extends "D:/NestEggVerification/evidence-20261120-ne222-ledge-support/fall.gd"

const VAULT := "res://data/levels/ch1_vault.tres"
const LEDGE_Y := 45.0 * 16.0
const LOW_FLOOR := 49.0 * 16.0
var _field: Array[Dictionary] = []


func _run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
	if out_dir.is_empty() or DisplayServer.get_name() == "headless":
		push_error("Vault support probe requires the native viewport")
		get_tree().quit(2)
		return
	Story.auto_skip = true
	Settings.set_reduce_flashes(true)
	for old_movement: bool in [true,false]:
		for facing: int in [-1,1]:
			await _test_vault(facing,old_movement)
	var file := FileAccess.open(out_dir.path_join("field.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(_field,"	"))
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)


func _test_vault(facing: int, old_movement: bool) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	level = Level.new()
	level.configure(load(VAULT) as LevelData)
	add_child(level)
	await settle(25)
	player = level.player
	await clear_enemies()
	level.child_entered_tree.connect(func(node: Node) -> void:
		if node is DeathScreen:
			node.set_deferred("visible",false))
	var edge := Vector2((14.0 if facing==1 else 8.0)*16.0,LEDGE_Y)
	player.global_position = edge-Vector2(facing,3.0)
	player.velocity = Vector2.ZERO
	await settle(30)
	var camera := get_viewport().get_camera_2d() as LevelCamera
	_check(camera != null and camera.acquire_presentation_focus(self,edge+Vector2(0,30)),
		"the fixed stage camera watches the authored edge and landing")
	await settle(100)
	var caught := player.is_on_floor() and absf(player.global_position.y-LEDGE_Y)<1.0
	_check(caught and level._layout.platform_rects.has(Rect2i(8,45,6,1)),
		"the player is supported by the actual vault platform")
	var trace: Array[Dictionary] = []
	player.health.setup(100,0.0)
	player.facing = facing
	var blow := DamageInfo.create(9999,Combat.Team.ENEMY,&"fatal_fall_probe")
	blow.origin = player.global_position-Vector2(facing*30.0,0)
	blow.knockback = Vector2(facing*140.0,0)
	blow.impact = 7.0
	blow.ignore_invulnerability = true
	_check(player.health.take_damage(blow) and player.is_dead(),"the original damage path kills on the upper deck")
	if old_movement:
		player._corpse_support_left = 0.0
	var name := "%s-facing-%d" % ["before" if old_movement else "after",facing]
	var rig := player._visual.rig
	for frame in 84:
		await get_tree().physics_frame
		var points := {}
		for bone: StringName in BONES:
			var pos := rig.bone(bone).global_position
			points[bone] = [pos.x,pos.y]
		trace.append({"frame":frame,"root":[player.global_position.x,player.global_position.y],
			"contact":player.is_on_floor(),"support":_solid_below(points,player.global_position),"bones":points})
		if frame in [0,24,34,44,54,72]:
			await RenderingServer.frame_post_draw
			capture("%s-%02d" % [name,frame])
	var goal := LEDGE_Y if old_movement else LOW_FLOOR
	_check(player.is_on_floor() and absf(player.global_position.y-goal)<1.0,name+" actual final terrain contact")
	_field.append({"facing":facing,"old_movement":old_movement,"edge":[edge.x,edge.y],"trace":trace})
	camera.release_presentation_focus(self)
	await finish()


func _solid_below(points: Dictionary, foot: Vector2) -> Dictionary:
	var entries := {}
	var state := player.get_world_2d().direct_space_state
	for bone: StringName in [&"hip",&"chest",&"head"]:
		var x: float = points[bone][0]
		var request := PhysicsRayQueryParameters2D.create(Vector2(x,foot.y-14.0),Vector2(x,foot.y+96.0),Layers.SOLID)
		var result := state.intersect_ray(request)
		entries[bone] = result["position"].y if not result.is_empty() else null
	return entries
