extends ScenarioBase

const STEPS := 73
const BONES := [&"hip", &"chest", &"head", &"hand_front", &"hand_back", &"foot_front", &"foot_back"]

var _rows: Array[Dictionary] = []
var _frames := false
var _quick := false
var _no_hitstop := false


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
		elif arg == "--frames":
			_frames = true
		elif arg == "--quick":
			_quick = true
		elif arg == "--no-hitstop":
			_no_hitstop = true
	if out_dir.is_empty():
		push_error("fall probe needs --out")
		get_tree().quit(2)
		return
	_frames = _frames and DisplayServer.get_name() != "headless"
	Story.auto_skip = true
	Settings.set_reduce_flashes(true)
	if _no_hitstop:
		Settings.set_feel_scale("hitstop", 0.0)
	add_child(LightKit.create_environment())
	var cases: Array[String] = ["flat", "edge"]
	for scenario in cases:
		for face: int in [-1, 1] if not _quick else [1]:
			for from_front: bool in [true, false]:
				for impact: float in [1.0, 7.0] if not _quick else [7.0]:
					await _sample(scenario,face,from_front,impact)
	var f := FileAccess.open(out_dir.path_join("samples.json"),FileAccess.WRITE)
	if f == null:
		push_error("missing fall probe result")
		failures += 1
	else:
		f.store_string(JSON.stringify(_rows, "\t"))
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)


func _sample(scenario: String, face: int, from_front: bool, impact: float) -> void:
	await open_arena("res://data/lighting/neutral.tres",30.0)
	await clear_enemies()
	level.child_entered_tree.connect(func(node: Node) -> void:
		if node is DeathScreen:
			node.set_deferred("visible", false))
	seed(222236)
	var x := player.global_position.x
	var floor := FLOOR_Y
	var ledge_y := floor - 74.0
	if scenario == "edge":
		var platform := StaticBody2D.new()
		platform.position = Vector2(x - face * 32.0,ledge_y + 5.0)
		platform.collision_layer = Layers.WORLD
		platform.collision_mask = 0
		var shape := RectangleShape2D.new()
		shape.size = Vector2(64.0, 10.0)
		var surface := CollisionShape2D.new()
		surface.shape = shape
		platform.add_child(surface)
		var surface_draw := Polygon2D.new()
		surface_draw.color = Color("426783")
		surface_draw.polygon = PackedVector2Array([Vector2(-32,-5),Vector2(32,-5),Vector2(32,5),Vector2(-32,5)])
		platform.add_child(surface_draw)
		level.add_child(platform)
		player.global_position = Vector2(x - face * 1.0,ledge_y - 3.0)
		await settle(12)
	elif scenario == "drop":
		player.global_position = Vector2(x, floor - 124.0)
		await settle(2)
	elif scenario == "jump":
		Input.action_press(&"jump")
		for i in 10:
			await get_tree().physics_frame
		Input.action_release(&"jump")
	snap_camera()
	player.facing = face
	var rig: CharacterRig = player._visual.rig
	var anim := rig.animator as HumanoidAnimator
	var expected_ground := scenario in ["flat", "edge"]
	var label := "%s_f%d_%s_%d" % [scenario,face,"front" if from_front else "back",int(impact)]
	_check(player.is_on_floor() == expected_ground,label + " expected initial physical contact")
	_check(scenario != "edge" or absf(player.global_position.y - ledge_y) < 1.0,label + " real ledge holds player at edge")
	var side := face if from_front else -face
	var blow := DamageInfo.create(9999, Combat.Team.ENEMY, &"fatal_fall_probe")
	blow.origin = player.global_position + Vector2(side * 30, 0)
	blow.knockback = Vector2(-side * 140,0) if impact > 1.0 else Vector2.ZERO
	blow.impact = impact
	blow.ignore_invulnerability = true
	_check(player.health.take_damage(blow) and player.is_dead(),label+" real damage makes corpse")
	var trace: Array[Dictionary] = []
	for frame in STEPS:
		await get_tree().physics_frame
		if _frames and frame in [0,12,24,36,48,60,72]:
			await RenderingServer.frame_post_draw
		var points := {}
		for key in BONES:
			var point := rig.bone(key).global_position
			points[key] = [point.x,point.y]
		trace.append({"frame":frame,"root":[player.global_position.x,player.global_position.y],
			"vel":[player.velocity.x,player.velocity.y],"contact":player.is_on_floor(),"time":anim._death_time,
			"duration":anim._death_duration(),"rest_shift":anim._ground_shift,"bones":points,
			"rotation":rig.bone(&"hip").rotation,"dir":anim._death_dir,"force":anim._death_force,
			"support":_probe_support(points, player.global_position)})
		if _frames and frame in [0,12,24,36,48,60,72]:
			capture("%s_%02d" % [label,frame])
	_rows.append({"scenario":scenario,"facing":face,"front":from_front,"impact":impact,"level_floor":floor,
		"ledge_floor":ledge_y if scenario=="edge" else null,"ledge_x":x if scenario=="edge" else null,"trace":trace})
	await finish()


func _check(ok: bool, why: String) -> void:
	if ok:
		print("PASS ",why)
	else:
		failures += 1
		push_error(why)



func _probe_support(points: Dictionary, foot: Vector2) -> Dictionary:
	var reads := {}
	var world := player.get_world_2d().direct_space_state
	for bone: StringName in [&"hip",&"chest",&"head"]:
		var x: float = points[bone][0]
		var query := PhysicsRayQueryParameters2D.create(Vector2(x,foot.y-12.0),Vector2(x,foot.y+96.0),Layers.WORLD)
		var hit := world.intersect_ray(query)
		reads[bone] = [hit["position"].y,hit["normal"].y] if not hit.is_empty() else []
	return reads
