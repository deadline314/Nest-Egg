extends Node

const FLOOR := ["#", "=", "~"]
const MAXIMUM := 64

func _ready() -> void:
	var layouts: Array[Dictionary] = []
	var folder := "res://data/levels"
	for filename: String in DirAccess.get_files_at(folder):
		if not filename.ends_with(".tres") or not (filename.begins_with("ch1_") or filename.begins_with("ch2_")):
			continue
		var path := folder.path_join(filename)
		var data := load(path) as LevelData
		if data == null:
			continue
		var layout := LevelBuilder.parse(data)
		if not layout.is_valid():
			push_error("[clearance] invalid layout %s" % path)
			get_tree().quit(1)
			return
		layouts.append({"path": path, "id": str(data.id), "chapter": str(data.chapter),
			"size": [layout.width, layout.height], "tile": layout.tile_size,
			"solid": scan(layout, ["#"]), "visible": scan(layout, FLOOR)})
	var out := OS.get_cmdline_user_args()[0]
	var file := FileAccess.open(out, FileAccess.WRITE)
	if file == null:
		push_error("[clearance] could not write %s" % out)
		get_tree().quit(2)
		return
	file.store_string(JSON.stringify(layouts, "\t") + "\n")
	file.close()
	print("audited ", layouts.size(), " level resources")
	get_tree().quit(0)

func scan(layout: LevelLayout, roof_kinds: Array) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for y in range(1, layout.height):
		var left := 0
		var previous := ""
		for x in range(layout.width + 1):
			var roof := -1
			var floor := layout.cell(x, y) if x < layout.width else "."
			if floor in FLOOR and layout.cell(x, y - 1) not in FLOOR:
				for ry in range(y - 2, maxi(-1, y - int(MAXIMUM / float(layout.tile_size)) - 2), -1):
					if layout.cell(x, ry) in roof_kinds:
						roof = ry
						break
			var current := "%d %s %s" % [roof, layout.cell(x, roof), floor] if roof >= 0 else ""
			if previous != current and not previous.is_empty():
				var part := previous.split(" ")
				result.append({"first": left, "last": x - 1, "roof": int(part[0]), "floor": y,
					"height": (y - int(part[0]) - 1) * layout.tile_size, "roof_kind": part[1],
					"floor_kind": part[2], "adjoining": [layout.cell(left - 1, y), layout.cell(x, y)]})
			if previous != current:
				previous = current
				left = x
	return result
