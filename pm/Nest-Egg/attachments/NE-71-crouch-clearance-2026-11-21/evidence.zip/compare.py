from pathlib import Path
import json
base=Path(__file__).resolve().parent

def read(path):
    return json.loads((base/path).read_bytes())

def by(scope):
    return {r['label']:r for r in read(f'{scope}/passes.json')}

def crouch(data):
    return [row for key,row in data.items() if key.endswith('-crouch')]

coverage=read('layouts.json')
assert len(coverage)==21 and sum(len(row['solid']) for row in coverage)==9
assert {p['height'] for row in coverage for p in row['solid']}=={48}
results={}
for name,before,after,count in (('headless','headless','headless-v2',36),('native','native-stock','native-v2',12)):
    stock,new=by(before),by(after)
    assert len(stock)==len(new)==count and stock.keys()==new.keys()
    assert all(row['passed'] and row['wrong_stance_frames']==0 and row['off_floor_frames']==0 for row in new.values())
    for key,row in stock.items():
        if key.endswith('-stand'):
            for field in ('start','exit','target','physics_frames','floor','height','passed','not_dead'):
                if field=='exit' and name=='native':
                    assert abs(new[key][field]-row[field])<0.1
                else:
                    assert new[key][field]==row[field], (name,key,field)
        else:
            assert not row['passed'] and row['exit']==row['start']
    rows=crouch(new)
    gap=min(row['min_visual_gap'] for row in rows)
    boot=max(row['max_painted_boot_depth'] for row in rows)
    assert gap>1.0 and boot<0.05, (gap,boot)
    results[name]={'routes':count,'crouch':len(rows),'previously_blocked':len(rows),
                   'min_visual_gap':gap,'max_painted_boot_depth':boot}
guide=(base/'guide.log').read_text(encoding='utf8')
assert 'CROUCH_GUIDE 按住 N，用 A／D 蹲行。' in guide and 'passed true' in guide
assert 'ERROR:' not in guide

if (base/'analog-v2/passes.json').is_file():
    rows=by('analog-v2')
    if len(rows)==12 and all(row['passed'] for row in rows.values()):
        assert min(row['min_visual_gap'] for row in crouch(rows))>0.0
        results['synthetic_axes']={'rows':len(rows),'crouch':len(crouch(rows))}

(base/'verification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(results)
