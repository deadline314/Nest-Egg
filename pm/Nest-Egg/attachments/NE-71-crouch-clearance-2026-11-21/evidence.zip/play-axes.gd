extends Node

var _rows: Array[Dictionary] = []
var _out := ""
var _native := false
var _use_raw_axes := false

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	_run.call_deferred()

func _run() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() < 2:
		get_tree().quit(2)
		return
	_out = args[1]
	_native = DisplayServer.get_name() != "headless"
	_use_raw_axes = args.size() > 3 and args[3] == "analog"
	var plans: Variant = JSON.parse_string(FileAccess.get_file_as_string(args[0]))
	Story.auto_skip = true
	for plan: Dictionary in plans:
		var passages: Array = plan["solid"]
		if passages.is_empty() or (args.size() > 2 and not String(plan["id"]) in args[2].split(",")):
			continue
		GameState.start_new_run(GameState.difficulties[1])
		var level := Level.new()
		level.configure(load(plan["path"]) as LevelData)
		add_child(level)
		await _frames(50)
		var player: Player = level.player
		if not is_instance_valid(player):
			push_error("[clearance] player did not load %s" % plan["path"])
			get_tree().quit(3)
			return
		level._next_story_trigger = level._layout.story_triggers.size()
		player.health.grant_invulnerability(300.0)
		for node in get_tree().get_nodes_in_group(&"enemies"):
			if node is Enemy:
				node.set_physics_process(false)
		AimInput.set_virtual_gamepad(player, true)
		for p: Dictionary in passages:
			for direction: int in [1, -1]:
				for crouch: bool in [false, true]:
					var result := await _passage(plan, p, player, level._layout, direction, crouch)
					_rows.append(result)
					print("PASSAGE ", str(result))
		_release()
		level.queue_free()
		await _frames(8)
	var output := FileAccess.open(_out.path_join("passes.json"), FileAccess.WRITE)
	if output == null:
		get_tree().quit(4)
		return
	output.store_string(JSON.stringify(_rows, "\t") + "\n")
	output.close()
	await AudioRelease.settle(get_tree())
	var failures := _rows.filter(func(row: Dictionary) -> bool: return not row["passed"])
	print("PASSAGES ", _rows.size(), " failures ", failures.size())
	get_tree().quit(0 if failures.is_empty() else 1)

func _passage(plan: Dictionary, p: Dictionary, player: Player, layout: LevelLayout, direction: int, crouch: bool) -> Dictionary:
	_release()
	var tile := int(plan["tile"])
	var y := float(p["floor"] * tile)
	var left := float(p["first"] * tile)
	var right := float((p["last"] + 1) * tile)
	var start := Vector2(left - 10.0 if direction > 0 else right + 10.0, y - 0.4)
	var target := right + 9.0 if direction > 0 else left - 9.0
	var label := "%s-%s-%s-%s" % [plan["id"], p["first"], "r" if direction > 0 else "l", "crouch" if crouch else "stand"]
	var result := {"label": label, "start": start.x, "target": target, "floor": y, "height": p["height"], "passed": false}
	result["starts_clear"] = layout.fits_body(start, Player.BODY_SIZE)
	if not result["starts_clear"]:
		return result
	player.global_position = start
	player.velocity = Vector2.ZERO
	Input.action_press(&"aim_right" if direction > 0 else &"aim_left")
	if crouch:
		if _use_raw_axes:
			_axis(JOY_AXIS_LEFT_Y, 0.80)
		else:
			Input.action_press(&"move_down")
	await _frames(22 if _native else 8)
	var action := &"move_right" if direction > 0 else &"move_left"
	if _use_raw_axes:
		_axis(JOY_AXIS_LEFT_X, 0.80 * direction)
	else:
		Input.action_press(action)
	var count := 0
	var different_stance := 0
	var off_floor := 0
	var max_sole_error := 0.0
	var captured := false
	var visual_gap := INF
	var painted_boot_depth := -INF
	while count < 140 and (player.global_position.x - target) * direction < 0.0:
		await _frames(1)
		count += 1
		if player.is_crouching != crouch:
			different_stance += 1
		if not player.is_on_floor():
			off_floor += 1
		max_sole_error = maxf(max_sole_error, absf(player.global_position.y - y))
		if player.global_position.x >= left + 3.0 and player.global_position.x <= right - 3.0:
			var rig := player._visual.rig
			visual_gap = minf(visual_gap, rig.visual_bounds().position.y - float((p["roof"] + 1) * tile))
			painted_boot_depth = maxf(painted_boot_depth, rig.animator.foot_floor_depth() * rig.body_scale())
		if _native and not captured and player.global_position.x >= left + 3.0 and player.global_position.x <= right - 3.0:
			captured = true
			await RenderingServer.frame_post_draw
			var picture := get_viewport().get_texture().get_image()
			if picture == null or picture.save_png(_out.path_join(label + ".png")) != OK:
				push_error("[clearance] could not capture " + label)
	if _native and not captured:
		await RenderingServer.frame_post_draw
		var blocked := get_viewport().get_texture().get_image()
		if blocked != null:
			blocked.save_png(_out.path_join(label + "-blocked.png"))
	result.merge({"exit": player.global_position.x, "physics_frames": count, "wrong_stance_frames": different_stance, 
		"off_floor_frames": off_floor, "max_sole_error": max_sole_error, "not_dead": not player.is_dead(), "min_visual_gap": visual_gap if is_finite(visual_gap) else null, "max_painted_boot_depth": painted_boot_depth if is_finite(painted_boot_depth) else null}, true)
	result["passed"] = ((player.global_position.x - target) * direction >= 0.0 and different_stance == 0
		and off_floor == 0 and max_sole_error <= 0.7 and result["not_dead"] and (captured or not _native))
	_release()
	await _frames(3)
	return result

func _axis(axis: JoyAxis, strength: float) -> void:
	var event := InputEventJoypadMotion.new()
	event.device = 0
	event.axis = axis
	event.axis_value = strength
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _release() -> void:
	if _use_raw_axes:
		_axis(JOY_AXIS_LEFT_X, 0.0)
		_axis(JOY_AXIS_LEFT_Y, 0.0)
	for action in [&"move_left", &"move_right", &"move_down", &"aim_left", &"aim_right"]:
		Input.action_release(action)

func _frames(count: int) -> void:
	for frame in count:
		await get_tree().physics_frame



