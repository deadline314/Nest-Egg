extends Node

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	_capture.call_deferred()

func _capture() -> void:
	var args := OS.get_cmdline_user_args()
	if args.is_empty():
		get_tree().quit(2)
		return
	Settings.set_ui_text_scale(1.2)
	InputBindings._set_device(false, -1)
	var settings := SettingsScreen.new()
	add_child(settings)
	settings._tabs.current_tab = 1
	InputBindings.set_code(&"move_down", 0, KEY_N)
	await get_tree().process_frame
	await get_tree().process_frame
	var rules := settings._hold_rule_labels[0]
	var scroll := settings._tabs.get_tab_control(1) as ScrollContainer
	scroll.ensure_control_visible(rules)
	await get_tree().process_frame
	var expected := InputBindings.format("按住 {move_down}，用 {move_left}／{move_right} 蹲行。")
	var rules_bounds := rules.get_global_rect()
	var scroll_bounds := scroll.get_global_rect()
	var passed := rules.text.contains(expected) and expected.contains("N") and scroll_bounds.encloses(rules_bounds)
	print("CROUCH_GUIDE ", expected, " rules ", rules_bounds, " scroll ", scroll_bounds, " passed ", passed)
	await RenderingServer.frame_post_draw
	var picture := get_viewport().get_texture().get_image()
	if picture == null or picture.save_png(args[0]) != OK:
		passed = false
	get_tree().quit(0 if passed else 1)
