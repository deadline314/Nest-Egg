extends ScenarioBase

const LANES := {
	"ch1_prologue": [63, 67, 15, 80],
	"ch2_ledger_office": [58, 69, 11, 80],
	"level_01": [32, 38, 20, 64],
	"level_02": [88, 92, 14, 64],
	"level_02:first_low": [30, 36, 20, 64],
	"level_02:early_upper": [133, 149, 8, 64],
	"level_02:low_sector": [190, 198, 20, 64],
	"level_02:upper_landing": [248, 250, 8, 64],
	"level_02:middle_low": [253, 261, 20, 64],
	"level_02:open_service": [354, 359, 20, 80],
	"level_02:far_service": [372, 379, 20, 64],
}

var selected := ""
var rows: Dictionary = {}
var draw := false


func _ready() -> void:
	draw = DisplayServer.get_name() != "headless"
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
		elif arg.begins_with("--case="):
			selected = arg.trim_prefix("--case=")
	if not out_dir.is_absolute_path() or (not selected.is_empty() and selected != "current" and not LANES.has(selected)):
		get_tree().quit(2)
		return
	if draw:
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	for area: String in LANES:
		if selected.is_empty() or selected == area or (selected == "current" and area.begins_with("ch")):
			await _inspect(area, LANES[area])
	var file := FileAccess.open(out_dir.path_join("corridors.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures": failures, "runs":rows},"  ")+"\n")
	file.close()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)


func _inspect(area: String, lane: Array) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	var stage := load("res://data/levels/%s.tres" % area.get_slice(":",0)) as LevelData
	level = Level.new()
	level.configure(stage)
	add_child(level)
	await settle(12)
	player = level.player
	level._next_story_trigger = level._layout.story_triggers.size()
	level.hud.visible = false
	for node in level.get_children():
		if node is ChapterCard:
			node.queue_free()
	for node in level._entities.get_children():
		if node is Enemy:
			node.process_mode = Node.PROCESS_MODE_DISABLED
			node.hurtbox.enabled = false
			for part: Hurtbox in node.hurtbox.parts:
				part.enabled = false
			if node.contact != null:
				node.contact.active = false
	player.health.grant_invulnerability(20.0)
	AimInput.set_virtual_gamepad(player, true)
	var tile := float(stage.tile_size)
	var left: float = (lane[0] + 0.5) * tile
	var right: float = (lane[1] + 0.5) * tile
	var floor_y: float = lane[2] * tile
	var geometry: Array[float] = []
	var space := player.get_world_2d().direct_space_state
	for x in range(lane[0],lane[1] + 1):
		var px := (x + 0.5) * tile
		var ray := PhysicsRayQueryParameters2D.create(Vector2(px,floor_y - 4.0), Vector2(px,floor_y - 140.0),Layers.WORLD)
		var roof := space.intersect_ray(ray)
		if not roof.is_empty():
			geometry.append(floor_y - (roof["position"] as Vector2).y)
	_check(geometry.size()==lane[1]-lane[0]+1 and absf(geometry.min()-lane[3])<0.1,
		area + " actual solid headroom matches the map")
	var opened := await _open_authored_obstacles(left,right,floor_y)
	var cases: Dictionary = {}
	for side: int in [-1,1]:
		var start := right if side < 0 else left
		var ending := left if side < 0 else right
		player.global_position = Vector2(start,floor_y - 0.15)
		player.velocity = Vector2.ZERO
		AimInput.restore_direction(Vector2(side,0.0))
		await settle(9)
		_check(player.is_on_floor(), area+" starts supported")
		var action := &"move_left" if side < 0 else &"move_right"
		var middle := (left+right)*0.5
		Input.action_press(action)
		var approach := await _walk_to(middle,side,floor_y)
		Input.action_release(action)
		_check(approach["reached"], area+" reaches the midpoint with normal movement")
		await settle(9)
		_place_camera(middle,floor_y)
		await _frame(area+"_standing_"+str(side))
		Input.action_press(&"move_down")
		await settle(20)
		var squat_top := player._visual.rig.visual_bounds().position.y
		var squat_foot := player.global_position.y
		_check(player.is_crouching and player.is_on_floor() and absf(squat_foot-floor_y)<1.0
			and squat_top>floor_y-lane[3], area+" can crouch while supported beneath its actual ceiling")
		await _frame(area+"_crouching_"+str(side))
		Input.action_release(&"move_down")
		Input.action_press(action)
		var exit_lane := await _walk_to(ending,side,floor_y)
		Input.action_release(action)
		_check(exit_lane["reached"] and not player.is_on_wall(), area+" releases crouch and reaches the far side")
		_check(approach["grounded"] and exit_lane["grounded"] and maxf(approach["visual_height"],exit_lane["visual_height"]) < lane[3],
			area+" supported traversal stays below the actual roof")
		player.global_position = Vector2(start, floor_y - 0.15)
		player.velocity = Vector2.ZERO
		Input.action_press(&"move_down")
		await settle(18)
		Input.action_press(action)
		var crouch_walk := await _walk_to(ending, side, floor_y, true)
		Input.action_release(action)
		Input.action_release(&"move_down")
		_check(crouch_walk["reached"] and crouch_walk["grounded"] and crouch_walk["correct_stance"]
			and float(crouch_walk["visual_height"]) < lane[3], area+" crouch-walks the full original passage")
		cases[str(side)] = {"entry":approach,"exit":exit_lane,"squat_foot":squat_foot,"squat_top":squat_top,"crouch_walk":crouch_walk}
	rows[area] = {"headroom_samples":geometry,"floor_y":floor_y,"path_obstacles":opened,"cases":cases}
	Story.reset_active_presentation(&"route")
	await finish()


func _open_authored_obstacles(left: float, right: float, floor_y: float) -> Array:
	var opened: Array = []
	var entities := level._entities.get_children()
	for object in entities:
		if not object is Node2D or absf(object.global_position.y-floor_y) > 2.0:
			continue
		if object.global_position.x < left-1.0 or object.global_position.x > right+1.0:
			continue
		if object is Breakable and object.data.look in [BreakableData.Look.WALL, BreakableData.Look.GLASS, BreakableData.Look.BARREL] and not object.is_broken:
			var firing_x := left if object.global_position.x-left > right-object.global_position.x else right
			if object.data.explosion_radius > 0.0:
				firing_x = object.global_position.x - object.data.explosion_radius - 16.0
			player.global_position = Vector2(firing_x,floor_y-0.15)
			player.velocity = Vector2.ZERO
			await settle(12)
			AimInput.restore_direction(object.global_position - Vector2(0.0,object.size_px.y * 0.5) - player.aim_origin())
			await settle(2)
			Input.action_press(&"shoot")
			for frame in 130:
				if object.is_broken:
					break
				await get_tree().physics_frame
			Input.action_release(&"shoot")
			_check(object.is_broken, "original path obstacle is destroyed by live player fire")
			opened.append({"kind":String(object.data.id),"cell":str(object.cell),"opened":object.is_broken})
			await settle(20)
		elif object is Gate and not object.is_open:
			for candidate in entities:
				if not candidate is MechanismSwitch or candidate.data.channel != object.data.channel:
					continue
				player.global_position = candidate.global_position - Vector2(0.0,0.15)
				player.velocity = Vector2.ZERO
				await settle(12)
				Input.action_press(&"interact")
				for frame in 30:
					if object.is_open:
						break
					await get_tree().physics_frame
				Input.action_release(&"interact")
				opened.append({"kind":"gate","cell":str(object.cell),"switch":str(candidate.cell),"opened":object.is_open})
				await settle(8)
				if object.is_open:
					break
			_check(object.is_open, "original gate opens through its own switch")
	return opened


func _walk_to(goal: float, side: int, floor_y: float, crouched := false) -> Dictionary:
	var tallest := 0.0
	var stayed_on_floor := true
	var correct_stance := true
	for tick in (400 if crouched else 110):
		await get_tree().physics_frame
		correct_stance = correct_stance and (not crouched or player.is_crouching)
		var top := player._visual.rig.visual_bounds().position.y
		tallest = maxf(tallest, floor_y - top)
		stayed_on_floor = stayed_on_floor and absf(player.global_position.y - floor_y) < 1.0
		if (goal-player.global_position.x)*side <= 1.0:
			return {"reached":true,"feet":str(player.global_position),"grounded":stayed_on_floor,"correct_stance":correct_stance,
				"visual_height":tallest,"ticks":tick+1}
	return {"reached":false,"feet":str(player.global_position),"grounded":stayed_on_floor,"correct_stance":correct_stance,"visual_height":tallest}


func _place_camera(x: float, floor_y: float) -> void:
	if not draw:
		return
	var camera := level.camera
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	camera.position = Vector2(x,floor_y-34.0)
	camera.offset = Vector2.ZERO
	camera.reset_smoothing()
	camera.force_update_scroll()


func _frame(name: String) -> void:
	if draw:
		await RenderingServer.frame_post_draw
		capture(name.replace(":","-"))


func _check(value: bool, note: String) -> void:
	print("PASS " + note if value else "FAIL " + note)
	if not value:
		failures += 1

