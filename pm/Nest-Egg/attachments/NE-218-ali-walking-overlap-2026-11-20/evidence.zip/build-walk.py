from hashlib import sha256
from io import BytesIO
from pathlib import Path
from runpy import run_path
import json
import sys

import numpy as np
from PIL import Image

root = Path.cwd()
base = Path(__file__).resolve().parent
work = root / 'art_src/characters/ali'
published = base.parent / 'evidence-20261120-ne222-guard-hurt/published-source.json'
manifest = json.loads(published.read_bytes())
sys.path.insert(0, str(root / 'tools/comfyui'))
from part_overlap import extend_pixels
from cut_layers import part_transform, render_part

original = work / 'overrides/refined/torso.png'
assert sha256(original.read_bytes()).hexdigest() == manifest[original.relative_to(root).as_posix()]
builder = run_path(str(work / 'shoulder_overlap/rebuild.py'))
assert builder['build'](work) == original.read_bytes()
stock = np.asarray(Image.open(original).convert('RGBA'))
choices = {
    'patch-a': ((359.45, 411.2, 1.65), (359.60, 417.5, 1.65)),
    'patch-b': ((358.9, 411.2, 1.70), (359.25, 417.6, 1.75)),
}
label = sys.argv[1]
part = extend_pixels(stock, choices[label])
candidate = np.asarray(part)
assert np.array_equal(candidate[stock[..., 3] >= 128], stock[stock[..., 3] >= 128])
count = int(np.count_nonzero(np.any(stock != candidate, axis=2)))
assert 0 < count <= 40
spec = json.loads((root / 'tools/comfyui/specs/ali_side.json').read_bytes())
ratio = spec['tex_px_per_wp'] / spec['illustration_px_per_wp']
joints = {name: np.asarray(point) * ratio for name, point in spec['joints'].items()}
rule = spec['parts']['torso']
original_cut = part_transform(Image.fromarray(stock), rule, joints, ratio)
candidate_cut = part_transform(part, rule, joints, ratio)
assert all(np.array_equal(a, b) for a, b in zip(original_cut, candidate_cut, strict=True))
old = render_part(Image.fromarray(stock), original_cut, ratio, crop_phase=rule.get('crop_phase'))
new = render_part(part, candidate_cut, ratio, crop_phase=rule.get('crop_phase'))
exact = np.asarray(Image.open(root / 'art/characters/ali/parts/torso.png').convert('RGBA'))
assert np.array_equal(old, exact) and new.shape == exact.shape
out = base / ('ali-' + label)
out.mkdir()
part.save(out / 'source-torso.png')
Image.fromarray(new).save(out / 'torso.png')
stats = {'contacts': choices[label], 'source_changed': count,
         'diffuse_changed': int(np.count_nonzero(np.any(old != new, axis=2))),
         'dimensions': list(new.shape[:2][::-1])}
(out / 'build.json').write_text(json.dumps(stats, indent=2) + '\n', encoding='utf-8')
print(stats)
