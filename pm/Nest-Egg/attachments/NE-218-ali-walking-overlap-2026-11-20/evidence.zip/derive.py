from hashlib import sha256
from pathlib import Path
import json

base = Path(__file__).resolve().parent
root = Path.cwd()
source = root / 'tools/rig_joint_audit.gd'
expected = json.loads((base.parent / 'evidence-20261120-ne95-watchdog-phase-flash/published-source.json').read_bytes())
assert sha256(source.read_bytes()).hexdigest() == expected['tools/rig_joint_audit.gd']
script = source.read_text(encoding='utf-8')
changes = [
    ('or _only_npc_pose in ["lean", "crouch"]', 'or _only_npc_pose in ["lean", "crouch", "walk"]'),
    ('input.npc_loop = expected_npc_loop',
     'if pose == "walk":\n\t\t\t\t\t\t\t\tinput.velocity = Vector2(70.0 * input.facing, 0.0)\n'
     '\t\t\t\t\t\t\t\tinput.stage_grounded = true\n\t\t\t\t\t\t\tinput.npc_loop = expected_npc_loop'),
    ('rig.animate(1.0 / 60.0, entry["input"])',
     'var previous_phase := rig.animator._phase\n\t\t\t\t\trig.animate(1.0 / 60.0, entry["input"])'),
    ('if not animator._use_npc or animator._pose_now != expected_npc_pose or animator._loop_name != expected_npc_loop:',
     'var valid := (not animator._use_npc and not is_equal_approx(previous_phase, animator._phase)) if pose == "walk" else '
     'animator._use_npc and animator._pose_now == expected_npc_pose and animator._loop_name == expected_npc_loop\n'
     '\t\t\t\t\t\tif not valid:'),
]
for original, substitute in changes:
    assert script.count(original) == 1, original
    script = script.replace(original, substitute)
output = base / 'audit.gd'
output.write_text(script, encoding='utf-8', newline='\n')
scene = (root / 'tools/rig_joint_audit.tscn').read_text(encoding='utf-8')
assert scene.count('res://tools/rig_joint_audit.gd') == 1
(base / 'audit.tscn').write_text(scene.replace('res://tools/rig_joint_audit.gd', output.as_posix()),
                                  encoding='utf-8', newline='\n')
print('Original inspection renderer plus optional stage walk applied to external fixture only')
