from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys

base = Path(__file__).resolve().parent
shared = base.parent / 'ne218-baseline-20261117'
previous = base.parent / 'evidence-20261120-ne222-guard-hurt'
manifest = json.loads((previous / 'published-source.json').read_bytes())
expected_head = json.loads((previous / 'publish/result.json').read_bytes())['commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=shared, text=True).strip() == expected_head
parts = Path('art/characters/ali/parts')
for label in sys.argv[1:]:
    candidate = base / ('ali-' + label)
    imported = json.loads((candidate / 'imports.json').read_bytes())
    assert set(imported) == {'torso.png', 'torso_n.png'}
    alter = {parts / key: candidate / key for key in imported}
    for file in map(Path, imported.values()):
        assert (shared / file).parent.resolve() == (shared / '.godot/imported').resolve()
        alter[file] = candidate / 'import-project' / file
    before = {rel: (shared / rel).read_bytes() for rel in alter}
    assert all(sha256(data).hexdigest() == manifest[rel.as_posix()] for rel, data in before.items() if rel.parent == parts)
    try:
        for rel, new in alter.items():
            (shared / rel).write_bytes(new.read_bytes())
        subprocess.run([sys.executable, '-B', str(base / 'run.py'), 'walk', '-' + label], cwd=shared, check=True)
    finally:
        for rel, original in before.items():
            (shared / rel).write_bytes(original)
        assert all((shared / rel).read_bytes() == original for rel, original in before.items())
    print(label, 'preview finished and exact runtime restored')
