from pathlib import Path
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
root = Path.cwd()
for frame in (1, 52):
    out = base / f'shoulder-trace-{frame}'
    out.mkdir()
    env = os.environ.copy()
    for key in ('APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP', 'TMPDIR'):
        d = out / key
        d.mkdir()
        env[key] = str(d)
    cmd = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--quit-after', '900', str(base / 'audit.tscn'), '--',
           f'--out={out}', '--chars=ali', '--joints=shoulder_front', '--frames=60', '--zooms=3.4',
           '--npc-performance', '--npc-pose=walk', '--trace-joint=shoulder_front', f'--trace-frame={frame}']
    with (out / 'engine.log').open('wb') as log:
        proc = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=160)
    raw = (out / 'engine.log').read_text(encoding='utf-8', errors='replace')
    assert proc.returncode == 0 and not re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit', raw, re.M), raw
    shot, = json.loads((out / 'frames.json').read_bytes())
    assert shot['cells'][0]['geometry_frame'] == frame and shot['cells'][0]['geometry_sample']
    print(frame, len(shot['cells'][0]['geometry_sample']), flush=True)
