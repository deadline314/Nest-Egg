from pathlib import Path
import json
import sys

import numpy as np
from PIL import Image
from scipy import ndimage

root = Path.cwd()
base = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'tools/comfyui'))
from cut_layers import part_transform


def pixel_uv(part, cell_point):
    transform = np.asarray(part['to_cell'])
    local = np.linalg.solve(transform[:, :2], cell_point - transform[:, 2])
    if 'rect_origin' in part:
        return local - part['rect_origin']
    vertex, uv = (np.asarray(part[key]) for key in ('vertices', 'uv'))
    for triangle in part['triangles']:
        points = vertex[triangle]
        barycenter = np.linalg.solve((points[1:] - points[0]).T, local - points[0])
        if min(barycenter) >= -1e-5 and sum(barycenter) <= 1.00001:
            return (1.0 - sum(barycenter)) * uv[triangle[0]] + barycenter @ uv[triangle[1:]]
    return None


spec = json.loads((root / 'tools/comfyui/specs/ali_side.json').read_bytes())
ratio = spec['tex_px_per_wp'] / spec['illustration_px_per_wp']
joints = {name: np.asarray(point) * ratio for name, point in spec['joints'].items()}
sources = {}
for name in ('torso', 'arm_upper'):
    work = root / 'art_src/characters/ali'
    src = work / f'overrides/refined/{name}.png'
    if not src.is_file():
        src = work / f'07_refined/{name}.png'
    with Image.open(src) as loaded:
        full = loaded.convert('RGBA')
    sources[name] = (np.asarray(full.getchannel('A')), part_transform(full, spec['parts'][name], joints, ratio)[0])
rows = []
for frame in (1, 52):
    out = base / f'shoulder-trace-{frame}'
    record, = json.loads((out / 'frames.json').read_bytes())
    cell = record['cells'][0]
    assert cell['geometry_frame'] == frame and record['zoom'] == 3.4
    with Image.open(out / record['samples'][frame]['file']) as atlas:
        alpha = np.asarray(atlas.getchannel('A'))[:128, :128]
    radius = cell['radius']
    low = 64 - radius
    opaque = alpha[low:64 + radius, low:64 + radius] >= 128
    holes = ndimage.binary_fill_holes(opaque, structure=np.ones((3, 3))) & ~opaque
    assert holes.sum() == 2, frame
    for y, x in zip(*np.where(holes), strict=True):
        point = np.asarray([x + low + .5, y + low + .5])
        info = {}
        for part in cell['geometry_sample']:
            name = Path(part['texture']).stem
            inside = pixel_uv(part, point)
            if inside is None:
                continue
            alpha_data, affine = sources[name]
            source = (affine[:, :2] @ inside + affine[:, 2]) / ratio
            xx, yy = np.floor(source).astype(int)
            if 0 <= yy < alpha_data.shape[0] and 0 <= xx < alpha_data.shape[1]:
                info[name] = {'source': source.round(3).tolist(), 'alpha': int(alpha_data[yy, xx]),
                              'diffuse': inside.round(3).tolist()}
        rows.append({'frame': frame, 'point': point.tolist(), 'pixel_alpha': int(alpha[y + low, x + low]), 'parts': info})
(base / 'contact-source.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
for row in rows:
    print(row)
