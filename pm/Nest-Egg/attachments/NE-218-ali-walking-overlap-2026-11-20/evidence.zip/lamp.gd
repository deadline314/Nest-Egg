extends "res://tools/ch1_flow_probe.gd"

const STREET := preload("res://data/levels/ch1_street.tres")
const LAMP := preload("res://art/portraits/lamp.png")
const WAV := preload("res://art/portraits/wataru.png")
var _radios: Array[Dictionary] = []


func _ready() -> void:
	add_child(LightKit.create_environment())
	super._ready()


func _run() -> void:
	Settings.use_storage("user://lamp_portrait.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_prologue_done")
	GameState.set_flag(&"ch1_dinner_done")
	GameState.set_flag(&"ch1_heard_brief")
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	_level = Level.new()
	_level.configure(STREET)
	add_child(_level)
	for object in get_tree().get_nodes_in_group(&"enemies"):
		object.process_mode = Node.PROCESS_MODE_DISABLED
	await _settle(50)
	var expected_hp := _level.player.health.current
	for scale: float in [1.0, 1.2]:
		Settings.set_ui_text_scale(scale)
		Story._layer.cancel_radio()
		await _settle(4)
		_check(Story.play(&"ch1_g06_lamp", false), "the original street radio enqueues")
		await _settle(16)
		var portrait := Story._layer._radio_portrait
		var text := Story._layer._radio_text.text
		_check(portrait.is_visible_in_tree() and portrait.texture == LAMP and portrait.texture != WAV,
			"actual street radio uses Lamp's own portrait")
		_check(LAMP.get_width() == 256 and LAMP.get_height() == 256 and LAMP.get_image().detect_alpha() != Image.ALPHA_NONE,
			"the imported native portrait is a 256px transparent crop")
		_check(text.contains("我是幫你看路的燈") and _level.player.health.current == expected_hp and not Story.is_cinematic_active(),
			"authored street radio preserves dialogue and play state")
		await RenderingServer.frame_post_draw
		_capture("lamp-%s" % str(scale))
		_radios.append({"scale": scale, "texture": portrait.texture.resource_path, "text": text,
			"rect": str(portrait.get_global_rect())})
	Story._layer.cancel_radio()
	var data := FileAccess.open(_out_dir.path_join("lamp.json"), FileAccess.WRITE)
	data.store_string(JSON.stringify({"failures": _failures, "radios": _radios, "adapter": RenderingServer.get_video_adapter_name()}, "  ") + "\n")
	data.close()
	AudioRelease.begin_shutdown()
	_level.queue_free()
	await _settle(6)
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(_failures > 0))
