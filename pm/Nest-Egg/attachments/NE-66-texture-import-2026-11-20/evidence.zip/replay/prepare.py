from pathlib import Path
from shutil import copyfile
from unittest.mock import patch
import json
import sys

root=Path.cwd()
base=Path(__file__).resolve().parent
expected=Path('D:/NestEggVerification/evidence-20261120-st19-pear/import-policy-comparison.json')
paths=set(json.loads(expected.read_bytes())['baseline_stale_paths'])
sys.path.insert(0, str(root/'tools/assets'))
import texture_import

changes={}
def capture(path, content, *args, **kwargs):
    changes[path.relative_to(root).as_posix()]=content

with patch.object(Path,'write_text',capture):
    texture_import.apply_policy()
assert set(changes)==paths and len(paths)==10
names=sorted(paths)
for variant in ('before','candidate'):
    project=base/variant
    project.mkdir()
    (project/'project.godot').write_text('config_version=5\n[application]\nconfig/name="Texture Import Audit"\n',encoding='utf-8')
    for name in names:
        out=project/name
        out.parent.mkdir(parents=True,exist_ok=True)
        copyfile(root/Path(name).with_suffix(''),out.with_suffix(''))
        if variant=='before':
            copyfile(root/name,out)
        else:
            out.write_text(changes[name],encoding='utf-8',newline='\n')
(base/'paths.json').write_text(json.dumps(names,indent=2)+'\n',encoding='utf-8')
