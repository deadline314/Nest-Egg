extends SceneTree

func _initialize() -> void:
	call_deferred("_report")

func _report() -> void:
	var args := OS.get_cmdline_user_args()
	var paths: Array = JSON.parse_string(FileAccess.get_file_as_string(args[0]))
	var rows := {}
	var failed := false
	for record: String in paths:
		var path := "res://" + record.trim_suffix(".import")
		var texture := ResourceLoader.load(path) as Texture2D
		if texture == null:
			push_error("Missing imported texture " + path)
			failed = true
			continue
		var pixels := texture.get_image()
		rows[record] = {"width":texture.get_width(), "height":texture.get_height(),
				"decoded_bytes":pixels.get_data().size(), "format":pixels.get_format(), "mipmaps":pixels.has_mipmaps()}
	var handle := FileAccess.open(args[1], FileAccess.WRITE)
	handle.store_string(JSON.stringify(rows, "  ") + "\n")
	quit(1 if failed else 0)
