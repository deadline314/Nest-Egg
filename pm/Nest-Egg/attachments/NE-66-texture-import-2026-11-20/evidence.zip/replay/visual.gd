extends Node

var _out := ""
const CASES := [&"ch2_t_s03_tea", &"ch3_t_c15_posted"]


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	assert(_out.is_absolute_path())
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	GameState.story_autosave = false
	GameState.start_new_run(GameState.difficulties[1])
	add_child(LightKit.create_environment())
	var table := {}
	var failed := false
	for id in CASES:
		var player := CutscenePlayer.new()
		add_child(player)
		player.play(id, Story._scenes[String(id)])
		for frame in 120:
			await get_tree().process_frame
			if is_instance_valid(player._stage) and player._dialogue.visible and player._dialogue.is_complete():
				break
		if not is_instance_valid(player._stage):
			push_error("The real cutscene stage failed to initialize: " + String(id))
			failed = true
			continue
		await RenderingServer.frame_post_draw
		var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
		if image.save_png(_out.path_join(String(id)+".png")) != OK:
			push_error("Could not save native screenshot: " + String(id))
			failed = true
		var sizes := {}
		for group in [player._stage.front, player._stage.back]:
			for node in group.get_children():
				if not node is StageLayers._Sprite or not node.texture is CanvasTexture:
					continue
				var diffuse := (node.texture as CanvasTexture).diffuse_texture
				var key := diffuse.resource_path
				if key.contains("rooftop__torn_umbrella_tea.png") or key.contains("clearwater__reception_desk.png"):
					sizes[key] = {"texture":str(diffuse.get_size()),"scale":str(node.scale),
						"logical_width":diffuse.get_width()*node.scale.x}
		table[String(id)] = sizes
		player.cancel()
		for frame in 6:
			await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	var output := FileAccess.open(_out.path_join("stage-report.json"), FileAccess.WRITE)
	output.store_string(JSON.stringify(table, "  ") + "\n")
	get_tree().quit(1 if failed else 0)
