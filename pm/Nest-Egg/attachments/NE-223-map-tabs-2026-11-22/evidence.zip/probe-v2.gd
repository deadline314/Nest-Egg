extends "res://tests/smoke_test.gd"

var _out := ""


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://map_tabs_probe.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
	super._ready()


func _run() -> void:
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(load("res://data/levels/ch1_pawnshop.tres") as LevelData)
	add_child(level)
	await _frames(36)
	var menu := level._pause_menu
	await _send_key(KEY_M)
	await _frames(10)
	var map := menu._navigation
	_check(is_instance_valid(map) and map._page == "region" and get_tree().paused, "real pawnshop map opens from M")
	if not is_instance_valid(map):
		await _finish()
		return
	var map_focus := map._buttons[2]
	map_focus.grab_focus()
	await _send_key(KEY_Q)
	await _frames(4)
	_check(map._page == "quests", "Q visits the sibling quests page")
	await _send_key(KEY_ESCAPE)
	await _frames(5)
	var focus := get_viewport().gui_get_focus_owner() as Button
	_check(map._page == "region" and focus != null and focus.text == "回到所在區域", "one new tab still returns to the previous page and focus")
	await _send_key(KEY_E)
	await _frames(5)
	_check(map._page == "world", "E opens the authored world map")
	var destination: Button
	for marker in map._canvas._markers:
		if not marker.text.begins_with("▲ "):
			destination = marker
			break
	_check(destination != null, "world map offers a correlated destination")
	if destination != null:
		var title := destination.text
		destination.grab_focus()
		await _send_button(JOY_BUTTON_A)
		await _frames(5)
		_check(map._page == "region" and map._map_path != map.player_path, "regional drill-down from the world map works")
		await _send_button(JOY_BUTTON_B)
		await _frames(5)
		focus = get_viewport().gui_get_focus_owner() as Button
		_check(map._page == "world" and focus != null and focus.text == title, "Back restores the original world node")
		await _send_button(JOY_BUTTON_B)
		await _frames(5)
		_check(map._page == "region" and map._map_path == map.player_path, "Back from world returns to the original region")
	for index in 6:
		await _send_key(KEY_Q)
		await _frames(2)
		await _send_button(JOY_BUTTON_RIGHT_SHOULDER)
		await _frames(2)
	_check(map._page == "region", "six loops leave the original region selected")
	print("TAB_LOOPS ", map._history.size(), " page=", map._page)
	_check(map._history.is_empty(), "returning to an earlier tab discards the loop")
	await _shot("region")
	await _send_button(JOY_BUTTON_B)
	await _frames(5)
	var returned := not is_instance_valid(menu._navigation)
	_check(returned and menu._root.visible and get_tree().paused, "one Back after cycling tabs returns to the pause menu")
	var final_focus := get_viewport().gui_get_focus_owner()
	_check(returned and final_focus != null and menu._menu_panel.is_ancestor_of(final_focus), "the pause menu owns focus after Back")
	await _shot("after-back")
	menu.close()
	await _frames(2)
	level.queue_free()
	await _frames(2)
	await _finish()


func _send_key(code: Key) -> void:
	var press := InputEventKey.new()
	press.keycode = code
	press.physical_keycode = code
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _send_button(button: JoyButton) -> void:
	var press := InputEventJoypadButton.new()
	press.button_index = button
	press.pressure = 1.0
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	release.pressure = 0.0
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _shot(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join(name + ".png")) == OK, "saved " + name)