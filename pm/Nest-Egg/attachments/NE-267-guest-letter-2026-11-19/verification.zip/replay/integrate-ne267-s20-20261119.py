from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118/s20-stationery-v6')
prior = base.parents[1] / 'ne267-candidate-20261118/roof-watcher-v7/integration'
rejected = base.with_name('s20-stationery-v5') / 'integration'
out = base / 'integration'
resuming = '--resume' in sys.argv
if not resuming:
    out.mkdir()
expected = json.loads((prior / 'publish/result.json').read_text())['commit']
published = json.loads((prior / 'published-source.json').read_text())
assert all(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=project).decode().strip() == expected for project in (root, shared))
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root).strip() == b'codex/ticket-work-20261119-ne267-guests'

native = json.loads((base / 'native/result.json').read_text())
assert native['exit'] == 0 and not native['errors'] and native['source_held']
app = json.loads((base / 'native/scenes.json').read_text())
assert len(app['scenes']) == 3 and not app['failures'] and '9070 XT' in app['adapter']
assert all(scene['flags_unchanged'] and scene['credits_unchanged'] for scene in app['scenes'])
assert native['contact_count'] > 90 and not native['failures']

source = base / 'author-files'
adoption = json.loads((source / 'paths.json').read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def snapshot(project, paths):
    return {name:sha(project / name) for name in paths}

def current(project, name):
    return sha(project / name) if (project / name).is_file() else None

if not resuming:
    red = json.loads((rejected / 'official/result.json').read_text())
    assert red['exit'] == 1 and red['source_held']
    previous = json.loads((rejected / 'source.json').read_text())
    assert snapshot(shared, previous) == previous
for row in adoption:
    name = row['path']
    assert sha(source / name) == row['after']
    expected_present = row['after'] if resuming else row.get('previous_candidate', row['after'])
    assert all(current(project, name) == expected_present for project in (root, shared)), (name, row)
    if name in native['source']:
        assert native['source'][name] == row['after']
paths = [row['path'] for row in adoption]
guard = published | {row['path']:row['after'] for row in adoption}
if not resuming:
    for project in (root, shared):
        for row in adoption:
            name = row['path']
            if 'previous_candidate' in row:
                (project / name).write_bytes((source / name).read_bytes())
assert snapshot(shared, guard) == guard and snapshot(root, paths) == {name:guard[name] for name in paths}
(out / 'paths.json').write_text(json.dumps(paths, indent=2) + '\n')
(out / 'source.json').write_text(json.dumps(guard, indent=2) + '\n')

sys.path.insert(0, str(root / 'tools/story'))
sys.path.insert(0, str(root / 'tools/assets'))
from build_ch2_story import spec
from chapter_compiler import write_chapter
from build_hong_stationery import build
import stage_defs
missing = write_chapter(spec(), out / 'ch2_heron.json')
assert not missing and sha(out / 'ch2_heron.json') == guard['data/story/ch2_heron.json']
stage_out = out / 'ch2_guest_book_room.json'
stage_before = subprocess.check_output(['git', 'show', expected + ':data/cutscene/stages/ch2_guest_book_room.json'], cwd=root)
stage_out.write_bytes(stage_before)
stage_defs.STAGES = out
sys.argv = [sys.argv[0], 'ch2_guest_book_room']
assert stage_defs.main() == 0
assert sha(stage_out) == guard['data/cutscene/stages/ch2_guest_book_room.json']
build(out / 'hong_stationery.png')
for name in ('hong_stationery.png', 'hong_stationery_n.png'):
    assert sha(out/name) == guard['art/environment/scene_props/guest_book_contacts/'+name]

def run(name, command, cwd):
    destination = out / name
    destination.mkdir()
    env = os.environ.copy()
    env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', SHARDS='8', LOG_DIR=str(destination / 'shards'))
    for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
        env[key] = str(destination / 'profile' / key)
    (destination / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
    with (destination / 'raw.log').open('wb') as log:
        process = subprocess.run(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=2400)
    raw = (destination / 'raw.log').read_bytes()
    held = snapshot(shared, guard) == guard and snapshot(root, paths) == {name:guard[name] for name in paths}
    result = {'exit':process.returncode, 'errors':[line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line], 'source_held':held}
    (destination / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(name, result, raw.decode(errors='replace')[-1500:], flush=True)
    assert result == {'exit':0,'errors':[],'source_held':True}, result
    return result

run('import', [sys.executable, '-B', str(root/'tools/comfyui/gpu_lock.py'), '--',
               'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared), '--headless','--editor','--import'], shared)
run('compiler', [sys.executable, '-B', '-X', 'utf8', '-m', 'unittest', 'test_chapter_completion_policies',
                 'test_story_contracts', 'test_ch2_guest_cast'], root / 'tools/story')
flow = out / 'guest-book'
run('guest-book', ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless','--path',str(shared),
                   '--fixed-fps','60','--quit-after','24000','res://tools/ch2_flow_probe.tscn','--',
                   '--out='+str(flow),'--guest-book-only'], shared)
report = json.loads((flow/'guest-book-result.json').read_text(encoding='utf-8'))
assert report['failures'] == 0 and report['credit_delta'] == 100 and report['book_complete'] and not report['paused']
changed = ['C:/Program Files/Git/bin/bash.exe', '-c', f'python3() {{ python "$@"; }}; export -f python3; tools/run_tests_changed.sh {expected}']
result = run('official', changed, shared)
(out / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
