from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

root = Path.cwd()
project = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118')
source = base / sys.argv[1]
out = source / (sys.argv[2] if len(sys.argv) > 2 else 'native')
out.mkdir()
assets = 'art/environment/scene_props/guest_book_contacts/hong_stationery.png'
normal = assets.removesuffix('.png') + '_n.png'
mapping = {'data/story/ch2_heron.json': 'ch2_heron.json', 'data/cutscene/stages/ch2_guest_book_room.json': 'ch2_guest_book_room.json',
           'art/motion/guest_hong.json': 'guest_hong.json', assets: 'hong_stationery.png', normal: 'hong_stationery_n.png'}
if (source/'npc_animations.json').is_file():
    mapping['art/rigs/npc_animations.json'] = 'npc_animations.json'
sidecars = [project / (name+'.import') for name in (assets,normal)]
known = ['art/rigs/guest_hong.json','art/rigs/ali.json','art/characters/guest_hong/character.json','art/characters/ali/character.json',
         'game/cutscene/cutscene_player.gd','game/cutscene/cutscene_actor.gd','game/cutscene/stage_prop_hold.gd',
         'game/rig/npc_animator.gd','autoload/story.gd','game/cutscene/stage_library.gd']
known += [path.relative_to(root).as_posix() for skin in ('guest_hong','ali') for path in (root/'art/characters'/skin/'parts').glob('*.png')]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert all(sha(root/name) == sha(project/name) for name in known)
for name in mapping:
    assert (root/name).is_file() == (project/name).is_file()
    if (root/name).is_file():
        assert sha(root/name) == sha(project/name)
assert all(not path.exists() for path in (project/assets, project/normal, *sidecars))
protected = {name:(project/name).read_bytes() for name in mapping if name not in (assets,normal)}

probe_text = (base/'root-integration-v7/native-s20/ne267_hong_scene.gd').read_text(encoding='utf-8')
probe_text = probe_text.replace('const SLIP := "zheng_meal_slip"', 'const SLIP := "hong_pen"')
probe_text = probe_text.replace('const SLIP_POINT := Vector2(72, 42)', 'const SLIP_POINT := Vector2(22.5, 23.5)')
probe_text = probe_text.replace('const SLIP_REST_X := 360.0\n', '')
probe_text = probe_text.replace('absf(slip.position.x - SLIP_REST_X) < 0.05', 'captured.has("pen-hong") and absf(slip.rotation - 0.49) < .005')
before = '\t\t\t\tvar palm := player._stage.to_local(actor.hand_contact_global(&"front"))'
assert probe_text.count(before) == 1
probe_text = probe_text.replace(before, '''				var grip_actor := actor
				for hold: StagePropHold in player._stage._held:
					if hold.prop_id == SLIP:
						grip_actor = hold._actor.get_ref() as CutsceneActor
				var palm := player._stage.to_local(grip_actor.hand_contact_global(&"front"))''')
probe_text = probe_text.replace('"paper_stage": paper_point, "distance": distance',
    '"paper_stage": paper_point, "distance": distance, "holder": grip_actor.actor_id, "tip_stage": player._stage.to_local(slip.to_global(slip.source_point(Vector2(5.5, 32.5))))')
probe_text = probe_text.replace('if not captured.has("slip-held"):\n\t\t\t\t\tcaptured["slip-held"] = true\n\t\t\t\t\tsnapshots.append(await _snapshot(id, "slip-held", actor, player._stage))',
    'var held_key := "pen-" + str(grip_actor.actor_id)\n\t\t\t\tif not captured.has(held_key):\n\t\t\t\t\tcaptured[held_key] = true\n\t\t\t\t\tsnapshots.append(await _snapshot(id, held_key, actor, player._stage))')
before = '\t\tif player.choice_active():'
assert probe_text.count(before) == 1
probe_text = probe_text.replace(before, '''			for prop_id: String in ["hong_letter_ink", "hong_envelope", "hong_letter"]:
				var prop := player._stage.prop_node(prop_id)
				if prop != null and prop.visible and not captured.has(prop_id):
					var show := prop_id == "hong_letter_ink" or player._stage.prop_held(prop_id)
					if show:
						captured[prop_id] = true
						snapshots.append(await _snapshot(id, prop_id, actor, player._stage))
		if player.choice_active():''')
probe_text = probe_text.replace('if pose == "slip-rest" and (paper._state != "lay_8" or absf(float(paper_metrics["material_bottom_stage_y"]) - 180.0) > 1.0):',
    'if pose == "slip-rest" and absf(float(paper_metrics["material_bottom_stage_y"]) - 180.0) > 1.0:')
before = '''	for y in pixels.get_height():
		for x in pixels.get_width():
			if pixels.get_pixel(x, y).a >= .5:
				bottom = maxf(bottom, (material_to_stage * (origin + Vector2(x + .5, y + .5))).y)'''
after = '''	var bounds := Rect2i(sprite.region_rect) if sprite.region_enabled else Rect2i(Vector2i.ZERO, pixels.get_size())
	for y in range(bounds.position.y, bounds.end.y):
		for x in range(bounds.position.x, bounds.end.x):
			if pixels.get_pixel(x, y).a >= .5:
				var point := origin + Vector2(x - bounds.position.x + .5, y - bounds.position.y + .5)
				bottom = maxf(bottom, (material_to_stage * point).y)'''
assert probe_text.count(before) == 1
probe_text = probe_text.replace(before, after)
before = '\tif not captured.has("sit"):'
probe_text = probe_text.replace(before, '''	if id == "ch2_t_s20_done":
		for key: String in ["pen-ali", "pen-hong", "slip-rest", "hong_letter_ink", "hong_envelope", "hong_letter"]:
			if not captured.has(key):
				_failures.append(id + ": no actual writing phase " + key)
''' + before)
probe = out / 'observer.gd'
probe.write_text(probe_text, encoding='utf-8')
scene = probe.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n[node name="GuestLetter" type="Node2D"]\nscript = ExtResource("1")\n',encoding='utf-8')

env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out/'profile'/key)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
gpu_lock = [sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',engine,'--path',str(project)]

def run(name, args, timeout):
    cmd = gpu_lock + args
    (out/(name+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
    with (out/(name+'.log')).open('wb') as log:
        process = subprocess.run(cmd, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    raw = (out/(name+'.log')).read_text(encoding='utf-8')
    return process.returncode, re.findall(r'^.*(?:ERROR:|WARNING:).*$', raw, re.M)


try:
    for name, candidate in mapping.items():
        (project/name).write_bytes((source/candidate).read_bytes())
    guard = {name:sha(project/name) for name in (*known,*mapping)}
    status, errors = run('import', ['--headless','--editor','--import'], 150)
    assert status == 0 and not errors, (status,errors)
    for sidecar in sidecars:
        (out/sidecar.name).write_bytes(sidecar.read_bytes())
    status, errors = run('raw', ['--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
                                 '--resolution','1280x720','--fixed-fps','60','--quit-after','10000',scene.as_posix(),'--','--out='+str(out)], 120)
    report = json.loads((out/'scenes.json').read_text())
    held = [contact for row in report['scenes'] for contact in row['held_contacts']]
    result = {'exit':status,'errors':errors,'failures':report['failures'],'contact_count':len(held),
              'source_held':all(sha(project/name) == digest for name,digest in guard.items()),'source':guard}
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k != 'source'},flush=True)
finally:
    for name in (assets, normal, assets+'.import', normal+'.import'):
        path = project/name
        assert path.resolve() == project.resolve()/name
        path.unlink(missing_ok=True)
    for name, content in protected.items():
        (project/name).write_bytes(content)
    assert all((project/name).read_bytes() == content for name,content in protected.items())
