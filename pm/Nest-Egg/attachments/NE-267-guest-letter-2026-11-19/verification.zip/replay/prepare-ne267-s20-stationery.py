from dataclasses import replace
import hashlib
import json
from pathlib import Path
import sys

from PIL import Image

import guest_letter_staging as stationery

root = Path.cwd()
out = Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118') / sys.argv[1]
sys.path.insert(0, str(root / 'tools/story'))
from build_ch2_story import spec
from chapter_compiler import write_chapter

with Image.open(out / 'hong_stationery.png') as atlas:
    for layer in stationery.layers():
        x, y, width, height = layer['region']
        assert atlas.width == layer['source_width'] and 0 <= x < x + width <= atlas.width and 0 <= y < y + height <= atlas.height
    for point in (stationery.PEN_GRIP, stationery.PEN_TIP, stationery.ENVELOPE_FIRST_GRIP,
                  stationery.ENVELOPE_LAST_GRIP, stationery.LETTER_GRIP):
        assert atlas.getpixel(tuple(map(int, point)))[3] >= 128
    letter = stationery.layers()[1]
    for x in range(358, 366):
        assert atlas.getpixel((64 + (x - 353)*4, int((176.5 - letter['pos'][1])*4)))[3] >= 128
for skin, contact in [('ali', stationery.ALI_FINGERS), ('guest_hong', stationery.HONG_FINGERS)]:
    with Image.open(root/'art'/'characters'/skin/'parts/hand.png') as hand:
        assert hand.convert('RGBA').getpixel(tuple(map(int, contact)))[3] >= 128, (skin, contact)

stage_path = 'data/cutscene/stages/ch2_guest_book_room.json'
stage = json.loads((root / stage_path).read_text(encoding='utf-8'))
stage['layers'][3:3] = stationery.layers()
(out / Path(stage_path).name).write_text(json.dumps(stage, ensure_ascii=False, indent=1)+'\n', encoding='utf-8')
motion_path = 'art/motion/guest_hong.json'
motion = (root / motion_path).read_text(encoding='utf-8')
assert motion.count('"stand": {\n      "chest": 0.0,\n      "head": 0.0\n') == 1
motion = motion.replace('"stand": {\n      "chest": 0.0,\n      "head": 0.0\n',
                        '"stand": {\n      "chest": 0.0,\n      "head": 0.0,\n      "foot_back": -0.12\n')
(out / Path(motion_path).name).write_bytes(motion.encode())
loop_path = 'art/rigs/npc_animations.json'
loops = (root / loop_path).read_text(encoding='utf-8')
marker = '    "read_note":'
assert loops.count(marker) == 1
loops = loops.replace(marker, '    "writing": {"bones": {"head": 0.25, "neck": 0.05, "chest": 0.04}},\n' + marker)
(out / Path(loop_path).name).write_bytes(loops.encode())
chapter = spec()
ids = [ident for ident, segment in chapter.source.segments.items() if segment.section == 'S20']
assert len(ids) == 5
for ident in ids:
    segment = chapter.source.segments[ident]
    accepted = ident == 'ch2_t_s20_done'
    steps = []
    line = 0
    for step in segment.steps:
        step = dict(step)
        if step['do'] == 'scene':
            step['props'] = stationery.initial(response=accepted)
        elif step['do'] == 'actor' and step['id'] == 'hong':
            step['seat_sag'] = 0.438
        elif step['do'] == 'say':
            if accepted:
                steps.extend({1:stationery.exchange, 2:stationery.offer_envelope}.get(line, tuple)())
            line += 1
        elif accepted and step['do'] == 'move' and step['id'] == 'hong':
            steps.extend(stationery.collect_letter())
        steps.append(step)
    chapter.source.segments[ident] = replace(segment, steps=tuple(steps))
story = out / 'ch2_heron.json'
assert not write_chapter(chapter, story)
before, after = (json.loads(path.read_text(encoding='utf-8')) for path in (root / 'data/story/ch2_heron.json', story))
assert [key for key in before if before[key] != after[key]] == ['scenes']
assert sorted(k for k in before['scenes'] if before['scenes'][k] != after['scenes'][k]) == sorted(ids)
for ident in ids:
    old, new = before['scenes'][ident], after['scenes'][ident]
    assert {k:v for k,v in old.items() if k != 'steps'} == {k:v for k,v in new.items() if k != 'steps'}
    assert [step for step in old['steps'] if step['do'] == 'say'] == [step for step in new['steps'] if step['do'] == 'say']
files = {name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in
         ('hong_stationery.png', 'hong_stationery_n.png', Path(stage_path).name, Path(motion_path).name,
          Path(loop_path).name, story.name)}
(out/'prepared.json').write_text(json.dumps({'files':files,'sections':ids}, indent=2)+'\n')
