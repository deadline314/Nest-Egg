from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
evidence = Path('D:/NestEggVerification/evidence-20261117')
project = evidence/'ne267-source-delivery-20261118/s19-runtime'
prior = evidence/'ne267-hong-20261118/s20-stationery-v5'
out = prior.with_name('s20-stationery-v6')
out.mkdir(exist_ok=True)
native = out/'native'
native.mkdir(exist_ok=True)
paths = json.loads((prior/'author-files/paths.json').read_text(encoding='utf-8'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
diffs = [row for row in paths if sha(project/row['path']) != row['after']]
assert sorted(row['path'] for row in diffs) == [
    'art/environment/scene_props/guest_book_contacts/hong_stationery.png.import',
    'art/environment/scene_props/guest_book_contacts/hong_stationery_n.png.import']
expected = json.loads((prior/'native/result.json').read_text(encoding='utf-8'))['source']
assert all(sha(project/name) == digest for name,digest in expected.items())
for row in paths:
    assert sha(root/row['path']) == sha(shared/row['path']) == row['after']
    for path in (out/'author-files'/row['path'],):
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(project/row['path'],path)
for row in diffs:
    name = row['path']
    before = (root/name).read_text(encoding='utf-8')
    after = (project/name).read_text(encoding='utf-8')
    assert before.count('mipmaps/generate=true') == 1 and before.replace('mipmaps/generate=true','mipmaps/generate=false') == after
    row['previous_candidate'] = row['after']
    row['after'] = sha(project/name)
(out/'author-files/paths.json').write_text(json.dumps(paths,indent=2)+'\n')

env = os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(native/'profile'/key)
env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
lock = [sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
        'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project)]
probe = native/'observer.gd'
shutil.copyfile(prior/'native/observer.gd',probe)
scene = probe.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n[node name="GuestLetter" type="Node2D"]\nscript = ExtResource("1")\n',encoding='utf-8')
guard = expected | {row['path']:row['after'] for row in paths}

def run(name, command, timeout):
    (native/(name+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
    with (native/(name+'.log')).open('wb') as log:
        process = subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    raw = (native/(name+'.log')).read_text(encoding='utf-8')
    assert process.returncode == 0 and not re.findall(r'^.*(?:ERROR:|WARNING:).*$',raw,re.M), (name,raw[-4200:])
    assert all(sha(project/name) == digest for name,digest in guard.items()), name

raw_import = native/'import.log'
if not raw_import.exists():
    run('import',lock+['--headless','--editor','--import'],180)
else:
    recorded=raw_import.read_text(encoding='utf-8')
    assert '[ DONE ]' in recorded and not re.findall(r'^.*(?:ERROR:|WARNING:).*$', recorded, re.M)
    assert all(sha(project/name) == digest for name,digest in guard.items())
run('assets',[sys.executable,'-B','-X','utf8','tools/assets/check_assets.py'],60)
for row in diffs:
    shutil.copyfile(project/row['path'],native/Path(row['path']).name)
run('raw',lock+['--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
               '--resolution','1280x720','--fixed-fps','60','--quit-after','10000',scene.as_posix(),'--','--out='+str(native)],120)
report = json.loads((native/'scenes.json').read_text(encoding='utf-8'))
old_report = json.loads((prior/'native/scenes.json').read_text(encoding='utf-8'))
assert not report['failures'] and [(scene['id'],scene['steps_sha256']) for scene in report['scenes']] == [
    (scene['id'],scene['steps_sha256']) for scene in old_report['scenes']]
result={'exit':0,'errors':[],'failures':[], 'contact_count':sum(len(scene['held_contacts']) for scene in report['scenes']),
        'source_held':all(sha(project/name) == digest for name,digest in guard.items()),'source':guard}
assert result['contact_count'] > 90 and result['source_held']
(native/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print({key:value for key,value in result.items() if key != 'source'},flush=True)
