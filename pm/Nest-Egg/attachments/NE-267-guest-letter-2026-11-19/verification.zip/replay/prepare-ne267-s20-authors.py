from pathlib import Path
import hashlib
import json
import sys

root = Path.cwd()
base = Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118') / sys.argv[1]
out = base / 'author-files'
out.mkdir()


def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


story_name = 'tools/story/ch2_source.py'
story = (root / story_name).read_text(encoding='utf-8')
story = replace(story, 'import guest_ticket_staging  # noqa: E402\n',
                'import guest_ticket_staging  # noqa: E402\nimport guest_letter_staging  # noqa: E402\n')
story = replace(story, '"坐下把想寫給朋友的話說完。", 0.45),', '"坐下把想寫給朋友的話說完。", 0.438),')
story = replace(story, '''        source.segments[ident] = replace(segment, mode="animated", steps=tuple(cast) + guest_start + segment.steps + guest_end)''',
                '''        dialogue = segment.steps
        if segment.section == "S20":
            response = ident == "ch2_t_s20_done"
            cast[0]["props"] = guest_letter_staging.initial(response=response)
            if response:
                dialogue = _with_cues(dialogue, ((1, guest_letter_staging.exchange()), (2, guest_letter_staging.offer_envelope())), ident)
                guest_end = guest_letter_staging.collect_letter() + guest_end
        source.segments[ident] = replace(segment, mode="animated", steps=tuple(cast) + guest_start + dialogue + guest_end)''')

stages_name = 'tools/assets/stage_defs.py'
stages = (root / stages_name).read_text(encoding='utf-8')
stages = replace(stages, 'import guest_ticket_staging\n', 'import guest_ticket_staging\nimport guest_letter_staging\n')
stages = replace(stages, '        guest_ticket_staging.layer(),\n', '        guest_ticket_staging.layer(),\n        *guest_letter_staging.layers(),\n')

builder = (root / 'work/build_hong_stationery.py').read_text(encoding='utf-8')
builder = replace(builder, 'import sys\n', '')
builder = replace(builder, "sys.path.insert(0, str(Path.cwd() / 'tools/assets'))\n", '')
drawing_start = builder.index("image = Image.new")
writer_start = builder.index('path = Path(sys.argv[1])')
imports = builder[:drawing_start]
drawing = builder[drawing_start:writer_start]
builder = imports + '''OUTPUT = Path(__file__).resolve().parents[2] / "art/environment/scene_props/guest_book_contacts/hong_stationery.png"


def build(path: Path) -> None:
''' + ''.join('    ' + line if line.strip() else line for line in drawing.splitlines(keepends=True)) + '''    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path)
    pixels = np.asarray(image, dtype=np.float32) / 255
    normals = depth_normal_map(pixels, profile="flat", relief=.15, detail=0.0)
    Image.fromarray(np.rint(normals * 255).astype(np.uint8)).save(path.with_stem(path.stem + "_n"))


if __name__ == "__main__":
    build(OUTPUT)
'''

test_name = 'tools/story/test_ch2_guest_cast.py'
test = (root / test_name).read_text(encoding='utf-8')
test = replace(test, 'import guest_ticket_staging\n', 'import guest_ticket_staging\nimport guest_letter_staging\n')
test = replace(test, '\n\nif __name__ == "__main__":', '''
    def test_hong_writes_and_takes_the_envelope_only_after_the_accepted_choice(self):
        staging = guest_letter_staging
        for scene in self.framed.segments.values():
            if scene.section != "S20":
                continue
            with self.subTest(scene=scene.id):
                response = scene.id == "ch2_t_s20_done"
                stage = next(step for step in scene.steps if step["do"] == "scene")
                self.assertEqual(stage["props"][staging.PEN]["visible"], response)
                self.assertTrue(stage["props"][staging.LETTER]["visible"])
                hands = [(step["id"], step["actor"]) for step in scene.steps if step["do"] == "prop_hold"]
                self.assertEqual(hands, [(staging.PEN, "ali"), (staging.PEN, "hong"),
                                         (staging.LETTER, "hong"), (staging.ENVELOPE, "hong")] if response else [])


if __name__ == "__main__":''')

paths = {
    story_name: story.encode(), stages_name: stages.encode(), test_name: test.encode(),
    'tools/story/guest_letter_staging.py': (root/'work/guest_letter_staging.py').read_bytes(),
    'tools/assets/build_hong_stationery.py': builder.encode(),
}
for name in ('data/story/ch2_heron.json', 'data/cutscene/stages/ch2_guest_book_room.json',
             'art/rigs/npc_animations.json', 'art/motion/guest_hong.json'):
    paths[name] = (base / Path(name).name).read_bytes()
for name in ('hong_stationery.png', 'hong_stationery_n.png'):
    prefix = 'art/environment/scene_props/guest_book_contacts/'
    paths[prefix + name] = (base / name).read_bytes()
    paths[prefix + name + '.import'] = (base / 'native' / (name + '.import')).read_bytes()
receipts = []
for name, payload in paths.items():
    path = out / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    original = root / name
    receipts.append({'path':name, 'before':hashlib.sha256(original.read_bytes()).hexdigest() if original.is_file() else None,
                     'after':hashlib.sha256(payload).hexdigest()})
(out/'paths.json').write_text(json.dumps(receipts,indent=2)+'\n')
