from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

root = Path.cwd()
project = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118/root-integration-v7/native-s20')
chen = '--chen' in sys.argv
skin = 'guest_chen' if chen else 'guest_hong'
actor = 'chen' if chen else 'hong'
segments = ('ch2_t_s19_band', 'ch2_t_s19_quiet', 'ch2_t_s19_done') if chen else ('ch2_t_s20_letter', 'ch2_t_s20_story', 'ch2_t_s20_done')
location = base.parents[2] / 'ne267-source-delivery-20261118' if chen else base.parents[1]
out = location / ('calibration-' + sys.argv[1])
out.mkdir()
trace = (location/'scene-adapter/ne267_chen_scene.gd' if chen else base/'ne267_hong_scene.gd').read_text(encoding='utf-8')
old = '\tvar scene: Dictionary = Story._scenes.get(id, {})'
sag = float(sys.argv[2])
walk = float(sys.argv[3])
grounding = '--grounding' in sys.argv
angle = float(sys.argv[sys.argv.index('--foot-back') + 1]) if '--foot-back' in sys.argv else 0.0
fps = int(sys.argv[sys.argv.index('--fps') + 1]) if '--fps' in sys.argv else 60
assert fps in (30, 60, 120)
assert 0.2 <= sag <= 0.5 and 1.0 <= walk <= 2.0
assert trace.count(old) == 1
new = f'''{old}.duplicate(true)
	if {sag} != 0.45 or {walk} != 1.5:
		for step: Dictionary in scene.steps:
			if step.get("id") != "{actor}":
				continue
			if step.get("do") == "actor":
				step["seat_sag"] = {sag}
			elif id == "{segments[-1]}" and step.get("do") == "move":
				step["time"] = {walk}'''
assert trace.count(old) == 1
trace = trace.replace(old, new)
before = '\tfor id in [' + ', '.join(json.dumps(ident) for ident in segments) + ']:'
if grounding:
    assert trace.count(before) == 1
    trace = trace.replace(before, f'\tRigLibrary.load_json("res://art/motion/{skin}.json")["grounding"] = true\n' + before)
if angle:
    assert trace.count(before) == 1
    trace = trace.replace(before, f'\tRigLibrary.load_json("res://art/motion/{skin}.json")["npc"]["stand"]["foot_back"] = {angle}\n' + before)
probe = out / 'observer.gd'
probe.write_text(trace, encoding='utf-8')
scene = probe.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n[node name="GuestSeat" type="Node2D"]\nscript = ExtResource("1")\n', encoding='utf-8')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
paths = ['data/story/ch2_heron.json', 'data/cutscene/stages/ch2_guest_book_room.json', f'art/rigs/{skin}.json',
         f'art/motion/{skin}.json', f'art/characters/{skin}/character.json', 'game/rig/npc_animator.gd',
         'game/rig/humanoid_animator.gd', 'game/cutscene/cutscene_player.gd', 'game/cutscene/cutscene_actor.gd']
paths += [path.relative_to(root).as_posix() for path in (root / 'art/characters'/skin/'parts').glob('*.png')]
def snapshot(directory):
    return {name: hashlib.sha256((directory / name).read_bytes()).hexdigest() for name in paths}

source = snapshot(project)
assert source == snapshot(root)
cmd = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
       'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(project), '--rendering-method', 'forward_plus',
       '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '1280x720', '--fixed-fps', str(fps),
       '--quit-after', '10000', scene.as_posix(), '--', '--out=' + str(out)]
(out / 'command.json').write_text(json.dumps(cmd, indent=2) + '\n')
with (out / 'raw.log').open('wb') as log:
    process = subprocess.run(cmd, env=env, cwd=project, stdout=log, stderr=subprocess.STDOUT, timeout=120)
raw = (out / 'raw.log').read_text(encoding='utf-8')
report = json.loads((out / 'scenes.json').read_text(encoding='utf-8'))
result = {'seat_sag':sag, 'exit_walk_seconds':walk, 'grounding_override':grounding, 'standing_back_foot_angle':angle,
          'fixed_fps':fps, 'exit':process.returncode,
          'errors': re.findall(r'^.*(?:ERROR:|WARNING:).*$', raw, re.M),
          'failures': report['failures'], 'source_held': source == snapshot(project) == snapshot(root), 'source':source}
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print({key:value for key,value in result.items() if key != 'source'}, flush=True)
assert not result['errors'] and result['source_held'] and len(report['scenes']) == 3
