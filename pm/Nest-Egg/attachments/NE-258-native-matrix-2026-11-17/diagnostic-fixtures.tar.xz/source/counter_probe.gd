extends "res://tools/weapon_light_probe.gd"


func _ready() -> void:
	out_dir = OS.get_environment("NE258_OUT")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_quality = "high"
	_phase = "exposure"
	_tag = "cpu-counter"
	run.call_deferred()


func _aim(direction: Vector2) -> void:
	# CPU diagnostics have no rendered frame_post_draw; retain real physics and input.
	_aim_dir = direction.normalized()
	AimInput.restore_direction(_aim_dir)
	for frame in 30:
		await get_tree().physics_frame


func _measure_exposure_states() -> Dictionary:
	var weapon := load("res://data/weapons/smg.tres") as WeaponData
	player.loadout.equip(weapon)
	player.loadout.set_ammo(player.loadout.active_slot, weapon.magazine_size, -1)
	var container := ProjectilePool.container()
	for node in container.get_children():
		_watch_projectile(node)
	container.child_entered_tree.connect(_watch_projectile)
	_perf_sound = weapon.fire_sound
	Sfx.sound_played.connect(_shot_sound)
	var reloads := [0, 0]
	player.loadout.reload_started.connect(func() -> void: reloads[0] += 1)
	player.loadout.reload_finished.connect(func() -> void: reloads[1] += 1)
	Input.action_press(&"shoot")
	for frame in 240:
		await get_tree().physics_frame
	Input.action_release(&"shoot")
	var result := {"scope": "CPU actual-input counter validation only; no rendering, hearing or frame-time acceptance",
		"actual_projectile_activations": _projectiles_spawned, "accepted_shot_sounds": _accepted_shots,
		"reload_started": reloads[0], "reload_finished": reloads[1], "final_mag": player.loadout.mag_in(player.loadout.active_slot)}
	_gate(_projectiles_spawned == _accepted_shots and _projectiles_spawned > weapon.magazine_size and reloads[0] > 0 and reloads[1] > 0,
		"real held SMG input produces matching activation/accepted counts and natural automatic reload")
	print("COUNTER_DIAGNOSTIC ", JSON.stringify(result))
	Sfx.sound_played.disconnect(_shot_sound)
	container.child_entered_tree.disconnect(_watch_projectile)
	return result
