extends "res://tools/weapon_light_probe.gd"
var _events: Array[Dictionary] = []


func _input(event: InputEvent) -> void:
	if event.is_action(&"reload"):
		_events.append({"route": "input", "pressed": event.is_pressed(), "type": event.get_class()})


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action(&"reload"):
		_events.append({"route": "unhandled", "pressed": event.is_pressed(), "type": event.get_class(), "reloading": player.loadout.is_reloading()})


func _measure_exposure_states() -> Dictionary:
	player.loadout.equip(load("res://data/weapons/smg.tres"))
	player.loadout.set_ammo(player.loadout.active_slot, 26, -1)
	await wait(0.4)
	var result := {"events": _events, "before": {"processing_unhandled": player.is_processing_unhandled_input(), "can_process": player.can_process(), "tree_paused": get_tree().paused, "story_cinematic": Story.is_cinematic_active(), "layer_cinematic": Story._layer.is_cinematic_active()}}
	result["head"] = await _head_exposure("reload-route-head")
	for kind: String in ["action", "key"]:
		var event: InputEvent
		if kind == "action":
			var action := InputEventAction.new()
			action.action = &"reload"
			action.pressed = true
			event = action
		else:
			var key := InputEventKey.new()
			key.physical_keycode = KEY_R
			key.pressed = true
			event = key
		Input.parse_input_event(event)
		result[kind + "_immediate"] = player.loadout.is_reloading()
		await get_tree().physics_frame
		await get_tree().physics_frame
		result[kind + "_two_physics"] = player.loadout.is_reloading()
		await get_tree().process_frame
		await get_tree().process_frame
		result[kind + "_two_ui"] = player.loadout.is_reloading()
		print("RELOAD_ROUTE ", JSON.stringify(result))
		if player.loadout.is_reloading():
			await wait(1.5)
		player.loadout.set_ammo(player.loadout.active_slot, 26, -1)
	return result
