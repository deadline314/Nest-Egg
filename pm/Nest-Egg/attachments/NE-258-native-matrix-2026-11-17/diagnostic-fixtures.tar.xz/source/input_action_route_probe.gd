extends SceneTree
class Observer:
	extends Node
	var received: Array[String] = []
	func _input(event: InputEvent) -> void:
		if event.is_action_pressed(&"reload"):
			received.append("input")
	func _unhandled_input(event: InputEvent) -> void:
		if event.is_action_pressed(&"reload"):
			received.append("unhandled")


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var observer := Observer.new()
	root.add_child(observer)
	await process_frame
	var action := InputEventAction.new()
	action.action = &"reload"
	action.pressed = true
	Input.parse_input_event(action)
	await process_frame
	print("ACTION_ROUTE ", observer.received)
	observer.received.clear()
	var key := InputEventKey.new()
	key.physical_keycode = KEY_R
	key.pressed = true
	Input.parse_input_event(key)
	await process_frame
	print("KEY_ROUTE ", observer.received)
	observer.queue_free()
	await process_frame
	quit()
