extends Node
var checks := 0
var failures := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_run.call_deferred()


func _check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures += 1
	print("LOCK_CHECK ", condition, " ", label)


func _run() -> void:
	await preload("res://tests/helpers/gameplay_lock_owner_checks.gd").run(CutsceneSuite.new(self))
	print("LOCK_SUITE checks=", checks, " failures=", failures)
	get_tree().quit(0 if failures == 0 else 1)
