extends SceneTree
## Same-owner token cleanup negative control, using the real lock service.
func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var service := root.get_node("GameplayLock")
	var first: Callable = service.release.bind(1001)
	var second: Callable = service.release.bind(1002)
	print("CALLABLE_IDENTITY ", JSON.stringify({"first_args": first.get_bound_arguments(), "second_args": second.get_bound_arguments(), "equal": first == second}))
	var owner := Node.new()
	root.add_child(owner)
	var token_a: int = service.acquire(owner)
	var token_b: int = service.acquire(owner)
	print("LOCK_TOKENS ", token_a, " ", token_b, " connections=", owner.get_signal_connection_list(&"tree_exiting").size())
	owner.queue_free()
	await process_frame
	await process_frame
	var stale: bool = service.is_locked()
	print("LOCK_OWNER_REMOVED stale=", stale, " paused=", paused)
	service.release(token_a)
	service.release(token_b)
	quit(1 if stale else 0)
