extends "res://work/ne258-light-owner-20261117/owner_probe.gd"
## Readonly diagnosis: real cover-map terrain/colliders/occluders; arranged inert Stalker.
var _target: Stalker
var _receiver: Polygon2D


func _observe(label: String) -> void:
	_point = _target._center()
	var row := _snapshot(label)
	var origin := _player._weapon_light.global_position
	var query := PhysicsRayQueryParameters2D.create(origin, _point, Layers.WORLD)
	var hit := _player.get_world_2d().direct_space_state.intersect_ray(query)
	row["stalker"] = {"position": [_target.global_position.x, _target.global_position.y], "center": [_point.x, _point.y],
		"can_process": _target.can_process(), "physics_enabled": _target.is_physics_processing(), "process_mode": _target.process_mode,
		"animation_time": _target._anim_time, "lit_check": _target._lit_check,
		"cloaked": _target.is_cloaked(), "visibility": _target._visibility, "lit": _target._lit,
		"reveal_left": _target._reveal_left, "state": str(_target.fsm.current), "health": _target.health.current,
		"telegraph": _target.is_telegraphing(), "finishable": _target.can_be_finished(), "ability_radius": _target.data.ability_radius,
		"world_ray_blocked": not hit.is_empty(), "world_ray_point": [hit.position.x, hit.position.y] if not hit.is_empty() else []}
	await _capture(label)
	if not _captures.is_empty():
		_captures.back()["receiver_world_center"] = [_receiver.global_position.x, _receiver.global_position.y]
		_captures.back()["receiver_world_size"] = [16, 16]
	print("NE258_WALL ", JSON.stringify(row))


func _run() -> void:
	GameState.story_autosave = false
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.story_autosave = false
	add_child(LightKit.create_environment())
	var data := EnemySuiteBase.map_data()
	data.chapter = &"ch1_kasa"
	var zone := LightingZone.new()
	zone.start_tile = 0
	zone.profile = load("res://data/lighting/blackout.tres")
	data.lighting_zones = [zone]
	_level = Level.new()
	_level.process_mode = Node.PROCESS_MODE_PAUSABLE
	_level.configure(data)
	add_child(_level)
	_player = _level.player
	_player.global_position = Vector2(25 * 16, 320)
	_player.velocity = Vector2.ZERO
	_player.loadout.equip(load("res://data/weapons/rifle.tres"))
	AimInput.using_gamepad = true
	AimInput.restore_direction(Vector2.UP)
	_target = _level._create_enemy(load("res://data/enemies/stalker.tres")) as Stalker
	_target.data = _target.data.duplicate()
	_target.data.detect_range = 0.0
	_target.data.attack_range = 0.0
	_target.data.move_speed = 0.0
	_target.data.ability_radius = 0.0
	_target.position = Vector2(600, 320)
	_level._entities.add_child(_target)
	_receiver = Polygon2D.new()
	_receiver.polygon = PackedVector2Array([Vector2(-8,-8), Vector2(8,-8), Vector2(8,8), Vector2(-8,8)])
	_receiver.color = Color(0.5, 0.5, 0.5)
	_receiver.position = _target._center() + Vector2(30, 0)
	_receiver.z_index = -1
	_level._entities.add_child(_receiver)
	await _physics(150)
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.snap_to_target()
	await _physics(30)
	await _observe("wall-aim-away")
	_check(_target.is_cloaked(), "inert unhurt Stalker really cloaks when aimed away")
	AimInput.restore_direction((_target._center() - _player.muzzle_position()).normalized())
	await _physics(90)
	await _observe("wall-aim-through")
	_check(_target.is_cloaked() and is_zero_approx(LightKit.light_level_at(get_tree(), _target._center())), "real rendered wall blocks gun-light visibility and preserves cloak")
	# Same separation on the open side; no occluders, shadow settings, or checker are edited.
	_player.global_position += Vector2(240, 0)
	_target.global_position += Vector2(240, 0)
	_receiver.position += Vector2(240, 0)
	_player.velocity = Vector2.ZERO
	AimInput.restore_direction((_target._center() - _player.muzzle_position()).normalized())
	await _physics(150)
	camera.snap_to_target()
	await _physics(30)
	await _observe("open-aim-at")
	_check(not _target.is_cloaked(), "inert Stalker reveals when genuinely illuminated in the open")
	AimInput.restore_direction(Vector2.UP)
	await _physics(90)
	await _observe("open-aim-away")
	_check(_target.is_cloaked(), "the same actually processed Stalker naturally recloaks when the real gun aim moves away")
	var report := {"scope": "Arranged cover-map consistency diagnosis; no product changes or automatic defect classification",
		"receiver": "16x16 middle-gray shaded world Polygon2D 30px right of Stalker center", "rows": _rows, "captures": _captures, "checks": _checks}
	var writer := FileAccess.open(_out.path_join("wall-report.json"), FileAccess.WRITE)
	writer.store_string(JSON.stringify(report, "\t"))
	writer.close()
	_level.queue_free()
	AimInput.using_gamepad = false
	await _ui(4)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _checks.all(func(row: Dictionary) -> bool: return row["passed"]) else 1)
