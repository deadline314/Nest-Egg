extends Node
## Observes real presentation/phone/vehicle owners; never calls WeaponLight.set_active/extinguish.
var _out := ""
var _level: Level
var _player: Player
var _rows: Array[Dictionary] = []
var _checks: Array[Dictionary] = []
var _point := Vector2.ZERO
var _captures: Array[Dictionary] = []
var _presentation_events := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_out = OS.get_environment("NE258_OUT")
	if not _out.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _physics(count: int) -> void:
	for frame in count:
		await get_tree().physics_frame


func _ui(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _capture(label: String) -> void:
	if OS.get_environment("NE258_NATIVE") != "1":
		return
	await RenderingServer.frame_post_draw
	var viewport := get_viewport()
	var raw := viewport.get_texture().get_image()
	var file := FileAccess.open(_out.path_join(label + ".hdr.bin"), FileAccess.WRITE)
	file.store_buffer(raw.get_data())
	file.close()
	var encoded := preload("res://tools/viewport_capture.gd").encode(raw, viewport.use_hdr_2d)
	_check(encoded.save_png(_out.path_join(label + ".png")) == OK, "native capture " + label, "evidence write")
	var transform := viewport.get_final_transform() * viewport.get_canvas_transform()
	var screen_point := transform * _point
	_captures.append({"name": label, "width": raw.get_width(), "height": raw.get_height(), "format": raw.get_format(),
		"world_to_image": [transform.x.x, transform.x.y, transform.y.x, transform.y.y, transform.origin.x, transform.origin.y],
		"use_hdr_2d": viewport.use_hdr_2d, "world_point": [_point.x, _point.y], "screen_point": [screen_point.x, screen_point.y],
		"state": _snapshot("capture-" + label)})


func _snapshot(name: String) -> Dictionary:
	var light := _player._weapon_light
	var record := {"name": name, "tree_paused": get_tree().paused, "locked": GameplayLock.is_locked(),
		"story_cinematic": Story.is_cinematic_active(), "layer_cinematic": Story._layer.is_cinematic_active(),
		"radio_frozen": Story._layer.is_radio_frozen(), "player_state": _player.state,
		"player_position": [_player.global_position.x, _player.global_position.y],
		"light_lit": light.is_lit(), "light_enabled": light._light.enabled, "light_energy": light._light.energy,
		"light_position": [light.global_position.x, light.global_position.y], "light_rotation": light.global_rotation,
		"world_query_point": [_point.x, _point.y], "world_light": LightKit.light_level_at(get_tree(), _point),
		"player_can_process": _player.can_process(), "level_process_mode": _level.process_mode,
		"render_visible": light._light.is_visible_in_tree(), "physics_frame": Engine.get_physics_frames(),
		"ui_frame": Engine.get_process_frames()}
	record["radio_id"] = str(Story._layer._radio_queue.front().get("id", "")) if not Story._layer._radio_queue.is_empty() else ""
	_rows.append(record)
	print("NE258_OWNER ", JSON.stringify(record))
	return record


func _check(passed: bool, name: String, scope := "input/owner precondition") -> void:
	_checks.append({"passed": passed, "name": name, "scope": scope})
	print("CHECK ", passed, " ", name)


func _warm() -> void:
	await _physics(30)
	_point = _player._weapon_light.global_position + Vector2.RIGHT * 120.0
	_check(_player._weapon_light.is_lit() and _player.is_on_floor() and not GameplayLock.is_locked(), "rifle genuinely lit on the floor before each case")


func _presentation_started() -> void:
	_presentation_events += 1


func _lifecycle_cases(lines: Array[Dictionary]) -> void:
	EventBus.cinematic_started.connect(_presentation_started)
	var events := _presentation_events
	Story._layer.start_cinematic(&"ne258_empty", [])
	_check(not Story._layer.is_cinematic_active() and not GameplayLock.is_locked() and _presentation_events == events and _player._weapon_light.is_lit(), "empty dialogue does not publish start or extinguish")
	Story._layer.enqueue_radio(&"ne258_nested_radio", lines, true)
	await _ui(4)
	_check(Story._layer.is_radio_frozen() and _player._weapon_light.is_lit() and _presentation_events == events, "radio alone does not publish a cinematic event")
	Story._layer.start_cinematic(&"ne258_nested_dialogue", lines)
	await _ui(4)
	_check(_presentation_events == events + 1 and not _player._weapon_light.is_lit() and not _player._weapon_light._light.enabled, "dialogue inside an already held radio lock extinguishes immediately")
	print("EXPECTED_WARNING_BEGIN dialogue reentry")
	Story._layer.start_cinematic(&"ne258_refused_dialogue", lines)
	print("EXPECTED_WARNING_END dialogue reentry")
	_check(_presentation_events == events + 1 and Story._layer._cinematic_id == &"ne258_nested_dialogue", "refused dialogue reentry keeps the original owner and publishes no start")
	Story._layer.cancel_cinematic()
	await _ui(4)
	_check(Story._layer.is_radio_frozen() and GameplayLock.is_locked() and not _player._weapon_light.is_lit(), "cancelling nested dialogue retains radio freeze and does not relight paused physics")
	Story._layer.cancel_radio()
	await _warm()
	# Base pause is an independent owner: cancelling the presentation must leave it paused.
	GameplayLock.set_base_paused(true)
	events = _presentation_events
	var animation := CutscenePlayer.new()
	add_child(animation)
	animation.play(&"ne258_direct_animation", {"overlay": true, "steps": [{"do": "wait", "time": 30.0}]})
	await _ui(4)
	_check(animation.is_running() and _presentation_events == events + 1 and not _player._weapon_light.is_lit(), "direct animated entry inside base pause extinguishes")
	print("EXPECTED_WARNING_BEGIN animation reentry")
	animation.play(&"ne258_refused_animation", {"steps": []})
	print("EXPECTED_WARNING_END animation reentry")
	_check(animation.scene_id == &"ne258_direct_animation" and animation.is_running() and _presentation_events == events + 1, "refused animated reentry preserves its running scene and publishes no start")
	animation.cancel()
	await _ui(4)
	_check(not GameplayLock.is_locked() and get_tree().paused and not _player._weapon_light.is_lit(), "animation cancel restores the retained base pause without relighting")
	GameplayLock.set_base_paused(false)
	await _warm()
	# Empty animated steps are currently accepted by the real owner and finish naturally.
	animation = CutscenePlayer.new()
	add_child(animation)
	events = _presentation_events
	animation.play(&"ne258_empty_animation", {"steps": []})
	await _ui(4)
	_check(_presentation_events == events + 1 and not is_instance_valid(animation) and not GameplayLock.is_locked(), "accepted empty animation naturally frees its owner and lock")
	await _warm()
	var connections := EventBus.get_signal_connection_list(&"cinematic_started").size()
	var transient_light := WeaponLight.new()
	add_child(transient_light)
	_check(EventBus.get_signal_connection_list(&"cinematic_started").size() == connections + 1, "a new light subscribes exactly once")
	transient_light.queue_free()
	await _ui(2)
	_check(EventBus.get_signal_connection_list(&"cinematic_started").size() == connections, "freed light automatically releases its presentation connection")
	var transient_layer := DialogueLayer.new()
	add_child(transient_layer)
	transient_layer.start_cinematic(&"ne258_removed_layer", lines)
	_check(GameplayLock.is_locked() and not _player._weapon_light.is_lit(), "independent dialogue owner extinguishes before its first paused frame")
	transient_layer.queue_free()
	await _ui(4)
	_check(not GameplayLock.is_locked() and not get_tree().paused, "freeing the actual dialogue owner releases its lock")
	await _warm()
	EventBus.cinematic_started.disconnect(_presentation_started)


## The phone may legitimately publish important radio: read it through the public input owner.
func _finish_phone(booth: Checkpoint) -> void:
	var presses := 0
	for frame in 240:
		if Story._layer.is_radio_frozen():
			_snapshot("phone-produced-radio-before-confirm-%d" % presses)
			var event := InputEventAction.new()
			event.action = &"ui_accept"
			event.pressed = true
			Input.parse_input_event(event)
			await _ui(1)
			event = InputEventAction.new()
			event.action = &"ui_accept"
			event.pressed = false
			Input.parse_input_event(event)
			await _ui(1)
			presses += 1
		else:
			await _physics(1)
		if not _player.is_on_phone() and not booth.is_calling() and not Story._layer.is_radio_frozen():
			break
	_check(not _player.is_on_phone() and not booth.is_calling() and not GameplayLock.is_locked(), "real phone timeline completes after public confirmation of its actual reading")


func _run() -> void:
	GameState.story_autosave = false
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.story_autosave = false
	add_child(LightKit.create_environment())
	var data := NewEnemiesSuite.arena_data()
	data.chapter = &"ch1_kasa"
	var zone := LightingZone.new()
	zone.start_tile = 0
	zone.profile = load("res://data/lighting/blackout.tres")
	data.lighting_zones = [zone]
	_level = Level.new()
	# The observer may continue while paused; the real Level/Player must retain PAUSABLE.
	_level.process_mode = Node.PROCESS_MODE_PAUSABLE
	_level.configure(data)
	add_child(_level)
	_player = _level.player
	_player.global_position = Vector2(12 * 16, 20 * 16)
	_player.velocity = Vector2.ZERO
	_player.loadout.equip(load("res://data/weapons/rifle.tres"))
	AimInput.using_gamepad = true
	AimInput.restore_direction(Vector2.RIGHT)
	await _physics(60)
	Story.auto_skip = false
	await _warm()
	var before := _snapshot("before-important-radio")
	await _capture("before-important-radio")
	# Read at the actual acquisition boundary: native readback can advance a process frame.
	before = _snapshot("at-important-radio-acquire")
	var lines: Array[Dictionary] = [{"name": "凜", "color": Palette.MAGENTA, "portrait": "", "text": "重要閱讀維持當前世界。"}]
	Story._layer.enqueue_radio(&"ne258_radio_fixture", lines, true)
	await _ui(4)
	var reading := _snapshot("during-important-radio")
	await _capture("during-important-radio")
	_check(reading["tree_paused"] and not reading["player_can_process"], "important radio really freezes the actual Level")
	_check(reading["light_energy"] == before["light_energy"] and reading["world_light"] == before["world_light"], "important radio preserves the frozen world light", "freeze preservation")
	Story._layer.cancel_radio()
	await _warm()
	before = _snapshot("before-layer-cinematic")
	await _capture("before-layer-cinematic")
	Story._layer.start_cinematic(&"ne258_layer_fixture", lines)
	await _ui(4)
	var cinema := _snapshot("during-layer-cinematic")
	await _capture("during-layer-cinematic")
	_check(cinema["layer_cinematic"] and cinema["locked"] and not cinema["player_can_process"], "real DialogueLayer.start_cinematic acquired its lock")
	_check(not cinema["light_lit"] and not cinema["light_enabled"], "NE258 literal cinematic-off contract through real layer entry", "literal state requirement; native visibility still needs inspection")
	Story._layer.finish_cinematic()
	await _warm()
	Story._scenes["ne258_story_dialogue_fixture"] = {"mode": "dialogue", "lines": [{"speaker": "rin", "text": "正式故事入口核對。"}]}
	_check(Story.play(&"ne258_story_dialogue_fixture", false), "public Story.play accepts the isolated dialogue fixture")
	await _ui(4)
	cinema = _snapshot("during-story-dialogue")
	await _capture("during-story-dialogue")
	_check(cinema["story_cinematic"] and cinema["layer_cinematic"] and cinema["locked"], "the real Story owner reports active dialogue")
	_check(not cinema["light_lit"] and not cinema["light_enabled"], "NE258 literal cinematic-off contract through public Story.play", "literal state requirement; native visibility still needs inspection")
	Story.reset_active_presentation(&"test_teardown")
	Story._scenes.erase("ne258_story_dialogue_fixture")
	await _warm()
	for overlay: bool in [false, true]:
		var id := "ne258_animated_overlay_fixture" if overlay else "ne258_animated_stage_fixture"
		var steps: Array = [{"do": "wait", "time": 30.0}] if overlay else [{"do": "scene", "id": "ch1_revival_room", "fade": 0.05}, {"do": "wait", "time": 30.0}]
		Story._scenes[id] = {"mode": "animated", "overlay": overlay, "steps": steps}
		_check(Story.play(StringName(id), false), "public Story.play accepts " + id)
		await _ui(8)
		if not overlay:
			for frame in 120:
				if Story._player._stage != null and Story._player._fade.color.a <= 0.001:
					break
				await _ui(1)
			_check(Story._player._stage != null and Story._player._fade.color.a <= 0.001, "actual stage has finished its real fade")
		cinema = _snapshot("during-" + id)
		await _capture("during-" + id)
		_check(Story._player != null and Story._player.is_running() and cinema["story_cinematic"] and cinema["locked"], "real animated owner is running " + id)
		_check(not cinema["light_lit"] and not cinema["light_enabled"], "NE258 cinematic-off through " + id, "literal cinematic state")
		Story.reset_active_presentation(&"test_teardown")
		Story._scenes.erase(id)
		await _warm()
	before = _snapshot("before-base-pause")
	GameplayLock.set_base_paused(true)
	await _ui(4)
	var paused := _snapshot("during-base-pause")
	_check(paused["tree_paused"] and paused["light_energy"] == before["light_energy"] and paused["world_light"] == before["world_light"], "ordinary pause preserves the same frozen illumination", "freeze preservation")
	GameplayLock.set_base_paused(false)
	await _warm()
	var booth := Checkpoint.new()
	booth.position = _player.global_position + Vector2(20, 0)
	_level._entities.add_child(booth)
	await _physics(8)
	_check(booth.start_call(_player), "real Checkpoint.start_call enters the Player phone action")
	await _physics(12)
	var phone := _snapshot("during-real-phone")
	_check(_player.is_on_phone() and booth.is_calling(), "phone call is still actually active when sampled")
	_check(not phone["light_lit"] and not phone["light_enabled"], "phone owner turns the light off without manual light calls", "NE258 phone requirement")
	await _finish_phone(booth)
	booth.queue_free()
	await _warm()
	var vehicle := Vehicle.new()
	vehicle.configure(load("res://data/vehicles/bulwark.tres"))
	vehicle.position = _player.global_position
	_level._entities.add_child(vehicle)
	await _physics(8)
	Input.action_press(&"interact")
	await _physics(2)
	Input.action_release(&"interact")
	await _physics(12)
	var mounted := _snapshot("during-real-mount")
	_check(_player.state == Player.State.MOUNTED and _player.mounted_vehicle == vehicle and vehicle.driver == _player, "public interact actually mounted the real vehicle")
	_check(not mounted["light_lit"] and not mounted["light_enabled"], "vehicle owner turns the light off without manual light calls", "NE258 vehicle requirement")
	_player.dismount_vehicle(false)
	await _physics(60)
	vehicle.queue_free()
	await _warm()
	_snapshot("after-real-dismount")
	await _lifecycle_cases(lines)
	var failed := _checks.filter(func(row: Dictionary) -> bool: return not row["passed"]).size()
	var report := {"scope": "Arranged CPU owner/state/world-light-query diagnostics, no native visual or human gameplay claim",
		"observer_always_level_pausable": true, "rows": _rows, "captures": _captures, "checks": _checks, "failures": failed}
	var writer := FileAccess.open(_out.path_join("owner-report.json"), FileAccess.WRITE)
	writer.store_string(JSON.stringify(report, "\t"))
	writer.close()
	print("NE258_OWNER_RESULT checks=", _checks.size(), " failures=", failed)
	Story.auto_skip = true
	AimInput.using_gamepad = false
	_level.queue_free()
	await _ui(4)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failed == 0 else 1)
