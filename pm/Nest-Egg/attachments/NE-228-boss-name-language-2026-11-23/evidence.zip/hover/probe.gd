extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const WIDTH := Vector2i(1280, 720)
const EXPECTED := {
	"en": ["Collect or earn credits from enemies to upgrade weapons.", "Ticks mark the boss's phase changes."],
	"ja": ["拾うか敵を倒してクレジットを獲得し、武器を改造できます。", "目盛りはボスの次の段階に移る体力を示します。"],
	"zh": ["撿拾或擊敗敵人取得信用點，用來改裝武器。", "刻度標示頭目轉階的血量。"],
}
var _out := ""
var _checks := 0
var _fails := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	get_window().size = WIDTH
	DisplayMode.ensure_scaling(get_window())
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://hud-hover-language-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	GameState.story_autosave = false
	add_child(LightKit.create_environment())
	GameState.start_new_run(GameState.difficulties[1])
	var data := (load("res://data/levels/ch1_street.tres") as LevelData).duplicate(true) as LevelData
	data.intro_scene = &""
	var level := Level.new()
	level.configure(data)
	add_child(level)
	for frame in 180:
		if level.is_initialized() and not GameplayLock.is_locked() and not Story.is_cinematic_active():
			break
		await get_tree().process_frame
	level.camera.snap_to_target()
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		enemy.set_physics_process(false)
	EventBus.boss_started.emit("Gatekeeper", 100)
	EventBus.boss_health_changed.emit(71, 100)
	var hud := level.hud
	var credits := hud.credits_tag
	var boss := hud.boss_bar
	_check(boss.is_open() and is_equal_approx(boss.ratio(), 0.71), "original HUD responds to boss health")
	_check(not hud.hover_guard.blocked, "ordinary HUD hovering is enabled")
	for language: String in EXPECTED:
		_check(Story.set_language(language), "changed language on the same level " + language)
		await _exercise(credits, EXPECTED[language][0], language + "-credits")
		await _exercise(boss, EXPECTED[language][1], language + "-boss")
	boss.set_phase_marks(PackedFloat64Array())
	Story.set_language("en")
	await _exercise(boss, "Shows the amount remaining in this phase.", "en-no-marks")
	_move(Vector2(-40, -40))
	level.queue_free()
	for frame in 8:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(1 if _fails else 0)


func _exercise(control: Control, expected: String, tag: String) -> void:
	_move(Vector2(-40, -40))
	await get_tree().process_frame
	await get_tree().process_frame
	var point := control.get_global_rect().get_center()
	_move(point)
	var deadline := Time.get_ticks_msec() + 2000
	var label := ""
	while Time.get_ticks_msec() < deadline:
		for child in control.get_children(true):
			var popup := child as Window
			if popup == null or not popup.visible or popup.is_queued_for_deletion():
				continue
			for text: Label in popup.find_children("*", "Label", true, false):
				label = text.text
				break
		if not label.is_empty():
			break
		await get_tree().process_frame
	print("HOVER ", tag, " ", label, " at ", point)
	_check(control.get_tooltip() == expected, tag + " resolves the current locale")
	_check(label == expected, tag + " engine tooltip shows that text")
	if label == expected and (tag == "en-credits" or tag == "ja-boss"):
		await RenderingServer.frame_post_draw
		var image := Capture.image(get_viewport())
		_check(image.save_png(_out.path_join(tag + ".png")) == OK, "captured " + tag)


func _move(point: Vector2) -> void:
	var event := InputEventMouseMotion.new()
	event.position = point
	event.global_position = point
	get_viewport().push_input(event, true)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	if not ok:
		printerr("FAIL: ", message)
