extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const AREA := "res://data/levels/ch1_warehouse.tres"
var _out := ""
var _checks := 0
var _fails := 0


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	GameState.story_autosave = false
	Story.auto_skip = true
	Enemy.activation_culling_enabled = false
	Settings.use_storage("user://watchdog-names-native.cfg")
	Settings.set_reduce_ui_motion(true)
	add_child(LightKit.create_environment())
	await _exercise("en", "Watchdog", "The partition lifted.")
	await _exercise("ja", "番犬", "仕切りが上がった。")
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(1 if _fails else 0)


func _exercise(language: String, name: String, notice: String) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(load(AREA) as LevelData)
	add_child(level)
	for frame in 240:
		if level.is_initialized() and not GameplayLock.is_locked() and not Story.is_cinematic_active():
			break
		await get_tree().process_frame
	var dog: PatternBoss
	for enemy in level._entities.get_children():
		if enemy is PatternBoss and (enemy as PatternBoss).data.id == &"watchdog":
			dog = enemy
		elif enemy is Enemy:
			enemy.set_physics_process(false)
	_check(dog != null, "loaded the actual watch dog in the original map for " + language)
	if dog != null:
		await _read_fight(level, dog, language, name, notice)
	level.queue_free()
	for frame in 10:
		await get_tree().process_frame


func _read_fight(level: Level, dog: PatternBoss, language: String, name: String, notice: String) -> void:
	var player := level.player
	player.health.setup(999, 0.0)
	player.global_position = dog.global_position + Vector2(-90.0, 0.0)
	player.velocity = Vector2.ZERO
	level.camera.snap_to_target()
	for frame in 180:
		if dog.is_awake() and dog.fsm.is_in(&"idle"):
			break
		await get_tree().physics_frame
	# Read the genuine entry radio before firing so the phase toast owns its normal HUD slot.
	for frame in 540:
		if not DialogueLayer.radio_visible() and not GameplayLock.is_locked():
			break
		await get_tree().process_frame
	var bar := level.hud.boss_bar
	var banner := level.hud.toast_banner
	print("WAREHOUSE ", language, " name=", bar._name, " health=", bar.ratio(), " radio=", DialogueLayer.radio_visible())
	_check(dog.is_awake() and bar.is_open() and is_equal_approx(bar.ratio(), 1.0), "the real guard starts at full health for " + language)
	_check(bar._name == name, "the title matches the story language " + language)
	var messages: Array[String] = []
	var gates: Array[StringName] = []
	var on_message := func(message: String) -> void: messages.append(message)
	var on_gate := func(channel: StringName, open: bool) -> void:
		if open:
			gates.append(channel)
	EventBus.toast_requested.connect(on_message)
	EventBus.mechanism_toggled.connect(on_gate)
	_hit(dog, int(dog.health.max_health * 0.45))
	for frame in 6:
		await get_tree().physics_frame
	var gun_notice := "Gun arm broken. Watch for shoulder missiles." if language == "en" else "銃腕が壊れた。肩のミサイルに注意。"
	for frame in 30:
		if banner.modulate.a >= 0.9:
			break
		await get_tree().process_frame
	print("PHASE TWO ", language, " phase ", dog.phase, " ", messages, " banner=", banner._label.text,
			" alpha=", banner.modulate.a, " radio=", DialogueLayer.radio_visible())
	_check(dog.phase == 1 and messages.has(gun_notice) and banner._label.text == gun_notice
			and banner.modulate.a >= 0.9 and not DialogueLayer.radio_visible(),
			"the real gun-arm transition appears in the HUD in the current language " + language)
	if language == "en":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join("watchdog-en.png")) == OK, "captured the actual English name and phase warning")
	_hit(dog, int(dog.health.max_health * 0.3))
	for frame in 6:
		await get_tree().physics_frame
	var chain_notice := "The chain broke. It can leave its territory." if language == "en" else "鎖が切れた。もう縄張りには縛られない。"
	print("PHASE THREE ", language, " phase ", dog.phase, " ", messages)
	_check(dog.phase == 2 and messages.has(chain_notice), "the chain break gives the current language " + language)
	_hit(dog, dog.health.max_health + 10)
	for frame in 220:
		if gates.has(&"watchdog_gate") and not bar.is_open():
			break
		await get_tree().physics_frame
	print("RELEASE ", language, " ", messages, " ", gates)
	_check(gates.has(&"watchdog_gate") and not bar.is_open(), "the original mechanism opens and closes the bar for " + language)
	_check(messages.has(notice), "the real gate notice matches " + language)
	EventBus.toast_requested.disconnect(on_message)
	EventBus.mechanism_toggled.disconnect(on_gate)


func _hit(dog: PatternBoss, amount: int) -> void:
	var info := DamageInfo.create(amount, Combat.Team.PLAYER, &"watchdog_language_probe")
	info.ignore_invulnerability = true
	info.bypass_guard = true
	dog.hurtbox.receive(info)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	if not ok:
		printerr("FAIL: ", message)
