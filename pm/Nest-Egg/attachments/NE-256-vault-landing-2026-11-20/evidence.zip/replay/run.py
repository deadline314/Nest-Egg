from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import os
import sys
import subprocess

root=Path.cwd()
base=Path(__file__).resolve().parent
shared=base.parents[1]/'ne218-baseline-20261117'
art=base.parents[1]/'evidence-20261120-st19-pear'
prior=root/'work/ne97-campaign-route-20261119'
runtime=json.loads((art/'source.json').read_bytes())
paths=['game/level/level_camera.gd','data/feel/camera.json','game/enemies/boss/pattern_boss.gd','autoload/fx.gd']
digest=lambda p: sha256(p.read_bytes()).hexdigest()
held=lambda: all(digest(shared/p)==runtime[p] for p in paths)
assert held()
for mode in sys.argv[1:] or ('baseline','guided'):
    assert mode in ('baseline','guided','sign')
    if mode=='sign':
        current=json.loads((base.parent/'source.json').read_bytes())
        four=json.loads((base.parent/'runtime.json').read_bytes())
        assert all(digest(shared/p)==current[p] and digest(root/p)==current[p] for p in four)
    out=base/mode
    (out/'slot').mkdir(parents=True)
    source=prior/'native-raft-v2/save/slot.json'
    orig=digest(source)
    copyfile(source,out/'slot/slot.json')
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(out/'profile'/key)
    args=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
          'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(shared),
          '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
          '--resolution','1280x720','--fixed-fps','60','--quit-after','18000',str(base/'route.tscn'),'--',
          '--from-save','--vault','--out='+str(out),'--save-dir='+str(out/'slot'),
          '--camera-audit','--camera-settle','--vault-shelf-only']
    if mode in ('guided','sign'):
        args.append('--vault-show-landing')
    if mode=='sign':
        args.append('--vault-check-sign')
    (out/'command.json').write_text(json.dumps(args,indent=2)+'\n')
    with (out/'raw.log').open('wb') as log:
        result=subprocess.run(args, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    raw=(out/'raw.log').read_text(encoding='utf-8',errors='replace')
    summary={'exit':result.returncode,'source_held':held(),'seed_sha256':orig,
             'issues':[line for line in raw.splitlines() if 'ERROR:' in line]}
    (out/'receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(raw[-3000:],summary,flush=True)
    assert held() and digest(source)==orig



