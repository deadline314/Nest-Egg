extends Node

var route: Node
var profile: StringName
var _projectile_audit := "--camera-projectile-audit" in OS.get_cmdline_user_args()
var _level: Level
var _player: Player
var _first_seen := {}
var _first_windup := {}
var _seen_enemy_shots: Dictionary[int, int] = {}
var _active_shot_observers: Dictionary[int, bool] = {}
var _missile_warnings: Dictionary[Vector2, Vector2i] = {}
var _last_ground := {}
var _takeoff := {}
var _damages: Array[Dictionary] = []
var _landings: Array[Dictionary] = []
var _windups: Array[Dictionary] = []
var _visited: Dictionary = {}


func _process(_delta: float) -> void:
	var main := route.get("_main") as Node
	if not is_instance_valid(main):
		return
	var active: Variant = main.get("_screen")
	var level := active as Level if is_instance_valid(active) else null
	var player := level.player if level != null and is_instance_valid(level.player) else null
	if level != _level or player != _player:
		_level = level
		_player = player
		_last_ground.clear()
		_takeoff.clear()
		_first_seen.clear()
		_first_windup.clear()
		_seen_enemy_shots.clear()
		_active_shot_observers.clear()
		_missile_warnings.clear()
		if is_instance_valid(player) and not player.health.damaged.is_connected(_damage):
			player.health.damaged.connect(_damage)
	if level == null or player == null or level.camera == null or not level.camera.is_current():
		return
	_visited[String(level.data.id)] = level.camera.tuning.zoom
	if player.is_dead() or GameplayLock.is_locked() or not level.is_processing():
		return
	var frame := Engine.get_physics_frames()
	var viewport := level.get_viewport()
	var screen := viewport.get_visible_rect()
	var transform := viewport.get_canvas_transform()
	if _projectile_audit:
		_observe_enemy_shots(frame, screen, transform)
	for node: Node in get_tree().get_nodes_in_group(&"enemies"):
		var enemy := node as Enemy
		if enemy == null or not level.is_ancestor_of(enemy) or enemy.health == null or enemy.health.current <= 0:
			continue
		var bounds := enemy.prompt_obstacle_rect()
		if _projectile_audit and enemy is PatternBoss and enemy.data.id == &"watchdog":
			_observe_missile_warnings(enemy as PatternBoss, frame, screen, transform)
		var visible := bounds.has_area() and screen.intersects(transform * bounds)
		var id := enemy.get_instance_id()
		if visible and not _first_seen.has(id):
			_first_seen[id] = frame
		if not _first_windup.has(id) and (enemy.fsm.current == &"windup" or enemy._telegraph_left > 0.0):
			_first_windup[id] = true
			_windups.append({"enemy": String(enemy.data.id), "area": String(level.data.id), "visible": visible,
				"first_visible_frames": frame - int(_first_seen[id]) if _first_seen.has(id) else -1})
	if player.is_on_floor():
		if not _takeoff.is_empty():
			var feet := player.global_position
			var from: Vector2 = _takeoff["feet"]
			if feet.distance_to(from) >= 16.0:
				var previous_transform: Transform2D = _takeoff["camera"]
				var before := previous_transform * feet
				_landings.append({"area": String(level.data.id), "from": [from.x,from.y], "landing": [feet.x,feet.y],
					"visible_before_takeoff": screen.has_point(before), "pixel_at_takeoff": [before.x,before.y],
					"jump": _takeoff["jump"], "air_frames": frame - int(_takeoff["frame"])})
			_takeoff.clear()
		_last_ground = {"feet": player.global_position, "camera": transform, "frame": frame}
	elif _takeoff.is_empty() and not _last_ground.is_empty():
		_takeoff = _last_ground.duplicate()
		_takeoff["jump"] = Input.is_action_pressed(&"jump") or player.velocity.y < -5.0
		_last_ground.clear()


func _damage(info: DamageInfo) -> void:
	if not is_instance_valid(_level) or not is_instance_valid(_player):
		return
	var viewport := _level.get_viewport()
	var source := info.get_attacker() as Node2D
	var status := "unknown"
	var source_type := ""
	if source != null and source.is_inside_tree():
		var on_screen := false
		if source is Enemy:
			var bounds := (source as Enemy).prompt_obstacle_rect()
			on_screen = bounds.has_area() and viewport.get_visible_rect().intersects(viewport.get_canvas_transform() * bounds)
			source_type = String((source as Enemy).data.id)
		else:
			on_screen = viewport.get_visible_rect().has_point(viewport.get_canvas_transform() * source.global_position)
			source_type = source.get_class()
		status = "visible" if on_screen else "outside"
	var entry := {"area": String(_level.data.id), "source": String(info.source_id), "source_type": source_type,
		"attacker": status, "amount": info.amount, "projectile": info.is_projectile, "health_after": _player.health.current,
		"frame": Engine.get_physics_frames()}
	if info.is_projectile and _projectile_audit:
		entry.merge(_match_received_shot(info))
	if _projectile_audit and info.source_id == &"watchdog_missile":
		var frame := Engine.get_physics_frames()
		# The authored explosion is centered four pixels above the warning ring.
		var warning := _missile_warnings.get(info.origin + Vector2(0, 4), Vector2i(-1, -1)) as Vector2i
		entry["warning_match"] = frame - warning.y <= 12 and warning.y >= 0
		entry["warning_visible_frames"] = frame - warning.x if entry["warning_match"] and warning.x >= 0 else -1
	_damages.append(entry)


func _observe_missile_warnings(boss: PatternBoss, frame: int, screen: Rect2, transform: Transform2D) -> void:
	for point in boss._marks:
		var previous := _missile_warnings.get(point, Vector2i(-1, -1)) as Vector2i
		var first: int = previous.x if frame - previous.y <= 2 else -1
		if first == -1 and screen.has_point(transform * point):
			first = frame
		_missile_warnings[point] = Vector2i(first, frame)
	if boss._marks.is_empty():
		for point in _missile_warnings.keys():
			if frame - _missile_warnings[point].y > 12:
				_missile_warnings.erase(point)


func _observe_enemy_shots(frame: int, screen: Rect2, transform: Transform2D) -> void:
	var bullets := ProjectilePool.container()
	if not is_instance_valid(bullets):
		return
	for node: Node in bullets.get_children():
		var shot := node as Projectile
		if shot == null or not shot.active or shot.team != Combat.Team.ENEMY:
			continue
		var id := shot.get_instance_id()
		if not _active_shot_observers.has(id):
			_active_shot_observers[id] = true
			if not shot.expired.is_connected(_forget_shot):
				shot.expired.connect(_forget_shot)
		if not _seen_enemy_shots.has(id) and screen.has_point(transform * shot.global_position):
			_seen_enemy_shots[id] = frame


func _forget_shot(shot: Projectile) -> void:
	_seen_enemy_shots.erase(shot.get_instance_id())


func _match_received_shot(info: DamageInfo) -> Dictionary:
	var bullets := ProjectilePool.container()
	if not is_instance_valid(bullets):
		return {"shot_match": "no-pool"}
	var match_id := 0
	var matches := 0
	for node: Node in bullets.get_children():
		var shot := node as Projectile
		if shot != null and shot.active and shot.team == info.team and shot.spec != null \
				and shot.spec.source_id == info.source_id and shot.global_position.is_equal_approx(info.origin):
			matches += 1
			match_id = shot.get_instance_id()
	if matches != 1:
		return {"shot_match": "ambiguous" if matches > 1 else "unresolved"}
	var seen: int = _seen_enemy_shots.get(match_id, -1)
	return {"shot_match": "exact", "frames_of_visible_lead": Engine.get_physics_frames() - seen if seen != -1 else -1}


func _exit_tree() -> void:
	var file := FileAccess.open(str(route.get("_out")).path_join("camera-observations.json"), FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify({"profile": String(profile), "visited": _visited,
			"windups": _windups, "damage": _damages, "landings": _landings}, "\t"))
