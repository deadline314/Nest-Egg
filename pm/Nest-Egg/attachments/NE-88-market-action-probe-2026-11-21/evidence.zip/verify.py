
from pathlib import Path
from collections import Counter
from PIL import Image
import json

base=Path(__file__).resolve().parent
def read(path):
    return json.loads(path.read_bytes())
def logs(filename):
    return (base/filename).read_text(encoding='utf-8-sig')

assert 'valid=false' in logs('stock-headless.log') and 'SCRIPT ERROR:' not in logs('stock-headless.log')
assert 'valid=true' in logs('final-headless.log') and 'ERROR:' not in logs('final-headless.log')
assert 'valid=false' in logs('legacy-control.log') and 'SCRIPT ERROR:' not in logs('legacy-control.log')
assert 'res://data/enemies/ch2_bill_thrower.tres (expected ch2_bill_thrower)' in logs('legacy-control.log')
assert read(base/'official-release/verification.json')=={'exit':0,'errors':[],'source_held':True}
summary={}
for tag, expected_quality in [('stock-native','high'),('final-high','high'),('final-low','low')]:
    directory=base/tag
    assert 'ERROR:' not in logs(tag+'.log') and 'BG55_ACTION actors=2 failures=0' in logs(tag+'.log')
    report=read(directory/'actions.json')
    assert report['quality']==expected_quality and report['failures']==0
    assert report['hdr_2d'] and report['renderer']=='forward_plus' and '9070 XT' in report['adapter']
    actors={data['id']:data for data in report['actors']}
    assert set(actors)=={'ch2_escort','ch2_bill_thrower'}
    overview={}
    for actor_id,data in actors.items():
        assert data['skin']==actor_id and {'windup','recover'}<=set(data['states'])
        assert len({row['enemy_hp'] for row in data['timeline']})==1
        if actor_id=='ch2_escort':
            assert 'strike' in data['states']
        else:
            assert Counter(p['source'] for p in data['projectiles'].values())=={'bill_paper':5}
        views={}
        for row in data['captures']:
            image=directory/row['file']
            with Image.open(image) as pic:
                assert all(i>0 for i in pic.size)
                pic.verify()
            if row['state'] in ('windup','strike','recover') and row['state'] not in views:
                views[row['state']]=row['file']
        assert {'windup','recover'}<=set(views)
        overview[actor_id]={'states':data['states'],'projectiles':len(data['projectiles']),
                             'frames':len(data['captures']),'source_sha256':data['enemy_data_sha256'],
                             'views':views}
    summary[tag]=overview
for actor in summary['stock-native']:
    assert len({data[actor]['source_sha256'] for data in summary.values()})==1
(base/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))

