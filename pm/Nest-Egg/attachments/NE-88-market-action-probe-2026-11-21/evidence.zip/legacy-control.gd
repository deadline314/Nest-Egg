extends "res://tools/bg55_enemy_action_probe.gd"

func _ready() -> void:
	const TARGET := "res://data/enemies/ch2_bill_thrower.tres"
	var original := load(TARGET) as EnemyData
	var changed := original.duplicate() as EnemyData
	changed.rig_skin = "collector_gunner"
	changed.take_over_path(TARGET)
	super._ready()

