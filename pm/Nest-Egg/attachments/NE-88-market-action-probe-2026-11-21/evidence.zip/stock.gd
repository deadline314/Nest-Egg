extends "res://tools/bg55_enemy_action_probe.gd"

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	super._ready()

