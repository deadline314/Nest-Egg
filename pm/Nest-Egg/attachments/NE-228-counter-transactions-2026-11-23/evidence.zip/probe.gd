extends "res://tests/smoke_test.gd"

const PAWNSHOP := preload("res://data/levels/ch1_pawnshop.tres")
const MED := preload("res://data/consumables/med_injector.tres")
const Capture := preload("res://tools/viewport_capture.gd")
const LOCALES := {
	"zh": ["當舖櫃台", "老 K 的櫃台", "購買", "還差", "已達攜帶上限", "典當", "贖回", "當票", "利息", "身上的錢已經滿了"],
	"ja": ["質屋", "老Kのカウンター", "購入", "あと", "所持上限", "質入れ", "買い戻す", "質札", "利息", "クレジットが上限"],
	"en": ["Pawnshop", "Old K's counter", "Buy", "Need", "Carry limit", "Pawn", "Redeem", "Ticket", "interest", "Wallet is full"],
}
const RECEIPT_VERBS := {
	"zh": ["購買", "贖回"],
	"ja": ["を購入", "を買い戻した"],
	"en": ["Bought", "Redeemed"],
}
var _image_path := ""


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	var args := OS.get_cmdline_user_args()
	if args.size() == 1:
		_image_path = args[0]
	Settings.use_storage("user://localized_counter_probe.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	for language in LOCALES:
		await _case(language)
	await _finish()


func _case(language: String) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	Progression.restore({"credits": 0})
	for flag in [&"ch1_prologue_done", &"ch1_dinner_done", &"ch1_heard_brief"]:
		GameState.set_flag(flag)
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	var level := Level.new()
	level.configure(PAWNSHOP)
	add_child(level)
	await _frames(10)
	var station: ShopStation
	for child in level.find_children("*", "Area2D", true, false):
		if child is ShopStation:
			station = child
			break
	_check(station != null, language + " formal counter exists")
	if station == null:
		level.queue_free()
		await _frames(3)
		return
	var prompt := station.get_children().filter(func(child: Node) -> bool: return child is WorldPrompt).front() as WorldPrompt
	var expected: Array = LOCALES[language]
	_check(prompt != null and prompt.text.contains(expected[1]) and prompt.text.contains("{interact}"),
		language + " authored world prompt retains actual binding")
	level.player.global_position = station.global_position
	await _frames(10)
	await _press(KEY_E)
	var screen := station._screen
	_check(screen != null and screen.is_open(), language + " counter from actual E input")
	if screen == null or not screen.is_open():
		level.queue_free()
		await _frames(3)
		return
	_check(screen._title.text == expected[0], language + " local counter title: " + screen._title.text)
	var stock := screen._pages[0] as ShopPage
	var pawn := screen._pages[1] as PawnPage
	var bag := level.player.consumables
	var entry := stock._entries[0]
	_check(entry.id == MED.id and entry.title == MED.display_name_for(language), language + " original shelf item")
	_check(entry.action_label.contains(expected[2]) and entry.action_label.contains(str(MED.price)) and stock._detail._action.disabled,
		language + " disabled buy button keeps price")
	_check(entry.action_hint.contains(expected[3]) and entry.action_hint.contains(str(MED.price)) and stock.current_hint() == entry.action_hint,
		language + " purchase shortfall in hover")
	await _press(KEY_ENTER)
	_check(bag.count(MED.id) == 0 and Progression.credits == 0, language + " refused purchase is atomic")
	_check(screen._hint_label.text.contains(expected[3]), language + " purchase refusal notice")
	Progression.add_credits(60)
	stock.refresh()
	_check(stock._entries[0].action_enabled and not stock._detail._action.disabled, language + " enough balance enables purchase")
	await _press(KEY_ENTER)
	_check(bag.count(MED.id) == 1 and Progression.credits == 0, language + " buys one for exact price")
	_check(screen._hint_label.text.contains(RECEIPT_VERBS[language][0])
		and screen._hint_label.text.contains(MED.display_name_for(language)),
		language + " purchase notice names item")
	await _press(KEY_E)
	_check(screen._current == 1 and pawn._entries.size() == 1, language + " next-tab binding opens pawn offers")
	entry = pawn._entries[0]
	var base := Progression.pawn_value(MED)
	var cost := Progression.redeem_cost(MED)
	_check(entry.title.contains(expected[5]) and entry.title.contains(MED.display_name_for(language))
		and entry.action_label.contains(str(base)), language + " pawn names item and exact proceeds")
	_check(" ".join(entry.detail_stats).contains(expected[8]) and " ".join(entry.detail_stats).contains("20%"),
		language + " pawn displays basis and interest")
	await _press(KEY_ENTER)
	_check(Progression.credits == base and Progression.pawned_count(MED.id) == 1 and bag.count(MED.id) == 0,
		language + " pawns once through accept")
	_check(screen._hint_label.text.contains(expected[5]) and screen._hint_label.text.contains(str(base)), language + " pawn success notice")
	entry = pawn._entries[0]
	_check(entry.title.contains(expected[6]) and entry.action_label.contains(str(cost)) and not entry.action_enabled,
		language + " redeem shows exact price when disabled")
	_check(entry.action_hint.contains(expected[3]) and entry.action_hint.contains(str(cost - base))
		and pawn._detail._action.tooltip_text == entry.action_hint, language + " redeem shortfall in visible tooltip")
	await _press(KEY_ENTER)
	_check(Progression.credits == base and Progression.pawned_count(MED.id) == 1 and bag.count(MED.id) == 0,
		language + " blocked redeem consumes no credits or tickets")
	_check(screen._hint_label.text.contains(expected[3]), language + " redeem refusal notice")
	Progression.add_credits(cost - base)
	pawn.refresh()
	await _press(KEY_ENTER)
	_check(Progression.credits == 0 and Progression.pawned_count(MED.id) == 0 and bag.count(MED.id) == 1,
		language + " exact redemption restores the original item")
	_check(screen._hint_label.text.contains(RECEIPT_VERBS[language][1])
		and screen._hint_label.text.contains(MED.display_name_for(language)), language + " redemption notice names item")
	Progression.add_credits(Progression.MAX_CREDITS - 1)
	pawn.refresh()
	entry = pawn._entries[0]
	_check(entry.action_label.contains("+¥1") and not entry.action_label.contains(str(base)), language + " quotes actual gain near wallet cap")
	if language == "en" and _image_path.is_absolute_path():
		await _frames(4)
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_image_path) == OK, "native cap-aware pawn screenshot")
	await _press(KEY_ENTER)
	_check(Progression.credits == Progression.MAX_CREDITS and Progression.pawned_count(MED.id) == 1 and bag.count(MED.id) == 0,
		language + " clipped pawn gain follows original economy")
	bag.add(MED)
	bag.add(MED)
	bag.add(MED)
	pawn.refresh()
	_check(pawn._entries[0].action_hint.contains(expected[9]), language + " full wallet reason")
	_check(pawn._entries[1].action_hint.contains(expected[4]) and not pawn._entries[1].action_enabled,
		language + " bag limit reason and disabled redeem")
	await _press(KEY_DOWN)
	await _press(KEY_ENTER)
	_check(bag.count(MED.id) == MED.max_carry and Progression.credits == Progression.MAX_CREDITS
		and Progression.pawned_count(MED.id) == 1, language + " full bag refuses redemption without mutation")
	await _press(KEY_ESCAPE)
	_check(not screen.is_open() and not get_tree().paused, language + " cancel resumes level")
	level.queue_free()
	await _frames(5)


func _press(code: int) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.keycode = code
	event.pressed = true
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await get_tree().process_frame
	await get_tree().physics_frame
	await get_tree().process_frame
	event.pressed = false
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await get_tree().process_frame

