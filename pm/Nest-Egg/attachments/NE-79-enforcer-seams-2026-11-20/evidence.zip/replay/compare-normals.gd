extends SceneTree

const MAKER := preload("res://tools/art/normal_map_maker.gd")

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() < 2 or args.size() % 2 != 0:
		quit(2)
		return
	for index in range(0, args.size(), 2):
		var source := Image.load_from_file(args[index])
		if source == null or not args[index+1].is_absolute_path():
			push_error("Cannot load normal source or output: " + args[index])
			quit(1)
			return
		var result := MAKER.make(source).save_png(args[index+1])
		if result != OK:
			push_error("Cannot write " + args[index+1])
			quit(1)
			return
	print("NormalMapMaker wrote ", args.size() / 2, " textures")
	quit(0)
