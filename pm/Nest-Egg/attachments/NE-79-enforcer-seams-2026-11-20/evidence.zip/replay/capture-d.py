from pathlib import Path
from hashlib import sha256
import json
import os
import subprocess
import sys

root=Path.cwd()
base=Path(__file__).resolve().parent
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
original=base.parent/'ne79-enforcer-neck-20261119'
argv=json.loads((original/'release-command.json').read_bytes())
roof=base.parent/'st19-roof-tea-20261120'
source=json.loads((roof/'integration/source.json').read_bytes())
tags=sys.argv[1:]
for tag in tags:
    out=Path('D:/NestEggVerification/evidence-20261120-ne79-traces')/tag
    out.mkdir(parents=True)
    art={name:sha256((shared/name).read_bytes()).hexdigest() for name in source if name.startswith('art/characters/enforcer/')}
    assert art and (not tag.startswith('before') or all(source[name]==proof for name,proof in art.items()))
    env=os.environ.copy()
    for name in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[name]=str(out/'profile'/name)
    env['PYTHONUTF8']='1'
    for mode, previous in argv.items():
        target=out/mode
        cmd=[('--out='+target.as_posix()) if arg.startswith('--out=') else arg for arg in previous]
        if tag.endswith('-all'):
            cmd = [arg for arg in cmd if not arg.startswith('--joints=')]
        if tag.startswith(('diag-a','diag-c')):
            texture = base / ('contact-' + tag[5]) / 'runtime/parts/head.png'
            assert texture.is_file()
            cmd.append('--diagnostic-part-texture=head:' + texture.as_posix())
        if tag.startswith('diag-limb-'):
            limb = tag.removeprefix('diag-limb-')
            slot, owner = {'knee_front':('leg_front_upper','leg_upper'),
                           'wrist_front':('arm_front_lower','arm_lower'),
                           'wrist_back':('arm_back_lower','arm_lower')}[limb]
            texture = base/'contact-limbs-b/runtime/parts'/f'{owner}.png'
            cmd = ['--joints='+limb if arg.startswith('--joints=') else arg for arg in cmd]
            cmd.append('--diagnostic-part-texture='+slot+':'+texture.as_posix())
        (out/f'{mode}-command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
        with (out/f'{mode}-raw.log').open('wb') as log:
            proc=subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=320)
        raw=(out/f'{mode}-raw.log').read_text(encoding='utf-8',errors='replace')
        assert proc.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw, raw[-3000:]
        check=subprocess.run([sys.executable,'-B',str(root/'tools/check_joint_frames.py'),str(target)],cwd=root,env=env,capture_output=True,timeout=100)
        (out/f'{mode}-checker.log').write_bytes(check.stdout+check.stderr)
        assert (target/'report.json').is_file(), check.stderr
    assert all(sha256((shared/name).read_bytes()).hexdigest()==proof for name,proof in art.items())
    (out/'source-held.json').write_text(json.dumps(art,indent=2)+'\n')
    print(out.name, 'both native renders and joint reports', len(art),'protected rig files',flush=True)
