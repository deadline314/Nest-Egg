from pathlib import Path
from PIL import Image
import numpy as np

old=Path("art/characters/enforcer/parts")
root=Path("D:/NestEggVerification/evidence-20261120-ne79-traces")
for name in ("head","arm_lower","leg_upper"):
    arr=lambda path:np.asarray(Image.open(path).convert("RGBA")).astype(int)
    old_n=arr(old/f"{name}_n.png")
    diffuse=arr(old/f"{name}.png")
    before=arr(root/f"before-{name}-normal.png")
    after=arr(root/f"after-{name}-normal.png")
    before_delta=np.abs(old_n-before)
    visible=diffuse[:,:,3]>128
    patch=np.argwhere(np.any(before!=after,axis=2))
    print(name,"published vs same generator",np.quantile(before_delta[visible].max(axis=1),[0,0.5,0.9,0.99,1]),
          "samples",len(patch),"min/max",patch.min(axis=0),patch.max(axis=0),
          "new normal format",Image.open(root/f"after-{name}-normal.png").mode)
