from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys

base=Path(__file__).resolve().parent
prior=base.parent/'ne79-enforcer-neck-20261119'
published=base.parent/'st19-roof-tea-20261120/integration'
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
target=Path('D:/NestEggVerification/evidence-20261120-ne79-traces')
default=json.loads((prior/'release-command.json').read_bytes())['worn']
label=sys.argv[1]
out=target/f'gear-{label}'
out.mkdir()
frozen=json.loads(((base/'trial-source.json') if label=='after' else (published/'source.json')).read_bytes())
paths=[path for path in frozen if path.startswith(('art/characters/enforcer/', 'art/weapons/', 'art/rigs/enforcer', 'game/rig/'))]
assert paths
def held():
    return all(sha256((shared/path).read_bytes()).hexdigest()==frozen[path] for path in paths)
assert held()
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
    (out/'profile'/key).mkdir(parents=True)
    env[key]=str(out/'profile'/key)
prefix=default[:default.index('res://tools/rig_joint_audit.tscn')]+['--resolution','1280x720','--fixed-fps','60','--quit-after','4000']
steps={
    'right':['res://tools/rig_preview.tscn','--',f'--out={(out/"right.png").as_posix()}','--chars=enforcer','--zoom=2.2'],
    'left':['res://tools/rig_preview.tscn','--',f'--out={(out/"left.png").as_posix()}','--chars=enforcer','--zoom=2.2','--left'],
    'armor':['res://tools/rig_preview.tscn','--',f'--out={(out/"armor.png").as_posix()}','--chars=enforcer','--damage','--zoom=3.0'],
    'combat':[(prior/'organic-replay-framed.tscn').as_posix(),'--',f'--out={(out/"combat").as_posix()}','--capture-images','--head='+subprocess.check_output(['git','rev-parse','HEAD'],cwd=shared,text=True).strip()],
}
for name,args in steps.items():
    cmd=prefix+args
    (out/f'{name}-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with (out/f'{name}.log').open('wb') as log:
        result=subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=140)
    raw=(out/f'{name}.log').read_text(encoding='utf-8',errors='replace')
    assert result.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw and held(),raw[-3000:]
    print(label,name,'passed',flush=True)
(out/'source-held.json').write_text(json.dumps({path:frozen[path] for path in paths},indent=2)+'\n')
