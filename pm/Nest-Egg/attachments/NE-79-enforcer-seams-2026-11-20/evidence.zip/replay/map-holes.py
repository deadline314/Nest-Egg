from pathlib import Path
from scipy import ndimage
import json
import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent
paths = {'neck-25': ('diag-a','dead'), 'wrist_front-2': ('before-all','dead'),
         'wrist_back-2': ('before-all','dead'), 'knee_front-2': ('before-all','crouch'),
         'knee_front-5': ('before-all','jump')}
assets=Path('art/characters/enforcer/parts')

def project(part, xy):
    matrix=np.asarray(part['to_cell'])
    local=np.linalg.solve(matrix[:,:2],xy-matrix[:,2])
    if 'rect_origin' in part:
        return local-part['rect_origin']
    for tri in part['triangles']:
        a,b,c=np.array(part['vertices'])[tri]
        uv_a,uv_b,uv_c=np.array(part['uv'])[tri]
        weights=np.linalg.solve(np.column_stack((b-a,c-a)),local-a)
        if min(weights)>=-0.00001 and sum(weights)<=1.00001:
            return uv_a + weights[0]*(uv_b-uv_a) + weights[1]*(uv_c-uv_a)
    return None

for case, (source, pose) in paths.items():
    trace=base/'traces'/case
    if not (trace/'frames.json').exists():
        continue
    joint, frame=case.rsplit('-',1)
    frame=int(frame)
    groups=json.loads((trace/'frames.json').read_bytes())
    group=next(group for group in groups if group['pose']==pose)
    cell=next(cell for cell in group['cells'] if cell['joint']==joint and cell['facing']==1)
    x,y,w,h=cell['rect']
    r=cell['radius']
    file=group['samples'][frame]['file']
    alpha=np.asarray(Image.open(trace/file))[:,:,3]
    ox,oy=x+w//2-r,y+h//2-r
    band=alpha[oy:oy+2*r,ox:ox+2*r]>=128
    mask=ndimage.binary_fill_holes(band,structure=np.ones((3,3))) & ~band
    output=[]
    for row,col in np.argwhere(mask):
        point=np.array([ox+col-x+0.5,oy+row-y+0.5])
        hit={'cell':point.tolist(),'materials':[]}
        for part in cell['geometry_sample']:
            uv=project(part,point)
            if uv is None:
                continue
            name=Path(part['texture'].removeprefix('res://')).name
            path=(base/'contact-a/runtime/parts/head.png') if part['part']=='head' and source=='diag-a' else assets/name
            if not path.is_file():
                continue
            image=np.asarray(Image.open(path).convert('RGBA'))
            edges=np.argwhere(image[:,:,3]>=128)
            nearest=edges[np.argsort(np.sum((edges-uv[::-1])**2,axis=1))[:4]][:,::-1]
            ix,iy=np.floor(uv).astype(int)
            direct=int(image[iy,ix,3]) if 0<=iy<image.shape[0] and 0<=ix<image.shape[1] else 0
            hit['materials'].append({'part':part['part'],'texture':name or 'head.png',
                                     'uv':uv.round(3).tolist(),'alpha':direct,'edge':nearest.tolist()})
        output.append(hit)
    print(case, json.dumps(output),flush=True)
    (trace/'mapped.json').write_text(json.dumps(output,indent=2)+'\n')
