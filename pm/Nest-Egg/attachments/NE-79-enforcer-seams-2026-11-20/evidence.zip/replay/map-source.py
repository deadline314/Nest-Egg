from pathlib import Path
import json
import sys
import numpy as np
from PIL import Image

root=Path.cwd()
sys.path.insert(0,str(root/'tools/comfyui'))
from cut_layers import part_transform

p=Path('art_src/characters/enforcer')
spec=json.loads(Path('tools/comfyui/specs/enforcer_side.json').read_bytes())
parts=spec['parts']
k=spec['tex_px_per_wp']/spec['illustration_px_per_wp']
joints={n: np.array(pt,float)*k for n,pt in spec['joints'].items()}
base=Path(__file__).resolve().parent
for case in sorted((base/'traces').glob('*/mapped.json')):
    output=[]
    for point in json.loads(case.read_bytes()):
        for m in point['materials']:
            name=Path(m['texture']).stem
            override=p/'overrides/refined'/f'{name}.png'
            source=override if override.exists() else p/'07_refined'/f'{name}.png'
            if name=='head':
                source=base/'contact-a/source/overrides/refined/head.png'
            image=Image.open(source).convert('RGBA')
            rgba=np.asarray(image)
            matrix,*_=part_transform(image,parts[name],joints,k)
            def unwarp(uv):
                return (matrix @ [uv[0], uv[1], 1])/k
            raw=unwarp(m['uv'])
            edges=[unwarp(uv) for uv in m['edge']]
            ix,iy=np.rint(raw).astype(int)
            output.append((name,m['uv'],raw.round(2).tolist(),int(rgba[iy,ix,3]),[edge.round(2).tolist() for edge in edges[:2]]))
    print(case.parent.name, output)
