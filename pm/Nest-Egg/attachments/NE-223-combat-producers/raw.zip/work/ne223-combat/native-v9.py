from pathlib import Path
import os,subprocess,json,shutil,hashlib
root=Path.cwd();out=root/'work/ne223-combat';env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/quests';saved=out/'native-save';results=[]
files=['work/ne223-combat/probe.gd','work/ne223-combat/phone_base.gd','work/ne223-combat/probe1080.gd','ui/cinematic_framing.gd','game/props/encounter_zone.gd','game/props/flood_pit.gd','game/enemies/boss/pattern_boss.gd']
(out/'frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')
for mode,scene,name in [('write','probe','ne223-1022-combat-writer'),('continue','probe1080','ne223-1022-combat-continue-1080')]:
 if mode=='continue':
  shutil.copytree(saved,out/'native-writer-save-frozen')
  (out/'native-cold-source.json').write_text(json.dumps({'writer_slot_sha256_before_continue':hashlib.sha256((saved/'slot.json').read_bytes()).hexdigest(),'frozen_copy_sha256':hashlib.sha256((out/'native-writer-save-frozen/slot.json').read_bytes()).hexdigest()},indent=2)+'\n')
 command=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/ne223-combat/'+scene+'.tscn','--mode='+mode,'--save-dir='+str(saved)]
 with (out/(name+'-wrapper.log')).open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1850)
 results.append({'mode':mode,'name':name,'command':command,'exit_code':r.returncode});(out/'native-receipt.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert r.returncode==0
