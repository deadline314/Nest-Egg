from pathlib import Path
import subprocess,os,json,time
root=Path.cwd();scratch=root/'work/ne223-combat';name='headless-v11';out=scratch/name;out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',XDG_DATA_HOME=str(scratch/(name+'-profile')))
command=['/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64','--headless','--path',str(root),'--fixed-fps','60','res://work/ne223-combat/probe.tscn','--','--out='+str(out),'--mode=write','--save-dir='+str(scratch/(name+'-save'))]
start=time.monotonic()
with (scratch/(name+'.log')).open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
(scratch/(name+'-receipt.json')).write_text(json.dumps({'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2)+'\n');print(r.returncode,flush=True)
raise SystemExit(r.returncode)
