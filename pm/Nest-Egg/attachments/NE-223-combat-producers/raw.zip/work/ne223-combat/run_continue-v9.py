from pathlib import Path
import os,subprocess,json,shutil,hashlib,time
root=Path.cwd();scratch=root/'work/ne223-combat';name='headless-v9-continue';out=scratch/name;out.mkdir(exist_ok=True);saved=scratch/'headless-v9-save';frozen=scratch/'headless-v9-writer-save-frozen';shutil.copytree(saved,frozen)
sha=hashlib.sha256((saved/'slot.json').read_bytes()).hexdigest();env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',XDG_DATA_HOME=str(scratch/(name+'-profile')))
command=['/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64','--headless','--path',str(root),'--fixed-fps','60','res://work/ne223-combat/probe.tscn','--','--mode=continue','--save-dir='+str(saved),'--out='+str(out)]
start=time.monotonic()
with (scratch/(name+'.log')).open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
(scratch/(name+'-receipt.json')).write_text(json.dumps({'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start,'writer_slot_sha256_before_continue':sha,'frozen_slot_sha256':hashlib.sha256((frozen/'slot.json').read_bytes()).hexdigest()},indent=2)+'\n');print(r.returncode,flush=True)
raise SystemExit(r.returncode)
