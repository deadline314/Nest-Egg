extends "res://work/ne223-combat/probe.gd"
func _continue() -> void:
	get_window().size = Vector2i(1920, 1080)
	DisplayMode.ensure_scaling(get_window())
	Settings.set_ui_text_scale(1.2)
	await super._continue()
