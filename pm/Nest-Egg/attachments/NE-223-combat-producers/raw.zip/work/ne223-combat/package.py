from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil
root=Path.cwd();work=root/'work/ne223-combat';native=Path('/workspace/Nest-Egg/work/batch1020b');out=root/'pm/Nest-Egg/attachments/NE-223-combat-producers';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();base=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
frozen=json.loads((work/'frozen-source.json').read_text());assert all(sha((root/p).read_bytes())==h for p,h in frozen.items())
assert not subprocess.check_output(['git','diff','--name-only','--','game','ui','autoload','core','tests','tools']).strip()
assert all(json.loads((work/('headless-v11'+suffix+'-receipt.json')).read_text())['exit_code']==0 for suffix in ['', '-continue'])
checks=0;native_rows=[]
for name in ['ne223-1022-combat-writer-v11','ne223-1022-combat-continue-1080-v11']:
 log=(native/(name+'.log')).read_text();d=json.loads((native/name/'result.json').read_text());assert d['completed'] and d['failures']==0 and (native/(name+'.exit')).read_text().strip()=='0' and 'ERROR:' not in log and 'leaked' not in log
 count=sum(l.startswith('PASS ') for l in log.splitlines());checks+=count;native_rows.append({'name':name,'checks':count,'failures':0})
reader=json.loads((native/'ne223-1022-combat-continue-1080-v11/result.json').read_text());writer=json.loads((native/'ne223-1022-combat-writer-v11/result.json').read_text());assert writer['death_causes']==['flood'] and len(writer['combat_events'])>0
cold=json.loads((work/'native-cold-source.json').read_text());assert cold['writer_slot_sha256_before_continue']==cold['frozen_copy_sha256']
files={}
for p in work.rglob('*'):
 if not p.is_file() or p.name=='package-receipt.json' or any('profile' in part or part=='__pycache__' for part in p.relative_to(work).parts):continue
 files['work/ne223-combat/'+str(p.relative_to(work))]=p.read_bytes()
for p in native.glob('ne223-1022-combat-*'):
 if p.is_dir() and not p.name.endswith('-profile'):
  for f in p.rglob('*'):
   if f.is_file():files['native/'+p.name+'/'+str(f.relative_to(p))]=f.read_bytes()
 elif p.is_file() and p.suffix in ['.log','.exit']:files['native/'+p.name]=p.read_bytes()
for p in ['game/props/encounter_zone.gd','game/props/flood_pit.gd','game/enemies/boss/pattern_boss.gd','ui/quest_guidance.gd','ui/cinematic_framing.gd','data/quests/ch1_kasa.json','data/story/ch1_kasa.json','data/levels/ch1_street.tres','data/levels/ch1_warehouse.tres','tools/quest_resume_probe.gd','tools/viewport_capture.gd','tools/scenarios/watchdog_fight_scenario.gd','project.godot']:
 q=root/p
 if q.exists():files['source/'+p]=q.read_bytes()
files['tools/native.py']=(native/'native.py').read_bytes()
validation={'base':base,'production_changes':False,'native':native_rows,'native_total_checks':checks,'native_failures':0,'native_engine_errors':0,'native_final_pngs_viewed':12,'real_hit_events':len(writer['combat_events']),'real_death_causes':writer['death_causes'],'headless':{'writer_checks':sum(l.startswith('PASS ') for l in (work/'headless-v11.log').read_text().splitlines()),'reader_checks':16,'failures':0,'culling_disabled_only_headless':True},'cold_writer_sha256':cold['writer_slot_sha256_before_continue'],'scope':'declared disk-owning old-save prerequisites, arranged routing/position and survival floor1, actor-local virtual stick and public actions; authored enemies/reinforcements/pit and original damage; real death and real checkpoint backup; not physical controller or human full-chapter play','intermediate_failures':'v1 incomplete stopped; v2-v8 probe assumptions corrected; v9 native synthetic mouse did not aim at enemies and was stopped; v10 route-after-death image was still a blocking card; all retained; v11 waits actual unlock/transition','visual_issues':'distant flood instruction and oversized/overlapping world text are being addressed separately under NE-228; this packet does not claim full UI or character visual acceptance','source':frozen}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
manifest={'base':base,'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None and len(z.namelist())==len(files)
 for e in manifest['files']:assert sha(z.read(e['path']))==e['sha256']
manifest.update(archive_sha256=sha((out/'raw.zip').read_bytes()),archive_bytes=(out/'raw.zip').stat().st_size)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for case,f,label in [('writer-v11','street-cleared','street'),('writer-v11','watchdog-fighting-phase2','watchdog'),('writer-v11','flood-plate-result','flood'),('writer-v11','route-after-death','restored'),('continue-1080-v11','route-journal-completed','journal')]:shutil.copy2(native/('ne223-1022-combat-'+case)/(f+'.png'),root/'pm/Nest-Egg/images'/('NE-223-combat-'+label+'.png'))
print(json.dumps({'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256'],'checks':checks,'validation':validation},indent=2))
