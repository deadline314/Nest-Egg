extends "res://work/ne223-combat/phone_base.gd"

const STREET := "res://data/levels/ch1_street.tres"
const WAREHOUSE := "res://data/levels/ch1_warehouse.tres"
var combat_events: Array = []

func _ready() -> void:
	# Headless has no screen visibility callbacks. Final native runs keep production culling.
	if DisplayServer.get_name() == "headless":
		Enemy.activation_culling_enabled = false
	super._ready()

func _until_play(predicate: Callable, seconds: float) -> bool:
	var deadline := Time.get_ticks_msec() + int(seconds * 1000.0)
	while Time.get_ticks_msec() < deadline:
		if predicate.call():
			return true
		if not await _read_interrupt():
			await get_tree().process_frame
	return bool(predicate.call())


func _shot(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await super._shot(name)
	else:
		rows.append({"name": name, "flags": GameState.world_flags.duplicate(true), "objective": _objective(), "deaths": GameState.deaths})
	if not rows.is_empty():
		rows[-1]["level"] = _level().data.resource_path
		rows[-1]["player_position"] = [_level().player.global_position.x, _level().player.global_position.y]
		rows[-1]["player_state"] = _level().player.state
		rows[-1]["health"] = _level().player.health.current
		rows[-1]["combat_event_count"] = combat_events.size()
		rows[-1]["production_culling"] = Enemy.activation_culling_enabled
	_save_report()

func _save_report() -> void:
	var report := {"completed": _completed, "failures": _failures, "mode": _mode, "rows": rows, "combat_events": combat_events,
		"scope": "real Main, authored enemies/reinforcements/pit; declared old-save prerequisites and arranged player positions/survival floor 1; public weapon input, no direct route flags, enemy damage or mechanism emits; not balance or human full-chapter acceptance"}
	FileAccess.open(out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))


func _route_step(flag: String) -> void:
	var catalog := _guidance().catalog
	var target := _guidance().state.target(catalog, "ch1_kasa", GameState.world_flags)
	_check(target.get("id") == "ch1_take_disk", "incomplete real route remains tracked despite disk ownership")
	_check(QuestCatalog.current_step(target, GameState.world_flags).get("complete_flag") == flag, "actual next route producer is " + flag)

func _durable_player() -> void:
	var player := _level().player
	player.health.floor_health = 1
	_check(player.health.invulnerability_time == player.tuning.hurt_invulnerability, "original hurt protection is retained; only probe survival floor is arranged")

func _formal_player() -> void:
	var player := _level().player
	player.health.floor_health = 0

func _set_action(action: StringName, on: bool) -> void:
	if on:
		Input.action_press(action)
	else:
		Input.action_release(action)

func _release() -> void:
	for action: StringName in [&"move_left", &"move_right", &"jump", &"move_down", &"dash", &"shoot", &"aim_left", &"aim_right", &"aim_up", &"aim_down"]:
		Input.action_release(action)

func _read_interrupt() -> bool:
	if Story._layer.is_radio_frozen():
		_release()
		await _read_to_end()
		return true
	return false

func _record_enemy(enemy: Enemy) -> void:
	enemy.health.damaged.connect(func(info: DamageInfo) -> void:
		combat_events.append({"enemy": String(enemy.data.id), "part": String(info.part), "damage": info.amount, "hp": enemy.health.current, "source": String(info.source_id)}))

func _street_fight() -> void:
	await _enter(STREET)
	_durable_player()
	_route_step("ch1_street_route_open")
	var zone: EncounterZone
	for node in _level().find_children("*", "", true, false):
		if node is EncounterZone and node.data.id == &"ch1_enc_street_blockade":
			zone = node
	_check(zone != null, "authored street blockade exists")
	if zone == null:
		return
	var rect := zone._zone_world_rect()
	_level().player.global_position = Vector2(rect.position.x + 48.0, zone.global_position.y - 2.0)
	var seen := {}
	var elapsed := 0.0
	var next_trace := 1.0
	var photographed := false
	while elapsed < 180.0 and zone.state != &"cleared":
		await get_tree().physics_frame
		if await _read_interrupt():
			continue
		elapsed += get_physics_process_delta_time()
		if not photographed and elapsed >= 5.0:
			photographed = true
			await _shot("street-fighting")
		var player := _level().player
		var target: Enemy
		var distance := INF
		for ref: WeakRef in zone._members:
			var enemy := ref.get_ref() as Enemy
			if not is_instance_valid(enemy) or enemy.is_dying():
				continue
			if not seen.has(enemy.get_instance_id()):
				seen[enemy.get_instance_id()] = true
				_record_enemy(enemy)
			var gap := player.global_position.distance_to(enemy.global_position)
			if gap < distance:
				target = enemy
				distance = gap
		if elapsed >= next_trace:
			next_trace += 10.0
			print("STREET_COMBAT_TRACE " + JSON.stringify({"elapsed": elapsed, "zone": String(zone.state), "living": zone.living_members(), "reinforcements": zone._reinforce_index, "player_position": [player.global_position.x, player.global_position.y], "player_state": player.state, "aim": [player.aim_dir.x, player.aim_dir.y], "mag": player.loadout.mag_in(player.loadout.active_slot), "headless_culling_disabled": not Enemy.activation_culling_enabled, "weapon": String(player.loadout.active_weapon().id) if player.loadout.active_weapon() != null else "none", "hits": combat_events.size(), "target": String(target.data.id) if target != null else "none", "target_position": [target.global_position.x, target.global_position.y] if target != null else [], "target_hp": target.health.current if target != null else 0}))
		if target == null:
			_set_action(&"shoot", false)
			continue
		var point := target.hurtbox.center()
		for part in target.hurtbox.parts:
			if part.part_id == &"head":
				point = part.center()
		var motion := InputEventMouseMotion.new()
		motion.position = get_viewport().get_final_transform() * player.get_canvas_transform() * point
		motion.global_position = motion.position
		Input.parse_input_event(motion)
		var offset := target.global_position.x - player.global_position.x
		_set_action(&"move_left", offset < -80.0)
		_set_action(&"move_right", offset > 80.0)
		var ray := PhysicsRayQueryParameters2D.create(player.global_position + Vector2(0, -8), player.global_position + Vector2(signf(offset) * 14.0, -8), Layers.WORLD)
		_set_action(&"jump", absf(offset) > 80.0 and (not player.get_world_2d().direct_space_state.intersect_ray(ray).is_empty() or not player.is_on_floor() and player.velocity.y < 0.0))
		_set_action(&"shoot", distance < 400.0)
	_release()
	_check(zone.state == &"cleared" and zone.living_members() == 0 and zone._reinforce_index == zone.data.reinforcements.size(), "real bullets clear the authored street members and both reinforcements")
	_check(GameState.has_flag(&"ch1_street_route_open") and not GameState.has_flag(&"watchdog_defeated"), "only real street completion publishes its route result")
	_route_step("watchdog_defeated")
	await _shot("street-cleared")
	_formal_player()

func _watchdog_fight() -> void:
	await _enter(WAREHOUSE)
	_durable_player()
	_route_step("watchdog_defeated")
	var dog: PatternBoss
	for node in get_tree().get_nodes_in_group(&"enemies"):
		if node is PatternBoss and node.data.id == &"watchdog" and _level().is_ancestor_of(node):
			dog = node
	_check(dog != null, "authored warehouse watchdog exists")
	if dog == null:
		return
	_record_enemy(dog)
	var bot := WatchdogFightScenario.new()
	add_child(bot)
	bot.level = _level()
	bot.player = _level().player
	bot._dog = dog
	bot.player.global_position.x = WatchdogFightScenario.START_TILE * 16.0
	var elapsed := 0.0
	var photographed_phase := -1
	while elapsed < 300.0 and is_instance_valid(dog) and not dog.is_dying():
		await get_tree().physics_frame
		if await _read_interrupt():
			continue
		elapsed += get_physics_process_delta_time()
		bot._drive()
		if is_instance_valid(dog) and dog.phase != photographed_phase:
			photographed_phase = dog.phase
			await _shot("watchdog-fighting-phase%d" % (dog.phase + 1))
	bot._release_all()
	_check(combat_events.any(func(e: Dictionary) -> bool: return e["enemy"] == "watchdog" and e["hp"] == 0 and e["source"] == "player_pistol"), "actual player pistol produces the lethal watchdog hit")
	_check(await _until(func() -> bool: return GameState.has_flag(&"watchdog_defeated"), 15.0), "authored watchdog collapse finishes and publishes its gate result")
	_check(GameState.has_flag(&"watchdog_defeated") and not GameState.has_flag(&"ch1_flood_gate_open"), "real watchdog death publishes only the watchdog result")
	await _read_to_end()
	_route_step("ch1_flood_gate_open")
	await _shot("watchdog-defeated")
	bot.queue_free()
	_formal_player()

func _flood_and_restore() -> void:
	var pit: FloodPit
	for node in _level().find_children("*", "", true, false):
		if node is FloodPit:
			pit = node
	_check(pit != null and not pit.triggered, "actual dry authored pit is still unfinished")
	if pit == null:
		return
	var original_level := _level().get_instance_id()
	var deaths := GameState.deaths
	_level().player.global_position = pit.global_position + Vector2(0, -pit.data.size_tiles.y * 16.0 - 16.0)
	_level().player.velocity = Vector2.ZERO
	_check(await _until_play(func() -> bool: return GameState.has_flag(&"ch1_flood_gate_open"), 15.0), "falling onto the real plate opens the actual flood gate")
	_check(QuestCatalog.status(_guidance().catalog.find("ch1_take_disk"), GameState.world_flags) == "completed", "disk ownership completes the route only after the last real mechanism")
	await _shot("flood-plate-result")
	_check(await _until_play(func() -> bool: return GameState.deaths > deaths, 15.0), "actual rising water causes the designed death")
	var budget := Time.get_ticks_msec() + 60000
	while Time.get_ticks_msec() < budget:
		if Story.is_cinematic_active():
			Story.skip_cinematic()
		var screen := _death_screen()
		if screen != null:
			screen.retry_requested.emit()
		if _level() != null and _level().get_instance_id() != original_level and not _level().player.is_dead() and not Story.is_cinematic_active() and not bool(_main.call("_route_pending")):
			break
		await get_tree().process_frame
	_check(_level() != null and not _level().player.is_dead() and GameState.deaths == deaths + 1, "formal death and restoration finish exactly once")
	_check(GameState.has_flag(&"ch1_street_route_open") and GameState.has_flag(&"watchdog_defeated") and GameState.has_flag(&"ch1_flood_gate_open"), "all real route results survive formal death")
	await _shot("route-after-death")

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	await _until(func() -> bool: return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested", GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE), "Main starts actual run")
	await _skip_cinematics()
	# Declared old-save prerequisites only. Never set the three producer results below.
	StoryItems.acquire(&"ch1_data_disk", false)
	for flag in [&"ch1_prologue_exit", &"ch1_dinner_done", &"ch1_heard_brief", &"ledger_disk_obtained"]:
		GameState.set_flag(flag)
	Story.outcomes.refresh_derived()
	_check(not GameState.has_flag(&"ch1_street_route_open") and not GameState.has_flag(&"watchdog_defeated") and not GameState.has_flag(&"ch1_flood_gate_open"), "declared disk-owning fixture has none of the three tested results")
	await _street_fight()
	await _watchdog_fight()
	await _flood_and_restore()
	# A real safe backup keeps the cold reader away from active warehouse enemies.
	await _enter(BOOTH)
	var checkpoint: Checkpoint
	for node in _level().find_children("*", "", true, false):
		if node is Checkpoint:
			checkpoint = node
	_check(checkpoint != null, "actual safe checkpoint exists after the route")
	if checkpoint == null:
		return
	_level().player.global_position = checkpoint.global_position + Vector2(-20, 0)
	_check(await _until(checkpoint.can_dial), "safe checkpoint sensor is ready")
	await _press(&"interact")
	_check(await _until(func() -> bool: return checkpoint.is_calling() or Story._layer.is_radio_frozen()), "public dial backs up the real completed route")
	if await _until(func() -> bool: return Story._layer.is_radio_frozen(), 3.0):
		await _read_to_end()
	_check(await _until(func() -> bool: return not checkpoint.is_calling() and not _level().player.is_on_phone()), "real safe backup ends normally")
	_check(_level().player.health.current == _level().player.health.max_health and _level().player.health.floor_health == 0, "real backup heals formal health with no probe survival floor")
	var expect := {"level": BOOTH, "credits": Progression.credits, "deaths": GameState.deaths}
	FileAccess.open(_save_dir.path_join("expect.json"), FileAccess.WRITE).store_string(JSON.stringify(expect))
	await _shot("route-safe-backup")
	_completed = true
	_save_report()
	FileAccess.open(out.path_join("combat-events.json"), FileAccess.WRITE).store_string(JSON.stringify(combat_events, "\t"))

func _continue() -> void:
	var expect: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(_save_dir.path_join("expect.json")))
	await _press_continue(expect["level"])
	_check(GameState.has_flag(&"ch1_street_route_open") and GameState.has_flag(&"watchdog_defeated") and GameState.has_flag(&"ch1_flood_gate_open"), "independent Main restores the three real route results")
	_check(StoryItems.holds(&"ch1_data_disk") and QuestCatalog.status(_guidance().catalog.find("ch1_take_disk"), GameState.world_flags) == "completed", "disk and completed route truth survive cold continue")
	_check(GameState.deaths == int(expect["deaths"]) and Progression.credits == int(expect["credits"]), "cold continue does not repeat deaths or route reward credits")
	_check(not Story._layer.is_radio_frozen() and not GameplayLock.is_locked() and not get_tree().paused, "cold continue leaves no radio or gameplay freeze")
	await _shot("route-cold-continued")
	await _enter(WAREHOUSE)
	_check(not get_tree().get_nodes_in_group(&"enemies").any(func(n: Node) -> bool: return n is PatternBoss and n.data.id == &"watchdog" and not n.is_dying()), "continued warehouse does not revive the actually defeated watchdog")
	var pit: FloodPit
	for node in _level().find_children("*", "", true, false):
		if node is FloodPit:
			pit = node
	_check(pit != null and pit.triggered and pit.is_flooded(), "actual flooded pit and bridge survive independent continue")
	_check(QuestCatalog.status(_guidance().catalog.find("ch1_take_disk"), GameState.world_flags) == "completed", "world revisit and journal still agree about the real route")
	await _shot("route-warehouse-revisited")
	_completed = true
	_save_report()
