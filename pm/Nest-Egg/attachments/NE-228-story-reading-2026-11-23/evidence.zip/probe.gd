extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
const DOCUMENT := &"doc_pawn_stub"
const RECORDING := &"rec_wataru_1"
const LOCALES := {
	"zh": ["文件", "錄音", "本章收集", "閱讀全文", "閱讀逐字稿"],
	"ja": ["文書", "録音", "章の収集", "全文を読む", "文字起こしを読む"],
	"en": ["Document", "Recording", "Chapter collection", "Read full text", "Read transcript"],
}


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://story_reader_check.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.auto_skip = true
	add_child(LightKit.create_environment())
	for language: String in LOCALES:
		Story.set_language(language)
		await _locale(language, LOCALES[language])
	await _finish()


func _locale(language: String, labels: Array) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	for scene in Story.scene_ids():
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	await _frames(8)
	StoryItems.acquire(DOCUMENT, false)
	StoryItems.acquire(RECORDING, false)
	var bag := level._inventory
	var index := bag.page_index(StoryItemsPage)
	var page := bag._pages[index] as StoryItemsPage
	bag.select_tab(index)
	bag.open()
	await _frames(4)
	_check(bag.is_open(), language + " opens the original story page from the street")
	await _open_item(bag, page, DOCUMENT, labels[0], labels[2], labels[3], language)
	await _open_item(bag, page, RECORDING, labels[1], labels[2], labels[4], language)
	bag.close()
	level.queue_free()
	await _frames(8)


func _open_item(bag: InventoryScreen, page: StoryItemsPage, id: StringName, kind: String, count_label: String, action: String, language: String) -> void:
	for i in page._entries.size():
		if page._entries[i].id == id:
			page._select(i)
			break
	var item := StoryItems.find(id)
	var record := page._entries[page._selected]
	var before := StoryItems.snapshot()
	_check(record.id == id and record.title == item.title_text(), language + "/" + str(id) + " original title")
	_check(record.subtitle == kind and record.detail_stats[0].begins_with(count_label), language + "/" + str(id) + " localized category and count")
	_check(record.action_label == action and not record.action_hint.is_empty(), language + "/" + str(id) + " reading action and hover")
	await _input_action(&"ui_accept")
	var shown := page._reader.visible
	_check(shown and page._reader._text.text == item.body_text(), language + "/" + str(id) + " modal shows the complete localized body")
	_check(shown and page._reader._back.has_focus() and get_tree().paused, language + "/" + str(id) + " reader stays in the paused focus context")
	if shown and language == "en" and id == RECORDING and OS.get_cmdline_user_args().size() == 1:
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(OS.get_cmdline_user_args()[0]) == OK, "native transcript capture")
	if shown:
		await _input_action(&"ui_cancel")
	_check(shown and not page._reader.visible and bag.is_open() and page._entries[page._selected].id == id,
			language + "/" + str(id) + " escape returns to the exact selected item")
	_check(before == StoryItems.snapshot(), language + "/" + str(id) + " reading does not consume the item")


func _input_action(id: StringName) -> void:
	var event := InputEventAction.new()
	event.action = id
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(2)
	event = InputEventAction.new()
	event.action = id
	Input.parse_input_event(event)
	await _frames(2)
