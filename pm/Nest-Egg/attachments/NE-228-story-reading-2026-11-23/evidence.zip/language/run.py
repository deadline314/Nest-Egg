from pathlib import Path
from tempfile import TemporaryDirectory
import os
import subprocess
import sys

base=Path(__file__).resolve().parent
shared=base.parent/"ne218-baseline-20261117"
engine="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
mode=sys.argv[1]
folder=base/mode
folder.mkdir()
checks = ("choose",) if mode in ("before", "recapture") else ("choose", "resume_choice", "override", "reset", "default", "invalid")
expected = {"choose":"zh", "resume_choice":"ja", "override":"en", "reset":"ja", "default":"zh", "invalid":"zh"}
with TemporaryDirectory(prefix="nestegg-language-") as temp:
    env=dict(os.environ,APPDATA=temp,LOCALAPPDATA=temp,XDG_DATA_HOME=temp)
    settings=Path(temp)/"Godot/app_userdata/Nest Egg/settings.cfg"
    for case in checks:
        if case == "invalid":
            assert settings.is_file()
            saved=settings.read_text(encoding="utf-8")
            assert saved.count("[display]")==1 and "story_language=" not in saved
            settings.write_text(saved.replace("[display]", '[display]\n\nstory_language={"broken": true}',1), encoding="utf-8")
        core=[engine,"--path",str(shared),"--fixed-fps","60","--audio-driver","Dummy","--quit-after","3500"]
        native=case=="choose" and mode!="before"
        command=([sys.executable,"-B",str(shared/"tools/comfyui/gpu_lock.py"),"--",*core,"--rendering-method","forward_plus",
                 "--rendering-driver","vulkan","--resolution","1280x720","--max-fps","120"] if native else [*core,"--headless"])
        command.extend((str(base/"probe.tscn"),"--",f"--mode={case}",f"--expect={expected[case]}"))
        if native:
            command.append(f"--capture={base/'choice.png'}")
        if case=="override":
            command.append("--story-language=en")
        raw=folder/(case+".log")
        with raw.open("wb") as output:
            proc=subprocess.run(command,env=env,cwd=shared,stdout=output,stderr=subprocess.STDOUT,timeout=120)
        (folder/(case+".exit")).write_text(str(proc.returncode)+"\n",encoding="utf-8")
        print(case,proc.returncode,raw.read_text(encoding="utf-8").splitlines()[-7:],flush=True)
        if mode!="before":
            assert proc.returncode==0 and "SCRIPT ERROR:" not in raw.read_text(encoding="utf-8")
