extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const MAIN := preload("res://scenes/main.tscn")
const LABEL := "劇情語言 / Story language"


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	var args := OS.get_cmdline_user_args()
	var mode := ""
	var expected := ""
	var out := ""
	for arg in args:
		if arg.begins_with("--mode="):
			mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--expect="):
			expected = arg.trim_prefix("--expect=")
		elif arg.begins_with("--capture="):
			out = arg.trim_prefix("--capture=")
	_check(Story.language == expected, "cold process loads the expected language " + expected)
	var main := MAIN.instantiate()
	add_child(main)
	var menu: MainMenu
	for i in 240:
		await get_tree().process_frame
		menu = main.get("_screen") as MainMenu
		if is_instance_valid(menu) and not Transition.is_active():
			break
	_check(is_instance_valid(menu), "normal Main boots to the main menu")
	if not is_instance_valid(menu):
		await _finish()
		return
	menu._open_settings()
	await _frames(4)
	var settings: SettingsScreen
	for item in menu.find_children("*", "Control", true, false):
		if item is SettingsScreen:
			settings = item
			break
	_check(is_instance_valid(settings), "normal main-menu action opens Settings")
	if not is_instance_valid(settings):
		await _finish()
		return
	settings._tabs.current_tab = 2
	await _frames(4)
	var option := _option_for(settings)
	_check(is_instance_valid(option), "Display offers the visible story-language selector")
	if is_instance_valid(option):
		var names := PackedStringArray()
		for i in option.item_count:
			names.append(option.get_item_text(i))
		_check(names == PackedStringArray(["繁體中文", "日本語", "English"]), "languages use their own native names")
		_check(option.tooltip_text.contains("Restart"), "short hover explains when the language applies")
		if mode == "choose":
			option.get_popup().index_pressed.emit(1)
			await _frames(3)
			_check(option.get_selected_id() == 1, "popup selection chooses Japanese")
			_check(Story.language == expected, "preference does not reload an active story catalog")
			_check(settings._status.text.contains("重新啟動"), "confirmation provides the next restart cue")
			option.grab_focus()
			await _frames(4)
			if out.is_absolute_path():
				await RenderingServer.frame_post_draw
				_check(Capture.image(get_viewport()).save_png(out) == OK, "native Settings screenshot")
		if mode == "resume_choice":
			_check(option.get_selected_id() == 1 and Story.language == "ja", "saved preference and real story catalog agree")
		if mode == "reset":
			settings._reset_current_tab()
			await _frames(3)
			_check(option.get_selected_id() == 0 and Story.language == "ja", "reset schedules the project language for next launch")
		var authored := Story.chapter_info(&"ch1_kasa")
		var subtitles := {"zh": "沉港市・下層港區", "ja": "沈港市・下層の港湾区", "en": "Sinkport · Lower Docks"}
		_check(authored.get("subtitle") == subtitles.get(expected), "real campaign text follows the initial language")
	settings.close()
	await _frames(4)
	main.queue_free()
	await _frames(6)
	await _finish()


func _option_for(screen: SettingsScreen) -> OptionButton:
	for label in screen.find_children("*", "Label", true, false):
		if label.text != LABEL:
			continue
		for sibling in label.get_parent().get_children():
			if sibling is OptionButton:
				return sibling
	return null
