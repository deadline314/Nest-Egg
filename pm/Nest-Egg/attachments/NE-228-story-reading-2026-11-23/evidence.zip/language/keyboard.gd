extends "res://tests/smoke_test.gd"

const MAIN := preload("res://scenes/main.tscn")


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	var main := MAIN.instantiate()
	add_child(main)
	var menu: MainMenu
	for i in 240:
		await get_tree().process_frame
		menu = main.get("_screen") as MainMenu
		if is_instance_valid(menu) and not Transition.is_active():
			break
	_check(is_instance_valid(menu) and not Transition.is_active(), "real title transition ends before interacting")
	if not is_instance_valid(menu):
		await _finish()
		return
	menu._open_settings()
	await _frames(4)
	var settings: SettingsScreen
	for item in menu.find_children("*", "Control", true, false):
		if item is SettingsScreen:
			settings = item
			break
	_check(is_instance_valid(settings), "launches the normal settings overlay")
	if not is_instance_valid(settings):
		await _finish()
		return
	settings._tabs.current_tab = 2
	await _frames(4)
	var option := settings._story_language_option
	option.grab_focus()
	await _frames(3)
	_check(option.has_focus(), "story language row takes keyboard focus")
	await _key(get_viewport(), KEY_ENTER)
	var popup := option.get_popup()
	_check(popup.visible and popup.get_focused_item() == 0, "Enter opens the language list on the current choice")
	if popup.visible:
		await _key(get_viewport(), KEY_DOWN)
		_check(popup.get_focused_item() == 1, "Down reaches Japanese")
		await _key(get_viewport(), KEY_ENTER)
	_check(not popup.visible and option.get_selected_id() == 1, "Enter chooses Japanese and closes the list")
	_check(Settings.get_story_language() == "ja" and Story.language == "zh", "real keyboard selection saves only the next-launch language")
	settings.close()
	await _frames(4)
	main.queue_free()
	await _frames(6)
	await _finish()


func _key(target: Viewport, code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = true
	target.push_input(event, true)
	await _frames(2)
	event = event.duplicate()
	event.pressed = false
	target.push_input(event, true)
	await _frames(2)
