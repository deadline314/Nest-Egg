from collections import Counter,defaultdict
from functools import lru_cache
from pathlib import Path
from PIL import Image
from scipy import ndimage
import json,numpy as np
base=Path(__file__).resolve().parent
@lru_cache(maxsize=6)
def alpha(folder,file):
    return np.array(Image.open(base/folder/file))[:,:,3]
def cut(folder,row):
    x,y,w,h=row['rect']; radius=row['radius']
    return alpha(folder,row['file'])[y+h//2-radius:y+h//2+radius,x+w//2-radius:x+w//2+radius]
neighbor=np.ones((3,3),bool)
def holes(solid):
    return ndimage.binary_fill_holes(solid,structure=neighbor)&~solid

proof={}
for mode in ('whole','dressed'):
    folder=f'armored-current-{mode}'
    cases=json.loads((base/folder/'report.json').read_bytes())['failures']
    result=[]
    for row in sorted((r for r in cases if r['enclosed_pixels']),key=lambda r:r['file']):
        actual=cut(folder,row)
        hole=holes(actual>=128)
        values=actual[hole]
        assert len(values)==row['enclosed_pixels']
        if mode=='whole':
            original=cut('armored-current-dressed',row)
            overlap={'open_in_dressed':not np.any(hole&holes(original>=128)), 'open_in_isolated':not np.any(hole&holes(cut('armored-current-isolated',row)>=128))}
        else:
            overlap={'covered_in_whole':bool(np.all(cut('armored-current-whole',row)[hole]>=128))}
        result.append(dict.fromkeys([],None)|{k:row[k] for k in ('char','joint','pose','file','zoom','frame','facing')}|
                      {'pixels':len(values),'min_alpha':int(values.min()),'max_alpha':int(values.max()),**overlap})
    proof[mode]=result
    counts=defaultdict(Counter)
    for r in result:
        label=(r['char'],r['joint'],r['pose'])
        counts[label]['frames']+=1
        a=r['min_alpha']
        counts[label]['alpha0' if a==0 else 'alpha1-63' if a<64 else 'alpha64-119' if a<120 else 'alpha120-127']+=1
        for k,v in r.items():
            if isinstance(v,bool) and v: counts[label][k]+=1
    for key,counts in counts.items():
        print(mode,*key,dict(counts))
(base/'armored-alpha-classification.json').write_text(json.dumps(proof,indent=2)+'\n')
