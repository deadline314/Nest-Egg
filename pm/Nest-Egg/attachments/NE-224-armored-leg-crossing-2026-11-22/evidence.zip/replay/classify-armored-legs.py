from collections import Counter
from functools import lru_cache
from pathlib import Path
from PIL import Image
from scipy import ndimage
import json,numpy as np

base=Path(__file__).resolve().parent
source="armored-current-whole"
legs="armored-leg-only"
joints={"ankle_back","ankle_front","knee_back","knee_front"}
read=lambda folder,name:json.loads((base/folder/name).read_bytes())

def cell_key(row):
    return row["char"],row["joint"],row["facing"]

def hard_legs(folder):
    return {(row["pose"],row["zoom"],row["frame"],*cell_key(row)):row
            for row in read(folder,"report.json")["failures"] if row["joint"] in joints
            and (row["enclosed_pixels"] or row["loose_pieces"] or row["center_alpha"]<128)}

def cells(folder):
    return {(group["pose"],group["zoom"],*cell_key(cell)):cell for group in read(folder,"frames.json") for cell in group["cells"]}

@lru_cache(maxsize=6)
def alpha(folder, name):
    return np.asarray(Image.open(base/folder/name).convert("RGBA"))[:,:,3]

def cut(values, bbox):
    x,y,w,h=bbox["rect"]
    r=bbox["radius"]
    return values[y+h//2-r:y+h//2+r,x+w//2-r:x+w//2+r]

kernel=np.ones((3,3),bool)
def closed(pixels):
    mask=pixels>=128
    return ndimage.binary_fill_holes(mask,structure=kernel)&~mask

full=hard_legs(source)
both=hard_legs(legs)
slots=cells(legs)
rows=[]
for key,baseline in sorted(full.items(),key=lambda item:item[1]["file"]):
    x,y,frame,*joint=key
    sample=slots[x,y,*joint]
    a=cut(alpha(source,baseline["file"]),baseline)
    b=cut(alpha(legs,baseline["file"]),sample)
    before,after=closed(a),closed(b)
    rows.append({"case":key,"exact_match":bool(np.array_equal(before,after)),
                 "before_enclosed":int(before.sum()),"after_enclosed":int(after.sum()),
                 "before_without_match":sorted(int(v) for v in a[before&~after]),
                 "two_legs_at_missing":sorted(int(v) for v in b[before&~after]),
                 "other_shape_differences":int(np.count_nonzero((a>=128)!=(b>=128)))})
report={"rows":rows,"groups":dict(Counter((r["case"][3]+"/"+r["case"][4]) for r in rows)),
        "pixel_exact":sum(r["exact_match"] for r in rows),"full_count":len(full),"both_count":len(both),
        "both_only":[key for key in sorted(set(both)-set(full))]}
(base/"armored-legs-classification.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print({k:v for k,v in report.items() if k!="rows"})
for item in [row for row in rows if not row["exact_match"]][:18]:
    print(item)
