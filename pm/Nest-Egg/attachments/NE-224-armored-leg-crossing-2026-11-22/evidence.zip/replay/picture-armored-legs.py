from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
import json,numpy as np

base=Path(__file__).resolve().parent
proof=json.loads((base/"armored-legs-classification.json").read_bytes())
out=Image.new("RGB",(560,610),"#152131")
draw=ImageDraw.Draw(out)
for y,actor in enumerate(("heavy_gunner","warden")):
    example=max((r for r in proof["rows"] if r["case"][3]==actor),key=lambda r:r["before_enclosed"])
    pose,zoom,idx,_,joint,side=example["case"]
    for x,(data,label) in enumerate((("armored-current-whole","FULL ACTOR"),("armored-leg-only","TWO LEGS"))):
        path=base/data
        group=next(group for group in json.loads((path/"frames.json").read_bytes()) if group["pose"]==pose and group["zoom"]==zoom)
        cell=next(row for row in group["cells"] if (row["char"],row["joint"],row["facing"])==(actor,joint,side))
        row,col,w,h=cell["rect"]
        radius=cell["radius"]
        left,top=row+w//2-radius,col+h//2-radius
        source=Image.open(path/group["samples"][idx]["file"]).convert("RGBA")
        crop=source.crop((left,top,left+2*radius,top+2*radius))
        rgba=np.array(crop)
        solid=rgba[:,:,3]>=128
        holes=ndimage.binary_fill_holes(solid,structure=np.ones((3,3),bool))&~solid
        assert int(holes.sum())==example["before_enclosed"]
        compounded=Image.new("RGBA",crop.size,"#45516c")
        compounded.alpha_composite(crop)
        matte=np.array(compounded)
        matte[holes]=[225,112,153,255]
        tile=Image.fromarray(matte).convert("RGB").resize((280,280),Image.Resampling.NEAREST)
        out.paste(tile,(x*280,y*305+25))
        draw.text((x*280+8,y*305+7),f"{actor.replace('_',' ').upper()} | {label}",fill="#dce5ee")
out.save(base/"armored-leg-only-comparison.png")
