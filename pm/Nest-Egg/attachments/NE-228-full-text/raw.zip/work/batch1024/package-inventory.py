from pathlib import Path
import hashlib,json,zipfile,subprocess,re,shutil
root=Path('/workspace/Nest-Egg');w=root/'work/batch1024';n=root/'work/batch1020b';ui=Path.cwd();out=ui/'pm/Nest-Egg/attachments/NE-228-full-text';out.mkdir(exist_ok=True)
base='1bbac54e4ffcd6825debc9b5f76bb5b585afbafd'
frozen=json.loads((w/'inventory-final-source-v4.json').read_text())
for p,h in frozen.items():assert hashlib.sha256((ui/p).read_bytes()).hexdigest()==h,p
rebuilt=(ui/'tests/suite/test_collectibles.gd').read_text().replace('\n\tawait preload("res://tests/helpers/story_item_full_text_checks.gd").run(self)','')
assert rebuilt.encode()==subprocess.check_output(['git','show',base+':tests/suite/test_collectibles.gd'],cwd=ui)
for p in ['tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt','.github/workflows/tests.yml']:
 assert (ui/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p],cwd=ui),p
rows={}
for key,name in [('changed','inventory-changed-final-console.log'),('controller','inventory-controller-regression-console.log'),('formal_before','inventory-formal-before-console.log'),('formal_after_v2','inventory-formal-after-v2-console.log')]:
 t=(w/name).read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',t);assert m,name
 rows[key]=dict(zip(['checks','new_failures','known_failures','seconds'],map(int,m.groups())))
assert rows['changed']['new_failures']==rows['controller']['new_failures']==rows['formal_after_v2']['new_failures']==0
assert rows['formal_before']['new_failures']==3
native=json.loads((w/'inventory-native-final-v4.json').read_text());assert len(native)==4 and sum(r['checks'] for r in native)==264
for row in native:assert row['exit']==row['failures']==row['engine_errors']==row['leaks']==0
mouse=json.loads((w/'inventory-reader-mouse-final.json').read_text());assert mouse['checks']==66 and mouse['exit']==mouse['failures']==mouse['engine_errors']==mouse['leaks']==0
viewed=json.loads((w/'inventory-native-v4-viewed.json').read_text());assert len(viewed['individually_viewed'])==36
for p,h in viewed['individually_viewed'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
neg_ja=json.loads((w/'inventory-reader-native-negative.json').read_text());neg_en=json.loads((w/'inventory-reader-native-en-negative.json').read_text());assert neg_ja['failures']==6 and neg_en['failures']==7
original_ui=['ui/inventory/pages/story_items_page.gd','ui/inventory/inventory_page.gd','ui/inventory/inventory_screen.gd']
for p in original_ui:
 assert subprocess.check_output(['git','show','f50882e9:'+p],cwd=ui)==subprocess.check_output(['git','show','4f164615:'+p],cwd=ui)==subprocess.check_output(['git','show',base+':'+p],cwd=ui)
ci=json.loads((w/'ci-1bbac54e-final.json').read_text());assert ci['conclusion']=='success'
headless_errors={}
for directory in ['inventory-changed-final','inventory-controller-regression']:
 for p in (w/directory).glob('shard_*.log'):
  t=p.read_text();headless_errors[str(p.relative_to(root))]={'error_lines':t.count('ERROR:'),'script_errors':t.count('SCRIPT ERROR:'),'leak_diagnostics':len(re.findall('leaked|still in use at exit|PagedAllocator',t))};assert 'SCRIPT ERROR:' not in t
references=[]
for p,game,archive,observation in [
 ('pm/Nest-Egg/images/NE-244-ref-hollow-knight.jpg','Hollow Knight / Team Cherry','design/20-campaign-experience/INVENTORY_WORLD_CLARITY.md','Distinct item/name/text regions and legible foreground; does not prove a document-scroll input policy.'),
 ('pm/Nest-Egg/attachments/NE-278-references/ghost-song.webp','Ghost Song / Old Moon','pm/Nest-Egg/attachments/NE-278-references/sources.json','Separate text from busy art; this is dialogue, not evidence of an inventory reader or save policy.')]:
 references.append({'file':p,'game':game,'sha256':hashlib.sha256((ui/p).read_bytes()).hexdigest(),'original_archive':archive,'reviewed_again':'2026-10-24','observation':observation,'limits':'Existing research image viewed again; no fresh web retrieval, player poll, asset license transfer or production-art use claimed.'})
receipt={'base':base,'frozen_24_paths':frozen,'original_collectibles_assertions_input_waits_byte_identical':True,'original_ui_bytes_identical_in_f508_4f_1bba':True,'headless':rows,'headless_diagnostics':headless_errors,'native':native,'native_mouse':mouse,'native_negative_ja':neg_ja,'native_negative_en':neg_en,'prior_ci':ci,'references':references,'limits':['Production InventoryScreen/StoryItemsPage in actual pawnshop LevelPAUSABLE under observerALWAYS. Ownership/selection explicit UI fixture, not natural acquisition/Main save/cold continue/chapter proof.','Three existing story-data languages plus new reader/action copy, not complete UI localization; existing Chinese tab/type labels remain.','32 actual window PNG plus4 explicit pixel-region crops in the four-mode acceptance; separate mouse8 window PNG also individually viewed. Wide capture includes genuine KEEP pillarboxes, not synthetic padding.','Legacy opacity is a runtime single-factor diagnostic; actual product fill is restored, never forced opaque for the positive image.','Artificial long-text fixture is separate from authored content. Public scrolling reaches its last line; no physical input latency or hardware-controller/GPU claim.','Earlier inline/full-text assumptions, geometry/opacity rejections and ordinary-photo layout assumption are retained. Original product tests are not weakened.','V2 intermediate source reconstruction is labeled as reconstruction, not a captured runtime SHA. English negative receipt copied a stale4f description; actual1bba source metadata correction and original receipt both retained.','Mother-ticket criteria remain unchanged; no rig/portrait art, human chapter, full UI localization or full-ticket acceptance.']}
(out/'validation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
design=ui/'design/20-campaign-experience/STORY_ITEM_FULL_TEXT.md'
design.write_text('''# 劇情道具全文與閱讀返回\n\n2026-10-24，NE-228。先讀User-guide與既有背包／閱讀研究，再逐張重看Hollow Knight背包及Ghost Song對話來源圖。採文字與圖像分區、清楚目前物品及固定返回；沒有從圖片推論存檔、特定操作時間或玩家偏好民調。既有來源及本輪實圖見[完整證據](../../pm/Nest-Egg/attachments/NE-228-full-text/README.md)。\n\n市場M17摘要、P17報表與看房卡屬KEY_ITEM，原正式背包只顯示description，即使資料有body也無全文入口。文件資料保持原值；有body的關鍵物品提供閱讀全文。無body物品仍只查看，收集品原有本文與NEW／已讀政策保持。\n\n不能把長本文直接塞回窄詳情欄：原生JA120三份都超出頁面。閱讀改用現有工作區的寬文字頁，固定名稱、文字捲動區與返回；Back先回同一物品，保持背包及世界暫停。換頁、關閉與離樹不留下舊閱讀狀態。只讀既有資料，不發物品、付款、獎勵或故事結果。UI不新增等待或全域鎖。\n\n摘要欄不再重複清單已有的物品大圖，把空間留給完整說明與全文動作；照片等普通關鍵物品也保留清單圖、完整description及原只查看行為。原生EN120的原照片本身會超出頁界，不能為了維持重複圖而擠掉文字。字級、原說明與本文不縮短；新英文操作提示則用一句完整短文，實測不省略、不碰操作列。\n\n閱讀底板須不透明。原0.98在Forward+透出後方文字；同一實際視窗區域做底層顯示／隱藏，舊透明度必須有像素差，實際產品樣式應完全相同。恢復真正原樣式與底層後再繼續流程，不把隱藏背景當正式正例。\n\n正式資料的全文、焦點、返回同選取、長按不關父頁、切頁、重新開啟及明確關閉以公開語意與合成joypad事件驗證。另以公開Viewport GUI滑鼠命中真正按鈕及滾輪；人工長文只是獨立元件邊界，不偽作劇情文本。實際32張視窗圖、4張像素區域控制及滑鼠8圖逐張檢視。1280、1920、真正2560寬視窗、三種資料語言、120%與像素字型／減動態分開記錄；寬視窗保留專案KEEP真黑邊，未改拉伸政策。\n\n原CollectiblesSuite只增加四項；原斷言／輸入／等待可逐位元重建。正式十組回歸與額外手把流程保持原runner／selector／filters／known failures。所有中途失敗、收據更正與驗證界線保留，不代勾整票、完整UI翻譯、實體裝置、人物接點或整章。\n''')
files={}
def add(p,arc=None):
 p=Path(p);assert p.is_file(),p;files[arc or str(p.relative_to(root) if p.is_relative_to(root) else p)]=p.read_bytes()
for p in frozen:add(ui/p,'source/final/'+p)
for p in ['work/batch1024/inventory-reader-mouse-probe.gd','work/batch1024/inventory-reader-mouse-probe.tscn','work/.gdignore']:
 add(ui/p,'source/final/'+p)
for p in original_ui:files['source/before/'+p]=subprocess.check_output(['git','show',base+':'+p],cwd=ui)
add(design,'design/20-campaign-experience/STORY_ITEM_FULL_TEXT.md')
for pattern in ['inventory-*','document-reader-proposed.gd','story-items-page-proposed.gd','inventory-page-proposed.gd','inventory-screen-proposed.gd','native-large.py','package-inventory.py','ci-1bbac54e*']:
 for p in w.glob(pattern):
  if p.is_file():add(p)
for directory in ['inventory-formal-before','inventory-formal-after','inventory-formal-after-v2','inventory-changed-final','inventory-controller-regression']:
 for p in (w/directory).glob('*.log'):add(p)
for directory in ['inventory-v1-source','inventory-v2-source-reconstructed','inventory-v3-source']:
 for p in (w/directory).rglob('*'):
  if p.is_file():add(p)
for p in n.glob('ne228-1024-body-*'):
 if p.is_file():add(p)
 elif p.is_dir() and not p.name.endswith('-profile'):
  for f in p.glob('*'):
   if f.is_file():add(f)
for p in n.glob('ne228-1024-reader-*'):
 if p.is_file():add(p)
 elif p.is_dir() and not p.name.endswith('-profile'):
  for f in p.glob('*'):
   if f.is_file():add(f)
for r in references:add(ui/r['file'],'research/'+Path(r['file']).name)
add(out/'validation.json','validation.json')
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(out/'raw.zip') as z:
 for name,m in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==m['sha256'],name
h=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest()
public={
 'NE-228-fulltext-before.png':n/'ne228-1024-reader-before/ch1_market_summary-entry.png',
 'NE-228-fulltext-ja.png':n/'ne228-1024-reader-v4-ja720/ch1_market_summary-full-text.png',
 'NE-228-fulltext-zh-pixel.png':n/'ne228-1024-reader-v4-zh1080pixel/ch3_report_p17-full-text.png',
 'NE-228-fulltext-wide.png':n/'ne228-1024-reader-v4-zhwide/ch3_tour_card-full-text.png',
 'NE-228-fulltext-photo-before.png':n/'ne228-1024-reader-en-before-v4/ordinary-key-return.png',
 'NE-228-fulltext-photo-after.png':n/'ne228-1024-reader-v4-en720/ordinary-key-return.png'}
for name,p in public.items():shutil.copyfile(p,ui/'pm/Nest-Egg/images'/name)
(out/'README.md').write_text(f'''# NE-228：關鍵文件可全文閱讀並返回原選取\n\nM17摘要、P17報表與看房卡原本在正式背包只有簡短description；有body也無全文入口。現在關鍵物品有本文即可閱讀，返回保留原物品與暫停。物品圖留在左清單，詳情欄給完整說明與閱讀動作；本文不縮字、不改故事資料，無body物品仍只查看。\n\n[設計及相近作品](../../../../design/20-campaign-experience/STORY_ITEM_FULL_TEXT.md)、[全部原檔](raw.zip)、[逐檔SHA](manifest.json)、[完整收據](validation.json)。先讀User-guide，重看Hollow Knight實際背包圖與Ghost Song對話圖；沿用既有來源檔及署名，沒有新網頁擷取或玩家偏好民調。圖片支持分區／文字層次，不證明全文操作或保存政策。\n\n| 驗證 | 實際結果 |\n|---|---|\n| 原Collectibles單組＋4項入口控制 | 303／3失敗→303／0；最終版同套件再由原十組驗證 |\n| 原選擇器，基準1bbac54e | 十組{rows['changed']['checks']}項／0新／已知失敗，{rows['changed']['seconds']}秒；含原main |\n| 額外原手把流程 | {rows['controller']['checks']}項／0新／已知失敗，{rows['controller']['seconds']}秒 |\n| 真正介面四模式 | 71＋65＋64＋64＝264項／0失敗；四輪0引擎ERROR／退出洩漏 |\n| 公開GUI滑鼠命中與滾輪補驗 | 66／0；8次真正GUI按鈕點擊、64個factor4滾輪事件；0引擎ERROR／退出洩漏 |\n\n原Collectibles整份斷言、輸入與等待去掉唯一新增呼叫後逐位元重建一致，runner／selector／filters／known failures未改。Headless原壞資料與物理查詢ERROR按原filters留存，逐shard數見收據，沒有SCRIPT ERROR；不稱headless完全無ERROR。前一票1bbac54e完整[CI40079797885](https://github.com/deadline314/Nest-Egg/actions/runs/40079797885)96,422項／0新／已知失敗，541秒，原job保留。本票新完整CI推送後另核對。\n\n四模式是1280×720 JA120平滑、1280×720 EN120平滑＋真減動態、1920×1080 ZH120像素、2560×1080 ZH120平滑。32張真正視窗PNG與4張明示像素區域控制逐張檢視，滑鼠補驗8張亦逐張看過。寬圖是真視窗含KEEP側邊黑邊，沒有補黑或改拉伸模式，也不稱21:9擴充世界內容。資料／新增閱讀文案三語，既有中文頁籤及類型標籤仍可見，沒有代稱整套UI已翻譯。\n\n每份文件都核對完整既有body、真焦點、固定返回、回同一選取且仍暫停、按住Back不關父頁、切頁不復活舊閱讀、重開與明確關閉。真正Player位置／生命保持，owned／held、錢包與劇情旗標不變；NEW仍依原移開／關頁政策清除。人工長文只作另列元件邊界，公開輸入可到最後一行，返回不被擠走。滑鼠用與既有UI測試相同的Viewport公開輸入與真GUI命中；合成輸入不冒稱實體手把或OS指標延遲。\n\n原介面三檔復原作真正負控制：JA21／6，EN27／7。新reader存在但未接線，並非整份歷史checkout；三個原UI檔在f508／4f／1bba位元相同。新功能不存在時後續依賴真reader的檢查不假造執行，次數因此少於正例。EN另抓到原照片面板本身超出頁界。英文負控制收據複製了一句舊4f基準描述，實際git show HEAD是1bba，原收據與更正都保留，沒有冒稱兩個不同整份checkout相同。\n\n中途原檔完整保留：初始三份無inline全文；把全文塞原欄的明示執行期實驗三份都溢出，拒收。V1正式reader59／3，且0.98底板透出背景，拒收。V2 JA66／0但EN59／2，未整體接受。V3 JA68／0但EN62／1；新增普通物品案例原期待復原重複大圖，回查原英文照片本身就超頁，最後採整頁文字優先、保留清單圖與完整只查看語意。未改任何原產品斷言。V2中途來源有明示重建說明，不冒稱當時凍結SHA；最終V4的24關注來源在每次運行前後逐一SHA相等，原生與最終回歸期間保持。\n\n底板控制在同一真正視窗安靜區域比較底層顯示／隱藏：舊0.98有差，產品原樣式完全相同；最後恢復原樣式及底層。四張小PNG是明示區域取樣，不冒作整張視窗或隱藏背景的正式正例。\n\n這是ActualLevelPAUSABLE／observerALWAYS、正式InventoryScreen／StoryItemsPage與明示取得／選取fixture。不是自然取得、真正Main保存／跨程序續玩、人物接點、硬體GPU、實體控制器或人工整章驗收；母票六項原條件維持。\n\n原檔{len(files)}項、{(out/'raw.zip').stat().st_size:,} bytes；zip SHA `{h}`，逐項解出核對。\n''')
p=ui/'pm/Nest-Egg/[NE-228]重整全遊戲介面體驗.md';s=p.read_text();assert '# Commit-25' not in s
s+=f'''\n\n# Commit-25\n\n## 內文\n\n市場M17摘要、P17報表與看房卡原本只有短說明，無法在背包讀到完整證據。現在有全文的關鍵物品可開閱讀頁，返回保留原選取與世界暫停；長文可捲到最後一行，返回保持可見。圖示留在清單，把詳情空間給完整文字，英文普通照片也不再把面板擠過頁界。\n\n新增閱讀動作、返回與提示有中日英，使用原本文及數字；閱讀不消耗物品、不付款或改劇情旗標。先讀User-guide，對照Hollow Knight與Ghost Song實圖；[完整設計、負控制、中途拒收、圖片與驗證界線](attachments/NE-228-full-text/README.md)。\n\n### 測試結果\n\n| 項目 | 結果 |\n|---|---|\n| 原單組入口對照＋4項 | 303／3失敗→303／0 |\n| 最終原受影響十組 | {rows['changed']['checks']}項／0新／已知失敗，{rows['changed']['seconds']}秒 |\n| 額外原手把流程 | {rows['controller']['checks']}項／0新／已知失敗 |\n| 正式介面原生四模式 | 264／0；三語、大字、像素字型、減動態與真正寬視窗 |\n| 真GUI滑鼠與滾輪補驗 | 66／0；合成輸入與實體裝置分開 |\n\n五輪正例原生均0引擎ERROR與退出洩漏診斷，44張正例圖片逐張看過，其中四張是明示像素區域診斷；原斷言、輸入、等待與篩選規則保持。全套UI翻譯、人物與人工整章不由本次局部結果代勾。\n\n### 本作前後圖\n\n| 原本只有摘要 | 現在可閱讀全文並返回原選取 |\n|---|---|\n| ![原摘要](images/NE-228-fulltext-before.png) | ![日文大字全文](images/NE-228-fulltext-ja.png) |\n\n![中文像素字型完整報表](images/NE-228-fulltext-zh-pixel.png)\n\n![真正寬視窗的看房卡](images/NE-228-fulltext-wide.png)\n''';p.write_text(s)
p=ui/'pm/user_guide.md';p.write_text('2026-10-24（NE-228）：有body的關鍵物品須能從正式背包讀全文，不能只驗通用詳情元件。摘要／全文分開，圖示留清單，Back先回同一物品且維持暫停；原英文照片也要查真頁界，不能為重複大圖犧牲文字。0.98閱讀底板會透字，實際產品底層顯示／隱藏像素須相同。[330項原生、十組6049／0、負控制與全部原檔](Nest-Egg/attachments/NE-228-full-text/README.md)。三語指既有物品資料與新增文案，不冒稱全UI翻譯；真寬視窗含KEEP黑邊，四張區域控制另標，不代勾整票。前票1bbac54e完整CI96,422／0、541秒已核對。\n\n'+p.read_text())
print('PACKAGED',len(files),(out/'raw.zip').stat().st_size,h)
print(json.dumps(rows))
