from pathlib import Path
import subprocess,hashlib,json,os,time,re
root=Path('/workspace/Nest-Egg');ui=root/'work/batch1024/inventory-worktree';w=root/'work/batch1024';n=root/'work/batch1020b'
mapping={'story-items-page-proposed.gd':'ui/inventory/pages/story_items_page.gd','inventory-page-proposed.gd':'ui/inventory/inventory_page.gd','inventory-screen-proposed.gd':'ui/inventory/inventory_screen.gd'}
final={p:(ui/p).read_bytes() for p in mapping.values()}
assert subprocess.check_output(['git','branch','--show-current'],cwd=ui,text=True).strip()=='ne228-inventory-body-1024'
frozen={}
try:
 for p in mapping.values():
  old=subprocess.check_output(['git','show','HEAD:'+p],cwd=ui);(ui/p).write_bytes(old);frozen[p]=hashlib.sha256(old).hexdigest()
 name='ne228-1024-reader-en-before-v4';cmd=['python',str(w/'native-large.py'),name,'res://work/batch1024/inventory-full-reader-probe.tscn','--size=1280x720','--text-scale=1.2','--language=en','--font=smooth','--reduce-motion'];started=time.monotonic()
 with (w/'inventory-reader-native-en-negative-driver.log').open('w') as f:r=subprocess.run(cmd,cwd=root,env={**os.environ,'NE_NATIVE_PROJECT':'../batch1024/inventory-worktree'},stdout=f,stderr=subprocess.STDOUT,timeout=2000)
 t=(n/(name+'.log')).read_text();m=re.search(r'INVENTORY_FULL_READER checks=(\d+) failures=(\d+)',t)
 rec={'exit':r.returncode,'checks':int(m[1]) if m else None,'failures':int(m[2]) if m else None,'engine_errors':t.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',t)),'original_ui_sha256':frozen,'seconds':time.monotonic()-started,'scope':'Original three production routing files from current4f head, new reader present but unused. Same final public-input probe. Conditional later checks require a real opened reader; absent reader is recorded as failure, not fabricated.'}
 (w/'inventory-reader-native-en-negative.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
 assert m and r.returncode==1 and rec['failures']==7 and rec['engine_errors']==rec['leaks']==0,rec
finally:
 for p,data in final.items():
  if p in frozen:assert hashlib.sha256((ui/p).read_bytes()).hexdigest()==frozen[p],p
  (ui/p).write_bytes(data)
 print('OWN_UI_ROUTING_RESTORED_BYTE_EXACT',flush=True)
