extends Node
## Explicit ownership/selection UI fixture, not a chapter acquisition or save claim.
const IDS := [&"ch1_market_summary", &"ch3_report_p17", &"ch3_tour_card"]
var _out := ""
var _requested := Vector2i(1280, 720)
var _failures := 0
var _records: Array[Dictionary] = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--size="):
			var dimensions := arg.trim_prefix("--size=").split("x")
			_requested = Vector2i(int(dimensions[0]), int(dimensions[1]))
	Settings.use_storage("user://body-entry-fixture.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
		elif arg.begins_with("--font="):
			Settings.set_ui_font(arg.trim_prefix("--font="))
	Story.set_language("ja")
	get_window().size = _requested
	get_window().position = Vector2i(32, 32)
	DisplayMode.ensure_scaling(get_window())
	_run.call_deferred()

func _run() -> void:
	DirAccess.make_dir_recursive_absolute(_out)
	GameState.story_autosave = false
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	var data := (load("res://data/levels/ch1_pawnshop.tres") as LevelData).duplicate(true) as LevelData
	data.intro_scene = &""
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(data)
	add_child(level)
	await _frames(30)
	for id: StringName in IDS:
		StoryItems.acquire(id, false) # Declared ownership fixture only.
	var inventory: InventoryScreen = level._inventory
	inventory.open()
	await _frames(20)
	var index := inventory.page_index(StoryItemsPage)
	inventory.select_tab(index)
	await _frames(15)
	var page := inventory._pages[index] as StoryItemsPage
	for id: StringName in IDS:
		var selected := page._entries.find_custom(func(entry: InventoryEntry) -> bool: return entry.id == id)
		_check(selected >= 0, "real inventory page lists fixture item " + String(id))
		if selected < 0:
			continue
		page._select(selected)
		await _frames(15)
		var item := StoryItems.find(id)
		var text := page._detail._body.text
		var entry: InventoryEntry = page._entries[selected]
		_check(text == item.body_text() or not entry.action_label.is_empty(), "real inventory exposes a full-body reading entry " + String(id))
		_records.append({"id": String(id), "body": item.body_text(), "displayed": text, "action": entry.action_label, "full_body_inline": text == item.body_text(), "body_rect": str(page._detail._body.get_global_rect())})
		if DisplayServer.get_name() != "headless":
			await RenderingServer.frame_post_draw
			var captured := preload("res://work/batch1024/window_capture.gd").image(get_window())
			_check(captured != null and captured.save_png(_out.path_join(String(id) + ".png")) == OK, "actual native inventory capture " + String(id))
	var f := FileAccess.open(_out.path_join("inventory-body-entry.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"failures": _failures, "items": _records, "scope": "Actual LevelPAUSABLE and productionInventoryPage; observerALWAYS. Ownership and selection explicitly arranged for UI only; no chapter/save/human/controllerhardware claims."}, "  "))
	inventory.close()
	await _frames(8)
	level.queue_free()
	await _frames(8)
	print("INVENTORY_BODY_ENTRY failures=", _failures)
	get_tree().quit(1 if _failures else 0)

func _frames(count: int) -> void:
	for i in count:
		await get_tree().process_frame

func _check(ok: bool, message: String) -> void:
	print(("PASS " if ok else "FAIL ") + message)
	if not ok:
		_failures += 1
