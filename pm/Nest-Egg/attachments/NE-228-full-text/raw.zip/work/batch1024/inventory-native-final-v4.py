from pathlib import Path
import subprocess,os,json,hashlib,re,time
root=Path('/workspace/Nest-Egg');ui=root/'work/batch1024/inventory-worktree';w=root/'work/batch1024';n=root/'work/batch1020b'
paths=['ui/inventory/document_reader.gd','ui/inventory/document_reader.gd.uid','ui/inventory/pages/story_items_page.gd','ui/inventory/inventory_page.gd','ui/inventory/inventory_screen.gd','ui/inventory/card_list_page.gd','ui/inventory/detail_panel.gd','ui/kit/chamfer_box.gd','ui/kit/ui_theme.gd','ui/ui_kit.gd','tests/suite/test_collectibles.gd','tests/helpers/story_item_full_text_checks.gd','tests/helpers/story_item_full_text_checks.gd.uid','data/story_items/i18n.json','data/story_items/ch1_market_summary.tres','data/story_items/ch3_report_p17.tres','data/story_items/ch3_tour_card.tres','game/player/vehicle_command_input.gd','game/story_result_completion.gd','game/world_item_completion.gd','work/batch1024/inventory-full-reader-probe.gd','work/batch1024/inventory-full-reader-probe.tscn','work/batch1024/inventory-body-entry-probe.gd','work/batch1024/window_capture.gd']
frozen={p:hashlib.sha256((ui/p).read_bytes()).hexdigest() for p in paths};(w/'inventory-final-source-v4.json').write_text(json.dumps(frozen,indent=2)+'\n')
rows=[]
cases=[('ja720','1280x720','ja','smooth',['--opacity-control'],71,12),('en720','1280x720','en','smooth',['--reduce-motion'],65,8),('zh1080pixel','1920x1080','zh','pixel',[],64,8),('zhwide','2560x1080','zh','smooth',[],64,8)]
for tag,size,language,font,extra,checks,images in cases:
 name='ne228-1024-reader-v4-'+tag;cmd=['python',str(w/'native-large.py'),name,'res://work/batch1024/inventory-full-reader-probe.tscn','--size='+size,'--text-scale=1.2','--language='+language,'--font='+font,*extra];start=time.monotonic()
 for p,h in frozen.items():assert hashlib.sha256((ui/p).read_bytes()).hexdigest()==h,p
 with (w/(name+'-driver.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env={**os.environ,'NE_NATIVE_PROJECT':'../batch1024/inventory-worktree'},stdout=f,stderr=subprocess.STDOUT,timeout=2000)
 t=(n/(name+'.log')).read_text();m=re.search(r'INVENTORY_FULL_READER checks=(\d+) failures=(\d+)',t)
 row={'name':name,'size':size,'language':language,'font':font,'extra':extra,'exit':r.returncode,'checks':int(m[1]) if m else None,'failures':int(m[2]) if m else None,'engine_errors':t.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',t)),'png_count':len(list((n/name).glob('*.png'))),'seconds':time.monotonic()-start,'command':cmd};rows.append(row);(w/'inventory-native-final-v4.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert row['exit']==0 and row['checks']==checks and row['failures']==row['engine_errors']==row['leaks']==0 and row['png_count']==images,row
 for p,h in frozen.items():assert hashlib.sha256((ui/p).read_bytes()).hexdigest()==h,p
print('ALL_FOUR_FINAL_READER_NATIVE_CASES_PASS',flush=True)
