extends "res://work/batch1024/inventory-body-entry-probe.gd"
## Actual inventory actions; explicit ownership fixture, no chapter/save claim.
var _checks := 0

func _run() -> void:
	DirAccess.make_dir_recursive_absolute(_out)
	GameState.story_autosave = false
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	var data := (load("res://data/levels/ch1_pawnshop.tres") as LevelData).duplicate(true) as LevelData
	data.intro_scene = &""
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(data)
	add_child(level)
	await _frames(30)
	for id: StringName in IDS:
		StoryItems.acquire(id, false)
	var wallet := Progression.snapshot().duplicate(true)
	var flags := GameState.world_flags.duplicate(true)
	var custody := StoryItems.snapshot().duplicate(true)
	var inventory: InventoryScreen = level._inventory
	inventory.open()
	await _frames(20)
	var index := inventory.page_index(StoryItemsPage)
	inventory.select_tab(index)
	await _frames(15)
	var page := inventory._pages[index] as StoryItemsPage
	var frozen_position := level.player.global_position
	var frozen_health := level.player.health.current
	_check(get_window().size == _requested, "native window uses requested dimensions")
	for id: StringName in IDS:
		var selected := page._entries.find_custom(func(entry: InventoryEntry) -> bool: return entry.id == id)
		_check(selected >= 0, "real page lists fixture key document " + String(id))
		if selected < 0:
			continue
		page._select(selected)
		await _frames(15)
		var item := StoryItems.find(id)
		_check(not page._entries[selected].action_label.is_empty(), "real key document offers a visible full-text action " + String(id))
		_check(page._detail._body.text == item.description_text(), "compact summary remains available " + String(id))
		_check(page.get_global_rect().encloses(page._detail.get_global_rect()), "summary and action stay inside the actual page " + String(id))
		await _shot(String(id) + "-entry")
		await _action(&"ui_accept")
		var reader = page.get("_reader")
		_check(reader != null and reader.visible and inventory.is_open() and get_tree().paused, "public confirm opens only the nested reader " + String(id))
		if reader == null or not reader.visible:
			continue
		_check(reader._text.text == item.body_text() and reader._heading.text == item.title_text(), "reader displays every authored character " + String(id))
		_check(page.get_global_rect().encloses(reader.get_global_rect()) and reader.get_global_rect().encloses(reader._scroll.get_global_rect()) and reader.get_global_rect().encloses(reader._back.get_global_rect()), "reader text region and fixed return remain within the page " + String(id))
		_check(get_viewport().gui_get_focus_owner() == reader._back and reader._back.is_visible_in_tree(), "reader return owns visible focus " + String(id))
		_check(reader._text.get_global_rect().end.y <= reader._scroll.get_global_rect().end.y + 1.0 or reader._scroll.get_v_scroll_bar().max_value > reader._scroll.get_v_scroll_bar().page, "authored text fits or has a real scroll range " + String(id))
		await _shot(String(id) + "-full-text")
		if id == IDS[0] and OS.get_cmdline_user_args().has("--opacity-control"):
			await _opacity_control(page, reader)
		_records.append({"id":String(id),"body":reader._text.text,"language":Story.language,"text_scale":Settings.get_ui_text_scale(),"font":Settings.get_ui_font(),"reader_rect":str(reader.get_global_rect()),"scroll_rect":str(reader._scroll.get_global_rect()),"return_rect":str(reader._back.get_global_rect())})
		await _action(&"ui_cancel")
		_check(not reader.visible and inventory.is_open() and get_tree().paused and page._selected == selected, "Back restores the same selected item without resuming the world " + String(id))
		_check(get_viewport().gui_get_focus_owner() != reader._back, "hidden reader never retains return focus " + String(id))
		await _joy(JOY_BUTTON_A)
		_check(reader.visible and get_viewport().gui_get_focus_owner() == reader._back, "synthetic controller confirm opens the actual reader " + String(id))
		_send_joy(JOY_BUTTON_B, true)
		await _frames(4)
		_check(not reader.visible and inventory.is_open() and page._selected == selected, "synthetic controller Back returns one level " + String(id))
		await _frames(4)
		_check(inventory.is_open(), "holding Back does not close the parent inventory " + String(id))
		_send_joy(JOY_BUTTON_B, false)
		await _frames(2)
	_check(level.player.global_position == frozen_position and level.player.health.current == frozen_health, "actual pausable player remains stopped through reading")
	var now := StoryItems.snapshot()
	_check(now["owned"] == custody["owned"] and now["held"] == custody["held"] and Progression.snapshot() == wallet and GameState.world_flags == flags, "reading does not consume items, pay money or publish plot flags")
	# A separate, explicitly artificial widget case forces overflow; authored data is unchanged.
	await _action(&"ui_accept")
	var reader = page.get("_reader")
	if reader != null and reader.visible:
		reader.show_document("Long-text UI fixture", "UI SCROLL FIXTURE\n".repeat(60) + "END OF UI SCROLL FIXTURE", Palette.CYAN)
		await _frames(4)
		var bar: VScrollBar = reader._scroll.get_v_scroll_bar()
		_check(bar.max_value > bar.page, "artificial long-text case has actual overflow")
		for i in 64:
			_send_action(&"ui_down", true)
			_send_action(&"ui_down", false)
		await _frames(4)
		_check(bar.value >= bar.max_value - bar.page - 1.0 and reader._text.get_global_rect().end.y <= reader._scroll.get_global_rect().end.y + 1.0, "public scroll actions make the final line reachable")
		_check(reader.get_global_rect().encloses(reader._back.get_global_rect()) and reader._back.is_visible_in_tree(), "long text never pushes the return action away")
		await _shot("artificial-scroll-end")
		await _action(&"inventory_next_tab")
		_check(not reader.visible and inventory._current != index and inventory.is_open(), "changing tabs retires the nested reader")
		await _action(&"inventory_prev_tab")
		_check(inventory._current == index and not reader.visible, "returning to the tab does not resurrect a stale reader")
		page._select(page._entries.find_custom(func(entry: InventoryEntry) -> bool: return entry.id == IDS[-1]))
		await _action(&"ui_accept")
		_check(reader.visible, "actual selected document opens again after tab return")
		await _action(&"inventory")
		_check(not inventory.is_open() and not reader.visible and not get_tree().paused, "explicit inventory close releases its pause and nested view")
	var file := FileAccess.open(_out.path_join("reader-result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks":_checks,"failures":_failures,"items":_records,"scope":"Actual production InventoryScreen, public semantic keyboard and synthetic joypad999 events. LevelPAUSABLE observerALWAYS. Ownership/selection fixture only; artificial overflow text clearly separate. No natural acquisition, save, physical-controller, hardware-GPU or human-chapter claim."}, "  "))
	inventory.close()
	await _frames(8)
	level.queue_free()
	await _frames(8)
	Sfx.stop_all()
	Music.stop(0.0)
	Ambience.stop_all(0.0)
	await _frames(4)
	print("INVENTORY_FULL_READER checks=",_checks," failures=",_failures)
	get_tree().quit(1 if _failures else 0)

func _action(action: StringName) -> void:
	_send_action(action, true)
	await _frames(2)
	_send_action(action, false)
	await _frames(2)

func _send_action(action: StringName, pressed: bool) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = pressed
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _joy(button: JoyButton) -> void:
	_send_joy(button, true)
	await _frames(2)
	_send_joy(button, false)
	await _frames(2)

func _send_joy(button: JoyButton, pressed: bool) -> void:
	var event := InputEventJoypadButton.new()
	event.device = 999
	event.button_index = button
	event.pressed = pressed
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _shot(label: String) -> void:
	await _frames(2)
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var capture := preload("res://work/batch1024/window_capture.gd").image(get_window())
	_check(capture != null and capture.get_size() == _requested and capture.save_png(_out.path_join(label + ".png")) == OK, "actual native window capture " + label)

func _check(ok: bool, message: String) -> void:
	_checks += 1
	super._check(ok, message)


func _opacity_control(page: StoryItemsPage, reader: UiPanel) -> void:
	var row := page.get_child(0) as CanvasItem
	var original_modulate := row.modulate
	var panel := reader.get_theme_stylebox(&"panel") as ChamferBox
	var original_fill := panel.fill
	# Single-factor legacy visual control; restore the actual product style,
	# never force an opaque value for the positive capture.
	panel.fill = Color(original_fill, 0.98)
	panel.emit_changed()
	var legacy_visible := await _background_sample(reader, "legacy-background-visible")
	row.modulate.a = 0.0
	var legacy_hidden := await _background_sample(reader, "legacy-background-hidden")
	row.modulate = original_modulate
	panel.fill = original_fill
	panel.emit_changed()
	var actual_visible := await _background_sample(reader, "actual-background-visible")
	row.modulate.a = 0.0
	var actual_hidden := await _background_sample(reader, "actual-background-hidden")
	row.modulate = original_modulate
	await _frames(2)
	_check(not legacy_visible.is_empty() and legacy_visible != legacy_hidden, "single-factor legacy opacity control detects underlying HDR text")
	_check(not actual_visible.is_empty() and actual_visible == actual_hidden, "actual production pane pixels do not depend on underlying text")
	_check(row.modulate == original_modulate and panel.fill == original_fill, "visual control restores the actual row and product style exactly")


func _background_sample(reader: UiPanel, label: String) -> String:
	await _frames(2)
	await RenderingServer.frame_post_draw
	var full := preload("res://work/batch1024/window_capture.gd").image(get_window())
	if full == null:
		_check(false, "actual opacity sample window capture " + label)
		return ""
	var scroll: ScrollContainer = reader.get("_scroll")
	var transform := get_viewport().get_final_transform() * scroll.get_global_transform_with_canvas()
	var first := transform * Vector2(12, scroll.size.y - 22)
	var last := transform * Vector2(scroll.size.x - 12, scroll.size.y - 10)
	var rect := Rect2i(Vector2i(first.round()), Vector2i((last - first).round()))
	if not Rect2i(Vector2i.ZERO, full.get_size()).encloses(rect):
		_check(false, "actual opacity sample rectangle " + label)
		return ""
	var crop := full.get_region(rect)
	_check(full.get_size() == _requested and crop.save_png(_out.path_join(label + "-crop.png")) == OK, "actual pixel-region crop " + label)
	var hash := crop.get_data().hex_encode().sha256_text()
	print("READER_BG_SAMPLE ", JSON.stringify({"label":label,"window":str(full.get_size()),"region":str(rect),"sha256":hash,"scope":"Actual native window quiet reader region; explicit runtime style/background control, not a whole-window acceptance image."}))
	return hash
