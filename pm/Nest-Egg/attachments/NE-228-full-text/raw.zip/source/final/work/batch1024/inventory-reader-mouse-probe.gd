extends "res://work/batch1024/inventory-full-reader-probe.gd"
## Separate public Viewport mouse route; never a physical-device claim.
var _mouse_clicks := 0
var _wheel_events := 0

func _run() -> void:
	await super._run()
	_check(_mouse_clicks >= 8 and _wheel_events == 64, "actual GUI mouse entry/return buttons and wheel route were exercised")
	var result := {"checks":_checks,"failures":_failures,"mouse_clicks":_mouse_clicks,"wheel_events":_wheel_events,"wheel_factor":4.0,"scope":"Public Viewport.push_input in local viewport coordinates, actual Button GUI hit testing and ScrollContainer wheel events. Synthetic mouse, semantic remaining actions, joypad999; not physical hardware or OS pointer latency."}
	var file := FileAccess.open(_out.path_join("mouse-route.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(result, "  "))
	print("MOUSE_READER_FINAL ", JSON.stringify(result))
	get_tree().quit(1 if _failures else 0)

func _inventory() -> InventoryScreen:
	for child in get_children():
		if child is Level:
			return child._inventory
	return null

func _action(action: StringName) -> void:
	var inventory := _inventory()
	if inventory != null and inventory.is_open() and inventory._pages[inventory._current] is StoryItemsPage:
		var page := inventory._pages[inventory._current] as StoryItemsPage
		var reader = page.get("_reader")
		if action == &"ui_accept" and reader != null and not reader.visible and page._detail._action.visible:
			await _click(page._detail._action)
			return
		if action == &"ui_cancel" and reader != null and reader.visible:
			await _click(reader._back)
			return
	await super._action(action)

func _point(control: Control) -> Vector2:
	return control.get_global_transform_with_canvas() * (control.size * 0.5)

func _motion(point: Vector2) -> void:
	var event := InputEventMouseMotion.new()
	event.position = point
	event.global_position = point
	get_viewport().push_input(event, true)

func _click(control: Control) -> void:
	var point := _point(control)
	_motion(point)
	for pressed in [true, false]:
		var event := InputEventMouseButton.new()
		event.position = point
		event.global_position = point
		event.button_index = MOUSE_BUTTON_LEFT
		event.pressed = pressed
		get_viewport().push_input(event, true)
		await _frames(2)
	_mouse_clicks += 1

func _send_action(action: StringName, pressed: bool) -> void:
	if action == &"ui_down":
		if not pressed:
			return
		var inventory := _inventory()
		if inventory != null:
			var page := inventory._pages[inventory._current] as StoryItemsPage
			var reader = page.get("_reader") if page != null else null
			if reader != null and reader.visible:
				var point := _point(reader._scroll)
				_motion(point)
				var event := InputEventMouseButton.new()
				event.position = point
				event.global_position = point
				event.button_index = MOUSE_BUTTON_WHEEL_DOWN
				event.factor = 4.0
				event.pressed = true
				get_viewport().push_input(event, true)
				_wheel_events += 1
				return
	super._send_action(action, pressed)
