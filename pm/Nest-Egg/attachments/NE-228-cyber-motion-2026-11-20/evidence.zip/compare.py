from pathlib import Path
import json
from PIL import Image
import numpy as np

base = Path(__file__).resolve().parent
cases = ('original', 'candidate')
phases = ('normal', 'reduced', 'restored', 'cooldown')
runs = {case: json.loads((base/case/'run.json').read_bytes()) for case in cases}
assert runs['original']['input_save'] == runs['candidate']['input_save']
results = {}
for case, report in runs.items():
    assert report['exit'] == 0 and report['errors'] == [] and report['resolution']['failures'] == 0
    results[case] = {}
    for phase in phases:
        rows = [row for row in report['resolution']['samples'] if row['phase'] == phase]
        assert len(rows) == 36
        assert all(row['reduced'] == (phase == 'reduced') for row in rows)
        assert all(row['ready'] == (phase != 'cooldown') for row in rows)
        if phase != 'cooldown':
            assert all(row['charge'] == 100 and row['progress'] == 1 for row in rows)
        else:
            assert 50 < rows[0]['charge'] < rows[-1]['charge'] < 53
            assert 0 < rows[0]['progress'] < rows[-1]['progress'] < .1
        animate = phase in ('normal', 'restored') or (case == 'original' and phase == 'reduced')
        assert all(row['processing'] == animate for row in rows)
        elapsed = rows[-1]['time'] - rows[0]['time']
        assert (.57 < elapsed < .60) if animate else elapsed == 0
        results[case][phase] = {'samples':len(rows), 'processing':animate, 'animation_clock_change':elapsed,
                                'charge_range':[rows[0]['charge'],rows[-1]['charge']],
                                'progress_range':[rows[0]['progress'],rows[-1]['progress']]}

rect = (1098, 79, 1257, 103)
def glyph_frame(case, index):
    with Image.open(base/case/f'reduced-{index:02}.png') as image:
        assert image.size == (1280, 720)
        return np.asarray(image.convert('RGB').crop(rect))

glyphs = {case: np.stack([glyph_frame(case, i) for i in (0, 16, 32)]) for case in cases}
mask = np.all((glyphs['candidate'][:,:,:,1] > 90) &
              (glyphs['candidate'][:,:,:,2] > 90) &
              (glyphs['candidate'][:,:,:,0] < 80), axis=0)
assert mask.sum() > 200
for case in cases:
    green = glyphs[case][:,mask,1]
    results[case]['rendered_glyph'] = {
        'pixels': int(mask.sum()),
        'green_median': [float(v) for v in np.median(green, axis=1)],
        'green_range_median': float(np.median(np.ptp(green, axis=0)))}
assert results['original']['rendered_glyph']['green_range_median'] >= 12
assert results['candidate']['rendered_glyph']['green_range_median'] == 0
(base/'comparison.json').write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps(results, indent=2))