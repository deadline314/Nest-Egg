extends "res://tools/ch1_flow_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
var _store := ""
var _main: Node
var _gauge: CyberGauge
var _rows: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	if _level == null or _level.player == null:
		_check(false, "real Main street save resumes")
		_finish()
		return
	var player := _level.player
	var ability := Progression.find_ability(&"emp_pulse")
	player.cyber.charge = CyberSystem.MAX_CHARGE
	player.cyber.debug_set_ability(ability)
	_gauge = _level.hud.cyber_gauge
	await _settle(8)
	_check(ability != null and player.cyber.is_ready() and _gauge.visible and _gauge._ready_to_use, "the real cyber system makes the visible gauge ready")
	await _observe(&"normal")
	await _toggle_in_pause(true)
	await _observe(&"reduced")
	await _toggle_in_pause(false)
	await _observe(&"restored")
	await _send(&"ability")
	_check(not player.cyber.is_ready() and not _gauge._ready_to_use and _gauge._bar.ratio() < 1.0, "the original ability key consumes charge and updates readiness")
	await _observe(&"cooldown")
	_finish()


func _toggle_in_pause(value: bool) -> void:
	var menu := _level._pause_menu
	menu.open()
	await _settle(6)
	menu._open_settings()
	await _settle(7)
	var screen := menu._settings
	screen._tabs.current_tab = 2
	await _settle(4)
	var toggle := screen._reduce_ui_motion
	toggle.grab_focus()
	_check(get_tree().paused and toggle.visible and toggle.has_focus(), "the original display setting is focused in pause")
	await _send(&"ui_accept")
	_check(Settings.get_reduce_ui_motion() == value and toggle.button_pressed == value, "the original settings toggle updates the saved value")
	screen.close()
	menu.close()
	await _settle(8)


func _send(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await _settle(1)
	var released := InputEventAction.new()
	released.action = action
	Input.parse_input_event(released)
	await _settle(3)


func _observe(label: StringName) -> void:
	for index in 36:
		await RenderingServer.frame_post_draw
		var row := {
			"phase":label,"processing":_gauge.is_processing(),"time":_gauge._time,
			"ready":_gauge._ready_to_use,"charge":_gauge._charge,"progress":_gauge._progress,"reduced":Settings.get_reduce_ui_motion()}
		_rows.append(row)
		if index in [0, 16, 32]:
			var path := _out_dir.path_join("%s-%02d.png" % [label, index])
			_check(CAPTURE.image(get_viewport()).save_png(path) == OK, "write native %s" % path.get_file())
		await _settle(1)


func _finish() -> void:
	var f := FileAccess.open(_out_dir.path_join("gauge.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"failures":_failures,"samples":_rows},"  ")+"\n")
	f.close()
	_main.call("_quit",0 if _failures==0 else 1)