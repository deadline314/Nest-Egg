from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = root / 'work/ne88-cast-matrix-20261119'
out = base / 'final-native'
out.mkdir()
probe = base / 'probe.gd'
scene = base / 'probe.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n'
                 '[node name="CastMatrix" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
command = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '17000',
           scene.as_posix(), '--', '--out=' + str(out)]
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (out / 'raw.log').open('wb') as log:
    result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=320)
raw = (out / 'raw.log').read_text(encoding='utf-8')
print(raw[-5500:], flush=True)
report = json.loads((out / 'report.json').read_text(encoding='utf-8'))
counts = {key:{'authored':len(value['authored']), 'runtime':len(value['runtime']), 'samples':len(value['samples'])}
          for key,value in report['areas'].items()}
print(json.dumps({'counts':counts,'errors':report['errors']}, ensure_ascii=False), flush=True)
assert '9070 XT' in report['adapter'] and report['size'] == [1280, 720]
assert result.returncode == report['capture_failures'] == 0 and not report['errors'] and 'SCRIPT ERROR' not in raw
assert len(report['areas']) == 21 and sum(row['samples'] for row in counts.values()) >= 20
assert sum(case['conditional'] for area in report['areas'].values() for case in area['samples'].values()) == 5
