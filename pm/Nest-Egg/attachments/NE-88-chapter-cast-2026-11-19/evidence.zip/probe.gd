extends ScenarioBase

const LEVELS := "res://data/levels"
const CHAPTERS := [&"ch1_kasa", &"ch2_heron"]

var _results: Dictionary = {}
var _errors: Array[String] = []


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	Settings.set_reduce_ui_motion(true)
	for file in DirAccess.get_files_at(LEVELS):
		if not file.ends_with(".tres") or not (file.begins_with("ch1_") or file.begins_with("ch2_")):
			continue
		var data := load(LEVELS.path_join(file)) as LevelData
		if data != null and data.chapter in CHAPTERS:
			await _visit(data)
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	var size := get_window().size
	var report := {"areas": _results, "errors": _errors, "capture_failures": failures,
		"adapter": RenderingServer.get_video_adapter_name(), "size": [size.x, size.y]}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	get_tree().quit(0 if _errors.is_empty() and failures == 0 else 1)


func _visit(data: LevelData) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	level = Level.new()
	level.configure(data)
	add_child(level)
	player = level.player
	if not is_instance_valid(player) or level._layout == null or not level._layout.is_valid():
		_errors.append("%s cannot load its authored level" % data.id)
		await finish()
		return
	level._next_story_trigger = level._layout.story_triggers.size()
	player.process_mode = Node.PROCESS_MODE_DISABLED
	level.hud.visible = false
	for child in level.get_children():
		if child is ChapterCard:
			child.queue_free()
	var nodes: Array[Node2D] = []
	for entity in level._entities.get_children():
		if entity is Enemy:
			entity.process_mode = Node.PROCESS_MODE_DISABLED
			nodes.append(entity)
		elif entity is NpcActor and entity.data != null and entity.data.kind == NpcData.Kind.PERSON:
			nodes.append(entity)
	await settle(35)
	var authored := []
	for spawn in level._layout.spawns:
		var resource: Resource = spawn["resource"]
		if resource is EnemyData or (resource is NpcData and resource.kind == NpcData.Kind.PERSON):
			var cell: Vector2i = spawn["cell"]
			authored.append({"resource": resource.resource_path, "cell": [cell.x, cell.y]})
	var samples: Dictionary = {}
	var live := []
	for node in nodes:
		if not is_instance_valid(node):
			continue
		var record := _actor(node)
		live.append(record)
		var code := str(record["id"])
		if samples.has(code):
			continue
		var before: Dictionary = {}
		if node is NpcActor and not node.is_present():
			before = _enable_actor(node)
			await settle(20)
		if data.id == &"ch1_prologue":
			var old_k := nodes.filter(func(current: Node2D) -> bool: return current is NpcActor and current.is_present())
			if old_k.size() != 1 or old_k[0] != node:
				_errors.append("prologue fixture leaves multiple Old K placements active for %s" % code)
		if not node.is_visible_in_tree():
			_errors.append("%s/%s remains hidden after its authored flags" % [data.id, code])
			_restore_flags(before)
			continue
		var position := node.global_position
		player.global_position = position - Vector2(40.0, 0.0)
		player.velocity = Vector2.ZERO
		snap_camera()
		await settle(22)
		await RenderingServer.frame_post_draw
		var physical := get_viewport().get_canvas_transform() * position
		if not get_viewport().get_visible_rect().grow(1.0).has_point(physical):
			_errors.append("%s/%s anchor off-screen %s" % [data.id, code, physical])
		var name := "%s-%s" % [data.id, code]
		capture(name)
		samples[code] = {"name": name, "anchor": [physical.x, physical.y], "source": record["source"],
			"conditional": not before.is_empty(), "flag_keys": before.keys()}
		_restore_flags(before)
	if samples.is_empty():
		await RenderingServer.frame_post_draw
		capture("%s-entry" % data.id)
	_results[data.id] = {"chapter": data.chapter, "source": data.resource_path, "authored": authored,
		"runtime": live, "samples": samples, "boss": not level._layout.boss_spawn.is_empty()}
	await finish()
	level = null


func _enable_actor(actor: NpcActor) -> Dictionary:
	var saved: Dictionary = {}
	var required := actor.data.spawn_requires_flag
	var blocked := actor.data.spawn_unless_flag
	if required == &"ch1_prologue_dash_done":
		var predecessor := &"ch1_prologue_jump_done"
		saved[predecessor] = GameState.get_flag(predecessor, false)
		GameState.set_flag(predecessor, true, false)
	if required != &"":
		saved[required] = GameState.get_flag(required, false)
		GameState.set_flag(required, true, false)
	if blocked != &"":
		saved[blocked] = GameState.get_flag(blocked, false)
		GameState.set_flag(blocked, false, false)
	return saved


func _restore_flags(saved: Dictionary) -> void:
	for key: StringName in saved:
		GameState.set_flag(key, saved[key], false)


func _actor(node: Node2D) -> Dictionary:
	var data: Variant = node.get("data")
	var position := node.global_position
	var rig_id: String = data.rig_skin if data is EnemyData else data.rig_id
	return {"id": data.id, "source": data.resource_path, "rig": rig_id,
		"visible": node.is_visible_in_tree(), "kind": "enemy" if data is EnemyData else "person",
		"pos": [position.x, position.y]}
