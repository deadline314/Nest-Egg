from pathlib import Path
import hashlib,json,zipfile,subprocess
root=Path.cwd(); scratch=root/'work/ne228-ci'; out=root/'pm/Nest-Egg/attachments/NE-228-header-diagnostic';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
original=subprocess.check_output(['git','show','7ee228083b6da0d9660f33554c1667d799618d03:tests/helpers/contextual_ui_checks.gd']).decode()
final=(root/'tests/helpers/contextual_ui_checks.gd').read_text()
original_checks=[x.strip() for x in original.splitlines() if 'suite.check(' in x]
assert original_checks==[x.strip() for x in final.splitlines() if 'suite.check(' in x]
wait='await suite.runner.get_tree().create_timer(CinematicFraming.CHECK_INTERVAL + CinematicFraming.EASE_SECONDS + 0.1).timeout'
assert final.count(wait)==original.count(wait)==1
harness=['tests/smoke_test.gd','tools/run_tests.sh','tools/run_tests_parallel.sh','tools/run_tests_changed.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']
for f in harness: assert subprocess.check_output(['git','show','7ee228083b6da0d9660f33554c1667d799618d03:'+f])==(root/f).read_bytes(),f
assert 'checks: 406, new failures: 0, known failures (tests/known_failures.txt): 0' in (scratch/'changed.log').read_text()
control=(scratch/'diagnostic-control.log').read_text();assert 'checks: 13, failures: 1' in control and 'HEADER_RESTORE_STATE ' in control and 'SCRIPT ERROR' not in control
files={}
for f in scratch.rglob('*'):
 if f.is_file() and not any('profile' in p for p in f.parts) and not f.suffix=='.uid' and f.name not in ['package.py']:
  files['work/'+str(f.relative_to(scratch))]=f.read_bytes()
files['source/final-contextual_ui_checks.gd']=final.encode()
files['source/base-contextual_ui_checks.gd']=original.encode()
files['ci/job.log']=(root.parent/'ne254-ci-39732548254.log').read_bytes()
files['work/package.py']=(scratch/'package.py').read_bytes()
manifest={'base':'7ee228083b6da0d9660f33554c1667d799618d03','original_assertions_equal':True,'original_wait_equal':True,'harness_unchanged':harness,'files':[{'path':f,'bytes':len(b),'sha256':sha(b)} for f,b in sorted(files.items())]}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,b in sorted(files.items()): z.writestr(name,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 for entry in manifest['files']: assert sha(z.read(entry['path']))==entry['sha256']
manifest['archive_sha256']=sha((out/'raw.zip').read_bytes());manifest['archive_bytes']=(out/'raw.zip').stat().st_size
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},ensure_ascii=False))
