extends Node

const WAREHOUSE := preload("res://data/levels/ch1_warehouse.tres")
const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://pause-retry-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.set_language("en")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_prologue_exit")
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(WAREHOUSE)
	add_child(level)
	await _frames(32)
	var booth: Checkpoint
	for node in level._entities.get_children():
		if node is Checkpoint:
			booth = node
			break
	_check(booth != null and not GameState.has_checkpoint, "the actual fresh warehouse route has an unused telephone booth")
	if booth == null:
		await _finish(level)
		return
	level.player.global_position = booth.global_position + Vector2(-24.0, -1.0)
	await _frames(29)
	await _key(KEY_ESCAPE)
	var pause := level._pause_menu
	var retry := _retry_button(pause)
	_check(pause._root.visible and retry != null, "the actual Escape menu publishes its retry action")
	if retry == null:
		await _finish(level)
		return
	retry.grab_focus()
	await _frames(4)
	var hint := pause._root.get_node("FocusHintBar") as FocusHintBar
	_check(retry.text == "Restart area" and retry.tooltip_text == "No checkpoint yet.",
			"the pause action names the true fresh-area restart")
	_check(hint.text() == retry.tooltip_text, "focus and Hover show the same initial destination")
	await _picture("restart-area.png")
	Story.set_language("ja")
	await _frames(6)
	_check(retry.has_focus() and retry.text == "エリアの最初から再開" and hint.text() == retry.tooltip_text,
			"the same focused action displays the Japanese restart guidance")
	await _key(KEY_ESCAPE)
	Story.set_language("en")
	_check(not get_tree().paused and booth.can_dial(), "closing pause retains access to the untouched telephone")
	await _key(KEY_E)
	for frame in 360:
		if booth.activated and GameState.has_checkpoint and not booth.is_calling():
			break
		await _frames(1)
	_check(booth.activated and GameState.has_checkpoint and GameState.checkpoint_position.distance_to(booth.global_position) < 1.0,
			"actual telephone interaction records the first backup")
	await _key(KEY_ESCAPE)
	_check(retry == _retry_button(pause) and retry.text == "Retry checkpoint"
			and retry.tooltip_text == "Keep the weapons saved there.",
			"reopening the same button names the real checkpoint after backup")
	retry.grab_focus()
	await _frames(4)
	_check(retry.has_focus() and hint.text() == retry.tooltip_text, "real checkpoint guidance is also exposed when focusing")
	_check(hint.get_global_rect().end.x <= pause._info_panel.get_global_rect().position.x,
			"the checkpoint focus help stays clear of the other pause panel at 120 percent")
	await _picture("retry-checkpoint.png")
	var calls := [0]
	level.retry_requested.connect(func() -> void: calls[0] += 1)
	await _key(KEY_ENTER)
	_check(calls[0] == 1 and not pause._root.visible, "confirmation still exits pause and requests one retry from Level")
	await _finish(level)


func _retry_button(menu: PauseMenu) -> Button:
	var actions: Variant = menu.get("_actions")
	return actions.get("retry") as Button if actions is Dictionary else null


func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish(level: Level) -> void:
	if is_instance_valid(level._pause_menu) and level._pause_menu._root.visible:
		level._pause_menu.close()
	level.queue_free()
	await _frames(7)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))
