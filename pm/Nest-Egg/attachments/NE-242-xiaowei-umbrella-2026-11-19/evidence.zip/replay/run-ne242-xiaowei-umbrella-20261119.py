from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = root / 'work/ne242-xiaowei-umbrella-20261119'
out = base / sys.argv[1]
out.mkdir()
probe = base / 'probe.gd'
scene = base / 'probe.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n'
                 '[node name="XiaoweiUmbrella" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
command = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '1900',
           scene.as_posix(), '--', '--out=' + str(out), '--tag=' + sys.argv[1]]
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (out / 'raw.log').open('wb') as log:
    result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=150)
raw = (out / 'raw.log').read_text(encoding='utf-8')
print(raw[-5000:], flush=True)
report = json.loads((out / 'report.json').read_bytes())
summary = {area: {field: frame[field] for field in ('hits', 'kills', 'credit_value') if field in frame}
           for area, frame in report['records'].items()}
print(json.dumps(report, indent=2), flush=True)
assert result.returncode == report['failures'] == 0 and 'ERROR:' not in raw and '9070 XT' in report['adapter']

