extends ScenarioBase

const NPC_ID := &"ch2_xiaowei"
const PROP_ID := &"yong_hideout__xiaowei_chair_umbrella"

var _tag := ""
var _npc: NpcActor
var _actor: CutsceneActor
var _prop: PropNode
var _reaction: PropReaction
var _rows: Dictionary = {}


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
		elif argument.begins_with("--tag="):
			_tag = argument.trim_prefix("--tag=")
	if not out_dir.is_absolute_path() or _tag.is_empty():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	level = Level.new()
	level.configure(load("res://data/levels/ch2_ledger_office.tres") as LevelData)
	add_child(level)
	player = level.player
	level._next_story_trigger = level._layout.story_triggers.size()
	level.hud.visible = false
	for child in level.get_children():
		if child is ChapterCard:
			child.queue_free()
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		var npc := node as NpcActor
		if npc != null and npc.data.id == NPC_ID:
			_npc = npc
	for node in get_tree().get_nodes_in_group(PropNode.GROUP):
		var prop := node as PropNode
		if prop != null and prop.data.id == PROP_ID:
			_prop = prop
	if _prop != null:
		_reaction = _prop.get_node_or_null("Reaction_xiaowei_umbrella") as PropReaction
	if _npc == null:
		push_error("the authored office is missing Xiaowei")
		get_tree().quit(2)
		return
	_actor = _npc.get("_actor") as CutsceneActor
	_expect(_actor != null and _actor.rig != null and _actor.rig.skin_id == "xiaowei", "the original Xiaowei rig is active")
	var candidate := _tag != "before"
	_expect(_npc.is_present() and (_prop != null) == candidate, "the staged prop and actor have the intended visibility")
	if candidate:
		_expect(_reaction != null and not _reaction.is_swapped(), "the yellow umbrella stays beside the chair during the fight")
	player.global_position = _npc.global_position + Vector2(-39.0, 0.0)
	player.velocity = Vector2.ZERO
	level.camera.set_physics_process(false)
	level.camera.position_smoothing_enabled = false
	level.camera.global_position = _npc.global_position + Vector2(1.0, -34.0)
	level.camera.reset_smoothing()
	level.camera.force_update_scroll()
	get_viewport().warp_mouse(Vector2(150, 160))
	await settle(72)
	await _frame("authored")
	if _tag == "before":
		_expect(_npc.present_pose(&"sit"), "the existing NPC pose can be calibrated")
	for side: int in [-1, 1]:
		player.global_position = _npc.global_position + Vector2(side * 39.0, 0.0)
		await settle(68)
		_expect(_actor.facing == side, "seated Xiaowei turns toward the player")
		await _frame("sit-left" if side < 0 else "sit-right")
	_expect(_actor.pose == &"sit", "the existing seat pose is applied")
	if candidate:
		_expect(await _npc._talk(), "the original dispatch remains available")
		_expect(Story.was_seen(&"ch2_t_xiaowei_line") and _actor.pose == &"sit", "the authored line completes with the seated actor")
		await _frame("after-talk")
	GameState.set_flag(&"ch2_yong_subdued", true, false)
	await settle(54)
	_expect(not _npc.is_present(), "the child departs when the fight ends")
	_expect(not _npc.is_visible_in_tree(), "the departure fade completes")
	if _reaction != null:
		_expect(_reaction.is_swapped() and _reaction._swap_node.visible, "the empty chair remains after the umbrella departs")
	await _frame("cleared")
	if _tag.begins_with("revisit"):
		var office_data := level.data
		await finish()
		level = Level.new()
		level.configure(office_data)
		add_child(level)
		player = level.player
		for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
			var npc := node as NpcActor
			if npc != null and npc.data.id == NPC_ID:
				_npc = npc
		for node in get_tree().get_nodes_in_group(PropNode.GROUP):
			var prop := node as PropNode
			if prop != null and prop.data.id == PROP_ID:
				_prop = prop
				_reaction = prop.get_node_or_null("Reaction_xiaowei_umbrella") as PropReaction
		_expect(_reaction != null and _reaction.is_swapped() and _reaction._swap_node.visible,
			"re-entering the finished office immediately loads the empty chair")
		_expect(is_instance_valid(_npc) and not _npc.is_present(), "re-entering preserves Xiaowei's departure")
		_rows["re-entry"] = {"present": _npc.is_present(), "swapped": _reaction.is_swapped()}
	var size := get_window().size
	var report := {"tag": _tag, "records": _rows, "failures": failures, "size": [size.x, size.y],
		"adapter": RenderingServer.get_video_adapter_name()}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)


func _frame(name: String) -> void:
	await RenderingServer.frame_post_draw
	var points := {}
	var anchor := _npc.global_position
	for key: StringName in [&"hip", &"leg_front_lower", &"foot_front", &"foot_back", &"head", &"hand_front"]:
		if _actor.rig.has_bone(key):
			var point := _actor.rig.bone(key).global_position - anchor
			points[key] = [point.x, point.y]
	var screen := _npc.get_global_transform_with_canvas().origin
	var chair := []
	if _prop != null:
		var offset := _prop.global_position - anchor
		chair = [offset.x, offset.y, _prop.data.size.x, _prop.data.size.y]
	_rows[name] = {"pose": str(_actor.pose), "facing": _actor.facing, "present": _npc.is_present(), "points": points,
		"anchor": [screen.x, screen.y], "chair": chair, "swapped": _reaction != null and _reaction.is_swapped()}
	capture(name)


func _expect(condition: bool, description: String) -> void:
	if not condition:
		failures += 1
		push_error(description)
