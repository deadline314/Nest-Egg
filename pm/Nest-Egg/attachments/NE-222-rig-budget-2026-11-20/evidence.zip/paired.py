from pathlib import Path
import hashlib,json,os,re,subprocess,sys
from statistics import median
p=Path(__file__).resolve().parent
roots={'history':p.parent/'ne204-rig-budget-reference-20261120','current':p.parent/'ne218-baseline-20261117'}
godot=Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
scene='res://tools/rig_perf_probe.tscn'
source='tools/rig_perf_probe.gd'
sha=lambda item:hashlib.sha256(item.read_bytes()).hexdigest()
assert sha(roots['history']/source)==sha(roots['current']/source)
historical='4d8206e9c5adecdf3dbccf1664bc96b9ad8e9763'
head=lambda root:subprocess.check_output(['git','rev-parse','HEAD'],text=True,cwd=root).strip()
assert head(roots['history'])==historical
metadata={'tool_sha256':sha(roots['current']/source),'versions':{tag:head(root) for tag,root in roots.items()}}
def sample(tag, code):
    root=roots[tag]
    folder=p/code
    folder.mkdir()
    log=folder/'engine.log'
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
        (folder/key).mkdir()
        env[key]=str(folder/key)
    flags=['--headless','--audio-driver','Dummy','--path',str(root),scene,'--','--count=10','--frames=1800','--skin=rin']
    with log.open('wb') as fp:
        run=subprocess.run([str(godot),*flags],cwd=root,env=env,stdout=fp,stderr=subprocess.STDOUT,timeout=120)
    raw=log.read_text(encoding='utf-8')
    assert run.returncode==0 and not re.search('^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit',raw,re.M),str(log)
    match=re.search(r'剛體 ([\d.]+) µs/格，關節網格 ([\d.]+) µs/格.*每隻多 ([\d.]+) µs.*網格頂點 (\d+)',raw)
    assert match,raw
    rigid,mesh,per_actor,count=match.groups()
    return {'tag':tag,'code':code,'rigid_us':float(rigid),'joint_us':float(mesh),'extra_us_per_actor':float(per_actor),
            'vertices_per_actor':int(count),'command':[str(godot),*flags]}
warm=[sample(tag,tag+'-warm') for tag in roots]
pairs=[]
for group in range(6):
    tags=('history','current') if group%2==0 else ('current','history')
    rec=[sample(tag,f'{tag}-{group+1}') for tag in tags]
    costs={r['tag']:r['extra_us_per_actor'] for r in rec}
    pairs.append({'order':tags,'records':rec,'relative':costs['current']/costs['history']})
    print(group+1,costs,pairs[-1]['relative'],flush=True)
receipt={**metadata,'warmups':warm,'pairs':pairs,'median_ratio':median(row['relative'] for row in pairs),
         'max_ratio':max(row['relative'] for row in pairs)}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')

