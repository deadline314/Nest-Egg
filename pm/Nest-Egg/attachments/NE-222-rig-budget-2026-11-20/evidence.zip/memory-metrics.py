from pathlib import Path
from statistics import median
import json
p=Path(__file__).resolve().parent
for source in ['history-memory.log','current-memory.log','row-memory/engine.log','compact-memory/engine.log']:
    path=p/source
    if not path.is_file(): continue
    lines=path.read_text(encoding='utf-8-sig').splitlines()
    payload=next((line[len('RIG_MEMORY '):] for line in lines if line.startswith('RIG_MEMORY ')),None)
    if payload is None: continue
    records=json.loads(payload)
    differences=[]
    for target in range(6):
        sel={r['rigid']:r for r in records if r['pass']==target}
        differences.append(sel[False]['per_rig_bytes']-sel[True]['per_rig_bytes'])
    print(source,'bytes per rig',round(median(differences),2),'range',round(min(differences),2),round(max(differences),2))

