from pathlib import Path
import hashlib,json,os,re,subprocess
from statistics import median
p=Path(__file__).resolve().parent
root=p.parent/'ne218-baseline-20261117'
last=p.parent/'evidence-20261120-st19-bridge-feedback'
file='game/rig/rig_part_mesh.gd'
target=root/file
sha=lambda fp:hashlib.sha256(fp.read_bytes()).hexdigest()
pub=json.loads((last/'publish/result.json').read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True,cwd=root).strip()==pub['commit']
manifest=json.loads((last/'published-source.json').read_bytes())
assert all(sha(root/name)==digest for name,digest in manifest.items())
baseline=target.read_bytes()
candidate=(p/'row-compact.gd').read_bytes()
(p/'row-base.gd').write_bytes(baseline)
scenes={'geometry':str(p/'geometry.tscn'),'speed':'res://tools/rig_perf_probe.tscn','memory':str(p/'memory.tscn')}
godot=r'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def run(which,name,source):
    target.write_bytes(source)
    folder=p/name
    folder.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
        (folder/key).mkdir()
        env[key]=str(folder/key)
    opts={'geometry':['--bytes='+str(folder/'trajectory.dat')],'speed':['--count=10','--frames=1800','--skin=rin'],'memory':[]}
    cmd=[godot,'--headless','--audio-driver','Dummy','--path',str(root),scenes[which],'--',*opts[which]]
    with (folder/'engine.log').open('wb') as log:
        proc=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    raw=(folder/'engine.log').read_text(encoding='utf-8')
    assert proc.returncode==0 and not re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit',raw,re.M),raw[-2500:]
    if which=='speed':
        match=re.search(r'剛體 ([\d.]+) µs/格，關節網格 ([\d.]+) µs/格.*每隻多 ([\d.]+) µs.*網格頂點 (\d+)',raw)
        assert match,raw
        a,b,c,d=match.groups()
        return {'rigid_us':float(a),'mesh_us':float(b),'extra_us_per_actor':float(c),'vertices':int(d)}
    if which=='geometry':
        return sha(folder/'trajectory.dat')
    return json.loads(raw.split('RIG_MEMORY ')[1].splitlines()[0])

try:
    changed=run('geometry','compact-geometry',candidate)
    reference=sha(p/'reference-geometry.dat')
    print('geometry',changed,reference,flush=True)
    assert changed==reference
    memory=run('memory','compact-memory',candidate)
    results=[]
    warm={'old':run('speed','compact-old-warm',baseline),'new':run('speed','compact-new-warm',candidate)}
    for n in range(6):
        pair={}
        for tag,source in ([('old',baseline),('new',candidate)] if n%2==0 else [('new',candidate),('old',baseline)]):
            pair[tag]=run('speed',f'compact-{tag}-{n+1}',source)
        results.append(pair)
        print(n+1,pair,flush=True)
    diffs=[(r['new']['extra_us_per_actor']-r['old']['extra_us_per_actor']) for r in results]
    receipt={'mesh_data_equal':True,'sha256':reference,'before_sha256':hashlib.sha256(baseline).hexdigest(),
             'after_sha256':hashlib.sha256(candidate).hexdigest(),'warm':warm,'pairs':results,'changes_us':diffs,
             'median_change_us':median(diffs),'memory':memory}
    (p/'compact-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
finally:
    target.write_bytes(baseline)
    assert all(sha(root/name)==digest for name,digest in manifest.items())



