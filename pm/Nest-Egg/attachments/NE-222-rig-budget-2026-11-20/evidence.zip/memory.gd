extends Node

const COUNT := 20

func _ready() -> void:
	_run.call_deferred()

func _run() -> void:
	for rigid: bool in [true, false]:
		var sample := _create(rigid)
		for rig: CharacterRig in sample:
			rig.free()
		await get_tree().process_frame
	var measurements: Array[Dictionary] = []
	for pass_index in 6:
		for rigid: bool in ([true, false] if pass_index % 2 == 0 else [false, true]):
			var before := OS.get_static_memory_usage()
			var rigs := _create(rigid)
			var after := OS.get_static_memory_usage()
			var transforms := 0
			var vertices := 0
			var triangles := 0
			for mesh: RigPartMesh in rigs[0].limb_meshes():
				vertices += mesh.vertex_count()
				triangles += mesh.triangle_count()
				transforms += 1
			measurements.append({"pass":pass_index,"rigid":rigid,"armatures":COUNT,"memory_bytes":after-before,
				"per_rig_bytes":(after-before)/float(COUNT),"meshes_per_rig":transforms,"vertices_per_rig":vertices,
				"triangles_per_rig":triangles})
			for rig: CharacterRig in rigs:
				rig.free()
			await get_tree().process_frame
	print("RIG_MEMORY ", JSON.stringify(measurements))
	get_tree().quit(0)

func _create(rigid: bool) -> Array[CharacterRig]:
	CharacterRig.force_rigid_limbs = rigid
	var inputs: Array[CharacterRig] = []
	for i in COUNT:
		var rig := CharacterRig.new()
		add_child(rig)
		rig.setup("rin")
		rig.set_weapon("rifle")
		inputs.append(rig)
	CharacterRig.force_rigid_limbs = false
	return inputs

