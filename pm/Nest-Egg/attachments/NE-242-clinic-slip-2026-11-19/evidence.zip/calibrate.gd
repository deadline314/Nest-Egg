extends Node2D


func _ready() -> void:
	_calibrate.call_deferred()


func _calibrate() -> void:
	for kind: String in ["rin", "zhi"]:
		var rin := kind == "rin"
		var actor := CutsceneActor.new()
		add_child(actor)
		if not actor.setup(StringName(kind), kind, "", 2.14 if rin else 2.0, ""):
			get_tree().quit(2)
			return
		actor.face(1 if rin else -1)
		var ys := 302.0 if rin else 276.0
		actor.ground_y = ys
		actor.set_process(false)
		var points := PackedVector2Array([Vector2(463.5,205), Vector2(449,215)] if rin else [Vector2(490.64,196.3),Vector2(472.2,205)])
		var rig := actor.rig
		var contact := rig.hand_source_point(&"front", Vector2(96.5,37.5) if rin else Vector2(99.5,16.5))
		var shoulder := rig.bone(&"arm_front_upper")
		var elbow := rig.bone(&"arm_front_lower")
		var wrist := rig.bone(&"hand_front")
		var max_reach := rig.rest(&"arm_front_lower").length() + rig.rest(&"hand_front").length()
		var skeleton := rig._skeleton
		var options: Array[Dictionary] = []
		for x: float in ([430.,435.,440.,445.,450.] if rin else [480.,485.,490.,495.,500.]):
			actor.position = Vector2(x,ys)
			for angle: float in ([-0.8,-0.4,0.0,0.4,0.8] if rin else [2.34,2.74,PI,3.54,3.94]):
				var margin := INF
				var accepted := true
				var joints: Array = []
				for frame in 30:
					actor._process(1.0/60.0)
					for fraction: float in [0.,0.25,0.5,0.75,1.]:
						var target := points[0].lerp(points[1],fraction)
						var inverse := skeleton.global_transform.affine_inverse()
						var local_angle := inverse.basis_xform(Vector2.from_angle(angle)).angle()
						var target_length := (inverse * target - contact.rotated(local_angle)).distance_to(inverse * shoulder.global_position)
						margin = minf(margin,max_reach-target_length)
						if not rig.place_hand(&"front",target,angle,1.,contact):
							accepted = false
						if frame == 29 and (fraction == 0. or fraction == 1.):
							joints.append([str(shoulder.global_position),str(elbow.global_position),str(wrist.global_position)])
				if accepted:
					options.append({"x":x,"angle":angle,"margin":margin,"joints":joints})
		options.sort_custom(func(a: Dictionary,b: Dictionary)->bool: return a["margin"]>b["margin"])
		print("NE242_CLINIC_CALIBRATION ", JSON.stringify({"kind":kind,"contact":str(contact),"length":max_reach,"options":options}))
		actor.free()
	get_tree().quit()
