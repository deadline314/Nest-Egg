from pathlib import Path
import json
import os
import subprocess
import sys

root=Path.cwd()
base=root/'work/ne81-warden-neck-20261119'
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
original=(base/'natural-reference.gd').read_text(encoding='utf-8')
changes = {
'var held_aim := Vector2.INF': 'var held_aim := Vector2.INF\nvar armor_breaks: Array[Dictionary] = []\nvar kills: Array[String] = []',
'boss.health.damaged.connect(_on_boss_damage)': '''boss.health.damaged.connect(_on_boss_damage)
	boss.rig.armor_broken.connect(func(part: StringName) -> void:
		var event := {"part": String(part), "remaining": boss.rig._armor_visible, "hp": boss.health.current}
		armor_breaks.append(event)
		pending.append({"name": "armor_%d" % boss.rig._armor_visible, "event": event}))
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: kills.append(String(id)))
	lab.hide()
	panel.hide()''',
'if closed_hit or boss.health.is_dead or player.health.is_dead: break': 'if boss.health.is_dead or player.health.is_dead: break',
'_check(not boss.health.is_dead and not player.health.is_dead, "both actors remain alive for the bounded verification")':
'''_check(boss.health.is_dead and not player.health.is_dead and kills.count("warden") == 1, "ordinary pistol finishes the fight and records one Warden defeat")
	_check(armor_breaks.size() == boss.rig.armor_count() and boss.rig._armor_visible == 0, "each real armor group falls once as health drops")
	_check(hits.all(func(event: Dictionary) -> bool: return event["source"] == &"player_pistol"), "all Warden damage came from real pistol projectiles")
	if boss.health.is_dead:
		await settle(14)
		if is_instance_valid(boss):
			await RenderingServer.frame_post_draw
			capture("death")''',
'if stage in ["damage", "body"]: target': 'if stage in ["damage", "body", "defeat"]: target',
'var may_fire := stage in ["damage", "core", "body", "closed"]': 'var may_fire := stage in ["damage", "core", "body", "closed", "defeat"]',
'pending.append({"name": "closed_hit", "event": event})': 'pending.append({"name": "closed_hit", "event": event})\n\t\tstage = "defeat"',
'"captures": captured}': '"captures": captured, "armor_breaks": armor_breaks, "kills": kills}',
'await finish()\n\tawait AudioRelease.settle': 'AudioRelease.begin_shutdown()\n\tawait finish()\n\tawait AudioRelease.settle',
}
for old,new in changes.items():
    assert original.count(old)==1, old
    original=original.replace(old,new)
probe=base/'combat.gd'
probe.write_text(original,encoding='utf-8',newline='\n')
scene=base/'combat.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n'
                 '[node name="WardenCombat" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')
out=Path('D:/NestEggVerification/evidence-20261120-ne80-ne81/warden-release')/sys.argv[1]
out.mkdir()
side=sys.argv[2] if len(sys.argv)>2 else '1'
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(out/'profile'/key)
cmd=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
    '--path',str(shared),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
    '--resolution','1280x720','--fixed-fps','60','--quit-after','14500',scene.as_posix(),'--',
    f'--out={out.as_posix()}',f'--side={side}','--parse-mouse']
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
with (out/'raw.log').open('wb') as log:
    result=subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
raw=(out/'raw.log').read_text(encoding='utf-8')
print(raw[-3000:],flush=True)
report=json.loads((out/'report.json').read_bytes())
print('checks',len(report['checks']),'armor',report['armor_breaks'],'kills',report['kills'],flush=True)
assert result.returncode==0 and 'ERROR:' not in raw and '9070 XT' in raw and (out/'death.png').is_file()
