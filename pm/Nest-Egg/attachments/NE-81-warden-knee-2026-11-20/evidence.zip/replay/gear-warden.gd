extends Node

const POSES := ["idle", "run", "aim_up", "crouch", "jump", "block", "stagger", "dead"]
const STEP := 1.0 / 60.0

func _ready() -> void:
	_run.call_deferred()

func _run() -> void:
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	if not out.is_absolute_path():
		push_error("gear-contact requires --out=<absolute JSON path>")
		get_tree().quit(1)
		return
	var measurements: Array[Dictionary] = []
	var failures: Array[String] = []
	for pose: String in POSES:
		for facing: int in [1, -1]:
			var rig := CharacterRig.new()
			add_child(rig)
			if not rig.setup("warden"):
				get_tree().quit(1)
				return
			rig.set_weapon("minigun")
			var input := RigInput.new()
			input.facing = facing
			input.aim_dir = Vector2(facing, -1.0 if pose == "aim_up" else 0.0).normalized()
			input.on_floor = pose != "jump"
			input.velocity = Vector2(150.0 * facing, -200.0 if pose == "jump" else 0.0) if pose in ["run", "jump"] else Vector2.ZERO
			input.crouching = pose == "crouch"
			input.blocking = pose == "block"
			input.staggered = pose == "stagger"
			input.dead = pose == "dead"
			input.two_handed = true
			input.shield_forward = false
			var grip_max := 0.0
			var muzzle_max := 0.0
			var visible := 0
			var reversed := 0
			var weapon := rig.weapon_root()
			var sprite := weapon.get_child(0) as Sprite2D
			var definition := rig.weapon_def()
			var grip_tex := RigLibrary.vec2(definition["grip"])
			var muzzle_tex := RigLibrary.vec2(definition["muzzle"])
			for frame in 120:
				rig.animate(STEP, input)
				if not weapon.visible:
					continue
				visible += 1
				var grip := sprite.to_global(grip_tex + sprite.offset)
				var muzzle := rig.muzzle_global()
				grip_max = maxf(grip_max, grip.distance_to(rig.hand_contact_global(&"front")))
				muzzle_max = maxf(muzzle_max, muzzle.distance_to(sprite.to_global(muzzle_tex + sprite.offset)))
				reversed += int((muzzle.x - grip.x) * facing <= 0.0)
			var correct_visibility := visible == (0 if input.dead else 120)
			if not correct_visibility or grip_max > float(AnimAudit.LIMITS["grip_gap"]) or muzzle_max > 0.001 or reversed > 0:
				failures.append("%s %d has fitted gear regression" % [pose, facing])
			measurements.append({"pose": pose, "facing": facing, "max_grip_px": grip_max, "max_muzzle_px": muzzle_max, "facing_errors": reversed, "visible_frames": visible})
			remove_child(rig)
			rig.queue_free()
			await get_tree().process_frame
	var file := FileAccess.open(out, FileAccess.WRITE)
	if file == null:
		push_error("gear-contact cannot write " + out)
		get_tree().quit(1)
		return
	file.store_string(JSON.stringify({"poses": measurements, "failures": failures}, "	") + "
")
	file.close()
	print("GEAR ", measurements.size(), " pose/direction combinations, failures=", failures)
	get_tree().quit(0 if failures.is_empty() else 1)
