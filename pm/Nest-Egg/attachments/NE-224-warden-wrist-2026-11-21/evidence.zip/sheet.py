from pathlib import Path
from PIL import Image, ImageDraw
import json
base = Path(__file__).resolve().parent

panels=('wrist-trace','finish-wrist','bare-stock','finish-bare')
titles=('Before / armoured','With cuff overlap / armoured','Before / isolated','With cuff overlap / isolated')
sheet=Image.new('RGB',(440,510),(29,32,42))
draw=ImageDraw.Draw(sheet)
for index, (scope,label) in enumerate(zip(panels,titles,strict=True)):
    groups=json.loads((base/scope/'frames.json').read_bytes())
    j=next(g for g in groups if g['pose']=='idle' and g['zoom']==3.4)
    x,y,w,h=next(c['rect'] for c in j['cells'] if c['joint']=='wrist_front' and c['facing']==1)
    panel=Image.new('RGBA',(w,h),(98,101,117,255))
    with Image.open(base/scope/j['samples'][0]['file']) as frame:
        panel.alpha_composite(frame.crop((x,y,x+w,y+h)))
    ox,oy=12+index%2*220,12+index//2*250
    sheet.paste(panel.crop((37,38,93,98)).resize((196,210),Image.Resampling.NEAREST).convert('RGB'),(ox,oy+24))
    draw.text((ox,oy+2),label,fill='#f9fafc')
sheet.save(base/'wrist-comparison.png')


