from pathlib import Path
from hashlib import sha256
from PIL import Image, ImageChops
import json
import numpy as np
import re

base=Path(__file__).resolve().parent
root=Path.cwd()
sha=lambda path: sha256(path.read_bytes()).hexdigest()
def read(p): return json.loads((base/p).read_bytes())
def key(f): return tuple(f[k] for k in ('char','joint','pose','zoom','facing','frame'))
def hole(f): return f['center_alpha'] < 128 or f['enclosed_pixels'] or f['loose_pieces']

comparisons={}
expected={'dressed':((3510,3360),(1376,0)),'isolated':((240,0),(0,0))}
for name, before, after in (('dressed','wrist-trace','finish-wrist'),('isolated','bare-stock','finish-bare')):
    report=[read(f'{scope}/report.json') for scope in (before,after)]
    compare=lambda p: (p['failed_samples'],sum(bool(hole(f)) for f in p['failures']))
    assert all(r['samples']==7680 for r in report)
    counts=tuple(compare(r) for r in report)
    assert counts==expected[name], counts
    old_keys,new_keys=({key(f) for f in r['failures']} for r in report)
    new_notches=sorted(new_keys-old_keys)
    comparisons[name]={'before':counts[0],'after':counts[1],'samples':7680,'new_notches':new_notches}
assert not comparisons['dressed']['new_notches']

for name in ('finish-wrist','finish-bare','rest-finish','damage-finish','bake-v3','import-v3'):
    log=(base/(name+'.log')).read_text(encoding='utf-8')
    assert 'ERROR:' not in log, name
    if name.startswith('finish-'):
        assert log.count('frames=120')==16, name

relative_hand=Path('art/characters/warden/parts/hand.png')
relative_normal=relative_hand.with_name('hand_n.png')
backup=root/'art_src/characters/warden/wrist_overlap/hand-before.png'
recipe=root/'art_src/characters/warden/overrides/hand.png'
assert sha(root/relative_hand)==sha(recipe)==sha(base/'trial-v3-hand.png')
assert sha(root/relative_normal)==sha(base/'rebuilt-v3-normal.png')
assert sha(base/'cut-final/warden/parts/hand.png')==sha(backup)
assert (base/'cut-final/warden_rig.json').read_bytes() == (base/'cut-check/warden_rig.json').read_bytes()
old,new=(np.asarray(Image.open(p).convert('RGBA')) for p in (backup,recipe))
changed=np.any(old!=new,axis=2)
assert old.shape==new.shape==(234,216,4) and changed.sum()==1536
assert np.all(old[changed,3] < 235)
assert np.all(old[changed,3] < new[changed,3])
normal0,normal1=(np.asarray(Image.open(p).convert('RGBA')) for p in (base/'original-normal.png',root/relative_normal))
assert np.array_equal(new[:,:,3],normal1[:,:,3])
assert sha(base/'original-normal.png')==sha(base/'reference-normal.png')
result={'joint_reports':comparisons,
        'diffuse_updated':int(changed.sum()),
        'normals_updated':int(np.any(normal0!=normal1,axis=2).sum()),
        'hand_size':[216,234],
        'unchanged_cut_rig_sha256':sha(base/'cut-final/warden_rig.json'),
        'before':sha(backup),'diffuse':sha(recipe),'normal':sha(root/relative_normal)}
(base/'verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print({k:(v['before'],v['after'], len(v['new_notches'])) for k,v in comparisons.items()},
      'texture pixels',result['diffuse_updated'],result['normals_updated'])

