from pathlib import Path
from math import sin, pi
from PIL import Image
import numpy as np

scope=Path(__file__).resolve().parent
source=Path('art_src/characters/warden/wrist_overlap/hand-before.png')
image=np.asarray(Image.open(source).convert('RGBA'))
candidate=image.copy()
for y in range(124,207):
    width=round(23 * max(0.0,sin(pi*(y-124)/82))**0.45)
    for x in range(38,80):
        shifted=image[y,x+width]
        if shifted[3] > image[y,x,3] and image[y,x,3] < 235:
            candidate[y,x]=shifted
assert np.array_equal(candidate[image[:,:,3]==255],image[image[:,:,3]==255])
print('modified',int(np.any(candidate!=image,axis=2).sum()))
Image.fromarray(candidate).save(scope/'trial-v3-hand.png')




