from pathlib import Path
import hashlib, json, sys
import numpy as np
from PIL import Image

root = Path('C:/Users/stanl/Github/Nest-Egg')
epoch = root / 'work/st22-native-review-v1' / sys.argv[1]
rows = json.loads((epoch / 'captures/observations.json').read_bytes())
assert rows['expected'] == 6 and len(rows['records']) == 6
receipt = json.loads((epoch / 'receipt.json').read_bytes())
assert receipt['exit_code'] == 0 and receipt['source_unchanged'] and receipt['c_unchanged'] and not receipt['diagnostics']
assert receipt['source_count'] == 18963
assert json.loads((epoch / 'source-before.json').read_bytes()) == json.loads((epoch / 'source-after.json').read_bytes())
assert json.loads((epoch / 'c-before.json').read_bytes()) == json.loads((epoch / 'c-after.json').read_bytes())
for name in ('outer-queue-before', 'inner-queue-before', 'inner-queue-after', 'outer-queue-after'):
    queue = json.loads((epoch / (name + '.json')).read_bytes())
    assert len(queue) == 2 and {q['port'] for q in queue} == {8188,8189}
    assert all(q['state'] == 'empty' or (q['state'] == 'refused' and q['winerror'] == 10061) for q in queue)
report = []
for record in rows['records']:
    assert record['renderer'] == 'forward_plus' and record['hdr'] and record['raw_format'] == 14 and record['png_error'] == 0
    width, height = record['size']
    path = epoch / 'captures' / record['label']
    raw_path = path.with_suffix('.raw')
    png_path = path.with_suffix('.png')
    data = raw_path.read_bytes()
    assert len(data) == width * height * 6
    raw = np.frombuffer(data, dtype='<f2').reshape(height,width,3).astype(np.float32)
    assert np.isfinite(raw).all()
    srgb = np.clip(np.where(raw <= .0031308, raw * 12.92, 1.055 * np.maximum(raw,0) ** (1/2.4) - .055),0,1)
    png = np.asarray(Image.open(png_path).convert('RGBA'))
    assert png.shape == (height,width,4) and (png[:,:,3] == 255).all()
    error = float(np.max(np.abs(srgb - png[:,:,:3] / 255)))
    assert error <= 1/255 + 1e-5
    x,y,w,h = record['visible_rect']
    sx,sy,sw,sh = record['safe_rect']
    assert abs(record['amount'] - 1) < 1e-5 and x == y == 0 and abs(width/w-height/h) < 1e-6
    inset = max(0, (h-w/(21/9))/2)
    assert np.allclose([sx,sy,sw,sh], [0,inset,w,h-2*inset], atol=1e-4)
    # Actor bounds contain transparent padding: an outlier is diagnostic, not an opaque clipping claim.
    scale = width / w
    outside = []
    for actor in record['actors']:
        ax,ay,aw,ah = np.asarray(actor['bounds']) / scale
        if ax < sx or ay < sy or ax+aw > sx+sw or ay+ah > sy+sh:
            outside.append({'id': actor['id'], 'pose': actor['pose'], 'logical_bounds': [ax,ay,aw,ah]})
    assert len(record['actors']) >= 1
    report.append({'label':record['label'], 'level':record['level'], 'size':record['size'], 'maximum_srgb_error':error, 'conservative_actor_bounds_outside':outside, 'raw_sha256':hashlib.sha256(data).hexdigest(), 'png_sha256':hashlib.sha256(png_path.read_bytes()).hexdigest()})
out = epoch / 'independent-review.json'
assert not out.exists()
out.write_bytes((json.dumps({'scope':'Six controlled camera samples; conservative bounds and exact raw conversion, pending personal image review. No natural Main route, continuous animation, physical input or performance claim.', 'records':report},ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(report,ensure_ascii=False,indent=2))
