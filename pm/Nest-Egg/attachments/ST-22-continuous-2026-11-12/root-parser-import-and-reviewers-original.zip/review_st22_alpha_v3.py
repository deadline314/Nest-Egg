from pathlib import Path
import json, subprocess, sys
import numpy as np
from PIL import Image

root = Path('C:/Users/stanl/Github/Nest-Egg')
epoch = root/'work/st22-native-review-v1'/sys.argv[1]
subprocess.run([sys.executable,'-X','utf8',str(root/'work/review_st22_native_v1.py'),sys.argv[1]],cwd=root,check=True,stdout=subprocess.DEVNULL)
observations = json.loads((epoch/'captures/observations.json').read_bytes())
reports = []
for row in observations['records']:
    mask = row['head_alpha']
    assert 'error' not in mask and mask['format'] == 15 and mask['size'] == row['size'] and mask['png_error'] == 0
    assert mask['drawables'] and all(d['copy_transform_equal'] for d in mask['drawables'])
    width,height = mask['size']
    stem = epoch/'captures'/row['label']
    data = (stem.parent/(stem.name+'-head-alpha.raw')).read_bytes()
    assert len(data) == width*height*8
    alpha = np.frombuffer(data,dtype='<f2').reshape(height,width,4)[:,:,3].astype(np.float32)
    assert np.isfinite(alpha).all() and (alpha >= 0).all() and (alpha <= 1).all()
    png = np.asarray(Image.open(stem.parent/(stem.name+'-head-alpha.png')).convert('RGBA'))
    assert float(np.max(np.abs(alpha - png[:,:,3]/255))) <= 1/255+1e-5
    sx,sy,sw,sh = row['safe_rect']
    _,_,logical_width,logical_height = row['visible_rect']
    xx,yy = np.meshgrid(np.arange(width)+.5,np.arange(height)+.5)
    inside = (xx >= sx*width/logical_width) & (xx < (sx+sw)*width/logical_width) & (yy >= sy*height/logical_height) & (yy < (sy+sh)*height/logical_height)
    opaque = alpha >= .999
    any_alpha = alpha > 0
    assert int(opaque.sum()) >= 200
    report = {'label':row['label'],'opaque_head_pixels':int(opaque.sum()),'opaque_outside_safe':int((opaque & ~inside).sum()),'any_alpha_outside_safe':int((any_alpha & ~inside).sum()),'first_opaque_row':int(np.flatnonzero(opaque.any(axis=1))[0]),'safe_top_raw':sy*height/logical_height,'drawables':len(mask['drawables'])}
    reports.append(report)
result = {'scope':'Independent same-frame copied head alpha, preserving source sway shader uniforms and transforms. Background/glow is excluded; any nonzero actual drawable alpha outside the geometric safe rect is reported, without raising the original margin.', 'records':reports, 'all_heads_inside':all(r['any_alpha_outside_safe'] == 0 for r in reports)}
path=epoch/'alpha-review.json'
assert not path.exists()
path.write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(result,indent=2))
sys.exit(0 if result['all_heads_inside'] else 1)
