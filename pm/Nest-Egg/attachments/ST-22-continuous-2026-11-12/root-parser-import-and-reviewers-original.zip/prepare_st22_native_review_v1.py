from pathlib import Path
import hashlib, json, subprocess

root = Path('C:/Users/stanl/Github/Nest-Egg')
tree = Path('D:/NestEggVerification/st22-native-review-20261112')
out = tree / 'work/st22-native-review-v1'
out.mkdir(parents=True, exist_ok=True)
assert not any(out.iterdir())
source = (tree / 'tools/cinematic_safe_area_capture.gd').read_text(encoding='utf-8')
source = source.replace('var _out := ""', '''var _out := ""
var _records: Array[Dictionary] = []
var _expected := 0
const REVIEW_LEVELS := {
    &"ch1_p01_door": "res://data/levels/ch1_prologue.tres",
    &"ch1_c14_home": "res://data/levels/ch1_pawnshop_dawn.tres",
    &"ch1_c09_wake": "res://data/levels/ch1_warehouse.tres",
}''')
source = source.replace('\tDirAccess.make_dir_recursive_absolute(_out)', '''	if "--parser-only" in OS.get_cmdline_user_args():
		print("ST22 parser loaded actual autoloads")
		get_tree().quit()
		return
	if "--wide" in OS.get_cmdline_user_args():
		get_window().content_scale_size = Vector2i(840, 360)
		get_window().content_scale_aspect = Window.CONTENT_SCALE_ASPECT_EXPAND
	DirAccess.make_dir_recursive_absolute(_out)''')
old = '''	var level := Level.new()
	level.configure(load(level_path))
	get_tree().root.add_child(level)
	await _frames(60)
	Story.reset_active_presentation(&"route")'''
assert source.count(old) == 1
source = source.replace(old, '\tvar level: Level')
source = source.replace('\tfor id: StringName in shots:\n\t\t_prepare(id)', '''	for id: StringName in shots:
		if is_instance_valid(level):
			level.queue_free()
			await _frames(6)
		level = Level.new()
		level.configure(load(REVIEW_LEVELS[id]))
		get_tree().root.add_child(level)
		await _frames(60)
		Story.reset_active_presentation(&"route")
		_expected += shots[id].size()
		_prepare(id)''')
old = '''					var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
					print("saved %s (%s)" % [name, error_string(image.save_png(_out.path_join(name + ".png")))])'''
assert source.count(old) == 1
source = source.replace(old, '\t\t\t\t\tawait _capture(name, level)')
old = '\n\tget_tree().quit()\n'
assert source.count(old) == 1
source = source.replace(old, '''
	AudioRelease.begin_shutdown()
	Story.reset_active_presentation(&"route")
	if is_instance_valid(level):
		level.queue_free()
	await _frames(6)
	await AudioRelease.settle(get_tree())
	var file := FileAccess.open(_out.path_join("observations.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"expected": _expected, "records": _records}, "  "))
	file.close()
	get_tree().quit(0 if _records.size() == _expected and _expected == 6 else 1)
''')
source += '''

func _capture(label: String, level: Level) -> void:
	await RenderingServer.frame_post_draw
	var viewport := get_viewport()
	var raw := viewport.get_texture().get_image()
	var bytes := FileAccess.open(_out.path_join(label + ".raw"), FileAccess.WRITE)
	bytes.store_buffer(raw.get_data())
	bytes.close()
	var encoded := preload("res://tools/viewport_capture.gd").encode(raw, viewport.use_hdr_2d)
	var error := encoded.save_png(_out.path_join(label + ".png"))
	var actors: Array[Dictionary] = []
	for key: StringName in Story._player._actors:
		var actor: CutsceneActor = Story._player._actors[key]
		if actor.rig == null or not actor.is_visible_in_tree():
			continue
		var bounds := actor.rig.visual_bounds()
		var screen := actor.rig.get_viewport_transform() * bounds
		actors.append({"id": key, "pose": actor.pose, "bounds": _rect(screen)})
	_records.append({"label": label, "level": level.data.resource_path,
		"scene": Story._current_cinematic, "raw_format": raw.get_format(),
		"size": [raw.get_width(), raw.get_height()], "hdr": viewport.use_hdr_2d,
		"renderer": RenderingServer.get_current_rendering_method(),
		"visible_rect": _rect(viewport.get_visible_rect()),
		"safe_rect": _rect(Story.framing.safe_rect()), "amount": Story.framing.amount,
		"text": Story._player._dialogue._text.text, "actors": actors,
		"text_rect": _rect(Story._player._dialogue._text.get_global_rect()),
		"png_error": error})
	print("ST22 captured ", label, " actors=", actors.size())


func _rect(value: Rect2) -> Array:
	return [value.position.x, value.position.y, value.size.x, value.size.y]
'''
(out / 'capture.gd').write_bytes(source.encode('utf-8'))
(out / 'capture.tscn').write_bytes(b'[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://work/st22-native-review-v1/capture.gd" id="1"]\n\n[node name="St22NativeReview" type="Node"]\nscript = ExtResource("1")\n')
meta = {'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree).decode().strip(), 'original_capture_sha256': hashlib.sha256((tree / 'tools/cinematic_safe_area_capture.gd').read_bytes()).hexdigest(), 'scope': 'Controlled original three scene sampling with explicit progress fixture and original dialogue advancement; actual corresponding Level under each stage. Not natural Main trigger, campaign play, controller or performance acceptance.', 'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}}
(out / 'preparation.json').write_bytes((json.dumps(meta, indent=2) + '\n').encode())
print(json.dumps(meta, indent=2))
