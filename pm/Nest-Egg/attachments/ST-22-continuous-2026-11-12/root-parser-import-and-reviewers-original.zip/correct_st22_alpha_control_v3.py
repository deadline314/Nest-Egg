from pathlib import Path
import hashlib, json

p = Path('D:/NestEggVerification/st22-native-review-20261112/work/st22-native-review-v1/capture.gd')
before = p.read_bytes()
assert hashlib.sha256(before).hexdigest() == 'a44ac117f24e48370f2ae317a44d4474ec206423b35985112c83ac517445beb0'
s = before.decode()
s = s.replace('var transform := part.global_transform', 'var transform: Transform2D = part.get_global_transform()')
s = s.replace('\tvar alpha := await _head_alpha(label, raw.get_size())\n', '')
s = s.replace('\t_records.append({"label": label,', '''	var text: String = Story._player._dialogue._text.text
	var text_rect := Story._player._dialogue._text.get_global_rect()
	var safe_rect := Story.framing.safe_rect()
	var alpha := await _head_alpha(label, raw.get_size())
	_records.append({"label": label,''')
s = s.replace('"safe_rect": _rect(Story.framing.safe_rect())', '"safe_rect": _rect(safe_rect)')
s = s.replace('"text": Story._player._dialogue._text.text, "actors": actors', '"text": text, "actors": actors')
s = s.replace('"text_rect": _rect(Story._player._dialogue._text.get_global_rect())', '"text_rect": _rect(text_rect)')
s = s.replace('if not is_equal_approx(part.self_modulate.a, 1.0) or (part.material', 'if part.use_parent_material or not is_equal_approx(part.self_modulate.a, 1.0) or (part.material')
s = s.replace('\t\tcopy.texture_repeat = part.texture_repeat\n', '''		copy.texture_repeat = part.texture_repeat
		var source_parent := part.get_parent()
		while source_parent is CanvasItem:
			if copy.texture_filter == CanvasItem.TEXTURE_FILTER_PARENT_NODE and source_parent.texture_filter != CanvasItem.TEXTURE_FILTER_PARENT_NODE:
				copy.texture_filter = source_parent.texture_filter
			if copy.texture_repeat == CanvasItem.TEXTURE_REPEAT_PARENT_NODE and source_parent.texture_repeat != CanvasItem.TEXTURE_REPEAT_PARENT_NODE:
				copy.texture_repeat = source_parent.texture_repeat
			source_parent = source_parent.get_parent()
''')
p.write_bytes(s.encode())
(p.parent/'alpha-v3-correction.json').write_bytes((json.dumps({'before_sha256': hashlib.sha256(before).hexdigest(), 'after_sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'correction':'Explicit CanvasItem transform return type fixes original parser error; freeze metadata before clone rendering; preserve inherited texture sampling and reject parent-material ambiguity. No native alpha-v2 epoch existed.'},indent=2)+'\n').encode())
print(hashlib.sha256(p.read_bytes()).hexdigest())
