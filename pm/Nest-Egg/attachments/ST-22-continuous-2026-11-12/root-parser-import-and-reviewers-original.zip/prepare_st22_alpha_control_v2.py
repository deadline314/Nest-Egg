from pathlib import Path
import hashlib, json

tree = Path('D:/NestEggVerification/st22-native-review-20261112')
p = tree / 'work/st22-native-review-v1/capture.gd'
before = p.read_bytes()
assert hashlib.sha256(before).hexdigest() == 'f1536e3518dbf875e366c2120c323e4f1153c3094696b38c6b9a1247b572c059'
source = before.decode('utf-8')
source = source.replace('await _frames(50)  # 鏡頭移動完', 'await _frames(50)\n\t\t\t\tawait get_tree().create_timer(1.0, true).timeout  # Observation settle only; no authored timing changes.')
source = source.replace('\tvar error := encoded.save_png(_out.path_join(label + ".png"))', '\tvar error := encoded.save_png(_out.path_join(label + ".png"))\n\tvar alpha := await _head_alpha(label, raw.get_size())')
source = source.replace('"png_error": error})', '"png_error": error, "head_alpha": alpha})')
source += '''

## Clone the frozen head drawables; the live actor, shader, pose and camera remain untouched.
func _head_alpha(label: String, size: Vector2i) -> Dictionary:
	var actor: CutsceneActor = Story._player._actors.get(&"rin")
	if actor == null or actor.rig == null:
		return {"error": "no actual Rin rig"}
	var view := SubViewport.new()
	view.size = size
	view.world_2d = World2D.new()
	view.transparent_bg = true
	view.use_hdr_2d = true
	view.disable_3d = true
	view.msaa_2d = get_viewport().msaa_2d
	view.snap_2d_transforms_to_pixel = get_viewport().snap_2d_transforms_to_pixel
	view.snap_2d_vertices_to_pixel = get_viewport().snap_2d_vertices_to_pixel
	view.canvas_item_default_texture_filter = get_viewport().canvas_item_default_texture_filter
	view.canvas_item_default_texture_repeat = get_viewport().canvas_item_default_texture_repeat
	view.render_target_update_mode = SubViewport.UPDATE_ONCE
	add_child(view)
	view.canvas_transform = actor.rig.get_viewport_transform()
	var originals: Array[Dictionary] = []
	for part: CanvasItem in actor.rig._parts:
		if not part.is_visible_in_tree() or not ["head", "hair", "ponytail", "bangs"].any(func(key: String) -> bool: return String(part.name).to_lower().contains(key)):
			continue
		if not (part is Sprite2D or part is Polygon2D) or (part is Polygon2D and part.get_bone_count() > 0):
			view.queue_free()
			return {"error": "unsupported GPU-skinned head drawable", "name": part.name}
		var ancestor: Node = part
		while ancestor is CanvasItem:
			if not is_equal_approx(ancestor.modulate.a, 1.0) or ancestor.clip_children != CanvasItem.CLIP_CHILDREN_DISABLED:
				view.queue_free()
				return {"error": "ancestor opacity or clipping requires another proof"}
			ancestor = ancestor.get_parent()
		if not is_equal_approx(part.self_modulate.a, 1.0) or (part.material != null and (not part.material is ShaderMaterial or part.material.shader != CharacterRig.LIGHT_SHADER)):
			view.queue_free()
			return {"error": "unsupported drawable alpha or shader"}
		var transform := part.global_transform
		var copy := part.duplicate(0) as Node2D
		for child in copy.get_children():
			copy.remove_child(child)
			child.free()
		copy.set_script(null)
		copy.process_mode = Node.PROCESS_MODE_DISABLED
		if part is RigPartMesh:
			(copy as Polygon2D).polygon = part.deformed_vertices()
		view.add_child(copy)
		copy.global_transform = transform
		copy.texture_filter = part.texture_filter
		copy.texture_repeat = part.texture_repeat
		var uniforms := {}
		for uniform in [&"sway_a", &"sway_a_shape", &"sway_b", &"sway_b_shape", &"sway_padding", &"sway_bounds"]:
			var value: Variant = part.get_instance_shader_parameter(uniform)
			if value != null:
				copy.set_instance_shader_parameter(uniform, value)
				uniforms[String(uniform)] = str(value)
		originals.append({"part": part.name, "class": part.get_class(), "texture": part.texture.resource_path,
			"source_transform": [transform.x.x,transform.x.y,transform.y.x,transform.y.y,transform.origin.x,transform.origin.y],
			"copy_transform_equal": copy.global_transform == transform, "uniforms": uniforms})
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var mask := view.get_texture().get_image()
	var file := FileAccess.open(_out.path_join(label + "-head-alpha.raw"), FileAccess.WRITE)
	file.store_buffer(mask.get_data())
	file.close()
	var format := mask.get_format()
	mask.convert(Image.FORMAT_RGBA8)
	var error := mask.save_png(_out.path_join(label + "-head-alpha.png"))
	view.queue_free()
	return {"format": format, "size": [size.x,size.y], "png_error": error,
		"drawables": originals, "scope": "frozen same-frame cloned head/hair drawables, including actual sway uniforms; no live-node mutation; alpha only"}
'''
p.write_bytes(source.encode())
receipt = {'previous_sha256':hashlib.sha256(before).hexdigest(), 'current_sha256':hashlib.sha256(p.read_bytes()).hexdigest(), 'reason':'Original conservative Rin bound at home second camera crossed the top safe edge; resolve transparent padding versus actual hair using copied original drawable alpha. Original raw, source and reviewer remain immutable.', 'original_v1_capture':'C:/Users/stanl/Github/Nest-Egg/work/st22-native-review-v1/native720-v1/capture.gd'}
(p.parent / 'alpha-v2-preparation.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt,indent=2))
