extends Node
## ST-22 安全區截圖：在真關卡裡播序章開場、第一章的診間醒來與回家過場，到指定台詞時截圖，確認演員的頭在 21:9 遮幅內。
## 只推進台詞、不改劇情；每段播完就結束。用法：
## godot --path . res://tools/cinematic_safe_area_capture.tscn -- --out=<絕對路徑資料夾>
## 其他章節的截圖工具繼承這支，覆寫 level_path、shots、story_file、shot_prefix 與 _prepare（例如 tools/ch3_office_capture.gd）。

const LEVEL := "res://data/levels/ch1_pawnshop_dawn.tres"
## 場景 id → 要截圖的台詞（含這句的畫面）。
const SHOTS := {
	&"ch1_p01_door": ["把門帶上喔，雨都跑進來了。"],
	&"ch1_c14_home": ["你已經回來了啊，我本來想留一壺。", "你什麼時候回來的？"],
	# 診間醒來最後接托盤的選擇，所以排在最後。
	&"ch1_c09_wake": ["歡迎回來。你死了十一分鐘。", "你的聲音跟電話亭很像。", "初次建檔免信用點費，之後復原照登記費扣，記憶也會磨損。"],
}

var _out := ""
var _records: Array[Dictionary] = []
var _expected := 0
const REVIEW_LEVELS := {
    &"ch1_p01_door": "res://data/levels/ch1_prologue.tres",
    &"ch1_c14_home": "res://data/levels/ch1_pawnshop_dawn.tres",
    &"ch1_c09_wake": "res://data/levels/ch1_warehouse.tres",
}
## 子類別可以覆寫：關卡、場景與台詞、譯文來源的劇本檔、截圖檔名前綴（場景 id 會去掉 id_prefix）。
var level_path := LEVEL
var shots: Dictionary = SHOTS
var story_file := "res://data/story/ch1_kasa.json"
var shot_prefix := "ST-22"
var id_prefix := "ch1_"


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if "--parser-only" in OS.get_cmdline_user_args():
		print("ST22 parser loaded actual autoloads")
		get_tree().quit()
		return
	if "--wide" in OS.get_cmdline_user_args():
		get_window().content_scale_size = Vector2i(840, 360)
		get_window().content_scale_aspect = Window.CONTENT_SCALE_ASPECT_EXPAND
	DirAccess.make_dir_recursive_absolute(_out)
	_run.call_deferred()


func _frames(n: int) -> void:
	for i in n:
		await get_tree().process_frame


## 中文台詞 → 目前劇本語言的同一句（直接讀劇本檔的 ja／en 欄位）。
func _translations() -> Dictionary:
	var result := {}
	if Story.language == StoryLocale.SOURCE_LANGUAGE:
		return result
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(story_file))
	var stack: Array = [data]
	while not stack.is_empty():
		var node: Variant = stack.pop_back()
		if node is Dictionary:
			if node.get("text") is String and node.has(Story.language):
				result[node["text"]] = node[Story.language]
			stack.append_array((node as Dictionary).values())
		elif node is Array:
			stack.append_array(node)
	return result


## 播某個場景之前的準備（子類別設定該場景成立需要的進度旗標）。
func _prepare(_id: StringName) -> void:
	pass


func _run() -> void:
	Story.auto_skip = false
	GameState.start_new_run(GameState.difficulties[1])
	for flag in [&"ch1_supper_done", &"ch1_handoff_done"]:
		GameState.set_flag(flag)
	var level: Level
	var translated := _translations()
	for id: StringName in shots:
		if is_instance_valid(level):
			level.queue_free()
			await _frames(6)
		level = Level.new()
		level.configure(load(REVIEW_LEVELS[id]))
		get_tree().root.add_child(level)
		await _frames(60)
		Story.reset_active_presentation(&"route")
		_expected += shots[id].size()
		_prepare(id)
		# 選了日文或英文（--story-language）時，要找的台詞換成同一句的譯文（ST-2）。
		var wanted: Array = shots[id].map(func(zh: String) -> String: return translated.get(zh, zh))
		var taken := 0
		if not Story.play(id, false):
			print("FAIL could not start %s" % id)
			continue
		for i in 300:
			if Story.is_cinematic_active() and Story._current_cinematic == id:
				break
			await _frames(1)
		for i in 6000:
			if not Story.is_cinematic_active() or taken >= wanted.size():
				break
			var player: CutscenePlayer = Story._player
			if player == null:
				await _frames(3)
				continue
			var text: String = player._dialogue._text.text
			var complete := player._dialogue.is_complete()
			if taken < wanted.size() and text == wanted[taken] and complete:
				await _frames(50)  # 鏡頭移動完
				var name := "%s-%s-%d%s" % [shot_prefix, String(id).trim_prefix(id_prefix), taken + 1, "" if Story.language == "zh" else "-" + Story.language]
				if DisplayServer.get_name() == "headless":
					print("reached %s" % name)
				else:
					await _capture(name, level)
				taken += 1
			if complete and (taken >= wanted.size() or text != wanted[taken]):
				player._advance_requested = true
			await _frames(3)
		print("%s shots %d/%d" % [id, taken, wanted.size()])
		if taken >= wanted.size() and Story.is_cinematic_active():
			Story.reset_active_presentation(&"route")
			await _frames(10)
	AudioRelease.begin_shutdown()
	Story.reset_active_presentation(&"route")
	if is_instance_valid(level):
		level.queue_free()
	await _frames(6)
	await AudioRelease.settle(get_tree())
	var file := FileAccess.open(_out.path_join("observations.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"expected": _expected, "records": _records}, "  "))
	file.close()
	get_tree().quit(0 if _records.size() == _expected and _expected == 6 else 1)


func _capture(label: String, level: Level) -> void:
	await RenderingServer.frame_post_draw
	var viewport := get_viewport()
	var raw := viewport.get_texture().get_image()
	var bytes := FileAccess.open(_out.path_join(label + ".raw"), FileAccess.WRITE)
	bytes.store_buffer(raw.get_data())
	bytes.close()
	var encoded := preload("res://tools/viewport_capture.gd").encode(raw, viewport.use_hdr_2d)
	var error := encoded.save_png(_out.path_join(label + ".png"))
	var actors: Array[Dictionary] = []
	for key: StringName in Story._player._actors:
		var actor: CutsceneActor = Story._player._actors[key]
		if actor.rig == null or not actor.is_visible_in_tree():
			continue
		var bounds := actor.rig.visual_bounds()
		var screen := actor.rig.get_viewport_transform() * bounds
		actors.append({"id": key, "pose": actor.pose, "bounds": _rect(screen)})
	_records.append({"label": label, "level": level.data.resource_path,
		"scene": Story._current_cinematic, "raw_format": raw.get_format(),
		"size": [raw.get_width(), raw.get_height()], "hdr": viewport.use_hdr_2d,
		"renderer": RenderingServer.get_current_rendering_method(),
		"visible_rect": _rect(viewport.get_visible_rect()),
		"safe_rect": _rect(Story.framing.safe_rect()), "amount": Story.framing.amount,
		"text": Story._player._dialogue._text.text, "actors": actors,
		"text_rect": _rect(Story._player._dialogue._text.get_global_rect()),
		"png_error": error})
	print("ST22 captured ", label, " actors=", actors.size())


func _rect(value: Rect2) -> Array:
	return [value.position.x, value.position.y, value.size.x, value.size.y]
