# ST-22 home2 連續頭部 alpha 觀察

只觀察真 `ch1_c14_home` 的「你什麼時候回來的？」首次顯示起的自然 idle／聆聽／手勢短段。沿Root原關卡、進度fixture與台詞推進，第一個指定home台詞只保留原50process等待，不加新版工具的1s；目標句不提前推進。記首次complete publication＋50process的觀測標記，至少再涵actor自然時間3.2s且NpcAnimator實際breath_phase跨度至少TAU。3.2是最低觀察長度，不把portrait fallback的BREATH_PERIOD誤當所有NpcAnimator固定週期。

不設定 actor pose、phase、global transform、physics、camera、live material、time_scale或動畫時間。Engine.max_fps=60只限制觀察擷取率，實際process／physics／actor_t／phase每格留存；這是受控路由，不是自然Main通關、人工操作或效能。

原v1 home2的conservative body top41.601654相對safe42.857143沒有同draw alpha。新的連續觀察即使相近幾何alpha全在內，也不能倒填舊frame為透明padding，更不能以新增1s settled圖覆蓋真剪切。

## 同draw與ROI

三個真head/hair Sprite2D做副本，保實際texture／flip／region／affine與CharacterRig實例shaderuniform數值。只接受既有實際材質、祖先alpha1且無clip；新drawable類型／不支援alpha語義直接拒收。原shader沒有TIME依賴，但仍每pre_draw同步當格uniform與transform；post_draw核同publication。

primary SubViewport預暖時不讀ROI，到目標句首pre_draw才依完整drawable quad含shader padding、每側32physical px觀察餘裕配置，凍結整個ROI矩形。之後不追crop、不自動擴大；canvas只減同一整數physical pixel origin，不resize。後續幾何超出或任何非零alpha碰ROI邊界即拒收；會保拒收當格bounds／ROI與真正post-draw全圖。原RGBAH15全部bytes保存，alpha>0在safe外即紅；opaque>=.999至少200像素以拒空遮罩，不把半透明當opaque。safe由真正final transform映射，依pixel center比較原邊界。32只增觀察區，不改產品／safe門檻。

第二個全幅reference view同步同三副本，為了在post_draw才發現新極值時仍能比較同draw，它持續render但只在首格／更新最窄格readback；最後只保存首與最窄reference。primary仍只讀小ROI。要求reference裁切對ROI的alpha16逐byte全零誤差，不接受浮點noise容差。

完整主viewport只有首、更新最窄／worst及真正最後draw取原image，RAM只保各類最後極值，結束才存原raw與精確sRGB PNG；不逐frame存全幅9MB，不重組ROI冒充全畫面。

## 控制與來源

CPU11已知答案涵fractional safe邊界、極淡half-alpha越界、錯位ROI、空mask、ROI邊觸、NaN／Inf／負值／超範圍、.999 half cutoff及已知1:1 affine。native仍必須真正跑同draw reference A/A，CPU綠不代稱原生。

新leaf為 `D:/NestEggVerification/st22-native-review-20261112/work/st22-continuous-head-v1/`；Root capture／runner只讀，tracked產品d20不變。wrapper每epoch保D原tracked與Root舊leaf、新leaf來源前後SHA，另守C397v24。五個user環境隔離，原主鎖非阻塞與兩port內外前後真空／真10061規則不變。此階段只準備／parser，native待Root明示START。
