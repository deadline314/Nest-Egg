extends Node
## Dynamic load keeps this parser entry alive even when the target has syntax errors.
func _ready() -> void:
	var script := load("res://work/st22-continuous-head-v1/capture.gd") as GDScript
	var good: bool=script!=null and script.can_instantiate()
	print("ST22_CONTINUOUS_PARSE ",good)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if good else 1)
