from pathlib import Path
import hashlib, json, msvcrt, os, re, subprocess, sys, time, urllib.error, urllib.request

root = Path('C:/Users/stanl/Github/Nest-Egg')
tree = Path('D:/NestEggVerification/st22-native-review-20261112')
out = root/'work/st22-continuous-head-v1'/sys.argv[1]
out.parent.mkdir(exist_ok=True)
out.mkdir(exist_ok=False)
parser = sys.argv[1].startswith(('parser', 'import'))
editor = sys.argv[1].startswith('import')
def save(name, value):
    (out/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file,'sha256').hexdigest()
def snapshot():
    names = subprocess.check_output(['git','ls-files','-z'],cwd=tree).decode('utf8').split('\0')
    names += ['work/st22-native-review-v1/capture.gd','work/st22-native-review-v1/capture.tscn','work/st22-continuous-head-v1/capture.gd','work/st22-continuous-head-v1/capture.tscn']
    return {n:sha(tree/n) for n in sorted(set(names)) if n and (n=='project.godot' or Path(n).suffix in {'.gd','.tscn','.tres','.json','.png','.svg','.ogg','.ttf','.otf','.gdshader'})}
def queues():
    rows = []
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for port in (8188,8189):
        try:
            with opener.open(f'http://127.0.0.1:{port}/queue',timeout=3) as response:
                raw=response.read()
            value=json.loads(raw)
            assert isinstance(value['queue_running'],list) and isinstance(value['queue_pending'],list)
            rows.append(dict(port=port,state='empty' if not value['queue_running'] and not value['queue_pending'] else 'busy',running=len(value['queue_running']),pending=len(value['queue_pending']),response_sha256=hashlib.sha256(raw).hexdigest()))
        except urllib.error.URLError as error:
            code=getattr(error.reason,'winerror',None)
            rows.append(dict(port=port,state='refused' if code==10061 else 'unknown',winerror=code))
    return rows
def clear(rows):
    return all(row['state'] in ('empty','refused') for row in rows)
if not parser:
    rows=queues();save('outer-queue-before.json',rows)
    if not clear(rows):
        save('blocked.json',dict(reason='busy or unknown queue; no lock and no engine'))
        print('BLOCKED: busy or unknown queue; no engine',flush=True)
        sys.exit(3)
before=snapshot();save('source-before.json',before)
cguard=json.loads((root/'work/ne264-product-adoption-v1/c-native-context-v24.json').read_bytes())['files']
assert len(cguard)==397 and all(sha(root/n)==wanted for n,wanted in cguard.items())
save('c-before.json',cguard)
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','USERPROFILE','HOME','XDG_DATA_HOME'):
    env[key]=str(out/'userdata')
argv=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(tree)]
argv += ['--headless'] if parser else ['--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan']
argv += ['--editor','--quit'] if editor else ['res://work/st22-continuous-head-v1/capture.tscn','--','--parser-only' if parser else '--out='+str(out/'captures')]
if 'wide' in sys.argv[1]:
    argv[argv.index('1280x720')]='1680x720'
    argv.append('--wide')
save('command.json',dict(argv=argv,cwd=str(tree),env={k:env[k] for k in ('APPDATA','LOCALAPPDATA','USERPROFILE','HOME','XDG_DATA_HOME')},source_count=len(before),scope='Actual autoload parser only; no rendering acceptance' if parser else 'New home2 continuous first-target-draw and original50+3.2s/actual breath cycle; live authored pose/camera/physics unchanged; cap60 observation only, no natural Main route/physical input/performance claim'))
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
for n in ('capture.gd','capture.tscn'):
    (out/n).write_bytes((tree/'work/st22-continuous-head-v1'/n).read_bytes())
lock=None
held=False
try:
    if not parser:
        sys.path.insert(0,str(root/'tools/comfyui'))
        import comfy_guard
        assert comfy_guard.LOCK_PATH == root/'assets_src/work/comfy.lock'
        lock=open(comfy_guard.LOCK_PATH,'a+b');lock.seek(0)
        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        held=True
        rows=queues();save('inner-queue-before.json',rows)
        assert clear(rows),'queue changed; no engine started'
    start=time.monotonic()
    with (out/'engine.log').open('wb') as log:
        result=subprocess.run(argv,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240 if editor else 150)
    if not parser:
        rows=queues();save('inner-queue-after.json',rows)
        assert clear(rows),'queue became busy during capture'
finally:
    if lock is not None:
        lock.seek(0)
        try:
            if held: msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
        finally: lock.close()
after=snapshot();save('source-after.json',after)
save('c-after.json',{n:sha(root/n) for n in cguard})
raw=(out/'engine.log').read_text(encoding='utf8')
receipt=dict(exit_code=result.returncode,seconds=time.monotonic()-start,source_count=len(before),source_unchanged=before==after,c_unchanged=all(sha(root/n)==wanted for n,wanted in cguard.items()),diagnostics=[line for line in raw.splitlines() if re.search(r'ERROR:|SCRIPT ERROR|WARNING:|ObjectDB.*leak|RID allocations.*leaked|resources still in use at exit',line)])
save('receipt.json',receipt);print(json.dumps(receipt,indent=2),flush=True)
assert result.returncode==0 and before==after and receipt['c_unchanged'] and not receipt['diagnostics']

if not parser:
    rows = queues(); save('outer-queue-after.json', rows)
    assert clear(rows), 'external queue after release is busy or unknown'
