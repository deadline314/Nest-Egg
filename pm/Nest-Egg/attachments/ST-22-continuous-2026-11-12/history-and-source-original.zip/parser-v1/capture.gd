extends Node
## Read-only continuous alpha observer for the authored home second camera.
const Capture := preload("res://tools/viewport_capture.gd")
const SCENE := &"ch1_c14_home"
const FIRST := "你已經回來了啊，我本來想留一壺。"
const TARGET := "你什麼時候回來的？"
const UNIFORMS := [&"sway_a", &"sway_a_shape", &"sway_b", &"sway_b_shape", &"sway_padding", &"sway_bounds"]
var out := ""
var level: Level
var actor: CutsceneActor
var sources: Array[Sprite2D] = []
var copies: Array[Sprite2D] = []
var reference_copies: Array[Sprite2D] = []
var view: SubViewport
var reference: SubViewport
var roi_size := Vector2i.ZERO
var rows: Array[Dictionary] = []
var masks: Array[Image] = []
var full: Dictionary = {}
var reference_samples: Dictionary = {}
var textures: Dictionary = {}
var texture_rows: Array = []
var issues: Array[String] = []
var enabled := false
var active := false
var done := false
var pending: Dictionary = {}
var complete_process := -1
var marker := -1
var marker_t := 0.0
var marker_breath := 0.0
var narrowest := INF
var worst := -1

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): out=arg.trim_prefix("--out=")
	if "--parser-only" in OS.get_cmdline_user_args():
		await AudioRelease.settle(get_tree())
		get_tree().quit()
		return
	if DisplayServer.get_name()=="headless" or RenderingServer.get_current_rendering_method()!="forward_plus":
		get_tree().quit(2)
		return
	Engine.max_fps=60 # Observation cap only; physics and time_scale are untouched.
	RenderingServer.frame_pre_draw.connect(_pre_draw)
	RenderingServer.frame_post_draw.connect(_post_draw)
	_run.call_deferred()

func _frames(n: int) -> void:
	for i in n: await get_tree().process_frame

func _fail(message: String) -> void:
	if not issues.has(message): issues.append(message)
	done=true

func _rect(value: Rect2) -> Array: return [value.position.x,value.position.y,value.size.x,value.size.y]
func _xf(value: Transform2D) -> Array: return [value.x.x,value.x.y,value.y.x,value.y.y,value.origin.x,value.origin.y]
func _number(value: Variant) -> Variant:
	if value is Vector2: return [value.x,value.y]
	if value is Vector4: return [value.x,value.y,value.z,value.w]
	return value

func _make_view(size: Vector2i) -> SubViewport:
	var result := SubViewport.new()
	result.size=size
	result.world_2d=World2D.new()
	result.transparent_bg=true
	result.use_hdr_2d=true
	result.disable_3d=true
	result.msaa_2d=get_viewport().msaa_2d
	result.snap_2d_transforms_to_pixel=get_viewport().snap_2d_transforms_to_pixel
	result.snap_2d_vertices_to_pixel=get_viewport().snap_2d_vertices_to_pixel
	result.canvas_item_default_texture_filter=get_viewport().canvas_item_default_texture_filter
	result.canvas_item_default_texture_repeat=get_viewport().canvas_item_default_texture_repeat
	result.render_target_update_mode=SubViewport.UPDATE_ALWAYS
	add_child(result)
	return result

func _copy(part: Sprite2D, target: SubViewport) -> Sprite2D:
	var clone := part.duplicate(0) as Sprite2D
	for child in clone.get_children():
		clone.remove_child(child)
		child.free()
	clone.set_script(null)
	clone.process_mode=Node.PROCESS_MODE_DISABLED
	target.add_child(clone)
	return clone

func _prepare_heads() -> bool:
	for candidate: CanvasItem in actor.rig._parts:
		if not candidate.is_visible_in_tree() or not ["head","hair","ponytail","bangs"].any(func(key: String)->bool:return String(candidate.name).to_lower().contains(key)): continue
		if not candidate is Sprite2D:
			_fail("home2 observer supports the three actual Sprite2D heads only; drawable type changed")
			return false
		sources.append(candidate as Sprite2D)
	if sources.size()!=3:
		_fail("actual home2 visible head/hair coverage is not exactly three drawables")
		return false
	var bounds := Rect2()
	for i in sources.size():
		var bound := actor.rig.get_viewport_transform()*sources[i].global_transform*sources[i].get_rect().grow(24.0)
		bounds=bound if i==0 else bounds.merge(bound)
	roi_size=Vector2i(ceili(bounds.size.x)+16,ceili(bounds.size.y)+16)
	view=_make_view(roi_size)
	# The reference is rendered in parallel so a newly-discovered alpha extremum
	# can be checked in that same draw; readback/storage happens only at selected draws.
	reference=_make_view(Vector2i(get_viewport().get_texture().get_size()))
	for part in sources:
		copies.append(_copy(part,view))
		reference_copies.append(_copy(part,reference))
	return true

func _pre_draw() -> void:
	if not enabled or done or not Story.is_cinematic_active() or Story._current_cinematic!=SCENE: return
	var player: CutscenePlayer=Story._player
	if player==null: return
	var live: CutsceneActor=player._actors.get(&"rin")
	if live==null or live.rig==null: return
	if actor==null:
		actor=live
		if not _prepare_heads(): return
	elif actor!=live:
		_fail("live actor instance changed during continuous observation")
		return
	var world_to_pixels := actor.rig.get_viewport_transform()
	var bounds := Rect2()
	var parts: Array = []
	for i in sources.size():
		var source := sources[i]
		if not is_instance_valid(source) or source.texture==null or not source.is_visible_in_tree():
			_fail("head drawable disappeared or lost its actual texture")
			return
		var parent: Node=source
		while parent is CanvasItem:
			if not is_equal_approx(parent.modulate.a,1.0) or parent.clip_children!=CanvasItem.CLIP_CHILDREN_DISABLED:
				_fail("ancestor opacity/clipping needs a separate proof")
				return
			parent=parent.get_parent()
		if source.use_parent_material or source.self_modulate.a!=1.0 or source.material!=null and (not source.material is ShaderMaterial or source.material.shader!=CharacterRig.LIGHT_SHADER):
			_fail("unsupported actual drawable alpha/material")
			return
		var uniforms := {}
		for clone in [copies[i],reference_copies[i]]:
			clone.global_transform=source.global_transform
			clone.texture=source.texture
			clone.material=source.material
			clone.modulate=source.modulate
			clone.self_modulate=source.self_modulate
			clone.flip_h=source.flip_h
			clone.flip_v=source.flip_v
			clone.centered=source.centered
			clone.offset=source.offset
			clone.hframes=source.hframes
			clone.vframes=source.vframes
			clone.frame=source.frame
			clone.region_enabled=source.region_enabled
			clone.region_rect=source.region_rect
			clone.texture_filter=source.texture_filter
			clone.texture_repeat=source.texture_repeat
			var ancestor := source.get_parent()
			while ancestor is CanvasItem:
				if clone.texture_filter==CanvasItem.TEXTURE_FILTER_PARENT_NODE and ancestor.texture_filter!=CanvasItem.TEXTURE_FILTER_PARENT_NODE: clone.texture_filter=ancestor.texture_filter
				if clone.texture_repeat==CanvasItem.TEXTURE_REPEAT_PARENT_NODE and ancestor.texture_repeat!=CanvasItem.TEXTURE_REPEAT_PARENT_NODE: clone.texture_repeat=ancestor.texture_repeat
				ancestor=ancestor.get_parent()
			for uniform in UNIFORMS:
				var value: Variant=source.get_instance_shader_parameter(uniform)
				if value!=null: clone.set_instance_shader_parameter(uniform,value)
				uniforms[String(uniform)]=_number(value)
		var key := str(source.texture.get_instance_id())
		textures[key]=source.texture
		var projected := world_to_pixels*source.global_transform*source.get_rect().grow(24.0)
		bounds=projected if i==0 else bounds.merge(projected)
		parts.append({"name":source.name,"instance":source.get_instance_id(),"texture_key":key,"sprite_rect":_rect(source.get_rect()),"global_transform":_xf(source.global_transform),"pixel_transform":_xf(world_to_pixels*source.global_transform),"copy_transform_equal":copies[i].global_transform==source.global_transform and reference_copies[i].global_transform==source.global_transform,"uniforms":uniforms,"z":source.z_index,"z_relative":source.z_as_relative})
	var origin := Vector2i(floori(bounds.get_center().x-float(roi_size.x)*0.5),floori(bounds.get_center().y-float(roi_size.y)*0.5))
	var roi := Rect2i(origin,roi_size)
	if not Rect2(roi).encloses(bounds.grow(2.0)):
		_fail("fixed ROI no longer contains the conservative full head drawable envelope")
		return
	view.canvas_transform=Transform2D(0,-Vector2(origin))*world_to_pixels
	reference.canvas_transform=world_to_pixels
	var text := player._dialogue._text.text
	if text!=TARGET: return
	if not active: active=true
	if player._dialogue.is_complete() and complete_process<0: complete_process=Engine.get_process_frames()
	var final := get_viewport().get_final_transform()
	var safe := final*Story.framing.safe_rect()
	var animator := actor.rig.animator as NpcAnimator
	if animator==null:
		_fail("actual home2 Rin animator is not the expected NpcAnimator")
		return
	pending={"sample":rows.size(),"process_pre":Engine.get_process_frames(),"physics_pre":Engine.get_physics_frames(),"usec_pre":Time.get_ticks_usec(),"actor_t":actor._t,"breath_phase":animator._breath_phase,"pose":actor.pose,"talk_weight":animator._w_talk,"listen_weight":animator._w_listen,"text":text,"complete":player._dialogue.is_complete(),"original_complete_process":complete_process,"roi":[origin.x,origin.y,roi_size.x,roi_size.y],"safe_pixels":_rect(safe),"safe_logical":_rect(Story.framing.safe_rect()),"final_transform":_xf(final),"world_to_pixels":_xf(world_to_pixels),"roi_canvas":_xf(view.canvas_transform),"body_pixels":_rect(world_to_pixels*actor.rig.visual_bounds()),"parts":parts,"time_scale":Engine.time_scale,"paused":get_tree().paused,"actual_max_fps":Engine.max_fps,"actor_processing":actor.is_processing(),"actor_can_process":actor.can_process(),"actor_visible":actor.is_visible_in_tree(),"live_material_mutated":false}

func _post_draw() -> void:
	if pending.is_empty() or done: return
	var row := pending
	pending={}
	row["process_post"]=Engine.get_process_frames()
	row["physics_post"]=Engine.get_physics_frames()
	row["usec_post"]=Time.get_ticks_usec()
	if row.process_pre!=row.process_post or row.physics_pre!=row.physics_post or actor._t!=float(row.actor_t):
		_fail("source publication advanced between pre/post draw")
		return
	var mask := view.get_texture().get_image()
	if mask.get_format()!=Image.FORMAT_RGBAH or mask.get_size()!=roi_size:
		_fail("unexpected original alpha format or ROI size")
		return
	# Preserve the actual failing draw too; do not lose a mask merely because
	# its emptiness/border/reference control is rejected later in this function.
	rows.append(row)
	masks.append(mask)
	var data := mask.get_data()
	var safe: Array=row.safe_pixels
	var roi: Array=row.roi
	var opaque := 0
	var outside := 0
	var border := 0
	var top := INF
	var margin := INF
	for y in roi_size.y:
		for x in roi_size.x:
			var offset := (y*roi_size.x+x)*8+6
			var bits := int(data[offset]) | int(data[offset+1])<<8
			if bits>0x3c00:
				_fail("nonfinite/negative/out-of-range original alpha")
				return
			if bits==0: continue
			if bits>=0x3bfe: opaque+=1
			var px := float(roi[0]+x)+0.5
			var py := float(roi[1]+y)+0.5
			top=minf(top,py)
			margin=minf(margin,minf(minf(px-safe[0],safe[0]+safe[2]-px),minf(py-safe[1],safe[1]+safe[3]-py)))
			if px<safe[0] or px>=safe[0]+safe[2] or py<safe[1] or py>=safe[1]+safe[3]: outside+=1
			if x==0 or y==0 or x==roi_size.x-1 or y==roi_size.y-1: border+=1
	row["opaque_pixels"]=opaque
	row["any_alpha_outside_safe"]=outside
	row["alpha_border_pixels"]=border
	row["first_alpha_pixel_center_y"]=top
	row["minimum_safe_margin_pixels"]=margin
	row["mask_format"]=mask.get_format()
	row["mask_size"]=[roi_size.x,roi_size.y]
	if opaque<200 or border>0:
		_fail("empty head alpha or ROI edge touched; cannot report outside0")
		return
	var selected: Array[String]=[]
	if int(row.sample)==0: selected.append("first")
	if margin<narrowest:
		narrowest=margin
		selected.append("narrowest")
	if outside>worst:
		worst=outside
		selected.append("worst")
	if marker<0 and complete_process>=0 and int(row.process_pre)>=complete_process+50:
		marker=int(row.sample)
		marker_t=actor._t
		marker_breath=float(row.breath_phase)
		row["original50_marker"]=true
	var finished := marker>=0 and actor._t-marker_t>=3.2 and float(row.breath_phase)-marker_breath>=TAU
	if finished: selected.append("last")
	if not selected.is_empty():
		var main := get_viewport().get_texture().get_image()
		for reason in selected: full[reason]={"sample":int(row.sample),"image":main}
		if selected.has("first") or selected.has("narrowest"):
			var ref := reference.get_texture().get_image()
			var wanted := Rect2i(int(roi[0]),int(roi[1]),roi_size.x,roi_size.y)
			if not Rect2i(Vector2i.ZERO,ref.get_size()).encloses(wanted):
				_fail("reference full viewport cannot cover the ROI")
				return
			var ref_bytes := ref.get_region(wanted).get_data()
			var differences := 0
			for offset in range(6,data.size(),8):
				if data[offset]!=ref_bytes[offset] or data[offset+1]!=ref_bytes[offset+1]: differences+=1
			row["same_draw_reference_alpha_differences"]=differences
			for reason in ["first","narrowest"]:
				if selected.has(reason): reference_samples[reason]={"sample":int(row.sample),"image":ref}
			if differences!=0:
				_fail("same-draw full reference vs translated ROI alpha is not byte-identical")
				return
	if finished: done=true

func _run() -> void:
	Story.auto_skip=false
	GameState.start_new_run(GameState.difficulties[1])
	for flag in [&"ch1_supper_done",&"ch1_handoff_done"]: GameState.set_flag(flag)
	level=Level.new()
	level.configure(load("res://data/levels/ch1_pawnshop_dawn.tres"))
	get_tree().root.add_child(level)
	await _frames(60)
	Story.reset_active_presentation(&"route")
	if not Story.play(SCENE,false):
		_fail("could not start authored home scene")
	enabled=true
	var first_observed := false
	for i in 10000:
		if done: break
		if Story.is_cinematic_active() and Story._current_cinematic==SCENE and Story._player!=null:
			var player: CutscenePlayer=Story._player
			var text := player._dialogue._text.text
			if text!=TARGET and player._dialogue.is_complete():
				if text==FIRST and not first_observed:
					first_observed=true
					await _frames(50) # Original observation delay, no extra1s.
				player._advance_requested=true # Same dialogue-only advancement as Root's original observer.
		await _frames(3)
	if not done: _fail("continuous target observation timed out")
	enabled=false
	RenderingServer.frame_pre_draw.disconnect(_pre_draw)
	RenderingServer.frame_post_draw.disconnect(_post_draw)
	DirAccess.make_dir_recursive_absolute(out)
	for i in masks.size():
		var name := "head-%04d.raw"%i
		FileAccess.open(out.path_join(name),FileAccess.WRITE).store_buffer(masks[i].get_data())
		rows[i]["mask_path"]=name
		rows[i]["mask_bytes"]=masks[i].get_data_size()
		rows[i]["mask_sha256"]=FileAccess.get_sha256(out.path_join(name))
	for group in [full,reference_samples]:
		for key in group:
			var item: Dictionary=group[key]
			var image: Image=item.image
			var name := ("full-" if group==full else "reference-alpha-")+String(key)
			FileAccess.open(out.path_join(name+".raw"),FileAccess.WRITE).store_buffer(image.get_data())
			Capture.encode(image,true).save_png(out.path_join(name+".png"))
			item["size"]=[image.get_width(),image.get_height()]
			item["format"]=image.get_format()
			item["raw_path"]=name+".raw"
			item["raw_sha256"]=FileAccess.get_sha256(out.path_join(name+".raw"))
			item["png_path"]=name+".png"
			item.erase("image")
	for key in textures:
		var texture: Texture2D=textures[key]
		var image := texture.get_image()
		var name := "source-texture-"+String(key)+".raw"
		FileAccess.open(out.path_join(name),FileAccess.WRITE).store_buffer(image.get_data())
		var offsets: Array=[]
		for i in image.get_mipmap_count()+1: offsets.append(image.get_mipmap_offset(i))
		texture_rows.append({"key":key,"size":[image.get_width(),image.get_height()],"format":image.get_format(),"mipmaps":image.has_mipmaps(),"mipmap_count":image.get_mipmap_count(),"offsets":offsets,"path":name,"sha256":FileAccess.get_sha256(out.path_join(name))})
	var report := {"scope":"new natural home2 target-line continuous observation, not proof of original unrecorded frame alpha; three copied source heads plus full reference, no live actor/physics/camera/material/phase mutations","rows":rows,"marker50_sample":marker,"full":full,"reference":reference_samples,"textures":texture_rows,"issues":issues,"renderer":RenderingServer.get_current_rendering_method(),"device":RenderingServer.get_video_adapter_name(),"declared_observation_cap":60,"breath_minimum_actor_seconds_after50":3.2,"actual_breath_phase_minimum_after50":TAU}
	FileAccess.open(out.path_join("observations.json"),FileAccess.WRITE).store_string(JSON.stringify(report,"  ")+"\n")
	full.clear()
	reference_samples.clear()
	textures.clear()
	masks.clear()
	sources.clear()
	copies.clear()
	reference_copies.clear()
	actor=null
	if is_instance_valid(view): view.queue_free()
	if is_instance_valid(reference): reference.queue_free()
	AudioRelease.begin_shutdown()
	Story.reset_active_presentation(&"route")
	if is_instance_valid(level): level.queue_free()
	await _frames(6)
	await AudioRelease.settle(get_tree())
	var failed := not issues.is_empty() or rows.is_empty() or rows.any(func(r: Dictionary)->bool:return int(r.any_alpha_outside_safe)>0)
	get_tree().quit(1 if failed else 0)
