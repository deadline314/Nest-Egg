from pathlib import Path
import hashlib,json,subprocess
here=Path(__file__).resolve().parent;tree=Path('D:/NestEggVerification/st22-native-review-20261112');repo=here.parents[1]
out=here/'parser-v2-timeout-audit-v1';out.mkdir()
before=json.loads((here/'parser-v2/source-before.json').read_text(encoding='utf-8'))
after={p:hashlib.sha256((tree/p).read_bytes()).hexdigest() for p in before}
guard=json.loads((repo/'work/ne264-product-adoption-v1/c-native-context-v24.json').read_text(encoding='utf-8'))['files']
c={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in guard}
command="Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'Godot*' -and $_.CommandLine -like '*D:\\NestEggVerification\\st22-native-review-20261112*' -and $_.CommandLine -like '*res://work/st22-continuous-head-v1/capture.tscn*' -and $_.CommandLine -like '*--parser-only*' } | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine | ConvertTo-Json -Depth 4"
raw=subprocess.check_output(['powershell','-NoProfile','-Command',command]);processes=json.loads(raw) if raw.strip() else []
assert not processes,processes
(out/'source-after-timeout.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'exact-process-check.txt').write_bytes(raw)
(out/'c-after-timeout.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
record={'scope':'new post-timeout audit, not an overwritten original receipt or successful parser','original_epoch':'parser-v2','original_failure':'same_source inference Parse Error; original console timed out150s','source_count':len(before),'source_unchanged':before==after,'c_source_count':len(guard),'c_unchanged':c==guard,'exact_owned_parser_children_remaining':processes,'stop_actions':[],'product_changed':False}
(out/'audit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'source-original.py').write_bytes(Path(__file__).read_bytes())
assert before==after and c==guard
print(json.dumps(record,indent=2))
