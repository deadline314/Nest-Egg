"""Known answers for physical-pixel ROI translation and exact half alpha gates."""
from pathlib import Path
import hashlib,json,math
import numpy as np
here=Path(__file__).resolve().parent;out=here/'cpu-controls-v2';out.mkdir()

def measure(alpha,origin,safe):
    assert np.isfinite(alpha).all() and (alpha>=0).all() and (alpha<=1).all()
    height,width=alpha.shape;x,y=np.meshgrid(np.arange(width)+origin[0]+.5,np.arange(height)+origin[1]+.5)
    inside=(x>=safe[0])&(x<safe[0]+safe[2])&(y>=safe[1])&(y<safe[1]+safe[3])
    any_alpha=alpha>0;opaque=alpha>=.999
    edge=any_alpha[0,:].sum()+any_alpha[-1,:].sum()+any_alpha[:,0].sum()+any_alpha[:,-1].sum()
    return {'any_outside':int((any_alpha&~inside).sum()),'opaque_outside':int((opaque&~inside).sum()),'opaque':int(opaque.sum()),'border':int(edge),'accepted':bool(opaque.sum()>=200 and edge==0 and not (any_alpha&~inside).any())}

checks=[]
def check(name,value):assert value,name;checks.append({'name':name,'passed':True})
alpha=np.zeros((40,40),dtype='<f2');alpha[11:31,10:30]=1
origin=(100,70);safe=(0,80.25,1280,600)
check('known400 opaque entirely inside fractional safe edge',measure(alpha,origin,safe)=={'any_outside':0,'opaque_outside':0,'opaque':400,'border':0,'accepted':True})
faint=alpha.copy();faint[9,12]=np.float16(.0001)
m=measure(faint,origin,safe);check('positive half alpha below opacity threshold outside still rejects',m['any_outside']==1 and m['opaque_outside']==0 and not m['accepted'])
wrong=measure(alpha,(100,60),safe);check('deliberately wrong integer ROI origin rejects actual nonempty mask',wrong['any_outside']>0 and not wrong['accepted'])
check('empty alpha cannot pass outside0',not measure(np.zeros_like(alpha),origin,safe)['accepted'])
edge=alpha.copy();edge[0,12]=1;check('ROI edge touch rejects clipped proof',not measure(edge,origin,safe)['accepted'])
for bad in [float('nan'),float('inf'),-.1,1.1]:
    data=alpha.astype(np.float64);data[3,3]=bad
    try:measure(data,origin,safe)
    except AssertionError:check('invalid alpha '+str(bad)+' rejected',True)
    else:raise AssertionError(bad)
values=np.array([0,.0001,.9985,.999,1],dtype='<f2')
bits=values.view('<u2');check('RGBAH alpha bit cutoff matches actual .999 float test',np.array_equal(bits>=0x3bfe,values.astype(np.float64)>=.999))
# Known physical affine: world point(10,20) -> pixel(620,130), then ROI(100,70)
# -> local(520,60). Expected points are explicit, not recomputed with the same mapping.
t=np.array([[2,0,600],[0,2,90],[0,0,1]],dtype=np.float64);shift=np.array([[1,0,-100],[0,1,-70],[0,0,1]])
check('integer translation retains known physical1:1 coordinates',np.array_equal((shift@t)@np.array([10,20,1]),[520,60,1]))
def freeze_roi(state,bounds,target):
    if not target:return state,True
    if state is None:
        state=(math.floor(bounds[0])-32,math.floor(bounds[1])-32,math.ceil(bounds[2])+64,math.ceil(bounds[3])+64)
    x,y,w,h=state;bx,by,bw,bh=bounds
    return state,bx-2>=x and by-2>=y and bx+bw+2<=x+w and by+bh+2<=y+h
state,valid=freeze_roi(None,(0,0,400,400),False)
check('large prewarm envelope does not freeze the target crop',state is None and valid)
state,valid=freeze_roi(state,(100.25,80.25,50.5,70.5),True)
check('target first-draw crop uses known integer bounds and32physical observation margin',state==(68,48,115,135) and valid)
frozen=state;state,valid=freeze_roi(state,(103.25,83.25,50.5,70.5),True)
check('small natural movement stays inside the same frozen ROI',state==frozen and valid)
state,valid=freeze_roi(state,(500,80,50,70),True)
check('later target envelope overflow rejects without chasing crop',state==frozen and not valid)
record={'scope':'CPU known-answer alpha classification/ROI math only, no native or original-frame claim','checks':checks,'passed':True}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'source-original.py').write_bytes(Path(__file__).read_bytes())
print(f'{len(checks)}/0 CPU known answers; native same-draw ROI/full alpha A/A remains required')
