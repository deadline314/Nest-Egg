extends "res://tests/smoke_test.gd"

var _out := ""


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://skip_modal_probe.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	super._ready()


func _run() -> void:
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(load("res://data/levels/ch1_prologue.tres") as LevelData)
	add_child(level)
	await _frames(30)
	var menu := level._pause_menu
	await _send_key(KEY_ESCAPE)
	await _frames(12)
	_check(menu._root.visible and get_tree().paused and menu._skip_button != null, "the real prologue opens its pause menu")
	menu._skip_button.grab_focus()
	await _send_key(KEY_ENTER)
	await _frames(6)
	_check(is_instance_valid(menu._skip_confirm) and menu._skip_confirm.is_visible_in_tree(), "a short key press opens the real skip confirmation")
	await _shot("confirmation")
	for code in [KEY_O, KEY_M]:
		await _send_key(code)
		await _frames(5)
		var opened := is_instance_valid(menu._navigation)
		var confirm_visible := is_instance_valid(menu._skip_confirm) and menu._skip_confirm.is_visible_in_tree()
		print("SHORTCUT ", OS.get_keycode_string(code), " nav=", opened, " confirm_visible=", confirm_visible, " paused=", get_tree().paused)
		_check(not opened and confirm_visible and get_tree().paused, "the modal owns " + OS.get_keycode_string(code))
		await _shot("shortcut-" + OS.get_keycode_string(code).to_lower())
		if opened:
			await _send_key(KEY_ESCAPE)
			await _frames(6)
	_check(not menu._menu_panel.is_visible_in_tree() and not menu._info_panel.is_visible_in_tree(),
		"only confirmation actions remain visible while the modal is open")
	for index in 5:
		await _send_button(JOY_BUTTON_DPAD_UP)
	var focus := get_viewport().gui_get_focus_owner()
	_check(is_instance_valid(menu._skip_confirm) and focus != null and menu._skip_confirm.is_ancestor_of(focus),
		"controller focus stays inside the confirmation")
	await _send_button(JOY_BUTTON_B)
	await _frames(5)
	_check(not is_instance_valid(menu._skip_confirm) and get_tree().paused and menu._root.visible,
		"controller Back restores the pause menu without resuming the world")
	_check(get_viewport().gui_get_focus_owner() == menu._skip_button, "the original skip button regains focus")
	_check(not GameState.has_flag(&"ch1_prologue_skipped"), "the prologue is unchanged after cancelling")
	await _shot("pause-returned")
	await _send_key(KEY_O)
	await _frames(6)
	_check(is_instance_valid(menu._navigation) and menu._navigation._page == "quests", "the normal shortcut works again after cancel")
	menu.close()
	await _frames(2)
	level.queue_free()
	await _frames(2)
	await _finish()


func _send_key(code: Key) -> void:
	var press := InputEventKey.new()
	press.keycode = code
	press.physical_keycode = code
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _send_button(button: JoyButton) -> void:
	var press := InputEventJoypadButton.new()
	press.button_index = button
	press.pressure = 1.0
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	release.pressure = 0.0
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _shot(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join(name + ".png")) == OK, "saved " + name)