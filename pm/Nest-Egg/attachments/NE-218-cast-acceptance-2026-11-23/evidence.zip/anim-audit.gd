extends Node

const ENEMIES := {"sweeper": "pistol", "collector_gunner": "pistol", "collector_brute": ""}
const NPCS := {"egret": ["stand", "lean", "sit", "crouch"], "ali": ["stand", "lean", "sit", "crouch"]}
const NPC_LIMITS := ["bone_stretch", "elbow_hyper", "knee_hyper", "trunk_lean", "head_turn",
	"angle_pop", "foot_below_ground", "foot_floating"]
var _out: String
var _failures: Array[Dictionary]
var _reports := {}


func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() != 1:
		get_tree().quit(2)
		return
	_out = args[0]
	_run.call_deferred()


func _run() -> void:
	for actor: String in ENEMIES.keys():
		var rig := CharacterRig.new()
		add_child(rig)
		if not rig.setup(actor):
			get_tree().quit(3)
			return
		rig.set_weapon(str(ENEMIES[actor]))
		var source: Dictionary = RigLibrary.load_json(HumanoidAnimator.ACTIONS_PATH).get("actions", {})
		var actions: Array[String] = []
		for name: String in source.keys():
			if name.begins_with(actor + "."):
				actions.push_back(name)
		_record(actor, AnimAudit.audit(rig, actor, actions), AnimAudit.LIMITS.keys(), false)
		rig.queue_free()
		await get_tree().process_frame
	for actor: String in NPCS.keys():
		var rig := CharacterRig.new()
		add_child(rig)
		if not rig.setup(actor, "npc"):
			get_tree().quit(3)
			return
		for pose: String in NPCS[actor]:
			_record(actor + "/" + pose, AnimAudit.audit_npc(rig, StringName(pose), &""), NPC_LIMITS, true)
		rig.queue_free()
		await get_tree().process_frame
	var output := FileAccess.open(_out, FileAccess.WRITE)
	if output == null:
		get_tree().quit(4)
		return
	output.store_string(JSON.stringify({"cases": _reports, "failed": _failures}, "  ") + "\n")
	output.close()
	print("CAST_ANIMATION_AUDIT ", _reports.size(), " cases, ", _failures.size(), " flag(s)")
	get_tree().quit(int(not _failures.is_empty()))


func _record(scope: String, result: Dictionary, keys: Array, npc: bool) -> void:
	_reports[scope] = result
	for metric: String in keys:
		var limit := float(AnimAudit.LIMITS[metric])
		if npc and metric == "foot_floating":
			limit *= 1.6
		var entry: Dictionary = result.get(metric, {})
		if float(entry.get("value", 0.0)) > limit:
			_failures.append({"case": scope, "metric": metric, "value": entry["value"],
				"limit": limit, "frame": entry["where"]})
