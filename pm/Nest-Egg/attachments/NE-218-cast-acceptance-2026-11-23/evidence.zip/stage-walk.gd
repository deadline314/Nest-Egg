extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const SCENES := {&"ch1_t_supper_stay_host": &"ali", &"ch1_t_supper_stay_host_none": &"ali", &"ch2_t_s03_tea": &"egret"}
var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://npc_stage_walk.cfg")
	var facts := [GameState.world_flags.duplicate(true), Progression.credits, StoryItems.snapshot()]
	for id: StringName in SCENES:
		if not await _play(id, SCENES[id]):
			printerr("Original stage could not finish both directions: ", id)
			get_tree().quit(1)
			return
	if facts != [GameState.world_flags, Progression.credits, StoryItems.snapshot()]:
		printerr("Direct actor preview changed story facts")
		get_tree().quit(1)
		return
	var file := FileAccess.open(_out.path_join("stage-walk.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"adapter": RenderingServer.get_video_adapter_name(),
		"renderer": RenderingServer.get_current_rendering_method(), "hdr": get_viewport().use_hdr_2d,
		"facts_unchanged": true, "rows": _rows}, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit()


func _play(id: StringName, actor: StringName) -> bool:
	var scene: Dictionary = Story._scenes.get(id, {})
	if scene.get("mode") != "animated" or not CutsceneChecker.staging_problems(str(id), scene).is_empty():
		return false
	var timeline := JSON.stringify(scene["steps"]).sha256_text()
	var player := CutscenePlayer.new()
	add_child(player)
	player.play(id, scene)
	var counts := {-1: 0, 1: 0}
	var start := _rows.size()
	for frame in 660:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		if not is_instance_valid(player) or not player.is_running(): break
		var character := player._actors.get(actor) as CutsceneActor
		if is_instance_valid(character) and character.rig != null and absf(character._input.velocity.x) > 0.001:
			var direction := int(signf(character._input.velocity.x))
			if direction != character.facing or (character.rig.animator as NpcAnimator)._use_npc:
				return false
			counts[direction] += 1
			if counts[direction] in [2, 5, 11, 20]:
				var key := "%s-%d-%02d" % [id, direction, counts[direction]]
				if counts[direction] == 5 and (id == &"ch1_t_supper_stay_host" or id == &"ch2_t_s03_tea") and Capture.image(get_viewport()).save_png(_out.path_join(key + ".png")) != OK:
					return false
				var joint := character.rig.bone(&"arm_front_upper").global_position
				_rows.append({"key": key, "scene": str(id), "actor": str(actor), "timeline": timeline,
					"direction": direction, "frame": counts[direction], "pose": str(character.pose),
					"position": [character.position.x, character.position.y], "speed": character._input.velocity.x,
					"shoulder": [joint.x, joint.y], "ground": character.ground_y})
		if player._dialogue.visible and frame % 12 == 6:
			var event := InputEventAction.new()
			event.action = &"ui_accept"
			event.pressed = true
			Input.parse_input_event(event)
			event = InputEventAction.new()
			event.action = &"ui_accept"
			Input.parse_input_event(event)
	var settled := not is_instance_valid(player) or not player.is_running()
	if is_instance_valid(player):
		player.queue_free()
	await get_tree().process_frame
	print(id, " settled=", settled, " movement=", counts, " captures=", _rows.size() - start)
	return settled and counts[-1] >= 20 and counts[1] >= 20 and _rows.size() - start == 8
