from pathlib import Path
from statistics import median
import json
p=Path(__file__).resolve().parent
x=json.loads((p/'render-final/result.json').read_bytes())
rows=x['render_holds']
stats=lambda values: [len(values),min(values),median(values),max(values)]
out={'all':stats([r['gap'] for r in rows])}
for side in [-1,1]:
    out[str(side)]=stats([r['gap'] for r in rows if r['pose']=='walk' and r['facing']==side])
print(out,flush=True)
(p/'kettle-render.json').write_text(json.dumps(out,indent=2)+'\n')

