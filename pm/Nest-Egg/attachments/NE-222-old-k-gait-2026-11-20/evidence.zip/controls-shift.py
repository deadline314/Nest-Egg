from pathlib import Path
import json, statistics
base=Path(__file__).resolve().parent
rows=lambda tag:{(r['actor'],r['tick']):r for r in json.loads((base/tag/'result.json').read_bytes())['rows']}
ref=rows('reference')
cur=rows('shift-blend')
assert ref.keys()==cur.keys() and len(cur)==3070
authored=['x','y','floor','where','speed','facing','pose']
assert all(all(a[k]==cur[key][k] for k in authored) for key,a in ref.items())
assert all(a==cur[key] for key,a in ref.items() if key[0]=='rin')
boots=('foot_front','foot_back')
deltas={}
for p in ['idle','squat']:
    stable={}
    streak=0
    last=-2
    entries=[]
    for (actor,tick),r in cur.items():
        if actor!='k' or r['pose']!=p: continue
        streak=streak+1 if tick==last+1 else 1
        last=tick
        a=ref[actor,tick]
        dev=max(abs(r[b][i]-a[b][i]) for b in boots for i in range(2))
        gap=max(r[b][1] for b in boots)-r['floor']
        entries.append((round(gap,3),tick,streak,r['where']))
        for frames in (20,30,45,60):
            if streak>=frames: stable.setdefault(frames,[]).append(dev)
    deltas[p]={'worst_floor':max(entries),'stable_landmarks':{k:[len(v),max(v),statistics.median(v)] for k,v in stable.items()}}
print(deltas)
(base/'controls.json').write_text(json.dumps({'paired_actor_frames':len(cur),'rin_exact_frames':sum(k[0]=='rin' for k in cur),'authored_tracks_exact':authored,'k_pose':deltas},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


