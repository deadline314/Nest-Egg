from pathlib import Path
import json
p=Path(__file__).resolve().parent
raw=json.loads((p/'shift-blend/result.json').read_bytes())['rows']
rows=[r for r in raw if r['actor']=='k' and r['pose']=='walk' and abs(r['speed'])>2]
lag=[]
for a,b in zip(rows,rows[1:]):
    travel=abs(b['x']-a['x'])
    if b['tick']!=a['tick']+1 or a['facing']!=b['facing'] or travel<.25: continue
    contacts=[]
    for boot in ('foot_front','foot_back'):
        if abs(b[boot][1]-b['floor'])<=2 and abs(a[boot][1]-a['floor'])<=2 and abs(b[boot][2]-a[boot][2])<.07:
            contacts.append(abs(b[boot][0]-a[boot][0]))
    if contacts:
        lag.append((min(contacts),b['tick'],a['gait_weight'],b['gait_weight'],travel))
print('highest',sorted(lag,reverse=True)[:12])

