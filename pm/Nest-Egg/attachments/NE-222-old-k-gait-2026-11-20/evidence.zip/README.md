# 老 K 回家過場的落腳

Godot 4.7.2、RX 9070 XT、Forward+、固定 60 fps。探針播放正式 ch1_c14_home，只有預備旗標與推進對話由腳本控制。每個程序使用獨立使用者資料夾。

metrics.py 的距地數量以兩靴最下面的畫點為準。水平位移僅納入同面向相鄰影格、舞台移動至少 0.25 像素、同靴子兩格都在 2 像素內、旋轉差小於 0.07 弧度的樣本。兩靴都符合時取較小的移動量。鞋底輪廓採原貼圖 alpha 至少 0.5 的位置。本次量測範圍涵蓋鞋底，關節接縫另有專屬檢查。

gait-render.gd 在 RenderingServer.frame_post_draw 檢查正式舞台持物時壺與掌心的座標。繪製前的診斷會量到一個物理步距，繪製後才是玩家所見。資料依次為原版 reference、全程落腳 candidate、移動落腳 move-only，以及腿與骨盆一起過渡的 shift-blend 與 render-final。

重跑時在對應版本的 Godot 專案啟動 gait.tscn 或 gait-render.tscn。把場景檔內的腳本地址換成解壓後的絕對路徑，並帶入 --fixed-fps 60 和 -- --out=<獨立資料夾>。執行 metrics.py reference candidate move-only shift-blend 重算。正式受影響測試的啟動參數與輸出亦收錄於 official。
