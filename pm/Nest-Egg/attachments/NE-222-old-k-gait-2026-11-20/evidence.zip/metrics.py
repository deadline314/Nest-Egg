import json
from pathlib import Path
from statistics import median
import sys

p=Path(__file__).resolve().parent

def collect(tag, who):
    rows=[r for r in json.loads((p/tag/"result.json").read_bytes())["rows"] if r["actor"]==who]
    notes={}
    for label,selected in (
        ("walk",[r for r in rows if r["pose"]=="walk" and abs(r["speed"])>2.0]),
        ("idle",[r for r in rows if r["pose"]=="idle"]),
        ("squat",[r for r in rows if r["pose"]=="squat"]),
    ):
        if not selected: continue
        boots=("foot_front","foot_back")
        floor_gap=[max(row[b][1] for b in boots)-row["floor"] for row in selected]
        step_size=[abs(now["x"]-prev["x"]) for prev,now in zip(selected,selected[1:]) if now["tick"]==prev["tick"]+1]
        planted=[]
        ratios=[]
        for prev,now in zip(selected,selected[1:]):
            if now["tick"]!=prev["tick"]+1 or now["facing"]!=prev["facing"]: continue
            distance=abs(now["x"]-prev["x"])
            if distance<.25: continue
            contacts=[abs(now[b][0]-prev[b][0]) for b in boots
                      if abs(now[b][1]-now["floor"])<=2.0 and abs(prev[b][1]-prev["floor"])<=2.0
                      and abs(now[b][2]-prev[b][2])<.07]
            if contacts:
                planted.append(min(contacts))
                ratios.append(min(contacts)/distance)
        stats=lambda s:[round(min(s),3),round(median(s),3),round(max(s),3)] if s else []
        notes[label]={"frames":len(selected),"true_gait":sum(r["gait"] for r in selected),"stage_motion":stats(step_size),
                      "sole_vs_floor":stats(floor_gap),"within_2":sum(abs(g)<=2 for g in floor_gap),
                      "moving_contact_frames":len(planted),"slip_per_frame":stats(planted),"slip_vs_stage":stats(ratios),
                      "speeds":stats([abs(r["speed"]) for r in selected])}
    return notes

all_notes={tag:{who:collect(tag,who) for who in ("k","rin")} for tag in sys.argv[1:]}
(p/"metrics.json").write_text(json.dumps(all_notes,indent=2)+"\n",encoding="utf-8")
for tag,record in all_notes.items():
    print(tag,record,flush=True)
