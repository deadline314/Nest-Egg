from pathlib import Path
import json
import numpy as np
from PIL import Image
p=Path(__file__).resolve().parent
folder=p/'pelvis-high'
rows=json.loads((folder/'profiles.json').read_bytes())
out={}
for tag,poses in rows.items():
    out[tag]={}
    for pose,(x,y) in poses.items():
        x,y=round(x*2),round(y*2)
        crop=(max(0,x-50),max(0,y-38),x+50,y+52)
        a,b,c=[np.asarray(Image.open(folder/f'{tag}_{pose}_{k}.png').convert('RGB').crop(crop),dtype=np.int16)
               for k in ('on','off','repeat')]
        delta=np.abs(a-b).max(axis=2)
        noise=np.abs(a-c).max(axis=2)
        eligible=noise<=2
        stable=eligible & (delta>=5)
        out[tag][pose]={'visible_contribution':int(stable.sum()),'largest_channel_difference':int(delta[eligible].max()),
                       'expected_pixels':int(eligible.sum()),'roi':crop}
        print(tag,pose,out[tag][pose])
(p/'pelvis-measurements.json').write_text(json.dumps(out,indent=2)+'\n')
