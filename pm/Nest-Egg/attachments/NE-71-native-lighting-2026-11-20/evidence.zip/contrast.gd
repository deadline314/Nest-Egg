extends "res://tools/readability_check.gd"

func targets() -> Array[Dictionary]:
	return [
		{"path":"res://data/levels/level_02.tres","spots":[["轉運站",428,20]],"enemy_path":""},
		{"path":"res://data/levels/level_01.tres","spots":[["停電走廊",279,20]],"enemy_path":""},
		{"path":"res://data/levels/ch2_market.tres","spots":[["公眾攤道",47,36]],"enemy_path":""},
	]
