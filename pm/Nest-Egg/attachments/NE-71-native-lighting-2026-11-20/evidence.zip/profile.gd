extends ScenarioBase

const FIELDS := [
	["transfer", "level_02", 428, 20],
	["blackout", "level_01", 279, 20],
	["market", "ch2_market", 47, 36],
]
const LIT_PARTS := [&"armor_torso", &"armor_pelvis", &"foot_front", &"foot_back"]

var _tier := LightQuality.Tier.HIGH
var _results: Dictionary = {}


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
		elif arg.begins_with("--tier="):
			_tier = int(arg.trim_prefix("--tier="))
	if out_dir.is_empty() or DisplayServer.get_name()=="headless" or not get_viewport().use_hdr_2d or _tier not in [0,1,2]:
		push_error("profile probe needs Forward+ HDR, output folder and a valid quality tier")
		get_tree().quit(2)
		return
	Story.auto_skip = true
	Settings.set_light_quality(_tier)
	for field: Array in FIELDS:
		await _review(field)
	var report := FileAccess.open(out_dir.path_join("profiles.json"),FileAccess.WRITE)
	report.store_string(JSON.stringify(_results,"\t"))
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)


func _review(field: Array) -> void:
	var tag: String = field[0]
	var map: String = field[1]
	var location := Vector2((int(field[2])+0.5)*16.0,int(field[3])*16.0)
	GameState.start_new_run(GameState.difficulties[1])
	seed(710311)
	level = Level.new()
	level.configure(load("res://data/levels/%s.tres" % map) as LevelData)
	add_child(level)
	await settle(25)
	player = level.player
	player.health.setup(100,0.0)
	await clear_enemies()
	player.global_position = location-Vector2(0,5)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player,true)
	Input.action_press(&"aim_right")
	snap_camera()
	await wait(3.9)
	_check(player.is_on_floor() and absf(player.global_position.y-location.y)<1.0,tag+" stable on assigned authored floor")
	_check(Settings.get_light_quality()==_tier,tag+" current settings use requested tier")
	var rig: CharacterRig = player._visual.rig
	var parts: Dictionary = {}
	var glow_nodes: Dictionary = {}
	var originals: Dictionary = {}
	for node in rig._parts:
		var canvas := node as CanvasItem
		if canvas==null or not canvas.visible or not LIT_PARTS.has(StringName(canvas.name)):
			continue
		var material_tex := canvas.get("texture") as CanvasTexture
		var glow: CanvasItem = null
		for child in canvas.get_children():
			if child is CanvasItem and child.material == CharacterRig._glow_material():
				glow = child
				break
		_check(material_tex != null and material_tex.diffuse_texture != null and glow != null,tag+" "+str(canvas.name)+" has its visible diffuse and authored glow")
		if glow==null or material_tex==null: continue
		glow_nodes[canvas] = {"node":glow,"visible":glow.visible}
		originals[canvas]=material_tex
		var bone := canvas.get_parent() as Node2D
		var pixel := bone.get_global_transform_with_canvas().origin
		parts[str(canvas.name)] = {
			"position":[pixel.x,pixel.y],"glow_visible":glow.visible,
			"uses_normal":material_tex.normal_texture != null,
			"normal":material_tex.normal_texture.resource_path if material_tex.normal_texture != null else "",
		}
	_check(parts.size()==4,tag+" required four emissive materials are present")
	var origin := rig.get_global_transform_with_canvas().origin
	var head := rig.bone(&"head").get_global_transform_with_canvas().origin
	var ambient := level._lighting.current.ambient_color
	var reference := load("res://data/lighting/%s.tres" % tag) as LightingProfile
	_check(reference != null and absf(LightKit.luminance(ambient) - LightKit.luminance(reference.ambient_color)) < .005,
		tag+" scene uses the expected ambient light")
	var case_info: Dictionary = {
		"map":map,"tile":[int(field[2]),int(field[3])],"quality":_tier,"player":[origin.x,origin.y],"head":[head.x,head.y],
		"profile":str(level._lighting.current.id),"ambient":[ambient.r,ambient.g,ambient.b],
		"fill":LightKit.character_fill,"light":LightKit.player_light_energy,
		"parts":parts,
		"camera_zoom":get_viewport().get_canvas_transform().get_scale().x,
	}
	get_tree().paused=true
	await _take(tag+"_intact")
	for canvas: CanvasItem in glow_nodes:
		(glow_nodes[canvas]["node"] as CanvasItem).visible=false
	await _take(tag+"_no_glows")
	for canvas: CanvasItem in glow_nodes:
		(glow_nodes[canvas]["node"] as CanvasItem).visible=glow_nodes[canvas]["visible"]
		var texture := (originals[canvas] as CanvasTexture).duplicate() as CanvasTexture
		texture.normal_texture=null
		canvas.set("texture",texture)
	await _take(tag+"_no_normals")
	for canvas: CanvasItem in originals:
		canvas.set("texture",originals[canvas])
	await _take(tag+"_repeat")
	rig.visible=false
	await _take(tag+"_no_body")
	rig.visible=true
	get_tree().paused=false
	_results[tag]=case_info
	Input.action_release(&"aim_right")
	AimInput.set_virtual_gamepad(player,false)
	await finish()


func _take(name: String) -> void:
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	capture(name)


func _check(ok: bool, why: String) -> void:
	if ok:
		print("PASS ",why)
	else:
		failures += 1
		push_error(why)

