from pathlib import Path
import json
from PIL import Image
import numpy as np
p=Path(__file__).resolve().parent
out=p/'pelvis-occlusion'
doc=json.loads((out/'positions.json').read_bytes())
facts={}
for name,r in doc.items():
    x,y=[round(v*2) for v in r['center']]
    box=(max(x-75,0),max(y-72,0),x+90,y+67)
    before,after,repeat=[np.asarray(Image.open(out/f'{name}_{k}.png').convert('RGB').crop(box),dtype=np.int16)
                         for k in ('on','off','repeat')]
    stable=np.abs(before-repeat).max(axis=-1)<=2
    delta=np.abs(before-after).max(axis=-1)
    facts[name]={'pixels':int((stable&(delta>=5)).sum()),'peak':int(delta[stable].max()),'hidden':r['hidden']}
    print(name, facts[name])
(p/'occlusion-measurements.json').write_text(json.dumps(facts,indent=2)+'\n')

