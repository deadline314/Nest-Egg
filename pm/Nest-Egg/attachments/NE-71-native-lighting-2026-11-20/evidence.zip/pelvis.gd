extends "D:/NestEggVerification/evidence-20261120-ne71-lighting/profile.gd"

func _review(field: Array) -> void:
	var tag: String = field[0]
	var map: String = field[1]
	var location := Vector2((int(field[2])+0.5)*16.0,int(field[3])*16.0)
	GameState.start_new_run(GameState.difficulties[1])
	seed(710311)
	level = Level.new()
	level.configure(load("res://data/levels/%s.tres" % map) as LevelData)
	add_child(level)
	await settle(25)
	player = level.player
	await clear_enemies()
	player.global_position = location-Vector2(0,5)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player,true)
	Input.action_press(&"aim_right")
	snap_camera()
	await wait(3.9)
	var rig: CharacterRig=player._visual.rig
	var pelvis: CanvasItem
	for part in rig._parts:
		if part.name==&"armor_pelvis":
			for child in part.get_children():
				if child is CanvasItem and child.material==CharacterRig._glow_material():
					pelvis=child
					break
	_check(pelvis!=null and pelvis.is_visible_in_tree(),tag+" real pelvis glow is present")
	if pelvis==null: return
	var rows: Dictionary = {}
	for action: String in ["stand","crouch"]:
		if action=="crouch":
			Input.action_press(&"move_down")
			await settle(40)
			_check(player.is_crouching,tag+" real down input starts crouch")
		var origin:=rig.bone(&"hip").get_global_transform_with_canvas().origin
		rows[action]=[origin.x,origin.y]
		get_tree().paused=true
		await _take("%s_%s_on"%[tag,action])
		pelvis.visible=false
		await _take("%s_%s_off"%[tag,action])
		pelvis.visible=true
		await _take("%s_%s_repeat"%[tag,action])
		get_tree().paused=false
	Input.action_release(&"move_down")
	Input.action_release(&"aim_right")
	AimInput.set_virtual_gamepad(player,false)
	_results[tag]=rows
	await finish()
