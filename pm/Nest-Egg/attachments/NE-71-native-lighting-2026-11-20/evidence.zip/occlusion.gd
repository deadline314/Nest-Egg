extends "D:/NestEggVerification/evidence-20261120-ne71-lighting/profile.gd"

func _run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
	if out_dir.is_empty():
		get_tree().quit(2)
		return
	Story.auto_skip=true
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	GameState.start_new_run(GameState.difficulties[1])
	seed(710322)
	level=Level.new()
	level.configure(load("res://data/levels/ch2_market.tres") as LevelData)
	add_child(level)
	await settle(25)
	player=level.player
	await clear_enemies()
	player.global_position=Vector2(47.5*16.0,36*16.0-3.0)
	player.velocity=Vector2.ZERO
	AimInput.set_virtual_gamepad(player,true)
	Input.action_press(&"aim_right")
	snap_camera()
	await wait(3.9)
	var rig := player._visual.rig
	var visible_parts := {}
	var glow: CanvasItem
	for part: CanvasItem in rig._parts:
		if not part.visible:
			continue
		visible_parts[String(part.name)]=part
		if part.name==&"armor_pelvis":
			for item in part.get_children():
				if item is CanvasItem and item.material==CharacterRig._glow_material():
					glow=item
	_check(glow!=null and glow.is_visible_in_tree(),"pelvis emits through the authored material when isolated")
	if glow==null:
		get_tree().quit(2)
		return
	var reports: Dictionary = {}
	get_tree().paused=true
	for c: Array in [
		["all",[]],
		["without_coat",["armor_jacket","armor_jacket_far","coat_tail","coat_tailFar"]],
		["without_torso",["armor_torso"]],
		["pelvis_only",visible_parts.keys().filter(func(i: String) -> bool: return i!="armor_pelvis")],
	]:
		for key: String in visible_parts:
			(visible_parts[key] as CanvasItem).visible=not c[1].has(key)
		var point := rig.bone(&"hip").get_global_transform_with_canvas().origin
		reports[c[0]]={"center":[point.x,point.y],"hidden":c[1]}
		for state: String in ["on","off","repeat"]:
			glow.visible=state!="off"
			await _take(c[0]+"_"+state)
	for part: CanvasItem in visible_parts.values(): part.visible=true
	get_tree().paused=false
	Input.action_release(&"aim_right")
	AimInput.set_virtual_gamepad(player,false)
	var file:=FileAccess.open(out_dir.path_join("positions.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(reports,"\t"))
	await finish()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)
