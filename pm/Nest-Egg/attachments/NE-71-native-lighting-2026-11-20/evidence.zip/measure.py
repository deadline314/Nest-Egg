from pathlib import Path
import json
import numpy as np
from PIL import Image

p=Path(__file__).resolve().parent
read=lambda file: json.loads(file.read_bytes())
results={}
for tier in (0,1,2):
    folder=p/f'material-profiles-{tier}'
    profiles=read(folder/'profiles.json')
    for tag,record in profiles.items():
        imgs={state:np.array(Image.open(folder/f'{tag}_{state}.png').convert('RGB'),dtype=np.int16)
              for state in ('intact','repeat','no_glows','no_normals','no_body')}
        h,w=imgs['intact'].shape[:2]
        ratio=np.array([w/640,h/360])
        foot=np.array(record['player'])*ratio
        head=np.array(record['head'])*ratio
        minx=max(0,int(min(foot[0],head[0])-70))
        maxx=min(w,int(max(foot[0],head[0])+125))
        miny=max(0,int(head[1]-35))
        maxy=min(h,int(foot[1]+16))
        imgs={name:a[miny:maxy,minx:maxx] for name,a in imgs.items()}
        ox,oy=np.mgrid[miny:maxy,minx:maxx]
        lit=imgs['intact']
        repeat=imgs['repeat']
        delta=lambda other: np.max(np.abs(lit-other),axis=2)
        noise=delta(repeat)
        # Pixels that stay stable during the repeat and that disappear with the whole character.
        body=(delta(imgs['no_body'])>=8)&(noise<=2)
        color=(lit@np.array([.2126,.7152,.0722]))/255
        under_glow=delta(imgs['no_glows'])
        normal=delta(imgs['no_normals'])
        glow=(under_glow>=5)&body
        changed_normal=(normal>=5)&body
        clipped=(lit>=247).all(axis=2)&body
        part_records={}
        bands={'torso':(record['parts']['armor_torso']['position'],(30,12)),
               'pelvis':(record['parts']['armor_pelvis']['position'],(27,17)),
               'front boot':(record['parts']['foot_front']['position'],(25,24)),
               'back boot':(record['parts']['foot_back']['position'],(25,24))}
        for part,(pos,bounds) in bands.items():
            center=np.array(pos)*ratio
            area=(abs(oy-center[0])<bounds[0])&(abs(ox-center[1])<bounds[1])
            part_records[part]=dict(glow=int((area&glow).sum()),normal=int((area&changed_normal).sum()),
                                   visible=int((area&body).sum()))
        mask=Image.fromarray((body*255).astype(np.uint8))
        mask.save(folder/f'{tag}-body-mask.png')
        count=int(body.sum())
        assert count>1000
        measurements=dict(pixel_crop=[minx,miny,maxx,maxy], stable_body=count,
                          stable_repeat=int((noise<=2).sum()),samples=int(noise.size),
                          clipped=int(clipped.sum()),clip_percent=round(100*float(clipped.sum())/count,3),
                          body_luma_percentiles=np.percentile(color[body],[10,50,90,99]).round(5).tolist(),
                          glow_pixels=int(glow.sum()),normal_pixels=int(changed_normal.sum()),parts=part_records)
        results[f'{tag}/{tier}']=measurements
        print(tag,tier,count,measurements['clipped'],measurements['body_luma_percentiles'],
              measurements['glow_pixels'],measurements['normal_pixels'],
              [(part,r['glow'],r['normal']) for part,r in part_records.items()])
(p/'measurements.json').write_text(json.dumps(results,indent=2)+'\n')
