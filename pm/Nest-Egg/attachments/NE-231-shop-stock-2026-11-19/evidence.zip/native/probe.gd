extends ScenarioBase

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=").replace("\\", "/")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()

func _run() -> void:
	Story.auto_skip = true
	await open_arena("res://data/lighting/warehouse_interior.tres")
	var shop := ShopData.new()
	var med := ConsumableBag.find(&"med_injector")
	var shield := ConsumableBag.find(&"shield_cell")
	var invalid := med.duplicate() as ConsumableData
	invalid.id = &"missing_price"
	invalid.price = 0
	shop.stock.assign([null, med, invalid, shield])
	Progression.add_credits(1000)
	var screen := ShopScreen.new()
	screen.configure_shop(player, shop)
	level.add_child(screen)
	screen.open()
	await settle(45)
	var page := screen._pages[0] as ShopPage
	var ids: Array = page._entries.map(func(entry: InventoryEntry) -> StringName: return entry.id)
	_verify(ids == [med.id, shield.id], "only the two priced items remain visible")
	page.navigate(Vector2i.DOWN)
	await settle(45)
	var action: Button = page._detail._action
	_verify(action.tooltip_text == "花費 ¥%d" % shield.price, "shield tooltip shows the displayed price")
	var mouse := action.get_global_transform_with_canvas() * (action.size * 0.5)
	get_viewport().warp_mouse(mouse)
	await settle(65)
	await RenderingServer.frame_post_draw
	capture("valid-items")
	var before := player.consumables.count(shield.id)
	page.activate()
	await settle(30)
	_verify(player.consumables.count(shield.id) == before + 1, "selected shield cell is delivered")
	_verify(Progression.credits == 1000 - shield.price, "selected shield cell price is charged")
	await RenderingServer.frame_post_draw
	capture("after-purchase")
	screen.close()
	_verify(not get_tree().paused, "closing the shop resumes play")
	var report := {"failures": failures, "items": ids, "shield_price": shield.price, "credits_after": Progression.credits,
		"tooltip": action.tooltip_text, "adapter": RenderingServer.get_video_adapter_name()}
	FileAccess.open(out_dir.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	print("NE231_SHOP invalid_slots=2 failures=%d" % failures)
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)

func _verify(condition: bool, label: String) -> void:
	if not condition:
		failures += 1
		push_error(label)
