from pathlib import Path
p=Path(__file__).resolve().parent
original=p.parent/'evidence-20261120-ne222-lazy-width'
code=(original/'refresh.gd').read_text(encoding='utf-8')
def edit(before,after):
    global code
    assert code.count(before)==1,before
    code=code.replace(before,after)
edit('const WIDTH_EPSILON := 0.0001','const WIDTH_EPSILON := 0.0001\nconst ROW_WIDTH_GUARD := 0.002')
edit('var _zone_row_data := PackedVector2Array()  ## (height in bone space, blend weight)',
     'var _zone_row_data := PackedVector2Array()  ## (height in bone space, blend weight)\nvar _row_width_floor := ROW_WIDTH_GUARD')
edit('\t_zone_offsets = PackedVector2Array()\n','\t_zone_offsets = PackedVector2Array()\n\t_row_width_floor = ROW_WIDTH_GUARD\n')
edit('''			if store_offsets:
				_zone_offsets.append(Vector2(in_a.x - _axis_x, 0.0))''','''			if store_offsets:
				var offset := Vector2(in_a.x - _axis_x, 0.0)
				_zone_offsets.append(offset)
				var width := absf(offset.x)
				if width > 0.0:
					_row_width_floor = maxf(_row_width_floor, 2.0 * WIDTH_EPSILON / width if width > WIDTH_EPSILON else INF)''')
edit('''		for column in COLUMNS:
			var offset := _zone_offsets[column]
			var moved_offset: Vector2 = offset.lerp(along_x * offset.x, w)
			var length := moved_offset.length()
			var wanted := absf(offset.x)
			if length > WIDTH_EPSILON and wanted > WIDTH_EPSILON:
				moved_offset *= lerpf(1.0, wanted / length, volume_keep)
			_deformed[first + column] = _to_local * (moved_axis + moved_offset)
''','''		var blended := Vector2.RIGHT.lerp(along_x, w)
		var length := blended.length()
		if length <= _row_width_floor:
			_deform_narrow_row(first, moved_axis, along_x, w)
			continue
		var direction := blended * lerpf(1.0, 1.0 / length, volume_keep)
		var index := first
		for offset in _zone_offsets:
			_deformed[index] = _to_local * (moved_axis + direction * offset.x)
			index += 1
''')
edit('## 目前的網格有幾個三角形被翻面','''## Near a collapsed row, retain per-column precision at the width cutoff.
func _deform_narrow_row(first: int, axis: Vector2, along_x: Vector2, weight: float) -> void:
	var index := first
	for offset in _zone_offsets:
		var moved: Vector2 = offset.lerp(along_x * offset.x, weight)
		var length := moved.length()
		var width := absf(offset.x)
		if length > WIDTH_EPSILON and width > WIDTH_EPSILON:
			moved *= lerpf(1.0, width / length, volume_keep)
		_deformed[index] = _to_local * (axis + moved)
		index += 1


## 目前的網格有幾個三角形被翻面''')
(p/'candidate.gd').write_text(code,encoding='utf-8',newline='\n')
