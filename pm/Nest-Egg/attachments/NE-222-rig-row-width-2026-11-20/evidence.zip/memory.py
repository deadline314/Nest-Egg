from pathlib import Path
from hashlib import sha256
from statistics import median
import json, os, re, subprocess

p=Path(__file__).resolve().parent
root=p.parent/'ne218-baseline-20261117'
stable=p.parent/'evidence-20261120-ne222-lazy-width'
mesh=root/'game/rig/rig_part_mesh.gd'
sha=lambda x:sha256(x.read_bytes()).hexdigest()
manifest=json.loads((stable/'published-source.json').read_bytes())
assert all(sha(root/file)==digest for file,digest in manifest.items())
before=mesh.read_bytes()
replacement=(p/'candidate.gd').read_bytes()
memory_probe=p.parent/'evidence-20261120-ne222-rig-budget/memory.tscn'
assert memory_probe.is_file()
proof={}
try:
    for tag,source in [('before',before),('after',replacement)]:
        mesh.write_bytes(source)
        out=p/f'memory-{tag}'
        out.mkdir()
        env=os.environ.copy()
        for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
            (out/key).mkdir()
            env[key]=str(out/key)
        command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--audio-driver','Dummy',
            '--path',str(root),str(memory_probe)]
        with (out/'engine.log').open('wb') as log:
            run=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=80)
        raw=(out/'engine.log').read_text(encoding='utf-8',errors='replace')
        assert run.returncode==0 and not re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit',raw,re.M),raw[-2500:]
        records=json.loads(raw.split('RIG_MEMORY ',1)[1].splitlines()[0])
        deltas=[]
        for index in range(6):
            pair={r['rigid']:r for r in records if r['pass']==index}
            deltas.append(pair[False]['per_rig_bytes']-pair[True]['per_rig_bytes'])
            assert pair[False]['vertices_per_rig']==423
        proof[tag]={'records':records,'median_extra_bytes':median(deltas)}
finally:
    mesh.write_bytes(before)
    assert all(sha(root/file)==digest for file,digest in manifest.items())
(p/'memory-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print({tag:group['median_extra_bytes'] for tag,group in proof.items()},flush=True)
