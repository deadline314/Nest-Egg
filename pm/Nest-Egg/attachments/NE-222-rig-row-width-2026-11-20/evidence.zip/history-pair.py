from pathlib import Path
from hashlib import sha256
from statistics import median
import json, os, re, subprocess

p=Path(__file__).resolve().parent
history=p.parent/'ne204-rig-budget-recheck-20261120'
current=p.parent/'ne218-baseline-20261117'
release=p.parent/'evidence-20261120-ne222-lazy-width'
read=lambda path:json.loads(path.read_bytes())
sha=lambda path:sha256(path.read_bytes()).hexdigest()
current_id=read(release/'publish/result.json')['commit']
historical_id='4d8206e9c5adecdf3dbccf1664bc96b9ad8e9763'
head=lambda root:subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head(history)==historical_id
assert head(current)==current_id
assert (p/'history-import.exit').read_text(encoding='utf-8-sig').strip()=='0'
manifest=read(release/'published-source.json')
assert all(sha(current/f)==digest for f,digest in manifest.items())
tool_hash=sha(current/'tools/rig_perf_probe.gd')
assert tool_hash==sha(history/'tools/rig_perf_probe.gd')
file='game/rig/rig_part_mesh.gd'
saved=(current/file).read_bytes()

def measure(label, root):
    out=p/label
    out.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
        (out/key).mkdir()
        env[key]=str(out/key)
    command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--audio-driver','Dummy',
        '--path',str(root),'res://tools/rig_perf_probe.tscn','--','--count=10','--frames=1800','--skin=rin']
    with (out/'engine.log').open('wb') as log:
        run=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    raw=(out/'engine.log').read_text(encoding='utf-8',errors='replace')
    assert run.returncode==0 and not re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit',raw,re.M),raw[-2000:]
    hit=re.search(r'剛體 ([\d.]+) µs/格，關節網格 ([\d.]+) µs/格.*每隻多 ([\d.]+) µs.*網格頂點 (\d+)',raw)
    assert hit,raw[-2000:]
    a,b,c,d=hit.groups()
    return {'rigid_us':float(a),'mesh_us':float(b),'extra_us':float(c),'vertices':int(d)}

candidate=p/'candidate.gd'
try:
    (current/file).write_bytes(candidate.read_bytes())
    variants=[('historical',history),('candidate',current)]
    warm={name:measure('compare-warm-'+name,root) for name,root in variants}
    pairs=[]
    for number in range(6):
        order=variants if number%2==0 else list(reversed(variants))
        pair={name:measure(f'compare-{number+1}-{name}',root) for name,root in order}
        pair['ratio']=pair['candidate']['extra_us']/pair['historical']['extra_us']
        pairs.append(pair)
        print(number+1,pair,flush=True)
    stats={'historical_commit':historical_id,'modern_base':current_id,'probe_sha256':tool_hash,
        'candidate_sha256':sha(candidate),'warm':warm,'pairs':pairs,
        'historical_median_us':median(item['historical']['extra_us'] for item in pairs),
        'candidate_median_us':median(item['candidate']['extra_us'] for item in pairs),
        'median_ratio':median(item['ratio'] for item in pairs)}
    (p/'historical-proof.json').write_text(json.dumps(stats,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(stats),flush=True)
finally:
    (current/file).write_bytes(saved)
    assert all(sha(current/f)==digest for f,digest in manifest.items())
