extends Node


func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	var old := FileAccess.open(args[0], FileAccess.READ)
	var new := FileAccess.open(args[1], FileAccess.READ)
	var summary := {"meshes": 0, "width_differences": 0, "fold_differences": 0,
		"moved_vertices": 0, "greatest_delta": 0.0, "greatest_glow_delta": 0.0, "largest_sample": []}
	while old.get_position() < old.get_length() and new.get_position() < new.get_length():
		var a: Array = old.get_var()
		var b: Array = new.get_var()
		if a.slice(0, 3) != b.slice(0, 3):
			push_error("paired rig trajectory out of sync")
			get_tree().quit(3)
			return
		summary["meshes"] += 1
		summary["width_differences"] += int(a[4] != b[4])
		summary["fold_differences"] += int(a[5] != b[5])
		var verts: PackedVector2Array = a[3]
		var changed: PackedVector2Array = b[3]
		var glow: PackedVector2Array = a[6]
		var changed_glow: PackedVector2Array = b[6]
		if verts.size() != changed.size() or glow.size() != changed_glow.size():
			push_error("mesh is no longer the same size: " + str(a.slice(0, 3)))
			get_tree().quit(3)
			return
		for index in verts.size():
			var error := verts[index].distance_to(changed[index])
			if error > 0.0:
				summary["moved_vertices"] += 1
			if error > float(summary["greatest_delta"]):
				summary["greatest_delta"] = error
				summary["largest_sample"] = a.slice(0, 3)
		for index in glow.size():
			var error := glow[index].distance_to(changed_glow[index])
			summary["greatest_glow_delta"] = maxf(float(summary["greatest_glow_delta"]), error)
	if old.get_position() != old.get_length() or new.get_position() != new.get_length():
		push_error("paired rig trajectory lengths differ")
		get_tree().quit(3)
		return
	var out := FileAccess.open(args[2], FileAccess.WRITE)
	out.store_string(JSON.stringify(summary, "	"))
	out.close()
	print("MESH_DIFFERENCE ", JSON.stringify(summary))
	get_tree().quit(0)
