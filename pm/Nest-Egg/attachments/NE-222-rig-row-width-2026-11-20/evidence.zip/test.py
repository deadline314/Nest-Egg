from pathlib import Path
from hashlib import sha256
from statistics import median
import json, os, re, subprocess

p=Path(__file__).resolve().parent
root=p.parent/'ne218-baseline-20261117'
stable=p.parent/'evidence-20261120-ne222-lazy-width'
id=json.loads((stable/'publish/result.json').read_bytes())['commit']
tree=json.loads((stable/'published-source.json').read_bytes())
sha=lambda x:sha256(x.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==id
assert all(sha(root/file)==digest for file,digest in tree.items())
target=root/'game/rig/rig_part_mesh.gd'
original=target.read_bytes()
candidate=(p/'candidate.gd').read_bytes()

def launch(folder, scene, options):
    folder.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
        (folder/key).mkdir()
        env[key]=str(folder/key)
    command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--audio-driver','Dummy',
             '--path',str(root),str(scene),'--',*options]
    with (folder/'engine.log').open('wb') as log:
        exit=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    raw=(folder/'engine.log').read_text(encoding='utf-8',errors='replace')
    assert exit.returncode==0 and not re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit',raw,re.M),raw[-2500:]
    return raw

def speed(label, code):
    target.write_bytes(code)
    raw=launch(p/label,'res://tools/rig_perf_probe.tscn',['--count=10','--frames=1800','--skin=rin'])
    metric=re.search(r'剛體 ([\d.]+) µs/格，關節網格 ([\d.]+) µs/格.*每隻多 ([\d.]+) µs.*網格頂點 (\d+)',raw)
    assert metric,raw[-2000:]
    rigid,mesh,extra,verts=metric.groups()
    return {'rigid_us':float(rigid),'mesh_us':float(mesh),'extra_us':float(extra),'vertices':int(verts)}

try:
    variants=[('before',original),('after',candidate)]
    for label, data in variants:
        target.write_bytes(data)
        launch(p/f'geometry-{label}',p/'geometry.tscn',['--bytes='+str(p/f'geometry-{label}/trajectory.dat')])
    compare=p/'geometry-receipt.json'
    raw=launch(p/'comparison',p/'compare.tscn',[str(p/'geometry-before/trajectory.dat'),
               str(p/'geometry-after/trajectory.dat'),str(compare)])
    summary=json.loads(compare.read_bytes())
    print(json.dumps(summary),flush=True)
    assert summary['meshes']==54540 and summary['width_differences']==summary['fold_differences']==0
    assert summary['greatest_delta']<0.001 and summary['greatest_glow_delta']<0.001
    warm={tag:speed('warm-'+tag,code) for tag,code in variants}
    pairs=[]
    for number in range(6):
        order=variants if number%2==0 else list(reversed(variants))
        case={tag:speed(f'pair-{number+1}-{tag}',code) for tag,code in order}
        print(number+1,case,flush=True)
        pairs.append(case)
    result={'rig_candidate':sha(p/'candidate.gd'),'baseline_head':id,'geometry':summary,'warm':warm,'pairs':pairs,
            'after_median_extra_us':median(case['after']['extra_us'] for case in pairs),
            'median_change':median(case['after']['extra_us']-case['before']['extra_us'] for case in pairs)}
    (p/'proof.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result),flush=True)
finally:
    target.write_bytes(original)
    assert all(sha(root/file)==digest for file,digest in tree.items())
