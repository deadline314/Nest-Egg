from pathlib import Path
from subprocess import run, check_output, STDOUT
import hashlib,json,os,re,sys
from PIL import Image,ImageChops
p=Path(__file__).resolve().parent
root=p.parent/'ne218-baseline-20261117'
base=p.parent/'evidence-20261120-ne222-lazy-width'
file='game/rig/rig_part_mesh.gd'
manifest=json.loads((base/'published-source.json').read_bytes())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert all(sha(root/name)==digest for name,digest in manifest.items())
assert check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==json.loads((base/'publish/result.json').read_bytes())['commit']
before=(root/file).read_bytes()
candidate=(p/'candidate.gd').read_bytes()
exe=r'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
folder=p/'native'
folder.mkdir()
results={}
try:
    for tag,code in [('before',before),('after',candidate)]:
        (root/file).write_bytes(code)
        for direction in ['left','right']:
            out=folder/f'{tag}-{direction}'
            out.mkdir()
            env=os.environ.copy()
            for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
                (out/key).mkdir()
                env[key]=str(out/key)
            cmd=[sys.executable,str(root/'tools/comfyui/gpu_lock.py'),'--',exe,'--path',str(root),'--fixed-fps','60',
                 'res://tools/rig_preview.tscn','--','--out='+str(out/'rin.png'),'--chars=rin,heavy_gunner','--cloth','--bright']
            if direction=='left': cmd.append('--left')
            with (out/'engine.log').open('wb') as log:
                proc=run(cmd,cwd=root,env=env,stdout=log,stderr=STDOUT,timeout=120)
            capture=(out/'engine.log').read_text(encoding='utf-8')
            if proc.returncode!=0 or re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit',capture,re.M):
                raise RuntimeError(capture[-2500:])
            assert (out/'rin.png').is_file()
            results[f'{tag}-{direction}']={'command':cmd,'sha256':sha(out/'rin.png')}
    comparisons={}
    for direction in ['left','right']:
        a=Image.open(folder/f'before-{direction}/rin.png').convert('RGBA')
        b=Image.open(folder/f'after-{direction}/rin.png').convert('RGBA')
        assert a.size==b.size,direction
        histogram=[0]*256
        changed_pixels=0
        for old,new in zip(a.getdata(),b.getdata()):
            peak=max(abs(x-y) for x,y in zip(old,new))
            histogram[peak]+=1
            changed_pixels+=peak!=0
        max_channel_delta=max(i for i,count in enumerate(histogram) if count)
        comparisons[direction]={'pixels':a.width*a.height,'different':changed_pixels,'max_channel_delta':max_channel_delta}
    same=all(row['different']==0 for row in comparisons.values())
    (folder/'result.json').write_text(json.dumps({'same_rendered_pixels':same,'comparisons':comparisons,'cases':results},indent=2)+'\n')
    print(json.dumps(comparisons),flush=True)
finally:
    (root/file).write_bytes(before)
    assert all(sha(root/name)==digest for name,digest in manifest.items())

