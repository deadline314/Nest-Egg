$base='D:/NestEggVerification/evidence-20261120-ne222-fast-row'
$history='D:/NestEggVerification/ne204-rig-budget-recheck-20261120'
if (Test-Path -LiteralPath $history) { throw 'Owned historical worktree already exists' }
git -c gc.auto=0 worktree add --detach $history 4d8206e9c5adecdf3dbccf1664bc96b9ad8e9763  2>&1 | Out-File -LiteralPath "$base/history-checkout.log" -Encoding utf8
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$profile="$base/history-import-profile"
New-Item -ItemType Directory -Path $profile | Out-Null
$env:APPDATA=$profile
$env:LOCALAPPDATA=$profile
$env:XDG_DATA_HOME=$profile
$env:XDG_CONFIG_HOME=$profile
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --editor --import --audio-driver Dummy --path $history 2>&1 | Out-File -LiteralPath "$base/history-import.log" -Encoding utf8
$code=$LASTEXITCODE
$code | Set-Content -LiteralPath "$base/history-import.exit"
exit $code
