extends ScenarioBase

const CENTER := 400.0
const INVULNERABLE_HEALTH := 999
const CASES := {
	"enforcer": "res://data/enemies/shield_rusher.tres",
	"heavy_gunner": "res://data/enemies/heavy_gunner.tres",
}

var _side := 1
var _id := ""
var _enemy: Enemy
var _damage: Array[Dictionary] = []
var _armor: Array[Dictionary] = []
var _markers: Array[String] = []
var _motion: Array[String] = []
var _gear: Array[Dictionary] = []
var _rounds: Array[Dictionary] = []
var _active_rounds: Dictionary = {}
var _suite: Dictionary = {}


func _ready() -> void:
	for token in OS.get_cmdline_user_args():
		if token.begins_with("--out="):
			out_dir = token.trim_prefix("--out=").replace("\\","/")
		elif token.begins_with("--side="):
			_side = int(token.trim_prefix("--side="))
	if not out_dir.is_absolute_path() or _side not in [-1, 1]:
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	for id: String in CASES:
		await _case(id)
	var report := {"adapter":RenderingServer.get_video_adapter_name(), "renderer":RenderingServer.get_current_rendering_method(),
		"failures":failures, "side":_side, "cases":_suite}
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	await settle(15)
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	get_tree().quit(0 if failures == 0 else 1)


func _case(id: String) -> void:
	_id = id
	_damage.clear()
	_armor.clear()
	_motion.clear()
	_gear.clear()
	_rounds.clear()
	_active_rounds.clear()
	_markers.clear()
	var data := LevelData.new()
	data.id = StringName("armor_replay_" + id)
	data.chapter = Story.DEFAULT_CHAPTER
	data.layout_path = "res://tests/fixtures/arena_map.json"
	await open_arena("res://data/lighting/neutral.tres", (CENTER - 97.0 * _side) / 16.0, data)
	level.hud.visible = false
	player.health.setup(INVULNERABLE_HEALTH, player.tuning.hurt_invulnerability)
	_enemy = spawn_enemy(CASES[id], CENTER / 16.0)
	_enemy.health.damaged.connect(_note_damage)
	_enemy.rig.armor_broken.connect(_note_armor)
	EventBus.hit_marker.connect(_note_marker)
	_check(_enemy.rig.skin_id == id and _enemy.rig.armor_count() == 4, "uses the four armored groups in production")
	var before := _enemy.health.current
	var prime := &"windup" if id == "enforcer" else &"spin_up"
	_check(await _until(func() -> bool: return _enemy.fsm.is_in(prime), 160), "the real move begins from AI acquisition")
	await _capture_pose("prime")
	var marks := _markers.size()
	_fire_body()
	_check(await _until(func() -> bool: return _markers.size() > marks, 45), "front projectile actually reaches the target")
	_check(_markers.slice(marks).has("blocked") and _enemy.health.current == before, "front protection blocks the pistol")
	var opening := &"skid" if id == "enforcer" else &"vent"
	_check(await _until(func() -> bool: return _enemy.fsm.is_in(opening), 420), "the natural attack finishes")
	_check(player.health.current < INVULNERABLE_HEALTH, "the attack damages the live player")
	await _capture_pose("opening")
	var last_hp := before
	var direction := _enemy.facing
	for round_index in range(40):
		if not is_instance_valid(_enemy) or _enemy.is_dying():
			break
		if id == "enforcer" and last_hp == 1 and _enemy.can_be_finished():
			player.global_position = _enemy.global_position + Vector2(-_enemy.facing * 25.0, 0.0)
			player.velocity = Vector2.ZERO
			await _physics(2)
			Input.action_press(&"melee")
			await _until(func() -> bool: return _enemy.is_dying(), 30)
			Input.action_release(&"melee")
			last_hp = _enemy.health.current
			if last_hp == 0:
				await _capture_pose("finisher")
				break
		var can_hit := _enemy.fsm.is_in(opening) or (id == "enforcer" and _enemy.fsm.is_in(&"dazed"))
		if not can_hit:
			await _until(func() -> bool: return _enemy.fsm.is_in(opening) or (id == "enforcer" and _enemy.fsm.is_in(&"dazed")), 420)
		if not is_instance_valid(_enemy) or _enemy.is_dying():
			break
		if id == "enforcer":
			direction = -_enemy.facing
		else:
			direction = _enemy.facing
		player.global_position = Vector2(_enemy.global_position.x + 68.0 * direction, FLOOR_Y)
		player.velocity = Vector2.ZERO
		await _physics(2)
		if player.loadout.is_dry():
			player.loadout.start_reload()
			await _physics(80)
			continue
		marks = _markers.size()
		_fire_body()
		await _until(func() -> bool: return _markers.size() > marks or _enemy.is_dying(), 40)
		if _enemy.health.current < last_hp:
			last_hp = _enemy.health.current
			await _capture_pose("hp-%02d" % last_hp)
		if _enemy.is_dying():
			break
		await _physics(22)
	_check(last_hp == 0 and _armor.size()==4 and GameState.kills >= 1, "authored armor groups all detach during the fight")
	if last_hp == 0 and is_instance_valid(_enemy):
		var slots: Array[String] = []
		for part in _enemy.rig._parts:
			if part.visible and not String(part.name).begins_with("armor_"):
				slots.append(String(part.name))
		_check(_enemy.rig._armor_visible==0 and slots.has("torso") and slots.has("head") and slots.has("pelvis"),
			"the defeated body keeps its torso, head and pelvis underlayer")
		await _physics(12)
		if is_instance_valid(_enemy):
			await _capture_pose("defeat")
			await _physics(24)
			if is_instance_valid(_enemy):
				await _capture_pose("underlayer")
	if id == "heavy_gunner":
		_check(_rounds.size() >= 12 and _rounds.all(func(round: Dictionary) -> bool:
			return float(round["distance"]) <= float(round["bound"])), "live pooled bullets appear within the first physics step of the mounted muzzle")
	_suite[id]={"armor":_armor.duplicate(), "damage":_damage.duplicate(), "motion":_motion.duplicate(),
		"markers":_markers.duplicate(), "gear":_gear.duplicate(),"enemy_rounds":_rounds.duplicate(),
		"health_before":before, "last_health":last_hp, "player_hp":player.health.current}
	EventBus.hit_marker.disconnect(_note_marker)
	await finish()


func _fire_body() -> void:
	var target := _enemy.hurtbox.center()
	player.facing = 1 if target.x > player.global_position.x else -1
	player.aim_dir = (target-player.muzzle_position()).normalized()
	player._try_fire()


func _until(predicate: Callable, cap: int) -> bool:
	for tick in range(cap):
		if not is_instance_valid(_enemy):
			return false
		var state := String(_enemy.fsm.current)
		if not _motion.has(state):
			_motion.append(state)
		if _id == "heavy_gunner":
			_track_rounds()
		if predicate.call():
			return true
		await get_tree().physics_frame
	return false


func _physics(frames: int) -> void:
	for frame in range(frames):
		await get_tree().physics_frame


func _note_marker(kind: StringName) -> void:
	_markers.append(String(kind))


func _note_damage(info: DamageInfo) -> void:
	_damage.append({"source":String(info.source_id),"hp":_enemy.health.current,"amount":info.amount,
		"facing":_enemy.facing,"state":String(_enemy.fsm.current),"origin":[info.origin.x,info.origin.y]})


func _note_armor(part: StringName) -> void:
	_armor.append({"part":String(part),"remaining":_enemy.rig._armor_visible,"hp":_enemy.health.current,
		"state":String(_enemy.fsm.current)})


func _track_rounds() -> void:
	var now: Dictionary = {}
	for node in ProjectilePool.container().get_children():
		var shot := node as Projectile
		if shot == null or not shot.active or shot.team != Combat.Team.ENEMY or shot.spec != _enemy.data.projectile:
			continue
		var id := shot.get_instance_id()
		now[id]=true
		if not _active_rounds.has(id):
			var distance := shot.global_position.distance_to(_enemy.rig.muzzle_global())
			var one_step := shot.velocity.length() / float(Engine.physics_ticks_per_second)
			_rounds.append({"distance":distance,"bound":one_step+2.0,"facing":_enemy.facing})
	_active_rounds = now


func _capture_pose(tag: String) -> void:
	if not is_instance_valid(_enemy):
		return
	var camera := level.camera
	camera.set_physics_process(false)
	camera.position_smoothing_enabled=false
	camera.limit_left=-100000
	camera.limit_right=100000
	camera.global_position = _enemy.global_position.lerp(player.global_position,0.48) + Vector2(0,-28)
	camera.reset_smoothing()
	camera.force_update_scroll()
	await RenderingServer.frame_post_draw
	if tag in ["prime", "opening"] and not _enemy.is_dying():
		var rig := _enemy.rig
		var grip := rig.bone(&"hand_front").to_global(rig.hand_grip_offset(&"hand_front"))
		var def := rig.weapon_def()
		var delta := (RigLibrary.vec2(def["muzzle"]) - RigLibrary.vec2(def["grip"])) * rig.weapon_scale()
		var muzzle := rig.weapon_root().global_transform * delta
		var grip_error := grip.distance_to(rig.weapon_root().global_position)
		var muzzle_error := muzzle.distance_to(rig.muzzle_global())
		_gear.append({"tag":tag,"face":_enemy.facing,"grip_error":grip_error,"muzzle_error":muzzle_error})
		_check(grip_error < 0.025 and muzzle_error < 0.001, "actual grip and muzzle stay on their authored anchors")
	capture("%s-%s" % [_id,tag])


func _check(result: bool, label: String) -> void:
	if not result:
		failures+=1
		push_error("%s: %s" % [_id,label])
