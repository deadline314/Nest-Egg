from pathlib import Path
from subprocess import run
import json
import os

base=Path(__file__).resolve().parent
shared=base.parent/'ne218-baseline-20261117'
out=base/'focused'
out.mkdir(exist_ok=False)
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    var=out/'profile'/key
    var.mkdir(parents=True)
    env[key]=str(var)
command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(shared),
         'res://tests/smoke_test.tscn','--','--only=AnimAuditSuite,EyeBlinkSuite,NpcAnimationSuite,PoseMeshSuite']
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
    result=run(command,env=env,cwd=shared,stdout=log,stderr=log,timeout=200)
(out/'exit.txt').write_text(str(result.returncode)+'\n')
lines=(out/'raw.log').read_text(encoding='utf-8',errors='replace').splitlines()
print('\n'.join(lines[-38:]))
assert result.returncode==0 and not any('SCRIPT ERROR:' in line or line.startswith('FAIL') for line in lines)
