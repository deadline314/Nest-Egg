extends "res://tools/npc_motion_strip.gd"

var _without_drape := false


func _ready() -> void:
	_without_drape = "--disable-drape-for-control" in OS.get_cmdline_user_args()
	super._ready()


func _new_rig(parent: Node, skin: String) -> CharacterRig:
	var rig := super._new_rig(parent, skin)
	if rig == null or not _without_drape:
		return rig
	var detached: Array[Dictionary] = []
	for spring: Dictionary in rig.animator._springs:
		var entry := spring.duplicate(true)
		entry.erase("drape")
		detached.append(entry)
	rig.animator._springs = detached
	return rig


func _simulate(rig: CharacterRig, input: RigInput, script: Dictionary, until: float) -> void:
	super._simulate(rig, input, script, until)
	var hem := rig.bone(&"coat_1")
	var tip := rig.bone(&"coat_2")
	var thigh := rig.bone(&"leg_front_upper")
	print("NE221_SAMPLE ", JSON.stringify({
		"skin": rig.skin_id,
		"time": until,
		"facing": _facing,
		"pose": String((rig.animator as NpcAnimator)._pose_now),
		"primary": hem.rotation,
		"tip": tip.rotation,
		"thigh": thigh.rotation,
		"tip_relative_to_thigh": tip.global_rotation - thigh.global_rotation,
		"spring": rig.animator._spring_angle.get(&"coat_1", 0.0),
		"control": _without_drape,
	}))
