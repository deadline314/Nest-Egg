from pathlib import Path
from subprocess import run
from shutil import copyfile
import json
import os
import sys

base = Path(__file__).resolve().parent
shared = base.parent/'ne218-baseline-20261117'
root=Path.cwd()
python = Path(sys.executable)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
scene = root/'pm/Nest-Egg/attachments/NE-224-scene-check/capture.gd'
assert scene.is_file()
copyfile(scene,base/'capture.gd')
(base/'capture.tscn').write_text('''[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="D:/NestEggVerification/evidence-20261120-ne221-review/capture.gd" id="1"]
[node name="SceneCheck" type="Node"]
script = ExtResource("1")
''',encoding='utf-8')

def render(case, scene, args, fixed):
    out=base/case
    out.mkdir(exist_ok=False)
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        var = out/'profile'/key
        var.mkdir(parents=True)
        env[key]=str(var)
    command = [str(python),str(shared/'tools/comfyui/gpu_lock.py'),'--',engine,
               '--path',str(shared),'--resolution','1280x720','--position','10,90',
               '--rendering-method','forward_plus','--rendering-driver','vulkan']
    if fixed:
        command.extend(('--fixed-fps','60'))
    command.append(str(scene))
    command.extend(('--',*[a.replace('{out}',out.as_posix()) for a in args]))
    (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=160)
    (out/'exit.txt').write_text(str(result.returncode)+'\n',encoding='utf-8')
    raw=(out/'raw.log').read_text(encoding='utf-8')
    print(case,result.returncode,len(raw),flush=True)
    assert result.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw
    return raw


for case, zoom, facing, cast in (
    ('clear-game', 2.2, 1, 'old_k,ah_po'),
    ('clear-stage-old-k',3.4,-1,'old_k'),
    ('clear-stage-ah-po',3.4,-1,'ah_po'),
):
    for control in ('original','no-drape'):
        args=['--out={out}/sitting.png',f'--chars={cast}',
              '--script=sit_cycle','--frames=6','--from=0.4','--step=0.95',
              f'--zoom={zoom}',f'--facing={facing}','--bright']
        if control=='no-drape':
            args.append('--disable-drape-for-control')
        raw=render(f'{case}-{control}',base/'drape.tscn',args,True)
        samples=[json.loads(line.split(' ',1)[1]) for line in raw.splitlines() if line.startswith('NE221_SAMPLE ')]
        assert len(samples)==len(cast.split(','))*6 and {row['skin'] for row in samples}==set(cast.split(','))
        (base/f'{case}-{control}'/'samples.json').write_text(json.dumps(samples,indent=2)+'\n',encoding='utf-8')
