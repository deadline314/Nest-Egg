from pathlib import Path
import json,os,subprocess
root=Path.cwd();base=Path('D:/NestEggVerification/evidence-20261117/st8-current-close-20261118/ownership-tests-final');base.mkdir(exist_ok=False)
legacy=base/'legacy';legacy.mkdir()
for name in ['build_item_icons.py','item_icon_kit.py']:
    (legacy/name).write_bytes(subprocess.check_output(['git','show','56f1c19b0ac0d9ea57cf061dbc0aa3c000a808cd:tools/art/'+name]))
(legacy/'test_item_icon_ownership.py').write_bytes((root/'tools/art/test_item_icon_ownership.py').read_bytes())
results=[]
for name,script,cwd,wanted in [('legacy',legacy/'test_item_icon_ownership.py',legacy,1),('fixed',root/'tools/art/test_item_icon_ownership.py',root,0)]:
    cmd=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-X','utf8',str(script)];r=subprocess.run(cmd,cwd=cwd,capture_output=True)
    (base/(name+'.log')).write_bytes(r.stdout+r.stderr);assert r.returncode==wanted,(name,r.returncode)
    results.append({'version':name,'exit':r.returncode,'expected_exit':wanted,'command':cmd});print(name,r.returncode,(r.stdout+r.stderr).decode('utf-8',errors='replace')[-900:],flush=True)
(base/'result.json').write_text(json.dumps({'passed':True,'runs':results},indent=2)+'\n')
