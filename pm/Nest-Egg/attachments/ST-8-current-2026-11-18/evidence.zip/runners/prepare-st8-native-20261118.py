from pathlib import Path
import hashlib,json
root=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');out=Path('D:/NestEggVerification/evidence-20261117/st8-current-close-20261118/native-adapter');out.mkdir(exist_ok=False)
source='''extends "res://tools/screenshot.gd"
## Existing screenshot scenarios; release the actual level before exiting.
func _run() -> void:
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	if _scenario == "item_icons":
		await _run_item_icons()
	elif _scenario == "item_inventory":
		await _run_item_inventory()
	else:
		push_error("ST8 adapter accepts only the two existing item scenarios")
		get_tree().quit(2)
		return
	Story.reset_active_presentation(&"capture_cleanup")
	for node in get_children():
		if node is Level: node.queue_free()
	await _settle(15)
	await AudioRelease.settle(get_tree())
	print("ST8_ITEM_NATIVE_COMPLETE ", _scenario)
	get_tree().quit()
'''
(d/'work/st8_item_capture.gd').write_text(source,encoding='utf-8')
scene='[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/st8_item_capture.gd" id="1"]\n[node name="ItemCapture" type="Node"]\nscript = ExtResource("1")\n'
(d/'work/st8_item_capture.tscn').write_text(scene,encoding='utf-8');(out/'adapter.gd').write_text(source,encoding='utf-8');(out/'adapter.tscn').write_text(scene,encoding='utf-8')
(out/'source.json').write_text(json.dumps({'screenshot_sha256':hashlib.sha256((d/'tools/screenshot.gd').read_bytes()).hexdigest(),'scope':'inherits original item icon/inventory fixture; only controls end-of-capture release; no layout or item behavior override'},indent=2)+'\n')
print('Prepared private adapter; original screenshot tool unchanged.')
