from pathlib import Path
import contextlib,hashlib,importlib.util,io,json,re
from PIL import Image
root=Path.cwd();base=Path('D:/NestEggVerification/evidence-20261117/st8-current-close-20261118');out=base/'icon-audit-v3';out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('item_icon_source',root/'tools/art/build_item_icons.py');icons=importlib.util.module_from_spec(spec);spec.loader.exec_module(icons)
history=(root/'pm/ST/images/ST-8-current-validation/root-item-icons.txt').read_text(encoding='utf-8');entries=re.findall(r'^SHA256 (.+) ([0-9a-f]{64})$',history,re.M);assert len(entries)==51
changed=[name for name,sha in entries if hashlib.sha256((root/name).read_bytes()).hexdigest()!=sha]
assert set(changed)=={'tools\\art\\build_item_icons.py','art\\items\\icons\\mono_dagger.png','art\\items\\icons\\mono_dagger_hd.png'},changed
owners=icons.melee_icon_owners();assert {name:entry['id'] for name,entry in owners.items() if name in icons.ICONS}=={'mono_dagger':'melee_dagger'}
icons.ICON_DIR=str(out/'rebuilt-icons');icons.WORLD_DIR=str(out/'rebuilt-world')
with contextlib.redirect_stdout(io.StringIO()) as output:icons.main([])
(out/'rebuild.log').write_text(output.getvalue(),encoding='utf-8')
checked=[]
for directory,relative in [(Path(icons.ICON_DIR),'art/items/icons'),(Path(icons.WORLD_DIR),'art/items/world')]:
    for generated in sorted(directory.glob('*.png')):
        current=root/relative/generated.name
        with Image.open(current) as actual, Image.open(generated) as expected:
            assert actual.mode==expected.mode=='RGBA' and actual.size==expected.size and actual.tobytes()==expected.tobytes(),str(current)
        checked.append({'path':current.relative_to(root).as_posix(),'sha256':hashlib.sha256(current.read_bytes()).hexdigest(),'rebuilt_sha256':hashlib.sha256(generated.read_bytes()).hexdigest(),'producer':'registered adopted PNG master' if generated.stem.startswith('mono_dagger') else 'existing vector source'})
assert len(checked)==50
result={'passed':True,'catalog':len(icons.ICONS),'png_count':len(checked),'historical_unchanged_entries':48,'historical_changes':changed,'adopted_icon_source_commit':'a4adfb7b6df92b225acf64c608d74d1c484fc2eb','source_master_provenance':json.loads((root/'art_src/weapons/melee_dagger/source.json').read_text()),'original_generation_raw_available':False,'pixel_rebuilds_identical':50,'runtime_assets_unchanged':all(hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'] for row in checked),'assets':checked}
assert result['runtime_assets_unchanged'];(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['assets','source_master_provenance']}),flush=True)
