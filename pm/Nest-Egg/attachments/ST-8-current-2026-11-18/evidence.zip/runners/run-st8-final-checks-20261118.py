from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/st8-current-close-20261118');out=base/'final-checks';out.mkdir(exist_ok=False)
files=['tools/art/build_item_icons.py','tools/art/test_item_icon_ownership.py','.github/workflows/tests.yml','assets_src/pipeline/melee_weapons.json','art_src/weapons/melee_dagger/mono_dagger.png','art_src/weapons/melee_dagger/mono_dagger_hd.png','art_src/weapons/melee_dagger/source.json']
for name in files:
    p=d/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,p)
original=json.loads(Path('D:/NestEggVerification/evidence-20261117/ne240-first-chapter-current/source-candidate-v13.json').read_text())
changed=[name for name,sha in original.items() if hashlib.sha256((d/name).read_bytes()).hexdigest()!=sha]
assert set(changed)<=set(files),changed
paths=set(original)|set(files);snapshot=lambda:{p:hashlib.sha256((d/p).read_bytes()).hexdigest() for p in paths};source=snapshot();(out/'source.json').write_text(json.dumps(source,indent=2)+'\n')
env=os.environ.copy();env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='4',LOG_DIR=str(out/'shards'))
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
cases=[('ownership',['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-X','utf8','tools/art/test_item_icon_ownership.py']),('changed',['C:/Program Files/Git/bin/bash.exe','-c','python3() { python "$@"; }; export -f python3; tools/run_tests_changed.sh 56f1c19b0ac0d9ea57cf061dbc0aa3c000a808cd'])]
results=[]
for name,cmd in cases:
    p=out/name;p.mkdir();(p/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with (p/'raw.log').open('wb') as log:r=subprocess.run(cmd,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=2400)
    raw=(p/'raw.log').read_bytes();row={'name':name,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'errors':[l.decode(errors='replace') for l in raw.splitlines() if b'ERROR:' in l],'source_held':snapshot()==source};results.append(row);(out/'runs.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode('utf-8',errors='replace')[-2500:],flush=True);assert row['exit']==row['script_errors']==0 and not row['errors'] and row['source_held']
