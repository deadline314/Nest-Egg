from pathlib import Path
root=Path.cwd()
for source, old, new in [
 ('work/st8-ownership-red-green-final-20261118.py','ownership-tests-final','ownership-tests-release'),
 ('work/st8-icon-audit-v3-20261118.py','icon-audit-v3','icon-audit-release'),
 ('work/run-st8-final-checks-20261118.py','final-checks','final-checks-release')]:
    code=(root/source).read_text(encoding='utf-8').replace(old,new)
    exec(compile(code,source,'exec'),{'__name__':'__main__'})
print('DONE',flush=True)
