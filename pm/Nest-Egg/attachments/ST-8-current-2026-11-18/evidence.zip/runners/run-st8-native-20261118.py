from pathlib import Path
import json,os,subprocess
root=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/st8-current-close-20261118/native');base.mkdir(exist_ok=False)
for scenario in ['item_icons','item_inventory']:
    out=base/scenario;out.mkdir();env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
    cmd=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(d),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','--fixed-fps','60','res://work/st8_item_capture.tscn','--','--out='+str(out),'--scenario='+scenario]
    (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with (out/'raw.log').open('wb') as log:r=subprocess.run(cmd,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    raw=(out/'raw.log').read_bytes();result={'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'errors':[l.decode(errors='replace') for l in raw.splitlines() if b'ERROR:' in l],'pngs':len(list(out.glob('*.png')))};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(scenario,json.dumps(result),flush=True);print(raw.decode('utf-8',errors='replace')[-700:],flush=True);assert result['exit']==result['script_errors']==0 and not result['errors'] and result['pngs']>0
