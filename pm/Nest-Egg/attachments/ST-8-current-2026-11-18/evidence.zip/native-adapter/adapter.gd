extends "res://tools/screenshot.gd"
## Existing screenshot scenarios; release the actual level before exiting.
func _run() -> void:
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	if _scenario == "item_icons":
		await _run_item_icons()
	elif _scenario == "item_inventory":
		await _run_item_inventory()
	else:
		push_error("ST8 adapter accepts only the two existing item scenarios")
		get_tree().quit(2)
		return
	Story.reset_active_presentation(&"capture_cleanup")
	for node in get_children():
		if node is Level: node.queue_free()
	await _settle(15)
	await AudioRelease.settle(get_tree())
	print("ST8_ITEM_NATIVE_COMPLETE ", _scenario)
	get_tree().quit()
