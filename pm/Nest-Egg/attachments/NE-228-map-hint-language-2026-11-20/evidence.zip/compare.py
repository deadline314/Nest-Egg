from pathlib import Path
import json

folder = Path(__file__).resolve().parent
read = lambda file: json.loads((folder / file).read_bytes())
stock = read("original-v5-en/run.json")
before = stock["resolution"]["samples"]
assert stock["exit"] == 0 and not stock["errors"] and set(before) == {"booth", "reflect", "reflect-rebound"}
assert all(row["text"] == row["source"] and row["visible"] and row["fits"] for row in before.values())
assert before["reflect-rebound"]["keycaps"] == ["B"]
table = read("ch1_hint_text.json")
comparison = {}
for language in ("zh", "ja", "en"):
    result = read(f"candidate-v6-{language}/run.json")
    assert result["input_save"] == stock["input_save"]
    assert result["exit"] == 0 and not result["errors"] and result["resolution"]["failures"] == 0
    assert result["resolution"]["language"] == language
    rows = result["resolution"]["samples"]
    assert rows.keys() == before.keys()
    for name, row in rows.items():
        assert row["position"] == before[name]["position"] and row["source"] == before[name]["source"]
        assert row["near"] and row["visible"] and row["fits"]
        expected = row["source"] if language == "zh" else table[row["source"]][language]
        assert row["text"] == expected and row["display_text"] != ""
    assert rows["reflect"]["text"] == rows["reflect-rebound"]["text"]
    assert rows["reflect"]["keycaps"] == ["右鍵"] and rows["reflect-rebound"]["keycaps"] == ["B"]
    comparison[language] = rows
(folder / "comparison.json").write_text(json.dumps(comparison, ensure_ascii=False, indent=2) + "\n", "utf-8")
print({lang: len(rows) for lang, rows in comparison.items()})
