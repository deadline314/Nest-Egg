extends "res://tools/ch1_flow_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
var _store := ""
var _locale := "en"
var _main: Node
var _actors := {}


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--locale="):
			_locale = arg.trim_prefix("--locale=")
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_check(Story.set_language(_locale), "sets the requested real story language")
	Settings.set_ui_text_scale(1.2)
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.player != null and _level.data.id == &"ch1_street", "continues the original harbor street save")
	if _level == null or _level.player == null:
		_finish_hints()
		return
	_level._next_story_trigger = _level._layout.story_triggers.size()
	_level.player.health.grant_invulnerability(30.0)
	for node: Node in get_tree().get_nodes_in_group(&"enemies"):
		node.set_physics_process(false)
	AimInput.set_virtual_gamepad(_level.player, true)
	await _visit("booth", 1)
	await _visit("reflect", 3)
	_check(InputBindings.set_code(&"block", 0, KEY_B) == &"" and InputBindings.get_code(&"block", 0) == KEY_B, "remaps block through the real binding system")
	await _visit("reflect-rebound", 3)
	Input.action_release(&"aim_left")
	Input.action_release(&"aim_right")
	AimInput.set_virtual_gamepad(_level.player, false)
	_level.camera.release_presentation_focus(self)
	_finish_hints()


func _visit(name: String, index: int) -> void:
	var source := _level.data.hints[index]
	var sign: HintSign
	for child: Node in _level._entities.get_children():
		if child is HintSign and child.text == source:
			sign = child
			break
	_check(sign != null, "original hint sign exists: "+name)
	if sign == null:
		return
	var prompt: WorldPrompt
	for child: Node in sign.get_children():
		if child is WorldPrompt:
			prompt = child
			break
	_check(prompt != null and prompt.keycaps, "original hint sign has the regular WorldPrompt")
	if prompt == null:
		return
	for other: WorldPrompt in PromptLayout._prompts:
		other.enabled = other == prompt
	PromptLayout.invalidate()
	var right_of_sign := index == 3
	_level.player.global_position = sign.global_position + Vector2(55.0 if right_of_sign else -18.0, -1.0)
	_level.player.velocity = Vector2.ZERO
	Input.action_release(&"aim_right" if right_of_sign else &"aim_left")
	Input.action_press(&"aim_left" if right_of_sign else &"aim_right")
	await _settle(20)
	var camera := _level.camera
	var focus := sign.global_position + Vector2(0.0, -44.0)
	camera.release_presentation_focus(self)
	_check(camera.acquire_presentation_focus(self, focus), "center the fixture on the existing world sign")
	camera.global_position = focus
	camera.reset_smoothing()
	camera.force_update_scroll()
	await _settle(36)
	await RenderingServer.frame_post_draw
	var rect := get_viewport().get_canvas_transform() * Rect2(prompt.base_rect().position + prompt._nudge, prompt.base_rect().size)
	var caps := PackedStringArray()
	var content_fits := true
	for item: Dictionary in prompt._segments:
		if item["cap"]:
			caps.append(item["text"])
		content_fits = content_fits and item["x"] + item["w"] <= prompt._box.size.x - WorldPrompt.PADDING.x * 2.0 + 0.5
	var visible := prompt.is_showing() and prompt._alpha > 0.95
	var fits := get_viewport().get_visible_rect().grow(0.5).encloses(rect) and content_fits
	_actors[name] = {"source":source,"text":prompt.text,"display_text":prompt._display_text,"visible":visible,"fits":fits,
		"keycaps":Array(caps), "position":str(sign.global_position),"panel":str(rect), "player":str(_level.player.global_position),
		"near":prompt._player_near(),"layout_allows":prompt._layout_allowed,"alpha":prompt._alpha}
	_check(visible and fits and CAPTURE.image(get_viewport()).save_png(_out_dir.path_join(name+".png")) == OK, "displays the full original sign: "+name)


func _finish_hints() -> void:
	var file := FileAccess.open(_out_dir.path_join("hints.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures":_failures,"language":Story.language,"samples":_actors},"  ")+"\n")
	file.close()
	_main.call("_quit",0 if _failures==0 else 1)
