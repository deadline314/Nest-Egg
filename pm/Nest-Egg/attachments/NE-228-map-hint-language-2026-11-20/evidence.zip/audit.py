from pathlib import Path
import json
import re

project = Path.cwd()
scope = Path(__file__).resolve().parent
translated = project / "data/levels/ch1_hint_text.json"
translations = json.loads(translated.read_bytes())
source = {}
for file in sorted((project / "data/levels").glob("ch1_*.tres")):
    hit = re.search(r"^hints = PackedStringArray\((.+)\)$", file.read_text("utf-8"), re.M)
    if hit is None:
        continue
    for text in json.loads("[" + hit[1] + "]"):
        source.setdefault(text, []).append(file.stem)
assert set(translations) == set(source), (set(translations) - set(source), set(source) - set(translations))
for original, locales in translations.items():
    assert set(locales) == {"en", "ja"}
    keys = re.findall(r"\{\w+\}", original)
    for language, text in locales.items():
        assert isinstance(text, str) and text.strip() and text != original, (original, language)
        assert keys == re.findall(r"\{\w+\}", text), (original, language, text)
result = {"unique_hints": len(source), "translations": len(source) * 2,
          "authored_occurrences": sum(map(len, source.values())), "sources": source}
(scope / "catalog-audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", "utf-8")
print({"unique_hints": len(source), "translations": len(source) * 2, "occurrences": result["authored_occurrences"]})
