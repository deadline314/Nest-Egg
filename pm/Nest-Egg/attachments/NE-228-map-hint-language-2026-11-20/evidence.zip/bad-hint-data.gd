extends Node


func _ready() -> void:
	var source := (load("res://data/levels/ch1_booth_alley.tres") as LevelData).hints[0]
	var english := HintSign.localized_text(source, "en")
	var entry: Dictionary = HintSign._translations[source]
	var ja: Variant = entry["ja"]
	var en: Variant = entry["en"]
	entry["ja"] = 27
	var prefers_english := HintSign.localized_text(source, "ja") == english
	entry["en"] = false
	var returns_source := HintSign.localized_text(source, "ja") == source
	HintSign._translations[source] = "invalid catalog row"
	var broken_row := HintSign.localized_text(source, "en") == source
	HintSign._translations[source] = entry
	entry["ja"] = ja
	entry["en"] = en
	var restored: bool = HintSign.localized_text(source, "ja") == ja
	var checked: bool = prefers_english and returns_source and broken_row and restored
	print("WORLD_HINT_FALLBACKS ", JSON.stringify({"english":prefers_english,"source":returns_source,"invalid_row":broken_row,"restored":restored}))
	get_tree().quit(0 if checked else 1)
