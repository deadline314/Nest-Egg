from pathlib import Path
from subprocess import check_output
import sys

base=Path(__file__).resolve().parent
related=base/'armor-visibility.gd'
code=related.read_text(encoding='utf-8')
initializer='if not _diagnostic_include_part.is_empty():'
assert code.count(initializer)==1
code=code.replace(initializer,'if _damaged and joint == "waist":\n\t\t\t\t\t\t\tkeep.assign(["torso_dmg", "pelvis_dmg"])\n\t\t\t\t\t\t'+initializer)
(base/'damaged-pair.gd').write_text(code,encoding='utf-8')
path=base/'armor-visibility.tscn'
content=path.read_text(encoding='utf-8')
assert 'armor-visibility.gd' in content
(base/'damaged-pair.tscn').write_text(content.replace('armor-visibility.gd','damaged-pair.gd'),encoding='utf-8')
filepath='art/characters/rin/parts/pelvis_dmg.png'
old_path=base/'damaged-control.png'
old_path.write_bytes(check_output(['git','show',f'HEAD:{filepath}']))
prefix=(base/'native.py').read_text(encoding='utf-8').split("paired=")[0]
exec(prefix)
for name,extra in (
    ('damaged-pair-control',[f'--diagnostic-part-texture=pelvis_dmg:{old_path.as_posix()}']),
    ('damaged-pair-after', []),
):
    render(name,base/'damaged-pair.tscn',
           ['--out={out}','--chars=rin','--joints=waist','--frames=120','--zooms=1,3.4','--pair-only','--damaged',*extra],True)
    run([sys.executable,str(shared/'tools/check_joint_frames.py'),str(base/name)],cwd=shared,check=False)
