extends Node


func _ready() -> void:
	var dir := "D:/NestEggVerification/evidence-20261120-ne222-waist/draft/art/characters/rin/parts"
	for part: String in ["pelvis", "pelvis_dmg"]:
		var before := Image.load_from_file(ProjectSettings.globalize_path("res://art/characters/rin/parts/%s.png" % part))
		var before_normal := Image.load_from_file(ProjectSettings.globalize_path("res://art/characters/rin/parts/%s_n.png" % part))
		var reconstructed := NormalMapMaker.make(before)
		if reconstructed.get_size() != before_normal.get_size() or reconstructed.get_data() != before_normal.get_data():
			push_error("published normals did not match the original maker for " + part)
			get_tree().quit(1)
			return
		var after := Image.load_from_file(dir.path_join(part+".png"))
		var new_normal := NormalMapMaker.make(after)
		if new_normal.save_png(dir.path_join(part+"_n.png")) != OK:
			push_error("could not write the staged normal for " + part)
			get_tree().quit(1)
			return
		print(part, " existing normal reproduced and candidate generated ", new_normal.get_size())
	get_tree().quit()