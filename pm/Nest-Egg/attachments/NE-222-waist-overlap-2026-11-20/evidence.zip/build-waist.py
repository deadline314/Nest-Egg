from pathlib import Path
from hashlib import sha256
import json
import sys
import numpy as np
from PIL import Image

root=Path.cwd()
base=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'tools/comfyui'))
from cut_layers import part_transform, render_part
spec=json.loads((root/'tools/comfyui/specs/rin_side.json').read_bytes())
k=spec['tex_px_per_wp']/spec['illustration_px_per_wp']
joints={name:np.array(point)*k for name,point in spec['joints'].items()}
assert k==1
manifest={}
paths=[]
for name in ('pelvis','pelvis_dmg'):
    source_name=f'art_src/characters/rin_field/07_refined/{name}.png'
    override=f'art_src/characters/rin_field/overrides/refined/{name}.png'
    output=f'art/characters/rin/parts/{name}.png'
    paths.extend([override,output])
    assert not (root/override).is_file()
    img=Image.open(root/source_name).convert('RGBA')
    assert img.size==(1056,1536)
    src=np.asarray(img)
    spec_part=spec['parts'][name]
    transform=part_transform(img,spec_part,joints,k)
    orig=render_part(img,transform,k)
    assert np.array_equal(orig,np.asarray(Image.open(root/output).convert('RGBA')))
    assert np.array_equal(transform[0][:,:2],np.eye(2))
    left,top=map(int,transform[0][:,2])
    new=src.copy()
    for y in range(8,13):
        for x in range(45,59):
            sy,sx=top+y,left+x
            if src[sy,sx,3]<128 and src[sy,sx+1,3]>src[sy,sx,3]:
                new[sy,sx]=src[sy,sx+1]
    diff=np.any(src!=new,axis=2)
    assert diff.sum()==5
    assert np.array_equal(src[src[:,:,3]>=128],new[src[:,:,3]>=128])
    src_img=Image.fromarray(new)
    after=part_transform(src_img,spec_part,joints,k)
    assert np.array_equal(transform[0],after[0]) and transform[1:3]==after[1:3] and np.array_equal(transform[3],after[3])
    final=render_part(src_img,after,k)
    assert np.count_nonzero(np.any(final!=orig,axis=2))==5
    if name=='pelvis':
        assert np.array_equal(final,np.asarray(Image.open(base/'pelvis-1.png').convert('RGBA')))
    for target,image in ((override,src_img),(output,Image.fromarray(final))):
        file=base/'draft'/target
        file.parent.mkdir(exist_ok=True,parents=True)
        image.save(file)
    yy,xx=np.where(diff)
    manifest[name]={'original_refined_sha256':sha256((root/source_name).read_bytes()).hexdigest(),
        'original_native_sha256':sha256((root/output).read_bytes()).hexdigest(),
        'override_sha256':sha256((base/'draft'/override).read_bytes()).hexdigest(),
        'pivot':after[3].tolist(),'size':[after[1],after[2]],'changed_pixels':int(diff.sum()),
        'changed_source_box':[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]}
(base/'draft-paths.json').write_text(json.dumps(paths, indent=2)+'\n')
(base/'material.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest))
