from collections import Counter
from pathlib import Path
import json

base=Path(__file__).resolve().parent
prior=base.parent/'evidence-20261120-ne222-back-shoulder'

def read(folder):
    report=json.loads((folder/'report.json').read_bytes())
    rows=report['failures']
    hard={(r['joint'],r['pose'],r['zoom'],r['facing'],r['frame']):r for r in rows
          if r['enclosed_pixels'] or r['loose_pieces'] or r['center_alpha']<128}
    return report['samples'],hard

report={}
for context,before,after in (
    ('paired',prior/'final-neighbors',base/'release-paired'),
    ('worn',base/'before-worn',base/'release-worn'),
    ('damaged',base/'before-damaged',base/'release-damaged'),
):
    count,orig=read(before)
    now,updated=read(after)
    assert count==now
    old=set(orig)
    new=set(updated)
    lost=old-new
    fresh=new-old
    inc=[k for k in (old&new) if updated[k]['enclosed_pixels']>orig[k]['enclosed_pixels']]
    report[context]={'samples':count,'baseline':dict(Counter(k[0] for k in old)),
        'candidate':dict(Counter(k[0] for k in new)),
        'fixed':dict(Counter(k[0] for k in lost)),
        'new':dict(Counter(k[0] for k in fresh)),
        'increased':dict(Counter(k[0] for k in inc))}
    if fresh or inc:
        print('first unexpected cases', sorted(fresh)[:8], sorted(inc)[:8])
print(json.dumps(report,indent=2,ensure_ascii=False))
(base/'comparison-release.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(not row['new'] and not row['increased'] for row in report.values())
assert report['paired']['baseline'].get('waist')==454
assert report['paired']['candidate'].get('waist',0)==0
