from pathlib import Path
from hashlib import sha256
from subprocess import run
from shutil import copyfile
import json
import os
import sys

base = Path(__file__).resolve().parent
shared = base.parent/'ne218-baseline-20261117'
root=Path.cwd()
python = Path(sys.executable)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def render(case, scene, args, fixed):
    out=base/case
    out.mkdir(exist_ok=False)
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        var = out/'profile'/key
        var.mkdir(parents=True)
        env[key]=str(var)
    command = [str(python),str(shared/'tools/comfyui/gpu_lock.py'),'--',engine,
               '--path',str(shared),'--resolution','1280x720','--position','10,90',
               '--rendering-method','forward_plus','--rendering-driver','vulkan']
    if fixed:
        command.extend(('--fixed-fps','60'))
    command.append(str(scene))
    command.extend(('--',*[a.replace('{out}',out.as_posix()) for a in args]))
    (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=650)
    (out/'exit.txt').write_text(str(result.returncode)+'\n',encoding='utf-8')
    raw=(out/'raw.log').read_text(encoding='utf-8')
    print(case,result.returncode,len(raw),flush=True)
    assert result.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw
    return raw







import numpy as np
from PIL import Image
source=root/'art/characters/rin/parts/pelvis.png'
art=np.array(Image.open(source).convert('RGBA'))
for offset in (0,1,2,3):
    result=art.copy()
    for y in range(6,16):
        step=round(offset*max(0,1-abs(y-10)/6))
        for x in range(45,59):
            if art[y,x,3] < 128 and art[y,x+step,3] > art[y,x,3]:
                result[y,x] = art[y,x+step]
    image=base/f'pelvis-{offset}.png'
    Image.fromarray(result).save(image)
    count=np.count_nonzero(np.any(art!=result,axis=2))
    print(f'extension {offset}: {count} pixels',flush=True)
    name=f'extension-{offset}'
    flags=['--out={out}','--chars=rin','--joints=waist','--frames=40','--zooms=3.4',
           f'--diagnostic-part-texture=armor_pelvis:{image.as_posix()}']
    render(name,base/'alpha-pilot.tscn',flags,True)
    run([sys.executable,str(shared/'tools/check_joint_frames.py'),str(base/name)],cwd=shared,check=False)