from pathlib import Path
from collections import Counter
import json
import numpy as np
from PIL import Image

root=Path.cwd()
base=Path(__file__).resolve().parent
for index,pose,point in ((2,'block',(28,34)),(2,'run',(28,34)),(7,'crouch',(28,34)),(19,'idle',(28,34))):
    doc=json.loads((base/f'trace-{index}/frames.json').read_bytes())
    row=next(r for r in doc if r['pose']==pose)
    cell=row['cells'][0]
    pix=np.array(point,float)+.5+64-cell['radius']
    print(pose, 'image point',pix.tolist())
    for entry in cell['geometry_sample']:
        part=entry['part']
        mat=np.array(entry['to_cell'])
        local=np.linalg.solve(mat[:,:2],pix-mat[:,2])
        if 'rect_origin' in entry:
            uv=local-np.array(entry['rect_origin'])
        else:
            poly=np.asarray(entry.get('vertices'))
            coords=np.asarray(entry.get('uv'))
            uv=None
            for tri in entry['triangles']:
                a,b,c=poly[tri[:3]]
                w=np.linalg.solve(np.array((b-a,c-a)).T,local-a)
                if min(w[0],w[1],1-w.sum())>=-.0001:
                    uv=coords[tri[0]]*(1.0-w.sum())+coords[tri[1]]*w[0]+coords[tri[2]]*w[1]
                    break
        src=root/entry['texture'].removeprefix('res://')
        if uv is None or not src.is_file():
            print(part,'outside mesh',entry['texture'])
            continue
        alpha=np.array(Image.open(src).convert('RGBA'))[:,:,3]
        xy=np.round(uv-.5).astype(int)
        win=alpha[max(0,xy[1]-3):xy[1]+4,max(0,xy[0]-3):xy[0]+4] if min(xy)>=-3 else np.array([])
        print(part,'source',entry['texture'],'UV',np.round(uv,2).tolist(),'nearby',Counter(win.flat) if win.size else None)
