from pathlib import Path
from collections import Counter
import json

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

base=Path(__file__).resolve().parent

def rows(name):
    doc=json.loads((base/name/'frames.json').read_bytes())
    return {row['pose']:row for row in doc if row['zoom']==3.4}

def crop(name,pose,frame):
    row=groups[name][pose]
    match=next(c for c in row['cells'] if c['joint']=='waist' and c['facing']==1)
    x,y,w,h=match['rect']
    radius=11
    region=(x+w//2-radius, y+h//2-radius, x+w//2+radius, y+h//2+radius)
    file=base/name/row['samples'][frame]['file']
    return Image.open(file).convert('RGBA').crop(region).copy()

def closed(image):
    solid=np.asarray(image)[:,:,3]>=128
    return ndimage.binary_fill_holes(solid,structure=np.ones((3,3))) & ~solid

groups={key:rows(key) for key in ('before-worn','release-worn')}
font=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc',22)
sheet=Image.new('RGB',(614,652),(30,29,38))
labels=ImageDraw.Draw(sheet)
labels.text((28,16),'修正前',font=font,fill='#faf2f6')
labels.text((328,16),'修正後',font=font,fill='#faf2f6')
examples=[]
for row,mode,title,pose,frame in ((0,'worn','穿外套待機','idle',19),(1,'worn','穿外套蹲姿','crouch',7)):
    before=f'before-{mode}'
    after=f'release-{mode}'
    a=crop(before,pose,frame)
    b=crop(after,pose,frame)
    resolved=closed(a) & (np.asarray(b)[:,:,3]>=128)
    yy,xx=np.nonzero(resolved)
    assert len(xx)>0,(mode,pose,frame)
    examples.append({'mode':mode,'pose':pose,'frame':frame,'pixels':list(map(list,zip(xx.tolist(),yy.tolist())))})
    py=row*294+54
    for col,picture in enumerate((a,b)):
        img=Image.alpha_composite(Image.new('RGBA',a.size,(110,104,120,255)),picture).convert('RGB')
        large=img.resize((264,264),Image.Resampling.NEAREST)
        mark=ImageDraw.Draw(large)
        for x,y in zip(xx,yy):
            mark.rectangle((int(x*12-2),int(y*12-2),int(x*12+14),int(y*12+14)),outline='#fbd889',width=2)
        sheet.paste(large,(28+300*col,py))
    labels.text((28,py+263),title,font=font,fill='#faf2f6')
sheet.save(base/'waist-seams.png')
(base/'examples.json').write_text(json.dumps(examples,indent=2)+'\n')
print(examples)
