extends SceneTree
## Arranged AudioStreamPlayer envelope observation; not listening or gameplay acceptance.

class Plot:
	extends Node2D
	var rows: Array = []
	func _draw() -> void:
		draw_rect(Rect2(0, 0, 640, 360), Color(0.045, 0.06, 0.08))
		var colors := [Color(0.3, 0.9, 0.9), Color(0.95, 0.7, 0.3), Color(0.8, 0.5, 0.95)]
		for i in rows.size():
			var top := 60.0 + i * 88.0
			draw_string(ThemeDB.fallback_font, Vector2(20, top), str(rows[i]["mode"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, colors[i])
			for db in [-8, -4, 0]:
				var y := top + 18.0 + float(-db) * 5.0
				draw_line(Vector2(150, y), Vector2(610, y), Color(0.2, 0.25, 0.3))
				draw_string(ThemeDB.fallback_font, Vector2(120, y + 3), str(db), HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.7, 0.75, 0.8))
			var previous := Vector2.INF
			for point in rows[i]["samples"]:
				var pos := Vector2(150 + float(point["seconds"]) * 460.0, top + 18.0 + float(-point["duck_db"]) * 5.0)
				if previous.is_finite(): draw_line(previous, pos, colors[i], 2.0, true)
				previous = pos
			draw_string(ThemeDB.fallback_font, Vector2(150, top + 78), "0", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.7, 0.75, 0.8))
			draw_string(ThemeDB.fallback_font, Vector2(585, top + 78), "1.0 s", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.7, 0.75, 0.8))
			draw_string(ThemeDB.fallback_font, Vector2(290, top + 78), "monotonic seconds", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.7, 0.75, 0.8))

var _out := ""
var _sfx

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	_run.call_deferred()

func _run() -> void:
	await process_frame
	_sfx = root.get_node_or_null("Sfx")
	if _sfx == null:
		printerr("DUCK_RELEASE_PROBE: project autoload missing")
		quit(2)
		return
	root.process_mode = Node.PROCESS_MODE_ALWAYS
	var plot := Plot.new()
	plot.process_mode = Node.PROCESS_MODE_ALWAYS
	root.add_child(plot)
	var title := Label.new()
	title.position = Vector2(16, 10)
	title.text = "AUDIO ENVELOPE LAB / ENGINE VALUES / NOT LISTENING ACCEPTANCE"
	title.add_theme_font_size_override("font_size", 12)
	plot.add_child(title)
	var subtitle := Label.new()
	subtitle.position = Vector2(16, 30)
	subtitle.text = "hold 0.50 s / release 0.25 s / software Forward+ when windowed"
	subtitle.add_theme_font_size_override("font_size", 11)
	plot.add_child(subtitle)
	var prior_scale := Engine.time_scale
	var prior_paused := paused
	var failures := 0
	for mode in ["normal", "slowmo 0.02", "paused"]:
		Engine.time_scale = 0.02 if mode == "slowmo 0.02" else 1.0
		paused = mode == "paused"
		_sfx.stop_all()
		_sfx._players[0].stream = _sfx._streams[&"explosion"]
		_sfx._voice_priority[0] = 1
		_sfx._voice_base_db[0] = -2.0
		_sfx._players[0].play()
		var started := Time.get_ticks_msec()
		_sfx._voice_end_msec[0] = started + 3000
		_sfx._start_duck(-8.0, 0.5, 9, started)
		var row := {"mode": mode, "time_scale": Engine.time_scale, "paused": paused, "samples": []}
		plot.rows.append(row)
		while Time.get_ticks_msec() - started < 1000:
			row["samples"].append({"seconds": float(Time.get_ticks_msec() - started) / 1000.0,
				"duck_db": _sfx._duck_db, "voice_db": _sfx._players[0].volume_db})
			plot.queue_redraw()
			await create_timer(0.015, true, false, true).timeout
		row["end_duck_db"] = _sfx._duck_db
		row["end_voice_db"] = _sfx._players[0].volume_db
		row["passed"] = is_zero_approx(_sfx._duck_db) and is_equal_approx(_sfx._players[0].volume_db, -2.0)
		if not row["passed"]: failures += 1
	Engine.time_scale = prior_scale
	paused = prior_paused
	_sfx.stop_all()
	DirAccess.make_dir_recursive_absolute(_out)
	var file := FileAccess.open(_out.path_join("envelope.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"kind": "arranged audio envelope fixture; engine parameter measurements, not audible quality or a playthrough",
		"engine": Engine.get_version_info().string, "adapter": RenderingServer.get_video_adapter_name(),
		"sfx_sha256": FileAccess.get_sha256("res://autoload/sfx.gd"), "rows": plot.rows, "failures": failures}, "  ") + "\n")
	file.close()
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		var capture := load("res://tools/viewport_capture.gd")
		if capture.image(root).save_png(_out.path_join("envelope.png")) != OK: failures += 1
	print("DUCK_RELEASE_PROBE failures=", failures)
	quit(1 if failures else 0)
