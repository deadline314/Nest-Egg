from pathlib import Path
import os,subprocess,hashlib,json
b=Path(__file__).parent;p=b/'audio';source=p/'autoload/sfx.gd';candidate=(b/'ne154-sfx-monotonic-candidate.gd').read_bytes()
base=subprocess.check_output(['git','show','223f936a:autoload/sfx.gd'],cwd=p)
records=[]
def run(name,engine):
 env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',GODOT=str(engine),LOG_DIR=str(b/name))
 with (b/(name+'.log')).open('w') as output:rc=subprocess.run(['tools/run_tests_parallel.sh','--only=FeelSuite','1'],cwd=p,env=env,stdout=output,stderr=subprocess.STDOUT).returncode
 (b/(name+'.exit')).write_text(str(rc));records.append({'name':name,'exit':rc,'sfx_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'test_sha256':hashlib.sha256((p/'tests/suite/test_feel.gd').read_bytes()).hexdigest()});(b/'ne154-clock-verification.json').write_text(json.dumps(records,indent=2)+'\n');print(name,rc,flush=True);return rc
try:
 source.write_bytes(base)
 assert run('ne154-clock-red-final','/workspace/Nest-Egg/work/ne279/Godot_v4.7-stable_linux.x86_64')!=0, 'negative control unexpectedly passed'
finally:source.write_bytes(candidate)
assert run('ne154-clock-green-ci','/workspace/Nest-Egg/work/ne279/Godot_v4.7-stable_linux.x86_64')==0
assert run('ne154-clock-green-472',b/'godot472/Godot_v4.7.2-stable_linux.x86_64')==0
assert source.read_bytes()==candidate
(b/'ne154-clock-verified').write_text('same 300ms monotonic interval, original assertions unchanged; old product fails negative controls, final product passes both engines\n')
