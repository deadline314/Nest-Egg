import os,sys
from pathlib import Path
os.environ["NE_NATIVE_SCRIPT"]="1"
os.execv(sys.executable,[sys.executable,str(Path(__file__).with_name("native.py")),*sys.argv[1:]])
