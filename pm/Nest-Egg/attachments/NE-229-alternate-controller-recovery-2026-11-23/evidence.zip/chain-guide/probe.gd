extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const COPY := {"zh": ["掙脫", "鎖鏈"], "ja": ["抜け出す", "鎖"], "en": ["break free", "chain"]}


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	add_child(LightKit.create_environment())
	Settings.use_storage("user://chain_guide_probe.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	Story.auto_skip = true
	Enemy.activation_culling_enabled = false
	var args := OS.get_cmdline_user_args()
	for language: String in COPY:
		await _case(language, args[0] if args.size() == 1 else "-")
	await _finish()


func _case(language: String, screenshot: String) -> void:
	Story.set_language(language)
	InputBindings.reset_to_defaults()
	InputBindings.set_code(&"dash", 0, KEY_KP_7)
	var key := InputEventKey.new()
	key.keycode = KEY_H
	key.physical_keycode = KEY_H
	key.pressed = true
	Input.parse_input_event(key)
	Input.flush_buffered_events()
	var key_release := key.duplicate() as InputEventKey
	key_release.pressed = false
	Input.parse_input_event(key_release)
	Input.flush_buffered_events()
	var suite := StrikeEnemiesSuite.new(self)
	var enemy := await suite._setup("chain_hook", 110.0)
	var player := suite.level.player
	_check(await suite.wait_state(enemy, &"reel", 500), "%s original hook reaches the player" % language)
	var banner := suite.level.hud.toast_banner
	var first_code := InputBindings.primary_label(&"dash")
	var message: Array = COPY[language]
	_check(not InputBindings.using_gamepad and _contains_guide(banner._label.text, first_code, message),
		"%s localized escape instructions show the rebound keyboard key" % language)
	var event := InputEventJoypadMotion.new()
	event.axis = JOY_AXIS_RIGHT_X
	event.axis_value = 0.8
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await _frames(2)
	var pad_code := InputBindings.primary_label(&"dash")
	_check(InputBindings.using_gamepad and pad_code != first_code and _contains_guide(banner._label.text, pad_code, message),
		"%s the same escape guide shows the active gamepad binding" % language)
	var centered := event.duplicate() as InputEventJoypadMotion
	centered.axis_value = 0.0
	Input.parse_input_event(centered)
	Input.flush_buffered_events()
	_check(await suite._wait_for_pull_steps(player, 2), "%s sampled an active pull before the escape action" % language)
	if language == "en" and screenshot.is_absolute_path():
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(screenshot) == OK, "native guide capture")
	var dash := InputEventJoypadButton.new()
	dash.button_index = InputBindings.get_joy_button(&"dash") as JoyButton
	dash.pressed = true
	dash.pressure = 1.0
	Input.parse_input_event(dash)
	Input.flush_buffered_events()
	await suite.physics_frames(3)
	var dash_release := dash.duplicate() as InputEventJoypadButton
	dash_release.pressed = false
	dash_release.pressure = 0.0
	Input.parse_input_event(dash_release)
	Input.flush_buffered_events()
	_check(not player.is_pulled(), "%s the displayed dash binding really breaks free" % language)
	await suite._finish(enemy)


func _contains_guide(text: String, key: String, message: Array) -> bool:
	return text.contains(key) and text.contains(message[0]) and text.contains(message[1])
