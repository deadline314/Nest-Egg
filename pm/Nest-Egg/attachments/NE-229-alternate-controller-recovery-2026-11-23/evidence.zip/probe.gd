extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const LEVEL := preload("res://data/levels/ch1_warehouse.tres")
const ACTIVE_PAD := 991
const SPARE_PAD := 992
const LATEST_PAD := 993


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://alternate_pad_recovery.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.set_language("en")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(LEVEL)
	add_child(level)
	await _frames(35)
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		enemy.set_physics_process(false)
	_check(is_instance_valid(level.player) and not get_tree().paused, "actual warehouse gameplay is running")
	# Isolate this process's three simulated connections from any physical pad.
	for physical_pad: int in Input.get_connected_joypads():
		Input.joy_connection_changed.emit(physical_pad, false)
	Input.joy_connection_changed.emit(SPARE_PAD, true)
	Input.joy_connection_changed.emit(ACTIVE_PAD, true)
	await _button(ACTIVE_PAD, JOY_BUTTON_X)
	_check(InputBindings.using_gamepad and InputBindings.active_device == ACTIVE_PAD, "original pad is the active input device")
	Input.action_press(&"shoot")
	Input.joy_connection_changed.emit(ACTIVE_PAD, false)
	await _frames(4)
	var prompt := InputBindings._recovery_prompt
	_check(is_instance_valid(prompt) and get_tree().paused and GameplayLock.is_locked(), "loss of active pad pauses the original player")
	if not is_instance_valid(prompt):
		await _finish()
		return
	_check(not Input.is_action_pressed(&"shoot"), "loss releases the active trigger")
	_check(prompt._title.text != "Controller disconnected", "already connected spare pad is shown as available")
	Input.joy_connection_changed.emit(LATEST_PAD, true)
	await _frames(3)
	_check(InputBindings._recovery_prompt == prompt and get_tree().paused, "a second connection neither replaces the modal nor resumes")
	Input.joy_connection_changed.emit(LATEST_PAD, false)
	await _frames(3)
	_check(prompt._title.text != "Controller disconnected", "losing the latest connection still shows the other available pad")
	_check(get_viewport().gui_get_focus_owner() == prompt.resume_button, "pad changes preserve recovery focus")
	var args := OS.get_cmdline_user_args()
	if args.size() == 1 and args[0].is_absolute_path():
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(args[0]) == OK, "native recovery panel captured")
	Input.joy_connection_changed.emit(SPARE_PAD, false)
	await _frames(3)
	_check(prompt._title.text == "Controller disconnected" and get_tree().paused, "losing the last spare shows disconnected and keeps the lock")
	Input.joy_connection_changed.emit(SPARE_PAD, true)
	await _frames(3)
	_check(prompt._title.text != "Controller disconnected" and get_tree().paused, "reconnection is reflected but requires consent")
	await _button(SPARE_PAD, JOY_BUTTON_A)
	_check(not InputBindings.is_controller_interrupted() and not get_tree().paused and not GameplayLock.is_locked(),
		"the remaining pad deliberately resumes the level")
	_check(InputBindings.active_device == SPARE_PAD and not Input.is_action_pressed(&"jump"),
		"confirmation switches to the spare pad without leaking a jump")
	_check(InputBindings._recovery_prompt == null and InputBindings._recovery_layer == null, "recovery releases only its own panel")
	level.queue_free()
	await _frames(5)
	await _finish()


func _button(device: int, button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.device = device
	event.button_index = button
	event.pressed = true
	event.pressure = 1.0
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await _frames(3)
	var release := event.duplicate() as InputEventJoypadButton
	release.pressed = false
	release.pressure = 0.0
	Input.parse_input_event(release)
	Input.flush_buffered_events()
	await _frames(3)


func _frames(count: int) -> void:
	for i in count:
		await get_tree().process_frame
