extends "res://tools/melee_art_probe.gd"


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://melee_emission_visual_audit.cfg")
	super._ready()


func open_arena(lighting_path: String, player_tile := 12.0, base_data: LevelData = null) -> void:
	var data := base_data if base_data != null else NewEnemiesSuite.arena_data()
	data.rain = false
	await super.open_arena(lighting_path, player_tile, data)


func _perf() -> void:
	var camera := get_viewport().get_camera_2d()
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * 3.0
	AimInput.using_gamepad = true
	AimInput.set_virtual_gamepad(player, true)
	var records := {}
	for id in WEAPONS:
		var weapon := load("res://data/weapons/melee/melee_%s.tres" % id) as WeaponData
		for facing: int in [1, -1]:
			var suffix := "%s-%s" % [id, "right" if facing > 0 else "left"]
			Settings.set_reduce_flashes(facing < 0)
			Settings.set_reduce_ui_motion(facing < 0)
			await _arm(weapon, camera)
			AimInput._last_stick_dir = Vector2(facing, 0.0)
			player.facing = facing
			await settle(20)
			await RenderingServer.frame_post_draw
			records[suffix + "-idle"] = _record(suffix + "-idle")
			if not player._try_melee():
				push_error("Cannot start real melee animation for " + suffix)
				_failures += 1
				continue
			var expected: Array[float] = [0.28, 0.50, 0.79]
			for index in 110:
				await RenderingServer.frame_post_draw
				if expected.is_empty() or player.melee_pose().is_empty():
					break
				if player.melee_pose_progress() >= expected[0]:
					var name := "%s-%02d" % [suffix, int(expected.pop_front() * 100.0)]
					records[name] = _record(name)
			if not expected.is_empty():
				push_error("Missing trial phases for " + suffix)
				_failures += 1
	var output := FileAccess.open(out_dir.path_join("emission.json"), FileAccess.WRITE)
	if output == null:
		_failures += 1
		return
	output.store_string(JSON.stringify({"quality": _quality, "gpu": RenderingServer.get_video_adapter_name(),
		"hdr": get_viewport().use_hdr_2d, "records": records, "failures": _failures}, "  ") + "\n")


func _record(name: String) -> Dictionary:
	var held := player._visual.melee_held()
	var xform := held.draw_transform()
	var at := get_viewport().get_canvas_transform() * xform.origin
	var tip := get_viewport().get_canvas_transform() * held.tip_point()
	capture(name)
	return {"progress": player.melee_pose_progress(), "active": player.melee.is_active(), "swing": player.is_melee_swinging(),
		"reduced_flashes": Settings.get_reduce_flashes(), "facing": player.facing,
		"origin": [at.x, at.y], "tip": [tip.x, tip.y]}