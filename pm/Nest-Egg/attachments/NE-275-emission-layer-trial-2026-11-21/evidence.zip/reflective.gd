extends "res://tools/melee_art_probe.gd"

var base_draws := 0
var parent_draws := 0


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://melee_emission_draw_audit.cfg")
	super._ready()


func _perf() -> void:
	var camera := get_viewport().get_camera_2d()
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * 3.0
	AimInput.using_gamepad = true
	AimInput._last_stick_dir = Vector2.RIGHT
	var held := player._visual.melee_held()
	var sprite := held._base_sprite
	sprite.draw.connect(func() -> void: base_draws += 1)
	held.draw.connect(func() -> void: parent_draws += 1)
	var records := {}
	for id in WEAPONS:
		var weapon := load("res://data/weapons/melee/melee_%s.tres" % id) as WeaponData
		records[id] = await _observe(id, weapon, camera, true)
	var blade := load("res://data/weapons/melee/melee_blade.tres") as WeaponData
	var fallback := blade.duplicate() as WeaponData
	fallback.id = &"audit_weapon_without_art"
	records["fallback"] = await _observe("fallback", fallback, camera, false)
	records["restored"] = await _observe("restored", blade, camera, true)
	var output := FileAccess.open(out_dir.path_join("reflective.json"), FileAccess.WRITE)
	if output == null:
		_failures += 1
		return
	output.store_string(JSON.stringify({"quality": _quality, "gpu": RenderingServer.get_video_adapter_name(),
		"hdr_2d": get_viewport().use_hdr_2d, "records": records, "failures": _failures}, "  ") + "\n")
	output.close()


func _observe(label: String, weapon: WeaponData, camera: Camera2D, textured: bool) -> Dictionary:
	await _arm(weapon, camera)
	await RenderingServer.frame_post_draw
	var held := player._visual.melee_held()
	var sprite := held._base_sprite
	if not held.visible or (sprite.texture != null) != textured:
		push_error("Wrong reflective base for " + label)
		_failures += 1
	var before := base_draws
	var parent_before := parent_draws
	var physics := Engine.get_physics_frames()
	var grip := held.hold()
	for frame in 120:
		await RenderingServer.frame_post_draw
	var result := {"textured": sprite.texture != null, "base_draws": base_draws - before,
		"parent_draws": parent_draws - parent_before, "physics": Engine.get_physics_frames() - physics,
		"initial_grip": [grip.origin.x, grip.origin.y], "final_grip": [held.hold().origin.x, held.hold().origin.y]}
	capture(label + "-idle")
	return result
