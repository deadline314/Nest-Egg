from collections import Counter
from pathlib import Path
from PIL import Image
import json
import numpy as np

base = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_bytes())
records = {}
for quality in ('high','low'):
    stock = base/('phases-stock' if quality == 'high' else 'phases-stock-low')
    control = base/'phases-control' if quality == 'high' else None
    candidate = base/('phases-candidate' if quality == 'high' else 'phases-candidate-low')
    data = [read(item/'emission.json') for item in (stock,candidate)]
    assert all(m['hdr'] and m['failures'] == 0 and m['quality'] == quality and '9070 XT' in m['gpu'] for m in data)
    assert data[0]['records'] == data[1]['records'] and len(data[0]['records']) == 40
    counters = []
    for name, metrics in data[0]['records'].items():
        def rgb(path):
            return np.asarray(Image.open(path/(name+'.png')).convert('RGB'),dtype=np.int16)
        first = rgb(stock)
        for mode, folder in (('stock-stock', control),('stock-candidate',candidate)):
            if folder is None:
                continue
            dif = np.max(np.abs(first-rgb(folder)),axis=2)
            counters.append({'name':name, 'mode':mode, 'maximum':int(dif.max()),
                             'over_1':int((dif>1).sum()),'over_16':int((dif>16).sum()),
                             'positions':metrics})
    original_counts = read((base/('stock-high' if quality == 'high' else 'stock-low'))/'reflective.json')
    candidate_counts = read((base/('candidate-high' if quality == 'high' else 'candidate-low'))/'reflective.json')
    draws = {}
    for name, original in original_counts['records'].items():
        changed = candidate_counts['records'][name]
        assert original['physics'] == changed['physics'] == 120 and original['parent_draws'] == 120
        assert original['initial_grip'] == changed['initial_grip'] and original['final_grip'] == changed['final_grip']
        assert changed['parent_draws'] == (120 if name in ('whip','fallback') else 0)
        assert original['base_draws'] == changed['base_draws']
        draws[name] = [original['parent_draws'],changed['parent_draws']]
    records[quality] = {'poses_equal': 40,'draw_counts':draws,'pixel_differences':counters}
    for mode in ('stock-stock','stock-candidate'):
        sel = [c for c in counters if c['mode'] == mode]
        if sel:
            print(quality, mode, len(sel), Counter('idle' if c['name'].endswith('idle') else 'swing' for c in sel),
                  'idle max',max(c['maximum'] for c in sel if c['name'].endswith('idle')),
                  'peak >16 counts',max(c['over_16'] for c in sel))
(base/'visual-summary.json').write_text(json.dumps(records,indent=2)+'\n')
