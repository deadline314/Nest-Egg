from pathlib import Path
import json
import os
import re
from statistics import median
import subprocess
import sys

base = Path(__file__).resolve().parent
root = Path('D:/NestEggVerification/ne218-baseline-20261117')
src = root/'game/player/melee_held.gd'
stock = (base/'melee-held-stock.gd.txt').read_bytes()
candidate = (base/'melee-held-candidate.gd.txt').read_bytes()
assert src.read_bytes() == stock
weapons = ('blade', 'dagger', 'glaive', 'maul', 'whip')

def run(name, patch):
    assert src.read_bytes() in (stock, candidate)
    src.write_bytes(patch)
    folder = base/('timing-'+name)
    folder.mkdir()
    env = os.environ.copy()
    profile = base/('timing-profile-'+name.split('-')[0])
    profile.mkdir(exist_ok=True)
    env.update(APPDATA=str(profile), LOCALAPPDATA=str(profile), PYTHONUTF8='1')
    command = [sys.executable, '-B', str(root/'tools/comfyui/gpu_lock.py'), '--',
               'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
               '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan',
               '--audio-driver', 'Dummy', '--resolution', '1280x720', '--quit-after', '22000',
               str(base/'timing.tscn'), '--', '--out='+str(folder), '--tag='+name, '--quality=high', '--perf']
    (folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    with (folder/'raw.log').open('wb') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=150, cwd=root)
    raw = (folder/'raw.log').read_text(encoding='utf-8')
    assert result.returncode == 0 and not re.search(r'^(?:SCRIPT )?ERROR:', raw, re.M), (name, raw)
    metrics = json.loads((folder/'grip-timings.json').read_bytes())
    assert metrics['resolution'] == [1280, 720] and '9070 XT' in metrics['gpu']
    assert metrics['failures'] == metrics['vsync'] == metrics['max_fps'] == 0
    assert set(metrics['records']) == set(weapons)
    output = {}
    for weapon, row in metrics['records'].items():
        samples = sorted(row['samples_ms'])
        assert row['drawn'] and row['dedicated_attachment'] and row['physics_steps'] >= 10 and len(samples) == 600
        output[weapon] = {'p50': median(samples), 'p99': samples[593], 'draw_calls': row['scene_draw_calls']}
    print(name, {weapon: round(values['p50'], 4) for weapon, values in output.items()}, flush=True)
    return output

try:
    run('stock-warm', stock)
    run('candidate-warm', candidate)
    pairs = []
    for index in range(1, 7):
        versions = (('stock',stock),('candidate',candidate))
        case = {}
        for version, data in versions if index % 2 else reversed(versions):
            case[version] = run(f'{version}-{index:02d}', data)
        pairs.append(case)
    timings = {}
    for weapon in weapons:
        timings[weapon] = {}
        for metric in ('p50','p99'):
            differences = [100.0*(case['candidate'][weapon][metric]/case['stock'][weapon][metric]-1.0) for case in pairs]
            timings[weapon][metric] = {'paired_change_percent': differences, 'median_change_percent': median(differences)}
    (base/'timing-summary.json').write_text(json.dumps({'timings':timings,'pairs':pairs,'frames':6*2*5*600},indent=2)+'\n')
    print(json.dumps(timings),flush=True)
finally:
    assert src.read_bytes() in (stock, candidate)
    src.write_bytes(stock)
    print('Guarded release source restored.',flush=True)
