from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
root = Path('D:/NestEggVerification/ne218-baseline-20261117')
path = root / 'game/player/melee_held.gd'
stock = (base/'melee-held-stock.gd.txt').read_bytes()
candidate = (base/'melee-held-candidate.gd.txt').read_bytes()
assert path.read_bytes() == stock
assert (base/'stock-high.exit').read_text().strip() == '0'

def run(tag, quality, payload):
    path.write_bytes(payload)
    profile = base/(tag+'-profile')
    profile.mkdir()
    env = os.environ.copy()
    env.update(APPDATA=str(profile), LOCALAPPDATA=str(profile), PYTHONUTF8='1')
    out = base/(tag+'.log')
    command = [sys.executable, '-B', str(root/'tools/comfyui/gpu_lock.py'), '--',
               'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--audio-driver', 'Dummy',
               '--fixed-fps', '60', '--resolution', '1280x720', '--quit-after', '10000', str(base/'phases.tscn'), '--',
               '--out='+str(base/tag), '--quality='+quality, '--perf']
    with out.open('wb') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=150)
    (base/(tag+'.exit')).write_text(str(result.returncode)+'\n')
    text = out.read_text(encoding='utf-8')
    print(tag, result.returncode, text[-1050:], flush=True)
    assert result.returncode == 0 and not re.search(r'^(?:SCRIPT )?ERROR:',text,re.M), tag

try:
    run('phases-stock','high',stock)
    run('phases-control','high',stock)
    run('phases-candidate','high',candidate)
    run('phases-stock-low','low',stock)
    run('phases-candidate-low','low',candidate)
finally:
    assert path.read_bytes() in (stock,candidate)
    path.write_bytes(stock)
    print('Restored the guarded stock source.', flush=True)
