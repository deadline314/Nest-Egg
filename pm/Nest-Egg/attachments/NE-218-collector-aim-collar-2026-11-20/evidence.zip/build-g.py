from hashlib import sha256
from pathlib import Path
from PIL import Image
from scipy import ndimage
import json
import numpy as np
import sys

root = Path.cwd()
output = Path(__file__).resolve().parent / sys.argv[1]
output.mkdir()
source = root / "art_src/characters/collector_gunner/07_refined/torso.png"
assert sha256(source.read_bytes()).hexdigest() == "1c3451b0b5199077a6ac1471b6278737773bf03e96d24ef56fc78872d0d0b8ab"
sys.path.insert(0, str(root / "tools/comfyui"))
from cut_layers import make_normal_map, part_transform, render_part

original = np.asarray(Image.open(source).convert("RGBA"))
extension = original.copy()
alpha = original[:,:,3]
distance, (source_y, source_x) = ndimage.distance_transform_edt(alpha < 128, return_indices=True)
contacts = (
    (405.51,125.94,1.8), (393.33,130.99,1.8), (398.20,131.30,2.65),
)
for px, py, reach in contacts:
    ix,iy=round(px),round(py)
    nx,ny=source_x[iy,ix],source_y[iy,ix]
    left,right=int(min(px,nx)-reach-2),int(max(px,nx)+reach+3)
    top,bottom=int(min(py,ny)-reach-2),int(max(py,ny)+reach+3)
    y,x=np.ogrid[top:bottom,left:right]
    vx,vy=px-nx,py-ny
    progress=np.clip(((x+0.5-nx)*vx+(y+0.5-ny)*vy)/max(vx*vx+vy*vy,.01),0.0,1.0)
    gap=np.hypot(x+0.5-nx-progress*vx,y+0.5-ny-progress*vy)
    coverage=np.clip((reach-gap)*255.0,0.0,255.0).astype(np.uint8)
    region=np.s_[top:bottom,left:right]
    local=extension[region]
    mask=(coverage>local[:,:,3]) & (alpha[region]<128)
    local[mask,:3]=original[source_y[region][mask],source_x[region][mask],:3]
    local[mask,3]=coverage[mask]
Image.fromarray(extension).save(output / "refined-torso.png")

spec = json.loads((root / "tools/comfyui/specs/collector_gunner_side.json").read_bytes())
scale = spec["tex_px_per_wp"] / spec["illustration_px_per_wp"]
joints = {name: np.array(point,float) * scale for name,point in spec["joints"].items()}
part = spec["parts"]["torso"]
reference = part_transform(Image.fromarray(original), part, joints, scale)
candidate = part_transform(Image.fromarray(extension), part, joints, scale)
assert all(np.array_equal(a,b) for a,b in zip(reference,candidate)), "the scope must preserve the existing crop grid"
old = render_part(Image.fromarray(original), reference, scale, crop_phase=part.get("crop_phase"))
new = render_part(Image.fromarray(extension), candidate, scale, crop_phase=part.get("crop_phase"))
original_texture = Image.open(root/"art/characters/collector_gunner/parts/torso.png").convert("RGBA")
assert np.array_equal(old, np.asarray(original_texture))
old_n = make_normal_map(old)
new_n = make_normal_map(new)
current_n = np.asarray(Image.open(root/"art/characters/collector_gunner/parts/torso_n.png").convert("RGBA"))
Image.fromarray(new).save(output / "torso.png")
Image.fromarray(new_n).save(output / "torso_n.png")
changed = lambda x,y: int(np.count_nonzero(np.any(x != y,axis=2)))
receipt={"source_changes":changed(original,extension),"texture_changes":changed(old,new),
         "native_normal_vs_cpu_reference":changed(old_n,current_n),"normal_changes_from_reference":changed(old_n,new_n)}
(output/"build.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(receipt)
