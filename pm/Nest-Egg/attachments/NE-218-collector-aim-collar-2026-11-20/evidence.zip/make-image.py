from pathlib import Path
from PIL import Image
import json
base=Path(__file__).resolve().parent
stock=base/"stock/frames"
fixed=base/"preview-g/frames"
record=next(r for r in json.loads((stock/"report.json").read_bytes())["failures"]
 if r["joint"]=="neck" and r["pose"]=="aim_up" and r["facing"]==1 and r["zoom"]==3.4 and r["frame"]==30)
x,y,_,_=record["rect"]
crop=(x+38,y+38,x+89,y+77)
shots=[]
for atlas in (stock,fixed):
    source=Image.open(atlas/record["file"]).convert("RGBA").crop(crop)
    bg=Image.new("RGBA",source.size,"#556271")
    bg.alpha_composite(source)
    shots.append(bg.convert("RGB").resize((source.width*5,source.height*5),Image.Resampling.NEAREST))
w,h=shots[0].size
page=Image.new("RGB",(2*w+4,h),"#202736")
for i,shot in enumerate(shots):
    page.paste(shot,(i*(w+4),0))
page.save(base/"aim-collar-detail.png")
