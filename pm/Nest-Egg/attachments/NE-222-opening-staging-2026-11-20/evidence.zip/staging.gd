extends "res://tools/cinematic_safe_area_capture.gd"

var _failures := 0
var _record: Dictionary = {}


func _run() -> void:
	Story.auto_skip = false
	GameState.start_new_run(GameState.difficulties[1])
	for flag in [&"ch1_supper_done", &"ch1_handoff_done"]:
		GameState.set_flag(flag, true, false)
	var level := Level.new()
	level.configure(load(level_path) as LevelData)
	get_tree().root.add_child(level)
	await _frames(60)
	Story.reset_active_presentation(&"route")
	await _frames(18)
	for id: StringName in [&"ch1_p01_door", &"ch1_c14_home", &"ch1_c09_wake"]:
		await _inspect(id)
		Story.reset_active_presentation(&"route")
		await _frames(18)
	var report := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
	report.store_string(JSON.stringify({"failures":_failures,"scenes":_record},"  ")+"\n")
	report.close()
	AudioRelease.begin_shutdown()
	level.queue_free()
	await _frames(6)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures == 0 else 1)


func _inspect(id: StringName) -> void:
	var allowed := {
		&"ch1_p01_door": {"rin":["idle"],"k":["idle"]},
		&"ch1_c14_home": {"rin":["idle","walk"],"k":["idle","walk","squat"]},
		&"ch1_c09_wake": {"rin":["sit"]},
	}
	var found: Dictionary = {}
	var poses: Dictionary = {}
	var streak: Dictionary = {}
	var context_pic := ""
	var count := 0
	var still := false
	var end := false
	_check(Story.play(id, false), "start shipped scene " + String(id))
	for step in 360:
		if Story.is_cinematic_active() and Story._current_cinematic == id:
			break
		await _frames(1)
	for tick in 2900:
		var player: CutscenePlayer = Story._player
		if not is_instance_valid(player) or player.scene_id != id or not player.is_running():
			end = tick > 0
			break
		var current := {}
		for actor_id: StringName in player._actors:
			var actor := player._actors[actor_id] as CutsceneActor
			if not is_instance_valid(actor) or actor.rig == null or not actor.is_visible_in_tree():
				continue
			var key := String(actor_id) + "/" + String(actor.pose)
			if not found.has(key):
				found[key] = {"frames":0,"pose":String(actor.pose),"actor":String(actor_id),
					"initial_at":str(actor.position),"initial_ground_y":actor.ground_y,"found_at":player._current_where,"photo":""}
			found[key]["frames"] += 1
			current[key] = int(streak.get(key, 0)) + 1
			if current[key] == 15 and found[key]["photo"] == "":
				var pic := "%s-%s-%s.png" % [id,actor_id,actor.pose]
				var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
				var result := image.save_png(_out.path_join(pic))
				_check(result == OK,"rendered the actual actor pose " + key + " in " + String(id))
				found[key]["photo"] = pic
			still = still or not actor.position.is_finite()
			count += 1
		streak = current
		var context_ready := (id == &"ch1_c09_wake" and int(current.get("rin/sit", 0)) == 100) \
			or (id == &"ch1_c14_home" and player._current_where.contains("第 38 步") and current.has("k/squat"))
		if context_ready and context_pic.is_empty():
			context_pic = String(id) + "-context.png"
			var frame := preload("res://tools/viewport_capture.gd").image(get_viewport())
			_check(frame.save_png(_out.path_join(context_pic)) == OK, "rendered the supported pose with its real furniture " + String(id))
		if player._dialogue.visible and tick % 32 == 31:
			player._dialogue.complete()
			player._advance_requested = true
		await _frames(1)
	for key: String in found:
		var actor: String = found[key]["actor"]
		var pose: String = found[key]["pose"]
		if not poses.has(actor):
			poses[actor] = []
		poses[actor].append(pose)
	_check(end and count > 0 and not still,"authored timeline yields finite live actor poses " + String(id))
	for actor: String in allowed[id]:
		var expected: Array = allowed[id][actor].duplicate()
		expected.sort()
		var seen: Array = poses.get(actor, [])
		seen.sort()
		_check(seen == expected, "%s only uses staged poses for %s: %s" % [id,actor,seen])
	_check(poses.size()==allowed[id].size(), "all actors are accounted for in " + String(id))
	_record[String(id)] = {"actors":poses,"frames":count,"found":found,"finished":end,"context":context_pic}


func _check(ok: bool, what: String) -> void:
	print("%s %s" % ["PASS" if ok else "FAIL",what])
	if not ok:
		_failures += 1
