extends Node

const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://capture-feedback-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.set_language("en")
	var menu := MainMenu.new()
	add_child(menu)
	await _frames(5)
	menu._open_settings()
	await _frames(6)
	var screen := menu._ui.get_child(menu._ui.get_child_count() - 1) as SettingsScreen
	await _joy(JOY_BUTTON_RIGHT_SHOULDER)
	_check(screen._tabs.current_tab == 1, "the actual settings overlay opens on Bindings with the shoulder button")
	var edit: Button = screen._binding_buttons["map:1"]
	var other_key: Button = screen._binding_buttons["map:0"]
	var other_pad: Button = screen._binding_buttons["map:-1"]
	edit.grab_focus()
	await _frames(5)
	await _key(KEY_ENTER)
	var instructions := screen._status.text
	_check(screen._capturing and instructions.begins_with("Press a key"), "Enter starts keyboard capture and shows the current instructions")
	await _hover(other_key)
	_check(screen._capturing and edit.has_focus() and screen._status.text == instructions,
			"hovering another key does not replace active capture instructions")
	await _key(KEY_R)
	var refusal := screen._status.text
	_check(refusal.contains("Reload") and screen._capturing, "numbered capture refuses Reload's only R without leaving the field")
	await _hover(other_pad)
	_check(screen._capturing and edit.has_focus() and screen._status.text == refusal,
			"hovering a controller field preserves the active refusal")
	await _joy(JOY_BUTTON_RIGHT_SHOULDER)
	_check(InputBindings.using_gamepad and screen._tabs.current_tab == 1 and screen._capturing and screen._status.text == refusal,
			"an unrelated controller input updates device identity without taking over capture feedback")
	await _picture("active-refusal.png")
	await _key(KEY_U)
	_check(not screen._capturing and screen._status.text == "Map binding updated." and InputBindings.get_code(&"map", 1) == KEY_U,
			"the next valid key clears the refusal, saves the requested key and ends capture")
	await _hover(other_key)
	_check(screen._status.text == other_key.tooltip_text, "outside capture Hover still shows the focused control explanation")
	screen.close()
	menu.queue_free()
	await _finish()


func _hover(control: Control) -> void:
	var motion := InputEventMouseMotion.new()
	motion.position = control.get_global_rect().get_center()
	motion.global_position = motion.position
	motion.relative = Vector2(9, 0)
	get_viewport().push_input(motion, true)
	await _frames(3)



func _button(node: Node, caption: String) -> Button:
	for child in node.find_children("*", "Button", true, false):
		if (child as Button).text == caption:
			return child as Button
	return null


func _has_text(node: Node, caption: String) -> bool:
	if node is Label and (node as Label).text == caption:
		return true
	for child in node.get_children():
		if _has_text(child, caption):
			return true
	return false


func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _tap(event)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	await _tap(event)


func _tap(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish() -> void:
	await _frames(7)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))
