from pathlib import Path
from collections import Counter
from PIL import Image
from scipy.ndimage import binary_fill_holes
import json,sys
import numpy as np
p=Path(__file__).resolve().parent
before=p.parent/'evidence-20261120-ne250-stage-motion'
prior=before/'visible-talk-and-gesture'
read=lambda f:json.loads(f.read_bytes())
sel=[r for r in read(before/'attribution-talk-and-gesture.json') if r['char']=='ali' and r['joint']=='shoulder_front' and r['enclosed']]
assert len(sel)==14
def same_cells(folder):
    return {(g['pose'],g['zoom'],c['joint'],c['facing']):c for g in read(folder/'frames.json') for c in g['cells'] if c['char']=='ali'}
def extract(folder,row,c):
    x,y,w,h=c['rect']
    r=c['radius']
    return np.asarray(Image.open(folder/row['file']).getchannel('A').crop((x+w//2-r,y+h//2-r,x+w//2+r,y+h//2+r)))
ref=same_cells(prior)
folders=sys.argv[1:] or ['collar-trim','collar-wider','source-1.1','source-1.5','source-1.9','release']
totals={}
for case in folders:
    dest=p/f'{case}-talk-and-gesture'
    if not (dest/'frames.json').is_file():
        continue
    replacement=same_cells(dest)
    report=[]
    for r in sel:
        key=tuple(r[n] for n in ('pose','zoom','joint','facing'))
        a,b=(extract(folder,r,index[key]) for folder,index in ((prior,ref),(dest,replacement)))
        enclosed=binary_fill_holes(b>=128,structure=np.ones((3,3)))&(b<128)
        for x,y in r['enclosed_points']:
            assert a[y,x]<128
            report.append(dict(frame=r['frame'],pose=r['pose'],facing=r['facing'],zoom=r['zoom'],point=[x,y],
                                before=int(a[y,x]),after=int(b[y,x]),
                                result='covered' if b[y,x]>=128 else 'enclosed' if enclosed[y,x] else 'edge'))
    totals[case]=report
    print(case,Counter(r['result'] for r in report),Counter((r['pose'],r['result']) for r in report))
(p/'original-coverage.json').write_text(json.dumps(totals,indent=2)+'\n',encoding='utf-8')
