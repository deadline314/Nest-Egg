from pathlib import Path
from hashlib import sha256
from scipy.ndimage import distance_transform_edt
from PIL import Image
import json,sys
import numpy as np
p=Path(__file__).resolve().parent
root=Path.cwd()
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'tools/comfyui'))
from cut_layers import part_transform,render_part
spec=json.loads((root/'tools/comfyui/specs/ali_side.json').read_bytes())
k=spec['tex_px_per_wp']/spec['illustration_px_per_wp']
joints={name:np.asarray(pt)*k for name,pt in spec['joints'].items()}
part=spec['parts']['torso']
original=Image.open(root/'art_src/characters/ali/07_refined/torso.png').convert('RGBA')
src=np.array(original)
alpha=src[:,:,3]
transform=part_transform(original,part,joints,k)
A,w,h,pivot=transform
reference=render_part(original,transform,k,crop_phase=part.get('crop_phase'))
assert np.array_equal(reference,np.asarray(Image.open(root/'art/characters/ali/parts/torso.png').convert('RGBA')))
raw=list(set((x,y) for r in json.loads((p/'sources.json').read_bytes()) for name,x,y,k in r['found'] if name=='torso'))
Y,X=np.indices(alpha.shape)
rx=(X+.5)*k-.5-A[0,2]
ry=(Y+.5)*k-.5-A[1,2]
d,near=distance_transform_edt(alpha<210,return_indices=True)
for radius in (1.1,1.5,1.9):
    result=src.copy()
    mask=np.zeros(alpha.shape,bool)
    for x,y in raw:
        mask|=(abs(rx-x)<=radius)&(abs(ry-y)<=radius)
    mask&=(alpha<128)&(d<8)
    result[mask]=src[near[0][mask],near[1][mask]]
    assert np.array_equal(src[alpha>=128],result[alpha>=128])
    fixed=Image.fromarray(result)
    new=part_transform(fixed,part,joints,k)
    assert np.array_equal(new[0],A) and new[1:3]==(w,h) and np.array_equal(new[3],pivot)
    mapped=render_part(fixed,new,k,crop_phase=part.get('crop_phase'))
    print(radius, int(mask.sum()),int((mapped!=reference).any(axis=-1).sum()))
    fixed.save(p/f'source-collar-{radius}.png')
    Image.fromarray(mapped).save(p/f'native-collar-{radius}.png')
