from pathlib import Path
p=Path(__file__).resolve().parent
exec((p/'template.py').read_text(encoding='utf-8').split('jobs=')[0])
for name,mode in (('talk-and-gesture','--npc-performance'),('sit-transitions','--npc-transitions')):
    flags=['--out={out}','--chars=ali',
           '--joints=shoulder_front,shoulder_back,elbow_front,elbow_back,waist,neck,hip_front,hip_back',
           '--zooms=2.8,3.4','--frames=100','--diagnostic-whole-rig',mode]
    render(f'release-{name}',p/'visible.tscn',flags,True)
