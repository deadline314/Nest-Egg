from pathlib import Path
from shutil import copyfile
from hashlib import sha256
from subprocess import run
import importlib.util
import json, os, sys
import numpy as np
from PIL import Image
p=Path(__file__).resolve().parent
root=Path.cwd()
shared=p.parent/'ne218-baseline-20261117'
sha=lambda f:sha256(f.read_bytes()).hexdigest()
from scipy.ndimage import binary_dilation
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'tools/comfyui'))
from cut_layers import part_transform, render_part
paths=['art_src/characters/ali/overrides/refined/torso.png']
old=Image.open(root/'art_src/characters/ali/07_refined/torso.png')
override=Image.open(p/'source-collar-1.5.png')
assert override.size==Image.open(root/'art_src/characters/ali/base_rgba.png').size and override.mode=='RGBA'
a,b=np.asarray(old),np.asarray(override)
changed=(a!=b).any(axis=-1)
assert changed.sum()==41 and (a[changed,3]<128).all()
recipe=json.loads((root/'tools/comfyui/specs/ali_side.json').read_bytes())
k=recipe['tex_px_per_wp']/recipe['illustration_px_per_wp']
joints={name:np.array(point)*k for name,point in recipe['joints'].items()}
part=recipe['parts']['torso']
original,new=(part_transform(image,part,joints,k) for image in (old,override))
assert np.array_equal(original[0],new[0]) and original[1:3]==new[1:3] and np.array_equal(original[3],new[3])
before=render_part(old,original,k,crop_phase=part.get('crop_phase'))
rgba=render_part(override,new,k,crop_phase=part.get('crop_phase'))
assert np.array_equal(before,np.asarray(Image.open(root/'art/characters/ali/parts/torso.png')))
assert np.array_equal(rgba,np.asarray(Image.open(p/'native-collar-1.5.png')))
assert (before[:,:,3]<=rgba[:,:,3]).all()
folder=Path('art/characters/ali/parts')
diffuse=folder/'torso.png'
normal=folder/'torso_n.png'
dest=p/'release-draft'/folder
dest.mkdir(parents=True)
Image.fromarray(rgba).save(p/'release-draft'/diffuse)
script=(p.parent/'evidence-20261120-ne222-waist/normals.gd').read_text(encoding='utf-8')
script=script.replace('evidence-20261120-ne222-waist',p.name).replace('/draft/','/release-draft/').replace('art/characters/rin','art/characters/ali').replace('["pelvis", "pelvis_dmg"]','["torso"]')
(p/'normals.gd').write_text(script,encoding='utf-8')
(p/'normals.tscn').write_text((p/'visible.tscn').read_text(encoding='utf-8').replace('visible.gd','normals.gd'),encoding='utf-8')
profile=p/'release-import-profile'
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    where=profile/key
    where.mkdir(parents=True)
    env[key]=str(where)
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def execute(name,cmd):
    with (p/f'{name}.log').open('wb') as log:
        result=run([engine,'--headless',*cmd],cwd=shared,env=env,stdout=log,stderr=log,timeout=90)
    raw=(p/f'{name}.log').read_text(encoding='utf-8')
    assert result.returncode==0 and 'ERROR:' not in raw and 'WARNING:' not in raw,raw
    print(raw.strip())
execute('normals',['--path',str(shared),str(p/'normals.tscn')])
mini=p/'release-import-project'
(mini/folder).mkdir(parents=True)
copyfile(p.parent/'evidence-20261120-ne222-waist/import-project/project.godot',mini/'project.godot')
for name in (diffuse,normal):
    copyfile(p/'release-draft'/name,mini/name)
    copyfile(root/(str(name)+'.import'),mini/(str(name)+'.import'))
execute('texture-import',['--editor','--path',str(mini),'--import'])
assert len(list((mini/'.godot/imported').glob('*.ctex')))==2
for name in (diffuse,normal):
    print(name,sha(p/'release-draft'/name))
(p/'prepared.json').write_text(json.dumps(paths+[diffuse.as_posix(),normal.as_posix()],indent=2)+'\n',encoding='utf-8')
print('Rebuilt the exact pilot texture from checked source, preserved glow, generated the official normal and imported both in a fresh project.')





