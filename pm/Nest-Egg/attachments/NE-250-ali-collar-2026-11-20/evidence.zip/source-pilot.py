from pathlib import Path
p=Path(__file__).resolve().parent
exec((p/'template.py').read_text(encoding='utf-8').split('jobs=')[0])
for variant in (1.1,1.5,1.9):
    flags=['--out={out}','--chars=ali','--joints=shoulder_front,elbow_front,neck',
           '--zooms=2.8,3.4','--frames=100','--diagnostic-whole-rig','--npc-performance',
           f'--diagnostic-part-texture=torso:{(base/f"native-collar-{variant}.png").as_posix()}']
    render(f'source-{variant}-talk-and-gesture',base/'visible.tscn',flags,True)
