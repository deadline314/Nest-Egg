extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const PAD := 420
const PATH := "user://overwrite-localization/slot.json"
const EXPECTED := {
	"en": ["Replace current save?", "Starting a new game replaces the progress in this slot. Cancel to keep your save.", "Keep save",
		"Replace and start", "Return to difficulty selection and keep your save.", "Replace this slot and start a new game."],
	"ja": ["新しいゲームを開始", "新しく始めると、このスロットの進行状況を上書きします。キャンセルすると現在のセーブを保持します。", "現在のセーブを保持",
		"上書きして開始", "セーブを保持して難易度選択に戻ります。", "このスロットを上書きして新しく始めます。"],
}
var _out := ""
var _language := "en"
var _checks := 0
var _failures := 0


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=")
		if argument.begins_with("--language="):
			_language = argument.trim_prefix("--language=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://overwrite-probe.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	Story.set_language(_language)
	Story.auto_skip = true
	GameState.story_autosave = false
	GameState.start_new_run(GameState.difficulties[1])
	var store := RunSaveStore.new(PATH)
	store.validator = RunSnapshot.prepare
	var old_save := RunSnapshot.capture(CampaignEdition.current().first_level,
			{"loadout": {}, "world": {}, "position": [80, 145], "health": 2})
	_check(store.write(old_save), "seed the private save with distinct position and health")
	var original := FileAccess.get_file_as_bytes(PATH)
	var backup_path := PATH + ".bak"
	var original_backup := FileAccess.get_file_as_bytes(backup_path) if FileAccess.file_exists(backup_path) else PackedByteArray()
	var main: Node = load("res://game/main.gd").new()
	main.set("_run_store", store)
	add_child(main)
	var menu: MainMenu
	for frame in 120:
		menu = main.get("_screen") as MainMenu
		if menu != null and not GameplayLock.is_locked():
			break
		await get_tree().process_frame
	_check(menu != null and menu.continue_available and menu.overwrite_required
			and get_viewport().gui_get_focus_owner() == menu._continue_button, "the real menu recognizes and protects the old save")
	if menu == null:
		await _finish(main)
		return
	await _key(KEY_DOWN)
	_check(get_viewport().gui_get_focus_owner() == menu._start_button, "Down moves from Continue to New game")
	await _key(KEY_ENTER)
	_check(menu._difficulty_page.visible, "Enter opens the actual difficulty selection")
	for attempt in 8:
		if get_viewport().gui_get_focus_owner() == menu._confirm_button:
			break
		await _key(KEY_TAB)
	_check(get_viewport().gui_get_focus_owner() == menu._confirm_button, "keyboard navigation reaches the real Start button")
	await _key(KEY_ENTER)
	var modal := menu._overwrite_dialog
	_check(is_instance_valid(modal) and get_viewport().gui_get_focus_owner() == modal.cancel_button, "the preserve action is focused first")
	if not is_instance_valid(modal):
		await _finish(main)
		return
	var panel := modal.get_child(1) as PanelContainer
	var content := panel.get_child(0) as VBoxContainer
	var title := content.get_child(0) as Label
	var warning := content.get_child(1) as Label
	var replace := content.get_child(2).get_child(1) as Button
	var expected: Array = EXPECTED[_language]
	_check(title.text == expected[0] and warning.text == expected[1], "title explains the replacement in the current language")
	_check(modal.cancel_button.text == expected[2] and replace.text == expected[3], "both consent actions use the current language")
	_check(modal.cancel_button.tooltip_text == expected[4] and replace.tooltip_text == expected[5], "both buttons expose localized Hover outcomes")
	_check(get_viewport().get_visible_rect().encloses(panel.get_global_rect())
			and panel.get_global_rect().encloses(warning.get_global_rect())
			and panel.get_global_rect().encloses(replace.get_global_rect())
			and warning.get_global_rect().end.y <= replace.get_global_rect().position.y,
			"the warning and confirm controls fit without overlap at 120 percent")
	await RenderingServer.frame_post_draw
	_check(Capture.image(get_viewport()).save_png(_out.path_join("overwrite.png")) == OK, "capture the actual consent screen")
	await _key(KEY_ESCAPE)
	_check(not is_instance_valid(modal) and menu._difficulty_page.visible
			and get_viewport().gui_get_focus_owner() == menu._confirm_button, "Escape closes only the prompt and restores Start focus")
	_check(FileAccess.get_file_as_bytes(PATH) == original and _same_backup(backup_path, original_backup), "Escape leaves the primary and backup intact")
	await _key(KEY_ENTER)
	modal = menu._overwrite_dialog
	await _pad(JOY_BUTTON_B)
	_check(not is_instance_valid(modal) and get_viewport().gui_get_focus_owner() == menu._confirm_button
			and FileAccess.get_file_as_bytes(PATH) == original and _same_backup(backup_path, original_backup),
			"test controller B closes safely and keeps the save")
	await _key(KEY_ENTER)
	modal = menu._overwrite_dialog
	await _key(KEY_RIGHT)
	_check(is_instance_valid(modal) and get_viewport().gui_get_focus_owner() != modal.cancel_button,
			"confirmation requires moving from the safe default")
	await _key(KEY_ENTER)
	var entered := false
	for frame in 360:
		var level := main.get("_screen") as Level
		if level != null and level.is_initialized():
			entered = true
			break
		await get_tree().process_frame
	_check(entered and FileAccess.get_file_as_bytes(PATH) != original and not store.read().is_empty(),
			"explicit confirmation writes a fresh valid slot and starts the original first level")
	await _finish(main)


func _same_backup(path: String, expected: PackedByteArray) -> bool:
	if expected.is_empty():
		return not FileAccess.file_exists(path)
	return FileAccess.get_file_as_bytes(path) == expected


func _key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	await _tap(event)


func _pad(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.device = PAD
	event.button_index = button
	await _tap(event)


func _tap(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await get_tree().process_frame
	var released := event.duplicate() as InputEvent
	released.pressed = false
	Input.parse_input_event(released)
	for frame in 5:
		await get_tree().process_frame


func _finish(main: Node) -> void:
	main.queue_free()
	for frame in 8:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _failures])
	get_tree().quit(1 if _failures else 0)


func _check(passed: bool, message: String) -> void:
	_checks += 1
	_failures += int(not passed)
	if not passed:
		printerr("FAIL: ", message)
