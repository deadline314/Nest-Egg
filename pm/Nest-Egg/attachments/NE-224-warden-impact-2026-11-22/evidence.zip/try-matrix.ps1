$ErrorActionPreference='Stop'
$e=$PSScriptRoot.Replace('\','/')
$d='D:/NestEggVerification/ne218-baseline-20261117'
$prior='D:/NestEggVerification/evidence-20261121-ne224-enforcer-upper-limbs'
$py='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
$engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$env:APPDATA="$e/matrix-profile"
$env:LOCALAPPDATA=$env:APPDATA
New-Item -ItemType Directory -Path $env:APPDATA -Force | Out-Null
foreach($variant in 'baseline','trial'){
    foreach($mode in 'whole','dressed','isolated'){
        $out="$e/$variant-$mode"
        $extra=@()
        if($mode -eq 'whole'){ $extra+='--diagnostic-whole-rig' }
        if($mode -eq 'isolated'){ $extra+='--pair-only' }
        if($variant -eq 'trial'){ $extra+="--diagnostic-part-texture=torso:$e/torso-refined.png" }
        & $py -B "$d/tools/comfyui/gpu_lock.py" -- $engine --path $d --rendering-method forward_plus --rendering-driver vulkan --resolution 1280x720 --max-fps 120 --audio-driver Dummy --quit-after 9000 "$prior/mip-probe.tscn" -- "--out=$out" --chars=warden '--joints=wrist_front,neck,shoulder_front,shoulder_back' --frames=120 @extra *> "$out.log"
        if($LASTEXITCODE -ne 0 -or (Select-String -LiteralPath "$out.log" -Pattern 'ERROR:' -Quiet)){ throw "Native $variant $mode failed." }
        & $py -B tools/check_joint_frames.py $out *> "$out-check.log"
        if($LASTEXITCODE -gt 1){ throw "Report $variant $mode unavailable." }
        Get-Content "$out-check.log" -TotalCount 2
    }
}