from collections import Counter
from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage
import sys
p=Path(sys.argv[1])
key=lambda r: (r['pose'],r['zoom'],r['facing'],r['frame'],r['joint'])
def band(image,r):
    x,y,w,h=r['rect']
    radius=r['radius']
    cx=x+w//2
    cy=y+h//2
    return image.crop((cx-radius,cy-radius,cx+radius,cy+radius))
stats={}
thumbs={}
for mode in ('dressed','isolated'):
    dirs=[p/f'{version}-{mode}' for version in ('baseline','final')]
    old,new=({key(r):r for r in json.loads((folder/'report.json').read_bytes())['failures']} for folder in dirs)
    nfill=0
    nloss=0
    nbackground=0
    ext=Counter()
    worst=0
    for k in sorted(new.keys()-old.keys()):
        r=new[k]
        a,b=(band(Image.open(folder/r['file']).convert('RGBA'),r) for folder in dirs)
        a_alpha,b_alpha=(np.array(im.getchannel('A')) for im in (a,b))
        s,t=a_alpha>=128,b_alpha>=128
        delta=t&~s
        holes=ndimage.binary_fill_holes(t)&~t
        nfill+=delta.sum()
        nloss+=(s&~t).sum()
        nbackground+=(holes&s).sum()
        worst=max(worst,int(holes.sum()))
        ext[(k[0],int(holes.sum()))]+=1
        assert not np.any(t^s) or np.any(delta)
        if mode=='isolated' and (k[0] not in thumbs or int(holes.sum()) > thumbs[k[0]][0]):
            thumbs[k[0]]=(int(holes.sum()),r,a,b,holes)
    stats[mode]={'new':len(new.keys()-old.keys()),'pixels_gained':int(nfill),'pixels_lost':int(nloss),
                 'notch_pixels_previously_opaque':int(nbackground),'max_notch_pixels':worst,
                 'by_pose_and_size':{f'{pose}/{size}':n for (pose,size),n in sorted(ext.items())}}
print(json.dumps(stats,indent=2))
canvas=Image.new('RGB',(920,840),'#596069')
draw=ImageDraw.Draw(canvas)
for row,(size,r,before,after,holes) in enumerate(thumbs.values()):
    for col,original in enumerate((before,after)):
        im=original.resize((392,392),Image.Resampling.NEAREST)
        im2=Image.new('RGB',im.size,'#596069')
        im2.paste(im,(0,0),im)
        pen=ImageDraw.Draw(im2)
        for y,x in np.argwhere(holes):
            pen.rectangle((x*7,y*7,x*7+6,y*7+6),outline='#ff284a',width=1)
        canvas.paste(im2,(col*460+34,row*420+23))
        draw.text((col*460+34,row*420+4),f'{r["pose"]} frame {r["frame"]} - {("before","after")[col]}',fill='white')
canvas.save(p/'neck-edge-comparison.png')
(p/'neck-edge-comparison.json').write_text(json.dumps(stats,indent=2)+'\n',encoding='utf-8')
