from pathlib import Path
from PIL import Image
from hashlib import sha256
import json
import numpy as np
base=Path(__file__).resolve().parent
root=Path.cwd()
def read(p):
    return json.loads(p.read_bytes())
def report_keys(report):
    return {(r['pose'],r['zoom'],r['facing'],r['frame'],r['joint']):
             bool(r['center_alpha']<128 or r['enclosed_pixels'] or r['loose_pieces']) for r in report['failures']}
stats={}
edge_audit=read(base/'neck-edge-comparison.json')
for mode in ('whole','dressed','isolated'):
    a=read(base/f'baseline-{mode}'/'report.json')
    b=read(base/f'final-{mode}'/'report.json')
    assert a['samples']==b['samples']==15360
    old,new=report_keys(a),report_keys(b)
    added=set(new)-set(old)
    if mode=='whole':
        assert not added
    else:
        edge=edge_audit[mode]
        assert len(added)==edge['new']==224
        assert edge['pixels_lost']==edge['notch_pixels_previously_opaque']==0
        assert edge['max_notch_pixels']==1
        assert all(k[0] in ('dead','stagger') and k[1]==3.4 and k[-1]=='neck' for k in added)
    assert not [k for k,v in new.items() if v and not old.get(k)],mode
    stats[mode]={'samples':b['samples'],'hard_before':sum(old.values()),'hard_after':sum(new.values()),
        'edge_before':len(old)-sum(old.values()),'edge_after':len(new)-sum(new.values()),
        'edge_added':len(added)}
    if mode=='whole':
        subgroup=lambda rows:sum(v and p[0]=='stagger' and p[1]==3.4 and p[-1]=='wrist_front' for p,v in rows.items())
        assert (subgroup(old),subgroup(new))==(236,0)
assert stats['whole']['hard_before']==444 and stats['whole']['hard_after']<=206
assert stats['dressed']['hard_after']==stats['isolated']['hard_after']==0
controls={}
for v in ('before','after'):
    d=base/f'street-{v}-v3'
    assert (d/'exit.txt').read_text().strip()=='0'
    j=read(d/'street.json')
    assert j['hdr_2d'] and j['rendering_method']=='forward_plus' and 'RX 9070 XT' in j['adapter']
    controls[v]={r['key']:{k:v for k,v in r.items() if k!='physics_frame'} for r in j['rows']}
    assert len(controls[v])==28
    assert sum(v['stunned'] for v in controls[v].values())>=16
assert controls['before']==controls['after']
stats['arena_cases']=len(controls['after'])
stats['textures']={}
for name in ('torso.png','torso_n.png'):
    origin=base/name
    final=root/'art/characters/warden/parts'/name
    source=np.array(Image.open(origin).convert('RGBA'))
    revised=np.array(Image.open(final).convert('RGBA'))
    assert source.shape==revised.shape
    delta=np.any(source!=revised,axis=2)
    stats['textures'][name]={'changed':int(delta.sum()),'before':sha256(origin.read_bytes()).hexdigest(),
                             'after':sha256(final.read_bytes()).hexdigest()}
    if name=='torso.png':
        assert stats['textures'][name]['changed']==756 and not np.any(delta&(source[:,:,3]>=235))
pic=Image.new('RGB',(960,640),'#565c62')
for col,label in enumerate(('baseline','final')):
    image=Image.open(base/f'{label}-whole/stagger_3.4_015.png').convert('RGBA')
    for side in (0,1):
        x=0 if side==0 else 512
        clip=(x+10,23,x+106,87)
        crop=image.crop(clip).resize((480,320),Image.Resampling.NEAREST)
        pic.paste(crop,(col*480,side*320),crop)
pic.save(base/'overlap-comparison.png')
(base/'comparison.json').write_text(json.dumps(stats,indent=2)+'\n')
print(json.dumps(stats))