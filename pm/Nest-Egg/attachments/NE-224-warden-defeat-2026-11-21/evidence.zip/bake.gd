extends Node

func _ready() -> void:
	var paths := OS.get_cmdline_user_args()
	var status := 0
	for index in range(0, paths.size(), 2):
		var image := Image.load_from_file(paths[index])
		if image == null or NormalMapMaker.make(image).save_png(paths[index + 1]) != OK:
			status = 1
			push_error("Cannot bake normal from " + paths[index])
	get_tree().quit(status)
