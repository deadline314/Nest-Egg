from collections import Counter
from hashlib import sha256
from pathlib import Path
import json

import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent
root=Path.cwd()
prior=base.parent/'evidence-20261121-ne224-warden-elbow'
sha=lambda path: sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_bytes())
def key(f): return (f['char'],f['joint'],f['pose'],f['zoom'],f['facing'],f['frame'])
def gap(f): return f['center_alpha']<128 or f['enclosed_pixels'] or f['loose_pieces']

results={}
for scope,before,num in (('rear-whole',prior/'final-whole',3840),('near',base/'control-stock-near',4608),
                         ('near-whole',base/'control-stock-near-whole',4608),('isolated',prior/'final-isolated',1152)):
    old=read(before/'report.json')
    new=read(base/f'finish-{scope}'/'report.json')
    assert new['samples']==old['samples']==num
    old_keys={key(f) for f in old['failures']}
    new_keys={key(f) for f in new['failures']}
    previous={key(f) for f in old['failures'] if gap(f)}
    repaired={key(f) for f in new['failures'] if gap(f)}
    added=sorted(repaired-previous)
    results[scope]={'samples':num,'before':[len(old_keys),len(previous)],'after':[new['failed_samples'],len(repaired)],
                    'new_gap_keys':added,'new_flag_keys':sorted(new_keys-old_keys)}
    assert not added and not new_keys-old_keys,(scope,added,sorted(new_keys-old_keys))
    if scope=='isolated':
        assert not new_keys
        assert all(sha(p)==sha(before/p.name) for p in (base/f'finish-{scope}').glob('*.png')),scope
assert results['rear-whole']['before'][1]==2 and results['rear-whole']['after'][1]==0
assert results['near-whole']['before'][1]==254 and results['near-whole']['after'][1]==252

for suffix in ('finish-rear-whole','finish-near','finish-near-whole','finish-isolated','finish-damage','normal-finish','import-finish'):
    assert 'ERROR:' not in (base/(suffix+'.log')).read_text(encoding='utf-8'),suffix
backup=root/'art_src/characters/warden/forearm_overlap/armor_forearm-before.png'
new=root/'art_src/characters/warden/overrides/armor_forearm.png'
actual_diffuse=root/'art/characters/warden/parts/armor_forearm.png'
actual_normal=root/'art/characters/warden/parts/armor_forearm_n.png'
assert sha(new)==sha(actual_diffuse)==sha(base/'forearm-mip.png')
assert sha(actual_normal)==sha(base/'normal-finish.png')
assert sha(backup)==sha(base/'cut-check/warden/parts/armor_forearm.png')
assert sha(base/'normal-before.png')==sha(base/'normal-before-rebuilt.png')
old,patched,original_normal,baked=(np.asarray(Image.open(p).convert('RGBA')) for p in (backup,new,base/'normal-before.png',actual_normal))
changed=np.any(old!=patched,axis=2)
assert changed.sum()==64 and np.array_equal(patched[:,:,3],baked[:,:,3])
assert np.all(old[changed,3]<235) and np.all(old[changed,3]<patched[changed,3])
results['source']={'old':sha(backup),'diffuse':sha(actual_diffuse),'normal':sha(actual_normal),
                   'diffuse_pixels':int(changed.sum()),'normal_pixels':int(np.any(original_normal!=baked,axis=2).sum()),
                   'grid':[337,529]}
(base/'verification.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results))

