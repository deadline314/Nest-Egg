extends "res://tools/rig_joint_audit.gd"

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS,true)
	super._ready()
