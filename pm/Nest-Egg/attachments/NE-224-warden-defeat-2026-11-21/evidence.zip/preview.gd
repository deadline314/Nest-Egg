extends "res://tools/rig_preview.gd"

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS,true)
	super._ready()
