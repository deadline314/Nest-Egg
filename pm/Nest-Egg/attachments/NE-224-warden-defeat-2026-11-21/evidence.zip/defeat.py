from pathlib import Path
from PIL import Image,ImageDraw
import json
base=Path(__file__).resolve().parent
prior=base.parent/'evidence-20261121-ne224-warden-elbow'
sheet=Image.new('RGB',(576,457),(33,37,48))
draw=ImageDraw.Draw(sheet)
for row,facing in enumerate((1,-1)):
    for col,scope in enumerate((prior/'final-whole',base/'finish-rear-whole')):
        groups=json.loads((scope/'frames.json').read_bytes())
        group=next(g for g in groups if g['pose']=='dead' and g['zoom']==3.4)
        x,y,w,h=next(c['rect'] for c in group['cells'] if c['facing']==facing)
        cx=(x+65 if facing==1 else x+63)
        with Image.open(scope/group['samples'][5]['file']) as frame:
            crop=frame.crop((cx-17,y+32,cx+17,y+56)).convert('RGBA')
        paper=Image.new('RGBA',crop.size,(140,151,170,255))
        paper.alpha_composite(crop)
        ox,oy=8+col*288,8+row*226
        sheet.paste(paper.resize((272,192),Image.Resampling.NEAREST).convert('RGB'),(ox,oy+19))
        draw.text((ox,oy),f'{"Before" if col==0 else "With overlap"}, facing {"right" if facing==1 else "left"}',
                  fill='#f9fafc')
sheet.save(base/'defeat-compare.png')


