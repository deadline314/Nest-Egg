from pathlib import Path
from hashlib import sha256
import math
import re
import subprocess
import json
import runpy
import wave

base = Path(__file__).resolve().parent
root = Path.cwd()
old = (base / "cue-spectra.json").read_bytes()
namespace = runpy.run_path(str(base / "analyze-spectra.py"))
new = (base / "cue-spectra.json").read_bytes()
(base / "cue-spectra.json").write_bytes(old)
(base / "candidate-cue-spectra.json").write_bytes(new)
stock = json.loads(old)
candidate = json.loads(new)
glaive = ("melee_glaive_hit", "melee_glaive_hit_heavy")
before_sources = base / "old-streams"
before_sources.mkdir(exist_ok=True)
git_revision = (base / "baseline.txt").read_text().strip()
lengths = {}
def stream_spec(path):
    result = subprocess.check_output(["C:/ffmpeg/bin/ffprobe.exe","-v","error","-show_entries",
            "stream=duration_ts,sample_rate,channels","-of","json",str(path)],text=True)
    spec, = json.loads(result)["streams"]
    return spec
for cue in stock["cues"]:
    assert (stock["cues"][cue] != candidate["cues"][cue]) == (cue in glaive)
assert stock["sets"] == candidate["sets"]
trials = json.loads((base / "filter-trials.json").read_bytes())
for cue, low, expected in ((glaive[0], "melee_low_light", trials["180"]["light"]),
                           (glaive[1], "melee_low_light", trials["340"]["heavy"])):
    current = candidate["cues"][cue][0]
    assert all(current[key] == expected[key] for key in ("duration_ms","median_hz","centroid_hz","pct_at_most_250_hz"))
    assert current["median_hz"] * 0.94 > 3 * max(candidate["pitched_median_ranges_hz"][low])
    member = current["file"].removeprefix("res://")
    extracted = before_sources / Path(member).name
    extracted.write_bytes(subprocess.check_output(["git", "show", f"{git_revision}:{member}"]))
    assert sha256(extracted.read_bytes()).hexdigest() == stock["cues"][cue][0]["sha256"]
    assert stream_spec(extracted) == stream_spec(Path(member))
    lengths[cue] = stream_spec(extracted)
    print(cue, "median", stock["cues"][cue][0]["median_hz"], "to", current["median_hz"])
assert candidate["cues"][glaive[1]][0]["median_hz"] < candidate["cues"][glaive[0]][0]["median_hz"]
report = {"stock": stock["cues"], "candidate": candidate["cues"], "native": [], "stream_lengths": lengths}
archives = [[base/name, json.loads((base/name/"result.json").read_bytes())]
            for name in ("stock-glaive","candidate-glaive")]
def normalized_hit(data):
    return [{key:value for key,value in hit.items() if key not in ("tick","contact")} for hit in data]
for before, after in zip(archives[0][1]["rows"], archives[1][1]["rows"], strict=True):
    for key in ("name","weapon","move","side","reduced","expected_layers","played","settings","first_observed_pair_freeze"):
        assert before[key] == after[key], (key,before["name"])
    assert normalized_hit(before["hits"]) == normalized_hit(after["hits"]), (before["name"],before["hits"],after["hits"])
    for row in (before, after):
        assert row["first_observed_pair_freeze"] and row["hits"]
        assert "hit_tail" in row["live_voices"] and row["expected_layers"][1] in row["live_voices"]
        assert bool(row["world_shakes"]) != row["reduced"]
    hit_tick = lambda row: row["hits"][0]["tick"] - row["frames"][0]["tick"]
    point = lambda row: tuple(float(x) for x in re.findall(r"[-\d.]+",row["hits"][0]["contact"]))
    assert hit_tick(before) == hit_tick(after)
    report["native"].append({"name":before["name"], "current_voices":after["live_voices"], "hits":after["hits"],
                             "relative_hit_tick":hit_tick(after),"contact_delta_world":math.dist(point(before),point(after))})
for directory, result in archives:
    with wave.open(str(directory / "master.wav"),"rb") as wav:
        assert wav.getnchannels()==2 and wav.getsampwidth()==2 and wav.getnframes()>wav.getframerate()
        report[directory.name]={"rows":len(result["rows"]),"checks":result["checks"],
                                "audio_driver":result["audio_driver"], "frames":wav.getnframes(),"rate":wav.getframerate(),
                                "master_sha256":sha256((directory/"master.wav").read_bytes()).hexdigest()}
(base/"impact-comparison.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print("Eight same-context native matches; real playing low/high voice slots plus raw master WAVs.")
