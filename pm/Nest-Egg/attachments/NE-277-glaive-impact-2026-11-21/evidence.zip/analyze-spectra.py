from pathlib import Path
from hashlib import sha256
from itertools import chain
import json
import subprocess

import numpy as np

base = Path(__file__).resolve().parent
root = Path.cwd()
audio = json.loads((root / "data/audio/sound_bank.json").read_bytes())["sounds"]
events = json.loads((root / "data/feel/sound_events.json").read_bytes())["events"]
rate = 48000
width = 2048
cache = {}
freq = np.fft.rfftfreq(width, 1.0 / rate)

def spectrum(path):
    if path not in cache:
        source = root / path.removeprefix("res://")
        pcm = subprocess.check_output(
            ["C:/ffmpeg/bin/ffmpeg.exe", "-v", "error", "-threads", "1",
             "-i", str(source), "-f", "f32le", "-ac", "2", "-ar", str(rate), "pipe:1"], timeout=12)
        samples = np.frombuffer(pcm, dtype="<f4").reshape(-1, 2)
        # Use the complete first quarter second, including the initial transient.
        attack = samples[: rate // 4]
        attack = np.pad(attack, ((width // 2, width // 2), (0, 0)))
        power = np.zeros(len(freq), dtype=np.float64)
        for offset in range(0, len(attack) - width + 1, width // 2):
            frame = attack[offset:offset + width]
            spectrum = np.fft.rfft(frame * np.hanning(width)[:, None], axis=0)
            power += (abs(spectrum) ** 2).sum(axis=1)
        power[0] = 0
        assert power.sum() > 0 and np.isfinite(power).all()
        pct = 100 * power[freq <= 250].sum() / power.sum()
        cache[path] = {
            "sha256": sha256(source.read_bytes()).hexdigest(),
            "duration_ms": round(1000 * len(samples) / rate, 2),
            "median_hz": round(float(freq[np.searchsorted(np.cumsum(power), .5 * power.sum())]), 1),
            "centroid_hz": round(float(np.dot(freq, power) / power.sum()), 1),
            "pct_at_most_250_hz": round(float(pct), 2),
        }
    return cache[path]

def leaves(cue):
    if cue not in events:
        return [(cue, 1.0, 1.0)]
    return [(voice, *layer.get("pitch", (1.0, 1.0)))
            for layer in events[cue]["layers"] for voice in layer["sounds"]]

def variants(cue):
    return [{"voice": leaf, "file": path, "pitch": [lo, hi], **spectrum(path)}
            for leaf, lo, hi in leaves(cue) for path in audio[leaf]["files"]]

sets = {}
cue_ids = set()
for path in sorted((root / "data/melee").glob("*.json")):
    data = json.loads(path.read_bytes())
    rows = {}
    for ident, attack in data["attacks"].items():
        feedback = attack["feedback"]
        low, high = feedback["low"], feedback["high"]
        cue_ids.update((low, high))
        rows[ident] = [low, high]
    sets[path.stem] = rows
cues = {cue: variants(cue) for cue in sorted(cue_ids)}
summary = {}
for cue, leaves in cues.items():
    low = min(row["median_hz"] * row["pitch"][0] for row in leaves)
    high = max(row["median_hz"] * row["pitch"][1] for row in leaves)
    summary[cue] = [round(low, 1), round(high, 1)]
    print(f"{cue:23s} N={len(leaves)} median range={low:.1f}–{high:.1f} Hz")
(base / "cue-spectra.json").write_text(json.dumps({"sets":sets,"cues":cues,"pitched_median_ranges_hz":summary},indent=2)+"\n",
                                    encoding="utf-8")
assert len(sets) == 5 and len(cues) == 12
