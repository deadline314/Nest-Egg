from pathlib import Path
import json
import runpy

base=Path(__file__).resolve().parent
context=runpy.run_path(str(base/"analyze-spectra.py"))
spectrum=context["spectrum"]
results={}
for cutoff in (0,180,260,340,420,500):
    results[cutoff]={}
    for kind,suffix in (("light",""),("heavy","_heavy")):
        path=base/f"variant-{cutoff}"/"sfx"/f"melee_glaive_hit{suffix}_01.ogg"
        row=spectrum(path.as_posix())
        print(cutoff,kind,row["median_hz"],row["centroid_hz"],row["pct_at_most_250_hz"])
        results[cutoff][kind]=row
(base/"filter-trials.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8")
