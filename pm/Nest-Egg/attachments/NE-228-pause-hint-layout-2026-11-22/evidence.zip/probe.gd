extends "res://tests/smoke_test.gd"

var _out := ""


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://skip_modal_probe.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	super._ready()


func _run() -> void:
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	var level_file := "res://data/levels/ch1_prologue.tres"
	if "--pawnshop" in OS.get_cmdline_user_args():
		level_file = "res://data/levels/ch1_pawnshop.tres"
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(load(level_file) as LevelData)
	add_child(level)
	await _frames(260)
	var menu := level._pause_menu
	await _send_key(KEY_ESCAPE)
	await _frames(36)
	var hint := menu._root.get_node("FocusHintBar") as FocusHintBar
	for target: Button in [menu._map_button, menu._resume_button]:
		target.grab_focus()
		await _frames(6)
		var area := menu._root.get_global_rect()
		var menu_box := menu._menu_panel.get_global_rect()
		var info := menu._info_panel.get_global_rect()
		var tip := hint.get_global_rect()
		var overlap := tip.intersection(menu_box).size
		print("HINT_LAYOUT ", JSON.stringify({"level":str(level.data.id), "scale":Settings.get_ui_text_scale(),
			"focus":target.text, "area":str(area), "tip":str(tip), "menu":str(menu_box), "overlap": str(overlap),
			"info_overlap":tip.intersects(info)}))
		_check(get_tree().paused and target.has_focus() and not hint.text().is_empty(), "the real pause control has a focus hint")
		_check(area.encloses(tip), "the hint fits inside the pause viewport")
		_check(not tip.intersects(menu_box) and not tip.intersects(info), "the hint leaves both pause panels clear")
		await _shot("map" if target == menu._map_button else "resume")
	menu.close()
	await _frames(2)
	level.queue_free()
	await _frames(2)
	await _finish()

func _send_key(code: Key) -> void:
	var press := InputEventKey.new()
	press.keycode = code
	press.physical_keycode = code
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _send_button(button: JoyButton) -> void:
	var press := InputEventJoypadButton.new()
	press.button_index = button
	press.pressure = 1.0
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	release.pressure = 0.0
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _shot(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join(name + ".png")) == OK, "saved " + name)