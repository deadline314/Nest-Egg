from pathlib import Path
from math import isclose, hypot
from collections import Counter
import json
p=Path(__file__).resolve().parent
key=lambda r:(r['scenario'],r['facing'],r['front'],r['impact'])
def load(name):
    return {key(r):r for r in json.loads((p/name/'samples.json').read_bytes())}
before=load('cpu-baseline-full')
after=load('cpu-final-full')
assert len(before)==32 and before.keys()==after.keys()
facts=[]
for k,orig in before.items():
    fixed=after[k]
    a,b=orig['trace'],fixed['trace']
    assert len(a)==len(b)==61
    for frame,(prior,now) in enumerate(zip(a,b,strict=True)):
        assert prior['frame']==now['frame']==frame
        assert prior['contact']==now['contact'], (k,frame,prior['contact'],now['contact'])
        assert all(isclose(x,y,abs_tol=.002) for field in ('root','vel') for x,y in zip(prior[field],now[field])),(k,frame,prior,now)
        assert isclose(now['duration'],prior['duration'],abs_tol=.0001)
        if now['time']>.0001:
            assert now['dir']==(1 if orig['front'] else -1) and now['force']==(1 if orig['impact']==7.0 else 0),(k,frame,now)
    leaving=next((t for t in b if not t['contact']),None)
    if leaving is None:
        contact=b[0]['frame']
        assert all(abs(old['rotation']-new['rotation'])<=.002 and
                   all(hypot(xy[0]-new['bones'][bone][0],xy[1]-new['bones'][bone][1])<=.01
                       for bone,xy in old['bones'].items())
                   for old,new in zip(a,b,strict=True)),k
        facts.append(dict(case=k,kind='control',samples=len(a),contact=contact))
        continue
    start=leaving['frame']
    contact=next(t['frame'] for t in b[start:] if t['contact'])
    assert contact in range(15,50)
    hovering=b[start:contact]
    assert all(t['time']<=t['duration']*.58+.001 for t in hovering)
    assert max(abs(t['rotation']) for t in hovering)<1.2
    assert all(t['time']<=n['time'] for t,n in zip(b,b[1:]))
    angle_change=max(abs(b[i+1]['rotation']-b[i]['rotation']) for i in range(contact-1,contact+2))
    assert angle_change < .15,(k,angle_change)
    after_air_time=b[contact-1]['time']
    assert b[-1]['time'] >= .84*b[-1]['duration'] and abs(b[-1]['rotation'])>1.4
    facts.append(dict(case=k,kind='air',samples=len(a),contact=contact,
                      first_contact_rotation_before=a[contact]['rotation'],
                      first_contact_rotation_after=b[contact]['rotation'],
                      angle_change=angle_change,just_before_air_time=after_air_time,
                      floor=b[contact]['root'][1],settled_at_last_sample=b[-1]['time']>=b[-1]['duration']*1.05))
natives={}
for name,n in [('native-before',8),('native-final',8),('native-pawnshop-final',2)]:
    path=p/name
    native=load(name)
    assert len(native)==n
    assert 'RX 9070 XT' in (path/'raw.log').read_text(encoding='utf-8')
    assert (path/'exit.txt').read_text().strip()=='0'
    values=[]
    for k,row in native.items():
        s=row['trace']
        leave=next((t['frame'] for t in s if not t['contact']),0)
        contact=next((t for t in s[leave:] if t['contact']),None)
        assert contact is not None,(name,k)
        values.append(dict(case=k,contact=contact['frame'],rotation=contact['rotation'],
                           eventually_laid=abs(s[-1]['rotation'])>1.4))
    natives[name]=values
counts=Counter(row['kind'] for row in facts)
maximum=max(row['angle_change'] for row in facts if row['kind']=='air')
print(counts,'same root and velocity in',sum(row['samples'] for row in facts),'matched physics frames','landing maximum angular change',round(maximum,3))
print('Controlled render: 8 original, 8 updated; current authored pawnshop: 2.')
(p/'comparison.json').write_text(json.dumps(dict(facts=facts,native=natives,max_landing_delta=maximum),indent=2)+'\n',encoding='utf-8')


