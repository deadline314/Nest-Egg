extends "D:/NestEggVerification/evidence-20261120-ne222-fall-contact/fall.gd"

func _run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
	if out_dir.is_empty() or DisplayServer.get_name() == "headless":
		push_error("field fall requires native viewport and output")
		get_tree().quit(2)
		return
	Story.auto_skip = true
	_frames = true
	for face: int in [-1, 1]:
		await _sample("jump",face,face==1,7.0)
	var f := FileAccess.open(out_dir.path_join("samples.json"),FileAccess.WRITE)
	f.store_string(JSON.stringify(_rows,"\t"))
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)


func open_arena(_lighting_path: String, _player_tile := 12.0, _base_data: LevelData = null) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	level = Level.new()
	level.configure(load("res://data/levels/ch1_pawnshop.tres") as LevelData)
	add_child(level)
	await settle(25)
	player = level.player
	player.global_position = Vector2(86.0*16.0,19.0*16.0)
	player.velocity = Vector2.ZERO
	snap_camera()
	await settle(30)
	player.health.setup(100,0.0)
	await wait(TITLE_CARD_TIME)
	_check(player.is_on_floor(), "actual pawnshop floor supports Rin before jumping")
