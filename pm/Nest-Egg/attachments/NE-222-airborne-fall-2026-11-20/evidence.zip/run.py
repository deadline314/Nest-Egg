from pathlib import Path
from subprocess import run
import os,sys,json
base=Path(__file__).resolve().parent
shared=base.parent/'ne218-baseline-20261117'
case=sys.argv[1]
native='--native' in sys.argv
quick='--quick' in sys.argv
out=base/case
out.mkdir()
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    where=out/'profile'/key
    where.mkdir(parents=True)
    env[key]=str(where)
command=([sys.executable,str(shared/'tools/comfyui/gpu_lock.py'),'--'] if native else [])+['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(shared)]
command+=['--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan'] if native else ['--headless']
command+=['--fixed-fps','60',str(base/('field.tscn' if '--field' in sys.argv else 'fall.tscn')),'--',f'--out={out.as_posix()}']
if native: command.append('--frames')
if quick: command.append('--quick')
if '--no-hitstop' in sys.argv: command.append('--no-hitstop')
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
    result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=400)
raw=(out/'raw.log').read_text(encoding='utf-8')
(out/'exit.txt').write_text(str(result.returncode)+'\n')
n=sum(line.startswith('PASS') for line in raw.splitlines())
print(n,'case setup checks',case,'result',result.returncode,flush=True)
assert result.returncode==0 and 'ERROR:' not in raw and 'FAIL ' not in raw,raw
if native: assert 'RX 9070 XT' in raw


