extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
const LANGUAGES := {
	"zh": ["生命", "護盾", "殘機", "難度", "遊玩時間", "擊破數", "無限", "標準", "終結"],
	"ja": ["ライフ", "シールド", "残機", "難易度", "プレイ時間", "撃破数", "無制限", "標準", "フィニッシュ"],
	"en": ["Health", "Shield", "Retries", "Difficulty", "Play time", "Defeated", "Unlimited", "Standard", "Finishers"],
}
const IDS: Array[StringName] = [&"health", &"guard", &"lives", &"difficulty", &"time", &"kills"]
var _out := ""


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	if OS.get_cmdline_user_args().size() == 1:
		_out = OS.get_cmdline_user_args()[0]
	Settings.use_storage("user://status_page_locale.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	add_child(LightKit.create_environment())
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	for scene in Story.scene_ids():
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	await _frames(7)
	var bag := level._inventory
	bag.select_tab(bag.page_index(StatusPage))
	for language: String in LANGUAGES.keys():
		Story.set_language(language)
		bag.open()
		await get_tree().process_frame
		await get_tree().process_frame
		var page := bag._pages[bag.page_index(StatusPage)] as StatusPage
		var labels: Array = LANGUAGES[language]
		_check(bag.is_open() and page.is_visible_in_tree(), language + " real status tab")
		for i in IDS.size():
			var value := page._values[IDS[i]]
			var row := value.get_parent() as HBoxContainer
			var label := row.get_child(0) as Label
			_check(label.text == labels[i] and not row.tooltip_text.is_empty(), language + " translated stat " + str(IDS[i]))
			_check(bag._frame.get_global_rect().grow(1.0).encloses(row.get_global_rect()), language + " status remains on screen")
		_check(page._values[&"lives"].text == labels[6], language + " unlimited lives label")
		_check(page._values[&"difficulty"].text == labels[7], language + " original difficulty display")
		_check(page._values[&"kills"].text.contains(labels[8]), language + " finisher field")
		if language == "en" and _out.is_absolute_path():
			await RenderingServer.frame_post_draw
			_check(Capture.image(get_viewport()).save_png(_out) == OK, "native status capture")
		bag.close()
		await _frames(5)
	level.queue_free()
	await _frames(4)
	await _finish()
