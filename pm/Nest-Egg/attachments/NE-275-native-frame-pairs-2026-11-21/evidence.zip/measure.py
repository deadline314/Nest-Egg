from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import re
import subprocess
import sys

root = Path.cwd()
folder = Path(__file__).resolve().parent
parent = folder.parent
history = parent / "ne275-whole-frame-review-20261121"
current = parent / "ne275-whole-frame-current-20261121"
live_rev = "5d5d511f2161cf3d97aa0534fa20d2229a90f39a"
old_rev = "a42eaa524ea406e3b81c77ccc30208769c6b3a1f"
godot = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
weapons = ("blade", "dagger", "glaive", "maul", "whip")
baseline_inputs = ("tools/melee_art_probe.gd", "game/player/player_visual.gd", "data/weapon_art/melee.json", "project.godot")


def git(project, *args):
    return subprocess.check_output(["git", *args], cwd=project)


def verify():
    assert git(current, "rev-parse", "HEAD").decode().strip() == live_rev
    assert git(history, "rev-parse", "HEAD").decode().strip() == old_rev
    assert not git(current, "status", "--porcelain", "--untracked-files=no")
    assert not git(history, "status", "--porcelain", "--untracked-files=no")
    critical = baseline_inputs + ("game/rig/rig_part_mesh.gd", "game/player/melee_held.gd", "game/player/player.gd")
    assert all((current / name).read_bytes() == git(current,"show",f"{live_rev}:{name}") for name in critical)
    assert all((history / name).read_bytes() == git(current,"show",f"{old_rev}:{name}") for name in baseline_inputs)


def scene(probe):
    scene_file = folder / (probe + ".tscn")
    script_file = folder / (probe + ".gd")
    scene_file.write_text('[gd_scene load_steps=2 format=3]\n'
        f'[ext_resource type="Script" path="{script_file.as_posix()}" id="1"]\n'
        '[node name="WeaponEvidence" type="Node"]\nscript = ExtResource("1")\n')
    return str(scene_file)


def run(tag, project, probe="timing", fixed=False):
    directory = folder / tag
    already_recorded = (directory / "grip-timings.json").is_file()
    directory.mkdir(exist_ok=already_recorded)
    env = os.environ.copy()
    profile = folder / ("reference-profile" if project == history else "shipped-profile")
    for key in ("APPDATA", "LOCALAPPDATA", "XDG_DATA_HOME", "XDG_CONFIG_HOME", "TEMP", "TMP", "TMPDIR"):
        env[key] = str(profile / key)
        (profile / key).mkdir(parents=True, exist_ok=True)
    command = [sys.executable, "-B", str(root / "tools/comfyui/gpu_lock.py"), "--", godot, "--path", str(project),
               "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--audio-driver", "Dummy",
               "--resolution", "1280x720", "--quit-after", "22000"]
    if fixed:
        command += ["--fixed-fps", "60"]
    command += [scene(probe), "--", "--out=" + str(directory), "--tag=" + tag, "--quality=high"]
    if probe == "timing":
        command.append("--perf")
    if not already_recorded:
        (directory / "command.json").write_text(json.dumps(command, indent=2) + "\n")
        with (directory / "raw.log").open("wb") as log:
            outcome = subprocess.run(command, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        assert outcome.returncode == 0
    else:
        assert json.loads((directory / "command.json").read_bytes()) == command
    evidence = (directory / "raw.log").read_text(encoding="utf-8", errors="replace")
    assert "9070 XT" in evidence
    lines = [line for line in evidence.splitlines() if re.match(r"^(?:SCRIPT )?ERROR:",line)]
    if lines:
        timestamp = evidence.index("NE275_HISTORIC_TIMING:")
        assert project == history and all(re.fullmatch(r"ERROR: \d+ resources still in use at exit .+", line) and evidence.index(line) > timestamp for line in lines), (tag,lines)
        print("historical shutdown:",tag,lines,flush=True)
    summary = {}
    if probe == "settings":
        data = json.loads((directory / "current-settings.json").read_bytes())
        assert data["failures"] == 0 and set(data["weapons"]) == set(weapons)
        assert all(set(modes) == {"normal", "motion", "flashes", "both"} for modes in data["weapons"].values())
        return data
    data = json.loads((directory / "grip-timings.json").read_bytes())
    assert data["resolution"] == [1280,720] and "9070 XT" in data["gpu"] and data["renderer"] == "forward_plus"
    assert data["failures"] == data["max_fps"] == data["vsync"] == 0
    assert not data["reduced_flashes"] and not data["reduced_ui_motion"]
    assert set(data["records"]) == set(weapons)
    for arm in weapons:
        item = data["records"][arm]
        raw = item["samples_ms"]
        assert item["drawn"] and item["dedicated_attachment"] == (project == current)
        assert item["physics_steps"] >= 10 and item["scene_draw_calls"] > 0 and len(raw) == 600 and min(raw) > 0
        summary[arm] = median(raw)
    print(tag, {arm: round(value, 4) for arm, value in summary.items()}, flush=True)
    return summary


verify()
run("before-warm", history)
run("after-warm", current)
trials = []
for i in range(1, 11):
    order = ("before", "after") if i % 2 else ("after", "before")
    measurements = {name:run(f"{name}-{i:02d}", history if name == "before" else current) for name in order}
    trials.append({"order":order, "ms": measurements})
verify()
summary = {}
for arm in weapons:
    old = [row["ms"]["before"][arm] for row in trials]
    new = [row["ms"]["after"][arm] for row in trials]
    ratios = [100*(changed/initial-1) for initial,changed in zip(old,new,strict=True)]
    summary[arm] = {"old_median_ms":median(old),"new_median_ms":median(new),
                    "paired_median_pct":median(ratios),"paired_range_pct":[min(ratios), max(ratios)],
                    "pairs_new_faster":sum(delta<0 for delta in ratios),"all_pairs_pct":ratios}
(folder / "idle-timing.json").write_text(json.dumps({"ship":live_rev,"reference":old_rev,"trials":trials,
    "summary":summary}, indent=2)+"\n")
print(json.dumps(summary,indent=2),flush=True)
run("settings-current", current, "settings", fixed=True)





