
from pathlib import Path
from statistics import median
from math import isfinite
import json

base=Path(__file__).resolve().parent
def read(path):
    return json.loads(path.read_bytes())
versions=read(base/'idle-timing.json')
weapons=('blade','dagger','glaive','maul','whip')
assert len(versions['trials'])==10
assert versions['ship']=='5d5d511f2161cf3d97aa0534fa20d2229a90f39a'
assert versions['reference']=='a42eaa524ea406e3b81c77ccc30208769c6b3a1f'
stats={}
for weapon in weapons:
    medians=[]
    tails=[]
    for trial in range(1,11):
        readings=[]
        for version in ('before','after'):
            path=base/f'{version}-{trial:02}'/'grip-timings.json'
            record=read(path)
            assert '9070 XT' in record['gpu'] and record['renderer']=='forward_plus' and record['resolution']==[1280,720]
            samples=sorted(record['records'][weapon]['samples_ms'])
            assert len(samples)==600 and all(isfinite(x) and x>0 for x in samples)
            readings.append((median(samples),samples[int((len(samples)-1)*.99)]))
        medians.append(100*(readings[1][0]/readings[0][0]-1))
        tails.append(100*(readings[1][1]/readings[0][1]-1))
        assert abs(medians[-1]-versions['summary'][weapon]['all_pairs_pct'][trial-1])<1.e-9
    stats[weapon]={'median_pct':median(medians),'p99_pct':median(tails),
                   'median_range':[min(medians),max(medians)],'not_slower_pairs':sum(p<=0 for p in medians)}
settings=read(base/'settings-current/current-settings.json')
assert settings['failures']==0 and set(settings['weapons'])==set(weapons)
assert all(set(row)=={'normal','motion','flashes','both'} for row in settings['weapons'].values())
assert 'ERROR:' not in (base/'settings-current/raw.log').read_text(encoding='utf-8')
result={'reference':versions['reference'],'current':versions['ship'],'native_pairs':10,'frames':60000,
        'weapons':stats,'settings_cases':20,'timing_met':all(data['median_pct']<=0 for data in stats.values())}
(base/'verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))

