import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd();base=root/'art_src/characters';targets=[]
for name in ['rin_hands','rin_worn_coat']:
 r=json.loads((base/name/'manifest.json').read_text())
 for folder in (['overrides/refined'] if name=='rin_hands' else ['06_parts','07_refined','overrides/refined']):
  for part,digest in r['outputs'].items():
   p=base/'rin2'/folder/(part+'.png');assert hashlib.sha256(p.read_bytes()).hexdigest()==digest;targets.append(p)
def snapshot():return {str(p.relative_to(root)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mtime_ns':p.stat().st_mtime_ns} for p in targets}
before=snapshot()
for repeat in range(2):
 for name in ['rin_hands','rin_worn_coat']:
  subprocess.run([sys.executable,str(base/name/'rebuild.py')],check=True)
 assert snapshot()==before
report={'actual_registered_outputs':len(targets),'repeats':2,'all_original_png_bytes_and_timestamps_unchanged':True,'outputs':before}
(root/'work/portable-layers/actual-rebuild.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS actual sources:',len(targets),'destinations, two rebuilds, no rewritten PNGs')
