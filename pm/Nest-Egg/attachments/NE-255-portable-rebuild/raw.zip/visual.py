from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image,ImageDraw
root=Path.cwd();base=root/'art_src/characters';rows=[]
for family in ['rin_hands','rin_worn_coat']:
 folder=base/family;r=json.loads((folder/'manifest.json').read_text())
 for name,sha in r['outputs'].items():rows.append((name,folder/r['approved_outputs'][name],base/'rin2/overrides/refined'/(name+'.png'),sha))
family=base/'rin_support_grip_22308'
for name,sha in [('hand_back.png','d4da7778be1c6df46797795d2aff09799bb928fa645df278afe16825a2ee4f89'),('hand_back_n.png','22e3eeeb6699cdfd7b0141b2418661b85d40e2ebe9ffb78afd33e96d5ef8e6a7')]:rows.append(('support/'+name,family/'source/approved_outputs'/name,root/'work/portable-layers/support-after'/name,sha))
canvas=Image.new('RGB',(560,7*164),(225,225,225));draw=ImageDraw.Draw(canvas);report=[]
for i,(name,before,after,sha) in enumerate(rows):
 a=Image.open(before).convert('RGBA');b=Image.open(after).convert('RGBA');assert before.read_bytes()==after.read_bytes();assert hashlib.sha256(before.read_bytes()).hexdigest()==sha
 assert np.array_equal(np.array(a),np.array(b))
 box=a.getbbox();cx=(box[0]+box[2])//2;cy=(box[1]+box[3])//2;crop=(cx-64,cy-64,cx+64,cy+64)
 x=(i%2)*280;y=(i//2)*164;draw.text((x+3,y+3),name,fill=(0,0,0));draw.text((x+3,y+17),'approved       rebuilt; 0 changed pixels',fill=(0,0,0))
 for side,img in enumerate([a,b]):
  tile=Image.new('RGBA',(128,128),(127,127,127,255));tile.alpha_composite(img.crop(crop));canvas.paste(tile.convert('RGB'),(x+side*136+3,y+34))
 report.append({'name':name,'approved_sha256':sha,'rebuilt_sha256':hashlib.sha256(after.read_bytes()).hexdigest(),'rgba_differences':0,'native_crop':list(crop)})
(root/'work/portable-layers/visual.json').write_text(json.dumps(report,indent=2)+'\n');canvas.save(root/'work/portable-layers/approved-rebuilt.png')
