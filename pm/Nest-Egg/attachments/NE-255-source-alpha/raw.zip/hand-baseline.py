import importlib.util,runpy,subprocess,sys
from pathlib import Path
sys.path.insert(0,'tools/comfyui')
for name in ['make_parts','cut_layers','check_spec']:
 p=Path('work/source-alpha')/(name+'_before.py')
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m)
original=subprocess.run
def run(*a,**kw):
 try:return original(*a,**kw)
 except subprocess.CalledProcessError as e:
  print(e.stderr.decode() if isinstance(e.stderr,bytes) else e.stderr);raise
subprocess.run=run
runpy.run_path('tools/comfyui/test_hand_attachments.py',run_name='__main__')
