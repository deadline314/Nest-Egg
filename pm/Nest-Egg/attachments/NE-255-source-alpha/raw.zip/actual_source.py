import contextlib, hashlib, importlib.util, io, json, sys, platform, zlib
import PIL, cv2, scipy
from pathlib import Path
from unittest.mock import patch
import numpy as np
from PIL import Image,ImageDraw
root=Path.cwd(); sys.path.insert(0,str(root/'tools/comfyui'))
import make_parts,cut_layers
work=root/'work/source-alpha'
def frozen(name):
 s=importlib.util.spec_from_file_location(name,work/f'{name}_before.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old_parts,old_cuts=frozen('make_parts'),frozen('cut_layers')
source=root/'art_src/characters/guest_hong/01_design/exec-824e4f3f-6bfe-4d97-b4b2-3669b2b3157d.png'
source_sha=hashlib.sha256(source.read_bytes()).hexdigest()
a=np.array(Image.open(source).convert('RGBA')); cleaned=a.copy();cleaned[cleaned[:,:,3]<40,3]=0
report={'environment':{'python':platform.python_version(),'Pillow':PIL.__version__,'numpy':np.__version__,'opencv':cv2.__version__,'scipy':scipy.__version__,'zlib':zlib.ZLIB_RUNTIME_VERSION},'source':str(source.relative_to(root)),'source_sha256':source_sha,'input_size':[a.shape[1],a.shape[0]],'cleanup':'alpha below 40 -> 0 in disposable reference only; RGB and remaining alpha unchanged; original source/portrait not written','cleanup_pixels':int(((a[:,:,3]>0)&(a[:,:,3]<40)).sum()),'runs':{}}
base=json.loads((root/'tools/comfyui/specs/resident_side.json').read_text())
base.update(id='hong_coverage_probe',display_name='Hong coverage probe',groups={'body':{'sam':[],'rest':True}},parts={'body':{'group':'body','from':'waist','to':'neck','mode':'upright','uses':[{'name':'body','bone':'chest','z':0}]}},stages=[],glow={},tex_px_per_wp=21.69)
for key in ['eye_states','near_leg','refine','seam_checks']:base.pop(key,None)
images={}
for name,module,cutter,mode in [('before',old_parts,old_cuts,None),('legacy_after',make_parts,cut_layers,False),('preserved',make_parts,cut_layers,True)]:
 folder=work/name;folder.mkdir(exist_ok=True);(folder/'.gdignore').touch();Image.fromarray(cleaned).save(folder/'base_rgba.png')
 spec=dict(base)
 if mode is not None:spec['preserve_source_alpha']=mode
 path=folder/'spec.json';path.write_text(json.dumps(spec),encoding='utf8')
 with patch.object(sys,'argv',['parts','--spec',str(path),'--work',str(folder)]):module.main()
 with patch.object(sys,'argv',['cut','--spec',str(path),'--work',str(folder),'--char',str(folder/'character'),'--rig',str(folder/'rig.json')]):cutter.main()
 result=np.array(Image.open(folder/'06_parts/body.png'))
 images[name]=Image.fromarray(result)
 outputs={str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((folder/'character').rglob('*')) if p.is_file()}
 outputs['rig.json']=hashlib.sha256((folder/'rig.json').read_bytes()).hexdigest()
 report['runs'][name]={'outputs':outputs,'rgba_mismatches_vs_input':int(np.any(result!=cleaned,axis=2).sum()),'alpha_values':sorted(map(int,np.unique(result[:,:,3])))}
assert report['runs']['before']['outputs']==report['runs']['legacy_after']['outputs']
assert report['runs']['preserved']['rgba_mismatches_vs_input']==0
assert hashlib.sha256(source.read_bytes()).hexdigest()==source_sha
box=(330,10,670,360);w,h=340,350
canvas=Image.new('RGB',(w*3,(h+26)*3),(230,230,230));draw=ImageDraw.Draw(canvas)
for row,(label,img) in enumerate([('SOURCE: native RGBA; alpha <40 cleanup only',Image.fromarray(cleaned)),('BEFORE: legacy binary coverage',images['before']),('AFTER: opt-in source coverage',images['preserved'])]):
 for col,bg in enumerate([(0,0,0),(127,127,127),(255,255,255)]):
  tile=Image.new('RGBA',(w,h),(*bg,255));tile.alpha_composite(img.crop(box));canvas.paste(tile.convert('RGB'),(col*w,row*(h+26)+26))
 draw.text((8,row*(h+26)+7),label,fill=(0,0,0))
canvas.save(work/'hong-source-coverage.png')
(work/'actual-source.json').write_text(json.dumps(report,indent=2)+'\n')
print('ACTUAL SOURCE: legacy exports byte-identical; preserved full-canvas RGBA exact; input unchanged')
