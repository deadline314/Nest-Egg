param([Parameter(Mandatory)][string]$Label,[int]$FixedFPS=24,[switch]$Pad,[switch]$Image)
$ErrorActionPreference='Stop'
$e=$PSScriptRoot.Replace('\','/')
$d='D:/NestEggVerification/ne218-baseline-20261117'
$out=New-Item -ItemType Directory -Path "$e/$Label"
$profile=New-Item -ItemType Directory -Path "$out/profile"
$env:APPDATA=$profile.FullName
$env:LOCALAPPDATA=$profile.FullName
$engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$python='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
$size='1280x720'
$extra=@()
if($Pad){$extra+=@('--pad','--text-scale=1.2'); $size='1600x900'}
if($Image){$extra+='--image'}
& $python -B "$d/tools/comfyui/gpu_lock.py" -- $engine --path $d --rendering-method forward_plus --rendering-driver vulkan --resolution $size --fixed-fps $FixedFPS --audio-driver Dummy --quit-after 5000 "$e/native-physics.tscn" -- "--out=$($out.FullName)" @extra *> "$out/raw.log"
$result=$LASTEXITCODE
$result | Set-Content -LiteralPath "$out/exit.txt"
Get-Content -LiteralPath "$out/raw.log" -Tail 14
exit $result
