extends "res://tests/smoke_test.gd"

var _out := ""
var _pad := false


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://skip_modal_probe.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg == "--pad":
			_pad = true
		if arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	super._ready()


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(load("res://data/levels/ch1_warehouse.tres") as LevelData)
	add_child(level)
	await _frames(260)
	for node in get_tree().get_nodes_in_group(&"enemies"):
		node.set_physics_process(false)
	var player := level.player
	var gate: Checkpoint
	for node in level._entities.get_children():
		if node is Checkpoint and (gate == null or node.global_position.x < gate.global_position.x):
			gate = node
	var box: Throwable
	for node in get_tree().get_nodes_in_group(Throwable.GROUP):
		if node is Throwable and node.data.id == &"crate_small" and roundi(node.global_position.x / 16.0 - 0.5) == 43:
			box = node
			break
	_check(box != null and gate != null, "the real warehouse contains its box and switch A")
	if box == null or gate == null:
		await _finish()
		return
	player.global_position = box.global_position + Vector2(-10, 0)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	AimInput._last_stick_dir = Vector2.RIGHT
	await _frames(24)
	await _interact()
	await _frames(35)
	_check(player.carry.is_holding() and player.carry.held == box, "interact picks up the original box")
	player.global_position = gate.global_position + Vector2(-48.0, 0.0)
	player.velocity = Vector2.ZERO
	await _frames(12)
	Input.action_press(&"move_right")
	for frame in 85:
		if player.global_position.x >= gate.global_position.x - 12.0:
			break
		await _frames(1)
	Input.action_release(&"move_right")
	for frame in 450:
		if not DialogueLayer.radio_visible():
			break
		await _frames(1)
	await _frames(25)
	print("PHONE_ARRIVAL player=", player.global_position, " booth=", gate.global_position,
		" holding=", player.carry.held == box, " available=", gate.interaction_available())
	_check(gate.interaction_available() and player.carry.held == box, "the carried original crate reaches the real phone")
	if not gate.interaction_available() or player.carry.held != box:
		await _finish()
		return
	_check(box._prompt.is_showing() and not gate._prompt.is_showing(), "the hold prompt is visible before the drop")
	await _interact()
	await _frames(14)
	print("PHONE_DROP holding=", player.carry.is_holding(), " calling=", gate.is_calling(),
		" checkpoint=", GameState.has_checkpoint, " player=", player.global_position)
	_check(not player.carry.is_holding() and not gate.is_calling() and not GameState.has_checkpoint,
		"one physical edge drops the crate without starting or saving a call")
	if gate.is_calling():
		level.queue_free()
		await _frames(4)
		await _finish()
		return
	player.global_position = gate.global_position
	player.velocity = Vector2.ZERO
	await _frames(25)
	_check(gate.can_dial() and gate._prompt.is_showing() and not box._prompt.is_showing(),
		"the visible phone hint names the next press while near the crate")
	await _shot("next-press")
	await _interact()
	await _frames(13)
	print("PHONE_SECOND calling=", gate.is_calling(), " holding=", player.carry.is_holding())
	_check(gate.is_calling() and player.is_on_phone() and not player.carry.is_holding(),
		"a distinct press starts only the phone call")
	await _frames(85)
	_check(gate.activated and GameState.has_checkpoint, "the confirmed call still creates its checkpoint")
	level.queue_free()
	await _frames(4)
	await _finish()


func _interact() -> void:
	if _pad:
		var button := InputEventJoypadButton.new()
		button.button_index = InputBindings.get_joy_button(&"interact") as JoyButton
		button.pressed = true
		button.pressure = 1.0
		Input.parse_input_event(button)
		Input.flush_buffered_events()
		await _frames(3)
		var up := button.duplicate() as InputEventJoypadButton
		up.pressed = false
		up.pressure = 0.0
		Input.parse_input_event(up)
		Input.flush_buffered_events()
		return
	var press := InputEventKey.new()
	press.keycode = KEY_E
	press.physical_keycode = KEY_E
	press.pressed = true
	Input.parse_input_event(press)
	Input.flush_buffered_events()
	await _frames(3)
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	Input.parse_input_event(release)
	Input.flush_buffered_events()

func _shot(name: String) -> void:
	if DisplayServer.get_name() == "headless" or "--image" not in OS.get_cmdline_user_args():
		return
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join(name + ".png")) == OK, "saved " + name)