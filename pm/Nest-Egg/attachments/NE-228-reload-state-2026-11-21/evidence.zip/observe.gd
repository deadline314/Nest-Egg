extends "res://tools/ch1_flow_probe.gd"

var app: Node
var slot_path := ""
var headless := false
var results: Dictionary = {}
var ring: AmmoRing

func _ready() -> void:
	headless = DisplayServer.get_name() == "headless"
	if not headless:
		get_window().set_flag(Window.FLAG_NO_FOCUS,true)
	super._ready()


func _run() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--slot="):
			slot_path = arg.trim_prefix("--slot=")
	if not slot_path.is_absolute_path():
		get_tree().quit(2)
		return
	app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	app.set("_run_store",RunSaveStore.new(slot_path))
	add_child(app)
	for tick in STEP_LIMIT:
		if app.get("_screen") is MainMenu and not Transition.is_active():
			break
		await get_tree().process_frame
	var menu := app.get("_screen") as MainMenu
	if menu == null:
		get_tree().quit(3)
		return
	menu._continue_button.pressed.emit()
	for tick in STEP_LIMIT:
		var view := app.get("_screen") as Level
		if view != null and view.is_initialized() and view.data.id == &"ch1_street" and not Transition.is_active():
			_level = view
			break
		await get_tree().process_frame
	if _level == null or _level.player == null:
		get_tree().quit(4)
		return
	var player := _level.player
	ring = _level.hud.ammo_ring
	player.global_position.x = 472.0
	player.velocity = Vector2.ZERO
	player.health.grant_invulnerability(4.0)
	AimInput.set_virtual_gamepad(player,true)
	AimInput.restore_direction(Vector2.RIGHT)
	_level.camera.snap_to_target()
	await _settle(12)
	var loadout := player.loadout
	var selected := loadout.active_slot
	loadout.set_ammo(selected,2,-1)
	await _settle(8)
	_check(loadout.start_reload(),"real loadout starts a reload with two rounds")
	await _settle(9)
	await _sample("mid_reload",loadout)
	_check(ring._reloading and ring._prompt_obstacle_rect().has_area(),"active game reserves space for reload label")
	get_tree().paused = true
	loadout.refill_all()
	_check(not loadout.is_reloading(),"original checkpoint refill cancels the actual reload immediately")
	await _sample("paused_after_refill",loadout)
	get_tree().paused = false
	await _settle(3)
	await _sample("resumed",loadout)
	_check(not ring._reloading and not ring._prompt_obstacle_rect().has_area(),"the light HUD clears the finished reserve after resuming")
	var file := FileAccess.open(_out_dir.path_join("reload-observations.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures":_failures,"samples":results},"  ")+"\n")
	file.close()
	app.call("_quit",int(_failures>0))


func _sample(label: String, loadout: Loadout) -> void:
	if not headless:
		await RenderingServer.frame_post_draw
		_capture(label)
	var rect := ring._prompt_obstacle_rect()
	results[label] = {"game_reload":loadout.is_reloading(),"hud_reload":ring._reloading,
		"hud_progress":ring._reload_progress,"prompt_reserved":rect.has_area(),
		"ammo":loadout.mag_in(loadout.active_slot),"max_ammo":loadout.active_weapon().magazine_size,
		"paused":get_tree().paused}
