from pathlib import Path
from hashlib import sha256
from shutil import copy2
import json
import os
import re
import subprocess
import sys

base=Path(__file__).resolve().parent
project=base.parent/"ne218-baseline-20261117"
scope=base/sys.argv[1]
headless="headless" in sys.argv[2:]
scope.mkdir()
env=os.environ.copy()
for key in ("APPDATA","LOCALAPPDATA","TEMP","TMP","TMPDIR","XDG_CONFIG_HOME","XDG_DATA_HOME"):
    profile=scope/key
    profile.mkdir()
    env[key]=str(profile)
seed=Path.cwd()/"work/ne97-campaign-route-20261119/native-camera-fresh-close-v1/save/slot.json"
slot=scope/"slot.json"
copy2(seed,slot)
sha=lambda path:sha256(path.read_bytes()).hexdigest()
paths=("ui/ammo_ring.gd","game/player/loadout.gd","game/player/player.gd","tests/suite/test_combat_hud.gd")
sources={name:sha(project/name) for name in paths}
engine="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
command=[engine,"--path",str(project)]
if headless:
    command.append("--headless")
else:
    command=[sys.executable,"-B",str(project/"tools/comfyui/gpu_lock.py"),"--"]+command
    command+=["--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy","--resolution","1280x720"]
command+=["--fixed-fps","60","--quit-after","2700",str(base/"observe.tscn"),"--",f"--out={scope}",f"--slot={slot}"]
(scope/"command.json").write_text(json.dumps({"argv":command,"source":sources,"seed_sha256":sha(seed)},indent=2)+"\n")
with (scope/"engine.log").open("wb") as file:
    p=subprocess.run(command,cwd=project,env=env,stdout=file,stderr=subprocess.STDOUT,timeout=250)
log=(scope/"engine.log").read_text(encoding="utf8",errors="replace")
assert p.returncode==0 and not re.search(r"^(?:SCRIPT )?ERROR:|^FAIL ",log,re.M),log[-3750:]
data=json.loads((scope/"reload-observations.json").read_bytes())
assert data["failures"]==0 and len(data["samples"])==3
assert {name:sha(project/name) for name in paths}==sources
print(json.dumps(data),flush=True)
