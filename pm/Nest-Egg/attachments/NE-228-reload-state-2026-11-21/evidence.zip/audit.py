import json
from pathlib import Path

root=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
rows={}
for mode in ("headless","native"):
    before=root/f"stock-{mode}"
    after=root/f"candidate-{mode}"
    x,y=[read(member/"reload-observations.json")["samples"] for member in (before,after)]
    assert len(x)==len(y)==3
    assert x["mid_reload"]==y["mid_reload"] and x["resumed"]==y["resumed"],(mode,x,y)
    assert x["mid_reload"]["hud_reload"] and x["mid_reload"]["prompt_reserved"]
    assert x["resumed"]["ammo"]==12 and not x["resumed"]["prompt_reserved"]
    old,new=x["paused_after_refill"],y["paused_after_refill"]
    assert all(old[k]==new[k] for k in ("ammo","max_ammo","paused","game_reload"))
    assert old["ammo"]==old["max_ammo"] and old["paused"] and not old["game_reload"]
    assert old["hud_reload"] and old["hud_progress"]>0.0 and old["prompt_reserved"]
    assert not new["hud_reload"] and new["hud_progress"]==0.0 and not new["prompt_reserved"]
    a,b=[read(member/"command.json") for member in (before,after)]
    assert a["seed_sha256"]==b["seed_sha256"]
    for unchanged in ("game/player/loadout.gd","game/player/player.gd"):
        assert a["source"][unchanged]==b["source"][unchanged]
    rows[mode]={"old_paused_refill":old,"new_paused_refill":new,"preserved_active_reload":x["mid_reload"],
                "preserved_resumed_play":x["resumed"]}
(root/"paired-results.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf8")
print(json.dumps(rows),flush=True)
