from pathlib import Path
from collections import Counter
from hashlib import sha256
from PIL import Image, ImageDraw
from scipy import ndimage
import json
import numpy as np

base=Path(__file__).resolve().parent
prior=base.parent/'evidence-20261122-ne224-warden-wrist-overlap'
def read(path):
    return json.loads(path.read_bytes())
def report(folder):
    data=read(folder/'report.json')
    assert data['samples']==15360
    return {(r['pose'],r['zoom'],r['facing'],r['frame'],r['joint']):r for r in data['failures']}
def hard(row):
    return bool(row['center_alpha']<128 or row['enclosed_pixels'] or row['loose_pieces'])
def subgroup(rows,pose,joint):
    return sum(hard(r) and k[:2]==(pose,3.4) and k[-1]==joint for k,r in rows.items())
stats={}
for mode in ('whole','dressed','isolated'):
    orig=prior/f'final-{mode}'
    result=base/f'final-{mode}'
    a,b=report(orig),report(result)
    hard_added={k for k,r in b.items() if hard(r) and (k not in a or not hard(a[k]))}
    added=b.keys()-a.keys()
    distribution=Counter(f'{x[0]}/{x[1]}/{x[-1]}' for x in added)
    print(mode,'hard_added',sorted(hard_added)[:25], 'added edge',distribution)
    assert not hard_added,mode
    assert not added,(mode,dict(distribution))
    stats[mode]={'samples':15360,'hard_before':sum(map(hard,a.values())),'hard_after':sum(map(hard,b.values())),
        'added':len(added),'edge_before':len(a)-sum(map(hard,a.values())),'edge_after':len(b)-sum(map(hard,b.values()))}
    if mode=='whole':
        for pose,joint,before in (('block','shoulder_front',86),('dead','wrist_front',100)):
            assert (subgroup(a,pose,joint),subgroup(b,pose,joint))==(before,0)
assert stats['whole']['hard_before']==206 and stats['whole']['hard_after']<=20
assert stats['dressed']['hard_after']==stats['isolated']['hard_after']==0
controls={}
for label in ('before','after'):
    folder=base/f'arena-{label}'
    assert (folder/'exit.txt').read_text().strip()=='0' and 'ERROR:' not in (folder/'raw.log').read_text()
    arena=read(folder/'street.json')
    assert arena['hdr_2d'] and arena['rendering_method']=='forward_plus' and 'RX 9070 XT' in arena['adapter']
    controls[label]={r['key']:{k:v for k,v in r.items() if k!='physics_frame'} for r in arena['rows']}
    assert len(controls[label])==52
    assert sum(v['dying'] and v['health']==0 for v in controls[label].values())==24
assert controls['before']==controls['after']
stats['arena_cases']=52
stats['arena_lethal_frames']=24
parts=Path('art/characters/warden/parts')
stats['textures']={}
for name,count in (('head',32),('armor_forearm',43)):
    stock=np.array(Image.open(base/f'stock-{name}.png').convert('RGBA'))
    update=np.array(Image.open(parts/f'{name}.png').convert('RGBA'))
    assert stock.shape==update.shape
    delta=np.any(stock!=update,axis=2)
    assert delta.sum()==count and not np.any(delta&(stock[:,:,3]>=235))
    override=Path(f'art_src/characters/warden/overrides/{name}.png')
    assert override.read_bytes()==(parts/f'{name}.png').read_bytes()
    stats['textures'][name]={'changed':count,'size':[stock.shape[1],stock.shape[0]],
        'diffuse_sha256':sha256((parts/f'{name}.png').read_bytes()).hexdigest(),
        'normal_sha256':sha256((parts/f'{name}_n.png').read_bytes()).hexdigest()}
assert (parts/'head_glow.png').read_bytes()==(base/'stock-head_glow.png').read_bytes()
stats['textures']['head_glow_sha256']=sha256((parts/'head_glow.png').read_bytes()).hexdigest()
pic=Image.new('RGB',(960,640),'#565c62')
overlay=ImageDraw.Draw(pic)
for col,path in enumerate((prior/'final-whole',base/'final-whole')):
    for row,(pose,frame,joint,description) in enumerate((
        ('block',60,'shoulder_front','Guard at sample 60'),
        ('dead',85,'wrist_front','Extended fall diagnostic at sample 85'))):
        sample=read(path/'frames.json')
        group=next(g for g in sample if g['pose']==pose and g['zoom']==3.4)
        cell=next(c for c in group['cells'] if c['joint']==joint and c['facing']==1)
        x,y,*_=cell['rect']
        im=Image.open(path/f'{pose}_3.4_{frame:03}.png').convert('RGBA')
        crop_top=y+(38 if pose=='dead' else 26)
        crop_left=x+18
        crop=im.crop((crop_left,crop_top,crop_left+96,crop_top+64)).resize((480,320),Image.Resampling.NEAREST)
        pic.paste(crop,(col*480,row*320),crop)
        reference=Image.open(prior/'final-whole'/f'{pose}_3.4_{frame:03}.png').convert('RGBA')
        radius=cell['radius']
        left,top=x+64-radius,y+64-radius
        mask=np.asarray(reference.getchannel('A'))[top:top+2*radius,left:left+2*radius]>=128
        locations=np.argwhere(ndimage.binary_fill_holes(mask,structure=np.ones((3,3)))&~mask)
        assert len(locations)==1,(pose,locations.tolist())
        yy,xx=locations[0]
        pin_x=col*480+5*(left+xx-crop_left)+2
        pin_y=row*320+5*(top+yy-crop_top)+2
        overlay.ellipse((pin_x-9,pin_y-9,pin_x+9,pin_y+9),outline='#ff314b',width=2)
        overlay.text((col*480+7,row*320+7),f'{description} - {("before","after")[col]}',fill='white',stroke_width=1,stroke_fill='black')
pic.save(base/'comparison.png')
(base/'comparison.json').write_text(json.dumps(stats,indent=2)+'\n')
print(json.dumps(stats))
