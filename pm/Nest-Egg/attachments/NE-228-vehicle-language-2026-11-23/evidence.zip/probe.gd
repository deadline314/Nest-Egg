extends Node

const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://vehicle-copy-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.auto_skip = true
	for entry: Array in [
		["en", "Bulwark MK-II", "%s Board %s", "Aboard %s. %s to exit.", "%s destroyed."],
		["ja", "バルワーク MK-II", "%s %s に乗る", "%s に搭乗。%s で降りる。", "%s は大破しました。"],
		["zh", "壁壘 MK-II", "%s 搭乘 %s", "搭乘 %s（%s 離開）", "%s 已損毀"],
	]:
		await _exercise(entry)
	await AudioRelease.settle(get_tree())
	await _finish()


func _exercise(copy: Array) -> void:
	var language: String = copy[0]
	var title: String = copy[1]
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	InputBindings._set_device(false, -1)
	var map := load("res://data/levels/level_01.tres") as LevelData
	# Use the already visited map, so dialogue does not intentionally hide world prompts.
	Story._seen[map.intro_scene] = true
	for scene: String in map.story_triggers:
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(map)
	add_child(level)
	await _frames(213)
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		enemy.set_physics_process(false)
	var vehicle := level.get_tree().get_first_node_in_group(&"vehicles") as Vehicle
	_check(vehicle != null and vehicle.can_mount(), language + " route loads the actual rain-night vehicle")
	if vehicle == null:
		level.queue_free()
		await _frames(6)
		return
	var player := level.player
	player.global_position = vehicle.global_position + Vector2(18.0, 0.0)
	player.velocity = Vector2.ZERO
	await _frames(25)
	_check(vehicle._prompt.is_showing()
			and vehicle._prompt._display_text == copy[2] % [InputBindings.primary_label(&"interact"), title],
			language + " reachable boarding prompt uses the current keyboard input and vehicle name")
	if language == "ja":
		await _picture("board-ja.png")
	await _key(KEY_E)
	var banner := level.hud.toast_banner
	await _frames(12)
	_check(player.mounted_vehicle == vehicle and vehicle.driver == player, language + " pressing the real interaction mounts the vehicle")
	_check(banner._label.text == copy[3] % [title, InputBindings.primary_label(&"interact")],
			language + " mounted banner describes how to exit with the keyboard")
	await _joy(JOY_BUTTON_RIGHT_SHOULDER)
	_check(InputBindings.using_gamepad and player.mounted_vehicle == vehicle
			and banner._label.text == copy[3] % [title, InputBindings.primary_label(&"interact")],
			language + " visible banner follows the controller without changing the ride")
	if language == "en":
		await _picture("mounted-en.png")
	await _frames(15)
	var interact := InputBindings.get_joy_button(&"interact") as JoyButton
	await _joy(interact)
	_check(player.state == Player.State.NORMAL and vehicle.driver == null,
			language + " the announced controller input dismounts normally")
	await _frames(31)
	player.global_position = vehicle.global_position + Vector2(18.0, 0.0)
	player.velocity = Vector2.ZERO
	await _frames(18)
	await _joy(interact)
	_check(player.mounted_vehicle == vehicle, language + " the same controller action boards again")
	vehicle.health.kill(DamageInfo.create(vehicle.health.current, Combat.Team.ENEMY, &"probe_hit"))
	await _frames(18)
	_check(vehicle.destroyed and player.mounted_vehicle == null and banner._label.text == copy[4] % title,
			language + " the original ejection produces the localized destruction banner")
	level.queue_free()
	InputBindings.clear_held_inputs()
	await _frames(8)



func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _tap(event)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	await _tap(event)


func _tap(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish() -> void:
	await _frames(7)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))
