from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path("D:/NestEggVerification/camera-20261117")
OUT = Path("D:/NestEggVerification/evidence-20261117/ne266/formal-v4")
OUT.mkdir(exist_ok=False)
paths = ["tools/screenshot.gd", "tools/scenarios/scenario_base.gd", "tools/scenarios/enemy_scenarios.gd", "tools/scenarios/ch2_market_enemies_scenario.gd", "tools/select_tests.py", "tools/run_tests_changed.sh", "tools/run_tests_parallel.sh", "tests/known_failures.txt", "tests/suite/test_ch2_enemies.gd"]
paths += [p for p in subprocess.check_output(["git", "ls-files", "-z", "core", "game", "autoload", "ui", "data"], cwd=ROOT).decode("utf8").split("\0") if p]
paths = sorted(set(paths))


def snapshot():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")


before = snapshot()
write("source-before.json", before)
env = os.environ.copy()
env.update(GODOT="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", SHARDS="2", PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
commands = [
    ("changed", 'python3() { python "$@"; }; export -f python3; tools/run_tests_changed.sh 6e47e2fe5e32ee3f13583bf7d59ae79953b65a85'),
    ("chapter2-enemies", 'python3() { python "$@"; }; export -f python3; tools/run_tests_parallel.sh --only=Chapter2EnemiesSuite'),
]
results = []
for name, command in commands:
    folder = OUT / name
    folder.mkdir()
    env["LOG_DIR"] = str(folder / "shards")
    argv = ["C:/Program Files/Git/bin/bash.exe", "-c", command]
    start = time.monotonic()
    with (folder / "runner.log").open("wb") as log:
        completed = subprocess.run(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    results.append({"name": name, "command": argv, "exit": completed.returncode, "elapsed_s": time.monotonic() - start})
    print(name, "exit", completed.returncode, flush=True)
    if completed.returncode:
        break
after = snapshot()
write("source-after.json", after)
write("result.json", {"base": "6e47e2fe5e32ee3f13583bf7d59ae79953b65a85", "commands": results, "source_unchanged": before == after, "scope": "Original changed-selector entry for four standalone screenshot utilities, plus existing complete Chapter2EnemiesSuite covering actual combat data/three difficulties. Existing seven archived NE256 files and read-only NE266 private diagnostics remain untracked and are not imported by these checks."})
assert before == after
assert len(results) == 2 and all(r["exit"] == 0 for r in results)
print("NE266_FORMAL sourceheld", len(before), flush=True)
