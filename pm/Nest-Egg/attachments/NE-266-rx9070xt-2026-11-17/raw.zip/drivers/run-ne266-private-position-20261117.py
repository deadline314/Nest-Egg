from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import psutil

ROOT = Path("D:/NestEggVerification/camera-20261117")
OUT = Path("D:/NestEggVerification/evidence-20261117/ne266/private-position-trace-v1")
OUT.mkdir(parents=True, exist_ok=False)
paths = [p for p in subprocess.check_output(["git", "ls-files", "-z", "autoload", "core", "game", "ui", "data", "art/characters", "art/rigs", "tools/scenarios", "tools/screenshot.gd", "tools/screenshot.tscn", "tools/bg55_enemy_action_probe.gd", "tools/bg55_enemy_action_probe.tscn", "tools/held_lighting_state.gd", "tools/viewport_capture.gd", "project.godot"], cwd=ROOT).decode("utf8").split("\0") if p and (ROOT / p).is_file()]


def snapshot():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")


paths += ["work/ne266-position/trace.gd", "work/ne266-position/host.gd", "work/ne266-position/host.tscn"]
before = snapshot()
write("source-before.json", before)
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "XDG_DATA_HOME", "XDG_CONFIG_HOME"):
    env[key] = str(OUT / "private-profile" / key)
command = ["D:/ComfyUI/.venv-rocm/Scripts/python.exe", str(ROOT / "tools/comfyui/gpu_lock.py"), "--", "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(ROOT), "--rendering-driver", "vulkan", "--rendering-method", "forward_plus", "--resolution", "1280x720", "--fixed-fps", "60", "res://work/ne266-position/host.tscn", "--", "--out=" + str(OUT), "--scenario=ch2_market_enemies"]
write("request.json", {"command": command, "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip(), "status_tracked": subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"], cwd=ROOT).decode("utf8"), "scope": "PRIVATE read-only position trace subclass, actual current candidate scenario under a small explicit host; not the public screenshot caller. Parentframephysics/position/HP observations only. Isolated HEAD6e47+4toolcandidate, 7 preserved old private fixtures. Guard4224 tracked runtime/art files. Two UI glyph sources already published in this worktree HEAD; private trace files explicitly guarded. Tool arranges player; validate real5 PNGs/enemy states and latest explicit report; not natural chapter play. Not natural chapter traversal."})
start = time.monotonic()
with (OUT / "native.log").open("wb") as log:
    proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    try:
        code = proc.wait(timeout=600)
        natural = True
    except subprocess.TimeoutExpired:
        for child in reversed(psutil.Process(proc.pid).children(recursive=True)):
            try:
                child.kill()
            except psutil.NoSuchProcess:
                pass
        proc.kill()
        proc.wait()
        code = 124
        natural = False
after = snapshot()
write("source-after.json", after)
write("result.json", {"exit": code, "natural": natural, "elapsed_s": time.monotonic() - start, "source_unchanged": before == after})
assert before == after
print("NE266_DIAGNOSTIC", code, "natural", natural, "sourceheld", before == after, flush=True)
