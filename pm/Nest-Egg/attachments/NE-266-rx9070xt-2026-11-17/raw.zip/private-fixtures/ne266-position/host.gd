extends Node
func _ready() -> void:
	_run.call_deferred()
func _run() -> void:
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	var probe = load("res://work/ne266-position/trace.gd").new()
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): probe.out_dir = arg.trim_prefix("--out=")
	add_child(probe)
	await probe.run()
	var count: int = probe.failures
	probe.queue_free()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if count else 0)
