extends "res://tools/scenarios/ch2_market_enemies_scenario.gd"
func _place(x_tile: float, row: int) -> void:
	super._place(x_tile, row)
	print("[DEBUG-ne266] immediate requested=",x_tile," actual=",player.global_position," physics=",player.is_physics_processing()," fall_limit=",player.fall_limit_y," safe=",player._last_safe_position," hp=",player.health.current," frozen=",Fx.is_frozen(player)," snapshot=",Fx._frozen.get(player,[]))
	_trace.call_deferred(x_tile)
func _trace(tile: float) -> void:
	for frame in 3:
		await get_tree().physics_frame
		await get_tree().process_frame
		if not is_instance_valid(player): return
		print("[DEBUG-ne266] after frame=",frame," requested=",tile," actual=",player.global_position," physics=",player.is_physics_processing()," velocity=",player.velocity," safe=",player._last_safe_position," hp=",player.health.current," frozen=",Fx.is_frozen(player)," snapshot=",Fx._frozen.get(player,[]))
