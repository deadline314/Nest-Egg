extends Node

func _ready() -> void:
	call_deferred("_run")

func _run() -> void:
	var root := get_tree().root
	root.size = Vector2i(1280, 720)
	Story.language = "zh"
	Settings.set_ui_text_scale(1.2)
	var output := "res://work/ne229-recovery"
	for variant: String in ["before", "after"]:
		var script: Script = load("res://work/ne229-recovery/before.gd" if variant == "before" else "res://ui/radio_save_prompt.gd")
		var prompt: Control = script.new()
		root.add_child(prompt)
		for i in 5: await get_tree().process_frame
		prompt.cancel_button.grab_focus()
		await get_tree().process_frame
		prompt.set_recovery(true)
		for i in 5: await get_tree().process_frame
		print("FOCUS ", variant, " ", prompt.retry_button.has_focus())
		await RenderingServer.frame_post_draw
		root.get_texture().get_image().save_png(output + "/" + variant + ".png")
		prompt.queue_free()
		for i in 3: await get_tree().process_frame
	get_tree().quit()
