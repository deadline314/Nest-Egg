from pathlib import Path
import subprocess,os,time,json,hashlib
b=Path(__file__).parent;p=b/'audio'
while not (b/'ne230-terminal-affected.exit').exists():time.sleep(2)
assert (b/'ne230-terminal-affected.exit').read_text()=='0'
product=p/'game/main.gd';candidate=product.read_bytes();assert hashlib.sha256(candidate).hexdigest()==json.loads((b/'ne230-terminal-test-inputs.json').read_text())['game/main.gd']
env=os.environ.copy();env['NE_NATIVE_PROJECT']='audio';results=[]
def run(name,mode,slot):
 args=['python',str(b/'native.py'),name,'res://work/ne230_terminal_probe.tscn','--mode='+mode,'--save-dir='+str(b/slot)]
 r=subprocess.run(args,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT);results.append({'name':name,'exit':r.returncode});(b/'ne230-terminal-native-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 log=(b/(name+'.log')).read_text()
 if any(x in log for x in ['SCRIPT ERROR:','Parse Error:','Compile Error:']):raise RuntimeError('script error in '+name)
 return r.returncode
try:
 product.write_bytes((b/'ne230-terminal-main-before.gd').read_bytes())
 assert run('ne230-terminal-native-before','refuse_write','ne230-terminal-before-slot')!=0
finally:product.write_bytes(candidate)
assert product.read_bytes()==candidate
for name,mode,slot in [('ne230-terminal-native-refuse','refuse_write','ne230-terminal-refuse-slot'),('ne230-terminal-native-refuse-cold','refuse_read','ne230-terminal-refuse-slot'),('ne230-terminal-native-retry','retry_write','ne230-terminal-retry-slot'),('ne230-terminal-native-retry-cold','accept_read','ne230-terminal-retry-slot')]:
 assert run(name,mode,slot)==0
assert product.read_bytes()==candidate
(b/'ne230-terminal-native-candidate-restored.json').write_text(json.dumps({'sha256':hashlib.sha256(candidate).hexdigest(),'restored':True},indent=2)+'\n')
