extends "res://tools/run_save_probe.gd"
## Real Main and Level signal, actual filesystem refusal, separate-process reads.
## Arranged room/checkpoint fixtures; not a chapter playthrough.

const LAST := "res://data/levels/ch1_pawnshop_dawn.tres"
var _out := ""
var _record: Dictionary = {}

func _ready() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=")
	if not _out.is_empty():
		DirAccess.make_dir_recursive_absolute(_out)
	super._ready()

func _run() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
	Story.auto_skip = true
	Transition.instant = true
	_main = MainScript.new()
	_main.process_mode = Node.PROCESS_MODE_PAUSABLE
	var store := RunSaveStore.new(_directory.path_join("slot.json"))
	_main.set("_run_store", store)
	add_child(_main)
	await _frames(3)
	if _mode in ["refuse_read", "accept_read"]:
		if DirAccess.dir_exists_absolute(store.path + ".tmp"):
			_check(DirAccess.remove_absolute(store.path + ".tmp") == OK, "remove only the previous probe-owned obstruction")
		var saved := store.read()
		_main.call("_on_continue_requested")
		var screen := await _settled()
		_check(screen is VictoryScreen if _mode == "accept_read" else screen is Level, "fresh Main returns to the accepted ending or uncompleted source")
		_check(bool(_main.get("_chapter_complete")) == (_mode == "accept_read"), "cold completion metadata matches the durable outcome")
		_check(Progression.credits == int(saved.get("progression", {}).get("credits", -1)), "cold continue restores the actual saved wallet")
		_check(not GameplayLock.is_locked() and not get_tree().paused and _prompt() == null, "cold continue has no stale recovery pause")
		_record = {"saved_complete": saved.get("chapter_complete"), "screen": screen.get_class(), "is_victory": screen is VictoryScreen}
		await _shot("cold-continue")
		await _finish()
		return
	_check(_mode in ["refuse_write", "retry_write"], "known terminal probe mode")
	_main.call("_on_start_requested", GameState.difficulties[1])
	await _settled()
	_main.call("_on_area_requested", LAST)
	var source := await _settled() as Level
	_check(source != null and source.data.resource_path == LAST and _main.call("_next_level", source.data) == null, "real Main reaches the authored cumulative-edition terminal room")
	if source == null:
		await _finish()
		return
	Story.reset_active_presentation(&"probe_setup")
	Progression.add_credits(37)
	_main.call("_flush_save")
	var baseline := FileAccess.get_file_as_bytes(store.path)
	var owners := _persistent_owners()
	_check(DirAccess.make_dir_absolute(store.path + ".tmp") == OK, "actual filesystem obstruction blocks terminal completion")
	var delivered := [false]
	source.completed.connect(func() -> void: delivered[0] = true, CONNECT_DEFERRED | CONNECT_ONE_SHOT)
	source.set("_ending", true) # Arranged completed boundary, not an entire chapter playthrough.
	source.completed.emit()
	var deadline := Time.get_ticks_msec() + 120000
	while not delivered[0] and Time.get_ticks_msec() < deadline:
		await _frames(1)
	_check(delivered[0], "actual deferred Level completion reached Main")
	var current := await _settled()
	_check(current == source and not bool(_main.get("_chapter_complete")), "refused terminal write retains the exact source and uncompleted Main metadata")
	_check(owners == _persistent_owners(), "refused completion preserves wallet checkpoint loadout and story")
	_check(baseline == FileAccess.get_file_as_bytes(store.path), "actual refused completion keeps exact primary bytes")
	var prompt := _prompt()
	_check(prompt != null and prompt.is_visible_in_tree() and not prompt.can_stay and prompt.purpose == "ending", "terminal refusal offers explicit retry instead of saved Victory")
	_check(GameplayLock.is_locked() and get_tree().paused, "terminal refusal holds its own recovery pause")
	if prompt != null:
		var back := InputEventAction.new()
		back.action = &"ui_cancel"
		back.pressed = true
		prompt._unhandled_input(back)
		_check(_prompt() == prompt, "Back cannot strand the completed source")
	_record = {"primary_unchanged": baseline == FileAccess.get_file_as_bytes(store.path), "after_refusal_victory": current is VictoryScreen, "source": LAST}
	await _shot("terminal-refused")
	if _mode == "retry_write":
		if prompt != null:
			prompt.retry_button.pressed.emit()
		current = await _settled()
		_check(current == source and _prompt() != null, "second refused write still exposes a usable retry")
		_check(DirAccess.remove_absolute(store.path + ".tmp") == OK, "remove only the probe-owned terminal obstruction")
		prompt = _prompt()
		if prompt != null:
			prompt.retry_button.pressed.emit()
		current = await _settled()
		_check(current is VictoryScreen and bool(_main.get("_chapter_complete")), "actual retry opens Victory only after successful terminal save")
		_check(_prompt() == null and not GameplayLock.is_locked() and not get_tree().paused, "accepted terminal recovery releases its UI and pause")
		var saved := store.read()
		_check(saved.get("chapter_complete") == true and saved.get("level") == LAST, "actual reader confirms durable completion at the correct terminal room")
		_record["after_retry_victory"] = current is VictoryScreen
		await _shot("terminal-accepted")
	await _finish()

func _settled() -> Node:
	var deadline := Time.get_ticks_msec() + 120000
	while Time.get_ticks_msec() < deadline:
		var screen: Node = _main.get("_screen")
		if _prompt() != null:
			await _frames(2)
			return screen
		if screen is VictoryScreen and not _main.call("_route_pending") and not screen._buttons.is_empty() and not screen._buttons[0].disabled:
			return screen
		if screen is Level and screen.is_initialized() and not _main.call("_route_pending") and not Story.is_cinematic_active() and Story._passive_requests.is_empty() and not GameplayLock.is_locked():
			return screen
		await _frames(1)
	_check(false, "actual terminal route settles before time guard")
	return _main.get("_screen")
func _persistent_owners() -> PackedByteArray:
	return var_to_bytes([GameState.has_checkpoint, GameState.checkpoint_level_path, GameState.checkpoint_position, GameState.checkpoint_loadout, GameState._carried_loadout, Progression.snapshot(), StoryItems.snapshot(), Story.progress_snapshot()])

func _prompt() -> Control:
	return _main.get("_destination_save_prompt") if _main.has_method("_retry_destination_save") else null

func _shot(name: String) -> void:
	if _out.is_empty() or DisplayServer.get_name() == "headless":
		return
	var canvas := CanvasLayer.new()
	canvas.layer = 120
	add_child(canvas)
	var note := Label.new()
	note.text = "SOFTWARE FORWARD+ / ARRANGED EDITION END + IO FAULT / NOT A PLAYTHROUGH"
	note.position = Vector2(12, 12)
	note.add_theme_font_size_override("font_size", 12)
	canvas.add_child(note)
	await _frames(2)
	await RenderingServer.frame_post_draw
	preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(_out.path_join(name + ".png"))
	canvas.queue_free()

func _finish() -> void:
	_record["mode"] = _mode
	_record["checks"] = _checks
	_record["failures"] = Array(_failures)
	_record["engine"] = Engine.get_version_info().string
	_record["probe_sha256"] = FileAccess.get_sha256("res://work/ne230_terminal_probe.gd")
	_record["prompt_sha256"] = FileAccess.get_sha256("res://ui/destination_save_prompt.gd")
	_record["main_sha256"] = FileAccess.get_sha256("res://game/main.gd")
	if not _out.is_empty():
		var file := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
		file.store_string(JSON.stringify(_record, "  ") + "\n")
		file.close()
	await super._finish()
