extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
var _image := ""
var _rows: Array[Dictionary]


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	var args := OS.get_cmdline_user_args()
	if args.size() == 1:
		_image = args[0]
	Settings.use_storage("user://live_supply_bindings.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.set_language("en")
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	for scene in Story.scene_ids():
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	await _frames(12)
	var med := ConsumableBag.find(&"med_injector")
	var other := ConsumableBag.find(&"shield_cell")
	_check(level.player.consumables.add(med) and level.player.consumables.add(other), "both supplies at launch")
	var inventory := level._inventory
	await _keyboard(KEY_TAB)
	_check(inventory.is_open() and not InputBindings.using_gamepad, "keyboard opens the live backpack")
	var page_index := inventory.page_index(ConsumablesPage)
	inventory.select_tab(page_index)
	var page := inventory._pages[page_index] as ConsumablesPage
	var card := page._cards[0]
	var stat := page._detail._stats.get_child(0)
	_verify(page, false, "initial keyboard", true)
	await _pad(JOY_BUTTON_Y)
	_verify(page, true, "gamepad after opening", true)
	_check(page._cards[0] == card and page._detail._stats.get_child(0) == stat, "switch preserves the card and detail controls")
	InputBindings.set_joy_button(&"use_item", JOY_BUTTON_LEFT_STICK)
	_verify(page, true, "gamepad rebound while open", true)
	_check(page._cards[0] == card and page._detail._stats.get_child(0) == stat, "rebind preserves the card and detail controls")
	if _image.is_absolute_path():
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_image) == OK, "forward plus screenshot")
	page._select(1)
	await _keyboard(KEY_F7)
	_verify(page, false, "keyboard with shield cell selected", false)
	InputBindings.set_code(&"use_item", 0, KEY_H)
	_verify(page, false, "keyboard rebound with shield cell selected", false)
	_check(page._detail._tag.text == "Supplies", "non-quick-use item's details stay unchanged")
	page._select(0)
	_verify(page, false, "med reselected after rebinding", true)
	_check(level.player.consumables.count(med.id) == 1 and level.player.consumables.count(other.id) == 1,
		"changing device and bindings does not consume either supply")
	print("SUPPLY_BINDINGS ", JSON.stringify(_rows))
	inventory.close()
	level.queue_free()
	await _frames(4)
	await _finish()


func _verify(page: ConsumablesPage, pad: bool, label: String, selected_med: bool) -> void:
	var binding := InputBindings.primary_label(&"use_item")
	var entry := page._entries[0]
	var tag := "Supplies · Quick key " + binding if selected_med else "Supplies"
	_check(InputBindings.using_gamepad == pad and not binding.is_empty(), label + " active device")
	_check(entry.badge == binding and page._cards[0].entry == entry, label + " quick label matches active binding")
	_check(page._detail._tag.text == tag and page._selected == (0 if selected_med else 1), label + " details reflect the same binding")
	_rows.append({"phase":label, "label":binding, "card":entry.badge, "details":page._detail._tag.text})


func _keyboard(code: int) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.pressed = true
	await _tap(event)


func _pad(button: int) -> void:
	var event := InputEventJoypadButton.new()
	event.device = 1
	event.button_index = button
	event.pressed = true
	await _tap(event)


func _tap(event: InputEvent) -> void:
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await get_tree().process_frame
	var released := event.duplicate() as InputEvent
	released.pressed = false
	Input.parse_input_event(released)
	Input.flush_buffered_events()
	await get_tree().process_frame
