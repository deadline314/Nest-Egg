extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
const IDS := ["dagger", "blade", "maul", "glaive", "whip"]


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://combo_readout.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	Story.set_language("zh")
	Story.auto_skip = true
	for scene in Story.scene_ids():
		Story._seen[StringName(scene)] = true
	add_child(LightKit.create_environment())
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	await _frames(8)
	var bag := level._inventory
	var page := bag._pages[bag.page_index(WeaponsPage)] as WeaponsPage
	for id: String in IDS:
		var weapon := load("res://data/weapons/melee/melee_%s.tres" % id) as WeaponData
		var set := MeleeData.set_of(weapon)
		var upgrade := Progression.find_upgrade(set.extension_upgrade())
		level.player.loadout.reset(weapon)
		bag.open()
		await _frames(4)
		_readout(page, set, set.combo(), id + " base")
		bag.close()
		Progression.add_credits(upgrade.cost)
		_check(Progression.buy_upgrade(weapon, upgrade), id + " technique uses the real progression rule")
		bag.open()
		await _frames(4)
		_readout(page, set, set.combo(true), id + " purchased")
		var stats: VBoxContainer = page._detail._stats
		_check(stats.get_child_count() >= 3 and stats.get_child(0).text == page._entries[0].detail_stats[0],
				id + " actual panel shows the selected weapon's current count")
		if id == "whip" and OS.get_cmdline_user_args().size() == 1:
			var dest := OS.get_cmdline_user_args()[0]
			await RenderingServer.frame_post_draw
			_check(Capture.image(get_viewport()).save_png(dest) == OK, "native technique readout screenshot")
		bag.close()
	level.queue_free()
	await _frames(8)
	await _finish()


func _readout(page: WeaponsPage, set: MeleeSet, ids: Array, label: String) -> void:
	var entry := page._entries[0]
	var damage := 0.0
	var time := 0.0
	var reach := 0.0
	for id: String in ids:
		var attack := set.attack(id)
		damage += float(attack["damage"])
		time += float(attack["windup"]) + float(attack["active"]) + float(attack["recovery"])
		reach = maxf(reach, float(attack["range"]))
	var text := entry.detail_stats
	print("COMBO_READOUT ", label, " ", text[0], " | ", text[1], " | ", text[2])
	_check(text[0] == "連段　%d 招" % ids.size(), label + " correct number of moves")
	_check(text[1] == "傷害　%.1f／秒" % (damage / time), label + " includes each move in the damage rate")
	_check(text[2] == "距離　%d" % roundi(reach), label + " includes each move in reach")
