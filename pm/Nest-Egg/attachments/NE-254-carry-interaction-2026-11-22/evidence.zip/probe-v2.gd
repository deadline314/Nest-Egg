extends "res://tests/smoke_test.gd"

var _out := ""


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://skip_modal_probe.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	super._ready()


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(load("res://data/levels/ch1_warehouse.tres") as LevelData)
	add_child(level)
	await _frames(260)
	for node in get_tree().get_nodes_in_group(&"enemies"):
		node.set_physics_process(false)
	var player := level.player
	var gate: MechanismSwitch
	for node in get_tree().get_nodes_in_group(WorldState.GROUP):
		if node is MechanismSwitch and node.data.id == &"ch1_switch_a":
			gate = node
			break
	var box: Throwable
	for node in get_tree().get_nodes_in_group(Throwable.GROUP):
		if node is Throwable and node.data.id == &"crate_small" and roundi(node.global_position.x / 16.0 - 0.5) == 43:
			box = node
			break
	_check(box != null and gate != null, "the real warehouse contains its box and switch A")
	if box == null or gate == null:
		await _finish()
		return
	player.global_position = box.global_position + Vector2(-10, 0)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	AimInput._last_stick_dir = Vector2.RIGHT
	await _frames(24)
	await _interact()
	await _frames(35)
	_check(player.carry.is_holding() and player.carry.held == box, "interact picks up the original box")
	player.global_position = gate.global_position + Vector2(-75.0, 0.0)
	player.velocity = Vector2.ZERO
	await _frames(12)
	Input.action_press(&"move_right")
	for tick in 550:
		if player.global_position.x >= gate.global_position.x + 8.0:
			break
		await _frames(1)
	Input.action_release(&"move_right")
	await _frames(16)
	print("CARRY_ARRIVAL pos=", player.global_position, " lever=", gate.global_position, " holding=", player.carry.is_holding(),
		" reachable=", gate.interaction_available())
	_check(gate.interaction_available() and player.carry.held == box, "the real player carries the box to switch A")
	if not gate.interaction_available() or player.carry.held != box:
		await _finish()
		return
	var toggles: Array[bool] = []
	EventBus.mechanism_toggled.connect(func(channel: StringName, enabled: bool) -> void:
		if channel == &"flood_a":
			toggles.append(enabled))
	var initial := gate.active
	await _shot("near-lever")
	await _interact()
	await _frames(10)
	print("CARRY_DROP holding=", player.carry.is_holding(), " box=", box.global_position,
		" player=", player.global_position, " lever=", gate.active, " prior=", initial, " signals=", toggles.size())
	_check(not player.carry.is_holding() and gate.active == initial and toggles.is_empty(), "one press puts the box down without toggling the lever")
	await _shot("dropped")
	Input.action_press(&"move_left")
	for tick in 26:
		if player.global_position.x <= gate.global_position.x - 14:
			break
		await _frames(1)
	Input.action_release(&"move_left")
	await _frames(5)
	_check(gate.interaction_available() and player.carry.nearest_pickable() == null, "the nearby lever remains available out of box reach")
	await _interact()
	await _frames(6)
	_check(gate.active != initial and toggles.size() == 1 and not player.carry.is_holding(), "a separate press toggles the lever once")
	await _shot("lever")
	level.queue_free()
	await _frames(4)
	await _finish()

func _interact() -> void:
	var press := InputEventKey.new()
	press.keycode = KEY_E
	press.physical_keycode = KEY_E
	press.pressed = true
	Input.parse_input_event(press)
	Input.flush_buffered_events()
	await _frames(3)
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	Input.parse_input_event(release)
	Input.flush_buffered_events()

func _send_key(code: Key) -> void:
	var press := InputEventKey.new()
	press.keycode = code
	press.physical_keycode = code
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _send_button(button: JoyButton) -> void:
	var press := InputEventJoypadButton.new()
	press.button_index = button
	press.pressure = 1.0
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	release.pressure = 0.0
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _shot(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join(name + ".png")) == OK, "saved " + name)