param(
    [Parameter(Mandatory=$true)][string]$Label,
    [switch]$Headless, [switch]$Pad,
    [string]$Resolution='1280x720', [double]$TextScale=1.0
)
$ErrorActionPreference='Stop'
$d='D:/NestEggVerification/ne218-baseline-20261117'
$e=$PSScriptRoot
$path=Join-Path $e $Label
New-Item -ItemType Directory -Path "$path/profile" | Out-Null
$env:APPDATA="$path/profile"
$env:LOCALAPPDATA="$path/profile"
$env:PYTHONUTF8='1'
$engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$options=@('--path',$d,'--audio-driver','Dummy','--resolution',$Resolution,'--fixed-fps','60','--quit-after','5000',"$e/probe-v4.tscn",'--',"--out=$path","--text-scale=$TextScale")
if($Pad){ $options += "--pad" }
if($Headless){
    & $engine --headless @options *> "$path/raw.log"
}
else {
    & 'D:/ComfyUI/.venv-rocm/Scripts/python.exe' -B "$d/tools/comfyui/gpu_lock.py" -- $engine @options *> "$path/raw.log"
}
$code=$LASTEXITCODE
Set-Content "$path/exit.txt" $code
Get-Content "$path/raw.log" -Tail 25
exit $code
