"""Run the original scale contract rejection, current self-check, then three native captures."""
import datetime
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
OUTPUT = Path("C:/NE/evidence-20261117/ne274-scale-verification")
GODOT = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
SOURCES = ["tools/dialogue_box_capture.gd", "tools/dialogue_box_capture.tscn", "autoload/settings.gd",
           "ui/ui_kit.gd", "ui/kit/radio_card.gd", "ui/dialogue_layer.gd", "tools/viewport_capture.gd"]


def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in SOURCES}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, default=OUTPUT)
    args = parser.parse_args()
    jobs = [("original-negative", True, 1, "res://work/ne274-scale-verification-20261117/original_scale_check.tscn", []),
            ("self-check", True, 0, "res://tools/dialogue_box_capture.tscn", ["--self-check", "--text-scale=1.5"]),
            ("normal", False, 0, "res://tools/dialogue_box_capture.tscn", []),
            ("large", False, 0, "res://tools/dialogue_box_capture.tscn", ["--text-scale=1.5"]),
            ("reduced", False, 0, "res://tools/dialogue_box_capture.tscn", ["--reduce-motion"])]
    receipts = []
    for tag, headless, expected, scene, flags in jobs:
        folder = args.output_root / tag
        if folder.exists():
            raise FileExistsError(f"Keep prior evidence; choose a new output root: {folder}")
        profile = folder / "profile"
        profile.mkdir(parents=True)
        environment = os.environ.copy()
        overrides = {"APPDATA": str(profile), "LOCALAPPDATA": str(profile), "NE274_OUT": str(folder)}
        environment.update(overrides)
        command = [GODOT, "--path", str(ROOT)]
        if headless:
            command += ["--headless"]
        else:
            command += ["--windowed", "--resolution", "1280x720", "--rendering-driver", "vulkan", "--rendering-method", "forward_plus"]
        command += [scene, "--", f"--out={folder}", f"--tag={tag}", *flags]
        if not headless:
            command = [sys.executable, "-B", "tools/comfyui/gpu_lock.py", "--", *command]
        before = hashes()
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (folder / "console.log").open("wb") as log:
            result = subprocess.run(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT)
        after = hashes()
        text = (folder / "console.log").read_text(encoding="utf8", errors="strict")
        diagnostics = [line for line in text.splitlines() if any(token in line for token in ("SCRIPT ERROR", "ERROR:", "WARNING:", "Leaked", "leaked", "orphan"))]
        receipt = {"tag": tag, "started_utc": started, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   "command": command, "cwd": str(ROOT), "environment_overrides": overrides,
                   "exit_code": result.returncode, "expected_exit_code": expected, "diagnostic_lines": diagnostics,
                   "source_before_sha256": before, "source_after_sha256": after, "source_unchanged": before == after}
        (folder / "process-receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf8")
        receipts.append(receipt)
        (WORK / (args.output_root.name + "-receipts.json")).write_text(json.dumps(receipts, indent=2), encoding="utf8")
        print(json.dumps({"tag": tag, "exit": result.returncode, "expected": expected, "diagnostics": diagnostics, "source_unchanged": before == after}), flush=True)
        if result.returncode != expected or diagnostics or before != after:
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
