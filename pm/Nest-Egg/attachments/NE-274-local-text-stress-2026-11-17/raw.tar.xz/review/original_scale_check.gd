extends Node
## The original capture path: public setter, UiKit label; deliberately requires the advertised 1.5 font.
func _ready() -> void:
	Settings.use_storage("user://ne274-original-scale.cfg")
	Settings.set_ui_text_scale(1.5)
	var label := UiKit.label("倉庫的電", UiKit.FS_BODY)
	add_child(label)
	var actual := label.get_theme_font_size(&"font_size")
	var required := roundi(UiKit.FS_BODY * 1.5)
	var report := {"requested": 1.5, "effective": Settings.get_ui_text_scale(), "base": UiKit.FS_BODY,
		"actual": actual, "required": required, "passed": actual == required,
		"scope": "Original public-setter/label path only, not native character capture"}
	var file := FileAccess.open(OS.get_environment("NE274_OUT").path_join("original-scale.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "\t"))
	file.close()
	print("ORIGINAL_SCALE_NEGATIVE_CONTROL ", JSON.stringify(report))
	Settings.use_storage(Settings.DEFAULT_PATH)
	get_tree().quit(0 if actual == required else 1)
