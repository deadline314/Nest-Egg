"""Independently recompute native NE274 capture evidence (no Godot/GPU)."""
import argparse
import hashlib
import json
import math
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding="utf8"))


def luminance(rgb):
    return sum(weight * (value / 12.92 if value <= .03928 else ((value + .055) / 1.055) ** 2.4)
               for value, weight in zip(rgb, (.2126, .7152, .0722)))


def contrast(ink, ground):
    a, b = luminance(ink), luminance(ground)
    return (max(a, b) + .05) / (min(a, b) + .05)


def verify(root):
    original = read(root / "original-negative/original-scale.json")
    assert original["actual"] == 13 and original["required"] == 17
    assert original["effective"] == 1.2 and not original["passed"]
    check = read(root / "self-check/self-check-index.json")
    assert not check["original_without_override"]["font_sizes_match"]
    assert check["candidate"]["actual_font_sizes"] == [17] and check["passed"]
    receipts = []
    for tag, code in (("original-negative", 1), ("self-check", 0), ("normal", 0), ("large", 0), ("reduced", 0)):
        receipt = read(root / tag / "process-receipt.json")
        assert receipt["exit_code"] == receipt["expected_exit_code"] == code
        assert not receipt["diagnostic_lines"] and receipt["source_unchanged"]
        assert receipt["source_before_sha256"] == receipt["source_after_sha256"]
        receipts.append({"tag": tag, "exit_code": code})
    result = {"negative_control": original, "self_check": check, "receipts": receipts, "native": []}
    names = {"rin": "凜", "old_k": "老K", "mei": "芽", "system": "天穹廣播", "unknown": "不明訊號"}
    for tag, size in (("normal", 11), ("large", 17), ("reduced", 11)):
        folder = root / tag
        report = read(folder / (tag + "-index.json"))
        assert report["failures"] == 0 and report["renderer"] == "forward_plus"
        assert report["adapter"] == "AMD Radeon RX 9070 XT" and report["display"] == "Windows"
        assert len(report["captures"]) == 15 and len(report["lines"]) == 5
        assert {row["speaker"] for row in report["lines"]} == set(names)
        ratios = []
        for row in report["captures"]:
            font = row["font_state"]
            assert font["base_font_size"] == 11 and font["expected_font_size"] == size
            assert font["actual_font_sizes"] == [size] * 3 and font["font_sizes_match"]
            assert all(math.isclose(value, size / 11, abs_tol=1e-12) for value in font["actual_renderer_ratios"])
            assert font["effective_setting_scale"] == (1.2 if tag == "large" else 1.0)
            assert font["local_font_override"] is (tag == "large")
            assert not row["paused"] and row["inside_screen"] and not row["text_clipped"]
            assert row["cell_size"] == [40, 40] and row["name"] == names[row["speaker"]]
            assert row["speaker_color"] == row["frame_color"]
            if row["speaker"] == "unknown":
                assert not row["portrait_visible"] and row["voice_waveform"]
            x, y, width, height = row["rect"]
            assert 0 <= x < x + width <= 640 and 0 <= y < y + height <= 360
            with Image.open(folder / row["file"]) as source:
                image = source.convert("RGBA")
                assert image.size == (1280, 720)
                px, py = map(int, row["contrast_probe"])
                ground = image.getpixel((px, py))[:3]
            assert list(ground) == [round(value * 255) for value in row["ground"]]
            ratio = contrast(row["ink"], [value / 255 for value in ground])
            assert abs(ratio - row["contrast"]) <= .0051
            if row["contrast_checked"]:
                assert ratio >= 4.5 and row["opacity"] >= .99
                ratios.append(ratio)
            if row["file"].endswith("-late.png"):
                assert row["visible_ratio"] == 1 and 0 < row["hold_seconds"] <= .35
            if row["file"].endswith("-full.png"):
                assert row["visible_ratio"] == 1 and 0 < row["hold_ratio"] <= 1
        for who in names:
            early = next(row for row in report["captures"] if row["speaker"] == who and row["file"].endswith("-in.png"))
            full = next(row for row in report["captures"] if row["speaker"] == who and row["file"].endswith("-full.png"))
            assert early["rect"][3] == full["rect"][3]
        fit = report["long_to_short"]
        assert fit["long_height"] > fit["short_height"]
        decoration = []
        if tag == "reduced":
            assert len(report["decoration_checks"]) == 5
            for sample in report["decoration_checks"]:
                assert sample["unchanged"]
                assert all(sample["first"][key] == sample["second"][key] for key in ("clock", "pixel_rects", "pixel_hashes", "card_processing"))
                assert sample["first"]["clock"] == 0 and sample["first"]["card_processing"]
                verified = []
                for filename, state in ((sample["first_file"], sample["first"]), (sample["second_file"], sample["second"])):
                    with Image.open(folder / filename) as source:
                        image = source.convert("RGBA")
                        for rectangle, expected in zip(state["pixel_rects"], state["pixel_hashes"]):
                            x, y, width, height = rectangle
                            assert width > 0 and height > 0
                            actual = hashlib.sha256(image.crop((x, y, x + width, y + height)).tobytes()).hexdigest()
                            assert actual == expected
                            verified.append(actual)
                assert verified[:2] == verified[2:]
                decoration.append({"speaker": sample["speaker"], "two_regions_two_frames_byte_identical": True})
        result["native"].append({"tag": tag, "speakers": 5, "main_captures": 15, "label_font_sizes": [size] * 3,
                                  "renderer_ratio": size / 11, "min_contrast": min(ratios), "max_contrast": max(ratios),
                                  "long_to_short": fit, "decoration": decoration})
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("--out", type=Path, default=HERE / "verification.json")
    args = parser.parse_args()
    result = verify(args.root)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf8")
    print(json.dumps({"native_sets": len(result["native"]), "phase_captures": 45,
                      "decorative_regions_byte_identical_in_two_frames": 10, "actual_large_label_font": 17}))


if __name__ == "__main__":
    main()
