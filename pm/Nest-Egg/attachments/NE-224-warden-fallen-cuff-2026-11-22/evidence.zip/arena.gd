extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/level_01.tres")
var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		printerr("Expected native rendering and an absolute output path")
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://warden_hall.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Settings.set_brightness(0.5)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	DirAccess.make_dir_recursive_absolute(_out)
	for zoom: float in [LevelCamera.base_zoom(), 3.4]:
		for direction: int in [-1, 1]:
			if not await _observe(direction, zoom):
				printerr("Warden level fixture failed for ", direction, " @ ", zoom)
				get_tree().quit(1)
				return
	var file := FileAccess.open(_out.path_join("street.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"adapter": RenderingServer.get_video_adapter_name(),
		"rendering_method": RenderingServer.get_current_rendering_method(), "hdr_2d": get_viewport().use_hdr_2d,
		"rows": _rows}, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)


func _observe(direction: int, zoom: float) -> bool:
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	var target: Enemy
	if level._layout.boss_spawn.is_empty():
		printerr("The authored Warden boss marker is missing")
		return false
	var boss_start: Vector2 = level._layout.boss_spawn["position"]
	level.player.health.setup(999, level.player.tuning.hurt_invulnerability)
	level.player.global_position = Vector2(level._layout.arena_x + Level.ARENA_TRIGGER_MARGIN + 8.0, boss_start.y)
	for frame in 170:
		for node in level._entities.get_children():
			if node is Enemy and node.data.id == &"warden":
				target = node
				break
		if target != null:
			break
		await get_tree().physics_frame
	if target == null or target.data.rig_skin != "warden" or target.rig == null:
		printerr("The actual Warden arena entrance did not spawn its boss")
		return false
	for node in level._entities.get_children():
		if node is Enemy and node != target:
			node.process_mode = Node.PROCESS_MODE_DISABLED
	var start := target.global_position
	level.player.health.setup(999, level.player.tuning.hurt_invulnerability)
	level.player.global_position = start + Vector2(112 * direction, 0)
	level.player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(level.player, true)
	level._lighting._lightning_gap = 1.0e9
	for node in level.find_children("*", "", true, false):
		if node is ChapterCard:
			node.queue_free()
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.limit_left = -100000
	camera.limit_right = 100000
	camera.offset = Vector2.ZERO
	camera.zoom = Vector2.ONE * zoom
	camera.global_position = start + Vector2(0, -34)
	camera.reset_smoothing()
	camera.force_update_scroll()
	var prefix := "%s_%d" % ["left" if direction < 0 else "right", roundi(100 * zoom)]
	for frame in 30:
		await get_tree().physics_frame
	target.facing = direction
	if not await _capture(target, camera, prefix + "_before"):
		return false
	var hit := DamageInfo.create(3, Combat.Team.PLAYER, &"probe", Vector2(-38.0 * direction, 0))
	hit.origin = level.player.global_position
	hit.impact = 2.0 * target.data.poise
	hit.ignore_invulnerability = true
	hit.bypass_guard = true
	if not target.health.take_damage(hit) or not target.is_stunned():
		printerr("Actual damage did not stun Warden @ ", prefix)
		return false
	var start_frame := Engine.get_physics_frames()
	for frame in 34:
		await get_tree().process_frame
		var elapsed := Engine.get_physics_frames() - start_frame
		if elapsed in [4, 6, 9, 13, 16, 22]:
			if not await _capture(target, camera, "%s_hit_%02d" % [prefix, elapsed]):
				return false
	if target.is_dying() or not target.rig.visible:
		return false
	var final_hit := DamageInfo.create(target.health.current + 1, Combat.Team.PLAYER, &"probe", Vector2(-38.0 * direction, 0))
	final_hit.origin = level.player.global_position
	final_hit.ignore_invulnerability = true
	final_hit.bypass_guard = true
	if not target.health.take_damage(final_hit) or not target.is_dying():
		printerr("Actual damage did not defeat Warden @ ", prefix)
		return false
	start_frame = Engine.get_physics_frames()
	for frame in 50:
		await get_tree().process_frame
		var elapsed := Engine.get_physics_frames() - start_frame
		if elapsed in [4, 12, 20, 32, 44, 48]:
			if not is_instance_valid(target) or not await _capture(target, camera, "%s_fall_%02d" % [prefix, elapsed]):
				return false
	level.queue_free()
	for frame in 6:
		await get_tree().process_frame
	return true


func _capture(target: Enemy, camera: LevelCamera, key: String) -> bool:
	await RenderingServer.frame_post_draw
	var result := Capture.image(get_viewport()).save_png(_out.path_join(key + ".png"))
	var neck := camera.get_canvas_transform() * target.rig.bone(&"head").global_position
	var front := camera.get_canvas_transform() * target.rig.bone(&"arm_front_upper").global_position
	var back := camera.get_canvas_transform() * target.rig.bone(&"arm_back_upper").global_position
	_rows.append({"key": key, "zoom": camera.zoom.x, "screen_head": [neck.x, neck.y], "facing": target.facing,
		"aim": [target._rig_aim().x,target._rig_aim().y],
		"shoulders": [[front.x, front.y], [back.x, back.y]],
		"world": [target.global_position.x,target.global_position.y],
		"state": str(target.fsm.current), "stunned": target.is_stunned(), "dying": target.is_dying(), "health": target.health.current,
		"physics_frame": Engine.get_physics_frames(), "screen": [get_viewport().size.x, get_viewport().size.y]})
	return result == OK



