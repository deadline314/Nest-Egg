from pathlib import Path
from PIL import Image
import numpy as np
base=Path('D:/NestEggVerification/evidence-20261122-ne224-warden-fallen-cuff')
stock=Path('art/characters/warden/parts/armor_forearm.png')
source=np.array(Image.open(stock))
assert (337,529)==(source.shape[1],source.shape[0])
candidate=source.copy()
ends=[263,265,266,266,266,265,265,266,266,267,267,267,267,267,266]
for row,right in enumerate(ends,357):
    left=259
    alpha=np.full(right-left+1,225,dtype=np.uint8)
    alpha[-1]=150
    margin=candidate[row,left:right+1]
    replace=alpha>margin[:,3]
    margin[replace,:3]=source[row,256,:3]
    margin[replace,3]=alpha[replace]
assert np.all(candidate[:,:,3]>=source[:,:,3])
print('CHANGED',np.count_nonzero(np.any(candidate!=source,axis=2)))
Image.fromarray(candidate).save(base/'cuff.png')
