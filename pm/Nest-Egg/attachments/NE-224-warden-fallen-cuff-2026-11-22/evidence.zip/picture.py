from pathlib import Path
from PIL import Image,ImageDraw
import json
import numpy as np
e=Path('D:/NestEggVerification/evidence-20261122-ne224-warden-fallen-cuff')
tiles=[]
for now,joint in ((73,'wrist_back'),(81,'hip_back')):
    for mode in ('before','trial'):
        source=e/mode
        meta=next(group for group in json.loads((source/'frames.json').read_bytes()) if group['pose']=='dead' and group['zoom']==3.4)
        cell=next(row for row in meta['cells'] if row['joint']==joint and row['facing']==1)
        x,y,w,h=cell['rect']
        image=Image.open(source/meta['samples'][now]['file']).convert('RGBA').crop((x+28,y+28,x+w-28,y+h-28))
        tile=Image.new('RGBA',image.size,'#4a394b')
        tile.alpha_composite(image)
        tiles.append(tile.convert('RGB').resize((288,288),Image.Resampling.NEAREST))
out=Image.new('RGB',(576,620),'#18202d')
draw=ImageDraw.Draw(out)
for i,tile in enumerate(tiles):
    x,y=i%2*288,i//2*310
    draw.text((x+6,y+4),('REAR WRIST' if i<2 else 'REAR HIP')+(' | BEFORE' if i%2==0 else ' | CUFF'),fill='#d7e7f8')
    out.paste(tile,(x,y+22))
out.save(e/'compare.png')
