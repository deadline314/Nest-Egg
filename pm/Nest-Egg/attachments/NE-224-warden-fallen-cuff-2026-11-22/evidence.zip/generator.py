from pathlib import Path
from PIL import Image
import numpy as np
base=Path('D:/NestEggVerification/evidence-20261122-ne224-warden-fallen-cuff')
work=Path('art_src/characters/warden')
path=work/'forearm_overlap/rebuild.py'
source=path.read_text(encoding='utf-8')
old='''    for row, (left, right) in enumerate(edge, 358):
        opacity = 155 if row < 366 else 185
        alpha = np.full(right - left + 1, opacity, dtype=np.uint8)
        alpha[-1] = round(0.66 * opacity)
        margin = patched[row, left:right + 1]
        extend = alpha > margin[:, 3]
        margin[extend, :3] = original[row, 256, :3]
        margin[extend, 3] = alpha[extend]
    if np.count_nonzero(np.any(patched != original, axis=2)) != 107:'''
new='''    edge_alpha = []
    for row, (left, right) in enumerate(edge, 358):
        opacity = 155 if row < 366 else 185
        edge_alpha.append((row, left, right, opacity, round(0.66 * opacity)))
    # Back the cuff where the rear plate crosses the hip during the final fall.
    cuff_right = (263, 265, 266, 266, 266, 265, 265, 266, 266, 267, 267, 267, 267, 267, 266)
    edge_alpha.extend((row, 259, right, 225, 150) for row, right in enumerate(cuff_right, 357))
    for row, left, right, opacity, feathered in edge_alpha:
        alpha = np.full(right - left + 1, opacity, dtype=np.uint8)
        alpha[-1] = feathered
        margin = patched[row, left:right + 1]
        extend = alpha > margin[:, 3]
        margin[extend, :3] = original[row, 256, :3]
        margin[extend, 3] = alpha[extend]
    if np.count_nonzero(np.any(patched != original, axis=2)) != COUNT:'''
assert source.count(old)==1
native=np.asarray(Image.open(base/'cuff.png'))
reference=(path.parent/'armor_forearm-before.png').resolve()
before=np.asarray(Image.open(reference))
count=np.count_nonzero(np.any(native!=before,axis=2))
update=source.replace(old,new.replace('COUNT',str(count)))
verify=update.replace('SOURCE = Path(__file__).with_name("armor_forearm-before.png")',f'SOURCE = Path({reference.as_posix()!r})')
verify=verify.replace('OUTPUT = SOURCE.parent.parent / "overrides/armor_forearm.png"',f'OUTPUT = Path({(base/"rebuilt.png").as_posix()!r})')
exec(compile(verify,str(path),'exec'),{'__name__':'__main__'})
assert np.array_equal(np.asarray(Image.open(base/'rebuilt.png')),native)
(base/'rebuild-candidate.py.txt').write_text(update,encoding='utf-8',newline='\n')
print('FOREARM GENERATOR EXACT',count)
