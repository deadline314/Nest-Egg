from pathlib import Path
from hashlib import sha256
from PIL import Image
import json,numpy as np,os,shutil,subprocess,sys

root=Path.cwd()
base=Path(__file__).resolve().parent
shared=base.with_name("ne218-baseline-20261117")
prior=base.with_name("evidence-20261122-ne224-leg-crossing")
before=json.loads((prior/"published-source.json").read_bytes())
parent=json.loads((prior/"publish/result.json").read_bytes())["commit"]
branch="codex/ne224-warden-fallen-cuff"
placeholder="codex/ticket-work-20261120-next"
source="art_src/characters/warden/forearm_overlap/rebuild.py"
override="art_src/characters/warden/overrides/armor_forearm.png"
design="design/12-cast-redraw/RIG_QUALITY.md"
part="art/characters/warden/parts/"
runtime=[part+"armor_forearm.png",part+"armor_forearm_n.png"]
load=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
image=lambda p:np.asarray(Image.open(p).convert("RGBA"))

def git(*args,cwd=root):
    return subprocess.check_output(["git",*args],cwd=cwd).decode("utf-8").strip()

def run(script, args, filename):
    with (base/filename).open("wb") as output:
        subprocess.run([sys.executable,"-X","utf8","-B",script,*args],cwd=root,
                       stdout=output,stderr=subprocess.STDOUT,check=True)

assert git("branch","--show-current")==placeholder
assert parent==git("rev-parse","HEAD")==git("rev-parse","origin/main")==git("rev-parse","HEAD",cwd=shared)
assert not git("status","--porcelain","--untracked-files=no")
assert all(sha(shared/name)==digest for name,digest in before.items())
assert all(sha(root/name)==before[name] for name in runtime)
assert np.array_equal(image(root/override),image(root/runtime[0]))
stock=image(root/runtime[0])
candidate=image(base/"cuff.png")
assert stock.shape==candidate.shape==(529,337,4)
mask=np.any(stock!=candidate,axis=2)
assert int(mask.sum())==94 and not np.any(stock[:,:,3]>candidate[:,:,3])
ys,xs=np.where(mask)
assert xs.min()>=259 and xs.max()<=267 and ys.min()>=357 and ys.max()<=371
assert np.array_equal(image(base/"baseline-normal.png"),image(root/runtime[1]))
assert np.array_equal(image(base/"candidate-normal.png")[:,:,3],candidate[:,:,3])
stats=load(base/"wide-comparison.json")
assert stats["whole"]["samples"]==stats["dressed"]["samples"]==stats["isolated"]["samples"]==53760
assert stats["whole"]["target_closed"]==268 and stats["whole"]["new_hard"]==[]
assert stats["dressed"]["new_hard"]==stats["isolated"]["new_hard"]==[]

git("switch","-c",branch)
git("branch","-d",placeholder)
for path in (*runtime,source,override):
    destination=base/"source-before"/path
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/path,destination)
shutil.copyfile(base/"rebuild-candidate.py.txt",root/source)
run(source,[],"override.log")
assert np.array_equal(image(root/override),candidate)
rebuilt=base/"rebuilt/warden"
assert not rebuilt.exists()
spec="tools/comfyui/specs/warden_side.json"
run("tools/comfyui/cut_layers.py",["--spec",spec,"--work","art_src/characters/warden","--char",str(rebuilt),
                                  "--rig",str(base/"rebuilt-rig.json")],"rebuild.log")
# The recipe applies validated final overrides after the cutter writes its generated parts.
target=rebuilt/"parts/armor_forearm.png"
assert image(target).shape==candidate.shape and np.array_equal(image(root/override),candidate)
shutil.copyfile(root/override,target)
old=load(root/"art/characters/warden/character.json")["textures"]["armor_forearm"]
new=load(rebuilt/"character.json")["textures"]["armor_forearm"]
assert all(old[key]==new[key] for key in ("size","pivot","file"))
for name,artifact in zip(runtime,[rebuilt/"parts/armor_forearm.png",base/"candidate-normal.png"]):
    for directory in (root,shared):
        target=directory/name
        temp=target.with_name(target.name+".cuff-install")
        shutil.copyfile(artifact,temp)
        os.replace(temp,target)
    before[name]=sha(root/name)
assert all(sha(shared/name)==digest for name,digest in before.items())
run("tools/comfyui/check_spec.py",["--recipe","tools/comfyui/recipes/warden.json"],"spec.log")
run("tools/comfyui/check_parts.py",["warden","--normals"],"parts.log")
assert "0 error(s), 0 warning(s)" in (base/"spec.log").read_text(encoding="utf-8")
assert "OK   warden" in (base/"parts.log").read_text(encoding="utf-8")
doc=(root/design).read_text(encoding="utf-8").rstrip()
note="""

### 監管者倒地時的後護臂內側

倒地動作最後一段，後護臂橫過髖部時露出小透空。沿原護臂內緣補上暗色銜接，沿用原尺寸、位置與相對層序，依相同流程重建貼圖與法線。
"""
(root/design).write_text(doc+note,encoding="utf-8",newline="\n")
assert set(git("diff","--name-only").splitlines())==set(runtime)|{source,override,design}
(base/"baseline.txt").write_text(parent+"\n")
(base/"runtime.json").write_text(json.dumps(runtime)+"\n")
(base/"source.json").write_text(json.dumps(before,indent=2)+"\n")
shutil.copyfile(prior/"verify.py",base/"verify.py")
script=(prior/"publish.py").read_text(encoding="utf-8")
for stock,value in (
    ("codex/ne224-enforcer-leg-crossing",branch),
    ("NE224_enforcer_leg_crossing_20261122","NE224_warden_fallen_cuff_20261122"),
    ("test: verify enforcer knee and ankle continuity","art: back the warden cuff during the fall"),
    ("verify the knee and ankle spacing during leg crossings","remove the small gaps between the fallen warden cuff and hip"),
):
    assert stock in script
    script=script.replace(stock,value)
(base/"publish.py").write_text(script,encoding="utf-8")
git("diff","--check")
print("FROZEN WARDEN CUFF",parent,len(before),runtime)
