from collections import Counter
from pathlib import Path
import json

base=Path(__file__).resolve().parent
key=lambda row:(row["pose"],row["zoom"],row["facing"],row["joint"],row["frame"])
read=lambda path:json.loads(path.read_bytes())

def maps(report):
    rows={key(row):row for row in report["failures"]}
    assert all(row["char"]=="warden" for row in rows.values())
    hard={name for name,row in rows.items() if row["enclosed_pixels"] or row["loose_pieces"] or row["center_alpha"]<128}
    return set(rows),hard

proof={}
for mode in ("whole","dressed","isolated"):
    stock=base/("wide-stock-"+mode)
    candidate=base/("wide-"+mode)
    for folder in (stock,candidate):
        raw=(folder/"raw.log").read_text(encoding="utf-8-sig")
        assert "Forward+" in raw and "RX 9070 XT" in raw and "ERROR:" not in raw
    before,after=[read(path/"report.json") for path in (stock,candidate)]
    assert before["samples"]==after["samples"]==53760
    old_flags,old_hard=maps(before)
    new_flags,new_hard=maps(after)
    target={item for item in old_hard if item[0]=="dead" and item[3] in {"hip_front","hip_back","wrist_back"}}
    assert len(target)==(268 if mode=="whole" else 0)
    assert new_hard==old_hard-target
    assert not (new_flags-old_flags)
    proof[mode]=dict(samples=after["samples"],before_hard=len(old_hard),after_hard=len(new_hard),
                     before_flags=len(old_flags),after_flags=len(new_flags),target_closed=len(target),
                     new_hard=sorted(new_hard-old_hard),
                     target_by_joint=dict(Counter(item[3] for item in target)))
(base/"wide-comparison.json").write_text(json.dumps(proof,indent=2)+"\n",encoding="utf-8")
print("EXACT MATCHED NATIVE",proof)
