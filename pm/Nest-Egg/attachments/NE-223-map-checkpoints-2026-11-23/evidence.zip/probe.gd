extends Node

const WAREHOUSE := "res://data/levels/ch1_warehouse.tres"
const PAWN := "res://data/levels/ch1_pawnshop.tres"
const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""
var _level: Level


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://checkpoint-marker-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Story.set_language("en")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_prologue_exit", true, false)
	add_child(LightKit.create_environment())
	await _enter(WAREHOUSE)
	var booth: Checkpoint
	for node in _level._entities.get_children():
		if node is Checkpoint:
			booth = node
			break
	_check(is_instance_valid(booth), "the original warehouse has the telephone booth")
	if not is_instance_valid(booth):
		await _finish()
		return
	var home := booth.global_position
	_level.player.global_position = home + Vector2(-24.0, -1.0)
	await _frames(30)
	var index := QuestMapIndex.for_chapter(&"ch1_kasa")
	var markers: Array[Dictionary] = index.areas[WAREHOUSE]["markers"]
	var found := markers.find_custom(func(marker: Dictionary) -> bool: return marker.get("kind") == "checkpoint")
	_check(found >= 0 and QuestMapState.for_run().knows(WAREHOUSE, markers[found]["cell"]), "standing at the real booth reveals its map marker")
	if found < 0:
		await _finish()
		return
	var key := "marker:%d" % found
	await _key(KEY_M)
	var map := _level._pause_menu._navigation
	_check(is_instance_valid(map) and map._map_path == WAREHOUSE, "keyboard opens the actual warehouse map")
	if not is_instance_valid(map):
		await _finish()
		return
	var marker := _map_button(map, key)
	_check(marker != null and marker.text == "◇" and marker.tooltip_text == "Activate the checkpoint here.",
		"the unused booth is marked with an outline and the activation hint")
	await _key(KEY_ESCAPE)
	await _key(KEY_ESCAPE)
	_check(not get_tree().paused and booth.can_dial(), "leaving the map restores direct access to the actual telephone")
	await _key(KEY_E)
	for attempt in 400:
		if booth.activated and GameState.has_checkpoint and not booth.is_calling():
			break
		await _frames(1)
	_check(booth.activated and GameState.has_checkpoint and GameState.checkpoint_position.distance_to(home) < 1.0,
		"one actual call completes and records the checkpoint at the booth")
	await _key(KEY_A, 24)
	await _key(KEY_M)
	map = _level._pause_menu._navigation
	marker = _map_button(map, key) if is_instance_valid(map) else null
	_check(marker != null and marker.text == "◆" and marker.tooltip_text == "Your latest backup is here.",
		"the same marker now identifies the real latest backup")
	if marker != null:
		marker.grab_focus()
		await _frames(3)
		_check(map._status.text == marker.tooltip_text, "focus uses the same backup information as Hover")
		if DisplayServer.get_name() != "headless":
			await RenderingServer.frame_post_draw
			_check(Capture.image(get_viewport()).save_png(_out.path_join("checkpoint.png")) == OK, "captured the official map after the call")
	if is_instance_valid(map):
		_level._pause_menu.close()
	await _frames(4)
	await _enter(PAWN)
	await _key(KEY_M)
	await _key(KEY_E)
	map = _level._pause_menu._navigation
	var entry := _map_button(map, "area:" + WAREHOUSE) if is_instance_valid(map) else null
	_check(entry != null, "the Pawnshop world map retains the warehouse area")
	if entry != null:
		entry.grab_focus()
		await _joy(JOY_BUTTON_A)
		marker = _map_button(map, key)
		_check(marker != null and marker.tooltip_text == "Your latest backup is here.",
			"the latest backup still belongs to the same map while viewing it remotely")
	await _finish()


func _enter(path: String) -> void:
	if is_instance_valid(_level):
		_level.queue_free()
		await _frames(6)
	_level = Level.new()
	_level.configure(load(path) as LevelData)
	add_child(_level)
	await _frames(38)


func _map_button(map: QuestMapScreen, key: String) -> Button:
	if is_instance_valid(map._canvas):
		for button in map._canvas._markers:
			if button.get_meta(&"nav_key", "") == key:
				return button
	return null


func _key(key: Key, held_frames := 4) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _press(event, held_frames)


func _joy(key: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = key
	await _press(event)


func _press(event: InputEvent, held_frames := 4) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(held_frames)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(8)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish() -> void:
	if is_instance_valid(_level):
		if is_instance_valid(_level._pause_menu) and _level._pause_menu._root.visible:
			_level._pause_menu.close()
		_level.queue_free()
	await _frames(6)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))

