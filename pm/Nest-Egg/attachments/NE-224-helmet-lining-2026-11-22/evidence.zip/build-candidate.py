from pathlib import Path
from PIL import Image
import json
import subprocess
import shutil
import sys
import numpy as np
base=Path(__file__).resolve().parent
root=Path.cwd()
stage=base/'candidate'
source='art_src/characters/enforcer'
current=root/source
work=stage/source
for name in ('base_rgba.png','07_refined','overrides','neck_overlap'):
    item=current/name
    target=work/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if item.is_dir():
        shutil.copytree(item,target,dirs_exist_ok=True)
    else:
        shutil.copyfile(item,target)
code=work/'neck_overlap/rebuild.py'
script=code.read_text(encoding='utf-8')
addition='''    # Extend the inner helmet lining beneath the raised forearm.
    for column in range(463, 485):
        lining = result[:169, column].copy()
        reach = min(10, column - 462, 2 * (485 - column))
        edge = int(np.flatnonzero(lining[:, 3] >= 128)[-1])
        rows = np.arange(edge + 1, min(edge + 2 + reach, len(lining)))
        underlap = lining[rows - reach]
        keep = underlap[:, 3] > lining[rows, 3]
        result[rows[keep], column, :3] = np.minimum(underlap[keep, :3], [38, 65, 96])
        result[rows[keep], column, 3] = underlap[keep, 3]
'''
assert script.count('    return Image.fromarray(result)')==1
code.write_text(script.replace('    return Image.fromarray(result)',addition+'    return Image.fromarray(result)'),encoding='utf-8')
subprocess.run([sys.executable,'-B',str(code)],check=True,cwd=stage)
assert np.array_equal(np.asarray(Image.open(work/'overrides/refined/head.png')),np.asarray(Image.open(base/'head-source-narrow-10.png')))
spec='tools/comfyui/specs/enforcer_side.json'
text=(root/spec).read_text(encoding='utf-8')
head_start=text.index('    "head": {',text.index('  "parts": {'))
head_end=text.index('    "leg_upper": {',head_start)
block=text[head_start:head_end]
phase=json.loads((base/'crop_phase.json').read_bytes())
lines=json.dumps(phase,indent=2).splitlines()
entry=lines[0]+'\n'+'\n'.join('      '+line for line in lines[1:])
block=block.replace('      "pivot": "head"','      "pivot": "head",\n      "crop_phase": '+entry)
assert block!=text[head_start:head_end]
draft=stage/spec
draft.parent.mkdir(parents=True,exist_ok=True)
draft.write_text(text[:head_start]+block+text[head_end:],encoding='utf-8')
char=stage/'art/characters/enforcer'
rig=stage/'art/rigs/enforcer.json'
rig.parent.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,'-B','tools/comfyui/cut_layers.py','--spec',str(draft),'--work',str(work),'--char',str(char),'--rig',str(rig)],check=True,cwd=root)
assert np.array_equal(np.asarray(Image.open(char/'parts/head.png')),np.asarray(Image.open(base/'head-game-narrow-extended.png')))
new_meta=json.loads((char/'character.json').read_bytes())['textures']['head']
orig=json.loads((root/'art/characters/enforcer/character.json').read_bytes())
assert orig['textures']['head']['pivot']==new_meta['pivot']
assert set(k for k in new_meta if new_meta[k]!=orig['textures']['head'][k])=={'size'}
orig['textures']['head']=new_meta
(char/'character.json').write_text(json.dumps(orig,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for asset in ('head','head_glow'):
    old=np.asarray(Image.open(root/f'art/characters/enforcer/parts/{asset}.png'))
    new=np.asarray(Image.open(char/f'parts/{asset}.png'))
    if asset=='head_glow':
        assert np.array_equal(new[:len(old)],old) and not new[len(old):,:,3].any()
print('prepared exact source, crop footprint, unchanged pivot, unchanged glow')