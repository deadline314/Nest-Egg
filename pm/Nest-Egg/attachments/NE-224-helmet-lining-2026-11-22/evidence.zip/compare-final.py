from pathlib import Path
from PIL import Image
import json
base=Path(__file__).resolve().parent
old=base.parent/'evidence-20261121-ne224-enforcer-neck-edge'
def read(path):
    return json.loads(path.read_bytes())
def failures(report):
    return {(r['pose'],r['zoom'],r['facing'],r['frame'],r['joint']):
        bool(r['center_alpha']<128 or r['enclosed_pixels'] or r['loose_pieces'])
        for r in report['failures']}
summary={}
for mode in ('whole','dressed','isolated','adjacent'):
    original=read(old/f'final-{mode}'/'report.json')
    updated=read(base/f'final-{mode}'/'report.json')
    a,b=failures(original),failures(updated)
    summary[mode]={'samples':original['samples'],'hard_before':sum(a.values()),
        'hard_after':sum(b.values()),'edge_before':len(a)-sum(a.values()),
        'edge_after':len(b)-sum(b.values()),
        'new_keys':list(set(b)-set(a)),
        'new_hard_keys':[key for key,problem in b.items() if problem and not a.get(key)],
        'remaining_hard_keys':[key for key,problem in b.items() if problem]}
    assert original['samples']==updated['samples']
    assert not summary[mode]['new_hard_keys'] and not summary[mode]['new_keys'],summary[mode]
assert [summary['whole'][key] for key in ('hard_before','hard_after')]==[272,6]
assert summary['dressed']['hard_after']==0 and summary['isolated']['hard_after']==0
street={}
for variant in ('before','after'):
    folder=base/f'street-{variant}'
    assert (folder/'exit.txt').read_text().strip()=='0'
    run=read(folder/'street.json')
    assert run['rendering_method']=='forward_plus' and run['hdr_2d'] and 'RX 9070 XT' in run['adapter']
    rows=run['rows']
    assert len(rows)==12
    street[variant]={row['key']:{k:v for k,v in row.items() if k!='physics_frame'} for row in rows}
assert street['before']==street['after']
region=(44,24,87,76)
width=region[2]-region[0]
height=region[3]-region[1]
scale=8
sheet=Image.new('RGB',(2*width*scale,2*height*scale),'#565c62')
for column,folder in enumerate((old/'final-whole',base/'final-whole')):
    native=Image.open(folder/'aim_up_3.4_102.png').convert('RGBA')
    for row in (0,1):
        if row:
            mirrored=(128+128-region[2],region[1],128+128-region[0],region[3])
            cut=native.crop(mirrored)
        else:
            cut=native.crop(region)
        cut=cut.resize((width*scale,height*scale),Image.Resampling.NEAREST)
        sheet.paste(cut,(column*width*scale,row*height*scale),cut)
sheet.save(base/'aim-joint-comparison.png')
summary['street']=street
(base/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print({k:{m:v for m,v in row.items() if m!='remaining_hard_keys'} for k,row in summary.items() if k!='street'})