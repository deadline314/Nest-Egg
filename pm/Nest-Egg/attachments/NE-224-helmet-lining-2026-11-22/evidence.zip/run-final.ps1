param([switch]$Adjacent)
$ErrorActionPreference='Stop'
$e=$PSScriptRoot.Replace('\','/')
$d='D:/NestEggVerification/ne218-baseline-20261117'
$prev='D:/NestEggVerification/evidence-20261121-ne224-enforcer-upper-limbs'
$python='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
$engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$env:APPDATA="$e/final-profile"
$env:LOCALAPPDATA=$env:APPDATA
New-Item -ItemType Directory -Path $env:APPDATA -Force | Out-Null
$modes=if($Adjacent){@('adjacent')}else{@('whole','dressed','isolated')}
foreach($mode in $modes){
    $joints='neck'
    $frames=120
    $out="$e/final-$mode"
    $extra=@()
    if($mode -eq 'whole' -or $mode -eq 'adjacent'){ $extra+='--diagnostic-whole-rig' }
    if($mode -eq 'isolated'){ $extra+='--pair-only' }
    if($mode -eq 'adjacent'){
        $joints='neck,hip_front,hip_back,shoulder_front,shoulder_back'
        $frames=36
    }
    & $python -B "$d/tools/comfyui/gpu_lock.py" -- $engine --path $d --rendering-method forward_plus --rendering-driver vulkan --resolution 1280x720 --max-fps 120 --audio-driver Dummy --quit-after 9000 "$prev/probe.tscn" -- "--out=$out" --chars=enforcer "--joints=$joints" "--frames=$frames" @extra *> "$out.log"
    $exit=$LASTEXITCODE
    if($exit -ne 0 -or (Select-String -Pattern 'ERROR:' -Quiet -LiteralPath "$out.log")){ throw "Imported asset failed to render: $mode" }
    & $python -B tools/check_joint_frames.py $out *> "$out-check.log"
    if($LASTEXITCODE -gt 1){ throw "Imported asset lacks a valid report: $mode" }
    Get-Content "$out-check.log" -TotalCount 2
}