from pathlib import Path
from math import dist
import json

base = Path(__file__).resolve().parent
read = lambda name: json.loads((base / name).read_bytes())
result = {}
for side, facing in (("left", -1), ("right", 1)):
    old, new = (read(f"{build}-{side}/run.json") for build in ("original", "candidate"))
    assert old["input_save"] == new["input_save"]
    assert all(run["exit"] == 0 and not run["errors"] and run["resolution"]["failures"] == 0 for run in (old, new))
    assert old["resolution"]["target"] == new["resolution"]["target"]
    before, after = (run["resolution"]["samples"] for run in (old, new))
    assert len(before) == len(after) == 7
    for a, b in zip(before, after):
        assert {k: v for k, v in a.items() if k != "contact"} == {k: v for k, v in b.items() if k != "contact"}
        if a["name"] in ("reload-complete", "rifle-holding", "melee-holding"):
            assert a["contact"] == b["contact"], (side, a["name"])
    lift_old, lift_new = (read(f"{build}-{side}/lift-samples.json") for build in ("original", "candidate"))
    assert len(lift_old) == len(lift_new) == 4 and lift_old[:2] == lift_new[:2]
    origin = lift_old[0]["position"]
    pivot = lift_old[0]["player"]
    for a, b in zip(lift_old, lift_new):
        assert a["phase"] == b["phase"] and a["lift_time"] == b["lift_time"] and a["player"] == b["player"] == pivot
        t = b["lift_time"] / 0.18
        blend = 2.0 * t * t
        endpoint = (pivot[0] + 2.0 * facing, pivot[1] - 50.0)
        expected = tuple(v + (target - v) * blend for v, target in zip(origin, endpoint))
        assert t <= 0.5 and dist(expected, b["position"]) < 0.001
    delta_old = abs(lift_old[2]["position"][0] - origin[0])
    delta_new = abs(lift_new[2]["position"][0] - origin[0])
    assert delta_old > 5.0 and delta_new < 0.3
    result[side] = {"samples": len(after), "first_motion_time": lift_new[2]["lift_time"],
                    "horizontal_move_before": delta_old, "horizontal_move_after": delta_new}
(base / "comparison.json").write_text(json.dumps(result, indent=2) + "\n", "utf-8")
print(json.dumps(result, indent=2))
