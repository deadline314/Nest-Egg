from pathlib import Path
import os, subprocess, sys
root=Path.cwd()
scope=Path('D:/NestEggVerification/evidence-20261120-ne254-carry-contact')
mode=sys.argv[1]
project=scope/'candidate-project' if mode=='original' else root
relative=Path('game/player/player_carry.gd')
selected=project/relative
candidate=selected.read_bytes()
out=scope/f'focus-{mode}-v2'
out.mkdir()
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','TEMP','TMP','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    folder=out/key
    folder.mkdir()
    env[key]=str(folder)
try:
    if mode=='original':
        old=subprocess.check_output(['git','show','HEAD:game/player/player_carry.gd'],cwd=root)
        assert old!=candidate
        selected.write_bytes(old)
    with (out/'suite.log').open('wb') as log:
        result=subprocess.run(['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(project),'res://tests/smoke_test.tscn','--','--only=ThrowablesSuite'],cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
    raw=(out/'suite.log').read_text('utf-8',errors='replace')
    print('\n'.join(line for line in raw.splitlines() if line.startswith(('checks:','FAIL:','SCRIPT ERROR:'))))
    failures=1 if mode=='original' else 0
    assert f'checks: 483, failures: {failures}' in raw and raw.count('FAIL:')==failures and 'SCRIPT ERROR:' not in raw
finally:
    if mode=='original':
        selected.write_bytes(candidate)
        assert selected.read_bytes()==candidate
