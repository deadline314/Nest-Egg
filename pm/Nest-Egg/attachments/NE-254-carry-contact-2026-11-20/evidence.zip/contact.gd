extends "D:/NestEggVerification/evidence-20261120-ne254-carry-contact/carry_probe.gd"

var _pickup := []


func _press(action: StringName) -> void:
	if action != &"interact":
		await super._press(action)
		return
	var target := _player.carry.nearest_pickable()
	_check(target != null, "observe the actual original crate at pickup")
	if target == null:
		return
	_capture_pickup(target)
	Input.action_press(action)
	for i in 2:
		await _settle(1)
		_capture_pickup(target)
	Input.action_release(action)
	await _settle(1)
	_capture_pickup(target)


func _capture_pickup(target: Throwable) -> void:
	_pickup.append({"position":_vector(target.global_position),"player":_vector(_player.global_position),
		"lift_time":_player.carry._phase_t,"phase":int(_player.carry.phase)})


func _observe(name: String) -> void:
	await super._observe(name)
	var prop := _player.carry.held
	if not is_instance_valid(prop):
		return
	var rig := _player._visual.rig
	var bounds := Rect2(Vector2(-prop.data.size.x * 0.5, -prop.data.size.y), prop.data.size)
	var hands := {}
	for id: StringName in [&"hand_front", &"hand_back"]:
		var bone := rig.bone(id)
		var point := prop.to_local(bone.global_transform * rig.hand_grip_offset(id))
		hands[id] = {"local":_vector(point),"surface_distance":point.distance_to(point.clamp(bounds.position,bounds.end))}
	_samples[-1]["contact"] = {"hands":hands,"prop_position":_vector(prop.global_position),"size":_vector(prop.data.size),
		"player":_vector(_player.global_position),"head":_vector(rig.bone(&"head").global_position)}


func _vector(point: Vector2) -> Array[float]:
	return [point.x,point.y]


func _finish_carry() -> void:
	var file := FileAccess.open(_out_dir.path_join("lift-samples.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(_pickup,"  ")+"\n")
	file.close()
	super._finish_carry()
