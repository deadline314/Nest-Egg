from pathlib import Path
import json

base = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_bytes())
parent = (base / "baseline.txt").read_text().strip()
before_hashes = read(base.parent / "evidence-20261120-ne250-stage-step/published-source.json")
after_hashes = read(base / "source.json")
movement_keys = {"sole", "foot_angles", "foot", "knees", "front_boot_screen",
                 "front_knee", "back_boot_screen", "back_knee"}
held_phases = ("aim_up", "aim_down", "crouch_hold")
summary = {}
for path in sorted((base / "stock").glob("*/motion.json")):
    label = path.parent.name
    cases = (path.parent, base / "candidate" / label)
    for case, hashes in zip(cases, (before_hashes, after_hashes), strict=True):
        command = read(case / "command.json")
        assert command["source"] == parent
        assert all(hashes[key] == digest for key, digest in command["worktree_sha256"].items())
    old, new = (read(case / "motion.json") for case in cases)
    assert old["checks_failed"] == new["checks_failed"] == 0
    old, new = old["rows"], new["rows"]
    assert len(old) == len(new) == 151, label
    for before, after in zip(old, new, strict=True):
        assert before.keys() == after.keys()
        assert all(before[key] == after[key] for key in before if key not in movement_keys), (label, before["action"], before["frame"])
        if before["kneel_weight"] == 0.0:
            assert before == after, (label, "normal motion changed")
        elif before["kneel_weight"] == 1.0:
            assert before["foot"] == after["foot"] and before["back_knee"] == after["back_knee"]
            assert before["foot_angles"][0] == after["foot_angles"][0]
            assert abs(after["foot_angles"][1] - before["foot_angles"][1] - 0.18) < 0.001

    def peak(trace, phases):
        picked = [row for row in trace if row["action"] in phases and row["kneel_weight"] > 0.001]
        worst = max(picked, key=lambda row: max(row["sole"]))
        return {"depth": max(worst["sole"]), "phase": worst["action"], "frame": worst["frame"]}

    phases = ("enter", "brake", "leave", "resume")
    kneeling = [peak(trace, phases) for trace in (old, new)]
    holding = [peak(trace, held_phases) for trace in (old, new)]
    assert kneeling[0]["depth"] >= 3.25 and kneeling[1]["depth"] < 0.65
    assert holding[0]["depth"] >= 1.35 and 0.35 <= holding[1]["depth"] <= 0.55
    summary[label] = {"frames": len(new), "kneeling": kneeling, "holding": holding}
assert len(summary) == 4
(base / "results.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary))
