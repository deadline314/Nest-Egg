extends "res://tools/ch1_flow_probe.gd"

var store_path := ""
var side := 1
var app: Node
var player: Player
var rig: CharacterRig
var rows: Array[Dictionary] = []
var lens := 0.0
var mode := ""
var anchor_x := 472.0
var shoe_outlines: Dictionary[int, PackedVector2Array] = {}
var sole_local := {}
var toe_pitch := []


func _run() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--slot="):
			store_path = arg.trim_prefix("--slot=")
		elif arg.begins_with("--side="):
			side = int(arg.trim_prefix("--side="))
		elif arg.begins_with("--lens="):
			lens = float(arg.trim_prefix("--lens="))
		elif arg.begins_with("--mode="):
			mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--anchor-x="):
			anchor_x = float(arg.trim_prefix("--anchor-x="))
	if not store_path.is_absolute_path() or side not in [-1, 1] or mode != "kneel":
		get_tree().quit(2)
		return
	app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	app.set("_run_store", RunSaveStore.new(store_path))
	add_child(app)
	for frame in STEP_LIMIT:
		if app.get("_screen") is MainMenu and not bool(app.call("_route_pending")):
			break
		await get_tree().process_frame
	var menu := app.get("_screen") as MainMenu
	if menu == null:
		get_tree().quit(2)
		return
	await _settle(8)
	menu._continue_button.pressed.emit()
	for frame in STEP_LIMIT:
		var current := app.get("_screen") as Level
		if current != null and current.is_initialized() and current.data.id == &"ch1_street" and not bool(app.call("_route_pending")):
			_level = current
			break
		await get_tree().process_frame
	if _level == null or _level.player == null:
		get_tree().quit(2)
		return
	player = _level.player
	rig = player._visual.rig
	player.global_position = Vector2(anchor_x, player.global_position.y)
	player.velocity = Vector2.ZERO
	_level.camera.snap_to_target()
	var aim := &"aim_right" if side > 0 else &"aim_left"
	AimInput.set_virtual_gamepad(player, true)
	Input.action_release(&"aim_right")
	Input.action_release(&"aim_left")
	AimInput.restore_direction(Vector2(side,0))
	Input.action_press(aim)
	await _settle(36)
	_check(player.facing == side and player.is_on_floor(), "real safe street floor and requested facing")
	if lens > 0.0:
		_level.camera.set_physics_process(false)
		_level.camera.position_smoothing_enabled = false
		_level.camera.offset = Vector2.ZERO
	await _kneel_sequence()
	Input.action_release(aim)
	AimInput.set_virtual_gamepad(player, false)
	var file := FileAccess.open(_out_dir.path_join("motion.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks_failed":_failures,"side":side,"mode":mode,"rows":rows, "sole_local":sole_local,"toe_pitch":toe_pitch},"  ") + "\n")
	file.close()
	app.call("_quit", int(_failures > 0))


func _kneel_sequence() -> void:
	await _record("stand", 0, true)
	Input.action_press(&"move_down")
	await _window("enter", 20)
	_check(player.is_crouching and rig.animator._kneel_w > 0.99 and rig.active_pose_parts() == &"kneel",
		"real crouch uses the dedicated held-gun kneel")
	for height: StringName in [&"aim_up", &"aim_down"]:
		Input.action_press(height)
		await _window(String(height), 20)
		_check(absf(player.aim_dir.y) >= 0.5 and player.facing == side, "real diagonal aim stays in chosen direction")
		Input.action_release(height)
	var move := &"move_right" if side > 0 else &"move_left"
	var anchor := player.global_position.x
	Input.action_press(move)
	await _window("crouch_hold", 12)
	_check(is_equal_approx(player.global_position.x, anchor), "holding direction while crouched preserves intentional immobility")
	Input.action_release(move)
	Input.action_release(&"move_down")
	await _window("leave", 20)
	_check(not player.is_crouching and not rig.animator._kneel_parts, "standing returns to original leg artwork")
	Input.action_press(move)
	await _window("move", 18)
	_check(absf(player.velocity.x) > 100.0, "standing direction reaches actual running speed")
	Input.action_press(&"move_down")
	await _window("brake", 20)
	_check(player.velocity.x == 0.0 and player.is_crouching, "crouch stops the same physical movement")
	Input.action_release(&"move_down")
	await _window("resume", 20)
	_check(absf(player.velocity.x) > 100.0 and not player.is_crouching, "ending the crouch resumes actual movement")
	Input.action_release(move)


func _window(label: String, count: int) -> void:
	for frame in range(1, count + 1):
		await _record(label, frame, frame in [2, 5, 8, 11, 20])


func _record(label: String, frame: int, shot: bool) -> void:
	if lens > 0.0:
		_level.camera.zoom = Vector2.ONE * lens
		_level.camera.global_position = player.global_position + Vector2(0, -32)
		_level.camera.force_update_scroll()
	await RenderingServer.frame_post_draw
	var root := player.global_position
	var sole_front := _lowest_shoe(&"foot_front",root.y)
	var sole_back := _lowest_shoe(&"foot_back",root.y)
	var feet := {"front": _p(rig.bone(&"foot_front").global_position-root),
		"back": _p(rig.bone(&"foot_back").global_position-root)}
	var chest := rig.bone(&"chest")
	var hip := rig.bone(&"hip")
	var head := rig.bone(&"head")
	var canvas := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	rows.append({"action":label,"frame":frame,"root":_p(root),"velocity":_p(player.velocity),"facing":player.facing,"aim":_p(player.aim_dir),
		"state":player.state,"ground":player.is_on_floor(),"dash_time":player._dash_left,"physics":Engine.get_physics_frames(),
		"foot":feet,"sole":[sole_front,sole_back],
		"crouching": player.is_crouching, "kneel_weight": rig.animator._kneel_w, "parts": String(rig.active_pose_parts()),
		"back_knee": _p(rig.bone(&"leg_back_lower").global_position - root),
		"front_knee": _p(rig.bone(&"leg_front_lower").global_position - root),
		"front_hand": _p(rig.bone(&"hand_front").global_position - root),
		"back_hand": _p(rig.bone(&"hand_back").global_position - root),
"chest":_p(chest.global_position-root),"hip":_p(hip.global_position-root),
		"head":_p(head.global_position-root),"muzzle":_p(player.muzzle_position()-root),"rounds":player.loadout.mag_in(player.loadout.active_slot),
		"knees":[rig.bone(&"leg_front_lower").rotation,rig.bone(&"leg_back_lower").rotation],"foot_angles":[rig.animator.foot_angle(&"foot_front"),rig.animator.foot_angle(&"foot_back")],"chest_rotation":chest.rotation,"hip_rotation":hip.rotation,
		"head_screen":_p(canvas*head.global_position),"root_screen":_p(canvas*root),
		"front_boot_screen":_p(canvas*rig.bone(&"foot_front").global_position),
		"back_boot_screen":_p(canvas*rig.bone(&"foot_back").global_position),
		"weapon":rig.weapon_root().visible,"zoom":_p(_level.camera.zoom),
		"camera":_p(_level.camera.global_position),"camera_center":_p(_level.camera.get_screen_center_position()),
		"camera_left":_level.camera.limit_left})
	if shot:
		_capture("%s-%03d" % [label,frame])
	await get_tree().process_frame


func _p(vector: Vector2) -> Array:
	return [vector.x, vector.y]


func _lowest_shoe(bone: StringName, floor_world: float) -> float:
	var shoe := rig.contact_part(bone)
	if not is_instance_valid(shoe):
		_check(false, "live boot sprite unavailable: " + str(bone))
		return INF
	var key := shoe.texture.get_instance_id()
	if not shoe_outlines.has(key):
		var image := shoe.texture.get_image()
		var boundary := PackedVector2Array()
		for x in image.get_width():
			var top := -1
			var bottom := -1
			for y in image.get_height():
				if image.get_pixel(x,y).a < 0.5:
					continue
				if top < 0:
					top = y
				bottom = y
			if top >= 0:
				boundary.append(Vector2(x+0.5,top+0.5))
				boundary.append(Vector2(x+0.5,bottom+0.5))
		shoe_outlines[key] = Geometry2D.convex_hull(boundary)
	if not sole_local.has(String(bone)):
		var contact: Array[Array] = []
		for point: Vector2 in shoe_outlines[key]:
			contact.append(_p(rig.bone(bone).to_local(shoe.to_global(CharacterRig.part_source_point(shoe,point)))))
		sole_local[String(bone)] = contact
	var sample_pitch := bone == &"foot_back" and toe_pitch.is_empty() and rig.animator._kneel_w > 0.999
	var low := -INF
	var contacts := PackedVector2Array()
	for source_point: Vector2 in shoe_outlines[key]:
		var point := shoe.to_global(CharacterRig.part_source_point(shoe,source_point))
		low = maxf(low, point.y - floor_world)
		if sample_pitch:
			contacts.append(point)
	if sample_pitch:
		var ankle := rig.bone(bone).global_position
		for tick in range(-10, 11):
			var change := 0.04 * tick
			var bottom := -INF
			for point: Vector2 in contacts:
				bottom = maxf(bottom, (ankle + (point - ankle).rotated(float(side) * change)).y - floor_world)
			toe_pitch.append([change, bottom])
	return low
