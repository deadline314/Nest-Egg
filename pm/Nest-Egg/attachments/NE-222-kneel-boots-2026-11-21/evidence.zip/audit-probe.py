from pathlib import Path
import os
import subprocess
import sys

scope = Path(__file__).resolve().parent
root = Path.cwd()
audit = (root / "game/rig/anim_audit.gd").read_text(encoding="utf-8")
first = audit.index("\tvar ctx :=")
last = audit.index('\t_hold(ctx, input, 50, "crouch")', first)
intro = (audit[first:last].replace("\t_reset(input, rig)", "\tAnimAudit._reset(input, rig)")
         .replace("\t_hold(", "\tAnimAudit._hold(").replace("\t\t_hold(", "\t\tAnimAudit._hold("))
script = scope / "audit-probe.gd"
script.write_text('''extends Node


func _ready() -> void:
	var rig := CharacterRig.new()
	add_child(rig)
	if not rig.setup("rin"):
		get_tree().quit(1)
		return
	rig.set_weapon("rifle")
''' + intro + '''
	for frame in 12:
		rig.animate(AnimAudit.DT, input)
		var lowest_ankle := -INF
		var lowest_painted := -INF
		for id: StringName in [&"foot_front", &"foot_back"]:
			var foot := rig.bone(id)
			lowest_ankle = maxf(lowest_ankle, rig.animator.bone_pos(id).y - rig.animator.ground_level())
			for offset: Vector2 in rig.animator._dash_sole:
				var point := rig.to_local(foot.to_global(offset))
				lowest_painted = maxf(lowest_painted, point.y - rig.animator._dash_floor)
		print("sole-audit ", frame, " / ankle ", lowest_ankle, " / sole ", lowest_painted)
	get_tree().quit()
''', encoding="utf-8")
scene = scope / "audit-probe.tscn"
scene.write_text('[gd_scene load_steps=2 format=3]\n\n'
                 f'[ext_resource type="Script" path="{script.as_posix()}" id="1"]\n\n'
                 '[node name="PaintedSoleAuditProbe" type="Node"]\nscript = ExtResource("1")\n',
                 encoding="utf-8")
command = ["C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--headless",
           "--path", str(root), str(scene)]
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    directory = scope / ("audit-" + sys.argv[1]) / key
    directory.mkdir(parents=True, exist_ok=True)
    env[key] = str(directory)
result = subprocess.run(command, env=env, text=True, encoding="utf-8", stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT, timeout=90)
(scope / f"audit-probe-{sys.argv[1]}.log").write_text(result.stdout, encoding="utf-8")
print(result.stdout)
assert result.returncode == 0 and result.stdout.count("sole-audit ") == 12 and "SCRIPT ERROR" not in result.stdout
