from pathlib import Path
import os
import subprocess
import sys

base = Path(__file__).resolve().parent
label = sys.argv[1]
folder = base / label
folder.mkdir()
suite = sys.argv[2] if len(sys.argv) > 2 else "ProtagonistMotionSuite"
assert suite in ("ProtagonistMotionSuite", "AnimAuditSuite,ProtagonistMotionSuite", "FxMeleePickupsSuite")
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "XDG_DATA_HOME", "XDG_CONFIG_HOME", "TEMP", "TMP", "TMPDIR"):
    env[key] = str(folder / key)
    Path(env[key]).mkdir()
env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8", SHARDS="1", LOG_DIR=str(folder / "shards"),
           GODOT="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe")
command = ["C:/Program Files/Git/bin/bash.exe", "-c",
           'python3() { python "$@"; }; export -f python3; tools/run_tests_parallel.sh --only="$1"', "_", suite]
with (folder / "engine.log").open("wb") as log:
    proc = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=240)
raw = (folder / "engine.log").read_text(encoding="utf-8", errors="replace")
print(raw)
assert not any("SCRIPT ERROR:" in f.read_text(encoding="utf-8", errors="replace") for f in (folder / "shards").glob("shard_*.log"))
sys.exit(proc.returncode)
