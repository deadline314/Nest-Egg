from pathlib import Path
from hashlib import sha256
import json,subprocess,sys

here=Path(__file__).resolve().parent
project=here.parent/'ne218-baseline-20261117'
file='ui/quest_guidance.gd'
path=project/file
prior=json.loads((here.parent/'evidence-20261120-ne222-reload-poses/published-source.json').read_bytes())
next_state=json.loads((here/'source.json').read_bytes())
before=path.read_bytes()
sha=lambda data:sha256(data).hexdigest()
assert sha(before)==next_state[file]
revision=(here/'baseline.txt').read_text().strip()
old=subprocess.check_output(['git','show',revision+':'+file])
if sha(old)!=prior[file]:
    old=old.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
assert sha(old)==prior[file]
try:
    path.write_bytes(old)
    subprocess.run([sys.executable,'-X','utf8',str(here/'run.py'),str(project),'screen-original','1280x720','zh'],check=True)
finally:
    path.write_bytes(before)
assert sha(path.read_bytes())==next_state[file]
