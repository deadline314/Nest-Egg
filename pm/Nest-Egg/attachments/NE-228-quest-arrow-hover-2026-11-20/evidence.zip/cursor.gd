extends "res://tools/ch1_flow_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
var _store := ""
var _main: Node
var _tips := {}
var _lang := ""


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--lang="):
			_lang = arg.trim_prefix("--lang=")
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.id == &"ch2_pawnshop", "original chapter-two pawnshop save continues")
	if _level == null or _level.player == null:
		_finish_tips()
		return
	if not _lang.is_empty():
		Story.set_language(_lang)
	GameState.set_flag(&"ch2_morning_settled", true, false)
	_level.player.set_physics_process(false)
	_level.player.global_position.x = 288.0
	_level.camera.snap_to_target()
	_level.camera.force_update_scroll()
	_level.camera.set_process(false)
	_level.camera.set_physics_process(false)
	await _settle(20)
	var guide: QuestGuidance = _level.hud.quest_guidance
	var original := guide.state.pinned_id
	await _take(guide, "ch2_settle", "roof", false)
	await _take(guide, "sq4_radio", "radio", true)
	await _take(guide, "ch2_settle", "roof-restored", false)
	guide.state.pin(original, guide.catalog)
	_finish_tips()


func _take(guide: QuestGuidance, quest: String, label: String, local: bool) -> void:
	guide.state.pin(quest, guide.catalog)
	await _settle(10)
	var arrow := guide._arrow
	var route := QuestCatalog.current_step(guide._target, GameState.world_flags)
	var destination: Dictionary = route.get("location", {})
	_check(arrow.visible and guide._target.get("id") == quest and not destination.is_empty(), label+" shows the real objective arrow")
	_check((destination.get("level") == _level.data.resource_path) == local, label+" points into the expected area")
	var hover_immediate := false
	for count in 52:
		var center := arrow.get_global_transform_with_canvas() * (arrow.get_minimum_size() * 0.5)
		if count == 0:
			Input.warp_mouse(get_viewport().get_final_transform() * center)
		var move := InputEventMouseMotion.new()
		move.position = center
		move.global_position = center
		get_viewport().push_input(move, true)
		hover_immediate = hover_immediate or get_viewport().gui_get_hovered_control() == arrow
		await _settle(1)
	await RenderingServer.frame_post_draw
	var hovered := get_viewport().gui_get_hovered_control()
	_tips[label] = {"tip":arrow.tooltip_text,"caption":arrow.text,"quest":quest,"expected_title":QuestCatalog.display_text(route,"title"),
		"area":str(destination.get("level")),"visible":arrow.visible,"hover":is_instance_valid(hovered) and hovered==arrow,
		"hover_immediate":hover_immediate,"row_yielding":guide.yielding,"player_x":_level.player.global_position.x,"camera":str(_level.camera.get_screen_center_position()),"filter":arrow.mouse_filter,"window_focus":get_window().has_focus(),
		"hovered_owner":str(hovered.get_path()) if is_instance_valid(hovered) else "",
		"pointer":str(get_viewport().get_mouse_position()),"size":[arrow.size.x,arrow.size.y],"minimum":[arrow.get_minimum_size().x,arrow.get_minimum_size().y], "rect":str(arrow.get_global_transform_with_canvas() * Rect2(Vector2.ZERO, arrow.size))}
	_check(CAPTURE.image(get_viewport()).save_png(_out_dir.path_join(label+".png")) == OK, "save native "+label)


func _finish_tips() -> void:
	var f := FileAccess.open(_out_dir.path_join("arrow.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"failures":_failures,"tips":_tips,"story_language":Story.language},"  ")+"\n")
	f.close()
	_main.call("_quit",0 if _failures==0 else 1)
