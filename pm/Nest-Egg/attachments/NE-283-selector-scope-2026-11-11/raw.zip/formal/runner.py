from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parents[1]
base=root/'work/ticket-batch-validation'
candidate=json.loads((base/'candidate.json').read_bytes());repo=Path(candidate['worktree'])
def hashes():return {name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in candidate['source_sha256']}
assert hashes()==candidate['source_sha256']
command=['C:/Program Files/Git/bin/bash.exe','tools/run_tests_changed.sh',candidate['base']]
(base/'command.json').write_text(json.dumps(command,indent=2),encoding='utf8')
env=dict(os.environ,GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='4',LOG_DIR=str(base/'logs'),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
env['PATH']='C:/Program Files/Git/bin;'+env.get('PATH','')
started=time.monotonic()
with (base/'full.log').open('wb') as log:
 process=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:code=process.wait(timeout=7200)
 except subprocess.TimeoutExpired:
  subprocess.run(["taskkill","/PID",str(process.pid),"/T","/F"],capture_output=True);code=124
after=hashes();unchanged=after==candidate['source_sha256']
receipt={'exit':code,'seconds':time.monotonic()-started,'source_after':after,'sources_unchanged':unchanged,'all_requested_via_official_changed_scope':True,'base':candidate['base'],'shards':4}
(base/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in receipt.items() if k!='source_after'}));print((base/'full.log').read_bytes().decode('utf8')[-8000:])
raise SystemExit(0 if code==0 and unchanged else 1)
