from pathlib import Path
import hashlib, json, os, shutil, subprocess

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118')
package = base / 'combined-three-part-v7'
out = base / 'root-integration-v7'
out.mkdir(exist_ok=False)
assert not (package / 'PENDING_VISUAL_REVIEW.md').exists()
rows = json.loads((package / 'adoption-manifest.json').read_text())
assert len(rows) == len({r['path'] for r in rows}) == 17
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
canonical = lambda p: hashlib.sha256(p.read_bytes().replace(b'\r\n', b'\n') if p.suffix in {'.py', '.json'} else p.read_bytes()).hexdigest()
source = json.loads((base.parent / 'ne267-combined-20261118/published-source.json').read_text())
assert all(sha(shared / name) == digest for name, digest in source.items()), 'published shared source drift'
for r in rows:
    assert sha(package / 'adoption' / r['path']) == r['after_sha256'], r['path']
    for workspace in (root, shared):
        p = workspace / r['path']
        assert (not p.exists() if r['before_sha256'] is None else p.is_file() and (sha(p) == r['before_sha256'] or canonical(p) == r['before_canonical_sha256'])), str(p)
record = json.loads((package / 'adoption/art_src/characters/guest_hong_repairs_20261118/provenance.json').read_text())
prereqs = list(record['inputs'])
prereqs += [p.relative_to(root).as_posix() for p in (root / 'art_src/characters/guest_hong/06_parts').glob('*.png')]
assert len(prereqs) >= 23, 'original part inputs missing'
for name in prereqs:
    assert (root / name).is_file(), name
    if name in record['inputs']:
        assert canonical(root / name) == record['inputs'][name], name
    assert not (shared / name).exists() or canonical(shared / name) == canonical(root / name), name
for workspace in (root, shared):
    assert not list((workspace / 'art_src/characters/guest_hong/overrides').rglob('*.png')), 'existing foreign override must be retained'
for label, workspace in (('root', root), ('shared', shared)):
    for r in rows:
        target = workspace / r['path']
        if target.is_file():
            backup = out / 'before' / label / r['path']
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(target, backup)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(package / 'adoption' / r['path'], target)
        assert sha(target) == r['after_sha256']
for name in prereqs:
    if not (shared / name).exists():
        (shared / name).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / name, shared / name)
source.update({r['path']: r['after_sha256'] for r in rows})
source.update({name: sha(shared / name) for name in prereqs})
(out / 'adoption-manifest.json').write_text(json.dumps(rows, indent=2) + '\n')
(out / 'source-adopted.json').write_text(json.dumps(source, indent=2) + '\n')
runtime_names = [p.relative_to(root).as_posix() for p in (root / 'art/characters/guest_hong').rglob('*') if p.is_file() and (p.suffix == '.png' or p.name == 'character.json')]
runtime_names += ['art/rigs/guest_hong.json', 'art/motion/guest_hong.json']
runtime = {name: sha(root / name) for name in runtime_names}
assert all(sha(shared / name) == digest for name, digest in runtime.items())
(out / 'runtime-approved.json').write_text(json.dumps(runtime, indent=2) + '\n')
python = 'D:/ComfyUI/.venv-rocm/Scripts/python.exe'
godot = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
env = os.environ.copy()
env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1', GODOT=godot)
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
commands = [('root-self-check', [python, '-B', '-X', 'utf8', 'art_src/characters/guest_hong_repairs_20261118/self_check.py', '--scratch', str(base)], root),
            ('root-callback', [python, '-B', '-X', 'utf8', 'art_src/characters/guest_hong_repairs_20261118/rebuild.py'], root)]
imp = [python, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--', godot, '--headless', '--path', str(shared), '--editor', '--quit']
commands += [('import-before-build', imp, shared),
             ('standard-build', [python, '-B', '-X', 'utf8', 'tools/comfyui/build_character.py', '--recipe', 'tools/comfyui/recipes/guest_hong.json', '--from', 'textures', '--to', 'normals'], shared),
             ('import-after-build', imp, shared)]
results = []
for label, command, cwd in commands:
    (out / (label + '-command.json')).write_text(json.dumps({'command': command, 'cwd': str(cwd)}, indent=2) + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=900)
    raw = (out / (label + '.log')).read_bytes()
    row = {'label': label, 'exit': result.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'errors': [line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line]}
    results.append(row)
    (out / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    assert row['exit'] == row['script_errors'] == 0 and not row['errors'], raw[-2400:]
assert all(sha(shared / name) == digest for name, digest in runtime.items()), 'standard runtime rebuild drift'
for name, digest in record['outputs'].items():
    path = f'art_src/characters/guest_hong/overrides/refined/{name}.png'
    assert sha(root / path) == sha(shared / path) == digest
    source[path] = digest
assert all(sha(shared / name) == digest for name, digest in source.items()), 'integrated source drift'
(out / 'source-final.json').write_text(json.dumps(source, indent=2) + '\n')
print(f'17-file adoption; {len(source)} guarded source files; all runtime bytes held through standard build.', flush=True)
