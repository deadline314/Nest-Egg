from pathlib import Path
import hashlib, json, os, subprocess
root=Path.cwd()
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118/root-integration-v7/native-s20')
out.mkdir(exist_ok=False)
original=(shared/'work/ne267_chen_scene.gd').read_text(encoding='utf-8')
text=original.replace('ch2_t_s19_band','ch2_t_s20_letter').replace('ch2_t_s19_quiet','ch2_t_s20_story').replace('ch2_t_s19_done','ch2_t_s20_done').replace('&"chen"','&"hong"')
target=shared/'work/ne267_hong_scene.gd'
target.write_text(text,encoding='utf-8')
scene='[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://work/ne267_hong_scene.gd" id="1"]\n\n[node name="HongScene" type="Node2D"]\nscript = ExtResource("1")\n'
target.with_suffix('.tscn').write_text(scene,encoding='utf-8')
(out/target.name).write_text(text,encoding='utf-8')
(out/target.with_suffix('.tscn').name).write_text(scene,encoding='utf-8')
(out/'adapter-scope.json').write_text(json.dumps({'source':'work/ne267_chen_scene.gd','source_sha256':hashlib.sha256(original.encode()).hexdigest(),'changes':['three formal S19 scene identifiers replaced by S20 letter/story/done','observed actor chen replaced by hong'],'classification':'direct CutscenePlayer, synthetic dialogue only; original support/normal/transition checks unchanged'},indent=2)+'\n')
source=json.loads((out.parent/'source-final.json').read_text())
snapshot=lambda:{name:hashlib.sha256((shared/name).read_bytes()).hexdigest() for name in source}
assert snapshot()==source
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(out/'profile'/key)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(shared),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','--fixed-fps','60','res://work/ne267_hong_scene.tscn','--','--out='+str(out)]
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
    r=subprocess.run(command,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
raw=(out/'raw.log').read_bytes()
result={'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'errors':[s.decode(errors='replace') for s in raw.splitlines() if b'ERROR:' in s],'source_held':snapshot()==source,'pngs':len(list(out.glob('*.png')))}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
print(raw.decode(errors='replace')[-1800:],flush=True)
assert result['exit']==result['script_errors']==0 and not result['errors'] and result['source_held']
