from pathlib import Path
import hashlib, json, os, subprocess

shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118/root-integration-v7')
folder = base / 'checks'
folder.mkdir(exist_ok=False)
source = json.loads((base / 'source-final.json').read_text())
snapshot = lambda: {name: hashlib.sha256((shared / name).read_bytes()).hexdigest() for name in source}
assert snapshot() == source
env = os.environ.copy()
env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', SHARDS='8', LOG_DIR=str(folder / 'shards'))
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(folder / 'profile' / key)
command = ['C:/Program Files/Git/bin/bash.exe', '-c', 'python3() { python "$@"; }; export -f python3; tools/run_tests_changed.sh 6ddf32b5f5a188914cd008af9904286f29718067']
(folder / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (folder / 'raw.log').open('wb') as log:
    result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=2400)
raw = (folder / 'raw.log').read_bytes()
record = {'exit': result.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'errors': [line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line], 'source_held': snapshot() == source}
(folder / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
print(raw.decode(errors='replace')[-2600:], flush=True)
assert record['exit'] == record['script_errors'] == 0 and not record['errors'] and record['source_held']
