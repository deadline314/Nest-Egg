from pathlib import Path
from PIL import Image, ImageDraw
root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118/root-integration-v7')
out=base/'material-review'
out.mkdir(exist_ok=False)
for part in ('torso','arm_upper','arm_lower'):
    name=f'art/characters/guest_hong/parts/{part}.png'
    before=Image.open(base/'before/root'/name).convert('RGBA')
    after=Image.open(root/name).convert('RGBA')
    assert before.size==after.size
    w,h=after.size
    page=Image.new('RGB',(max(140,w+12)*6,h+36),(60,60,60))
    draw=ImageDraw.Draw(page)
    for index,(label,background) in enumerate((('black',(0,0,0)),('gray',(128,128,128)),('white',(255,255,255)))):
        for version,image in enumerate((before,after)):
            x=(index*2+version)*max(140,w+12)
            cell=Image.new('RGBA',(w,h),background+(255,))
            cell.alpha_composite(image)
            page.paste(cell.convert('RGB'),(x,28))
            draw.text((x+2,4),f'{label} '+('main' if version==0 else 'V7'),fill=(255,255,255))
    page.save(out/(part+'-before-after-3bg.png'))
print(str(out))
