from pathlib import Path
import hashlib, json, shutil, zipfile
root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118')
integration=base/'root-integration-v7'
target=root/'pm/Nest-Egg/attachments/NE-267-hong-seams-2026-11-18'
target.mkdir(exist_ok=True)
assert not list(target.iterdir()), 'do not overwrite a published package'
staging=integration/'packages'
staging.mkdir(exist_ok=True)
manifest={'baseline':'6ddf32b5f5a188914cd008af9904286f29718067','archives':[],'source_paths':{}}
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def archive(name,entries):
    assert len(entries)==len(set(entries))
    output=staging/name
    records=[]
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for label,source in sorted(entries.items()):
            assert source.is_file(),str(source)
            z.write(source,label)
            records.append({'path':label,'bytes':source.stat().st_size,'sha256':digest(source)})
        z.writestr('CONTENTS.json',json.dumps(records,ensure_ascii=False,indent=2)+'\n')
    assert output.stat().st_size<95_000_000,(name,output.stat().st_size)
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        assert len(z.infolist())==len(records)+1
        for row in records:
            with z.open(row['path']) as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
    shutil.copyfile(output,target/name)
    assert digest(output)==digest(target/name)
    manifest['archives'].append({'name':name,'bytes':output.stat().st_size,'sha256':digest(output),'files':len(records),'all_members_reread_sha256':True})
    (target/'ARCHIVES.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(name,output.stat().st_size,len(records),flush=True)
comparison=json.loads((base/'combined-three-part-v7/joint-comparison-73920.json').read_text())
for case in comparison['cases']:
    entries={}
    for edition in ('before','after'):
        folder=Path(case[edition+'_path'])
        manifest['source_paths'][str(folder)]='joints-'+case['case']+'.zip/'+edition
        for path in folder.rglob('*'):
            if path.is_file():entries[edition+'/'+path.relative_to(folder).as_posix()]=path
    if case['case']=='performance':
        for edition in ('before','after'):
            name='joints-performance-'+edition+'.zip'
            manifest['source_paths'][case[edition+'_path']]=name+'/'+edition
            archive(name,{label:path for label,path in entries.items() if label.startswith(edition+'/')})
    else:
        archive('joints-'+case['case']+'.zip',entries)
entries={}
for path in (integration/'before/root').rglob('*'):
    if path.is_file():entries['before/'+path.relative_to(integration/'before/root').as_posix()]=path
rows=json.loads((integration/'adoption-manifest.json').read_text())
for row in rows:entries['adopted/'+row['path']]=root/row['path']
record=json.loads((root/'art_src/characters/guest_hong_repairs_20261118/provenance.json').read_text(encoding='utf-8'))
inputs=set(record['inputs'])
inputs.update(p.relative_to(root).as_posix() for p in (root/'art_src/characters/guest_hong/06_parts').glob('*.png'))
for name in inputs:entries['source-inputs/'+name]=root/name
for path in (base/'combined-three-part-v7').iterdir():
    if path.is_file():entries['frozen-proof/'+path.name]=path
for folder in ('visual','normal-binding'):
    for path in (base/'v7-upper-underlap'/folder).rglob('*'):
        if path.is_file() and 'profile' not in path.parts:
            entries['native-'+folder+'/'+path.relative_to(base/'v7-upper-underlap'/folder).as_posix()]=path
for path in (base/'v7-upper-underlap').glob('source-*'):
    if path.is_file():entries['source-review/'+path.name]=path
archive('source-and-native.zip',entries)
print('Six original joint archives plus source/native archive independently reread.',flush=True)
