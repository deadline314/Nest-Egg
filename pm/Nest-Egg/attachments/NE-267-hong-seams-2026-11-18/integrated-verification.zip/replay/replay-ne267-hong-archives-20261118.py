from pathlib import Path
import json, os, subprocess, zipfile
root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118/root-integration-v7')
folder=base/'archive-joint-replay'
folder.mkdir(exist_ok=False)
env=os.environ.copy()
env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
python='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
checker=root/'tools/check_joint_frames.py'
control=subprocess.run([python,'-B',str(checker),'--self-check'],cwd=root,env=env,capture_output=True,timeout=120)
(folder/'negative-control.log').write_bytes(control.stdout+control.stderr)
assert control.returncode==0
results=[]
for archive in sorted((base/'packages').glob('joints-*.zip')):
    if archive.name=='joints-performance.zip':continue
    extracted=folder/archive.stem
    extracted.mkdir()
    with zipfile.ZipFile(archive) as z:
        for entry in z.infolist():
            assert (extracted/entry.filename).resolve().is_relative_to(extracted.resolve())
        z.extractall(extracted)
    for edition in ('before','after'):
        data=extracted/edition
        if not data.is_dir():continue
        original=json.loads((data/'report.json').read_text(encoding='utf-8'))
        command=[python,'-B',str(checker),str(data)]
        run=subprocess.run(command,cwd=root,env=env,capture_output=True,timeout=300)
        (folder/(archive.stem+'-'+edition+'.log')).write_bytes(run.stdout+run.stderr)
        actual=json.loads((data/'report.json').read_text(encoding='utf-8'))
        assert actual==original,(archive.name,edition,'report drift')
        assert run.returncode==int(actual['failed_samples']>0)
        results.append({'archive':archive.name,'edition':edition,'exit':run.returncode,'samples':actual['samples'],'failures':actual['failed_samples'],'report_exact':True})
        (folder/'result.json').write_text(json.dumps({'negative_control_exit':control.returncode,'cases':results},indent=2)+'\n')
        print(archive.name,edition,actual['samples'],actual['failed_samples'],flush=True)
assert len(results)==12
assert sum(r['samples'] for r in results if r['edition']=='before')==73920
assert sum(r['samples'] for r in results if r['edition']=='after')==73920
assert sum(r['failures'] for r in results if r['edition']=='before')==811
assert sum(r['failures'] for r in results if r['edition']=='after')==32
print('All 147840 original archived checks replayed; 12 reports exact; original negative controls active.',flush=True)
