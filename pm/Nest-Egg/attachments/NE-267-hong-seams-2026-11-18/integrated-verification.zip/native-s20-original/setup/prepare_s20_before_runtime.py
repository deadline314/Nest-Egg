"""建立獨立洪先生原版 S20 對照環境；不啟動 GPU。"""
from pathlib import Path
import hashlib, json, os, shutil

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'runtime'
TARGET = BASE / 's20-before-runtime'
FROZEN = BASE / 'baseline-source'
assert not TARGET.exists(), '既有對照環境不得覆寫'
files = size = 0
for source in SOURCE.rglob('*'):
    if not source.is_file():
        continue
    assert not source.is_symlink() and not source.is_junction(), str(source)
    target = TARGET / source.relative_to(SOURCE)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert not os.path.samefile(source, target), str(target)
    files += 1
    size += source.stat().st_size

restored = []
for source in FROZEN.rglob('*'):
    if not source.is_file():
        continue
    target = TARGET / source.relative_to(FROZEN)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    restored.append(source.relative_to(FROZEN).as_posix())

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
guard = json.loads((BASE / 'source-before.json').read_text())
checks = [{'path': n, 'expected': h, 'actual': sha(TARGET / n)} for n, h in guard.items()]
assert all(row['expected'] == row['actual'] for row in checks)
recipe = json.loads((TARGET / 'tools/comfyui/recipes/guest_hong.json').read_text())
assert not recipe.get('source_rebuilds'), recipe.get('source_rebuilds')
assert not (TARGET / 'art_src/characters/guest_hong/overrides').exists()
assert not (TARGET / 'art_src/characters/guest_hong_repairs_20261118').exists()
report = {'runtime': str(TARGET), 'source_runtime': str(SOURCE), 'independent_regular_copy': True,
          'copied_files': files, 'copied_bytes': size, 'restored_files': restored,
          'original_hong_all_sha_match': True, 'original_hong_checks': checks,
          'gpu_started': False, 'requires_import_before_render': True,
          'note': '洪先生採凍結原main；其他角色及舞台沿獨立runtime。可由主代理複製同版S20探針/場景後匯入；不得當作整份舊main快照。'}
(BASE / 's20-before-runtime-ready.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({k: report[k] for k in ['runtime','copied_files','copied_bytes','original_hong_all_sha_match','gpu_started']}, ensure_ascii=False), flush=True)
