"""以完全相同探針比較原版洪先生；所有 Godot 工作共用鎖。"""
from pathlib import Path
import hashlib, json, os, shutil, subprocess

BASE = Path(__file__).resolve().parent
PROJECT = BASE / 's20-before-runtime'
OUT = BASE / 's20-before-proof'
PARENT = BASE / 'root-integration-v7/native-s20'
SHARED = Path('D:/NestEggVerification/ne218-baseline-20261117')
ROOT = Path('C:/Users/stanl/Github/Nest-Egg')
OUT.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
def scenes(p):
    value = json.loads(p.read_text(encoding='utf-8'))['scenes']
    return value if isinstance(value, dict) else {v['id']:v for v in value}

story = Path('data/story/ch2_heron.json')
before_scenes, current_scenes = scenes(PROJECT / story), scenes(SHARED / story)
ids = ['ch2_t_s20_letter','ch2_t_s20_story','ch2_t_s20_done']
scene_checks = []
for scene_id in ids:
    a, b = before_scenes[scene_id], current_scenes[scene_id]
    assert a == b, scene_id + ': S20 完整場景 dict 不同'
    scene_checks.append({'id':scene_id, 'complete_dict_equal':True,
                         'canonical_sha256':hashlib.sha256(canonical(a).encode()).hexdigest(), 'scene':a})
(OUT / 's20-scene-dict-proof.json').write_text(json.dumps({'checks':scene_checks,
    'note':'僅 S20 三場完整 dict 相同；本對照環境不宣稱包含當前 S08 來源改動。'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['ne267_hong_scene.gd','ne267_hong_scene.tscn']:
    target = PROJECT / 'work' / name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(PARENT / name, target)
    shutil.copyfile(PARENT / name, OUT / name)
    assert sha(target) == sha(PARENT / name)

guard = json.loads((BASE / 'source-before.json').read_text())
assert all(sha(PROJECT / n) == h for n,h in guard.items())
core = json.loads((BASE / 'v7-main-core-proof.json').read_text())
core_checks=[]
for row in core['checks']:
    n=row['path']; actual=sha(PROJECT/n)
    assert actual == row['private_sha256'], n
    core_checks.append({'path':n,'sha256':actual})
env=os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:
    env[key]=str(OUT/'profile'/key)
prefix=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-B',str(ROOT/'tools/comfyui/gpu_lock.py'),'--',
        'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(PROJECT)]
def run(label,cmd):
    folder=OUT/label;folder.mkdir()
    (folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with (folder/'raw.log').open('wb') as log:
        process=subprocess.run(cmd,cwd=PROJECT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    raw=(folder/'raw.log').read_bytes()
    result={'exit':process.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),
            'errors':[line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line],
            'original_hong_held':all(sha(PROJECT/n)==h for n,h in guard.items())}
    (folder/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    assert result['script_errors']==0 and not result['errors'] and result['original_hong_held'],result
    return result
import_result=run('import',prefix+['--headless','--editor','--quit'])
assert import_result['exit']==0
command=json.loads((PARENT/'command.json').read_text())
command[command.index('--path')+1]=str(PROJECT)
command[-1]='--out='+str(OUT/'native')
native=run('native',command)
assert native['exit'] in [0,1]
before=json.loads((OUT/'native/scenes.json').read_text());after=json.loads((PARENT/'scenes.json').read_text())
def metrics(data):
    result={}
    for scene in data['scenes']:
        for snapshot in scene['snapshots']:
            key=scene['id']+'/'+snapshot['pose']
            result[key]={'seat_delta':snapshot['seat'].get('delta'),
                         'feet':{v['part']:v['delta_stage_pixels'] for v in snapshot['feet']}}
    return result
bm,am=metrics(before),metrics(after)
comparison={'original_hong_held':True,'probe_bytes_held':True,'core26_held':core_checks,
    'complete_scene_dicts_held':True,'import':import_result,'native':native,
    'before_failures':before['failures'],'after_failures':after['failures'],
    'before_metrics':bm,'after_metrics':am,
    'note':'相同自然時間探針，未固定每次採樣相位；支撐誤差可因呼吸相位不同而有小幅差異。門檻始終 1px，任何既存失敗仍保留。'}
(OUT/'comparison.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(comparison,ensure_ascii=False),flush=True)
