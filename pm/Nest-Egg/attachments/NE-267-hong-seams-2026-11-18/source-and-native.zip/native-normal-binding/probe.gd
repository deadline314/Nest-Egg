extends Node2D
func _ready() -> void:
	call_deferred("_verify")
func _verify() -> void:
	var rig := CharacterRig.new()
	add_child(rig)
	if not rig.setup("guest_hong", "npc"):
		get_tree().quit(2)
		return
	var found := 0
	for part in rig._parts:
		if str(part.name) not in ["torso", "arm_front_upper", "arm_back_upper", "arm_front_lower", "arm_back_lower"]:
			continue
		var texture = part.texture
		if not texture is CanvasTexture or texture.normal_texture == null:
			push_error("洪先生修補件缺少實際CanvasTexture normal通道")
			get_tree().quit(3)
			return
		var normal := texture.normal_texture as Texture2D
		var key := "torso"
		var size := Vector2(212,336)
		if str(part.name) in ["arm_front_upper", "arm_back_upper"]:
			key = "arm_upper"
			size = Vector2(105,215)
		elif str(part.name) in ["arm_front_lower", "arm_back_lower"]:
			key = "arm_lower"
			size = Vector2(97,186)
		var expected := "res://art/characters/guest_hong/parts/%s_n.png" % key
		if normal.resource_path != expected or normal.get_size() != size:
			push_error("洪先生修補件normal掛載或畫布不同")
			get_tree().quit(4)
			return
		print(JSON.stringify({"part":str(part.name),"canvas_texture":true,"normal_path":normal.resource_path,"normal_size":[normal.get_width(),normal.get_height()],"normal_source_sha256":FileAccess.get_sha256(expected),"diffuse_source_sha256":FileAccess.get_sha256("res://art/characters/guest_hong/parts/%s.png" % key)}))
		found += 1
	if found != 5:
		push_error("未找到洪先生修補件")
	rig.queue_free()
	get_tree().quit(0 if found == 5 else 5)
