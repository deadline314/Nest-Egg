# NE-267 洪先生三片合併 V7 凍結交接

此17檔單位可正式整合：原main 73,920 keys，811→32，修復779、保留32、零新增。尚不是整角色、S20實景、真人或整票驗收；32及骨盆13source px警告不豁免，後續另候選，不疊入本包。

## 採用與before

只採用本 `adoption/`，不要再疊V2九檔或V5十三檔。17個path唯一：6個遊戲PNG、1份recipe、同一來源目錄10檔。只有一個hook `art_src/characters/guest_hong_repairs_20261118/rebuild.py`，schema2同時登記torso/arm_upper/arm_lower三片批准來源。

- 遊戲只換torso/torso_n、arm_upper/arm_upper_n、arm_lower/arm_lower_n。其餘6件diffuse/normal、角色/rig/motion/頭像保持。
- 來源10檔：`.gdignore`、3張批准PNG、neck mask、upper/lower兩份座標JSON、provenance、rebuild、self_check。
- `overrides/refined/`三個PNG由hook發布，不重複stage；不複製fixture/runtime/cache。
- 不改generic工具、spec、骨架、動作、checker、門檻、分類或known failure。

`adoption-manifest.json`及`adoption-changes-only.json`保存差異。before逐檔與固定origin/main `6ddf32b5f5a188914cd008af9904286f29718067` 核對；`before_sha256`是原main實體工作目錄原bytes，另列不可變Git物件SHA及canonical SHA。只有.py/.json的CRLF→LF可正規化，其他文字差異拒收；PNG始終原bytes。這避免把未提交候選誤當main，也避免CRLF重複誤拒。

目前main沒有Hong overrides。若曾先執行V5 hook，舊已批准upper衍生檔會與本版不同；見 `derived-output-upgrade.json`，只可由主代理在舊SHA精確相符時封存該衍生檔再重建。未知bytes保留拒收，callback不自動覆寫不同輸出。

## 三片來源與所有權

原RGBA `4261d3d92d389639f49cfc864cc46c7a9dec6418b66a3ca6d79b48ee6f3b25d5` 保持，35歲成年港工、短髮鬍渣、服裝與臉不改，未新生成整人。

- torso：256個同座標原RGBA頸部皮膚，bbox `[458,159,517,173]`；排除髮緣。原頭/身來源只是相接，點頭後取樣不同而露孔；補足需要的重疊。仍212×336、pivot `(109.55,311.79)`。
- arm_upper：172個同一上臂原材料映射補點。123個袖口取原(480,528)，RGBA(69,80,96,253)；49個肩端/內側取原(480,303)/(495,450)。不是把原圖同座標的衣身藍料拖到手臂。仍105×215、pivot `(49.41,34.86)`。
- arm_lower：35個下袖口補點，bbox `[492,536,497,546]`，取同一下臂原(480,540)袖料RGBA(73,79,83,253)。仍97×186、pivot `(47.91,9.79)`。

三片原opaque與補點以外RGBA逐像素保持，affine/取樣格不變；局部重疊輪廓會改，不宣稱所有外輪廓不變。座標JSON每項明列來源/目標/所屬件；來源必須屬於該件原opaque材料。沒有新髮片、黑色條帶、衣身拖臂、袖條凸塊或新肢體。

批准PNG原bytes SHA：torso `2aa535d34065311224fa84086c82ba7faeb2c9783c65653684df195c26b203f5`；upper `3fdde155238786a02311ec15af99bf29153f0fd1b5aa068044497f061b77823d`；lower `e9c9f5bdc36eaeb0e83e4b942ca018f2f79bddd589854e7abeb59b94ce867497`。

## 完整原生逐key

真S20 seat_sag0.45，14個適用接點、左右、zoom1/3.7、120格；Forward+ Vulkan、RX9070XT、Godot4.7.2。所有Godot/匯入/Normal經共享GPU鎖，runtime普通檔案獨立副本，四項profile皆私有。

| 組別 | keys | 原main失敗 | V7失敗 | 修復 | 新增 |
|---|---:|---:|---:|---:|---:|
| 站/坐/坐談/坐聽/揮手 |33600|231|0|231|0|
| 坐下/站起 |13440|200|32|168|0|
| 靠牆 |6720|0|0|0|0|
| 蹲 |6720|90|0|90|0|
| 攪拌 |6720|94|0|94|0|
| 敲擊 |6720|196|0|196|0|
| 合計 |73920|811|32|779|0|

`joint-comparison-73920.json`、`fixed-keys-779.json`、`retained-failures-32.json`保存原始路徑/完整差集。sample keyset完全一致。32為knee_front24/knee_back4/hip_front4，components/hole/enclosed/loose/center五項metrics也與原main完全一致，見空的 `retained-metrics-diff.json`。

逐階保護：V2先修721；V5相對V2再修52；V6相對V5再修2腕；V7相對V6再修2肩+2肘。每階都完整73,920且零新key，沒有退化先前修復。原程序exit0/0SCRIPT/ERROR；V7五組checker0，只有坐站保留32的checker仍1。舊Commit-5的109真縫/390邊缺是歷史拒收，不將工具/坐深差異假稱修復。

## 全色與normal實看/實掛

`../v7-upper-underlap/visual/`含16張新候選原生PNG及16張原main凍結前圖。前圖逐bytes複製既有真實運行，不重新取樣/編碼，也不冒稱本次重跑；每張origin/command/raw log與SHA保存在 `frozen-before-copies.json`。來源同版本已核對，`../v7-main-core-proof.json`另核對26個相關rig/定義/shader/工具與目前main完全相同。

8張1280×772、1:1 contact page全部實看：NPC兩頁×左右×明暗，加坐下/站起兩方向完整八時間點。分頁保留原八份模擬和時間，只排整名actor；兩頁涵蓋全部，手腳不被viewport裁掉。主代理亦獨立實看同8頁，回報未見新增袖條/肢體/材料凸塊，原骨盆量體仍保留。這不代稱真人或S20舞台批准。

`../v7-upper-underlap/normal-binding/result.json`建立正式CharacterRig，實際核對torso及近遠上/下臂5件CanvasTexture normal通道、路徑/尺寸/來源SHA，全部exit0。三種normal由既有NormalMapMaker產生：torso `3da756a6d86ed2562a8440e7b561a4a5eaa218f617c74dbf48a4a472c95d8626`；upper `47d69de4003e2d28ebda144915e8c29ecc5e86b8456272d488212ce52949c124`；lower `1aa0be065f200df85cc90c1eec2d1bd8b841b917e70ea9b6aedeb380be850ac7`。其他6件normal原bytes保持。

## 最終CPU與故障拒收

`cpu-proof.json`包含最終程式實際自檢、callback、11項完整重切command/stdout/exit。三片source與runtime diffuse皆符合批准像素/原bytes；其他6張diffuse與main原bytes相同，character/rig與main內容相同，正常重跑三輸出mtime保持。

14個輸入版本守衛；PNG原bytes、.py/.json只LFcanonical。neck mask raw SHA、兩份映射canonical SHA、172/35個唯一整數補點、畫布邊界、同件材料來源與原opaque保持皆驗證。RGBA重建逐像素核對批准PNG後發布固定原始bytes，不呼叫PNG encoder；自檢禁止encoder仍成功。

錯來源、損毀任一批准PNG、mask/任一映射/spec內容變更皆拒收；LF/CRLF兩種都過。先核對全部既有輸出，最後一片不同時不先發布前兩片。另實測後置 `overrides/arm_upper.png`與未登記 `overrides/refined/head.png`會被來源優先序守衛拒收，不讓舊/外來覆寫遮掉批准組裝，也不部分發布。這是本包最後增加並測過的守衛，不改generic工具。

採用後用既有Python執行來源目錄 `self_check.py --scratch D:/NestEggVerification/evidence-20261117/ne267-hong-20261118`；同目錄rebuild由既有pipeline呼叫。

## 保留與下一步

V2及V5凍結包不改。V1髮緣、V3缺同列材料、V4黑摺線條帶皆已拒收且留存；前兩種probe/文書產生器語法錯誤及其拒收紀錄保留，沒有改成成功。Sprite UV定位補了畫布界限，舊無界版另存；不改PNG/checker/分類。trace原before2400張及V2 remaining2160張逐張A/A原bytes一致。

main/root/shared/他人runtime/服務未改，未commit/push。來源包至此凍結；正式整合測試、S20實景、票務與Git由主代理交付。後續32膝髖/骨盆候選只在新私有目錄試驗，不改本包。
