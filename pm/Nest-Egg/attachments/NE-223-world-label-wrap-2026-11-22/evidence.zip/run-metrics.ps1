param([Parameter(Mandatory)][string]$Label,
      [string]$Resolution='1280x720',
      [double]$TextScale=1.0,[string]$Font="smooth")
$ErrorActionPreference='Stop'
$e=$PSScriptRoot.Replace('\','/')
$d='D:/NestEggVerification/ne218-baseline-20261117'
$out="$e/$Label"
New-Item -ItemType Directory -Path "$out/profile" | Out-Null
$env:APPDATA="$out/profile"
$env:LOCALAPPDATA=$env:APPDATA
$engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$py='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
$scale=$TextScale.ToString([System.Globalization.CultureInfo]::InvariantCulture)
& $py -B "$d/tools/comfyui/gpu_lock.py" -- $engine --path $d --rendering-method forward_plus --rendering-driver vulkan --resolution $Resolution --fixed-fps 60 --audio-driver Dummy --quit-after 1500 "$e/probe-metrics.tscn" -- "--out=$out" "--text-scale=$scale" "--font=$Font" *> "$out/raw.log"
$code=$LASTEXITCODE
Set-Content -LiteralPath "$out/exit.txt" -Value $code
Get-Content "$out/raw.log" -Tail 20
exit $code
