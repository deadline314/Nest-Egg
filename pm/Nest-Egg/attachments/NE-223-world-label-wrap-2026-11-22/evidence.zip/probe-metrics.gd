extends "res://tests/smoke_test.gd"

var _out := ""


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://world_label_wrap_probe.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--font="):
			Settings.set_ui_font(arg.trim_prefix("--font="))
		elif arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
	super._ready()


func _run() -> void:
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	for path: String in ["ch1_pawnshop", "ch2_harbor_street", "ch3_plaza"]:
		GameState.start_new_run(GameState.difficulties[1])
		var level := Level.new()
		level.process_mode = Node.PROCESS_MODE_PAUSABLE
		level.configure(load("res://data/levels/" + path + ".tres") as LevelData)
		add_child(level)
		await _frames(60)
		var menu := level._pause_menu
		await _send_key(KEY_M)
		await _frames(10)
		var map := menu._navigation
		_check(is_instance_valid(map) and map._page == "region" and get_tree().paused, path + " opens normal map")
		if is_instance_valid(map):
			await _send_key(KEY_E)
			await _frames(8)
			var expected := str(Story.chapter_info(level.data.chapter).get("title", ""))
			var caption := map._body.get_child(0).get_child(0).get_child(0) as Label
			_check(map._page == "world" and not expected.is_empty(), path + " reaches real world page")
			var scoped := not map.maps.areas.is_empty()
			for area: Dictionary in map.maps.areas.values():
				scoped = scoped and area["data"].chapter == level.data.chapter
			_check(scoped and map.maps.areas.size() == map._canvas._markers.size(), path + " contains only the actual chapter zones")
			print("WORLD_CHAPTER ", path, " caption=", caption.text, " expected=", expected, " areas=", map.maps.areas.size())
			_check(caption.text == expected, path + " world label names its sourced chapter")
			var width := caption.get_theme_font(&"font").get_string_size(caption.text, HORIZONTAL_ALIGNMENT_LEFT, -1, caption.get_theme_font_size(&"font_size")).x
			_check(width <= caption.size.x, path + " chapter name fits at the selected text scale")
			_report_markers(path, map, "before")
			await _shot(path + "-baseline")
			for marker: Button in map._canvas._markers:
				if marker.autowrap_mode != TextServer.AUTOWRAP_OFF:
					marker.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			await _frames(5)
			_report_markers(path, map, "smart")
			await _shot(path + "-smart")
		menu.close()
		await _frames(4)
		level.queue_free()
		await _frames(4)
	await _finish()


func _report_markers(path: String, screen: QuestMapScreen, mode: String) -> void:
	var rows: Array[Dictionary] = []
	var server := TextServerManager.get_primary_interface()
	for marker: Button in screen._canvas._markers:
		var font := marker.get_theme_font(&"font")
		var font_size := marker.get_theme_font_size(&"font_size")
		var width := marker.size.x - marker.get_theme_stylebox(&"normal").get_minimum_size().x
		var line_flags := TextServer.BREAK_MANDATORY | marker.autowrap_trim_flags
		if marker.autowrap_mode == TextServer.AUTOWRAP_WORD_SMART:
			line_flags |= TextServer.BREAK_WORD_BOUND | TextServer.BREAK_ADAPTIVE
		elif marker.autowrap_mode == TextServer.AUTOWRAP_ARBITRARY:
			line_flags |= TextServer.BREAK_GRAPHEME_BOUND
		var shaped := server.create_shaped_text()
		if not server.shaped_text_add_string(shaped, marker.text, font.get_rids(), font_size):
			server.free_rid(shaped)
			_check(false, "shapes theme text for " + marker.text)
			continue
		var cuts := server.shaped_text_get_line_breaks(shaped, width, 0, line_flags)
		var pieces: Array[String] = []
		for index in range(0, cuts.size(), 2):
			pieces.append(marker.text.substr(cuts[index], cuts[index+1]-cuts[index]).strip_edges())
		server.free_rid(shaped)
		rows.append({"name":marker.text, "pieces":pieces, "rect":[marker.position.x,marker.position.y,marker.size.x,marker.size.y],
			"tooltip":marker.tooltip_text, "wrap":int(marker.autowrap_mode),"width":width})
	print("WORLD_WRAP ", JSON.stringify({"chapter":path,"mode":mode,"rows":rows}))


func _send_key(code: Key) -> void:
	var press := InputEventKey.new()
	press.keycode = code
	press.physical_keycode = code
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _send_button(button: JoyButton) -> void:
	var press := InputEventJoypadButton.new()
	press.button_index = button
	press.pressure = 1.0
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	release.pressure = 0.0
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _shot(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join(name + ".png")) == OK, "saved " + name)