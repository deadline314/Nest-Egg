extends Node

const CAPTURE := preload("res://tools/viewport_capture.gd")
const MARKET := "res://data/levels/ch2_market.tres"
var _out := ""
var _main: Node
var _checks := 0
var _failures: Array[String] = []

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()

func _frames(count: int) -> void:
	for f in count:
		await get_tree().physics_frame

func _check(value: bool, label: String) -> void:
	_checks += 1
	if not value:
		_failures.append(label)

func _run() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Story.auto_skip = true
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_out.path_join("fixture.json")))
	add_child(_main)
	await _frames(25)
	_main.call("_on_start_requested", GameState.difficulties[1])
	await _frames(90)
	_main.call("_on_area_requested", MARKET)
	var level: Level
	for i in 240:
		await _frames(1)
		level = _main.get("_screen") as Level
		if level != null and level.data.resource_path == MARKET and not GameplayLock.is_locked():
			break
	_check(level != null and level.data.resource_path == MARKET, "the original market is loaded by Main")
	var vendor: NpcActor
	for node in level._entities.get_children():
		if node is NpcActor and node.data.id == &"ch2_hawker":
			vendor = node
	_check(vendor != null and vendor.data.rig_id == "ch2_hawker" and vendor.data.loop == &"sort_gear", "the authored market vendor stands at her stall using her own rig and work animation")
	if vendor == null:
		get_tree().quit(1)
		return
	level.player.global_position = vendor.global_position + Vector2(-30.0, 0.0)
	level.player.velocity = Vector2.ZERO
	Story.auto_skip = false
	await _frames(75)
	await RenderingServer.frame_post_draw
	_check(CAPTURE.image(get_viewport()).save_png(_out.path_join("vendor-standing.png")) == OK, "original market view is captured")
	var scene := Story.resolve_dispatch(vendor.data.talks[0].scene)
	var done: Array[bool] = [false]
	var script := func() -> void:
		await vendor._talk()
		done[0] = true
	script.call()
	for i in 360:
		await _frames(1)
		if Story._layer._portrait.visible and Story._layer._portrait.texture != null and Story._layer._portrait.texture.resource_path == "res://art/portraits/ch2_hawker.png" and Story._layer._name.text == "小販":
			break
	_check(Story._seen.has(scene) and Story._layer._portrait.texture != null and Story._layer._portrait.texture.resource_path == "res://art/portraits/ch2_hawker.png", "the original NPC talk displays her own portrait")
	await _frames(45)
	await RenderingServer.frame_post_draw
	_check(CAPTURE.image(get_viewport()).save_png(_out.path_join("vendor-speaking.png")) == OK, "original market dialogue is captured")
	Story.skip_cinematic()
	await _frames(45)
	FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify({"checks":_checks,"failures":_failures,"scene":scene,
		"adapter":RenderingServer.get_video_adapter_name()}, "\t"))
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures.is_empty() else 1)
