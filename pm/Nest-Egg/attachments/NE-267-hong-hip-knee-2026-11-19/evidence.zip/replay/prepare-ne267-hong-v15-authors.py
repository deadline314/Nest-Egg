from pathlib import Path
import hashlib,json,shutil,subprocess,sys
from PIL import Image

root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118')
variant=base/'v15-hip-and-knee'
assert json.loads((variant/'native/passed-regression.json').read_text())['after']==0
out=variant/'author-release'
out.mkdir()
module='art_src/characters/guest_hong_repairs_20261118'
folder=out/module
shutil.copytree(root/module,folder)
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
sha=lambda data:hashlib.sha256(data).hexdigest()
copy=lambda src,dst:(dst.parent.mkdir(parents=True,exist_ok=True),shutil.copyfile(src,dst))
prov=read(folder/'provenance.json')
assert prov['schema_version']==2 and set(prov['approved_outputs'])=={'torso','arm_lower','arm_upper'}
prov['schema_version']=3
prov['kind']='NE-267 洪先生頸部、袖口、髖部與膝部的局部來源修補'
prov['known_scope']='14 接點、雙面向與雙倍率 73,920 筆檢查，累計 811→0 失敗。姿態與舞台條件各由原生檢視確認。'
prov['publication']='先逐像素核對所有批准來源，再發布原始 PNG bytes。全部既有輸出通過才開始寫入，重跑相同輸出保留 mtime。'
paths=[]
for part in ('leg_upper','pelvis'):
    part_claim=read(variant/f'{part}-ownership.json')
    claims=part_claim['added']
    if part=='leg_upper':
        old=read(base/'v11-upper-convex-knee/coordinate-claims.json')
        assert len(old)==658
        claims=old+claims
    normalized=[{'part':part,'to':row['to'],'from':row['from']} for row in claims]
    assert len(normalized)==len({tuple(row['to']) for row in normalized})
    coord_name=f'{part}-coordinate-claims.json'
    coord_data=(json.dumps(normalized,ensure_ascii=False,indent=1)+'\n').encode()
    (folder/coord_name).write_bytes(coord_data)
    prov['coordinate_claims'][part]={'file':coord_name,'canonical_sha256':sha(coord_data),'pixels':len(normalized)}
    approved=f'approved_{part}.png'
    copy(variant/approved,folder/approved)
    diffuse=variant/f'{part}.png'
    normal=variant/f'{part}_n.png'
    prov['approved_outputs'][part]=approved
    prov['outputs'][part]=sha((folder/approved).read_bytes())
    with Image.open(diffuse) as image:
        prov['diffuse_rgba_sha256'][part]=sha(image.convert('RGBA').tobytes())
        prov['native_size'][part]=list(image.size)
    prov['diffuse_png_sha256'][part]=sha(diffuse.read_bytes())
    prov['normal_png_sha256'][part]=sha(normal.read_bytes())
    prov['source_changed_pixels'][part]=len(normalized)
    prov['source_claim'][part]=(f'{len(normalized)} 個補點取自同一褲料的原精修分件。膝側連續重疊與髖側修補保留既有不透明像素。'
        if part=='leg_upper' else f'{len(normalized)} 個補點使用同件髖部褲料，維持坐下時與大腿的連續接觸。')
    paths.extend([module+'/'+name for name in (coord_name,approved)])
    for source in (diffuse,normal):
        filename='art/characters/guest_hong/parts/'+source.name
        copy(source,out/filename)
        paths.append(filename)
(folder/'provenance.json').write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=folder/'rebuild.py'
s=p.read_text(encoding='utf-8')
changes={
 '由固定原圖與袖料座標映射，重建洪先生頸部及上下袖口批准來源。':'由固定原圖與同部件座標映射，重建洪先生五片批准來源。',
 "record.get('schema_version')!=2 or set(record['approved_outputs'])!={'torso','arm_upper','arm_lower'}":"record.get('schema_version')!=3 or set(record['approved_outputs'])!={'torso','arm_upper','arm_lower','leg_upper','pelvis'}",
 '需要schema2與三片批准來源':'需要 schema 3 與五片批准來源',
 "if set(configs)!={'arm_upper','arm_lower'}:":"if set(configs)!=set(record['approved_outputs'])-{'torso'}:",
 '洪先生映射登記須包含arm_upper及arm_lower':'洪先生各映射分件須與批准內容吻合',
 '袖料映射':'分件映射',
 '袖料座標映射':'分件座標映射',
 'results[part][y,x]=base[sy,sx]':'results[part][y,x]=originals[part][sy,sx]',
 '洪先生來源：頸部256同座標原RGBA、上臂172及下臂35同件材料映射；批准PNG原bytes；畫布/支點/其他件保持；相同輸出不改寫':'洪先生五片來源已核對原圖、同件材料、批准 PNG 與位置。'
}
for old,new in changes.items():
    assert old in s,old
    s=s.replace(old,new)
p.write_text(s,encoding='utf-8')
p=folder/'self_check.py'
s=p.read_text(encoding='utf-8').replace('三片','五片').replace('袖料座標映射','分件座標映射')
p.write_text(s,encoding='utf-8')
paths += [module+'/'+name for name in ('provenance.json','rebuild.py','self_check.py')]
old_checks={'rebuild':(root/module/'rebuild.py').read_bytes(),'self_check':(root/module/'self_check.py').read_bytes()}
for name in prov['inputs']:
    copy(root/name,out/name)
proof=variant/'author-proof'
proof.mkdir()
cmd=[sys.executable,'-B','-X','utf8',str(folder/'self_check.py'),'--scratch',str(proof)]
(proof/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (proof/'raw.log').open('wb') as log:
    process=subprocess.run(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=120)
print((proof/'raw.log').read_text(encoding='utf-8')[-1600:],flush=True)
assert process.returncode==0
assert all((root/module/(name+'.py')).read_bytes()==data for name,data in old_checks.items())
(out/'delivery.json').write_text(json.dumps({name:sha((out/name).read_bytes()) for name in paths},indent=2)+'\n')
print({name:prov['source_changed_pixels'][name] for name in ('leg_upper','pelvis')},len(paths))
