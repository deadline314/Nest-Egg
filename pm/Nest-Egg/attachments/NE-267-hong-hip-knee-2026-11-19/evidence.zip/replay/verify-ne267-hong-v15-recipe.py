from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
root=Path.cwd()
evidence=Path('D:/NestEggVerification/evidence-20261117')
base=evidence/'ne267-hong-20261118/v15-hip-and-knee'
project=evidence/'ne267-source-delivery-20261118/s19-runtime'
out=base/'recipe-proof'
out.mkdir()
module='art_src/characters/guest_hong_repairs_20261118'
author=base/'author-release'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=read(author/'delivery.json')
recipe='tools/comfyui/recipes/guest_hong.json'
prov=read(author/module/'provenance.json')
assert sha(root/recipe)==sha(project/recipe)
for name in prov['inputs']:
    path=project/name
    if not path.is_file():
        path.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(root/name,path)
    assert (path.read_bytes().replace(b'\r\n',b'\n') if path.suffix in {'.json','.py'} else path.read_bytes())==(root/name).read_bytes().replace(b'\r\n',b'\n') if path.suffix in {'.json','.py'} else path.read_bytes()==(root/name).read_bytes(),name
path_list=list((root/'art_src/characters/guest_hong/06_parts').glob('*.png'))
assert path_list
for path in path_list:
    destination=project/path.relative_to(root)
    if not destination.exists():
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,destination)
    assert destination.read_bytes()==path.read_bytes()
for name,digest in manifest.items():
    assert sha(author/name)==digest
    if name.startswith(module):
        p=project/name
        if p.exists():
            assert p.read_bytes()==(root/name).read_bytes(),name
        p.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(author/name,p)
    else:
        assert sha(project/name)==sha(root/name),name
runtimes=[f.relative_to(root).as_posix() for f in (root/'art/characters/guest_hong').rglob('*') if f.suffix=='.png']
runtimes+=['art/characters/guest_hong/character.json','art/rigs/guest_hong.json','art/motion/guest_hong.json']
expected={name:manifest[name] if name in manifest else sha(root/name) for name in runtimes}
assert all(sha(project/name)==sha(root/name) for name in runtimes)
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(out/'profile'/key)
env.update(GODOT=engine,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
cmd=[sys.executable,'-B','-X','utf8','tools/comfyui/build_character.py','--recipe',recipe,'--from','textures','--to','normals']
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
    proc=subprocess.run(cmd,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=320)
raw=(out/'raw.log').read_text(encoding='utf-8')
changed=[name for name,digest in expected.items() if sha(project/name)!=digest]
assert proc.returncode==0 and 'ERROR:' not in raw and not changed,(changed,raw[-2400:])
overrides={}
for name,digest in prov['outputs'].items():
    p=f'art_src/characters/guest_hong/overrides/refined/{name}.png'
    assert sha(project/p)==digest
    overrides[p]=digest
(out/'result.json').write_text(json.dumps({'exit':0,'matching_runtime_files':expected,'matching_approved_overrides':overrides},indent=2)+'\n')
print('Verified',len(expected),'runtime files;',len(overrides),'approved exact source PNGs',flush=True)
