from pathlib import Path
import hashlib,json,os,re,subprocess,sys

root=Path.cwd()
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
evidence=Path('D:/NestEggVerification/evidence-20261117')
base=evidence/'ne267-hong-20261118/v15-hip-and-knee'
prior=evidence/'st15-runtime-locale-20261119/integration'
output=base/'integration'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=read(prior/'publish/result.json')['commit']
previous=read(prior/'published-source.json')
assert subprocess.check_output(['git','branch','--show-current'],cwd=root).strip()==b'codex/ticket-work-20261119-ne267-seams'
assert all(subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree).decode().strip()==expected for tree in (root,shared))
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root).strip()
assert all(sha(shared/path)==digest for path,digest in previous.items())
report=read(base/'native/passed-regression.json')
assert report['samples']==73920 and report['before']==32 and report['after']==report['new']==0
preview=read(base/'native-review/compare.json')
assert all(not row['scene_failures'] and row['captures']==17 and row['contact_count']==97 and row['visual_cases']==8 for row in preview.values())
assert '洪先生合併來源自檢通過' in (base/'author-proof-v2/raw.log').read_text(encoding='utf-8')
recipe=read(base/'recipe-proof/result.json')
assert recipe['exit']==0 and len(recipe['matching_approved_overrides'])==5
catalog=base/'author-release'
paths=read(catalog/'delivery.json')
assert len(paths)==11 and all(sha(catalog/name)==digest for name,digest in paths.items())
for name in paths:
    if name in previous:
        assert sha(root/name)==sha(shared/name)==previous[name]
    else:
        assert not (root/name).exists() and not (shared/name).exists(),name
runtime=recipe['matching_runtime_files']
assert all(preview['after']['source'][name]==digest for name,digest in paths.items() if name.startswith('art/characters/'))
assert all(sha(root/name)==sha(shared/name)==digest for name,digest in runtime.items() if name not in paths)
output.mkdir()
for project in (root,shared):
    for name in paths:
        (project/name).write_bytes((catalog/name).read_bytes())
source=previous|paths
assert all(sha(shared/name)==digest for name,digest in source.items())
(output/'source.json').write_text(json.dumps(source,indent=2)+'\n')
(output/'paths.json').write_text(json.dumps(list(paths),indent=2)+'\n')
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'

def run(label,args):
    location=output/label
    location.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(location/'profile'/key)
    env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',GODOT=engine,SHARDS='8',LOG_DIR=str(location/'shards'))
    (location/'command.json').write_text(json.dumps(args,indent=2)+'\n')
    with (location/'raw.log').open('wb') as log:
        proc=subprocess.run(args,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=2100)
    raw=(location/'raw.log').read_bytes()
    result={'exit':proc.returncode,'errors':[line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line],
            'source_held':all(sha(shared/name)==digest for name,digest in source.items()) and all(sha(root/name)==source[name] for name in paths)}
    (location/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(label,result,raw.decode(errors='replace')[-1100:],flush=True)
    assert result=={'exit':0,'errors':[],'source_held':True}
    return result

run('import',[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',engine,'--headless','--editor','--import'])
run('assets',[sys.executable,'-B','-X','utf8','tools/assets/check_assets.py'])
selector=['C:/Program Files/Git/bin/bash.exe','-c',f'python3() {{ python "$@"; }}; export -f python3; tools/run_tests_changed.sh {expected}']
result=run('official',selector)
(output/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
