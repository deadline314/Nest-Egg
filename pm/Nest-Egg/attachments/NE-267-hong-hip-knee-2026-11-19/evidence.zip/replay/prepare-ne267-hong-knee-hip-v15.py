from pathlib import Path
import json,sys
import numpy as np
from PIL import Image,ImageDraw
from scipy.spatial import cKDTree

root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118')
original=base/'baseline-source'
out=base/'v15-hip-and-knee'
out.mkdir()
sys.path.insert(0,str(root/'tools/comfyui'))
from cut_layers import part_transform,render_part
spec=json.loads((original/'tools/comfyui/specs/guest_hong_side.json').read_text())
k=spec['tex_px_per_wp']/spec['illustration_px_per_wp']
joints={name:np.array(value,float)*k for name,value in spec['joints'].items()}
source=original/'art_src/characters/guest_hong/07_refined'
config={
    'leg_upper': {'points':[(384,1041),(391,1041),(392,1054),(386,1059),(382,1057),(382,1047)],'size':(343,202,4),'box':(376,1034,404,1069)},
    'pelvis': {'points':[(626,729),(641,727),(646,731),(645,735),(639,736),(630,735),(625,733)],'size':(189,219,4),'box':(615,716,650,743)},
}
raw=np.array(Image.open(original/'art_src/characters/guest_hong/base_rgba.png').convert('RGBA'))
records=[]
for part,opts in config.items():
    normal=np.array(Image.open(source/(part+'.png')).convert('RGBA'))
    pixels=np.array(Image.open(base/'v11-upper-convex-knee/approved_leg_upper.png').convert('RGBA')) if part=='leg_upper' else normal.copy()
    selection=Image.new('L',(1024,1536))
    draw=ImageDraw.Draw(selection)
    draw.polygon(opts['points'],fill=255)
    if part=='leg_upper':
        draw.polygon([(626,770),(630,771),(634,773),(635,776),(633,780),(629,783),(626,782)],fill=255)
    active=(np.array(selection)>0)&(pixels[:,:,3]<128)
    targets=np.argwhere(active)
    x0,y0,x1,y1=opts['box']
    candidates=np.argwhere((normal[y0:y1,x0:x1,3]>=230)&(raw[y0:y1,x0:x1,3]>=230))+[y0,x0]
    if part=='leg_upper':
        sources=np.tile([1010,410],(len(targets),1))
        hip_region=targets[:,0]<900
        local=normal[766:786,614:635,3]>=230
        local &= raw[766:786,614:635,3]>=230
        eligible=np.argwhere(local)+[766,614]
        distances,matches=cKDTree(eligible).query(targets[hip_region])
        assert distances.max()<12
        sources[hip_region]=eligible[matches]
    else:
        distances,matches=cKDTree(candidates).query(targets)
        assert distances.max()<8
        sources=candidates[matches]
    assert all(normal[y,x,3]>=230 and raw[y,x,3]>=230 for y,x in sources)
    values=normal[sources[:,0],sources[:,1]].copy()
    pixels[active]=values
    assert np.array_equal(normal[normal[:,:,3]>=128],pixels[normal[:,:,3]>=128])
    transform=part_transform(Image.fromarray(normal),spec['parts'][part],joints,k)
    edited=part_transform(Image.fromarray(pixels),spec['parts'][part],joints,k)
    assert all(np.array_equal(a,b) for a,b in zip(transform,edited)),part
    texture=render_part(Image.fromarray(pixels),edited,k)
    assert texture.shape==opts['size']
    Image.fromarray(pixels).save(out/(f'approved_{part}.png'))
    Image.fromarray(texture).save(out/(part+'.png'))
    claims=[{'to':[int(x),int(y)],'from':[int(sx),int(sy)]} for (y,x),(sy,sx) in zip(targets,sources)]
    more=(base/'v11-upper-convex-knee/coordinate-claims.json') if part=='leg_upper' else None
    (out/(part+'-ownership.json')).write_text(json.dumps({'part':part,'added':claims,'prior_mask':str(more) if more else None},indent=2)+'\n')
    records.append({'part':part,'local_additions':len(claims),'old_opaque_held':True,'new_sampling_transform':False})
(out/'source-result.json').write_text(json.dumps({'parts':list(config),'records':records},indent=2)+'\n')
print(records)
