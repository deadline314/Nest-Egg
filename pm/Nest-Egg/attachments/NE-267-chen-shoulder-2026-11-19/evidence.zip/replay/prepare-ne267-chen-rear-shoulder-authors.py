from pathlib import Path
import hashlib,json,shutil,subprocess,sys
from PIL import Image

root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-transitions-20261118/v20-rear-shoulder')
out=base/'author-release'
out.mkdir()
module='art_src/characters/guest_chen_torso_20261118'
folder=out/module
shutil.copytree(root/module,folder)
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
manifest=read(folder/'provenance.json')
result=read(base/'native-screen/results.json')
assert sum(r['samples'] for r in result)==28800 and sum(r['before'] for r in result)==280 and sum(r['after'] for r in result)==166 and not any(r['new'] for r in result)
assert len(read(base/'torso-claims.json'))==24
claims=folder/'shoulder-coordinate-claims.json'
shutil.copyfile(base/'torso-claims.json',claims)
shutil.copyfile(base/'approved_torso.png',folder/'approved_torso.png')
manifest['shoulder_claims_sha256']=sha(claims.read_bytes())
manifest['shoulder_claimed_pixels']=24
manifest['source_override_sha256']=sha((folder/'approved_torso.png').read_bytes())
manifest['outputs']['torso']=manifest['source_override_sha256']
manifest['diffuse_png_sha256']=sha((base/'torso.png').read_bytes())
manifest['normal_png_sha256']=sha((base/'torso_n.png').read_bytes())
with Image.open(base/'torso.png') as tex:
    manifest['diffuse_rgba_sha256']=sha(tex.convert('RGBA').tobytes())
    assert list(tex.size)==manifest['native_size']
manifest['kind']='NE-267 陳女士軀幹原圖漏切與遠側肩部的同件衣料補點'
manifest['known_scope']='六接點 28,800 個原採樣鍵，遠側肩部 114 個問題全部排除，原個別 166 筆須繼續修，新增 0。'
manifest['source_claim']+=' 遠側肩部的 24 點由原生孔位回推，取自核對後同一軀幹材質。'
(folder/'provenance.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=folder/'rebuild.py'
s=p.read_text(encoding='utf-8').replace('在既有精修後補回陳女士漏切的3009個原圖軀幹像素。','重建陳女士核對過的軀幹材質與遠側肩部補點。')
anchor='    opaque = original[:, :, 3] > 127\n'
assert s.count(anchor)==1
s=s.replace(anchor,'''    coordinates = HERE / "shoulder-coordinate-claims.json"
    if input_sha(coordinates) != record["shoulder_claims_sha256"]:
        raise ValueError("陳女士肩部座標版本不同：shoulder-coordinate-claims.json")
    claims = json.loads(coordinates.read_text(encoding="utf-8"))
    if not isinstance(claims, list) or len(claims) != record["shoulder_claimed_pixels"]:
        raise ValueError("陳女士肩部補點數量不同")
    material = result.copy()
    height, width = material.shape[:2]
    for index, claim in enumerate(claims):
        coords = [claim.get("to"), claim.get("from")] if isinstance(claim, dict) else []
        if len(coords) != 2 or any(
            not isinstance(point, list) or len(point) != 2 or any(type(point[i]) is not int for i in (0, 1))
            or not (0 <= point[0] < width and 0 <= point[1] < height)
            for point in coords
        ):
            raise ValueError(f"陳女士肩部第 {index} 筆來源座標無效")
        (x, y), (sx, sy) = coords
        if claim.get("part") != "torso" or material[sy, sx, 3] < 128 or result[y, x, 3] >= 128:
            raise ValueError(f"陳女士肩部第 {index} 筆未使用同一衣料或改到既有像素")
        result[y, x] = material[sy, sx]
'''+anchor)
s=s.replace('陳女士軀幹來源：3009原圖像素；原畫布、支點及其他零件保持；既有相同輸出不改寫','陳女士軀幹來源已核對原圖漏切、肩部補點及批准 PNG。')
p.write_text(s,encoding='utf-8')
p=folder/'self_check.py'
s=p.read_text(encoding='utf-8').replace('        assert not target.exists(), "損毀批准PNG不應發布輸出"','''        assert not target.exists(), "損毀批准PNG不應發布輸出"
        coordinates = callback / "shoulder-coordinate-claims.json"
        reject_change(coordinates, coordinates.read_bytes() + b" ", "陳女士肩部座標版本不同")
        assert not target.exists(), "錯誤肩部補點不應發布輸出"''')
p.write_text(s,encoding='utf-8')
paths=[module+'/'+name for name in ('provenance.json','rebuild.py','self_check.py','approved_torso.png','shoulder-coordinate-claims.json')]
for name in ('torso.png','torso_n.png'):
    target=f'art/characters/guest_chen/parts/{name}'
    (out/target).parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(base/name,out/target)
    paths.append(target)
for name in manifest['inputs']:
    (out/name).parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/name,out/name)
for path in (root/'tools/comfyui').glob('*.py'):
    dst=out/path.relative_to(root)
    if not dst.is_file():
        shutil.copyfile(path,dst)
proof=base/'author-proof'
proof.mkdir()
args=[sys.executable,'-B','-X','utf8',str(folder/'self_check.py'),'--scratch',str(proof)]
(proof/'command.json').write_text(json.dumps(args,indent=2)+'\n')
with (proof/'raw.log').open('wb') as log:
    p=subprocess.run(args,cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=120)
print((proof/'raw.log').read_text(encoding='utf-8')[-1700:],flush=True)
assert p.returncode==0
(out/'delivery.json').write_text(json.dumps({name:sha((out/name).read_bytes()) for name in paths},indent=2)+'\n')
