from pathlib import Path
import collections,json,sys
import numpy as np
from PIL import Image,ImageDraw
from scipy import ndimage
root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-transitions-20261118')
trace=base/'trace-retained-v17-20261119'
out=base/'v20-rear-shoulder'
out.mkdir()
rows=json.loads((trace/'source-locations.json').read_text())
sys.path.insert(0,str(root/'tools/comfyui'))
from cut_layers import part_transform,render_part
spec=json.loads((root/'tools/comfyui/specs/guest_chen_side.json').read_text())
k=spec['tex_px_per_wp']/spec['illustration_px_per_wp']
joints={name:np.array(points,float)*k for name,points in spec['joints'].items()}
needed=collections.defaultdict(list)
for case in ('arms-lean',):
    for row in rows[case]:
        owner=next((x for x in row['owners'] if x['material']=='torso'),None)
        if owner is not None:
            needed[owner['material']].append(owner)
result=[]
for name,points in needed.items():
    if name=='torso':
        path=root/'art_src/characters/guest_chen_torso_20261118/approved_torso.png'
    else:
        path=root/'art_src/characters/guest_chen/07_refined'/f'{name}.png'
    src=Image.open(path).convert('RGBA')
    arr=np.array(src)
    mask=Image.new('L',src.size)
    draw=ImageDraw.Draw(mask)
    for point in points:
        target=tuple(round(value) for value in point['point'])
        near=tuple(point['near'])
        assert point['distance']<13
        span=4 if point['distance']>4 else 2
        draw.line([near,target],fill=255,width=span)
        x,y=target
        draw.ellipse((x-span,y-span,x+span,y+span),fill=255)
    selected=(np.array(mask)>0)&(arr[:,:,3]<128)
    dist,nearest=ndimage.distance_transform_edt(arr[:,:,3]<220,return_indices=True)
    points=np.argwhere(selected)
    assert dist[selected].max()<18
    pixels=arr.copy()
    claims=[]
    for y,x in points:
        sy,sx=nearest[:,y,x]
        pixels[y,x]=arr[sy,sx]
        claims.append({'part':name,'to':[int(x),int(y)],'from':[int(sx),int(sy)]})
    edited=Image.fromarray(pixels)
    default=part_transform(src,spec['parts'][name],joints,k)
    updated=part_transform(edited,spec['parts'][name],joints,k)
    assert all(np.array_equal(a,b) for a,b in zip(default,updated)),name
    Image.fromarray(render_part(edited,updated,k)).save(out/(name+'.png'))
    edited.save(out/(f'approved_{name}.png'))
    (out/(name+'-claims.json')).write_text(json.dumps(claims,indent=2)+'\n')
    result.append({'part':name,'pixels':len(claims),'max_sourced_distance':float(dist[selected].max())})
(out/'source.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
