from pathlib import Path
from shutil import copy2
from hashlib import sha256
import json
import os
import re
import subprocess
import sys

initial=Path.cwd()
scope=Path(__file__).resolve().parent
project=Path(sys.argv[1]).resolve()
label=sys.argv[2]
parent=scope/label
parent.mkdir()
seed=initial/"work/ne97-campaign-route-20261119/native-camera-fresh-close-v1/save/slot.json"
assert seed.is_file()
sha=lambda p:sha256(p.read_bytes()).hexdigest()
tree=subprocess.check_output(["git","rev-parse","HEAD"],cwd=initial,text=True).strip()
scenarios=[(1,232.0),(-1,232.0),(1,472.0),(-1,472.0)]
if len(sys.argv)>3:
    selected={int(item) for item in sys.argv[3:]}
    scenarios=[case for index,case in enumerate(scenarios) if index in selected]
mode,lens="dash",0.0
for side, anchor in scenarios:
    name=f"{mode}-{side}-{int(anchor)}"
    folder=parent/name
    folder.mkdir()
    env=os.environ.copy()
    for key in ("APPDATA","LOCALAPPDATA","TEMP","TMP","TMPDIR","XDG_CONFIG_HOME","XDG_DATA_HOME"):
        profile=folder/key
        profile.mkdir()
        env[key]=str(profile)
    slot=folder/"slot.json"
    copy2(seed,slot)
    command=[sys.executable,"-B",str(project/"tools/comfyui/gpu_lock.py"),"--",
             "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(project),
             "--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy",
             "--fixed-fps","60","--resolution","1280x720","--quit-after","1800",str(scope/"observe.tscn"),"--",
             "--out="+str(folder),"--slot="+str(slot),"--side="+str(side),"--mode="+mode,"--lens="+str(lens),"--anchor-x="+str(anchor)]
    (folder/"command.json").write_text(json.dumps({"argv":command,"source":tree,"seed_sha256":sha(seed)},indent=2)+"\n")
    with (folder/"engine.log").open("wb") as log:
        ending=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=160)
    logs=(folder/"engine.log").read_text(encoding="utf-8",errors="replace")
    errors=[line for line in logs.splitlines() if re.search(r"^(?:SCRIPT )?ERROR:|^FAIL |Parse Error|leaked at exit",line)]
    assert ending.returncode==0 and not errors,(name,ending.returncode,logs[-5300:])
    run=json.loads((folder/"motion.json").read_bytes())
    assert run["checks_failed"]==0 and run["rows"]
    print(name,len(run["rows"]),flush=True)
