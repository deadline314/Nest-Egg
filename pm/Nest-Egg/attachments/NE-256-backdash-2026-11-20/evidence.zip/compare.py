from pathlib import Path
import json
import math
import re
import sys

base=Path(__file__).resolve().parent
stock=base/"original-v2"
candidate=base/sys.argv[1]
summary={}
fields=("root","velocity","facing","aim","state","ground","dash_time","foot","chest","hip","head","chest_rotation","hip_rotation","weapon","zoom")
read=lambda p:json.loads(p.read_bytes())
def equal(a,b):
    if isinstance(a,list):return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    if isinstance(a,dict):return a.keys()==b.keys() and all(equal(a[k],b[k]) for k in a)
    if isinstance(a,float):return math.isclose(a,b,rel_tol=0,abs_tol=1e-5)
    return a==b

def dash_summary(sequence,side):
    edge=lambda x: x if side>0 else 1280-x
    active=[row for row in sequence if row["state"]==1]
    assert len(active)==11 and active[0]["frame"]==2 and active[-1]["frame"]==12
    assert all(row["facing"]==side and row["ground"] for row in active)
    posikeys=("head_screen","root_screen","front_boot_screen","back_boot_screen")
    minimum={key:min(edge(row[key][0]) for row in active) for key in posikeys}
    step=max(abs(a["camera_center"][0]-b["camera_center"][0]) for a,b in zip(sequence,sequence[1:]))
    return {"seconds":len(active)/60,"minimum_rear_pixels":minimum,"maximum_center_step_world":step,
            "camera_center_after":sequence[-1]["camera_center"],"camera_center_before":sequence[0]["camera_center"]}

for orig in sorted(stock.iterdir()):
    before=read(orig/"motion.json")
    folder=candidate/orig.name
    after=read(folder/"motion.json")
    side=before["side"]
    assert side==after["side"] and before["checks_failed"]==after["checks_failed"]==0
    for sample in (orig,folder):
        log=(sample/"engine.log").read_text(encoding="utf-8")
        assert "Forward+ - Using Device #0: AMD - AMD Radeon RX 9070 XT" in log
        assert not re.search(r"^(?:SCRIPT )?ERROR:|^FAIL|Parse Error|leaked at exit",log,re.M)
    for first,last in zip(before["rows"],after["rows"],strict=True):
        assert (first["action"],first["frame"])==(last["action"],last["frame"])
        for key in fields:
            assert equal(first[key],last[key]),(orig.name,first["action"],first["frame"],key,first[key],last[key])
    result={}
    for label in ("forward","back"):
        sequences=[[x for x in report["rows"] if x["action"]==label] for report in (before,after)]
        first,last=sequences
        assert len(first)==len(last)==36
        if label=="forward":
            for a,b in zip(first,last,strict=True):
                for key in ("camera_center","camera","root_screen","head_screen","back_boot_screen","front_boot_screen"):
                    assert equal(a[key],b[key]),(orig.name,key,a[key],b[key])
        else:
            assert all(equal(a["camera_center"][1],b["camera_center"][1]) for a,b in zip(first,last,strict=True))
            assert equal(first[0]["camera_center"],last[0]["camera_center"])
        original=dash_summary(first,side)
        fixed=dash_summary(last,side)
        result[label]={"original":original,"candidate":fixed}
    summary[orig.name]=result
report={"comparison":summary,"matched_samples":len(summary)*72,
        "view":"native 1280×720 Forward+ Vulkan RX 9070 XT 60 fixed FPS, default game camera",
        "source":"identical original Main Continue saves and controlled position and aim; game dash actual input press and release",
        "coordinates":"nearest rear edge measured in actual output pixels at head, root and front/back foot bones"}
(base/"camera-evidence.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
for case,res in summary.items():
    a,b=[res["back"][k] for k in ("original","candidate")]
    print(case,a["minimum_rear_pixels"],b["minimum_rear_pixels"],b["maximum_center_step_world"])
    assert b["maximum_center_step_world"] <= 7.5
    assert min(b["minimum_rear_pixels"].values()) > 24
assert sum(val["back"]["original"]["minimum_rear_pixels"]["head_screen"] < 0 for val in summary.values())==3
