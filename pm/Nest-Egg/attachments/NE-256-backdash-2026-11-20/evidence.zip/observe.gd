extends "res://tools/ch1_flow_probe.gd"

var store_path := ""
var side := 1
var app: Node
var player: Player
var rig: CharacterRig
var rows: Array[Dictionary] = []
var lens := 0.0
var mode := ""
var anchor_x := 472.0


func _run() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--slot="):
			store_path = arg.trim_prefix("--slot=")
		elif arg.begins_with("--side="):
			side = int(arg.trim_prefix("--side="))
		elif arg.begins_with("--lens="):
			lens = float(arg.trim_prefix("--lens="))
		elif arg.begins_with("--mode="):
			mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--anchor-x="):
			anchor_x = float(arg.trim_prefix("--anchor-x="))
	if not store_path.is_absolute_path() or side not in [-1, 1] or mode not in ["dash","jump"]:
		get_tree().quit(2)
		return
	app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	app.set("_run_store", RunSaveStore.new(store_path))
	add_child(app)
	for frame in STEP_LIMIT:
		if app.get("_screen") is MainMenu and not bool(app.call("_route_pending")):
			break
		await get_tree().process_frame
	var menu := app.get("_screen") as MainMenu
	if menu == null:
		get_tree().quit(2)
		return
	await _settle(8)
	menu._continue_button.pressed.emit()
	for frame in STEP_LIMIT:
		var current := app.get("_screen") as Level
		if current != null and current.is_initialized() and current.data.id == &"ch1_street" and not bool(app.call("_route_pending")):
			_level = current
			break
		await get_tree().process_frame
	if _level == null or _level.player == null:
		get_tree().quit(2)
		return
	player = _level.player
	rig = player._visual.rig
	player.global_position = Vector2(anchor_x, player.global_position.y)
	player.velocity = Vector2.ZERO
	_level.camera.snap_to_target()
	var aim := &"aim_right" if side > 0 else &"aim_left"
	AimInput.set_virtual_gamepad(player, true)
	Input.action_release(&"aim_right")
	Input.action_release(&"aim_left")
	AimInput.restore_direction(Vector2(side,0))
	Input.action_press(aim)
	await _settle(36)
	_check(player.facing == side and player.is_on_floor(), "real safe street floor and requested facing")
	if lens > 0.0:
		_level.camera.set_physics_process(false)
		_level.camera.position_smoothing_enabled = false
		_level.camera.offset = Vector2.ZERO
	if mode == "dash":
		await _dash("forward", side)
		await _dash("back", -side)
	else:
		await _jump()
	Input.action_release(aim)
	AimInput.set_virtual_gamepad(player, false)
	var file := FileAccess.open(_out_dir.path_join("motion.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks_failed":_failures,"side":side,"mode":mode,"rows":rows},"  ") + "\n")
	file.close()
	app.call("_quit", int(_failures > 0))


func _dash(label: String, dir: int) -> void:
	player.global_position.x = anchor_x
	player.velocity = Vector2.ZERO
	_level.camera.snap_to_target()
	await _settle(45)
	var x := player.global_position.x
	var action := &"move_right" if dir > 0 else &"move_left"
	await _record(label, 0, true)
	Input.action_press(action)
	Input.action_press(&"dash")
	var seen := 0
	var end_position := player.position.x
	var cooldown_rest := 0
	for frame in range(1, 36):
		await _record(label, frame, frame in [1, 4, 7, 10, 12, 19, 25])
		if player.state == Player.State.DASH:
			seen += 1
			end_position = player.position.x
		elif seen > 0:
			cooldown_rest += 1
		if frame == 1:
			Input.action_release(&"dash")
			Input.action_release(action)
	_check(seen >= 8 and cooldown_rest >= 8 and (end_position - x) * dir > 30.0, label + " uses real dash input and finishes")
	_check(player.facing == side, label + " preserves independently aimed facing")


func _jump() -> void:
	var floor_y := player.global_position.y
	await _record("jump", 0, true)
	Input.action_press(&"jump")
	var air := 0
	var total := 0
	var prev := true
	for frame in range(1, 91):
		var grounded := player.is_on_floor()
		var bounced := grounded and not prev
		prev = grounded
		await _record("jump", frame, frame in [1, 5, 12, 22, 34, 44, 55, 65, 74] or bounced)
		if not player.is_on_floor():
			air += 1
			total += 1
		if frame == 38:
			Input.action_release(&"jump")
	_check(air >= 24 and total < 85 and absf(player.global_position.y-floor_y)<0.05, "real jump rose, fell and landed at the same edge-free floor")


func _record(label: String, frame: int, shot: bool) -> void:
	if lens > 0.0:
		_level.camera.zoom = Vector2.ONE * lens
		_level.camera.global_position = player.global_position + Vector2(0, -32)
		_level.camera.force_update_scroll()
	await RenderingServer.frame_post_draw
	var root := player.global_position
	var feet := {"front": _p(rig.bone(&"foot_front").global_position-root),
		"back": _p(rig.bone(&"foot_back").global_position-root)}
	var chest := rig.bone(&"chest")
	var hip := rig.bone(&"hip")
	var head := rig.bone(&"head")
	var canvas := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	rows.append({"action":label,"frame":frame,"root":_p(root),"velocity":_p(player.velocity),"facing":player.facing,"aim":_p(player.aim_dir),
		"state":player.state,"ground":player.is_on_floor(),"dash_time":player._dash_left,"physics":Engine.get_physics_frames(),
		"foot":feet,"chest":_p(chest.global_position-root),"hip":_p(hip.global_position-root),
		"head":_p(head.global_position-root),"chest_rotation":chest.rotation,"hip_rotation":hip.rotation,
		"head_screen":_p(canvas*head.global_position),"root_screen":_p(canvas*root),
		"front_boot_screen":_p(canvas*rig.bone(&"foot_front").global_position),
		"back_boot_screen":_p(canvas*rig.bone(&"foot_back").global_position),
		"weapon":rig.weapon_root().visible,"zoom":_p(_level.camera.zoom),
		"camera":_p(_level.camera.global_position),"camera_center":_p(_level.camera.get_screen_center_position()),
		"camera_left":_level.camera.limit_left})
	if shot:
		_capture("%s-%03d" % [label,frame])
	await get_tree().process_frame


func _p(vector: Vector2) -> Array:
	return [vector.x, vector.y]
