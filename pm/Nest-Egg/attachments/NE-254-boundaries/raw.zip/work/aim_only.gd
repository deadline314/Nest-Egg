extends Node
var failures := 0
var checks := 0
func _ready() -> void:
 run.call_deferred()
func run() -> void:
 Story.auto_skip = true
 var suite := ThrowablesSuite.new(self)
 await suite._test_barrel_aim_priority()
 print("checks: ",checks,", failures: ",failures)
 await get_tree().create_timer(0.3).timeout
 get_tree().quit(0 if failures == 0 else 1)
func _check(ok: bool, message: String) -> void:
 checks += 1
 print("PASS: " if ok else "FAIL: ",message)
 if not ok: failures += 1
func _frames(n: int) -> void:
 for i in n: await get_tree().process_frame
func _end_level(level: Level) -> void:
 level.queue_free()
 await _frames(3)
