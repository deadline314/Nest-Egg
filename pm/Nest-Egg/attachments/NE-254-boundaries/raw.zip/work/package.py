from pathlib import Path
import hashlib,json,re,subprocess,zipfile
root=Path.cwd(); scratch=root/'work/ne254-boundaries'; out=root/'pm/Nest-Egg/attachments/NE-254-boundaries'; native=root/'work/batch1020b'
# The shared native wrapper writes under the root checkout's work directory.
native=Path('/workspace/Nest-Egg/work/batch1020b')
log=(scratch/'selector.log').read_text(); match=re.search(r'checks: (\d+), new failures: (\d+), known failures .*: (\d+)  \(wall time (\d+) s\)',log)
assert match and (scratch/'selector.exit').read_text().strip()=='0'
assert match.group(2,3)==('0','0')
frozen=json.loads((scratch/'frozen-source.json').read_text());assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==sha for p,sha in frozen.items())
control=json.loads((scratch/'fresh-complete-control-receipt.json').read_text());assert control['exact_restore']
assert control['test_source_sha256']==frozen['tests/suite/test_throwables.gd']
negative=(scratch/'fresh-complete-control-tests.log').read_text();assert 'checks: 326, failures: 6' in negative
runs=['ne254-1022-candidate','ne254-1022-candidate-v2','ne254-1022-candidate-v3','ne254-1022-control','ne254-1022-final','ne254-1022-wall-control','ne254-1022-wall-control-fresh','ne254-1022-wall-final']
results={name:json.loads((native/name/'result.json').read_text()) for name in runs}
assert results['ne254-1022-final']['failures']==0 and results['ne254-1022-wall-final']['failures']==0
assert results['ne254-1022-wall-control-fresh']['enemy_health_after']==1 and results['ne254-1022-wall-final']['enemy_health_after']==4
for name in ['ne254-1022-final','ne254-1022-control','ne254-1022-wall-control-fresh','ne254-1022-wall-final']:
 assert 'ERROR:' not in (native/(name+'.log')).read_text()
for name in ['ne254-1022-final','ne254-1022-wall-final']:
 assert results[name]['game/props/throwable.gd']==frozen['game/props/throwable.gd']
for name,filename in [('ne254-1022-wall-control-fresh','NE-254-wall-before.png'),('ne254-1022-wall-final','NE-254-wall-after.png')]:
 (root/'pm/Nest-Egg/images'/filename).write_bytes((native/name/'wall-after.png').read_bytes())
files={}
def add(path, rel):
 assert rel not in files,rel
 files[rel]=Path(path).read_bytes()
for p in scratch.iterdir():
 if p.name != 'package.log' and p.is_file() and p.suffix in ['.log','.json','.py','.gd','.tscn','.exit']:
  add(p,'work/'+p.name)
for p in Path('/tmp/tmp.g3IogweXoC').glob('shard_*.log'):add(p,'selector/'+p.name)
for name in runs:
 for p in (native/name).iterdir():
  if p.is_file():add(p,'native/'+name+'/'+p.name)
 for suffix in ['.log','.exit','-xvfb.log']:
  p=native/(name+suffix)
  if p.is_file():add(p,'native/'+name+'/'+p.name)
for rel in ['core/aim_input.gd','core/input_feel.gd','game/props/throwable.gd','tests/suite/test_throwables.gd']:
 files['source/final/'+rel]=(root/rel).read_bytes()
 files['source/base/'+rel]=subprocess.check_output(['git','show','a66794ec:'+rel])
for p in (scratch/'research').iterdir():add(p,'research/'+p.name)
for p in (scratch/'final-control-profile').rglob('slot-1.json*'):add(p,'reused-profile/'+p.name)
archive=out/'raw.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel,data in sorted(files.items()):z.writestr(rel,data)
manifest={'version':1,'archive':'raw.zip','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':[{'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for rel,data in sorted(files.items())]}
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(files)
 for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
validation={'date':'2026-10-22 Asia/Taipei','base':'a66794ecc8bb81398d86decd9c24f84348696837','engine':'4.7.2.stable.official.ed1daf0bf','affected':{'groups':66,'checks':int(match[1]),'new_failures':0,'known_failures':0,'exit':0,'wall_seconds':int(match[4]),'original_selector':True},'final_control':{'checks':326,'failures':6,'exit':1,'same_final_test_source':True,'exact_candidate_restore':True},'native_aim':{'before':results['ne254-1022-control'],'after':results['ne254-1022-final']},'native_wall':{'before':results['ne254-1022-wall-control-fresh'],'after':results['ne254-1022-wall-final']},'frozen_source':frozen,'harness_unchanged':json.loads((scratch/'harness-unchanged.json').read_text()),'archive_sha256':manifest['sha256'],'archive_entries':len(files),'ci':'See the pushed commit GitHub Actions; no future result is claimed here.','limits':['Synthetic controller 999; no physical controller or human chapter playthrough.','Forward+ llvmpipe software rendering; arranged positions, frozen enemy AI and fuse after ignition.','Early reused-profile controller failure and non-reproducing wall setup remain in raw evidence.']}
(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checks':validation['affected'],'archive_bytes':manifest['bytes'],'archive_entries':len(files),'archive_sha256':manifest['sha256']},indent=2))
