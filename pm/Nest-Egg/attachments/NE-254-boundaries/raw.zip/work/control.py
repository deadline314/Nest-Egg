from pathlib import Path
import subprocess, os, hashlib, json
root=Path.cwd(); out=root/'work/ne254-boundaries'; paths=['core/aim_input.gd','core/input_feel.gd','game/props/throwable.gd']
saved={p:(root/p).read_bytes() for p in paths}; receipts={'base':'a66794ecc8bb81398d86decd9c24f84348696837','before':{p:hashlib.sha256(b).hexdigest() for p,b in saved.items()}}
env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',XDG_DATA_HOME=str(out/'final-control-profile'),NE_NATIVE_PROJECT='../batch1022/kitchen')
engine='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64'
try:
 for p in paths:(root/p).write_bytes(subprocess.check_output(['git','show',receipts['base']+':'+p]))
 receipts['control']={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
 with (out/'final-control-tests.log').open('w') as log:
  receipts['test_exit']=subprocess.run([engine,'--headless','--path','.', 'res://tests/smoke_test.tscn','--','--only=ThrowablesSuite,InputFeelSuite'],env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 with (out/'final-control-native-wrapper.log').open('w') as log:
  receipts['native_exit']=subprocess.run(['python','/workspace/Nest-Egg/work/batch1020b/native.py','ne254-1022-control','res://work/ne254-boundaries/native_probe.tscn'],env=env,stdout=log,stderr=subprocess.STDOUT).returncode
finally:
 for p,b in saved.items():(root/p).write_bytes(b)
 receipts['restored']={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
 receipts['exact_restore']=receipts['restored']==receipts['before']
 (out/'control-receipt.json').write_text(json.dumps(receipts,indent=2))
 assert receipts['exact_restore']
print(json.dumps(receipts,indent=2))
