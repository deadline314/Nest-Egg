extends ScenarioBase
var failures := 0
var checks := 0
var receipt := {}
class Rays extends Node2D:
 var origin := Vector2.ZERO
 var raw := Vector2.RIGHT
 var assisted := Vector2.RIGHT
 func _draw() -> void:
  draw_line(origin, origin + raw * 245, Color(0.3,1,0.3,0.8), 0.7)
  draw_line(origin, origin + assisted * 245, Color(1,0.6,0.15,0.8), 0.7)
func _ready() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with('--out='): out_dir = arg.trim_prefix('--out=')
 DirAccess.make_dir_recursive_absolute(out_dir)
 _run.call_deferred()
func check(ok: bool, text: String) -> void:
 checks += 1
 print('PASS: ' if ok else 'FAIL: ', text)
 if not ok: failures += 1
func axis(axis_id: JoyAxis, value: float) -> void:
 var event := InputEventJoypadMotion.new()
 event.device = 999
 event.axis = axis_id
 event.axis_value = value
 Input.parse_input_event(event)
 Input.flush_buffered_events()
func _run() -> void:
 add_child(LightKit.create_environment())
 Story.auto_skip = true
 await open_arena('', 94.0, load('res://data/levels/ch1_street.tres'))
 level._next_story_trigger = level._layout.story_triggers.size()
 for zone in level.find_children('*', 'EncounterZone', true, false): zone.queue_free()
 await clear_enemies()
 player.position.y = level._layout.floor_below(94, 10)
 player.velocity = Vector2.ZERO
 var barrel: Throwable
 for node in get_tree().get_nodes_in_group(Throwable.GROUP):
  if node is Throwable and node.data.id == &"fuel_barrel" and absf(node.position.x - 1672.0) < 24:
   barrel = node
 check(barrel != null, 'formal first-chapter plaza contains its authored barrel')
 if barrel == null:
  get_tree().quit(1)
  return
 var rival := spawn_enemy('res://data/enemies/grunt.tres', 109.0, player.position.y)
 rival.set_physics_process(false)
 var camera := Camera2D.new()
 camera.position = Vector2(player.position.x + 120, player.position.y - 36)
 camera.zoom = Vector2.ONE * 2.0
 add_child(camera)
 camera.make_current()
 var layer := CanvasLayer.new()
 add_child(layer)
 var label := Label.new()
 label.position = Vector2(12, 10)
 label.text = 'NE-254 驗證：正式街道／安排站位與停止敵人\n合成手把 999；綠＝原始方向，橙＝實際方向；非真人手感驗收'
 label.add_theme_font_size_override('font_size', 12)
 layer.add_child(label)
 InputBindings.clear_held_inputs()
 axis(JOY_AXIS_RIGHT_X, 0)
 axis(JOY_AXIS_RIGHT_Y, 0)
 await settle(3)
 var origin := player.aim_origin()
 var raw := (barrel.world_center() - origin).normalized()
 axis(JOY_AXIS_RIGHT_X, raw.x)
 axis(JOY_AXIS_RIGHT_Y, raw.y)
 AimInput.restore_direction(raw)
 await settle(3)
 var actual := AimInput.direction_from(player, origin, raw)
 var ordinary := InputFeel.assist(origin, raw, [rival], 0, true)
 check(not ordinary.is_equal_approx(raw), 'rival really competes for aim assistance')
 check(actual.is_equal_approx(raw), 'the authored barrel keeps the deliberate raw aim direction')
 var rays := Rays.new()
 rays.origin = origin
 rays.raw = raw
 rays.assisted = actual
 add_child(rays)
 await RenderingServer.frame_post_draw
 capture('aim')
 # Hold this one fuse for a readable capture; damage and the real RT path remain active.
 barrel.health.died.connect(func(_info: DamageInfo) -> void: barrel.set_physics_process(false))
 var ammo_before := player.loadout.mag_in(player.loadout.active_slot)
 for i in 2:
  axis(JOY_AXIS_TRIGGER_RIGHT, 1)
  await get_tree().physics_frame
  axis(JOY_AXIS_TRIGGER_RIGHT, 0)
  await wait(0.28)
 await settle(2)
 check(barrel.is_fuse_lit(), 'mapped RT shots from the real Player ignite the authored barrel')
 var ammo_after := player.loadout.mag_in(player.loadout.active_slot)
 check(ammo_after == ammo_before - 2, 'two trigger taps spend exactly two real rounds')
 await RenderingServer.frame_post_draw
 capture('fuse')
 receipt = {'checks':checks,'failures':failures,'renderer':RenderingServer.get_current_rendering_method(),
  'device':999,'raw':[raw.x,raw.y],'actual':[actual.x,actual.y],'ordinary':[ordinary.x,ordinary.y],
  'origin':[origin.x,origin.y],'barrel':[barrel.position.x,barrel.position.y],
  'rival':[rival.position.x,rival.position.y],'ammo_before':ammo_before,'ammo_after':ammo_after,
  'fuse_lit':barrel.is_fuse_lit(),'physics_gpu':'software Vulkan','fuse_frozen_for_capture':true}
 for path in ['core/aim_input.gd','core/input_feel.gd','game/props/throwable.gd']:
  receipt[path] = FileAccess.get_sha256('res://' + path)
 var file := FileAccess.open(out_dir.path_join('result.json'), FileAccess.WRITE)
 file.store_string(JSON.stringify(receipt,' '))
 file.close()
 axis(JOY_AXIS_RIGHT_X,0)
 axis(JOY_AXIS_RIGHT_Y,0)
 axis(JOY_AXIS_TRIGGER_RIGHT,0)
 InputBindings.clear_held_inputs()
 await finish()
 Sfx.stop_all()
 Music.stop(0)
 Ambience.stop_all(0)
 await get_tree().create_timer(0.4,true,false,true).timeout
 print('checks: ',checks,', failures: ',failures)
 get_tree().quit(0 if failures == 0 else 1)
