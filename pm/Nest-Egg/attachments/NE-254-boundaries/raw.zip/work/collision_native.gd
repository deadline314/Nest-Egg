extends ScenarioBase
var failures := 0
var checks := 0
func _ready() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with('--out='): out_dir = arg.trim_prefix('--out=')
 DirAccess.make_dir_recursive_absolute(out_dir)
 _run.call_deferred()
func check(ok: bool, message: String) -> void:
 checks += 1
 print('PASS: ' if ok else 'FAIL: ',message)
 if not ok: failures += 1
func _run() -> void:
 add_child(LightKit.create_environment())
 Story.auto_skip = true
 Enemy.activation_culling_enabled = false
 var previous_hz := Engine.physics_ticks_per_second
 Engine.physics_ticks_per_second = 30
 var data := EnemySuiteBase.map_data()
 data.chapter = &"ch1_kasa"
 await open_arena('res://data/lighting/neutral.tres',10,data)
 await clear_enemies()
 var wall := StaticBody2D.new()
 wall.collision_layer = Layers.WORLD
 wall.collision_mask = 0
 wall.position = Vector2(400,260)
 var shape := CollisionShape2D.new()
 var rect := RectangleShape2D.new()
 rect.size = Vector2(3,120)
 shape.shape = rect
 wall.add_child(shape)
 var art := Polygon2D.new()
 art.polygon = PackedVector2Array([Vector2(-1.5,-60),Vector2(1.5,-60),Vector2(1.5,60),Vector2(-1.5,60)])
 art.color = Color('b7cad3')
 wall.add_child(art)
 level.add_child(wall)
 var enemy := spawn_enemy('res://data/enemies/grunt.tres',412.0/16.0)
 await settle(3)
 enemy.set_physics_process(false)
 enemy.global_position = Vector2(412,320)
 enemy.velocity = Vector2.ZERO
 var pipe := Throwable.new()
 pipe.configure(load('res://data/throwables/pipe.tres'))
 pipe.position = Vector2(387.5,302.5)
 level._entities.add_child(pipe)
 pipe.set_physics_process(false)
 var camera := Camera2D.new()
 camera.position = Vector2(395,275)
 camera.zoom = Vector2.ONE*3.4
 add_child(camera)
 camera.make_current()
 var layer := CanvasLayer.new()
 add_child(layer)
 var label := Label.new()
 label.position = Vector2(12,10)
 label.add_theme_font_size_override('font_size',12)
 label.text = 'NE-254 薄牆碰撞驗證場地・軟體 Forward+\n30 Hz 真物理步進／正式鐵管速度 400；停止敵人 AI'
 layer.add_child(label)
 await settle(3)
 var before := enemy.health.current
 await RenderingServer.frame_post_draw
 capture('wall-before')
 pipe.launch(pipe.position,Vector2(pipe.data.throw_speed,0),Combat.Team.PLAYER)
 pipe.set_physics_process(true)
 await get_tree().physics_frame
 await get_tree().physics_frame
 pipe.set_physics_process(false)
 var after := enemy.health.current
 check(absf(pipe._flight_time - 1.0/30.0) < 0.00001, 'the actual object completed one full 30 Hz physics step')
 check(after == before,'the actual wall collision prevents damage to the real enemy behind it')
 check(pipe.global_position.x < 398.5,'the pipe stays on the near side of the wall')
 label.text += '\n敵人生命：%s → %s' % [before,after]
 await RenderingServer.frame_post_draw
 capture('wall-after')
 var result := {'checks':checks,'failures':failures,'physics_hz':Engine.physics_ticks_per_second,
  'speed':pipe.data.throw_speed,'enemy_health_before':before,'enemy_health_after':after,
  'flight_time':pipe._flight_time,'enemy_position':[enemy.position.x,enemy.position.y],'pipe_position':[pipe.position.x,pipe.position.y],'wall_center':[400,260],'wall_width':3,
  'enemy':String(enemy.data.id),'renderer':RenderingServer.get_current_rendering_method(),
  'fixture':true,'game/props/throwable.gd':FileAccess.get_sha256('res://game/props/throwable.gd')}
 var file := FileAccess.open(out_dir.path_join('result.json'),FileAccess.WRITE)
 file.store_string(JSON.stringify(result,' '));file.close()
 Engine.physics_ticks_per_second = previous_hz
 # Match the normal suite's immediate scene retirement before stopping audio.
 remove_child(level)
 level.free()
 level = null
 await settle(4)
 Sfx.stop_all(); Music.stop(0); Ambience.stop_all(0)
 await get_tree().create_timer(0.4,true,false,true).timeout
 print('checks: ',checks,', failures: ',failures)
 get_tree().quit(0 if failures == 0 else 1)
