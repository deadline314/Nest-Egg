from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();out=root/'work/ne223-language'; paths=['core/navigation/quest_catalog.gd','ui/quest_guidance.gd','ui/quest_map_screen.gd'];saved={p:(root/p).read_bytes() for p in paths};env=os.environ.copy();env['LD_LIBRARY_PATH']='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu';env['XDG_DATA_HOME']=str(out/'native-control-final-profile');env['NE_NATIVE_PROJECT']='../batch1022/quests'
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt={'base':'7ee228083b6da0d9660f33554c1667d799618d03','candidate':{p:sha(b) for p,b in saved.items()}}
try:
 for p in paths:
  data=subprocess.check_output(['git','show',receipt['base']+':'+p]); (root/p).write_bytes(data)
  dest=out/'baseline'/p; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 with (out/'native-control-final-wrapper.log').open('w') as log:
  r=subprocess.run(['python','/workspace/Nest-Egg/work/batch1020b/native.py','ne223-1022-frozen-control','res://work/ne223-language/native_probe.tscn'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 receipt['exit_code']=r.returncode
 text=Path('/workspace/Nest-Egg/work/batch1020b/ne223-1022-frozen-control.log').read_text();assert 'SCRIPT ERROR' not in text
 receipt['result']=[l for l in text.splitlines() if l.startswith(('checks:','FAIL:'))]
finally:
 for p,b in saved.items(): (root/p).write_bytes(b)
 receipt['restored']={p:sha((root/p).read_bytes())==sha(b) for p,b in saved.items()}
 (out/'native-control-final-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
