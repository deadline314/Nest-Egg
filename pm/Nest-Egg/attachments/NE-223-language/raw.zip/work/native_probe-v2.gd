extends Node
var out := ''
var checks := 0
var failures := 0
var results := []
func _ready() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with('--out='): out=arg.trim_prefix('--out=')
 DirAccess.make_dir_recursive_absolute(out)
 _run.call_deferred()
func check(ok: bool, message: String) -> void:
 checks += 1
 print('PASS: ' if ok else 'FAIL: ',message)
 if not ok: failures += 1
func frames(n: int) -> void:
 for i in n: await get_tree().process_frame
func texts(root: Node) -> PackedStringArray:
 var result := PackedStringArray()
 if root is Label or root is Button: result.append(root.text)
 for child in root.get_children(): result.append_array(texts(child))
 return result
func shot(name: String) -> void:
 await RenderingServer.frame_post_draw
 var err := preload('res://tools/viewport_capture.gd').image(get_viewport()).save_png(out.path_join(name+'.png'))
 check(err == OK, 'capture '+name)
func _run() -> void:
 Settings.use_storage('user://ne223-language-native.cfg')
 Settings.set_ui_text_scale(1.2)
 Settings.set_hud_auto_hide(false)
 Story.auto_skip = true
 GameState.start_new_run(GameState.difficulties[1])
 add_child(LightKit.create_environment())
 var level := Level.new()
 level.configure(load('res://data/levels/ch3_clinic.tres'))
 add_child(level)
 await frames(12)
 level._next_story_trigger = level._layout.story_triggers.size()
 Story.reset_active_presentation(&"leave")
 GameState.set_flag(&"ch3_clinic_access",true,false)
 var guidance: QuestGuidance = level.hud.quest_guidance
 guidance.state.pin('sq7_ahan_tape',guidance.catalog)
 var raw_before := JSON.stringify(guidance.catalog.quests)
 var flags_before := JSON.stringify(GameState.world_flags)
 var quest := guidance.catalog.find('sq7_ahan_tape')
 var checker: Node = load('res://tools/quest_map_probe.gd').new()
 for language in ['en','ja','zh']:
  Story.set_language(language)
  guidance._refresh_target()
  await frames(2)
  var step: Dictionary=quest['steps'][0]
  var expected_step := str(step['title'] if language == 'zh' else step['title_'+language])
  check(guidance._label.text == '◎ '+expected_step,'real HUD uses '+language+' step')
  check(guidance._row.tooltip_text.begins_with(expected_step),'HUD retains full '+language+' text for hover')
  await shot(language+'-hud')
  get_tree().paused=true
  var layer := CanvasLayer.new()
  layer.layer=UiLayers.PAUSE
  add_child(layer)
  var root := UiKit.full_rect_root(layer)
  var screen := QuestMapScreen.new()
  screen.catalog=guidance.catalog
  screen.maps=guidance.maps
  screen.state=guidance.state
  screen.chapter='ch3_clearwater'
  screen.player_path=level.data.resource_path
  screen.player_position=level.player.position
  screen.world=WorldState.capture(get_tree())
  root.add_child(screen)
  await frames(4)
  screen._select('sq7_ahan_tape')
  screen._status.text='驗證樣本 '+language+'／120%'
  await frames(4)
  var shown := texts(screen)
  for field in ['title','background','reward']:
   var expected := str(quest[field] if language == 'zh' else quest[field+'_'+language])
   check(shown.has(expected),'real detail '+field+' uses '+language)
  checker._check_layout(screen)
  check(checker._layout_issues.is_empty(),'original layout audit accepts '+language+' at 120%')
  check(JSON.stringify(guidance.catalog.quests)==raw_before and JSON.stringify(GameState.world_flags)==flags_before,'language '+language+' preserves quest facts and progress')
  await shot(language+'-quest')
  results.append({'language':language,'text_scale':1.2,'visible_text':Array(shown),'layout_issues':Array(checker._layout_issues),'hud':guidance._label.text,'tooltip':guidance._row.tooltip_text})
  layer.queue_free()
  await frames(3)
  get_tree().paused=false
 var receipt := {'checks':checks,'failures':failures,'renderer':RenderingServer.get_current_rendering_method(),'state_fixture':true,'complete_playthrough':false,'results':results}
 for path in ['core/navigation/quest_catalog.gd','ui/quest_guidance.gd','ui/quest_map_screen.gd','data/story/ch3_clearwater.json']:
  receipt[path]=FileAccess.get_sha256('res://'+path)
 var file:=FileAccess.open(out.path_join('result.json'),FileAccess.WRITE)
 file.store_string(JSON.stringify(receipt,' '));file.close()
 checker.free()
 remove_child(level);level.free()
 await frames(4)
 Sfx.stop_all(); Music.stop(0); Ambience.stop_all(0)
 await get_tree().create_timer(0.4,true,false,true).timeout
 print('checks: ',checks,', failures: ',failures)
 get_tree().quit(0 if failures==0 else 1)
