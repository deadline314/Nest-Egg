from pathlib import Path
import os,subprocess,json,hashlib
root=Path.cwd();out=root/'work/ne223-language'; env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/quests'
cases=[('pawnshop',1280,720,'en',1.0),('pawnshop',1920,1080,'ja',1.2),('warehouse',1280,720,'ja',1.2),('warehouse',1920,1080,'en',1.2),('street',1920,1080,'en',1.2)]
results=[]
for level,w,h,lang,scale in cases:
 name=f'ne223-1022-{level}-{w}-{lang}'
 args=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/ne223-language/layout_probe.tscn',f'--level={level}',f'--width={w}',f'--height={h}',f'--text-scale={scale}',f'--language={lang}','--flags=ch1_prologue_exit,ch1_dinner_done,ch1_heard_brief']
 with (out/(name+'-wrapper.log')).open('w') as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=360)
 result={'name':name,'args':args,'exit_code':r.returncode};results.append(result);print(json.dumps(result),flush=True)
 (out/'layout-matrix-receipt.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['exit_code']==0 for r in results)
