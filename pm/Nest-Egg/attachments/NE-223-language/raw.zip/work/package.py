from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil
root=Path.cwd();scratch=root/'work/ne223-language';native=Path('/workspace/Nest-Egg/work/batch1020b');out=root/'pm/Nest-Egg/attachments/NE-223-language';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
frozen=json.loads((scratch/'frozen-source.json').read_text())
assert all(sha((root/p).read_bytes())==s for p,s in frozen.items())
assert 'checks: 8469, new failures: 0, known failures (tests/known_failures.txt): 0' in (scratch/'final-changed.log').read_text()
assert 'checks: 336, failures: 32' in (scratch/'final-frozen-control.log').read_text()
assert 'checks: 336, failures: 3' in (scratch/'focus-control.log').read_text()
final=json.loads((native/'ne223-1022-focus-final/result.json').read_text());assert final['checks']==55 and final['failures']==0
for p in ['core/navigation/quest_catalog.gd','ui/quest_guidance.gd','ui/quest_map_screen.gd','data/story/ch3_clearwater.json']: assert final[p]==frozen[p]
assert not any(x in (native/'ne223-1022-focus-final.log').read_text() for x in ['ERROR:','SCRIPT ERROR:'])
assert (native/'ne223-1022-focus-final.exit').read_text().strip()=='0'
control=json.loads((native/'ne223-1022-frozen-control/result.json').read_text());assert control['checks']==55 and control['failures']>0
assert all(all(json.loads((scratch/p).read_text())['restored'].values()) for p in ['final-frozen-control-receipt.json','native-control-final-receipt.json'])
files={}
for p in scratch.rglob('*'):
 if p.is_file() and not any('profile' in part or part.startswith('data_') for part in p.relative_to(scratch).parts) and p.suffix in ['.gd','.tscn','.json','.log','.py','.patch','.md']:
  files['work/'+str(p.relative_to(scratch))]=p.read_bytes()
for p in native.glob('ne223-1022-*'):
 if p.is_dir() and not p.name.endswith('-profile'):
  for f in p.iterdir():
   if f.is_file(): files['native/'+p.name+'/'+f.name]=f.read_bytes()
 elif p.is_file() and p.suffix in ['.log','.exit']: files['native/'+p.name]=p.read_bytes()
for p in frozen: files['source/final/'+p]=(root/p).read_bytes()
for p in ['core/navigation/quest_catalog.gd','ui/quest_guidance.gd','ui/quest_map_screen.gd','tests/suite/test_quest_map.gd','data/story/ch3_clearwater.json']:
 files['source/base/'+p]=subprocess.check_output(['git','show','7ee228083b6da0d9660f33554c1667d799618d03:'+p])
validation={'base':'cf85b566b9409d195c371fc7f092b38a163c823a','changed_groups':26,'changed_checks':8469,'changed_new_failures':0,'changed_known_failures':0,'changed_seconds':210,'negative_checks':336,'negative_failures':32,'focus_negative_checks':336,'focus_negative_failures':3,'native_final_checks':55,'native_final_failures':0,'native_control_checks':control['checks'],'native_control_failures':control['failures'],'native_renderer':'forward_plus','native_device':'llvmpipe','native_final_errors':0,'static_matrix_before_final_focus_guard':True,'static_matrix_cases':5,'static_matrix_screenshots':25,'full_ci_required_for_this_commit':'pending push; prior cf85b566 CI 39735305084 passed 95894 checks','frozen_source':frozen}
(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
manifest={'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for e in manifest['files']:assert sha(z.read(e['path']))==e['sha256']
manifest.update(archive_sha256=sha((out/'raw.zip').read_bytes()),archive_bytes=(out/'raw.zip').stat().st_size)
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
images=root/'pm/Nest-Egg/images'
for src,dst in [('ne223-1022-frozen-control/en-quest.png','NE-223-language-before.png'),('ne223-1022-focus-final/en-quest.png','NE-223-language-en.png'),('ne223-1022-focus-final/ja-quest.png','NE-223-language-ja.png'),('ne223-1022-focus-final/zh-quest.png','NE-223-language-zh.png'),('ne223-1022-focus-final/en-hover.png','NE-223-language-full-goal.png'),('ne223-1022-focus-final/en-live-ja.png','NE-223-language-live.png')]:shutil.copy2(native/src,images/dst)
print(json.dumps({**validation,'archive_bytes':manifest['archive_bytes'],'archive_sha256':manifest['archive_sha256'],'entries':len(files)},ensure_ascii=False,indent=2))
