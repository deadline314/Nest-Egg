"""Explicit omitted-input and stopped-publication controls, confined to work scripts."""
from pathlib import Path
root=Path('D:/NestEggVerification/ticket-batch-20261111')
source=(root/'work/ne277-contact-order/holster_formal.gd').read_text()
assert source.count('Input.parse_input_event(mouse)')==1
controls={
 'missing_mouse':source.replace('Input.parse_input_event(mouse)','# CONTROL: omit the mouse event completely'),
 'bound_shift':source.replace('KEY_CAPSLOCK','KEY_SHIFT'),
 'stopped_carry':source.replace('player.carry.pick(crate)','player.carry.pick(crate)\n\tplayer.carry.set_physics_process(false) # CONTROL: real lift cannot publish HOLDING'),
 'stopped_visual':source.replace('player.carry.pick(crate)','player.carry.pick(crate)\n\tplayer._visual.set_physics_process(false) # CONTROL: normal support pose cannot publish'),
}
for kind,text in controls.items():
 for directory in [root,Path.cwd()]:
  (directory/f'work/ne277-contact-order/holster_{kind}.gd').write_bytes(text.encode())
print('four explicit work-only negative fixtures written')
