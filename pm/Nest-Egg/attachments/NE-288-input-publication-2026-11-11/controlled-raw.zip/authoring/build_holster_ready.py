"""Work-only proposed test fixture; never modifies sealed formal test sources."""
from pathlib import Path
ROOT=Path('D:/NestEggVerification/ticket-batch-20261111')
source=(ROOT/'work/ne277-contact-order/holster_neutral.gd').read_text()
source=source.replace('Story._player.choose(0)\n\tawait s.frames(4)', '''Story._player.choose(0)
	await _published(s, func() -> bool: return not player.interaction.active and not s.runner.get_tree().paused and not GameplayLock.is_locked() and crosshair.visible and marker.talk_count == 1, "choice completion is actually published before carry setup")''')
source=source.replace('player.carry.pick(crate)\n\tawait s.frames(35)', '''player.carry.pick(crate)
	await _published(s, func() -> bool: return player.carry.phase == PlayerCarry.Phase.HOLDING and player.carry.held == crate and player._visual._input.action == PlayerCarry.POSE_HOLD and player._visual._carry_hid_weapon and not player._visual.rig.weapon_root().visible and crate.global_position.is_equal_approx(player.carry.hold_point()), "carried-object HOLDING support is actually published before reading")''')
source=source.replace('var carry_position := crate.global_position\n\tmarker._talk()', '''var carry_position := crate.global_position
	marker._talk()
	s.check(player.interaction.active and player.carry.is_holding() and player._visual._interaction_input.action == PlayerCarry.POSE_HOLD and crate.global_position == carry_position and player.carry._phase_t == carry_time and not player._visual.rig.weapon_root().visible, "first synchronous reading frame preserves the published carried-object support")''')
source=source.replace('player.health.take_damage(lethal)\n\tawait s.frames(3)', '''player.health.take_damage(lethal)
	await _published(s, func() -> bool: return player.is_dead() and not player.interaction.active and not crosshair.visible, "death crosshair presentation is actually published")''')
source=source.replace('key.physical_keycode = KEY_CAPSLOCK\n\tkey.pressed = true', '''key.physical_keycode = KEY_CAPSLOCK
	key.pressed = true
	for action: StringName in InputMap.get_actions():
		s.check(not key.is_action(action), "synthetic keyboard device event is unbound: "+str(action))''')
source=source.replace('Input.parse_input_event(joy)\n\tawait s.frames(2)', '''Input.parse_input_event(joy)
	Input.flush_buffered_events()
	s.check(InputBindings.using_gamepad, "synthetic gamepad switch actually publishes")
	await s.frames(2)''')
source=source.replace('Input.parse_input_event(key)\n\tkey = key.duplicate()', '''Input.parse_input_event(key)
	Input.flush_buffered_events()
	s.check(not InputBindings.using_gamepad, "synthetic keyboard switch actually publishes")
	key = key.duplicate()''')
source=source.replace('Input.parse_input_event(mouse)\n\tawait s.frames(2)', '''Input.parse_input_event(mouse)
	Input.flush_buffered_events()
	await _published(s, func() -> bool:
		for action: StringName in [&"dash", &"melee", &"block", &"shoot", &"interact"]:
			if Input.is_action_pressed(action) or Input.is_action_just_pressed(action): return false
		return not InputBindings.using_gamepad, "device events are published with no gameplay action edge")''')
source+='''

static func _published(s: TestSuite, condition: Callable, message: String) -> void:
	var deadline := Time.get_ticks_msec()+3000
	# This is a real process boundary; physics-frame catch-up alone does not publish UI/visual state.
	await s.runner.get_tree().process_frame
	while not condition.call() and Time.get_ticks_msec() < deadline:
		await s.runner.get_tree().process_frame
	s.check(condition.call(), message)
'''
for root in [ROOT,Path.cwd()]:
 (root/'work/ne277-contact-order/holster_ready.gd').write_bytes(source.encode())
print('work-only ready fixture written')
