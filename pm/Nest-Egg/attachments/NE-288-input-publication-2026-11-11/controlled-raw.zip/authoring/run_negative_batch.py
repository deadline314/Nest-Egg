from pathlib import Path
import subprocess,sys,json
root=Path('D:/NestEggVerification/ticket-batch-20261111')
for kind,expected in [('bound_shift','synthetic keyboard device event is unbound'),('stopped_carry','HOLDING support is actually published'),('stopped_visual','HOLDING support is actually published')]:
 name='holster-'+kind.replace('_','-')+'-negative-v1'
 result=subprocess.run([sys.executable,'-X','utf8','work/ne277-contact-order/regression_run.py',name,'--holster','--one-grid','--quiet-pick','--fixture='+kind],capture_output=True)
 folder=root/'work/ne277-contact-order'/name
 raw=(folder/'process.log').read_text(encoding='utf-8')
 failures=[line for line in raw.splitlines() if line.startswith('FAIL: ')]
 assert result.returncode==1 and any(expected in line for line in failures),(kind,result.stdout[-2000:])
 assert 'SCRIPT ERROR' not in raw and '\nERROR:' not in raw,kind
 print(json.dumps({'control':kind,'correctly_rejected':True,'failures':failures}),flush=True)
