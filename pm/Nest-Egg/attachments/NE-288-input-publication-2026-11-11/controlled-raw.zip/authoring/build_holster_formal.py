"""Prepare a maintainable NE288 fixture proposal in work only."""
from pathlib import Path
ROOT=Path('D:/NestEggVerification/ticket-batch-20261111')
t=(ROOT/'work/ne277-contact-order/holster_ready.gd').read_text()
t=t.replace('const OVERLAY :=', '''# Observe the dispatched event, rather than assuming parse_input_event was published.
class DeviceWitness extends Node:
	var joy := false
	var keyboard := false
	var mouse := false
	func _input(event: InputEvent) -> void:
		if event is InputEventJoypadMotion and event.axis == JOY_AXIS_RIGHT_X and event.axis_value > 0.5: joy = true
		if event is InputEventKey and event.physical_keycode == KEY_CAPSLOCK and event.pressed: keyboard = true
		if event is InputEventMouseMotion and event.relative.length_squared() > 1.0: mouse = true

const OVERLAY :=''')
t=t.replace('var carry_position := crate.global_position\n\tmarker._talk()', '''var carry_position := crate.global_position
	var front_hand := player._visual.rig.hand_contact_global(&"front")
	var back_hand := player._visual.rig.hand_contact_global(&"back")
	marker._talk()
	s.check(player._visual.rig.hand_contact_global(&"front").distance_to(front_hand) < 0.001 and player._visual.rig.hand_contact_global(&"back").distance_to(back_hand) < 0.001, "first synchronous reading frame preserves both actual support hand contacts")''')
t=t.replace('static func _switch_devices(s: TestSuite) -> void:\n', '''static func _switch_devices(s: TestSuite) -> void:
	var witness := DeviceWitness.new()
	witness.process_mode = Node.PROCESS_MODE_ALWAYS
	s.runner.add_child(witness)
''')
t=t.replace('for action: StringName in InputMap.get_actions():\n\t\ts.check(not key.is_action(action), "synthetic keyboard device event is unbound: "+str(action))', '''var unbound := true
	for action: StringName in InputMap.get_actions():
		unbound = unbound and not key.is_action(action)
	s.check(unbound, "synthetic keyboard device event is unbound to every InputMap action")''')
t=t.replace('return not InputBindings.using_gamepad, "device events are published with no gameplay action edge")', '''return not InputBindings.using_gamepad, "device events are published with no gameplay action edge")
	s.check(witness.joy and witness.keyboard and witness.mouse, "all three synthetic device events actually dispatch")
	witness.queue_free()''')
for root in [ROOT,Path.cwd()]:
 (root/'work/ne277-contact-order/holster_formal.gd').write_bytes(t.encode())
print('work-only final fixture proposal written')
