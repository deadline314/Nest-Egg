"""Seal original NE288 diagnostic bytes and separately authored metadata."""
from pathlib import Path
import hashlib,json,shutil,zipfile
C=Path('C:/Users/stanl/Github/Nest-Egg')
D=Path('D:/NestEggVerification/ticket-batch-20261111')
OUT=C/'pm/Nest-Egg/attachments/NE-288-input-publication-2026-11-11'
CASES={
 'original-stack-red':'holster-stack-grid-quiet-v6',
 'neutral-key-only':'holster-neutral-key-grid-v6',
 'wrong-readiness-proposal':'holster-neutral-published-grid-v6',
 'ready-seven-grid':'holster-neutral-published-grid-v6-valid',
 'final-seven-grid':'holster-formal-seven-grid-v1',
 'missing-mouse-negative':'holster-missing-mouse-negative-v1',
 'bound-shift-negative':'holster-bound-shift-negative-v1',
 'stopped-carry-negative':'holster-stopped-carry-negative-v1',
 'stopped-visual-negative':'holster-stopped-visual-negative-v1',
 'formal-path-original-carry':'holster-final-formal-path-original-carry-v1',
}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 OUT.mkdir(exist_ok=True)
 for name,data in {'.gdignore':b'', '.gitignore':b'__pycache__/\n*.pyc\n', '.gitattributes':b'*.zip binary\n*.py text eol=lf\n*.json text eol=lf\n*.md text eol=lf\n'}.items():(OUT/name).write_bytes(data)
 raw=OUT/'controlled-raw.zip'
 assert not raw.exists(),'never overwrite an executed raw archive'
 entries={}
 with zipfile.ZipFile(raw,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  def add(path,name):
   z.write(path,name);entries[name]={'bytes':path.stat().st_size,'sha256':sha(path)}
  for label,folder in CASES.items():
   root=D/'work/ne277-contact-order'/folder
   assert (root/'receipt.json').exists(),folder
   for p in sorted(root.rglob('*')):
    if p.is_file() and p.relative_to(root).parts[0] not in ['user','local'] and '__pycache__' not in p.parts and p.suffix!='.pyc':add(p,label+'/'+p.relative_to(root).as_posix())
  for name in ['build_holster_ready.py','build_holster_formal.py','build_holster_negatives.py','run_negative_batch.py','build_ne288_packet.py','original-interaction-holster-before-ne288.gd']:
   add(C/'work/ne277-contact-order'/name,'authoring/'+name)
  add(D/'tests/helpers/interaction_holster_checks.gd','final/tests/helpers/interaction_holster_checks.gd')
 with zipfile.ZipFile(raw) as z:assert z.testzip() is None
 info={'scope':'Headless controlled input/publication regression evidence. Actual NE277 candidate gameplay is context, not a NE288 gameplay change. No GPU performance, physical controller or human evaluation claim. Original application-data caches excluded; executed commands, source copies, logs and receipts retained byte-for-byte.','raw_sha256':sha(raw),'raw_bytes':raw.stat().st_size,'cases':CASES,'entries':entries,'final_helper_sha256':sha(D/'tests/helpers/interaction_holster_checks.gd')}
 (OUT/'controlled-index.json').write_bytes((json.dumps(info,indent=2)+'\n').encode())
 print(json.dumps({k:v for k,v in info.items() if k in ['raw_sha256','raw_bytes','final_helper_sha256']}))
if __name__=='__main__':main()
