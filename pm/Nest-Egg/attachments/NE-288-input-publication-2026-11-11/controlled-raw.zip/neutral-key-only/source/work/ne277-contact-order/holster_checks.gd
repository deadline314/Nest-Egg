extends "res://tests/smoke_test.gd"
class AuditCarry extends PlayerCarry:
	func facts(label: String) -> void:
		var buttons := {}
		for action in [&"dash",&"melee",&"block",&"shoot",&"interact"]:
			buttons[str(action)] = [Input.is_action_pressed(action),Input.is_action_just_pressed(action)]
		get_tree().current_scene.record_carry_event({"event":label,"physics":Engine.get_physics_frames(),"process":Engine.get_process_frames(),"carry_phase":phase,"carry_time":_phase_t,"held":is_instance_valid(held),"interaction":player.interaction.active,"paused":get_tree().paused,"buttons":buttons,"player_state":player.state,"physics_context":Engine.is_in_physics_frame(),"stack":get_stack()})
	func pick(item: Throwable) -> void:
		if "--quiet-pick" not in OS.get_cmdline_user_args(): facts("before_pick")
		super.pick(item)
		if "--quiet-pick" not in OS.get_cmdline_user_args(): facts("after_pick")
	func put_down() -> void:
		facts("put_down")
		super.put_down()
	func throw_toward(direction: Vector2) -> void:
		facts("throw")
		super.throw_toward(direction)
	func drop() -> void:
		facts("drop")
		super.drop()
class AuditNpc extends NpcSuite:
	var current: Level
	func spawn_level(data: LevelData) -> Level:
		current = await super.spawn_level(data)
		if "--original-carry" in OS.get_cmdline_user_args():
			return current
		var old := current.player.carry
		var index := old.get_index()
		var old_name := old.name
		current.player.remove_child(old)
		old.queue_free()
		var carry := AuditCarry.new()
		carry.name = old_name
		carry.player = current.player
		current.player.carry = carry
		current.player.add_child(carry)
		current.player.move_child(carry,index)
		return current
class Observe extends Node:
	var runner: Node
	var label := "after"
	func _physics_process(_delta: float) -> void:
		runner.observe(label,_delta)
	func _input(event: InputEvent) -> void:
		runner.input_ledger(event)
var suite: AuditNpc
var _last_carry := -1
var _active_level: Level
var _last_item: WeakRef
var _ledger: Array[Dictionary] = []
var _phase_by_label := {}
var _before_phase := -1
var _before_tick := -1
var _last_delta := 0.0
var _last_input_id := -1
func record_carry_event(value: Dictionary) -> void:
	_ledger.append(value)
func tracked_player() -> Player:
	if is_instance_valid(_active_level): return _active_level.player
	return suite.current.player if suite != null and is_instance_valid(suite.current) else null
func node_added(node: Node) -> void:
	if node is Level: _active_level = node
	if node is Player:
		node.ready.connect(func() -> void: node.interaction.changed.connect(func() -> void: facts("interaction_changed")),CONNECT_ONE_SHOT)
	if node is Throwable:
		var ref: WeakRef = weakref(node)
		_last_item = ref
		node.ready.connect(func() -> void:
			var item := ref.get_ref() as Throwable
			facts("crate_ready_before_pick")
			if item.health != null:
				item.health.damaged.connect(func(info: DamageInfo) -> void: item_event("damaged",ref,info))
			item.tree_exiting.connect(func() -> void: item_event("tree_exiting",ref)),CONNECT_ONE_SHOT)
func item_event(label: String, ref: WeakRef, info: DamageInfo = null) -> void:
	var item := ref.get_ref() as Throwable
	_ledger.append({"event":"item_"+label,"physics":Engine.get_physics_frames(),"process":Engine.get_process_frames(),"state":item.state if item != null else -1,"source":str(info.source_id) if info != null else "","stack":get_stack()})
func input_ledger(event: InputEvent) -> void:
	if event is InputEventKey and event.physical_keycode == KEY_SHIFT:
		if event.get_instance_id() == _last_input_id: return
		_last_input_id = event.get_instance_id()
		_ledger.append({"event":"shift_input","pressed":event.pressed,"physics":Engine.get_physics_frames(),"process":Engine.get_process_frames(),"paused":get_tree().paused,"physics_context":Engine.is_in_physics_frame()})
func facts(label: String) -> void:
	var player := tracked_player()
	if player == null: return
	var buttons := {}
	for action in [&"dash",&"melee",&"block",&"shoot",&"interact"]:
		buttons[str(action)] = [Input.is_action_pressed(action),Input.is_action_just_pressed(action)]
	var held := player.carry.held
	var last := _last_item.get_ref() as Throwable if _last_item != null else null
	var marker_facts: Array = []
	for marker: NpcActor in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if marker.cell.x == 24: marker_facts.append({"talking":marker._talking,"talk_count":marker.talk_count,"cooldown":marker._cooldown})
	_ledger.append({"event":label,"physics":Engine.get_physics_frames(),"process":Engine.get_process_frames(),"carry_phase":player.carry.phase,"carry_time":player.carry._phase_t,"held":is_instance_valid(held),"interaction":player.interaction.active,"paused":get_tree().paused,"buttons":buttons,"hp":player.health.current,"player_state":player.state,"last_item_state":last.state if last != null else -1,"object_position":str(held.global_position) if is_instance_valid(held) else "missing","visual_action":str(player._visual._interaction_input.action),"carry_hid_weapon":player._visual._carry_hid_weapon,"gun_visible":player._visual.rig.weapon_root().visible,"physics_context":Engine.is_in_physics_frame(),"scale":Engine.time_scale,"physics_rate":Engine.physics_ticks_per_second,"delta":_last_delta,"cinematic":str(Story._current_cinematic),"lock_count":GameplayLock._locks.size(),"base_paused":GameplayLock.base_paused(),"player_can_process":player.can_process(),"carry_can_process":player.carry.can_process(),"markers":marker_facts})
func observe(label: String, delta: float) -> void:
	_last_delta = delta
	var player := tracked_player()
	if player == null: return
	var phase := player.carry.phase
	if is_instance_valid(player.carry.held): _last_item = weakref(player.carry.held)
	if label == "before":
		_before_phase = phase
		_before_tick = Engine.get_physics_frames()
	if phase != int(_phase_by_label.get(label,-1)) or (label == "after" and _before_tick == Engine.get_physics_frames() and phase != _before_phase):
		facts(label+"_phase_change_from_"+str(_phase_by_label.get(label,-1)))
	_phase_by_label[label] = phase
func _run() -> void:
	if "--parse-only" in OS.get_cmdline_user_args():
		print("HOLSTER_PARSE_OK")
		get_tree().quit(0)
		return
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	for priority in [-100000,100000]:
		var observer := Observe.new()
		observer.runner = self
		observer.label = "before" if priority < 0 else "after"
		observer.process_physics_priority = priority
		observer.process_mode = Node.PROCESS_MODE_ALWAYS
		add_child(observer)
	get_tree().node_added.connect(node_added)
	Story.scene_started.connect(func(id: StringName,_mode: StringName) -> void: facts("scene_started_"+str(id)))
	Story.scene_finished.connect(func(id: StringName) -> void: facts("scene_finished_"+str(id)))
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--fps="): Engine.max_fps = int(arg.trim_prefix("--fps="))
	if "--schedule-grid" in OS.get_cmdline_user_args() or "--offset-grid" in OS.get_cmdline_user_args():
		var helper := load("res://work/ne277-contact-order/holster_neutral.gd") if "--neutral-key" in OS.get_cmdline_user_args() else preload("res://tests/helpers/interaction_holster_checks.gd")
		for entry in ([0,1,2,3,4,5,6,7] if "--offset-grid" in OS.get_cmdline_user_args() else [6,8,10,12,15,30,60]):
			var fps: int = 15 if "--offset-grid" in OS.get_cmdline_user_args() else entry
			Engine.max_fps = fps
			Engine.max_physics_steps_per_frame = 8
			_ledger.append({"event":"grid_begin","fps":fps,"offset":entry if "--offset-grid" in OS.get_cmdline_user_args() else 0})
			if "--offset-grid" in OS.get_cmdline_user_args(): await _frames(entry+1)
			suite = AuditNpc.new(self)
			suite._install_test_scenes()
			await helper.run(suite)
			suite._remove_test_scenes()
		Engine.max_fps = 0
		dump_ledger()
		await _finish()
		return
	if "--slow-render" in OS.get_cmdline_user_args():
		Engine.max_fps = 5
		Engine.max_physics_steps_per_frame = 8
	if "--exact-4" in OS.get_cmdline_user_args():
		await _run_suites("PropsSuite,EnvironmentSuite,AmmoIconsSuite,NpcSuite")
		dump_ledger()
		await _finish()
		return
	if "--prelude" in OS.get_cmdline_user_args():
		await PropsSuite.new(self).run()
		await EnvironmentSuite.new(self).run()
		await AmmoIconsSuite.new(self).run()
	suite = AuditNpc.new(self)
	if "--full-npc" in OS.get_cmdline_user_args():
		await suite.run()
		dump_ledger()
		await _finish()
		return
	suite._install_test_scenes()
	await preload("res://tests/helpers/interaction_holster_checks.gd").run(suite)
	suite._remove_test_scenes()
	dump_ledger()
	await _finish()
func dump_ledger() -> void:
	for entry in _ledger: print("HOLSTER_BUFFERED ",JSON.stringify(entry))
func _check(ok: bool, message: String) -> void:
	if message.contains("frozen carried-object") or message.contains("return from reading keeps"):
		facts("assertion_pass_"+str(ok)+"_"+message)
	super._check(ok,message)
