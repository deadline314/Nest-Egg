from pathlib import Path
import hashlib,json,subprocess,os,time,shutil,sys
ROOT=Path('D:/NestEggVerification/ticket-batch-20261111')
out=ROOT/'work/ne277-contact-order'/sys.argv[1];out.mkdir(exist_ok=False)
files=set(json.loads((Path(__file__).parents[1]/'ne277-timing-isolated/candidate-v4.json').read_bytes())['source_sha256'])
files.update(['tests/suite/test_audio.gd','tests/suite/test_heavy_enemies.gd','work/ne277-contact-order/regression_checks.gd','work/ne277-contact-order/regression_checks.tscn'])
files.update(['data/audio/stage_scenes.json','tools/sound_lab/stage_actions.gd','tools/sound_lab/lab_arena.gd'])
if '--holster' in sys.argv:files.update(['work/ne277-contact-order/holster_checks.gd','work/ne277-contact-order/holster_checks.tscn','tests/helpers/interaction_holster_checks.gd','game/player/player_carry.gd'])
if '--neutral-key' in sys.argv:files.add('work/ne277-contact-order/holster_neutral.gd')
if '--published-ready' in sys.argv:files.add('work/ne277-contact-order/holster_ready.gd')
if '--formal-proposal' in sys.argv:files.add('work/ne277-contact-order/holster_formal.gd')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={n:sha(ROOT/n) for n in sorted(files)}
for n in files:
 p=out/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/n,p)
shutil.copyfile(__file__,out/'executed-runner.py')
cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--audio-driver','Dummy','--path',str(ROOT),'res://work/ne277-contact-order/regression_checks.tscn','--','--out='+str(out)]
if '--old-recovery' in sys.argv:cmd.append('--old-recovery')
if '--holster' in sys.argv:cmd[6]='res://work/ne277-contact-order/holster_checks.tscn'
if '--slow-render' in sys.argv:cmd.append('--slow-render')
for flag in ['--original-carry','--full-npc','--prelude','--exact-4','--schedule-grid','--offset-grid','--quiet-pick','--neutral-key','--published-ready','--formal-proposal','--parse-only']:
 if flag in sys.argv:cmd.append(flag)
cmd += [flag for flag in sys.argv if flag.startswith('--fps=')]
(out/'command.json').write_bytes(json.dumps(cmd).encode())
env=dict(os.environ,APPDATA=str(out/'user'),LOCALAPPDATA=str(out/'local'))
start=time.monotonic()
with (out/'process.log').open('wb') as f:
 p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 try:code=p.wait(timeout=240)
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True);code=124
after={n:sha(ROOT/n) for n in files}
text=(out/'process.log').read_text(encoding='utf-8',errors='replace')
receipt={'before':before,'after':after,'same_source':before==after,'exit':code,'seconds':time.monotonic()-start,'runner_sha256':sha(Path(__file__))}
(out/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in receipt.items() if k not in ['before','after']}));print(text[-4000:])
sys.exit(code)
