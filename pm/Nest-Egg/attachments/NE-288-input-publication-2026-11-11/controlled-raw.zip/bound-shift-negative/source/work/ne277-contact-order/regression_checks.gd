extends "res://tests/smoke_test.gd"
class OldRecovery extends MeleeModule:
	func _enter_recovery() -> void:
		_recovery_pose_from = POSE_RECOVERY_FROM
		phase = Phase.RECOVERY
		time = 0.0
class OldRecoverySuite extends MeleeWeaponsSuite:
	func open_level(player_tile := 10.0, difficulty_index := 1) -> Level:
		var result := await super.open_level(player_tile, difficulty_index)
		var old := result.player.melee
		result.player.remove_child(old)
		old.queue_free()
		result.player.melee = OldRecovery.new(result.player)
		result.player.add_child(result.player.melee)
		return result
class StageProbe extends StageSuiteBase:
	func run() -> void:
		await _open_stage()
		Engine.time_scale = 1.5
		check(await _stage.run_scene("wpn_glaive_light_hit"), "real glaive-hit sound stage completes")
		check(_stage.recorded_unique().has("melee_glaive_hit"), "real glaive-hit sound stage produces actual hit audio")
		await _close_stage()
var suite: EnemySuiteBase
var label := ""
var ledger: Array[Dictionary] = []
var out := ""

func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	process_physics_priority = 100000
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): out = arg.trim_prefix("--out=")
	if "--old-recovery" in OS.get_cmdline_user_args():
		await OldRecoverySuite.new(self)._test_sustain_release_pose()
		await _finish()
		return
	label = "reach"
	suite = MeleeSuite.new(self)
	await suite._test_visual_reach()
	label = "audio"
	suite = AudioSuite.new(self)
	await suite._test_melee_weapon_sounds()
	label = "late"
	suite = MeleeWeaponsSuite.new(self)
	await suite._test_single_hit_and_windows()
	await suite._test_sustain_release_pose()
	label = "platform"
	suite = HeavyEnemiesSuite.new(self)
	await suite._test_platform_strike_contact()
	suite = null
	await StageProbe.new(self).run()
	var file := FileAccess.open(out.path_join("regression-ledger.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(ledger))
	file.close()
	await _finish()

func vec(v: Vector2) -> Array:
	return [v.x, v.y]

func _physics_process(_delta: float) -> void:
	if suite == null or not is_instance_valid(suite.level) or not is_instance_valid(suite.level.player): return
	var p := suite.level.player
	if p.melee.phase != MeleeModule.Phase.ACTIVE: return
	var held := p._visual.melee_held()
	var chest := p.global_position + Vector2(0, -Player.BODY_SIZE.y * 0.55)
	var row := {"label":label, "tick":Engine.get_physics_frames(), "def":p.melee.attack, "time":p.melee.time, "progress":p.melee.pose_progress(), "visual_t":p._visual._input.action_t, "position":vec(p.global_position), "chest":vec(chest), "tip":vec(held.tip_point()), "hand":vec(held.hold().origin), "direction":vec(p.melee.swing_direction), "reach":(held.tip_point()-chest).dot(p.melee.swing_direction), "facing":p.facing}
	if label == "platform":
		var geo := held.contact_sweep()
		var points: Array = []
		for point: Vector2 in geo.current: points.append(vec(point))
		row["current"] = points
		row["nominees"] = p.melee.targets(p.melee.attack).size()
		row["enemies"] = []
		for n in get_tree().get_nodes_in_group(&"enemies"):
			if not n is Enemy: continue
			var e := n as Enemy
			row["enemies"].append({"position":vec(e.global_position), "center":vec(e.hurtbox.center()), "size":vec(e.hurtbox._shape.size), "contact":vec(held.contact_point(e.hurtbox)), "hp":e.health.current})
	ledger.append(row)
