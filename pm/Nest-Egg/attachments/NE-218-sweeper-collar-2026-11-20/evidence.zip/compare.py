from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import binary_fill_holes

base = Path(__file__).resolve().parent
root = Path.cwd()
read = lambda path: json.loads((base / path).read_bytes())
s, c = (read(f"whole-{variant}/run.json") for variant in ("stock", "candidate"))
assert s == {"exit":0,"audit_exit":1,"samples":26880,"failed":46,"edge_notch_only":30,"enclosed":16,"loose":0,"engine_errors":[]}
assert c == {**s, "failed":30,"enclosed":0}
reports = [read(f"whole-{variant}/frames/report.json") for variant in ("stock","candidate")]
key = lambda row: (row["joint"], row["pose"], row["zoom"], row["facing"], row["frame"])
old = {key(row): row for row in reports[0]["failures"]}
new = {key(row): row for row in reports[1]["failures"]}
new_flags = sorted(new.keys() - old.keys())
closed = [row for row in old.values() if row["enclosed_pixels"] > 0]
print("new", [(k, new[k]["hole_pixels"], new[k]["enclosed_pixels"], new[k]["center_alpha"]) for k in new_flags])
assert all(row["joint"] == "neck" and row["pose"] == "dead" for row in closed)
assert all(row["diagnostic_part_texture"] == "" for row in list(old.values())+list(new.values()))
def alpha_crop(variant, row):
    x,y,w,h = row["rect"]
    r = row["radius"]
    center_x,center_y = x+w//2,y+h//2
    frame = base / f"whole-{variant}/frames" / row["file"]
    with Image.open(frame) as sample:
        crop = sample.crop((center_x-r,center_y-r,center_x+r,center_y+r)).convert("RGBA")
        return np.asarray(crop)[:,:,3]

edge_comparisons = []
for flag in new_flags:
    row = new[flag]
    stock_alpha = alpha_crop("stock", row)
    candidate_alpha = alpha_crop("candidate", row)
    stock_solid = stock_alpha >= 128
    candidate_solid = candidate_alpha >= 128
    assert not (stock_solid & ~candidate_solid).any()
    flagged = binary_fill_holes(candidate_solid) & ~candidate_solid
    assert flagged.any() and not (flagged & stock_solid).any()
    edge_comparisons.append({"flag":flag,"flagged_pixels":int(flagged.sum()),
                             "stock_pixels_lost":0,"coverage_gained":int((candidate_solid & ~stock_solid).sum())})
variants = ("stock","candidate")
rows = [read(f"street-{variant}/street.json") for variant in variants]
assert all(r["hdr_2d"] and r["rendering_method"] == "forward_plus" and "9070 XT" in r["adapter"] for r in rows)
for x, y in zip(rows[0]["rows"], rows[1]["rows"], strict=True):
    assert x == y, (x,y)
assert len(rows[0]["rows"]) == 28

old_src = np.asarray(Image.open(root / "art_src/characters/sweeper/07_refined/torso.png").convert("RGBA"))
new_src = np.asarray(Image.open(root / "art_src/characters/sweeper/overrides/refined/torso.png").convert("RGBA"))
diff = lambda a,b: int(np.count_nonzero(np.any(a != b,axis=2)))
loc = tuple(np.asarray(np.where(np.any(new_src != old_src,axis=2))).tolist())
assert len(loc[0]) == 439 and np.array_equal(old_src[old_src[:,:,3]>=128],new_src[old_src[:,:,3]>=128])
paths = base / "preinstall"
runtime = root / "art/characters/sweeper/parts"
old_diff, new_diff = (np.asarray(Image.open(path / "torso.png").convert("RGBA")) for path in (paths,runtime))
old_norm, new_norm = (np.asarray(Image.open(path / "torso_n.png").convert("RGBA")) for path in (paths,runtime))
assert old_diff.shape == new_diff.shape == old_norm.shape == new_norm.shape == (325,258,4)
check = {"source_pixels":diff(old_src,new_src),"diffuse_pixels":diff(old_diff,new_diff),"normal_pixels":diff(old_norm,new_norm),
         "unchanged_solid_source":True,"edge_comparisons":edge_comparisons,"enclosed_holes_removed":[key(row) for row in closed],
         "reference_render_size":[1280,720],"authored_frames_matched":len(rows[0]["rows"])}
(base / "compare.json").write_text(json.dumps(check,indent=2)+"\n")
print(check)

font = ImageFont.truetype("C:/Windows/Fonts/segoeui.ttf",16)
phases = ("aim","death_05","death_11","death_19")
sheet = Image.new("RGB", (924,624), "#101923")
canvas = ImageDraw.Draw(sheet)
for col, phase in enumerate(phases):
    canvas.text((110+202*col,10),phase.replace("_"," "),font=font,fill="#e2eef5")
for row_idx, (face, variant) in enumerate((("left","stock"),("left","candidate"),("right","stock"),("right","candidate"))):
    canvas.text((7,49+146*row_idx),f"{face} {variant}",font=font,fill="#e2eef5")
    by_key = {row["key"]:row for row in rows[variants.index(variant)]["rows"]}
    for col, phase in enumerate(phases):
        stem = f"{face}_340_{phase}"
        item = by_key[stem]
        frame = Image.open(base / f"street-{variant}" / (stem+".png")).convert("RGB")
        x = round(item["screen_head"][0]*frame.width/640)
        y = round(item["screen_head"][1]*frame.height/360)
        crop=frame.crop((x-95,y-59,x+95,y+81))
        sheet.paste(crop,(106+202*col,33+146*row_idx))
sheet.save(base / "street-collar-contact.png")




