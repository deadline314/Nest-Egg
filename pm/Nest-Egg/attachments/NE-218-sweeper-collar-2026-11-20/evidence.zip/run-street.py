from pathlib import Path
import os
import subprocess
import sys

base = Path(__file__).resolve().parent
label = sys.argv[1]
folder = base / label
folder.mkdir()
profile = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    child = folder / key
    child.mkdir()
    profile[key] = str(child)
godot = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
root = Path.cwd()
with (folder / "engine.log").open("wb") as log:
    if label == "native-normal-c":
        command = [godot, "--headless", "--path", str(root), "--quit-after", "120", str(base / "normals.tscn"),
                   "--", f"--source={base / 'patch-c/torso.png'}", f"--out={base / 'patch-c/candidate-normal-native.png'}"]
    else:
        command = [sys.executable, "-B", str(root / "tools/comfyui/gpu_lock.py"), "--", godot, "--path", str(root),
                   "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--fixed-fps", "60",
                   "--audio-driver", "Dummy", "--resolution", "1280x720", "--quit-after", "1800", str(base / "street.tscn"),
                   "--", f"--out={folder}"]
    result = subprocess.run(command, env=profile, stdout=log, stderr=subprocess.STDOUT, timeout=230)
raw = (folder / "engine.log").read_text(encoding="utf-8", errors="replace")
print(raw[-8000:])
assert result.returncode == 0 and not any(x in raw for x in ("SCRIPT ERROR:", "Parse Error"))
if label != "native-normal-c":
    assert (folder / "street.json").is_file()
