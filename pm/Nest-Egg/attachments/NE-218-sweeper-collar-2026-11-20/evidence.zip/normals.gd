extends Node

func _ready() -> void:
	var out := ""
	var input := ""
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--source="):
			input = argument.trim_prefix("--source=")
		if argument.begins_with("--out="):
			out = argument.trim_prefix("--out=")
	var source := Image.load_from_file(input)
	if source == null or not out.is_absolute_path():
		push_error("The scoped normal bake needs a valid source and absolute output.")
		get_tree().quit(1)
		return
	var result := NormalMapMaker.make(source).save_png(out)
	print("SWEEPER_NORMAL_GENERATION ", result)
	get_tree().quit(0 if result == OK else 1)
