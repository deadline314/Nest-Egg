from pathlib import Path
from hashlib import sha256
import json
import os
import re
import subprocess
import sys

scope = Path(__file__).resolve().parent
project = Path.cwd()
label = sys.argv[1]
run = scope / label
run.mkdir()
native = run / "frames"
native.mkdir()
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME"):
    item = run / key
    item.mkdir()
    env[key] = str(item)
tiles = ("art/characters/sweeper/character.json", "art/characters/sweeper/parts/head.png",
         "art/characters/sweeper/parts/torso.png", "art/rigs/sweeper.json", "tools/rig_joint_audit.gd")
identity = {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
            "files": {name: sha256((project / name).read_bytes()).hexdigest() for name in tiles}}
(run / "input.json").write_text(json.dumps(identity, indent=2) + "\n")
command = [sys.executable, "-B", str(project / "tools/comfyui/gpu_lock.py"), "--",
           "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(project),
           "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--audio-driver", "Dummy",
           "--resolution", "1280x720", "res://tools/rig_joint_audit.tscn", "--",
           "--out=" + str(native), "--chars=sweeper", "--joints=neck,shoulder_front,shoulder_back", "--frames=60", "--zooms=1,3.4"]
command.extend(sys.argv[2:])
(run / "command.json").write_text(json.dumps(command, indent=2) + "\n")
with (run / "engine.log").open("wb") as log:
    result = subprocess.run(command, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=420)
raw = (run / "engine.log").read_text("utf-8", errors="replace")
errors = [line for line in raw.splitlines() if re.search(r"^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit", line)]
assert result.returncode == 0 and not errors and (native / "frames.json").is_file(), (result.returncode, errors)
with (run / "audit.log").open("wb") as log:
    check = subprocess.run([sys.executable, str(project / "tools/check_joint_frames.py"), str(native)],
                           cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
document = json.loads((native / "report.json").read_bytes())
assert check.returncode in (0, 1) and document["samples"] > 0
result = {"exit": result.returncode, "audit_exit": check.returncode, "samples": document["samples"],
          "failed": document["failed_samples"], "edge_notch_only": document["edge_notch_only_samples"],
          "enclosed": sum(item["enclosed_pixels"] > 0 for item in document["failures"]),
          "loose": sum(item["loose_pieces"] > 0 for item in document["failures"]), "engine_errors": errors}
(run / "run.json").write_text(json.dumps(result, indent=2) + "\n")
print(result)
