extends Node

const Capture := preload("res://tools/viewport_capture.gd")


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://disposed_dialogue_probe.cfg")
	Settings.set_reduce_ui_motion(true)
	Story.set_language("en")
	var root := get_tree().root
	var live := DialogueLayer.new()
	var leaving := DialogueLayer.new()
	root.add_child(live)
	root.add_child(leaving)
	var line: Array[Dictionary] = [
		{"name": "Wick", "color": Color.CYAN, "text": "Wait by the door.", "portrait": ""},
	]
	live.enqueue_radio(&"live", line)
	leaving.enqueue_radio(&"leaving", line)
	var visible_before := DialogueLayer.radio_visible() and live._radio_root.visible and leaving._radio_root.visible
	root.remove_child(leaving)
	var original_frame: Rect2 = live._safe_rect
	Story.framing.reset()
	var disposed := not leaving.is_inside_tree() and not leaving._laying_out
	var live_ready := DialogueLayer.radio_visible() and live._radio_root.visible and live._safe_rect != Rect2()
	var failures := int(not visible_before) + int(not disposed) + int(not live_ready)
	print("DETACHED_RADIO visible_before=%s disposed=%s live_ready=%s original_frame=%s updated_frame=%s" %
		[str(visible_before), str(disposed), str(live_ready), original_frame, live._safe_rect])
	var checks := 3
	var args := OS.get_cmdline_user_args()
	if DisplayServer.get_name() != "headless" and args.size() == 1:
		for i in 90:
			if live._radio_text.visible_ratio >= 1.0:
				break
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		checks += 1
		if not live._radio_root.visible or live._radio_text.visible_ratio < 1.0 \
				or Capture.image(get_viewport()).save_png(args[0]) != OK:
			failures += 1
	print("checks: %d, failures: %d" % [checks, failures])
	leaving.free()
	live.queue_free()
	await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(failures != 0))
