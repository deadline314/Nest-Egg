from pathlib import Path
import json,os,re,shutil,subprocess,sys
from hashlib import sha256

here=Path(__file__).resolve().parent
root=Path.cwd()
project=Path(sys.argv[1]).resolve()
label,size=sys.argv[2:4]
out=here/label
out.mkdir()
slot=out/'save/slot.json'
slot.parent.mkdir()
orig=root/'work/ne97-campaign-route-20261119/native-camera-fresh-close-v1/save/slot.json'
shutil.copyfile(orig,slot)
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
    (out/key).mkdir()
    env[key]=str(out/key)
command=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
    '--path',str(project),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
    '--resolution',size,'--fixed-fps','60','--quit-after','800',str(here/'phone.tscn'),'--',
    '--out='+str(out),'--save-dir='+str(slot.parent)]
with (out/'engine.log').open('wb') as log:
    proc=subprocess.run(command,cwd=project,env=env,timeout=180,stdout=log,stderr=subprocess.STDOUT)
log=(out/'engine.log').read_text('utf-8',errors='replace')
errors=[line for line in log.splitlines() if re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|^FAIL |leaked at exit',line)]
p=out/'phone.json'
receipt={'input_save':sha256(orig.read_bytes()).hexdigest(),'exit':proc.returncode,'errors':errors,
         'resolution':json.loads(p.read_bytes()) if p.is_file() else {}}
(out/'run.json').write_text(json.dumps(receipt,indent=2)+'\n')
print({"exit":receipt["exit"],"errors":receipt["errors"],"failures":receipt["resolution"].get("failures"),"samples":len(receipt["resolution"].get("samples",[]))},flush=True)
assert proc.returncode==0 and not errors and receipt['resolution']['failures']==0
