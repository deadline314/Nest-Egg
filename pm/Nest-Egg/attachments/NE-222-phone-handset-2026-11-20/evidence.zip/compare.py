from pathlib import Path
import json
from PIL import Image

here = Path(__file__).resolve().parent
before, after = (here / name for name in ('original-alley', 'candidate-alley'))
reports = [json.loads((folder / 'run.json').read_bytes()) for folder in (before, after)]
assert reports[0]['input_save'] == reports[1]['input_save']
assert all(rep['exit'] == 0 and rep['errors'] == [] and rep['resolution']['failures'] == 0 for rep in reports)
old, new = [rep['resolution']['samples'] for rep in reports]
assert len(old) == len(new) == 130
matching = old[0].keys() - {'weapon', 'face'}
assert all(all(a[key] == b[key] for key in matching) for a, b in zip(old, new, strict=True))
assert all(abs(row['progress'] - row['visual_progress']) < 1e-10 for row in new if row['on_phone'])

stats = {}
for label, face, held_afterward in (('reload', 1, 'pistol.png'), ('switch', -1, 'rifle.png')):
    original_rows = [row for row in old if row['case'] == label]
    candidate_rows = [row for row in new if row['case'] == label]
    assert all(row['face'] == face for row in original_rows + candidate_rows if row['on_phone'])
    assert sum(row['booth_out'] for row in original_rows) == sum(row['booth_out'] for row in candidate_rows)
    def bad(rows):
        return [row for row in rows if row['booth_out'] and row['weapon'] != 'handset.png']
    errors_before, errors_after = bad(original_rows), bad(candidate_rows)
    assert errors_before and not errors_after
    assert all(row['weapon'] == '' for row in candidate_rows if row['on_phone'] and not row['booth_out'])
    assert candidate_rows[-1]['weapon'] == held_afterward and candidate_rows[-1]['activated']
    stats[label] = {'samples': len(candidate_rows), 'face': face,
                    'handset_off_hook_samples': sum(row['booth_out'] for row in candidate_rows),
                    'wrong_visual_before': len(errors_before), 'wrong_visual_after': len(errors_after),
                    'first_wrong_progress': errors_before[0]['progress'],
                    'normal_weapon_at_end': candidate_rows[-1]['weapon'],
                    'free_aim_facing_at_end': [original_rows[-1]['face'], candidate_rows[-1]['face']]}
    for rows, folder in ((original_rows, before), (candidate_rows, after)):
        for frame in ('pickup', 'middle', 'ready'):
            row = next(row for row in rows if row['name'] == f'{label}-{frame}')
            assert (folder / f'{row["name"]}.png').is_file()

# The booth anchors each 1:1 crop because the live camera starts at a different offset.
areas = {'reload': ((70, 252), (70, 276)), 'switch': ((466, 266), (488, 226))}
plate = Image.new('RGB', (436, 476), (16, 21, 35))
for row, label in enumerate(('reload', 'switch')):
    for column, folder in enumerate((before, after)):
        with Image.open(folder / f'{label}-middle.png') as image:
            assert image.size == (1280, 720)
            x, y = areas[label][column]
            crop = image.crop((x, y, x + 216, y + 236)).convert('RGB')
        plate.paste(crop, (column * 220, row * 240))
plate.save(here / 'phone-comparison.png')
(here / 'comparison.json').write_text(json.dumps(stats, indent=2) + '\n')
print(json.dumps(stats, indent=2))