extends "res://tools/ch1_flow_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
var _store := ""
var _main: Node
var _player: Player
var _booth: Checkpoint
var _samples: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.id == &"ch1_street", "the ordinary street save continues")
	if _level == null or _level.player == null:
		_finish_phone()
		return
	var portal: Portal
	for node: Node in _level.find_children("*", "Area2D", true, false):
		if node is Portal and node.data.id == &"street_booth":
			portal = node
			break
	_check(portal != null, "find the original street route to the booth alley")
	if portal == null:
		_finish_phone()
		return
	_level._on_portal_used(portal)
	await _settle(65)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.id == &"ch1_booth_alley", "main loads the original booth alley")
	if _level == null or _level.player == null:
		_finish_phone()
		return
	_player = _level.player
	for node: Node in _level.find_children("*", "Area2D", true, false):
		if node is Checkpoint and (_booth == null or _player.global_position.distance_to(node.global_position) < _player.global_position.distance_to(_booth.global_position)):
			_booth = node
	_check(_booth != null, "use the original booth on the alley map")
	if _booth == null:
		_finish_phone()
		return
	_player.loadout.equip(load("res://data/weapons/rifle.tres") as WeaponData)
	_player.loadout.select(Loadout.PRIMARY)
	await _case("reload", 1, false)
	await _case("switch", -1, true)
	_finish_phone()


func _case(label: String, face: int, switch_weapon: bool) -> void:
	_player.global_position = _booth.global_position + Vector2(-23.0 * face, -1.0)
	_level.camera.snap_to_target()
	await _settle(28)
	_check(_booth.can_dial(), label+" uses the active booth target through normal proximity")
	var primary := _player.loadout.active_slot
	var before := _player.loadout.mag_in(primary)
	AimInput.set_virtual_gamepad(_player, true)
	var aim := &"aim_right" if face > 0 else &"aim_left"
	Input.action_press(aim)
	Input.action_press(&"shoot")
	for i in 15:
		await _settle(1)
		if _player.loadout.mag_in(primary) < before:
			break
	Input.action_release(&"shoot")
	Input.action_release(aim)
	AimInput.set_virtual_gamepad(_player, false)
	_check(_player.loadout.mag_in(primary) < before, label+" fires a real shot before the call")
	await _send(&"reload")
	_check(_player.is_reloading(), label+" starts a real reload before dialing")
	Input.action_press(&"interact")
	for i in 6:
		await _settle(1)
		if _player.is_on_phone():
			break
	Input.action_release(&"interact")
	_check(_player.is_on_phone() and _booth.is_calling() and _player.facing == face, label+" enters the real booth interaction on the requested side")
	var switched := false
	var taken := false
	var later := false
	for i in 90:
		if not _player.is_on_phone():
			break
		var progress := _player.phone_progress()
		if switch_weapon and not switched and progress > 0.46:
			await _send(&"weapon_next")
			switched = true
		var filename := ""
		if not taken and progress > 0.32:
			taken = true
			filename = label+"-pickup"
		elif not later and progress > (0.54 if switch_weapon else 0.82):
			later = true
			filename = label+"-middle"
		await _observe(label, filename)
		await _settle(1)
	_check(taken and later and not _player.is_on_phone() and _booth.activated, label+" reaches pickup, call, and original checkpoint completion")
	if switch_weapon:
		_check(switched and _player.loadout.active_slot != primary, "mid-call equipment change reaches the actual loadout")
	await _settle(14)
	await _observe(label, label+"-ready")


func _send(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await _settle(1)
	var released := InputEventAction.new()
	released.action = action
	Input.parse_input_event(released)
	await _settle(1)


func _observe(label: String, name: String) -> void:
	await RenderingServer.frame_post_draw
	var visual := _player._visual
	var rig := visual.rig
	_samples.append({"case":label,"name":name,"progress":_player.phone_progress(),"visual_progress":visual.phone_progress(),
		"on_phone":_player.is_on_phone(),"booth_out":_booth._handset_out,"weapon":str(rig.weapon_def().get("file","")),
		"equipped":str(_player.loadout.active_weapon().id),"reload":_player.is_reloading(),"face":_player.facing,"activated":_booth.activated})
	if not name.is_empty():
		_check(CAPTURE.image(get_viewport()).save_png(_out_dir.path_join(name+".png")) == OK,"save native "+name)


func _finish_phone() -> void:
	var f := FileAccess.open(_out_dir.path_join("phone.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"failures":_failures,"samples":_samples},"  ")+"\n")
	f.close()
	_main.call("_quit",0 if _failures==0 else 1)
