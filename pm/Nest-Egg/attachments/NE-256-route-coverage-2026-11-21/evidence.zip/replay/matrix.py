
from pathlib import Path
import json,math,collections

base=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_bytes())
phases=('fresh','street','blockade','watchdog','flood','vault-obtain','vault','handoff')
result={}
for phase in phases:
    sides={}
    rows={}
    for view in ('close','wide'):
        attempts={}
        for suffix in ('','-retry','-defend','-guided','-vault-defend'):
            folder=base/f'{phase}-{view}{suffix}'
            if (folder/'summary.json').is_file():
                attempts[folder.name]=read(folder/'summary.json')
        if not attempts:
            continue
        ordered=list(reversed(attempts))
        picked=next((k for k in ordered if attempts[k]['exit']==0 and attempts[k]['clean_log']),ordered[0])
        folder=base/picked
        receipt=attempts[picked]
        if receipt['exit']!=0 or not receipt['clean_log'] or not receipt['renderer_confirmed'] or not receipt.get('end'):
            sides[view]={'receipt':receipt,'status':'failed','attempts':attempts}
            continue
        report=read(folder/'camera-observations.json')
        areas=report['visited']
        assert all(v in (1.5,1.92) for v in areas.values())
        shots=[x for x in report['damage'] if x.get('shot_match')=='exact']
        jumps=[x for x in report['landings'] if x['jump']]
        drops=[x for x in report['landings'] if not x['jump']]
        threats=report['windups']
        rows[view]=report
        sides[view]={
            'folder':folder.name,'attempts':attempts,'areas':areas,'checks':receipt['checks'],
            'jumps':[len(jumps),sum(r['visible_before_takeoff'] for r in jumps)],
            'drops':[len(drops),sum(r['visible_before_takeoff'] for r in drops)],
            'jump_misses':[r for r in jumps if not r['visible_before_takeoff']],
            'drop_misses':[r for r in drops if not r['visible_before_takeoff']],
            'damage_ambiguous':[x for x in report['damage'] if x.get('shot_match')!='exact' and x.get('attacker')=='unknown'],
            'damage_sources':dict(collections.Counter(x['source'] for x in report['damage'])),
            'damage_offscreen':[x for x in report['damage'] if x.get('attacker')=='outside' or 'frames_of_visible_lead' in x and x.get('shot_match')=='exact' and x['frames_of_visible_lead']<1],
            'threat_prompt_misses':[x for x in threats if not x['visible']],
            'missile_warning_lead':[x['warning_visible_frames'] for x in report['damage'] if x.get('warning_match')],
            'projectile_first_visible_lead':[x['frames_of_visible_lead'] for x in shots if 'frames_of_visible_lead' in x],
            'windup_lead':[x['first_visible_frames'] for x in threats if x['visible'] and x['first_visible_frames']>=0],
        }
    if {'close','wide'}==rows.keys():
        pool=list(rows['wide']['landings'])
        comparable=[]
        for a in rows['close']['landings']:
            options=[(math.dist(a['from'],b['from'])+math.dist(a['landing'],b['landing']),i,b)
                     for i,b in enumerate(pool) if a['jump']==b['jump'] and a['area']==b['area']]
            if not options:
                continue
            distance,i,b=min(options,key=lambda x:x[0])
            if distance>18:
                continue
            del pool[i]
            comparable.append({'close':a,'wide':b,'world_distance_sum':distance})
        sides['paired_landings']=comparable
    result[phase]=sides
for phase,cases in result.items():
    for view in ('close','wide'):
        row=cases.get(view)
        if not row:
            continue
        if 'receipt' in row:
            print(phase,view,row['receipt'])
            continue
        print(phase,view,sorted(row['areas']), 'jumps',row['jumps'], 'drops',row['drops'],
              'projectile lead',row['projectile_first_visible_lead'],'immediate/offscreen',len(row['damage_offscreen']),
              'ambiguous',len(row['damage_ambiguous']))
        for miss in row['jump_misses']:
            print(' jumping landing not in view',miss)
    if 'paired_landings' in cases:
        print(' ',len(cases['paired_landings']),'matched movement segments')
(base/'matrix.json').write_text(json.dumps(result,indent=2)+'\n')

