
from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json,os,re,subprocess,sys

repo=Path.cwd()
base=Path(__file__).resolve().parent
shared=base.parent/'ne218-baseline-20261117'
prior=repo/'work/ne97-campaign-route-20261119'
scripts=base
prev=base.parent/'evidence-20261121-st19-radio-feedback'
comm=json.loads((prev/'publish/result.json').read_bytes())['commit']
manifest=json.loads((prev/'published-source.json').read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=shared).decode().strip()==comm
sha=lambda p:sha256(p.read_bytes()).hexdigest()
assert all(sha(shared/p)==digest for p,digest in manifest.items())
phases={
    'fresh': (None,['--fresh','--camera-settle']),
    'street': ('camera-ch1-start-seed',['--from-save','--street','--camera-settle']),
    'blockade': ('native-camera-street-ledges-close-v1',['--from-save','--blockade','--camera-settle']),
    'watchdog': ('native-blockade-v3',['--from-save','--warehouse','--camera-settle']),
    'flood': ('native-flood-v2',['--from-save','--raft','--camera-settle']),
    'vault': ('native-upper-vault-v2',['--from-save','--vault-bridge','--camera-settle']),
    'vault-obtain': ('native-raft-v2',['--from-save','--vault','--camera-settle','--difficulty-audit']),
    'handoff': ('native-vault-bridge-v1',['--from-save','--handoff']),
}
for arg in sys.argv[1:]:
    phase,view=arg.split(':',1)
    assert phase in phases and view in ('close','wide')
    seed,flags=phases[phase]
    current=base/f'{phase}-{view}-retry'
    (current/'slot').mkdir(parents=True)
    path=prior/seed/'save/slot.json' if seed else None
    digest=sha(path) if path else None
    if path:
        copyfile(path,current/'slot/slot.json')
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
        folder=current/'profile'/key
        folder.mkdir(parents=True)
        env[key]=str(folder)
    invocation=[sys.executable,'-B',str(shared/'tools/comfyui/gpu_lock.py'),'--',
                'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(shared),
                '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
                '--resolution','1280x720','--fixed-fps','60','--quit-after','21300',str(scripts/'route-retry.tscn'),'--',
                '--camera-audit','--camera-projectile-audit','--out='+str(current),'--save-dir='+str(current/'slot'),*flags]
    if view=='wide':
        invocation.append('--camera-wide')
    (current/'command.json').write_text(json.dumps({'argv':invocation,'commit':comm,'source_save':str(path) if path else None,'seed_sha256':digest},indent=2)+'\n')
    with (current/'engine.log').open('wb') as log:
        try:
            result=subprocess.run(invocation,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=235).returncode
        except subprocess.TimeoutExpired:
            result=124
    raw=(current/'engine.log').read_text(encoding='utf-8',errors='replace')
    report=current/'camera-observations.json'
    native='RX 9070 XT' in raw and 'Forward+' in raw
    clean=not re.search(r'^ERROR:|^SCRIPT ERROR:',raw,re.M)
    receipt={'exit':result,'renderer_confirmed':native,'clean_log':clean,'checks':sum(line.startswith('PASS ') for line in raw.splitlines()),'end': [line for line in raw.splitlines() if 'failures=' in line][-2:]}
    if report.exists():
        data=json.loads(report.read_bytes())
        receipt.update(areas=data['visited'],jumps=len(data['landings']),damage=len(data['damage']))
    (current/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(arg,receipt,flush=True)
    assert not path or sha(path)==digest
assert all(sha(shared/p)==digest for p,digest in manifest.items())

