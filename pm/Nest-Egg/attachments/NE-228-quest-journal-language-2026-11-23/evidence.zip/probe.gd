extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const PAGES := {"zh": "任務", "ja": "クエスト", "en": "Quests"}
const PIN := {"zh": "釘選這項任務", "ja": "追跡する", "en": "Track quest"}
const UNPIN := {"zh": "取消釘選", "ja": "追跡を解除", "en": "Stop tracking"}
const FILTER := {"zh": "進行中", "ja": "進行中", "en": "Active"}
const DETAIL := {"zh": "背景", "ja": "背景", "en": "Background"}
const DESTINATION := {"zh": "前往", "ja": "地図を開く", "en": "Open map"}

var _failed := 0
var _checks := 0
var _output := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_output = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://quest-journal-probe.cfg")
	Settings.set_ui_text_scale(1.2)
	Story.set_language("zh")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_prologue_exit", true, false)
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(load("res://data/levels/ch1_pawnshop.tres") as LevelData)
	add_child(level)
	await _frames(25)
	await _key(KEY_O)
	var map: QuestMapScreen = level._pause_menu._navigation
	_check(is_instance_valid(map) and map._page == "quests", "Quest shortcut opens the original pause-menu journal")
	if not is_instance_valid(map):
		get_tree().quit(1)
		return
	var quest := map._selected
	_check(not quest.is_empty() and not map.catalog.find(quest).is_empty(), "The selected quest comes from the formal campaign")
	for lang in ["zh", "ja", "en"]:
		Story.set_language(lang)
		await _frames(4)
		var tab := map._tabs.get_child(1) as Button
		var pin := map._actions.get_child(0) as Button
		var jump := map._actions.get_child(1) as Button
		_check(tab != null and tab.text == PAGES[lang], "%s journal tab is localized" % lang)
		_check(map._buttons[0].text.begins_with(FILTER[lang]), "%s active filter is localized" % lang)
		_check(map._details.find_children("*", "Label", true, false).any(func(label: Label) -> bool:
			return label.text == DETAIL[lang]), "%s detail section is localized" % lang)
		_check(pin != null and pin.text == PIN[lang] and jump != null and jump.text.contains(DESTINATION[lang]),
			"%s tracking and destination actions are localized" % lang)
		if lang != "zh":
			_check(map.get_viewport().gui_get_focus_owner() == pin, "%s keeps tracking focus after rebuilding" % lang)
		_check(map._selected == quest, "%s keeps the same quest" % lang)
		pin.grab_focus()
		await _frames(2)
		_check(map._status.text == pin.tooltip_text and not pin.tooltip_text.is_empty(),
			"%s focus reads the same hint as Hover" % lang)
		await _confirm(lang == "en")
		pin = map._actions.get_child(0) as Button
		_check(map.state.pinned_id == quest and pin.text == UNPIN[lang], "%s confirms real tracking" % lang)
		await _confirm(lang == "en")
		pin = map._actions.get_child(0) as Button
		_check(map.state.pinned_id.is_empty() and map.get_viewport().gui_get_focus_owner() == pin,
			"%s clears tracking and keeps the same action focused" % lang)
		if lang == "en" and DisplayServer.get_name() != "headless":
			await RenderingServer.frame_post_draw
			_check(Capture.image(get_viewport()).save_png(_output.path_join("journal.png")) == OK,
				"The original English quest journal is captured")
	var land := map._actions.get_child(1) as Button
	land.grab_focus()
	await _confirm(true)
	_check(map._page == "region", "Destination action opens its actual area map")
	await _joy(JOY_BUTTON_B)
	land = map._actions.get_child(1) as Button
	_check(map._page == "quests" and map._selected == quest and map.get_viewport().gui_get_focus_owner() == land,
		"Back restores the original task and focused destination action")
	print("checks: %d, failures: %d" % [_checks, _failed])
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(_failed != 0))


func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(2)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(4)


func _confirm(controller: bool) -> void:
	if controller:
		await _joy(JOY_BUTTON_A)
	else:
		await _key(KEY_ENTER)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.device = 0
	event.button_index = button
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(2)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(4)


func _frames(count: int) -> void:
	for index in count:
		await get_tree().process_frame


func _check(ok: bool, note: String) -> void:
	_checks += 1
	if not ok:
		_failed += 1
	print("PASS " if ok else "FAIL ", note)
