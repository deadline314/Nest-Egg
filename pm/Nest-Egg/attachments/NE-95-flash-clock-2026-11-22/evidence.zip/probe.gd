extends "res://tests/smoke_test.gd"


class FlashClockSuite extends HitReactionSuite:
	var _spawned := 0

	func _spawn_trooper() -> Enemy:
		var enemy := super._spawn_trooper()
		_spawned += 1
		if _spawned % 2 == 0:
			enemy.health.damaged.connect(func(_info: DamageInfo) -> void:
				Fx.freeze([enemy], 0.8)
				print("CLOCK_HELD ", Engine.get_physics_frames(), " ", Time.get_ticks_msec()))
		return enemy


func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var suite := FlashClockSuite.new(self)
	await suite._test_reduced_rig_flashes()
	print("CLOCK_FINISHED ", Engine.get_physics_frames(), " ", Time.get_ticks_msec())
	await _finish()