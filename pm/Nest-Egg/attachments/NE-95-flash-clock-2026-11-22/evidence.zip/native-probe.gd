extends ScenarioBase


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://flash_clock_native.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	await open_arena("res://data/lighting/warehouse_interior.tres")
	var camera := get_viewport().get_camera_2d()
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * 3.4
	camera.global_position = player.global_position + Vector2(45, -32)
	AimInput.set_virtual_gamepad(player, true)
	AimInput._last_stick_dir = Vector2.RIGHT
	var enemy := spawn_enemy("res://data/enemies/grunt.tres", 16.0)
	enemy.data = enemy.data.duplicate()
	enemy.data.detect_range = 0.0
	enemy.data.attack_range = 0.0
	enemy.data.move_speed = 0.0
	enemy.health.setup(999, 0.0)
	player.health.setup(6, 0.0)
	await settle(18)
	for reduced: bool in [false, true]:
		Settings.set_reduce_flashes(reduced)
		var hit := DamageInfo.create(1, Combat.Team.PLAYER, &"flash_clock_evidence")
		hit.impact = 6.0
		enemy.hurtbox.receive(hit)
		player.hurtbox.receive(DamageInfo.create(1, Combat.Team.ENEMY, &"flash_clock_evidence"))
		var flashing := enemy.rig._skeleton.modulate.r
		var player_flashing := player._visual.rig._skeleton.modulate.r
		await RenderingServer.frame_post_draw
		capture("reduced-%s-flash" % reduced)
		var deadline := Time.get_ticks_msec() + 2000
		while (Fx.is_frozen(enemy) or Fx.is_frozen(player)) and Time.get_ticks_msec() < deadline:
			await get_tree().process_frame
		for index in 20:
			await get_tree().physics_frame
		await RenderingServer.frame_post_draw
		capture("reduced-%s-restored" % reduced)
		var restored := enemy.rig._skeleton.modulate.is_equal_approx(Color.WHITE) and player._visual.rig._skeleton.modulate.is_equal_approx(Color.WHITE)
		print("NATIVE_FLASH ", JSON.stringify({"reduced":reduced, "enemy_peak":flashing, "player_peak":player_flashing,
			"restored":restored, "player_health":player.health.current}))
		if not restored or flashing <= 1.0 or player_flashing <= 1.0:
			failures += 1
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)