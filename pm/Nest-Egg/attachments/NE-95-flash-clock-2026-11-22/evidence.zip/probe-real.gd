extends "res://tests/smoke_test.gd"


func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var suite := HitReactionSuite.new(self)
	await suite._test_reduced_rig_flashes()
	print("CLOCK_FINISHED ", Engine.get_physics_frames(), " ", Time.get_ticks_msec())
	await _finish()