import os,sys,json,subprocess,re,signal
from pathlib import Path
r=Path.cwd();w=r/'work/controller-storage';cases=[]
for mode in ['after']:
 out=w/('native-flushed-'+mode);out.mkdir();profile=out/'existing-profile'
 env=os.environ.copy();env.update(XDG_DATA_HOME=str(profile),APPDATA=str(profile),LOCALAPPDATA=str(profile))
 command=[sys.executable,'tools/comfyui/gpu_lock.py','--','xvfb-run','-a','-s','-screen 0 1280x720x24',os.environ['GODOT'],'--path',str(r),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','res://work/controller-storage/capture-'+mode+'.tscn','--','--mode=existing','--out='+str(out/'existing')]
 with (out/'run.log').open('w') as f:
  p=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=180)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);code=p.wait(timeout=10)
 result=json.loads((out/'existing/result.json').read_text()) if (out/'existing/result.json').exists() else {}
 cases.append({'mode':mode,'exit':code,'result':result,'command':command});(w/'native-flushed-receipt.json').write_text(json.dumps(cases,indent=2));print(mode,code,result,flush=True)
