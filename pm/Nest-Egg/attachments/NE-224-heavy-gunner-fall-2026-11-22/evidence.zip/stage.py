from pathlib import Path
from hashlib import sha256
from PIL import Image
import json,numpy as np,os,shutil,subprocess,sys

root=Path.cwd()
base=Path(__file__).resolve().parent
shared=base.with_name("ne218-baseline-20261117")
prior=base.with_name("evidence-20261122-ne224-armored-leg-crossing")
before=json.loads((prior/"published-source.json").read_bytes())
parent=json.loads((prior/"publish/result.json").read_bytes())["commit"]
branch="codex/ne224-heavy-fall-helmet"
placeholder="codex/ticket-work-20261120-next"
override="art_src/characters/heavy_gunner/overrides/head.png"
design="design/12-cast-redraw/RIG_QUALITY.md"
part="art/characters/heavy_gunner/parts/"
runtime=[part+"head.png",part+"head_n.png"]
load=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
image=lambda p:np.asarray(Image.open(p).convert("RGBA"))

def git(*args,cwd=root):
    return subprocess.check_output(["git",*args],cwd=cwd).decode("utf-8").strip()

def run(script,args,filename):
    with (base/filename).open("wb") as output:
        subprocess.run([sys.executable,"-X","utf8","-B",script,*args],cwd=root,
                       stdout=output,stderr=subprocess.STDOUT,check=True)

assert git("branch","--show-current")==placeholder
assert parent==git("rev-parse","HEAD")==git("rev-parse","origin/main")==git("rev-parse","HEAD",cwd=shared)
assert not git("status","--porcelain","--untracked-files=no")
assert all(sha(shared/name)==digest for name,digest in before.items())
assert all(sha(root/name)==before[name] for name in runtime)
assert not (root/override).exists()
stock,candidate=image(root/runtime[0]),image(base/"head.png")
assert stock.shape==candidate.shape==(171,168,4)
assert {tuple(x) for x in np.argwhere(np.any(stock!=candidate,axis=2))}=={(118,16),(118,17)}
assert not np.any(stock[:,:,3]>candidate[:,:,3])
assert np.array_equal(image(base/"baseline-normal.png"),image(root/runtime[1]))
normal=image(base/"candidate-normal.png")
assert np.array_equal(normal[:,:,3],candidate[:,:,3])
stats=load(base/"wide-comparison.json")
assert stats["whole"]["samples"]==stats["dressed"]["samples"]==stats["isolated"]["samples"]==53760
assert stats["whole"]["target_closed"]==2 and stats["whole"]["new_hard"]==[]
assert stats["dressed"]["new_hard"]==stats["isolated"]["new_hard"]==[]

git("switch","-c",branch)
git("branch","-d",placeholder)
for path in runtime:
    destination=base/"source-before"/path
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/path,destination)
shutil.copyfile(base/"head.png",root/override)
rebuilt=base/"rebuilt/heavy_gunner"
assert not rebuilt.exists()
spec="tools/comfyui/specs/heavy_gunner_side.json"
run("tools/comfyui/cut_layers.py",["--spec",spec,"--work","art_src/characters/heavy_gunner","--char",str(rebuilt),
                                  "--rig",str(base/"rebuilt-rig.json")],"rebuild.log")
# The recipe applies validated final overrides after the cutter writes its generated parts.
target=rebuilt/"parts/head.png"
assert image(target).shape==candidate.shape and np.array_equal(image(root/override),candidate)
shutil.copyfile(root/override,target)
current=load(root/"art/characters/heavy_gunner/character.json")["textures"]["head"]
new=load(rebuilt/"character.json")["textures"]["head"]
assert all(current[key]==new[key] for key in ("size","pivot","file"))
glow=part+"head_glow.png"
if "glow" in current:
    assert current["glow"]==new["glow"] and np.array_equal(image(root/glow),image(rebuilt/"parts/head_glow.png"))
for name,artifact in zip(runtime,[rebuilt/"parts/head.png",base/"candidate-normal.png"]):
    for directory in (root,shared):
        target=directory/name
        temp=target.with_name(target.name+".head-install")
        shutil.copyfile(artifact,temp)
        os.replace(temp,target)
    before[name]=sha(root/name)
assert all(sha(shared/name)==digest for name,digest in before.items())
run("tools/comfyui/check_spec.py",["--recipe","tools/comfyui/recipes/heavy_gunner.json"],"spec.log")
run("tools/comfyui/check_parts.py",["heavy_gunner","--normals"],"parts.log")
assert "0 error(s), 0 warning(s)" in (base/"spec.log").read_text(encoding="utf-8")
assert "OK   heavy_gunner" in (base/"parts.log").read_text(encoding="utf-8")
doc=(root/design).read_text(encoding="utf-8").rstrip()
note="""

### 機槍重兵倒地時的頭盔底緣

倒地起手時，頭盔側邊和前肩之間會透出一個背景像素。沿頭盔內緣的原有顏色補兩個像素，依同一流程重建法線，維持原頭盔尺寸、掛點與發光層。
"""
(root/design).write_text(doc+note,encoding="utf-8",newline="\n")
assert set(git("diff","--name-only").splitlines())==set(runtime)|{design}
(base/"baseline.txt").write_text(parent+"\n")
(base/"runtime.json").write_text(json.dumps(runtime)+"\n")
(base/"source.json").write_text(json.dumps(before,indent=2)+"\n")
shutil.copyfile(prior/"verify.py",base/"verify.py")
script=(prior/"publish.py").read_text(encoding="utf-8")
for stock,value in (
    ("codex/ne224-armored-leg-crossing",branch),
    ("NE224_armored_leg_crossing_20261122","NE224_heavy_fall_helmet_20261122"),
    ("test: verify armored knee and ankle continuity","art: close the heavy gunner helmet gap during the fall"),
    ("verify the two armored actors' crossing-leg geometry","remove the exposed shoulder pixel during the heavy gunner fall"),
):
    assert stock in script
    script=script.replace(stock,value)
(base/"publish.py").write_text(script,encoding="utf-8")
git("diff","--check")
print("FROZEN HEAVY HELMET",parent,len(before),runtime)
