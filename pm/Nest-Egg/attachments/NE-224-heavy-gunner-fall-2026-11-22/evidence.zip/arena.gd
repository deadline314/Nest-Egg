extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const DISTRICT := preload("res://data/levels/level_02.tres")
var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://heavy_fall_probe.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Story.auto_skip = true
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	for direction: int in [-1, 1]:
		for zoom: float in [LevelCamera.base_zoom(), 3.4]:
			if not await _observe(direction, zoom):
				push_error("Heavy gunner fall fixture failed at %d / %.2f" % [direction, zoom])
				get_tree().quit(1)
				return
	var file := FileAccess.open(_out.path_join("street.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"adapter": RenderingServer.get_video_adapter_name(),
		"renderer": RenderingServer.get_current_rendering_method(), "rows": _rows}, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)


func _observe(direction: int, zoom: float) -> bool:
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(DISTRICT)
	add_child(level)
	for tick in 10:
		await get_tree().physics_frame
	if level.player == null or level._entities == null:
		return false
	var gunner: HeavyGunner
	for actor in level._entities.get_children():
		if actor is HeavyGunner and gunner == null:
			gunner = actor
		elif actor is Enemy:
			actor.process_mode = Node.PROCESS_MODE_DISABLED
	if gunner == null or gunner.rig == null:
		return false
	var start := gunner.global_position
	level.player.health.setup(999, level.player.tuning.hurt_invulnerability)
	level.player.global_position = start + Vector2(94.0 * direction, 0)
	level.player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(level.player, true)
	level._lighting._lightning_gap = 1.0e9
	for node in level.find_children("*", "ChapterCard", true, false):
		node.queue_free()
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.limit_left = -100000
	camera.limit_right = 100000
	camera.offset = Vector2.ZERO
	camera.zoom = Vector2.ONE * zoom
	camera.global_position = start + Vector2(0, -34)
	camera.reset_smoothing()
	camera.force_update_scroll()
	var label := "%s_%d" % ["left" if direction < 0 else "right", roundi(zoom * 100)]
	for tick in 18:
		await get_tree().physics_frame
	gunner.facing = direction
	if not await _capture(gunner, camera, label + "_before"):
		return false
	var hit := DamageInfo.create(gunner.health.current + 1, Combat.Team.PLAYER, &"probe", Vector2(-32.0 * direction, 0.0))
	hit.origin = level.player.global_position
	hit.ignore_invulnerability = true
	hit.bypass_guard = true
	if not gunner.health.take_damage(hit) or not gunner.is_dying():
		return false
	var hit_step := Engine.get_physics_frames()
	for tick in 22:
		await get_tree().process_frame
		var step := Engine.get_physics_frames() - hit_step
		if step in [2, 8, 16] and not await _capture(gunner, camera, "%s_fall_%02d" % [label, step]):
			return false
	level.queue_free()
	for tick in 6:
		await get_tree().process_frame
	return true


func _capture(gunner: HeavyGunner, camera: LevelCamera, name: String) -> bool:
	await RenderingServer.frame_post_draw
	var code := Capture.image(get_viewport()).save_png(_out.path_join(name + ".png"))
	var transform := camera.get_canvas_transform()
	var head := transform * gunner.rig.bone(&"head").global_position
	var arm := transform * gunner.rig.bone(&"arm_front_upper").global_position
	_rows.append({"key": name, "head": [head.x, head.y], "arm": [arm.x, arm.y], "facing": gunner.facing,
		"world": [gunner.global_position.x, gunner.global_position.y], "dying": gunner.is_dying(), "health": gunner.health.current})
	return code == OK
