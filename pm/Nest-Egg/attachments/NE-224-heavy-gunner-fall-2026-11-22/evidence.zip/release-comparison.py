from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
import json,numpy as np

base=Path(__file__).resolve().parent
key=lambda row:(row["pose"],row["zoom"],row["facing"],row["joint"],row["frame"])
read=lambda path:json.loads(path.read_bytes())

def maps(report):
    rows={key(row):row for row in report["failures"]}
    assert all(row["char"]=="heavy_gunner" for row in rows.values())
    hard={name for name,row in rows.items() if row["enclosed_pixels"] or row["loose_pieces"] or row["center_alpha"]<128}
    return set(rows),hard

proof={}
for mode in ("whole","dressed","isolated"):
    stock=base/("before-"+mode)
    candidate=base/("trial-"+mode)
    for folder in (stock,candidate):
        raw=(folder/"raw.log").read_text(encoding="utf-8-sig")
        assert "Forward+" in raw and "RX 9070 XT" in raw and "ERROR:" not in raw
    before,after=[read(path/"report.json") for path in (stock,candidate)]
    assert before["samples"]==after["samples"]==53760
    old_flags,old_hard=maps(before)
    new_flags,new_hard=maps(after)
    target={item for item in old_hard if item[0]=="dead" and item[3]=="shoulder_front"}
    assert len(target)==(2 if mode=="whole" else 0)
    assert new_hard==old_hard-target
    assert new_flags==old_flags-target
    proof[mode]=dict(samples=after["samples"],before_hard=len(old_hard),after_hard=len(new_hard),
                     before_flags=len(old_flags),after_flags=len(new_flags),target_closed=len(target),
                     new_hard=sorted(new_hard-old_hard))
(base/"wide-comparison.json").write_text(json.dumps(proof,indent=2)+"\n",encoding="utf-8")
print("EXACT MATCHED NATIVE",proof)

image=Image.new("RGB",(600,322),"#142130")
draw=ImageDraw.Draw(image)
for index,folder in enumerate((base/"before",base/"trial")):
    group=read(folder/"frames.json")[0]
    cell=next(row for row in group["cells"] if row["joint"]=="shoulder_front" and row["facing"]==1)
    x,y,w,h=cell["rect"]
    crop=Image.open(folder/group["samples"][1]["file"]).convert("RGBA").crop((x+34,y+20,x+94,y+80))
    if index==0:
        solid=np.asarray(crop)[:,:,3]>=128
        spots=np.argwhere(ndimage.binary_fill_holes(solid,structure=np.ones((3,3),bool))&~solid)
        assert len(spots)==1
    matte=Image.new("RGBA",crop.size,"#5c465c")
    matte.alpha_composite(crop)
    image.paste(matte.convert("RGB").resize((300,300),Image.Resampling.NEAREST),(300*index,22))
    yd,xd=spots[0]
    x1,y1=300*index+int(xd*5+2),int(yd*5+24)
    draw.rectangle((x1-13,y1-13,x1+13,y1+13),outline="#f2a65a",width=2)
    draw.text((300*index+8,5),("ORIGINAL" if index==0 else "RESTORED HELMET EDGE"),fill="#e3edf5")
image.save(base/"compare.png")
