extends SceneTree

func _init() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() != 2:
		quit(2)
		return
	var image := Image.load_from_file(args[0])
	if image == null or image.is_empty():
		quit(3)
		return
	var normal := NormalMapMaker.make(image)
	quit(normal.save_png(args[1]))
