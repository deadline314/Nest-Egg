from pathlib import Path
from PIL import Image
import numpy as np
e=Path('D:/NestEggVerification/evidence-20261122-ne224-heavy-fall-helmet')
p=Path('art/characters/heavy_gunner/parts/head.png')
raw=np.array(Image.open(p))
assert raw.shape==(171,168,4)
assert raw[118,16:18,3].tolist()==[42,55]
raw[118,16:18,:3]=raw[117,16:18,:3]
raw[118,16:18,3]=[190,225]
Image.fromarray(raw).save(e/'head.png')
