$ErrorActionPreference='Stop'
$e=$PSScriptRoot.Replace('\','/')
$x=Join-Path (Split-Path -Parent $e) 'evidence-20261122-ne224-enforcer-visor-hips'
$d='D:/NestEggVerification/ne218-baseline-20261117'
$py='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
$engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
foreach($mode in 'whole','dressed','isolated') {
 foreach($variant in 'before','trial') {
  $out=New-Item -ItemType Directory -Path "$e/$variant-$mode"
  $profile=New-Item -ItemType Directory -Path "$out/profile"
  $env:APPDATA=$profile.FullName
  $env:LOCALAPPDATA=$profile.FullName
  $extra=@()
  if($mode -eq 'whole'){$extra+='--diagnostic-whole-rig'}
  if($mode -eq 'isolated'){$extra+='--pair-only'}
  if($variant -eq 'trial'){$extra+="--diagnostic-part-texture=head:$e/head.png"}
  & $py -B "$d/tools/comfyui/gpu_lock.py" -- $engine --path $d --rendering-method forward_plus --rendering-driver vulkan --resolution 1280x720 --max-fps 120 --audio-driver Dummy --quit-after 18000 "$x/forearm-matrix.tscn" -- "--out=$($out.FullName)" --chars=heavy_gunner --frames=120 @extra *> "$out/raw.log"
  if($LASTEXITCODE -ne 0 -or (Select-String -LiteralPath "$out/raw.log" -Pattern 'ERROR:' -Quiet)){Get-Content -LiteralPath "$out/raw.log" -Tail 12;exit 2}
  & $py -X utf8 -B tools/check_joint_frames.py $out *> "$out/check.log"
  if($LASTEXITCODE -gt 1){Get-Content -LiteralPath "$out/check.log" -Tail 8;exit 3}
  Get-Content -LiteralPath "$out/check.log" -TotalCount 3
 }
}
