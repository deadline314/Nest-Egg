extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const PROLOGUE := "res://data/levels/ch1_prologue.tres"
const RESUME := {"zh": "繼續", "en": "Resume", "ja": "再開"}
const MAP := {"zh": "地圖", "en": "Map", "ja": "地図"}
const PAUSE := {"zh": "暫停", "en": "Paused", "ja": "ポーズ"}
const SKIP := {"zh": "略過序章", "en": "Skip prologue", "ja": "序章をスキップ"}
const KEEP := {"zh": "繼續練習", "en": "Keep practicing", "ja": "練習を続ける"}
const CONTROLS := {"zh": "移動", "en": "Move", "ja": "移動"}
const PROGRESS := {"zh": "遊玩時間", "en": "Play time", "ja": "プレイ時間"}

var _output := ""
var _fails := 0
var _checks := 0


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_output = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://pause-language-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_skip_cutscenes(true)
	Story.set_language("zh")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(load(PROLOGUE) as LevelData)
	add_child(level)
	await _frames(50)
	for attempt in 30:
		if not Story.is_cinematic_active():
			break
		Story.skip_cinematic()
		await _frames(4)
	await _key(KEY_ESCAPE)
	var pause: PauseMenu = level._pause_menu
	_check(pause._root.visible and get_tree().paused, "actual Escape opens the prologue pause layer")
	if not pause._root.visible:
		await _finish(level)
		return
	pause._map_button.grab_focus()
	for locale: String in ["en", "ja", "zh"]:
		Story.set_language(locale)
		await _frames(18)
		_check(pause._menu_panel._title_label.text == PAUSE[locale] and pause._resume_button.text == RESUME[locale],
			locale + " translates pause heading and Resume")
		_check(pause._map_button.text == MAP[locale] and pause._map_button.has_focus(),
			locale + " retains focus on the same localized Map button")
		_check(pause._status_label.text.contains(PROGRESS[locale]) and pause._controls_label.text.begins_with(CONTROLS[locale]),
			locale + " translates progress and real binding labels")
		_check(not pause._menu_panel.get_global_rect().intersects(pause._info_panel.get_global_rect().grow(-1)),
			locale + " progress and action panels fit without overlap at 120%")
		_check(pause._skip_button.text == SKIP[locale], locale + " reads the prologue action from authored data")
		if locale == "en":
			_check(pause._map_button.tooltip_text.contains(InputBindings.primary_label(&"map")), "keyboard map Hover shows the active shortcut")
			var hint := pause._root.find_child("FocusHintBar", true, false) as FocusHintBar
			_check(hint != null and hint.text() == pause._map_button.tooltip_text and hint.text().begins_with("Open "),
				"visible focus hint follows the same localized English keyboard tooltip")
			await _capture("pause.png")
	Story.set_language("en")
	await _frames(7)
	pause._skip_button.grab_focus()
	await _key(KEY_ENTER)
	var panel := pause._skip_confirm as UiPanel
	_check(is_instance_valid(panel), "Enter opens the real skip confirmation without skipping")
	if is_instance_valid(panel):
		var keep := panel.body.get_child(1) as Button
		_check(panel._title_label.text == SKIP["en"] and keep.text == KEEP["en"] and keep.has_focus(),
			"English confirmation offers Keep practicing as the safe default")
		Story.set_language("ja")
		await _frames(9)
		_check(panel._title_label.text == SKIP["ja"] and keep.text == KEEP["ja"] and keep.has_focus(),
			"Japanese updates the same live confirmation and retains its safe focus")
		var hint := panel.find_child("FocusHintBar", true, false) as FocusHintBar
		_check(hint != null and hint.text() == keep.tooltip_text and hint.text().begins_with("ポーズ"),
			"visible confirmation hint updates in Japanese without refocusing")
		await _capture("skip.png")
		await _joy(JOY_BUTTON_B)
		_check(not is_instance_valid(pause._skip_confirm) and pause._skip_button.has_focus() and get_tree().paused,
			"controller B cancels the skip and restores its pause selection")
	_check(not GameState.has_flag(&"ch1_prologue_skipped"), "cancel and language changes never mark the prologue skipped")
	await _finish(level)


func _capture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_output.path_join(name)) == OK, "saved " + name)


func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _press(event)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	await _press(event)


func _press(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(7)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish(level: Level) -> void:
	if is_instance_valid(level):
		if is_instance_valid(level._pause_menu) and level._pause_menu._root.visible:
			level._pause_menu.close()
		level.queue_free()
	await _frames(6)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))

