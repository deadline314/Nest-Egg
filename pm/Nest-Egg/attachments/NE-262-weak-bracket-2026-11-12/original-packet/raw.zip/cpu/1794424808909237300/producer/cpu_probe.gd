extends ScenarioBase
## Short causal API controls, not natural aim/combat or an audio recording.
const Factory=preload("res://work/ne262-producer/factory.gd")
var checks := 0
var failures: Array[String] = []
var rows: Array = []
var weak_calls: Array = []
var sounds: Array[String] = []
var markers: Array[String] = []
var damage: Array = []
var current_case := ""
var negative := false

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out_dir=arg.trim_prefix("--out=")
		elif arg=="--control=body-as-head":negative=true
	_run.call_deferred()

func _check(ok: bool, message: String) -> void:
	checks+=1
	if not ok:failures.append(message);printerr("CHECK_FAIL: "+message)

func weak_callback(actor: Enemy, info: DamageInfo, before: int, after: int) -> void:
	weak_calls.append({"actor":String(actor.data.id),"part":String(info.part),"weak":info.weak_hit,"amount":info.amount,"particles_before":before,"particles_after":after,"case":current_case})

func _sound(id: StringName) -> void:sounds.append(String(id))
func _marker(kind: StringName) -> void:markers.append(String(kind))
func _damaged(info: DamageInfo) -> void:damage.append({"part":String(info.part),"weak":info.weak_hit,"amount":info.amount})

func _run() -> void:
	assert(out_dir.is_absolute_path() and DisplayServer.get_name()=="headless")
	DirAccess.make_dir_recursive_absolute(out_dir)
	Settings.use_storage("user://ne262-cpu.cfg")
	Enemy.activation_culling_enabled=false;Story.auto_skip=true
	await open_arena("res://data/lighting/neutral.tres",12.0)
	player.visible=false
	Sfx.sound_played.connect(_sound);EventBus.hit_marker.connect(_marker)
	var crosshair := Crosshair.new();add_child(crosshair)
	for kind in ["head","body"]:
		current_case=kind;weak_calls.clear();sounds.clear();markers.clear();damage.clear()
		var original := load("res://data/enemies/grunt.tres") as EnemyData
		var data := original.duplicate() as EnemyData
		data.detect_range=0.0;data.attack_range=0.0;data.move_speed=0.0
		var actor := Factory.create(data,self)
		_check(actor!=null,"actual grunt behavior compiles with the disclosed observer bridge")
		if actor==null:break
		actor.position=Vector2(24.0*16.0,FLOOR_Y)
		level._entities.add_child(actor)
		await settle(6)
		actor.health.setup(100,0.0)
		actor.health.damaged.connect(_damaged)
		actor.set_physics_process(false)
		var part := actor.hurtbox.parts[0] if kind=="head" and not negative else actor.hurtbox
		var point := part.center()
		var body_space := PhysicsServer2D.body_get_space(actor.get_rid()).is_valid()
		var area_space := PhysicsServer2D.area_get_space(part.get_rid()).is_valid()
		_check(body_space and area_space,"real actor and target part remain in the physics space")
		var before := actor.health.current
		crosshair._weak_left=0.0
		weak_calls.clear();sounds.clear();markers.clear();damage.clear()
		var shot := Projectile.new();add_child(shot)
		shot.activate(load("res://data/projectiles/rifle_shot.tres"),point,Vector2.RIGHT,Combat.Team.PLAYER)
		shot.set_physics_process(false)
		shot.call(&"_strike",part)
		var particles_scale := Settings.get_feel_scale("particles")
		var expected_particles := 0 if particles_scale<=0.0 else maxi(1,roundi(6.0*Fx.PARTICLE_SCALE*particles_scale))
		var row := {"case":kind,"health_before":before,"health_after":actor.health.current,"damage":damage.duplicate(true),"weak_callbacks":weak_calls.duplicate(true),"sounds":sounds.duplicate(),"markers":markers.duplicate(),"crosshair_weak_left":crosshair._weak_left,"body_space":body_space,"area_space":area_space,"authored_head_multiplier":float(original.hurt_parts[0]["mult"]),"projectile_damage":(load("res://data/projectiles/rifle_shot.tres") as ProjectileSpec).damage,"requested_weak_particles":6,"published_particle_scale":Fx.PARTICLE_SCALE,"settings_particle_scale":particles_scale,"expected_emitted_particles":expected_particles}
		rows.append(row)
		_check(damage.size()==1,"exactly one actual Health damage publication")
		if kind=="head":
			_check(before-actor.health.current==2,"actual head damage is the authored 1.5x rounded from one")
			_check(damage.size()==1 and damage[0]["part"]=="head" and damage[0]["weak"],"the actual hit identifies the head and weak flag")
			_check(weak_calls.size()==1 and weak_calls[0]["particles_after"]-weak_calls[0]["particles_before"]==expected_particles,"the real Enemy weak callback emits the authored request through the unchanged published particle scaling")
			_check(not sounds.is_empty(),"the actual Sfx sound_played signal publishes selected sound leaves")
			_check(markers==["weak"] and crosshair._weak_left>0.0,"the real projectile emits the weak marker and the real Crosshair receives it")
		else:
			_check(before-actor.health.current==1,"actual body damage remains one")
			_check(damage.size()==1 and not damage[0]["weak"] and weak_calls.is_empty(),"ordinary body hit does not invoke weak feedback")
			_check(markers==["hit"] and crosshair._weak_left==0.0,"ordinary hit does not create a weak Crosshair marker")
		actor.queue_free();shot.queue_free();await settle(3)
	Sfx.sound_played.disconnect(_sound);EventBus.hit_marker.disconnect(_marker)
	crosshair.queue_free()
	await finish();await AudioRelease.settle(get_tree())
	var file := FileAccess.open(out_dir.path_join("cpu-result.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks":checks,"failures":failures,"rows":rows,"negative_body_as_head":negative,"scope":"Actual controlled API calls and selected sound leaf events; no natural flight, PCM capture, listening or performance claim."},"  "));file.close()
	print("NE262_CPU_DONE checks=%d failures=%d" % [checks,failures.size()])
	get_tree().quit(0 if failures.is_empty() else 1)
