extends RefCounted
## No global class. Actual authored behavior is inherited; only draw dispatch and an observing weak callback are added.
const LEGACY := "res://work/ne262-producer/legacy_weak_points.gd.txt"

static func source(data: EnemyData) -> String:
	var text := 'extends "'+data.behavior.resource_path+'"\n'
	text += '''var ne262_before := false
var ne262_observer: Node
func _draw_hurtbox_debug() -> void:
	if ne262_before:
		_draw_weak_points()
	else:
		super._draw_hurtbox_debug()
func _weak_point_feedback(info: DamageInfo) -> void:
	var before := Fx.particle_count()
	super._weak_point_feedback(info)
	if is_instance_valid(ne262_observer):
		ne262_observer.weak_callback(self,info,before,Fx.particle_count())
'''
	return text+FileAccess.get_file_as_string(LEGACY)

static func create(data: EnemyData, observer: Node) -> Enemy:
	var script := GDScript.new()
	script.source_code=source(data)
	if script.reload()!=OK:
		return null
	var actor := script.new() as Enemy
	actor.data=data
	actor.set("ne262_observer",observer)
	return actor
