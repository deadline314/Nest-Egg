# NE262 scoped verification leaf

This leaf belongs to the NE262 evidence task. All existing tracked files and Root's `work/bg42*` remain read-only. It uses published runtime `8c788e7c79a6c842e94aaf62892b5301492bc9a6`; it does not use primary C's pending NE277 Hurtbox or any private performance tree.

`factory.gd` dynamically inherits each actual authored actor's behavior. Its only renderer change dispatches to the verbatim archived `_draw_weak_points` function when requested. The other override observes before/after particle counts around `super._weak_point_feedback`. `legacy-source.json` identifies the original parent/function SHA. **B is a draw restoration on the published runtime, not a complete historical checkout.**

Commands (CPU controls already executed; native awaits explicit Root GPU handoff):

```powershell
python -X utf8 work/ne262-producer/run.py
python -X utf8 work/ne262-producer/run.py --parse
python -X utf8 work/ne262-producer/run.py --cpu
python -X utf8 work/ne262-producer/run.py --cpu --control=body-as-head
# Only after handoff, one at a time:
python -X utf8 work/ne262-producer/run.py --native
python -X utf8 work/ne262-producer/run.py --native --control=after-still-brackets
python -X utf8 work/ne262-producer/run.py --native --control=debug-off
```

Each invocation isolates APPDATA, copies its producer, records its exact command, runtime/actor-art SHA before and after, original stdout, engine exit and elapsed time. Native uses the **primary C** `gpu_lock.py`, never this plain D archive's local lock. Elapsed time is operational duration, not a performance sample. The default plan starts no engine.

The CPU probe invokes the real Projectile `_strike` API against a true grunt's authored head or body, observing actual Health damage, part/weak flag, Enemy weak callback particles, selected Sfx sound leaves, EventBus hit marker and Crosshair weak timer. It does not prove natural projectile flight, recorded PCM, human listening or device operation. Initial particle expectation failure is preserved: requested six particles means three actual particles under published `Fx.PARTICLE_SCALE=.5`. Positive final run `cpu/1794424808909237300` is 14/0. Body-as-head `cpu/1794424851834357800-body-as-head` records four real semantic rejections, engine exit1, no script diagnostics; it is an expected negative, not a green test run.

The native probe will capture five whole renderer readbacks on the same real grunt and watchdog: normal A1, archived draw B, normal A2, published debug, normal A3. Root `ScenarioBase` opens a neutral arena; actor duplicate data only disables movement/detection. The actual bones, sprite transforms, animation time, hurtbox geometry/enable state and physics spaces are serialized. The level is explicitly PAUSABLE under the probe's ALWAYS root; tree pause and an independent world process/physics witness must stay fixed. Five distinct post-draw readbacks are required. The three A images must be byte equal. No caption is inserted into PNG pixels; JSON carries labels. Raw Image bytes accompany the fixed published float-to-sRGB helper's PNGs.

`verify.py` reads only recorded files. It checks actual A/A pixels and pose equality, then independently projects the exact old corner formula and current debug rectangle edges into the actual viewport. Every predicted segment must contain a cluster of changed pixels of its expected yellow/cyan class. A wrong projection can be tested with `--projection-shift=10000`; no evidence image is edited. The two native producer faults must fail actual pixel/geometry checks, not just a declared control flag. Six Python geometry checks pass; these are unit controls, **not native renderer acceptance**. All native/visual conditions remain pending until actual captures, negative controls and full-size human review occur.

`verify.py <run-directory>` rechecks a CPU or native receipt. Python dependencies are NumPy and Pillow; it never launches an engine or reads live runtime. The selected runtime/asset source set is explicitly listed, not described as a complete checkout hash. Existing initial CPU receipts predate the artifact-hash field; native receipts require it.

Native first normal 1794458714060871000 is retained as a rejected framing epoch: engine0/13 producer checks, actual float/PNG A/A identical, but zoom3 clipped the watchdog body and an original legacy back_power bracket. Reader correctly refused projected out-of-frame geometry. New fixture epoch changes only camera zoom3 to2; actual actors/data/parts, renderer formula and reader thresholds remain unchanged.
