from pathlib import Path
import hashlib,json,subprocess,sys,time,urllib.request
ROOT=Path('D:/NestEggVerification/bg42-published-8c788e7c-20261112')
C=Path('C:/Users/stanl/Github/Nest-Egg')
HERE=Path(__file__).resolve().parent
CONTROL=sys.argv[1] if len(sys.argv)>1 else 'normal'
OUT=HERE/(str(time.time_ns())+'-'+CONTROL);OUT.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_bytes((json.dumps(value,indent=2)+'\n').encode())
def queues():
 result={}
 for port in [8188,8189]:
  start=time.monotonic()
  try:
   with urllib.request.urlopen(f'http://127.0.0.1:{port}/queue',timeout=6) as f:d=json.load(f)
   result[str(port)]={'running':len(d['queue_running']),'pending':len(d['queue_pending'])}
  except Exception as e:result[str(port)]={'status':'absent' if getattr(getattr(e,'reason',None),'winerror',None)==10061 else 'unknown','reason':type(getattr(e,'reason',None)).__name__,'winerror':getattr(getattr(e,'reason',None),'winerror',None)}
  result[str(port)]['seconds']=time.monotonic()-start
 return result
context=C/'work/ne228-reviewed-controls-official-v1/c-native-context-v14.json'
raw=context.read_bytes();d=json.loads(raw);assert d['count']==364
before={p:sha(C/p) for p in d['files']};assert before==d['files'],'C364 source guard failed'
(OUT/'C-context-v14.json').write_bytes(raw);save('C-before.json',before)
leaf=ROOT/'work/ne262-producer';fixed=json.loads((leaf/'plan-index.json').read_bytes());assert all(sha(leaf/p)==v for p,v in fixed['producer_files'].items())
q=queues();save('queue-before.json',q);assert q['8188'].get('running')==0 and q['8188'].get('pending')==0 and q['8189'].get('status')!='unknown'
command=[sys.executable,'-X','utf8',str(leaf/'run.py'),'--native']
if CONTROL!='normal':command+=['--control='+CONTROL]
save('command.json',command);(OUT/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
start=time.monotonic()
with (OUT/'wrapper.log').open('wb') as log:run=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
save('queue-after.json',queues());after={p:sha(C/p) for p in d['files']};save('C-after.json',after)
receipt={'control':CONTROL,'wrapper_exit':run.returncode,'seconds':time.monotonic()-start,'C364_same':before==after,'context_sha256':hashlib.sha256(raw).hexdigest(),'sequence_runner_sha256':sha(Path(__file__)),'frozen_leaf12_same':all(sha(leaf/p)==v for p,v in fixed['producer_files'].items()),'performance':False}
save('receipt.json',receipt);print(json.dumps({'output':str(OUT),**receipt}));print((OUT/'wrapper.log').read_text(errors='replace')[-5000:]);assert before==after
raise SystemExit(run.returncode)
