"""Explicit short NE262 stages. Default plan never starts Godot; native requires --native."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
from concurrent.futures import ThreadPoolExecutor

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PRIMARY=Path('C:/Users/stanl/Github/Nest-Egg')
EXPECTED_ROOT=Path('D:/NestEggVerification/bg42-published-8c788e7c-20261112')
BASE='8c788e7c79a6c842e94aaf62892b5301492bc9a6'
GODOT=Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,value):path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())

def inputs():
 raw=subprocess.run(['git','ls-tree','-r','-z',BASE],cwd=PRIMARY,check=True,capture_output=True).stdout
 files={}
 for entry in raw.split(b'\0'):
  if not entry:continue
  header,name=entry.split(b'\t',1);name=name.decode();mode,kind,oid=header.decode().split()
  if kind!='blob':continue
  text=(name.startswith(('core/','game/','autoload/','ui/','data/','tests/','art/rigs/')) and Path(name).suffix in ['.gd','.json','.tres'])
  extra=name in ['project.godot','tools/scenarios/scenario_base.gd','tools/viewport_capture.gd','tools/held_lighting_state.gd','art/creatures/watchdog.json'] or name.startswith(('art/characters/trooper/','art/creatures/watchdog/','art/shaders/','art/weapons/'))
  if (text or extra) and (ROOT/name).is_file():files[name]=oid
 required=['game/enemies/enemy.gd','game/enemies/grunt.gd','data/enemies/grunt.tres','data/enemies/watchdog.tres','core/components/hurtbox.gd','tools/viewport_capture.gd']
 assert all(name in files for name in required)
 return files

def snapshot(files):
 def one(item):
  name,oid=item;data=(ROOT/name).read_bytes()
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,('published input drift',name)
  return name,sha(data)
 with ThreadPoolExecutor(max_workers=4) as pool:return dict(pool.map(one,files.items()))

def main():
 assert ROOT.resolve()==EXPECTED_ROOT.resolve()
 parser=argparse.ArgumentParser(description=__doc__)
 stage=parser.add_mutually_exclusive_group();stage.add_argument('--cpu',action='store_true');stage.add_argument('--native',action='store_true');stage.add_argument('--parse',action='store_true')
 parser.add_argument('--control',choices=['body-as-head','after-still-brackets','debug-off']);args=parser.parse_args()
 if not args.cpu and not args.native and not args.parse:
  print(json.dumps({'engine_started':False,'native_awaits_explicit_gpu_handoff':True,'root':str(ROOT),'scope':'Only work/ne262-producer; all published runtime read-only'}));return
 assert args.control is None or (args.cpu and args.control=='body-as-head') or (args.native and args.control in ['after-still-brackets','debug-off'])
 files=inputs();before=snapshot(files)
 run=HERE/('parse' if args.parse else 'cpu' if args.cpu else 'native')/(str(time.time_ns())+('-'+args.control if args.control else ''));run.mkdir(parents=True)
 own={p.name:sha(p.read_bytes()) for p in HERE.iterdir() if p.is_file()}
 for name,digest in own.items():
  target=run/'producer'/name;target.parent.mkdir(exist_ok=True);data=(HERE/name).read_bytes();assert sha(data)==digest;target.write_bytes(data)
 save(run/'source-before.json',{'base':BASE,'published_inputs':before,'producer':own,'scope':'Selected existing code/data plus real actor art, all byte-equal to immutable published Git8c; not a complete historical checkout.'})
 scene='cpu_probe.tscn' if args.cpu else 'probe.tscn'
 command=[str(GODOT),'--quit-after','1200','--path',str(ROOT)]
 if args.cpu or args.parse:command.append('--headless')
 else:command+=['--resolution','1280x720']
 command+=['res://work/ne262-producer/'+scene,'--','--out='+str(run)]
 if args.parse:command.append('--validate-only')
 if args.control:command+=['--control='+args.control]
 if args.native:command=[sys.executable,str(PRIMARY/'tools/comfyui/gpu_lock.py'),'--',*command]
 save(run/'command.json',command);env=os.environ.copy();env['APPDATA']=str(run/'isolated-appdata')
 started=time.monotonic()
 with (run/'engine.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 after=snapshot(files);own_after={name:sha((HERE/name).read_bytes()) for name in own}
 save(run/'source-after.json',{'base':BASE,'published_inputs':after,'producer':own_after})
 text=(run/'engine.log').read_text(encoding='utf-8',errors='replace')
 diagnostics=[line for line in text.splitlines() if any(x in line for x in ['SCRIPT ERROR','ERROR:','ObjectDB instances leaked','resources still in use'])]
 receipt={'exit':result.returncode,'seconds':time.monotonic()-started,'source_same':before==after and own==own_after,'diagnostics':diagnostics,'performance':False,'control':args.control,'output':str(run)}
 receipt['artifacts']={p.name:sha(p.read_bytes()) for p in run.iterdir() if p.is_file() and p.name not in ['exit.json']}
 save(run/'exit.json',receipt);print(json.dumps(receipt))
 expected=1 if args.control=='body-as-head' else 0
 assert result.returncode==expected and receipt['source_same'] and not diagnostics
 if args.cpu:
  observed=json.loads((run/'cpu-result.json').read_bytes());assert observed['checks']>0
  assert bool(observed['failures'])==(args.control=='body-as-head')
 if args.native:
  from verify import check_render
  try:
   observed=check_render(run)
  except AssertionError as error:
   save(run/'reader-result.json',{'accepted':False,'reason':str(error),'expected_negative':bool(args.control)})
   assert args.control is not None,('normal native evidence rejected',str(error))
  else:
   save(run/'reader-result.json',{'accepted':True,'observed':observed})
   assert args.control is None,'reader accepted a deliberately wrong native control'

if __name__=='__main__':main()
