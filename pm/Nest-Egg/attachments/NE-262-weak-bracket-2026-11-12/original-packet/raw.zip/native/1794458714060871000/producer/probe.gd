extends ScenarioBase
## A/A and pose guards execute in the producer and are independently checked offline.
## B restores only the archived draw function on the real authored actor behavior.
const Factory = preload("res://work/ne262-producer/factory.gd")
const Capture = preload("res://tools/viewport_capture.gd")
const Witness = preload("res://work/ne262-producer/witness.gd")
var actors: Array[Enemy] = []
var rows: Array = []
var failures: Array[String] = []
var control := ""
var validate_only := false
var witness: Node
var checks := 0

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): out_dir = arg.trim_prefix("--out=")
		elif arg.begins_with("--control="): control = arg.trim_prefix("--control=")
		elif arg == "--validate-only": validate_only = true
	_run.call_deferred()

func weak_callback(_actor: Enemy, _info: DamageInfo, _before: int, _after: int) -> void:
	pass

func _check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures.append(message)
		printerr("CHECK_FAIL: " + message)

func _values(t: Transform2D) -> Array:
	return [t.x.x,t.x.y,t.y.x,t.y.y,t.origin.x,t.origin.y]

func _vec(v: Vector2) -> Array:
	return [v.x,v.y]

func _node_state(root: Node, result: Array) -> void:
	if root is Node2D:
		result.append({"path":String(root.get_path()),"local":_values(root.transform),"global":_values(root.global_transform),"visible":root.visible})
	for child in root.get_children(): _node_state(child,result)

func _state() -> Dictionary:
	var bodies: Array = []
	for actor in actors:
		var nodes: Array = []
		_node_state(actor,nodes)
		var parts: Array = []
		for entry in actor._parts:
			var box: Hurtbox = entry["box"]
			parts.append({"id":String(box.part_id),"size":_vec(entry["size"]),"offset":_vec(box.shape_offset()),"mult":entry["mult"],"enabled":box.enabled,"space":PhysicsServer2D.area_get_space(box.get_rid()).is_valid()})
		bodies.append({"id":String(actor.data.id),"anim_time":actor._anim_time,"facing":actor.facing,"fsm":String(actor.fsm.current),"body_space":PhysicsServer2D.body_get_space(actor.get_rid()).is_valid(),"main_enabled":actor.hurtbox.enabled,"nodes":nodes,"parts":parts,"draw_to_viewport":_values(get_viewport().get_final_transform()*actor.get_global_transform_with_canvas())})
	return {"actors":bodies,"witness_process":witness.process_ticks,"witness_physics":witness.physics_ticks,"canvas":_values(get_viewport().get_canvas_transform()),"final":_values(get_viewport().get_final_transform()),"paused":get_tree().paused}

func _draw_mode(before: bool, debug: bool) -> void:
	Enemy.debug_hurtboxes = debug
	for actor in actors:
		actor.set("ne262_before",before)
		actor.queue_redraw()

func _frame(name: String, before: bool, debug: bool) -> Image:
	_draw_mode(before,debug)
	await RenderingServer.frame_post_draw
	# Readback occurs only after the actual renderer has published this mode.
	var raw: Image = get_viewport().get_texture().get_image()
	var png: Image = Capture.encode(raw,get_viewport().use_hdr_2d)
	_check(png.save_png(out_dir.path_join(name+".png"))==OK,"actual PNG saved: "+name)
	var data := FileAccess.open(out_dir.path_join(name+".raw"),FileAccess.WRITE)
	data.store_buffer(raw.get_data());data.close()
	rows.append({"name":name,"before_draw_only":before,"debug":debug,"engine_process_frame":Engine.get_process_frames(),"engine_physics_frame":Engine.get_physics_frames(),"raw_format":raw.get_format(),"raw_bytes":raw.get_data_size(),"width":raw.get_width(),"height":raw.get_height(),"state":_state()})
	return png

func _run() -> void:
	if validate_only:
		# Compilation plus actual authored behavior reload, without a renderer claim.
		for path in ["res://data/enemies/grunt.tres","res://data/enemies/watchdog.tres"]:
			var actor := Factory.create(load(path),self)
			_check(actor != null,"authored behavior compiles: "+path)
			if actor != null: actor.free()
		print("NE262_PARSE checks=%d failures=%d" % [checks,failures.size()])
		await AudioRelease.settle(get_tree())
		get_tree().quit(0 if failures.is_empty() else 1)
		return
	assert(out_dir.is_absolute_path() and DisplayServer.get_name()!="headless")
	DirAccess.make_dir_recursive_absolute(out_dir)
	Settings.use_storage("user://ne262-render.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Enemy.activation_culling_enabled=false; Story.auto_skip=true
	await open_arena("res://data/lighting/neutral.tres",12.0)
	player.visible=false
	for path in ["res://data/enemies/grunt.tres","res://data/enemies/watchdog.tres"]:
		var data := (load(path) as EnemyData).duplicate() as EnemyData
		data.detect_range=0.0; data.attack_range=0.0; data.move_speed=0.0
		var actor := Factory.create(data,self)
		_check(actor != null,"real actor with the archived draw bridge")
		if actor == null: continue
		actor.position=Vector2((20.0 if actors.is_empty() else 32.0)*16.0,FLOOR_Y)
		level._entities.add_child(actor)
		actors.append(actor)
	await settle(12)
	var camera := get_viewport().get_camera_2d()
	camera.position_smoothing_enabled=false
	camera.global_position=Vector2(26.0*16.0,FLOOR_Y-36.0)
	camera.zoom=Vector2(3,3)
	camera.set_process(false);camera.set_physics_process(false)
	camera.force_update_scroll()
	witness=Witness.new();witness.process_mode=Node.PROCESS_MODE_PAUSABLE;level.add_child(witness)
	await settle(3)
	# The probe ALWAYS process mode must not propagate into the tested world.
	level.process_mode=Node.PROCESS_MODE_PAUSABLE
	get_tree().paused=true
	await settle(3)
	var held := _state()
	var a1 := await _frame("after-a1",control=="after-still-brackets",false)
	await _frame("legacy-before",true,false)
	var a2 := await _frame("after-a2",control=="after-still-brackets",false)
	await _frame("debug",false,control!="debug-off")
	var a3 := await _frame("after-a3",control=="after-still-brackets",false)
	_check(a1.get_data()==a2.get_data() and a1.get_data()==a3.get_data(),"actual after A/A/A PNG bytes are identical")
	for row in rows:
		_check(row["state"]==held,"same actual frozen actor pose, physics spaces, camera and world witness: "+row["name"])
	var output := {"checks":checks,"failures":failures,"rows":rows,"control":control,"renderer":RenderingServer.get_current_rendering_method(),"adapter":RenderingServer.get_video_adapter_name(),"display":DisplayServer.get_name(),"hdr_2d":get_viewport().use_hdr_2d,"window":_vec(DisplayServer.window_get_size()),"scope":"Same real grunt/watchdog actors. B restores only the exact original deleted draw function; no whole historical checkout. No performance or listening claim."}
	var file := FileAccess.open(out_dir.path_join("render-result.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(output,"  "));file.close()
	Enemy.debug_hurtboxes=false
	get_tree().paused=false
	await finish();await AudioRelease.settle(get_tree())
	print("NE262_RENDER_DONE checks=%d failures=%d" % [checks,failures.size()])
	get_tree().quit(0 if failures.is_empty() else 1)
