from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

base=Path(__file__).resolve().parent
game=base.parent/"ne218-baseline-20261117"
label=sys.argv[1]
folder=base/label
folder.mkdir()
env=os.environ.copy()
for name in ("APPDATA","LOCALAPPDATA","XDG_DATA_HOME","XDG_CONFIG_HOME","TEMP","TMP","TMPDIR"):
    path=folder/"profile"/name
    path.mkdir(parents=True)
    env[name]=str(path)
paths=("audio/sfx/melee_glaive_hit_01.ogg", "audio/sfx/melee_glaive_hit_heavy_01.ogg", "data/melee/ion_glaive.json",
       "game/melee/melee_module.gd","autoload/sfx.gd","autoload/fx.gd","game/fx/melee_fx.gd","autoload/settings.gd", "data/feel/sound_events.json","data/audio/sound_bank.json")
sha=lambda p:sha256(p.read_bytes()).hexdigest()
assets={path:sha(game/path) for path in paths}
command=[sys.executable,"-B",str(game/"tools/comfyui/gpu_lock.py"),"--",
         "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(game),"--rendering-method","forward_plus",
         "--rendering-driver","vulkan","--audio-driver","WASAPI","--resolution","1280x720",
         "--quit-after","9000",str(base/"observe.tscn"),"--","--out="+str(folder),"--facing=both","--capture"]
if len(sys.argv)>2:
    command.append("--reduced") if sys.argv[2]=="reduced" else command.append("--weapon="+sys.argv[2])
(folder/"command.json").write_text(json.dumps({"argv":command,"source_sha256":assets},indent=2)+"\n",encoding="utf-8")
with (folder/"engine.log").open("wb") as log:
    proc=subprocess.run(command,cwd=game,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=230)
text=(folder/"engine.log").read_text(encoding="utf-8",errors="replace")
print(text[-7000:],flush=True)
assert all(sha(game/path)==digest for path,digest in assets.items())
assert proc.returncode==0 and not re.search(r"^(SCRIPT ERROR|ERROR:)|leaked at exit",text,re.M)
result=json.loads((folder/"contact-result.json").read_bytes())
assert result["failures"]==[] and len(result["rows"])==10
assert result["capture"] and result["renderer"]=="forward_plus" and all(row["voice_driver"].lower()=="wasapi" for row in result["rows"])
assert (folder/"contact-master.wav").stat().st_size>1000
