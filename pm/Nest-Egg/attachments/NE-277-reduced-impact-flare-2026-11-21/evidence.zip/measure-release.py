from pathlib import Path
from collections import Counter
import json
import math
import statistics

from PIL import Image

base = Path(__file__).resolve().parent
labels = ("stock-normal-hdr", "stock-reduced-hdr", "candidate-normal-hdr", "candidate-reduced-hdr")
runs = {}
for label in labels:
    raw = json.loads((base/label/"contact-result.json").read_bytes())
    draw = {row["name"]: row for row in raw["rows"]}
    assert len(draw) == 10 and not raw["failures"]
    info = {}
    for name, row in draw.items():
        first = row["contact_hits"][0]
        case = {"shake_count":len(row["world_shakes"]), "hits":[], "source_photo":row["contact_first_image"]}
        assert row["freeze"][0]["rin"] and row["freeze"][0]["enemy"] and row["freeze"][0]["tick"] == first["tick"]
        assert bool(row["world_shakes"]) == ("normal" in label)
        high = row["contact_definition"]["feedback"]["high"]
        low = "land_dirt" if row["contact_definition"]["feedback"]["low"] == "melee_low_heavy" else "hit_tail"
        for hit in row["contact_hits"]:
            tick = int(hit["tick"])
            active_voices = {v["id"]:v["volume_db"] for v in row["accepted_voices"] if v["tick"]==tick}
            assert {low, high} <= set(active_voices), (label,name,tick,active_voices)
            emissions = [v for v in row["flare_particles"] if v["tick"]==tick and math.dist(v["at"],hit["point"])<.01]
            assert len(emissions)==6, (label,name,tick,len(emissions))
            case["hits"].append({"damage":hit["amount"],"held":hit["hold_mode"],"pose_phase":hit["phase"],
               "voices":{k:active_voices[k] for k in (low,high)},
               "particles":[{k:v[k] for k in ("cell","rgba","radius","life")} for v in emissions]})
        for frame in row["frames"]:
            if "capture_canvas_transform" in frame:
                a,b,c,d,x,y = frame["capture_canvas_transform"]
                world_x,world_y = first["point"]
                cx,cy=round(a*world_x+c*world_y+x),round(b*world_x+d*world_y+y)
                with Image.open(base/label/row["contact_first_image"]) as img:
                    assert img.size == (1280,720) and 24 <= cx < 1256 and 24 <= cy < 696
                    colors=img.convert("RGB").crop((cx-24,cy-24,cx+24,cy+24)).getdata()
                    case["near_white_48px_square"]=sum(min(rgb)>=238 for rgb in colors)
                break
        assert "near_white_48px_square" in case, (label,name)
        info[name] = case
    runs[label]=info
    print(label,sum(len(row["hits"]) for row in info.values()),"held contacts")
before=runs[labels[0]]
for label, data in runs.items():
    percentages=Counter()
    assert data.keys()==before.keys()
    target_scale=.25 if label=="candidate-reduced-hdr" else 1.0
    for name, case in data.items():
        control=before[name]
        for a,b in zip(control["hits"],case["hits"],strict=True):
            for key in ("damage","held","pose_phase","voices"):
                assert a[key]==b[key], (label,name,key,a,b)
            for source,actual in zip(a["particles"],b["particles"],strict=True):
                for key in ("cell","radius","life"):
                    assert source[key]==actual[key], (label,name,key)
                assert source["rgba"][:3]==actual["rgba"][:3]
                assert math.isclose(source["rgba"][3]*target_scale,actual["rgba"][3],abs_tol=.000001), (label,name,source,actual)
                percentages[(actual["cell"],round(actual["rgba"][3],4))]+=1
    print(label,percentages)
old_counts=[item["near_white_48px_square"] for item in runs[labels[1]].values()]
new_counts=[item["near_white_48px_square"] for item in runs[labels[3]].values()]
print("Local near-white pixels pooled",sum(old_counts),"to",sum(new_counts), "paired medians",statistics.median(old_counts),statistics.median(new_counts))
(base/"flare-comparison.json").write_text(json.dumps(runs,indent=2)+"\n",encoding="utf-8")
