from pathlib import Path
from collections import Counter
import json
import math

base=Path(__file__).resolve().parent
labels=("stock-normal-hdr","stock-reduced-hdr")
stats={}
for label in labels:
    raw=json.loads((base/label/"contact-result.json").read_bytes())
    assert raw["checks"]==297 and raw["failures"]==[]
    counts=Counter()
    by_weapon={}
    for row in raw["rows"]:
        weapon=row["name"].split("/")[0]
        ident=row["contact_definition"]["feedback"]["high"]
        low="land_dirt" if row["contact_definition"]["feedback"]["low"]=="melee_low_heavy" else "hit_tail"
        matches=[]
        for hit in row["contact_hits"]:
            tick=int(hit["tick"])
            starts={voice["id"] for voice in row["accepted_voices"] if voice["tick"]==tick}
            assert {ident,low}<=starts, (label,row["name"],tick,starts)
            particles=[emission for emission in row["flare_particles"] if emission["tick"]==tick and
                       math.dist(emission["at"],hit["point"])<.01]
            assert particles, (label,row["name"],tick)
            counts.update((p["cell"],round(p["rgba"][3],4)) for p in particles)
            matches.append({"tick":tick,"damage":hit["amount"],"high":ident,"low":low,"particles":len(particles)})
        assert row["freeze"][0]["rin"] and row["freeze"][0]["enemy"]
        assert bool(row["world_shakes"]) == (label=="stock-normal-hdr"), (label,row["name"])
        by_weapon[row["name"]]={"hits":matches,"shakes":len(row["world_shakes"])}
    stats[label]={"checks":raw["checks"],"opacity":{str(key):n for key,n in counts.items()},"cases":by_weapon}
    print(label,"hits",sum(len(case["hits"]) for case in by_weapon.values()),"emissions",counts)
assert stats[labels[0]]["opacity"]==stats[labels[1]]["opacity"]
(base/"stock-flash-and-voices.json").write_text(json.dumps(stats,indent=2)+"\n",encoding="utf-8")
