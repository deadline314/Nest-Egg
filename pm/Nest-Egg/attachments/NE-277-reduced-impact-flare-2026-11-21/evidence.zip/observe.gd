extends "res://tools/ne277_contact_probe.gd"

var _reduced_mode := false
var _accepted: Array[Dictionary] = []
var _last_start: Dictionary = {}
var _last_cursor := 0
var _bursts: Array[Dictionary] = []
var _held_shakes: Array[Dictionary] = []
var _freeze_pair: Array[Dictionary] = []


func _ready() -> void:
	_reduced_mode = OS.get_cmdline_user_args().has("--reduced")
	EventBus.screen_shake.connect(_held_shake)
	super._ready()


func _move(id: String, weapon: WeaponData, set: MeleeSet, move: String, side: int, held: bool) -> void:
	if not held:
		return
	Settings.set_reduce_flashes(_reduced_mode)
	Settings.set_reduce_ui_motion(_reduced_mode)
	Settings.set_feel_scale("shake", 0.0 if _reduced_mode else 1.0)
	Settings.set_zoom_pulse(not _reduced_mode)
	Sfx.stop_all()
	_last_start = Sfx._last_play_msec.duplicate()
	_accepted.clear()
	_bursts.clear()
	_held_shakes.clear()
	_freeze_pair.clear()
	_last_cursor = Fx._glow._cursor if is_instance_valid(Fx._glow) else 0
	await super._move(id, weapon, set, move, side, held)
	var row: Dictionary = _rows[-1]
	row["accepted_voices"] = _accepted.duplicate(true)
	row["reduced"] = _reduced_mode
	row["flare_particles"] = _bursts.duplicate(true)
	row["world_shakes"] = _held_shakes.duplicate(true)
	row["freeze"] = _freeze_pair.duplicate(true)
	row["voice_driver"] = AudioServer.get_driver_name()
	var hits: Array = row["contact_hits"]
	var windows: Array[int] = []
	for event: Dictionary in hits:
		var tick: int = event["tick"]
		if not windows.has(tick):
			windows.append(tick)
	var source := MeleeMove.hit_layers(row["contact_definition"])
	print("HELD_AUDIO ", JSON.stringify({"case": _case_name, "damage_frames": windows, "expected": source,
		"accepted": _accepted}))


func _step() -> void:
	await super._step()
	var field := Fx._glow
	if is_instance_valid(field):
		for offset in posmod(field._cursor - _last_cursor, ParticleField.CAPACITY):
			var index := (_last_cursor + offset) % ParticleField.CAPACITY
			var cell: int = field._cell[index]
			if cell in [VfxAtlas.Cell.FLARE, VfxAtlas.Cell.GLOW]:
				var point: Vector2 = field._pos[index]
				var tint: Color = field._col0[index]
				_bursts.append({"tick": Engine.get_physics_frames(), "cell": cell,
					"at": [point.x, point.y], "rgba": [tint.r, tint.g, tint.b, tint.a],
					"radius": field._size0[index], "life": field._max_life[index]})
		_last_cursor = field._cursor
	if not _hit_facts.is_empty() and _freeze_pair.is_empty():
		_freeze_pair.append({"tick": Engine.get_physics_frames(),
			"rin": Fx.is_frozen(player), "enemy": Fx.is_frozen(_foe)})
	for index in Sfx._players.size():
		var voice: AudioStreamPlayer = Sfx._players[index]
		if not voice.playing or voice.stream == null:
			continue
		var id: StringName = Sfx._voice_sound[index]
		if id == &"":
			continue
		var start: int = Sfx._last_play_msec.get(id, -1)
		if _last_start.get(id, -1) == start:
			continue
		_last_start[id] = start
		_accepted.append({"id": str(id), "tick": Engine.get_physics_frames(), "stamp": start,
			"pitch": voice.pitch_scale, "volume_db": voice.volume_db})


func _capture_frame(name: String, index: int, frame: Dictionary) -> void:
	if not _hit_facts.is_empty() and _first_image == "":
		super._capture_frame(name, index, frame)


func _held_shake(amplitude: float, duration: float, _direction: Vector2, _origin: Vector2) -> void:
	_held_shakes.append({"tick": Engine.get_physics_frames(), "amplitude": amplitude, "duration": duration})
