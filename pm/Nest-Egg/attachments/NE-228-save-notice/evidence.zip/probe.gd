extends "res://tests/probes/training_completion.gd"

func _shot(name: String) -> void:
	if name == "training-saved":
		var banner := _level().get("hud").toast_banner as UiBanner
		_check(not banner.is_showing() or banner._label.text != "存檔未成功，原進度仍保留。", "successful real save retires its old failure notice immediately")
	await super._shot(name)
