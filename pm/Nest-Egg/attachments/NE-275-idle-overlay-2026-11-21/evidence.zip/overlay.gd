extends ScenarioBase

var draws := 0
var results: Dictionary = {}
var visual: PlayerVisual
var quality := "high"


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	var args := OS.get_cmdline_user_args()
	if args.size() != 2 or not args[0].is_absolute_path() or args[1] not in ["low", "high"]:
		get_tree().quit(2)
		return
	out_dir = args[0]
	quality = args[1]
	if DirAccess.make_dir_recursive_absolute(out_dir) != OK:
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://optional_overlay_draw_audit.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH if quality == "high" else LightQuality.Tier.LOW)
	Settings.set_reduce_flashes(quality == "low")
	Story.auto_skip = true
	Story._layer.visible = false
	add_child(LightKit.create_environment())
	var data := NewEnemiesSuite.arena_data()
	data.rain = false
	await open_arena("res://data/lighting/transfer.tres", 24.0, data)
	visual = player._visual
	visible_aim()
	level.process_mode = Node.PROCESS_MODE_DISABLED
	Engine.time_scale = 0.0
	visual.draw.connect(func() -> void: draws += 1)
	await _phase("idle-before", 90)
	visual.notify_fired(Palette.CYAN)
	await _phase("muzzle", 2)
	await _phase("muzzle-clear", 12)
	await _phase("idle-after-muzzle", 10)
	visual.notify_melee_swing({"style": "thrust", "life": 0.22, "radius": 48.0, "width": 4.0}, 1)
	var requested := draws
	await RenderingServer.frame_post_draw
	results["swing-immediate"] = {"draws": draws - requested}
	capture("swing-immediate")
	await _phase("swing", 4)
	await _phase("swing-clear", 24)
	await _phase("idle-after-swing", 10)
	player.is_blocking = true
	await _phase("shield", 6)
	visual.notify_parry()
	await _phase("parry", 2)
	player.is_blocking = false
	player._guard_lockout_left = 0.2
	await _phase("break", 2)
	player._guard_lockout_left = 0.0
	await _phase("shield-clear", 34)
	await _phase("idle-after-shield", 10)
	visual.notify_finisher()
	await _phase("finisher", 2)
	await _phase("finisher-clear", 27)
	visual.begin_materialize()
	await _phase("materialize", 2)
	await _phase("materialize-clear", 88)
	await _phase("idle-final", 90)
	Engine.time_scale = 1.0
	var file := FileAccess.open(out_dir.path_join("draws.json"), FileAccess.WRITE)
	if file == null:
		get_tree().quit(2)
		return
	file.store_string(JSON.stringify({"adapter": RenderingServer.get_video_adapter_name(),
		"hdr_2d": get_viewport().use_hdr_2d, "quality": quality, "phases": results, "errors": failures}, "  ") + "\n")
	file.close()
	await finish()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures > 0 else 0)


func visible_aim() -> void:
	AimInput.set_virtual_gamepad(player, true)
	AimInput.restore_direction(Vector2.RIGHT)
	player.aim_dir = Vector2.RIGHT
	level.camera.set_physics_process(false)
	level.camera.position_smoothing_enabled = false
	level.camera.offset = Vector2.ZERO
	level.camera.global_position = player.global_position - Vector2(0.0, 28.0)
	level.camera.reset_smoothing()
	level.camera.force_update_scroll()
	level._lighting._lightning_gap = 1.0e9
	await RenderingServer.frame_post_draw


func _phase(id: String, ticks: int) -> void:
	var before := draws
	for i in ticks:
		visual._process(1.0 / 120.0)
		await RenderingServer.frame_post_draw
	results[id] = {"ticks": ticks, "draws": draws - before}
	capture(id)
