from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import re
import subprocess
import sys

root = Path.cwd()
work = Path(__file__).resolve().parent
runtime = ("game/player/player_visual.gd", "game/player/guard_presenter.gd", "game/fx/shield_surface.gd")
godot = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
weapons = ("blade", "dagger", "glaive", "maul", "whip")
parent = "281448e8262d74ebc7b8318ed59ad5b71ab3ea12"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


assert git("rev-parse", "HEAD").decode().strip() == parent
assert git("branch", "--show-current").decode().strip() == "codex/ticket-work-20261121-idle-redraw"
assert set(git("diff", "--name-only").decode().splitlines()) == set(runtime)
versions = {
    "reference": {p: git("show", f"{parent}:{p}") for p in runtime},
    "candidate": {p: (root / p).read_bytes() for p in runtime},
}
for name, version in versions.items():
    folder = work / "inputs" / name
    for p, blob in version.items():
        target = folder / p
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as file:
            file.write(blob)


def install(name):
    actual = {p: (root / p).read_bytes() for p in runtime}
    assert actual in list(versions.values()), "Runtime changed outside the benchmark."
    desired = versions[name]
    for p in runtime:
        if actual[p] != desired[p]:
            (root / p).write_bytes(desired[p])


def run(tag, version):
    install(version)
    folder = work / tag
    folder.mkdir()
    env = os.environ.copy()
    for key in ("APPDATA", "LOCALAPPDATA", "XDG_DATA_HOME", "XDG_CONFIG_HOME", "TEMP", "TMP", "TMPDIR"):
        destination = folder / "profile" / key
        destination.mkdir(parents=True)
        env[key] = str(destination)
    command = [sys.executable, "-B", str(root / "tools/comfyui/gpu_lock.py"), "--", godot, "--path", str(root),
               "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--audio-driver", "Dummy",
               "--resolution", "1280x720", "--quit-after", "22000", str(work / "timing.tscn"), "--",
               "--out=" + str(folder), "--tag=after-" + tag, "--quality=high", "--perf"]
    (folder / "command.json").write_text(json.dumps(command, indent=2) + "\n")
    with (folder / "raw.log").open("wb") as log:
        process = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    assert process.returncode == 0, (tag, process.returncode)
    text = (folder / "raw.log").read_text(encoding="utf-8")
    assert re.search(r"Forward\+.*9070 XT", text) and not re.search(r"^(?:SCRIPT )?ERROR:", text, re.M)
    report = json.loads((folder / "grip-timings.json").read_bytes())
    assert report["resolution"] == [1280, 720] and report["renderer"] == "forward_plus"
    assert report["failures"] == report["max_fps"] == report["vsync"] == 0
    assert not report["reduced_flashes"] and not report["reduced_ui_motion"]
    assert set(report["records"]) == set(weapons)
    values = {}
    for weapon, record in report["records"].items():
        samples = record["samples_ms"]
        assert record["drawn"] and record["dedicated_attachment"]
        assert record["physics_steps"] >= 10 and len(samples) == 600 and min(samples) > 0
        values[weapon] = median(samples)
    print(tag, {k: round(v, 4) for k, v in values.items()}, flush=True)
    return values


pairs = []
try:
    for version in ("reference", "candidate"):
        run("timing-warm-" + version, version)
    for pair in range(1, 7):
        order = ("reference", "candidate") if pair % 2 else ("candidate", "reference")
        measurements = {name: run(f"timing-{pair:02d}-{name}", name) for name in order}
        pairs.append({"order": order, "samples": measurements})
finally:
    install("candidate")
assert all((root / p).read_bytes() == versions["candidate"][p] for p in runtime)
deltas = {weapon: [100 * (p["samples"]["candidate"][weapon] / p["samples"]["reference"][weapon] - 1)
                  for p in pairs] for weapon in weapons}
report = {"parent": parent, "pairs": pairs, "percent_deltas": deltas,
          "paired_median_percent": {weapon: median(values) for weapon, values in deltas.items()},
          "source_sha256": {name: {p: sha256(blob).hexdigest() for p, blob in version.items()}
                            for name, version in versions.items()}}
(work / "timing-summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report["paired_median_percent"]), flush=True)
