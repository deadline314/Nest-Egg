from hashlib import sha256
from pathlib import Path
import json

import numpy as np
from PIL import Image

base = Path(__file__).resolve().parent
active = {"muzzle", "swing", "swing-immediate", "shield", "parry", "break", "finisher", "materialize"}
idle = {"idle-before", "idle-after-muzzle", "idle-after-swing", "idle-after-shield", "idle-final"}
counts = {}
for quality in ("high", "low"):
    folders = {mode: base / f"only-{mode}-{quality}" for mode in ("stock", "candidate")}
    phase_data = {}
    full = {}
    for mode, folder in folders.items():
        case = folder.name
        assert (base / (case + ".exit")).read_text(encoding="ascii").strip() == "0"
        assert (base / (f"{mode}-{quality}.exit")).read_text(encoding="ascii").strip() == "0"
        for prefix in (case, f"{mode}-{quality}"):
            log = (base / (prefix + ".log")).read_text(encoding="utf-8")
            assert "RX 9070 XT" in log and "Forward+" in log
            assert not any(line.startswith(("ERROR:", "SCRIPT ERROR:")) for line in log.splitlines())
        meta = json.loads((folder / "draws.json").read_bytes())
        assert meta["hdr_2d"] and meta["errors"] == 0 and meta["quality"] == quality
        phase_data[mode] = meta["phases"]
        full[mode] = json.loads((base / f"{mode}-{quality}/draws.json").read_bytes())["phases"]
    assert set(phase_data["stock"]) == set(phase_data["candidate"])
    assert phase_data == full
    assert all(phase_data["candidate"][key]["draws"] == 0 < phase_data["stock"][key]["draws"] for key in idle)
    assert all(phase_data["stock"][key]["draws"] == phase_data["candidate"][key]["draws"] > 0 for key in active)
    assert phase_data["candidate"]["swing-immediate"]["draws"] == 1
    pixels = {}
    baseline = {mode: (folder / "idle-before.png").read_bytes() for mode, folder in folders.items()}
    for key in phase_data["stock"]:
        images = {mode: folder / (key + ".png") for mode, folder in folders.items()}
        hashes = {mode: sha256(png.read_bytes()).hexdigest() for mode, png in images.items()}
        for mode, png in images.items():
            assert (png.read_bytes() != baseline[mode]) == (key in active), key
        diff = 0
        if hashes["stock"] != hashes["candidate"]:
            p, q = (np.asarray(Image.open(path).convert("RGB")) for path in images.values())
            diff = int(np.count_nonzero(np.any(p != q, axis=2)))
        if quality == "high" or key not in {"muzzle", "parry", "shield"}:
            assert diff == 0, (quality, key, diff)
        else:
            assert diff <= 32, (quality, key, diff)
        pixels[key] = {"changed_pixels": diff, "sha256": hashes}
    totals = {mode: sum(row["draws"] for row in rows.values()) for mode, rows in phase_data.items()}
    assert totals == {"stock": 416, "candidate": 174}
    counts[quality] = {"totals": totals, "phases": phase_data, "isolated_pixels": pixels}
(base / "visual-verification.json").write_text(json.dumps(counts, indent=2) + "\n")
print({q: row["totals"] for q, row in counts.items()})
