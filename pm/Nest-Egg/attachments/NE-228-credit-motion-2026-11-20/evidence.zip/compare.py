from math import isclose
from pathlib import Path
import json

base = Path(__file__).resolve().parent
lookup = lambda data: {(row["mode"],row["step"]): row for row in data["rows"]}
stock, candidate = [lookup(json.loads((base/tag/"result.json").read_bytes())) for tag in ("stock","candidate")]
assert len(stock) == 22 and set(stock) == set(candidate)
for key,row in stock.items():
    equivalent = candidate[key]
    for prop in ("wallet","counter_value","pile_value","pile_cell","collected","motion","flashes"):
        assert row[prop] == equivalent[prop], (key,prop)
    assert equivalent["wallet"] == equivalent["counter_value"]
for mode in ("motion","both"):
    assert stock[mode,"gain"]["shown"] < stock[mode,"gain"]["wallet"]
    for phase in ("gain","spend","refuse"):
        row = candidate[mode,phase]
        assert row["shown"] == row["wallet"] and row["flash"] == 0 and not row["processing"]
    assert candidate[mode,"refuse"]["wallet"] == candidate[mode,"spend"]["wallet"]
assert candidate["flashes","gain"]["shown"] < candidate["flashes","gain"]["wallet"]
assert candidate["flashes","gain"]["processing"]
assert candidate["flashes","gain"]["flash"] == 0
assert stock["flashes","spend"]["flash"] > 0 and candidate["flashes","spend"]["flash"] == 0
assert not candidate["flashes","spend"]["processing"]
for phase in ("gain-toggle","spend-toggle"):
    row = candidate["toggle",phase]
    assert row["flash"] == 0 and row["shown"] == row["wallet"] and not row["processing"]
    assert stock["toggle",phase]["processing"]
for phase in ("gain","spend"):
    s,c = stock["standard",phase],candidate["standard",phase]
    assert c["flash"] > 0 and c["processing"] and c["flash_color"] == s["flash_color"]
    assert isclose(c["shown"],s["shown"],abs_tol=0.0001)
doc = {"matched":len(stock), "actual_pile": stock["standard","gain"]["pile_cell"],
       "pile_value": stock["standard","gain"]["pile_value"],
       "audited_no_balance_changes":True,
       "rows":[{"mode":key[0],"stage":key[1],"stock":stock[key],"candidate":candidate[key]} for key in stock]}
(base/"paired.json").write_text(json.dumps(doc,indent=2)+"\n")
print(f'Street credit counter: {doc["matched"]} matching events with real authored pickup {doc["actual_pile"]} (+{doc["pile_value"]})')
