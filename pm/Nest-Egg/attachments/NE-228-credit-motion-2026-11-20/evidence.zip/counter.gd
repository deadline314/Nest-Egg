extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	for key: String in OS.get_cmdline_user_args():
		if key.begins_with("--out="):
			_out = key.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://credit_counter_fixture.cfg")
	Settings.set_brightness(0.5)
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	DirAccess.make_dir_recursive_absolute(_out)
	for mode: String in ["standard", "motion", "flashes", "both", "toggle"]:
		if not await _observe(mode):
			printerr("Street credit counter fixture failed for ", mode)
			get_tree().quit(1)
			return
	var file := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"rows":_rows, "adapter":RenderingServer.get_video_adapter_name(),
		"renderer":RenderingServer.get_current_rendering_method(),"hdr_2d":get_viewport().use_hdr_2d}, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)


func _observe(mode: String) -> bool:
	seed(506228)
	Settings.set_reduce_ui_motion(mode in ["motion", "both"])
	Settings.set_reduce_flashes(mode in ["flashes", "both"])
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	var pile: CreditPickup
	for node in level._entities.get_children():
		if node is CreditPickup and pile == null and node._requires_flag == &"" and not node._elevated:
			pile = node
		elif node is Enemy:
			node.process_mode = Node.PROCESS_MODE_DISABLED
	if pile == null or pile.value <= 1 or pile.collected:
		return false
	for node in level.find_children("*", "", true, false):
		if node is ChapterCard:
			node.queue_free()
	var player := level.player
	var counter := level.hud.credits_tag
	player.global_position = pile.global_position + Vector2(-30, 0)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	level._lighting._lightning_gap = 1.0e9
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	camera.global_position = pile.global_position + Vector2(-32, -43)
	camera.reset_smoothing()
	camera.force_update_scroll()
	var initial := Progression.credits
	if not await _record(mode, "before", pile, counter):
		return false
	player.global_position = pile.global_position
	for tick in 25:
		await get_tree().process_frame
		if pile.collected:
			break
	if not pile.collected or Progression.credits != initial + pile.value or not await _record(mode, "gain", pile, counter):
		return false
	if mode == "toggle":
		Settings.set_reduce_ui_motion(true)
		if not await _record(mode, "gain-toggle", pile, counter):
			return false
		Settings.set_reduce_ui_motion(false)
	if not Progression.spend(pile.value / 2) or not await _record(mode, "spend", pile, counter):
		return false
	if Progression.spend(Progression.credits + 1) or not await _record(mode, "refuse", pile, counter):
		return false
	if mode == "toggle":
		Settings.set_reduce_flashes(true)
		if not await _record(mode, "spend-toggle", pile, counter):
			return false
		Settings.set_reduce_flashes(false)
	level.queue_free()
	await get_tree().process_frame
	return true


func _record(mode: String, stage: String, pile: CreditPickup, counter: CreditsTag) -> bool:
	await RenderingServer.frame_post_draw
	var image := mode + "-" + stage + ".png"
	var outcome := Capture.image(get_viewport()).save_png(_out.path_join(image))
	_rows.append({"mode":mode,"step":stage,"file":image,"wallet":Progression.credits,"counter_value":counter.value(),
		"shown":counter._shown,"flash":counter._flash,"flash_color":str(counter._flash_color),
		"processing":counter.is_processing(),"pile_value":pile.value,"pile_cell":str(pile.cell),"collected":pile.collected,
		"motion":Settings.get_reduce_ui_motion(),"flashes":Settings.get_reduce_flashes()})
	return outcome == OK
