extends ScenarioBase

var _boss: JanusBoss
var _tag := ""
var _records: Dictionary = {}


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
		elif argument.begins_with("--tag="):
			_tag = argument.trim_prefix("--tag=")
	if not out_dir.is_absolute_path() or _tag.is_empty():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch3_janus_intro_seen", true, false)
	level = Level.new()
	level.configure(load("res://data/levels/ch3_gate_hall.tres") as LevelData)
	add_child(level)
	player = level.player
	level._next_story_trigger = level._layout.story_triggers.size()
	for entity in level._entities.get_children():
		if entity is JanusBoss:
			_boss = entity
	if _boss == null:
		push_error("the authored gate hall does not have Janus")
		get_tree().quit(2)
		return
	var atlas: Variant = _boss.get("_frame_texture")
	_verify(_boss.rig != null and _boss.rig.skin_id == "janus", "the gatekeeper uses the original human rig")
	if _tag == "after":
		_verify(atlas is Texture2D and atlas.resource_path == "res://art/weapons/janus_work_frame.png", "the frame loads separately")
	else:
		_verify(atlas == null, "the original frame strokes remain available")
	player.set_physics_process(false)
	player.health.grant_invulnerability(100.0)
	_boss.set_physics_process(false)
	level.hud.visible = false
	_boss.call(&"_wake")
	for facing in [-1, 1]:
		var side := "left" if facing == -1 else "right"
		_boss.facing = facing
		player.global_position = _boss.global_position + Vector2(facing * 48.0, 0.0)
		snap_camera()
		await settle(30)
		_boss.fsm.transition(&"idle")
		await _record(side + "-intact")
		_boss.set("_move_id", &"scan_low")
		_boss.fsm.transition(&"windup")
		await _record(side + "-scan")
	_boss.fsm.transition(&"idle")
	_boss.set("_move_id", &"call_backup")
	_boss.fsm.transition(&"windup")
	await _record("backup-warning")
	_boss.call(&"_crack_shield")
	_boss.call(&"_break_comm")
	await settle(38)
	await _record("broken")
	_verify(_boss.shield_cracked and _boss.comm_broken and not _boss.is_part_open(&"comm"), "the broken communication box no longer takes hits")
	_boss.call(&"_halt", false)
	await settle(8)
	await _record("stopped")
	_verify(_boss.halted and not _boss.pin_pulled and _boss.completed_channel() == &"", "the stop keeps the repair pin available")
	var size := get_window().size
	var report := {"tag": _tag, "records": _records, "failures": failures,
		"size": [size.x, size.y], "adapter": RenderingServer.get_video_adapter_name()}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)


func _record(label: String) -> void:
	_boss.call(&"_drive_rig", 0.0)
	_boss.call(&"_update_hurt_parts")
	_boss.queue_redraw()
	await settle(3)
	await RenderingServer.frame_post_draw
	var parts: Dictionary = {}
	for id in [&"shield", &"shield_lock", &"arm_lock", &"comm"]:
		var point: Vector2 = _boss.call(&"_part_offset", id)
		parts[id] = {"center": [point.x, point.y], "open": _boss.is_part_open(id)}
	var pin: Vector2 = _boss.call(&"_pin_local")
	_records[label] = {"parts": parts, "pin": [pin.x, pin.y], "facing": _boss.facing, "state": _boss.fsm.current,
		"health": _boss.health.current, "shield_cracked": _boss.shield_cracked,
		"comm_broken": _boss.comm_broken, "halted": _boss.halted}
	capture(label)


func _verify(condition: bool, label: String) -> void:
	if not condition:
		failures += 1
		push_error(label)
