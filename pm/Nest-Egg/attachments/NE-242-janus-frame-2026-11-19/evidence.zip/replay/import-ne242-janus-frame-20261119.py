from pathlib import Path
import os
import re
import shutil
import subprocess

root = Path.cwd()
out = root / 'work/ne242-janus-frame-20261119'
project = out / 'import-project'
source = Path('art/weapons/janus_work_frame.png')
asset = project / source
asset.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(root / source, asset)
(project / 'project.godot').write_text('config_version=5\n\n[application]\nconfig/name="Work frame texture import"\n', encoding='utf-8')
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
args = [engine, '--headless', '--editor', '--import', '--path', str(project)]
env = os.environ.copy()
for name in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[name] = str(out / 'import-profile' / name)
metadata = asset.with_suffix('.png.import')
for step in (1, 2):
    if step == 2:
        text = metadata.read_text(encoding='utf-8')
        assert 'mipmaps/generate=false' in text
        metadata.write_text(text.replace('mipmaps/generate=false', 'mipmaps/generate=true'), encoding='utf-8', newline='\n')
    with (out / f'import-{step}.log').open('wb') as log:
        run = subprocess.run(args, cwd=project, stdout=log, stderr=subprocess.STDOUT, env=env, timeout=120)
    raw = (out / f'import-{step}.log').read_text(encoding='utf-8')
    assert run.returncode == 0 and 'ERROR:' not in raw
text = metadata.read_text(encoding='utf-8')
assert 'mipmaps/generate=true' in text and 'source_file="res://art/weapons/janus_work_frame.png"' in text
ctex = re.search(r'^path="res://([^\"]+\.ctex)"', text, re.M)[1]
assert (project / ctex).stat().st_size > 0
shutil.copyfile(metadata, (root / source).with_suffix('.png.import'))
print(ctex)

