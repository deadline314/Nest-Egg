from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = root / 'work/ne242-janus-frame-20261119'
variant = sys.argv[1]
assert variant in ('before', 'after', 'fallback')
out = base / f'native-{variant}'
out.mkdir()
probe = base / 'probe.gd'
scene = base / 'probe.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n'
                 '[node name="JanusFrame" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
command = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '1800',
           scene.as_posix(), '--', '--out=' + str(out), '--tag=' + variant]
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
config = shared / 'data/bosses/janus.json'
saved = config.read_bytes()
declared = b'res://art/weapons/janus_work_frame.png'
assert (declared in saved) == (variant != 'before')
try:
    if variant == 'fallback':
        assert saved.count(declared) == 1
        config.write_bytes(saved.replace(declared, b'res://art/weapons/test_missing_janus_work_frame.png'))
    with (out / 'raw.log').open('wb') as log:
        result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=160)
finally:
    if variant == 'fallback':
        config.write_bytes(saved)
raw = (out / 'raw.log').read_text(encoding='utf-8')
print(raw[-3500:], flush=True)
report = json.loads((out / 'report.json').read_text(encoding='utf-8'))
print(json.dumps(report, ensure_ascii=False), flush=True)
assert '9070 XT' in report['adapter'] and report['size'] == [1280, 720]
assert result.returncode == report['failures'] == 0 and 'SCRIPT ERROR' not in raw and 'ERROR:' not in raw
assert len(report['records']) == 7
assert ('hooks.work_frame_art' in raw) == (variant == 'fallback')

