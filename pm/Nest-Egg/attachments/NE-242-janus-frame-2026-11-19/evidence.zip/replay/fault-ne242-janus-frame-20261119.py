from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = root / 'work/ne242-janus-frame-20261119'
boss, fault = sys.argv[1:]
assert boss in ('janus', 'yong') and fault in ('missing', 'wrong-type', 'wrong-size')
if boss == 'janus':
    hook = 'work_frame_art'
    source = base / 'probe.tscn'
else:
    hook = 'baton_art'
    source = root / 'work/ne242-yong-baton-20261119/probe.tscn'
out = base / f'fault-{boss}-{fault}'
out.mkdir()
config = shared / f'data/bosses/{boss}.json'
original = config.read_bytes()
candidate = json.loads(original)
substitution = {'missing': 'res://art/weapons/test_missing_janus_work_frame.png',
                'wrong-type': {'path': 'bad'}, 'wrong-size': 'res://art/weapons/yong_baton.png'}[fault]
assert candidate['hooks'][hook].startswith('res://')
candidate['hooks'][hook] = substitution
(out / 'fault.json').write_text(json.dumps({'hook': hook, 'value': substitution}, indent=2) + '\n')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
command = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '1800',
           source.as_posix(), '--', '--out=' + str(out), '--tag=fallback']
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
try:
    config.write_text(json.dumps(candidate, ensure_ascii=False), encoding='utf-8')
    with (out / 'raw.log').open('wb') as log:
        result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=160)
finally:
    config.write_bytes(original)
raw = (out / 'raw.log').read_text(encoding='utf-8')
report = json.loads((out / 'report.json').read_bytes())
assert result.returncode == report['failures'] == 0 and f'hooks.{hook}' in raw and 'ERROR:' not in raw
print(out.name, 'fallback verified in', len(report['records']), 'states', flush=True)
