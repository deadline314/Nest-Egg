extends ScenarioBase


func _ready() -> void:
	_review.call_deferred()


func _review() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
	if out_dir.is_empty() or DisplayServer.get_name() == "headless" or not get_viewport().use_hdr_2d:
		push_error("armor review requires native HDR 2D and an output directory")
		get_tree().quit(1)
		return
	Story.auto_skip = true
	seed(222211)
	add_child(LightKit.create_environment())
	await open_arena("res://data/lighting/neutral.tres", 18.0)
	await clear_enemies()
	var trooper := spawn_enemy("res://data/enemies/grunt.tres", 21.0)
	trooper.data = trooper.data.duplicate()
	trooper.data.detect_range = 0.0
	trooper.data.attack_range = 0.0
	trooper.data.move_speed = 0.0
	trooper.data.finish_health_ratio = 0.0
	trooper.health.setup(10, 0.0)
	await settle(4)
	var before := RigDebris._active
	var armor_before := trooper.rig._armor_visible
	_check(armor_before > 0, "trooper visibly starts with armor")
	await RenderingServer.frame_post_draw
	capture("trooper-before-hit")
	for i in 6:
		var hit := DamageInfo.create(1, Combat.Team.PLAYER, &"trooper_armor_review")
		hit.origin = player.global_position
		hit.ignore_invulnerability = true
		trooper.hurtbox.receive(hit)
	_check(trooper.health.current == 4, "all controlled hits go through the real enemy hurtbox")
	_check(trooper.rig._armor_visible < armor_before, "enemy health crosses an original armor step")
	await settle(2)
	var debris := level.find_children("*", "RigDebris", true, false)
	_check(RigDebris._active > before and not debris.is_empty(),
		"real enemy armor uses physical debris")
	var start: Vector2 = debris[0].position if not debris.is_empty() else Vector2.ZERO
	await RenderingServer.frame_post_draw
	capture("trooper-armor-break")
	await settle(12)
	if not debris.is_empty():
		_check(is_instance_valid(debris[0]) and start.distance_to(debris[0].position) > 1.0,
			"enemy armor debris visibly travels after the hit")
	await RenderingServer.frame_post_draw
	capture("trooper-armor-travel")
	await wait(1.6)
	_check(RigDebris._active == before, "detached armor returns to its pool")
	await finish()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)


func _check(ok: bool, msg: String) -> void:
	if ok:
		print("PASS ", msg)
	else:
		failures += 1
		push_error(msg)
