extends ScenarioBase


func _ready() -> void:
	_review.call_deferred()


func _review() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
	if out_dir.is_empty():
		get_tree().quit(1)
		return
	Story.auto_skip = true
	Settings.set_dash_silhouettes(true)
	add_child(LightKit.create_environment())
	await open_arena("res://data/lighting/neutral.tres", 30.0)
	await clear_enemies()
	AimInput.set_virtual_gamepad(player, true)
	Input.action_press(&"move_right")
	Input.action_press(&"aim_right")
	Input.action_press(&"dash")
	var pool := player._visual._ghost_pool
	for i in 10:
		await get_tree().physics_frame
		if pool.active_count() > 0:
			break
	_check(player.state == Player.State.DASH and player.facing == 1 and pool.active_count() > 0,
		"a genuine dash has active silhouettes")
	await RenderingServer.frame_post_draw
	capture("dash-before-fatal")
	Input.action_release(&"dash")
	Input.action_release(&"move_right")
	Input.action_release(&"aim_right")
	AimInput.set_virtual_gamepad(player, false)
	var hit := DamageInfo.create(9999, Combat.Team.ENEMY, &"dash_fall_review")
	hit.origin = player.global_position - Vector2(30, 0)
	hit.impact = 7.0
	hit.ignore_invulnerability = true
	_check(player.health.take_damage(hit) and player.is_dead(), "a real rear hit ends the dash")
	_check(pool.active_count() == 0, "fatal event clears dash silhouettes synchronously")
	await wait(0.28)
	var animator := player._visual.rig.animator as HumanoidAnimator
	_check(animator._death_dir == -1.0 and animator._death_force == 1.0,
		"rear-heavy fall replaces the active dash pose")
	await RenderingServer.frame_post_draw
	capture("dash-after-fatal")
	await finish()
	await open_arena("res://data/lighting/neutral.tres", 30.0)
	await clear_enemies()
	var unusable := DamageInfo.create(0, Combat.Team.ENEMY, &"bad_vector")
	unusable.origin = Vector2.INF
	unusable.knockback = Vector2(NAN, 0.0)
	unusable.impact = INF
	player.health.kill(unusable)
	await wait(0.28)
	animator = player._visual.rig.animator as HumanoidAnimator
	_check(player.is_dead() and animator._death_dir == 1.0 and animator._death_force == 0.0,
		"unusable direction and impact leave the safe forward-hit defaults")
	await finish()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)


func _check(ok: bool, msg: String) -> void:
	if ok:
		print("PASS ", msg)
	else:
		failures += 1
		push_error(msg)
