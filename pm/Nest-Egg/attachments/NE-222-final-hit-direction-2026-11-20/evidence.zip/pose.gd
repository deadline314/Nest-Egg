extends ScenarioBase


func _ready() -> void:
	_review.call_deferred()


func _review() -> void:
	var mode := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
		elif arg.begins_with("--mode="):
			mode = arg.trim_prefix("--mode=")
	if out_dir.is_empty() or mode not in ["before", "after", "legacy"] or DisplayServer.get_name() == "headless" or not get_viewport().use_hdr_2d:
		push_error("fatal preview needs a native HDR viewport, output path, and mode")
		get_tree().quit(1)
		return
	if mode == "legacy":
		RigLibrary.character("rin")["armor_debris"] = true
	Story.auto_skip = true
	add_child(LightKit.create_environment())
	var rows: Array[Dictionary] = []
	for facing: int in [1, -1]:
		for side: int in [1, -1]:
			for strength: String in (["light", "heavy"] if mode != "legacy" else ["light"]):
				await open_arena("res://data/lighting/neutral.tres", 30.0)
				await clear_enemies()
				await settle(2)
				seed(222211)
				player.facing = facing
				var hit := DamageInfo.create(9999, Combat.Team.ENEMY, &"fatal_pose_review")
				hit.origin = player.global_position + Vector2(side * 30, 0)
				hit.impact = 7.0 if strength == "heavy" else 1.0
				if strength == "heavy":
					hit.knockback = Vector2(-side * 140, 0)
				hit.ignore_invulnerability = true
				var before := RigDebris._active
				var accepted := player.health.take_damage(hit)
				var spawned := RigDebris._active - before
				var rig: CharacterRig = player._visual.rig
				var tag := "face%d_hit%d_%s" % [facing, side, strength]
				_check(accepted and player.is_dead() and rig._armor_visible == 0, tag + " fatal damage reaches game health and clothing")
				_check(spawned > 0 if mode == "legacy" else spawned == 0, tag + " whole-part debris follows selected control")
				var expected_dir := -1.0 if mode == "after" and side != facing else 1.0
				var expected_force := 1.0 if mode == "after" and strength == "heavy" else 0.0
				var animator := rig.animator as HumanoidAnimator
				var t := 0.0
				for sample: float in [0.12, 0.28, 0.44, 0.55]:
					await wait(sample - t)
					t = sample
					await RenderingServer.frame_post_draw
					var center := rig.bone(&"hip").get_global_transform_with_canvas().origin
					var head := rig.bone(&"head").get_global_transform_with_canvas().origin
					var file := "%s_%03d" % [tag, roundi(sample * 100)]
					capture(file)
					rows.append({"file": file + ".png", "facing": facing, "source_side": side, "strength": strength,
						"sample_time": sample, "animator_time": animator._death_time, "force": animator._death_force,
						"dir": animator._death_dir, "legacy_debris": mode == "legacy", "spawned": spawned,
						"hip_rotation": rig.bone(&"hip").rotation, "hip_view": [center.x, center.y], "head_view": [head.x, head.y]})
				_check(animator._death_time > 0 and animator._death_dir == expected_dir, tag + " animator receives expected direction")
				_check(animator._death_force == expected_force, tag + " animator receives expected force")
				await finish()
	var receipt := FileAccess.open(out_dir.path_join("samples.json"), FileAccess.WRITE)
	if receipt == null:
		push_error("could not create native fatal receipt")
		failures += 1
	else:
		receipt.store_string(JSON.stringify(rows, "\t"))
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)


func _check(ok: bool, msg: String) -> void:
	if ok:
		print("PASS ", msg)
	else:
		failures += 1
		push_error(msg)
