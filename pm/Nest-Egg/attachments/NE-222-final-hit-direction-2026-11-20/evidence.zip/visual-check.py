from pathlib import Path
from collections import Counter
import json
from PIL import Image,ImageDraw,ImageFont

base=Path(__file__).resolve().parent
read=lambda case:json.loads((base/case/'samples.json').read_bytes())
rows={case:read(case) for case in ('pose-before','pose-after','pose-legacy')}
assert [len(rows[name]) for name in rows]==[32,32,16]
verify={}
for name,group in rows.items():
    summary=Counter()
    for row in group:
        facing=row['facing']
        side=row['source_side']
        front=(facing==side)
        assert front or side==-facing
        if row['animator_time']>0:
            assert row['dir']==(-1 if name=='pose-after' and not front else 1)
            assert row['force']==(1 if name=='pose-after' and row['strength']=='heavy' else 0)
        else:
            assert row['sample_time']<=0.12
        assert row['spawned']>0 if name=='pose-legacy' else row['spawned']==0
        summary[(facing,side,row['strength'],row['dir'],row['force'],row['spawned'])]+=1
        path=base/name/row['file']
        with Image.open(path) as img:
            assert img.size==(1280,720)
            img.verify()
    verify[name]=[{**dict(zip(('facing','side','strength','direction','force','physical_fragments'),k)),'frames':v}
                  for k,v in sorted(summary.items())]
(base/'paired-visual-validation.json').write_text(json.dumps(verify,indent=2)+'\n')
font=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc', 23)
small=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc', 17)
def compare(filename,modes,labels,cases,time,strength):
    size=(430,276)
    canvas=Image.new('RGB',(920,56+len(cases)*314),(27,27,37))
    painter=ImageDraw.Draw(canvas)
    for col,caption in enumerate(labels):
        painter.text((22+col*454,12),caption,font=font,fill='#faf2f6')
    for i,(facing,side,tag) in enumerate(cases):
        for col,folder in enumerate(modes):
            filename_part=f'face{facing}_hit{side}_{strength}_{time:03}.png'
            im=Image.open(base/folder/filename_part).convert('RGB')
            left=0 if facing==1 else 230
            box=(0,164,650,581) if time==28 else (left,276,left+540,622)
            crop=im.crop(box).resize(size,Image.Resampling.LANCZOS)
            canvas.paste(crop,(22+454*col,48+314*i))
        painter.text((22,48+314*i+size[1]),tag,font=small,fill='#faf2f6')
    canvas.save(base/filename)
compare('rear-fall-before-after.png',('pose-before','pose-after'),
    ('修正前','修正後'),
    ((1,-1,'面向右，背後重擊'),(-1,1,'面向左，背後重擊')),44,'heavy')
compare('clothing-fragments-before-after.png',('pose-legacy','pose-after'),
    ('重現舊衣物碎片','正式衣物受損'),
    ((1,1,'面向右，正面致命輕擊'),(-1,-1,'面向左，正面致命輕擊')),28,'light')
print({name:len(group) for name,group in rows.items()})
