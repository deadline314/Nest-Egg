#!/usr/bin/env bash
set -uo pipefail
cd /d/NestEggVerification/ne258-20261117
python3() { 'C:/Users/stanl/AppData/Local/Programs/Python/Python313/python.exe' "$@"; }
export -f python3
export GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
export SHARDS=3
export LOG_DIR='D:/NestEggVerification/evidence-20261117/ne258/official-owner-wall-AAE/shards'
mkdir -p "$LOG_DIR"
export PYTHONIOENCODING=utf-8
tools/run_tests_changed.sh aae101cfc85b192af9558d5b38d250aea4f1e726
