# NE-258 wall-light correction proposal (not implemented)

The original v2 native report and unchanged HDR buffers establish a fully black world receiver behind real terrain while Stalker's light query remains 0.70277 and reveals it. `LightKit.light_level_at` has one production caller, Stalker, at its existing 0.12-second interval. Its other current callers are ExposureSuite. `mark_aimed` currently has one production source, WeaponLight.

## Why a single WORLD physics ray is insufficient

The renderer and collision engine do not share an occlusion mask. [Godot's official shadow reference](https://docs.godotengine.org/en/stable/tutorials/2d/2d_lights_and_shadows.html) specifies the relationship between Light2D's Shadow Item Cull Mask and LightOccluder2D's Occluder Light Mask. These are render masks, not physics collision layers.

| Existing source | Physics behavior | Actual render occlusion |
| --- | --- | --- |
| `Terrain.build/_make_occluder` | WORLD rectangles | Matching rectangle occluders; one-way platforms do not receive occluders |
| `PropNode._add_occluder` | Props may have no solid collider or only one-way support | Explicit inset rectangle when the prop data requests occlusion |
| `Gate._ready/_set_open` | WORLD collider, disabled when opened | Existing full rectangle remains registered; this proposal preserves that current renderer policy |
| `Breakable._ready` | WORLD collider | No LightOccluder2D created |
| `Level._lock_boss_arena` | WORLD collision boundary | No LightOccluder2D created |

Consequently, a reusable RayCast2D avoids query allocations but introduces false blockers and misses actual prop blockers. Reusing WeaponLight's laser ray also changes the stored result its `_draw` uses and therefore risks altering an existing feature. A reusable PhysicsRayQueryParameters2D avoids parameter allocation but still returns a fresh result dictionary and has the same renderer mismatch.

## Proposed scope

Keep all existing scene-light contributions unchanged. After an aimed light passes its current enabled/visible/range/cone checks, only a shadow-enabled aimed light may have its contribution excluded by an actually intersected render occluder. Test the original LightOccluder2D polygon in its current local coordinates (transform segment endpoints through its inverse global transform), so terrain, prop inset, scaling and rotation use the same geometry as rendering. Respect visibility, actual canvas and intersecting render shadow masks. No light energy, renderer settings, culling budget, wall material or Stalker reveal threshold changes.

Register at the three existing occluder construction sites, once per object. Keep registrations weak and clean them on owner exit so repeated level changes do not accumulate references. Queries reuse those registrations and original polygon resources. No per-query shapes, physics parameters, exclusion arrays or new per-frame tick. Current registered polygons are four-vertex, closed, double-sided rectangles; future changed polygon/culling policy must be explicitly handled rather than silently guessed.

This is larger than inserting an incorrect WORLD ray, but limits product changes to the shared query and the three true occluder construction sites. It does not alter the v7 owner patch or introduce a new gameplay owner/token system. Implementation remains subject to root review of this scope.

## Necessary controls

1. Same original real cover-map wall / target / receiver / unmodified light parameters: wall blocks the aimed contribution, Stalker remains cloaked, world receiver stays black.
2. Same-distance open side: original numeric contribution, actual reveal and lit receiver remain; aim away naturally recloaks.
3. Shadow disabled, nonmatching render mask, hidden/freed blocker and unrelated canvas: no false block; match corresponding native shadow behavior.
4. A WORLD collider with no actual occluder does not block the logical gun light. A real prop occluder without a solid collider does block it.
5. Same terrain geometry under different wall materials gives the same occlusion result. One-way platforms preserve their current nonoccluding behavior.
6. Scene-light contribution remains numerically identical, including through the existing wall; only the aimed contribution is filtered. This preserves the current scene-light policy rather than silently repairing other classes of lights.
7. Retain v2 raw negative evidence, test exact source epochs, repeat native wall/open/away captures under the GPU lock and run affected CPU suites. The <=105% gate still needs the separate sustained-combat experiment; a query microbenchmark cannot replace it.
