# NE-258: presentation light ownership and lock audit

2026-11-17, Godot 4.7.2 `ed1daf0bf`, RX 9070 XT. This is an arranged real-owner diagnostic, not a human chapter playthrough.

The lock freezes a world state; it does not identify a cinematic. `GameplayLock.started` only emits for the first token and cannot cover a cinematic starting inside an important-radio or ordinary-pause lock. The light change therefore listens to a presentation event sent only by the two accepted visual entry points, before those owners acquire their locks. `WeaponLight.extinguish` owns its existing active/level switch; normal Player physics restores it after gameplay actually resumes. There is no new per-frame observer, token, suppression override or completion policy.

| Actual acquisition | Why it locks | Light policy |
| --- | --- | --- |
| `ui/dialogue_layer.gd:start_cinematic` | Actual dialogue/object-reading presentation | Immediately extinguish, including inside another lock |
| `game/cutscene/cutscene_player.gd:play` | Actual animated stage, overlay or replay | Immediately extinguish; ordinary Player light must not remain in the retained Level |
| `ui/dialogue_layer.gd:_ensure_radio_freeze` | Important radio reading, NE-246 | Preserve the frozen light; a subsequent cinematic can extinguish it |
| `ui/chapter_card.gd:_ready` | Blocking chapter card | Preserve the frozen world state |
| `autoload/transition.gd:_begin` | Cover/reveal and scene transition | Preserve the frozen world state; level replacement owns disposal |
| `autoload/input_bindings.gd:_on_joy_connection_changed` | Controller disconnect recovery | Preserve the visible frozen world state |
| `game/main.gd:_show_destination_failure` | Destination save failure prompt | Preserve the pending source world state |
| `game/world_item_completion.gd:collect` | Durable item-custody commit/retry | Preserve the pending source world state |
| `game/training_completion.gd:complete` | Durable training result commit/retry | Preserve the pending source world state |
| `game/story_result_completion.gd:choose` | Durable choice publication | Retain the current presentation's light policy |
| `game/story_result_completion.gd:complete` | Durable story result publication | Retain the current presentation's light policy |
| `game/story_flag_completion.gd:complete` | Durable story flag/result publication | Retain the existing world/presentation state |
| `game/story_flag_completion.gd:refuse_choice` | Failed durable choice recovery | Retain the existing world/presentation state |
| `game/skip_completion.gd:request` | Durable route skip publication | Preserve the pending source world state |
| `game/channel_completion.gd:request` | Durable world-channel publication | Preserve the pending source world state |

All callers retain explicit `GameplayLock.release`; acquisition also attaches owner-exit cleanup. Story normal finish, skip, reset, cancellation and replay disposal retain their existing lifecycle. Empty dialogue returns before the event. Reentrant Layer/animated play rejects before the event and preserves the running presentation. An empty animated step list is currently accepted, briefly runs and naturally releases its owner; the probe records that actual behavior rather than calling it rejected. Freed light nodes automatically lose their signal connection. No event is sent by the other acquisition sites.

## Same-owner lock cleanup defect

The real nested dialogue/radio probe exposed an additional existing failure. In the tested engine, `GameplayLock.release.bind(1001) == GameplayLock.release.bind(1002)` prints `true`, although the recorded bound-argument arrays differ. Registering both against one owner yields one cleanup connection, a duplicate-connect engine ERROR and a stale paused lock when the owner is freed. This was measured locally, not inferred from documentation. The [official Callable reference](https://docs.godotengine.org/en/stable/classes/class_callable.html) describes binding, custom callables and equality; it does not replace the version-specific local control.

The smallest correction creates a distinct cleanup closure capturing only the token. It retains the weak owner, stored cleanup callable, explicit disconnect, original restoration logic and one allocation per acquisition. The permanent `gameplay_lock_owner_checks.gd` runs in CutsceneSuite: the original yields 4 checks / 3 failures plus duplicate-connect ERRORs, the candidate yields 4 / 0 and no ERROR. Both independent release and owner exit are tested.

## Preserved limitations and failures

- Original owner v1 had a fixed phone wait that failed to acknowledge its genuine important-radio reading; later mount preconditions were contaminated. It is preserved and is not vehicle acceptance.
- Original v2 fixes that fixture using real public confirmation input: phone and real interact/mount/dismount pass; the two dialogue entry contracts fail.
- Native v3 compared an earlier process snapshot across readback and acquired a radio after a small visual update; its exact-equality failure is a fixture timing issue. Its stage `fade: 0` also left the real initial black fade intact. Neither is a claimed product defect.
- Original native v4 reads the actual acquisition boundary and waits for the formal stage fade. It cleanly exposes four cinematic-light failures. Full stage hides the retained world; its nonzero world query does **not** prove the gun light illuminates the separate stage canvas. Dialogue and overlay retain the visible world.
- Candidate owner v5 assertions/exit were initially reported as passing, but full-log review found a duplicate-connect ERROR. Those CPU/native runs are invalid as clean passes; raw output remains. The same ERROR was independently reproduced by permanent ExposureSuite v1. It is not whitelisted.
- Wall v1 CPU leaves the activation-culled Stalker dormant under the headless renderer, so it is not Stalker-state acceptance. Native v1 actually processes the target and preserves its contradictory rendered/logical observations. Its source receipt records only a concurrent ExposureSuite edit; the four light products and LightKit were stable. It is diagnostic, not a source-unchanged final run.
- No LightKit/terrain/Stalker product change is included. A rendered shadow is not automatically a defect: wall consistency requires the actual receiver pixels, ray and all alternative reveal causes to be examined together.
- Historical Arc B580 and current RX 9070 XT metrics are different experiments. Old montage images and exit-0 probe runs do not supply a current <=105% gate. The existing historical contrast area bug does not invalidate every recorded inner-brightness percentile.
