"""Snapshot only this delivery's owned candidate sources; never stage or mutate products."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FILES = ["autoload/event_bus.gd", "ui/dialogue_layer.gd", "game/cutscene/cutscene_player.gd",
         "game/player/weapon_light.gd", "design/08-lighting/LIGHT_SOURCES.md",
         "work/ne258-light-owner-20261117/owner_probe.gd", "work/ne258-light-owner-20261117/owner_probe.tscn",
         "work/ne258-light-owner-20261117/run_owner.py"]
FILES += ["autoload/gameplay_lock.gd", "tests/suite/test_exposure.gd", "tests/suite/test_cutscene.gd",
          "tests/helpers/gameplay_lock_owner_checks.gd"]
VERSION = sys.argv[1] if len(sys.argv) > 1 else "v7"
result = {}
for name in FILES:
    data = (ROOT / name).read_bytes()
    target = HERE / ("freeze-owner-" + VERSION) / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == data
    else:
        target.write_bytes(data)
    result[name] = {"sha256": hashlib.sha256(data).hexdigest(), "size": len(data)}
(HERE / ("freeze-owner-" + VERSION + ".json")).write_text(json.dumps(result, indent=2), encoding="utf8")
print(json.dumps(result, indent=2))
