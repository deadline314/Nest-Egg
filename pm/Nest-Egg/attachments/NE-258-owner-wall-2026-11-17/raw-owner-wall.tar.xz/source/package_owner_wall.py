"""Preserve raw owner/wall epochs without any private profile or save data."""
import hashlib
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
EVIDENCE = Path("C:/NE/evidence-20261117")
PACKET = HERE / "packet-owner-wall"
PACKET.mkdir(exist_ok=True)
ARCHIVE = PACKET / "raw-owner-wall.tar.xz"
assert not ARCHIVE.exists()
members = {}
inputs = []
for run in sorted(EVIDENCE.glob("ne258*")):
    if run.is_dir():
        for path in sorted(run.rglob("*")):
            if path.is_file() and "profile" not in path.relative_to(run).parts:
                inputs.append((path, "runs/" + run.name + "/" + path.relative_to(run).as_posix()))
for path in sorted(HERE.rglob("*")):
    relative = path.relative_to(HERE)
    if path.is_file() and not any(part in {"packet-owner-wall", "__pycache__"} for part in relative.parts) and path.name != ".gdignore":
        inputs.append((path, "source/" + relative.as_posix()))
with tarfile.open(ARCHIVE, "w:xz", preset=6) as archive:
    for path, member in inputs:
        data = path.read_bytes()
        members[member] = {"sha256": hashlib.sha256(data).hexdigest(), "size": len(data)}
        archive.add(path, arcname=member, recursive=False)
assert ARCHIVE.stat().st_size < 100_000_000
(PACKET / "members.json").write_text(json.dumps(members, indent=2), encoding="utf8")
receipt = {"archive": ARCHIVE.name, "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
           "size": ARCHIVE.stat().st_size, "members": len(members), "profile_data_included": False}
(PACKET / "archive.json").write_text(json.dumps(receipt, indent=2), encoding="utf8")
print(json.dumps(receipt))
