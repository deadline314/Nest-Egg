"""Freeze the combined candidate without changing or staging any product source."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
files = list(json.loads((HERE / "freeze-owner-v7.json").read_text(encoding="utf8")))
files += ["core/light_kit.gd", "game/level/terrain.gd", "game/level/environment/prop_node.gd", "game/props/gate.gd",
          "tests/helpers/weapon_light_occlusion_checks.gd", "work/ne258-light-owner-20261117/wall_probe.gd",
          "work/ne258-light-owner-20261117/wall_probe.tscn", "work/ne258-light-owner-20261117/run_wall.py",
          "work/ne258-light-owner-20261117/verify_wall.py"]
manifest = {}
for name in files:
    data = (ROOT / name).read_bytes()
    target = HERE / "freeze-wall-v4" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == data
    else:
        target.write_bytes(data)
    manifest[name] = {"sha256": hashlib.sha256(data).hexdigest(), "size": len(data)}
(HERE / "freeze-wall-v4.json").write_text(json.dumps(manifest, indent=2), encoding="utf8")
print(json.dumps(manifest, indent=2))
