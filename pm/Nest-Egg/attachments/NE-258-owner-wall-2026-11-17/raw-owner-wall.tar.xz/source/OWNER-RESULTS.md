# NE-258 owner correction: reviewable results

All paths below are under `C:/NE/evidence-20261117/`. The stable delivery snapshot is `work/ne258-light-owner-20261117/freeze-owner-v7.json` and its adjacent `freeze-owner-v7/`. No LightKit, Player, terrain, Stalker or Story semantics were changed. Formal affected selection remains owned by root.

| Run | Engine result | Scope |
| --- | --- | --- |
| `ne258-cpu-baseline/geometry` | 84 checks / 0 failures, exit 0 | Existing known-answer contrast geometry |
| `ne258-cpu-baseline/exposure` | 253 / 0, exit 0 | Original existing ExposureSuite; its manual phone/vehicle switch check did not exercise real owners |
| `ne258-owner-original-v2` | 21 / 2, exit 1 | Real phone/important-reading input/mount/dismount pass; two true dialogue entries retain their light |
| `ne258-owner-original-v4-native` | 37 / 4, exit 1 | RX9070XT Forward+/HDR, actual Layer, Story dialogue, stage and overlay entries retain their light |
| `ne258-lock-original` | exit 1, engine ERROR | Same-owner bound-callable identity and stale paused lock on owner deletion |
| `ne258-lock-suite-original` | 4 / 3, exit 1, engine ERROR | Exact permanent helper, original cleanup |
| `ne258-lock-suite-candidate` | 4 / 0, exit 0, no ERROR | Same helper, distinct cleanup closure |
| `ne258-exposure-candidate-v2` | 265 / 0, exit 0, no ERROR | Permanent real-owner regression; no direct light event/switch substitutes |
| `ne258-owner-candidate-v7-cpu` | 47 / 0, exit 0, diagnostics `[]` | Stable complete owner/phone/vehicle/lifecycle probe |
| `ne258-owner-candidate-v7-native` | 54 / 0, exit 0, diagnostics `[]` | Same owner logic plus 7 raw native capture writes, all receipt sources unchanged |

Two intentional reentry attempts in the complete probe retain the existing warning behavior. Their exact warning blocks are surrounded by `EXPECTED_WARNING_BEGIN/END`; they do not hide engine ERRORs. Candidate v5 had a real duplicate-connect ERROR despite zero assertion failures and is explicitly invalid as a clean pass. The corrected v7 runner rejects any ERROR, script error, leak/orphan diagnostic or source drift in addition to nonzero engine exit.

## Player-visible behavior

Entering ordinary dialogue, animated stage, overlay or replay immediately extinguishes the retained player's gun cone and laser sight. Starting dialogue inside important radio also extinguishes it; there is no dependency on the first lock notification. Normal pause and important-radio reading preserve their exact frozen light. Cancelling/finishing a cinematic while a separate pause/radio remains does not prematurely relight it. Once actual Player physics resumes, its existing current-weapon/phone/vehicle/death rules restore or keep off the light.

The clean original full stage covers the underlying world, so its nonzero underlying light query is a literal state-contract failure, not evidence of gun light spilling into the separate stage. The original dialogue and overlay retain the visible Level. All native runs identify Vulkan Forward+ and the AMD Radeon RX9070XT; raw RGB half-float frame bytes and corresponding sRGB PNGs are retained.

## Remaining separate wall diagnosis

`ne258-wall-candidate-v2-native` is a source-stable, clean native diagnostic using real `cover_map` collision and terrain occluders. No wall/light visibility rule was changed. The arranged Stalker has no proximity reveal, damage, telegraph, aim/burst, finisher state or movement. Its actual GPU culling/physics remains active.

| Actual case | World query at target | Stalker opacity/state | Gray world receiver inner pixels |
| --- | --- | --- | --- |
| Aim away, wall in between | 0 | 0.05, cloaked | 870 pixels, mean/median 0 |
| Aim through real wall, ray hits x480 | 0.7027706723 | 1, revealed by `_lit` | 900 pixels, mean/median 0 |
| Same separation, open side | 0.7156377679 | 1, revealed | 870 pixels, mean 0.03652609 / median 0.03627939 |

Read-only recomputation: `python -B work/ne258-light-owner-20261117/verify_wall.py C:/NE/evidence-20261117/ne258-wall-candidate-v2-native`. The world sample is the same inset 8×8 rectangle inside the same 16×16 shaded gray receiver, transformed with each actual final×canvas matrix and checked entirely in bounds. Slight raster sample-count differences are recorded rather than rescaled away. The receiver is an arranged diagnostic surface, not an enemy contrast or acceptance mask. Rain and scene phase differ, so no whole-frame difference percentage is claimed.

The actual world receiver is fully shadowed while logical light reveals the target through the wall. This is evidence for a subsequent occlusion correction, not an implemented fix or a passing NE-258 claim. Native v1 had concurrent test-source drift and CPU v1 activation-culling limitations, both retained. The reader's first format assertion failed because Godot format14 is RGBH (6 bytes/pixel), not RGBAH; its original version and failing log are retained. The corrected reader explicitly decodes format10/11/14/15 and checks exact buffer lengths.

All nine ticket conditions are not newly certified by this owner correction alone: historical weapon montage, old exposure and <=105% measurements need their own current reproducible evidence. No human hearing or physical controller acceptance is claimed or required by NE-258's text. See `LOCK-AUDIT.md` for all production lock callers, lifecycle decisions and preserved earlier fixture failures.
