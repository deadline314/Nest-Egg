"""CPU owner observation with immutable prior evidence and exact probe/product hashes."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUTPUT = Path(sys.argv[1])
assert OUTPUT.is_absolute() and not OUTPUT.exists()
profile = OUTPUT / "profile"
profile.mkdir(parents=True)
paths = list(json.loads((HERE / "original-source-hashes.json").read_text(encoding="utf8")))
paths += ["work/ne258-light-owner-20261117/owner_probe.gd", "work/ne258-light-owner-20261117/owner_probe.tscn"]


def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in paths}


before = hashes()
environment = os.environ.copy()
overrides = {"APPDATA": str(profile), "LOCALAPPDATA": str(profile), "NE258_OUT": str(OUTPUT)}
native = "--native" in sys.argv[2:]
if native:
    overrides["NE258_NATIVE"] = "1"
environment.update(overrides)
command = ["C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", *( [] if native else ["--headless"]), "--path", str(ROOT),
           "res://work/ne258-light-owner-20261117/owner_probe.tscn"]
if native:
    command[1:1] = ["--rendering-driver", "vulkan", "--rendering-method", "forward_plus"]
    command = [sys.executable, "-B", str(ROOT / "tools/comfyui/gpu_lock.py"), "--", *command]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUTPUT / "console.log").open("wb") as log:
    process = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, cwd=ROOT)
after = hashes()
receipt = {"command": command, "cwd": str(ROOT), "environment_overrides": overrides, "started_utc": started,
           "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exit_code": process.returncode,
           "source_before_sha256": before, "source_after_sha256": after, "source_unchanged": before == after}
(OUTPUT / "process-receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf8")
print(json.dumps({"exit_code": process.returncode, "source_unchanged": before == after}))
