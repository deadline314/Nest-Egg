"""Readonly HDR receiver measurements using the recorded actual final*canvas transform."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

folder = Path(sys.argv[1])
report = json.loads((folder / "wall-report.json").read_text(encoding="utf8"))
receipt = json.loads((folder / "process-receipt.json").read_text(encoding="utf8"))
assert receipt["exit_code"] == 0 and receipt["source_unchanged"] and not receipt["diagnostics"]
rows = {}
for capture in report["captures"]:
    path = folder / (capture["name"] + ".hdr.bin")
    data = path.read_bytes()
    formats = {10: ("<f4", 3), 11: ("<f4", 4), 14: ("<f2", 3), 15: ("<f2", 4)}
    assert capture["format"] in formats and capture["use_hdr_2d"]
    dtype, channels = formats[capture["format"]]
    width, height = capture["width"], capture["height"]
    assert width > 0 and height > 0 and len(data) == width * height * channels * np.dtype(dtype).itemsize
    raw = np.frombuffer(data, dtype=dtype).reshape(height, width, channels).astype(np.float64)
    assert np.isfinite(raw).all()
    xx, xy, yx, yy, ox, oy = capture["world_to_image"]
    assert abs(xy) < 1e-8 and abs(yx) < 1e-8 and xx > 0 and yy > 0
    center = np.array(capture["receiver_world_center"])
    # The inner 8x8 world pixels exclude polygon raster edges; same region in all cases.
    lo = center - 4
    hi = center + 4
    x0, y0 = np.ceil(lo * [xx, yy] + [ox, oy]).astype(int)
    x1, y1 = np.floor(hi * [xx, yy] + [ox, oy]).astype(int)
    assert 0 <= x0 < x1 <= width and 0 <= y0 < y1 <= height
    patch = raw[y0:y1, x0:x1, :3]
    luma = patch @ [0.2126, 0.7152, 0.0722]
    row = next(r for r in report["rows"] if r["name"] == capture["name"])
    rows[capture["name"]] = {"raw_sha256": hashlib.sha256(data).hexdigest(), "raw_size": len(data),
        "sample_image_rect": [int(x0), int(y0), int(x1-x0), int(y1-y0)], "sample_pixels": luma.size,
        "mean_linear_luma": float(luma.mean()), "median_linear_luma": float(np.median(luma)),
        "world_query": row["world_light"], "stalker": row["stalker"]}
assert {"wall-aim-away", "wall-aim-through", "open-aim-at"}.issubset(rows)
if "--gate" in sys.argv[2:]:
    assert rows["wall-aim-through"]["world_query"] == 0.0 and rows["wall-aim-through"]["stalker"]["cloaked"]
    assert rows["wall-aim-through"]["mean_linear_luma"] == 0.0
    assert rows["open-aim-at"]["world_query"] > 0.18 and not rows["open-aim-at"]["stalker"]["cloaked"]
    assert rows["open-aim-at"]["median_linear_luma"] > 0.0
    if "open-aim-away" in rows:
        assert rows["open-aim-away"]["stalker"]["cloaked"] and rows["open-aim-away"]["world_query"] == 0.0
result = {"scope": "Diagnostic receiver pixels, not a new visibility threshold or gameplay acceptance", "cases": rows}
print(json.dumps(result, indent=2))
