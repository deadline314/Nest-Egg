"""Single-process CPU baseline, exact source snapshots and private profiles."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUTPUT = Path("C:/NE/evidence-20261117/ne258-cpu-baseline")
GODOT = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
SOURCES = ["game/player/player.gd", "game/player/weapon_light.gd", "core/light_kit.gd",
           "tools/weapon_light_probe.gd", "tools/contrast_probe.gd", "tools/test_contrast_probe_geometry.gd",
           "tests/suite/test_exposure.gd", "autoload/gameplay_lock.gd", "ui/dialogue_layer.gd", "autoload/story.gd",
           "ui/chapter_card.gd", "autoload/transition.gd", "autoload/input_bindings.gd",
           "game/world_item_completion.gd", "game/training_completion.gd", "game/story_result_completion.gd",
           "game/story_flag_completion.gd", "game/skip_completion.gd", "game/main.gd",
           "game/cutscene/cutscene_player.gd", "game/channel_completion.gd", "core/light_quality.gd",
           "game/vehicles/vehicle.gd", "game/enemies/stalker.gd"]


def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in SOURCES}


def main():
    original = hashes()
    for name in SOURCES:
        target = HERE / "original-source" / name
        if target.exists():
            raise FileExistsError(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((ROOT / name).read_bytes())
    (HERE / "original-source-hashes.json").write_text(json.dumps(original, indent=2), encoding="utf8")
    receipts = []
    for tag, scene, flags in [("geometry", "res://tools/test_contrast_probe_geometry.tscn", []),
                              ("exposure", "res://tests/smoke_test.tscn", ["--only=ExposureSuite"])]:
        folder = OUTPUT / tag
        if folder.exists():
            raise FileExistsError(folder)
        profile = folder / "profile"
        profile.mkdir(parents=True)
        environment = os.environ.copy()
        overrides = {"APPDATA": str(profile), "LOCALAPPDATA": str(profile)}
        environment.update(overrides)
        command = [GODOT, "--headless", "--path", str(ROOT), scene, "--", f"--out={folder}", *flags]
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (folder / "console.log").open("wb") as log:
            result = subprocess.run(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT)
        text = (folder / "console.log").read_text(encoding="utf8", errors="strict")
        diagnostics = [line for line in text.splitlines() if any(token in line for token in
                       ("SCRIPT ERROR", "ERROR:", "WARNING:", "Leaked", "leaked", "orphan"))]
        receipt = {"tag": tag, "command": command, "cwd": str(ROOT), "environment_overrides": overrides,
                   "started_utc": start, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   "exit_code": result.returncode, "diagnostics": diagnostics,
                   "source_before_sha256": original, "source_after_sha256": hashes(), "source_unchanged": original == hashes()}
        (folder / "process-receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf8")
        receipts.append(receipt)
        (HERE / "cpu-receipts.json").write_text(json.dumps(receipts, indent=2), encoding="utf8")
        print(json.dumps({"tag": tag, "exit_code": result.returncode, "diagnostics": diagnostics,
                          "source_unchanged": receipt["source_unchanged"]}), flush=True)
        if result.returncode != 0 or diagnostics or not receipt["source_unchanged"]:
            return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
