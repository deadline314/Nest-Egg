extends Node

const INPUTS := ["res://data/story/ch1_kasa.json","res://data/story/ch2_heron.json"]
const FRAME_ACTIONS := ["scene","camera","actor","pose","face","remove"]

var output := ""
var samples := {}
var failures: Array[String] = []


func _ready() -> void:
	for flag: String in OS.get_cmdline_user_args():
		if flag.begins_with("--out="):
			output = flag.trim_prefix("--out=")
	if not output.is_absolute_path() or DisplayServer.get_name() != "headless":
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	var active: Dictionary = Story.audit_data()["scenes"]
	for path: String in INPUTS:
		var authored: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
		for id: String in authored["scenes"]:
			if not active.has(id) or str(active[id].get("mode","")) != "animated" or bool(active[id].get("overlay",false)):
				continue
			var before_spawn: Array[Dictionary] = []
			var placement: StringName
			for step: Dictionary in active[id].get("steps",[]):
				var kind := str(step.get("do",""))
				if kind in FRAME_ACTIONS:
					before_spawn.append(step)
				if kind == "actor" and step.get("kind","") == "rin":
					placement = StringName(step.get("id",""))
					break
			if placement != &"":
				await _sample(id,placement,before_spawn)
	var file := FileAccess.open(output.path_join("placements.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures":failures,"scenes":samples},"  ")+"\n")
	file.close()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if not failures.is_empty() else 0)


func _sample(id: String, placement: StringName, steps: Array[Dictionary]) -> void:
	var player := CutscenePlayer.new()
	add_child(player)
	var steps_with_hold := steps.duplicate()
	steps_with_hold.append({"do":"wait","time":15.0})
	player.play(StringName(id),{"steps":steps_with_hold})
	var was_ready := false
	for cycle in 360:
		await get_tree().process_frame
		if not is_instance_valid(player) or not player.is_running():
			break
		if player.steps_run < steps.size():
			continue
		for _settle in 8:
			await get_tree().process_frame
		var actor: CutsceneActor = player._actors.get(placement)
		if actor == null or actor.rig == null or not actor.rig.is_valid():
			break
		var rect := actor.rig.visual_bounds()
		var screen := Story.framing.safe_rect()
		samples[id] = {"camera":[player.cam_pos.x,player.cam_pos.y,player.cam_zoom],"scale":actor.scale.x,
			"actor":str(placement),"bounds":[rect.position.x,rect.position.y,rect.end.x,rect.end.y],
			"margins":[rect.position.x-screen.position.x,rect.position.y-screen.position.y,
				screen.end.x-rect.end.x,screen.end.y-rect.end.y],"pose":str(steps.back().get("pose","stand"))}
		was_ready = true
		break
	if not was_ready:
		failures.append(id)
		print("FAIL did not reach Rin placement in ",id)
	if is_instance_valid(player):
		player.cancel()
	for _settle in 3:
		await get_tree().process_frame
