extends Node

const CHECKPOINTS := {
	"ch1_c09_wake": {4: 0, 10: 9, 14: 13},
	"ch1_c14_home": {4: 0, 14: 0, 59: 0},
	"ch2_t_s11_xiaowei": {4: 0, 11: 10},
	"ch2_t_s11_boxes": {5: 0, 9: 8},
}

var output := ""
var native := false
var failures := 0
var frames: Array[Dictionary] = []
var home_motion := {"frames":0,"minimum_top":INF,"worst_step":-1}


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			output = arg.trim_prefix("--out=")
	if not output.is_absolute_path():
		get_tree().quit(2)
		return
	native = DisplayServer.get_name() != "headless"
	if native:
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	_run.call_deferred()


func _run() -> void:
	Story.set_language("zh")
	for id: String in CHECKPOINTS:
		await _observe(id)
	var handle := FileAccess.open(output.path_join("framing.json"),FileAccess.WRITE)
	handle.store_string(JSON.stringify({"native":native,"failures":failures,"samples":frames,"home_motion":home_motion},"  ")+"\n")
	handle.close()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)


func _observe(id: String) -> void:
	var scene: Dictionary = Story.audit_data()["scenes"][id]
	var steps: Array = scene["steps"]
	var expected: Dictionary = CHECKPOINTS[id].duplicate()
	var player := CutscenePlayer.new()
	add_child(player)
	if native:
		# Run the shipped stage and animation on the normal cutscene renderer. The
		# isolated viewer does not acquire the desktop mouse mode or gameplay lock.
		player.scene_id = StringName(id)
		player._steps = steps.duplicate(true)
		player._build_ui()
		player._framing_token = Story.framing.acquire(player)
		Story.framing.safe_rect_changed.connect(player._layout_safe_rect)
		player._layout_safe_rect(Story.framing.safe_rect())
		player._running = true
		player._run.call_deferred()
	else:
		player.play(StringName(id),scene)
	for cycle in 2600:
		await get_tree().process_frame
		if not is_instance_valid(player) or not player.is_running() or expected.is_empty():
			break
		if id == "ch1_c14_home":
			_sample_home_motion(player)
		var dialogue := player._dialogue
		if not dialogue._frame.visible or not dialogue.is_complete():
			continue
		var step := player.steps_run
		if expected.has(step):
			var desired: Dictionary = steps[int(expected[step])]
			var focus := Vector2(float(desired["pos"][0]),float(desired["pos"][1]))
			if player.cam_pos.distance_to(focus) > 0.001 or absf(player.cam_zoom - float(desired["zoom"])) > 0.001:
				continue
			await _save(player,id,step)
			expected.erase(step)
		player._advance_requested = true
	if not expected.is_empty():
		failures += 1
		print("FAIL missing framed scene checkpoints ",id," ",expected)
	if is_instance_valid(player) and player.is_running():
		player.cancel()
	for cycle in 3:
		await get_tree().process_frame


func _sample_home_motion(player: CutscenePlayer) -> void:
	var actor: CutsceneActor = player._actors.get(&"rin")
	if actor == null or actor.rig == null or not actor.rig.is_valid():
		return
	var gap := actor.rig.visual_bounds().position.y - Story.framing.safe_rect().position.y
	home_motion["frames"] += 1
	if gap < float(home_motion["minimum_top"]):
		home_motion["minimum_top"] = gap
		home_motion["worst_step"] = player.steps_run


func _save(player: CutscenePlayer, id: String, step: int) -> void:
	var actor: CutsceneActor = player._actors.get(&"rin")
	if not is_instance_valid(actor) or actor.rig == null or not actor.rig.is_valid():
		failures += 1
		print("FAIL missing Rin rig ",id," ",step)
		return
	if native:
		await RenderingServer.frame_post_draw
		var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
		var saved := image.save_png(output.path_join("%s_%02d.png" % [id,step]))
		if saved != OK:
			failures += 1
		if id == "ch1_c14_home" and step == 59:
			await _sample_top_edge(actor)
	var safe := Story.framing.safe_rect()
	var bounds := actor.rig.visual_bounds()
	var head := actor.rig.bone(&"head").global_position
	frames.append({"scene":id,"step":step,"camera":[player.cam_pos.x,player.cam_pos.y,player.cam_zoom],
		"safe":[safe.position.x,safe.position.y,safe.end.x,safe.end.y],
		"bounds":[bounds.position.x,bounds.position.y,bounds.end.x,bounds.end.y],"head":[head.x,head.y],
		"top_gap":bounds.position.y - safe.position.y,"bottom_gap":safe.end.y - bounds.end.y})


func _sample_top_edge(actor: CutsceneActor) -> void:
	var top := Story.framing._top
	var prior_visibility := top.visible
	var prior_process := actor.is_processing()
	actor.set_process(false)
	top.hide()
	for name: String in ["home-top-actor", "home-top-background"]:
		await RenderingServer.frame_post_draw
		var saved := preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(output.path_join(name+".png"))
		if saved != OK:
			failures += 1
		actor.hide()
	actor.show()
	top.visible = prior_visibility
	actor.set_process(prior_process)
