from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json
import math
from PIL import Image

root = Path.cwd()
base = Path(__file__).resolve().parent
def read(name):
    return json.loads((base/name).read_bytes())

initial = read('headless-placements/placements.json')
assert not initial['failures']
scenes = initial['scenes']
assert len(scenes) == 81 and min(min(row['margins']) for row in scenes.values()) > 0
headless = read('headless-home/framing.json')
native = read('native-alpha/framing.json')
assert len(native['samples']) == len(headless['samples']) == 10
assert native['failures'] == headless['failures'] == 0

late_home = next(row for row in native['samples'] if row['scene'] == 'ch1_c14_home' and row['step'] == 59)
actor, background, framed = (
    Image.open(base/'native-alpha'/name).convert('RGB')
    for name in ('home-top-actor.png', 'home-top-background.png', 'ch1_c14_home_59.png')
)
left, _, right, _ = late_home['bounds']
edge = math.ceil(late_home['safe'][1] * 2)
columns = range(math.floor(left * 2) - 5, math.ceil(right * 2) + 6)
rows = {}
for y in range(edge - 9, edge + 14):
    diffs = [
        max(abs(a - b) for a,b in zip(actor.getpixel((x,y)), background.getpixel((x,y))))
        for x in columns
    ]
    rows[y] = {'max_rgb_delta': max(diffs), 'pixels_above_1': sum(d > 1 for d in diffs)}
visible_from = next(y for y, record in rows.items() if record['pixels_above_1'])
assert framed.getpixel((600,edge-1)) == (0,0,0) and max(framed.getpixel((600,edge))) > 0
assert visible_from >= edge and rows[visible_from]['max_rgb_delta'] > 100
audit = {'scenes': len(scenes), 'initial_minimum_margin': min(min(row['margins']) for row in scenes.values()),
         'headless_samples': len(headless['samples']), 'native_samples': len(native['samples']),
         'home_rendered_frames': native['home_motion']['frames'], 'home_top_bar_end_px': edge,
         'home_actor_first_visible_y': visible_from, 'home_edge_comparison': rows}
(base/'verification.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')

ticket = Path('pm/Nest-Egg/[NE-71]驗證凜新外觀在遊戲內的表現.md')
archive = Path('pm/Nest-Egg/attachments/NE-71-cutscene-framing-2026-11-21/evidence.zip')
photos = {
    'clinic-wake': 'ch1_c09_wake_10.png',
    'kitchen-late': 'ch1_c14_home_59.png',
    'xiaowei-dialogue': 'ch2_t_s11_xiaowei_11.png',
    'loading-boxes': 'ch2_t_s11_boxes_09.png',
}
images = {key: Path(f'pm/Nest-Egg/images/NE-71-{key}-20261121.png') for key in photos}
before = (root/ticket).read_text(encoding='utf-8')
assert '# Commit-12（' in before and '# Commit-13（' not in before
assert read('official-release/verification.json') == {'exit':0,'errors':[],'source_held':True}
assert not (root/archive.parent).exists() and all(not (root/file).exists() for file in images.values())
raw = ['observe.gd','observe.tscn','run.py','sample_placements.gd','sample_placements.tscn','run_placements.py',
       'bundle.py','verification.json','official-release/raw.log','official-release/verification.json']
for directory, report in [('headless-placements','placements.json'),('headless-home','framing.json'),
                          ('native-alpha','framing.json')]:
    raw.extend(f'{directory}/{name}' for name in ('command.json','engine.log',report))
raw.extend(f'native-alpha/{path.name}' for path in sorted((base/'native-alpha').glob('*.png')))
(root/archive).parent.mkdir()
with ZipFile(root/archive,'x',compression=ZIP_DEFLATED) as bundle:
    for name in raw:
        bundle.write(base/name,name)
with ZipFile(root/archive) as bundle:
    assert bundle.testzip() is None
for label,file in images.items():
    (root/file).write_bytes((base/'native-alpha'/photos[label]).read_bytes())

section = f'''
---

# Commit-13（複驗凜在第一、二章的過場取景）

## 內文

- 用目前的正式故事資料及過場舞台建立第一章 44 段、第二章 37 段有凜的動畫過場。初始站位、坐姿及蹲姿的角色繪製範圍都在安全畫面內，最窄的邊界留 {audit['initial_minimum_margin']:.2f} 邏輯像素。
- 診所甦醒、回家廚房、小瑋談話及裝卸箱子四段各以無頭流程和 RX 9070 XT Forward+ 1280×720 複驗，共各十個節點。廚房追蹤 {audit['home_rendered_frames']:,} 幀，後段辮子網格的透明外框略越過黑邊。用同幀有角色及移去角色的畫面比對，黑邊下第一個有效畫素在 y={visible_from}，視窗畫面從 y={edge} 開始，保留現行構圖。
- 過場和程式未改動，受影響測試選擇器為 0 套。逐段完整分支、動畫姿勢及實玩通關仍待驗。

[原始畫面、過場量測與重現腳本](attachments/NE-71-cutscene-framing-2026-11-21/evidence.zip)

### 截圖

![診所坐姿](images/NE-71-clinic-wake-20261121.png)
![廚房對話後段](images/NE-71-kitchen-late-20261121.png)
![第二章小瑋對話](images/NE-71-xiaowei-dialogue-20261121.png)
![第二章裝卸箱子](images/NE-71-loading-boxes-20261121.png)
'''
(root/ticket).write_text(before.rstrip()+'\n\n\n'+section.lstrip('\n'),encoding='utf-8')
(base/'delivery.json').write_text(json.dumps([path.as_posix() for path in (ticket,archive,*images.values())],
                                            ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(raw),(root/archive).stat().st_size,audit['initial_minimum_margin'])
