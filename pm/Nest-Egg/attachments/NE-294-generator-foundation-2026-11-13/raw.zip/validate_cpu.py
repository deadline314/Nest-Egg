from pathlib import Path
import json,subprocess,os,time,hashlib
root=Path.cwd();out=root/'work/ne294-foundation-v1';base='78c367b1efc2f7945196d9373b24c3d8377394ba'
paths=['tools/level/build_ch1.py','tools/level/build_ch2.py','tools/level/build_ch3.py','tools/level/level_kit.py','tools/level/test_level_kit.py']
manifest={n:{'bytes':(root/n).stat().st_size,'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest()} for n in paths}
env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1','GODOT':'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'}
commands=[('old-red',['python','-B','work/ne294-foundation-v1/old_contract_red.py'],1),('unit',['python','-B','tools/level/test_level_kit.py'],0),('original-channel',['python','-B','tools/level/check_channel_generation.py'],0),('select-five',['python','-B','tools/select_tests.py','--files',*paths,'--explain'],0),('select-base',['python','-B','tools/select_tests.py','--base',base],0)]
results=[]
for name,cmd,expected in commands:
 t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,env=env);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);results.append({'name':name,'command':cmd,'exit':r.returncode,'expected_exit':expected,'elapsed':time.perf_counter()-t});assert r.returncode==expected,(name,r.stderr.decode())
 if name=='select-base':assert not r.stdout.strip(),('Unexpected engine scope, do not run changed',r.stdout)
cmd=['C:/Program Files/Git/bin/bash.exe','tools/run_tests_changed.sh',base];t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,env=env);(out/'changed-five.stdout').write_bytes(r.stdout);(out/'changed-five.stderr').write_bytes(r.stderr);results.append({'name':'changed-five','command':cmd,'exit':r.returncode,'elapsed':time.perf_counter()-t,'scope':'Original entry, selected zero groups, no Godot process launched'});assert r.returncode==0
assert manifest=={n:{'bytes':(root/n).stat().st_size,'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest()} for n in paths}
(out/'cpu-validation.json').write_text(json.dumps({'base':base,'source_before':manifest,'source_after':manifest,'commands':results},indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(results,indent=2))
