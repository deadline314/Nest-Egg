from pathlib import Path
import types,sys,zipfile,json
root=Path.cwd()
sys.path.insert(0,str(root/'tools/level'))
with zipfile.ZipFile(root/'work/ne294-foundation-v1/before-source.zip') as z:
 oldgrid=types.ModuleType('level_kit');oldgrid.__file__=str(root/'tools/level/level_kit.py')
 exec(compile(z.read('tools/level/level_kit.py'),oldgrid.__file__,'exec'),oldgrid.__dict__);sys.modules['level_kit']=oldgrid
 kit=types.ModuleType('old_build_ch1');kit.__file__=str(root/'tools/level/build_ch1.py')
 exec(compile(z.read('tools/level/build_ch1.py'),kit.__file__,'exec'),kit.__dict__)
observed=[]
a=kit.Area('height','Height',30,20,height=48)
observed.append({'case':'height48','expected':48,'actual':a.grid.h,'passed':a.grid.h==48})
g=oldgrid.Grid(8,12)
try:g.put(-1,0,'X');rejected=False
except ValueError:rejected=True
observed.append({'case':'negative_coordinate','expected_rejected':True,'actual_rejected':rejected,'passed':rejected})
a=kit.Area('gate','Gate',30,20);a.put(3,19,'P');a.put(14,19,'a')
missing=kit.reachable(a,(3,19),[('behind_closed_gate',(25,19))])
observed.append({'case':'old_all_open_has_no_closed_gate_state','expected_unreachable':True,'actual_missing':missing,'passed':bool(missing)})
print(json.dumps({'scope':'Real exact baseline modules, not candidate. These three assertions must be red.','cases':observed,'failures':sum(not x['passed'] for x in observed)},indent=2))
raise SystemExit(1 if any(not x['passed'] for x in observed) else 0)
