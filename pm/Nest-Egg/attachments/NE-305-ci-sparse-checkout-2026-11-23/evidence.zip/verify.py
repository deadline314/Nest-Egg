from hashlib import sha256
import json
from pathlib import Path
import os
import random
import subprocess
from tempfile import TemporaryDirectory
from time import perf_counter

import yaml


root = Path.cwd()
scratch = Path(__file__).resolve().parent
bash = "C:/Program Files/Git/bin/bash.exe"
workflow = Path(".github/workflows/tests.yml")
candidate = yaml.load((scratch / workflow).read_bytes(), Loader=yaml.BaseLoader)
before = yaml.load((root / workflow).read_bytes(), Loader=yaml.BaseLoader)
steps = candidate["jobs"]["full"]["steps"]
original_steps = before["jobs"]["full"]["steps"]
checkout, gate, expanded, *rest = steps
assert checkout == {"uses": "actions/checkout@v4", "with": {"sparse-checkout": ".github"}}
assert gate == original_steps[1]
assert expanded["if"] == "steps.gate.outputs.skip != 'true'" and expanded["shell"] == "bash"
assert rest == original_steps[2:]
candidate["jobs"]["full"]["steps"] = original_steps
assert candidate == before


def git(cwd, *args, env=None):
    outcome = subprocess.run(["git", *args], cwd=cwd, env=env, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return outcome.stdout.decode("utf-8")


def put(folder, name, data):
    path = folder / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def missing(cwd):
    result = git(cwd, "rev-list", "--objects", "--all", "--missing=print",
                 env=dict(os.environ, GIT_NO_LAZY_FETCH="1"))
    return {line[1:] for line in result.splitlines() if line.startswith("?")}


started = perf_counter()
with TemporaryDirectory(prefix="checkout-fixture-", dir=scratch) as temp:
    location = Path(temp).resolve()
    assert location.parent == scratch.resolve() and location.name.startswith("checkout-fixture-")
    origin = location / "origin.git"
    authoring = location / "author"
    selected = location / "selected"
    control = location / "full"
    git(location, "init", "--quiet", "--bare", "-b", "main", str(origin))
    git(origin, "config", "uploadpack.allowFilter", "true")
    for folder in (authoring, selected, control):
        folder.mkdir()
        git(folder, "init", "--quiet", "-b", "main")
        git(folder, "config", "core.autocrlf", "false")
        git(folder, "remote", "add", "origin", origin.as_uri())
    fixtures = {
        ".github/workflows/tests.yml": b"name: example\n",
        "project.godot": b"config_version=5\n",
        "art/game.png": b"asset bytes\n",
        "tools/test.gd": b"tool bytes\n",
        "art_src/source.png": b"authoring asset bytes\n",
        "new folder/game": b"future directory included automatically\n",
        "pm/Nest-Egg/attachments/evidence.zip": random.Random(402).randbytes(2 * 1024 * 1024),
        "pm/Nest-Egg/[NE-17]ticket.md": b"evidence index\n",
    }
    for path, contents in fixtures.items():
        put(authoring, path, contents)
    git(authoring, "add", "--all")
    git(authoring, "-c", "user.name=Fixture", "-c", "user.email=fixture@example.invalid",
        "commit", "--quiet", "-m", "test checkout")
    git(authoring, "push", "--quiet", "origin", "HEAD:main")
    excluded = {git(authoring, "rev-parse", "HEAD:" + path).strip() for path in fixtures if path.startswith("pm/")}
    unneeded = git(authoring, "rev-parse", "HEAD:art/game.png").strip()
    assert len(excluded) == 2
    git(selected, "-c", "protocol.version=2", "fetch", "--quiet", "--no-tags", "--depth=1", "--filter=blob:none", "origin", "main")
    git(selected, "sparse-checkout", "set", "--cone", ".github")
    git(selected, "checkout", "--quiet", "--detach", "FETCH_HEAD")
    assert {path for path in fixtures if (selected / path).is_file()} == {".github/workflows/tests.yml", "project.godot"}
    assert excluded | {unneeded} <= missing(selected)
    print("PASS initial checkout retains root and workflows; game and PM fixture blobs are absent")
    subprocess.run([bash, "-e", "-o", "pipefail", "-c", expanded["run"]], cwd=selected, check=True)
    assert {path for path in fixtures if (selected / path).is_file()} == {path for path in fixtures if not path.startswith("pm/")}
    assert excluded <= missing(selected) and unneeded not in missing(selected)
    assert not (selected / "pm").exists()
    assert not git(selected, "status", "--short").strip()
    for path, contents in fixtures.items():
        if not path.startswith("pm/"):
            assert (selected / path).read_bytes() == contents
    assert any(path.startswith("pm/") for path in git(selected, "ls-tree", "-r", "--name-only", "HEAD").splitlines())
    print("PASS changed run obtains every non-PM file including a new spaced directory; both PM blobs stay unfetched")
    git(control, "-c", "protocol.version=2", "fetch", "--quiet", "--no-tags", "--depth=1", "origin", "main")
    git(control, "checkout", "--quiet", "--detach", "FETCH_HEAD")
    assert all((control / path).read_bytes() == contents for path, contents in fixtures.items())
    assert not missing(control)
    print("PASS full checkout control materializes all files and all objects")


def tree_stats(paths=None):
    args = ["ls-tree", "-rlz", "HEAD"]
    if paths:
        args.extend(("--", paths))
    files = 0
    size = 0
    for record in git(root, *args).split("\0"):
        if not record:
            continue
        try:
            metadata, path = record.split("\t", 1)
            mode, kind, digest, raw_size = metadata.split()
            if kind == "blob":
                size += int(raw_size)
                files += 1
        except ValueError as error:
            raise RuntimeError(record[:100]) from error
    return {"files": files, "bytes": size}


proof = {
    "source": git(root, "rev-parse", "HEAD").strip(),
    "checkout_excluded_pm": tree_stats("pm/"),
    "tracked_tree": tree_stats(),
    "fixture_updates_required": True,
    "workflow_sha256": sha256((scratch / workflow).read_bytes()).hexdigest(),
    "fixture_wall_seconds": round(perf_counter() - started, 2),
}
print(json.dumps(proof, indent=2))
(scratch / "verification.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")

