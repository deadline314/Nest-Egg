from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

root=Path.cwd()
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/ne267-source-delivery-20261118')
candidate=base/'s09-hawker-release'
prior=base.parent/'ne276-idle-repro-20261119/integration'
out=candidate/'integration'
out.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
expected=read(prior/'publish/result.json')['commit']
previous=read(prior/'published-source.json')
assert subprocess.check_output(['git','branch','--show-current'],cwd=root).strip()==b'codex/ticket-work-20261119-ne267-hawker'
assert all(subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree).decode().strip()==expected for tree in (root,shared))
assert all(sha(shared/path)==digest for path,digest in previous.items())
record=read(candidate/'prepared.json')
native=candidate/'native-release'
native_source=read(native/'source.json')
for lang,count in [('zh',0),('ja',110),('en',1447)]:
    proof=read(native/lang/'result.json')
    assert proof['exit']==0 and proof['equivalent_to_baseline'] and proof['guard_held'] and len(proof['diagnostics'])==count
    assert proof['report']['checks']==9 and not proof['report']['failures'] and proof['report']['language']==lang

mapping={'tools/story/ch2_source.py':'ch2_source.py','tools/story/i18n/ch2_heron.json':'i18n/ch2_heron.json',
         'data/story/ch2_heron.json':'ch2_heron.json','data/levels/ch2_loading.tres':'ch2_loading.tres',
         'data/levels/ch2_loading_map.json':'ch2_loading_map.json'}
paths={name:(candidate/filename).read_bytes() for name,filename in mapping.items()}
assert all(hashlib.sha256(paths[name]).hexdigest()==record['candidate'][filename] for name,filename in mapping.items())
assert all(sha(root/name)==sha(shared/name)==digest for name,digest in record['baseline'].items())
level_source='tools/level/build_ch2.py'
author=(root/level_source).read_text(encoding='utf-8')
point="    a.stand(134, 'c')\n    a.stand(146, 'Ⅻ')\n"
assert author.count(point)==1
paths[level_source]=author.replace(point,"    a.stand(134, 'c')\n    a.trigger(135, 'ch2_s09_hawker')\n    a.stand(146, 'Ⅻ')\n").encode()
guard=previous | {name:hashlib.sha256(value).hexdigest() for name,value in paths.items()}
assert all(native_source[name]==guard[name] for name in (*record['baseline'],'game/fx/soft_whip.gd'))
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root).strip()
for project in (root,shared):
    for name,value in paths.items():
        (project/name).write_bytes(value)
assert all(sha(shared/path)==digest for path,digest in guard.items())
(out/'paths.json').write_text(json.dumps(list(paths),indent=2)+'\n')
(out/'source.json').write_text(json.dumps(guard,indent=2)+'\n')

sys.path.insert(0,str(root/'tools/story'))
from build_ch2_story import spec
from chapter_compiler import write_chapter
assert not write_chapter(spec(),out/'ch2_heron.json')
assert sha(out/'ch2_heron.json')==guard['data/story/ch2_heron.json']
sys.path.insert(0,str(root/'tools/level'))
import build_ch2 as levels
kit=levels.kit
shutil.copyfile(root/'data/levels/ch2_layout_v2.json',out/'ch2_layout_v2.json')
kit.LEVEL_DIR=str(out)
kit.THEME_DIR=str(out)
kit.ENCOUNTER_DIR=str(out)
levels.configure()
loading=levels.build_loading()
for name,left,right,_use,members in levels.COMBAT_ZONES['loading']:
    loading.encounter(name,left,right,members)
issues=loading.check()+levels.route_checks(loading)
assert not issues,issues
loading.grid.write(loading.id,(kit.LEVEL_DIR,'ch2_loading_map.json'),kit._map_extra(loading))
kit.write_level(loading)
for name in ('ch2_loading.tres','ch2_loading_map.json'):
    assert sha(out/name)==guard['data/levels/'+name],name

def run(label,args,cwd):
    destination=out/label
    destination.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(destination/'profile'/key)
    env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8', GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
               SHARDS='8',LOG_DIR=str(destination/'shards'))
    (destination/'command.json').write_text(json.dumps(args,indent=2)+'\n')
    with (destination/'raw.log').open('wb') as log:
        proc=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=2400)
    raw=(destination/'raw.log').read_bytes()
    result={'exit':proc.returncode,'errors':[line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line],
            'source_held':all(sha(shared/name)==digest for name,digest in guard.items()) and all(sha(root/name)==guard[name] for name in paths)}
    (destination/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(label,result,raw.decode(errors='replace')[-1300:],flush=True)
    assert result=={'exit':0,'errors':[],'source_held':True}
    return result

run('compiler',[sys.executable,'-B','-X','utf8','-m','unittest','test_story_contracts','test_chapter_completion_policies',
                'test_ch2_guest_cast'],root/'tools/story')
selector=['C:/Program Files/Git/bin/bash.exe','-c',f'python3() {{ python "$@"; }}; export -f python3; tools/run_tests_changed.sh {expected}']
verify=run('official',selector,shared)
(out/'verification.json').write_text(json.dumps(verify,indent=2)+'\n')
