from pathlib import Path
from collections import Counter
import hashlib
import json
import os
import re
import subprocess
import sys

root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-source-delivery-20261118')
project=base/'s19-runtime'
prepared=base/sys.argv[1]
out=prepared/('native-'+(sys.argv[3] if len(sys.argv)>3 else 'v1'))
out.mkdir()
mapping={'data/story/ch2_heron.json':'ch2_heron.json','data/levels/ch2_loading.tres':'ch2_loading.tres',
         'data/levels/ch2_loading_map.json':'ch2_loading_map.json'}
known=('autoload/story.gd','game/level/level.gd','game/level/level_builder.gd','game/props/portal.gd',
       'ui/dialogue_layer.gd','game/fx/soft_whip.gd','art/characters/ch2_hawker/character.json','art/portraits/ch2_hawker.png')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(root/name)==sha(project/name) for name in known)
old={name:(project/name).read_bytes() for name in mapping}
expected=json.loads((prepared/'prepared.json').read_text())
assert all(sha(project/name)==digest for name,digest in expected['baseline'].items())
probe=out/'observer.gd'
probe.write_bytes((root/'work/ne267-hawker-native.gd').read_bytes())
scene=probe.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n[node name="FreightVoice" type="Node"]\nscript = ExtResource("1")\n',encoding='utf8')
known_results=[]
lang_codes=sys.argv[2].split(',')
def invoke(kind, lang, extra):
    assert lang in ('zh','ja','en')
    unit=out/(lang+kind)
    unit.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(unit/'profile'/key)
    cmd=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
         'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project),'--audio-driver','Dummy',
         '--rendering-method','forward_plus','--rendering-driver','vulkan','--resolution','1280x720','--fixed-fps','60',
         '--quit-after','5000',scene.as_posix(),'--','--out='+str(unit),'--story-language='+lang,*extra]
    (unit/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with (unit/'raw.log').open('wb') as log:
        process=subprocess.run(cmd,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    raw=(unit/'raw.log').read_text(encoding='utf8')
    return unit,process.returncode,re.findall(r'^.*(?:ERROR:|WARNING:).*$',raw,re.M)

baselines={}
for lang in lang_codes:
    unit, code, diagnostics = invoke('-baseline',lang,['--locale-diagnostics'])
    assert code == 0 and all(re.match(r'(?:ERROR|WARNING): \[Story\]',line) for line in diagnostics)
    baselines[lang] = diagnostics
    (unit/'result.json').write_text(json.dumps({'exit':code,'diagnostics':diagnostics},indent=2)+'\n')
try:
    for name,target in mapping.items():
        assert sha(prepared/target)==expected['candidate'][target]
        (project/name).write_bytes((prepared/target).read_bytes())
    guard={name:sha(project/name) for name in (*known,*mapping)}
    for lang in lang_codes:
        unit,code,raw=invoke('',lang,[])
        report=json.loads((unit/'report.json').read_text(encoding='utf8')) if (unit/'report.json').exists() else {}
        result={'exit':code,'diagnostics':raw,'equivalent_to_baseline':raw==baselines[lang],
                'guard_held':all(sha(project/name)==digest for name,digest in guard.items()),'report':report}
        print(lang,{key:value for key,value in result.items() if key!='diagnostics'},'diagnostics',len(raw),flush=True)
        (unit/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        known_results.append(result)
        delta=list((Counter(raw)-Counter(baselines[lang])).items())
        assert code==0 and result['equivalent_to_baseline'] and result['guard_held'] and not report['failures'], (lang, code, delta[:6],report)
    (out/'source.json').write_text(json.dumps(guard,indent=2)+'\n')
finally:
    for name,content in old.items():
        (project/name).write_bytes(content)
    assert all((project/name).read_bytes()==content for name,content in old.items())
