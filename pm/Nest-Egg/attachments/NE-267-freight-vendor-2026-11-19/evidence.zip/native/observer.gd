extends Node
## Move through the actual freight map with its existing inputs and story layer.

const CALL := &"ch2_s09_hawker"
const WIRE := &"ch2_s09_wire"
const SOURCE := "res://data/levels/ch2_loading.tres"
const CAPTURE := preload("res://tools/viewport_capture.gd")

var _out := ""
var _checked := 0
var _failures := PackedStringArray()
var _starts: Array[StringName] = []


func _check(value: bool, message: String) -> void:
	_checked += 1
	if not value:
		_failures.append(message)


func _settle(frames: int) -> void:
	for _frame in frames:
		await get_tree().physics_frame


func _ready() -> void:
	if "--locale-diagnostics" in OS.get_cmdline_user_args():
		get_tree().quit.call_deferred()
		return
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if _out.is_empty():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip = false
	Story.scene_started.connect(func(id: StringName, _mode: StringName) -> void:
		if id == CALL or id == WIRE:
			_starts.append(id))
	var area := Level.new()
	area.configure(load(SOURCE) as LevelData)
	add_child(area)
	await _settle(35)
	var gate := area._portals.get(&"loading_ledger") as Portal
	_check(gate != null and gate.data.requires_flag == &"ch2_market_reconciled", "the freight door still uses its original reconciliation flag")
	var trigger_x := 135.0 * 16.0
	# The existing credit pickup is left of this starting point.
	area.player.global_position = Vector2(trigger_x - 6.0, 576.0)
	for _frame in 1200:
		if Story._completed.has(WIRE):
			break
		await _settle(1)
	_check(_starts == [WIRE] and Story._completed.has(WIRE), "the original wire line completes before crossing the new marker")
	_check(not Story._seen.has(CALL), "the vendor line has not played outside its trigger")
	var flags := GameState.world_flags.duplicate(true)
	var credits := Progression.credits
	var held_movement := false
	Input.action_press(&"move_right")
	for _frame in 270:
		if Story._seen.has(CALL) and area.player.global_position.x >= trigger_x + 64.0:
			held_movement = true
			break
		await _settle(1)
	Input.action_release(&"move_right")
	_check(held_movement and _starts == [WIRE, CALL], "the ordinary movement input crossed the marker, then continued while the line was active")
	_check(not get_tree().paused and not Story._layer.is_radio_frozen(), "the optional voice caption never freezes the area")
	var expected: Array[Dictionary] = Story.resolved_lines(CALL)
	var captured := false
	var observed := ""
	var speaker := ""
	for _frame in 270:
		await _settle(1)
		if Story._layer._radio_root.visible and Story._layer._radio_text.visible_ratio >= 1.0 and _starts.has(CALL):
			observed = Story._layer._radio_text.text
			speaker = Story._layer._radio_name.text
			if expected.size() != 1 or observed != expected[0]["text"] or speaker != expected[0]["name"]:
				continue
			await RenderingServer.frame_post_draw
			captured = CAPTURE.image(get_viewport()).save_png(_out.path_join("hawker-caption.png")) == OK
			break
	_check(captured, "the actual translated line and speaker are visibly rendered")
	for _frame in 840:
		if Story._completed.has(CALL):
			break
		await _settle(1)
	_check(Story._completed.has(CALL), "the caption naturally finishes")
	area.player.global_position = Vector2(trigger_x - 6.0, 576.0)
	await _settle(6)
	area.player.global_position.x = trigger_x + 16.0
	await _settle(6)
	_check(_starts == [WIRE, CALL], "crossing again did not replay the optional rumor")
	_check(flags == GameState.world_flags and credits == Progression.credits,
		"the rumor has no plot flag, requirement or payment: flags=%s, credits=%d" % [flags != GameState.world_flags, Progression.credits - credits])
	FileAccess.open(_out.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify({
		"checks":_checked, "failures":_failures, "language":Story.language, "speaker":speaker,
		"line":observed, "scenes":_starts, "adapter":RenderingServer.get_video_adapter_name()}, "\t"))
	area.queue_free()
	await _settle(3)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures.is_empty() else 1)
