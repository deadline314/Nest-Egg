from pathlib import Path
import json,time,subprocess
w=Path('work/ne228-hud-reading');deadline=time.monotonic()+1500
while True:
 r=json.loads((w/'integration-receipt.json').read_text()) if (w/'integration-receipt.json').exists() else {}
 if r.get('base','').startswith('7009af86') and r.get('exit_code') is not None:break
 assert time.monotonic()<deadline
 time.sleep(2)
assert r['exit_code']==0,r
n=json.loads((w/'integration-native-receipt.json').read_text());v=json.loads((w/'viewed.json').read_text());assert len(v[n['name']])==5
p=w/'final-docs.py';s=p.read_text().replace('2026-10-22（NE-228）','2026-10-23（NE-228）');p.write_text(s)
subprocess.run(['python',str(w/'package.py')],check=True)
subprocess.run(['python',str(w/'final-docs.py')],check=True)
subprocess.run(['git','diff','--check'],check=True)
print('HUD_PACKET_READY',flush=True)
