from pathlib import Path
import os,json,time,subprocess,hashlib,shutil
w=Path('work/ne228-hud-reading');deadline=time.monotonic()+900
while True:
 rows=json.loads((w/'native-before-receipt.json').read_text()) if (w/'native-before-receipt.json').exists() else []
 assert all(r['exit_code']==1 and r['engine_errors']==0 for r in rows)
 if len(rows)==3:break
 assert time.monotonic()<deadline
 time.sleep(1)
for p,h in json.loads((w/'before-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1');receipts=[]
def run(label):
 child=env.copy();child['LOG_DIR']=str((w/(label+'-shards')).resolve());cmd=['tools/run_tests_parallel.sh','--only=QuestMapSuite'];start=time.monotonic()
 with (w/(label+'.log')).open('w') as f:r=subprocess.run(cmd,env=child,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 receipts.append({'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start});(w/'focus-receipt.json').write_text(json.dumps(receipts,indent=2));print(label,r.returncode,flush=True);return r.returncode
assert run('negative')==1
for p in ['ui/hud.gd','ui/pickup_feed.gd','ui/quest_guidance.gd']:shutil.copy2(w/(Path(p).stem+'-candidate.gd'),p)
assert run('fixed')==0
