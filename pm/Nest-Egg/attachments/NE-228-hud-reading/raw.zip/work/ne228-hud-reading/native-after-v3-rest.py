from pathlib import Path
import subprocess,os,json,hashlib,time,re
w=Path('work/ne228-hud-reading');env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen';rows=json.loads((w/'native-after-receipt.json').read_text())
files=['ui/hud.gd','ui/quest_guidance.gd','game/level/prompt_layout.gd','game/level/map_bubbles.gd','game/level/world_prompt.gd','ui/pickup_feed.gd','ui/ui_kit.gd','tests/suite/test_quest_map.gd','work/ne228-hud-reading/probe.gd','work/ne228-hud-reading/motion_base.gd','work/ne228-hud-reading/item_base.gd','work/ne228-hud-reading/phone_base.gd','tools/quest_resume_probe.gd']
(w/'after-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2))
for label,args in [('1080',['--1080']),('smooth',['--smooth']),('reduced',['--reduced'])]:
 n='ne228-1022-hud-reading-after-'+label+'-v3';cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',n,'res://work/ne228-hud-reading/probe.tscn','--mode=write','--save-dir='+str((w/('after-'+label+'-v3-save')).resolve()),*args];start=time.monotonic()
 with (w/('after-'+label+'-wrapper.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
 log=(Path('/workspace/Nest-Egg/work/batch1020b')/(n+'.log')).read_text();row={'label':label,'name':n,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'expected':0,'engine_errors':log.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log))};rows.append(row);(w/'native-after-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);assert r.returncode==0 and row['engine_errors']==0 and row['leaks']==0
 report=json.loads((Path('/workspace/Nest-Egg/work/batch1020b')/n/'result.json').read_text());assert report['completed'] and report['failures']==0
