from pathlib import Path
import json
w=Path('work/ne228-hud-reading');out=Path('pm/Nest-Egg/attachments/NE-228-hud-reading');r=json.loads((w/'integration-receipt.json').read_text());assert r['exit_code']==0
t=(w/'integration.log').read_text();summary=[x for x in t.splitlines() if x.startswith('checks:')][-1];assert 'new failures: 0' in summary
native=json.loads((w/'integration-native-receipt.json').read_text());assert native['completed'] and native['exit_code']==0 and native['engine_errors']==0 and native['leaks']==0
base=r['base'][:8]
packet=json.loads((w/'package-receipt.json').read_text())
(out/'README.md').write_text(f'''# NE-228：HUD與世界閱讀共用空間

世界氣泡原本會壓到右上計時／信用點與剛取得的道具紀錄；目的地方向字也會壓住人物。固定HUD和取得紀錄現在保留實際占位，世界氣泡避開；方向字在同一邊緣找空間，保留世界閱讀優先，空間不足便讓位。[設計與五團隊實圖觀察](../../../../design/20-campaign-experience/HUD_READING_SPACE.md)、[全部收據](validation.json)、[原檔](raw.zip)、[逐檔SHA](manifest.json)。

| 原同條件 | 結果 |
|---|---|
| 原QuestMap套件，只追加8項 | 修前354／4；修後354／0 |
| 最終v3平滑原版控制，72格 | 34項／2失敗：氣泡蓋HUD、方向字蓋人物 |
| v3像素720、像素1080、平滑720、減少動態120% | 每組34／0，共136／0；288個實際逐格矩形取樣 |
| 接上7a29f753載具修正後，原同平滑組 | 34／0；72格，0引擎ERROR、0退出洩漏診斷；該次完整回歸7358／1另有暖檔順序失敗，保留全部原檔 |
| 接上BG-50修正後，原同平滑組 | 34／0；72格，0引擎ERROR、0退出洩漏診斷 |
| 原選擇器、5bcc9f68 | 20組，7,349／0新失敗／0已知失敗，216秒 |
| 最後整合後原選擇器、{base} | {summary}；程序含準備{r['seconds']:.2f}秒 |

最終v3前後共25張PNG、首次整合5張與最新整合5張，共35張逐張檢視；七次原生程序均0引擎ERROR／0退出洩漏診斷。世界路牌原本至少16可見格的斷言保持；方向字另要求有真可見見證，v3四組分別8／6／6／1格，首次整合6格，最新整合{native['hud_summary']['caption_witness']}格。後段世界閱讀優先會收起方向字，不把其隱藏說成每格都顯示。四個正向都有17格真正取得紀錄與真正人物氣泡共存；不是全藏再宣稱無重疊。

v1新寫的方向字最低16格規則，與原「世界閱讀優先」契約衝突，額外造成一項失敗；v2只移除這個新任意下限，仍要求至少一格真見證，所有原路牌最低16格及重疊斷言保留。v2初期只驗固定HUD；圖片看起來靠近動態彈帶，v3補真AmmoTray／VitalsTag矩形後仍通過，像素frame16氣泡右邊與彈帶左邊相隔約5世界單位。全部v1／v2失敗和源碼保留，沒有改runner、selector、filters或known_failures。

真Main、真保險箱資料盤、真IO拒絕與公開重試。明示六個已通過路線旗標、安排人物位置、存活下限1；為72格文字動畫固定actor物理。不是真人從新遊戲一路通關。英／日較早fixture只測排版，沒有稱全章翻譯；人物登記的閱讀矩形不是完整alpha輪廓或全關節驗收。軟體Forward+／HDR／Vulkan llvmpipe與硬體GPU、實體手把分開。

五團隊十張官方商店原圖與API回應、URL、時間、SHA全部留存，10張逐張檢視。HUNTDOWN／FinalStation／Blasphemous／Eastward作資訊區域參照；DeadCells兩張無HUD，只參考威脅與背景分離，不從靜態圖推論隱藏機制或玩家民調。

此前5bcc9f68完整CI實際96,000項／3新失敗、634秒；原job log保留，沒有稱綠。7a29f753載具修正完整CI39789378374已96,007／0新／0已知失敗、550秒，兩份原job全log均保留。本次第一次7a整合回歸7358／1暖檔順序失敗轉BG-50，HUD改動保持；BG-50證實預算延後會丟讀完標記，但未逕稱偶發唯一根因。最新同來源HUD接上BG-50後再驗畫面與原選擇器，實際版本與結果如上。整票仍進行中，原未勾條件不代勾。

原檔{packet['entries']}項，{packet['bytes']:,} bytes，zip SHA `{packet['sha256']}`；每一項已解出核對SHA。
''')
ticket=Path('pm/Nest-Egg/[NE-228]重整全遊戲介面體驗.md');s=ticket.read_text();assert '# Commit-23' not in s
s+='''\n\n# Commit-23

## 內文

右上的計時、信用點與取得紀錄原本會被人物氣泡壓住，目的地方向字也可能蓋住人物。現在氣泡會避開真正顯示中的HUD與取得紀錄；方向字保留原目的地與文字，沿同一邊緣讓位，並保留世界閱讀優先。空白或消失的紀錄立即釋放空間，原取得通知時間、操作與保存規則保持。

開始前重讀User-guide，另看HUNTDOWN、The Final Station、Blasphemous、Eastward、Dead Cells五團隊十張官方圖片，逐張保存與核對；靜態圖只作構圖觀察，不當玩家民調或輸入機制證明。[設計與取捨](../../design/20-campaign-experience/HUD_READING_SPACE.md)、[前後負控制、全部中途失敗與35張原圖](attachments/NE-228-hud-reading/README.md)。

### 測試結果

| 項目 | 結果 |
|---|---|
| 原任務地圖套件＋8項 | 修前354／4；修後354／0，既有斷言逐位元相同 |
| 相同原生平滑組負控制 | 修前34／2；修後34／0 |
| 四組最終原生設定 | 136／0；288格取樣，像素／平滑、720／1080、減少動態與120%文字 |
| 首次7a整合 | 原生34／0；完整回歸7358／1暖檔順序失敗，原檔保留並轉BG-50處理 |
| 再接上BG-50修正後原生複驗 | 34／0，72格；0引擎ERROR、0退出洩漏診斷 |
| 原選擇器基準5bcc9f68 | 20組、7,349項，0新／已知失敗，216秒 |
'''+f'| 最新{base}整合後原選擇器 | {summary} |\n'+'''
七次原生程序共35張圖已逐張檢視；合成輸入、安排好的路線前提與軟體Vulkan明確標示。此項修正維持本票進行中與原未勾條件。

### 本作前後圖

| 修前：氣泡蓋住右上資訊 | 修後：各自保留閱讀空間 |
|---|---|
| ![修前](images/NE-228-hud-reading-before.png) | ![修後](images/NE-228-hud-reading-after.png) |

![1080p：氣泡避開動態彈帶；方向字沿邊讓位](images/NE-228-hud-reading-1080.png)
![減少動態與120%文字：世界閱讀優先，方向字讓位](images/NE-228-hud-reading-reduced.png)

<details>
<summary>五個團隊的研究原圖（他作，非本作驗收）</summary>

![HUNTDOWN](images/NE-228-hud-reading-ref-598550.jpg)
![The Final Station](images/NE-228-hud-reading-ref-435530.jpg)
![Blasphemous](images/NE-228-hud-reading-ref-774361.jpg)
![Eastward](images/NE-228-hud-reading-ref-977880.jpg)
![Dead Cells：無HUD，只參考威脅與背景](images/NE-228-hud-reading-ref-588650.jpg)

</details>
''';ticket.write_text(s)
guide=Path('pm/user_guide.md');s=guide.read_text();line='2026-10-23（NE-228）：世界氣泡也要避開固定HUD、真正取得紀錄與動態彈帶；目的地方向字沿邊讓位，世界閱讀優先。[五團隊十張研究圖、負控制、35張逐張檢視原圖與合併複驗](Nest-Egg/attachments/NE-228-hud-reading/README.md)。首次7a整合7358／1暖檔失敗保留，HUD來源不變，接上BG-50後再驗畫面與原選擇器。只移除本次新探針與既有契約衝突的方向字16格下限，原路牌至少16格與所有重疊判定保持。人物閱讀矩形不冒充全輪廓／關節驗收，原整票版面條件維持未勾。\n\n';assert line not in s;guide.write_text(line+s)
print(summary)
