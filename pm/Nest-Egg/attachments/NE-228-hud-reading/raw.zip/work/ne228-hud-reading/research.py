from pathlib import Path
import urllib.request,json,hashlib,datetime
w=Path('work/ne228-hud-reading/references');rows=[]
for app in ['598550','435530','774361','977880','588650']:
 url='https://store.steampowered.com/api/appdetails?appids='+app+'&l=english';raw=urllib.request.urlopen(url,timeout=25).read();d=json.loads(raw)[app];assert d['success'];data=d['data'];(w/(app+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
 for i,s in enumerate(data.get('screenshots',[])[:2],1):
  u=s['path_full'];b=urllib.request.urlopen(u,timeout=30).read();p=w/(app+'-'+str(i)+'.jpg');p.write_bytes(b);rows.append({'app':app,'game':data['name'],'developers':data['developers'],'page':'https://store.steampowered.com/app/'+app,'api':url,'url':u,'file':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (w/'sources.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
 print(data['name'],flush=True)
