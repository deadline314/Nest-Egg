from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil,re
root=Path.cwd();w=root/'work/ne228-hud-reading';base='5bcc9f68b4e226e4d5b91d788d20d40b174efce0';native=Path('/workspace/Nest-Egg/work/batch1020b');out=root/'pm/Nest-Egg/attachments/NE-228-hud-reading';sha=lambda b:hashlib.sha256(b).hexdigest()
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
assert json.loads((w/'original-test-reconstruction.json').read_text())['original_assertions_byte_exact']
receipt=json.loads((w/'changed-receipt.json').read_text());assert receipt['exit_code']==0
integrated=json.loads((w/'integration-receipt.json').read_text());assert integrated['exit_code']==0
for p,h in json.loads((w/'integration-frozen-source.json').read_text())['sha256'].items():assert sha((root/p).read_bytes())==h,p
rows=[json.loads((w/'native-before-v3-receipt.json').read_text())]+json.loads((w/'native-after-receipt.json').read_text());assert len(rows)==5
viewed=json.loads((w/'viewed.json').read_text());reports=[]
integration_native=json.loads((w/'integration-native-receipt.json').read_text())
assert integration_native['exit_code']==0 and integration_native['engine_errors']==0 and integration_native['leaks']==0
assert len(viewed[integration_native['name']])==5
for row in rows:
 name=row['name'];assert row['exit_code']==row['expected'] and row['engine_errors']==0 and row['leaks']==0
 report=json.loads((native/name/'result.json').read_text());assert report['completed']
 assert len(viewed[name])==5
 assert report['hud_summary']['feed_bubble_witness']>0 and report['hud_summary']['caption_witness']>0
 if row['expected']==0:assert report['hud_summary']['hud_clear'] and report['hud_summary']['caption_clear']
 reports.append({'run':row,'summary':report['hud_summary'],'individually_viewed_png':viewed[name]})
harness=['tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']
for p in harness:assert (root/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p]),p
files={}
for p in w.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in part or part=='__pycache__' for part in p.relative_to(w).parts):files['work/ne228-hud-reading/'+str(p.relative_to(w))]=p.read_bytes()
for p in native.glob('ne228-1022-hud-reading-*'):
 if 'profile' in p.name:continue
 if p.is_dir():
  for f in p.rglob('*'):
   if f.is_file():files['native/'+str(f.relative_to(native))]=f.read_bytes()
 elif p.is_file():files['native/'+p.name]=p.read_bytes()
paths=list(json.loads((w/'verification-frozen-source.json').read_text()))+list(json.loads((w/'integration-frozen-source.json').read_text())['sha256'])+harness+['design/20-campaign-experience/HUD_READING_SPACE.md','tools/viewport_capture.gd']
for p in paths:files['source/final/'+p]=(root/p).read_bytes()
for p in ['ui/hud.gd','ui/pickup_feed.gd','ui/quest_guidance.gd','tests/suite/test_quest_map.gd']:files['source/before/'+p]=subprocess.check_output(['git','show',base+':'+p])
text=(w/'changed.log').read_text();validation={'base':base,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'affected':receipt,'affected_summary':[l for l in text.splitlines() if 'checks:' in l or re.search(r'Running \d+ groups',l)],'additional_checks':8,'unit':'354/4 before;354/0 after','native':reports,'history':'v1 caption anti-vacuity minimum16 conflicted with existing hide-on-reading priority: removed only the new arbitrary16 rule; retained original world prompt minimum16. v2 static HUD passed; actual images prompted v3 extension to dynamic AmmoTray/VitalsTag. v3 retained all assertions and passed all four positive cases. Full raw v1/v2 failures retained.','harness_unchanged':harness,'scope':'Forward+ HDR llvmpipe software Vulkan. Real Main/authored vault disc, actual IO refusal and public retry. Declared six preexisting route flags, positioned actors, survival floor1 and held actor physics for72 text animation frames. EN/JA previous probes are layout fixtures, not full chapter translations. Actor reading bounds are not rendered-alpha silhouettes/joint acceptance. No human, physical controller/GPU or full campaign acceptance.'}
for f in ['integration-receipt.json','integration-native-receipt.json']:
 if (w/f).exists():validation[f]=json.loads((w/f).read_text())
validation['first_integration_failure']=json.loads((w/'first-integration-receipt.json').read_text())
validation['first_integration_native']=json.loads((w/'first-integration-native-receipt.json').read_text())
validation['first_integration_scope']='7a original20 groups7358/1 warm-order failure,225s; native34/0. Preserved; BG50 isolated read-proof loss under budget deferral, not called unique original intermittent root. HUD source unchanged for new-main integration.'
out.mkdir(parents=True,exist_ok=True);(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for p,b in files.items():assert sha(z.read(p))==sha(b),p
manifest={'archive_bytes':(out/'raw.zip').stat().st_size,'archive_sha256':sha((out/'raw.zip').read_bytes()),'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name,frame,dest in [('before-smooth',0,'before'),('after-smooth',0,'after'),('after-1080',16,'1080'),('after-reduced',16,'reduced'),('after-pixel',16,'pixel')]:shutil.copyfile(native/('ne228-1022-hud-reading-'+name+'-v3')/('motion-%02d.png'%frame),root/('pm/Nest-Egg/images/NE-228-hud-reading-'+dest+'.png'))
for app in ['598550','435530','774361','977880','588650']:shutil.copyfile(w/'references'/(app+'-2.jpg'),root/('pm/Nest-Egg/images/NE-228-hud-reading-ref-'+app+'.jpg'))
r={'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256']};(w/'package-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
