from pathlib import Path
import subprocess,os,json,time,hashlib,re
w=Path('work/ne228-hud-reading');base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert base!='5bcc9f68b4e226e4d5b91d788d20d40b174efce0','integrate new main first'
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
files=['autoload/fx.gd','game/player/player.gd','game/player/vehicle_command_input.gd','game/vehicles/vehicle.gd','tests/smoke_test.gd','core/asset_prefetch.gd','tests/suite/test_ch1_map.gd']
(w/'integration-frozen-source.json').write_text(json.dumps({'base':base,'sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}},indent=2))
env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen';name='ne228-1022-hud-reading-integrated-'+base[:8];cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/ne228-hud-reading/probe.tscn','--mode=write','--save-dir='+str((w/('integrated-'+base[:8]+'-save')).resolve()),'--smooth'];start=time.monotonic()
with (w/'integration-native-wrapper.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
native=Path('/workspace/Nest-Egg/work/batch1020b');log=(native/(name+'.log')).read_text();report=json.loads((native/name/'result.json').read_text());rec={'name':name,'base':base,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'engine_errors':log.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log)),'completed':report['completed'],'hud_summary':report['hud_summary']};(w/'integration-native-receipt.json').write_text(json.dumps(rec,indent=2));assert r.returncode==0 and rec['engine_errors']==0 and rec['leaks']==0 and rec['completed'] and report['hud_summary']['hud_clear'] and report['hud_summary']['caption_clear']
env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='2',LOG_DIR=str((w/'integration-shards').resolve()));cmd=['tools/run_tests_changed.sh',base];start=time.monotonic()
with (w/'integration.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
(w/'integration-receipt.json').write_text(json.dumps({'base':base,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2));assert r.returncode==0
print('INTEGRATED_HUD_PASS',flush=True)
