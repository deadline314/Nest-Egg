extends "res://work/ne228-hud-reading/motion_base.gd"
var hud_frames:Array=[]
var _feed_witness:=0
var _hud_clear:=true
var _caption_clear:=true
var _caption_witness:=0
func _observe_motion_frame(frame:int)->void:
	var level:=_level()
	var inverse:=get_viewport().get_canvas_transform().affine_inverse()
	var hud_boxes:Array[Rect2]=[]
	var occupied:Array=[]
	for control:Control in [level.hud._timer_label,level.hud.credits_tag]:
		if control.is_visible_in_tree() and control.modulate.a>0.02:
			var rect:Rect2=(inverse*control.get_global_transform_with_canvas())*Rect2(Vector2.ZERO,control.size.max(control.get_minimum_size()))
			hud_boxes.append(rect)
			occupied.append({"owner":String(control.name),"rect":[rect.position.x,rect.position.y,rect.size.x,rect.size.y]})
	for control in [level.hud.ammo_tray,level.hud.vitals_tag]:
		var rect:Rect2=control.prompt_obstacle_rect()
		if rect.has_area():
			hud_boxes.append(rect)
			occupied.append({"owner":"dynamic:"+String(control.name),"rect":[rect.position.x,rect.position.y,rect.size.x,rect.size.y]})
	var feed_boxes:Array[Rect2]=[]
	for row in level.hud.pickup_feed.get_children():
		if row is Control and row.is_visible_in_tree() and row.modulate.a>0.02:
			var rect:Rect2=(inverse*row.get_global_transform_with_canvas())*Rect2(Vector2.ZERO,row.size)
			feed_boxes.append(rect)
			hud_boxes.append(rect)
			occupied.append({"owner":"pickup:"+row.label.text,"rect":[rect.position.x,rect.position.y,rect.size.x,rect.size.y]})
	var bubbles:Array=[]
	var overlapped:=false
	var host:MapBubbles=level._bubbles
	for bubble:Dictionary in host._active:
		var rect:Rect2=bubble.get("rect",Rect2())
		if host.is_visible_in_tree() and host._alpha_of(bubble)>0.02 and rect.has_area():
			bubbles.append({"text":bubble["text"],"alpha":host._alpha_of(bubble),"rect":[rect.position.x,rect.position.y,rect.size.x,rect.size.y]})
			if not feed_boxes.is_empty():_feed_witness+=1
			for box:Rect2 in hud_boxes:overlapped=overlapped or rect.intersects(box)
	var arrow:=_guidance()._arrow
	var caption:Rect2=(inverse*arrow.get_global_transform_with_canvas())*Rect2(Vector2.ZERO,arrow.size.max(arrow.get_minimum_size()))
	var body:=level.player.prompt_obstacle_rect()
	var caption_overlap:=arrow.visible and caption.intersects(body)
	_caption_witness+=int(arrow.visible)
	_hud_clear=_hud_clear and not overlapped
	_caption_clear=_caption_clear and not caption_overlap
	hud_frames.append({"frame":frame,"hud":occupied,"bubbles":bubbles,"bubble_hud_overlap":overlapped,"caption_visible":arrow.visible,"caption_player_overlap":caption_overlap,"caption":[caption.position.x,caption.position.y,caption.size.x,caption.size.y],"body":[body.position.x,body.position.y,body.size.x,body.size.y]})
func _shot(label:String)->void:
	await super._shot(label)
	if label=="write-accepted":
		_check(_feed_witness>0,"actual acquired feed and actual authored speech coexist in the native sample")
		_check(_hud_clear,"every visible authored speech frame avoids the actual acquired feed, fixed status and dynamic ammo/health")
		_check(_caption_witness>0,"the actual destination caption is observed rather than vacuously hidden")
		_check(_caption_clear,"every visible destination caption frame avoids the actual player reading bounds")
		_save_report()
func _save_report()->void:
	super._save_report()
	var file:=out.path_join("result.json")
	var d:Dictionary=JSON.parse_string(FileAccess.get_file_as_string(file))
	d["hud_frames"]=hud_frames
	d["hud_summary"]={"feed_bubble_witness":_feed_witness,"caption_witness":_caption_witness,"hud_clear":_hud_clear,"caption_clear":_caption_clear}
	FileAccess.open(file,FileAccess.WRITE).store_string(JSON.stringify(d,"\t"))
