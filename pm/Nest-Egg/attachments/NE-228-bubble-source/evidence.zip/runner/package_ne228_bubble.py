from pathlib import Path
import json,hashlib,zipfile,re,shutil
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=Path('/workspace/Nest-Egg/work/batch1020b');d=r/'pm/Nest-Egg/attachments/NE-228-bubble-source'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
frozen=json.loads((w/'ne228-bubble-final-source-v1.json').read_text())
for name,expected in frozen.items():assert digest(r/name)==expected,name
before=json.loads((n/'ne228-bubble-before-v1/result.json').read_text());early_after=json.loads((n/'ne228-bubble-after-v1/result.json').read_text());assert before['checks']==early_after['checks']==52 and len(before['failures'])==1 and not early_after['failures']
original=w/'ne228-bubble-before-v1-source/work/ne228-bubble-source/probe.gd';assert digest(original)==digest(r/'work/ne228-bubble-source/probe.gd')
native=json.loads((w/'ne228-bubble-native-final-v1.json').read_text());assert len(native)==2 and all(row['clean'] and not row['failures'] and row['exit']==row['engine_exit']==0 for row in native)
headless=json.loads((w/'ne228-bubble-ci-style-v1/receipt.json').read_text());assert len(headless['cases'])==1 and headless['cases'][0]['passed']
assert (w/'ne228-bubble-affected-v1.exit').read_text().strip()==(w/'ne228-bubble-focus-v2.exit').read_text().strip()=='0'
text=(w/'ne228-bubble-affected-v1.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)\s+\(wall time (\d+) s\)',text);assert m and m[2]==m[3]=='0'
shared={}
for key in ['ali','voice','sunday','handoff']:
 receipt=json.loads((w/('ne228-bubble-'+key+'-regression-v1')/'receipt.json').read_text());assert all(row['passed'] for row in receipt['cases']);shared[key]={'processes':len(receipt['cases']),'checks':sum(row['result']['checks'] for row in receipt['cases']),'failures':0}
entries={}
def add(name,p):
 if p.is_file():entries[name]=p

def tree(prefix,path):
 for file in sorted(path.rglob('*')):
  if file.is_file() and not any(part.endswith('-profile') or part in ['.godot','__pycache__'] for part in file.relative_to(path).parts):add(prefix+'/'+str(file.relative_to(path)),file)
for name in frozen:add('source/final/'+name,r/name)
add('source/final/design/20-campaign-experience/BUBBLE_SOURCE_LIFETIME.md',r/'design/20-campaign-experience/BUBBLE_SOURCE_LIFETIME.md')
tree('source/before',w/'ne228-bubble-before-v1-source');tree('source/original-probe',r/'work/ne228-bubble-source')
for tag in ['ne228-bubble-before-v1','ne228-bubble-after-v1','ne228-bubble-final-original-v1','ne228-bubble-final-published-v1']:
 tree('native/'+tag,n/tag)
 for suffix in ['.log','.exit','-xvfb.log']:add('native/'+tag+suffix,n/(tag+suffix))
for path in w.glob('ne228-bubble-*'):
 if path.is_file() and path.suffix in ['.log','.exit','.json']:add('logs/'+path.name,path)
 elif path.is_dir() and (path.name.endswith('-slot') or path.name.endswith('-shards') or path.name.startswith(('ne228-bubble-ci-style-','ne228-bubble-ali-regression-','ne228-bubble-voice-regression-','ne228-bubble-sunday-regression-','ne228-bubble-handoff-regression-'))):
  if path.name.endswith('-shards'):
   for file in path.glob('*.log'):add('tests/'+path.name+'/'+file.name,file)
  else:tree('runs/'+path.name,path)
for path in w.glob('run_ne228_bubble*.py'):add('runner/'+path.name,path)
add('runner/package_ne228_bubble.py',Path(__file__))
manifest={};archive=d/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(entries.items()):manifest[name]={'bytes':path.stat().st_size,'sha256':digest(path)};z.write(path,name)
with zipfile.ZipFile(archive) as z:
 for name,expected in manifest.items():
  with z.open(name) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==expected['sha256'],name
assert archive.stat().st_size<50*1024*1024
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
validation={'base':'bdd6ec1c54710f9b4fce78246bb3fc98d218f54a','source_sha256':frozen,'engine_sha256':headless['engine_sha256'],'negative':{'checks':52,'before_failures':1,'after_failures':0,'identical_probe_sha256':digest(original),'before_state':json.loads((n/'ne228-bubble-before-v1/source-state.json').read_text())},'affected':{'groups':int(re.search(r'Running (\d+) groups',text)[1]),'workers':4,'checks':int(m[1]),'new_failures':0,'known_failures':0,'seconds':int(m[4])},'focused':{'groups':2,'checks':92,'failures':0,'seconds':15},'headless':{'processes':1,'checks':headless['cases'][0]['result']['checks'],'failures':0},'native':{'processes':2,'checks':sum(row['checks'] for row in native),'failures':0,'cases':native},'shared':shared,'archive':{'file':'evidence.zip','bytes':archive.stat().st_size,'entries':len(manifest),'sha256':digest(archive)},'limits':['Exact original produced handoff seed and actual Ali interaction, not a natural human chapter playthrough.','Software Forward+ HDR2D; physical controller, GPU performance and overall UI/art acceptance remain separate.','Only original source lifetime and invitation eligibility; reading budgets, fonts, fades and maximum concurrent lines remain unchanged.']}
(d/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
images={'before':n/'ne228-bubble-before-v1/accepted/refused.png','after':n/'ne228-bubble-final-original-v1/accepted/refused.png','before-state':n/'ne228-bubble-before-v1/source-state/refused.png','after-state':n/'ne228-bubble-final-original-v1/source-state/refused.png'}
(r/'pm/Nest-Egg/images').mkdir(parents=True,exist_ok=True)
for name,path in images.items():shutil.copyfile(path,r/'pm/Nest-Egg/images'/('NE-228-bubble-source-'+name+'.png'))
print(json.dumps({key:value for key,value in validation.items() if key not in ['source_sha256','native','limits']},ensure_ascii=False))
