from pathlib import Path
import subprocess,time,json,hashlib
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';deadline=time.monotonic()+1800
while not (w/'ne228-bubble-affected-v1.exit').exists():
 assert time.monotonic()<deadline
 time.sleep(1)
assert (w/'ne228-bubble-affected-v1.exit').read_text().strip()=='0'
frozen=json.loads((w/'ne228-bubble-final-source-v1.json').read_text());engine=str(w/'godot-audio-build/dist/godot')
for tool,label in [('run_ali_completion.py','ali'),('run_voice_completion.py','voice'),('run_sunday_choice.py','sunday'),('run_handoff_completion.py','handoff')]:
 name='ne228-bubble-'+label+'-regression-v1';print('START',name,flush=True)
 with (w/(name+'.log')).open('w') as log:code=subprocess.run(['python',str(r/'tools'/tool),'--godot',engine,'--output',str(w/name)],cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
 (w/(name+'.exit')).write_text(str(code)+'\n');assert code==0,name
 for file,expected in frozen.items():assert hashlib.sha256((r/file).read_bytes()).hexdigest()==expected,file
 print('PASS',name,flush=True)
print('ALL ORIGINAL SAVE AND CONTINUATION FLOWS VERIFIED',flush=True)
