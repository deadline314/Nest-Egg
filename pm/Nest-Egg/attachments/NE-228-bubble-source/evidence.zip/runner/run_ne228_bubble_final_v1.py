from pathlib import Path
import os,subprocess,time,json,re,hashlib
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=Path('/workspace/Nest-Egg/work/batch1020b');deadline=time.monotonic()+1800
while not (w/'ne228-bubble-affected-v1.exit').exists():
 assert time.monotonic()<deadline
 time.sleep(1)
assert (w/'ne228-bubble-affected-v1.exit').read_text().strip()=='0'
frozen=json.loads((w/'ne228-bubble-final-source-v1.json').read_text());env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(w/'godot-audio-build/dist/godot'));rows=[]
for label,scene in [('original','res://work/ne228-bubble-source/probe.tscn'),('published','res://tests/probes/bubble_source.tscn')]:
 tag='ne228-bubble-final-'+label+'-v1';command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,scene,'--mode=evening_ordered','--save-dir='+str(w/(tag+'-slot'))];print('START',tag,flush=True)
 with (w/(tag+'-console.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 data=json.loads((n/tag/'result.json').read_text());state=json.loads((n/tag/'source-state.json').read_text());raw=(n/(tag+'.log')).read_text();row={'tag':tag,'checks':data['checks'],'failures':data['failures'],'exit':code,'engine_exit':int((n/(tag+'.exit')).read_text()),'clean':not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use|^FAIL ',raw,re.M),'state':state};rows.append(row);(w/'ne228-bubble-native-final-v1.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);assert code==0 and row['engine_exit']==0 and row['clean'] and not data['failures'] and state['active']==state['queued']==state['passive_requests']==[] and state['present'] is False and not state['completed_greeting'],row
 for name,expected in frozen.items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==expected,name
print('FINAL ORIGINAL AND PUBLISHED NATIVE SOURCE FLOWS VERIFIED',flush=True)
