extends "res://tools/radio_durable_probe.gd"
## Explicitly arranged combat proximity, real Main/store, no story result writes.
## Input replay and synthetic device events, not human/device acceptance.

var observations: Array[Dictionary] = []
var damage_events: Array[Dictionary] = []
var world_samples: Array[Dictionary] = []
var completion_order: Array[StringName] = []

func _check(ok: bool, what: String) -> void:
	observations.append({"passed": ok, "message": what})
	super._check(ok, what)

func _durable_run() -> void:
	Story.auto_skip = false
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_main.process_mode = Node.PROCESS_MODE_PAUSABLE
	_main.set("_run_store", RunSaveStore.new(_save_dir.path_join("slot.json")))
	add_child(_main)
	await _frames(30)
	await _wait_route()
	_main.call("_on_start_requested", GameState.difficulties[1])
	await _wait_route()
	for i in 180:
		Story.skip_cinematic()
		await _frames(1)
	_main.call("_on_area_requested", LEVEL)
	var level := await _wait_street()
	_check(level != null, "real Main enters initialized authored street")
	if level == null:
		_finish()
		return
	for i in 300:
		Story.skip_cinematic()
		await _read_all(Story._layer)
		await _frames(1)
		if not GameplayLock.is_locked() and not _main.call("_route_pending"):
			break
	level.player.health.setup(9999, level.player.tuning.hurt_invulnerability)
	level.player.global_position.x = 96.0 * 16.0
	level.player.health.damaged.connect(func(info: DamageInfo) -> void: _record_damage("player", level.player, info))
	for node in get_tree().get_nodes_in_group(&"enemies"):
		var enemy := node as Enemy
		if enemy != null:
			enemy.health.damaged.connect(func(info: DamageInfo) -> void: _record_damage("enemy", enemy, info))
	await _frames(15)
	await _read_all(Story._layer)
	var bullet: Projectile
	# Public mouse/shoot/reload only. Do not assign device history or enemy fields.
	for frame in 900:
		if Story._layer.is_radio_frozen():
			Input.action_release(&"shoot")
			await _read_all(Story._layer)
		var target: Enemy
		var distance := INF
		for node in get_tree().get_nodes_in_group(&"enemies"):
			var enemy := node as Enemy
			if enemy != null and not enemy.health.is_dead:
				var gap := level.player.global_position.distance_squared_to(enemy.global_position)
				if gap < distance:
					distance = gap
					target = enemy
		if target != null:
			var mouse := InputEventMouseMotion.new()
			mouse.position = get_viewport().get_canvas_transform() * target.hurtbox.center()
			mouse.global_position = mouse.position
			mouse.relative = Vector2(0.01, 0)
			get_viewport().push_input(mouse, true)
			Input.warp_mouse(get_viewport().get_final_transform() * mouse.position)
		Input.action_press(&"shoot")
		if level.player.loadout.is_dry(): Input.action_press(&"reload")
		else: Input.action_release(&"reload")
		await _frames(1)
		if not damage_events.is_empty():
			for node in ProjectilePool.container().get_children():
				if node is Projectile and node.active and node.team == Combat.Team.PLAYER:
					bullet = node
					break
		if bullet != null: break
	Input.action_release(&"shoot")
	Input.action_release(&"reload")
	_check(not damage_events.is_empty(), "actual street combat produced a real health damage event")
	_check(bullet != null and bullet.active, "actual public shooting leaves a live player projectile")
	_check(not _enemy_positions(level).is_empty(), "authored enemies remain in the street")
	# No time passes between choosing the active bullet and freezing the world.
	for id in PAIR:
		_check(Story.play(id, false), "canonical radio request admitted: " + String(id))
	Story.scene_finished.connect(_record_completion)
	await _frames(6)
	var layer: DialogueLayer = Story._layer
	var before := _world_sample(level, bullet)
	world_samples.append(before)
	_check(layer.is_radio_frozen() and get_tree().paused, "back-to-back canonical radios pause the real Main world")
	await _shot("pair-first-reading")
	await _frames(90)
	var after := _world_sample(level, bullet)
	world_samples.append(after)
	_check(before == after, "same projectile, enemies, health, clock and damage ledger stay frozen")
	level._pause_menu.open()
	await _shot("pair-pause-menu")
	level._pause_menu.close()
	await _frames(10)
	_check(layer.is_radio_frozen() and get_tree().paused and before == _world_sample(level, bullet), "closing pause retains reading pause and the exact live world")
	var expected: Array[String] = []
	for id in PAIR:
		for line in Story.resolved_lines(id): expected.append(str(line.get("text", "")))
	var shown: Array[String] = []
	var presses := 0
	while layer.is_radio_frozen() and presses < 60:
		if not await _wait_radio_line(layer): break
		shown.append(layer._radio_text.text)
		await _shot("pair-line-%02d" % presses)
		Input.parse_input_event(_key(true))
		await _frames(2)
		Input.parse_input_event(_key(false))
		presses += 1
		if presses < expected.size():
			_check(before == _world_sample(level, bullet) and get_tree().paused, "world remains frozen between queued radio lines %d" % presses)
	_check(shown == expected, "each canonical line is fully visible once, in exact script order")
	_check(presses == expected.size(), "one real confirm event advances each complete line")
	_check(completion_order.filter(func(id: StringName) -> bool: return id in PAIR) == PAIR, "both real completion signals follow queued order")
	var store: RunSaveStore = _main.get("_run_store")
	var saved := store.read()
	for id in PAIR:
		_check(Story.progress_snapshot().has(id) and saved.get("story", {}).get("seen", []).has(String(id)), "completed radio is live and durable: " + String(id))
	await _frames(12)
	_check(not get_tree().paused and not GameplayLock.is_locked(), "last confirmation releases reading pause without a stale gate")
	_check(bullet == null or not is_instance_valid(bullet) or not bullet.active or bullet.global_position != Vector2(before["bullet_position"][0], before["bullet_position"][1]), "same live projectile resumes or naturally collides after reading")
	await _shot("combat-after-reading")
	Story.scene_finished.disconnect(_record_completion)
	var report := {"scope": "arranged position and player HP, real Main/Level/store, public input replay; not a campaign or physical-device playtest", "checks": observations, "damage": damage_events, "frozen_world": world_samples, "expected_lines": expected, "shown_lines": shown, "completion_order": completion_order, "engine": Engine.get_version_info(), "gpu": RenderingServer.get_video_adapter_name()}
	var file := FileAccess.open(_out.path_join("report.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "  "))
	file.close()
	_finish()

func _record_completion(id: StringName) -> void:
	completion_order.append(id)

func _record_damage(kind: String, actor: Node2D, info: DamageInfo) -> void:
	damage_events.append({"kind": kind, "actor": actor.get_instance_id(), "frame": Engine.get_physics_frames(), "amount": info.amount, "source": String(info.source_id), "position": [actor.global_position.x, actor.global_position.y]})

func _world_sample(level: Level, bullet: Projectile) -> Dictionary:
	var enemies: Array[Dictionary] = []
	for node in get_tree().get_nodes_in_group(&"enemies"):
		var enemy := node as Enemy
		if enemy != null:
			enemies.append({"id": enemy.get_instance_id(), "position": [enemy.global_position.x, enemy.global_position.y], "hp": enemy.health.current})
	return {"bullet_id": bullet.get_instance_id() if is_instance_valid(bullet) else 0, "bullet_position": [bullet.global_position.x, bullet.global_position.y] if is_instance_valid(bullet) else [], "bullet_active": is_instance_valid(bullet) and bullet.active, "enemies": enemies, "clock": GameState.run_time, "player_hp": level.player.health.current, "damage_count": damage_events.size()}
