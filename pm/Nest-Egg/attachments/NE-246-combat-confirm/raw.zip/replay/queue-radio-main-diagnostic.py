import os,subprocess,hashlib,json
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');p=b/'audio';f=p/'ui/dialogue_layer.gd';current=f.read_bytes();before=(b/'radio-combat-source/dialogue-before.gd').read_bytes();assert current==(b/'radio-combat-source/dialogue-after.gd').read_bytes()
rows=[]
try:
 for label,raw in [('baseline',before),('candidate',current)]:
  f.write_bytes(raw)
  name='radio-main-'+label+'-quiet'
  env=dict(os.environ,GODOT=str(b/'godot472/Godot_v4.7.2-stable_linux.x86_64'),LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',LOG_DIR=str(b/name))
  with (b/(name+'.log')).open('w') as log:r=subprocess.run(['bash','tools/run_tests_parallel.sh','--only=main','1'],cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT)
  (b/(name+'.exit')).write_text(str(r.returncode));rows.append({'label':label,'exit':r.returncode,'ui_sha256':hashlib.sha256(raw).hexdigest()})
  print(name,r.returncode,flush=True)
finally:
 f.write_bytes(current)
 (b/'radio-main-diagnostic-restore.json').write_text(json.dumps({'restored':f.read_bytes()==current,'runs':rows},indent=2)+'\n')
