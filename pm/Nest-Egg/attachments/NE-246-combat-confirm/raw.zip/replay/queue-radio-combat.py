import os,subprocess,json,time,hashlib
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');p=b/'audio'
while not (b/'warden-point-control-restore-v9.json').exists():time.sleep(.5)
assert json.loads((b/'warden-point-control-restore-v9.json').read_text())['restored']
assert hashlib.sha256((p/'game/projectiles/projectile.gd').read_bytes()).hexdigest()=='8018c6058da731a9cfc2165f1e4365ce57264a8c28a7910a66ee3c4857712c50'
name='radio-combat-sequence-v1';save=b/(name+'-save');save.mkdir()
r=subprocess.run(['python',str(b/'native.py'),name,'res://work/radio_combat_sequence.tscn','--save-dir='+str(save)],cwd=p,env=dict(os.environ,NE_NATIVE_PROJECT='audio'))
print('RADIO_COMBAT_NATIVE_EXIT',r.returncode,flush=True)
