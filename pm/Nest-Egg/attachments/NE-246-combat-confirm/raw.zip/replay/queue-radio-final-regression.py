import os,time,json,subprocess,hashlib
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');p=b/'audio'
while not (b/'radio-main-diagnostic-restore.json').exists():time.sleep(.5)
d=json.loads((b/'radio-main-diagnostic-restore.json').read_text());assert d['restored'] and len(d['runs'])==2 and all(x['exit']==0 for x in d['runs']),d
assert (p/'ui/dialogue_layer.gd').read_bytes()==(b/'radio-combat-source/dialogue-after.gd').read_bytes()
for suffix in ['', '.log']:(b/('radio-combat-changed'+suffix)).rename(b/('radio-combat-changed-first'+suffix))
env=dict(os.environ,GODOT=str(b/'godot472/Godot_v4.7.2-stable_linux.x86_64'),LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',LOG_DIR=str(b/'radio-combat-changed'),SHARDS='6')
with (b/'radio-combat-changed.log').open('w') as log:r=subprocess.run(['bash','tools/run_tests_changed.sh','fab8bdf8dcad3fde7ada5b893888264cc3d08690'],cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT)
(b/'radio-combat-changed.exit').write_text(str(r.returncode));print('FINAL_FIXED_BASE_EXIT',r.returncode,flush=True)
