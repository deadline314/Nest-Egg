import os,subprocess,time,json
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b')
while not (b/'warden-point-control-restore-v9.json').exists():time.sleep(.5)
assert json.loads((b/'warden-point-control-restore-v9.json').read_text())['restored']
env=dict(os.environ,GODOT=str(b/'godot472/Godot_v4.7.2-stable_linux.x86_64'),LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',LOG_DIR=str(b/'radio-combat-regression'))
with (b/'radio-combat-regression.log').open('w') as log:
 r=subprocess.run(['bash','tools/run_tests_parallel.sh','--only=RunSaveSuite,UiScreensSuite,StoryContentSuite','3'],cwd=b/'audio',env=env,stdout=log,stderr=subprocess.STDOUT)
(b/'radio-combat-regression.exit').write_text(str(r.returncode))
print('RADIO_REGRESSION_EXIT',r.returncode,flush=True)
