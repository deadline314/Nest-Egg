import csv,hashlib,json,os,re,shutil,subprocess,zipfile
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');p=b/'audio';out=p/'pm/Nest-Egg/attachments/NE-246-combat-confirm'
subprocess.run(['python',str(b/'validate-radio-combat-proof.py')],check=True)
proof=json.loads((b/'radio-combat-independent-validation.json').read_text());out.mkdir()
files={}
for f in list(b.glob('radio-combat-*'))+list(b.glob('radio-main-*')):
 if f.is_file() and f.suffix in ['.log','.exit','.json','.txt']:files['logs/'+f.name]=f
 elif f.is_dir() and not f.name.endswith('-profile'):
  for child in f.rglob('*'):
   if child.is_file():files['raw/'+f.name+'/'+str(child.relative_to(f))]=child
for f in (p/'work').glob('radio_combat_sequence*'):
 if f.suffix in ['.gd','.tscn']:files['replay/'+f.name]=f
for name in ['native.py','queue-radio-combat.py','queue-radio-regression.py','validate-radio-combat-proof.py','prepare-radio-combat-delivery.py','queue-radio-main-diagnostic.py','queue-radio-final-regression.py']:
 files['replay/'+name]=b/name
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=[]
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for arc,f in sorted(files.items()):
  raw=f.read_bytes();z.writestr(arc,raw);manifest.append({'path':arc,'bytes':len(raw),'sha256':sha(raw)})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copyfile(b/'radio-combat-independent-validation.json',out/'validation.json')
source={'base':proof['base'],'runtime_change':'only ui/dialogue_layer.gd, one visibility assignment and its comment','probe_sha256':proof['probe_sha256'],'raw_zip_sha256':sha((out/'raw.zip').read_bytes()),'protected_files':json.loads((b/'radio-combat-source/protected-source.json').read_text()),'original_reference_images':'../NE-278-references/sources.json','full_ci':'new commit workflow checked after push; fixed-base 60-group result below is the local affected scope'}
(out/'source.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
diagnostics=[]
for arc,f in files.items():
 if f.suffix=='.log':
  for n,line in enumerate(f.read_text(errors='replace').splitlines(),1):
   if 'ERROR:' in line or line.startswith('FAIL '):diagnostics.append({'file':arc,'line':n,'text':line})
(out/'diagnostics.json').write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2)+'\n')
images={'NE-246-confirm-before.png':'radio-combat-hint-before-v2/hint-hidden-line-00.png','NE-246-confirm-after.png':'radio-combat-hint-after-v2/hint-visible-line-00.png','NE-246-combat-second.png':'radio-combat-hint-after-v2/pair-line-01.png','NE-246-combat-pause.png':'radio-combat-hint-after-v2/pair-pause-menu.png','NE-246-combat-resumed.png':'radio-combat-hint-after-v2/combat-after-reading.png'}
for name,path in images.items():shutil.copyfile(b/path,p/'pm/Nest-Egg/images'/name)
refs=json.loads((p/'pm/Nest-Egg/attachments/NE-278-references/sources.json').read_text())
(out/'references.json').write_text(json.dumps({'viewed_again':'2026-10-20','images':refs,'technical':'https://docs.godotengine.org/en/stable/classes/class_input.html','player_discussion':'https://steamcommunity.com/app/1809540/discussions/0/596276686578787980/','safe_skip_mod':'https://github.com/Ixrec/NineSolsCutsceneSkip','interpretation':'Discussion contains opposite preferences, not a player consensus; images only substantiate layout, not animation or save behavior. Wiki open failed and is not relied on.'},ensure_ascii=False,indent=2)+'\n')
gallery='\n'.join('![研究圖：%s](../NE-278-references/%s)'%(r['file'],r['file']) for r in refs)
tests=proof['changed_tests'];table='\n'.join('|%s|%d|%d|%s|%s|'%(r['name'],r['checks'],r['expected_failures'],r['visible_prompt_samples'],r['hidden_prompt_samples']) for r in proof['native_runs'])
readme=f'''# NE-246 真戰鬥連續通訊與穩定確認提示

2026-10-20，固定基準 `{proof['base']}`。本批只改重要通訊完整顯字後的確認提示；普通氣泡、劇本、故事結果和保存規則沿用原契約。本機／實體裝置的原待驗條件不代勾，票保持進行中。

## 問題與改後

完整文字已出現，世界正在等待玩家確認，但「繼續」按鍵會閃到完全看不見。改為完整顯字後持續顯示；下一句打字時收起，仍依改鍵與目前裝置產生提示。原本的確認一次一句、保存成功才完成與恢復世界都維持。

![修前：同一正式街道的等待狀態，確認提示因閃爍隱藏](../../images/NE-246-confirm-before.png)
![修後：完整顯字後確認鍵持續可見](../../images/NE-246-confirm-after.png)

修前／後採同一V2探針與正式場景／公開射擊及Enter規則，不冒稱隨機AI和人物位置逐像素相同。修前兩句都在一秒實際渲染觀察窗中出現隱藏幀；修後兩句觀察到的渲染幀全可見。觀察器沒有改UI時鐘或強制提示狀態，也沒有直接補滿文字。

## 真正遊戲邊界

使用真正Main開始新遊戲、進正式第一章街道、正式Player／16個原敵人與實際整輪writer。只安排玩家x=96格與9999生命，保留正式1秒受傷保護；沒有改敵人生命、位置、招式或故事旗標。公開滑鼠、射擊／換彈與真正Enter事件；兩則正式通訊由公開Story.play排入，明示為安排的連續閱讀，不冒充自然觸發整章流程。兩方都有實際傷害，之後同一顆玩家活子彈、16敵人的身份／位置／生命、玩家生命、傷害帳與時鐘在閱讀、開關暫停及兩句之間維持一致。最後確認後原子彈自然繼續飛行或碰撞，兩個完成訊號和真正磁碟觀看紀錄依序成立。

雲端官方Godot4.7.2、軟體Vulkan llvmpipe、原生Forward+／HDR，沒有改Compatibility。這是自動公開輸入與渲染證據，**不是本機硬體、實體手把、真人手感或整章通關驗收**。修前使用正式程式，不是為了製造失敗把提示改壞；原版已在截圖中觀察到缺口後才新增同條件觀察。

|程序|檢查|預期失敗|提示可見取樣|隱藏取樣|
|---|---:|---:|---:|---:|
{table}

三輪原生log均0引擎／腳本ERROR；V1原17項全過，但不含新發現的穩定提示條件，不能用17/0掩蓋圖片上的缺口。V2修前19項只失敗兩個穩定提示條件，修後19/0。[獨立核對](validation.json)保留真正戰鬥、相同世界、台詞／完成順序及渲染取樣，並核對正式程式只差一個提示可見判斷及其註解。

原保存／介面／劇情三組先跑2330/0/68秒。首輪固定基準60組63040項有3個失敗（載具上車、下車、落坑復原），536秒；不當通過，也沒有改原斷言或塞known_failures。這輪與軟體原生算圖重疊；之後原版及修改版各自獨立執行原main均通過，原版／修改版收據在validation，不能據此斷言已證明CPU或時間是根因。保留全部首輪與獨立控制log。第二次完整重跑在02:28後沒有完成輸出與退出碼，02:54檢查時已無程序、原工具session也不可用；中斷原因未證實，不算通過，原件在raw。再次確認正式修改版已還原後，才在沒有原生算圖重疊時，使用同一原選擇器、同基準、同6程序完整重跑受影響範圍。正式修正後使用原選擇器、固定fab8bdf8基準的 `tools/run_tests_changed.sh`：**{tests['groups']}組、{tests['checks']}檢查、0新失敗、0已知失敗、{tests['seconds']}秒**。沒有改原測試、選擇器、錯誤過濾或known_failures。負資料測試原本會刻意push_error，全部原始行保留在[diagnostics](diagnostics.json)，由未修改的正式測試流程判斷；不能把原套件有預期ERROR寫成整份log零ERROR。完整專案CI另由推送觸發，不把局部數字當全套。

![第二則正式通訊與原戰鬥保持](../../images/NE-246-combat-second.png)
![閱讀中開暫停選單，關閉仍等待通訊確認](../../images/NE-246-combat-pause.png)
![最後確認後戰鬥自然繼續](../../images/NE-246-combat-resumed.png)

## 研究圖與採用理由

開始前讀User-guide，重新看五款不同團隊的對話原圖。Katana ZERO採清楚的選項與焦點區；Hollow Knight採正文區和場景分離；Ghost Song採講者、正文與下一步符號可分辨；Blasphemous 2採讀取方向集中的字幕；Ori採高對比正文。單張圖片無法證明它們的提示是否閃爍或世界是否暫停，持續顯示的決策來自本作可重現的問題。

九日討論同時有人希望縮短對話、有人喜歡長敘事；安全略過模組也明確保留會破壞遊戲的必要段落。這些是樣本意見，沒有宣稱玩家普遍偏好，也沒有因此改掉必要的耐久結果。Godot Input文件區別action state與真正input事件，本次UI確認使用parse_input_event。來源、原圖SHA與連結在[references](references.json)；Wiki開啟失敗沒有當作已讀來源。研究圖保留原尺寸，不混作本作驗收。

{gallery}

## 重跑與原始資料

在隔離checkout放raw/replay的V2 gd／tscn到work，以原生Forward+執行 `res://work/radio_combat_sequence_v2.tscn -- --out=<絕對路徑> --save-dir=<全新隔離路徑>`。修前使用source裡的dialogue-before，修後使用dialogue-after；不可改別人main。凍結中擷取與逐格觀察需要實際渲染時間，不以固定影格數猜文字已打完。重播程式含環境絕對路徑，換機時只改成實際路徑。

raw.zip共{len(manifest)}檔，原始圖、報告、save／bak、探針版本、負控制、全部原測試log及研究開啟失敗都保留；[manifest](manifest.json)逐檔bytes／SHA，[source](source.json)記錄ZIP與保護檔SHA。最終程式沒有加入任意故事跳過、背景自動完成或偽造IO成功。
'''
(out/'README.md').write_text(readme)
ticket=p/'pm/Nest-Egg/[NE-246]凍結重要通訊以供完整閱讀.md';s=ticket.read_text();assert '# Commit-5' not in s
s+=f'''\n# Commit-5（完整文字後持續顯示確認鍵）\n\n## 內文\n\n重要通訊已完整顯字、世界正在等玩家時，確認提示會閃到完全看不見。現在確認鍵持續顯示，下一句打字時才收起，仍跟隨改鍵及裝置；一次一句、保存與解凍規則不變。\n\n同一正式Main街道重播先重現兩項提示消失，修後19項全部通過。實際戰鬥後同一活子彈、16個敵人、生命與時計在連續通訊及暫停期間完全相同，兩句依序確認、保存後才回到戰鬥。固定基準原受影響範圍{tests['groups']}組／{tests['checks']}項、0新失敗；三輪原生0引擎／腳本ERROR。雲端公開輸入與軟體Forward+證據不代稱本機／實體手把驗收。\n\n![修前確認提示消失](images/NE-246-confirm-before.png)\n![修後確認提示持續可見](images/NE-246-confirm-after.png)\n\n[完整研究圖、原生對照、世界帳與全部原始紀錄](attachments/NE-246-combat-confirm/README.md)。\n''';ticket.write_text(s)
guide=p/'pm/user_guide.md';s=guide.read_text();s+='\n2026-10-20（NE-246）：文字已完整顯示且遊戲等玩家時，必要確認鍵應持續可見；不能以取到閃爍亮相的單張圖當穩定提示。[真Main戰鬥、連續通訊前後圖與原始紀錄](Nest-Egg/attachments/NE-246-combat-confirm/README.md)保留修前兩項失敗與修後19/0，本機／實體操作條件未代勾。\n';guide.write_text(s)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert set(z.namelist())=={e['path'] for e in manifest}
 for e in manifest:
  raw=z.read(e['path']);assert len(raw)==e['bytes'] and sha(raw)==e['sha256'],e['path']
print('NE246 packet raw SHA verified',len(manifest),(out/'raw.zip').stat().st_size)
