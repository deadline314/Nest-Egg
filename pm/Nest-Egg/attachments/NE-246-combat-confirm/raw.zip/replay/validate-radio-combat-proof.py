import hashlib,json,re,subprocess
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');p=b/'audio';rows=[]
for name,expected_failures in [('radio-combat-sequence-v1',0),('radio-combat-hint-before-v2',2),('radio-combat-hint-after-v2',0)]:
 d=json.loads((b/name/'report.json').read_text());raw=(b/(name+'.log')).read_text()
 assert 'ERROR:' not in raw,name
 assert (b/(name+'.exit')).read_text()==('1' if expected_failures else '0'),name
 failures=[c for c in d['checks'] if not c['passed']]
 assert len(failures)==expected_failures and all('confirm hint visible' in c['message'] for c in failures),(name,failures)
 assert len(d['checks'])==(17 if name.endswith('v1') else 19),name
 first,last=d['frozen_world'];assert first==last and first['bullet_active'] and first['bullet_id']>0,name
 assert len(first['enemies'])==16 and 0<first['player_hp']<9999,name
 assert {x['kind'] for x in d['damage'][:first['damage_count']]}=={'player','enemy'},name
 assert d['shown_lines']==d['expected_lines'] and len(d['shown_lines'])==2,name
 assert d['completion_order']==['ch1_g06_tip_slide','ch1_g06_tip_collector'],name
 visible=hidden=None
 if 'prompt_samples' in d:
  samples=d['prompt_samples'];assert {v['line'] for v in samples}=={0,1},name
  assert all(v['world_clock']==first['clock'] and v['hint'] for v in samples),name
  visible=sum(v['visible'] for v in samples);hidden=len(samples)-visible
  for index in [0,1]:
   line=[v for v in samples if v['line']==index]
   assert len(line)>=2 and max(v['msec'] for v in line)-min(v['msec'] for v in line)>=300,name
   assert all(v['visible'] for v in line) if expected_failures==0 else any(not v['visible'] for v in line),name
 rows.append({'name':name,'checks':len(d['checks']),'expected_failures':len(failures),'native_engine_errors':0,'frozen_enemies':16,'same_active_projectile':True,'initial_real_damage_events':first['damage_count'],'exact_line_order':True,'visible_prompt_samples':visible,'hidden_prompt_samples':hidden})
base='fab8bdf8dcad3fde7ada5b893888264cc3d08690'
before=(b/'radio-combat-source/dialogue-before.gd').read_bytes();after=(p/'ui/dialogue_layer.gd').read_bytes()
assert before==subprocess.check_output(['git','show',base+':ui/dialogue_layer.gd'],cwd=p)
expected=before.replace(b'# \xe9\x87\x8d\xe8\xa6\x81\xe9\x80\x9a\xe8\xa8\x8a\xe8\xae\x80\xe5\xae\x8c\xe4\xb9\x9f\xe4\xb8\x8d\xe8\x87\xaa\xe5\x8b\x95\xe6\xb6\x88\xe5\xa4\xb1\xef\xbc\x9a\xe7\xad\x89\xe7\xa2\xba\xe8\xaa\x8d\xe3\x80\x82',b'# Waiting for input: keep the required control visible, including between blink phases.').replace(b'_radio_continue.visible = Settings.get_reduce_ui_motion() or int(_time * 3.0) % 2 == 0',b'_radio_continue.visible = true')
assert after==expected
protected=json.loads((b/'radio-combat-source/protected-source.json').read_text())
for path,proof in protected.items():
 assert hashlib.sha256((p/path).read_bytes()).hexdigest()==proof['sha256'],path
 if path!='ui/dialogue_layer.gd':assert proof['unchanged'],path
raw=(b/'radio-combat-changed.log').read_text()
assert 'Running 60 groups in 6 processes' in raw
match=re.search(r'checks: (\d+), new failures: 0, known failures .*?: 0\s+\(wall time (\d+) s\)',raw)
assert match,'fixed-base changed tests must finish successfully'
diagnostic=json.loads((b/'radio-main-diagnostic-restore.json').read_text());assert diagnostic['restored'] and all(v['exit']==0 for v in diagnostic['runs'])
quiet=[]
for label in ['baseline','candidate']:
 log=(b/('radio-main-'+label+'-quiet.log')).read_text()
 m=re.search(r'checks: (\d+), new failures: 0, known failures .*?: 0\s+\(wall time (\d+) s\)',log);assert m,label
 quiet.append({'variant':label,'checks':int(m[1]),'failures':0,'seconds':int(m[2])})
first=(b/'radio-combat-changed-first.log').read_text();assert 'checks: 63040, new failures: 3' in first
assert all(text in first for text in ['NEW FAILURE: player mounts vehicle','NEW FAILURE: player dismounts vehicle','NEW FAILURE: pit damages and respawns'])
assert (b/'radio-combat-changed.exit').read_text()=='0'
result={'initial_changed_run':{'checks':63040,'failures':3,'seconds':536,'scope':'initial run overlapped software native rendering; not adopted as passing, root cause not proven'},'isolated_main_controls':quiet,'base':base,'native_runs':rows,'changed_tests':{'groups':60,'checks':int(match[1]),'new_failures':0,'known_failures':0,'seconds':int(match[2])},'scope':'real Main/Level/store with explicitly arranged player position and HP, public shooting and real key events; cloud software Forward+, no physical-device or full-campaign acceptance','runtime_change':'one required radio hint stays visible after its text completes; original tests/selectors/filters unchanged','probe_sha256':hashlib.sha256((p/'work/radio_combat_sequence_v2.gd').read_bytes()).hexdigest()}
(b/'radio-combat-independent-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
