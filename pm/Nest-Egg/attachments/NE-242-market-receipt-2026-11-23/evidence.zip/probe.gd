extends "res://tools/ch2_flow_probe.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const RECEIPT := "collection_paid_receipt"
const STAMP := "collection_receipt_stamp"
const MARK := "collection_receipt_mark"

var _checks := 0
var _marks := 0
var _watched := false
var _before := 0
var _last_marker := false
var _capture_done := false
var _calibrated := false
var _stamp_sounds := 0
var _skip_mode := false
var _skip_requested := false


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://vig-receipt-probe.cfg")
	Story.set_language("en")
	Story.auto_skip = false
	add_child(LightKit.create_environment())
	Sfx.sound_played.connect(_record_sound)
	await _case("pay", 200, ["pay", "confirm"], 1, -40)
	await _case("ask", 200, ["ask"], 0, 20)
	await _case("short funds", 5, ["pay", "confirm", "ask"], 0, 20)
	await _case_skip()
	Sfx.sound_played.disconnect(_record_sound)
	if DisplayServer.get_name() != "headless":
		_check(_capture_done, "rendered the mark appearing on the real receipt")
	if is_instance_valid(_level):
		_level.queue_free()
	await _settle(6)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _failures])
	get_tree().quit(int(_failures != 0))


func _case(label: String, credits: int, choices: Array, marks: int, delta: int) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	_carry_ch1_results()
	GameState.set_flag(&"ch2_gate_checked", true, false)
	Progression.credits = credits
	_before = credits
	_marks = 0
	_stamp_sounds = 0
	await _enter("market")
	_watched = true
	await _talk(&"ch2_vig", choices)
	_watched = false
	_check(_marks == marks, "%s has %d receipt contact events, expected %d" % [label, _marks, marks])
	_check(_stamp_sounds == marks, "%s has %d stamp sound events at the receipt" % [label, _stamp_sounds])
	_check(Progression.credits == credits + delta, "%s has the original wallet change (%d)" % [label, Progression.credits - credits])
	_check(StoryItems.holds(&"ch2_evidence_receipt") and GameState.has_flag(&"ch2_market_contact_done"),
		"%s keeps the original receipt and route completion" % label)
	await _talk(&"ch2_vig")
	_check(Progression.credits == credits + delta, "%s revisiting has no extra charge" % label)


func _case_skip() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	_carry_ch1_results()
	GameState.set_flag(&"ch2_gate_checked", true, false)
	Progression.credits = 200
	_marks = 0
	_stamp_sounds = 0
	await _enter("market")
	_watched = true
	_skip_mode = true
	await _talk(&"ch2_vig", ["pay", "confirm"])
	_skip_mode = false
	_watched = false
	_check(_skip_requested and _marks == 0 and _stamp_sounds == 0 and not get_tree().paused,
		"Escape leaves the paid receipt scene before it plays the contact")
	_check(Progression.credits == 160 and StoryItems.holds(&"ch2_evidence_receipt"),
		"skipping the presentation retains the original accepted transaction and receipt")
	print("SKIP_ROUTE receipt=%s credits=%d contact_complete=%s" % [
		StoryItems.holds(&"ch2_evidence_receipt"), Progression.credits, GameState.has_flag(&"ch2_market_contact_done")])


func _process(_delta: float) -> void:
	var cut := Story._player
	if not _watched or not is_instance_valid(cut) or cut.scene_id != &"ch2_t_s06_invite" or cut._stage == null:
		_last_marker = false
		return
	if _skip_mode and not _skip_requested and cut.steps_run >= 4:
		_skip_requested = true
		_skip_choice.call_deferred()
		return
	if "--capture-before" in OS.get_cmdline_user_args() and not _skip_mode and not _capture_done \
			and int(GameState.get_flag(&"ali_advance_40")) == 40 and cut.steps_run >= 4:
		_capture_done = true
		_capture_contact.call_deferred()
	var mark := cut._stage.prop_node(MARK) as CanvasItem
	if not _calibrated and "--calibrate" in OS.get_cmdline_user_args() and cut._actors.has(&"vig"):
		_calibrated = true
		_calibrate(cut)
	if not is_instance_valid(mark) or not mark.visible:
		_last_marker = false
		return
	if _last_marker:
		return
	_last_marker = true
	_marks += 1
	var paper := cut._stage.prop_node(RECEIPT) as StageLayers._Sprite
	var stamp := cut._stage.prop_node(STAMP) as StageLayers._Sprite
	var actor := cut._actors.get(&"vig") as CutsceneActor
	var contact := stamp.to_global(stamp.source_point(Vector2(23.5, 50.5))).distance_to(
		paper.to_global(paper.source_point(Vector2(48.0, 43.0))))
	var grip := stamp.to_global(stamp.source_point(Vector2(23.5, 12.5))).distance_to(actor.hand_contact_global(&"front"))
	_check(cut._stage.prop_held(STAMP) and contact < 0.1 and grip < 0.1,
		"mark appears while hands hold the stamp on the receipt (base %.4f, grip %.4f)" % [contact, grip])
	_check(Progression.credits == _before - 40 and int(GameState.get_flag(&"ali_advance_40")) == 40,
		"the receipt mark follows the accepted original payment")
	if DisplayServer.get_name() != "headless" and not _capture_done:
		_capture_contact.call_deferred()


func _capture_contact() -> void:
	await RenderingServer.frame_post_draw
	_capture_done = Capture.image(get_viewport()).save_png(_out_dir.path_join("receipt-contact.png")) == OK


func _record_sound(id: StringName) -> void:
	if _watched and id == &"mat_wood" and Story._current_cinematic == &"ch2_t_s06_invite":
		_stamp_sounds += 1


func _skip_choice() -> void:
	var key := InputEventKey.new()
	key.keycode = KEY_ESCAPE
	key.physical_keycode = KEY_ESCAPE
	key.pressed = true
	Input.parse_input_event(key)
	await get_tree().process_frame
	key = key.duplicate()
	key.pressed = false
	Input.parse_input_event(key)


func _calibrate(cut: CutscenePlayer) -> void:
	var actor := cut._actors[&"vig"] as CutsceneActor
	var rig := actor.rig
	var parent := actor.get_parent() as Node2D
	var inverse := rig._skeleton.global_transform.affine_inverse()
	var shoulder := inverse * rig.bone(&"arm_front_upper").global_position
	var contact := rig.hand_source_point(&"front", Vector2(79.5, 37.5))
	var reach := rig.rest(&"arm_front_lower").length() + rig.rest(&"hand_front").length()
	var targets := [Vector2(428.0, 269.7908), Vector2(411.0, 264.1768), Vector2(411.0, 270.1768)]
	print("REACH shoulder=", shoulder, " contact=", contact, " limit=", reach, " actor=", actor.position)
	for shift in [-18, -14, -10, -6, -2, 0]:
		var best := INF
		var best_angle := 0.0
		for step in range(12, 28):
			var angle := float(step) / 10.0
			var local_angle := inverse.basis_xform(parent.global_transform.basis_xform(Vector2.from_angle(angle))).angle()
			var worst := 0.0
			for target: Vector2 in targets:
				var requested := inverse * parent.to_global(target - Vector2(shift, 0))
				worst = maxf(worst, (requested - contact.rotated(local_angle)).distance_to(shoulder))
			if worst < best:
				best = worst
				best_angle = angle
		print("REACH shift=", shift, " angle=", best_angle, " max=", best)


func _check(ok: bool, what: String) -> void:
	_checks += 1
	super._check(ok, what)
