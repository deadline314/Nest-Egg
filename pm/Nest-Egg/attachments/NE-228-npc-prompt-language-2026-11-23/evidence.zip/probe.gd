extends Node

const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://npc-prompts-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	await _exercise("ch1_pawnshop", &"ch1_old_k", "en", "Talk to Old K", false, "ch1-old-k.png")
	await _exercise("ch2_market", &"ch2_vig", "ja", "利息と話す", true, "ch2-vig.png")
	await _exercise("ch3_pump", &"ch3_branch_panel", "en", "Open the pump room panel", false, "ch3-panel.png")
	await AudioRelease.settle(get_tree())
	await _finish()


func _exercise(area: String, id: StringName, language: String, text: String, pad: bool, image_name: String) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	var map := load("res://data/levels/%s.tres" % area) as LevelData
	Story._seen[map.intro_scene] = true
	for scene: String in map.story_triggers:
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(map)
	add_child(level)
	await _frames(215)
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		enemy.set_physics_process(false)

	var actor: NpcActor
	for node: Node in level._entities.get_children():
		if node is NpcActor and (node as NpcActor).data.id == id:
			actor = node
			break
	_check(is_instance_valid(actor) and actor._present, area + " contains the real actor or reading object")
	if not is_instance_valid(actor):
		level.queue_free()
		await _frames(6)
		return

	var player := level.player
	player.global_position = actor.global_position + Vector2(-17, 0)
	player.velocity = Vector2.ZERO
	InputBindings._set_device(false, -1)
	if pad:
		await _joy(JOY_BUTTON_RIGHT_SHOULDER)
	for frame in 125:
		if actor._prompt.is_showing() and actor._prompt._alpha >= 0.8:
			break
		await _frames(1)
	var displayed := actor._prompt._display_text
	var formatted := InputBindings.primary_label(&"interact") + " " + text
	print("PROMPT ", area, " available=", actor.interaction_available(), " alpha=", actor._prompt._alpha, " text=", displayed)
	_check(actor._prompt.is_showing() and actor._prompt._alpha >= 0.8 and displayed == formatted,
			area + " shows its own localized action and active binding")
	_check(actor.interaction_available() and Story.framing.is_interaction_target(actor),
			area + " the prompt points to the actual nearest interactive actor")
	await _picture(image_name)

	var started := []
	var listener := func(scene_id: StringName, _mode: StringName) -> void: started.append(scene_id)
	Story.scene_started.connect(listener)
	Story.auto_skip = false
	if pad:
		await _joy(InputBindings.get_joy_button(&"interact") as JoyButton)
	else:
		await _key(KEY_E)
	await _frames(11)
	print("STARTED ", area, " scenes=", started)
	_check(not started.is_empty(),
			area + " the announced key opens the original dialogue or action")
	Story.scene_started.disconnect(listener)
	Story.reset_active_presentation(&"localized-prompt-probe")
	level.queue_free()
	InputBindings.clear_held_inputs()
	await _frames(8)



func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _tap(event)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	await _tap(event)


func _tap(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish() -> void:
	await _frames(7)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))
