extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		printerr("Expected native rendering and an absolute output path")
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://collector_gunner_street.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Settings.set_brightness(0.5)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	DirAccess.make_dir_recursive_absolute(_out)
	for zoom: float in [LevelCamera.base_zoom(), 3.4]:
		for direction: int in [-1, 1]:
			if not await _observe(direction, zoom):
				printerr("Collector gunner street fixture failed for ", direction, " @ ", zoom)
				get_tree().quit(1)
				return
	var file := FileAccess.open(_out.path_join("street.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"adapter": RenderingServer.get_video_adapter_name(),
		"rendering_method": RenderingServer.get_current_rendering_method(), "hdr_2d": get_viewport().use_hdr_2d,
		"rows": _rows}, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)


func _observe(direction: int, zoom: float) -> bool:
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	var target: Enemy
	for node in level._entities.get_children():
		if node is Enemy:
			if target == null and node.data.id == &"collector_gunner":
				target = node
			else:
				node.process_mode = Node.PROCESS_MODE_DISABLED
	if target == null or target.data.rig_skin != "collector_gunner" or target.rig == null:
		return false
	var start := Vector2(472.0, 832.0)
	target.global_position = start
	level.player.health.setup(999, level.player.tuning.hurt_invulnerability)
	level.player.global_position = start + Vector2(72 * direction, 0)
	level.player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(level.player, true)
	level._lighting._lightning_gap = 1.0e9
	for node in level.find_children("*", "", true, false):
		if node is ChapterCard:
			node.queue_free()
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.offset = Vector2.ZERO
	camera.zoom = Vector2.ONE * zoom
	camera.global_position = start + Vector2(0, -34)
	camera.reset_smoothing()
	camera.force_update_scroll()
	var prefix := "%s_%d" % ["left" if direction < 0 else "right", roundi(100 * zoom)]
	var aimed := false
	for frame in 75:
		await get_tree().process_frame
		if target.fsm.current == &"aim" and target.facing == direction and target.is_on_floor():
			aimed = true
			if not await _capture(target, camera, prefix + "_aim"):
				return false
			break
	if not aimed:
		printerr("Aim test target @ ", start, ", target=", target.global_position, ", player=", level.player.global_position,
			", fsm=", target.fsm.current, ", facing=", target.facing, ", floor=", target.is_on_floor())
		return false
	Input.action_press(&"jump")
	var raised := false
	for frame in 25:
		await get_tree().process_frame
		if target.fsm.current != &"aim":
			break
		if target._rig_aim().y <= -0.53 and not level.player.is_on_floor():
			raised = await _capture(target, camera, prefix + "_aim_up")
			break
	Input.action_release(&"jump")
	if not raised:
		printerr("The authored gunner never aimed up at the real jump: ", prefix, "; aim=", target._rig_aim())
		return false
	var hit := DamageInfo.create(target.health.current, Combat.Team.PLAYER, &"p9",
		Vector2(38.0 * direction, 0))
	if not target.health.take_damage(hit) or not target.is_dying():
		return false
	var start_frame := Engine.get_physics_frames()
	for frame in 43:
		await get_tree().process_frame
		var elapsed := Engine.get_physics_frames() - start_frame
		if elapsed in [2, 8, 14, 22, 29, 36]:
			if not await _capture(target, camera, "%s_death_%02d" % [prefix, elapsed]):
				return false
	if target.facing != direction or not target.rig.visible:
		return false
	level.queue_free()
	await get_tree().process_frame
	return _rows.size() >= 5


func _capture(target: Enemy, camera: LevelCamera, key: String) -> bool:
	await RenderingServer.frame_post_draw
	var result := Capture.image(get_viewport()).save_png(_out.path_join(key + ".png"))
	var neck := camera.get_canvas_transform() * target.rig.bone(&"head").global_position
	_rows.append({"key": key, "zoom": camera.zoom.x, "screen_head": [neck.x, neck.y], "facing": target.facing,
		"aim": [target._rig_aim().x,target._rig_aim().y],
		"world": [target.global_position.x,target.global_position.y],
		"state": str(target.fsm.current), "dying": target.is_dying(), "health": target.health.current,
		"physics_frame": Engine.get_physics_frames(), "screen": [get_viewport().size.x, get_viewport().size.y]})
	return result == OK



