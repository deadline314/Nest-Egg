from pathlib import Path
from PIL import Image
from hashlib import sha256
import json
import numpy as np
root=Path.cwd()
base=Path("D:/NestEggVerification/evidence-20261120-ne218-collector-fall")
last=base/"patch-d"
original=base.parent/"evidence-20261120-ne218-collector-joins/preview-g/frames"
stock=json.loads((original/"report.json").read_bytes())
fixed=json.loads((base/"preview-d/frames/report.json").read_bytes())
assert stock["samples"]==fixed["samples"]==26880
assert sum(row["enclosed_pixels"]>0 for row in stock["failures"])==78
assert all(row["enclosed_pixels"]==row["loose_pieces"]==0 for row in fixed["failures"])
read=lambda x:np.asarray(Image.open(x).convert("RGBA"))
different=lambda a,b:int(np.count_nonzero(np.any(a!=b,axis=2)))
parts=root/"art/characters/collector_gunner/parts"
source=root/"art_src/characters/collector_gunner"
out={}
for kind,ref in (("head",source/"07_refined/head.png"),("torso",source/"overrides/refined/torso.png")):
 old_draw=read(parts/f"{kind}.png")
 new_draw=read(last/f"{kind}.png")
 old_original=read(ref)
 new_original=read(last/f"refined-{kind}.png")
 assert old_draw.shape==new_draw.shape and old_original.shape==new_original.shape
 assert np.array_equal(old_original[old_original[:,:,3]>=128],new_original[old_original[:,:,3]>=128])
 assert np.count_nonzero((old_original[:,:,3]>=128)&(new_original[:,:,3]<128))==0
 out[kind]={ "source_pixels":different(old_original,new_original),"diffuse_pixels":different(old_draw,new_draw),
      "native_normal_pixels":different(read(parts/f"{kind}_n.png"),read(last/f"{kind}_n.png")),
      "source_before_sha256":sha256(ref.read_bytes()).hexdigest(),"pixel_dimensions":list(reversed(old_draw.shape[:2]))}
edges=json.loads((base/"preview-d-edges.json").read_bytes())
assert edges["with_alpha_loss"]==0
out["audit"]={"samples":26880,"enclosed":[78,0],"edge_notches":[450,508],"new_edge_notch_flags":edges["new_edge_notch_flags"]}
(base/"fall-material.json").write_text(json.dumps(out,indent=2)+"\n")
print(out)
