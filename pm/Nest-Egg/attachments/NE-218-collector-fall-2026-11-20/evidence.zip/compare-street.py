from pathlib import Path
import json,math
base=Path("D:/NestEggVerification/evidence-20261120-ne218-collector-fall")
raw=[json.loads((base/file/"street.json").read_bytes()) for file in ("../evidence-20261120-ne218-collector-joins/street-g","street-d")]
assert all(v["hdr_2d"] and v["rendering_method"]=="forward_plus" and "9070 XT" in v["adapter"] for v in raw)
expected={"count":32,"raised_aim":0,"both_rendered_directions":set(),"max_aim_difference":0.0}
paired=list(zip(raw[0]["rows"],raw[1]["rows"],strict=True))
assert len(paired)==expected["count"]
for before,after in paired:
 for key in ("key","facing","state","dying","health","screen","zoom"):
  assert before[key]==after[key],(key,before,after)
 for key in ("world","screen_head","aim"):
  diff=math.dist(before[key],after[key])
  assert diff<0.00001,(key,diff,before,after)
  if key=="aim": expected["max_aim_difference"]=max(diff,expected["max_aim_difference"])
 if before["key"].endswith("aim_up"):
  assert before["aim"][1] <= -.53 and not before["dying"] and before["state"]=="aim"
  expected["raised_aim"]+=1
  expected["both_rendered_directions"].add(before["facing"])
expected["both_rendered_directions"]=sorted(expected["both_rendered_directions"])
assert expected["both_rendered_directions"]==[-1,1] and expected["raised_aim"]==4
(base/"paired-street.json").write_text(json.dumps(expected,indent=2)+"\n")
print(expected)

