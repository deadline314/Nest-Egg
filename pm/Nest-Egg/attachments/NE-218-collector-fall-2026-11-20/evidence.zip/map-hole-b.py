from pathlib import Path
from PIL import Image
from scipy import ndimage
import json
import numpy as np
import sys

project = Path.cwd()
scope = Path(__file__).resolve().parent
sys.path.insert(0, str(project / "tools/comfyui"))
from cut_layers import part_transform, render_part

spec = json.loads((project / "tools/comfyui/specs/collector_gunner_side.json").read_bytes())
scale = spec["tex_px_per_wp"] / spec["illustration_px_per_wp"]
joints = {name: np.array(point, float) * scale for name, point in spec["joints"].items()}
source = {}
for name in ("torso", "head"):
    path = project / f"art_src/characters/collector_gunner/overrides/refined/{name}.png"
    if not path.is_file():
        path = project / f"art_src/characters/collector_gunner/07_refined/{name}.png"
    full = Image.open(path).convert("RGBA")
    raw = np.asarray(Image.open(project / f"art/characters/collector_gunner/parts/{name}.png").convert("RGBA"))
    cut = part_transform(full, spec["parts"][name], joints, scale)
    rendered = render_part(full, cut, scale, crop_phase=spec["parts"][name].get("crop_phase"))
    assert rendered.shape == raw.shape and np.array_equal(rendered, raw), name
    source[name] = full, cut[0]

def coordinates(piece, cell):
    src_transform = np.asarray(piece["to_cell"])
    matrix, offset = src_transform[:, :2], src_transform[:, 2]
    local = np.linalg.solve(matrix, cell - offset)
    if "rect_origin" in piece:
        return local - piece["rect_origin"]
    vertices = np.asarray(piece["vertices"])
    uv = np.asarray(piece["uv"])
    for indices in piece["triangles"]:
        points = vertices[indices]
        bary = np.linalg.solve((points[1:] - points[0]).T, local - points[0])
        if np.min(bary) >= -1e-5 and bary.sum() <= 1.00001:
            return (1 - bary.sum()) * uv[indices[0]] + bary @ uv[indices[1:]]
    return None

all_points = []
def trace_cases():
    for index in (22,27):
        directory=scope/f"trace-b-{index}"/"frames"
        for record in json.loads((directory/"frames.json").read_bytes()):
            if record["pose"] in ("aim_up","dead"):
                yield index,directory,record
for run, frames, record in trace_cases():
    cell = record["cells"][0]
    radius = cell["radius"]
    n = cell["geometry_frame"]
    atlas = Image.open(frames / record["samples"][n]["file"]).convert("RGBA")
    pixels = np.asarray(atlas)[:128, :128, 3]
    cropped = pixels[64 - radius:64 + radius, 64 - radius:64 + radius]
    solid = cropped >= 128
    holes = ndimage.binary_fill_holes(solid, structure=np.ones((3,3))) & ~solid
    for y, x in zip(*np.where(holes)):
        xy = np.array([x, y], dtype=float) + 64 - radius + 0.5
        entries = {}
        for part in cell["geometry_sample"]:
            name = part["part"]
            uv = coordinates(part, xy)
            if uv is None:
                continue
            full, affine = source[name]
            point = (affine[:, :2] @ uv + affine[:, 2]) / scale
            alpha = np.asarray(full.getchannel("A"))
            y0, x0 = (int(min(max(p, 0), axis - 1)) for p, axis in zip(reversed(point), alpha.shape))
            search = alpha[max(0,y0-32):y0+33, max(0,x0-32):x0+33]
            sy, sx = np.where(search >= 128)
            candidates = np.stack((sx + max(0,x0-32), sy + max(0,y0-32)), axis=1)
            near = candidates[np.argmin(np.linalg.norm(candidates - point, axis=1))] if len(candidates) else point
            entries[name] = {"part_pixel": uv.round(2).tolist(), "source_pixel": point.round(2).tolist(),
                             "alpha": int(alpha[y0,x0]), "near": near.tolist(), "distance": round(np.linalg.norm(near-point), 2)}
        all_points.append({"trace": run, "pose": record["pose"], "zoom": record["zoom"], "cell": xy.tolist(), "source": entries})
(scope / "hole-material-b.json").write_text(json.dumps(all_points, indent=2)+"\n")
print(json.dumps(all_points, indent=2))
