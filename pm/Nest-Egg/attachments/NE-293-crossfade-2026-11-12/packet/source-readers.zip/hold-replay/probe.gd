extends "res://tools/melee_sound_probe.gd"
const Audit=preload("res://work/ne293-hold-replay/audit_melee.gd")
var kind := "parse"
var rows: Array[Dictionary]=[]
var passes: Array[Dictionary]=[]
var inputs: Array[Dictionary]=[]
var current: Dictionary={}
var foe_ref: WeakRef
var expected_attack := ""
var expected_mode := ""
var current_pass := 0
var last_pass := 0
var old_module: MeleeModule
var installed := false
var culling_original := true
var installer: Array[Dictionary]=[]
var runtime: Dictionary={}
var recording := false

func require(ok: bool, text: String) -> void:
	if ok:return
	_failures+=1
	push_error("[NE261PublishedHold] " + text)

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out_dir=arg.trim_prefix("--out=")
		elif arg.begins_with("--kind="):kind=arg.trim_prefix("--kind=")
	main.call_deferred()

func module_state(module: MeleeModule) -> Dictionary:
	var result := {"host":module.host.get_instance_id(),"commands_host":module.commands.player.get_instance_id(),"command_deadline":module.commands._deadline_ms,"command_latches":module.commands._held_actions.duplicate(),"set":module.set_in_use.get_instance_id()}
	for key in ["cooldown_left","phase","time","attack","chain","paid_tail","feedback_done","weapon_id","swing_facing","swing_direction","index","landed","hit_ids","buffer_left","combo_left","visual_left","hit_window","_window_sound_done","hold_mode","charged","_sustain_tick"]:result[key]=var_to_str(module.get(key))
	return result

func install_observer() -> void:
	require(player.melee.phase==MeleeModule.Phase.NONE,"install observer only at idle")
	old_module=player.melee
	var before:=module_state(old_module)
	player.remove_child(old_module)
	var observed:=Audit.new(player)
	observed.logger=self
	# Preserve two already-published idle runtime values; never alter clocks,
	# combat indices/phase, targets, attack data or damage for observation.
	observed.weapon_id=old_module.weapon_id
	observed.commands._held_actions=old_module.commands._held_actions.duplicate()
	player.melee=observed
	player.add_child(observed)
	var after:=module_state(observed)
	installer.append({"before":before,"after":after,"equal":before==after,"installed_idle":true,"preserved_idle_fields":["weapon_id","command_latches"]})
	require(before==after,"published parent constructor/necessary initial state preserved")
	installed=true

func uninstall_observer() -> void:
	if not installed:return
	require(player.melee.phase==MeleeModule.Phase.NONE,"uninstall observer only at idle")
	var observed:=player.melee
	player.remove_child(observed)
	player.melee=old_module
	player.add_child(old_module)
	observed.free()
	installer.append({"uninstalled_idle":player.melee.phase==MeleeModule.Phase.NONE})
	installed=false

func attack_name(module: MeleeModule) -> String:
	return str(module.chain[module.index]) if module.index>=0 and module.index<module.chain.size() else ""

func target_state() -> Dictionary:
	var foe:=foe_ref.get_ref() as Enemy if foe_ref!=null else null
	if foe==null:return {}
	return {"id":foe.get_instance_id(),"health":foe.health.current,"position":[foe.global_position.x,foe.global_position.y],"can_process":foe.can_process(),"body_space":PhysicsServer2D.body_get_space(foe.get_rid()).get_id(),"area_space":PhysicsServer2D.area_get_space(foe.hurtbox.get_rid()).get_id(),"material":String(foe.hurtbox.material_id())}

func crossfade_state(value: CrossfadePlayer) -> Dictionary:
	var voices: Array[Dictionary]=[]
	for voice: AudioStreamPlayer in value._players:
		voices.append({"playing":voice.playing,"volume_db":voice.volume_db,"position":voice.get_playback_position(),"stream":voice.stream.resource_path if voice.stream!=null else "","loop":voice.stream.get("loop") if voice.stream!=null and &"loop" in voice.stream else null})
	return {"stream":value.current_stream().resource_path if value.current_stream()!=null else "","target_volume":value.target_volume(),"targets":value._targets.duplicate(),"rates":value._rates.duplicate(),"active":value._active,"voices":voices}

func audio_state() -> Dictionary:
	var hum:=player.find_child("MeleeHum",true,false) as MeleeHum
	var layers: Array[Dictionary]=[]
	for i in Ambience._layers.size():layers.append(crossfade_state(Ambience.layer_player(i)))
	return {"music_cue":String(Music.current_cue()),"music_state":String(Music.current_state()),"music_level":String(Music._level_id),"music_zone":String(Music._zone_id),"music_filter":Music.filter_state(),"music":crossfade_state(Music.player()),"ambience_zone":String(Ambience.current_zone()),"ambience_playing_layers":Ambience.playing_layers(),"ambience":layers,"hum":{"sound":String(hum.sounding()),"gain":hum.gain(),"player_db":hum._player.volume_db,"playing":hum._player.playing,"position":hum._player.get_playback_position()}}

func state(module: MeleeModule) -> Dictionary:
	var hum:=player.find_child("MeleeHum",true,false)
	return {"attack":attack_name(module),"hold_mode":module.hold_mode,"phase":module.phase,"time":module.time,"hit_window":module.hit_window,"sustain_tick":module._sustain_tick,"charged":module.charged,"landed":module.landed,"window_sound_done":module._window_sound_done,"hit_ids":module.hit_ids.keys(),"input_pressed":Input.is_action_pressed(&"shoot"),"physics_frame":Engine.get_physics_frames(),"process_frame":Engine.get_process_frames(),"target":target_state(),"hum":String(hum.call(&"sounding")) if hum!=null else ""}

func sample_mark() -> Dictionary:
	return _clock.mark() if recording else {}

func begin_row(weapon: String, part: String) -> void:
	close_row()
	current={"weapon":weapon,"part":part,"start_frames":sample_mark(),"start_state":state(player.melee),"damage":[],"sounds":[],"confirmed":[],"hold_starts":[],"input_indices":[],"pass_ids":[]}
	current["audio_start"]=audio_state()
	rows.append(current)

func close_row() -> void:
	if current.is_empty():return
	current["end_frames"]=sample_mark()
	current["end_state"]=state(player.melee)
	current["audio_end"]=audio_state()
	current={}

func hold_started(module: MeleeModule) -> void:
	if current.get("part","").begins_with("entry_"):
		var weapon: String=current["weapon"]
		var part: String=String(current["part"]).trim_prefix("entry_")
		begin_row(weapon,"hold_"+part)
	if not current.is_empty():current["hold_starts"].append(state(module))

func pass_before(module: MeleeModule) -> int:
	var id:=passes.size()+1
	current_pass=id
	last_pass=id
	passes.append({"id":id,"row":rows.size()-1,"before":state(module),"sounds":[],"damage":[],"confirmed":[]})
	if not current.is_empty():current["pass_ids"].append(id)
	return id

func pass_after(id: int, module: MeleeModule) -> void:
	passes[id-1]["after"]=state(module)
	current_pass=0

func event_window() -> int:
	if current_pass>0:return current_pass
	if last_pass>0 and passes[last_pass-1]["row"]==rows.size()-1 and passes[last_pass-1]["before"]["physics_frame"]==Engine.get_physics_frames():return last_pass
	return 0

func damaged(info: DamageInfo) -> void:
	if current.is_empty():return
	var event:={"source":String(info.source_id),"amount":info.amount,"weak":info.weak_hit,"state":state(player.melee),"window":current_pass}
	current["damage"].append(event)
	if current_pass>0:passes[current_pass-1]["damage"].append(event)

func heard(id: StringName) -> void:
	if current.is_empty():return
	var window:=event_window()
	var event:={"id":String(id),"state":state(player.melee),"window":window}
	current["sounds"].append(event)
	if window>0:passes[window-1]["sounds"].append(event)

func confirmed(point: Vector2, killed: bool) -> void:
	if current.is_empty():return
	var event:={"point":[point.x,point.y],"killed":killed,"window":current_pass,"physics_frame":Engine.get_physics_frames()}
	current["confirmed"].append(event)
	if current_pass>0:passes[current_pass-1]["confirmed"].append(event)

func input(pressed: bool) -> void:
	if pressed:Input.action_press(&"shoot")
	else:Input.action_release(&"shoot")
	inputs.append({"pressed":pressed,"actual":Input.is_action_pressed(&"shoot"),"state":state(player.melee),"frames":sample_mark()})
	if not current.is_empty():current["input_indices"].append(inputs.size()-1)
	require(Input.is_action_pressed(&"shoot")==pressed,"actual public input state")

func target(weapon: WeaponData) -> void:
	var foe:=_target(weapon)
	foe_ref=weakref(foe)
	foe.health.damaged.connect(damaged)

func wait_hold(weapon: String, with_target: bool, instrumented: bool) -> void:
	var data:=load("res://data/weapons/melee/melee_%s.tres" % weapon) as WeaponData
	await clear_enemies();foe_ref=null
	await _arm(data)
	player.guard=player.guard_max() # Same full-guard fixture precondition as original combo probe.
	if with_target:target(data);await settle(20)
	var spec:=MeleeData.set_of(data).hold()
	expected_attack=str(spec["attack"]);expected_mode=str(spec["mode"])
	begin_row(weapon,"entry_hit" if with_target else "entry_miss")
	input(true)
	var deadline:=Time.get_ticks_usec()+12000000
	while player.melee.hold_mode!=expected_mode or attack_name(player.melee)!=expected_attack:
		if Time.get_ticks_usec()>=deadline:require(false,"public input never entered published hold "+weapon);input(false);return
		await get_tree().process_frame
	if not instrumented:hold_started(player.melee)
	while Time.get_ticks_usec()<deadline:
		var ready:=false
		if expected_mode=="charge":ready=player.melee.phase==MeleeModule.Phase.ACTIVE
		elif expected_mode=="sustain":ready=player.melee.phase==MeleeModule.Phase.RECOVERY
		else:
			ready=current["hold_starts"].size()>=3 and player.melee.hit_window>=MeleeMove.hits(player.melee.attack).size()-1 and player.melee.phase==MeleeModule.Phase.ACTIVE
		if ready:break
		await get_tree().process_frame
	require(Time.get_ticks_usec()<deadline,"published hold release readiness timed out "+weapon)
	input(false)
	deadline=Time.get_ticks_usec()+5000000
	while player.melee.phase!=MeleeModule.Phase.NONE and Time.get_ticks_usec()<deadline:await get_tree().process_frame
	require(player.melee.phase==MeleeModule.Phase.NONE,"natural recovery after release "+weapon)
	await _seconds(.5)
	close_row()

func main() -> void:
	runtime={"display":DisplayServer.get_name(),"audio_driver":AudioServer.get_driver_name(),"adapter":RenderingServer.get_video_adapter_name(),"rendering_device_null":RenderingServer.get_rendering_device()==null}
	print("NE261_HOLD_RUNTIME "+JSON.stringify(runtime))
	require(runtime["display"]=="headless" and runtime["audio_driver"]=="WASAPI" and runtime["adapter"]=="" and runtime["rendering_device_null"],"audio-only headless/WASAPI preflight")
	if _failures>0:get_tree().quit(1);return
	if kind=="parse":get_tree().quit(0 if _failures==0 else 1);return
	var mkdir:=DirAccess.make_dir_recursive_absolute(out_dir)
	require(mkdir==OK and DirAccess.dir_exists_absolute(out_dir),"output directory "+out_dir)
	culling_original=Enemy.activation_culling_enabled;Enemy.activation_culling_enabled=false
	Story.auto_skip=true
	await open_arena("",12.0)
	AimInput.using_gamepad=true;AimInput._last_stick_dir=Vector2.RIGHT
	Sfx.sound_played.connect(heard);EventBus.hit_confirmed.connect(confirmed)
	var instrumented:=kind!="equivalence-original"
	if instrumented:install_observer()
	if _failures>0:
		if installed:uninstall_observer()
		Enemy.activation_culling_enabled=culling_original
		await finish();get_tree().quit(1);return
	if kind.begins_with("equivalence"):
		await wait_hold("blade",true,instrumented)
	else:
		_clock=preload("res://tools/audio/melee_pcm_clock.gd").new();add_child(_clock)
		require(_clock.attach(),"canonical PCM clock attach")
		var pistol:=load("res://data/weapons/pistol.tres") as WeaponData
		await _arm(pistol);await settle(30)
		require(await _clock.start(),"canonical PCM clock real audio readiness");recording=true
		begin_row("ref","silence");await _seconds(1.0)
		begin_row("ref","pistol")
		for shot in 3:input(true);await settle(3);input(false);await _seconds(.45)
		close_row();target(pistol);await settle(20)
		begin_row("ref","pistol_hit")
		for shot in 3:input(true);await settle(3);input(false);await _seconds(.45)
		close_row();await clear_enemies();foe_ref=null
		begin_row("ref","walk");Input.action_press(&"move_right");await _seconds(1.2);Input.action_release(&"move_right");await _seconds(.4);close_row()
		for weapon: String in WEAPONS:
			var data:=load("res://data/weapons/melee/melee_%s.tres" % weapon) as WeaponData
			await _arm(data)
			begin_row(weapon,"idle");await _seconds(1.6);close_row()
			await wait_hold(weapon,false,true)
			await wait_hold(weapon,true,true)
			begin_row(weapon,"holster");await clear_enemies();foe_ref=null;await _arm(pistol);await _seconds(.6);close_row()
			if _failures>0:break
	if installed:uninstall_observer()
	if recording:
		var end: Dictionary=_clock.stop();recording=false
		var pcm: Dictionary=await _clock.save(out_dir,end);pcm["cleanup"]=_clock.cleanup();_failures+=_clock.problems.size()
		var starts:={"Master":0,"SFX":0,"Music":0,"Ambience":0}
		var file:=FileAccess.open(out_dir.path_join("hold-index.json"),FileAccess.WRITE)
		file.store_string(JSON.stringify({"schema":"ne261-published-five-holds-v1","runtime":runtime,"sample_clock":pcm,"segments":[{"weapon":"capture","part":"whole_recording","bus_start_frames":starts,"bus_end_frames":end["frames"]}],"hold_segments":rows,"passes":passes,"inputs":inputs,"installer":installer,"failures":_failures,"scope":"Published4a2f9ecf+only2NE293, RAM observation-only derived MeleeModule; actual public hold/release, original target/damage/data, not C26 or original24 labels."},"  "));file.close()
	else:
		var file:=FileAccess.open(out_dir.path_join("equivalence.json"),FileAccess.WRITE)
		file.store_string(JSON.stringify({"kind":kind,"runtime":runtime,"rows":rows,"passes":passes,"inputs":inputs,"installer":installer,"failures":_failures},"  "));file.close()
	Input.action_release(&"shoot");Input.action_release(&"move_right")
	Enemy.activation_culling_enabled=culling_original
	await finish()
	print("NE261_HOLD_DONE failures=%d" % _failures)
	get_tree().quit(0 if _failures==0 else 1)
