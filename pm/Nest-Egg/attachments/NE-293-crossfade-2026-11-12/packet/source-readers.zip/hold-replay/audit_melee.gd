extends "res://game/melee/melee_module.gd"
## Instrumented published parent only. No state/data/query edits.
var logger

func _init(p_host: Player = null) -> void:
	super(p_host)

func start_hold() -> bool:
	var accepted: bool=super.start_hold()
	if accepted and is_instance_valid(logger):logger.hold_started(self)
	return accepted

func hit_pass() -> void:
	var token: int=logger.pass_before(self) if is_instance_valid(logger) else 0
	super.hit_pass() # Exactly once; published parent has a void return contract.
	if is_instance_valid(logger):logger.pass_after(token,self)
