import hashlib,importlib.util,json,os,pathlib,re,shutil,subprocess,time,zipfile
HERE=pathlib.Path(__file__).resolve().parent
PARENT=HERE.parent
WT=pathlib.Path('D:/NestEggVerification/ne293-crossfade-20261112')
BASE='4a2f9ecfaf3d98db102e79b37420821f714549ca'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
def main():
    assert subprocess.run(['git','rev-parse','HEAD'],cwd=WT,capture_output=True,check=True).stdout.decode().strip()==BASE
    official=sorted(PARENT.glob('published-default-official-*'))[-1]
    result=json.loads((official/'exit.json').read_text(encoding='utf8'));assert result['exit_code']==0 and result['source_unchanged'],'do not continue after actual affected RED without reporting'
    frozen=json.loads((official/'source-after.json').read_text(encoding='utf8'))
    assert all(sha(WT/n)==digest for n,digest in frozen.items())
    delta=subprocess.run(['git','diff','--name-only'],cwd=WT,capture_output=True,check=True).stdout.decode().splitlines();assert sorted(delta)==['core/audio/crossfade_player.gd','tests/suite/test_audio.gd']
    leaf=WT/'work/ne293-hold-replay';leaf.mkdir(exist_ok=True)
    own={}
    for n in ('probe.gd','audit_melee.gd','probe.tscn'):shutil.copyfile(HERE/n,leaf/n);own[n]=sha(leaf/n)
    out=HERE/'runs'/str(time.time_ns());out.mkdir(parents=True)
    with zipfile.ZipFile(out/'executed-leaf.zip','w',zipfile.ZIP_DEFLATED) as z:
        for n in own:z.write(HERE/n,n)
        z.write(pathlib.Path(__file__),'run.py')
    selected=['game/melee/melee_module.gd','game/player/melee_command_input.gd','data/feel/sound_events.json','data/feel/materials.json','core/audio/crossfade_player.gd','data/audio/music.json','data/audio/ambience.json']+['data/melee/'+n+'.json' for n in ('thermal_blade','mono_dagger','ion_glaive','hydraulic_maul','mono_whip')]
    for n in selected:
        p=out/'published-inputs'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WT/n,p)
    env=os.environ.copy();env['APPDATA']=str(out/'appdata');env['LOCALAPPDATA']=str(out/'localappdata')
    command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(WT),'--display-driver','headless','--audio-driver','WASAPI','res://work/ne293-hold-replay/probe.tscn','--','--out='+str(out/'recording'),'--kind=holds']
    save(out/'command.json',{'argv':command,'cwd':str(WT),'base':BASE,'source_before':frozen,'leaf_before':own,'scope':'Published4a2f9ecf+onlyNE293twofilecandidate. Original34row logic/Input/targets/time/volumes/thresholds unchanged from two retained NE261 RED runs; only deployment URL and explicit scope label differ. RAM observer unchanged.'})
    start=time.monotonic()
    with (out/'engine.log').open('wb') as f:r=subprocess.run(command,cwd=WT,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
    text=(out/'engine.log').read_text(encoding='utf8',errors='replace');after={n:sha(WT/n) for n in frozen};own_after={n:sha(leaf/n) for n in own}
    diagnostics=[l for l in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|WARNING:|Parse Error',l)]
    runtime=[json.loads(l.split(' ',1)[1]) for l in text.splitlines() if l.startswith('NE261_HOLD_RUNTIME ')]
    expected={'adapter':'','audio_driver':'WASAPI','display':'headless','rendering_device_null':True}
    receipt={'exit_code':r.returncode,'seconds':time.monotonic()-start,'source_unchanged':frozen==after and own==own_after,'source_after':after,'leaf_after':own_after,'diagnostic_lines':diagnostics,'runtime_ok':runtime==[expected],'runtime':runtime,'gpu_log_rejected':bool(re.search(r'Vulkan.*(?:API|Device)|Using Device|OpenGL.*Renderer',text,re.I)),'scope':'Actual audio-only hold replay; not human hearing/GPU/performance/physical controller.'}
    save(out/'exit.json',receipt);save(out/'recording/exit.json',receipt);print(out);print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_after','leaf_after')},indent=2))
    return 0 if r.returncode==0 and receipt['source_unchanged'] and receipt['runtime_ok'] and not diagnostics and not receipt['gpu_log_rejected'] else 1
if __name__=='__main__':raise SystemExit(main())
