import argparse,hashlib,json,os,pathlib,re,shutil,subprocess,time
HERE=pathlib.Path(__file__).resolve().parent
WT=pathlib.Path('D:/NestEggVerification/ne293-crossfade-20261112')
BASE='cb2f08740ee5513559b60a4f98e51662c53c3977'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
def snapshot():
    names=subprocess.run(['git','ls-files','core','game','autoload','data'],cwd=WT,capture_output=True,check=True).stdout.decode('utf8').splitlines()
    return {n:sha(WT/n) for n in names if (WT/n).is_file()}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--variant',choices=['baseline','candidate'],required=True);ap.add_argument('--kind',choices=['state','pcm'],required=True);a=ap.parse_args()
    assert subprocess.run(['git','rev-parse','HEAD'],cwd=WT,capture_output=True,check=True).stdout.decode().strip()==BASE
    leaf=WT/'work/ne293-proof';leaf.mkdir(parents=True,exist_ok=True)
    (WT/'work/.gdignore').touch(exist_ok=True)
    for n in ('probe.gd','probe.tscn'):shutil.copyfile(HERE/n,leaf/n)
    shutil.copyfile(HERE/(a.variant+'-crossfade_player.gd'),WT/'core/audio/crossfade_player.gd')
    out=HERE/'runs'/(str(time.time_ns())+'-'+a.variant+'-'+a.kind);out.mkdir(parents=True)
    before=snapshot();own={n:sha(leaf/n) for n in ('probe.gd','probe.tscn')}
    for n in own:shutil.copyfile(leaf/n,out/n)
    shutil.copyfile(WT/'core/audio/crossfade_player.gd',out/'executed-crossfade_player.gd')
    cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(WT),'--display-driver','headless','--audio-driver','WASAPI','res://work/ne293-proof/probe.tscn','--','--out='+str(out),'--kind='+a.kind]
    save(out/'command.json',{'argv':cmd,'base':BASE,'variant':a.variant,'kind':a.kind,'source_before':before,'leaf_before':own})
    env=os.environ.copy();env['APPDATA']=str(out/'appdata');env['LOCALAPPDATA']=str(out/'localappdata');t=time.monotonic()
    with (out/'engine.log').open('wb') as log:r=subprocess.run(cmd,cwd=WT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=35)
    log=(out/'engine.log').read_text(encoding='utf8',errors='replace');after=snapshot()
    diagnostics=[l for l in log.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|WARNING:',l)]
    gpu=bool(re.search(r'Vulkan.*(?:API|Device)|Using Device|OpenGL.*Renderer',log,re.I))
    result={'exit_code':r.returncode,'seconds':time.monotonic()-t,'diagnostic_lines':diagnostics,'gpu_log_rejected':gpu,'source_unchanged':before==after and own=={n:sha(leaf/n) for n in own},'source_after':after}
    save(out/'exit.json',result);print(out);print(log);print(json.dumps({k:v for k,v in result.items() if k!='source_after'},indent=2))
    return r.returncode if not diagnostics and not gpu and result['source_unchanged'] else 2
if __name__=='__main__':raise SystemExit(main())
