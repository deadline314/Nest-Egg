import hashlib,json,os,pathlib,re,shutil,subprocess,time
HERE=pathlib.Path(__file__).resolve().parent;WT=pathlib.Path('D:/NestEggVerification/ne293-crossfade-20261112')
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,j):p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf8',newline='\n')
frozen=json.loads((HERE.parent/'published-default-official-1794475000448228800/source-after.json').read_text(encoding='utf8'))
assert all(sha(WT/n)==v for n,v in frozen.items())
leaf=WT/'work/ne293-unequal';leaf.mkdir(exist_ok=True)
own={}
for name in ('baseline_crossfade.gd','candidate_crossfade.gd','probe.gd','probe.tscn'):
    shutil.copyfile(HERE/name,leaf/name);own[name]=sha(leaf/name)
for variant in ('baseline','candidate'):
    out=HERE/'runs'/(str(time.time_ns())+'-'+variant);out.mkdir(parents=True)
    for n in own:shutil.copyfile(HERE/n,out/n)
    cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(WT),'--display-driver','headless','--audio-driver','WASAPI','res://work/ne293-unequal/probe.tscn','--','--out='+str(out),'--variant='+variant]
    save(out/'command.json',{'argv':cmd,'base':'4a2f9ecfaf3d98db102e79b37420821f714549ca','source_before':frozen,'leaf_before':own})
    env=os.environ.copy();env['APPDATA']=str(out/'appdata');env['LOCALAPPDATA']=str(out/'localappdata')
    with (out/'engine.log').open('wb') as f:r=subprocess.run(cmd,cwd=WT,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30)
    text=(out/'engine.log').read_text(encoding='utf8',errors='replace');diagnostics=[s for s in text.splitlines() if re.search('SCRIPT ERROR|^ERROR:|WARNING:',s)]
    after={n:sha(WT/n) for n in frozen};receipt={'exit_code':r.returncode,'diagnostic_lines':diagnostics,'source_unchanged':frozen==after and own=={n:sha(leaf/n) for n in own},'source_after':after,'gpu_log_rejected':bool(re.search('Vulkan.*(?:API|Device)|Using Device|OpenGL.*Renderer',text,re.I))}
    save(out/'exit.json',receipt);print(out);print(text)
    assert r.returncode==0 and not diagnostics and receipt['source_unchanged'] and not receipt['gpu_log_rejected']
