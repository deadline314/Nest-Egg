extends Node
var out := ""
var variant := ""
var fader: Node
var capture: AudioEffectCapture
var bus := -1
var pcm := PackedVector2Array()
var elapsed := 0.0
var tracking := false
var ledger: Array[Dictionary]=[]

func _ready() -> void:
	process_mode=Node.PROCESS_MODE_ALWAYS;process_priority=1000
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
		if arg.begins_with("--variant="):variant=arg.trim_prefix("--variant=")
	main.call_deferred()

func tone() -> AudioStreamWAV:
	var sound:=AudioStreamWAV.new();sound.mix_rate=48000;sound.stereo=true;sound.format=AudioStreamWAV.FORMAT_16_BITS
	var bytes:=PackedByteArray();bytes.resize(384000)
	for i in 192000:bytes.encode_s16(i*2,3276)
	sound.data=bytes;return sound

func _process(delta: float) -> void:
	if tracking:
		elapsed+=delta
		var voices: Array=fader.get("_players")
		ledger.append({"delta":delta,"elapsed":elapsed,"sample":capture.get_pushed_frames(),"old_linear":voices[0].volume_linear,"new_linear":voices[1].volume_linear,"old_db":voices[0].volume_db,"new_db":voices[1].volume_db,"old_playing":voices[0].playing,"new_playing":voices[1].playing})
	if capture!=null:
		var n:=capture.get_frames_available()
		if n>0:pcm.append_array(capture.get_buffer(n))

func wait(seconds: float) -> void:
	var end:=Time.get_ticks_usec()+int(seconds*1000000.0)
	while Time.get_ticks_usec()<end:await get_tree().process_frame

func main() -> void:
	var runtime:={"display":DisplayServer.get_name(),"audio":AudioServer.get_driver_name(),"adapter":RenderingServer.get_video_adapter_name(),"rendering_device_null":RenderingServer.get_rendering_device()==null}
	print("NE293_UNEQUAL_RUNTIME "+JSON.stringify(runtime))
	if runtime["display"]!="headless" or runtime["audio"]!="WASAPI" or runtime["adapter"]!="" or not runtime["rendering_device_null"]:get_tree().quit(1);return
	DirAccess.make_dir_recursive_absolute(out)
	AudioServer.add_bus();bus=AudioServer.bus_count-1;AudioServer.set_bus_name(bus,&"NE293Unequal")
	capture=AudioEffectCapture.new();capture.buffer_length=5.0;AudioServer.add_bus_effect(bus,capture)
	AudioServer.set_bus_mute(AudioServer.get_bus_index(&"Master"),true)
	var script:=load("res://work/ne293-unequal/"+variant+"_crossfade.gd") as Script
	fader=script.new(&"NE293Unequal");add_child(fader)
	fader.call(&"play",tone(),0.0,0.0,0.0,false);await wait(.35)
	var start:=capture.get_pushed_frames()
	fader.call(&"play",tone(),-6.0,0.8,0.4,false);tracking=true
	await wait(1.0);tracking=false
	var finish:=capture.get_pushed_frames();await wait(.2)
	AudioServer.lock()
	var pushed:=capture.get_pushed_frames();var discarded:=capture.get_discarded_frames();var available:=capture.get_frames_available()
	if available>0:pcm.append_array(capture.get_buffer(available))
	AudioServer.set_bus_effect_enabled(bus,0,false);AudioServer.unlock()
	var file:=FileAccess.open(out.path_join("actual.f32"),FileAccess.WRITE);file.store_buffer(pcm.to_byte_array());file.close()
	file=FileAccess.open(out.path_join("result.json"),FileAccess.WRITE);file.store_string(JSON.stringify({"runtime":runtime,"variant":variant,"start":start,"finish":finish,"mix_rate":AudioServer.get_mix_rate(),"frames":pcm.size(),"pushed":pushed,"discarded":discarded,"out_duration":0.4,"in_duration":0.8,"old_target_db":0.0,"new_target_db":-6.0,"ledger":ledger,"scope":"Actual fixed PCM unequal target/duration. Only global class_name removed in isolated copies; product untouched."},"  "));file.close()
	fader.free();AudioServer.remove_bus(bus);capture=null
	await AudioRelease.settle(get_tree());get_tree().quit(0 if discarded==0 and pushed==pcm.size() else 1)
