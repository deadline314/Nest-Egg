"""Unequal-duration/volume actual PCM and state, not an equal-level flat gate."""
import hashlib,json,pathlib
import numpy as np
HERE=pathlib.Path(__file__).resolve().parent
NAMES=('1794476804078500200-baseline','1794476813175979400-candidate')
results=[]
for name in NAMES:
    p=HERE/'runs'/name;j=json.loads((p/'result.json').read_text(encoding='utf8'));r=json.loads((p/'exit.json').read_text(encoding='utf8'));c=json.loads((p/'command.json').read_text(encoding='utf8'))
    assert r['exit_code']==0 and not r['diagnostic_lines'] and not r['gpu_log_rejected'] and r['source_unchanged'] and r['source_after']==c['source_before']
    assert all(hashlib.sha256((p/n).read_bytes()).hexdigest()==digest for n,digest in c['leaf_before'].items())
    assert j['runtime']=={'adapter':'','audio':'WASAPI','display':'headless','rendering_device_null':True}
    assert (j['out_duration'],j['in_duration'],j['old_target_db'],j['new_target_db'])==(.4,.8,0,-6)
    original=HERE.parent/('baseline-crossfade_player.gd' if j['variant']=='baseline' else 'candidate-crossfade_player.gd')
    actual=(p/(j['variant']+'_crossfade.gd')).read_text(encoding='utf8')
    assert actual.split('\n',1)[1]==original.read_text(encoding='utf8').split('\n',1)[1],'isolated body differs beyond omitted global class declaration'
    ledger=j['ledger'];t=np.array([v['elapsed'] for v in ledger]);d=np.array([v['delta'] for v in ledger]);assert np.allclose(t,np.cumsum(d),rtol=0,atol=1e-10)
    maxstep=float(max(d));old=np.array([v['old_linear'] for v in ledger]);new=np.array([v['new_linear'] for v in ledger]);target=10**(-6/20)
    assert np.max(np.abs(old-(np.maximum(.001,1-.999*t/.4) if j['variant']=='candidate' else 10**(-60*np.minimum(t/.4,1)/20))))<2e-5
    assert np.max(np.abs(new-(np.minimum(target,.001+(target-.001)*t/.8) if j['variant']=='candidate' else 10**((-60+54*np.minimum(t/.8,1))/20))))<2e-5
    stopped=next(v for v in ledger if not v['old_playing']);reached=next(v for v in ledger if abs(v['new_db']+6)<.0001)
    assert .4-maxstep<=stopped['elapsed']<=.4+maxstep and .8-maxstep<=reached['elapsed']<=.8+maxstep,'original per-voice durations not preserved'
    x=np.fromfile(p/'actual.f32',dtype='<f4').reshape(-1,2).mean(axis=1);assert np.isfinite(x).all() and len(x)==j['frames']==j['pushed'] and j['discarded']==0
    rate=j['mix_rate'];b=j['start'];assert rate==48000 and b>int(.2*rate)
    rms=lambda a:float(np.sqrt(np.mean(np.square(a,dtype=np.float64))))
    steady=rms(x[b-int(.2*rate):b-int(.05*rate)]);assert steady>0
    # Bound actual mix/property publication latency by the observed capture
    # quantum plus one measured process step, scaled by maximum gain slope.
    quantum=max(np.diff(sorted(set(v['sample'] for v in ledger))))/rate
    bound=(.999/.4+(target-.001)/.8)*(quantum+maxstep)+2e-5
    samples=[]
    for center in (.2,.4,.6,.8,.9):
        start=b+int((center-.025)*rate);end=b+int((center+.025)*rate);assert 0<=start<end<=len(x)
        time=(np.arange(start,end)-b)/rate
        outgoing=np.maximum(.001,1-.999*time/.4);outgoing[time>=.4]=0
        incoming=np.minimum(target,.001+(target-.001)*time/.8)
        expected=rms(outgoing+incoming);actual=rms(x[start:end])/steady
        samples.append({'center_seconds':center,'actual_rms_relative_to_initial':actual,'correct_amplitude_curve_rms':expected,'absolute_error':abs(actual-expected)})
    follows=max(v['absolute_error'] for v in samples)<=bound
    assert follows==(j['variant']=='candidate'),'actual unequal PCM did not separate old trough from correct amplitude curve'
    results.append({'run':name,'variant':j['variant'],'frames':len(x),'no_discard':True,'original_out0_4s_in0_8s_and_endpoints_verified':True,'old_stopped_at_delta_sum':stopped['elapsed'],'new_reached_minus6db_at_delta_sum':reached['elapsed'],'max_process_step':maxstep,'capture_quantum_seconds':float(quantum),'pcm_publication_error_bound':float(bound),'actual_pcm_matches_correct_amplitude_curve':bool(follows),'samples':samples})
assert results[0]['variant']=='baseline' and results[1]['variant']=='candidate'
result={'accepted':True,'results':results,'scope':'Actual unequal-target/duration audio capture plus per-process delta/state. Different durations naturally allow a trough; no equal-level flat gate or arbitrary musical constant-energy claim.'}
(HERE/'verified.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(result,indent=2))
