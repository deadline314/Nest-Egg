"""Read-only actual Capture PCM comparison, no engine or audio synthesis."""
import hashlib,json,pathlib
import numpy as np
HERE=pathlib.Path(__file__).resolve().parent
NAMES=('1794473459581321500-baseline-pcm','1794473474700396200-candidate-pcm')
def read(name):
    p=HERE/'runs'/name;receipt=json.loads((p/'exit.json').read_text(encoding='utf8'));cmd=json.loads((p/'command.json').read_text(encoding='utf8'));j=json.loads((p/'result.json').read_text(encoding='utf8'));d=j['data']
    assert receipt['exit_code']==0 and receipt['diagnostic_lines']==[] and not receipt['gpu_log_rejected'] and receipt['source_unchanged'] and receipt['source_after']==cmd['source_before']
    assert j['runtime']=={'adapter':'','audio':'WASAPI','display':'headless','rendering_device_null':True} and j['failures']==0
    assert hashlib.sha256((p/'executed-crossfade_player.gd').read_bytes()).hexdigest()==cmd['source_before']['core/audio/crossfade_player.gd']
    assert all(hashlib.sha256((p/n).read_bytes()).hexdigest()==digest for n,digest in cmd['leaf_before'].items())
    data=(p/'actual.f32').read_bytes();assert len(data)==d['pushed']*8==d['frames']*8 and d['discarded']==0 and d['float_format']=='stereo_f32le'
    x=np.frombuffer(data,dtype='<f4').reshape(-1,2).mean(axis=1);assert np.isfinite(x).all()
    rate=d['mix_rate'];begin=d['begin'];end=d['end'];assert rate==48000 and 0<int(.2*rate)<begin<end<len(x)-int(.2*rate)
    rms=lambda a:float(np.sqrt(np.mean(np.square(a,dtype=np.float64))))
    steady=rms(x[begin-int(.2*rate):begin-int(.05*rate)])
    middle=x[begin+int(.30*rate):begin+int(.70*rate)];step=int(rate*.05)
    windows=[rms(middle[i:i+step]) for i in range(0,len(middle)-step+1,step)]
    assert steady>0 and windows and min(windows)>0
    changes=[float(20*np.log10(v/steady)) for v in windows]
    return {'run':name,'frames':len(x),'start_sample':begin,'end_sample':end,'steady_rms':steady,'midpoint_min_rms':min(windows),'middle_50ms_db_relative_to_same_input':changes,'algorithm_flat_within_quarter_db':max(abs(v) for v in changes)<=.25},cmd
old,oc=read(NAMES[0]);new,nc=read(NAMES[1])
assert oc['leaf_before']==nc['leaf_before'],'fixture/source differs between paired actual recordings'
changed=[n for n,digest in oc['source_before'].items() if nc['source_before'].get(n)!=digest]
assert changed==['core/audio/crossfade_player.gd'],changed
assert not old['algorithm_flat_within_quarter_db'] and new['algorithm_flat_within_quarter_db'],'old dip not reproduced or new coherent input not flat'
result={'accepted':True,'old':old,'new':new,'runtime_source_only_change':changed,'scope':'Same coherent fixed DC PCM input. Actual WASAPI/AudioEffectCapture, anchored to pushed sample counts, no drops or GPU. The quarter-dB check permits mix/property-publication quantization; this is not a music equal-energy or NE261 actual-track acceptance.'}
(HERE/'pcm-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(result,indent=2))
