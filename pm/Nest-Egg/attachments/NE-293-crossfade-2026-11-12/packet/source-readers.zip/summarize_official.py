"""Recount original raw/filter/source results without running Godot."""
import argparse,hashlib,json,pathlib,re,subprocess
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('folder',type=pathlib.Path);a=ap.parse_args();o=a.folder.resolve()
before=json.loads((o/'source-before.json').read_text(encoding='utf8'));after=json.loads((o/'source-after.json').read_text(encoding='utf8'));receipt=json.loads((o/'exit.json').read_text(encoding='utf8'));command=json.loads((o/'command.json').read_text(encoding='utf8'))
assert before==after and receipt['source_unchanged'] and receipt['exit_code']==0
assert all(after[n]==v['sha256'] for n,v in command['candidate'].items())
logs=[]
for p in sorted((o/'logs').glob('shard_*.log')):
    text=p.read_text(encoding='utf8');summary=re.findall(r'^checks: (\d+), failures: (\d+)$',text,re.M);assert len(summary)==1
    filter_path=(o/'source/tools/test_filters.sh').as_posix();log_path=p.as_posix()
    r=subprocess.run(['C:/Program Files/Git/bin/bash.exe','-c','source "$1"\nhas_unexpected_errors "$2"','ne293',filter_path,log_path],capture_output=True)
    assert r.returncode==1 and not r.stdout and not r.stderr,'original filter rejected or failed'
    assert 'SCRIPT ERROR' not in text and not re.search('^FAIL: ',text,re.M)
    logs.append({'path':p.relative_to(o).as_posix(),'sha256':sha(p),'checks':int(summary[0][0]),'raw_failures':int(summary[0][1]),'script_errors':0,'raw_error_lines':len(re.findall('^ERROR:',text,re.M)),'shutdown_diagnostic_lines':[s for s in text.splitlines() if re.search(r'ObjectDB.*leaked|resources still in use|RID allocations.*leaked',s)],'original_filter_no_unexpected':True})
children=[]
if (o/'observed-godot-exits.json').exists():children=json.loads((o/'observed-godot-exits.json').read_text(encoding='utf8'))['children']
else:
    for p in sorted((o/'launches').glob('*.json')):children.append(json.loads(p.read_text(encoding='utf8')))
assert all(c['exit_code']==0 for c in children),'observed engine/launcher exit nonzero'
result={'scope':'Default original entry' if command.get('driver')=='default' else 'WASAPI enhanced coverage, not a replacement for default CI entry','script_exit':receipt['exit_code'],'seconds':receipt['seconds'],'checks':sum(l['checks'] for l in logs),'new_failures':0,'known_failures':0,'source_count':len(before),'source_before_after_equal':True,'logs':logs,'individual_child_exits_observed':bool(children),'child_process_exit_codes':[c['exit_code'] for c in children],'individual_exit_limit':'No default child exit codes captured; passive observer failed. Original changed/parallel script exit and complete raw checks/filter outcome are verified. No synthetic child exit codes.' if not children else None,'raw_error_total':sum(l['raw_error_lines'] for l in logs),'warning':'Original intentional errors/shutdown messages remain in raw. Do not describe as 0ERROR.'}
(o/'verified-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(result,indent=2))
