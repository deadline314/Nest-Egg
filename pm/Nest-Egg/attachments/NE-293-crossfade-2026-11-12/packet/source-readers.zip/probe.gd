extends Node
var out := ""
var kind := "state"
var checks: Array[Dictionary]=[]
var capture: AudioEffectCapture
var capture_bus := -1
var recorded := PackedVector2Array()

func _ready() -> void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
		if arg.begins_with("--kind="):kind=arg.trim_prefix("--kind=")
	main.call_deferred()

func check(ok: bool, label: String) -> void:checks.append({"ok":ok,"label":label})

func tone() -> AudioStreamWAV:
	var sound:=AudioStreamWAV.new()
	sound.mix_rate=48000;sound.format=AudioStreamWAV.FORMAT_16_BITS;sound.stereo=true
	var data:=PackedByteArray();data.resize(48000*2*2*2)
	for i in data.size()/2:data.encode_s16(i*2,3276)
	sound.data=data;sound.loop_begin=0;sound.loop_end=96000
	return sound

func real_wait(seconds: float) -> void:
	var end:=Time.get_ticks_usec()+int(seconds*1000000.0)
	while Time.get_ticks_usec()<end:
		await get_tree().process_frame
		if capture!=null:
			var count:=capture.get_frames_available()
			if count>0:recorded.append_array(capture.get_buffer(count))

func states(fader: CrossfadePlayer) -> Dictionary:
	var voices: Array[Dictionary]=[]
	for p in fader._players:voices.append({"db":p.volume_db,"linear":p.volume_linear,"playing":p.playing})
	return {"voices":voices,"active":fader._active,"targets_db":fader._targets.duplicate(),"rates":fader._rates.duplicate(),"public_target_db":fader.target_volume()}

func control_state() -> Dictionary:
	var fader:=CrossfadePlayer.new(&"SFX");add_child(fader);fader.set_process(false)
	var a:=Sfx.bank().variants(&"amb_wind")[0] as AudioStream
	var b:=Sfx.bank().variants(&"amb_rain")[0] as AudioStream
	var c:=Sfx.bank().variants(&"amb_city_night")[0] as AudioStream
	var observations: Dictionary={}
	check(fader.process_mode==Node.PROCESS_MODE_ALWAYS,"pause processing mode unchanged")
	check(fader.play(a,-6.0,0.0,0.0,true),"first fade0 starts")
	check(is_equal_approx(fader._players[fader._active].volume_db,-6.0),"fade0 exact dB endpoint")
	check(fader.current_stream()==a and not bool(a.get("loop")) and fader._players[fader._active].stream!=a,"loop clone leaves original source unchanged")
	check(not fader.play(a,-12.0,0.4,0.4,true),"same stream adjusts without restart")
	var index:=fader._active
	var same_voice:=fader._players[index].get_instance_id()
	var initial:=fader._players[index].volume_linear
	fader._process(0.0);check(fader._players[index].volume_linear==initial,"zero delta does not progress")
	fader._process(0.4)
	check(is_equal_approx(fader._players[index].volume_db,-12.0) and fader._players[index].get_instance_id()==same_voice,"same stream reaches same endpoint at specified duration")
	fader.stop(0.0);check(fader.voices_playing()==0 and fader.current_stream()==null,"stop0 releases both streams")
	fader.play(a,0.0,0.0,0.0,true);fader.play(b,0.0,1.0,1.0,true);fader._process(0.5)
	observations["equal_midpoint"]=states(fader)
	check(absf(fader._players[0].volume_linear+fader._players[1].volume_linear-1.001)<0.0001,"equal target midpoint sums to unchanged amplitude, not -30dB pair")
	fader._process(0.5)
	check(fader.voices_playing()==1 and is_equal_approx(fader._players[fader._active].volume_db,0.0),"original1s duration endpoints and old voice stop")
	fader.play(a,0.0,0.0,0.0,true)
	fader._process(0.0)
	check(fader.voices_playing()==1,"zero delta still releases inactive voice already at silent fade0 endpoint")
	fader.stop(0.0);fader.play(a,0.0,0.0,0.0,true);fader.play(b,-6.0,0.8,0.4,true)
	var new_voice:=fader._active;var old_voice:=1-new_voice
	fader._process(0.2)
	check(absf(fader._players[old_voice].volume_linear-0.5005)<0.0001,"unequal duration outgoing half-amplitude at own0.2/0.4")
	check(absf(fader._players[new_voice].volume_linear-lerpf(0.001,db_to_linear(-6.0),0.25))<0.0001,"unequal target incoming quarter-amplitude at own0.2/0.8")
	fader._process(0.2);check(not fader._players[old_voice].playing and fader._players[new_voice].volume_db < -6.0,"outgoing stops at own0.4s, incoming still progresses")
	fader._process(0.4);check(is_equal_approx(fader._players[new_voice].volume_db,-6.0),"incoming reaches its original0.8s/-6dB endpoint")
	fader.play(c,-18.0,0.6,0.9,true);fader._process(0.1);fader.play(a,-3.0,0.2,0.7,true)
	check(fader._players.size()==2 and fader.voices_playing()==2 and fader.current_stream()==a,"midfade rapid reentry reuses exactly two voices and newest source")
	fader._process(0.7);check(fader.voices_playing()==1 and is_equal_approx(fader._players[fader._active].volume_db,-3.0),"rapid reentry settles newest target and stops old voice")
	fader.set_volume(-70.0,0.3);fader._process(0.3)
	check(absf(fader._players[fader._active].volume_db+70.0)<0.002,"target below -60dB converges without linear epsilon early exit")
	fader.stop(0.0);fader.play(a,-70.0,0.3,0.3,true);fader._process(0.3)
	check(absf(fader._players[fader._active].volume_db+70.0)<0.002,"initial fade to below -60dB converges")
	fader.set_volume(-59.9,0.3);fader._process(0.3);fader.stop(0.4)
	for i in 400:fader._process(0.001)
	observations["small_gain_stop"]=states(fader)
	check(fader.voices_playing()==0 and fader.current_stream()==null,"small-gain stop releases old voice using original dB equality/stop thresholds")
	fader.play(a,-8.0,0.0,0.0,true,0.2);await real_wait(0.06);fader.seek(0.7);await real_wait(0.06)
	check(fader.playback_position()>=0.69 and fader.playback_position()<1.0,"seek/from-position still reach actual audio playback")
	get_tree().paused=true;check(fader.can_process() and fader._players[fader._active].can_process(),"real paused tree leaves ALWAYS fader and voice processing")
	fader.set_volume(-10.0,0.2);fader._process(0.2);check(is_equal_approx(fader.target_volume(),-10.0) and is_equal_approx(fader._players[fader._active].volume_db,-10.0),"paused fade keeps original target and duration")
	get_tree().paused=false
	fader.stop(0.1);fader._process(0.1);check(not fader.is_playing() and fader.voices_playing()==0,"nonzero stop ends at original deadline")
	check(not fader.play(null),"null stream remains ignored")
	fader.play(a,0.0,0.0,0.0,true);var ids: Array[int]=[]
	for voice in fader._players:ids.append(voice.get_instance_id())
	fader.free();check(not is_instance_id_valid(ids[0]) and not is_instance_id_valid(ids[1]),"free during playback releases both actual voice nodes")
	return observations

func control_pcm() -> Dictionary:
	AudioServer.add_bus();capture_bus=AudioServer.bus_count-1;AudioServer.set_bus_name(capture_bus,&"NE293Proof")
	capture=AudioEffectCapture.new();capture.buffer_length=5.0;AudioServer.add_bus_effect(capture_bus,capture)
	AudioServer.set_bus_mute(AudioServer.get_bus_index(&"Master"),true)
	var fader:=CrossfadePlayer.new(&"NE293Proof");add_child(fader)
	var a:=tone();var b:=tone()
	fader.play(a,0.0,0.0,0.0,false);await real_wait(0.35)
	var begin:=capture.get_pushed_frames()
	fader.play(b,0.0,1.0,1.0,false);var start:=states(fader)
	await real_wait(0.5);var midpoint:=states(fader)
	await real_wait(0.5);var ending:=states(fader);var end:=capture.get_pushed_frames()
	await real_wait(0.35)
	AudioServer.lock()
	var pushed:=capture.get_pushed_frames();var discarded:=capture.get_discarded_frames()
	var remaining:=capture.get_frames_available()
	if remaining>0:recorded.append_array(capture.get_buffer(remaining))
	AudioServer.set_bus_effect_enabled(capture_bus,0,false)
	AudioServer.unlock()
	check(discarded==0 and pushed==recorded.size() and pushed>0,"actual Capture PCM/count with no discarded frames")
	var pcm_file:=FileAccess.open(out.path_join("actual.f32"),FileAccess.WRITE)
	check(pcm_file!=null,"float PCM output opens")
	if pcm_file!=null:pcm_file.store_buffer(recorded.to_byte_array());pcm_file.close()
	fader.free();AudioServer.remove_bus(capture_bus);capture=null
	return {"begin":begin,"end":end,"start":start,"midpoint":midpoint,"ending":ending,"mix_rate":AudioServer.get_mix_rate(),"pushed":pushed,"discarded":discarded,"frames":recorded.size(),"float_format":"stereo_f32le","input":"both WAV resources contain exactly identical PCM: constant signed16=3276,48kHz,stereo2s. Coherent test of algorithm only; no music energy claim."}

func main() -> void:
	var runtime:={"display":DisplayServer.get_name(),"audio":AudioServer.get_driver_name(),"adapter":RenderingServer.get_video_adapter_name(),"rendering_device_null":RenderingServer.get_rendering_device()==null}
	print("NE293_RUNTIME "+JSON.stringify(runtime))
	if runtime["display"]!="headless" or runtime["audio"]!="WASAPI" or runtime["adapter"]!="" or not runtime["rendering_device_null"]:get_tree().quit(1);return
	DirAccess.make_dir_recursive_absolute(out)
	var data: Dictionary=await control_state() if kind=="state" else await control_pcm()
	var fail:=checks.filter(func(c: Dictionary)->bool:return not c["ok"]).size()
	var file:=FileAccess.open(out.path_join("result.json"),FileAccess.WRITE);file.store_string(JSON.stringify({"kind":kind,"runtime":runtime,"checks":checks,"failures":fail,"data":data},"  "));file.close()
	await AudioRelease.settle(get_tree())
	print("NE293_DONE checks=%d failures=%d" % [checks.size(),fail]);get_tree().quit(1 if fail else 0)
