import hashlib,json,pathlib
HERE=pathlib.Path(__file__).resolve().parent
specs=[('1794473416764590300-baseline-state',4),('1794473435109872200-candidate-state',1),('1794473446128261000-candidate-state',0)]
for name,failures in specs:
    p=HERE/'runs'/name;c=json.loads((p/'command.json').read_text(encoding='utf8'));r=json.loads((p/'exit.json').read_text(encoding='utf8'));j=json.loads((p/'result.json').read_text(encoding='utf8'))
    assert r['source_unchanged'] and r['source_after']==c['source_before'] and not r['diagnostic_lines'] and not r['gpu_log_rejected']
    assert len(j['checks'])==26 and sum(not x['ok'] for x in j['checks'])==failures==j['failures'] and r['exit_code']==int(failures>0)
    assert hashlib.sha256((p/'executed-crossfade_player.gd').read_bytes()).hexdigest()==c['source_before']['core/audio/crossfade_player.gd']
    assert j['runtime']=={'adapter':'','audio':'WASAPI','display':'headless','rendering_device_null':True}
    if failures==1:assert [x['label'] for x in j['checks'] if not x['ok']]==['zero delta still releases inactive voice already at silent fade0 endpoint']
    if failures==0:
        midpoint=j['data']['equal_midpoint'];assert abs(sum(x['linear'] for x in midpoint['voices'])-1.001)<.0001
        assert not any(x['playing'] for x in j['data']['small_gain_stop']['voices'])
print('NE293_STATE original26/4, rejected-early-return26/1, final26/0: exact raw/source scope verified')
