import argparse,hashlib,json,os,pathlib,re,shutil,subprocess,sys,time
HERE=pathlib.Path(__file__).resolve().parent
WT=pathlib.Path('D:/NestEggVerification/ne293-crossfade-20261112')
BASE='4a2f9ecfaf3d98db102e79b37420821f714549ca'
GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
def names():
    tracked=subprocess.run(['git','ls-files','-z','core','game','autoload','data','tests','tools','ui','audio','art/rigs','project.godot','default_bus_layout.tres'],cwd=WT,capture_output=True,check=True).stdout.decode('utf8').split('\0')
    return sorted(n for n in tracked if n and (WT/n).is_file())
def snapshot(paths):return {n:sha(WT/n) for n in paths}
def observe_original_command(cmd,env,logfile,out):
    # Read-only process handles retain real direct-Godot child exit codes;
    # no executable/argument wrapping in the default-entry verification.
    import ctypes,ctypes.wintypes as win
    kernel=ctypes.windll.kernel32
    kernel.OpenProcess.argtypes=[win.DWORD,win.BOOL,win.DWORD];kernel.OpenProcess.restype=win.HANDLE
    kernel.GetExitCodeProcess.argtypes=[win.HANDLE,ctypes.POINTER(win.DWORD)]
    kernel.CloseHandle.argtypes=[win.HANDLE]
    class Entry(ctypes.Structure):
        _fields_=[('size',win.DWORD),('usage',win.DWORD),('pid',win.DWORD),('heap',ctypes.c_size_t),('module',win.DWORD),('threads',win.DWORD),('parent',win.DWORD),('priority',win.LONG),('flags',win.DWORD),('exe',win.WCHAR*260)]
    kernel.CreateToolhelp32Snapshot.argtypes=[win.DWORD,win.DWORD];kernel.CreateToolhelp32Snapshot.restype=win.HANDLE
    kernel.Process32FirstW.argtypes=[win.HANDLE,ctypes.POINTER(Entry)];kernel.Process32NextW.argtypes=[win.HANDLE,ctypes.POINTER(Entry)]
    handles={};records={}
    with logfile.open('wb') as log:
        process=subprocess.Popen(cmd,cwd=WT,env=env,stdout=log,stderr=subprocess.STDOUT)
        deadline=time.monotonic()+2400
        while process.poll() is None:
            assert time.monotonic()<deadline,'original test entry timed out'
            snapshot=kernel.CreateToolhelp32Snapshot(2,0);entries=[]
            if snapshot and snapshot!=ctypes.c_void_p(-1).value:
                entry=Entry();entry.size=ctypes.sizeof(Entry);ok=kernel.Process32FirstW(snapshot,ctypes.byref(entry))
                while ok:
                    entries.append((int(entry.pid),int(entry.parent),str(entry.exe)))
                    ok=kernel.Process32NextW(snapshot,ctypes.byref(entry))
                kernel.CloseHandle(snapshot)
            descendants={process.pid};changed=True
            while changed:
                before=len(descendants);descendants.update(pid for pid,parent,name in entries if parent in descendants);changed=len(descendants)!=before
            for pid,parent,name in entries:
                if pid in descendants and pid not in handles and name.lower().startswith('godot'):
                    handle=kernel.OpenProcess(0x1000|0x100000,False,pid)
                    if handle:handles[pid]=handle;records[pid]={'pid':pid,'parent_pid':parent,'name':name}
            time.sleep(.1)
        for pid,handle in handles.items():
            value=win.DWORD();ok=kernel.GetExitCodeProcess(handle,ctypes.byref(value))
            records[pid]['exit_code']=int(value.value) if ok else None;kernel.CloseHandle(handle)
    save(out/'observed-godot-exits.json',{'scope':'Passive Windows handles only, original executable/arguments unchanged. Includes engine/console launcher if both are present.','children':list(records.values())})
    return process.returncode
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--driver',choices=('default','wasapi'),default='default');args=parser.parse_args()
    assert subprocess.run(['git','rev-parse','HEAD'],cwd=WT,capture_output=True,check=True).stdout.decode().strip()==BASE
    candidate=json.loads((HERE/'candidate-2-manifest.json').read_text(encoding='utf8'))
    assert all(sha(WT/n)==row['sha256'] for n,row in candidate['files'].items())
    delta=subprocess.run(['git','diff','--name-only'],cwd=WT,capture_output=True,check=True).stdout.decode().splitlines();assert sorted(delta)==sorted(candidate['files'])
    out=HERE/('published-'+args.driver+'-official-'+str(time.time_ns()));out.mkdir()
    shutil.copyfile(pathlib.Path(__file__),out/'executed-runner.py')
    paths=names();before=snapshot(paths);save(out/'source-before-import.json',before)
    env=os.environ.copy();env['APPDATA']=str(out/'import-appdata');env['LOCALAPPDATA']=str(out/'import-localappdata')
    command=[GODOT,'--path',str(WT)]+(['--headless'] if args.driver=='default' else ['--display-driver','headless','--audio-driver','WASAPI'])+['--editor','--import','--quit']
    save(out/'import-command.json',{'argv':command,'base':BASE});start=time.monotonic()
    with (out/'import.log').open('wb') as f:result=subprocess.run(command,cwd=WT,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=360)
    log=(out/'import.log').read_text(encoding='utf8',errors='replace');diagnostics=[l for l in log.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|WARNING:|Parse Error',l)]
    assert snapshot(paths)==before,'import changed existing frozen runtime/source'
    generated=subprocess.run(['git','ls-files','--others','--exclude-standard','-z'],cwd=WT,capture_output=True,check=True).stdout.decode('utf8').split('\0');metadata={n:sha(WT/n) for n in generated if n.endswith('.gd.uid')}
    save(out/'generated-metadata.json',metadata);save(out/'import-exit.json',{'exit_code':result.returncode,'seconds':time.monotonic()-start,'diagnostic_lines':diagnostics,'existing_source_unchanged':True})
    assert result.returncode==0 and not diagnostics,'import rejected'
    frozen={**before,**metadata};save(out/'source-before.json',frozen)
    wrapper=out/'godot_audio_only.sh';python=pathlib.Path(sys.executable).as_posix();adapter=(HERE/'godot_audio_only.py').as_posix()
    wrapper.write_text('#!/usr/bin/env bash\nexec "'+python+'" "'+adapter+'" "$@"\n',encoding='utf8',newline='\n');shutil.copyfile(HERE/'godot_audio_only.py',out/'executed-godot_audio_only.py')
    env=os.environ.copy();env.update({'GODOT':GODOT if args.driver=='default' else wrapper.as_posix(),'SHARDS':'2','LOG_DIR':str(out/'logs'),'NE293_LAUNCH_DIR':str(out/'launches'),'PYTHONIOENCODING':'utf-8'})
    cmd=['C:/Program Files/Git/bin/bash.exe','tools/run_tests_changed.sh',BASE]
    save(out/'command.json',{'argv':cmd,'cwd':str(WT),'base':BASE,'driver':args.driver,'env':{k:env[k] for k in ('GODOT','SHARDS','LOG_DIR','NE293_LAUNCH_DIR','PYTHONIOENCODING')},'wrapper_used':args.driver=='wasapi','wrapper_sha256':sha(wrapper),'adapter_sha256':sha(HERE/'godot_audio_only.py'),'candidate':candidate['files'],'scope':'Original changed.sh/selector/filter, two shards, only two product/test candidates. Default mode uses original Godot executable directly, unchanged --headless arguments. WASAPI mode is separately enhanced coverage and does not replace default.'})
    for name in ('tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt'):
        p=out/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WT/name,p)
    start=time.monotonic()
    code=observe_original_command(cmd,env,out/'full.log',out)
    after=snapshot(sorted(frozen));save(out/'source-after.json',after);log=(out/'full.log').read_text(encoding='utf8',errors='replace')
    save(out/'exit.json',{'exit_code':code,'seconds':time.monotonic()-start,'source_unchanged':frozen==after,'summary':[l for l in log.splitlines() if l.startswith(('checks:','受影響的測試','Running '))]})
    print(out);print(log[-2500:]);return code if frozen==after else 2
if __name__=='__main__':raise SystemExit(main())
