"""CLI adapter only: original test scripts stay byte-identical."""
import json,os,pathlib,subprocess,sys,time
out=pathlib.Path(os.environ['NE293_LAUNCH_DIR']);out.mkdir(parents=True,exist_ok=True)
command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--display-driver','headless','--audio-driver','WASAPI']+[a for a in sys.argv[1:] if a!='--headless']
receipt={'argv':command,'original_argv':sys.argv[1:],'scope':'Only translate --headless to explicit headless display plus WASAPI; original scene/suite arguments unchanged, no GPU renderer.'}
file=out/(str(time.time_ns())+'.json');file.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n')
result=subprocess.run(command)
receipt['exit_code']=result.returncode;file.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n');raise SystemExit(result.returncode)
