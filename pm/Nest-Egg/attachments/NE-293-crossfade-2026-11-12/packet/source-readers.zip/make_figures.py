"""Actual recorded PCM plots. No engine/rendered-game-image claim."""
import argparse,copy,importlib.util,json,pathlib,sys,types
import numpy as np
from PIL import Image,ImageDraw
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'hold-replay/canonical-audio-tools'))
import melee_sound_report as report
from melee_pcm_reader import load
ap=argparse.ArgumentParser();ap.add_argument('--before-run',type=pathlib.Path,default=HERE/'runs/1794472002092308000-holds');ap.add_argument('--after-run',type=pathlib.Path,default=HERE/'hold-replay/runs/1794475671530991700');ap.add_argument('--out',type=pathlib.Path,default=HERE/'figures');args=ap.parse_args()
RUNS=[args.before_run,args.after_run]
spec=importlib.util.spec_from_file_location('hold_reader',HERE/'hold-replay/verify_holds.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
OUT=args.out;OUT.mkdir(exist_ok=True)
panels=[];maul=[]
for n,run in enumerate(RUNS):
    j=json.loads((run/'recording/hold-index.json').read_text(encoding='utf8'))
    rate,buses=load(run/'recording',j)
    metrics,problems=reader.evaluate(j,buses,rate,report.levels);r={'rows':metrics}
    master=np.frombuffer(buses['Master']['pcm_s16'],dtype='<i2').reshape(-1,2).mean(axis=1,dtype=np.float32)/32768
    segments=[];rows=[]
    for segment,metric in zip(j['hold_segments'],r['rows']):
        start=segment['start_frames']['SFX']/rate;end=segment['end_frames']['SFX']/rate
        segments.append({'weapon':segment['weapon'],'part':segment['part'],'start':start,'end':end})
        rows.append({**metric,'start':start,'end':end})
    file=OUT/('before-waveforms.png' if n==0 else 'after-waveforms.png')
    # Reuse the original waveform/binning/scale. Replace its long statistic
    # captions with short phase labels so the additional hold/entry rows fit.
    original_draw=report.ImageDraw
    class CompactDraw:
        def __init__(self,image):self.draw=ImageDraw.Draw(image)
        def __getattr__(self,name):return getattr(self.draw,name)
        def text(self,xy,text,**kwargs):
            if '峰值' not in text:self.draw.text(xy,text,**kwargs)
    report.ImageDraw=types.SimpleNamespace(Draw=CompactDraw)
    try:report.sheet(master,rate,segments,rows,file)
    finally:report.ImageDraw=original_draw
    panel=Image.open(file).copy();pd=ImageDraw.Draw(panel)
    groups=[]
    for s in segments:
        if not groups or groups[-1][0]['weapon']!=s['weapon']:groups.append([])
        groups[-1].append(s)
    short={'silence':'R0','pistol':'R1','pistol_hit':'R2','walk':'R3','idle':'I','entry_miss':'E-','hold_miss':'H-','entry_hit':'E+','hold_hit':'H+','holster':'X'}
    for group_id,group in enumerate(groups):
        start,end=group[0]['start'],group[-1]['end']
        for s in group:
            x=10+int((s['start']-start)/(end-start)*1580);pd.text((x+4,group_id*150+36),short[s['part']],font=report.font(14),fill=(230,230,240))
    panel.save(file);panels.append(panel)
    row=next(s for s in j['hold_segments'] if s['weapon']=='maul' and s['part']=='idle');cut=slice(row['start_frames']['SFX'],row['end_frames']['SFX'])
    sfx=np.frombuffer(buses['SFX']['pcm_s16'],dtype='<i2').reshape(-1,2)[cut].mean(axis=1,dtype=np.float32)/32768
    bed=np.zeros_like(sfx)
    for name in ('Music','Ambience'):
        x=np.frombuffer(buses[name]['raw_f32'],dtype='<f4').reshape(-1,2)[cut].mean(axis=1)
        x*=buses[name]['gain']/buses['SFX']['gain'];bed+=x
    series=[]
    for x in (sfx,bed):
        step=int(rate*report.WINDOW);count=len(x)//step;windows=np.sqrt(np.square(x[:count*step].reshape(count,step)).mean(axis=1))
        series.append([report.db(float(v)) for v in windows])
    maul.append({'series':series,'metric':next(v for v in r['rows'] if v['weapon']=='maul' and v['part']=='idle'),'row':row})
title=Image.new('RGB',(3200,panels[0].height+140),(14,15,20));draw=ImageDraw.Draw(title)
for i,(panel,text) in enumerate(zip(panels,['修前：Published896+7，原10dB規則失敗','修後：Published4a+only2，原10dB規則通過'])):
    draw.text((i*1600+15,8),text,font=report.font(24),fill='white');draw.text((i*1600+15,46),'I待機 / E-普通揮空前置 / H-按住揮空 / E+普通命中前置 / H+按住命中 / X收起',font=report.font(18),fill=(210,210,220));title.paste(panel,(i*1600,104))
draw.text((15,title.height-30),'真WASAPI混音波形；同公開輸入／自然動作，非音訊byte A/A。headless audio-only，非Forward+視覺原生截圖。',font=report.font(20),fill=(200,200,210));title.save(OUT/'holds-before-after.png')

def plot(draw,box,values,colour,ymin,ymax,xend=1.6,step=.05):
    x0,y0,x1,y1=box
    points=[(x0+(i+.5)*step/xend*(x1-x0),y1-(min(ymax,max(ymin,v))-ymin)/(ymax-ymin)*(y1-y0)) for i,v in enumerate(values)]
    if len(points)>1:draw.line(points,fill=colour,width=3)

image=Image.new('RGB',(1500,620),(14,15,20));draw=ImageDraw.Draw(image)
draw.text((20,10),'液壓錘待機：同原操作與音量，實際逐50ms RMS',font=report.font(26),fill='white')
for i,info in enumerate(maul):
    x0=70+i*750;box=(x0,150,x0+650,490);m=info['metric']
    draw.text((x0,55),'修前 RED' if i==0 else '修後 GREEN',font=report.font(23),fill='white')
    draw.text((x0,88),'待機 %.3f dB / 音床 %.3f dB'%(m['floor'],m['bed']),font=report.font(18),fill='white')
    for db in (-70,-60,-50,-40,-30,-20,-10):
        y=box[3]-(db+70)/60*(box[3]-box[1]);draw.line([(box[0],y),(box[2],y)],fill=(55,55,65));draw.text((box[0]-45,y-10),str(db),font=report.font(16),fill=(190,190,200))
    plot(draw,box,info['series'][0],(255,205,80),-70,-10);plot(draw,box,info['series'][1],(90,195,255),-70,-10)
    for time_value in (0,.4,.8,1.2,1.6):
        x=box[0]+time_value/1.6*(box[2]-box[0]);draw.text((x-10,500),'%.1f'%time_value,font=report.font(17),fill=(200,200,210))
    draw.text((box[2]-30,525),'秒',font=report.font(16),fill=(200,200,210))
draw.text((30,545),'黃：SFX待機聲　藍：真Music+Ambience（正確bus gain平面；Ambience仍為0，沒有加背景）',font=report.font(19),fill=(220,220,230))
draw.text((30,580),'headless / WASAPI，非Forward+視覺原生。曲線以各自真sample起點；未更改片段或門檻。',font=report.font(19),fill=(220,220,230));image.save(OUT/'maul-idle-before-after.png')

j=json.loads((HERE/'pcm-result.json').read_text(encoding='utf8'));image=Image.new('RGB',(1300,550),(14,15,20));draw=ImageDraw.Draw(image)
draw.text((25,15),'相同固定PCM：實際錄音的中段音量（對各自steady參考）',font=report.font(25),fill='white');box=(100,100,1200,420)
for db in (-25,-20,-15,-10,-5,0):
    y=box[3]-(db+25)/27*(box[3]-box[1]);draw.line([(box[0],y),(box[2],y)],fill=(55,55,65));draw.text((35,y-10),str(db)+'dB',font=report.font(17),fill=(200,200,210))
for key,colour in [('old',(255,155,100)),('new',(90,205,255))]:
    plot(draw,box,j[key]['middle_50ms_db_relative_to_same_input'],colour,-25,2,xend=.4)
for time_value in (.3,.4,.5,.6,.7):
    x=box[0]+(time_value-.3)/.4*(box[2]-box[0]);draw.text((x-12,425),'%.1fs'%time_value,font=report.font(17),fill=(200,200,210))
draw.text((30,460),'橘：修前最低-23.871dB　藍：修後+0.008686～+0.008697dB，兩份各82432真float幀',font=report.font(20),fill='white')
draw.text((30,495),'只證固定相干輸入的算法凹谷；不是音樂恆能量、真人試聽或Forward+視覺截圖。',font=report.font(20),fill=(210,210,220));image.save(OUT/'fixed-input-before-after.png')
print(OUT)
