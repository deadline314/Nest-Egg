#!/usr/bin/env bash
exec "C:/Users/stanl/AppData/Local/Programs/Python/Python313/python.exe" "C:/Users/stanl/Github/Nest-Egg/work/ne293-crossfade-20261112/godot_audio_only.py" "$@"
