from hashlib import sha256
from pathlib import Path
import json
import math
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
label = sys.argv[1]
out = base / label
out.mkdir()
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    path = out / key
    path.mkdir()
    env[key] = str(path)
paths = ["ui/vitals_tag.gd","ui/hud_presence.gd","ui/hud.gd","autoload/settings.gd",
         "game/player/player.gd","data/levels/ch1_street.tres","core/components/health_component.gd"]
sha = lambda path: sha256(path.read_bytes()).hexdigest()
source = {p:sha(game / p) for p in paths}
argv = [sys.executable,"-B",str(game/"tools/comfyui/gpu_lock.py"),"--",
        "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(game),
        "--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy",
        "--fixed-fps","60","--resolution","1280x720","--quit-after","3300",str(base/"observe.tscn"),"--",f"--out={out}"]
(out/"command.json").write_text(json.dumps({"argv":argv,"source":source},indent=2)+"\n",encoding="utf-8")
with (out/"engine.log").open("wb") as log:
    proc = subprocess.run(argv,cwd=game,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=230)
raw=(out/"engine.log").read_text(encoding="utf-8",errors="replace")
print(raw[-8000:],flush=True)
report = json.loads((out/"result.json").read_bytes())
assert all(sha(game/p)==digest for p,digest in source.items())
assert proc.returncode==0 and not re.search(r"^SCRIPT ERROR:|^ERROR:",raw,re.M), (proc.returncode,report["failures"])
assert report["hdr"] and "9070 XT" in report["adapter"] and not report["failures"]
rows={(r["mode"],r["label"]):r for r in report["rows"]}
assert len(rows)==39 and len(list(out.glob("*.png")))==39
assert all(row["health"]==row["health_actual"] and row["alive"] and row["alpha"]>.5 for row in rows.values())
for mode in ("normal","motion","flashes","both","toggle"):
    hit=rows[mode,"hit"]
    heal=rows[mode,"heal"]
    assert hit["health"]==2 and heal["health"]==4 and rows[mode,"guard-break"]["broken"]
    assert rows[mode,"parry"]["broken"] is False
    if label.startswith("stock") or mode in ("normal","toggle"):
        assert hit["shake"]>0 and max(hit["lost"])>=0 and max(heal["gain"])>=0
        assert rows[mode,"parry"]["parry"]>0.0
    else:
        assert max(hit["lost"])<0 and max(heal["gain"])<0 and rows[mode,"parry"]["parry"]==0
        assert (hit["shake"]==0) == hit["motion"]
        for step in ("guard-loss","guard-break","guard-recover"):
            row=rows[mode,step]
            assert not row["guard_rising"] and math.isclose(row["guard_ghost"],row["guard_shown"],abs_tol=1e-5)
            if row["motion"]:
                assert math.isclose(row["guard_shown"],row["guard"],abs_tol=1e-5)
if not label.startswith("stock"):
    quiet=rows["toggle","hit-flashes-toggle"]
    quiet_motion=rows["toggle","hit-motion-toggle"]
    restored=rows["toggle","hit-options-restored"]
    assert max(quiet["lost"])<0 and quiet["shake"]>0
    assert quiet_motion["shake"]==0 and max(restored["lost"])<0 and restored["shake"]==0
    row=rows["toggle","guard-motion-toggle"]
    assert row["broken"] and math.isclose(row["guard_shown"],row["guard"],abs_tol=1e-5)
print("39 steps from five actual street fixtures rendered and recorded.",flush=True)
