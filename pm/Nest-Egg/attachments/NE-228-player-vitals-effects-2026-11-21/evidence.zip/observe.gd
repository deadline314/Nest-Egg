extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
var _out := ""
var _rows: Array[Dictionary] = []
var _failures: Array[String] = []


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://vitals_fixture.cfg")
	Settings.set_brightness(0.5)
	Settings.set_hud_auto_hide(false)
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	for mode: String in ["normal", "motion", "flashes", "both", "toggle"]:
		await _observe(mode)
	var file := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"rows":_rows,"failures":_failures,
		"adapter":RenderingServer.get_video_adapter_name(),"hdr":get_viewport().use_hdr_2d}, "  "))
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(not _failures.is_empty()))


func _observe(mode: String) -> void:
	seed(506228)
	Settings.set_reduce_ui_motion(mode in ["motion","both"])
	Settings.set_reduce_flashes(mode in ["flashes","both"])
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	for _frame in 120:
		if level.is_initialized():
			break
		await get_tree().process_frame
	var pile: CreditPickup
	for node in level._entities.get_children():
		if node is CreditPickup and pile == null and node._requires_flag == &"" and not node._elevated:
			pile = node
		elif node is Enemy:
			node.process_mode = Node.PROCESS_MODE_DISABLED
	if pile == null:
		_failures.append(mode + " missing authored position")
		level.queue_free()
		await get_tree().process_frame
		return
	for node in level.find_children("*","",true,false):
		if node is ChapterCard:
			node.queue_free()
	var player := level.player
	var vitals := level.hud.vitals_tag
	player.global_position = pile.global_position + Vector2(-30,0)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	level._lighting._lightning_gap = 1.0e9
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	camera.global_position = pile.global_position + Vector2(-42,-43)
	camera.reset_smoothing()
	camera.force_update_scroll()
	for _frame in 12:
		await get_tree().process_frame
	var original := player.health.current
	var initial_max := player.health.max_health
	await _record(mode,"before",player,vitals)
	var info := DamageInfo.create(maxi(1,original-2),Combat.Team.ENEMY,&"rifle_shot")
	info.ignore_invulnerability = true
	info.origin = player.global_position + Vector2(60,-20)
	player.hurtbox.receive(info)
	_check(player.health.current==2 and player.health.max_health==initial_max, mode+" actual hit reaches low health")
	await _record(mode,"hit",player,vitals)
	if mode == "toggle":
		Settings.set_reduce_flashes(true)
		await _record(mode,"hit-flashes-toggle",player,vitals)
		Settings.set_reduce_ui_motion(true)
		await _record(mode,"hit-motion-toggle",player,vitals)
		Settings.set_reduce_ui_motion(false)
		Settings.set_reduce_flashes(false)
		await _record(mode,"hit-options-restored",player,vitals)
	player.health.heal(2)
	_check(player.health.current==4, mode+" actual recovery restores two health")
	await _record(mode,"heal",player,vitals)
	player.guard = 33.0
	player._emit_guard()
	await _record(mode,"guard-loss",player,vitals)
	player._guard_break(player.global_position + Vector2(0,-20))
	player._emit_guard()
	_check(vitals.guard_broken, mode+" actual guard break reaches the HUD")
	await _record(mode,"guard-break",player,vitals)
	if mode == "toggle":
		Settings.set_reduce_ui_motion(true)
		await _record(mode,"guard-motion-toggle",player,vitals)
		Settings.set_reduce_ui_motion(false)
	player._guard_lockout_left = 0.0
	player.guard = 68.0
	player._emit_guard()
	await _record(mode,"guard-recover",player,vitals)
	EventBus.player_parried.emit(player.global_position)
	await _record(mode,"parry",player,vitals)
	level.queue_free()
	await get_tree().process_frame


func _record(mode: String, label: String, player: Player, vitals: VitalsTag) -> void:
	await RenderingServer.frame_post_draw
	var picture := "%s-%s.png" % [mode,label]
	_check(Capture.image(get_viewport()).save_png(_out.path_join(picture))==OK, mode+" "+label+" captured")
	var low_color := vitals._health_color(1.0)
	_rows.append({"mode":mode,"label":label,"file":picture,"alive":not player.is_dead(),
		"health":vitals.health,"health_actual":player.health.current,"max":vitals.max_health,
		"guard":vitals.guard_ratio,"guard_shown":vitals._guard_shown,"guard_ghost":vitals._guard_ghost,
		"guard_rising":vitals._guard_rising,"broken":vitals.guard_broken,
		"shake":vitals._shake_left,"parry":vitals._parry_left,"gain":Array(vitals._gain_time),"lost":Array(vitals._lost_time),
		"alpha":vitals.presence.alpha,"pop":vitals.presence.pop,"time":vitals._time,
		"pos":[vitals._pos.x,vitals._pos.y],"low_color":[low_color.r,low_color.g,low_color.b,low_color.a],
		"motion":Settings.get_reduce_ui_motion(),"flashes":Settings.get_reduce_flashes()})


func _check(ok: bool, message: String) -> void:
	if not ok:
		_failures.append(message)
