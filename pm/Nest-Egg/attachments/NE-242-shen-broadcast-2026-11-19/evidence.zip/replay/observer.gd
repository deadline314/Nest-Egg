extends Node

const CAPTURE := preload("res://tools/viewport_capture.gd")
const MARKET := "res://data/levels/ch2_market.tres"
const SCENE := &"ch2_t_s08_screen"
const PORTRAIT := "res://art/portraits/ch2_shen.png"
var _out := ""
var _language := ""
var _before := false
var _checks := 0
var _failures: Array[String] = []
var _flag_changes: Dictionary = {}

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--language="):
			_language = arg.trim_prefix("--language=")
		elif arg == "--before":
			_before = true
	_run.call_deferred()

func _frames(count: int) -> void:
	for i in count:
		await get_tree().physics_frame

func _check(value: bool, label: String) -> void:
	_checks += 1
	if not value:
		_failures.append(label)

func _press(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(2)
	event = InputEventAction.new()
	event.action = action
	Input.parse_input_event(event)

func _screenshot(filename: String) -> void:
	await RenderingServer.frame_post_draw
	_check(CAPTURE.image(get_viewport()).save_png(_out.path_join(filename)) == OK, filename)

func _run() -> void:
	_check(Story.set_language(_language), "locale is supported")
	TranslationServer.set_locale(_language)
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Story.auto_skip = true
	var main := load("res://game/main.gd").new() as Node
	main.set("_run_store", RunSaveStore.new(_out.path_join("fixture.json")))
	add_child(main)
	await _frames(25)
	main.call("_on_start_requested", GameState.difficulties[1])
	await _frames(130)
	main.call("_on_area_requested", MARKET)
	var level: Level
	for i in 360:
		await _frames(1)
		level = main.get("_screen") as Level
		if is_instance_valid(level) and level.data.resource_path == MARKET and not GameplayLock.is_locked():
			break
	_check(is_instance_valid(level) and level.data.resource_path == MARKET, "real market loads through Main")
	if not is_instance_valid(level):
		await _finish()
		return
	var notice: NpcActor
	for node in level._entities.get_children():
		if node is NpcActor and node.data.id == &"ch2_notice_screen":
			notice = node
	_check(notice != null and Story.resolve_dispatch(notice.data.talks[0].scene) == SCENE, "original notice dispatch")
	if notice == null:
		await _finish()
		return
	var player := level.player
	player.global_position = notice.global_position + Vector2(-28, 0)
	player.velocity = Vector2.ZERO
	await _frames(110)
	Story.auto_skip = false
	var data: Dictionary = Story._scenes[String(SCENE)]
	var steps: Array = data.get("steps", [])
	_check(data.get("mode") == "animated" and data.get("overlay") == true and steps.size() == 2, "original two-line map overlay")
	var flags := GameState.world_flags.duplicate(true)
	var count := notice.talk_count
	_check(Story.framing.is_interaction_target(notice), "notice owns actual interact key")
	await _screenshot("market-screen.png")
	await _press(&"interact")
	var dialogue: CutsceneDialogue
	for i in 360:
		await _frames(1)
		if is_instance_valid(Story._player) and Story._player._dialogue.is_complete():
			dialogue = Story._player._dialogue
			break
	_check(dialogue != null and Story.is_cinematic_active() and GameplayLock.is_locked() and Story.framing.amount == 0.0, "original map overlay without wide framing")
	if dialogue == null:
		await _finish()
		return
	var expected_portrait := "res://art/portraits/system.png" if _before else PORTRAIT
	var name_by_language := {"zh": "沈望", "ja": "沈望", "en": "Shen Wang"}
	_check(dialogue._portrait.texture != null and dialogue._portrait.texture.resource_path == expected_portrait, "anniversary line shows the expected portrait")
	_check(dialogue._name.text == name_by_language[_language] and dialogue._text.text == steps[0]["text"] and dialogue.is_complete(), "speaker and complete original speech match locale")
	await _screenshot("shen-anniversary.png")
	await _press(&"ui_accept")
	for i in 360:
		await _frames(1)
		if dialogue._text.text == steps[1]["text"] and dialogue.is_complete():
			break
	_check(dialogue._text.text == steps[1]["text"] and dialogue.is_complete(), "complete original weather sidebar")
	await _screenshot("notice-weather.png")
	await _press(&"ui_accept")
	await _frames(60)
	_check(notice.talk_count == count + 1 and not Story.is_cinematic_active() and not GameplayLock.is_locked(), "reading both cards releases the original lock and records interaction")
	await _press(&"interact")
	await _frames(20)
	_check(Story._current_cinematic == SCENE, "real interact opens the same optional notice again")
	await _press(&"ui_cancel")
	await _frames(45)
	_check(notice.talk_count == count + 2 and not Story.is_cinematic_active() and not GameplayLock.is_locked(), "original cancel closes the replay")
	for flag: Variant in flags.keys() + GameState.world_flags.keys():
		var old: Variant = flags.get(flag)
		var current: Variant = GameState.world_flags.get(flag)
		if old != current:
			_flag_changes[flag] = [old, current]
	_check(not _flag_changes.keys().any(func(key: Variant) -> bool: return str(key).begins_with("ch2_")) and not notice.data.talks[0].has_reward(), "notice changes no Chapter 2 flags and remains reward-free")

	await _finish()

func _finish() -> void:
	FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify({
		"checks": _checks, "failures": _failures, "adapter": RenderingServer.get_video_adapter_name(),
		"language": _language, "previous": _before, "changed_flags": _flag_changes,
	}, "\t"))
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures.is_empty() else 1)
