from pathlib import Path
import json,os,subprocess,sys
root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117')
project=base/'st15-runtime-locale-20261119/runtime'
label,language=sys.argv[1:]
out=base/'ne242-shen-portrait-20261119'/f'native-{label}-{language}'
out.mkdir()
script=out/'observer.gd'
script.write_bytes((root/'work/ne242-shen-notice-native.gd').read_bytes())
scene=script.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{script.as_posix()}" id="1"]\n[node name="NoticeObserver" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')
args=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--fixed-fps','60','--resolution','1280x720','--quit-after','2950',scene.as_posix(),'--','--out='+str(out),'--language='+language]
if label.startswith('before'): args+=['--before']
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(out/'profile'/key)
(out/'command.json').write_text(json.dumps(args,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
    p=subprocess.run(args,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=170)
raw=(out/'raw.log').read_text(encoding='utf-8')
print(raw[-1600:],flush=True)
if (out/'result.json').exists(): print((out/'result.json').read_text(),flush=True)
assert p.returncode==0 and 'ERROR:' not in raw and 'WARNING:' not in raw
result=json.loads((out/'result.json').read_text())
assert result['checks']>=6 and not result['failures']
