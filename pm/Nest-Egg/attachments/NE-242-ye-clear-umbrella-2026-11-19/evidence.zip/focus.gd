extends "res://tools/ch3_office_capture.gd"


func _init() -> void:
	level_path = "res://data/levels/ch3_office_hall.tres"
	story_file = "res://data/story/ch3_clearwater.json"
	shot_prefix = "ST-21"
	id_prefix = "ch3_t_"
	shots = {
		&"ch3_t_c18_box": ["取件格的回執寫著：風控接待收件，月報17查核件。"],
		&"ch3_t_c19_watch": ["葉把透明傘掛在桌旁，停筆，把手背翻向自己，補了一行字才翻開檔案。"],
		&"ch3_t_c20_trade": ["資料在天穹保管，交付人是你。這一點沒有改。", "她不知道那份資料是我交的，妳別把這個拿到她面前。"],
	}


func _run() -> void:
	Story.auto_skip = false
	GameState.start_new_run(GameState.difficulties[1])
	for flag in [&"ch1_supper_done", &"ch1_handoff_done"]:
		GameState.set_flag(flag)
	var level := Level.new()
	level.configure(load(level_path))
	get_tree().root.add_child(level)
	await _frames(60)
	Story.reset_active_presentation(&"route")
	var translated := _translations()
	var failures := 0
	for id: StringName in shots:
		_prepare(id)
		var wanted: Array = shots[id].map(func(zh: String) -> String: return translated.get(zh, zh))
		var taken := 0
		if Story.play(id, false):
			for frame in range(300):
				if Story.is_cinematic_active() and Story._current_cinematic == id:
					break
				await _frames(1)
			for frame in range(5400):
				if not Story.is_cinematic_active() or taken >= wanted.size():
					break
				var player: CutscenePlayer = Story._player
				if player == null:
					await _frames(3)
					continue
				var line: String = player._dialogue._text.text
				if player._dialogue.is_complete():
					if line == wanted[taken]:
						await _frames(50)
						var name := "%s-%s-%d" % [shot_prefix, String(id).trim_prefix(id_prefix), taken + 1]
						await RenderingServer.frame_post_draw
						var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
						var err := image.save_png(_out.path_join(name + ".png"))
						print("saved %s (%s)" % [name, error_string(err)])
						if err != OK:
							failures += 1
						taken += 1
					player._advance_requested = true
				await _frames(3)
		print("%s shots %d/%d" % [id, taken, wanted.size()])
		if taken != wanted.size():
			failures += 1
		Story.reset_active_presentation(&"route")
		await _frames(10)
	AudioRelease.begin_shutdown()
	level.queue_free()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)
