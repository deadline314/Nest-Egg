extends Node2D

const DT := 1.0 / 60.0
const WEAPONS := ["blade","dagger","glaive","maul","whip"]
var output := ""
var frames: Array[Dictionary] = []
var failed := false


class CountedMelee extends MeleeModule:
	var reads := 0

	func _init(player: Player) -> void:
		super(player)

	func path_now() -> PackedFloat32Array:
		reads += 1
		return super.path_now()


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			output = arg.trim_prefix("--out=")
	if not output.is_absolute_path():
		get_tree().quit(2)
		return
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	_run.call_deferred()


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	for weapon_id: String in WEAPONS:
		for side: int in [-1,1]:
			await _capture(weapon_id,side)
	var file := FileAccess.open(output.path_join("path-reads.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"failed":failed,"frames":frames},"  ") + "\n")
	file.close()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(failed))


func _capture(weapon_id: String, side: int) -> void:
	var player := Player.new()
	player.position = Vector2(320,240)
	player.configure(preload("res://data/player/player_tuning.tres"),6,{})
	player.melee.free()
	var melee := CountedMelee.new(player)
	player.melee = melee
	add_child(player)
	player.set_physics_process(false)
	player._visual.set_physics_process(false)
	player._visual.set_process(false)
	player.loadout.equip(load("res://data/weapons/melee/melee_%s.tres" % weapon_id) as WeaponData)
	player.facing = side
	player.aim_dir = Vector2(side,0.0)
	for _tick in 20:
		player._visual._physics_process(DT)
	if not player._start_melee_attack(false):
		failed = true
		print("FAIL could not start ",weapon_id," side ",side)
		player.queue_free()
		return
	for tick in 110:
		player._tick_melee(DT)
		melee.reads = 0
		player._visual._physics_process(DT)
		var weapon := player._visual.melee_hold()
		var rig := player._visual.rig
		var grip := rig.hand_contact_global(&"front")
		frames.append({"weapon":weapon_id,"side":side,"frame":tick,"reads":melee.reads,"phase":melee.phase,
			"pose":melee.pose_progress(),"hold":[weapon.origin.x,weapon.origin.y,weapon.x.x,weapon.x.y],
			"hand":[grip.x,grip.y]})
		if tick > 5 and melee.phase == MeleeModule.Phase.NONE:
			break
		if DisplayServer.get_name() != "headless" and side == 1 and tick in [2,8]:
			await RenderingServer.frame_post_draw
			preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(output.path_join("%s_%02d.png" % [weapon_id,tick]))
	player.queue_free()
	await get_tree().process_frame
