from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json
import re

root=Path.cwd()
base=Path(__file__).resolve().parent
def read(path):
    return json.loads((base/path).read_bytes())

for measurement in ('headless','native'):
    old=read(f'stock-{measurement}/path-reads.json')['frames']
    new=read(f'candidate-{measurement}/path-reads.json')['frames']
    assert len(old)==len(new)==340
    for before,after in zip(old,new,strict=True):
        assert before['reads']==after['reads'] * 2 and before['reads'] in (0,2)
        assert {k:v for k,v in before.items() if k!='reads'}=={k:v for k,v in after.items() if k!='reads'}
    assert sum(f['reads'] for f in old)==660 and sum(f['reads'] for f in new)==330
matched=sorted((base/'stock-native').glob('*.png'))
assert len(matched)==10 and all(f.read_bytes()==(base/'candidate-native'/f.name).read_bytes() for f in matched)
settings=read('candidate-settings/current-settings.json')
assert settings['failures']==0 and len(settings['weapons'])==5 and all(len(modes)==4 for modes in settings['weapons'].values())
assert read('official-release/verification.json')=={'exit':0,'errors':[],'source_held':True}
official=(base/'official-release/raw.log').read_text(encoding='utf-8')
suites=int(re.search(r'Running (\d+) groups',official)[1])
check=re.search(r'checks:\s*(\d+), new failures: 0, known failures [^:]*: 0.*wall time (\d+) s',official)
assert check and suites==31
checks,seconds=int(check[1]),int(check[2])

ticket=next((root/'pm/Nest-Egg').glob('[[]NE-275]*')).relative_to(root)
archive=Path('pm/Nest-Egg/attachments/NE-275-shared-path-2026-11-21/evidence.zip')
photos={'shared-path-glaive':'candidate-settings/glaive-normal.png',
        'shared-path-whip-reduced':'candidate-settings/whip-both.png'}
images={key:Path(f'pm/Nest-Egg/images/NE-275-{key}-20261121.png') for key in photos}
previous=(root/ticket).read_text(encoding='utf-8')
assert '# Commit-6（' in previous and '# Commit-7（' not in previous
assert not (root/archive.parent).exists() and all(not (root/file).exists() for file in images.values())
raw=[base/path for path in ('adopt.py','bundle.py','observe.gd','observe.tscn','run.py','settings.gd','settings.tscn',
                            'official-release/command.json','official-release/raw.log','official-release/verification.json')]
for scope in ('stock-headless','candidate-headless','stock-native','candidate-native','candidate-settings','official-release/shards'):
    raw.extend(file for file in sorted((base/scope).iterdir()) if file.is_file())
(root/archive).parent.mkdir()
with ZipFile(root/archive,'x',compression=ZIP_DEFLATED) as bundle:
    for file in raw:
        bundle.write(file,file.relative_to(base).as_posix())
with ZipFile(root/archive) as bundle:
    assert bundle.testzip() is None
for name,path in images.items():
    (root/path).write_bytes((base/photos[name]).read_bytes())
section=f'''
---

# Commit-7（同一物理影格共用武器路徑）

## 內文

近戰時骨架和武器原本各取一次手部路徑。同一個物理影格改為取樣一次，再把既有方向、距離、傾角交給兩者。握點與接觸面仍由當格骨架及武器姿勢更新。

### 測試結果

- 五把武器的左右出招，共比對 340 個物理影格。每輪路徑取樣由 660 次降為 330 次；招式進度、握點、武器座標與朝向逐格一致。無頭及原生流程皆相同。
- RX 9070 XT Forward+ 的十對診斷原圖逐檔一致。另在倉庫光影驗證五把武器的四種輔助設定，20 組全過，含減少閃光與減少介面動態。
- 受影響回歸 {suites} 套、{checks:,} 項全過，{seconds} 秒。本輪量測路徑呼叫與姿勢，歷史版整幀計時仍待複驗。

[原生畫面、逐格資料與正式回歸](attachments/NE-275-shared-path-2026-11-21/evidence.zip)

![正常光影下離子戰戟的握槍路徑](images/NE-275-shared-path-glaive-20261121.png)
![雙輔助設定下軟鞭的原生出招](images/NE-275-shared-path-whip-reduced-20261121.png)
'''
section=section.replace('離子戰戟的握槍路徑','離子戰戟的出招握法')
(root/ticket).write_text(previous.rstrip()+'\n\n\n'+section.lstrip('\n'),encoding='utf-8')
paths=[*map(Path,read('runtime.json')),Path('design/14-combat-variety/DESIGN.md'),ticket,archive,*images.values()]
(base/'delivery.json').write_text(json.dumps([path.as_posix() for path in paths],ensure_ascii=False,indent=2)+'\n',
                                  encoding='utf-8')
print(len(raw),(root/archive).stat().st_size)
