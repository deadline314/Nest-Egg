from hashlib import sha256
from pathlib import Path
import json,os,re,subprocess,sys

base=Path(__file__).resolve().parent
game=base.parent/'ne218-baseline-20261117'
dest=base/sys.argv[1]
dest.mkdir()
native='native' in sys.argv[2:]
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','TEMP','TMP','TMPDIR'):
    folder=dest/key
    folder.mkdir()
    env[key]=str(folder)
paths=['game/player/player_visual.gd','game/player/melee_held.gd','game/melee/melee_module.gd',
       'data/player/player_tuning.tres','art/characters/rin/character.json']
sha=lambda path:sha256((game/path).read_bytes()).hexdigest()
sources={path:sha(path) for path in paths}
argv=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(game)]
if native:
    argv=[sys.executable,'-B',str(game/'tools/comfyui/gpu_lock.py'),'--',*argv,
          '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720']
else:
    argv+=['--headless']
argv+=['--max-fps','120','--quit-after','2400',str(base/'observe.tscn'),'--','--out='+str(dest)]
(dest/'command.json').write_text(json.dumps({'argv':argv,'source':sources},indent=2)+'\n')
with (dest/'engine.log').open('wb') as f:
    result=subprocess.run(argv,env=env,cwd=game,stdout=f,stderr=subprocess.STDOUT,timeout=100)
log=(dest/'engine.log').read_text(encoding='utf-8')
assert result.returncode==0 and not re.search(r'^(?:SCRIPT )?ERROR:|^FAIL',log,re.M),log[-3500:]
assert sources=={path:sha(path) for path in paths}
rows=json.loads((dest/'path-reads.json').read_bytes())
assert not rows['failed'] and len(rows['frames'])==340
assert not native or len(list(dest.glob('*.png')))==10
print(len(rows['frames']),sum(row['reads'] for row in rows['frames']),flush=True)
