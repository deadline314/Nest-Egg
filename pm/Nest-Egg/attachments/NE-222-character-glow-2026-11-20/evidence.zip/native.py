from pathlib import Path
from hashlib import sha256
import json, os, re, shutil, subprocess, sys

p=Path(__file__).resolve().parent
root=Path.cwd()
project=Path(sys.argv[1]).resolve()
run_folder=p/sys.argv[2]
run_folder.mkdir()
work=root/'work/ne97-campaign-route-20261119'
cases=[
    ('street','native-camera-fresh-close-v1','ch1_street'),
    ('warehouse','native-camera-flood-close-v1','ch1_warehouse'),
    ('daylight','native-handoff-v2','ch2_pawnshop')]
if len(sys.argv)>3:
    cases=[case for case in cases if case[0]==sys.argv[3]]
    assert len(cases)==1
report={}
for label,folder,area in cases:
    out=run_folder/label
    save=out/'save'
    save.mkdir(parents=True)
    initial=work/folder/'save/slot.json'
    shutil.copyfile(initial,save/initial.name)
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
        (out/key).mkdir()
        env[key]=str(out/key)
    command=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
        '--path',str(project),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
        '--resolution','1280x720','--fixed-fps','60','--quit-after','600',str(p/'glow.tscn'),'--',
        '--out='+str(out),'--save-dir='+str(save),'--area='+area]
    if sys.argv[2].startswith("sweep"):
        command.append("--threshold-sweep")
    if sys.argv[2].startswith("emitters"):
        command.append("--emitter-diagnostic")
    if gains:=env.get("NE222_GLOW_GAIN_PROBE"):
        command.append("--gains="+gains)
    if masks:=env.get("NE222_GLOW_MASK_PROBE"):
        command.append("--masks="+str(p/masks))
    with (out/'engine.log').open('wb') as log:
        run=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    raw=(out/'engine.log').read_text(encoding='utf-8',errors='replace')
    errors=[line for line in raw.splitlines() if re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|^FAIL |leaked at exit',line)]
    receipt=out/'receipt.json'
    report[label]={'input_save':folder,'input_sha256':sha256(initial.read_bytes()).hexdigest(),'errors':errors,
        'exit':run.returncode,'result':json.loads(receipt.read_bytes()) if receipt.is_file() else {}}
    print(label,report[label],flush=True)
    (run_folder/'run.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
