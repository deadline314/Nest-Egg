from pathlib import Path
from hashlib import sha256
import json
import numpy as np

root=Path(__file__).resolve().parent
for file, receipt in json.loads((root/'linear-manifest.json').read_bytes()).items():
    target=root/file
    base=(root/receipt['base']).read_bytes()
    patch=(root/(file+'.xor')).read_bytes()
    assert len(base)==len(patch),file
    raw=np.bitwise_xor(np.frombuffer(base,dtype=np.uint8),np.frombuffer(patch,dtype=np.uint8)).tobytes()
    assert sha256(raw).hexdigest()==receipt['sha256'],file
    target.write_bytes(raw)
