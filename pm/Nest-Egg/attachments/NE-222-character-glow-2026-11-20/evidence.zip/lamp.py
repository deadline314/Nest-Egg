from pathlib import Path
import json, os, re, subprocess, sys

here=Path(__file__).resolve().parent
root=Path.cwd()
project=Path(sys.argv[1]).resolve()
run=here/sys.argv[2]
run.mkdir()
cases=(('vault','ch1_vault',0,False),('vault-legacy','ch1_vault',0,True),('warehouse','ch1_warehouse',0,False),('pawnshop','ch1_pawnshop_dawn',0,False))
result={}
for label,level,lamp,legacy in cases:
    case=run/label
    case.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
        (case/key).mkdir()
        env[key]=str(case/key)
    command=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
        '--path',str(project),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
        '--resolution','1280x720','--fixed-fps','60','--quit-after','300','res://tools/screenshot.tscn','--',
        '--out='+str(case),'--scenario=exposure_lamp@'+level+'@'+str(lamp)]
    if legacy:
        command.append('--legacy-exposure')
    with (case/'engine.log').open('wb') as stream:
        proc=subprocess.run(command,cwd=project,env=env,timeout=120,stdout=stream,stderr=subprocess.STDOUT)
    log=(case/'engine.log').read_text('utf-8',errors='replace')
    rows=[line for line in log.splitlines() if line.startswith('LAMP')]
    errors=[line for line in log.splitlines() if re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit',line)]
    result[label]={'rows':rows, 'exit':proc.returncode, 'error':errors}
    (run/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(label,result[label],flush=True)
    assert len(rows)==4 and proc.returncode==0
