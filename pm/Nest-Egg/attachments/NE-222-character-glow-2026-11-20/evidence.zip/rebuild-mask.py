from io import BytesIO
from pathlib import Path
import subprocess
import sys

import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt

root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
output.mkdir(parents=True, exist_ok=True)
baseline = '138af857e313e419b3b2c012ae2dfb221cf0adbe'
parts = 'art/characters/rin/parts'

def rgba(name):
    png = subprocess.check_output(['git', 'show', f'{baseline}:{parts}/{name}.png'], cwd=root)
    return np.asarray(Image.open(BytesIO(png)).convert('RGBA'))

for group, (radius, opacity) in {'foot': (3, .62), 'torso': (8, .80), 'pelvis': (13, .92)}.items():
    src = rgba(group + '_glow')
    diffuse = rgba(group)
    distance, nearest = distance_transform_edt(src[:, :, 3] == 0, return_indices=True)
    rim = np.rint(np.clip(1 - np.square((distance - 1) / radius), 0, 1) * opacity * diffuse[:, :, 3]).astype(np.uint8)
    added = (src[:, :, 3] == 0) & (rim > 0)
    result = src.copy()
    result[added, :3] = src[tuple(nearest[:, added])][:, :3]
    result[added, 3] = rim[added]
    Image.fromarray(result).save(output / f'{group}_glow.png', optimize=True)
