from pathlib import Path
import json, sys
import numpy as np

p=Path(__file__).resolve().parent
run=p/sys.argv[1]
results={}
colors=np.asarray([0.2126,0.7152,0.0722],dtype=np.float32)
for label,case in json.loads((run/'run.json').read_bytes()).items():
    if case['exit'] or case['errors']:
        print(label, 'native case incomplete',case['errors'])
        continue
    meta=case['result']['projection']
    rect=meta['region']
    x,y,width,height=rect
    def frame(name):
        array=np.fromfile(run/label/(name+'.rgba'),dtype='<f4')
        return array.reshape(height,width,4)[:,:,:3]
    def luma(array):
        return array @ colors
    baseline={kind:frame(kind+'-on') for kind in ['bloom','flat']}
    deltas={}
    for kind in ['bloom','flat']:
        deltas[kind]=np.maximum(
            np.max(np.abs(baseline[kind]-frame(kind+'-repeat')),axis=2),
            np.max(np.abs(baseline[kind]-frame(kind+'-restored')),axis=2))
    floor=np.maximum(0.003,4*np.maximum(deltas['flat'],deltas['bloom']))
    group_results={}
    for group in ['foot','torso','pelvis']:
        flat=baseline['flat']-frame('flat-without-'+group)
        with_bloom=baseline['bloom']-frame('bloom-without-'+group)
        direct=luma(flat)
        bloom_luma=luma(with_bloom)
        core=(direct>floor)
        halo=(bloom_luma>floor) & (bloom_luma-direct>floor) & ~core
        positive=run/label/("extraction-without-"+group+".rgba")
        kernel={}
        if positive.is_file():
            direct_extraction=frame("extraction-on")
            extraction=luma(direct_extraction-frame("extraction-without-"+group))
            extraction_noise=np.max(np.abs(direct_extraction-frame("extraction-restored")),axis=2)
            ring=(extraction>np.maximum(0.0003,4*extraction_noise)) & ~core
            kernel={"source":int((extraction>0.0003).sum()),"outside_emission":int(ring.sum()),
                "peak_outside_linear_luma":float(np.where(ring,extraction,0).max()),
                "peak_linear_luma":float(extraction.max()),"repeat_noise":float(extraction_noise.max())}
        bloom_difference=bloom_luma-direct
        group_results[group]={'core_pixels':int(core.sum()),'halo_pixels':int(halo.sum()),'kernel':kernel,
            'max_system_bloom_added_linear_luma':float(bloom_difference.max()),
            'max_core_linear_luma':float(direct.max()),'max_halo_added_linear_luma':float(np.where(halo,bloom_luma-direct,0).max()),
            'total_direct_linear_luma':float(np.maximum(0,direct[core]).sum())}
    center=np.array(meta['head'])-np.array([x,y])
    scale=meta['render_scale']
    yy,xx=np.mgrid[:height,:width]
    head_region=(abs(xx-center[0])<=12*scale)&(yy>=center[1]-20*scale)&(yy<=center[1]+4.0*scale)
    head=head_region&(np.max(np.abs(baseline['flat']-frame('flat-without-player')),axis=2)>0.025)
    with_all=baseline['bloom']
    without_emitters=frame('bloom-without-all')
    clipped=(with_all>0.97).all(axis=2)
    clipped_control=(without_emitters>0.97).all(axis=2)
    highlights=luma(with_all[head])
    head_data={'mask_pixels':int(head.sum()),'clipped_with_emitters':int((head&clipped).sum()),
        'clipped_without_emitters':int((head&clipped_control).sum()),
        'linear_luma_p10':float(np.percentile(highlights,10)) if len(highlights) else None,
        'linear_luma_p90':float(np.percentile(highlights,90)) if len(highlights) else None}
    stats={'area':case['result']['area'],'geometry':meta,
        'control_noise_peak':{k:float(d.max()) for k,d in deltas.items()},'groups':group_results,'head':head_data}
    print(label,json.dumps(stats),flush=True)
    results[label]=stats
(run/'analysis.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
