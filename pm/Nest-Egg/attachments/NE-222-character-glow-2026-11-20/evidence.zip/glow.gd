extends "res://tools/ch1_flow_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
const MATERIAL_NAMES := ["foot", "torso", "pelvis"]
var _store := ""
var _expected_area := ""
var _main: Node
var _rig: CharacterRig
var _groups := {}
var _clip := Rect2i()
var _geometry := {}
var _raw_format := -1
var _tuned := PackedStringArray()
var _probe_masks := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--area="):
			_expected_area = arg.trim_prefix("--area=")
		elif arg.begins_with("--gains="):
			_tuned = arg.trim_prefix("--gains=").split(",")
		elif arg.begins_with("--masks="):
			_probe_masks = arg.trim_prefix("--masks=")
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and str(_level.data.id) == _expected_area, "continue the requested native campaign area")
	if _level == null or _level.player == null:
		_finish()
		return
	var player := _level.player
	_rig = player._visual.rig
	_check(_rig != null and _rig.skin_id == "rin" and player.health.current == 6, "the saved healthy protagonist owns the original rig")
	if _rig == null:
		_finish()
		return
	_check(not Story.is_cinematic_active() and not get_tree().paused, "the saved scene is normal unpaused gameplay")
	_collect_glow()
	if not _probe_masks.is_empty():
		for group: String in MATERIAL_NAMES:
			var path := _probe_masks.path_join(group + "_glow.png")
			if not FileAccess.file_exists(path):
				continue
			var mask := Image.load_from_file(path)
			mask.generate_mipmaps()
			for emitter: CanvasItem in _groups[group]:
				emitter.set("texture", ImageTexture.create_from_image(mask))
	if _tuned.size() == 3:
		for index in MATERIAL_NAMES.size():
			var group: String = MATERIAL_NAMES[index]
			var multiplier := float(_tuned[index])
			for emitter: CanvasItem in _groups[group]:
				var color := emitter.self_modulate
				emitter.self_modulate = Color(color.r * multiplier, color.g * multiplier, color.b * multiplier, color.a)
	_level.hud.hide()
	_capture("gameplay-before-controls")
	var env := LightKit.environment()
	var old_time_scale := Engine.time_scale
	var glow_enabled := env.glow_enabled
	_check(glow_enabled and env.glow_intensity > 0.0 and get_viewport().use_hdr_2d, "capture uses the normal Forward+ bloom and HDR canvas")
	var bright := env.glow_intensity
	var old_threshold := env.glow_hdr_threshold
	var old_bloom := env.glow_bloom
	var old_mode := env.glow_blend_mode
	get_tree().paused = true
	Engine.time_scale = 0.00001
	await RenderingServer.frame_post_draw
	var original := get_viewport().get_texture().get_image()
	var canvas := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	var scale := canvas.get_scale().x
	var feet := canvas * player.global_position
	var head := canvas * _rig.bone(&"head").global_position
	_clip = Rect2i(Vector2i(feet - Vector2(54.0, 110.0) * scale),
		Vector2i(Vector2(108.0, 133.0) * scale)).intersection(Rect2i(Vector2i.ZERO, original.get_size()))
	_check(_clip.has_area() and _clip.has_point(Vector2i(feet)) and _clip.has_point(Vector2i(head)), "the same native crop encloses the real head and feet")
	_geometry = {"region": [_clip.position.x, _clip.position.y, _clip.size.x, _clip.size.y],
		"image_size": [original.get_width(), original.get_height()], "render_scale": scale,
		"head": [head.x, head.y], "feet": [feet.x, feet.y], "character_fill": LightKit.character_fill,
		"player_light": LightKit.player_light_energy, "bloom": bright, "threshold": old_threshold, "probe_gains": Array(_tuned),
		"environment_is_active": get_viewport().find_world_3d().environment == env, "disable_3d": get_viewport().disable_3d,
		"environment_canvas_max_layer": env.background_canvas_max_layer,
		"lighting_cap": _rig._light_cap}
	if _clip.has_area():
		for bloom: bool in [true, false]:
			env.glow_enabled = bloom
			env.glow_intensity = bright if bloom else 0.0
			await _settle(4)
			var label := "bloom" if bloom else "flat"
			await _record(label + "-on")
			await _record(label + "-repeat")
			for group: String in MATERIAL_NAMES:
				_set_glow(group, false)
				await _record(label + "-without-" + group)
				_set_glow(group, true)
			for group: String in MATERIAL_NAMES:
				_set_glow(group, false)
			await _record(label + "-without-all")
			for group: String in MATERIAL_NAMES:
				_set_glow(group, true)
			await _record(label + "-restored")
			if not bloom:
				player.hide()
				await _record("flat-without-player")
				player.show()
		env.glow_enabled = glow_enabled
		env.glow_intensity = bright
		env.glow_blend_mode = Environment.GLOW_BLEND_MODE_REPLACE
		await _settle(5)
		await _record("extraction-on")
		for group: String in MATERIAL_NAMES:
			_set_glow(group, false)
			await _record("extraction-without-" + group)
			_set_glow(group, true)
		await _record("extraction-restored")
		if "--threshold-sweep" in OS.get_cmdline_user_args():
			env.glow_blend_mode = old_mode
			for threshold: float in [0.95, 0.85, 0.75, 0.65, 0.55]:
				env.glow_hdr_threshold = threshold
				await _settle(4)
				var tune := "threshold-" + str(int(round(threshold * 100.0)))
				await _record(tune + "-on")
				for group: String in MATERIAL_NAMES:
					_set_glow(group, false)
					await _record(tune + "-without-" + group)
					_set_glow(group, true)
				await _record(tune + "-repeat")
		env.glow_enabled = true
		env.glow_intensity = 1.0
		env.glow_bloom = 1.0
		env.glow_hdr_threshold = 0.0
		env.glow_blend_mode = Environment.GLOW_BLEND_MODE_REPLACE
		await _settle(5)
		await _record("positive-bloom-only")
		if "--emitter-diagnostic" in OS.get_cmdline_user_args():
			for group: String in MATERIAL_NAMES:
				_set_glow(group, false)
			await _record("positive-without-emitters")
			for group: String in MATERIAL_NAMES:
				_set_glow(group, true)
			env.glow_bloom = old_bloom
			env.glow_hdr_threshold = old_threshold
			env.glow_intensity = bright
			var canvas_max := env.background_canvas_max_layer
			env.background_canvas_max_layer = 100
			await _settle(5)
			await _record("wide-layer-extraction")
			for group: String in MATERIAL_NAMES:
				_set_glow(group, false)
			await _record("wide-layer-without-emitters")
			for group: String in MATERIAL_NAMES:
				_set_glow(group, true)
			env.background_canvas_max_layer = canvas_max
			var original_modulation := {}
			for group: String in MATERIAL_NAMES:
				for glow: CanvasItem in _groups[group]:
					original_modulation[glow] = glow.self_modulate
			for multiplier: float in [1.5, 2.0, 3.0, 4.0]:
				for node: CanvasItem in original_modulation:
					var color: Color = original_modulation[node]
					node.self_modulate = Color(color.r * multiplier, color.g * multiplier, color.b * multiplier, color.a)
				var label := "gain-" + str(int(round(multiplier * 100.0)))
				await _settle(4)
				await _record(label + "-extraction")
				for group: String in MATERIAL_NAMES:
					_set_glow(group, false)
					await _record(label + "-without-" + group)
					_set_glow(group, true)
			for node: CanvasItem in original_modulation:
				node.self_modulate = original_modulation[node]
	env.glow_enabled = glow_enabled
	env.glow_intensity = bright
	env.glow_bloom = old_bloom
	env.glow_hdr_threshold = old_threshold
	env.glow_blend_mode = old_mode
	Engine.time_scale = old_time_scale
	get_tree().paused = false
	_finish()


func _collect_glow() -> void:
	for group: String in MATERIAL_NAMES:
		_groups[group] = []
	for part: CanvasItem in _rig._parts:
		for child: Node in part.get_children():
			if not (child is Sprite2D or child is Polygon2D):
				continue
			var texture := child.get("texture") as Texture2D
			if texture == null:
				continue
			for group: String in MATERIAL_NAMES:
				if texture.resource_path.get_file() == group + "_glow.png":
					_groups[group].append(child)
					_check((child as CanvasItem).is_visible_in_tree() and (child as CanvasItem).light_mask == 0,
						"the real additive emitter is enabled on %s" % part.name)
	for group: String in MATERIAL_NAMES:
		_check(_groups[group].size() == (2 if group == "foot" else 1), "find the authored %s emitters" % group)


func _set_glow(group: String, enabled: bool) -> void:
	for node: CanvasItem in _groups[group]:
		node.visible = enabled


func _record(label: String) -> void:
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var raw := get_viewport().get_texture().get_image()
	_raw_format = raw.get_format()
	_check(_raw_format in [Image.FORMAT_RGBH, Image.FORMAT_RGBAH, Image.FORMAT_RGBF, Image.FORMAT_RGBAF], "read live linear HDR frame " + label)
	var crop := raw.get_region(_clip)
	crop.convert(Image.FORMAT_RGBAF)
	var file := FileAccess.open(_out_dir.path_join(label + ".rgba"), FileAccess.WRITE)
	file.store_buffer(crop.get_data())
	file.close()
	if label == "bloom-on" or label == "bloom-without-all":
		_check(CAPTURE.encode(raw, get_viewport().use_hdr_2d).save_png(_out_dir.path_join(label + ".png")) == OK, "save native frame " + label)


func _finish() -> void:
	var file := FileAccess.open(_out_dir.path_join("receipt.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"area": _expected_area, "failures": _failures, "projection": _geometry,
		"format": _raw_format}, "  ") + "\n")
	file.close()
	_main.call("_quit", 0 if _failures == 0 else 1)
