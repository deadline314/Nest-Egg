extends Node

func _ready() -> void:
	var target := Node2D.new()
	add_child(target)
	var controller := LightingController.new()
	add_child(controller)
	var zone := LightingZone.new()
	zone.profile = load("res://data/lighting/warehouse_interior.tres")
	controller.setup([zone], 16, target, null, null, null, Color.BLACK)
	controller.set_process(false)
	var rows: Array = []
	rows.append(sample("baseline", controller))
	controller.flash(Color.WHITE, 1.0, 0.18)
	controller.snap()
	rows.append(sample("full_flash", controller))
	controller._process(0.2)
	rows.append(sample("recovered", controller))
	print(JSON.stringify(rows))
	var valid: bool = rows[0].original_condition and not rows[1].original_condition and rows[2].original_condition
	controller.queue_free()
	await get_tree().process_frame
	get_tree().quit(0 if valid else 1)

func sample(phase: String, controller: LightingController) -> Dictionary:
	return {"phase":phase, "ambient":LightKit.ambient_luma, "flash":controller.flash_level(),
		"character_fill":LightKit.character_fill, "enemy_fill":LightKit.enemy_fill,
		"original_condition":LightKit.character_fill > 1.0 and LightKit.enemy_fill < LightKit.character_fill and LightKit.enemy_fill >= 1.0}
