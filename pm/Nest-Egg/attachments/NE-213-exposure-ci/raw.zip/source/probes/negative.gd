extends "res://tests/smoke_test.gd"

func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var source := load("res://data/lighting/warehouse_interior.tres") as LightingProfile
	var original := source.enemy_fill_scale
	source.enemy_fill_scale = 1.0
	await ExposureSuite.new(self)._test_enemy_fill_is_separate()
	source.enemy_fill_scale = original
	await _finish()
