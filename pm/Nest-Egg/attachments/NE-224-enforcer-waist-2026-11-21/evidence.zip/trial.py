from pathlib import Path
from math import pi, sin
from PIL import Image
import numpy as np

target=Path(__file__).resolve().parent/'torso-trial.png'
original=np.asarray(Image.open('art/characters/enforcer/parts/torso.png').convert('RGBA'))
candidate=original.copy()
for row in range(223,254):
    depth=round(7*max(0.0,sin(pi*(row-223)/30))**0.65)
    span=candidate[row,236:250]
    extension=original[row,236-depth:250-depth]
    selected=(span[:,3]<235) & (extension[:,3]>span[:,3])
    span[selected]=extension[selected]
assert np.array_equal(original[original[:,:,3]>=235],candidate[original[:,:,3]>=235])
print('updated',np.count_nonzero(np.any(candidate!=original,axis=2)))
Image.fromarray(candidate).save(target)
