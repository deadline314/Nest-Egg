
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json

import numpy as np
from PIL import Image

base = Path(__file__).resolve().parent
root = Path.cwd()
def read(path):
    return json.loads(path.read_bytes())
def key(failure):
    return tuple(failure[k] for k in ('char','joint','pose','zoom','facing','frame'))
def gap(failure):
    return failure['center_alpha'] < 128 or failure['enclosed_pixels'] or failure['loose_pieces']
def digest(path):
    return sha256(path.read_bytes()).hexdigest()

results = {}
for scope, count in (('dressed',3840), ('isolated',3840), ('whole',3840), ('neck',3840), ('adjacent',5760)):
    old,new=(read(base/f'{mode}-{scope}'/'report.json') for mode in ('stock','final'))
    assert old['samples'] == new['samples'] == count
    old_flags,new_flags=({key(f) for f in report['failures']} for report in (old,new))
    old_gaps,new_gaps=({key(f) for f in report['failures'] if gap(f)} for report in (old,new))
    results[scope] = {'samples':count, 'before':[len(old_flags),len(old_gaps)], 'after':[len(new_flags),len(new_gaps)],
                      'new_flags':sorted(new_flags-old_flags), 'new_gaps':sorted(new_gaps-old_gaps),
                      'remaining_gaps_by_pose':dict(Counter(f[2] for f in new_gaps))}
print(json.dumps(results, indent=2))
for scope,data in results.items():
    assert not data['new_flags'] and not data['new_gaps'], (scope,data)
assert all(results[scope]['after'][1] == new and results[scope]['before'][1] == old
           for scope,old,new in (('dressed',304,0), ('isolated',0,0), ('whole',20,2), ('neck',70,2), ('adjacent',272,270)))
for scope in ('dressed','isolated','whole','neck','adjacent','damage'):
    assert 'ERROR:' not in (base/f'final-{scope}.log').read_text(encoding='utf-8'), scope
for filename in ('normal.log','import.log','cut-check/cut.log'):
    assert 'ERROR:' not in (base/filename).read_text(encoding='utf-8'), filename
assert read(base/'official-release/verification.json') == {'exit':0,'errors':[],'source_held':True}
parts = root/'art/characters/enforcer/parts'
source = root/'art_src/characters/enforcer'
assert digest(parts/'torso.png') == digest(source/'overrides/torso.png') == digest(base/'torso-trial.png')
assert digest(parts/'torso_n.png') == digest(base/'normal-after.png')
assert digest(source/'neck_overlap/torso-before.png') == digest(base/'cut-check/enforcer/parts/torso.png')
assert digest(base/'normal-before.png') == digest(base/'normal-before-rebuilt.png')
old, new, old_normal, new_normal = (np.asarray(Image.open(p).convert('RGBA')) for p in
    (base/'torso-before.png', parts/'torso.png', base/'normal-before.png', parts/'torso_n.png'))
changed = np.any(old != new, axis=2)
assert changed.sum() == 148 and np.array_equal(new[:,:,3], new_normal[:,:,3])
assert np.all(old[changed,3] < 235) and np.all(old[changed,3] < new[changed,3])
results['source'] = {'previous':digest(base/'torso-before.png'), 'diffuse':digest(parts/'torso.png'),
                     'normal':digest(parts/'torso_n.png'), 'diffuse_pixels':int(changed.sum()),
                     'normal_pixels':int(np.any(old_normal != new_normal,axis=2).sum()), 'grid':list(new.shape[:2][::-1])}
(base/'verification.json').write_text(json.dumps(results,indent=2)+'\n', encoding='utf-8')

