
from pathlib import Path
from PIL import Image, ImageDraw
import json

base=Path(__file__).resolve().parent
sheet=Image.new('RGB',(520,487),(32,35,46))
draw=ImageDraw.Draw(sheet)
for row,(view,pose,frame,cx,cy) in enumerate((('whole','dead',13,49,42),('dressed','stagger',12,85,49))):
    for column,mode in enumerate(('stock','final')):
        stage=base/f'{mode}-{view}'
        groups=json.loads((stage/'frames.json').read_bytes())
        group=next(g for g in groups if g['pose']==pose and g['zoom']==3.4)
        x,y,_,_=next(c['rect'] for c in group['cells'] if c['facing']==1)
        with Image.open(stage/group['samples'][frame]['file']) as source:
            crop=source.crop((x+cx-26,y+cy-26,x+cx+26,y+cy+26)).convert('RGBA')
        background=Image.new('RGBA',crop.size,(145,156,175,255))
        background.alpha_composite(crop)
        offset=(8+column*260,8+row*242)
        draw.text(offset,f'{"Before" if column==0 else "With overlap"} / {pose} / 3.4x',fill='#f9fafc')
        sheet.paste(background.resize((220,220),Image.Resampling.NEAREST).convert('RGB'),(offset[0],offset[1]+17))
sheet.save(base/'waist-compare.png')

