from pathlib import Path
import json

from PIL import Image, ImageDraw

base=Path(__file__).resolve().parent
sheet=Image.new("RGB",(520,530),"#232838")
draw=ImageDraw.Draw(sheet)
values={}
for row,face in enumerate((1,-1)):
    for col,mode in enumerate(("full-stock","final")):
        directory=base/(mode+"-dressed")
        frames=json.loads((directory/"frames.json").read_bytes())
        group=next(item for item in frames if item["pose"]=="aim_up" and item["zoom"]==3.4)
        x,y,_,_=next(cell["rect"] for cell in group["cells"] if cell["facing"]==face)
        local_x=84 if face==1 else 43
        local_y=69
        with Image.open(directory/group["samples"][2]["file"]) as png:
            frame=png.convert("RGBA")
            alpha=frame.getpixel((x+local_x,y+local_y))[3]
            crop=frame.crop((x+local_x-23,y+local_y-23,x+local_x+23,y+local_y+23))
        assert (alpha<128)==(mode=="full-stock"),(mode,face,alpha)
        values[f"{mode}:{face}"]=alpha
        background=Image.new("RGBA",crop.size,"#a5adc0")
        background.alpha_composite(crop)
        left=12+258*col
        top=10+260*row
        draw.text((left,top),f"{'Before' if col==0 else 'Repaired'} / {'right' if face==1 else 'left'}",fill="#f2f5fa")
        sheet.paste(background.convert("RGB").resize((230,230),Image.Resampling.NEAREST),(left,top+20))
sheet.save(base/"aim-up-comparison.png")
(base/"aim-up-opacity.json").write_text(json.dumps(values,indent=2)+"\n")
print(values)
