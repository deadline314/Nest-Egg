param([Parameter(Mandatory)][string]$Tag)
$ErrorActionPreference='Stop'
$root='C:/Users/stanl/Github/Nest-Egg'
$verify='D:/NestEggVerification/ne218-baseline-20261117'
$tool='D:/NestEggVerification/evidence-20261121-ne224-enforcer-upper-limbs'
$ev=$PSScriptRoot.Replace('\','/')
$py='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
$godot='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$common=@('--path',$verify,'--rendering-method','forward_plus','--rendering-driver','vulkan','--resolution','1280x720','--max-fps','120','--audio-driver','Dummy','--quit-after','9000')
$env:APPDATA="$ev/$Tag-adjacent-profile/AppData"
$env:LOCALAPPDATA="$ev/$Tag-adjacent-profile/Local"
$out="$ev/$Tag-adjacent"
& $py -B "$root/tools/comfyui/gpu_lock.py" -- $godot @common "$tool/probe.tscn" -- "--out=$out" --chars=enforcer '--joints=neck,hip_front,hip_back,shoulder_front,shoulder_back' --frames=36 --diagnostic-whole-rig *> "$out.log"
if($LASTEXITCODE -ne 0 -or (Select-String -Pattern 'ERROR:' -Quiet -LiteralPath "$out.log")){throw "Native adjacent capture failed: $out"}
& $py -B "$root/tools/check_joint_frames.py" $out *> "$out-check.log"
if($LASTEXITCODE -gt 1){throw "Adjacent geometry audit is incomplete: $out"}
Get-Content -LiteralPath "$out-check.log" -TotalCount 2
