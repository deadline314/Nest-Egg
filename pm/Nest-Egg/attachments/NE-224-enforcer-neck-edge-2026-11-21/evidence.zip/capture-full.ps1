param([string[]]$Modes=@('stock','80'),[int]$Frames=120)
$ErrorActionPreference='Stop'
$root='C:/Users/stanl/Github/Nest-Egg'
$verify='D:/NestEggVerification/ne218-baseline-20261117'
$tool='D:/NestEggVerification/evidence-20261121-ne224-enforcer-upper-limbs'
$ev=$PSScriptRoot.Replace('\','/')
$py='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
$godot='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$common=@('--path',$verify,'--rendering-method','forward_plus','--rendering-driver','vulkan','--resolution','1280x720','--max-fps','120','--audio-driver','Dummy','--quit-after','9000')
foreach($Mode in $Modes){
  $env:APPDATA="$ev/$Mode-profile/AppData"
  $env:LOCALAPPDATA="$ev/$Mode-profile/Local"
  foreach($kind in @('dressed','isolated','whole')){
    $out="$ev/full-$Mode-$kind"
    $extra=@()
    if($kind -eq 'isolated'){$extra+='--pair-only'}
    if($kind -eq 'whole'){$extra+='--diagnostic-whole-rig'}
    if($Mode -ne 'stock'){$extra+="--diagnostic-part-texture=torso:$ev/torso-$Mode.png"}
    & $py -B "$root/tools/comfyui/gpu_lock.py" -- $godot @common "$tool/mip-probe.tscn" -- "--out=$out" --chars=enforcer --joints=neck "--frames=$Frames" @extra *> "$out.log"
    if($LASTEXITCODE -ne 0 -or (Select-String -Pattern 'ERROR:' -Quiet -LiteralPath "$out.log")){throw "Native capture failed: $out"}
    & $py -B "$root/tools/check_joint_frames.py" $out *> "$out-check.log"
    if($LASTEXITCODE -gt 1){throw "Geometry audit is incomplete: $out"}
    Get-Content -LiteralPath "$out-check.log" -TotalCount 2
  }
}


