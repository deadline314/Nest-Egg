from collections import Counter
from pathlib import Path
import json
import sys

base=Path(__file__).resolve().parent
rows={}
for mode in sys.argv[1:]:
    rows[mode]={}
    for kind in ("dressed","isolated","whole"):
        report=base/f"{mode}-{kind}"/"report.json"
        if not report.is_file():
            continue
        data=json.loads(report.read_bytes())
        flags={(r["pose"],r["zoom"],r["facing"],r["frame"]):bool(
            r["center_alpha"]<128 or r["enclosed_pixels"] or r["loose_pieces"]) for r in data["failures"] if r["joint"]=="neck"}
        rows[mode][kind]=flags
for kind,old in rows.get(sys.argv[1],{}).items():
    print(kind,"stock",len(old),sum(old.values()))
    for mode,reports in rows.items():
        if mode==sys.argv[1] or kind not in reports:
            continue
        after=reports[kind]
        print(mode,len(after),sum(after.values()),"new flags",len(set(after)-set(old)),
              "gaps by pose",dict(Counter(key[0] for key,true in after.items() if true)),
              "new real gaps",sorted(key for key,true in after.items() if true and not old.get(key,False)))

