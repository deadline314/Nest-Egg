from hashlib import sha256
from pathlib import Path
from PIL import Image
import numpy as np

root=Path.cwd()
base=Path(__file__).resolve().parent
source=root/"art/characters/enforcer/parts/torso.png"
with Image.open(source) as image:
    prior=np.asarray(image.convert("RGBA")).copy()
assert prior[115,229,3]==prior[115,230,3]==0
assert np.all(prior[114,229:231,3]>=235)
for alpha in (80,110,145):
    candidate=prior.copy()
    candidate[115,229:231,:3]=prior[114,229:231,:3]
    candidate[115,229:231,3]=alpha
    assert np.count_nonzero(np.any(prior!=candidate,axis=2))==2
    with (base/f"torso-{alpha}.png").open("xb") as output:
        Image.fromarray(candidate).save(output,format="PNG")
print(sha256(source.read_bytes()).hexdigest())
