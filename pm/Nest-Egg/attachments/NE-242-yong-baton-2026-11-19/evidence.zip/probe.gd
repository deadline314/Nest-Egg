extends ScenarioBase

var _boss: PatternBoss
var _tag := ""
var _records: Dictionary = {}


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
		elif argument.begins_with("--tag="):
			_tag = argument.trim_prefix("--tag=")
	if not out_dir.is_absolute_path() or _tag.is_empty():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	level = Level.new()
	level.configure(load("res://data/levels/ch2_ledger_office.tres") as LevelData)
	add_child(level)
	player = level.player
	level._next_story_trigger = level._layout.story_triggers.size()
	for entity in level._entities.get_children():
		if entity is PatternBoss and entity.data.id == &"yong":
			_boss = entity
	if _boss == null:
		push_error("the authored ledger office does not have Yong")
		get_tree().quit(2)
		return
	var baton = _boss.get("_baton_texture")
	if _tag == "after" or _tag == "live":
		_verify(baton is Texture2D and baton.resource_path == "res://art/weapons/yong_baton.png", "the official boss uses the authored baton")
	else:
		_verify(baton == null, "the untextured cases reach the original fallback")
	player.set_physics_process(false)
	player.health.grant_invulnerability(100.0)
	_boss.set_physics_process(false)
	level.hud.visible = false
	if _boss.mark != null:
		_boss.mark.stop()
	_boss.call(&"_wake")
	if _tag == "live":
		await _live_windups()
	else:
		await _static_states()
	var size := get_window().size
	var report := {"tag": _tag, "records": _records, "failures": failures,
		"size": [size.x, size.y], "adapter": RenderingServer.get_video_adapter_name()}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)


func _static_states() -> void:
	for facing in [-1, 1]:
		var side := "left" if facing == -1 else "right"
		_boss.facing = facing
		player.global_position = _boss.global_position + Vector2(facing * 44.0, 0.0)
		snap_camera()
		await settle(30)
		_boss.fsm.transition(&"idle")
		await _record(side + "-idle")
		_boss.set("_move_id", &"slam")
		_boss.fsm.transition(&"windup")
		_boss.fsm.time_in_state = 0.36
		await _record(side + "-windup")
	_boss.call(&"_enter_subdue", "subdue", false)
	_boss.fsm.transition(&"idle")
	await _record("before-disarm")
	var lock: Hurtbox
	for part in _boss.hurtbox.parts:
		if part.part_id == &"baton_lock":
			lock = part
	_verify(lock != null and _boss.is_part_open(&"baton_lock"), "the authored latch is available in the subdue phase")
	if lock != null:
		for index in 3:
			var hit := DamageInfo.create(1, Combat.Team.PLAYER, &"baton_probe")
			hit.ignore_invulnerability = true
			lock.receive(hit)
			await settle(2)
	_verify(_boss.call(&"is_disarmed") and _boss.phase_set.begins_with("disarmed"), "three actual hits on the latch disarm Yong")
	await settle(30)
	await _record("after-disarm")


func _live_windups() -> void:
	for facing in [-1, 1]:
		var side := "left" if facing == -1 else "right"
		_boss.facing = facing
		player.global_position = _boss.global_position + Vector2(facing * 44.0, 0.0)
		snap_camera()
		await settle(20)
		_boss.fsm.transition(&"idle")
		_boss.set("_move_id", &"slam")
		_boss.fsm.transition(&"windup")
		_boss.set_physics_process(true)
		for index in range(1, 4):
			for tick in 9:
				await get_tree().physics_frame
			await RenderingServer.frame_post_draw
			var input: RigInput = _boss.get("_rig_input") as RigInput
			_verify(_boss.fsm.is_in(&"windup") and _boss.facing == facing and input.action == &"yong.windup_overhead",
				"the rendered pose comes from the actual slam windup")
			_capture_record("%s-live-%d" % [side, index])
		_boss.set_physics_process(false)


func _record(label: String) -> void:
	_boss.call(&"_drive_rig", 0.0)
	_boss.queue_redraw()
	await settle(3)
	await RenderingServer.frame_post_draw
	_capture_record(label)


func _capture_record(label: String) -> void:
	var hand := _boss.anchor_node(&"hand_front").global_position
	var arm := _boss.anchor_node(&"arm_front_lower").global_position
	var direction := (hand - arm).normalized() if hand.distance_to(arm) > 0.1 else Vector2(_boss.facing, 0.0)
	var tip := hand + direction * 24.0
	var transform := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	var screen: Vector2 = transform * tip
	var raw := get_viewport().get_texture().get_image()
	var tip_color := raw.get_pixelv(Vector2i(screen.floor())) if Rect2(Vector2.ZERO, Vector2(raw.get_size())).has_point(screen) else Color.WHITE
	_records[label] = {"hand": [hand.x, hand.y], "tip": [tip.x, tip.y], "screen_tip": [screen.x, screen.y],
		"tip_red": tip_color.r - maxf(tip_color.g, tip_color.b), "facing": _boss.facing,
		"disarmed": _boss.call(&"is_disarmed"), "state": _boss.fsm.current, "health": _boss.health.current,
		"phase_seconds": _boss.fsm.time_in_state}
	capture(label)


func _verify(condition: bool, label: String) -> void:
	if not condition:
		failures += 1
		push_error(label)
