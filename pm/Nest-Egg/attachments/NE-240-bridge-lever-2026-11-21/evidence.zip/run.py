from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
label, *args = sys.argv[1:]
out = base / label
out.mkdir()
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    path = out / key
    path.mkdir()
    env[key] = str(path)
seed = base.parent / "evidence-20261121-st19-reconcile-source-map/candidate-release-zh/slot.json"
custom = [arg for arg in args if arg.startswith("--seed=")]
if custom:
    assert len(custom) == 1
    seed = Path(custom[0].removeprefix("--seed="))
    args.remove(custom[0])
slot = out / "slot.json"
copy2(seed, slot)
paths = [
    "data/story/ch2_heron.json", "data/cutscene/world_prop_actions.json", "data/levels/ch2_loading.tres",
    "data/levels/ch2_loading_map.json", "data/npcs/ch2_sc1_lever.tres",
    "art/environment/scene_props/dock_warehouse/dock_warehouse__bridge_lever.png",
    "data/environment/prop_reactions.json", "game/player/world_prop_action.gd", "autoload/story.gd",
]
sha = lambda path: sha256(path.read_bytes()).hexdigest()
source = {p: sha(game / p) for p in paths}
seed_sha = sha(seed)
command = [sys.executable, "-B", str(game / "tools/comfyui/gpu_lock.py"), "--",
           "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(game),
           "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--audio-driver", "Dummy",
           "--fixed-fps", "60", "--resolution", "1280x720", "--quit-after", "4800", str(base / "observe.tscn"),
           "--", f"--out={out}", f"--slot={slot}", *args]
(out / "command.json").write_text(json.dumps({"argv": command, "source": source, "seed_sha256": seed_sha}, indent=2) + "\n", encoding="utf-8")
with (out / "engine.log").open("wb") as log:
    process = subprocess.run(command, cwd=game, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=200)
raw = (out / "engine.log").read_text(encoding="utf-8", errors="replace")
print(raw[-8000:], flush=True)
assert all(sha(game / p) == digest for p, digest in source.items()) and sha(seed) == seed_sha
assert process.returncode == 0 and not re.search(r"^SCRIPT ERROR:|^ERROR:|optional world action unavailable|^FAIL", raw, re.M)
report = json.loads((out / "result.json").read_bytes())
assert report["hdr"] and "9070 XT" in report["adapter"] and report["failures"] == 0
assert report["credits"]==1274
print(report, flush=True)
