extends "res://tools/ch1_flow_probe.gd"

const LOADING := "res://data/levels/ch2_loading.tres"
const SCENE := &"ch2_t_s09_lever"
const REVISIT := &"ch2_t_s09_lever_revisit"
const MARKET := "res://data/levels/ch2_market.tres"
const PORTAL := &"loading_sc1"
const FLAG := &"ch2_sc1_open"
const ACTION := "loading_bridge_lever"
const ACTION_PATH := "D:/NestEggVerification/evidence-20261121-ne240-bridge-lever/approved-action.json"
const LADDER := "dock_warehouse__bridge_ladder_up"
const LEVER := "dock_warehouse__bridge_lever"
var _app: Node
var _store: RunSaveStore
var _side := -1.0
var _prototype := false
var _lang := "zh"
var _skip := false
var _revisit := false
var _cross := false
var _counts := 0
var _measure := {}
var _phases: Array[String] = []


func _run() -> void:
	var slot := ""
	var action_path := ACTION_PATH
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--slot="):
			slot = arg.trim_prefix("--slot=")
		elif arg.begins_with("--action="):
			action_path = arg.trim_prefix("--action=")
		elif arg == "--prototype":
			_prototype = true
		elif arg == "--revisit":
			_revisit = true
		elif arg == "--cross":
			_cross = true
		elif arg == "--right":
			_side = 1.0
		elif arg == "--skip":
			_skip = true
		elif arg.begins_with("--lang="):
			_lang = arg.trim_prefix("--lang=")
	if not slot.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	_store = RunSaveStore.new(slot)
	_app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_app.set("_run_store", _store)
	add_child(_app)
	Story.auto_skip = false
	for _frame in STEP_LIMIT:
		if _app.get("_screen") is MainMenu and not bool(_app.call("_route_pending")):
			break
		await get_tree().process_frame
	var menu := _app.get("_screen") as MainMenu
	if menu == null or not Story.set_language(_lang):
		_finish(false)
		return
	await _settle(6)
	menu._continue_button.pressed.emit()
	for _frame in STEP_LIMIT:
		var level := _app.get("_screen") as Level
		if level != null and level.is_initialized() and not bool(_app.call("_route_pending")):
			_level = level
			break
		await get_tree().process_frame
	if _level == null or _level.data.resource_path != LOADING:
		_finish(false)
		return
	_check(GameState.has_flag(FLAG) == _revisit and _store.read().get("level", "") == LOADING, "authentic saved bridge state on opening")
	var text := FileAccess.get_file_as_string(action_path).trim_prefix("\ufeff")
	var definition := JSON.parse_string(text) as Dictionary
	if _prototype:
		WorldPropAction.definition("audit_terminal_submit")
		WorldPropAction._table[ACTION] = definition
		Story._scenes[String(SCENE)]["steps"].push_front({"do":"world_action","id":ACTION})
		_check(WorldPropAction.problem(ACTION, String(SCENE), true).is_empty(), "existing action registry accepts the stage contact")
	var stage_steps: Array = Story._scenes[String(SCENE)]["steps"]
	var expect_action: bool = not _revisit and not stage_steps.is_empty() and stage_steps[0].get("id", "") == ACTION
	var lever: NpcActor
	for child: Node in _level._entities.get_children():
		if child is NpcActor and child.data.id == &"ch2_sc1_lever":
			lever = child
			break
	var box: PropNode
	var ladder: PropReaction
	for child: Node in get_tree().get_nodes_in_group(PropNode.GROUP):
		var prop := child as PropNode
		if not _level.is_ancestor_of(prop):
			continue
		if String(prop.data.id) == LEVER:
			box = prop
		elif String(prop.data.id) == LADDER:
			for reaction in prop.get_children():
				if reaction is PropReaction:
					ladder = reaction
					break
	var gate := _level._portals.get(PORTAL) as Portal
	if lever == null or box == null or ladder == null or gate == null:
		_finish(false)
		return
	_check(gate.is_open() == _revisit and ladder.is_swapped() == _revisit, "authored bridge and portal match the saved state")
	var player := _level.player
	if _revisit:
		for _frame in 5:
			await get_tree().physics_frame
		_measure["cold_spawn"] = _vector(player.global_position)
		_measure["cold_gate"] = _vector(gate.global_position)
		_measure["cold_armed"] = gate.is_armed()
		_measure["cold_in_range"] = gate._player_in_range
	var arena := lever.global_position
	_measure["lever"] = _vector(arena)
	_measure["box"] = _vector(box.global_position)
	_measure["box_size"] = _vector(box.data.size)
	_measure["target"] = _vector(box.to_global(Vector2(float(definition["button"][0]),float(definition["button"][1]))))
	var old_items := StoryItems.snapshot()
	var old_credits := Progression.credits
	player.global_position = arena + Vector2(_side * 21, -2.0)
	player.velocity = Vector2.ZERO
	_level.camera.snap_to_target()
	for _frame in 65:
		if lever.interaction_available() and player.is_on_floor():
			break
		await get_tree().physics_frame
	_measure["player_ground"] = _vector(player.global_position)
	_measure["station_reachable"] = WorldPropAction.route_clear(player, box.to_global(Vector2(float(definition["station"][0]),float(definition["station"][1]))))
	_check(lever.interaction_available() and player.is_on_floor(), "actual lever prompt offers interaction")
	_capture("lever-before")
	await _tap(&"interact")
	var action: WorldPropAction
	var caption := ""
	var interrupted := false
	var selected := REVISIT if _revisit else SCENE
	for frame in STEP_LIMIT:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var cutscene := Story._player
		if not is_instance_valid(cutscene) or not cutscene.is_running():
			if GameState.has_flag(FLAG) and (interrupted or not caption.is_empty()):
				break
			continue
		if cutscene.scene_id != selected:
			continue
		if player._visual.interaction_action is WorldPropAction:
			action = player._visual.interaction_action
			if not action.phase in _phases:
				_phases.append(action.phase)
			if action.phase == "press" and action._elapsed > 0.39 and not _measure.has("press_sample"):
				_measure["press_sample"] = action.contact_error
				_measure["press_palm"] = _vector(player._visual.rig.hand_contact_global(&"front"))
				_measure["press_root"] = _vector(player.global_position)
				_capture("lever-press-attempt")
			if action.contacts_completed > 0 and not _measure.has("contact_metric"):
				_measure["contact_metric"] = action.contact_error
				_measure["palm"] = _vector(player._visual.rig.hand_contact_global(&"front"))
				_check(not GameState.has_flag(FLAG), "contact itself does not commit the bridge")
				_capture("lever-on-contact")
			if _skip and not interrupted and action.phase == "press":
				interrupted = true
				await _tap(&"ui_cancel")
				continue
		if cutscene._dialogue.visible and cutscene._dialogue.is_complete():
			caption = cutscene._dialogue._text.text
			_capture("lever-original-line")
			await _tap(&"ui_accept")
	for _frame in 120:
		if gate.is_open() and ladder.is_swapped() and _store.read().get("story", {}).get("flags",{}).get(String(FLAG),false):
			break
		await get_tree().process_frame
	_check(GameState.has_flag(FLAG) and gate.is_open() and ladder.is_swapped(), "original story flag opens the portal and displays the unfolded ladder")
	_check(StoryItems.snapshot()==old_items and Progression.credits==old_credits, "bridge interaction does not create money or items")
	_check(not GameplayLock.is_locked() and not player.interaction.active, "player regains motion after interaction")
	_measure["did_skip"] = interrupted
	_measure["caption"] = caption
	_measure["had_action"] = action != null
	if expect_action:
		_check(action != null, "the actual world-action owner ran")
		_check(interrupted if _skip else _measure.has("contact_metric"), "the expected hand action finishes or skips")
		if not _skip and _measure.has("contact_metric"):
			var palm: Array = _measure["palm"]
			var target: Array = _measure["target"]
			_check(Vector2(palm[0]-target[0],palm[1]-target[1]).length() < 0.25, "actual visible rig palm is on the original lever handle")
	player.global_position = gate.global_position - Vector2(12.0, 2.0)
	player.velocity = Vector2.ZERO
	_level.camera.snap_to_target()
	for _frame in 60:
		if player.is_on_floor() and gate._player_in_range:
			break
		await get_tree().physics_frame
	if _revisit and gate._player_in_range and not gate.is_armed():
		player.global_position = gate.global_position - Vector2(48.0, 2.0)
		player.velocity = Vector2.ZERO
		for _frame in 60:
			if gate.is_armed():
				break
			await get_tree().physics_frame
		_measure["armed_by_exit"] = gate.is_armed()
		player.global_position = gate.global_position - Vector2(12.0, 2.0)
		player.velocity = Vector2.ZERO
		_level.camera.snap_to_target()
		for _frame in 60:
			if player.is_on_floor() and gate.interaction_available():
				break
			await get_tree().physics_frame
	_measure["supported_gate"] = [player.is_on_floor(),gate.is_armed(),gate._player_in_range]
	_check(player.is_on_floor() and gate.interaction_available(), "the unfolded portal is reachable from its actual supported landing")
	await RenderingServer.frame_post_draw
	_capture("bridge-open")
	if _revisit:
		_check(action == null and _phases.is_empty(), "revisit does not replay the approach or contact")
	if _cross:
		await _tap(&"interact")
		var crossed := false
		for _frame in STEP_LIMIT:
			var next := _app.get("_screen") as Level
			if next != null and next.data.resource_path == MARKET and next.is_initialized() and not bool(_app.call("_route_pending")):
				var back := next._portals.get(&"market_sc1") as Portal
				crossed = is_instance_valid(back) and back.is_open()
				break
			await get_tree().process_frame
		_check(crossed and _store.read().get("level","") == MARKET, "original bridge portal enters the market and leaves the return shortcut open")
		_measure["crossed"] = crossed
		await RenderingServer.frame_post_draw
		_capture("bridge-market")
	_finish(true)


func _tap(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await get_tree().physics_frame
	await get_tree().process_frame
	event = InputEventAction.new()
	event.action = action
	Input.parse_input_event(event)
	await get_tree().process_frame


func _vector(v: Vector2) -> Array:
	return [v.x,v.y]


func _check(ok: bool, what: String) -> void:
	_counts += 1
	super._check(ok,what)


func _finish(ok: bool) -> void:
	var file := FileAccess.open(_out_dir.path_join("result.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks":_counts,"failures":_failures+int(not ok),"phases":_phases,"metrics":_measure,
		"hdr":get_viewport().use_hdr_2d,"adapter":RenderingServer.get_video_adapter_name(),"language":Story.language,
		"side":_side,"prototype":_prototype,"credits":Progression.credits,"revisit":_revisit,"cross":_cross}, "  "))
	file.close()
	_app.call("_quit",int(not ok or _failures>0))
