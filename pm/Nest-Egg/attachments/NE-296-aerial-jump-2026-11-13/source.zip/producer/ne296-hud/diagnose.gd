extends "res://tests/smoke_test.gd"

func _run() -> void:
	print("NE296_HUD_PROBE: unchanged original dynamic HUD and real player obstacle assertions")
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	await _test_dynamic_hud()
	await preload("res://tests/helpers/contextual_priority_checks.gd")._actual_player_obstacle(UiScreensSuite.new(self))
	await _finish()
