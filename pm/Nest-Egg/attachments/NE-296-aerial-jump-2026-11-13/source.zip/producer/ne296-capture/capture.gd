extends Node

const Capture := preload("res://tools/viewport_capture.gd")
var out := ""
var checks := 0
var failures := 0
var rows: Array[Dictionary] = []

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	_run.call_deferred()

func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("FAIL: ", label)

func ticks(count: int) -> void:
	for i in count:
		await get_tree().physics_frame

func _run() -> void:
	check(not out.is_empty(), "explicit output directory")
	if out.is_empty():
		get_tree().quit(2)
		return
	DirAccess.make_dir_recursive_absolute(out)
	get_viewport().use_hdr_2d = true
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(load("res://data/levels/ch1_rooftop.tres"))
	add_child(level)
	var player := level.player
	AimInput.set_virtual_gamepad(player, true)
	AimInput.restore_direction(Vector2.RIGHT)
	await ticks(24)
	for earned in [false, true]:
		GameState.set_flag(&"ledger_disk_obtained", earned, false)
		check(player.is_on_floor(), "same authored rooftop floor before each pair")
		Input.action_press(&"jump")
		await ticks(2)
		Input.action_release(&"jump")
		await ticks(8)
		var before := player.velocity.y
		Input.action_press(&"jump")
		await ticks(2)
		check(player._air_jump_used == earned, "only earned progress consumes an aerial jump")
		check((player.velocity.y < before) == earned, "second press produces an impulse only after unlock")
		await RenderingServer.frame_post_draw
		var tag := "earned-air-jump" if earned else "locked-second-press"
		var image := get_viewport().get_texture().get_image()
		var path := out.path_join(tag)
		var raw := FileAccess.open(path + ".raw", FileAccess.WRITE)
		check(raw != null, "raw output opens")
		if raw != null:
			raw.store_buffer(image.get_data())
			raw.close()
		check(Capture.encode(image, true).save_png(path + ".png") == OK, "PNG output saved")
		rows.append({"tag":tag,"position":[player.position.x,player.position.y],"velocity":[player.velocity.x,player.velocity.y],"air_jump_used":player._air_jump_used,"on_floor":player.is_on_floor(),"format":image.get_format(),"size":[image.get_width(),image.get_height()],"png_sha256":FileAccess.get_sha256(path + ".png"),"raw_sha256":FileAccess.get_sha256(path + ".raw")})
		Input.action_release(&"jump")
		await ticks(90)
	AimInput.set_virtual_gamepad(player, false)
	Input.action_release(&"jump")
	level.queue_free()
	await get_tree().process_frame
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	var result := {"checks":checks,"failures":failures,"renderer":RenderingServer.get_current_rendering_method(),"device":RenderingServer.get_video_adapter_name(),"hdr_2d":get_viewport().use_hdr_2d,"scope":"Actual player input on authored rooftop; arranged progress flag, automated input, not a full campaign or physical controller playthrough","frames":rows}
	var report := FileAccess.open(out.path_join("result.json"), FileAccess.WRITE)
	if report == null:
		get_tree().quit(2)
		return
	report.store_string(JSON.stringify(result, "\t"))
	report.close()
	print("NE296_CAPTURE ", JSON.stringify(result))
	get_tree().quit(0 if failures == 0 else 1)
