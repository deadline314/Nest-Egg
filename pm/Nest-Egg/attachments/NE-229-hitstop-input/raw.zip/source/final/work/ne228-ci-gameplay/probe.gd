extends "res://tests/smoke_test.gd"
var _observed:Level
var _round:=0
var _injected:=false
func _run()->void:
	Enemy.activation_culling_enabled=false
	Story.auto_skip=true
	get_tree().physics_frame.connect(_note_physics)
	for i in 3:
		_round=i
		_injected=false
		await _test_gameplay()
	await _finish()
func _start_level()->Level:
	_observed=await super._start_level()
	return _observed
func _check(condition:bool,message:String)->void:
	if not condition or message in ["vehicle exists","player mounts vehicle","player dismounts vehicle","pit damages and respawns"]:
		print("GAMEPLAY_DIAG ",JSON.stringify(_snapshot(message)))
	super._check(condition,message)
func _snapshot(label:String)->Dictionary:
	var d:={"label":label,"round":_round,"physics_frame":Engine.get_physics_frames(),"process_frame":Engine.get_process_frames(),"time_usec":Time.get_ticks_usec(),"time_scale":Engine.time_scale,"paused":get_tree().paused,"locked":GameplayLock.is_locked(),"interact_pressed":Input.is_action_pressed(&"interact"),"interact_just":Input.is_action_just_pressed(&"interact")}
	if is_instance_valid(_observed):
		var p:=_observed.player
		d["player"]={"id":p.get_instance_id(),"state":p.state,"position":[p.position.x,p.position.y],"velocity":[p.velocity.x,p.velocity.y],"health":p.health.current,"floor":p.is_on_floor(),"stagger_left":p._stagger_left,"remount_left":p._remount_cooldown_left,"process_mode":p.process_mode,"can_process":p.can_process(),"mounted_id":p.mounted_vehicle.get_instance_id() if is_instance_valid(p.mounted_vehicle) else 0}
		var vehicles:Array=[]
		for v in get_tree().get_nodes_in_group(&"vehicles"):
			vehicles.append({"id":v.get_instance_id(),"position":[v.position.x,v.position.y],"distance":v.global_position.distance_to(p.global_position),"can_mount":v.can_mount(),"destroyed":v.destroyed,"driver":v.driver.get_instance_id() if is_instance_valid(v.driver) else 0,"grace":v._mount_grace})
		d["vehicles"]=vehicles
	return d

func _note_physics()->void:
	if not is_instance_valid(_observed) or not is_instance_valid(_observed.player):return
	var p:=_observed.player
	for v in get_tree().get_nodes_in_group(&"vehicles"):
		if v.global_position.distance_to(p.global_position)<32.0:
			if not _injected:
				_injected=true
				print("CONTROLLED_HITSTOP ",JSON.stringify(_snapshot("before controlled 60ms player hitstop")))
				Fx.freeze.call_deferred([p],0.06)
			print("PHYSICS_SAMPLE ",JSON.stringify(_snapshot("near vehicle")))
