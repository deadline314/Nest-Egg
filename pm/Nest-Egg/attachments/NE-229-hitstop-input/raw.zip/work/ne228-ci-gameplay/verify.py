from pathlib import Path
import subprocess,os,json,time,hashlib
w=Path('work/ne228-ci-gameplay')
files=['autoload/fx.gd','game/player/player.gd','game/player/vehicle_command_input.gd','game/player/vehicle_command_input.gd.uid','game/vehicles/vehicle.gd','tests/smoke_test.gd','tests/suite/test_input_feel.gd','work/ne228-ci-gameplay/probe.gd','work/ne228-ci-gameplay/native.gd']
(w/'verification-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2))
env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6',LOG_DIR=str((w/'changed-shards').resolve()))
cmd=['tools/run_tests_changed.sh','5bcc9f68b4e226e4d5b91d788d20d40b174efce0'];start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
(w/'changed-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2));print(r.returncode,flush=True)
raise SystemExit(r.returncode)
