from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil,re
root=Path.cwd();w=root/'work/ne228-ci-gameplay';native=Path('/workspace/Nest-Egg/work/batch1020b');out=root/'pm/Nest-Egg/attachments/NE-229-hitstop-input';base='5bcc9f68b4e226e4d5b91d788d20d40b174efce0'
sha=lambda b:hashlib.sha256(b).hexdigest()
smoke=Path('tests/smoke_test.gd').read_text().split('\n\n\n## Failure-only state')[0]+'\n'
smoke=smoke.replace('\t\tif message in ["player mounts vehicle", "player dismounts vehicle", "pit damages and respawns"]:\n\t\t\t_gameplay_failure_state(message)\n','')
feel=Path('tests/suite/test_input_feel.gd').read_text().split('\n\n\nfunc _vehicle_press')[0]+'\n'
feel=feel.replace('\tawait _test_vehicle_hitstop_interaction()\n','',1)
reconstruction=[]
for path,text in [('tests/smoke_test.gd',smoke),('tests/suite/test_input_feel.gd',feel)]:
 original=subprocess.check_output(['git','show',base+':'+path]);assert original==text.encode(),path
 reconstruction.append({'path':path,'original_assertions_inputs_waits_byte_exact':True,'original_sha256':sha(original)})
(w/'original-test-reconstruction.json').write_text(json.dumps(reconstruction,indent=2)+'\n')
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
harness=['tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']
for p in harness:assert (root/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p]),p
receipt=json.loads((w/'changed-receipt.json').read_text());assert receipt['exit_code']==0
text=(w/'changed.log').read_text();assert 'new failures: 0' in text and 'Detected script errors' not in text
cases=json.loads((w/'native-receipt.json').read_text());assert len(cases)==2
for c in cases:
 assert c['exit_code']==c['expected'] and c['engine_errors']==0 and c['leaks']==0
 assert len(list((native/c['name']).glob('*.png')))==3
viewed={'individually_viewed':True,'files':[str(p.relative_to(native)) for c in cases for p in sorted((native/c['name']).glob('*.png'))],'observation':'修前搭乘圖保留玩家且無機甲血條，修後有正式機甲血條；離開後玩家恢復可見。落坑圖是渲染讀回時刻，斷言狀態另保留於GAMEPLAY_DIAG；六圖不證明完整角色關節或實體裝置。'}
(w/'viewed.json').write_text(json.dumps(viewed,ensure_ascii=False,indent=2)+'\n')
files={}
for p in w.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in x or x=='__pycache__' for x in p.relative_to(w).parts):files['work/'+str(p.relative_to(root/'work'))]=p.read_bytes()
for p in native.glob('ne229-1022-hitstop-*'):
 if 'profile' in p.name:continue
 if p.is_dir():
  for f in p.rglob('*'):
   if f.is_file():files['native/'+str(f.relative_to(native))]=f.read_bytes()
 elif p.is_file():files['native/'+p.name]=p.read_bytes()
refs=root/'../kitchen/work/ne228-hud-reading/references'
for p in refs.iterdir():
 if p.is_file():files['references/'+p.name]=p.read_bytes()
files['ci/39781993137-job.log']=(root/'../kitchen/work/ne228-hud-reading/ci-39781993137.log').read_bytes()
paths=list(json.loads((w/'verification-frozen-source.json').read_text()))+harness+['design/20-campaign-experience/VEHICLE_HITSTOP_INPUT.md','tools/viewport_capture.gd']
for p in paths:files['source/final/'+p]=(root/p).read_bytes()
for p in ['autoload/fx.gd','game/player/player.gd','game/vehicles/vehicle.gd','tests/smoke_test.gd','tests/suite/test_input_feel.gd']:files['source/before/'+p]=subprocess.check_output(['git','show',base+':'+p])
validation={'base':base,'red_ci':{'run':39781993137,'checks':96000,'new_failures':3,'seconds':634,'artifact_sha256':'827256e782e1f0de023feca1748186edffeff00c0b0af17ee725833baa1ffa9b'},'original_gameplay_repeat':'320 checks / 0; original CI uniquely identifying state absent','controlled_gameplay':'explicit public 60ms player hitstop near authored vehicle; original inputs/waits/assertions: 48/9 before,48/0 after','additional_checks':9,'unit':'final 118/2 before,118/0 after; earlier v1 118/4 includes 2 cascading fixture failures, retained','affected':receipt,'affected_summary':[l for l in text.splitlines() if 'checks:' in l or re.search(r'Running \d+ groups',l)],'native':cases,'viewed':viewed,'harness_unchanged':harness,'original_tests':reconstruction,'scope':'Forward+ HDR llvmpipe software Vulkan, authored legacy level_01 retained; explicit 60ms intervention, no HP/driver/result injection. Native readback holds tree only after all original gameplay assertions. Render capture can follow assertion by physics frames; full snapshots retained. No physical controller/GPU or human chapter acceptance. Controlled defect is demonstrated; original red CI unique root remains unproven.'}
out.mkdir(parents=True,exist_ok=True)
(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for p,b in files.items():assert sha(z.read(p))==sha(b),p
manifest={'archive_bytes':(out/'raw.zip').stat().st_size,'archive_sha256':sha((out/'raw.zip').read_bytes()),'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for label in ['before','after']:
 shutil.copyfile(native/('ne229-1022-hitstop-'+label+'-v2')/'player-mounts-vehicle.png',root/('pm/Nest-Egg/images/NE-229-hitstop-'+label+'.png'))
shutil.copyfile(refs/'598550-2.jpg',root/'pm/Nest-Egg/images/NE-229-hitstop-huntdown-reference.jpg')
r={'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256']};(w/'package-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
