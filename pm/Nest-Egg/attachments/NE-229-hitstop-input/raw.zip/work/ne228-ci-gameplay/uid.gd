extends SceneTree
func _initialize()->void:
	var path:="res://game/player/vehicle_command_input.gd.uid"
	if not FileAccess.file_exists(path):
		FileAccess.open(path,FileAccess.WRITE).store_string(ResourceUID.id_to_text(ResourceUID.create_id())+"\n")
	print(FileAccess.get_file_as_string(path))
	quit()
