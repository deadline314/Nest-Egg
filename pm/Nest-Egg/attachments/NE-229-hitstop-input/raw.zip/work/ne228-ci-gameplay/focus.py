from pathlib import Path
import subprocess,os,json,time,hashlib
w=Path('work/ne228-ci-gameplay');files=['autoload/fx.gd','game/player/player.gd','game/vehicles/vehicle.gd'];final={p:Path(p).read_bytes() for p in files};env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1');rows=[]
def run(label):
 child=env.copy();child['LOG_DIR']=str((w/(label+'-shards')).resolve());cmd=['tools/run_tests_parallel.sh','--only=InputFeelSuite'];start=time.monotonic()
 with (w/(label+'.log')).open('w') as f:r=subprocess.run(cmd,env=child,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 rows.append({'label':label,'exit_code':r.returncode,'seconds':time.monotonic()-start,'command':cmd});(w/'focus-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);return r.returncode
try:
 for p in files:Path(p).write_bytes((w/(Path(p).stem+'-before.gd')).read_bytes())
 assert run('negative')==1
finally:
 for p,b in final.items():Path(p).write_bytes(b)
assert run('fixed')==0
