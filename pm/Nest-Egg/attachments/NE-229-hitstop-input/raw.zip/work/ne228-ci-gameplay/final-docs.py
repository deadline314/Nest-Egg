from pathlib import Path
import json,re
w=Path('work/ne228-ci-gameplay');out=Path('pm/Nest-Egg/attachments/NE-229-hitstop-input')
r=json.loads((w/'changed-receipt.json').read_text());assert r['exit_code']==0
t=(w/'changed.log').read_text();summary=[s for s in t.splitlines() if s.startswith('checks:')][-1];assert 'new failures: 0' in summary
packet=json.loads((w/'package-receipt.json').read_text())
(out/'README.md').write_text(f'''# NE-229：受擊停格期間的載具互動

修正只讓實際被Fx局部停住的玩家／載具接收同一個互動鍵邊緣；保留停格截止時間、空車、距離、owner、離開保護、長按與暫停規則。[設計與研究](../../../../design/20-campaign-experience/VEHICLE_HITSTOP_INPUT.md)、[完整收據](validation.json)、[原檔](raw.zip)、[逐檔SHA](manifest.json)。

| 同一情境 | 修前 | 修後 |
|---|---|---|
| 原遊戲流程＋明示60ms局部停格，三輪 | 48項／9失敗 | 48項／0失敗 |
| 輸入套件（只新增9項） | 118項／2失敗 | 118項／0失敗 |
| Forward+原舊關卡＋正式環境，一輪 | 20項／1失敗 | 20項／0失敗 |

最終原生v2前後兩輪都是0引擎ERROR、0退出洩漏診斷，六張PNG逐張檢視。第一個斷言的快照顯示修後實際driver與mounted身份成立，玩家仍process_mode=DISABLED；沒有提早解凍。畫面讀回可能晚於斷言若干物理影格，GAMEPLAY_DIAG與CAPTURE_STATE分別保留，完成原斷言後才暫停世界等讀回。兩輪使用原level_01，不換成另一張正式章節來避退出錯誤；這不代表其他舊工具的退出250已修好。

原選擇器、固定基準5bcc9f68：{summary}；實際{r['seconds']:.2f}秒。原Smoke與InputFeel既有斷言／輸入／等待逐位元重建相同；runner、selector、filters與known_failures保持。所有shard原log收於zip。

原CI39781993137有96,000項／3新失敗（搭乘、離開、落坑），634秒。原artifact與job全log保留；artifact SHA 827256e782e1f0de023feca1748186edffeff00c0b0af17ee725833baa1ffa9b。原版未介入流程20輪320／0，原CI沒有失敗當刻owner／停格快照，因此本次60ms控制證明一個真缺口，不逕稱原CI唯一根因。原Smoke只新增失敗時診斷，未放寬等待或判準。推送後仍需核對新完整CI。

較早輸入fixture v1為118／4，其中2項是離開失敗造成後續獨立案例的連鎖；修正fixture僅在已記失敗後建立下一案例前提，最終負控制118／2與正式118／0全部保留。原生v1與最終v2皆留原檔。

Vulkan／llvmpipe為軟體Forward+，Dummy音訊；輸入合成、60ms介入明示，不代稱實體手把、硬體GPU、人工整章或整票完成。研究原圖屬各作品，HUNTDOWN載具圖只作構圖參照，不當作該作輸入時間證據；五團隊十圖及官方URL／SHA收於zip。人物關節與完整渲染輪廓不屬本次驗收。

原檔共{packet['entries']}項、{packet['bytes']:,} bytes；zip SHA `{packet['sha256']}`，已逐項解出核對SHA。
''')
ticket=Path('pm/Nest-Egg/[NE-229]補齊全流程手把操作.md');s=ticket.read_text();assert '# Commit-7' not in s
s+='''\n\n# Commit-7

## 內文

短暫受擊停格時按下附近載具的互動鍵，原本可能完全沒有反應；接著原想離開的操作反而成為搭乘。現在停格期間仍接收一次搭乘／離開，保留原距離、上下車保護及停格時間。按住不會反覆上下車，暫停時按下不會在返回後執行。

先讀User-guide，對照相近作品研究圖，再保留原遊戲流程做60ms停格前後對照。原CI同段三項失敗的當刻狀態不足以證明唯一根因，原檔與這次控制結果分開記錄；後續失敗會輸出當刻狀態。[設計與研究](../../design/20-campaign-experience/VEHICLE_HITSTOP_INPUT.md)、[全部成功／失敗、六張逐張檢視原圖與界線](attachments/NE-229-hitstop-input/README.md)。

### 測試結果

| 項目 | 結果 |
|---|---|
| 原遊戲流程，明示60ms局部停格 | 修前48項／9失敗；修後48項／0失敗 |
| 原輸入套件＋9項回歸 | 修前118項／2失敗；修後118項／0失敗 |
| Forward+原生前後對照 | 修前20項／1失敗；修後20項／0失敗；兩輪0引擎ERROR、0退出洩漏診斷 |
'''+f'| 原選擇器、基準5bcc9f68 | {summary}；{r["seconds"]:.2f}秒 |\n'+'''
合成輸入與軟體Vulkan分開標示，原實體手把條件及整票狀態保持。

### 本作前後圖

| 修前：同一操作未搭乘 | 修後：正式機甲血條出現 |
|---|---|
| ![修前](images/NE-229-hitstop-before.png) | ![修後](images/NE-229-hitstop-after.png) |

### 相近作品參照

![HUNTDOWN官方載具戰鬥圖；只參考構圖，不推論輸入時序](images/NE-229-hitstop-huntdown-reference.jpg)
''';ticket.write_text(s)
guide=Path('pm/user_guide.md');s=guide.read_text();line='2026-10-22（NE-229）：受擊局部停格不該漏掉載具互動；同一鍵只執行一次，原上下車保護、距離、暫停與停格截止時間維持。[60ms負控制、原流程、原生六圖與完整回歸](Nest-Egg/attachments/NE-229-hitstop-input/README.md)。5bcc9f68完整CI實際為96,000項／3新失敗、634秒，原版未介入20輪320／0；控制重現一個真缺口，不補造原CI缺少的根因狀態，也不把局部交付當實體手把或整票驗收。\n\n';assert line not in s;guide.write_text(line+s)
print(summary)
