from pathlib import Path
import subprocess,os,json,time,hashlib,re
w=Path('work/ne228-ci-gameplay');files=['autoload/fx.gd','game/player/player.gd','game/vehicles/vehicle.gd'];final={p:Path(p).read_bytes() for p in files};env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/quests';rows=[]
(w/'native-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files+['game/player/vehicle_command_input.gd','tests/smoke_test.gd','tests/suite/test_input_feel.gd','work/ne228-ci-gameplay/probe.gd','work/ne228-ci-gameplay/native.gd']},indent=2))
def run(label,expected):
 name='ne229-1022-hitstop-'+label+'-v2';cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/ne228-ci-gameplay/native.tscn'];start=time.monotonic()
 with (w/('native-'+label+'-wrapper.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=500)
 log=(Path('/workspace/Nest-Egg/work/batch1020b')/(name+'.log')).read_text();row={'name':name,'label':label,'command':cmd,'exit_code':r.returncode,'expected':expected,'seconds':time.monotonic()-start,'engine_errors':log.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log))};rows.append(row);(w/'native-receipt.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True);assert r.returncode==expected and row['engine_errors']==0 and row['leaks']==0
try:
 for p in files:Path(p).write_bytes((w/(Path(p).stem+'-before.gd')).read_bytes())
 run('before',1)
finally:
 for p,b in final.items():Path(p).write_bytes(b)
run('after',0)
