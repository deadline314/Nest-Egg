extends "res://tools/ch1_flow_probe.gd"

const ROOFTOP := "res://data/levels/ch2_rooftop.tres"
const GATE := "res://data/levels/ch2_market_gate.tres"
var _mode := ""
var _slot := ""
var _font_style := "smooth"
var _main: Node
var _measured: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--font="):
			_font_style = arg.trim_prefix("--font=")
		elif arg.begins_with("--save-dir="):
			_slot = arg.trim_prefix("--save-dir=")
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_slot.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	Story.set_language("en")
	Settings.set_ui_font(_font_style)
	_main.call("_on_continue_requested")
	await _settle(65)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.resource_path == ROOFTOP
		and GameState.has_flag(&"ch2_brief_done") and StoryItems.holds(&"ch2_check_card")
		and not GameState.has_flag(&"ch2_gate_checked"), "load the real rooftop save between the briefing and the market")
	if _level == null or _level.data.resource_path != ROOFTOP:
		_finish()
		return
	var guidance := _level.hud.quest_guidance
	_check(guidance._goal_key.begins_with("ch2_gate_checked"), "the original market check drives the guidance")
	for size: float in [1.0, 1.2]:
		Settings.set_ui_text_scale(size)
		await _settle(40)
		var label := guidance._label
		var width := label.get_theme_font(&"font").get_string_size(label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, label.get_theme_font_size(&"font_size")).x
		var available := label.size.x
		_measured.append({"font":_font_style,"scale":size,"width":width,"available":available,"text":label.text,"in_view":label.is_visible_in_tree()})
		_check(label.is_visible_in_tree() and width > 0.0 and available > 0.0, "the real objective is visible at %.2f" % size)
		if _mode == "after":
			_check(width <= available and label.text.contains("inspection pass") and label.text.ends_with("market gate."), "the full pass and destination fit at %.2f" % size)
		_capture("market-goal-" + str(size))
	if _mode == "before":
		_check(_measured.any(func(sample: Dictionary) -> bool: return sample["width"] > sample["available"]), "the original objective visibly elides")
	_main.call("_on_area_requested", GATE)
	await _settle(60)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.resource_path == GATE and _object(&"ch2_patroller") != null, "the original market destination and guard remain present")
	if _level != null and _object(&"ch2_patroller") != null:
		_check(await _talk(&"ch2_patroller"), "the original guard confirms the pass")
		_check(GameState.has_flag(&"ch2_gate_checked") and StoryItems.holds(&"ch2_check_card"), "the original pass and market gate result are retained")
	_finish()


func _finish() -> void:
	var file := FileAccess.open(_out_dir.path_join("result.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"mode":_mode,"failures":_failures,"samples":_measured},"  ")+"\n")
	file.close()
	_main.call("_quit",0 if _failures == 0 else 1)
