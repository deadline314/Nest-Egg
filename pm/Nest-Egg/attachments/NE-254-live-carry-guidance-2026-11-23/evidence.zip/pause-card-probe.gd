extends "res://tests/smoke_test.gd"

func _run() -> void:
	var suite := CombatHudSuite.new(self)
	Settings.use_storage("user://controls_pause_fixture.cfg")
	Settings.set_reduce_ui_motion(true)
	for expires in [true, false]:
		var level := await suite.start_level(PropsSuite.level_data())
		await suite.frames(3)
		var hud := level.hud
		var pause := level._pause_menu
		suite.check(hud._controls_card.visible, "the original opening hint is visible before pause")
		if expires:
			# Reproduce the original fixture's late observation without real-time load or pointer motion.
			hud._controls_read_time = 0.001
		var left := hud._controls_read_time
		pause.open()
		await suite.frames(3)
		suite.check(not hud._controls_card.visible and is_equal_approx(hud._controls_read_time, left),
			"pausing hides the real card and freezes reading time")
		pause.close()
		await suite.frames(2)
		print("PAUSE_CARD %s left_before=%.5f left_after=%.5f visible=%s dismissing=%s paused=%s gameplay_lock=%s" %
			["near-expiry" if expires else "fresh", left, hud._controls_read_time, str(hud._controls_card.visible),
			str(hud._controls_dismissing), str(get_tree().paused), str(GameplayLock.is_locked())])
		suite.check(not get_tree().paused and not GameplayLock.is_locked(), "resume actually unlocks game processing")
		suite.check(hud._controls_card.visible != expires,
			"after resume only the hint with remaining reading time should be visible")
		await suite.end_level(level)
	await _finish()
