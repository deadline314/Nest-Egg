extends "res://tests/smoke_test.gd"

const WAREHOUSE := preload("res://data/levels/ch1_warehouse.tres")
const Capture := preload("res://tools/viewport_capture.gd")
const COPY := {
	"zh": ["撿起木箱", "往準星丟出", "放下"],
	"ja": ["木箱を拾う", "照準方向に投げる", "置く"],
	"en": ["Pick up crate", "Throw toward the reticle", "Put down"],
}


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://carry_guidance_probe.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	var args := OS.get_cmdline_user_args()
	for language: String in COPY:
		await _case(language, args[0] if args.size() == 1 else "-")
	await _finish()


func _case(language: String, screenshot: String) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	InputBindings.reset_to_defaults()
	await _key(KEY_H)
	var level := Level.new()
	level.configure(WAREHOUSE)
	add_child(level)
	await _frames(55)
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		enemy.set_physics_process(false)
	var crate: Throwable
	for node in get_tree().get_nodes_in_group(Throwable.GROUP):
		if node is Throwable and node.data.id == &"crate_small" and roundi(node.global_position.x / 16.0 - 0.5) == 43:
			crate = node
			break
	_check(crate != null, language + " authored warehouse crate")
	if crate == null:
		level.queue_free()
		await _frames(4)
		return
	var player := level.player
	player.global_position = crate.global_position + Vector2(-10.0, 0.0)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	AimInput._last_stick_dir = Vector2.RIGHT
	await _frames(28)
	var prompt := crate._prompt
	var expected: Array = COPY[language]
	_check(prompt.is_showing() and prompt._display_text.contains(expected[0]) and prompt._display_text.contains("E"),
		language + " localized world pickup")
	await _key(KEY_E)
	await _frames(20)
	var banner := level.hud.toast_banner
	_check(player.carry.held == crate and banner.is_showing(), language + " first lift displays teaching")
	_check(_matches(banner._label.text, expected) and prompt._display_text.contains(expected[2]),
		language + " localized initial instructions and drop")
	var tween := banner._tween
	var first_text := banner._label.text
	var start := tween.get_total_elapsed_time()
	await _axis(JOY_AXIS_RIGHT_X, 0.9)
	_check(InputBindings.using_gamepad and banner.is_showing(), language + " live switch recognizes gamepad while held")
	_check(_matches(banner._label.text, expected) and banner._label.text != first_text,
		language + " active tutorial switches to actual gamepad bindings")
	_check(prompt._display_text.contains(InputBindings.primary_label(&"interact")), language + " world drop agrees with gamepad")
	_check(banner._tween == tween and tween.get_total_elapsed_time() > start, language + " device switch preserves banner timeline")
	if language == "en" and screenshot.is_absolute_path():
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(screenshot) == OK, "native warehouse capture")
	await _axis(JOY_AXIS_RIGHT_X, 0.0)
	await _key(KEY_H)
	InputBindings.set_code(&"interact", 0, KEY_H)
	await _frames(2)
	_check(not InputBindings.using_gamepad and _matches(banner._label.text, expected)
		and prompt._display_text.contains("H") and not prompt._display_text.contains("X"),
		language + " active tutorial and drop both follow rebinding")
	_check(banner._tween == tween, language + " rebinding keeps original banner timer")
	if language == "zh":
		level.hud.show_toast("關卡更新")
		await _axis(JOY_AXIS_RIGHT_X, 0.9)
		await _axis(JOY_AXIS_RIGHT_X, 0.0)
		_check(banner._label.text == "關卡更新", "device switch leaves newer notice intact")
	await _key(KEY_H)
	await _frames(9)
	_check(not player.carry.is_holding() and crate.state == Throwable.State.REST, language + " rebound key really puts crate down")
	_check(banner._label.text == ("關卡更新" if language == "zh" else ""),
		language + " drop clears only its own instructions")
	level.queue_free()
	await _frames(5)


func _matches(text: String, expected: Array) -> bool:
	return text.contains(expected[1]) and text.contains(expected[2]) 		and text.contains(InputBindings.primary_label(&"shoot")) and text.contains(InputBindings.primary_label(&"interact"))


func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	event.pressed = true
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await _frames(3)
	var release := event.duplicate() as InputEventKey
	release.pressed = false
	Input.parse_input_event(release)
	Input.flush_buffered_events()
	await _frames(3)


func _axis(axis: JoyAxis, value: float) -> void:
	var event := InputEventJoypadMotion.new()
	event.axis = axis
	event.axis_value = value
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await _frames(3)


func _frames(count: int) -> void:
	for i in count:
		await get_tree().physics_frame
		await get_tree().process_frame

