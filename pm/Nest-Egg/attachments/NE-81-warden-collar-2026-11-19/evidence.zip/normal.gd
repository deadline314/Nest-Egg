extends SceneTree

func _initialize() -> void:
	var paths := OS.get_cmdline_user_args()
	if paths.size() != 2 or not paths[0].is_absolute_path() or not paths[1].is_absolute_path():
		quit(2)
		return
	var texture := Image.load_from_file(paths[0])
	if texture == null:
		quit(1)
		return
	var normals := NormalMapMaker.make(texture)
	quit(0 if normals.save_png(paths[1]) == OK else 1)
