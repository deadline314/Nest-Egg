from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path('C:/Users/stanl/Github/Nest-Egg')
OLD = ROOT / 'work/ne286-ne267-official'
OUT = ROOT / 'work/ne286-ne267-official-v3'
OUT.mkdir()
old = json.loads((OLD / 'candidate.json').read_bytes())
project = Path(old['worktree'])

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

frozen = json.loads((OLD / 'test-source-before.json').read_bytes())
assert {name: sha(project / name) for name in frozen} == frozen
manifest_path = ROOT / 'pm/Nest-Egg/attachments/NE-267-guest-rigs/validation-inputs-v3.json'
manifest = json.loads(manifest_path.read_bytes())
new = {row['path']: row['sha256'] for row in manifest['files']}
assert len(new) == manifest['count'] == 314
assert {name: sha(ROOT / name) for name in new} == new
extra_names = [
    'game/enemies/janus_boss.gd', 'game/enemies/boss/janus_config.gd',
    'game/enemies/boss/janus_config.gd.uid', 'tests/suite/test_ch3_enemies.gd',
    'tests/helpers/janus_config_checks.gd', 'tests/helpers/janus_config_checks.gd.uid',
    'pm/Nest-Egg/attachments/NE-267-guest-rigs/cut_layers-before-crop-phase.py.txt']
for name in extra_names:
    assert sha(ROOT / name) == old['source_sha256'][name]
    new[name] = old['source_sha256'][name]
assert len(new) == 321
removed = sorted(set(old['source_sha256']) - set(new))
assert not removed, removed
changes = []
for name, digest in new.items():
    target = project / name
    previous = sha(target) if target.is_file() else None
    if previous != digest:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
        assert sha(target) == digest
        changes.append(dict(path=name, before=previous, after=digest))
assert {name: sha(project / name) for name in new} == new
save('adoption.json', dict(changes=changes, manifest_sha256=sha(manifest_path), old_sources_guarded=len(frozen)))
save('candidate.json', dict(base=old['base'], worktree=str(project),
    scope='NE267 frozen v3 314 + NE286 six + original cutter fixture; no unpublished NE277 geometry',
    source_sha256=new))
original_runner = ROOT / 'work/run_ne286_ne267_official.py'
runner = ROOT / 'work/run_ne286_ne267_official_v3.py'
assert not runner.exists()
runner.write_text(original_runner.read_text(encoding='utf-8').replace("OUT = ROOT / 'work/ne286-ne267-official'", "OUT = ROOT / 'work/ne286-ne267-official-v3'"), encoding='utf-8', newline='\n')
save('runner-derivation.json', dict(original_sha256=sha(original_runner), runner_sha256=sha(runner), only_change='OUT directory'))
print('adopted', len(changes), 'changes; frozen', len(new), 'files; preserved old red receipts')
