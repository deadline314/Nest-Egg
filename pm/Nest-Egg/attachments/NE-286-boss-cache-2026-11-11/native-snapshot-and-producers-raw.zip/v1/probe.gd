extends Node

var _scripts: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_scripts.append(load("res://game/enemies/yong_boss.gd"))
	_scripts.append(load("res://game/enemies/janus_boss.gd"))
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	var level := Level.new()
	level.configure(load("res://data/levels/ch3_gate_hall.tres"))
	add_child(level)
	for step in 90:
		await get_tree().physics_frame
	var boss: Node2D
	for actor in get_tree().get_nodes_in_group(&"enemies"):
		if actor.data != null and actor.data.id == &"janus":
			boss = actor
			break
	if boss == null:
		push_error("[NE286Snapshot] real gate-hall JANUS was not instantiated")
		get_tree().quit(2)
		return
	level.player.health.setup(999, 0.0)
	level.player.global_position = boss.global_position + Vector2(-96, 0)
	level.player.velocity = Vector2.ZERO
	var camera := get_viewport().get_camera_2d()
	if camera != null:
		camera.position_smoothing_enabled = false
		camera.reset_smoothing()
		camera.force_update_scroll()
	for step in 18:
		await get_tree().physics_frame
	await RenderingServer.frame_post_draw
	var picture := get_viewport().get_texture().get_image()
	var path := "C:/Users/stanl/Github/Nest-Egg/work/ne286-native-snapshot/janus-level.png"
	var result := picture.save_png(path)
	if result != OK:
		push_error("[NE286Snapshot] PNG write failed %s: %s" % [result, path])
		get_tree().quit(2)
		return
	var info := {"fixture": true, "not_human_boss_fight": true,
		"both_behavior_scripts_held": _scripts.size(),
		"renderer": RenderingServer.get_current_rendering_method(),
		"hdr_2d": get_viewport().use_hdr_2d,
		"image_size": [picture.get_width(), picture.get_height()],
		"player_feet": str(level.player.global_position), "boss_feet": str(boss.global_position)}
	FileAccess.open(path + ".json", FileAccess.WRITE).store_string(JSON.stringify(info, "  ") + "\n")
	AudioRelease.begin_shutdown()
	level.queue_free()
	_scripts.clear()
	for step in 4:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	get_tree().quit()
