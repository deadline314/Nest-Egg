from pathlib import Path
import json
import numpy as np
from PIL import Image

root = Path('C:/Users/stanl/Github/Nest-Egg/work/ne286-native-snapshot-v2')
meta = json.loads((root / 'janus-level.png.json').read_bytes())
assert meta['raw_format'] == 14 and meta['renderer'] == 'forward_plus' and meta['hdr_2d']
width, height = meta['image_size']
raw = np.fromfile(root / 'janus-level.png.bin', dtype='<f2').reshape(height, width, 3).astype(np.float64)
assert np.isfinite(raw).all()
linear = np.maximum(raw, 0)
srgb = np.where(linear < 0.0031308, linear * 12.92, 1.055 * linear ** (1 / 2.4) - 0.055)
expected = np.concatenate((srgb, np.ones((height, width, 1))), axis=2)
# Image.set_pixel quantizes to RGBA8 by truncation; allow one step for float32 math.
expected = (np.clip(expected, 0, 1) * 255).astype(np.uint8)
actual = np.asarray(Image.open(root / 'janus-level.png').convert('RGBA'))
error = np.abs(actual.astype(int) - expected.astype(int))
assert error.max() <= 1
assert meta['boss_visible'] and meta['both_behavior_scripts_held'] == 2
record = dict(independent_numpy_srgb=True, image_size=[width, height], max_channel_error=int(error.max()),
              differing_channels=int(np.count_nonzero(error)), finite_raw=True, fixture_only=True)
(root / 'independent-image-verification.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(record)
