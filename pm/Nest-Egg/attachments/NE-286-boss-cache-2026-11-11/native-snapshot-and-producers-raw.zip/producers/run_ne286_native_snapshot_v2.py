from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT = Path('C:/Users/stanl/Github/Nest-Egg')
PROJECT = Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
OUT = ROOT / 'work/ne286-native-snapshot-v2'
OUT.mkdir()
PROBE = PROJECT / 'work/ne286-native-snapshot-v2'
PROBE.mkdir(parents=True)
(PROJECT / 'work/.gdignore').touch()
image_path = (OUT / 'janus-level.png').as_posix()
source = '''extends Node

var _scripts: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_scripts.append(load("res://game/enemies/yong_boss.gd"))
	_scripts.append(load("res://game/enemies/janus_boss.gd"))
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	var level := Level.new()
	level.configure(load("res://data/levels/ch3_gate_hall.tres"))
	add_child(level)
	for step in 90:
		await get_tree().physics_frame
	var boss: Node2D
	for actor in get_tree().get_nodes_in_group(&"enemies"):
		if actor.data != null and actor.data.id == &"janus":
			boss = actor
			break
	if boss == null:
		push_error("[NE286Snapshot] real gate-hall JANUS was not instantiated")
		get_tree().quit(2)
		return
	level.player.health.setup(999, 0.0)
	level.player.global_position = boss.global_position + Vector2(-96, 0)
	level.player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(level.player, true)
	AimInput.restore_direction(Vector2.RIGHT)
	level.hud.visible = false
	var camera := get_viewport().get_camera_2d()
	if camera != null:
		camera.position_smoothing_enabled = false
		camera.reset_smoothing()
		camera.force_update_scroll()
	for step in 18:
		await get_tree().physics_frame
	await RenderingServer.frame_post_draw
	var raw := get_viewport().get_texture().get_image()
	var picture := preload("res://tools/viewport_capture.gd").encode(raw, get_viewport().use_hdr_2d)
	var path := __IMAGE_PATH__
	FileAccess.open(path + ".bin", FileAccess.WRITE).store_buffer(raw.get_data())
	var result := picture.save_png(path)
	if result != OK:
		push_error("[NE286Snapshot] PNG write failed %s: %s" % [result, path])
		get_tree().quit(2)
		return
	var info := {"fixture": true, "not_human_boss_fight": true,
		"both_behavior_scripts_held": _scripts.size(),
		"renderer": RenderingServer.get_current_rendering_method(),
		"hdr_2d": get_viewport().use_hdr_2d, "raw_format": raw.get_format(),
		"scripted_aim": str(level.player.aim_dir), "boss_visible": boss.is_visible_in_tree(),
		"image_size": [picture.get_width(), picture.get_height()],
		"player_feet": str(level.player.global_position), "boss_feet": str(boss.global_position)}
	FileAccess.open(path + ".json", FileAccess.WRITE).store_string(JSON.stringify(info, "  ") + "\\n")
	AudioRelease.begin_shutdown()
	level.queue_free()
	_scripts.clear()
	for step in 4:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	get_tree().quit()
'''.replace('__IMAGE_PATH__', json.dumps(image_path))
(PROBE / 'probe.gd').write_text(source, encoding='utf-8', newline='\n')
(PROBE / 'probe.tscn').write_text('''[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://work/ne286-native-snapshot-v2/probe.gd" id="1"]
[node name="NE286Snapshot" type="Node"]
script = ExtResource("1")
''', encoding='utf-8', newline='\n')
for path in PROBE.iterdir():
    (OUT / path.name).write_bytes(path.read_bytes())
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
inputs = json.loads((ROOT / 'work/ne286-ne267-official/test-source-before.json').read_bytes())
before = {name: sha(PROJECT / name) for name in inputs}
assert before == inputs
command = [sys.executable, str(ROOT / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(PROJECT),
           '--audio-driver', 'Dummy', 'res://work/ne286-native-snapshot-v2/probe.tscn']
environment = os.environ.copy()
environment.update(APPDATA=str(OUT / 'user/roaming'), LOCALAPPDATA=str(OUT / 'user/local'))
for name in ['APPDATA', 'LOCALAPPDATA']:
    Path(environment[name]).mkdir(parents=True)
record = dict(command=command, cwd=str(PROJECT), runner_sha256=sha(Path(__file__)),
              producer_sha256=sha(PROBE / 'probe.gd'), source_before=before)
(OUT / 'command.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
started = time.monotonic()
with (OUT / 'run.log').open('xb') as log:
    process = subprocess.run(command, cwd=PROJECT, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=180)
text = (OUT / 'run.log').read_text(encoding='utf-8', errors='replace')
errors = [line for line in text.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|leaked at exit', line, re.I)]
after = {name: sha(PROJECT / name) for name in inputs}
record = dict(exit=process.returncode, seconds=time.monotonic() - started, error_lines=errors,
              sources_unchanged=after == before, source_after=after)
(OUT / 'exit.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print('native snapshot', process.returncode, 'seconds', record['seconds'], 'errors', errors, 'sources unchanged', record['sources_unchanged'])
assert process.returncode == 0 and not errors and after == before and (OUT / 'janus-level.png').is_file()
