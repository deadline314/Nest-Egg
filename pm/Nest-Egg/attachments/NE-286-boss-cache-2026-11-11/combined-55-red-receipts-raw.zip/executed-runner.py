"""Run the original affected-test entry point on the sealed isolated candidate."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path('C:/Users/stanl/Github/Nest-Egg')
OUT = ROOT / 'work/ne286-ne267-official'
CANDIDATE = json.loads((OUT / 'candidate.json').read_bytes())
PROJECT = Path(CANDIDATE['worktree'])
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
ERRORS = re.compile(r'SCRIPT ERROR|Script Error|ERROR:|Parse Error|Assertion failed', re.I)


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def source_hashes(files):
    return {name: sha(PROJECT / name) for name in files}


def run(command, log, environment):
    started = time.monotonic()
    with (OUT / log).open('xb') as stream:
        process = subprocess.run(command, cwd=PROJECT, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    return dict(command=command, exit=process.returncode, seconds=time.monotonic() - started, log=log, log_sha256=sha(OUT / log))


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=PROJECT).decode().strip() == CANDIDATE['base']
before = source_hashes(CANDIDATE['source_sha256'])
assert before == CANDIDATE['source_sha256']
save('runner-before.json', dict(path=str(Path(__file__)), sha256=sha(Path(__file__))))
save('source-before.json', before)
environment = os.environ.copy()
environment.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', GODOT=ENGINE, SHARDS='4', LOG_DIR=str(OUT / 'logs').replace('\\', '/'))
environment['PATH'] = 'C:/Program Files/Git/bin;C:/Users/stanl/AppData/Local/Programs/Python/Python313;' + environment['PATH']
for key, folder in [('APPDATA', 'roaming'), ('LOCALAPPDATA', 'local'), ('XDG_DATA_HOME', 'data'), ('XDG_CONFIG_HOME', 'config'), ('XDG_CACHE_HOME', 'cache')]:
    path = OUT / 'user' / folder
    path.mkdir(parents=True, exist_ok=True)
    environment[key] = str(path)
record = run([ENGINE, '--headless', '--path', str(PROJECT), '--import'], 'import.log', environment)
record['error_lines'] = [line for line in (OUT / 'import.log').read_text(encoding='utf-8', errors='replace').splitlines() if ERRORS.search(line)]
record['sources_unchanged'] = source_hashes(before) == before
save('import.json', record)
assert record['exit'] == 0 and not record['error_lines'] and record['sources_unchanged'], record
print('import passed', record['seconds'], flush=True)
generated = {}
for name in subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=PROJECT).decode('utf-8').split('\0'):
    if name and name.endswith('.uid') and name not in before:
        generated[name] = sha(PROJECT / name)
save('generated-uid-context.json', generated)
frozen = dict(before, **generated)
save('test-source-before.json', frozen)
command = ['C:/Program Files/Git/bin/bash.exe', 'tools/run_tests_changed.sh', CANDIDATE['base']]
save('command.json', dict(command=command, cwd=str(PROJECT), shards=4, runner_sha256=sha(Path(__file__))))
record = run(command, 'full.log', environment)
after = source_hashes(frozen)
record['sources_unchanged'] = after == frozen
record['changed_sources'] = [name for name in frozen if frozen[name] != after[name]]
record['source_after'] = after
save('exit.json', record)
print('affected tests finished', record['exit'], record['seconds'], 'sources unchanged', record['sources_unchanged'], flush=True)
assert record['sources_unchanged']
raise SystemExit(record['exit'])
