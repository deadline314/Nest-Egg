from pathlib import Path
import hashlib
import json
import math
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PROJECT = Path('D:/NE232/diag-main-f52')
MAIN = PROJECT / 'game/main.gd'
ORIGINAL = MAIN.read_bytes()
SOURCE = ORIGINAL.decode('utf-8')
OLD = '\t\tprint("EDITION_INFO ", JSON.stringify(CampaignEdition.current().scope_report()))'
assert SOURCE.count(OLD) == 1
OUT = ROOT / 'minimize'
OUT.mkdir()
environment = os.environ.copy()
environment['APPDATA'] = str(ROOT / 'user/roaming')
environment['LOCALAPPDATA'] = str(ROOT / 'user/local')
command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', str(PROJECT), '--', '--edition-info']
results = []
cache = {}


def failing(paths):
    key = tuple(paths)
    if key in cache:
        return cache[key]
    case = OUT / f'case-{len(results):03}'
    case.mkdir()
    code = '\t\tvar rows: Array = []\n\t\tfor path in ' + json.dumps(paths) + ':\n\t\t\trows.append(load(path))\n\t\tprint("RETAINED ", rows.size())'
    MAIN.write_text(SOURCE.replace(OLD, code), encoding='utf-8', newline='\n')
    (case / 'main.gd').write_bytes(MAIN.read_bytes())
    started = time.monotonic()
    with (case / 'run.log').open('xb') as log:
        process = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=120)
    text = (case / 'run.log').read_text(encoding='utf-8', errors='replace')
    assert process.returncode == 0 and f'RETAINED {len(paths)}' in text
    assert 'SCRIPT ERROR' not in text
    errors = [line for line in text.splitlines() if 'ERROR' in line or 'leaked at exit' in line]
    failed = bool(errors)
    record = dict(command=command, resources=paths, exit=process.returncode, seconds=time.monotonic() - started,
                  source_sha256=hashlib.sha256(MAIN.read_bytes()).hexdigest(), failed=failed, errors=errors)
    (case / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
    results.append(record)
    cache[key] = failed
    print(case.name, 'files', len(paths), 'FAIL' if failed else 'clean', flush=True)
    return failed


try:
    paths = ['res://data/levels/' + p.name for p in sorted((PROJECT / 'data/levels').glob('*.tres'))]
    assert failing(paths)
    granularity = 2
    while len(paths) >= 2:
        width = math.ceil(len(paths) / granularity)
        reduced = False
        for start in range(0, len(paths), width):
            complement = paths[:start] + paths[start + width:]
            if complement and failing(complement):
                paths = complement
                granularity = max(2, granularity - 1)
                reduced = True
                break
        if not reduced:
            if granularity >= len(paths):
                break
            granularity = min(len(paths), granularity * 2)
    (OUT / 'minimal.json').write_text(json.dumps(dict(resources=paths, cases=len(results)), indent=2) + '\n', encoding='utf-8', newline='\n')
    print('MINIMAL', paths, flush=True)
finally:
    MAIN.write_bytes(ORIGINAL)
