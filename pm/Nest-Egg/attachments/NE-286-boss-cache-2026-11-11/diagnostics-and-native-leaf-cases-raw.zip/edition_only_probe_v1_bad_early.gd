extends SceneTree

func _initialize() -> void:
	call_deferred("_finish")

func _finish() -> void:
	print("EDITION_INFO ", JSON.stringify(CampaignEdition.current().scope_report()))
	CampaignEdition.override_current(null)
	quit()
