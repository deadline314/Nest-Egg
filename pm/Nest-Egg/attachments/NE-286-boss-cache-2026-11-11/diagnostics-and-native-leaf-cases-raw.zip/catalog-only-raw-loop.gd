class_name ResourceCatalog
extends RefCounted
## 資料目錄載入器：把某個資料夾裡同型別的 .tres 讀成一份依 order 排序的清單（消耗品、劇情道具等共用）。
## 資料項需有 `id`（StringName）；可選 `order`（int）與 `validate() -> PackedStringArray`。
## 壞檔、型別不符、重複 id 都會記錄具體路徑並略過，不影響其他資料。


## 讀取 dir 底下所有 `type` 型別的 .tres。tag 是錯誤訊息前綴，例如 "ConsumableBag"。
static func load_dir(dir: String, type: Script, tag: String) -> Array[Resource]:
	var result: Array[Resource] = []
	for file in DirAccess.get_files_at(dir):
		var path := dir.path_join(file.trim_suffix(".remap"))
		if path.ends_with(".tres"):
			var item = load(path)
			if item != null:
				result.append(item)
	return result
static func _is_type(res: Resource, type: Script) -> bool:
	var script := res.get_script() as Script
	while script != null:
		if script == type:
			return true
		script = script.get_base_script()
	return false


static func _by_order(a: Resource, b: Resource) -> bool:
	# order 是可選欄位：沒有這個屬性的資料視為 0，再以 id 排序。
	var order_a := _order_of(a)
	var order_b := _order_of(b)
	if order_a != order_b:
		return order_a < order_b
	return str(a.get(&"id")) < str(b.get(&"id"))


static func _order_of(res: Resource) -> int:
	var value: Variant = res.get(&"order")
	return int(value) if typeof(value) == TYPE_INT or typeof(value) == TYPE_FLOAT else 0
