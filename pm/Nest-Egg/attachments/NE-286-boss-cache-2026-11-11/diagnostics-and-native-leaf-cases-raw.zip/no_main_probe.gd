extends SceneTree

func _initialize() -> void:
	call_deferred("_finish")

func _finish() -> void:
	for step in 4:
		await process_frame
	print("NE232_NO_MAIN_PROBE")
	quit()
