from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PROJECT = Path('D:/NE232/diag-main-f52')
MAIN = PROJECT / 'game/main.gd'
LEAF = PROJECT / 'game/enemies/boss/janus_config.gd'
ORIGINAL = MAIN.read_bytes()
LEAF_SOURCE = LEAF.read_bytes()
OLD = '\t\tprint("EDITION_INFO ", JSON.stringify(CampaignEdition.current().scope_report()))\n\t\tget_tree().quit()\n\t\treturn'
assert ORIGINAL.decode().count(OLD) == 1
OUT = ROOT / 'leaf-cases'
OUT.mkdir()
environment = os.environ.copy()
environment['APPDATA'] = str(ROOT / 'user/roaming')
environment['LOCALAPPDATA'] = str(ROOT / 'user/local')
command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', str(PROJECT), '--', '--edition-info']
results = []
cache_probe = '''		var config_before = JanusBoss._load_config(&"janus")
		var original_values = config_before.duplicate(true)
		config_before["__ne286_cache_hit"] = 286
		var repeated = JanusBoss._load_config(&"janus")
		var passed = repeated.get("__ne286_cache_hit") == 286
		config_before.erase("__ne286_cache_hit")
		repeated.erase("__ne286_cache_hit")
		passed = passed and config_before == original_values and repeated == original_values
		JanusConfig.clear_cache()
		var reloaded = JanusBoss._load_config(&"janus")
		passed = passed and reloaded == original_values
		print("NE286_CACHE ", JSON.stringify({"passed": passed, "values": reloaded}))
		get_tree().quit(0 if passed else 1)
		return'''
cases = []
for kind, paths in [
    ('scripts-yong-first', ['res://game/enemies/yong_boss.gd', 'res://game/enemies/janus_boss.gd']),
    ('scripts-janus-first', ['res://game/enemies/janus_boss.gd', 'res://game/enemies/yong_boss.gd']),
    ('data-yong-first', ['res://data/enemies/yong.tres', 'res://data/enemies/janus.tres']),
    ('data-janus-first', ['res://data/enemies/janus.tres', 'res://data/enemies/yong.tres']),
]:
    code = '\t\tvar rows: Array = []\n\t\tfor path in ' + json.dumps(paths) + ':\n\t\t\trows.append(load(path))\n\t\tprint("RETAINED ", rows.size())\n\t\tget_tree().quit()\n\t\treturn'
    cases.append((kind, code, 0))
cases += [('cache-reuse', cache_probe, 0), ('cache-disabled-negative', cache_probe, 1)]
try:
    for name, code, expected in cases:
        case = OUT / name
        case.mkdir()
        MAIN.write_text(ORIGINAL.decode().replace(OLD, code), encoding='utf-8', newline='\n')
        if name == 'cache-disabled-negative':
            mutated = LEAF_SOURCE.decode().replace('if _config_cache.has(key):', 'if false:')
            assert mutated != LEAF_SOURCE.decode()
            LEAF.write_text(mutated, encoding='utf-8', newline='\n')
        (case / 'main.gd').write_bytes(MAIN.read_bytes())
        (case / 'janus_config.gd').write_bytes(LEAF.read_bytes())
        started = time.monotonic()
        with (case / 'run.log').open('xb') as log:
            process = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=120)
        text = (case / 'run.log').read_text(encoding='utf-8', errors='replace')
        errors = [line for line in text.splitlines() if 'ERROR' in line or 'leaked at exit' in line]
        assert process.returncode == expected and not errors, (name, process.returncode, errors)
        record = dict(case=name, command=command, exit=process.returncode, expected_exit=expected,
                      seconds=time.monotonic() - started, errors=errors,
                      source_sha256={p.relative_to(PROJECT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in [MAIN, LEAF, PROJECT / 'game/enemies/janus_boss.gd']})
        (case / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
        results.append(record)
        print(name, 'exit', process.returncode, '0 diagnostics', flush=True)
finally:
    MAIN.write_bytes(ORIGINAL)
    LEAF.write_bytes(LEAF_SOURCE)
(OUT / 'summary.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf-8', newline='\n')
