extends SceneTree

func _initialize() -> void:
	call_deferred("_finish")

func _finish() -> void:
	var script = load("res://core/campaign_edition.gd")
	var edition = script.current()
	print("EDITION_INFO ", JSON.stringify(edition.scope_report()))
	script.override_current(null)
	edition = null
	script = null
	quit()
