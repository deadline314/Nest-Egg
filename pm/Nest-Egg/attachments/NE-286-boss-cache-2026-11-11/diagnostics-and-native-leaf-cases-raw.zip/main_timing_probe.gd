extends SceneTree

var _probe_script: GDScript

func _initialize() -> void:
	var source := FileAccess.get_file_as_string("res://game/main.gd")
	if OS.get_cmdline_user_args().has("--defer-quit"):
		var old := "\t\tget_tree().quit()\n\t\treturn"
		assert(source.count(old) == 1)
		source = source.replace(old, "\t\tfor step in 4:\n\t\t\tawait get_tree().process_frame\n\t\tget_tree().quit()\n\t\treturn")
	elif OS.get_cmdline_user_args().has("--clear-edition"):
		var old := "\t\tget_tree().quit()\n\t\treturn"
		assert(source.count(old) == 1)
		source = source.replace(old, "\t\tCampaignEdition.override_current(null)\n\t\tget_tree().quit()\n\t\treturn")
	elif OS.get_cmdline_user_args().has("--clear-animators"):
		var old := "\t\tget_tree().quit()\n\t\treturn"
		assert(source.count(old) == 1)
		source = source.replace(old, "\t\tCharacterRig.ANIMATORS.clear()\n\t\tget_tree().quit()\n\t\treturn")
	elif OS.get_cmdline_user_args().has("--clear-melee-default"):
		var old := "\t\tget_tree().quit()\n\t\treturn"
		assert(source.count(old) == 1)
		source = source.replace(old, "\t\tMeleeData._default = null\n\t\tget_tree().quit()\n\t\treturn")
	elif OS.get_cmdline_user_args().has("--clear-static-roots"):
		var old := "\t\tget_tree().quit()\n\t\treturn"
		assert(source.count(old) == 1)
		source = source.replace(old, "\t\tCampaignEdition.override_current(null)\n\t\tMeleeData._default = null\n\t\tCharacterRig.ANIMATORS.clear()\n\t\tget_tree().quit()\n\t\treturn")
	_probe_script = GDScript.new()
	_probe_script.source_code = source
	assert(_probe_script.reload() == OK)
	call_deferred("_start_main")

func _start_main() -> void:
	root.add_child(_probe_script.new())
