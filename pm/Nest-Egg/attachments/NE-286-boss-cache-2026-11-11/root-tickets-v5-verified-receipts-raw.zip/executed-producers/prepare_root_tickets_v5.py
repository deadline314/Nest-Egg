from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

ROOT=Path('C:/Users/stanl/Github/Nest-Egg')
PROJECT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
OUT=ROOT/'work/root-tickets-official-v5'
OUT.mkdir()
sha=lambda data:hashlib.sha256(data).hexdigest()
frozen=json.loads((ROOT/'work/queue-official-v4/test-source-before.json').read_bytes())
assert len(frozen)==360 and all(sha((PROJECT/n).read_bytes())==v for n,v in frozen.items())
index=json.loads((ROOT/'pm/Nest-Egg/attachments/NE-286-boss-cache-2026-11-11/archives.json').read_bytes())
assert any(r['file']=='combined-77-v4-red-source-delta-raw.zip' for r in index)
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=PROJECT).strip()
dirty=set(filter(None,subprocess.check_output(['git','diff','--name-only','-z'],cwd=PROJECT).decode().split('\0')))
assert dirty<=set(frozen)
tree=set(filter(None,subprocess.check_output(['git','ls-tree','-r','--name-only','-z','2189222d'],cwd=PROJECT).decode().split('\0')))
existing=sorted(set(frozen)&tree)
data=subprocess.check_output(['git','archive','--format=tar','2189222d','--',*existing],cwd=PROJECT)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for member in archive:
        if member.isdir():continue
        assert member.isfile() and member.name in frozen
        path=PROJECT/member.name
        assert PROJECT.resolve() in path.resolve().parents
        path.write_bytes(archive.extractfile(member).read())
removed=[]
for name in sorted(set(frozen)-tree):
    path=PROJECT/name
    assert PROJECT.resolve() in path.resolve().parents and path.is_file() and sha(path.read_bytes())==frozen[name]
    path.unlink()  # Only this owned, byte-checked file; no directory deletion.
    removed.append(name)
assert not subprocess.check_output(['git','diff','--name-only'],cwd=PROJECT).strip()
base='1549787c470d4a6cf4a51e21bac9b460b71870bd'
subprocess.run(['git','switch','--detach',base],cwd=PROJECT,check=True)
owned={}
for name in ['game/enemies/janus_boss.gd','game/enemies/boss/janus_config.gd',
             'game/enemies/boss/janus_config.gd.uid','tests/suite/test_ch3_enemies.gd',
             'tests/helpers/janus_config_checks.gd','tests/helpers/janus_config_checks.gd.uid',
             'tests/helpers/reach_completion_checks.gd','tests/helpers/reach_completion_checks.gd.uid',
             'tests/helpers/interaction_holster_checks.gd']:
    owned[name]=(ROOT/name).read_bytes()
for name in ['game/cutscene/cutscene_player.gd','game/cutscene/cutscene_actor.gd','game/cutscene/cutscene_reach.gd']:
    owned[name]=(ROOT/'work/ne287-native-pair-v4/new/source'/name).read_bytes()
name='tests/suite/test_cutscene.gd'
source=subprocess.check_output(['git','show',f'{base}:{name}'],cwd=PROJECT).decode('utf-8')
old='\tawait preload("res://tests/helpers/kitchen_choreography_checks.gd").run(self)'
assert source.count(old)==1
owned[name]=source.replace(old,'\tawait preload("res://tests/helpers/reach_completion_checks.gd").run(self)\n'+old).encode('utf-8')
assert len(owned)==13
for name,data in owned.items():
    path=PROJECT/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
expected={n:sha(data) for n,data in owned.items()}
def save(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
save('isolation.json',dict(previous_red_sources=len(frozen),red_fully_sealed=True,
    restored_existing=len(existing),removed_only_owned_byte_checked_files=removed,
    scope='Exact intended NE286 six + NE287 six (native-tested pure move-independent player) + NE288 one; no NE267/NE277/BG56 uncommitted product changes'))
save('candidate.json',dict(base=base,worktree=str(PROJECT),scope='NE286, NE287, NE288 only, exact proposed commit source',source_sha256=expected))
original=ROOT/'work/run_ne286_ne267_official.py';runner=ROOT/'work/run_root_tickets_official_v5.py'
assert not runner.exists()
runner.write_text(original.read_text(encoding='utf-8').replace("OUT = ROOT / 'work/ne286-ne267-official'","OUT = ROOT / 'work/root-tickets-official-v5'"),encoding='utf-8',newline='\n')
save('runner-derivation.json',dict(original_sha256=sha(original.read_bytes()),runner_sha256=sha(runner.read_bytes()),only_change='OUT directory'))
print('isolated',len(owned),'actual proposed source files; old 77-group red preserved; base',base)
