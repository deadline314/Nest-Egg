from pathlib import Path
import hashlib
import json
import shutil

ROOT=Path('C:/Users/stanl/Github/Nest-Egg')
PROJECT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
OUT=ROOT/'work/queue-official-v4'
OUT.mkdir()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
frozen=json.loads((ROOT/'work/ne287-c-adoption/managed-current-source.json').read_bytes())
assert len(frozen)==332 and all(sha(PROJECT/n)==v for n,v in frozen.items())
handoff=ROOT/'work/ne277-timing-isolated/root-union-handoff.json'
proposal=json.loads(handoff.read_bytes())
geometry=proposal['source_sha256']
assert len(geometry)==26 and not (set(geometry)&set(frozen))
other=Path('D:/NestEggVerification/ticket-batch-20261111')
changes=[]
for name,digest in geometry.items():
    assert sha(ROOT/name)==sha(other/name)==digest,name
    target=PROJECT/name
    changes.append(dict(path=name,before=sha(target) if target.is_file() else None,after=digest,kind='NE277'))
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/name,target)
    frozen[name]=digest
fixture=proposal['ne288']
name=fixture['target'];source=Path(fixture['source'])
assert sha(source)==sha(other/name)==fixture['sha256']
assert sha(PROJECT/name)==fixture['original_sha256']
assert name not in frozen
changes.append(dict(path=name,before=sha(PROJECT/name),after=fixture['sha256'],kind='NE288'))
shutil.copyfile(source,PROJECT/name)
frozen[name]=fixture['sha256']
assert len(frozen)==359 and all(sha(PROJECT/n)==v for n,v in frozen.items())
def save(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
save('adoption.json',dict(changes=changes,geometry_handoff_sha256=sha(handoff),not_geometry_official_until_actual_runner_passes=True))
save('candidate.json',dict(base='2189222d22eeb2200f7f15438c890694564107e1',worktree=str(PROJECT),
    scope='NE267 frozen v3 + NE286 leaf cache + NE287 actual reach completion + NE277 exact 26 geometry sources + NE288 exact final neutral/published fixture; excludes BG56 candidate and old D nine-tool context',source_sha256=frozen))
original=ROOT/'work/run_ne286_ne267_official.py'
runner=ROOT/'work/run_queue_official_v4.py'
assert not runner.exists()
runner.write_text(original.read_text(encoding='utf-8').replace("OUT = ROOT / 'work/ne286-ne267-official'", "OUT = ROOT / 'work/queue-official-v4'"),encoding='utf-8',newline='\n')
save('runner-derivation.json',dict(original_sha256=sha(original),runner_sha256=sha(runner),only_change='OUT directory'))
print('prepared',len(frozen),'actual sources; adopted26geometry+1fixture, no source collisions')
