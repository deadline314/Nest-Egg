from pathlib import Path
import hashlib
import json
import time
import urllib.request
import zipfile

root = Path('D:/NE232/templates-4.7.2')
root.mkdir(parents=True, exist_ok=True)
url = 'https://github.com/godotengine/godot-builds/releases/download/4.7.2-stable/Godot_v4.7.2-stable_export_templates.tpz'
expected = 'f298490b8d44d934be425a5a65a51bf15f422428b229a06a6e11d9ffea248011'
archive = root / 'Godot_v4.7.2-stable_export_templates.tpz'
if not archive.exists():
    partial = root / (archive.name + '.part')
    started = time.monotonic()
    with urllib.request.urlopen(url, timeout=60) as response, partial.open('xb') as target:
        sha = hashlib.sha256()
        total = 0
        while block := response.read(1024 * 1024):
            target.write(block)
            sha.update(block)
            total += len(block)
            if total % (64 * 1024 * 1024) == 0:
                print('downloaded', total, 'bytes', flush=True)
    assert total == 1281349702 and sha.hexdigest() == expected
    partial.rename(archive)
    print('download verified', total, time.monotonic() - started, flush=True)
else:
    with archive.open('rb') as source:
        assert hashlib.file_digest(source, 'sha256').hexdigest() == expected
files = {}
with zipfile.ZipFile(archive) as z:
    for name in ['version.txt', 'linux_release.x86_64', 'windows_release_x86_64.exe']:
        member = 'templates/' + name
        destination = root / name
        assert not destination.exists(), destination
        with z.open(member) as source, destination.open('xb') as target:
            sha = hashlib.sha256()
            total = 0
            while block := source.read(1024 * 1024):
                sha.update(block)
                target.write(block)
                total += len(block)
        files[name] = {'sha256': sha.hexdigest(), 'bytes': total}
provenance = {'url': url, 'archive_sha256': expected, 'archive_bytes': archive.stat().st_size, 'files': files}
(root / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(provenance, indent=2), flush=True)
