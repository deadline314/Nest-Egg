extends Node

const CHAPTERS := ["ch1_kasa","ch2_heron"]
const SYSTEM := ["broadcast","label","note","terminal","voice","weather"]
const LANGUAGES := ["zh","en","ja"]
const SPEAKERS := ["ali","banyan","broadcast","chen","egret","hawker","hawker_far","hong",
	"label","lamp","medic","note","old_k","patroller","rin","shen","terminal","vig","voice",
	"weather","window_clerk","xiaowei","ye","yong","zheng"]

var out := ""
var checks := 0
var failed := 0
var layers: DialogueLayer
var animated: CutsceneDialogue
var observations: Dictionary = {}
var capture_rows: Dictionary = {}
var natural_native := false


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	if not out.is_absolute_path():
		get_tree().quit(2)
		return
	natural_native = DisplayServer.get_name() != "headless"
	if natural_native:
		get_window().set_flag(Window.FLAG_NO_FOCUS,true)
	_run.call_deferred()


func _run() -> void:
	Settings.set_reduce_ui_motion(true)
	layers = DialogueLayer.new()
	add_child(layers)
	var canvas := CanvasLayer.new()
	canvas.layer = UiLayers.DIALOGUE + 1
	add_child(canvas)
	animated = CutsceneDialogue.new()
	canvas.add_child(animated)
	await get_tree().process_frame
	if natural_native:
		Story.set_language("zh")
		await _take_examples()
	else:
		for code: String in LANGUAGES:
			if not _check(Story.set_language(code), "official language loads: "+code):
				continue
			observations[code] = _inspect_language()
		await _check_map_bubble()
	var file := FileAccess.open(out.path_join("portraits.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"assertions":checks,"failures":failed,"languages":observations,"native":capture_rows},"  ")+"\n")
	file.close()
	layers.cancel_radio()
	layers.cancel_cinematic()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failed else 0)


func _inspect_language() -> Dictionary:
	var actual: Dictionary = Story.audit_data()["scenes"]
	var speakers := {}
	var representatives := {}
	var scene_count := 0
	var turns_count := 0
	var frame_count := 0
	for chapter: String in CHAPTERS:
		var path := "res://data/story/%s.json" % chapter
		var official: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
		for scene_name: String in (official["scenes"] as Dictionary):
			if not _check(actual.has(scene_name), "runtime scene exists "+scene_name):
				continue
			scene_count += 1
			var entry: Dictionary = actual[scene_name]
			var mode := str(entry.get("mode","radio"))
			var lines: Array[Dictionary] = []
			_find_turns(entry,lines)
			for one in lines:
				turns_count += 1
				var id := str(one["speaker"])
				var info := Story.speaker(id)
				var portrait := str(info.get("portrait",""))
				var official_system := id in SYSTEM
				_check(not str(info.get("name","")).is_empty() and not portrait.is_empty(),
					"resolved speaker "+id+" in "+scene_name)
				_check(portrait.ends_with("/system.png") == official_system,
					"speaker texture class "+id+" in "+scene_name)
				if not speakers.has(id):
					var texture := RigLibrary.optional_texture(portrait)
					_check(texture != null and texture.resource_path == portrait, "imported texture: "+id)
					speakers[id] = {"path":portrait,"localized_name":info.get("name",""),"turns":0,"modes":[]}
				var counts: Dictionary = speakers[id]
				counts["turns"] += 1
				if mode not in counts["modes"]:
					counts["modes"].append(mode)
				var key := mode + ":" + id
				if not representatives.has(key):
					representatives[key] = {"mode":mode,"line":one,"path":portrait,"scene":scene_name}
	for details: Dictionary in representatives.values():
		_test_widget(details)
		frame_count += 1
	var speaker_ids := speakers.keys()
	speaker_ids.sort()
	_check(speaker_ids == SPEAKERS, "all first and second chapter speaking ids audited")
	var unique := {}
	for id: String in speakers:
		if id in SYSTEM or id == "hawker_far":
			continue
		var source: String = speakers[id]["path"]
		_check(not unique.has(source), "one human portrait identity: "+id)
		unique[source] = id
	_check(speakers.get("hawker", {}).get("path", "") == speakers.get("hawker_far", {}).get("path", "!"), "same hawker near and over radio")
	return {"scene_count":scene_count,"speaking_turns":turns_count,"widget_cases":frame_count,
		"human_portraits":unique.size(),"speakers":speakers}


func _find_turns(value: Variant, turns: Array[Dictionary]) -> void:
	if value is Dictionary:
		if typeof(value.get("speaker")) == TYPE_STRING and typeof(value.get("text")) == TYPE_STRING and not String(value["text"]).is_empty():
			turns.append(value)
		for item in value.values():
			if item is Array or item is Dictionary:
				_find_turns(item,turns)
	elif value is Array:
		for item in value:
			if item is Array or item is Dictionary:
				_find_turns(item,turns)


func _test_widget(data: Dictionary) -> void:
	var mode: String = data["mode"]
	var own: Dictionary = data["line"]
	var expected: String = data["path"]
	var id := str(own["speaker"])
	if mode == "animated":
		animated.show_line(Story.speaker(id),str(own["text"]),str(own.get("style","normal")))
		_check(animated._frame.is_visible_in_tree() and animated._portrait.texture != null
			and animated._portrait.texture.resource_path == expected, "animated portrait "+id)
		animated.hide_box()
		return
	# The instant preview reaches the same widget that a line uses after its authored silence.
	var line := own.duplicate()
	line.erase("delay")
	var normalized := Story._resolve_lines([line])
	if mode == "dialogue" or mode == "cinematic":
		layers.start_cinematic(&"portrait_audit",normalized)
		_check(layers._portrait.is_visible_in_tree() and layers._portrait.texture != null
			and layers._portrait.texture.resource_path == expected, "dialogue portrait "+id)
		layers.cancel_cinematic()
	else:
		layers.enqueue_radio(&"portrait_audit",normalized)
		_check(layers._radio_portrait.is_visible_in_tree() and layers._radio_portrait.texture != null
			and layers._radio_portrait.texture.resource_path == expected, "radio portrait "+id)
		layers.cancel_radio()


func _take_examples() -> void:
	var examples := [ ["shen","radio"],["egret","animated"],["xiaowei","animated"],["broadcast","animated"] ]
	var actual: Dictionary = Story.audit_data()["scenes"]
	for item: Array in examples:
		var actor: String = item[0]
		var mode: String = item[1]
		var match_line := {}
		var scene_name := ""
		for name: String in _formal_scene_names():
			var source: Dictionary = actual[name]
			if str(source.get("mode","radio")) != mode:
				continue
			var all_turns: Array[Dictionary] = []
			_find_turns(source,all_turns)
			for own: Dictionary in all_turns:
				if own["speaker"] == actor:
					match_line = own
					scene_name = name
					break
			if not match_line.is_empty():
				break
		if not _check(not match_line.is_empty(), "native original line for "+actor):
			continue
		if mode == "animated":
			animated.show_line(Story.speaker(actor),str(match_line["text"]),str(match_line.get("style","normal")))
			animated.complete()
		else:
			var ready := match_line.duplicate()
			ready.erase("delay")
			layers.enqueue_radio(&"portrait_audit",Story._resolve_lines([ready]))
			layers._radio_text.visible_ratio = 1.0
		await RenderingServer.frame_post_draw
		var path := out.path_join(actor+".png")
		var result := preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(path)
		_check(result==OK,"native portrait captured: "+actor)
		capture_rows[actor]={"mode":mode,"portrait":Story.speaker(actor)["portrait"],"scene":scene_name}
		layers.cancel_radio()
		animated.hide_box()


func _formal_scene_names() -> Array[String]:
	var names: Array[String] = []
	for chapter: String in CHAPTERS:
		var path := "res://data/story/%s.json" % chapter
		var source: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
		for id: String in source["scenes"]:
			if id not in names:
				names.append(id)
	return names


func _check_map_bubble() -> void:
	var host := MapBubbles.new()
	add_child(host)
	var anchor := Node2D.new()
	anchor.position = Vector2(220, 240)
	add_child(anchor)
	var actual: Dictionary = Story.audit_data()["scenes"]
	var tested := false
	for scene_name in _formal_scene_names():
		if str(actual[scene_name].get("mode", "")) != "bubbles":
			continue
		var lines := Story.resolved_lines(StringName(scene_name))
		if lines.is_empty():
			continue
		_check(not host.can_show_all(lines), "bubble host rejects absent actors for radio fallback")
		host.anchor_resolver = func(_speaker: String) -> Node2D: return anchor
		_check(host.can_show_all(lines), "bubble host accepts local actors")
		host.show_lines(StringName(scene_name), lines)
		await get_tree().process_frame
		await get_tree().process_frame
		_check(host.visible_count() > 0 and host._active[0].get("text") == lines[0].get("text")
			and host._active[0].get("name") == lines[0].get("name"),
			"local bubble presents the line and speaker at the world anchor")
		tested = true
		break
	_check(tested, "a formally authored bubble scene exercised")
	host.queue_free()
	anchor.queue_free()


func _check(value: bool, reason: String) -> bool:
	checks += 1
	if not value:
		failed += 1
		print("FAIL "+reason)
	return value
