from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

base=Path(__file__).resolve().parent
project=base.parent/"ne218-baseline-20261117"
scope=base/sys.argv[1]
headless="headless" in sys.argv[2:]
scope.mkdir()
env=os.environ.copy()
for key in ("APPDATA","LOCALAPPDATA","TEMP","TMP","TMPDIR","XDG_CONFIG_HOME","XDG_DATA_HOME"):
    profile=scope/key
    profile.mkdir()
    env[key]=str(profile)
sources=["data/story/ch1_kasa.json","data/story/ch2_heron.json","autoload/story.gd","ui/dialogue_layer.gd","game/cutscene/cutscene_dialogue.gd"]
sha=lambda p:sha256(p.read_bytes()).hexdigest()
fingerprint={path:sha(project/path) for path in sources}
engine="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
command=[engine,"--path",str(project)]
if headless:
    command.append("--headless")
else:
    command=[sys.executable,"-B",str(project/"tools/comfyui/gpu_lock.py"),"--"]+command
    command+=["--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy","--resolution","1280x720"]
command+=["--fixed-fps","60","--quit-after","2400",str(base/"observe.tscn"),"--",f"--out={scope}"]
(scope/"command.json").write_text(json.dumps({"argv":command,"sources":fingerprint},indent=2)+"\n")
with (scope/"engine.log").open("wb") as f:
    proc=subprocess.run(command,cwd=project,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=215)
log=(scope/"engine.log").read_text(encoding="utf8",errors="replace")
assert proc.returncode==0 and not re.search(r"^(?:SCRIPT )?ERROR:|^FAIL ",log,re.M),log[-5300:]
audit=json.loads((scope/"portraits.json").read_bytes())
assert audit["failures"]==0
if headless:
    assert set(audit["languages"])=={"zh","en","ja"}
    print({k:{a:b for a,b in x.items() if a!="speakers"} for k,x in audit["languages"].items()})
else:
    assert set(audit["native"])=={"shen","egret","xiaowei","broadcast"}
    print(audit["native"])
assert fingerprint=={path:sha(project/path) for path in sources}
