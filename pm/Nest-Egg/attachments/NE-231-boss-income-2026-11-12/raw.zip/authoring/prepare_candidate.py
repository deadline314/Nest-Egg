"""Create only the three D-owned candidate files. Does not modify C/managed or start Godot."""
from pathlib import Path
import json,subprocess
from run_original import ROOT,OUT,git,save,sha

DEST=Path('D:/NestEggVerification/ne231-nonlethal-income-20261112')
FILES=['data/enemies/yong.tres','data/enemies/janus.tres','tests/suite/test_progression.gd']

def main():
 assert DEST.resolve().parent==Path('D:/NestEggVerification').resolve()
 assert not DEST.exists(),'refusing to overwrite an existing candidate'
 DEST.mkdir()
 source={name:(ROOT/name).read_bytes() for name in FILES}
 for name,data in source.items():
  assert b'\r' not in data,('source EOL must be explicit',name)
  assert data==git('show','HEAD:'+name),('unpublished candidate input',name)
 changes={}
 for name,data in source.items():
  if name.endswith('yong.tres'):before=b'credit_value = 120\n';after=b'credit_value = 0\n'
  elif name.endswith('janus.tres'):before=b'credit_value = 1\n';after=b'credit_value = 0\n'
  else:
   before=b'\t\tcheck(enemy != null and enemy.credit_value > 0, "enemy drops credits: %s" % file)\n'
   after=b'\t\tif enemy != null and enemy.id in [&"yong", &"janus"]:\n\t\t\tcheck(enemy.credit_value == 0, "nonlethal story actor has no death bounty: %s" % file)\n\t\telse:\n\t\t\tcheck(enemy != null and enemy.credit_value > 0, "enemy drops credits: %s" % file)\n'
  assert data.count(before)==1,name
  candidate=data.replace(before,after)
  for folder,payload in [('baseline',data),('candidate',candidate)]:
   target=DEST/folder/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(payload)
  changes[name]={'before_sha256':sha(data),'after_sha256':sha(candidate),'before':str(DEST/'baseline'/name),'candidate':str(DEST/'candidate'/name)}
 base=git('rev-parse','HEAD').decode().strip()
 save(DEST/'candidate.json',{'base':base,'scope':'D-only two unused death-bounty metadata values and a narrow nonlethal-vs-ordinary data contract. No behavior/story payment change. Not yet adopted or formal-regression tested.','files':changes})
 command=['python','-X','utf8','tools/select_tests.py','--files',*FILES,'--explain']
 result=subprocess.run(command,cwd=ROOT,check=True,capture_output=True)
 (DEST/'selector.stdout').write_bytes(result.stdout);(DEST/'selector.stderr').write_bytes(result.stderr)
 save(DEST/'selector-command.json',{'command':command,'cwd':str(ROOT),'exit':result.returncode,'selector_sha256':sha((ROOT/'tools/select_tests.py').read_bytes()),'actual_game_tests_started':False})
 print(json.dumps({'candidate':str(DEST),'base':base,'files':changes,'selector':result.stdout.decode('utf-8')}))

if __name__=='__main__':main()
