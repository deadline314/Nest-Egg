"""Seal the small CPU evidence packet; raw engine bytes are never normalized."""
from pathlib import Path
import hashlib,json,shutil,zipfile
from run_original import OUT,save,sha
from prepare_candidate import DEST

ATTACH=OUT.parents[1]/'pm/Nest-Egg/attachments/NE-231-boss-income-2026-11-12'
RUNS={
 'original-ledger':'original-1794421491041687600',
 'original-actor-controls':'boss-control-1794422072874860900',
 'candidate-v2-controls':'candidate-control-1794422678952181600',
 'candidate-v3-controls':'candidate-control-1794422868384400500',
}

def main():
 ATTACH.mkdir(parents=True,exist_ok=True);archive=ATTACH/'raw.zip'
 assert not archive.exists(),'refusing to overwrite an existing raw packet'
 members={}
 def add(name,path):
  assert name not in members
  members[name]=Path(path).read_bytes()
 for folder,name in RUNS.items():
  for path in sorted((OUT/name).iterdir()):
   if path.is_file():add(folder+'/'+path.name,path)
 for path in sorted((OUT/'frozen-inputs').rglob('*')):
  if path.is_file():add('frozen-inputs/'+path.relative_to(OUT/'frozen-inputs').as_posix(),path)
 for name,item in json.loads((DEST/'candidate.json').read_bytes())['files'].items():
  add('candidate-v2-source/'+name,DEST/'candidate-v2-original'/name)
 add('candidate-v2-source/candidate.json',DEST/'candidate-v2-original/candidate.json')
 add('candidate-v3-source/candidate.json',DEST/'candidate.json')
 for path in sorted(OUT.iterdir()):
  if path.is_file() and path.suffix in ['.py','.gd','.tscn']:
   add('authoring/'+path.name,path)
 for name in ['original-source-audit.json','candidate-source-audit.json','candidate-v3-source-audit.json']:
  add('independent/'+name,OUT/name)
 members['provenance.json']=(json.dumps({
  'original_ledger_base':'faa5e4e84155e72509e325967d22787e6c74097e',
  'original_ledger_context':'UI six frozen working files, individually recorded; economics published',
  'actor_and_candidate_control_base':'83319fef08227dd4868474fa2307c305dd7f703d',
  'actor_and_candidate_control_context':'Only the separately published NE291 CombatHUD fixture; UI six had been restored',
  'historical_tests_source':'Original actor-control captures base+tracked diff; Ch2/Ch3 test individual hashes were not taken before that run. Their unmodified immutable Git833 bytes were retrieved afterwards, as disclosed per file in frozen-inputs/manifest.json. Final v3 control directly guards all tracked test scripts.',
  'ram_override':'Candidate controls load real D TRES files and call Resource.take_over_path in this process only. Candidate suite copies remove only duplicate global class_name. These are narrow controls, not formal full-suite results.',
  'authoring_failures':'The first input freeze stopped on missing Ch2 test prehash; its incomplete source copy is retained at work/ne231-ledger-published/frozen-inputs-incomplete-v2. No final manifest or successful validation was claimed for it.',
  'formal_affected':'Pending Root joint official regression; no passing result invented here.',
  'natural_playthrough':False,'performance_measurement':False,'physical_controller':False,
 },ensure_ascii=False,indent=2)+'\n').encode()
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as out:
  for name,data in sorted(members.items()):out.writestr(name,data)
 manifest=json.loads((DEST/'candidate.json').read_bytes())
 index={'raw':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':{name:sha(data) for name,data in sorted(members.items())},'final_sources':manifest['files'],'formal_affected':'pending','raw_bytes_normalized':False}
 save(ATTACH/'index.json',index)
 shutil.copyfile(OUT/'audit.py',ATTACH/'audit.py')
 print(json.dumps({'attachment':str(ATTACH),'members':len(members),'bytes':index['bytes'],'sha256':index['sha256']}))

if __name__=='__main__':main()
