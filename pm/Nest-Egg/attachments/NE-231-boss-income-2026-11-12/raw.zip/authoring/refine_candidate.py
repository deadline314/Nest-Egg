"""Retain v2 and apply review corrections only to the D-owned contract wording/assertion."""
import json,shutil
from prepare_candidate import DEST
from run_original import save,sha

def main():
 manifest_path=DEST/'candidate.json';old=manifest_path.read_bytes();manifest=json.loads(old)
 history=DEST/'candidate-v2-original';assert not history.exists();history.mkdir()
 (history/'candidate.json').write_bytes(old)
 for name,item in manifest['files'].items():
  data=__import__('pathlib').Path(item['candidate']).read_bytes();assert sha(data)==item['after_sha256']
  path=history/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
 changes={
 'tests/suite/test_progression.gd':{'nonlethal story actor has no death bounty':'story actor without credit drops has no death bounty'},
 'tests/suite/test_economy.gd':{
  'these story actors finish alive and are paid by their one-time story transactions.':'these actors do not publish credit drops; their story rewards are settled separately.',
  '_test_nonlethal_story_income':'_test_story_actors_without_drops',
  'nonlethal story actor data loads':'story actor without credit drops loads',
  'an alive story completion must not add a death bounty':'a story completion without credit drops must not add a death bounty',
  'grunt.credit_value == 8 and int(EconomyReport.area_income(layout)["total"]) == 8':'grunt.credit_value > 0 and int(EconomyReport.area_income(layout)["enemies"]) == grunt.credit_value and int(EconomyReport.area_income(layout)["total"]) == grunt.credit_value',
  'ordinary enemy death income remains its real eight-credit drop':'ordinary enemy death income equals its actual positive resource credit value'
 }}
 from pathlib import Path
 for name,replacements in changes.items():
  item=manifest['files'][name];path=Path(item['candidate']);text=path.read_text(encoding='utf-8')
  for before,after in replacements.items():
   assert before in text,(name,before);text=text.replace(before,after)
  data=text.encode();assert b'\r' not in data;path.write_bytes(data);item['after_sha256']=sha(data)
 manifest['scope']='Final D-only v3: two unused credit-drop values, narrow story-actor/ordinary-enemy contract and real EconomyReport/layout regression. Story rewards are settled separately; Health.died is not equated with an ordinary loot-producing death. No behavior or payment changes.'
 save(manifest_path,manifest);print(json.dumps({name:item['after_sha256'] for name,item in manifest['files'].items()}))

if __name__=='__main__':main()
