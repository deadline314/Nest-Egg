"""Run the published ledger once, headless, with explicit output and isolated storage."""
from pathlib import Path
import hashlib,json,os,subprocess,time
from concurrent.futures import ThreadPoolExecutor

ROOT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
OUT=Path(__file__).resolve().parent
GODOT=Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
BASE='faa5e4e84155e72509e325967d22787e6c74097e'

def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,data):path.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
def git(*args):return subprocess.run(['git',*args],cwd=ROOT,check=True,capture_output=True).stdout

def main():
 assert git('rev-parse','HEAD').decode().strip()==BASE
 run=OUT/('original-'+str(time.time_ns()));run.mkdir(parents=True)
 names=git('ls-files','-z','--','core','game','autoload','data','project.godot','tools/campaign_ledger.gd','tools/campaign_ledger.tscn','tests/helpers/campaign_ledger_checks.gd','tests/suite/test_economy.gd').decode().split('\0')
 names=sorted({name for name in names if name and (ROOT/name).is_file()})
 def snapshot():
  with ThreadPoolExecutor(max_workers=4) as pool:return dict(pool.map(lambda name:(name,sha((ROOT/name).read_bytes())),names))
 before=snapshot()
 # Economic inputs must be published; UI's six frozen changes are recorded as
 # context rather than silently described as a pristine whole working tree.
 changed=git('diff','--name-only','HEAD','--','core','game','autoload','data','project.godot','tools/campaign_ledger.gd','tools/campaign_ledger.tscn','tests/helpers/campaign_ledger_checks.gd','tests/suite/test_economy.gd').decode().splitlines()
 assert not changed,('unpublished economic input',changed)
 context_names=git('diff','--name-only','HEAD').decode().splitlines()
 context={name:sha((ROOT/name).read_bytes()) for name in context_names}
 save(run/'source-before.json',{'base':BASE,'economic_inputs':before,'other_working_context':context,'whole_tree_pristine':False})
 command=[str(GODOT),'--headless','--quit-after','180','--path',str(ROOT),'res://tools/campaign_ledger.tscn','--','--json='+str(run/'ledger.json')]
 save(run/'command.json',command)
 env=os.environ.copy();env['APPDATA']=str(run/'isolated-appdata')
 save(run/'runner.json',{'sha256':sha(Path(__file__).read_bytes()),'path':str(Path(__file__).resolve()),'godot_sha256':sha(GODOT.read_bytes()),'performance':False,'renderer_used':False,'storage_override':env['APPDATA']})
 started=time.monotonic()
 with (run/'engine.log').open('wb') as log:completed=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 after=snapshot();context_after={name:sha((ROOT/name).read_bytes()) for name in context}
 save(run/'source-after.json',{'base':git('rev-parse','HEAD').decode().strip(),'economic_inputs':after,'other_working_context':context_after})
 text=(run/'engine.log').read_text(encoding='utf-8',errors='replace')
 diagnostic=[line for line in text.splitlines() if any(mark in line for mark in ['SCRIPT ERROR','ERROR:','ObjectDB instances leaked','resources still in use'])]
 result={'exit':completed.returncode,'seconds':time.monotonic()-started,'economic_sources_same':before==after,'context_same':context==context_after,'diagnostics':diagnostic,'performance':False,'output':str(run)}
 save(run/'exit.json',result);print(json.dumps(result,ensure_ascii=False))
 assert completed.returncode==0 and before==after and context==context_after and not diagnostic
 ledger=json.loads((run/'ledger.json').read_bytes());assert not ledger['issues'],ledger['issues']
 print(json.dumps({'chapters':[{k:c[k] for k in ['id','map_main','map_explore','quest_main','quest_side','payments','supplies']} for c in ledger['chapters']],'plan':ledger['plan']},ensure_ascii=False))

if __name__=='__main__':main()
