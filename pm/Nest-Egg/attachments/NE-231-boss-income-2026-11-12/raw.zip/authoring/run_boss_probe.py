"""Explicit single-process headless actor/transaction evidence; no renderer or source mutation."""
from pathlib import Path
import json,os,shutil,subprocess,time
from concurrent.futures import ThreadPoolExecutor
from run_original import ROOT,OUT,GODOT,BASE,git,save,sha
PROBE_BASE='83319fef08227dd4868474fa2307c305dd7f703d'

def main():
 assert git('rev-parse','HEAD').decode().strip()==PROBE_BASE
 reference=json.loads((OUT/'original-1794421491041687600/source-before.json').read_bytes())['economic_inputs']
 def snapshot():
  with ThreadPoolExecutor(max_workers=4) as pool:return dict(pool.map(lambda name:(name,sha((ROOT/name).read_bytes())),reference))
 before=snapshot();assert before==reference,'economic input changed since the original ledger'
 run=OUT/('boss-control-'+str(time.time_ns()));run.mkdir()
 tool=ROOT/'work/ne231-ledger-published';tool.mkdir(parents=True,exist_ok=True)
 for name in ['boss_drop_probe.gd','boss_drop_probe.tscn']:
  data=(OUT/name).read_bytes();(run/name).write_bytes(data);(tool/name).write_bytes(data)
 context_names=git('diff','--name-only','HEAD').decode().splitlines()
 context={name:sha((ROOT/name).read_bytes()) for name in context_names}
 save(run/'source-before.json',{'base':PROBE_BASE,'economic_input_origin':BASE,'economic_inputs':before,'other_working_context':context,'ui_six_present':False})
 command=[str(GODOT),'--headless','--quit-after','20000','--path',str(ROOT),'res://work/ne231-ledger-published/boss_drop_probe.tscn','--','--out='+str(run)]
 save(run/'command.json',command);(run/'executed-runner.py').write_bytes(Path(__file__).read_bytes());(run/'run_original.py').write_bytes((OUT/'run_original.py').read_bytes())
 env=os.environ.copy();env['APPDATA']=str(run/'isolated-appdata')
 started=time.monotonic()
 with (run/'engine.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 after=snapshot();context_after={name:sha((ROOT/name).read_bytes()) for name in context}
 save(run/'source-after.json',{'base':git('rev-parse','HEAD').decode().strip(),'economic_inputs':after,'other_working_context':context_after})
 text=(run/'engine.log').read_text(encoding='utf-8',errors='replace')
 diagnostic=[line for line in text.splitlines() if any(mark in line for mark in ['SCRIPT ERROR','ERROR:','ObjectDB instances leaked','resources still in use'])]
 output={'exit':result.returncode,'seconds':time.monotonic()-started,'economic_sources_same':before==after,'context_same':context==context_after,'diagnostics':diagnostic,'performance':False,'output':str(run)}
 save(run/'exit.json',output);print(json.dumps(output))
 assert result.returncode==0 and before==after and context==context_after and not diagnostic
 observed=json.loads((run/'boss-drops.json').read_bytes());assert observed['checks']>0 and not observed['failures'];print(json.dumps(observed,ensure_ascii=False))

if __name__=='__main__':main()
