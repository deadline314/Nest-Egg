extends Node
## Work-only CPU evidence: existing controlled boss routes plus actual drop publication.
var checks := 0
var failures: Array[String] = []
var records: Array = []
var out := ""

class YongEvidence extends Chapter2EnemiesSuite:
	var route := ""
	var drop_events: Array = []
	var died_signals := 0
	func _saw_child(node: Node) -> void:
		if node is CreditPickup:
			drop_events.append({"value":node.value,"physics":Engine.get_physics_frames()})
	func _saw_death(_info: DamageInfo) -> void:
		died_signals += 1
	func _spawn_yong(wake := true) -> PatternBoss:
		var boss := await super._spawn_yong(wake)
		level._entities.child_entered_tree.connect(_saw_child)
		boss.health.died.connect(_saw_death)
		return boss
	func _subdue_and_pull(boss: PatternBoss, player: Player) -> void:
		await super._subdue_and_pull(boss,player)
		await runner.settle_publication()
		var observed := {"actor":"yong","route":route,"authored_credit_value":boss.data.credit_value,"health":boss.health.current,"floor_health":boss.health.floor_health,"dying":boss.is_dying(),"subdued":boss.call(&"is_subdued"),"health_died_signals":died_signals,"published_credit_pickups":drop_events.duplicate(true)}
		runner.records.append(observed)
		check(observed["subdued"] and not observed["dying"] and died_signals==0,"%s: genuine subdue never emits health death" % route)
		check(drop_events.is_empty(),"%s: no CreditPickup was published during the real controlled route" % route)
	func run() -> void:
		for name in ["cut","keep"]:
			route=name;drop_events.clear();died_signals=0
			Story.reset_progress();_reset_flags()
			if name=="cut":await _test_cut_route()
			else:await _test_keep_route()

class JanusEvidence extends Chapter3EnemiesSuite:
	var drop_events: Array = []
	var died_signals := 0
	func _saw_child(node: Node) -> void:
		if node is CreditPickup:drop_events.append({"value":node.value,"physics":Engine.get_physics_frames()})
	func _saw_death(_info: DamageInfo) -> void:
		died_signals+=1
	func _spawn_janus(player_tile: float, awake := true) -> JanusBoss:
		var boss := await super._spawn_janus(player_tile,awake)
		level._entities.child_entered_tree.connect(_saw_child)
		boss.health.died.connect(_saw_death)
		return boss
	func end_level(ending: Level) -> void:
		await runner.settle_publication()
		runner.records.append({"actor":"janus","route":"halt-and-pull-pin","authored_credit_value":(load(JANUS_PATH) as EnemyData).credit_value,"health_died_signals":died_signals,"published_credit_pickups":drop_events.duplicate(true)})
		check(died_signals==1,"zero stability emits the real Health death signal once")
		check(drop_events.is_empty(),"Janus override halts the rig without publishing a CreditPickup")
		await super.end_level(ending)
	func run() -> void:
		Story.reset_progress()
		await _test_janus_halt_and_pin()

class GruntEvidence extends EnemySuiteBase:
	var drop_events: Array = []
	func _saw_child(node: Node) -> void:
		if node is CreditPickup:drop_events.append(node.value)
	func run() -> void:
		await open_level(3.0)
		level._entities.child_entered_tree.connect(_saw_child)
		var enemy := spawn(GRUNT_PATH,16.0)
		await physics_frames(3)
		var expected := enemy.data.credit_value
		enemy.health.take_damage(lethal())
		await runner.settle_publication()
		check(drop_events.size()==1 and drop_events[0]==expected,"positive control sees the actual ordinary enemy CreditPickup and its full value")
		runner.records.append({"actor":"grunt-positive-control","authored_credit_value":expected,"published_credit_pickups":drop_events.duplicate()})
		await end_level(level)

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
	_run.call_deferred()

func _run() -> void:
	assert(out.is_absolute_path())
	Enemy.activation_culling_enabled=false
	Story.auto_skip=true
	var grunt := GruntEvidence.new(self)
	await grunt.run()
	var yong := YongEvidence.new(self)
	await yong.run()
	var janus := JanusEvidence.new(self)
	await janus.run()
	for path in ["res://data/story_transactions/ch2_yong_subdued.tres","res://data/story_transactions/ch3_gate_disabled.tres"]:
		Progression.reset_run()
		var data := load(path) as StoryTransactionData
		var before := Progression.credits
		var first := Progression.apply_story_transaction(data)
		var after := Progression.credits
		var second := Progression.apply_story_transaction(data)
		_check(after-before==data.credits_delta and Progression.credits==after,"%s: actual registered transaction pays its amount exactly once" % data.id)
		records.append({"transaction":String(data.id),"resource":path,"authored_delta":data.credits_delta,"before":before,"after_first":after,"after_second":Progression.credits,"first_result":first,"second_result":second})
	await AudioRelease.settle(get_tree())
	var file := FileAccess.open(out.path_join("boss-drops.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks":checks,"failures":failures,"records":records,"scope":"Real controlled actor routes, Health signals, published drop nodes and public story transaction API. Not natural combat/route completion or performance."},"  "));file.close()
	print("NE231_BOSS_DROP_DONE checks=%d failures=%d" % [checks,failures.size()])
	get_tree().quit(0 if failures.is_empty() else 1)

func settle_publication() -> void:
	await get_tree().create_timer(0.0,true,false,true).timeout
	await get_tree().create_timer(0.0,true,false,true).timeout

func _check(condition: bool, message: String) -> void:
	checks+=1
	if not condition:failures.append(message);printerr("FAIL: "+message)

func _frames(count: int) -> void:
	for i in count:await get_tree().physics_frame

func _end_level(level: Level) -> void:
	for action in InputMap.get_actions():Input.action_release(action)
	if is_instance_valid(level):
		get_tree().root.remove_child(level);level.free()
	get_tree().paused=false;Engine.time_scale=1.0
	await settle_publication()
