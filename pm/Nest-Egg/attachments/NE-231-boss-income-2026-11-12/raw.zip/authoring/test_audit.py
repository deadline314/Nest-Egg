import copy,json,unittest
from audit import Audit,OUT

class AuditControls(unittest.TestCase):
 def setUp(self):self.ledger=json.loads((OUT/'original-1794421491041687600/ledger.json').read_bytes())
 def test_original_static_ledger_matches_raw_maps_and_registered_prices(self):
  result=Audit().verify(self.ledger);self.assertEqual(result['growth_total'],2300)
 def test_wrong_area_bounty_is_rejected(self):
  self.ledger['chapters'][1]['areas'][0]['income']['enemies']+=1
  with self.assertRaisesRegex(AssertionError,'per-area'):Audit().verify(self.ledger)
 def test_duplicate_transaction_cannot_inflate_income(self):
  chapter=self.ledger['chapters'][1];chapter['transactions'].append(copy.deepcopy(chapter['transactions'][0]))
  with self.assertRaisesRegex(AssertionError,'counted twice'):Audit().verify(self.ledger)
 def test_missing_area_is_not_an_accepted_reduced_scope(self):
  self.ledger['chapters'][0]['areas'].pop()
  with self.assertRaises(AssertionError):Audit().verify(self.ledger)
 def test_modified_death_fee_or_growth_price_is_rejected(self):
  wrong=copy.deepcopy(self.ledger);wrong['plan'][2]['deaths']-=1
  with self.assertRaisesRegex(AssertionError,'wallet'):Audit().verify(wrong)
  self.ledger['growth'][0]['price']-=1
  with self.assertRaisesRegex(AssertionError,'growth price'):Audit().verify(self.ledger)

if __name__=='__main__':unittest.main()
