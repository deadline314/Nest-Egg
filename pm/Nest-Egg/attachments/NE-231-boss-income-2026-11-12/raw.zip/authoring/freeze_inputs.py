"""Freeze only the independently read text/map inputs, verifying their original source hashes."""
import json
from pathlib import Path
from run_original import ROOT,OUT,sha,save,git
from prepare_candidate import DEST

def main():
 manifest=json.loads((DEST/'candidate.json').read_bytes())
 reference=json.loads((OUT/'original-1794421491041687600/source-before.json').read_bytes())['economic_inputs']
 names={path[6:] for path in json.loads((OUT/'original-source-audit.json').read_bytes())['read_sources']}
 names|=set(manifest['files'])
 names|={'core/campaign_ledger.gd','game/enemies/enemy.gd','game/enemies/yong_boss.gd','game/enemies/janus_boss.gd','tests/suite/test_ch2_enemies.gd','tests/suite/test_ch3_enemies.gd','tools/campaign_ledger.gd','tools/campaign_ledger.tscn'}
 target=OUT/'frozen-inputs';assert not target.exists(),'refusing to overwrite frozen evidence'
 hashes={'baseline':{},'candidate':{}}
 provenance={}
 for name in sorted(names):
  item=manifest['files'].get(name)
  original=Path(item['before']).read_bytes() if item else (ROOT/name).read_bytes()
  if item:expected=item['before_sha256'];provenance[name]='D candidate baseline captured before controls'
  elif name in reference:expected=reference[name];provenance[name]='Individual source hash captured before original ledger'
  else:
   expected=sha(git('show','83319fef08227dd4868474fa2307c305dd7f703d:'+name))
   provenance[name]='Source retrieved after capture from immutable Git833; original boss-control base and tracked diff prove this file was unmodified, but no individual pre-run hash was recorded for this test script'
  assert sha(original)==expected,('baseline drift',name)
  candidate=Path(item['candidate']).read_bytes() if item else original
  if item:assert sha(candidate)==item['after_sha256']
  for version,data in [('baseline',original),('candidate',candidate)]:
   path=target/version/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);hashes[version][name]=sha(data)
 save(target/'manifest.json',{'scope':'Independent audit input subset plus relevant actor/contract source. Not claimed to be an entire executable Godot project.','files':hashes,'baseline_source_provenance':provenance})
 print(json.dumps({'files_each':len(names),'output':str(target)}))

if __name__=='__main__':main()
