"""Add the narrowly authorized fourth candidate file; retain the initial three-file proposal."""
from prepare_candidate import DEST,FILES
from run_original import ROOT,git,save,sha
import json,subprocess

def main():
 path=DEST/'candidate.json';old=path.read_bytes();manifest=json.loads(old)
 assert len(manifest['files'])==3,'fourth file was already prepared'
 (DEST/'candidate-v1-original.json').write_bytes(old)
 name='tests/suite/test_economy.gd';before=(ROOT/name).read_bytes()
 assert b'\r' not in before and before==git('show','HEAD:'+name)
 needle=b'\t_test_income_matches_prices()\n';assert before.count(needle)==1
 method='''

## NE-231: these story actors finish alive and are paid by their one-time story transactions.
func _test_nonlethal_story_income() -> void:
	for path in ["res://data/enemies/yong.tres", "res://data/enemies/janus.tres"]:
		var enemy := load(path) as EnemyData
		check(enemy != null, "nonlethal story actor data loads: %s" % path)
		if enemy == null:
			continue
		var layout := LevelLayout.new()
		layout.spawns.append({"resource":enemy})
		var income := EconomyReport.area_income(layout)
		check(int(income["enemies"]) == 0 and int(income["total"]) == 0, "an alive story completion must not add a death bounty to the chapter ledger: %s" % path)
	var grunt := load("res://data/enemies/grunt.tres") as EnemyData
	check(grunt != null, "ordinary enemy positive-control data loads")
	if grunt != null:
		var layout := LevelLayout.new()
		layout.spawns.append({"resource":grunt})
		check(grunt.credit_value == 8 and int(EconomyReport.area_income(layout)["total"]) == 8, "ordinary enemy death income remains its real eight-credit drop")
'''.encode()
 after=before.replace(needle,needle+b'\t_test_nonlethal_story_income()\n')+method
 for folder,data in [('baseline',before),('candidate',after)]:
  target=DEST/folder/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 manifest['files'][name]={'before_sha256':sha(before),'after_sha256':sha(after),'before':str(DEST/'baseline'/name),'candidate':str(DEST/'candidate'/name)}
 manifest['scope']='D-only two unused death-bounty values, narrow Progression data contract and actual EconomyReport/layout regression with ordinary-enemy positive control. No behavior, story payment, selector or C product changes.'
 save(path,manifest)
 command=['python','-X','utf8','tools/select_tests.py','--files',*FILES,name,'--explain']
 result=subprocess.run(command,cwd=ROOT,check=True,capture_output=True)
 (DEST/'selector-v2.stdout').write_bytes(result.stdout);(DEST/'selector-v2.stderr').write_bytes(result.stderr)
 save(DEST/'selector-v2-command.json',{'command':command,'cwd':str(ROOT),'exit':result.returncode,'selector_sha256':sha((ROOT/'tools/select_tests.py').read_bytes()),'actual_game_tests_started':False})
 print(json.dumps({'files':len(manifest['files']),'economy_sha256':sha(after),'groups':len(result.stdout.decode().splitlines()),'has_economy':'EconomySuite:' in result.stdout.decode()}))

if __name__=='__main__':main()
