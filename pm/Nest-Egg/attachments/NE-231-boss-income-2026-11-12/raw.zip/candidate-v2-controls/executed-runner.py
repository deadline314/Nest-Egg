"""Explicit headless data-file controls; full affected regression remains a separate stage."""
import argparse,json,os,subprocess,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from run_original import ROOT,OUT,GODOT,git,save,sha
from prepare_candidate import DEST

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--base',required=True);args=parser.parse_args()
 assert len(args.base)==40 and git('rev-parse','HEAD').decode().strip()==args.base
 manifest=json.loads((DEST/'candidate.json').read_bytes())
 assert len(manifest['files'])==4
 before={name:sha((ROOT/name).read_bytes()) for name in manifest['files']}
 for name,item in manifest['files'].items():
  assert before[name]==item['before_sha256'],('candidate/context collision',name)
  assert sha(Path(item['candidate']).read_bytes())==item['after_sha256']
  assert sha(Path(item['before']).read_bytes())==item['before_sha256']
 original=json.loads((OUT/'original-1794421491041687600/source-before.json').read_bytes())['economic_inputs']
 def economic_snapshot():
  with ThreadPoolExecutor(max_workers=4) as pool:return dict(pool.map(lambda name:(name,sha((ROOT/name).read_bytes())),original))
 economic_before=economic_snapshot();assert economic_before==original
 run=OUT/('candidate-control-'+str(time.time_ns()));run.mkdir()
 tool=ROOT/'work/ne231-ledger-published';tool.mkdir(parents=True,exist_ok=True)
 for name in ['candidate_probe.gd','candidate_probe.tscn']:
  data=(OUT/name).read_bytes();(run/name).write_bytes(data);(tool/name).write_bytes(data)
 context={name:sha((ROOT/name).read_bytes()) for name in git('diff','--name-only','HEAD').decode().splitlines()}
 save(run/'source-before.json',{'base':args.base,'economic_inputs':economic_before,'other_working_context':context,'candidate_manifest':manifest})
 (run/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
 for name in ['run_original.py','prepare_candidate.py']:(run/name).write_bytes((OUT/name).read_bytes())
 command=[str(GODOT),'--headless','--quit-after','180','--path',str(ROOT),'res://work/ne231-ledger-published/candidate_probe.tscn','--','--out='+str(run),'--candidate-root='+str(DEST)]
 save(run/'command.json',command);env=os.environ.copy();env['APPDATA']=str(run/'isolated-appdata')
 started=time.monotonic()
 with (run/'engine.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 after=economic_snapshot();context_after={name:sha((ROOT/name).read_bytes()) for name in context}
 for item in manifest['files'].values():assert sha(Path(item['candidate']).read_bytes())==item['after_sha256']
 save(run/'source-after.json',{'base':git('rev-parse','HEAD').decode().strip(),'economic_inputs':after,'other_working_context':context_after,'candidate_sources_unchanged':True})
 text=(run/'engine.log').read_text(encoding='utf-8',errors='replace')
 diagnostic=[line for line in text.splitlines() if any(mark in line for mark in ['SCRIPT ERROR','ERROR:','ObjectDB instances leaked','resources still in use'])]
 receipt={'exit':result.returncode,'seconds':time.monotonic()-started,'economic_sources_same':economic_before==after,'context_same':context==context_after,'diagnostics':diagnostic,'performance':False,'output':str(run)}
 save(run/'exit.json',receipt);print(json.dumps(receipt))
 assert result.returncode==0 and economic_before==after and context==context_after and not diagnostic
 control=json.loads((run/'candidate-control.json').read_bytes());assert control['accepted'];print(json.dumps(control,ensure_ascii=False))
 ledger=json.loads((run/'candidate-ledger.json').read_bytes());print(json.dumps({'plan':ledger['plan']},ensure_ascii=False))

if __name__=='__main__':main()
