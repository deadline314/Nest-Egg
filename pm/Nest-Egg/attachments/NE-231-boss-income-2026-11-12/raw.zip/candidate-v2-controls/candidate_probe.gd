extends Node
## Work-only data-file override in this isolated headless process. No product files are written.
var out := ""
var candidate_root := ""
var checks := 0
var rejects: Array[String] = []
var cases: Array = []
var retained: Array[Resource] = []

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
		elif arg.begins_with("--candidate-root="):candidate_root=arg.trim_prefix("--candidate-root=")
	_run.call_deferred()

func _install_data(folder: String) -> void:
	for actor in ["yong","janus"]:
		var file := candidate_root.path_join(folder).path_join("data/enemies/"+actor+".tres")
		var resource := load(file) as EnemyData
		assert(resource != null and resource.id==StringName(actor) and resource.validate().is_empty())
		resource.take_over_path("res://data/enemies/"+actor+".tres")
		retained.append(resource)

func _exercise(label: String, script_folder: String, data_folder: String, expected_rejects: int) -> bool:
	return _exercise_method(label,script_folder,data_folder,expected_rejects,"test_progression.gd","ProgressionSuite","_test_data")

func _exercise_method(label: String, script_folder: String, data_folder: String, expected_rejects: int, filename: String, global_name: String, method: String) -> bool:
	_install_data(data_folder)
	var file := candidate_root.path_join(script_folder).path_join("tests/suite/"+filename)
	var text := FileAccess.get_file_as_string(file)
	var declaration := "class_name "+global_name+"\n"
	assert(text.count(declaration)==1)
	var script := GDScript.new()
	# Only the global registration name is removed, identically on each side;
	# the actual data-contract method and all its original checks run unchanged.
	script.source_code=text.replace(declaration,"")
	assert(script.reload()==OK)
	checks=0;rejects.clear()
	var suite: TestSuite=script.new(self)
	suite.call(StringName(method))
	cases.append({"label":label,"script_file":file,"script_folder":script_folder,"data_folder":data_folder,"checks":checks,"observed_rejections":rejects.duplicate(),"expected_rejections":expected_rejects})
	return checks>0 and rejects.size()==expected_rejects

func _run() -> void:
	assert(out.is_absolute_path() and candidate_root.is_absolute_path())
	var ok := true
	ok=_exercise("original-contract-original-data","baseline","baseline",0) and ok
	ok=_exercise("new-contract-original-data","candidate","baseline",2) and ok
	ok=_exercise("original-contract-zero-data","baseline","candidate",2) and ok
	ok=_exercise("new-contract-zero-data","candidate","candidate",0) and ok
	ok=_exercise_method("real-economy-contract-original-data","candidate","baseline",2,"test_economy.gd","EconomySuite","_test_nonlethal_story_income") and ok
	ok=_exercise_method("real-economy-contract-zero-data","candidate","candidate",0,"test_economy.gd","EconomySuite","_test_nonlethal_story_income") and ok
	# This process has not built the chapter index before the final data files
	# were installed. Refuse a pre-existing layout rather than quietly reusing it.
	assert(QuestMapIndex._chapters.is_empty())
	var ledger := CampaignLedger.build()
	ok=ledger["issues"].is_empty() and ok
	var file := FileAccess.open(out.path_join("candidate-ledger.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(ledger,"  "));file.close()
	file=FileAccess.open(out.path_join("candidate-control.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"accepted":ok,"cases":cases,"override":"Actual D TRES files loaded, then Resource.take_over_path overrides their original res paths in this process only. The suite copy removes only its duplicate global class_name. Not a formal full-suite run or adopted C source."},"  "));file.close()
	await AudioRelease.settle(get_tree())
	print("NE231_CANDIDATE_DONE accepted=%s" % ok)
	get_tree().quit(0 if ok else 1)

func _check(condition: bool, message: String) -> void:
	checks+=1
	if not condition:rejects.append(message)
