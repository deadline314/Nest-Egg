extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const AREA := "res://data/levels/ch3_gate_hall.tres"
var _out := ""
var _language := "en"
var _checks := 0
var _fails := 0


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--language="):
			_language = arg.trim_prefix("--language=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://janus-guidance-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	GameState.story_autosave = false
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	Story.set_language(_language)
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch3_janus_intro_seen", true, false)
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(load(AREA) as LevelData)
	add_child(level)
	for frame in 260:
		if level.is_initialized() and not GameplayLock.is_locked() and not Story.is_cinematic_active():
			break
		await get_tree().process_frame
	var janus: JanusBoss
	for enemy in level._entities.get_children():
		if enemy is JanusBoss:
			janus = enemy
		elif enemy is Enemy:
			enemy.set_physics_process(false)
	_check(janus != null, "the original gate hall contains Janus")
	if janus != null:
		await _exercise(level, janus)
	level.queue_free()
	for frame in 8:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(1 if _fails else 0)


func _exercise(level: Level, janus: JanusBoss) -> void:
	var player := level.player
	player.global_position = janus.global_position + Vector2(-90.0, 0.0)
	player.velocity = Vector2.ZERO
	player.health.setup(999, 0.0)
	level.camera.snap_to_target()
	for frame in 140:
		if janus.is_awake() and janus.fsm.is_in(&"idle"):
			break
		await get_tree().physics_frame
	_check(janus.is_awake(), "the original boss wakes as the player approaches")
	var notices: Array[String] = []
	var gates: Array[StringName] = []
	var record := func(message: String) -> void: notices.append(message)
	var open_gate := func(channel: StringName, active: bool) -> void:
		if active:
			gates.append(channel)
	EventBus.toast_requested.connect(record)
	EventBus.mechanism_toggled.connect(open_gate)
	var body_hit := DamageInfo.create(4, Combat.Team.PLAYER, &"janus_guidance_probe")
	var blocked := janus.hurtbox.receive(body_hit)
	var guard := "The man is protected. Aim at orange outer parts." if _language == "en" else "本人は保護対象。オレンジ色の外部部品を狙う。"
	print("GUARD ", blocked, " ", notices)
	_check(blocked == Hurtbox.Result.BLOCKED and notices.has(guard), "a real body block displays the protected-person instruction")
	var lethal := DamageInfo.create(janus.health.max_health + 5, Combat.Team.PLAYER, &"janus_guidance_probe")
	lethal.ignore_invulnerability = true
	lethal.bypass_guard = true
	janus.health.take_damage(lethal)
	for frame in 10:
		await get_tree().physics_frame
	var halt := "The frame stopped. Pull the service pin from behind." if _language == "en" else "作業架台が止まった。背後から整備ピンを抜く。"
	print("HALT ", janus.halted, " ", notices)
	_check(janus.halted and not janus.pin_pulled and gates.is_empty(), "zero stability still waits for the repair pin")
	_check(notices.has(halt), "the genuine stopped frame tells where to pull its pin")
	var use_pad := _language == "ja"
	var confirm: InputEvent
	if use_pad:
		var shoulder := InputEventJoypadButton.new()
		shoulder.button_index = JOY_BUTTON_RIGHT_SHOULDER
		await _tap(shoulder)
		var press := InputEventJoypadButton.new()
		press.button_index = InputBindings.get_joy_button(&"interact") as JoyButton
		confirm = press
	else:
		var press := InputEventKey.new()
		press.physical_keycode = KEY_E
		press.keycode = KEY_E
		confirm = press
	player.global_position = janus.global_position + Vector2(janus._pin_local().x, 0.0)
	player.velocity = Vector2.ZERO
	level.camera.snap_to_target()
	for frame in 180:
		if janus._pin_prompt.is_showing() and janus._pin_prompt._alpha >= 0.9:
			break
		await get_tree().process_frame
	var action := "Pull the service pin" if _language == "en" else "整備ピンを抜く"
	var prompt := janus._pin_prompt
	print("PIN ", _language, " ", prompt._display_text, " visible=", prompt.is_showing(), " reachable=", janus.pin_reachable(),
			" selected=", Story.framing.is_interaction_prompt_target(janus), " position=", prompt.get_global_transform_with_canvas().origin)
	_check(janus.pin_reachable() and Story.framing.is_interaction_prompt_target(janus)
			and prompt.is_showing() and prompt._display_text == InputBindings.primary_label(&"interact") + " " + action,
			"the real visible pin supplies the active key and current language")
	await RenderingServer.frame_post_draw
	_check(Capture.image(get_viewport()).save_png(_out.path_join("pin.png")) == OK, "captured the real localized world prompt")
	await _tap(confirm)
	for frame in 60:
		if GameState.has_flag(&"ch3_janus_disabled"):
			break
		await get_tree().physics_frame
	var unlocked := "The gate frame powered off. The gate opened." if _language == "en" else "門番の作業架台が停止し、門が開いた。"
	print("OPEN ", gates, " disabled=", GameState.has_flag(&"ch3_janus_disabled"), " ", notices)
	_check(gates == [&"ch3_janus_down"] and GameState.has_flag(&"ch3_janus_disabled"), "the shown input pulls the pin and opens the original gate once")
	_check(notices.has(unlocked), "the existing localized gate notice still appears")
	EventBus.toast_requested.disconnect(record)
	EventBus.mechanism_toggled.disconnect(open_gate)
	Fx.thaw_all()


func _tap(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	for frame in 3:
		await get_tree().physics_frame
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	for frame in 5:
		await get_tree().physics_frame


func _check(passed: bool, message: String) -> void:
	_checks += 1
	_fails += int(not passed)
	if not passed:
		printerr("FAIL: ", message)
