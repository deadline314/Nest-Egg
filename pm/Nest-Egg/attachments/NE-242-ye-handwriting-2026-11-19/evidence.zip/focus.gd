extends "../ne242-ye-umbrella-20261119/focus.gd"

const LOOK_NEW := &"ch3_t_c19_read_new"
const LOOK_TAPE := &"ch3_t_c19_read_tape"
const QUOTE := "葉的手背上寫著一行字：「他叫阿翰。你愛他。」"


func _init() -> void:
	level_path = "res://data/levels/ch3_office_hall.tres"
	story_file = "res://data/story/ch3_clearwater.json"
	shot_prefix = "NE-242"
	id_prefix = "ch3_t_"
	shots = {LOOK_NEW: [QUOTE], LOOK_TAPE: [QUOTE]}


func _translations() -> Dictionary:
	for step: Dictionary in Story._scenes[String(LOOK_NEW)]["steps"]:
		if step.get("do") == "say":
			return {QUOTE: String(step["text"])}
	return {}


func _prepare(id: StringName) -> void:
	GameState.set_flag(&"ch3_petition_receipt_taken", true, false)
	GameState.set_flag(&"ye_handwriting_seen", true, false)
	GameState.set_flag(&"sq7_ahan_clip_heard", id == LOOK_TAPE, false)
	GameState.set_flag(&"sq7_ye_name_seen", false, false)
	print("reading route %s language=%s" % [id, Story.language])
