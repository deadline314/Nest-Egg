extends Node

const DISPATCH := &"ch3_dispatch_c19_read"


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	var failed := 0
	Story.auto_skip = false
	for heard in [false, true]:
		GameState.start_new_run(GameState.difficulties[1])
		GameState.set_flag(&"ch3_petition_receipt_taken", true, false)
		GameState.set_flag(&"ye_handwriting_seen", true, false)
		GameState.set_flag(&"sq7_ahan_clip_heard", heard, false)
		var expected := &"ch3_t_c19_read_tape" if heard else &"ch3_t_c19_read_new"
		var start := Progression.credits
		if Story.resolve_dispatch(DISPATCH) != expected or not Story.play(DISPATCH, false):
			failed += 1
			continue
		for frame in range(120):
			if Story.is_cinematic_active() and Story._current_cinematic == expected:
				break
			await get_tree().process_frame
		var active := Story._current_cinematic == expected
		Story.skip_cinematic()
		for frame in range(90):
			if GameState.has_flag(&"sq7_ye_name_seen"):
				break
			await get_tree().process_frame
		var seen := GameState.has_flag(&"sq7_ye_name_seen")
		var earnings := Progression.credits - start
		var blocked := not Story.scene_available(expected)
		print("%s active=%s seen=%s reward=%d repeat_blocked=%s" % [expected, active, seen, earnings, blocked])
		if not active or not seen or earnings != 20 or not blocked:
			failed += 1
		Story.reset_active_presentation(&"route")
		await get_tree().process_frame
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failed == 0 else 1)
