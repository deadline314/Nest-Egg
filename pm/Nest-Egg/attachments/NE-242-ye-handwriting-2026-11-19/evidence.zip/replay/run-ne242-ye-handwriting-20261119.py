from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = root / 'work/ne242-ye-handwriting-20261119'
out = base / sys.argv[1]
out.mkdir()
probe = base / ('focus-preview.gd' if sys.argv[1].startswith('preview') else 'focus.gd')
scene = base / 'focus.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n'
                 '[node name="FolioHandwriting" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
command = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '5000',
           scene.as_posix(), '--', '--out=' + str(out), '--story-language=' + (sys.argv[2] if len(sys.argv) > 2 else 'zh')]
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (out / 'raw.log').open('wb') as log:
    result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=160)
raw = (out / 'raw.log').read_text(encoding='utf-8')
print(raw[-4500:], flush=True)
assert result.returncode == 0 and 'ERROR:' not in raw and '9070 XT' in raw
assert all(summary in raw for summary in ('ch3_t_c19_read_new shots 1/1',
                                          'ch3_t_c19_read_tape shots 1/1'))
assert len(list(out.glob('*.png'))) == 2

