extends "res://tests/smoke_test.gd"

const GuardSuite := preload("res://tests/suite/test_melee_weapons.gd")

class StopObserver extends Node:
	var start_ms := 0
	var end_ms := 0
	var observed := false

	func _notification(what: int) -> void:
		var parent := get_parent()
		if what == NOTIFICATION_DISABLED and Fx.is_frozen(parent):
			start_ms = Time.get_ticks_msec()
			observed = true
		elif what == NOTIFICATION_ENABLED and observed:
			end_ms = Time.get_ticks_msec()


class Diagnostic extends GuardSuite:
	func verify_observation(stall: bool) -> void:
		await open_level(10.0)
		var player := _arm("melee_blade")
		_aim(player, Vector2.LEFT)
		var target := _dummy(-24.0)
		var stop := StopObserver.new()
		player.add_child(stop)
		await physics_frames(3)
		check(player._try_melee(), "actual left blade swing begins")
		var attack := player._melee_attack.duplicate(true)
		var ticks := 180
		var sampled := false
		if stall:
			# Begin old frame sampling only after the real stop has passed.
			var deadline := Time.get_ticks_msec() + 2000
			while stop.end_ms == 0 and Time.get_ticks_msec() < deadline:
				await level.get_tree().process_frame
		while not player.is_melee_cancellable() and ticks > 0:
			sampled = sampled or Fx.is_frozen(player)
			await physics_frames(1)
			ticks -= 1
		check(ticks > 0, "actual left blade reaches cancel window")
		check(target.health.current == 999 - int(attack.damage), "actual blade deals its authored damage once")
		check(stop.observed and stop.end_ms > stop.start_ms, "process-mode notification sees actual freeze and release")
		check(sampled != stall, "physics-only observation loses the stop only when the observation starts after the stop")
		print("HITSTOP_OBSERVATION ", JSON.stringify({
			"delayed_sample":stall, "physics_seen":sampled, "stop_observed":stop.observed,
			"local_hitstop_ms":stop.end_ms-stop.start_ms, "target_hp":target.health.current,
			"cancellable":player.is_melee_cancellable(),
		}))
		await end_level(level)


func _run() -> void:
	if not DisplayServer.get_name() == "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var diag := Diagnostic.new(self)
	for stall in [false, true, true, false]:
		await diag.verify_observation(stall)
	await _finish()

