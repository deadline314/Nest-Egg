from pathlib import Path
ROOT=Path('D:/NestEggVerification/ticket-batch-20261111')
source=(ROOT/'tests/suite/test_quest_map.gd').read_text()
start=source.index('func _check_prompt_avoids_objective(');end=source.index('\n\n\nfunc _key(',start)
function=source[start:end]
function=function.replace('var guidance: QuestGuidance = level.hud.quest_guidance','''runner.call("begin",level)
	var guidance: QuestGuidance = level.hud.quest_guidance
	if "--stable-layout" in OS.get_cmdline_user_args():
		var camera := runner.get_viewport().get_camera_2d()
		var last_center := camera.get_screen_center_position()
		var last_row := guidance.row_world_rect()
		var stable := 0
		var deadline := Time.get_ticks_msec()+5000
		while stable<2 and Time.get_ticks_msec()<deadline:
			await runner.get_tree().process_frame
			var current_center := camera.get_screen_center_position()
			var current_row := guidance.row_world_rect()
			var pulse_done := guidance._pulse==null or not guidance._pulse.is_running()
			stable = stable+1 if pulse_done and current_row.has_area() and current_center.distance_to(last_center)<=0.01 and current_row.position.distance_to(last_row.position)<=0.01 and current_row.size.distance_to(last_row.size)<=0.01 else 0
			last_center=current_center
			last_row=current_row
		check(stable>=2,"independent camera and objective layout publication settle before prompt setup")
		runner.call("mark","stable_camera_and_row")''',1)
function=function.replace('check(row.has_area(),','runner.call("set_initial_row",row)\n\trunner.call("mark","row_captured")\n\tcheck(row.has_area(),',1)
function=function.replace('holder.add_child(prompt)','runner.set("tracked_prompt",prompt)\n\trunner.set("tracked_holder",holder)\n\tholder.add_child(prompt)\n\trunner.call("mark","prompt_added")',1)
function=function.replace('# 提示框原本的位置','runner.call("mark","before_align")\n\t# 提示框原本的位置',1)
function=function.replace('holder.global_position += row.get_center() - prompt.base_rect().get_center()','holder.global_position += row.get_center() - prompt.base_rect().get_center()\n\trunner.call("mark","after_align")',1)
function=function.replace('runner.call("mark","after_align")','''runner.call("mark","after_align")
	if "--stop-layout" in OS.get_cmdline_user_args(): prompt.set_process(false)
	if "--published-layout" in OS.get_cmdline_user_args() or "--settled-nudge" in OS.get_cmdline_user_args():
		var aligned_process := Engine.get_process_frames()
		var deadline := Time.get_ticks_msec()+3000
		while (Engine.get_process_frames() <= aligned_process or PromptLayout._frame < aligned_process) and Time.get_ticks_msec()<deadline:
			await runner.get_tree().process_frame
		runner.call("mark","after_layout_publication")
		if "--settled-nudge" in OS.get_cmdline_user_args():
			while (not prompt.is_processing() or not prompt.can_process() or prompt._nudge.distance_to(prompt._nudge_target)>0.01) and Time.get_ticks_msec()<deadline:
				await runner.get_tree().process_frame
			check(prompt.is_processing() and prompt.can_process() and Engine.get_process_frames()>aligned_process and PromptLayout._frame>=aligned_process and prompt._nudge.distance_to(prompt._nudge_target)<=0.01,"independent layout publication and nudge-to-own-target settle before fade sample")
			runner.call("mark","nudge_converged")''',1)
function=function.replace('var placed :=','runner.call("mark","faded_sample")\n\tvar placed :=',1)
function=function.replace('var placed :=',"""if "--current-row" in OS.get_cmdline_user_args(): row=guidance.row_world_rect()
	if "--wrong-target" in OS.get_cmdline_user_args():
		prompt._nudge_target=Vector2(10000,10000)
		prompt._nudge=prompt._nudge_target
		runner.call("mark","wrong_target_control")
	var placed :=""",1)
function=function.replace('holder.queue_free()','runner.call("mark","assertions_finished")\n\tholder.queue_free()',1)
function+='\n\trunner.call("mark","function_finished")\n\trunner.set("tracking",false)\n'
driver=(Path(__file__).with_name('driver.gd.txt')).read_text()
text='extends "res://tests/smoke_test.gd"\nclass TraceQuest extends QuestMapSuite:\n'+'\n'.join('\t'+line if line else '' for line in function.splitlines())+'\n'+driver
for root in [ROOT,Path.cwd()]:
 out=root/'work/ne289-prompt-diag';out.mkdir(parents=True,exist_ok=True);(out/'.gdignore').touch()
 (out/'probe.gd').write_bytes(text.encode())
 (out/'probe.tscn').write_bytes(b'[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://work/ne289-prompt-diag/probe.gd" id="1"]\n\n[node name="PromptTiming" type="Node"]\nscript = ExtResource("1")\n')
print('original function plus RAM observations generated in work only')
