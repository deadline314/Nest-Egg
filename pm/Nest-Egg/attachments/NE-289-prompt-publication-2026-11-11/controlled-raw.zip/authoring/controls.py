from pathlib import Path
import subprocess,sys,json
ROOT=Path('D:/NestEggVerification/ticket-batch-20261111')
cases=[('current-row-only-runtime-fps15',['--current-row'],'the prompt itself stays in place'),('wrong-target-runtime-fps15',['--current-row','--settled-nudge','--wrong-target'],'the prompt itself stays in place'),('stopped-layout-runtime-fps15',['--current-row','--settled-nudge','--stop-layout'],'independent layout publication')]
for name,flags,expected in cases:
 result=subprocess.run([sys.executable,'-X','utf8','work/ne289-prompt-diag/run.py',name,'--runtime','--fps=15']+flags,capture_output=True)
 path=ROOT/'work/ne289-prompt-diag'/name
 log=(path/'process.log').read_text(encoding='utf-8')
 failures=[line for line in log.splitlines() if line.startswith('FAIL: ')]
 assert result.returncode==1 and any(expected in value for value in failures),(name,result.stdout[-1500:])
 assert 'SCRIPT ERROR' not in log and '\nERROR:' not in log,name
 print(json.dumps({'name':name,'expected_rejection':True,'failures':failures}),flush=True)
