from pathlib import Path
import hashlib,json,subprocess,os,time,shutil,sys
ROOT=Path('D:/NestEggVerification/ticket-batch-20261111')
OUT=ROOT/'work/ne289-prompt-diag'/sys.argv[1];OUT.mkdir(exist_ok=False)
paths=['tests/suite/test_quest_map.gd','game/level/world_prompt.gd','ui/quest_guidance.gd','game/level/prompt_layout.gd','game/level/world_text_layout.gd','game/level/level_camera.gd','ui/hud.gd','work/ne289-prompt-diag/probe.gd','work/ne289-prompt-diag/probe.tscn']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={p:sha(ROOT/p) for p in paths}
for name in paths:
 p=OUT/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,p)
shutil.copyfile(__file__,OUT/'executed-runner.py')
cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--audio-driver','Dummy','--path',str(ROOT),'res://work/ne289-prompt-diag/probe.tscn','--']+sys.argv[2:]
(OUT/'command.json').write_bytes((json.dumps(cmd,indent=2)+'\n').encode())
env=dict(os.environ,APPDATA=str(OUT/'user'),LOCALAPPDATA=str(OUT/'local'));start=time.monotonic()
with (OUT/'process.log').open('wb') as log:
 proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:code=proc.wait(timeout=180)
 except subprocess.TimeoutExpired:subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True);code=124
after={p:sha(ROOT/p) for p in paths}
receipt={'exit':code,'seconds':time.monotonic()-start,'before':before,'after':after,'same_source':before==after,'runner_sha256':sha(Path(__file__))}
(OUT/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in receipt.items() if k not in ['before','after']}));print((OUT/'process.log').read_text(encoding='utf-8')[-1300:])
sys.exit(code)
