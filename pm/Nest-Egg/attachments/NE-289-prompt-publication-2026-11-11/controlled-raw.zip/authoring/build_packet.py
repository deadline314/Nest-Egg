from pathlib import Path
import hashlib,json,zipfile
C=Path('C:/Users/stanl/Github/Nest-Egg');D=Path('D:/NestEggVerification/ticket-batch-20261111')
OUT=C/'pm/Nest-Egg/attachments/NE-289-prompt-publication-2026-11-11'
CASES={'original-red':'original-runtime-fps15','layout-only-red':'published-runtime-fps15','layout-nudge-old-row-red':'nudge-ready-runtime-fps15','current-row-only-red':'current-row-only-runtime-fps15','first-both-green':'current-frame-nudge-runtime-fps15','first-wrong-target':'wrong-target-runtime-fps15','first-stopped-layout':'stopped-layout-runtime-fps15','final-timer-green':'final-post-process-runtime-fps15','final-wrong-target':'final-wrong-target-fps15','final-stopped-layout':'final-stopped-layout-fps15','final-full-suite':'final-full-suite'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 OUT.mkdir(exist_ok=True)
 for name,value in {'.gdignore':b'', '.gitignore':b'__pycache__/\n*.pyc\n', '.gitattributes':b'*.zip binary\n*.py text eol=lf\n*.json text eol=lf\n*.md text eol=lf\n'}.items():(OUT/name).write_bytes(value)
 entries={};raw=OUT/'controlled-raw.zip';assert not raw.exists()
 with zipfile.ZipFile(raw,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  def add(p,name):z.write(p,name);entries[name]={'sha256':sha(p),'bytes':p.stat().st_size}
  for label,folder in CASES.items():
   base=D/'work/ne289-prompt-diag'/folder
   assert (base/'receipt.json').exists()
   for path in sorted(base.rglob('*')):
    if path.is_file() and path.relative_to(base).parts[0] not in ['user','local'] and '__pycache__' not in path.parts and path.suffix!='.pyc':add(path,label+'/'+path.relative_to(base).as_posix())
  for name in ['build.py','build_final.py','driver.gd.txt','run.py','controls.py','final_controls.py','reproject.py','build_packet.py','adoption-manifest.json']:
   add(C/'work/ne289-prompt-diag'/name,'authoring/'+name)
  add(D/'work/ne289-prompt-diag/final_test_quest_map.gd','final/tests/suite/test_quest_map.gd')
 with zipfile.ZipFile(raw) as z:assert z.testzip() is None
 data={'scope':'Headless UI fixture diagnosis and proposal only. The original 77-group batch remains red; official affected verification is separate. Player, camera, quest authority and product UI unchanged. Original command/source/log/receipt bytes retained; application-data caches excluded.','raw_sha256':sha(raw),'raw_bytes':raw.stat().st_size,'final_test_sha256':sha(D/'work/ne289-prompt-diag/final_test_quest_map.gd'),'cases':CASES,'entries':entries}
 (OUT/'controlled-index.json').write_bytes((json.dumps(data,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in data.items() if k in ['raw_sha256','raw_bytes','final_test_sha256']}))
if __name__=='__main__':main()
