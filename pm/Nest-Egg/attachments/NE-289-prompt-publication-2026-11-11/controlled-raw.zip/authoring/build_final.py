"""Work-only final proposal; original product/test files stay untouched until handoff."""
from pathlib import Path
ROOT=Path('D:/NestEggVerification/ticket-batch-20261111')
source=(ROOT/'tests/suite/test_quest_map.gd').read_text()
start=source.index('func _check_prompt_avoids_objective(');end=source.index('\n\n\nfunc _key(',start)
function=source[start:end].replace('await frames(1)','await _prompt_ui_frame()')
function=function.replace('await frames(2)','await _prompt_ui_frame()')
function=function.replace('holder.global_position += row.get_center() - prompt.base_rect().get_center()', '''holder.global_position += row.get_center() - prompt.base_rect().get_center()
	# 等提示本身處理及對齊後的版面發布，再獨立確認它已到自己的目標；不以重疊結果作前提。
	var aligned_process := Engine.get_process_frames()
	var deadline := Time.get_ticks_msec() + 3000
	var published := false
	while Time.get_ticks_msec() < deadline:
		await _prompt_ui_frame()
		published = prompt.is_processing() and prompt.can_process() and PromptLayout._frame >= aligned_process and prompt._nudge.distance_to(prompt._nudge_target) <= 0.01
		if published:
			break
	check(published, "prompt layout publishes and converges to its own target before sampling")''')
function=function.replace('check(placed.intersects(row),','var observation_row := guidance.row_world_rect()\n\tcheck(placed.intersects(observation_row),')
helper='''


## process_frame 在節點更新前發出；零時 timer 在本輪所有 Node._process 後才回來。
func _prompt_ui_frame() -> void:
	await runner.get_tree().process_frame
	await runner.get_tree().create_timer(0.0, true, false, true).timeout
'''
final=source[:start]+function+helper+source[end:]
for root in [ROOT,Path.cwd()]:
 (root/'work/ne289-prompt-diag/final_test_quest_map.gd').write_bytes(final.encode())
# Add observations to the proposal's copied override, without modifying the proposed formal source.
probe=function.replace('var guidance: QuestGuidance = level.hud.quest_guidance','runner.call("begin",level)\n\tvar guidance: QuestGuidance = level.hud.quest_guidance',1)
probe=probe.replace('check(row.has_area(),','runner.call("set_initial_row",row)\n\trunner.call("mark","row_captured")\n\tcheck(row.has_area(),',1)
probe=probe.replace('holder.add_child(prompt)','runner.set("tracked_prompt",prompt)\n\trunner.set("tracked_holder",holder)\n\tholder.add_child(prompt)\n\trunner.call("mark","prompt_added")',1)
probe=probe.replace('holder.global_position += row.get_center() - prompt.base_rect().get_center()','holder.global_position += row.get_center() - prompt.base_rect().get_center()\n\trunner.call("mark","after_align")\n\tif "--stop-layout" in OS.get_cmdline_user_args(): prompt.set_process(false)',1)
probe=probe.replace('check(published,','runner.call("mark","published_sample")\n\tcheck(published,',1)
probe=probe.replace('var placed :=','''runner.call("mark","faded_sample")
	if "--wrong-target" in OS.get_cmdline_user_args():
		prompt._nudge_target=Vector2(10000,10000)
		prompt._nudge=prompt._nudge_target
		runner.call("mark","wrong_target_control")
	var placed :=''',1)
probe+='\n\trunner.call("mark","function_finished")\n\trunner.set("tracking",false)\n'
driver=Path(__file__).with_name('driver.gd.txt').read_text()
text='extends "res://tests/smoke_test.gd"\nclass TraceQuest extends QuestMapSuite:\n'+'\n'.join('\t'+line if line else '' for line in (probe+helper).splitlines())+'\n'+driver
for root in [ROOT,Path.cwd()]:(root/'work/ne289-prompt-diag/probe.gd').write_bytes(text.encode())
print('final proposal and separate RAM preview written; formal source unchanged')
