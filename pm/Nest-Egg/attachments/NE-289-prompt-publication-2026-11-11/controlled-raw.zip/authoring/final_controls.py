from pathlib import Path
import subprocess,sys,json
ROOT=Path('D:/NestEggVerification/ticket-batch-20261111')
for name,flags,exit_code,phrase in [('final-wrong-target-fps15',['--runtime','--fps=15','--wrong-target'],1,'the prompt itself stays in place'),('final-stopped-layout-fps15',['--runtime','--fps=15','--stop-layout'],1,'prompt layout publishes'),('final-full-suite',[],0,'')]:
 result=subprocess.run([sys.executable,'-X','utf8','work/ne289-prompt-diag/run.py',name]+flags,capture_output=True)
 folder=ROOT/'work/ne289-prompt-diag'/name
 log=(folder/'process.log').read_text(encoding='utf-8');failures=[line for line in log.splitlines() if line.startswith('FAIL: ')]
 assert result.returncode==exit_code and (not failures if exit_code==0 else any(phrase in value for value in failures)),(name,result.stdout[-1300:])
 assert 'SCRIPT ERROR' not in log and '\nERROR:' not in log,name
 print(json.dumps({'case':name,'expected_exit':exit_code,'failures':failures}),flush=True)
