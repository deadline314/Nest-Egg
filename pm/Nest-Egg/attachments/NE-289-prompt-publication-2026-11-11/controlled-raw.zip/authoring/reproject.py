from pathlib import Path
import json,math,sys
def rect_transform(rect,t):
 x,y,w,h=rect;a,b,c,d,ox,oy=t
 points=[(a*px+c*py+ox,b*px+d*py+oy) for px,py in [(x,y),(x+w,y),(x,y+h),(x+w,y+h)]]
 left=min(x for x,y in points);top=min(y for x,y in points)
 return [left,top,max(x for x,y in points)-left,max(y for x,y in points)-top]
def intersects(a,b):return max(a[0],b[0])<min(a[0]+a[2],b[0]+b[2]) and max(a[1],b[1])<min(a[1]+a[3],b[1]+b[3])
def main():
 root=Path('D:/NestEggVerification/ticket-batch-20261111/work/ne289-prompt-diag')/(sys.argv[1] if len(sys.argv)>1 else 'current-frame-nudge-runtime-fps15')
 rows=[json.loads(l.split('PROMPT_BUFFERED ',1)[1]) for l in (root/'process.log').read_text().splitlines() if 'PROMPT_BUFFERED ' in l]
 errors=[max(abs(a-b) for a,b in zip(rect_transform(r['actual_row'],r['canvas']),r['row_screen'])) for r in rows if r['actual_row'][2]>0]
 assert errors and max(errors)<0.001
 final=next(r for r in rows if r['event'].startswith('assert_true_the prompt itself stays'))
 placed=[final['prompt_base'][0]+final['prompt_nudge'][0],final['prompt_base'][1]+final['prompt_nudge'][1],*final['prompt_base'][2:]]
 assert intersects(placed,final['actual_row']) and not intersects(placed,final['initial_row'])
 result={'observations':len(errors),'max_screen_rect_error':max(errors),'placed':placed,'current_row':final['actual_row'],'old_row':final['initial_row'],'current_row_projected':rect_transform(final['actual_row'],final['canvas']),'actual_screen_row':final['row_screen'],'old_row_projected_with_current_canvas':rect_transform(final['initial_row'],final['canvas']),'current_intersects':True,'old_intersects':False}
 (root/'independent-reprojection.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result))
if __name__=='__main__':main()
