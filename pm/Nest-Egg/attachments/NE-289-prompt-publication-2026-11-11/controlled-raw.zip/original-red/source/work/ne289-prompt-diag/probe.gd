extends "res://tests/smoke_test.gd"
class TraceQuest extends QuestMapSuite:
	func _check_prompt_avoids_objective(level: Level) -> void:
		runner.call("begin",level)
		var guidance: QuestGuidance = level.hud.quest_guidance
		var row := Rect2()
		for i in 60:
			await frames(1)
			row = guidance.row_world_rect()
			if row.has_area():
				break
		runner.call("set_initial_row",row)
		runner.call("mark","row_captured")
		check(row.has_area(), "the objective row is on screen in a new game")
		if not row.has_area():
			return
		var prompt := WorldPrompt.new()
		prompt.text = "{jump} 跳上搬貨台，工具就放在上面。"
		prompt.reach_check = func() -> bool: return true
		var holder := Node2D.new()
		level.add_child(holder)
		runner.set("tracked_prompt",prompt)
		runner.set("tracked_holder",holder)
		holder.add_child(prompt)
		runner.call("mark","prompt_added")
		await frames(2)
		runner.call("mark","before_align")
		# 提示框原本的位置正好壓在目標列中央。
		holder.global_position += row.get_center() - prompt.base_rect().get_center()
		runner.call("mark","after_align")
		var faded := false
		for i in 120:
			await frames(1)
			if prompt.is_showing() and guidance._row.modulate.a < 0.05:
				faded = true
				break
		runner.call("mark","faded_sample")
		var placed := Rect2(prompt.base_rect().position + prompt._nudge, prompt.base_rect().size)
		check(faded and guidance.yielding, "a world prompt over the objective row makes the row fade out")
		check(guidance._row.mouse_filter == Control.MOUSE_FILTER_IGNORE, "the faded objective row no longer catches the mouse tooltip")
		check(placed.intersects(row), "the prompt itself stays in place instead of being pushed off screen")
		runner.call("mark","assertions_finished")
		holder.queue_free()
		var back := false
		for i in 120:
			await frames(1)
			if not guidance.yielding and guidance._row.modulate.a > 0.35:
				back = true
				break
		check(back, "the objective row comes back once the prompt is gone")
		runner.call("mark","function_finished")
		runner.set("tracking",false)
class Observe extends Node:
	var runner: Node
	var label := ""
	func _physics_process(delta: float) -> void: runner.mark(label+"_physics",delta)
	func _process(delta: float) -> void: runner.mark(label+"_process",delta)
var tracking := false
var tracked_level: Level
var tracked_prompt: WorldPrompt
var tracked_holder: Node2D
var initial_row := Rect2()
var ledger: Array[Dictionary] = []
func rect(value: Rect2) -> Array: return [value.position.x,value.position.y,value.size.x,value.size.y]
func vector(value: Vector2) -> Array: return [value.x,value.y]
func transform(value: Transform2D) -> Array: return [value.x.x,value.x.y,value.y.x,value.y.y,value.origin.x,value.origin.y]
func set_initial_row(value: Rect2) -> void: initial_row=value
func begin(level: Level) -> void:
	tracked_level=level
	tracked_prompt=null
	tracked_holder=null
	tracking=true
func mark(label: String,delta := 0.0) -> void:
	if not tracking or not is_instance_valid(tracked_level): return
	var guidance: QuestGuidance=tracked_level.hud.quest_guidance
	var row := guidance._row
	var camera:=get_viewport().get_camera_2d()
	var value := {"event":label,"physics":Engine.get_physics_frames(),"process":Engine.get_process_frames(),"physics_context":Engine.is_in_physics_frame(),"delta":delta,"time_usec":Time.get_ticks_usec(),"paused":get_tree().paused,"initial_row":rect(initial_row),"actual_row":rect(guidance.row_world_rect()),"row_position":vector(row.position),"row_size":vector(row.size),"row_minimum":vector(row.get_minimum_size()),"row_scale":vector(row.scale),"row_alpha":row.modulate.a,"row_visible":row.visible,"row_pulse":guidance._pulse.is_running() if guidance._pulse!=null else false,"yielding":guidance.yielding,"canvas":transform(get_viewport().get_canvas_transform()),"camera_position":vector(camera.global_position),"camera_screen_center":vector(camera.get_screen_center_position()),"camera_zoom":vector(camera.zoom),"player_position":vector(tracked_level.player.global_position),"prompt_layout_frame":PromptLayout._frame,"ui_text_scale":Settings.get_ui_text_scale(),"reduce_motion":Settings.get_reduce_ui_motion(),"viewport":rect(get_viewport().get_visible_rect()),"guidance_process_priority":guidance.process_priority,"guidance_physics_priority":guidance.process_physics_priority}
	if is_instance_valid(tracked_prompt):
		value.merge({"prompt_base":rect(tracked_prompt.base_rect()),"prompt_box":rect(tracked_prompt._box),"prompt_nudge":vector(tracked_prompt._nudge),"prompt_target":vector(tracked_prompt._nudge_target),"prompt_alpha":tracked_prompt._alpha,"prompt_layout_allowed":tracked_prompt._layout_allowed,"prompt_showing":tracked_prompt.is_showing(),"prompt_position":vector(tracked_prompt.global_position),"prompt_layout_width":tracked_prompt._layout_width,"prompt_text":tracked_prompt._display_text,"prompt_process_priority":tracked_prompt.process_priority,"prompt_physics_priority":tracked_prompt.process_physics_priority})
	if is_instance_valid(tracked_holder):value["holder_position"]=vector(tracked_holder.global_position)
	ledger.append(value)
func _check(ok: bool,message: String) -> void:
	if tracking:mark("assert_"+str(ok)+"_"+message)
	super._check(ok,message)
func _run() -> void:
	Enemy.activation_culling_enabled=false
	Story.auto_skip=true
	for value in OS.get_cmdline_user_args():
		if value.begins_with("--fps="):Engine.max_fps=int(value.trim_prefix("--fps="))
	Engine.max_physics_steps_per_frame=8
	for priority in [-100000,100000]:
		var observer:=Observe.new()
		observer.runner=self
		observer.label="before" if priority<0 else "after"
		observer.process_mode=Node.PROCESS_MODE_ALWAYS
		observer.process_priority=priority
		observer.process_physics_priority=priority
		add_child(observer)
	var suite:=TraceQuest.new(self)
	if "--runtime" in OS.get_cmdline_user_args():await suite._test_runtime()
	else:await suite.run()
	for value in ledger:print("PROMPT_BUFFERED ",JSON.stringify(value))
	await _finish()
