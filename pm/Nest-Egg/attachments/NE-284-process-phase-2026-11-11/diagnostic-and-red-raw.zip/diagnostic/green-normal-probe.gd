extends "res://tests/smoke_test.gd"

var process_count := 0
func _process(_delta: float) -> void:
	process_count += 1

func _run() -> void:
	var original_ticks := Engine.physics_ticks_per_second
	Engine.physics_ticks_per_second = 60
	for trial in 20:
		var before := process_count
		var count := _failures.size()
		await EnvironmentSuite.new(self)._test_local_drip()
		print("NE284_TRIAL ", trial, " process_callbacks=", process_count - before, " failures=", _failures.size() - count)
		await get_tree().process_frame
	Engine.physics_ticks_per_second = original_ticks
	await _finish()
