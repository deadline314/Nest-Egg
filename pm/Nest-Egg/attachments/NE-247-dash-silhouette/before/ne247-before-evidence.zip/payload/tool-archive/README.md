# NE247 genuine original-product before: normal scene candidate

This supersedes the rejected CPU-only `C:/tmp/ne247-before-world-review/` custom SceneTree/--script launcher. That entry bypassed normal project autoload compilation and is not an accepted native entry. Its frozen files remain untouched. This candidate uses ordinary Node .gd+.tscn under `res://tools/` and the normal project scene argv, matching the established native probe launch route. No autoload is manually constructed or mocked.

CPU review did not edit primary, Git or PM, or run any engine. Root must adopt ONLY these two new untracked tools into the primary original product before running. All377 original source bytes remain separately frozen; the runtime preflight checks them and BOTH adopted tool files, then writes a fresh379-path actual runtime manifest. There is no product-toggle suppression, pool substitute, fabricated state, viewport clone or fake image.

Root adoption, assuming neither destination already exists (otherwise inspect it and do not overwrite blindly):

```powershell
$beforeTools = @('dash_silhouette_before_probe.gd','dash_silhouette_before_probe.tscn')
foreach ($beforeTool in $beforeTools) {
    $beforeTarget = Join-Path C:/Github/Nest-Egg/tools $beforeTool
    if (Test-Path -LiteralPath $beforeTarget) { throw "Existing before tool requires review: $beforeTarget" }
    Copy-Item -LiteralPath (Join-Path C:/tmp/ne247-before-scene-review/candidate/tools $beforeTool) -Destination $beforeTarget
}
$beforeHead = (git -C C:/Github/Nest-Egg rev-parse HEAD).Trim()
& C:/Users/stanl/AppData/Local/Programs/Python/Python312/python.exe C:/Github/Nest-Egg/tools/comfyui/gpu_lock.py -- pwsh -NoProfile -File C:/tmp/ne247-before-scene-review/run_before.ps1 -Out C:/tmp/ne247-before-native-1 -Baseline $beforeHead
```

Run only after the other native engine ends, under the same shared GPU lock. Out must be a NEW absolute Ctmp directory; do not reuse evidence. Root can use its existing serial GPU-lock wrapper with the same inner command. Actual baseline HEAD is obtained by Root, then checked exactly by preflight; reviewer did not invoke Git. Root reported main aeb45f77f5b99ca962786fb28341f1a87fb9ad4f/81d runtime-identical for this scope. Any frozen-source drift rejects before engine launch; do not bypass it by relabeling this as passed source.

Exactly two cases use the same actual pawnshop VisualLevel, support cells, pistol, lighting, physics, input and camera as the after probe:

- `pistol-dark-right-ground`, cell19; `NE247-before-00-pistol-dark-right-ground.png`
- `pistol-lit-left-air`, cell58; `NE247-before-01-pistol-lit-left-air.png`

Actual tuning remains dash speed360/time0.17. Capture waits for genuine Player.DASH elapsed >=0.09 seconds and before the real dash ends, then pauses the actual main viewport for rendering/readback. All15 observed frames remain, including every DASH invulnerability, peak physical speed, unchanged health and natural original FX expiry assertions. The original PlayerVisual generates its own older bounded capsule FX. Controlled relocation only changes player position; no velocity, dash state/cooldown, ghosts or lighting is assigned. Real jump and movement use Input actions. The normal Node host processes ALWAYS so it can render/resume the paused scene while the real Level stays PAUSABLE.

The seven critical LF snapshots include actual original Player/Visual. Map/map JSON/tuning/Level/viewport-capture bytes match the after manifest. Original Player/Visual intentionally differ. Before waits real >=0.09-second DASH age; after additionally uses real silhouette oldest-age/displacement eligibility. This is a genuine same-scenario comparison with different capture policies, not a claim of identical frames or phases.

Fresh private APPDATA and LOCALAPPDATA isolate settings/saves, and previous launcher environment is restored. The wrapper records actual large Godot PID WorkingSet/PrivateBytes, stdout/stderr, manifest SHA, natural EOF and rejection. Script/Parse/Compile/ERROR output, nonzero exit, failed report assertion or screenshot count other than2 reject the run. Its120-second watchdog stops only its owned process and records non-natural EOF. OS memory is process memory, not VRAM, a strict cap or a matched full-scenario performance delta.

No editor/import ran here. Normal project scene avoids the identified custom SceneTree entry issue, but native global-class/cache loading and Godot semantics remain unverified until Root runs the actual executable. This is tool-driven Input, isolated authored Level and controlled staging; it does not prove physical keyboard/gamepad, Main start/continue, disk resume, clinic, whole chapter or whole game. Both PNGs still require Root viewing; native_visual_accepted remains false in the report. Captured image existence alone is not acceptance.
