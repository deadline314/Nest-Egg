extends Node

var route: Node
var profile: StringName
var _level: Level
var _player: Player
var _first_seen := {}
var _first_windup := {}
var _last_ground := {}
var _takeoff := {}
var _damages: Array[Dictionary] = []
var _landings: Array[Dictionary] = []
var _windups: Array[Dictionary] = []
var _visited: Dictionary = {}


func _process(_delta: float) -> void:
	var main := route.get("_main") as Node
	if not is_instance_valid(main):
		return
	var active: Variant = main.get("_screen")
	var level := active as Level if is_instance_valid(active) else null
	var player := level.player if level != null and is_instance_valid(level.player) else null
	if level != _level or player != _player:
		_level = level
		_player = player
		_last_ground.clear()
		_takeoff.clear()
		_first_seen.clear()
		_first_windup.clear()
		if is_instance_valid(player) and not player.health.damaged.is_connected(_damage):
			player.health.damaged.connect(_damage)
	if level == null or player == null or level.camera == null or not level.camera.is_current():
		return
	_visited[String(level.data.id)] = level.camera.tuning.zoom
	if player.is_dead() or GameplayLock.is_locked() or not level.is_processing():
		return
	var frame := Engine.get_physics_frames()
	var viewport := level.get_viewport()
	var screen := viewport.get_visible_rect()
	var transform := viewport.get_canvas_transform()
	for node: Node in get_tree().get_nodes_in_group(&"enemies"):
		var enemy := node as Enemy
		if enemy == null or not level.is_ancestor_of(enemy) or enemy.health == null or enemy.health.current <= 0:
			continue
		var bounds := enemy.prompt_obstacle_rect()
		var visible := bounds.has_area() and screen.intersects(transform * bounds)
		var id := enemy.get_instance_id()
		if visible and not _first_seen.has(id):
			_first_seen[id] = frame
		if not _first_windup.has(id) and (enemy.fsm.current == &"windup" or enemy._telegraph_left > 0.0):
			_first_windup[id] = true
			_windups.append({"enemy": String(enemy.data.id), "area": String(level.data.id), "visible": visible,
				"first_visible_frames": frame - int(_first_seen[id]) if _first_seen.has(id) else -1})
	if player.is_on_floor():
		if not _takeoff.is_empty():
			var feet := player.global_position
			var from: Vector2 = _takeoff["feet"]
			if feet.distance_to(from) >= 16.0:
				var previous_transform: Transform2D = _takeoff["camera"]
				var before := previous_transform * feet
				_landings.append({"area": String(level.data.id), "from": [from.x,from.y], "landing": [feet.x,feet.y],
					"visible_before_takeoff": screen.has_point(before), "pixel_at_takeoff": [before.x,before.y],
					"jump": _takeoff["jump"], "air_frames": frame - int(_takeoff["frame"])})
			_takeoff.clear()
		_last_ground = {"feet": player.global_position, "camera": transform, "frame": frame}
	elif _takeoff.is_empty() and not _last_ground.is_empty():
		_takeoff = _last_ground.duplicate()
		_takeoff["jump"] = Input.is_action_pressed(&"jump") or player.velocity.y < -5.0
		_last_ground.clear()


func _damage(info: DamageInfo) -> void:
	if not is_instance_valid(_level) or not is_instance_valid(_player):
		return
	var viewport := _level.get_viewport()
	var source := info.get_attacker() as Node2D
	var status := "unknown"
	var source_type := ""
	if source != null and source.is_inside_tree():
		var on_screen := false
		if source is Enemy:
			var bounds := (source as Enemy).prompt_obstacle_rect()
			on_screen = bounds.has_area() and viewport.get_visible_rect().intersects(viewport.get_canvas_transform() * bounds)
			source_type = String((source as Enemy).data.id)
		else:
			on_screen = viewport.get_visible_rect().has_point(viewport.get_canvas_transform() * source.global_position)
			source_type = source.get_class()
		status = "visible" if on_screen else "outside"
	_damages.append({"area": String(_level.data.id), "source": String(info.source_id), "source_type": source_type,
		"attacker": status, "amount": info.amount, "projectile": info.is_projectile, "health_after": _player.health.current,
		"frame": Engine.get_physics_frames()})


func _exit_tree() -> void:
	var file := FileAccess.open(str(route.get("_out")).path_join("camera-observations.json"), FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify({"profile": String(profile), "visited": _visited,
			"windups": _windups, "damage": _damages, "landings": _landings}, "\t"))
