extends "res://tools/ch1_flow_probe.gd"

var store_path := ""
var side := 1
var app: Node
var player: Player
var rig: CharacterRig
var rows: Array[Dictionary] = []
var lens := 0.0
var mode := ""
var anchor_x := 472.0


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--slot="):
			store_path = arg.trim_prefix("--slot=")
		elif arg.begins_with("--side="):
			side = int(arg.trim_prefix("--side="))
		elif arg.begins_with("--lens="):
			lens = float(arg.trim_prefix("--lens="))
		elif arg.begins_with("--mode="):
			mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--anchor-x="):
			anchor_x = float(arg.trim_prefix("--anchor-x="))
	if not store_path.is_absolute_path() or side not in [-1, 1] or mode != "kneel":
		get_tree().quit(2)
		return
	app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	app.set("_run_store", RunSaveStore.new(store_path))
	add_child(app)
	for frame in STEP_LIMIT:
		if app.get("_screen") is MainMenu and not bool(app.call("_route_pending")):
			break
		await get_tree().process_frame
	var menu := app.get("_screen") as MainMenu
	if menu == null:
		get_tree().quit(2)
		return
	await _settle(8)
	menu._continue_button.pressed.emit()
	for frame in STEP_LIMIT:
		var current := app.get("_screen") as Level
		if current != null and current.is_initialized() and current.data.id == &"ch1_street" and not bool(app.call("_route_pending")) and not Transition.is_active():
			_level = current
			break
		await get_tree().process_frame
	if _level == null or _level.player == null:
		get_tree().quit(2)
		return
	player = _level.player
	rig = player._visual.rig
	player.global_position = Vector2(anchor_x, player.global_position.y)
	player.velocity = Vector2.ZERO
	_level.camera.snap_to_target()
	AimInput.set_virtual_gamepad(player, true)
	AimInput.restore_direction(Vector2(side,0))
	await _settle(36)
	_check(player.facing == side and player.is_on_floor(), "real safe street floor and requested facing")
	if lens > 0.0:
		_level.camera.set_physics_process(false)
		_level.camera.position_smoothing_enabled = false
		_level.camera.offset = Vector2.ZERO
	await _fire_sequence()
	AimInput.set_virtual_gamepad(player, false)
	var file := FileAccess.open(_out_dir.path_join("motion.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks_failed":_failures,"side":side,"mode":mode,"rows":rows, "device":"scripted game input"},"  ") + "\n")
	file.close()
	app.call("_quit", int(_failures > 0))



func _fire_sequence() -> void:
	for blocking: bool in [false, true]:
		AimInput.restore_direction(Vector2(side, 0.0))
		if blocking:
			Input.action_press(&"block")
		await _settle(48)
		_check(player.is_blocking == blocking and player._visual._input.blocking == blocking, "real player and rig agree before shot")
		var label := "from_guard" if blocking else "steady"
		await _draw_frame(label + "_before")
		var before := player.loadout.mag_in(player.loadout.active_slot)
		var muzzle := player.muzzle_position()
		var projectile: Projectile = ProjectilePool._free.back()
		var events: Array[Dictionary] = []
		var on_debit := func(loadout: Loadout) -> void:
			if loadout == player.loadout and loadout.mag_in(player.loadout.active_slot) == before - 1:
				var sampled := player.muzzle_position()
				var actual := player._visual._input.blocking
				player._visual._input.blocking = false
				rig.refresh_weapon_aim(player._visual._input)
				var unguarded := player.muzzle_position()
				player._visual._input.blocking = actual
				rig.refresh_weapon_aim(player._visual._input)
				events.append({"sampled": _p(sampled), "target": _p(unguarded),
					"sample_gap": sampled.distance_to(unguarded), "rig_guard": actual, "game_guard": player.is_blocking})
		EventBus.player_loadout_changed.connect(on_debit)
		if blocking:
			Input.action_release(&"block")
		Input.action_press(&"shoot")
		await get_tree().process_frame
		Input.action_release(&"shoot")
		EventBus.player_loadout_changed.disconnect(on_debit)
		var first := _projectile_state(projectile)
		_check(events.size() == 1 and projectile.active, "one debit and an actual live projectile")
		if events.size() == 1:
			_check(projectile.global_position.distance_to(Vector2(events[0].sampled[0], events[0].sampled[1])) < 0.001, "projectile launches from the sampled gun")
		await _draw_frame(label + "_first")
		rows.append({"label":label,"prior_muzzle":_p(muzzle),"after_pose":_p(player.muzzle_position()),
			"first":first,"debits":events})
func _draw_frame(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	_capture(name)


func _projectile_state(projectile: Projectile) -> Dictionary:
	return {} if projectile == null else {"id": projectile.get_instance_id(), "position": _p(projectile.global_position),
		"velocity": _p(projectile.velocity), "live": projectile.active, "physics": Engine.get_physics_frames()}


func _p(vector: Vector2) -> Array:
	return [vector.x, vector.y]


func _select(slot: int) -> void:
	var key := InputEventKey.new()
	key.physical_keycode = KEY_1 + slot
	key.pressed = true
	Input.parse_input_event(key)
	var release := InputEventKey.new()
	release.physical_keycode = key.physical_keycode
	Input.parse_input_event(release)


