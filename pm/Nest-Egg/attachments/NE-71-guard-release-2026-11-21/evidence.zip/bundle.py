from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json
import re

root = Path.cwd()
base = Path(__file__).resolve().parent
def read(path):
    return json.loads(path.read_bytes())

media = {
    'guard-held': 'candidate-native/kneel-1-3.4/from_guard_before.png',
    'guard-release-before': 'stock-native/kneel-1-3.4/from_guard_first.png',
    'guard-release-after': 'candidate-native/kneel-1-3.4/from_guard_first.png',
}
run_dirs = ('stock-headless','candidate-headless','stock-native','candidate-native')
runs = {label:[read(file) for file in sorted((base/label).glob('*/motion.json'))] for label in run_dirs}
assert [len(runs[label]) for label in run_dirs] == [2,2,1,1]
for label, rr in runs.items():
    for report in rr:
        assert report['checks_failed'] == 0
        steady, guard = report['rows']
        assert steady['label']=='steady' and guard['label']=='from_guard'
        assert steady['debits'][0]['sample_gap'] < 0.001
        assert all(row['first']['position']==row['debits'][0]['sampled'] for row in report['rows'])
        event = guard['debits'][0]
        assert not event['game_guard']
        if label.startswith('stock'):
            assert event['rig_guard'] and 2.79 < event['sample_gap'] < 2.82
        else:
            assert not event['rig_guard'] and event['sample_gap'] < 0.001
        assert guard['first']['velocity'][0] * report['side'] > 570.0
for stock, candidate in (('stock-headless','candidate-headless'),('stock-native','candidate-native')):
    for old, fixed in zip(runs[stock],runs[candidate]):
        assert old['side'] == fixed['side']
        assert old['rows'][0]['debits'][0]['sampled'] == fixed['rows'][0]['debits'][0]['sampled']

report = base/'official-release'
assert read(report/'verification.json') == {'exit':0,'errors':[],'source_held':True}
official = (report/'raw.log').read_text(encoding='utf-8')
print(official)
assert 'Running 31 groups' in official
totals = official.splitlines()[-20:]
check_count = next(int(m[1]) for line in totals if (m:=re.search(r'checks:\s*(\d+)',line)))
stock_output = (base/'focus-stock.log').read_bytes().decode('utf-8-sig')
assert stock_output.count('FAIL: the shot on the guard-release tick') == 1

ticket=Path('pm/Nest-Egg/[NE-71]驗證凜新外觀在遊戲內的表現.md')
archive=Path('pm/Nest-Egg/attachments/NE-71-guard-release-2026-11-21/evidence.zip')
images={name: Path(f'pm/Nest-Egg/images/NE-71-{name}-20261121.png') for name in media}
runtime = list(map(Path,read(base/'runtime.json')))
design = Path('design/12-cast-redraw/RIG_QUALITY.md')
before=(root/ticket).read_text(encoding='utf-8')
assert '# Commit-13（' in before and '# Commit-14（' not in before
assert not (root/archive.parent).exists() and all(not (root/file).exists() for file in images.values())
raw = [base/p for p in ('adopt.py','bundle.py','observe_prefire.gd','observe_prefire.tscn','run.py','focus-stock.log',
                       'official-release/raw.log','official-release/verification.json','official-release/command.json')]
raw.extend(sorted((report/'shards').glob('*.log')))
for label in run_dirs:
    for folder in sorted((base/label).iterdir()):
        raw.extend(file for file in sorted(folder.iterdir()) if file.is_file())
(root/archive).parent.mkdir()
with ZipFile(root/archive,'x',compression=ZIP_DEFLATED) as bundle:
    for path in raw:
        bundle.write(path,path.relative_to(base).as_posix())
with ZipFile(root/archive) as bundle:
    assert bundle.testzip() is None
for label,file in images.items():
    (root/file).write_bytes((base/media[label]).read_bytes())
section=f'''
---

# Commit-14（放開盾的同一格同步槍口）

## 內文

凜放開格擋並立刻射擊時，遊戲已允許開火，槍械求解卻仍沿用上一格縮短握槍距離的格擋姿勢。把格擋狀態移入共用的持槍取樣，同一格先更新握點再發射。按住格擋時仍擋住射擊。後座及盾面的收起動畫按原時序播放。

### 測試結果

- 第一章港區街道用正式 P-9，向左、向右的無頭流程及 RX 9070 XT Forward+ 向右取景都重現問題。舊版第一發比未格擋的槍口內縮約 2.80 世界像素；修正後實際彈頭貼合扣彈當下伸出的槍口，誤差低於 0.001。沒舉盾直接開火的起點一致。
- 新回歸在舊程式重現一次失敗。修正版本的受影響測試通過 31 套、{check_count:,} 項。

[原生比較、實際彈道及回歸日誌](attachments/NE-71-guard-release-2026-11-21/evidence.zip)

### 截圖

![放開前的格擋姿勢](images/NE-71-guard-held-20261121.png)
![舊版放盾時的第一發](images/NE-71-guard-release-before-20261121.png)
![修正後放盾時的第一發](images/NE-71-guard-release-after-20261121.png)
'''
(root/ticket).write_text(before.rstrip()+'\n\n\n'+section.lstrip('\n'),encoding='utf-8')
paths=[*runtime,design,ticket,archive,*images.values()]
(base/'delivery.json').write_text(json.dumps([path.as_posix() for path in paths],ensure_ascii=False,indent=2)+'\n',
                                  encoding='utf-8')
print(len(raw),(root/archive).stat().st_size)

