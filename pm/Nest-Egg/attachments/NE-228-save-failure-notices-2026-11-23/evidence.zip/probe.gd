extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const FIRST := "res://data/levels/ch1_pawnshop.tres"
const TARGET := "res://data/levels/ch1_rooftop.tres"
const COPY := {
	"zh": ["存檔未成功", "區域進度尚未保存"],
	"ja": ["保存できませんでした", "エリアの進行状況を保存できませんでした"],
	"en": ["Save failed", "Could not save this area"],
}


class ProbeMain extends "res://game/main.gd":
	func _ready() -> void:
		pass


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://save_notice_probe.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	GameState.story_autosave = false
	Story.auto_skip = true
	add_child(LightKit.create_environment())
	var args := OS.get_cmdline_user_args()
	for language: String in COPY:
		await _case(language, args[0] if args.size() == 1 else "-")
	await _finish()


func _case(language: String, screenshot: String) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_active_presentation(&"test_setup")
	var main := ProbeMain.new()
	add_child(main)
	var level := Level.new()
	level.configure(load(FIRST) as LevelData)
	main.add_child(level)
	main._screen = level
	main._level_path = FIRST
	main._active_run = true
	main._run_store = RunSaveStore.new("user://save-notice-%s.json" % language)
	main._run_store.validator = RunSnapshot.prepare
	await _frames(24)
	Story.reset_active_presentation(&"test_setup")
	main._save_run()
	var store := main._run_store
	var original := FileAccess.get_file_as_bytes(store.path)
	var blocker := ProjectSettings.globalize_path(store.path + ".tmp")
	var words: Array = COPY[language]
	_check(not original.is_empty(), "%s original game writer produced a real primary" % language)
	_check(DirAccess.make_dir_absolute(blocker) == OK, "%s isolated filesystem blocks only the temporary save file" % language)
	Progression.add_credits(13)
	main._save_run()
	var banner := level.hud.toast_banner
	_check(FileAccess.get_file_as_bytes(store.path) == original, "%s write refusal leaves the previous primary byte-identical" % language)
	_check(banner._label.text.contains(words[0]), "%s real HUD shows the save failure in the selected language [%s]" % [language, banner._label.text])
	if language == "en" and screenshot.is_absolute_path():
		for i in 12:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(screenshot) == OK, "actual localized save warning captured")
	_check(DirAccess.remove_absolute(blocker) == OK, "%s remove only our failed-write fixture" % language)
	main._save_run()
	_check(FileAccess.get_file_as_bytes(store.path) != original and banner._label.text.is_empty(),
		"%s a successful retry publishes the real wallet and withdraws its own warning" % language)
	original = FileAccess.get_file_as_bytes(store.path)
	_check(DirAccess.make_dir_absolute(blocker) == OK, "%s recreate only our temporary-file refusal" % language)
	var runtime := level.run_snapshot()
	_check(not main._save_destination(runtime, TARGET) and FileAccess.get_file_as_bytes(store.path) == original,
		"%s destination failure retains the exact source save" % language)
	_check(banner._label.text.contains(words[1]), "%s real area warning uses the selected language [%s]" % [language, banner._label.text])
	_check(DirAccess.remove_absolute(blocker) == OK, "%s remove temporary area refusal" % language)
	main.queue_free()
	await _frames(5)
