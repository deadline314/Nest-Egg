extends Node
## Ticket-local producer, initially menu/calibration scope only. No full-matrix
## acceptance is emitted until every inventory row has a real observation.
const Capture := preload("res://tools/viewport_capture.gd")
const Geometry := preload("res://work/ne228-matrix-20261117/geometry_audit.gd")
const WindowCapture := preload("res://work/ne228-matrix-20261117/window_capture.gd")
var _out := ""
var _size := Vector2i(1280, 720)
var _scale := 1.0
var _reduce := false
var _phase := "menus"
var _level: Level
var _records: Array[Dictionary] = []
var _failures: Array[String] = []


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
		elif arg.begins_with("--width="): _size.x = int(arg.trim_prefix("--width="))
		elif arg.begins_with("--height="): _size.y = int(arg.trim_prefix("--height="))
		elif arg.begins_with("--text-scale="): _scale = float(arg.trim_prefix("--text-scale="))
		elif arg == "--reduce-motion": _reduce = true
		elif arg.begins_with("--phase="): _phase = arg.trim_prefix("--phase=")
	if _phase not in ["menus", "core", "all"]:
		printerr("[NE228] Unknown/unimplemented scope; refusing full-matrix acceptance.")
		get_tree().quit(2)
		return
	if DisplayServer.get_name() == "headless" or RenderingServer.get_current_rendering_method() != "forward_plus" or not _out.is_absolute_path():
		printerr("[NE228] Native Forward+, a fresh absolute output and isolated profile are required.")
		get_tree().quit(2)
		return
	var isolated := OS.get_environment("NE228_PROFILE_ROOT").replace("\\", "/").to_lower()
	if isolated.is_empty() or not OS.get_user_data_dir().replace("\\", "/").to_lower().begins_with(isolated + "/"):
		get_tree().quit(2)
		return
	DirAccess.make_dir_recursive_absolute(_out)
	Settings.use_storage("user://ne228-matrix-settings.cfg")
	Settings.set_ui_text_scale(_scale)
	Settings.set_reduce_ui_motion(_reduce)
	Settings.set_ui_font("smooth")
	Settings.set_brightness(0.5)
	get_window().borderless = true
	get_window().position = Vector2i(0, 32)
	get_window().size = _size
	DisplayMode.ensure_scaling(get_window())
	_run.call_deferred()


func _wait(seconds := 0.35) -> void:
	await get_tree().create_timer(seconds, true, false, true).timeout
	await get_tree().process_frame
	await RenderingServer.frame_post_draw


func _capture(page: String, screen: Node, content: Dictionary) -> void:
	var opening_state := {}
	if page == "pause/main": opening_state = _pause_state()
	var world_before := {}
	if is_instance_valid(_level) and get_tree().paused:
		world_before = preload("res://tools/world_pause_sample.gd").snapshot(_level)
	await _wait()
	# A real-time timer can expire during synchronous image readback while the
	# UI coroutine still needs actual process frames before creating its tween.
	for frame in 3:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
	var presentation_trace: Array[Dictionary] = []
	var presentation_deadline := Time.get_ticks_msec() + 1500
	while true:
		var presentation := _presentation_state(screen)
		presentation_trace.append(presentation)
		if presentation.ready or Time.get_ticks_msec() >= presentation_deadline: break
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
	if not presentation_trace[-1].ready: _failures.append(page + ": required presentation did not settle")
	var settle_trace: Array[Dictionary] = []
	if page == "pause/main":
		var deadline := Time.get_ticks_msec() + 1500
		while Time.get_ticks_msec() < deadline:
			var state := _pause_state()
			settle_trace.append(state)
			if state.info_visible and state.info_alpha >= 0.999 and state.menu_alpha >= 0.999: break
			await get_tree().process_frame
			await RenderingServer.frame_post_draw
		var state := _pause_state()
		if not state.info_visible or state.info_alpha < 0.999 or state.menu_alpha < 0.999:
			_failures.append("pause/main mandatory info panel did not finish opening")
	var image := Capture.image(get_viewport())
	var name := page.replace("/", "-") + ".png"
	var error := image.save_png(_out.path_join(name))
	if error != OK: _failures.append("cannot save " + name)
	var viewport_rect := get_viewport().get_visible_rect()
	var final := get_viewport().get_final_transform()
	var drawable := final * viewport_rect
	var native_size := DisplayServer.window_get_size(get_window().get_window_id())
	var native_position := DisplayServer.window_get_position(get_window().get_window_id())
	# KEEP's root texture is the active content. Native black bars belong to the
	# window, not that texture. Both sizes and their real transform are retained.
	if get_window().size != _size or native_size != _size or image.get_size() != Vector2i(drawable.size):
		_failures.append("native window / active drawable dimensions disagree")
	if not Rect2(Vector2.ZERO, Vector2(_size)).encloses(drawable):
		_failures.append("active drawable outside native window")
	var full_window := {}
	if page == "main/main" and _size.x == 2560:
		full_window = {"scope":"optional complete desktop client rectangle, separate from active-viewport layout evidence",
			"known_external_overlay":"OSK UIAccess window may occlude desktop pixels; no attempt to hide, operate or cover it",
			"accepted_as_unobstructed_window":false}
		var desktop := WindowCapture.image(get_window())
		if desktop == null or desktop.get_size() != _size:
			full_window["status"] = "unavailable; not used for UI-layout acceptance"
		else:
			var path := _out.path_join("native-wide-complete-window.png")
			if desktop.save_png(path) != OK:
				full_window["status"] = "cannot save optional desktop capture"
			else:
				full_window.merge({"status":"captured; external occlusion review pending, not accepted as unobstructed",
					"file": "native-wide-complete-window.png", "sha256": FileAccess.get_sha256(path),
					"width": desktop.get_width(), "height": desktop.get_height(), "basis": "actual DisplayServer desktop client rectangle; no padding or scaling"})
	var geometry := Geometry.inspect(screen, get_viewport())
	for issue in geometry.errors: _failures.append(page + ": " + str(issue))
	var world_after := {}
	if not world_before.is_empty():
		world_after = preload("res://tools/world_pause_sample.gd").snapshot(_level)
		if world_before != world_after or world_after.level_can_process or world_after.player_can_process or world_after.camera_can_process:
			_failures.append(page + ": paused world advanced or can still process")
	_records.append({"page": page, "file": name, "png_width": image.get_width(), "png_height": image.get_height(),
		"png_sha256": FileAccess.get_sha256(_out.path_join(name)), "content": content,
		"geometry": geometry, "text_scale": Settings.get_ui_text_scale(), "reduce_motion": Settings.get_reduce_ui_motion(),
		"window_size": [_size.x, _size.y], "active_drawable_window_rect": Geometry.box(drawable),
		"native_window_size": [native_size.x,native_size.y], "native_window_position": [native_position.x,native_position.y],
		"png_basis": "native active viewport readback, excludes KEEP black bars", "complete_window": full_window,
		"pause_opening_state": opening_state, "pause_settle_trace": settle_trace,
		"presentation_settle_trace": presentation_trace,
		"paused_world_before": world_before, "paused_world_after": world_after,
		"reading_state": {"cinematic": Story._layer.is_cinematic_active(),
			"dialogue_kind": Story._layer._dialogue_kind, "radio_visible": Story._layer._radio_root.is_visible_in_tree(),
			"dialogue_name":Story._layer._name.text,"dialogue_body":Story._layer._text.text,
			"reading_title":Story._layer._reading_title,
			"radio_name":Story._layer._radio_name.text,"radio_text": Story._layer._radio_text.text}})


func _run() -> void:
	GameState.story_autosave = false
	add_child(LightKit.create_environment())
	await _wait()
	var menu := MainMenu.new()
	add_child(menu)
	await _capture("main/main", menu, {"basis": "production MainMenu instance; Main cold route proved separately", "progress_seeded": false})
	menu._open_difficulty()
	await _capture("main/difficulty", menu, {"basis": "production difficulty definitions", "progress_seeded": false})
	# Deliberate overwrite UI state; no slot is overwritten or start signal handled.
	menu.overwrite_required = true
	menu._on_start()
	await _capture("main/overwrite-confirm", menu, {"basis": "arranged overwrite_required flag; layout only", "progress_seeded": true, "save_changed": false})
	if is_instance_valid(menu._overwrite_dialog):
		menu._overwrite_dialog._cancel()
		await _wait(0.05)
	menu.queue_free()
	await _wait(0.05)
	var settings := SettingsScreen.new()
	add_child(settings)
	for tab in settings._tabs.get_tab_count():
		settings._tabs.current_tab = tab
		settings._focus_first()
		await _capture("settings/" + ["audio", "bindings", "display", "controller"][tab], settings, {"basis": "production settings; isolated settings file", "progress_seeded": false})
	settings.queue_free()
	await _wait(0.05)
	var codex := CodexScreen.new()
	add_child(codex)
	codex.select_tab(0)
	await _capture("codex/defeat", codex, {"basis": "real catalog, fresh unearned progress; legitimately locked content", "progress_seeded": false})
	codex.select_tab(1)
	await _capture("codex/replay-empty", codex, {"basis": "fresh actual empty story history; no fake completion", "progress_seeded": false})
	codex._close()
	await _wait(0.05)
	if _phase in ["core", "all"]: await _core_pages()
	var pages := {}
	for record in _records: pages[record.page] = true
	var complete := _phase == "all" and pages.size() == 42 and _records.size() == 42 and _failures.is_empty()
	var report := {"scope": "single configuration of 42 production page/state layout observations; full five-configuration matrix is independently checked", "full_matrix_accepted": false, "page_state_scope_complete": complete,
		"renderer": RenderingServer.get_current_rendering_method(), "adapter": RenderingServer.get_video_adapter_name(),
		"hdr": get_viewport().use_hdr_2d, "records": _records, "failures": _failures,
		"physical_controller_verified": false, "human_gameplay_verified": false}
	var file := FileAccess.open(_out.path_join("matrix.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "\t") + "\n")
	print("NE228_MATRIX observations=", _records.size(), " issues=", _failures.size(), " PAGE_STATE_SCOPE_COMPLETE=", complete)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures.is_empty() else 1)


func _pause_state() -> Dictionary:
	var pause := _level._pause_menu
	return {"ticks_usec": Time.get_ticks_usec(), "frame": Engine.get_process_frames(),
		"info_visible": pause._info_panel.is_visible_in_tree(),
		"info_alpha": Geometry.effective_alpha(pause._info_panel),
		"menu_alpha": Geometry.effective_alpha(pause._menu_panel),
		"info_can_process": pause._info_panel.can_process(), "tree_paused": get_tree().paused,
		"engine_time_scale": Engine.time_scale,
		"running_tweens": get_tree().get_processed_tweens().size()}


func _presentation_state(screen: Node) -> Dictionary:
	var pending: Array[String] = []
	var nodes: Array[Node] = [screen]
	nodes.append_array(screen.find_children("*", "", true, false))
	for node in nodes:
		if not node is CanvasItem or not node.is_visible_in_tree(): continue
		if node.has_meta(UiMotion.TWEEN_META):
			var tween: Variant = node.get_meta(UiMotion.TWEEN_META)
			if tween is Tween and tween.is_valid() and tween.is_running(): pending.append(str(screen.get_path_to(node)))
		if screen is DeathScreen and node is UiPanel and (node.scale != Vector2.ONE or Geometry.effective_alpha(node) < 0.999):
			pending.append("death card not fully presented")
	if screen is InventoryScreen and screen._is_open:
		if screen._root.modulate.a < 0.999 or absf(screen._frame.scale.y - 1.0) > 0.001:
			pending.append("inventory opening")
	if screen is MainMenu and screen._difficulty_page.is_visible_in_tree():
		for card in screen._cards:
			if Geometry.effective_alpha(card) < 0.999: pending.append("difficulty card not fully presented")
	if screen is VictoryScreen:
		for row in screen._rows:
			if row.modulate.a < 0.999: pending.append("unrevealed result row")
		for button in screen._buttons:
			if button.disabled: pending.append("result actions not ready")
	return {"frame": Engine.get_process_frames(), "time_usec": Time.get_ticks_usec(), "ready": pending.is_empty(), "pending": pending}


func _core_pages() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	var data := (load("res://data/levels/ch1_pawnshop.tres") as LevelData).duplicate(true) as LevelData
	data.intro_scene = &"" # Explicit presentation arrangement, never a route completion.
	_level = Level.new()
	_level.process_mode = Node.PROCESS_MODE_PAUSABLE
	_level.configure(data)
	add_child(_level)
	await _wait(1.2)
	await _capture("world/hud", _level.hud, {"basis": "actual Level/HUD; authored pawnshop geometry; intro suppressed for UI", "progress_seeded": false})
	_level._pause_menu.open()
	await _capture("pause/main", _level._pause_menu, {"basis": "production PauseMenu; actual paused world", "progress_seeded": false})
	if _phase == "all":
		var prologue := load("res://data/levels/ch1_prologue.tres") as LevelData
		_level._pause_menu.skip_label = prologue.skip_label
		_level._pause_menu.skip_note = prologue.skip_note
		_level._pause_menu._ask_skip()
		await _capture("pause/skip-confirm", _level._pause_menu, {"basis": "real prologue confirmation copy presented over pawnshop; no skip action or route completion", "progress_seeded": true})
		_level._pause_menu._cancel_skip()
	_level._pause_menu._open_navigation("quests")
	await _wait(0.1)
	var navigation := _level._pause_menu._navigation
	for filter: String in ["active", "completed", "main", "side"]:
		if filter in ["main", "side"]: navigation._filter("active")
		navigation._filter(filter)
		await _capture("quest/" + filter, navigation, {"basis": "formal chapter catalog and actual fresh state; empty completed/side result remains legitimate", "fixtures": false})
	for page: String in ["region", "world"]:
		navigation.show_page(page)
		await _capture("quest/" + page, navigation, {"basis": "formal map data and real player exploration; no artificial quest definitions", "fixtures": false})
	navigation.closed.emit()
	navigation.queue_free()
	await _wait(0.15)
	_level._pause_menu.close()
	await _wait(0.15)
	# Only holdings/balance are arranged; item/shop definitions and prices are real.
	Progression.add_credits(500)
	_level.player.consumables.add(ConsumableBag.find(&"med_injector"))
	StoryItems.acquire(&"ch3_report_p17", false)
	var bag := _level._inventory
	bag.open()
	var names := ["weapons", "upgrades", "consumables", "cyber", "story-items", "status"]
	for tab in bag._pages.size():
		bag.select_tab(tab)
		await _capture("inventory/" + names[tab], bag, {"basis": "production page and real data; wallet500/medical item/P17 possession explicitly arranged", "progress_seeded": true})
	bag.select_tab(bag.page_index(StoryItemsPage))
	await _wait(0.1)
	var story_page := bag._pages[bag._current] as StoryItemsPage
	for index in story_page._entries.size():
		if story_page._entries[index].id == &"ch3_report_p17":
			story_page._select(index)
			story_page._activate_entry(index)
			await _capture("inventory/full-document", bag, {"basis": "real authored P17 full text; acquisition arranged, not a chapter completion", "progress_seeded": true})
			story_page.handle_back()
	bag.close()
	await _wait(0.2)
	var shop := ShopScreen.new()
	shop.configure_shop(_level.player, load("res://data/shops/ch1_pawn.tres") as ShopData)
	add_child(shop)
	shop.open()
	for tab in shop._pages.size():
		shop.select_tab(tab)
		var page := shop._pages[tab]
		var name := "stock" if page is ShopPage else "pawn" if page is PawnPage else "workbench"
		await _capture("shop/" + name, shop, {"basis": "real ch1_pawn ShopData; arranged balance/medical item; production transactions", "progress_seeded": true})
		if page is PawnPage and not page._entries.is_empty():
			page.activate() # Actual production pawn operation on the arranged medical item.
			await _capture("shop/redeem", shop, {"basis": "real pawn transaction generated the ticket; no direct pawn-dictionary write", "progress_seeded": true})
	shop.close()
	await _wait(0.2)
	shop.queue_free()
	await _wait(0.1)
	if _phase == "all": await _context_pages()
	_level.queue_free()
	await _wait(0.1)
	_level = null
	if _phase == "all": await _outcome_pages()


func _context_pages() -> void:
	Story.auto_skip = false
	Settings.set_skip_cutscenes(false)
	# The production feed receives the real consumable's label, not invented copy.
	var med := ConsumableBag.find(&"med_injector")
	_level.hud.pickup_feed.push(med.display_name)
	await _capture("world/pickup-feed", _level.hud, {"basis": "production feed; real medical-item label; deliberately injected notification, not claimed acquired here"})
	var npc: NpcActor
	var object: NpcActor
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if not node is NpcActor or not _level.is_ancestor_of(node): continue
		if node.data.id == &"ch1_old_k": npc = node
		if node.data.id == &"ch1_label_watch": object = node
	if npc == null or object == null:
		_failures.append("authored pawnshop person/object missing")
		return
	_level.player.global_position = npc.global_position + Vector2(24, 0)
	await _wait(0.3)
	_level.camera.snap_to_target()
	_level.camera.force_update_scroll()
	if not npc._player_in_range or npc.talk_count != 0: _failures.append("person prompt/bubble source not eligible")
	await _capture("world/context-prompt", _level.hud, {"basis": "actual pawnshop actor's in-range WorldPrompt", "actor_id": str(npc.data.id), "in_range": npc._player_in_range})
	await _capture("world/bubble", npc, {"basis": "actual unread NPC bubble; no synthetic billboard", "talk_count": npc.talk_count})
	npc._talk()
	await _wait(0.5)
	if not Story._layer.is_cinematic_active(): _failures.append("actual person request failed")
	Story._layer._text.visible_ratio = 1.0
	await _capture("world/npc-dialogue", Story._layer, {"basis": "actual old K request, original first line revealed; cancelled without completion", "dialogue_kind": Story._layer._dialogue_kind})
	Story.reset_active_presentation(&"leave")
	await _wait(0.1)
	_level.player.global_position = object.global_position + Vector2(24, 0)
	await _wait(0.3)
	_level.camera.snap_to_target()
	_level.camera.force_update_scroll()
	object._talk()
	await _wait(0.5)
	if not Story._layer.is_cinematic_active() or Story._layer._dialogue_kind != "object": _failures.append("actual object request failed")
	Story._layer._text.visible_ratio = 1.0
	await _capture("world/object-reading", Story._layer, {"basis": "actual watch-label OBJECT and original text; no legacy test level", "actor_id": str(object.data.id), "dialogue_kind": Story._layer._dialogue_kind})
	Story.reset_active_presentation(&"leave")
	await _wait(0.1)
	# Explicit current-campaign definitions, not the first legacy scene found.
	var radio_id := &"ch1_g06_lamp"
	var choice_id := "ch1_t_handoff_confirm"
	var choice_step := {}
	for step: Dictionary in Story._scenes.get(choice_id, {}).get("steps", []):
		if step.get("do") == "choice":
			choice_step = step.duplicate(true)
			break
	if Story.scene_mode(radio_id) != Story.MODE_RADIO or Story.resolved_lines(radio_id).is_empty(): _failures.append("current-campaign authored radio missing")
	else:
		var authored_freeze := bool(Story._scenes.get(String(radio_id), {}).get("freeze", false))
		Story._layer.enqueue_radio(radio_id, Story.resolved_lines(radio_id), authored_freeze)
		await _wait(0.1)
		if not Story._layer._radio_root.is_visible_in_tree() or Story._layer._radio_text.text.is_empty(): _failures.append("authored radio not visible")
		Story._layer._radio_text.visible_ratio = 1.0
		await _capture("world/radio", Story._layer, {"basis": "current campaign's actual authored radio lines and freeze setting; first complete line revealed, cancelled without outcome", "scene_id": str(radio_id), "authored_freeze":authored_freeze})
		Story.reset_active_presentation(&"leave")
		await _wait(0.1)
	if choice_step.is_empty(): _failures.append("no authored choice")
	else:
		var player := CutscenePlayer.new()
		add_child(player)
		# One unchanged authored step, deliberately replayed in isolation; no option chosen.
		player.play(StringName(choice_id), {"overlay": true, "steps": [choice_step]})
		await _wait(0.3)
		if not player.choice_active(): _failures.append("authored choice not active")
		await _capture("world/choice", player, {"basis": "real authored choice step and real CutscenePlayer; isolated UI presentation, no flags/rewards selected", "scene_id": choice_id, "step": choice_step})
		player.cancel()
		await _wait(0.1)


func _outcome_pages() -> void:
	Story._completed[&"ch1_p01_door"] = true
	var codex := CodexScreen.new()
	add_child(codex)
	codex.select_tab(1)
	await _capture("codex/replay-list", codex, {"basis": "real opening entry; completion explicitly arranged for layout; actual earned/cold Main evidence reused from NE279", "progress_seeded": true})
	codex._close()
	await _wait(0.1)
	var death := DeathScreen.new()
	death.setup(DefeatCodex._cards[DefeatCodex.FALLBACK_ID].duplicate(true), true)
	add_child(death)
	await _wait(0.7)
	await _capture("flow/death", death, {"basis": "production DeathScreen and actual fallback card; UI-only outcome, no health/death/route claim"})
	death.queue_free()
	await _wait(0.1)
	var victory := VictoryScreen.new()
	add_child(victory)
	await _wait(2.0)
	await _capture("flow/victory", victory, {"basis": "production result screen, actual chapter metadata and arranged current stats; no chapter completion claimed"})
	victory.queue_free()
	await _wait(0.1)
	for entry: Array in [["radio-save", "res://ui/radio_save_prompt.gd"], ["destination-save", "res://ui/destination_save_prompt.gd"], ["controller-recovery", "res://ui/controller_recovery_prompt.gd"]]:
		var prompt := (load(entry[1]) as Script).new() as Control
		add_child(prompt)
		await _capture("recovery/" + entry[0], prompt, {"basis": "real production recovery component with original copy; explicit layout fixture, not disk-failure injection or physical disconnect"})
		prompt.queue_free()
		await _wait(0.1)
