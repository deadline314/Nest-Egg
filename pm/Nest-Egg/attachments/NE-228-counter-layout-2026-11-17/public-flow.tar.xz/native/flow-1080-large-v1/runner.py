"""Use the existing controller-capture CLI unchanged; synthetic public input, never hardware proof."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
tag, width, height, scale = sys.argv[1:]
assert re.fullmatch(r"[a-z0-9-]+", tag)
OUT = Path("D:/NestEggVerification/evidence-20261117/ne228-matrix") / tag
assert not OUT.exists()
OUT.mkdir(parents=True)
names = set(json.loads((OUT.parent / "all-720-normal-v3/source-before.json").read_text(encoding="utf8")))
names.update(["tools/controller_flow_probe.gd", "tools/controller_flow_capture.gd", "tools/controller_flow_capture.tscn", "tools/run_controller_capture.ps1"])
def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(names)}
before = hashes()
for name in before:
    target = OUT / "source" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
(OUT / "source-before.json").write_text(json.dumps(before, indent=2), encoding="utf8")
(OUT / "runner.py").write_bytes(Path(__file__).read_bytes())
command = [sys.executable, "-B", str(ROOT / "tools/comfyui/gpu_lock.py"), "--", "powershell.exe", "-NoProfile", "-File",
    str(ROOT / "tools/run_controller_capture.ps1"), "-Godot", "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "-OutputPath", str(OUT), "-Width", width, "-Height", height, "-TextScale", scale]
(OUT / "command.json").write_text(json.dumps(command, indent=2), encoding="utf8")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUT / "run.log").open("wb") as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
after = hashes()
raw = (OUT / "run.log").read_bytes()
text = raw.decode("utf8", errors="replace")
summary = re.search(r"NE229_SYNTHETIC_FLOW checks=(\d+) failures=(\d+)", text)
diagnostics = [line for line in text.splitlines() if re.search(r"SCRIPT ERROR|ERROR:|ObjectDB instances were leaked|resources still in use|RID allocations", line)]
receipt = {"exit": result.returncode, "sources_unchanged": before == after, "source_after": after,
    "checks": int(summary[1]) if summary else None, "failures": int(summary[2]) if summary else None,
    "diagnostics": diagnostics, "started_utc": started, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "unchanged CLI/real Main/public synthetic controller input; no physical controller or chapter-completion verification"}
(OUT / "exit.json").write_text(json.dumps(receipt, indent=2), encoding="utf8")
print(json.dumps({k: v for k, v in receipt.items() if k != "source_after"}), flush=True)
sys.exit(0 if result.returncode == 0 and before == after and summary and int(summary[2]) == 0 and not diagnostics else 1)
