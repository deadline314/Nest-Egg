extends RefCounted
## Read-only observer for a ticket-local producer, not a new game framework.
## It distinguishes ordinary clipped scroll content from inaccessible text.


static func box(rect: Rect2) -> Array[float]:
	return [rect.position.x, rect.position.y, rect.size.x, rect.size.y]


static func effective_alpha(item: CanvasItem) -> float:
	var result := item.modulate.a * item.self_modulate.a
	var parent := item.get_parent()
	while parent != null:
		if parent is CanvasItem: result *= parent.modulate.a
		parent = parent.get_parent()
	return result


static func scroll_owner(node: Node) -> ScrollContainer:
	var parent := node.get_parent()
	while parent != null:
		if parent is ScrollContainer: return parent
		parent = parent.get_parent()
	return null


static func clipping_rect(node: Control, viewport: Rect2) -> Rect2:
	var clip := viewport
	var parent := node.get_parent()
	while parent != null:
		if parent is Control and parent.clip_contents:
			clip = clip.intersection(parent.get_global_rect())
		parent = parent.get_parent()
	return clip


static func inspect(root: Node, viewport: Viewport) -> Dictionary:
	var view := viewport.get_visible_rect()
	var errors: Array[Dictionary] = []
	var labels: Array[Dictionary] = []
	var controls: Array[Dictionary] = []
	var scrolls: Array[Dictionary] = []
	var offscreen_scroll_labels := 0
	var nodes: Array[Node] = [root]
	nodes.append_array(root.find_children("*", "", true, false))
	for node in nodes:
		if not node is Control or not node.is_visible_in_tree() or effective_alpha(node) <= 0.01:
			continue
		var path := str(root.get_path_to(node))
		var rect: Rect2 = node.get_global_rect()
		var clip := clipping_rect(node, view)
		var visible := rect.intersection(clip)
		if node is ScrollContainer:
			var bar: VScrollBar = node.get_v_scroll_bar()
			var overflow: bool = bar.max_value - bar.page > 1.0
			var cue := ScrollCue.of(node)
			# A visible native scrollbar is also a real scrolling affordance.
			# Requiring only the bespoke arrow would create false failures.
			var native_bar: bool = bar.is_visible_in_tree() and bar.size.x > 0.0
			var custom_cue: bool = cue != null and cue.is_visible_in_tree() and (cue.more_above or cue.more_below)
			scrolls.append({"path": path, "rect": box(rect), "overflow": overflow,
				"native_bar": native_bar, "custom_cue": custom_cue,
				"position": node.scroll_vertical, "limit": maxf(0, bar.max_value - bar.page)})
			if overflow and not native_bar and not custom_cue:
				errors.append({"path": path, "issue": "overflow_without_visible_scroll_affordance"})
		if node is BaseButton:
			controls.append({"path": path, "rect": box(rect), "visible_rect": box(visible),
				"text": node.text if node is Button else "", "tooltip": node.tooltip_text,
				"disabled": node.disabled, "focused": node.has_focus(), "focus_mode": node.focus_mode})
		if not node is Label or node.text.strip_edges().is_empty(): continue
		var scroll := scroll_owner(node)
		var row := {"path": path, "text": node.text, "rect": box(rect), "clip": box(clip),
			"visible_rect": box(visible), "line_count": node.get_line_count(),
			"visible_line_count": node.get_visible_line_count(), "wrap": node.autowrap_mode,
			"overrun": node.text_overrun_behavior, "clip_text": node.clip_text,
			"font_size": node.get_theme_font_size(&"font_size"), "inside_scroll": scroll != null}
		if node.autowrap_mode == TextServer.AUTOWRAP_OFF and node.text_overrun_behavior == TextServer.OVERRUN_NO_TRIMMING:
			var needed := 0.0
			for line in node.text.split("\n"):
				needed = maxf(needed, node.get_theme_font(&"font").get_string_size(line, HORIZONTAL_ALIGNMENT_LEFT, -1, node.get_theme_font_size(&"font_size")).x)
			var origin := rect.position
			if node.horizontal_alignment == HORIZONTAL_ALIGNMENT_CENTER:
				origin.x += (rect.size.x - needed) * 0.5
			elif node.horizontal_alignment == HORIZONTAL_ALIGNMENT_RIGHT:
				origin.x += rect.size.x - needed
			row["unwrapped_text_extent"] = box(Rect2(origin, Vector2(needed, rect.size.y)))
		labels.append(row)
		if scroll != null and view.encloses(scroll.get_global_rect().grow(-0.5)) and not clip.encloses(rect.grow(-0.5)):
			offscreen_scroll_labels += 1
			continue
		if not view.encloses(rect.grow(-0.5)):
			errors.append({"path": path, "issue": "label_outside_viewport", "text": node.text, "rect": box(rect)})
		elif node.clip_text and node.text_overrun_behavior == TextServer.OVERRUN_NO_TRIMMING:
			if node.get_visible_line_count() < node.get_line_count():
				errors.append({"path": path, "issue": "label_vertical_text_clipping", "text": node.text})
			if node.autowrap_mode == TextServer.AUTOWRAP_OFF:
				var needed: float = node.get_theme_font(&"font").get_string_size(node.text, HORIZONTAL_ALIGNMENT_LEFT, -1, node.get_theme_font_size(&"font_size")).x
				if needed > rect.size.x + 1.0:
					errors.append({"path": path, "issue": "label_horizontal_text_clipping", "text": node.text, "needed": needed, "available": rect.size.x})
	var focus := viewport.gui_get_focus_owner()
	return {"viewport": box(view), "window_size": [viewport.get_window().size.x, viewport.get_window().size.y],
		"final_transform": [viewport.get_final_transform().x.x, viewport.get_final_transform().x.y,
			viewport.get_final_transform().y.x, viewport.get_final_transform().y.y,
			viewport.get_final_transform().origin.x, viewport.get_final_transform().origin.y],
		"labels": labels, "buttons": controls, "scrolls": scrolls,
		"scroll_clipped_labels": offscreen_scroll_labels, "errors": errors,
		"focus": str(root.get_path_to(focus)) if focus != null and root.is_ancestor_of(focus) else "outside-or-none",
		"scope": "geometry and accessibility metadata only; visual review and content provenance are separate"}
