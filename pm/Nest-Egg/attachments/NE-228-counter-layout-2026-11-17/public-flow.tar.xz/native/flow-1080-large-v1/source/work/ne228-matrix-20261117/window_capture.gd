extends RefCounted
## Actual desktop pixels of the complete native client window, including KEEP
## letterboxing. No padding, scaling, sRGB conversion or image reconstruction.

static func image(window: Window) -> Image:
	var desktop := DisplayServer.screen_get_image(window.current_screen)
	if desktop == null or desktop.is_empty(): return null
	var native_size := DisplayServer.window_get_size(window.get_window_id())
	if native_size != window.size: return null
	var origin := DisplayServer.window_get_position(window.get_window_id()) - DisplayServer.screen_get_position(window.current_screen)
	var region := Rect2i(origin, native_size)
	if not Rect2i(Vector2i.ZERO, desktop.get_size()).encloses(region): return null
	return desktop.get_region(region)
