"""Derived review contacts only. Original native PNGs remain untouched."""
import hashlib
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

BASE = Path("D:/NestEggVerification/evidence-20261117/ne228-matrix")
OUT = Path(__file__).resolve().parent / "review"
OUT.mkdir(exist_ok=True)
font = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 16)
for folder in sorted([*BASE.glob("final-*-v6"), *BASE.glob("supplemental-*-v6")]):
    if not (folder / "exit.json").exists(): continue
    receipt = json.loads((folder / "exit.json").read_text(encoding="utf8"))
    if not receipt["strict_clean"]: continue
    report = json.loads((folder / "matrix.json").read_text(encoding="utf8"))
    groups = {"menus": [], "navigation": [], "inventory": [], "world": [], "outcomes": []}
    for row in report["records"]:
        page = row["page"]
        group = "navigation" if page.startswith(("pause/", "quest/")) else "inventory" if page.startswith(("inventory/", "shop/")) else "world" if page.startswith("world/") else "outcomes" if page.startswith(("flow/", "recovery/")) or page == "codex/replay-list" else "menus"
        groups[group].append(row)
    records = {}
    for group, rows in groups.items():
        target = OUT / (folder.name + "-" + group + "-review.png")
        if target.exists(): continue
        columns = 3 if group in ["menus", "inventory"] else 2
        tile = 426 if columns == 3 else 640
        height = round(tile * 9 / 16)
        sheet = Image.new("RGB", (columns * tile, ((len(rows) + columns - 1) // columns) * (height + 25)), "#141b24")
        draw = ImageDraw.Draw(sheet)
        for index, row in enumerate(rows):
            x = index % columns * tile
            y = index // columns * (height + 25)
            draw.text((x + 5, y + 3), row["page"], font=font, fill="white")
            with Image.open(folder / row["file"]) as original:
                sheet.paste(original.convert("RGB").resize((tile, height), Image.Resampling.LANCZOS), (x, y + 25))
        sheet.save(target)
        records[target.name] = {"scope": "resized derived contact for review, never raw native capture or pixel measurement", "pages": [row["page"] for row in rows], "original_sha256": {row["file"]: row["png_sha256"] for row in rows}, "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}
    if records:
        (OUT / (folder.name + ".json")).write_text(json.dumps(records, indent=2), encoding="utf8")
