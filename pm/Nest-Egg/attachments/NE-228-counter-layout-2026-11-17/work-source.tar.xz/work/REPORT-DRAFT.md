# NE-228：當舖標題與可閱讀詳情

本輪的產品修正只有背包／商店共用畫面及詳情面板兩份：標題與分頁依真文字尺寸分開；長詳情可在有界區域閱讀，原確認動作固定在頁尾上方。全文、價錢、字級、交易與保存規則保留。另兩份永久測試來源為既有UI套件的一個hook與短helper。

## 已有有效紀錄

- 真磁碟原版、舊helper：原UiScreensSuite 513項／3失敗，無SCRIPT ERROR。原生相同v4工具42狀態／8失敗：四個商店標題相交、典當及贖回的詳情與動作各越界。原始失敗不刪除。
- 第一版候選517／1的幾何失敗在第10格：頁面仍有3.8724單位滑動；action下緣284.1、footer上緣304.4並未相交。觀察沒有改輸入／8格等待／幾何判定。正常動畫保留，永久純版面helper保存並開啟減少動態，動畫由原生矩陣另驗。
- runtime reload原基類的負控制無效：ShopScreen仍持有舊member布局，出現null SCRIPT ERROR，雖engine exit0／0 checks仍明確拒收。正式原版須使用乾淨原來源的引擎程序。
- 最終UiScreens＋Collectibles原scene 825／0，自然exit0，六份指定源before/after相同；保留缺角色的預期容錯ERROR。原內文高度比較仍量原始_content，而非有界viewport，沒有放寬原翻譯契約。
- 原未修改的controller-capture CLI在720p／100%及1080p／120%各38／0，自然exit0／來源保持／無診斷；真Main、難度、真序章、背包、暫停、任務／兩地圖、設定綁定與取消、返回遊戲。是公開合成device999輸入，不是實體手把、自然戰鬥或章節通關。

## 必須保留的舊工具假陽性

- v1五配置各42狀態及舊reader曾報210/210；world/bubble其實是NPC頭上的未交談『…』，沒有MapBubbles正文。後續同raw被真正正文gate拒絕。
- v2 Story.play回true，但宿主當格仍是先前招呼、正文rect為0，新gate真正拒絕。v3改用正式Rin短句在清楚位置取景；記真宿主、場景、原文、alpha、字型、paragraph、rect及相同draw/post_draw frame。
- v3／v5五配置有區域地圖『尚未載入區域』：舊工具duplicate LevelData後resource_path為空，Level因此無法登記目前地圖。不能把這些地圖當正式內容驗收，也不能以engine exit0代稱整210格有效。
- v6改直接load未修改正式LevelData，沿原Story.auto_skip跑真正入口，沒有手填current path／探索。首組取得一致的data/current/player/canvas path、110實際探索格、真地形貼圖及玩家marker；其他配置以各自原始收據為準。

## 範圍

矩陣為正式元件與原資料的安排後版面，不是逐章自然取得：餘額／醫療針／P17持有、回顧解鎖、死亡及結算、復原提示與單獨選項都明列fixture；選項不套用結果。空的完成任務／回顧與尚未解鎖卡片是合法狀態。五配置是標準平滑字型的720普通、720放大減動態、1080普通、1080放大及超寬放大減動態。要求值、Settings有效值、真FontFile資源、實際Label／Button字級、活動viewport與外窗尺寸分開觀察；整數字級不能假稱精確倍率。

原生PNG保持bytes。contact為另外縮小排版的review衍生圖，不能代替原圖或像素量測。寬視窗的活動viewport與包含黑邊的desktop client capture分開記錄；外部OS遮擋未核實的完整桌面圖不作無遮擋驗收。來源守衛範圍是記錄的程式／data／字型及私有producer，不冒稱所有未列入的美術貼圖都另做了來源守衛。

票的實體裝置、全自然流程與其他未完成條件不由本次局部修正或版面樣本代勾。
