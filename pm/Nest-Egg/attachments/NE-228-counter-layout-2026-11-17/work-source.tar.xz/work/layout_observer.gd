extends "res://tests/smoke_test.gd"
## Failure-only geometry observation. Original helper input, frames and gates stay intact.

func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	if OS.get_cmdline_user_args().has("--original"):
		for path: String in ["ui/inventory/detail_panel.gd", "ui/inventory/inventory_screen.gd"]:
			var script := load("res://" + path) as GDScript
			var original := FileAccess.get_file_as_string("res://work/ne228-matrix-20261117/before-product/" + path)
			assert(not original.is_empty())
			script.source_code = original
			assert(script.reload() == OK)
			print("NE228_RUNTIME_ORIGINAL ", path, " ", script.source_code.sha256_text())
	await preload("res://tests/helpers/inventory_layout_checks.gd").run(UiScreensSuite.new(self))
	await _finish()


func _check(condition: bool, message: String) -> void:
	if not condition and message == "large real pawn detail and action stay above the inventory footer":
		for node in get_tree().get_nodes_in_group(ShopScreen.OVERLAY_GROUP):
			if node is ShopScreen:
				var page := node._pages[node._current] as PawnPage
				print("NE228_LAYOUT_OBSERVATION ", JSON.stringify({"frame": Engine.get_process_frames(), "scale": str(node._frame.scale),
					"host": str(node._page_host.get_global_rect()), "detail": str(page._detail.get_global_rect()),
					"action": str(page._detail._action.get_global_rect()), "footer": str(node._legend_label.get_global_rect())}))
	super._check(condition, message)
