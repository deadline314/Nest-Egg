"""Run the same existing UI suite before/after the two layout sources."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path("D:/NestEggVerification/evidence-20261117/ne228-matrix") / sys.argv[1]
assert not OUT.exists()
OUT.mkdir(parents=True)
names = ["ui/inventory/inventory_screen.gd", "ui/inventory/detail_panel.gd", "tests/suite/test_ui_screens.gd",
         "tests/helpers/inventory_layout_checks.gd", "tests/smoke_test.gd", "tools/test_filters.sh"]
def hashes(): return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names}
before = hashes()
for name in names:
    target = OUT / "source" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
command = ["C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(ROOT),
           "--headless", "res://tests/smoke_test.tscn", "--", "--only=" + (sys.argv[2] if len(sys.argv) > 2 else "UiScreensSuite")]
with (OUT / "console.log").open("wb") as log:
    result = subprocess.run(command, cwd=ROOT, env=dict(os.environ, APPDATA=str(OUT / "profile"), LOCALAPPDATA=str(OUT / "profile")), stdout=log, stderr=subprocess.STDOUT)
after = hashes()
text = (OUT / "console.log").read_text(encoding="utf8")
receipt = {"command": command, "exit": result.returncode, "source_before": before, "source_after": after,
           "source_unchanged": before == after, "script_error": "SCRIPT ERROR" in text}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf8")
print(json.dumps({k: v for k, v in receipt.items() if not k.startswith("source_")}), flush=True)
sys.exit(result.returncode if before == after else 1)
