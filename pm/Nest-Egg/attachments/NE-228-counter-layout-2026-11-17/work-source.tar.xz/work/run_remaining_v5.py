import subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
cases=[('final-720-reduced-v5',1280,720,1.2,True),('final-1080-normal-v5',1920,1080,1.0,False),('final-1080-large-v5',1920,1080,1.2,False),('final-wide-reduced-v5',2560,1080,1.2,True)]
for tag,width,height,scale,reduced in cases:
 command=[sys.executable,'-B',str(Path(__file__).with_name('run_native.py')),tag,f'--width={width}',f'--height={height}',f'--text-scale={scale}','--phase=all']
 if reduced:command.append('--reduce-motion')
 print('BEGIN '+tag,flush=True)
 result=subprocess.run(command,cwd=root)
 if result.returncode:sys.exit(result.returncode)
 print('END '+tag,flush=True)
