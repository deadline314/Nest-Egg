"""Cold published baseline + new tests, then the original affected selector with four frozen files."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
WT = Path("D:/NestEggVerification/camera-20261117")
OUT = Path("D:/NestEggVerification/evidence-20261117/ne228/official-6e47")
BASE = "6e47e2fe5e32ee3f13583bf7d59ae79953b65a85"
GODOT = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
phase = sys.argv[1]
assert phase in ["baseline", "candidate"]
frozen = json.loads((WORK / "freeze-product-v2.json").read_text(encoding="utf8"))
products = [name for name in frozen if name.startswith("ui/")]
tests = [name for name in frozen if name.startswith("tests/")]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(["git", *args], cwd=WT).decode("utf8")
def private_hashes(names): return {name: sha(WT / name) for name in names}
assert git("rev-parse", "HEAD").strip() == BASE
for name, digest in frozen.items():
    assert sha(WORK / "freeze-product-v2" / name) == digest == sha(ROOT / name)
if phase == "baseline":
    assert not OUT.exists()
    assert not git("diff", "--name-only") and not git("diff", "--cached", "--name-only")
    status = git("status", "--porcelain=v1", "--untracked-files=all")
    private = [line[3:] for line in status.splitlines() if line.startswith("??")]
    assert len(private) == 16 and all(name.startswith(("work/ne256-", "work/ne266-")) for name in private)
    before_products = {name: sha(WT / name) for name in products}
    expected = json.loads((WORK / "before-product/hashes.json").read_text(encoding="utf8"))
    assert all(before_products[name] == expected[name] for name in products)
    OUT.mkdir(parents=True)
    preparation = {"base": BASE, "worktree": str(WT), "original_status": status,
        "private_files": private_hashes(private), "baseline_products": before_products,
        "candidate": frozen, "policy": "no branch/index/stash operations; preserve all original private files"}
    (OUT / "preparation.json").write_text(json.dumps(preparation, indent=2), encoding="utf8")
    copied = tests
else:
    preparation = json.loads((OUT / "preparation.json").read_text(encoding="utf8"))
    baseline = json.loads((OUT / "baseline/receipt.json").read_text(encoding="utf8"))
    assert baseline["valid_expected_red"] and baseline["source_unchanged"]
    assert all(sha(WT / name) == digest for name, digest in preparation["baseline_products"].items())
    copied = list(frozen)
assert private_hashes(preparation["private_files"]) == preparation["private_files"]
for name in copied:
    target = WT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((WORK / "freeze-product-v2" / name).read_bytes())
dest = OUT / phase
assert not dest.exists()
dest.mkdir()
def discover():
    names = git("ls-files", "-co", "--exclude-standard", "-z").split("\0")
    exclude = ("pm/", "design/", "work/", ".agents/", ".claude/", ".github/", "docs/")
    return sorted({name for name in names if name and not name.startswith(exclude) and (WT / name).is_file()})
def sources(): return {name: {"size": (WT / name).stat().st_size, "sha256": sha(WT / name)} for name in discover()}
before = sources()
(dest / "source-before.json").write_text(json.dumps(before, indent=2), encoding="utf8")
for name in list(frozen) + ["tools/run_tests_changed.sh", "tools/run_tests_parallel.sh", "tools/select_tests.py", "tools/test_filters.sh", "tests/known_failures.txt"]:
    target = dest / "source" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((WT / name).read_bytes())
(dest / "caller.py").write_bytes(Path(__file__).read_bytes())
env = os.environ.copy()
if phase == "baseline":
    command = [GODOT, "--path", str(WT), "--headless", "res://tests/smoke_test.tscn", "--", "--only=UiScreensSuite"]
    env.update(APPDATA=str(dest / "profile"), LOCALAPPDATA=str(dest / "profile"))
else:
    script = dest / "run.sh"
    py = Path(sys.executable).as_posix()
    script.write_text("#!/usr/bin/env bash\nset -uo pipefail\ncd /d/NestEggVerification/camera-20261117\n"
        + "python3() { '" + py + "' \"$@\"; }\nexport -f python3\n"
        + "export GODOT='" + GODOT + "'\nexport SHARDS=2\nexport PYTHONIOENCODING=utf-8\n"
        + "export LOG_DIR='" + (dest / "shards").as_posix() + "'\nmkdir -p \"$LOG_DIR\"\n"
        + "tools/run_tests_changed.sh " + BASE + "\n", encoding="utf8", newline="\n")
    command = ["C:/Program Files/Git/bin/bash.exe", "--noprofile", "--norc", str(script)]
(dest / "command.json").write_text(json.dumps({"command": command, "base": BASE,
    "profile_policy": "fresh isolated baseline profile or original parallel runner per-shard profiles"}, indent=2), encoding="utf8")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (dest / "console.log").open("wb") as log:
    result = subprocess.run(command, cwd=WT, env=env, stdout=log, stderr=subprocess.STDOUT)
after = sources()
(dest / "source-after.json").write_text(json.dumps(after, indent=2), encoding="utf8")
text = (dest / "console.log").read_text(encoding="utf8")
failures = re.findall(r"^FAIL: (.+)$", text, re.M)
expected_failures = {"large real counter title does not overlap its tab row",
    "large real pawn detail and action stay above the inventory footer", "long pawn details expose one bounded reading region"}
valid_red = phase == "baseline" and result.returncode == 1 and set(failures) == expected_failures and len(failures) == 3 and "checks: 513, failures: 3" in text and "SCRIPT ERROR" not in text
private_after = private_hashes(preparation["private_files"])
receipt = {"command": command, "base": BASE, "phase": phase, "exit_code": result.returncode,
    "valid_expected_red": valid_red, "source_unchanged": before == after, "source_files": len(before),
    "private_before": preparation["private_files"], "private_after": private_after,
    "private_unchanged": private_after == preparation["private_files"],
    "started_utc": started, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "script_error": "SCRIPT ERROR" in text, "status_after": git("status", "--porcelain=v1", "--untracked-files=all"),
    "source_scope": "all tracked/nonignored runtime/tool/test/assets except pm/design/work/instructions/CI/docs; original private work files separately held"}
(dest / "receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf8")
print(json.dumps({k: v for k, v in receipt.items() if k not in ["private_before", "private_after", "status_after"]}), flush=True)
assert before == after and receipt["private_unchanged"]
sys.exit(0 if valid_red or (phase == "candidate" and result.returncode == 0) else 1)
