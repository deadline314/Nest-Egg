#!/usr/bin/env bash
set -uo pipefail
cd /d/NestEggVerification/camera-20261117
python3() { 'C:/Users/stanl/AppData/Local/Programs/Python/Python313/python.exe' "$@"; }
export -f python3
export GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
export SHARDS=2
export PYTHONIOENCODING=utf-8
export LOG_DIR='D:/NestEggVerification/evidence-20261117/ne228/official-6e47/candidate/shards'
mkdir -p "$LOG_DIR"
tools/run_tests_changed.sh 6e47e2fe5e32ee3f13583bf7d59ae79953b65a85
