"""Run the relocated existing page producer with isolated profile and raw source receipts."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
tag = sys.argv[1]
assert re.fullmatch(r"[a-z0-9-]+", tag)
OUT = Path("D:/NestEggVerification/evidence-20261117/ne228-matrix") / tag
assert not OUT.exists()
OUT.mkdir(parents=True)
paths = {"project.godot", "tools/viewport_capture.gd", "tools/world_pause_sample.gd"}
for folder in ["ui", "autoload", "core", "game", "data", "art/fonts"]:
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT / folder).rglob("*")
                 if p.is_file() and p.suffix in [".gd", ".gdshader", ".json", ".tres", ".ttf"])
for name in ["probe.gd", "probe.tscn", "geometry_audit.gd", "window_capture.gd"]:
    paths.add((WORK / name).relative_to(ROOT).as_posix())
def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sorted(paths)}
before = hashes()
for name in before:
    target = OUT / "source" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / name).read_bytes())
(OUT / "source-before.json").write_text(json.dumps(before, indent=2), encoding="utf8")
(OUT / "runner.py").write_bytes(Path(__file__).read_bytes())
profile = OUT / "profile"
overrides = {"APPDATA": str(profile), "LOCALAPPDATA": str(profile / "local"),
             "NE228_PROFILE_ROOT": str(profile), "PYTHONIOENCODING": "utf-8"}
command = [sys.executable, "-B", str(ROOT / "tools/comfyui/gpu_lock.py"), "--",
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(ROOT),
    "--rendering-method", "forward_plus", "--rendering-driver", "vulkan",
    "res://work/ne228-matrix-20261117/probe.tscn", "--", "--out=" + str(OUT), *sys.argv[2:]]
(OUT / "command.json").write_text(json.dumps({"command": command, "environment_overrides": overrides}, indent=2), encoding="utf8")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUT / "run.log").open("wb") as log:
    result = subprocess.run(command, cwd=ROOT, env=dict(os.environ, **overrides), stdout=log, stderr=subprocess.STDOUT)
after = hashes()
log = (OUT / "run.log").read_text(encoding="utf8")
diagnostics = [line for line in log.splitlines() if re.search(r"SCRIPT ERROR|^ERROR:|ObjectDB instances were leaked|resources still in use|RID allocations", line)]
receipt = {"exit": result.returncode, "sources_unchanged": before == after, "source_after": after,
           "strict_clean": result.returncode == 0 and before == after and not diagnostics, "diagnostics": diagnostics,
           "started_utc": started, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "scope": "production page layout fixture; not performance, physical device or natural campaign completion"}
(OUT / "exit.json").write_text(json.dumps(receipt, indent=2), encoding="utf8")
print(json.dumps({k: v for k, v in receipt.items() if k != "source_after"}), flush=True)
sys.exit(0 if receipt["strict_clean"] else 1)
