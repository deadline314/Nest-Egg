extends Node
var out := ""
var checks := 0
var failures := 0
var level: Level
var width := 1280
var height := 720
var level_id := "pawnshop"
var scale := 1.2
func _ready() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with('--out='): out=arg.trim_prefix('--out=')
  elif arg.begins_with('--width='): width=int(arg.trim_prefix('--width='))
  elif arg.begins_with('--height='): height=int(arg.trim_prefix('--height='))
  elif arg.begins_with('--level='): level_id=arg.trim_prefix('--level=')
  elif arg.begins_with('--text-scale='): scale=float(arg.trim_prefix('--text-scale='))
 get_window().size=Vector2i(width,height)
 DisplayMode.ensure_scaling(get_window())
 DirAccess.make_dir_recursive_absolute(out)
 run.call_deferred()
func frames(n: int) -> void:
 for i in n: await get_tree().process_frame
func check(ok: bool,message: String) -> void:
 checks+=1
 print('PASS: ' if ok else 'FAIL: ',message)
 if not ok:failures+=1
func press(action: StringName) -> void:
 var event:=InputEventAction.new()
 event.action=action;event.pressed=true
 Input.parse_input_event(event)
 await frames(2)
 event=InputEventAction.new()
 event.action=action;event.pressed=false
 Input.parse_input_event(event)
 await frames(2)
func shot(name: String) -> void:
 await RenderingServer.frame_post_draw
 var err:=preload('res://tools/viewport_capture.gd').image(get_viewport()).save_png(out.path_join(name+'.png'))
 check(err==OK,'capture '+name)
func menu_button(text: String) -> Button:
 for child in level._pause_menu._menu_panel.body.get_children():
  if child is Button and child.text==text:return child
 return null
func run() -> void:
 Settings.use_storage('user://ne228-pause-probe.cfg')
 Settings.set_ui_text_scale(scale)
 Settings.set_reduce_ui_motion(false)
 Settings.set_hud_auto_hide(false)
 Story.set_language('en')
 Story.auto_skip=true
 GameState.start_new_run(GameState.difficulties[1])
 for flag in ['ch1_prologue_exit','ch1_dinner_done','ch1_heard_brief']:GameState.set_flag(StringName(flag),true,false)
 Story.outcomes.refresh_derived()
 add_child(LightKit.create_environment())
 level=Level.new()
 level.configure(load('res://data/levels/ch1_'+level_id+'.tres'))
 add_child(level)
 await frames(20)
 Story.reset_active_presentation(&'capture_setup')
 if level_id=='pawnshop':
  level.player.global_position=Vector2(60.5*16,320)
  level.camera.snap_to_target();level._lighting.snap();level.camera.force_update_scroll()
 level.hud.quest_guidance._refresh_target()
 await frames(4)
 await shot('world')
 var pause:=level._pause_menu
 await press(&'pause')
 check(get_tree().paused and pause._root.visible and pause._resume_button.has_focus(),'public pause input opens with resume focus')
 await get_tree().create_timer(0.3,true,false,true).timeout
 await shot('pause')
 var rounds := level.player.loadout.mag_in(level.player.loadout.active_slot)
 var click := InputEventMouseButton.new()
 click.position=Vector2(626,330);click.global_position=click.position
 click.button_index=MOUSE_BUTTON_LEFT;click.pressed=true
 get_viewport().push_input(click,true)
 await frames(2)
 click=InputEventMouseButton.new()
 click.position=Vector2(626,330);click.global_position=click.position
 click.button_index=MOUSE_BUTTON_LEFT;click.pressed=false
 get_viewport().push_input(click,true)
 await frames(2)
 check(get_tree().paused and pause._root.visible and level.player.loadout.mag_in(level.player.loadout.active_slot)==rounds,'blank modal click cannot shoot or resume the frozen world')
 # Paired visual diagnostic changes only underlay visibility, never text or flags.
 var row: Control=level.hud.quest_guidance._row
 var row_was_visible:=row.visible
 row.visible=false
 await frames(2)
 await shot('pause-no-goal-control')
 row.visible=row_was_visible
 await press(&'ui_down');await press(&'ui_down');await press(&'ui_down')
 check(menu_button('設定').has_focus(),'public navigation reaches settings')
 await press(&'ui_accept')
 check(is_instance_valid(pause._settings) and pause._settings.is_ancestor_of(get_viewport().gui_get_focus_owner()),'settings receives focus over pause')
 await shot('settings')
 await press(&'ui_cancel')
 check(not is_instance_valid(pause._settings) and menu_button('設定').has_focus(),'closing settings restores its original pause button')
 await shot('pause-returned')
 await press(&'ui_up');await press(&'ui_up');await press(&'ui_accept')
 check(is_instance_valid(pause._navigation) and pause._navigation._page=='quests','public input opens real quest page above pause')
 await shot('nested-quests')
 await press(&'ui_cancel')
 check(not is_instance_valid(pause._navigation) and pause._quest_button.has_focus(),'back from quests restores pause focus')
 await press(&'ui_down');await press(&'ui_down');await press(&'ui_down');await press(&'ui_accept')
 check(is_instance_valid(pause._codex),'public input opens the real codex')
 await shot('codex')
 await press(&'ui_cancel')
 check(not is_instance_valid(pause._codex) and menu_button('圖鑑').has_focus(),'back from codex restores pause focus')
 await press(&'ui_cancel')
 check(not get_tree().paused and not pause._root.visible,'public back closes pause and resumes the same world')
 await shot('resumed')
 Settings.set_reduce_ui_motion(true)
 await press(&'pause')
 check(get_tree().paused and pause._resume_button.has_focus() and pause._menu_panel.modulate.a==1.0,'reduced motion opens directly with working focus')
 await shot('pause-reduced-motion')
 await press(&'ui_cancel')
 check(not get_tree().paused and not pause._root.visible,'reduced motion closes without leaving an overlay')
 var f:=FileAccess.open(out.path_join('result.json'),FileAccess.WRITE)
 f.store_string(JSON.stringify({'checks':checks,'failures':failures,'resolution':[width,height],'text_scale':scale,'level':level_id,'state_fixture':true,'full_playthrough':false,'pause_source':FileAccess.get_sha256('res://ui/pause_menu.gd'),'renderer':RenderingServer.get_current_rendering_method()},' '));f.close()
 remove_child(level);level.free()
 await frames(4)
 await get_tree().create_timer(0.2,true,false,true).timeout
 Sfx.stop_all();Music.stop(0);Ambience.stop_all(0)
 await get_tree().create_timer(0.2,true,false,true).timeout
 print('checks: ',checks,', failures: ',failures)
 get_tree().quit(0 if failures==0 else 1)
