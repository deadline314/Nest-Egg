from pathlib import Path
import subprocess,os,json
out=Path('work/ne228-pause');env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen'
cases=[('pawnshop',1280,720,1.2),('warehouse',1280,720,1.0),('pawnshop',1920,1080,1.0),('warehouse',1920,1080,1.2)]
results=[]
for level,w,h,scale in cases:
 name=f'ne228-1022-modal-{level}-{w}'
 args=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/ne228-pause/probe.tscn',f'--level={level}',f'--width={w}',f'--height={h}',f'--text-scale={scale}']
 with (out/(name+'-wrapper.log')).open('w') as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=360)
 results.append({'name':name,'args':args,'exit_code':r.returncode});(out/'matrix-receipt.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
assert all(x['exit_code']==0 for x in results)
