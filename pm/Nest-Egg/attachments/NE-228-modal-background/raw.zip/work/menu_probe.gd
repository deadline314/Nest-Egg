extends "res://work/ne228-pause/probe.gd"
func run() -> void:
 Settings.use_storage('user://ne228-codex-menu-probe.cfg')
 Settings.set_ui_text_scale(1.2)
 Settings.set_reduce_ui_motion(true)
 var menu:=MainMenu.new()
 add_child(menu)
 await frames(4)
 var target: Button
 for child in menu.find_children('*','Button',true,false):
  if child.text=='圖鑑':target=child
 check(target!=null,'actual main menu provides its codex button')
 if target!=null:
  target.grab_focus()
  await press(&'ui_accept')
  var pages:=menu._ui.get_children().filter(func(child: Node) -> bool:return child is CodexScreen)
  check(pages.size()==1 and pages[0].is_visible_in_tree(),'real confirmation opens codex from main menu')
  await shot('codex-from-main-menu')
  await press(&'ui_cancel')
  check(menu._main_page.visible and target.has_focus(),'back restores the original main menu and focus')
  await shot('main-menu-returned')
 remove_child(menu);menu.free()
 await frames(4)
 Sfx.stop_all();Music.stop(0);Ambience.stop_all(0)
 await get_tree().create_timer(0.3,true,false,true).timeout
 var f:=FileAccess.open(out.path_join('result.json'),FileAccess.WRITE)
 f.store_string(JSON.stringify({'checks':checks,'failures':failures,'entry':'main_menu','renderer':RenderingServer.get_current_rendering_method(),'codex_source':FileAccess.get_sha256('res://ui/codex_screen.gd')},' '));f.close()
 print('checks: ',checks,', failures: ',failures)
 get_tree().quit(0 if failures==0 else 1)
