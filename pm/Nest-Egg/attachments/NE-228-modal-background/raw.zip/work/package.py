from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil
root=Path.cwd();scratch=root/'work/ne228-pause';native=Path('/workspace/Nest-Egg/work/batch1020b');out=root/'pm/Nest-Egg/attachments/NE-228-modal-background';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
frozen=json.loads((scratch/'frozen-source.json').read_text());assert all(sha((root/p).read_bytes())==h for p,h in frozen.items())
assert 'checks: 6911, new failures: 0, known failures (tests/known_failures.txt): 0' in (scratch/'changed.log').read_text()
files={}
for p in scratch.rglob('*'):
 if p.is_file() and not any('profile' in part or part.startswith('data_') for part in p.relative_to(scratch).parts):files['work/'+str(p.relative_to(scratch))]=p.read_bytes()
for p in native.glob('ne228-1022-*'):
 if p.is_dir() and not p.name.endswith('-profile'):
  for f in p.iterdir():
   if f.is_file():files['native/'+p.name+'/'+f.name]=f.read_bytes()
 elif p.is_file() and p.suffix in ['.log','.exit']:files['native/'+p.name]=p.read_bytes()
for p in frozen:
 files['source/final/'+p]=(root/p).read_bytes()
 files['source/before/'+p]=subprocess.check_output(['git','show','54b05d17:'+p])
files['source/unchanged/ui/kit/scene_backdrop.gd']=(root/'ui/kit/scene_backdrop.gd').read_bytes()
assert files['source/unchanged/ui/kit/scene_backdrop.gd']==subprocess.check_output(['git','show','54b05d17:ui/kit/scene_backdrop.gd'])
validation={'base':'54b05d17f3fa527a93c6d0e3f65e8323ab4cad8a','changed_groups':18,'checks':6911,'new_failures':0,'known_failures':0,'seconds':215,'native_final_checks':89,'native_final_failures':0,'native_final_engine_errors':0,'renderer':'forward_plus','device':'llvmpipe','pause_cases':4,'pause_resolutions':[[1280,720],[1920,1080]],'text_scales':[1.0,1.2],'levels':['ch1_pawnshop','ch1_warehouse'],'main_menu_entry_checked':True,'source':frozen,'previous_ne223_full_ci':{'run_id':39737383458,'checks':95951,'new_failures':0,'known_failures':0,'seconds':620},'current_commit_full_ci':'Captured before push; workflow runs after the commit.'}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
manifest={'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for e in manifest['files']:assert sha(z.read(e['path']))==e['sha256']
manifest.update(archive_sha256=sha((out/'raw.zip').read_bytes()),archive_bytes=(out/'raw.zip').stat().st_size)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for src,dst in [('ne228-1022-pause-before/pause.png','NE-228-modal-pause-before.png'),('ne228-1022-pause-before/codex.png','NE-228-modal-codex-before.png'),('ne228-1022-modal-pawnshop-1280/pause.png','NE-228-modal-pause-after.png'),('ne228-1022-modal-pawnshop-1280/codex.png','NE-228-modal-codex-after.png'),('ne228-1022-modal-warehouse-1920/pause.png','NE-228-modal-pause-dark-1080.png'),('ne228-1022-modal-warehouse-1920/nested-quests.png','NE-228-modal-nested-quest.png'),('ne228-1022-main-codex/codex-from-main-menu.png','NE-228-modal-main-codex.png')]:shutil.copy2(native/src,root/'pm/Nest-Egg/images'/dst)
print(json.dumps({'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256']},indent=2))
