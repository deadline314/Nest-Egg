from pathlib import Path
from hashlib import sha256
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
label = sys.argv[1]
folder = base / label
folder.mkdir()
(folder / "series").mkdir()
profile = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    child = folder / key
    child.mkdir()
    profile[key] = str(child)
godot = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
root = Path.cwd()
motion = [root / "art/motion" / f"{name}.json" for name in ("guest_zheng", "guest_chen", "guest_hong")]
motion.extend(root / path for path in ("data/story/ch2_heron.json", "data/cutscene/stages/ch2_guest_book_room.json"))
source = {str(path.relative_to(root)): sha256(path.read_bytes()).hexdigest() for path in motion}
parent = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
with (folder / "engine.log").open("wb") as log:
    command = [sys.executable, "-B", str(root / "tools/comfyui/gpu_lock.py"), "--", godot, "--path", str(root),
               "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--fixed-fps", "60",
               "--audio-driver", "Dummy", "--resolution", "1280x720", "--quit-after", "6800", str(base / "stage-walk.tscn"),
               "--", f"--out={folder}"]
    if "--series" in sys.argv:
        command.append("--series")
    if "--crop-series" in sys.argv:
        command.append("--crop-series")
    if "--crop-release-series" in sys.argv:
        command.append("--crop-release-series")
    if "--wide-release-series" in sys.argv:
        command.append("--wide-release-series")
    (folder / "command.json").write_text(json.dumps({"command": command, "head": parent, "sources": source}, indent=2) + "\n", encoding="utf-8")
    result = subprocess.run(command, env=profile, stdout=log, stderr=subprocess.STDOUT, timeout=400 if "--series" in sys.argv else 230)
raw = (folder / "engine.log").read_text(encoding="utf-8", errors="replace")
print(raw[-8000:])
assert result.returncode == 0 and not re.search(r"^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit",raw,re.M)
assert (folder / "stage-walk.json").is_file()
assert source == {str(path.relative_to(root)): sha256(path.read_bytes()).hexdigest() for path in motion}

