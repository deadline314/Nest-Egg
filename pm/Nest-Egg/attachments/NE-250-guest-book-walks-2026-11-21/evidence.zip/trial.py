from pathlib import Path
import subprocess
import sys

base = Path(__file__).resolve().parent
root = Path.cwd()
if "--series" in sys.argv:
    import time
    published = base.parent / "evidence-20261121-ne277-body-flash/publish/result.json"
    deadline = time.monotonic() + 900.0
    while not published.is_file() and time.monotonic() < deadline:
        time.sleep(3.0)
    assert published.is_file(), "must preserve the current scoped commit until publication"
files = [root / "art/motion" / f"{actor}.json" for actor in ("guest_zheng", "guest_chen", "guest_hong")]
original = {path: path.read_bytes() for path in files}
needle = b'  "move": {'
assert all(data.count(needle) == 1 and b'"grounding"' not in data for data in original.values())

try:
    for path, data in original.items():
        line_end = b"\r\n" if b"\r\n" in data else b"\n"
        candidate = data.replace(needle, needle + line_end + b'    "grounding": true,', 1)
        if "--slow" in sys.argv:
            threshold = b'"threshold": 0.08,'
            assert candidate.count(threshold) == 1
            candidate = candidate.replace(threshold, b'"threshold": 0.07,')
        if "--short" in sys.argv:
            assert b'"stride_exp"' not in candidate and b'"stride_floor"' not in candidate
            marker = b'"threshold": 0.07,'
            assert candidate.count(marker) == 1
            candidate = candidate.replace(marker, marker + line_end + b'    "stride_exp": 0.5,' + line_end + b'    "stride_floor": 0.4,')
        path.write_bytes(candidate)
    subprocess.run([sys.executable, "-B", str(base / "run.py"), sys.argv[1]] + (["--series", "--crop-series"] if "--series" in sys.argv else []), cwd=root, check=True)
finally:
    for path, data in original.items():
        path.write_bytes(data)
    assert all(path.read_bytes() == data for path, data in original.items())
