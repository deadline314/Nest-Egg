from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

scope = Path(__file__).resolve().parent
project = Path.cwd()
pose = sys.argv[1]
assert pose in ('walk', 'crouch', 'lean', 'stand', 'sit', 'sit_talk', 'sit_listen', 'wave')
run = scope / ('review-' + pose + (sys.argv[2] if len(sys.argv) > 2 else ''))
run.mkdir()
native = run / 'frames'
native.mkdir()
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP', 'TMPDIR', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME'):
    path = run / key
    path.mkdir()
    env[key] = str(path)
files = ['game/rig/npc_animator.gd', 'game/rig/humanoid_animator.gd', 'tools/rig_joint_audit.gd']
for actor in ('guest_zheng','guest_chen','guest_hong'):
    files.extend([f'art/rigs/{actor}.json', f'art/motion/{actor}.json'])
    files.extend(path.relative_to(project).as_posix() for path in sorted((project / f'art/characters/{actor}/parts').glob('*.png')))
fingerprints = lambda: {name: sha256((project / name).read_bytes()).hexdigest() for name in files}
digest = fingerprints()
command = [sys.executable, '-B', str(project / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(project),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--quit-after', '900', str(scope / 'audit.tscn'), '--', '--out=' + str(native),
           '--chars=guest_zheng,guest_chen,guest_hong', '--frames=60', '--zooms=1,3.7', '--npc-performance', '--npc-pose=' + pose]
meta = {'command': command, 'inputs': digest, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()}
(run / 'command.json').write_text(json.dumps(meta, indent=2) + '\n', encoding='utf-8')
with (run / 'engine.log').open('wb') as log:
    capture = subprocess.run(command, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=420)
native_log = (run / 'engine.log').read_text(encoding='utf-8', errors='replace')
errors = [line for line in native_log.splitlines() if re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit', line)]
assert capture.returncode == 0 and not errors and '9070' in native_log, (capture.returncode, errors)
with (run / 'audit.log').open('wb') as log:
    reviewed = subprocess.run([sys.executable, '-B', str(project / 'tools/check_joint_frames.py'), str(native)],
                              cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
report = json.loads((native / 'report.json').read_bytes())
assert reviewed.returncode in (0, 1) and report['samples'] == 10080 and digest == fingerprints()
def rec(part):
    return {'samples': len(part), 'enclosed': sum(row['enclosed_pixels'] > 0 for row in part),
            'loose': sum(row['loose_pieces'] > 0 for row in part)}
summary = {**rec(report['failures']), 'total': report['samples'], 'audit_exit': reviewed.returncode}
(run / 'result.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(pose, summary, flush=True)
