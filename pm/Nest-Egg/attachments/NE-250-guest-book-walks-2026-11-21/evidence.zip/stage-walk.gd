extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const SCENES := {
	&"ch2_t_s18_ticket": [&"zheng", -1], &"ch2_t_s18_done": [&"zheng", 1],
	&"ch2_t_s19_band": [&"chen", -1], &"ch2_t_s19_done": [&"chen", 1],
	&"ch2_t_s20_letter": [&"hong", -1], &"ch2_t_s20_done": [&"hong", 1],
}
var _out := ""
var _series := false
var _crop_series := Rect2i()
var _rows: Array[Dictionary] = []
var _soles: Array[Dictionary] = []
var _bottom_points := {}


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
		elif arg == "--series": _series = true
		elif arg == "--crop-series": _crop_series = Rect2i(760, 110, 226, 380)
		elif arg == "--crop-release-series": _crop_series = Rect2i(730, 96, 260, 396)
		elif arg == "--wide-release-series": _crop_series = Rect2i(690, 90, 340, 408)
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://npc_stage_walk.cfg")
	var facts := [GameState.world_flags.duplicate(true), Progression.credits, StoryItems.snapshot()]
	for id: StringName in SCENES:
		if not await _play(id, SCENES[id][0], SCENES[id][1]):
			printerr("Original stage could not finish the authored path: ", id)
			get_tree().quit(1)
			return
	if facts != [GameState.world_flags, Progression.credits, StoryItems.snapshot()]:
		printerr("Direct actor preview changed story facts")
		get_tree().quit(1)
		return
	var file := FileAccess.open(_out.path_join("stage-walk.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"adapter": RenderingServer.get_video_adapter_name(),
		"renderer": RenderingServer.get_current_rendering_method(), "hdr": get_viewport().use_hdr_2d,
		"facts_unchanged": true, "rows": _rows, "soles": _soles}, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit()


func _play(id: StringName, actor: StringName, expected_direction: int) -> bool:
	var scene: Dictionary = Story._scenes.get(id, {})
	if scene.get("mode") != "animated" or not CutsceneChecker.staging_problems(str(id), scene).is_empty():
		return false
	var timeline := JSON.stringify(scene["steps"]).sha256_text()
	var player := CutscenePlayer.new()
	add_child(player)
	player.play(id, scene)
	var counts := {-1: 0, 1: 0}
	var start := _rows.size()
	for frame in 1000:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		if not is_instance_valid(player) or not player.is_running() or player.choice_active(): break
		var character := player._actors.get(actor) as CutsceneActor
		if is_instance_valid(character) and character.rig != null and absf(character._input.velocity.x) > 0.001:
			var direction := int(signf(character._input.velocity.x))
			if direction != character.facing or (character.rig.animator as NpcAnimator)._use_npc:
				return false
			counts[direction] += 1
			var surface := character.get_parent() as Node2D
			var left := character.rig.contact_part(&"foot_front")
			var right := character.rig.contact_part(&"foot_back")
			if left == null or right == null or surface == null:
				return false
			_soles.append({"scene": str(id), "direction": direction, "frame": counts[direction],
				"world": [character.position.x, character.position.y], "floor": character.ground_y,
				"stage_grounded": character._input.stage_grounded, "speed": character._input.velocity.x,
				"front": _floor_contact(left, surface), "back": _floor_contact(right, surface),
				"gait": character.rig.animator._gait_on, "weight": character.rig.animator._gait_w})
			var frame_path := "series/%s-%d-%03d.png" % [id, direction, counts[direction]]
			if _series:
				var viewport := get_viewport()
				var frame_image := viewport.get_texture().get_image()
				if _crop_series.has_area():
					frame_image = frame_image.get_region(_crop_series)
				if Capture.encode(frame_image, viewport.use_hdr_2d).save_png(_out.path_join(frame_path)) != OK:
					return false
			if counts[direction] in [2, 5, 11, 20]:
				var key := "%s-%d-%02d" % [id, direction, counts[direction]]
				if Capture.image(get_viewport()).save_png(_out.path_join(key + ".png")) != OK:
					return false
				var joint := character.rig.bone(&"arm_front_upper").global_position
				_rows.append({"key": key, "scene": str(id), "actor": str(actor), "timeline": timeline,
					"direction": direction, "frame": counts[direction], "pose": str(character.pose),
					"position": [character.position.x, character.position.y], "speed": character._input.velocity.x,
					"shoulder": [joint.x, joint.y], "ground": character.ground_y})
		if player._dialogue.visible and frame % 12 == 6:
			var event := InputEventAction.new()
			event.action = &"ui_accept"
			event.pressed = true
			Input.parse_input_event(event)
			event = InputEventAction.new()
			event.action = &"ui_accept"
			Input.parse_input_event(event)
	var settled := not is_instance_valid(player) or not player.is_running() or player.choice_active()
	if is_instance_valid(player):
		player.queue_free()
	await get_tree().process_frame
	print(id, " settled=", settled, " movement=", counts, " captures=", _rows.size() - start)
	return settled and counts[expected_direction] >= 20 and counts[-expected_direction] == 0 and _rows.size() - start == 4


func _floor_contact(part: Sprite2D, stage: Node2D) -> Array:
	var key := part.texture.get_instance_id()
	if not _bottom_points.has(key):
		var image := part.texture.get_image()
		var outline := PackedVector2Array()
		for x in image.get_width():
			for y in range(image.get_height()-1, -1, -1):
				if image.get_pixel(x,y).a >= 0.5:
					outline.append(Vector2(x+0.5,y+0.5))
					break
		_bottom_points[key] = Geometry2D.convex_hull(outline)
	var bottom := Vector2.ZERO
	var found := false
	for point: Vector2 in _bottom_points[key]:
		var local := CharacterRig.part_source_point(part, point)
		var location := stage.to_local(part.to_global(local))
		if not found or location.y > bottom.y:
			bottom = location
			found = true
	return [bottom.x,bottom.y,part.global_rotation] if found else []

