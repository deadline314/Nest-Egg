from pathlib import Path
import json
import subprocess

base = Path(__file__).resolve().parent
result = json.loads((base / "result-candidate-wide-series.json").read_bytes())
output = base / "wide-video"
output.mkdir()
names = []
for number, (key, row) in enumerate(result.items(), 1):
    scene, direction = key.split("/")
    count = row["after"]["frames"]
    frame_prefix = f"{scene}-{direction}-"
    captures = []
    for case in ("stock-series", "candidate-wide-series"):
        folder = base / case / "series"
        assert len(list(folder.glob(frame_prefix + "*.png"))) == count
        captures.extend(["-framerate", "30", "-start_number", "1", "-i", str(folder / (frame_prefix + "%03d.png"))])
    name = f"case-{number}.mp4"
    subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-filter_complex_threads", "2", *captures,
                    "-filter_complex", "[0:v]crop=340:408:690:90[old];[old][1:v]hstack=shortest=1[v]", "-map", "[v]", "-frames:v", str(count),
                    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "19", "-preset", "fast", "-threads", "2", str(output / name)],
                   check=True)
    names.append(name)
sequence = output / "list.txt"
sequence.write_text("".join(f"file '{name}'\n" for name in names), encoding="utf-8")
video = output / "guest-walks.mp4"
subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "1", "-i", str(sequence),
                "-c", "copy", "-movflags", "+faststart", str(video)], check=True)
probe = json.loads(subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "v",
                                          "-show_entries", "stream=width,height,nb_frames", "-of", "json", str(video)]))
assert probe["streams"] == [{"width": 680, "height": 408, "nb_frames": "488"}], probe
(output / "probe.json").write_text(json.dumps(probe, indent=2) + "\n", encoding="utf-8")
print(video, video.stat().st_size, probe)
