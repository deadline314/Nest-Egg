extends "res://tools/melee_art_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
const SHOTS := [
	[Player.MeleePhase.WINDUP, 0.20, "windup"],
	[Player.MeleePhase.ACTIVE, 0.46, "strike"],
	[Player.MeleePhase.RECOVERY, 0.75, "follow"],
	[Player.MeleePhase.RECOVERY, 0.92, "recover"],
]
var _frames := {}


func _run() -> void:
	Story.auto_skip = true
	Settings.set_reduce_flashes(true)
	await open_arena("res://data/lighting/warehouse_interior.tres", 12.0)
	await clear_enemies()
	var camera := get_viewport().get_camera_2d()
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * 2.25
	AimInput.set_virtual_gamepad(player, true)
	for facing: int in [1, -1]:
		Input.action_release(&"aim_right" if facing < 0 else &"aim_left")
		Input.action_press(&"aim_left" if facing < 0 else &"aim_right")
		for id: String in WEAPONS:
			var weapon := load("res://data/weapons/melee/melee_%s.tres" % id) as WeaponData
			await _arm(weapon, camera)
			camera.global_position = player.global_position + Vector2(23.0 * facing, -37.0)
			camera.force_update_scroll()
			await settle(8)
			if player.facing != facing or player.loadout.active_weapon() != weapon or not player._visual.shows_melee_weapon():
				push_error("The equipped melee weapon did not settle in the requested direction: " + id)
				_failures += 1
				continue
			await _swing(id, facing)
	Input.action_release(&"aim_left")
	Input.action_release(&"aim_right")
	AimInput.set_virtual_gamepad(player, false)
	var file := FileAccess.open(out_dir.path_join("frames.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures":_failures,"frames":_frames},"  ")+"\n")
	file.close()
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures == 0 else 1)


func _swing(id: String, facing: int) -> void:
	var at := 0
	var action_at := Engine.get_physics_frames()
	Input.action_press(&"melee")
	for tick in 110:
		await get_tree().process_frame
		if tick == 3:
			Input.action_release(&"melee")
		var phase := int(player._melee_phase)
		var progress := player.melee_pose_progress()
		if phase != SHOTS[at][0] or progress < SHOTS[at][1]:
			continue
		await RenderingServer.frame_post_draw
		var name := "%s-%s-%s" % [id, "right" if facing > 0 else "left", SHOTS[at][2]]
		var transform := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
		var feet := transform * player.global_position
		var hold := player._visual.melee_hold()
		var tip := transform * player._visual.melee_held().tip_point()
		var image := CAPTURE.image(get_viewport())
		if image.save_png(out_dir.path_join(name + ".png")) != OK:
			_failures += 1
		_frames[name] = {"weapon":id,"facing":player.facing,"phase":phase,"progress":progress,
			"since_press":Engine.get_physics_frames() - action_at,"attack":str(player.melee.attack.get("id","")),
			"pose":str(player.melee_pose()),"feet":[feet.x,feet.y],"hold":[hold.origin.x,hold.origin.y],"tip":[tip.x,tip.y],
			"size":[image.get_width(),image.get_height()]}
		at += 1
		if at == SHOTS.size():
			Input.action_release(&"melee")
			await settle(45)
			return
	Input.action_release(&"melee")
	push_error("Could not capture all attack phases for %s facing %s: %s" % [id,facing,at])
	_failures += 1
