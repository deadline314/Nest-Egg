from pathlib import Path
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
project = Path.cwd()
output = base / sys.argv[1]
output.mkdir()
env = os.environ.copy()
for name in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR", "XDG_DATA_HOME", "XDG_CONFIG_HOME"):
    folder = output / name
    folder.mkdir()
    env[name] = str(folder)
command = [sys.executable, "-B", str(project / "tools/comfyui/gpu_lock.py"), "--",
           "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(project),
           "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--audio-driver", "Dummy",
           "--resolution", "1280x720", "--fixed-fps", "60", "--quit-after", "3000", str(base / "readability.tscn"), "--",
           "--out=" + str(output)]
(output / "command.json").write_text(json.dumps(command, indent=2))
with (output / "engine.log").open("wb") as log:
    result = subprocess.run(command, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=210)
raw = (output / "engine.log").read_text("utf-8", errors="replace")
errors = [line for line in raw.splitlines() if re.search(r"^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit", line)]
document = output / "frames.json"
data = json.loads(document.read_bytes()) if document.exists() else {}
receipt = {"exit": result.returncode, "errors": errors, "count": len(data.get("frames", {})), "failures": data.get("failures")}
(output / "run.json").write_text(json.dumps(receipt, indent=2))
print(receipt)
assert receipt == {"exit": 0, "errors": [], "count": 40, "failures": 0}
