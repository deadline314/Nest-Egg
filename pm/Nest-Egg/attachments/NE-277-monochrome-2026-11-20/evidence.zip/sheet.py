from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
from random import SystemRandom
import json
import sys

base = Path(__file__).resolve().parent
capture = base / sys.argv[1]
records = json.loads((capture / "frames.json").read_bytes())
weapons = ("blade", "dagger", "glaive", "maul", "whip")
phases = (("windup", 1, 0.20), ("strike", 2, 0.46), ("follow", 3, 0.75), ("recover", 3, 0.92))
assert records["failures"] == 0 and len(records["frames"]) == 40
font = ImageFont.truetype("C:/Windows/Fonts/msjh.ttc", 21)
small = ImageFont.truetype("C:/Windows/Fonts/segoeui.ttf", 16)
answer = {}
for side, facing in (("right", 1), ("left", -1)):
    batch = []
    for weapon in weapons:
        previous_tick = -1
        for phase, phase_id, lower in phases:
            name = f"{weapon}-{side}-{phase}"
            row = records["frames"][name]
            assert row["facing"] == facing and row["phase"] == phase_id and row["progress"] >= lower
            assert row["since_press"] > previous_tick and row["pose"]
            assert row["size"] == [1280, 720]
            previous_tick = row["since_press"]
            batch.append(row)
    x_values = [value for row in batch for value in (row["feet"][0], row["tip"][0])]
    y_values = [value for row in batch for value in (row["feet"][1], row["tip"][1])]
    x0, x1 = max(0, int(min(x_values) - 132)), min(1280, int(max(x_values) + 132))
    y0, y1 = max(0, int(min(y_values) - 310)), min(720, int(max(y_values) + 80))
    roll = list(weapons)
    SystemRandom().shuffle(roll)
    cell_width = 400
    cell_height = min(330, round(cell_width * (y1 - y0) / (x1 - x0)))
    panel = Image.new("L", (42 + len(phases) * (cell_width + 4), 46 + len(weapons) * (cell_height + 4)), 18)
    draw = ImageDraw.Draw(panel)
    for column, label in enumerate(("起手", "出手", "跟隨", "收招")):
        draw.text((44 + column * (cell_width + 4), 14), label, font=font, fill=218)
    for index, weapon in enumerate(roll):
        row_y = 46 + index * (cell_height + 4)
        draw.text((10,row_y + 10), chr(65 + index), font=small, fill=225)
        for column, (phase, _, _) in enumerate(phases):
            name = f"{weapon}-{side}-{phase}"
            with Image.open(capture / (name + ".png")) as source:
                visual = ImageOps.grayscale(source).crop((x0, y0, x1, y1))
            visual.thumbnail((cell_width, cell_height), Image.Resampling.LANCZOS)
            panel.paste(visual, (42 + column * (cell_width + 4) + (cell_width - visual.width) // 2, row_y))
    panel.save(capture / (side + "-monochrome.png"), optimize=True)
    answer[side] = {"crop": [x0, y0, x1, y1],
                    "rows": {chr(65+i): weapon for i, weapon in enumerate(roll)}}
(capture / "row-order.json").write_text(json.dumps(answer, indent=2) + "\n")
print("Wrote two monochrome sheets. Row identities are in row-order.json.")
