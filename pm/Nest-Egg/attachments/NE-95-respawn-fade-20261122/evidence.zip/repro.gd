extends "res://tests/smoke_test.gd"

func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var candidate := "--candidate" in OS.get_cmdline_user_args()
	var suite: FxUpgradesSuite = preload("candidate.gd").new(self) if candidate else FxUpgradesSuite.new(self)
	for i in 5:
		await suite._test_dash_and_materialize()
	await _finish()
