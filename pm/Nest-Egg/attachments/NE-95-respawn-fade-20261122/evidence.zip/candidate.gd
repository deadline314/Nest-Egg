extends FxUpgradesSuite


func _test_dash_and_materialize() -> void:
	await open_level(10.0)
	var player := level.player
	var visual: PlayerVisual = player._visual
	player._dash_cooldown_left = 0.0
	player._try_dash(1.0)
	await physics_frames(12)
	check(is_instance_valid(visual._ghost_pool) and visual._ghost_pool.active_count() > 0 and visual._ghost_pool.active_count() <= PlayerVisual.MAX_GHOSTS, "real dash leaves bounded actual-pose silhouettes")
	if is_instance_valid(visual._ghost_pool):
		for slot in visual._ghost_pool.slots:
			if slot.visible:
				check(absf(slot.facing) == 1.0 and slot.used > 0, "actual-pose snapshot stores a valid captured rig facing and geometry")
	await physics_frames(60)
	check(is_instance_valid(visual._ghost_pool) and visual._ghost_pool.active_count() == 0, "afterimages fade out and release source texture leases")
	visual.notify_parry()
	await frames(2)
	check(visual._parry_flash > 0.0, "the parry starburst is playing")
	player.play_respawn_fx()
	# The fade advances in render time; physics can run several steps before it draws.
	var half_duration := PlayerVisual.MATERIALIZE_TIME * 0.5
	check(is_equal_approx(visual._materialize_left, PlayerVisual.MATERIALIZE_TIME), "respawn starts the full body fade")
	visual._process(half_duration)
	check(is_equal_approx(visual.modulate.a, 0.5), "a respawn fades the body in")
	visual._process(half_duration)
	check(visual._materialize_left == 0.0 and visual.modulate.a >= 0.99, "the fade-in ends fully visible")
	await end_level(level)

