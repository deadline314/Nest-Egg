extends "res://tests/smoke_test.gd"

const OUT := "D:/NestEggVerification/evidence-20261122-ne95-respawn-alpha/"

func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var suite := FxUpgradesSuite.new(self)
	await suite.open_level(10.0)
	var level := suite.level
	var player := level.player
	var visual: PlayerVisual = player._visual
	for i in 155:
		await get_tree().process_frame
	player.play_respawn_fx()
	_check(is_equal_approx(visual._materialize_left, PlayerVisual.MATERIALIZE_TIME), "the production entry starts the entire fade")
	var captures := {}
	var previous := -1.0
	for i in 50:
		await RenderingServer.frame_post_draw
		var alpha := visual.modulate.a
		_check(alpha >= previous, "native body alpha never decreases during respawn")
		previous = alpha
		var tag := ""
		if alpha < 0.12 and not captures.has("early"):
			tag = "early"
		elif alpha >= 0.48 and alpha < 0.55 and not captures.has("middle"):
			tag = "middle"
		elif visual._materialize_left == 0.0 and not captures.has("restored"):
			tag = "restored"
		if not tag.is_empty():
			captures[tag] = alpha
			_check(get_viewport().get_texture().get_image().save_png(OUT + tag + ".png") == OK, "the native frame writes successfully")
		await get_tree().process_frame
	_check(captures.size() == 3 and is_equal_approx(visual.modulate.a, 1.0), "all native fade phases are visible")
	print("NATIVE_FADE ", JSON.stringify(captures))
	await suite.end_level(level)
	await _finish()
