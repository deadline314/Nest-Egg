from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

root=Path.cwd()
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118/medic-transport-v1/root-s13-20261119')
out=base/('main-outcomes-'+sys.argv[1])
out.mkdir()
slug='ne267_s13_main_'+sys.argv[1].replace('-','_')
old=Path('D:/NestEggVerification/evidence-20261117/ne267-hong-20261118/s20-before-runtime') if sys.argv[1]=='legacy' else shared
if old!=shared:
    baseline=json.loads(subprocess.check_output(['git','show','07c68e3e8:data/story/ch2_heron.json'],cwd=root))
    old_data=json.loads((old/'data/story/ch2_heron.json').read_bytes())
    assert {n:d for n,d in baseline['scenes'].items() if n.startswith('ch2_t_s13_')}=={n:d for n,d in old_data['scenes'].items() if n.startswith('ch2_t_s13_')}
    for name in ['game/main.gd','game/cutscene/cutscene_player.gd','data/npcs/ch2_ledger_cabinet.tres']:
        git_file=subprocess.check_output(['git','show',f'07c68e3e8:{name}'],cwd=root)
        assert git_file.replace(b'\r\n',b'\n')==(old/name).read_bytes().replace(b'\r\n',b'\n'),name
for project in {old,shared}:
    source=project/f'work/{slug}.gd'
    shutil.copyfile(root/'work/ne267-s13-main-probe.gd',source)
    source.with_suffix('.tscn').write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/{slug}.gd" id="1"]\n[node name="S13MainProbe" type="Node"]\nscript=ExtResource("1")\n')
for filename in [source,source.with_suffix('.tscn')]:
    shutil.copyfile(filename,out/filename.name)
prefix=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe']
guard_paths=['data/story/ch2_heron.json','data/npcs/ch2_ledger_cabinet.tres','game/main.gd',f'work/{slug}.gd']
hashes=lambda project:{name:hashlib.sha256((project/name).read_bytes()).hexdigest() for name in guard_paths}
guard={str(project):hashes(project) for project in {old,shared}}
results=[]
for mode in ['cut_play','cut_read','keep_play','keep_read']:
    dest=out/mode
    dest.mkdir()
    slot=out/mode.split('_')[0]/'save'
    env=os.environ.copy()
    for name in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[name]=str(dest/'profile'/name)
    project=old if mode.endswith('_play') else shared
    cmd=prefix+['--path',str(project),'--headless','--audio-driver','Dummy','--fixed-fps','60','res://work/'+slug+'.tscn','--','--mode='+mode,'--save-dir='+str(slot),'--out='+str(dest)]
    (dest/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with (dest/'raw.log').open('wb') as log:
        run=subprocess.run(cmd,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
    raw=(dest/'raw.log').read_text(encoding='utf-8',errors='replace')
    report=dest/'result.json'
    result={'mode':mode,'project':str(project),'exit':run.returncode,'diagnostics':[s for s in raw.splitlines() if 'ERROR:' in s],'source_held':hashes(project)==guard[str(project)],'report':json.loads(report.read_text(encoding='utf-8')) if report.is_file() else None}
    results.append(result)
    (out/'receipt.json').write_text(json.dumps({'source':guard,'results':results},indent=2)+'\n')
    print(result,flush=True)
    assert run.returncode==0 and result['source_held'] and not result['diagnostics'] and result['report'] and not result['report']['failures']
