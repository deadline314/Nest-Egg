from pathlib import Path
from PIL import Image, ImageDraw
import hashlib
import json
import sys

base=Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118/medic-transport-v1')/('native-release-v7-'+(sys.argv[1] if len(sys.argv)>1 else 'checked'))
out=base/'review'
out.mkdir()
images=[]
for route in ('cut','keep','fall'):
    path=base/route
    result=json.loads((path/'result.json').read_text(encoding='utf-8'))
    images.extend(path/row['png'] for row in result['scenes'][0]['captures'])
assert len(images)==26
records=[]
for start in range(0,len(images),4):
    selected=images[start:start+4]
    page=Image.new('RGB',(1280,384*((len(selected)+1)//2)),(36,36,36))
    draw=ImageDraw.Draw(page)
    name=f's13-{start//4+1:02}.png'
    for index,picture in enumerate(selected):
        x,y=(index%2)*640,(index//2)*384
        draw.text((x+6,y+4),picture.name,fill=(250,235,213))
        with Image.open(picture) as frame:
            assert frame.size==(640,360)
            page.paste(frame,(x,y+24))
        records.append({'source':str(picture),'sha256':hashlib.sha256(picture.read_bytes()).hexdigest(),'page':name})
    page.save(out/name)
(out/'pages.json').write_text(json.dumps(records,indent=2)+'\n')
