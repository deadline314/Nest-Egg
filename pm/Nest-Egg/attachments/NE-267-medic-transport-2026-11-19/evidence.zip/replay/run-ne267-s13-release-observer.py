from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118')
runtime=base/'runtime-ownership-v7'
transport=base/'medic-transport-v1'
out=transport/('native-release-v7-'+sys.argv[1] if len(sys.argv)>1 else 'native-release-v7')
out.mkdir()
source_dir=transport/'native-formal-stage-v1'
source=(source_dir/'observer.gd').read_text(encoding='utf-8')
before='\t\t\tvar bed:=stage.prop_node("transport_stretcher") as StageLayers._Sprite'
extra='''
			var visitor := player._actors.get(&"xiaowei") as CutsceneActor
			if visitor != null and visitor.position.x > 600.0 and not phases.has("escort"):
				phases["escort"] = true
				shots.append(_capture(player,id,"escort",poses))
			for prop: String in ["medic_pause_lock","medic_maintenance_key"]:
				if stage.prop_held(prop) and not phases.has(prop):
					phases[prop] = true
					shots.append(_capture(player,id,prop,poses))
'''.lstrip('\n')
assert source.count(before)==1
source=source.replace(before,extra+before)
source=source.replace('"loading","strapped"','"loading","carrying","strapped"')
carry='\t\t\t\t\t\t"loading":ready=patient!=null and patient.position.y<280 and patient.position.x<330'
assert source.count(carry)==1
source=source.replace(carry,carry+'\n\t\t\t\t\t\t"carrying":ready=patient!=null and patient.position.x>360 and patient.position.x<410 and patient.position.y<249')
marker='\tif GameState.world_flags!=flags or Progression.credits!=credits:'
assert source.count(marker)==1
source=source.replace(marker,'''\tvar required := ["carrying", "lift_ready", "strapped", "outgoing"] if id.ends_with("_fall") else ["escort"]
	if id.ends_with("_keep"):
		required.append_array(["medic_pause_lock", "medic_maintenance_key"])
	for phase: String in required:
		if not phases.has(phase):
			_failures.append(id + ": lost required presentation phase " + phase)
'''+marker)
(out/'observer.gd').write_text(source,encoding='utf-8')
scene=(source_dir/'observer.tscn').read_text(encoding='utf-8')
old_script=(source_dir/'observer.gd').as_posix()
assert scene.count(old_script)==1
(out/'observer.tscn').write_text(scene.replace(old_script,(out/'observer.gd').as_posix()),encoding='utf-8')
script_paths=['data/story/ch2_heron.json','data/cutscene/stages/ch2_medic_transport.json','game/cutscene/cutscene_player.gd','game/cutscene/stage_prop_binding.gd','game/cutscene/stage_library.gd','game/rig/humanoid_animator.gd']
script_paths += ['art/motion/'+skin+'/transport.json' for skin in ('ch2_medic','ch2_greycoat','egret')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={name:sha(runtime/name) for name in script_paths}
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(out/'profile'/key)
prefix=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(runtime),'--audio-driver','Dummy']
results={}
for episode in ('cut','keep','fall'):
    dest=out/episode
    dest.mkdir()
    cmd=prefix+['--rendering-method','forward_plus','--rendering-driver','vulkan','--resolution','640x360','--max-fps','60',str(out/'observer.tscn'),'--','--scene=ch2_t_s13_'+episode,'--out='+str(dest)]
    (dest/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with (dest/'raw.log').open('wb') as log:
        run=subprocess.run(cmd,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    raw=(dest/'raw.log').read_bytes()
    native=json.loads((dest/'result.json').read_text(encoding='utf-8'))
    rows=native['scenes'][0]
    record={'exit':run.returncode,'diagnostics':[line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line or b'WARNING:' in line],'failed_contacts':native['failures'],'samples':len(rows['contacts']),'max_contact':max(row['distance'] for row in rows['contacts']),'phases':[row['phase'] for row in rows['captures']],'flags_held':rows['flags_and_credits_held'],'source_held':all(sha(runtime/name)==digest for name,digest in sources.items())}
    results[episode]=record
    (out/'receipt.json').write_text(json.dumps({'results':results,'source':sources},indent=2)+'\n')
    print(episode,record,flush=True)
    phases={'fall':{'carrying','lift_ready','strapped','outgoing'},'cut':{'escort'},'keep':{'escort','medic_pause_lock','medic_maintenance_key'}}[episode]
    assert run.returncode==0 and not record['diagnostics'] and not record['failed_contacts'] and record['source_held'] and record['flags_held'] and phases.issubset(record['phases'])
