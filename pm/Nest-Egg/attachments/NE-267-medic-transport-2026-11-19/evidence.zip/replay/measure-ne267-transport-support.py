from pathlib import Path
import json
import sys

import numpy as np
from PIL import Image

base = Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118')
runtime = base / 'runtime-ownership-v7'
source = Path(sys.argv[1])
out = Path(sys.argv[2])
images = {}


def opaque(row):
    path = row['texture'].removeprefix('res://')
    if path not in images:
        with Image.open(runtime / path) as image:
            alpha = np.asarray(image.convert('RGBA'))[:, :, 3]
        y, x = np.nonzero(alpha >= 128)
        images[path] = (np.stack((x, y), axis=1) + .5, alpha.shape[::-1])
    points, size = images[path]
    assert tuple(row['imported_size']) == size, (path, row['imported_size'], size)
    return points


def material(row):
    points = opaque(row)
    if 'matrix' in row:
        matrix = np.asarray(row['matrix'])
        return (points + row['origin']) @ matrix[:2] + matrix[2]
    projected = []
    uv, vertices = np.asarray(row['uv']), np.asarray(row['vertices'])
    for a, b, c in row['polygons']:
        source_basis = np.stack((uv[b] - uv[a], uv[c] - uv[a]))
        if abs(np.linalg.det(source_basis)) < 1e-6:
            continue
        weights = (points - uv[a]) @ np.linalg.inv(source_basis)
        selected = np.all(weights >= 0, axis=1) & (weights.sum(axis=1) <= 1)
        dest_basis = np.stack((vertices[b] - vertices[a], vertices[c] - vertices[a]))
        projected.append(weights[selected] @ dest_basis + vertices[a])
    return np.concatenate(projected)


def bounds(points):
    return {'x': [float(points[:, 0].min()), float(points[:, 0].max())], 'y': [float(points[:, 1].min()), float(points[:, 1].max())]}


report = {}
for scene in json.loads(source.read_text(encoding='utf-8'))['scenes']:
    phases = {}
    for shot in scene['captures']:
        parts = {}
        props = {}
        for row in shot['geometry']['parts']:
            if row['actor'] in {'egret', 'porter_front', 'porter_rear', 'rin'} and row['part'].startswith(('head','torso','pelvis','leg','foot')):
                points = material(row)
                assert len(points), (row['actor'], row['part'])
                parts.setdefault(row['actor'], {})[row['part']] = bounds(points)
        for row in shot['geometry']['props']:
            if row['id'] != 'transport_stretcher':
                continue
            points = material(row)
            matrix = np.asarray(row['matrix'])
            props[row['id']] = bounds(points)
            props[row['id']]['mattress_y'] = float(((np.array([250, 59]) + row['origin']) @ matrix[:2] + matrix[2])[1])
            props[row['id']]['floor_y'] = 296.0
        phases[shot['phase']] = {'parts':parts,'props':props}
    report[scene['id']] = phases
out.write_text(json.dumps(report, indent=2)+'\n',encoding='utf-8')
for phases in report.values():
    for phase, row in phases.items():
        if not row['props']:
            continue
        print(phase, row['props']['transport_stretcher'], {actor:{part:round(v['y'][1],3) for part,v in mats.items()} for actor,mats in row['parts'].items() if actor != 'rin'})
