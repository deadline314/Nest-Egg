import copy
from pathlib import Path
import unittest
from ne277_verify import METRICS, LIMITS, verify_motion, verify_feedback


class MotionEvidenceTests(unittest.TestCase):
    def fixture(self):
        frames = [{"tick": i, "phase": phase, "angles": {"hand": 0.1}, "held_input": phase != 0, "hold_mode": "sustain" if phase else ""} for i, phase in enumerate([1, 2, 3, 0])]
        return {"checks": 12, "failures": [], "rows": [{"name": "glaive/1/guard-held", "ended": True, "frames": frames, "held": True, "released": True, "results": {key: {"value": 0, "limit": LIMITS[key]} for key in METRICS}, "path_samples": 4, "palm_max": 0, "second_max": 0, "second_missed": 0}]}

    def test_valid(self):
        self.assertEqual([], self.verify(self.fixture()))

    def verify(self, data):
        return verify_motion(data, {"glaive/1/guard-held"}, Path("."))

    def test_rejects_each_missing_metric(self):
        for key in METRICS:
            with self.subTest(key=key):
                d = self.fixture(); del d["rows"][0]["results"][key]
                self.assertTrue(self.verify(d))

    def test_rejects_failed_state_mutations(self):
        changes = [lambda d: d.update(checks=0), lambda d: d.update(rows=[]), lambda d: d["rows"].append(copy.deepcopy(d["rows"][0])), lambda d: d["rows"][0].update(frames=[]), lambda d: d["rows"][0].update(ended=False), lambda d: d["rows"][0].update(released=False), lambda d: d["rows"][0]["frames"][1].update(tick=9), lambda d: d["rows"][0]["frames"][2].update(phase=2), lambda d: d["rows"][0].update(path_samples=0), lambda d: d["rows"][0].update(second_missed=1), lambda d: d["rows"][0]["results"]["angle_pop"].update(value=1), lambda d: d["rows"][0]["results"]["angle_pop"].update(value=float("nan")), lambda d: d["rows"][0]["frames"][0].update(angles={}), lambda d: d.update(failures=["bad"])]
        for i, change in enumerate(changes):
            with self.subTest(case=i):
                d = self.fixture(); change(d)
                self.assertTrue(self.verify(d))

    def test_headless_cannot_claim_native(self):
        self.assertTrue(verify_motion(self.fixture(), {"glaive/1/guard-held"}, Path("."), native=True))

    def test_relaxed_limits_and_hidden_real_jump_are_rejected(self):
        d = self.fixture(); d["rows"][0]["results"]["angle_pop"]["limit"] = 1.98
        self.assertTrue(self.verify(d))

        d = self.fixture(); d["rows"][0]["frames"][2]["angles"]["hand"] = 3
        self.assertTrue(self.verify(d))

    def test_feedback_rejects_missing_contact_freeze_and_leaf(self):
        row = {"name": "blade", "hits": [{"tick": 9, "amount": 2, "attacker": True, "freeze_attacker": True}], "frames": [{"tick": 9, "player_frozen": True, "enemy_frozen": True}], "first_observed_pair_freeze": True, "expected_layers": ["low", "high"], "played": ["thud", "cut"]}
        events = {"low": {"layers": [{"sounds": ["thud"]}]}, "high": {"layers": [{"sounds": ["cut"]}]}}
        d = {"checks": 8, "failures": [], "rows": [row]}
        self.assertEqual([], verify_feedback(d, {"blade"}, events))
        for mutate in [lambda r: r.update(hits=[]), lambda r: r["frames"][0].update(enemy_frozen=False), lambda r: r.update(played=["cut"]), lambda r: r.update(first_observed_pair_freeze=False)]:
            bad = copy.deepcopy(d); mutate(bad["rows"][0])
            self.assertTrue(verify_feedback(bad, {"blade"}, events))
        self.assertTrue(verify_feedback(d, {"blade", "maul"}, events))


if __name__ == "__main__":
    unittest.main()
