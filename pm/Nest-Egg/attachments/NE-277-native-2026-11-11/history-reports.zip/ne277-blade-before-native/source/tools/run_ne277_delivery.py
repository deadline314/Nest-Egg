"""Serial isolated NE-277 probes with immutable source snapshots and raw ZIP evidence."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import wave
import zipfile
from ne277_verify import verify_motion

ROOT = Path(__file__).resolve().parents[1]
WEAPONS = {"blade": "thermal_blade", "dagger": "mono_dagger", "glaive": "ion_glaive", "maul": "hydraulic_maul", "whip": "mono_whip"}
SOURCES = ["tools/ne277_delivery_probe.gd", "tools/ne277_delivery_probe.tscn", "tools/ne277_feedback_probe.gd", "tools/ne277_feedback_probe.tscn", "tools/melee_joint_audit.gd", "tools/viewport_capture.gd", "tools/ne277_verify.py", "tools/run_ne277_delivery.py", "game/melee/melee_module.gd", "game/melee/melee_move.gd", "game/player/player.gd", "game/player/player_visual.gd", "game/player/melee_held.gd", "game/player/melee_command_input.gd", "game/rig/character_rig.gd", "game/rig/humanoid_animator.gd", "game/rig/anim_audit.gd", "game/enemies/enemy.gd", "autoload/feel.gd", "autoload/fx.gd", "autoload/sfx.gd", "autoload/settings.gd", "data/feel/events.json", "data/feel/sound_events.json", "data/audio/sound_bank.json", "art/rigs/action_poses.json", "art/rigs/rin.json", "art/motion/rin.json", "data/weapon_art/melee.json", "project.godot"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def sources():
    paths = set(p for p in SOURCES if p != "art/rigs/rin.json")
    skin = json.loads((ROOT / "art/characters/rin/character.json").read_text(encoding="utf-8"))
    paths.add(skin["rig"].removeprefix("res://"))
    for folder, pattern in [("data/melee", "*.json"), ("data/weapons/melee", "*.tres"), ("art/characters/rin", "*")]:
        paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT / folder).rglob(pattern) if p.is_file() and p.suffix != ".import")
    return sorted(paths)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--godot", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--mode", choices=["motion", "feedback"], default="motion")
    parser.add_argument("--weapon", choices=WEAPONS)
    parser.add_argument("--facing", choices=["-1", "1", "both"], default="both")
    parser.add_argument("--native", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--negative", choices=["missing-input"])
    parser.add_argument("--timeout", type=int, default=360)
    args = parser.parse_args()
    out = args.out.resolve(); out.mkdir(parents=True, exist_ok=False); (out / ".gdignore").touch()
    inputs = sources(); before = {p: sha(ROOT / p) for p in inputs}
    for p in inputs:
        if Path(p).suffix in [".gd", ".tscn", ".json", ".py", ".godot", ".tres", ".gdshader"]:
            target = out / "source" / p; target.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(ROOT / p, target)
    scene = "ne277_delivery_probe" if args.mode == "motion" else "ne277_feedback_probe"
    cmd = [str(args.godot.resolve())]
    if args.verbose:
        cmd += ["--verbose"]
    if args.native:
        cmd += ["--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--resolution", "1280x720"]
    else:
        cmd += ["--headless", "--audio-driver", "Dummy"]
    cmd += ["--path", str(ROOT), "res://tools/" + scene + ".tscn", "--", "--out=" + str(out), "--facing=" + args.facing]
    if args.weapon:
        cmd += ["--weapon=" + args.weapon]
    if args.negative:
        cmd += ["--negative=" + args.negative]
    if args.native:
        cmd += ["--capture"]
        cmd = [sys.executable, str(ROOT / "tools/comfyui/gpu_lock.py"), "--"] + cmd
    env = os.environ.copy(); env.update(APPDATA=str(out / "user"), LOCALAPPDATA=str(out / "user"), XDG_DATA_HOME=str(out / "user"), PYTHONUTF8="1")
    started = time.monotonic(); timed_out = False
    with (out / "process.log").open("wb") as log:
        process = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=args.timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            # Only the process tree started immediately above; never broad Godot/service cleanup.
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], stdout=log, stderr=log, check=False)
            else:
                os.killpg(process.pid, signal.SIGKILL)
            code = process.wait(timeout=15)
    after = {p: sha(ROOT / p) for p in inputs}
    text = (out / "process.log").read_text(encoding="utf-8", errors="strict")
    diagnostics = [line for line in text.splitlines() if re.search(r"^ERROR:|SCRIPT ERROR|Parse Error|leaked at exit|resources still in use|crashed|handle_crash:", line)]
    errors = []
    try:
        data = json.loads((out / "result.json").read_text(encoding="utf-8"))
        if args.mode == "motion":
            sides = [-1, 1] if args.facing == "both" else [int(args.facing)]
            expected = set()
            for id, profile in WEAPONS.items():
                if args.weapon and id != args.weapon:
                    continue
                definition = json.loads((ROOT / f"data/melee/{profile}.json").read_text(encoding="utf-8"))
                moves = list(definition["combo"])
                extension = definition.get("extension", {})
                if extension.get("attack"):
                    moves.append(extension["attack"])
                for side in sides:
                    if not args.negative:
                        expected.update(f"{id}/{side}/{move}" for move in moves)
                    expected.add(f"{id}/{side}/{definition['hold']['attack']}-held")
            errors += verify_motion(data, expected, out, args.native)
        elif not data.get("checks") or data.get("failures") != [] or not data.get("rows"):
            errors.append("feedback requires nonempty passing observations")
        if args.native and args.mode == "feedback":
            with wave.open(str(out / "master.wav"), "rb") as wav:
                samples = wav.readframes(wav.getnframes())
                if wav.getnframes() < wav.getframerate() or not any(samples):
                    errors.append("native WAV must contain nonzero recorded audio")
    except (OSError, ValueError, KeyError, TypeError, wave.Error) as error:
        errors.append(str(error))
    if before != after:
        errors.append("source/assets changed during process")
    if diagnostics:
        errors.append("engine/probe diagnostics")
    receipt = {"command": cmd, "engine_sha256": sha(args.godot), "source_before_sha256": before, "source_after_sha256": after, "exit": code, "timeout_exceeded": timed_out, "wall_seconds_not_performance": round(time.monotonic() - started, 3), "diagnostics": diagnostics, "verification_errors": errors, "passed": code == 0 and not timed_out and not errors}
    files = [p for p in out.rglob("*") if p.is_file() and "user" not in p.relative_to(out).parts]
    receipt["files_sha256"] = {p.relative_to(out).as_posix(): sha(p) for p in files}
    write(out / "run.json", receipt)
    with zipfile.ZipFile(out / "raw.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files + [out / "run.json"]:
            archive.write(path, path.relative_to(out).as_posix())
    print(json.dumps({"passed": receipt["passed"], "exit": code, "errors": errors, "raw_zip_sha256": sha(out / "raw.zip")}, ensure_ascii=False), flush=True)
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
