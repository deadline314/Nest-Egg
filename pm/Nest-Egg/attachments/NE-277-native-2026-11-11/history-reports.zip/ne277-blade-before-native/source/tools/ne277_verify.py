"""Independent fail-closed verification of NE-277 observations, never a visual verdict."""
from __future__ import annotations
import math
from pathlib import Path
import struct

METRICS = {"bone_stretch", "elbow_hyper", "trunk_lean", "head_turn", "mesh_fold", "limb_pinch", "angle_pop"}


def verify_motion(data: dict, expected: set[str], directory: Path, native=False) -> list[str]:
    errors = []
    def require(ok, message):
        if not ok:
            errors.append(message)
    require(type(data.get("checks")) is int and data["checks"] > 0, "positive check count")
    require(data.get("failures") == [], "probe failures must be empty")
    rows = data.get("rows", [])
    require(isinstance(rows, list) and len(rows) > 0, "nonempty motion rows")
    if not isinstance(rows, list):
        return errors
    names = [r.get("name") for r in rows if isinstance(r, dict)]
    require(len(names) == len(rows) == len(set(names)) and set(names) == expected, "exact unique move/side coverage")
    for row in rows:
        if not isinstance(row, dict):
            continue
        name = str(row.get("name"))
        frames = row.get("frames", [])
        require(isinstance(frames, list) and len(frames) >= 3 and row.get("ended") is True, name + ": completed nonempty frames")
        if not isinstance(frames, list) or not frames:
            continue
        ticks = [f.get("tick") for f in frames]
        require(all(type(t) is int for t in ticks) and all(b == a + 1 for a, b in zip(ticks, ticks[1:])), name + ": contiguous physics ticks")
        require({0, 1, 2, 3}.issubset({f.get("phase") for f in frames}), name + ": all phases and return")
        require(all(isinstance(f.get("angles"), dict) and f["angles"] and all(isinstance(a, (int, float)) and math.isfinite(a) for a in f["angles"].values()) for f in frames), name + ": finite actual bone observations")
        results = row.get("results", {})
        require(METRICS.issubset(results), name + ": every metric present")
        for key in METRICS:
            value = results.get(key, {})
            number, limit = value.get("value"), value.get("limit")
            require(type(number) in (int, float) and type(limit) in (int, float) and math.isfinite(number) and math.isfinite(limit) and number <= limit, name + ": metric " + key)
        require(row.get("path_samples", 0) > 0 and row.get("palm_max", math.inf) <= 1 and row.get("second_max", math.inf) <= 1.5 and row.get("second_missed") == 0, name + ": measured grips")
        if row.get("held"):
            require(row.get("released") is True and any(f.get("held_input") is True and f.get("hold_mode") for f in frames) and frames[-1].get("held_input") is False, name + ": actual held input and release")
        if native:
            for frame in frames:
                relative = frame.get("image", "")
                path = (directory / relative).resolve()
                require(bool(relative) and path.is_relative_to(directory.resolve()), name + ": image path stays in evidence")
                for image, rect in [(path, frame.get("crop")), (path.with_name(path.stem + "-hands.png"), frame.get("hands_crop"))]:
                    try:
                        header = image.read_bytes()[:24]
                        size = struct.unpack(">II", header[16:24])
                        require(header[:8] == b"\x89PNG\r\n\x1a\n" and isinstance(rect, list) and len(rect) == 4 and size == tuple(rect[2:]) and min(size) > 0, name + ": unscaled native image geometry")
                    except (OSError, ValueError, struct.error):
                        require(False, name + ": missing or invalid native image")
    if native:
        require(data.get("renderer") == "forward_plus" and data.get("display") != "headless" and bool(data.get("adapter")), "real native Forward+ renderer")
    return errors
