"""Independent fail-closed verification of NE-277 observations, never a visual verdict."""
from __future__ import annotations
import math
from pathlib import Path
import struct

LIMITS = {"bone_stretch": 0.3, "elbow_hyper": 0.6, "trunk_lean": 1.15, "head_turn": 1.0, "mesh_fold": 0.4, "limb_pinch": 0.75, "angle_pop": 0.9}
METRICS = set(LIMITS)


def verify_motion(data: dict, expected: set[str], directory: Path, native=False) -> list[str]:
    errors = []
    def require(ok, message):
        if not ok:
            errors.append(message)
    require(type(data.get("checks")) is int and data["checks"] > 0, "positive check count")
    require(data.get("failures") == [], "probe failures must be empty")
    rows = data.get("rows", [])
    require(isinstance(rows, list) and len(rows) > 0, "nonempty motion rows")
    if not isinstance(rows, list):
        return errors
    names = [r.get("name") for r in rows if isinstance(r, dict)]
    require(len(names) == len(rows) == len(set(names)) and set(names) == expected, "exact unique move/side coverage")
    for row in rows:
        if not isinstance(row, dict):
            continue
        name = str(row.get("name"))
        frames = row.get("frames", [])
        require(isinstance(frames, list) and len(frames) >= 3 and row.get("ended") is True, name + ": completed nonempty frames")
        if not isinstance(frames, list) or not frames:
            continue
        ticks = [f.get("tick") for f in frames]
        require(all(type(t) is int for t in ticks) and all(b == a + 1 for a, b in zip(ticks, ticks[1:])), name + ": contiguous physics ticks")
        require({0, 1, 2, 3}.issubset({f.get("phase") for f in frames}), name + ": all phases and return")
        require(all(isinstance(f.get("angles"), dict) and f["angles"] and all(isinstance(a, (int, float)) and math.isfinite(a) for a in f["angles"].values()) for f in frames), name + ": finite actual bone observations")
        results = row.get("results", {})
        require(METRICS.issubset(results), name + ": every metric present")
        for key in METRICS:
            value = results.get(key, {})
            number, limit = value.get("value"), value.get("limit")
            require(type(number) in (int, float) and type(limit) in (int, float) and math.isfinite(number) and limit == LIMITS[key] and number <= limit, name + ": metric " + key)
        if all(isinstance(f.get("angles"), dict) and f["angles"] for f in frames):
            try:
                pop = max(abs((current["angles"][bone] - previous["angles"][bone] + math.pi) % (2 * math.pi) - math.pi) / 2.2 for previous, current in zip(frames, frames[1:]) for bone in current["angles"])
                require(math.isfinite(pop) and pop <= LIMITS["angle_pop"] and abs(pop - results.get("angle_pop", {}).get("value", math.inf)) < 1e-5, name + ": independently recalculated angle changes")
            except (TypeError, KeyError, ValueError):
                require(False, name + ": incomplete actual angle trace")
        require(row.get("path_samples", 0) > 0 and row.get("palm_max", math.inf) <= 1 and row.get("second_max", math.inf) <= 1.5 and row.get("second_missed") == 0, name + ": measured grips")
        if row.get("held"):
            require(row.get("released") is True and any(f.get("held_input") is True and f.get("hold_mode") for f in frames) and frames[-1].get("held_input") is False, name + ": actual held input and release")
        if native:
            for frame in frames:
                relative = frame.get("image", "")
                path = (directory / relative).resolve()
                require(bool(relative) and path.is_relative_to(directory.resolve()), name + ": image path stays in evidence")
                for image, rect in [(path, frame.get("crop")), (path.with_name(path.stem + "-hands.png"), frame.get("hands_crop"))]:
                    try:
                        header = image.read_bytes()[:24]
                        size = struct.unpack(">II", header[16:24])
                        require(header[:8] == b"\x89PNG\r\n\x1a\n" and isinstance(rect, list) and len(rect) == 4 and size == tuple(rect[2:]) and min(size) > 0, name + ": unscaled native image geometry")
                    except (OSError, ValueError, struct.error):
                        require(False, name + ": missing or invalid native image")
    if native:
        require(data.get("renderer") == "forward_plus" and data.get("display") != "headless" and bool(data.get("adapter")), "real native Forward+ renderer")
    return errors


def verify_feedback(data: dict, expected: set[str], events: dict) -> list[str]:
    errors = []
    if type(data.get("checks")) is not int or data["checks"] <= 0 or data.get("failures") != []:
        errors.append("nonempty passing feedback checks required")
    rows = data.get("rows", [])
    if not isinstance(rows, list):
        return errors + ["feedback rows must be an array"]
    names = [r.get("name") for r in rows if isinstance(r, dict)]
    if not expected or len(names) != len(rows) or len(names) != len(set(names)) or set(names) != expected:
        errors.append("exact unique contact/mode/side coverage")
    for row in rows:
        if not isinstance(row, dict):
            continue
        name = str(row.get("name"))
        hits = row.get("hits", [])
        frames = row.get("frames", [])
        if not hits or not frames or not row.get("first_observed_pair_freeze"):
            errors.append(name + ": actual contact and first-frame pair freeze required")
            continue
        hit = hits[0]
        if not hit.get("attacker") or not hit.get("freeze_attacker") or not isinstance(hit.get("amount"), (int, float)) or hit["amount"] <= 0:
            errors.append(name + ": actual attacker/damage required")
        first = next((f for f in frames if f.get("tick", -1) >= hit.get("tick", math.inf)), {})
        if not first.get("player_frozen") or not first.get("enemy_frozen"):
            errors.append(name + ": observed first contact must freeze both actors")
        layers = row.get("expected_layers", [])
        if len(layers) != 2 or len(set(layers)) != 2:
            errors.append(name + ": distinct declared low/high layers required")
        for layer in layers:
            groups = [part.get("sounds", []) for part in events[layer].get("layers", [])] if layer in events else [[layer]]
            if not groups or any(not group or not any(leaf in row.get("played", []) for leaf in group) for group in groups):
                errors.append(name + ": missing resolved sound layer " + layer)
    return errors
