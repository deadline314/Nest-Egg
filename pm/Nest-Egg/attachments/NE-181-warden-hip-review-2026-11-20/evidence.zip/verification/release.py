from pathlib import Path
from subprocess import run
from shutil import copyfile
import json
import os
import sys

base = Path(__file__).resolve().parent
shared = base.parent/'ne218-baseline-20261117'
root=Path.cwd()
python = Path(sys.executable)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def render(case, scene, args, fixed):
    out=base/case
    out.mkdir(exist_ok=False)
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        var = out/'profile'/key
        var.mkdir(parents=True)
        env[key]=str(var)
    command = [str(python),str(shared/'tools/comfyui/gpu_lock.py'),'--',engine,
               '--path',str(shared),'--resolution','1280x720','--position','10,90',
               '--rendering-method','forward_plus','--rendering-driver','vulkan']
    if fixed:
        command.extend(('--fixed-fps','60'))
    command.append(str(scene))
    command.extend(('--',*[a.replace('{out}',out.as_posix()) for a in args]))
    (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=650)
    (out/'exit.txt').write_text(str(result.returncode)+'\n',encoding='utf-8')
    raw=(out/'raw.log').read_text(encoding='utf-8')
    print(case,result.returncode,len(raw),flush=True)
    assert result.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw
    return raw





def check(out):
    with (out/'checker.log').open('wb') as log:
        status=run([str(python),str(root/'tools/check_joint_frames.py'),str(out)],cwd=root,stdout=log,stderr=log,timeout=240)
    (out/'checker-exit.txt').write_text(str(status.returncode)+'\n',encoding='utf-8')
    raw=(out/'checker.log').read_text(encoding='utf-8',errors='replace').splitlines()
    print(out.name,status.returncode,'; '.join(raw[:2]),flush=True)
    assert (out/'report.json').is_file()



case='actual-negative-control'
render(case,base/'body-only.tscn',
       ['--out={out}','--chars=warden','--joints=waist,hip_front,hip_back',
        '--frames=12','--zooms=3.4','--diagnostic-whole-rig','--displace-part=pelvis'],False)
check(base/case)
render('poses','res://tools/rig_preview.tscn',
       ['--out={out}/heavy-warden.png','--chars=heavy_gunner,warden','--zoom=2.2','--bright'],True)
render('warden-battle','res://tools/screenshot.tscn',['--out={out}','--scenario=warden_core'],True)
render('warden-stage','res://tools/screenshot.tscn',['--out={out}','--scenario=cutscenes:cut_c2_hangar'],True)
