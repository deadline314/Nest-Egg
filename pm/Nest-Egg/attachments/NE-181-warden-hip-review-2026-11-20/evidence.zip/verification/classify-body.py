from functools import lru_cache
from pathlib import Path
from collections import Counter
import json

import numpy as np
from PIL import Image
from scipy.ndimage import binary_fill_holes

base=Path(__file__).resolve().parent
art=base.parent/'evidence-20261120-ne181-review'/'natural-dead-waist-hips'
excluded=base/'warden-body'
read=lambda p:json.loads(p.read_bytes())
original=read(art/'report.json')
data=read(excluded/'frames.json')[0]
assert data['pose']=='dead' and data['zoom']==3.4
pins={(c['char'],c['joint'],c['facing']):c for c in data['cells']}

@lru_cache(maxsize=4)
def alpha(folder,name):
    return np.asarray(Image.open(folder/name).convert('RGBA'))[:,:,3]

def coverage(folder,name,cell):
    x,y,w,h=cell['rect']
    r=cell['radius']
    cx,cy=x+w//2,y+h//2
    return alpha(folder,name)[cy-r:cy+r,cx-r:cx+r]>=128

counts=Counter()
unresolved=[]
probes={}
for row in original['failures']:
    if row['char']!='warden' or not row['enclosed_pixels']:
        continue
    assert row['zoom']==3.4 and row['pose']=='dead'
    key=row['char'],row['joint'],row['facing']
    a=coverage(art,row['file'],row)
    where=binary_fill_holes(a,structure=np.ones((3,3))) & ~a
    assert int(where.sum())==row['enclosed_pixels']
    b=coverage(excluded,row['file'],pins[key])
    remains=binary_fill_holes(b,structure=np.ones((3,3))) & ~b & where
    if remains.any():
        unresolved.append({'asset':row['char'],'joint':row['joint'],'frame':row['file'],'face':row['facing'],'pixels':int(remains.sum())})
    counts[(row['char'],'original_cells')]+=1
    counts[(row['char'],'old_pixels')]+=int(where.sum())
    counts[(row['char'],'still_enclosed')]+=int(remains.sum())
    probes.setdefault(row['char'],row['file'])
out={skin:{metric:counts[skin,metric] for metric in ('original_cells','old_pixels','still_enclosed')} for skin in ('warden',)}
report={'native_shape_counts':out,'unresolved':unresolved,'example_files':probes}
(base/'shape-classification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(report['native_shape_counts'],unresolved[:4])
