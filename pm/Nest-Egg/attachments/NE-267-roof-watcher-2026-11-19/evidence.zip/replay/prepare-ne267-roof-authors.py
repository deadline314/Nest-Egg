from pathlib import Path
import hashlib
import json

root = Path.cwd()
base = Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118/roof-watcher-v7')
out = base / 'author-files'
out.mkdir()


def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


stage_name = 'tools/story/ch2_stages.py'
story_name = 'tools/story/ch2_source.py'
stages = (root / stage_name).read_text(encoding='utf-8')
stages = replace(stages, 'from dataclasses import dataclass\n', 'from dataclasses import dataclass, replace\n')
stages = replace(stages, 'import market_pass_staging\n', 'import market_pass_staging\nimport roof_watcher_staging\n')
stages = replace(stages, 'STAGES = (LEDGER, BOOTH, COLLECTION, PAWNSHOP, RENT_WINDOW, MEDIC_LEDGER, MARKET_PASS)', '''# S22 沿用同一屋頂景色，換成遠樓的落腳高度。
ROOF_WATCHER = replace(derived(
    roof_watcher_staging.STAGE, "ch1_rooftop", roof_watcher_staging.layers(),
    scale=roof_watcher_staging.SCALE, shot=roof_watcher_staging.SHOT), floor=roof_watcher_staging.FLOOR)

STAGES = (LEDGER, BOOTH, COLLECTION, PAWNSHOP, RENT_WINDOW, MEDIC_LEDGER, MARKET_PASS, ROOF_WATCHER)''')
story = (root / story_name).read_text(encoding='utf-8')
story = replace(story, 'import market_pass_staging  # noqa: E402\n',
                'import market_pass_staging  # noqa: E402\nimport roof_watcher_staging  # noqa: E402\n')
story = replace(story, '''    # NE-267: the unnamed grey-coat stands on the far roof as a small distant figure; no lines, no identity unlocked.
    source.add("ch2_t_s22_greycoat", "S22", steps=_roof_cast(0.25) + [
        dict(stage_actor("greycoat", "ch2_greycoat", 440, 130, facing=-1, scale=0.6), shade=0.42, backdrop=True)] + beats(''',
                '    watcher_lines = beats(')
story = replace(story, '''        ("lamp", "港區的通路都接上了，市場後門能回當舖街口。上層那條還沒通，明天得從廣場走。"),
        ("rin", "我先回去，老 K 留了飯。"),
        ("egret", "喝完再走，這次我真不追妳。")),
        mode="animated", completion=(set_flag("ch2_heron_closed"), set_flag("harbor_walk_ready")))''',
                '''        ("lamp", "港區的通路都接上了，市場後門能回當舖街口。上層那條還沒通，明天得從廣場走。"))
    closing_lines = beats(
        ("rin", "我先回去，老 K 留了飯。"),
        ("egret", "喝完再走，這次我真不追妳。"))
    reframe = dict(do="camera", pos=[320, 220], zoom=1.08, time=0.55, wait=True)
    source.add("ch2_t_s22_greycoat", "S22", steps=(
        _roof_cast(0.25) + watcher_lines[:1] + roof_watcher_staging.reveal_and_retreat()
        + _roof_cast(0.25) + watcher_lines[1:] + [reframe] + closing_lines),
        mode="animated", completion=(set_flag("ch2_heron_closed"), set_flag("harbor_walk_ready")))''')
paths = {
    stage_name: stages.encode(), story_name: story.encode(),
    'tools/story/roof_watcher_staging.py': (root / 'work/roof_watcher_staging.py').read_bytes(),
    'data/cutscene/stages/ch2_rooftop_watcher.json': (base / 'ch2_rooftop_watcher.json').read_bytes(),
    'data/story/ch2_heron.json': (base / 'ch2_heron.json').read_bytes(),
}
receipts = []
for name, payload in paths.items():
    path = out / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    original = root / name
    receipts.append({'path': name, 'before': hashlib.sha256(original.read_bytes()).hexdigest() if original.is_file() else None,
                     'after': hashlib.sha256(payload).hexdigest()})
(out / 'paths.json').write_text(json.dumps(receipts, indent=2) + '\n')
