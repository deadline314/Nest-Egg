from pathlib import Path
import dataclasses
import hashlib
import json
import sys

from PIL import Image

root = Path.cwd()
out = Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118') / sys.argv[1]
out.mkdir()
sys.path.insert(0, str(root / 'tools/story'))
from build_ch2_story import spec
from chapter_compiler import write_chapter
from ch2_source import _roof_cast
from ch2_stages import Stage
import roof_watcher_staging as watcher

old_stage = json.loads((root / 'data/cutscene/stages/ch1_rooftop.json').read_text(encoding='utf-8'))
layers = watcher.layers()
for layer in layers:
    with Image.open(root / layer['path'].removeprefix('res://')) as image:
        x, y, width, height = layer['region']
        assert image.width == layer['source_width'] and x + width <= image.width and y + height <= image.height
        if layer['id'] == watcher.UMBRELLA:
            assert image.convert('RGBA').getpixel(tuple(int(point) for point in watcher.GRIP))[3] >= 128
        elif layer['id'] == watcher.CLOSED:
            assert image.convert('RGBA').getpixel(tuple(int(point) for point in watcher.CLOSED_GRIP))[3] >= 128

stage = Stage(watcher.STAGE, floor=watcher.FLOOR, scale=watcher.SCALE, shot=watcher.SHOT,
              layers=tuple(old_stage['layers']) + layers)
(out / 'ch2_rooftop_watcher.json').write_text(json.dumps(stage.definition(), ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
identifier = 'ch2_t_s22_greycoat'
chapter = spec()
segment = chapter.source.segments[identifier]
spoken = [step for step in segment.steps if step['do'] == 'say']
assert len(spoken) == 5
reframe = {"do":"camera", "pos":[320, 220], "zoom":1.08, "time":0.55, "wait":True}
scene = tuple(_roof_cast(0.25) + [spoken[0]] + watcher.reveal_and_retreat() + _roof_cast(0.25) + spoken[1:3] + [reframe] + spoken[3:])
chapter.source.segments[identifier] = dataclasses.replace(segment, steps=scene)
assert not write_chapter(chapter, out / 'ch2_heron.json')
original = json.loads((root / 'data/story/ch2_heron.json').read_text(encoding='utf-8'))
new = json.loads((out / 'ch2_heron.json').read_text(encoding='utf-8'))
assert [key for key in original if new[key] != original[key]] == ['scenes']
assert [name for name in original['scenes'] if original['scenes'][name] != new['scenes'][name]] == [identifier]
old, new = original['scenes'][identifier], new['scenes'][identifier]
assert all(value == new[key] for key,value in old.items() if key != 'steps')
assert [step for step in new['steps'] if step['do'] == 'say'] == [step for step in old['steps'] if step['do'] == 'say']
(out / 'receipt.json').write_text(json.dumps({'changed': identifier, 'same_effects': True,
    'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()}}, indent=2) + '\n')
