extends Node2D

const ID := &"ch2_t_s22_greycoat"
const UMBRELLA := &"watcher_black_umbrella"
const CLOSED := &"watcher_closed_umbrella"
const SHAFT := Vector2(158.5, 171.5)
const CLOSED_SHAFT := Vector2(54.5, 53.5)
const Capture := preload("res://tools/viewport_capture.gd")


func _ready() -> void:
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	var issues := PackedStringArray()
	var scene: Dictionary = Story._scenes[ID]
	issues.append_array(CutsceneChecker.validate(ID, scene, Story._speakers))
	issues.append_array(CutsceneChecker.staging_problems(ID, scene))
	var original := GameState.world_flags.duplicate(true)
	var player := CutscenePlayer.new()
	add_child(player)
	if issues.is_empty():
		player.play(ID, scene)
	var shots := {}
	var distance: Array[float] = []
	var closed_distance: Array[float] = []
	var phase_x := []
	var started := Time.get_ticks_msec()
	var pending := ""
	var lines: Array[String] = []
	var next_dialogue := started
	while is_instance_valid(player) and player.is_running() and Time.get_ticks_msec() - started < 18000:
		await RenderingServer.frame_post_draw
		if not is_instance_valid(player):
			break
		var stage := player._stage
		var actor := player._actors.get(&"greycoat") as CutsceneActor
		if actor == null and shots.has("door") and not shots.has("inside") and stage != null and stage.prop_node(CLOSED) != null:
			shots["inside"] = get_viewport().get_texture().get_image()
		if stage != null and actor != null and (stage.prop_held(UMBRELLA) or stage.prop_held(CLOSED)):
			var is_closed := stage.prop_held(CLOSED)
			var umbrella := stage.prop_node(CLOSED if is_closed else UMBRELLA) as StageLayers._Sprite
			var prop_point := stage.to_local(umbrella.to_global(umbrella.source_point(CLOSED_SHAFT if is_closed else SHAFT)))
			var palm := stage.to_local(actor.hand_contact_global(&"front"))
			if is_closed:
				closed_distance.append(prop_point.distance_to(palm))
			else:
				distance.append(prop_point.distance_to(palm))
			phase_x.append(actor.position.x)
			var phase := "watch" if actor.position.x < 522 else "walk" if actor.position.x > 539 and actor.position.x < 548 else "door" if is_closed and actor.position.x >= 568 else "folded" if is_closed else ""
			if not phase.is_empty() and not shots.has(phase):
				shots[phase] = get_viewport().get_texture().get_image()
		if player._dialogue.visible and not player._dialogue._text.text.is_empty():
			var text: String = player._dialogue._text.text
			if not pending.is_empty():
				shots[pending] = get_viewport().get_texture().get_image()
				pending = ""
			elif not lines.has(text):
				player._dialogue.complete()
				lines.append(player._dialogue._text.text)
				pending = "dialogue-%d" % lines.size()
				next_dialogue = Time.get_ticks_msec() + 400
			if Time.get_ticks_msec() > next_dialogue:
				player._advance_requested = true
	for phase in ["watch", "walk", "folded", "door", "inside"]:
		if not shots.has(phase):
			issues.append("S22 missing actual silhouette phase " + phase)
	if distance.is_empty() or distance.max() > StagePropHold.CONTACT_TOLERANCE:
		issues.append("S22 umbrella shaft exceeds the original palm tolerance")
	if closed_distance.is_empty() or closed_distance.max() > StagePropHold.CONTACT_TOLERANCE:
		issues.append("S22 closed umbrella exceeds the original palm tolerance")
	if GameState.world_flags != original or lines.size() != 5:
		issues.append("S22 presentation changed results or dropped lines")
	for name: String in shots:
		var raw: Image = shots[name]
		FileAccess.open(out.path_join(name + ".raw"), FileAccess.WRITE).store_buffer(raw.get_data())
		if Capture.encode(raw, get_viewport().use_hdr_2d).save_png(out.path_join(name + ".png")) != OK:
			issues.append("Cannot save " + name)
	FileAccess.open(out.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify({
		"adapter": RenderingServer.get_video_adapter_name(), "contact": distance, "closed_contact": closed_distance, "actor_x": phase_x,
		"lines": lines, "images": shots.keys(), "issues": issues}, "\t"))
	if is_instance_valid(player) and player.is_running():
		player.skip()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if issues.is_empty() else 1)
