extends "res://tools/ch2_flow_probe.gd"
## Replay the original rooftop level, actor and ending selection through both Sunday branches.

var _count := 0


func _check(ok: bool, detail: String) -> void:
	_count += 1
	super._check(ok, detail)


func _run() -> void:
	var known := "--known-sunday" in OS.get_cmdline_user_args()
	var skip_watcher := "--skip-watcher" in OS.get_cmdline_user_args()
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip = false
	_carry_ch1_results()
	# Arrange only the already-returned, already-submitted preconditions for S22.
	for flag: StringName in [&"ch2_brief_done", &"ch2_audit_submitted", &"ch2_egret_returned"]:
		GameState.set_flag(flag)
	if known:
		GameState.set_flag(&"sq2_sunday_heard")
	await _enter("rooftop")
	var area := _level
	var completions := [0]
	area.completed.connect(func() -> void: completions[0] += 1)
	var scenes: Array[StringName] = []
	Story.scene_started.connect(func(id: StringName, _mode: StringName) -> void:
		scenes.append(id)
		if skip_watcher and id == &"ch2_t_s22_greycoat":
			Story.skip_cinematic.call_deferred())
	var credits := Progression.credits
	_check(_object(&"ch2_egret") != null and not GameState.has_flag(&"ch2_heron_closed"), "the real rooftop is available with its original unfinished ending")
	await _talk(&"ch2_egret", ["wait"])
	_check(scenes == [&"ch2_t_s22_tea"] and completions[0] == 0, "drinking first returns control to the existing rooftop")
	_check(not GameState.has_flag(&"ch2_heron_closed") and not GameState.has_flag(&"harbor_walk_ready"), "waiting does not publish either ending result")
	scenes.clear()
	await _talk(&"ch2_egret", ["go"])
	for frame in STEP_LIMIT:
		if completions[0] > 0:
			break
		await _settle(2)
	await _settle(120)
	var branch := &"ch2_t_s22_sunday_known" if known else &"ch2_t_s22_sunday_unknown"
	_check(scenes == [&"ch2_t_s22_tea", &"ch2_t_s22_decided", branch, &"ch2_t_s22_greycoat"], "the expected Sunday branch flows into the same existing watcher scene: " + str(scenes))
	_check(Story._completed.has(&"ch2_t_s22_greycoat") and GameState.has_flag(&"ch2_heron_closed") and GameState.has_flag(&"harbor_walk_ready"), "ending writes the original complete and harbor flags")
	_check(completions[0] == 1 and Progression.credits == credits, "the real rooftop hands off the chapter once without new payment: %s, %d" % [completions, Progression.credits - credits])
	_check(Story.resolve_dispatch(&"ch2_dispatch_egret") == &"ch2_t_s22_revisit", "the original revisit is still offered after closure")
	FileAccess.open(_out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify({
		"checks": _count, "failures": _failures, "known_sunday": known, "skip_watcher": skip_watcher,
		"scenes": scenes, "level_completions": completions[0]}, "\t"))
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures == 0 else 1)
