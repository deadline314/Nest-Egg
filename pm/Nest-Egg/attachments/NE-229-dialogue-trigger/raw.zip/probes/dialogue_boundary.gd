extends "res://tests/smoke_test.gd"

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	await preload("res://work/batch1024/dialogue_boundary_checks.gd").run(CutsceneSuite.new(self))
	print("FOCUSED CHECKS COMPLETE")
	_finish()
