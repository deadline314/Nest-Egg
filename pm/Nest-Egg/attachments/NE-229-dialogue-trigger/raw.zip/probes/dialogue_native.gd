extends "res://tests/smoke_test.gd"
var _out := ""
var _states: Dictionary = {}
func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 get_window().size = Vector2i(1280,720)
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
 await preload("res://work/batch1024/dialogue_native_checks.gd").run(CutsceneSuite.new(self))
 var file := FileAccess.open(_out.path_join("states.json"),FileAccess.WRITE)
 file.store_string(JSON.stringify(_states,"  "))
 file.close()
 await _finish()
func capture_state(id: String, owner: Object, step: int, active: bool) -> void:
 _states[id] = {"step":step,"active":active,"valid":is_instance_valid(owner)}
 await RenderingServer.frame_post_draw
 get_viewport().get_texture().get_image().save_png(_out.path_join(id+".png"))
