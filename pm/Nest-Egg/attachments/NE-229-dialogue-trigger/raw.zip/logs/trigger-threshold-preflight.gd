extends SceneTree
func _initialize() -> void:
 InputMap.add_action(&"threshold_probe",0.5)
 var binding := InputEventJoypadMotion.new()
 binding.axis = JOY_AXIS_TRIGGER_RIGHT
 binding.axis_value = 1.0
 InputMap.action_add_event(&"threshold_probe",binding)
 for value: float in [0.499,0.5,0.501]:
  var event := InputEventJoypadMotion.new()
  event.axis = JOY_AXIS_TRIGGER_RIGHT
  event.axis_value = value
  print("THRESHOLD ",value," pressed=",event.is_action_pressed(&"threshold_probe"))
 quit()
