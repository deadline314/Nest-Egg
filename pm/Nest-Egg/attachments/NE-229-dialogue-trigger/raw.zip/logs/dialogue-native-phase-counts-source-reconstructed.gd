# Reconstructed from preserved V3 base and recorded edit instructions; not an originally saved debug source.
extends RefCounted
## Real dialogue owners, public analog events; not physical-controller acceptance.
static func run(s: TestSuite) -> void:
	var layer := DialogueLayer.new()
	s.runner.add_child(layer)
	await s.frames(1)
	var lines: Array[Dictionary] = [
		{"name": "Rin", "color": Color.WHITE, "portrait": "", "text": "First line stays until a second press."},
		{"name": "Rin", "color": Color.WHITE, "portrait": "", "text": "Second line."},
	]
	_axis(0.0)
	layer.start_cinematic(&"test_trigger_dialogue", lines)
	_axis(0.9)
	s.check(layer._text.visible_ratio == 1.0 and layer._cinematic_index == 0, "first trigger press reveals the current dialogue line")
	for value: float in [InputMap.action_get_deadzone(&"shoot"), 0.92, 0.8, 1.0, 0.85]:
		_axis(value)
	await s.runner.capture_state("dialogue-held", layer, layer._cinematic_index, layer.is_cinematic_active())
	s.check(layer.is_cinematic_active() and layer._cinematic_index == 0, "held trigger variation cannot advance or finish cinematic dialogue")
	_axis(0.0)
	_axis(0.95)
	s.check(layer._cinematic_index == 1, "releasing then pressing advances dialogue exactly once")
	layer.cancel_cinematic()
	_axis(0.0)
	layer.queue_free()
	await s.frames(1)

	var player := CutscenePlayer.new()
	s.runner.add_child(player)
	player.play(&"test_trigger_cutscene", {"overlay": true, "steps": [
		{"do": "say", "speaker": "rin", "text": "First animated line waits for another press."},
		{"do": "say", "speaker": "rin", "text": "Second animated line."},
	]})
	await s.frames(2)
	_axis(0.9)
	s.check(player._dialogue.is_complete() and player.steps_run == 0, "first trigger press reveals the animated line")
	for value: float in [InputMap.action_get_deadzone(&"shoot"), 0.92, 0.8, 1.0, 0.85]:
		_axis(value)
		await s.frames(1)
	await s.runner.capture_state("animated-held", player, player.steps_run if is_instance_valid(player) else -1, player.is_running() if is_instance_valid(player) else false)
	s.check(is_instance_valid(player) and player.is_running() and player.steps_run == 0 and not player._advance_requested, "held trigger variation cannot request the next animated line")
	var phase_process_before := Engine.get_process_frames()
	var phase_physics_before := Engine.get_physics_frames()
	print("NATIVE_POSTDRAW_BEFORE ", player._shoot_press._axes, " request=", player._advance_requested)
	_axis(0.0)
	print("NATIVE_POSTDRAW_RELEASE ", player._shoot_press._axes, " request=", player._advance_requested)
	_axis(0.95)
	print("NATIVE_POSTDRAW_PRESS ", player._shoot_press._axes, " request=", player._advance_requested)
	await s.frames(2)
	print("NATIVE_PHASE_COUNTS process=", Engine.get_process_frames()-phase_process_before, " physics=", Engine.get_physics_frames()-phase_physics_before)
	print("NATIVE_POSTDRAW_AFTER ", player._shoot_press._axes, " request=", player._advance_requested, " steps=", player.steps_run, " where=", player._current_where)
	s.check(is_instance_valid(player) and player.is_running() and player.steps_run == 1, "a new trigger press advances to the second animated line")
	_axis(0.0)
	if is_instance_valid(player):
		player.cancel()
	await s.frames(2)
	InputBindings.clear_held_inputs()

static func _axis(value: float) -> void:
	var event := InputEventJoypadMotion.new()
	event.axis = JOY_AXIS_TRIGGER_RIGHT
	event.axis_value = value
	Input.parse_input_event(event)
	Input.flush_buffered_events()
