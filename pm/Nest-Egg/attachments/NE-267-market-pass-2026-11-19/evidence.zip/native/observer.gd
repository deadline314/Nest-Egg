extends Node2D

const SCENE_ID := &"ch2_t_s05_gate"
const PASS := &"public_aisle_pass"
const CAPTURE := preload("res://tools/viewport_capture.gd")
const CARD_CONTACTS := {&"rin": Vector2(138.5, 287.5), &"patroller": Vector2(246.5, 264.5)}


func _ready() -> void:
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	var failures := PackedStringArray()
	var definition: Dictionary = Story._scenes[SCENE_ID]
	failures.append_array(CutsceneChecker.validate(SCENE_ID, definition, Story._speakers))
	failures.append_array(CutsceneChecker.staging_problems(SCENE_ID, definition))
	var flags := GameState.world_flags.duplicate(true)
	var credits := Progression.credits
	var player := CutscenePlayer.new()
	add_child(player)
	if failures.is_empty():
		player.play(SCENE_ID, definition)
	var shots := {}
	var contacts := {&"rin": [], &"patroller": []}
	var lines: Array[String] = []
	var start := Time.get_ticks_msec()
	var line_start := start
	var pending_capture := ""
	while is_instance_valid(player) and player.is_running() and Time.get_ticks_msec() - start < 18000:
		await RenderingServer.frame_post_draw
		if not is_instance_valid(player):
			break
		var stage := player._stage
		if stage == null:
			continue
		var card := stage.prop_node(PASS) as StageLayers._Sprite
		var guard := player._actors.get(&"patroller") as CutsceneActor
		if card != null and card.visible and stage.prop_held(PASS):
			var held := true
			for role in CARD_CONTACTS:
				var actor := player._actors.get(role) as CutsceneActor
				if actor == null or not actor.hand_target_settled(&"front"):
					held = false
					continue
				var card_point := card.to_global(card.source_point(CARD_CONTACTS[role]))
				var palm := actor.hand_contact_global(&"front")
				var gap := stage.to_local(card_point).distance_to(stage.to_local(palm))
				contacts[role].append(gap)
			if held and not shots.has("inspection"):
				shots["inspection"] = get_viewport().get_texture().get_image()
		if guard != null and guard.position.x > 423.9 and card != null and not card.visible and not shots.has("cleared"):
			shots["cleared"] = get_viewport().get_texture().get_image()
		if player._dialogue.visible and not player._dialogue._text.text.is_empty():
			var text: String = player._dialogue._text.text
			if not pending_capture.is_empty():
				shots[pending_capture] = get_viewport().get_texture().get_image()
				pending_capture = ""
			elif not lines.has(text):
				player._dialogue.complete()
				text = player._dialogue._text.text
				lines.append(text)
				pending_capture = "line-%d" % lines.size()
				line_start = Time.get_ticks_msec()
			if Time.get_ticks_msec() - line_start > 400:
				player._advance_requested = true
	if not shots.has("inspection") or not shots.has("cleared") or lines.size() != 3:
		failures.append("Missing actual S05 phases or dialogue")
	for role in contacts:
		if (contacts[role] as Array).is_empty() or float(contacts[role].max()) > StagePropHold.CONTACT_TOLERANCE:
			failures.append("S05 actor contact misses actual card: %s" % role)
	if flags != GameState.world_flags or credits != Progression.credits:
		failures.append("Direct presentation changed campaign results")
	for name: String in shots:
		var raw: Image = shots[name]
		FileAccess.open(out.path_join(name + ".raw"), FileAccess.WRITE).store_buffer(raw.get_data())
		if CAPTURE.encode(raw, get_viewport().use_hdr_2d).save_png(out.path_join(name + ".png")) != OK:
			failures.append("Cannot save S05 frame %s" % name)
	FileAccess.open(out.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify({
		"adapter": RenderingServer.get_video_adapter_name(), "contacts": contacts, "lines": lines,
		"shots": shots.keys(), "failures": failures}, "\t"))
	if is_instance_valid(player) and player.is_running():
		player.skip()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures.is_empty() else 1)
