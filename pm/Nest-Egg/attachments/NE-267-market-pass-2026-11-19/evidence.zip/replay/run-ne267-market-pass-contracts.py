from pathlib import Path
import hashlib
import json
import shutil
import sys

root = Path.cwd()
base = Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118')
runtime = base / 'runtime-ownership-v7'
unit = base / 'market-pass-v4'
out = unit / 'patroller-contracts'
out.mkdir()
sys.path.insert(0, str(runtime / 'tools'))
from run_patroller_completion import CASES, EXPECTED_DIAGNOSTICS, SOURCES
from runtime_probe import run_case, write_json

engine = Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
story = 'data/story/ch2_heron.json'
contract = 'data/story_contracts/ch2.json'
stage = 'data/cutscene/stages/ch2_market_pass.json'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
author = unit / 'author-files'
baseline = {story: (root / story).read_bytes(), contract: (root / contract).read_bytes()}
staged = {name: (author / name).read_bytes() for name in (story, contract, stage)}
original = {name: (runtime / name).read_bytes() if (runtime / name).is_file() else None for name in staged}
assert original[stage] is None
stable = {name: sha(root / name) for name in SOURCES if name not in staged}
assert all(sha(runtime / name) == digest for name, digest in stable.items())
results = []

def record(label, mode, destination, slot, revised):
    names = (*stable, story, contract, *((stage,) if revised else ()))
    guard = {name: sha(runtime / name) for name in names}
    result = run_case(mode, engine, destination, 240, project=runtime, scene='res://tests/probes/patroller_completion.tscn',
                      slot=slot, verbose=True, expected_diagnostics=EXPECTED_DIAGNOSTICS.get(mode, ()))
    result['source_held'] = all(sha(runtime / name) == digest for name, digest in guard.items())
    result['source'] = guard
    result['edition'] = label
    results.append(result)
    write_json(out / 'receipt.json', {'cases':results})
    print(label, mode, result['passed'], result.get('result'), flush=True)
    assert result['passed'] and result['source_held'], result

try:
    for name, payload in baseline.items():
        (runtime / name).write_bytes(payload)
    before = out / 'before'
    before.mkdir()
    record('before', 'accepted', before, before / 'accepted', False)
    old = out / 'legacy'
    old.mkdir()
    shutil.copytree(before / 'accepted', old / 'accepted')
    for name, payload in staged.items():
        (runtime / name).write_bytes(payload)
    record('legacy', 'accepted_read', old, old / 'accepted', True)
    after = out / 'after'
    after.mkdir()
    for mode, slot in CASES:
        record('after', mode, after, after / slot, True)
finally:
    for name, payload in original.items():
        path = runtime / name
        if payload is None:
            assert path.resolve() == runtime.resolve() / name
            if path.is_file():
                assert path.read_bytes() == staged[name]
                path.unlink()
        else:
            path.write_bytes(payload)
