from pathlib import Path
import hashlib
import json

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
unit = Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118/market-pass-v4')
out = unit / 'author-files'
path = 'tests/fixtures/story_contracts_data_only/ch2.json'
sha = lambda value: hashlib.sha256(value).hexdigest()
before = (root / path).read_bytes()
assert (shared / path).read_bytes() == before
published = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118/restore85-integration/published-source.json')
assert json.loads(published.read_text())[path] == sha(before)
assert json.loads(before)['records'][0]['id'] == 'ch2_t_s05_gate'
needle = b'"mode": "dialogue"'
assert needle in before
after = before.replace(needle, b'"mode": "animated"', 1)
expected = json.loads(before)
expected['records'][0]['rule']['mode'] = 'animated'
assert json.loads(after) == expected
records = json.loads((out / 'paths.json').read_text())
assert path not in {item['path'] for item in records}
(out / path).parent.mkdir(parents=True, exist_ok=True)
with (out / path).open('xb') as result:
    result.write(after)
for project in (root, shared):
    (project / path).write_bytes(after)
records.append({'path':path,'before':sha(before),'after':sha(after)})
(out / 'paths.json').write_text(json.dumps(records, indent=2) + '\n')
