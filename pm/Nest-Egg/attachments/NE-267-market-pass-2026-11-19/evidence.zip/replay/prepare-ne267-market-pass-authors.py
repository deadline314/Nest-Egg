from pathlib import Path
import hashlib
import json

root = Path.cwd()
unit = Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118/market-pass-v4')
out = unit / 'author-files'
out.mkdir()

def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

story = root / 'tools/story/ch2_source.py'
stages = root / 'tools/story/ch2_stages.py'
story_text = story.read_text(encoding='utf-8')
stages_text = stages.read_text(encoding='utf-8')
story_text = replace(story_text, 'import medic_transport_staging  # noqa: E402\n',
                     'import medic_transport_staging  # noqa: E402\nimport market_pass_staging  # noqa: E402\n')
story_text = replace(story_text, 'RENT_WINDOW, MEDIC_LEDGER, Cast, Stage', 'RENT_WINDOW, MEDIC_LEDGER, MARKET_PASS, Cast, Stage')
story_text = replace(story_text, 'FORMAL_FRAMES = {\n', '''FORMAL_FRAMES = {
    "ch2_t_s05_gate": Frame(MARKET_PASS, (Cast("rin", 304, 1), Cast("patroller", 350, -1, kind="ch2_patroller")), True,
        ((0, market_pass_staging.inspect_steps()), (2, market_pass_staging.clear_steps()))),
''')
stages_text = replace(stages_text, 'import medic_transport_staging\n', 'import medic_transport_staging\nimport market_pass_staging\n')
stages_text = replace(stages_text, 'STAGES = (LEDGER, BOOTH, COLLECTION, PAWNSHOP, RENT_WINDOW, MEDIC_LEDGER)', '''# S05 查核證在市集濕路面上出示；背景中間的公眾攤道保持可見。
MARKET_PASS = Stage(
    "ch2_market_pass", floor=market_pass_staging.FLOOR, scale=market_pass_staging.ACTOR_SCALE, shot=(337, 243, 1.14),
    layers=({"kind": "gradient", "top": "#0a0614", "bottom": "#1a1024", "parallax": 0.0},
            background("neon_market", modulate="#b8b0c3"),
            {"kind": "glow", "pos": [325, 235], "radius": 160, "color": "#f9c28c", "intensity": 0.52,
             "additive": True, "alpha": 0.28, "pulse": 0.04, "pulse_depth": 0.12},
            market_pass_staging.layer(), {"kind": "rain", "depth": "front", "opacity": 0.28}))

STAGES = (LEDGER, BOOTH, COLLECTION, PAWNSHOP, RENT_WINDOW, MEDIC_LEDGER, MARKET_PASS)''')
paths = {
    'tools/story/ch2_source.py': story_text.encode(), 'tools/story/ch2_stages.py': stages_text.encode(),
    'tools/story/market_pass_staging.py': (root / 'work/market_pass_staging.py').read_bytes(),
    'data/story_contracts/ch2.json': (unit / 'contract.json').read_bytes(),
    'data/story/ch2_heron.json': (unit / 'ch2_heron.json').read_bytes(),
    'data/cutscene/stages/ch2_market_pass.json': (unit / 'ch2_market_pass.json').read_bytes(),
}
receipts = []
for name, payload in paths.items():
    path = out / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    original = root / name
    receipts.append({'path':name, 'before':hashlib.sha256(original.read_bytes()).hexdigest() if original.is_file() else None,
                     'after':hashlib.sha256(payload).hexdigest()})
(out / 'paths.json').write_text(json.dumps(receipts, indent=2) + '\n')
