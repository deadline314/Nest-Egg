from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118/market-pass-v4')
prior = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118/restore85-integration')
out = base / 'integration'
resuming = '--resume' in sys.argv
if not resuming:
    out.mkdir()
expected = json.loads((prior / 'publish/result.json').read_text())['commit']
published = json.loads((prior / 'published-source.json').read_text())
assert all(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=project).decode().strip() == expected for project in (root, shared))
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root).strip() == b'codex/ticket-work-20261119-ne267-market'

native = json.loads((base / 'native-subtitles/result.json').read_text())
assert native['exit'] == 0 and not native['errors'] and native['source_held']
app = json.loads((base / 'native-subtitles/report.json').read_text())
assert len(app['shots']) == 5 and not app['failures'] and '9070 XT' in app['adapter']
assert all(samples and max(samples) < 0.25 for samples in app['contacts'].values())
access = json.loads((base / 'patroller-contracts/receipt.json').read_text())['cases']
assert len(access) == 10 and all(case['passed'] and case['source_held'] for case in access)

source = base / 'author-files'
adoption = json.loads((source / 'paths.json').read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def snapshot(project, paths):
    return {name:sha(project / name) for name in paths}

def current(project, name):
    return sha(project / name) if (project / name).is_file() else None

if not resuming:
    assert snapshot(shared, published) == published
for row in adoption:
    name = row['path']
    assert sha(source / name) == row['after']
    expected_present = row['after'] if resuming else row['before']
    assert all(current(project, name) == expected_present for project in (root, shared)), (name, row)
    if name in native['source']:
        assert native['source'][name] == row['after']
    for case in access:
        if case['edition'] != 'before' and name in case['source']:
            assert case['source'][name] == row['after']
paths = [row['path'] for row in adoption]
guard = published | {row['path']:row['after'] for row in adoption}
if not resuming:
    for project in (root, shared):
        for name in paths:
            (project / name).write_bytes((source / name).read_bytes())
assert snapshot(shared, guard) == guard and snapshot(root, paths) == {name:guard[name] for name in paths}
(out / 'paths.json').write_text(json.dumps(paths, indent=2) + '\n')
(out / 'source.json').write_text(json.dumps(guard, indent=2) + '\n')

sys.path.insert(0, str(root / 'tools/story'))
from build_ch2_story import spec
from chapter_compiler import write_chapter
from ch2_stages import MARKET_PASS
missing = write_chapter(spec(), out / 'ch2_heron.json')
assert not missing and sha(out / 'ch2_heron.json') == guard['data/story/ch2_heron.json']
stage_out = out / 'ch2_market_pass.json'
stage_out.write_text(json.dumps(MARKET_PASS.definition(), ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
assert sha(stage_out) == guard['data/cutscene/stages/ch2_market_pass.json']

def run(name, command, cwd):
    destination = out / name
    destination.mkdir()
    env = os.environ.copy()
    env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', SHARDS='8', LOG_DIR=str(destination / 'shards'))
    for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
        env[key] = str(destination / 'profile' / key)
    (destination / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
    with (destination / 'raw.log').open('wb') as log:
        process = subprocess.run(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=2400)
    raw = (destination / 'raw.log').read_bytes()
    held = snapshot(shared, guard) == guard and snapshot(root, paths) == {name:guard[name] for name in paths}
    result = {'exit':process.returncode, 'errors':[line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line], 'source_held':held}
    (destination / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(name, result, raw.decode(errors='replace')[-1500:], flush=True)
    assert result == {'exit':0,'errors':[],'source_held':True}, result
    return result

run('compiler-v2', [sys.executable, '-B', '-X', 'utf8', '-m', 'unittest', 'test_chapter_completion_policies', 'test_story_contracts'], root / 'tools/story')
changed = ['C:/Program Files/Git/bin/bash.exe', '-c', f'python3() {{ python "$@"; }}; export -f python3; tools/run_tests_changed.sh {expected}']
result = run('official', changed, shared)
(out / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
