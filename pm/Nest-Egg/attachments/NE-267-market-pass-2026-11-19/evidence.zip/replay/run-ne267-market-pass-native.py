from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118')
runtime = base / 'runtime-ownership-v7'
roof = '--roof' in sys.argv
source = base / (sys.argv[sys.argv.index('--roof') + 1] if roof else 'market-pass-v4')
out = source / ('native' if roof else 'native-subtitles')
out.mkdir()
stage = 'ch2_rooftop_watcher.json' if roof else 'ch2_market_pass.json'
scope = f'data/cutscene/stages/{stage}'
mapping = {'data/story/ch2_heron.json': source / 'ch2_heron.json', scope:source / stage,
           'data/story_contracts/ch2.json': root / 'data/story_contracts/ch2.json' if roof else source / 'contract.json'}
if roof and (root / 'data/cutscene/stages/ch2_market_pass.json').is_file():
    market = 'data/cutscene/stages/ch2_market_pass.json'
    mapping[market] = root / market
observer = 'ne267-roof-watcher-probe.gd' if roof else 'ne267-market-pass-probe.gd'
known = ('game/cutscene/cutscene_player.gd', 'game/cutscene/cutscene_actor.gd', 'game/cutscene/stage_prop_binding.gd',
         'game/cutscene/stage_library.gd')
known += ('art/characters/ch2_greycoat/character.json', 'art/environment/scenes/rooftop.webp', 'art/environment/scene_props/suo_boat/suo_boat__boat_umbrella.png',
    'art/environment/scene_props/rooftop/rooftop__stairwell_hut.png') if roof else (
    'art/characters/ch2_patroller/character.json', 'art/items/icons/doc_stub_hd.png')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert all(sha(root / name) == sha(runtime / name) for name in known)
protected = {name: (runtime / name).read_bytes() if (runtime / name).is_file() else None for name in mapping}
assert protected[scope] is None
probe = out / 'observer.gd'
scene = probe.with_suffix('.tscn')
with probe.open('xb') as file:
    file.write((root / 'work' / observer).read_bytes())
with scene.open('x', encoding='utf-8', newline='\n') as file:
    file.write(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n[node name="MarketPass" type="Node2D"]\nscript = ExtResource("1")\n')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
cmd = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
       'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(runtime), '--audio-driver', 'Dummy',
       '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--resolution', '640x360',
       '--quit-after', '18000', scene.as_posix(), '--', '--out=' + str(out)]
(out / 'command.json').write_text(json.dumps(cmd, indent=2) + '\n')
try:
    for name, candidate in mapping.items():
        (runtime / name).write_bytes(candidate.read_bytes())
    guard = {name: sha(runtime / name) for name in (*mapping, *known)}
    with (out / 'raw.log').open('wb') as log:
        run = subprocess.run(cmd, cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    raw = (out / 'raw.log').read_bytes()
    receipt = {'exit': run.returncode, 'errors': [line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line or b'WARNING:' in line],
               'source_held': all(sha(runtime / name) == digest for name, digest in guard.items()), 'source': guard}
finally:
    for name, old in protected.items():
        path = runtime / name
        if old is None:
            assert path.resolve() == runtime.resolve() / name
            if path.is_file():
                assert path.read_bytes() == mapping[name].read_bytes()
                path.unlink()
        else:
            path.write_bytes(old)
    assert all((runtime / name).read_bytes() == old if old is not None else not (runtime / name).exists() for name, old in protected.items())
(out / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print({k:v for k,v in receipt.items() if k != 'source'}, raw.decode(errors='replace')[-1500:], flush=True)
assert receipt['exit'] == 0 and not receipt['errors'] and receipt['source_held']
