extends "res://tools/creature_preview.gd"


func _ready() -> void:
	super._ready()
	var center := get_viewport_rect().size * 0.5
	if _creatures.size() == 1:
		_creatures[0].position = center + Vector2(0.0, 26.0)
	if _worms.size() == 1:
		var camera := get_viewport().get_camera_2d()
		_worms[0].position = center / camera.zoom + Vector2(32.0, 0.0)
