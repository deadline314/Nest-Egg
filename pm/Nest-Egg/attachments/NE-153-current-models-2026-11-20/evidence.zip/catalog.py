from collections import defaultdict,Counter
from pathlib import Path
from hashlib import sha256
import json,re

root=Path.cwd()
base=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_bytes())
history=read(root/'pm/Nest-Egg/images/NE-153-review-20261009.json')
old={row['id']:row for row in history['models']}
defs={}
for name in sorted((root/'art/characters').glob('*/character.json')):
    if name.parent.name!='harbor_lamplighter_demo':
        defs[name.parent.name]=('human',name)
for name in sorted((root/'art/creatures').glob('*.json')):
    if name.stem=='test_creature':
        continue
    data=read(name)
    kind='PartCreature' if 'parts' in data else 'ChainCreature' if 'tentacles' in data else 'WormCreature'
    assert kind!='WormCreature' or 'segment' in data
    defs[name.stem]=(kind,name)
defs['bulwark']=('vehicle',root/'data/vehicles/bulwark.tres')
refs=defaultdict(set)
labels={}
for category,field in (('enemies',r'(?:rig_skin|creature_skin)'),('npcs','rig_id'),('vehicles','id')):
    for file in sorted((root/'data'/category).rglob('*.tres')):
        text=file.read_text(encoding='utf-8')
        match=re.search(rf'^{field}\s*=\s*&?"([^"]+)"',text,re.M)
        if match is None or match[1] not in defs:
            continue
        model=match[1]
        refs[model].add(file.relative_to(root).as_posix())
        name=re.search(r'^display_name\s*=\s*"([^"]+)"',text,re.M)
        if name is not None and (file.stem==model or model not in labels):
            labels[model]=name[1]

def actors(item):
    if isinstance(item,list):
        for entry in item:
            yield from actors(entry)
    if isinstance(item,dict):
        if item.get('do')=='actor' and item.get('kind') in defs:
            yield item['kind']
        for value in item.values():
            yield from actors(value)
story_head=(root/'autoload/story.gd').read_text(encoding='utf-8').split('const LEGACY_CHAPTER_PATHS',1)[0]
for chapter in re.findall(r'res://data/story/([A-Za-z0-9_]+)\.json',story_head):
    path=root/'data/story'/f'{chapter}.json'
    if not path.is_file():
        continue
    data=read(path)
    for model,value in data['speakers'].items():
        if model in defs and model not in labels and value.get('name'):
            labels[model]=value['name']
        portrait=Path(value.get('portrait','')).stem
        if portrait in defs and value.get('name'):
            labels.setdefault(portrait,value['name'])
    for scene,value in data['scenes'].items():
        for model in set(actors(value)):
            refs[model].add(f'{path.relative_to(root).as_posix()}#{scene}')
labels.setdefault('ch2_greycoat','灰衣人')
refs['rin'].add('game/player/player_visual.gd')
level_binding={}
for file in sorted((root/'data/levels').glob('*.tres')):
    text=file.read_text(encoding='utf-8')
    refs_in_level=set(re.findall(r'path="res://(data/(?:enemies|npcs|vehicles)/[^"]+\.tres)"',text))
    if refs_in_level:
        level_binding[file.relative_to(root).as_posix()]=refs_in_level
result=[]
for model,(kind,path) in defs.items():
    result.append({'id':model,'name':old.get(model,{}).get('name') or labels.get(model,model),
         'type':kind,'definition':path.relative_to(root).as_posix(),
         'definition_sha256':sha256(path.read_bytes()).hexdigest(),
         'usage_refs':sorted(refs.get(model,[])),
         'level_resource_refs':[level for level,paths in level_binding.items() if paths.intersection(refs.get(model,[]))]})
assert len({r['id'] for r in result})==len(result)
assert set(old)<=set(defs)
(base/'catalog-draft.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(result),dict(Counter(r['type'] for r in result)))
print('historical additions',len(set(defs)-set(old)))
print('without recognized runtime ref',[(r['id'],r['name']) for r in result if not r['usage_refs']])
