from pathlib import Path
from collections import Counter
from hashlib import sha256
from itertools import batched
from PIL import Image, ImageDraw, ImageFont
import json

import numpy as np

base=Path(__file__).resolve().parent
out=base/'review-draft'
out.mkdir(exist_ok=True)
raw=json.loads((base/'gallery-progress.json').read_bytes())
models=json.loads((base/'catalog-draft.json').read_bytes())
assert len(raw)==len(models)==63
index={row['id']:row for row in models}
font=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc',22)
compact=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc',18)
ink='#f6f2f7'
canvas='#20212c'
archive={}
groups=set()

def center_label(draw,bounds,y,value,style=font):
    left,w=bounds
    size=draw.textlength(value,font=style)
    assert size<w-16,value
    draw.text((round(left+(w-size)/2),y),value,font=style,fill=ink)

def record(id,file,rect):
    index[id]['review_image']=file
    index[id]['review_box']=rect

human=[row for row in models if row['type']=='human']
for row in human:
    entry=raw[row['id']]
    group=entry['group']
    if group in groups:
        continue
    groups.add(group)
    file=base/entry['raw']
    assert sha256(file.read_bytes()).hexdigest()==entry['sha256']
    image=Image.open(file).convert('RGB')
    assert image.size==(1280,720)
    view=Image.new('RGB',(1280,772),canvas)
    view.paste(image,(0,0))
    draw=ImageDraw.Draw(view)
    for n,id in enumerate(entry['ids']):
        layout=(n*320,320)
        center_label(draw,layout,730,index[id]['name'] or id)
        record(id,group+'.png',[n*320,0,320,720])
    view.save(out/(group+'.png'))
    archive[entry['raw']]=file

def visible_crop(im):
    values=np.array(im,dtype=np.int16)
    edged=np.zeros((im.height,im.width),dtype=bool)
    edged[:,1:] |= np.max(np.abs(np.diff(values,axis=1)),axis=2)>=16
    edged[1:,:] |= np.max(np.abs(np.diff(values,axis=0)),axis=2)>=16
    edged[:12]=False
    edged[-12:]=False
    edged[:,:12]=False
    edged[:,-12:]=False
    y,x=np.nonzero(edged)
    assert len(x)>=55,len(x)
    assert min(x.min(),y.min())>=20 and x.max()<im.width-20 and y.max()<im.height-20, (x.min(),y.min(),x.max(),y.max())
    pad=45
    rect=[max(0,int(x.min())-pad),max(0,int(y.min())-pad),
          min(im.width,int(x.max())+pad+1),min(im.height,int(y.max())+pad+1)]
    return im.crop(rect), rect

creatures=[row for row in models if row['type'] not in ('human','vehicle')]
for page,items in enumerate(batched(creatures,6),1):
    name=f'creatures-{page:02}.png'
    img=Image.new('RGB',(1260,694),canvas)
    draw=ImageDraw.Draw(img)
    for n,row in enumerate(items):
        id=row['id']
        entry=raw[id]
        path=base/entry['raw']
        lit=base/f'lit-{id}/preview.png'
        alt=lit.is_file()
        if alt:
            path=lit
        key=path.relative_to(base).as_posix()
        archive[key]=path
        archive[entry['raw']]=base/entry['raw']
        raw_img=Image.open(path).convert('RGB')
        assert raw_img.size==(1280,720)
        cropped,rect=visible_crop(raw_img)
        row['source_crop']=rect
        row['selected_native_frame']=key
        row['selected_native_sha256']=sha256(path.read_bytes()).hexdigest()
        pic=cropped.copy()
        pic.thumbnail((400,277),Image.Resampling.LANCZOS)
        x=(n%3)*420
        y=(n//3)*347
        px=x+(420-pic.width)//2
        py=y+(280-pic.height)//2
        img.paste(pic,(px,py))
        center_label(draw,(x,420),y+293,row['name'])
        center_label(draw,(x,420),y+322,id,compact)
        record(id,name,[x,y,420,347])
    img.save(out/name)

vehicle=index['bulwark']
path=base/raw['bulwark']['raw']
img=Image.open(path).convert('RGB')
assert img.size==(1280,720)
img.save(out/'vehicle.png')
record('bulwark','vehicle.png',[0,0,1280,720])
archive[raw['bulwark']['raw']]=path

for row in models:
    entry=raw[row['id']]
    for key in ('group','pose','raw','sha256','size'):
        row[f'native_{key}']=entry[key]
    row.setdefault('selected_native_sha256',entry['sha256'])
    row.setdefault('selected_native_frame',entry['raw'])
    assert (out/row['review_image']).is_file()
stats=dict(Counter(row['type'] for row in models))
assert stats=={'human':43,'PartCreature':14,'ChainCreature':4,'WormCreature':1,'vehicle':1}
result={'baseline':(base/'baseline.txt').read_text().strip(),'models':models,
        'model_counts':stats,'native_captures':len({tag['raw'] for tag in raw.values()}),
        'display_recaptures':len(list(base.glob('lit-*/preview.png')))}
(base/'review-index.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(base/'archive-images.json').write_text(json.dumps(sorted(archive),indent=2)+'\n')
print(len(models),'valid review rows',len(archive),'raw captures',len(list(out.glob('*.png'))),'review pages')
