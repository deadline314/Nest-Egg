from pathlib import Path
from hashlib import sha256
from subprocess import run
from shutil import copyfile
import json
import os
import sys

base = Path(__file__).resolve().parent
shared = base.parent/'ne218-baseline-20261117'
root=Path.cwd()
python = Path(sys.executable)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def render(case, scene, args, fixed):
    out=base/case
    out.mkdir(exist_ok=False)
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        var = out/'profile'/key
        var.mkdir(parents=True)
        env[key]=str(var)
    command = [str(python),str(shared/'tools/comfyui/gpu_lock.py'),'--',engine,
               '--path',str(shared),'--resolution','1280x720','--position','10,90',
               '--rendering-method','forward_plus','--rendering-driver','vulkan']
    if fixed:
        command.extend(('--fixed-fps','60'))
    command.append(str(scene))
    command.extend(('--',*[a.replace('{out}',out.as_posix()) for a in args]))
    (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=650)
    (out/'exit.txt').write_text(str(result.returncode)+'\n',encoding='utf-8')
    raw=(out/'raw.log').read_text(encoding='utf-8')
    print(case,result.returncode,len(raw),flush=True)
    assert result.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw
    return raw







from collections import defaultdict
from itertools import batched
from PIL import Image
import json
from hashlib import sha256
from subprocess import check_output

expected=check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
assert check_output(['git','rev-parse','HEAD'],cwd=shared).decode().strip()==expected
assert check_output(['git','rev-parse','origin/main'],cwd=root).decode().strip()==expected
(base/'baseline.txt').write_text(expected+'\n')
rows=json.loads((base/'catalog-draft.json').read_bytes())
by_pose=defaultdict(list)
for row in rows:
    definition=row['definition']
    local=sha256((root/definition).read_bytes()).hexdigest()
    assert local==sha256((shared/definition).read_bytes()).hexdigest()==row['definition_sha256'],row['id']
    if row['type']=='human':
        placement=row['usage_refs']
        npc=any(ref.startswith('data/npcs/') for ref in placement) and not any(ref.startswith('data/enemies/') for ref in placement)
        by_pose['npc' if npc else 'combat'].append(row)
jobs=[]
for pose,models in sorted(by_pose.items()):
    for index,batch in enumerate(batched(models,4),1):
        tag=f'{pose}-{index:02}'
        ids=','.join(row['id'] for row in batch)
        args=[f'--chars={ids}','--closeup','--bright','--weapon=','--zoom=3.15','--out={out}/preview.png']
        if pose=='npc':
            args.append('--npc')
        jobs.append((tag,'res://tools/rig_preview.tscn',args,[row['id'] for row in batch],'preview.png',pose))
for row in rows:
    id=row['id']
    kind=row['type']
    if kind=='human':
        continue
    stage=base/'center-sheet.tscn'
    filename='preview.png'
    state=None
    defaults=['--bright','--out={out}/preview.png']
    if kind!='vehicle':
        data=json.loads((root/row['definition']).read_bytes())
        state='idle' if 'idle' in data['states'] else next(iter(data['states']))
    if kind=='PartCreature':
        opts=[f'--parts={id}','--cell=520x324','--cols=1','--zoom=1.65']
    elif kind=='ChainCreature':
        opts=[f'--creature={id}','--zoom=1.25']
    elif kind=='WormCreature':
        opts=[f'--worm={id}','--zoom=1.60']
    else:
        filename='vehicle.png'
        stage='res://tools/screenshot.tscn'
        opts=['--scenario=model_vehicle','--out={out}']
    if state is not None:
        opts.extend(defaults+[f'--states={state}'])
    jobs.append((id,stage,opts,[id],filename,state or 'vehicle'))
manifest={}
for name,scene,args,ids,file,pose in jobs:
    raw=render('gallery-'+name,scene,args,True)
    path=base/f'gallery-{name}'/file
    with Image.open(path) as image:
        size=list(image.size)
        assert image.width>=640 and image.height>=360
        image.verify()
    for index,id in enumerate(ids):
        manifest[id]={'group':name,'ids':ids,'raw':path.relative_to(base).as_posix(),
                      'sha256':sha256(path.read_bytes()).hexdigest(),'size':size,'pose':pose,'column':index}
    (base/'gallery-progress.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert set(manifest)=={r['id'] for r in rows}
print(len(manifest),'models from',len(jobs),'native captures on',expected,flush=True)
