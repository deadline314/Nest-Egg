extends "res://tools/creature_preview.gd"


func _ready() -> void:
	super._ready()
	var center := get_viewport_rect().size * 0.5
	var stage_center := center + Vector2(0.0, 22.0)
	if _creatures.size() == 1:
		_creatures[0].position = stage_center
	if _worms.size() == 1:
		var camera := get_viewport().get_camera_2d()
		stage_center = center / camera.zoom + Vector2(32.0, 0.0)
		_worms[0].position = stage_center
	for offset: Vector2 in [Vector2(-58.0, -72.0), Vector2(66.0, -60.0), Vector2(0.0, 70.0)]:
		var light := LightKit.create_point_light(Color("#eff4ff"), 470.0, 1.05)
		light.position = stage_center + offset
		add_child(light)
