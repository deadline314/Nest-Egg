from collections import defaultdict
from pathlib import Path
import json
import re

from PIL import Image, ImageDraw, ImageFont

root = Path.cwd()
base = root / "work/ne275-closeup-comparison-v2-20261119"
out = root / "work/ne275-melee-draw-20261119/closeups"
out.mkdir(exist_ok=True)
font = ImageFont.truetype("C:/Windows/Fonts/segoeui.ttf", 14)
newfont = ImageFont.truetype("C:/Windows/Fonts/segoeuib.ttf", 18)
poses = {"idle", "walk", "run", "crouch", "air", "dash"}
counts = {}
panels = []
for side in (1, -1):
    captures = {tag: base / f"{tag}-{side}" for tag in ("before", "current")}
    maps = {}
    for tag, image_dir in captures.items():
        data = json.loads((image_dir / "frames.json").read_text())
        assert data["side"] == side and data["failures"] == 0
        mapping = {(r["weapon"], r["action"], int(r["tick"])): r for r in data["shots"]}
        assert len(mapping) == len(data["shots"])
        assert all((image_dir / r["file"]).is_file() for r in mapping.values())
        maps[tag] = mapping
    shared = set(maps["before"]) & set(maps["current"])
    ranges = {tag: defaultdict(list) for tag in maps}
    for tag, items in maps.items():
        for weapon, action, tick in items:
            ranges[tag][(weapon, action)].append(tick)
    assert set(ranges["before"]) <= set(ranges["current"]), {
        "before_only_actions": sorted(set(ranges["before"]) - set(ranges["current"]))}
    assert {(w, a) for w, a, _ in shared} == set(ranges["before"])
    counts[str(side)] = {
        "before": len(maps["before"]), "current": len(maps["current"]),
        "exact_tick_pairs": len(shared),
        "before_only_tick_rows": len(set(maps["before"]) - shared),
        "current_only_tick_rows": len(set(maps["current"]) - shared), "current_only_actions": sorted(set(ranges["current"]) - set(ranges["before"]))}
    by_weapon = defaultdict(list)
    for weapon, action in ranges["current"]:
        by_weapon[weapon].append(action)
    direction = "right" if side == 1 else "left"
    for weapon, actions in by_weapon.items():
        for group in (["idle", "walk", "run", "crouch", "air", "dash"],
                      *([a] for a in actions if a not in poses)):
            rows = sorted(set().union(*(set(items) for items in maps.values())))
            rows = [(w, a, t) for a in group for w, action, t in rows if w == weapon and action == a]
            for offset in range(0, len(rows), 12):
                batch = rows[offset:offset+12]
                width, height = 674, 137
                sheet = Image.new("RGB", (width, 60 + height * len(batch)), "#16191f")
                draw = ImageDraw.Draw(sheet)
                title = "/".join(group) if len(group) > 1 else group[0]
                draw.text((15, 8), f"{weapon} · {direction} · {title}", font=newfont, fill="white")
                draw.text((112, 35), "Before grip change", font=font, fill="white")
                draw.text((392, 35), "Current grip", font=font, fill="white")
                for row, key in enumerate(batch):
                    y = 61 + row * height
                    draw.text((13, y + 8), f"{key[1]}\n{key[2]:03} tick", font=font, fill="white")
                    for tag, x in [("before", 112), ("current", 392)]:
                        if key not in maps[tag]:
                            note = "Move added later" if key[:2] not in ranges[tag] else "Motion already ended"
                            draw.text((x + 18, y + 42), note, font=font, fill="#a5aabe")
                            continue
                        with Image.open(captures[tag] / maps[tag][key]["file"]) as picture:
                            assert picture.size == (640, 360)
                            sheet.paste(picture.crop((190, 115, 450, 245)), (x, y))
                name = f"{direction}-{weapon}-{group[0] if len(group)==1 else 'poses'}-{offset//12+1:02}.jpg"
                sheet.save(out / name, quality=91, subsampling=0)
                panels.append(name)
(out / "index.json").write_text(json.dumps({"capture_counts": counts, "panels": panels}, indent=2) + "\n")
print(counts, len(panels))
