extends "res://tools/melee_art_probe.gd"

func _run() -> void:
	seed(275)
	Story.auto_skip = true
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	await open_arena("res://data/lighting/warehouse_interior.tres",12.0)
	var camera := get_viewport().get_camera_2d()
	camera.set_physics_process(false)
	camera.limit_enabled = false
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * 2.3
	AimInput.using_gamepad = true
	AimInput._last_stick_dir = Vector2.RIGHT
	level.hud.visible = false
	var weapon := load("res://data/weapons/melee/melee_whip.tres") as WeaponData
	await _arm(weapon,camera)
	await settle(90)
	MeleeArt.probe_segment_calls = 0
	var frames: Array[Dictionary] = []
	for i in 120:
		await get_tree().process_frame
		if i % 10 == 0:
			frames.append(_read_pose())
	await RenderingServer.frame_post_draw
	capture("whip-idle")
	var idle_calls := MeleeArt.probe_segment_calls
	MeleeArt.probe_segment_calls = 0
	var seen_active := false
	Input.action_press(&"melee")
	for i in 100:
		await get_tree().physics_frame
		await get_tree().process_frame
		if i % 3 == 0:
			frames.append(_read_pose())
		if not seen_active and player.melee.is_active():
			seen_active = true
			await RenderingServer.frame_post_draw
			capture("whip-active")
		if i == 1:
			Input.action_release(&"melee")
	Input.action_release(&"melee")
	var total := MeleeArt.probe_segment_calls
	var count_ok := idle_calls > 0 and total > 0 if _tag == "before" else idle_calls == 0 and total == 0
	if not seen_active or not count_ok:
		_failures += 1
	var record := {"idle_calls":idle_calls,"strike_calls":total,"visible_active":seen_active,
		"frames":frames, "failures":_failures, "renderer":RenderingServer.get_current_rendering_method(),"adapter":RenderingServer.get_video_adapter_name()}
	FileAccess.open(out_dir.path_join("whip-draw.json"),FileAccess.WRITE).store_string(JSON.stringify(record,"\t"))
	print("NE275_WHIP_DRAWS case=%s idle=%d strike=%d failures=%d" % [_tag,idle_calls,total,_failures])
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures==0 else 1)

func _read_pose() -> Dictionary:
	var held := player._visual.melee_held()
	var attached := held.whip()
	var points: Array[Array] = []
	if attached != null and attached.is_laid():
		for i in SoftWhip.NODES:
			var p := attached.node(i)
			points.append([p.x,p.y])
	var origin := held.hold().origin
	return {"points":points,"palm":[origin.x,origin.y],"active":player.melee.is_active(),"pose_t":player.melee_pose_progress()}
