extends "res://tools/melee_art_probe.gd"

var side := 1
var frames: Array[Dictionary] = []
var _weapon: String

func _run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--facing="):
			side = arg.trim_prefix("--facing=").to_int()
	if side not in [-1,1]:
		get_tree().quit(2)
		return
	Engine.max_physics_steps_per_frame = 1
	Story.auto_skip = true
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	await open_arena("res://data/lighting/warehouse_interior.tres",12.0)
	await clear_enemies()
	var camera := get_viewport().get_camera_2d()
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.limit_enabled = false
	camera.zoom = Vector2(5.0,5.0)
	var step_action := &"move_right" if side > 0 else &"move_left"
	for id: String in WEAPONS:
		_weapon = id
		var weapon := load("res://data/weapons/melee/melee_%s.tres" % id) as WeaponData
		for sample in [["idle",&"",0.0,30],["walk",step_action,0.3,30],["run",step_action,1.0,30],
				["crouch",&"move_down",1.0,30],["air",&"jump",1.0,10],["dash",&"dash",1.0,10]]:
			await _arm_facing(weapon,camera)
			if sample[1] != &"":
				Input.action_press(sample[1],sample[2])
			for i in sample[3]:
				await _step()
			await _photo(camera,sample[0],sample[3])
			if sample[1] != &"":
				Input.action_release(sample[1])
			await settle(50)
		var data := MeleeData.set_of(weapon)
		var roster: Array = data.combo(true)
		if data.has_method(&"hold"):
			var held: Dictionary = data.call(&"hold")
			if not held.is_empty():
				roster.append(str(held["attack"]))
		for move in roster:
			await _arm_facing(weapon,camera)
			if not player._start_melee_attack(false):
				_failures += 1
				continue
			var attack: Dictionary = data.call(&"attack",str(move))
			if attack.is_empty():
				_failures += 1
				continue
			player._melee_attack = attack
			var tick := 0
			while player.melee_pose_progress() >= 0.0 and tick < 180:
				await _step()
				if tick % 2 == 0:
					await _photo(camera,str(move),tick)
				tick += 1
			if tick < 2 or tick == 180:
				_failures += 1
		FileAccess.open(out_dir.path_join("frames.json"),FileAccess.WRITE).store_string(JSON.stringify({"side":side,"shots":frames,"failures":_failures,"adapter":RenderingServer.get_video_adapter_name()},"\t"))
	print("NE275_CLOSEUP samples=%d failures=%d" % [frames.size(),_failures])
	await finish()
	get_tree().quit(0 if _failures==0 else 1)

func _arm_facing(weapon: WeaponData, camera: Camera2D) -> void:
	await _arm(weapon,camera)
	AimInput.using_gamepad = true
	AimInput._last_stick_dir = Vector2(side,0)
	player.facing = side
	player.aim_dir = Vector2(side,0)
	await settle(30)

func _step() -> void:
	await get_tree().physics_frame
	await get_tree().process_frame

func _photo(camera: Camera2D, action: String, tick: int) -> void:
	var rig := player._visual.rig
	var front := rig.bone(&"hand_front").global_position
	var rear := rig.bone(&"hand_back").global_position
	camera.global_position = (front+rear)*0.5
	camera.force_update_scroll()
	var name := "%s-%s-%03d" % [_weapon,action,tick]
	await RenderingServer.frame_post_draw
	var view := get_viewport().get_canvas_transform()
	var bounds := get_viewport().get_visible_rect().grow(-14.0)
	if not bounds.has_point(view*front) or not bounds.has_point(view*rear) or player.facing != side:
		_failures += 1
	frames.append({"file":name+".png","weapon":_weapon,"action":action,"tick":tick,"facing":player.facing,
		"front":str(view*front),"rear":str(view*rear),"pose_t":player.melee_pose_progress()})
	capture(name)
