from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
project = 'D:/NestEggVerification/ne218-baseline-20261117'
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
version = sys.argv[1]
out = base / version
out.mkdir()
scene = (base / 'observer.tscn').read_text(encoding='utf-8')
remote = scene.split('path="', 1)[1].split('"', 1)[0]
entry = out / 'observer.tscn'
entry.write_text(scene.replace(remote, (base / 'observer.gd').as_posix()), encoding='utf-8')
env = os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key] = str(base / 'profile' / key)
records = {}
for episode in sys.argv[2:] or ('fall', 'cut', 'keep'):
    result = out / episode
    result.mkdir()
    command = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--', engine, '--path', project,
               '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
               '--resolution', '640x360', '--max-fps', '60', entry.as_posix(), '--',
               f'--scene=ch2_t_s13_{episode}', f'--out={result.as_posix()}']
    (result / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
    with (result / 'raw.log').open('wb') as log:
        run = subprocess.run(command, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=140)
    log = (result / 'raw.log').read_text(encoding='utf-8', errors='replace')
    assert run.returncode == 0 and 'SCRIPT ERROR:' not in log, (episode, version, log[-2000:])
    report = json.loads((result / 'result.json').read_bytes())
    assert not report['failures'] and 'RX 9070 XT' in report['adapter'], episode
    data = report['scenes'][0]
    assert data['flags_and_credits_held']
    contacts = data['contacts']
    records[episode] = {'samples': len(contacts),
                        'max_contact': max((sample['distance'] for sample in contacts), default=0.0),
                        'captures': [sample['phase'] for sample in data['captures']]}
    print(episode, records[episode], flush=True)
(out / 'receipt.json').write_text(json.dumps(records, indent=2) + '\n')
