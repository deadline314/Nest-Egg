extends Node2D
## 正式S13資料的自然Tween觀察；直接CutscenePlayer，不冒稱Main結果/真人遊測。
var _out:=""
var _images:Array[Dictionary]=[]
var _failures:Array[String]=[]
var _reports:Array[Dictionary]=[]
func _ready()->void:
	var wanted:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):_out=arg.trim_prefix("--out=")
		if arg.begins_with("--scene="):wanted=arg.trim_prefix("--scene=")
	DirAccess.make_dir_recursive_absolute(_out)
	for id in ["ch2_t_s13_cut","ch2_t_s13_keep","ch2_t_s13_fall"]:
		if wanted.is_empty() or wanted==id:await _scene(id)
	for capture in _images:
		var raw:Image=capture.image
		FileAccess.open(_out.path_join(capture.name+".raw"),FileAccess.WRITE).store_buffer(raw.get_data())
		preload("res://tools/viewport_capture.gd").encode(raw,capture.hdr).save_png(_out.path_join(capture.name+".png"))
		capture.metadata["raw"]={"format":raw.get_format(),"hdr":capture.hdr,"sha256":FileAccess.get_sha256(_out.path_join(capture.name+".raw"))}
	FileAccess.open(_out.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify({"adapter":RenderingServer.get_video_adapter_name(),"scenes":_reports,"failures":_failures,"classification":"正式S13資料，直接視覺observer、合成台詞推進；不經Main結果owner"},"  "))
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures.is_empty() else 1)

func _capture(player:CutscenePlayer,id:String,phase:String,rows:Array)->Dictionary:
	var metadata:Dictionary={"phase":phase,"actor_states":rows.duplicate(true),"png":id+"-"+phase+".png","geometry":_geometry(player)}
	_images.append({"name":id+"-"+phase,"image":get_viewport().get_texture().get_image(),"hdr":get_viewport().use_hdr_2d,"metadata":metadata})
	return metadata

func _scene(id:String)->void:
	var definition:Dictionary=Story._scenes[id]
	var errors:=CutsceneChecker.validate(id,definition,Story._speakers)
	errors.append_array(CutsceneChecker.staging_problems(id,definition))
	if not errors.is_empty():
		_failures.append(id+": "+str(errors));return
	var flags:=GameState.world_flags.duplicate(true)
	var credits:=Progression.credits
	var player:=CutscenePlayer.new();add_child(player);player.play(StringName(id),definition)
	var started:=Time.get_ticks_msec();var next:=started+1500
	var contacts:Array[Dictionary]=[];var shots:Array[Dictionary]=[];var phases:={};var poses:Array[Dictionary]=[]
	var head_samples:Array[float]=[]
	var nod_events:Array[Dictionary]=[]
	var pending_line:=""
	var last_nods:=0
	while player.is_running() and Time.get_ticks_msec()-started<65000:
		await RenderingServer.frame_post_draw
		if not is_instance_valid(player):break
		var stage:=player._stage
		if stage!=null:
			poses=[]
			for actor:CutsceneActor in player._actors.values():
				poses.append(_actor_state(actor,stage))
				for hand in ["front","back"]:
					if not actor.hand_target_settled(StringName(hand)):continue
					var reach:CutsceneReach=actor._reaches[0 if hand=="front" else 1]
					var target:Vector2=reach._binding.stage_point(actor.get_parent() as Node2D) if reach._binding!=null else (actor.position+reach.target if reach._actor_space else reach.target)
					var palm:Vector2=(actor.get_parent() as Node2D).to_local(actor.hand_contact_global(StringName(hand)))
					var distance:=target.distance_to(palm)
					contacts.append({"milliseconds":Time.get_ticks_msec()-started,"id":str(actor.actor_id),"hand":hand,"distance":distance,"target":target,"palm":palm,"root":actor.position,"shoulder":stage.to_local(actor.rig.bone(&"arm_"+hand+"_upper").global_position),"consumed_hip":(actor.rig.animator as NpcAnimator)._angles.get(&"hip",0.0),"kneel":(actor.rig.animator as NpcAnimator)._kneel_w})
					if distance>StagePropHold.CONTACT_TOLERANCE and _failures.size()<120:_failures.append(id+": contact "+str(actor.actor_id)+"/"+hand+" "+str(distance))
				if actor.actor_id==&"porter_front" and actor.pose==&"listen":
					head_samples.append(actor.rig.bone(&"head").rotation)
					var animator:=actor.rig.animator as NpcAnimator
					if animator._life!=null and animator._life.nods>last_nods:
						last_nods=animator._life.nods
						nod_events.append({"milliseconds":Time.get_ticks_msec()-started,"counter":last_nods,"head":actor.rig.bone(&"head").rotation})
						shots.append(_capture(player,id,"nod-"+str(last_nods),poses))
			if player._dialogue.visible and not player._dialogue._text.text.is_empty():
				var text:String=player._dialogue._text.text
				if pending_line==text:
					var shot:=_capture(player,id,"line-"+str(phases.get("line_count",0)),poses)
					shot["text"]=text;shots.append(shot)
					phases[text]=true;phases["line_count"]=int(phases.get("line_count",0))+1;pending_line=""
				elif not phases.has(text):
					player._dialogue.complete();pending_line=text
			var visitor := player._actors.get(&"xiaowei") as CutsceneActor
			if visitor != null and visitor.position.x > 600.0 and not phases.has("escort"):
				phases["escort"] = true
				shots.append(_capture(player,id,"escort",poses))
			for prop: String in ["medic_pause_lock","medic_maintenance_key"]:
				if stage.prop_held(prop) and not phases.has(prop):
					phases[prop] = true
					shots.append(_capture(player,id,prop,poses))
			var bed:=stage.prop_node("transport_stretcher") as StageLayers._Sprite
			var patient:=player._actors.get(&"egret") as CutsceneActor
			if bed!=null and bed.visible:
				for phase in ["arrival","lift_ready","loading","carrying","strapped","secured_clear","outgoing"]:
					var ready:=false
					match phase:
						"arrival":ready=bed.position.x>440
						"lift_ready":ready=patient!=null and patient.position.y>300 and player._actors.has(&"porter_front") and player._actors.has(&"porter_rear") and (player._actors[&"porter_front"] as CutsceneActor).pose==&"crouch" and _posture_ready(player._actors[&"porter_front"]) and _posture_ready(player._actors[&"porter_rear"]) and (player._actors[&"porter_front"] as CutsceneActor).hand_target_settled(&"front") and (player._actors[&"porter_rear"] as CutsceneActor).hand_target_settled(&"front")
						"loading":ready=patient!=null and patient.position.y<280 and patient.position.x<330
						"carrying":ready=patient!=null and patient.position.x>360 and patient.position.x<410 and patient.position.y<249
						"strapped":ready=(stage.prop_node("transport_strap_chest") as Node2D).visible
						"secured_clear":ready=bed.position.x<400 and player._actors.has(&"porter_front") and (player._actors[&"porter_front"] as CutsceneActor).position.x<365 and (stage.prop_node("transport_strap_hips") as Node2D).visible
						"outgoing":ready=bed.position.x>480 and (stage.prop_node("transport_strap_chest") as Node2D).visible
					if ready and not phases.has(phase):phases[phase]=true;shots.append(await _capture(player,id,phase,poses))
		if Time.get_ticks_msec()>=next:
			player._dialogue.complete();player._advance_requested=true;next=Time.get_ticks_msec()+1200
	if is_instance_valid(player) and player.is_running():_failures.append(id+": 演出超出65秒護欄");player.skip()
	var required := ["carrying", "lift_ready", "strapped", "outgoing"] if id.ends_with("_fall") else ["escort"]
	if id.ends_with("_keep"):
		required.append_array(["medic_pause_lock", "medic_maintenance_key"])
	for phase: String in required:
		if not phases.has(phase):
			_failures.append(id + ": lost required presentation phase " + phase)
	if GameState.world_flags!=flags or Progression.credits!=credits:_failures.append(id+": 視覺cue改了結果")
	_reports.append({"id":id,"contacts":contacts,"captures":shots,"head_samples":head_samples,"nod_events":nod_events,"flags_and_credits_held":GameState.world_flags==flags and Progression.credits==credits})
	if is_instance_valid(player):player.skip()
	while is_instance_valid(player) and player.is_running():await get_tree().process_frame
	if is_instance_valid(player):player.queue_free()
	await get_tree().process_frame


func _geometry(player:CutscenePlayer)->Dictionary:
	var stage:=player._stage
	var parts:Array[Dictionary]=[]
	for actor:CutsceneActor in player._actors.values():
		if actor.rig==null:continue
		for part:Node2D in actor.rig._parts:
			if not part.is_visible_in_tree():continue
			var texture:Texture2D=part.texture
			var normal:Texture2D=null
			if texture is CanvasTexture:
				normal=(texture as CanvasTexture).normal_texture
				texture=(texture as CanvasTexture).diffuse_texture
			var row:Dictionary={"actor":str(actor.actor_id),"part":str(part.name),"texture":texture.resource_path,"normal":normal.resource_path if normal!=null else "","imported_size":[texture.get_width(),texture.get_height()]}
			if part is RigPartMesh:
				row["uv"]=Array(part.uv).map(func(v:Vector2)->Array:return [v.x,v.y])
				row["vertices"]=Array(part.deformed_vertices()).map(func(v:Vector2)->Array:
					var point:Vector2=stage.to_local(part.to_global(v));return [point.x,point.y])
				row["polygons"]=Array(part.polygons).map(func(v:PackedInt32Array)->Array:return Array(v))
			else:
				row["origin"]=[part.get_rect().position.x,part.get_rect().position.y]
				var matrix:Transform2D=stage.global_transform.affine_inverse()*part.global_transform
				row["matrix"]=[[matrix.x.x,matrix.x.y],[matrix.y.x,matrix.y.y],[matrix.origin.x,matrix.origin.y]]
			parts.append(row)
	var props:Array[Dictionary]=[]
	for id in ["transport_stretcher","transport_head_pad","transport_strap_chest","transport_strap_hips","egret_equipment_bag","egret_broken_umbrella","medic_side_box","medic_pause_lock","medic_maintenance_key","family_exit_frame","family_exit_panel","family_exit_sill"]:
		var prop:=stage.prop_node(id) as Sprite2D
		if prop==null or not prop.is_visible_in_tree():continue
		var texture:Texture2D=prop.texture
		var normal:Texture2D=null
		if texture is CanvasTexture:
			normal=(texture as CanvasTexture).normal_texture;texture=(texture as CanvasTexture).diffuse_texture
		var matrix:Transform2D=stage.global_transform.affine_inverse()*prop.global_transform
		props.append({"id":id,"texture":texture.resource_path,"normal":normal.resource_path if normal!=null else "","imported_size":[texture.get_width(),texture.get_height()],"origin":[prop.get_rect().position.x,prop.get_rect().position.y],"matrix":[[matrix.x.x,matrix.x.y],[matrix.y.x,matrix.y.y],[matrix.origin.x,matrix.origin.y]]})
	return {"parts":parts,"props":props}


func _posture_ready(actor:CutsceneActor)->bool:
	if actor.rig==null:return false
	var animator:=actor.rig.animator as NpcAnimator
	if actor.pose==&"crouch":return absf(angle_difference(float(animator._angles[&"hip"]),float(animator._motion["crouch"]["hip"])))<.001 and animator._kneel_w>.999
	return animator.posture_progress()>=1.0

func _actor_state(actor:CutsceneActor,stage:Node2D)->Dictionary:
	var animator:=actor.rig.animator as NpcAnimator
	var hip:Transform2D=stage.global_transform.affine_inverse()*actor.rig.bone(&"hip").global_transform
	return {"id":str(actor.actor_id),"kind":actor.rig.skin_id,"pos":actor.position,"pose":str(actor.pose),"shoulder":stage.to_local(actor.rig.bone(&"arm_front_upper").global_position),"elbow":stage.to_local(actor.rig.bone(&"arm_front_lower").global_position),"wrist":stage.to_local(actor.rig.bone(&"hand_front").global_position),"consumer":"npc" if animator._use_npc else "humanoid","configured_crouch_hip":animator._motion["crouch"]["hip"],"consumed_hip":animator._angles.get(&"hip",0.0),"kneel_weight":animator._kneel_w,"npc_posture":str(actor._input.npc_pose),"npc_progress":animator.posture_progress(),"posture_ready":_posture_ready(actor),"hip_world":[[hip.x.x,hip.x.y],[hip.y.x,hip.y.y],[hip.origin.x,hip.origin.y]]}
