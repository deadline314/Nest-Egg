extends Node2D


func _ready() -> void:
	_calibrate.call_deferred()


func _calibrate() -> void:
	var actor := CutsceneActor.new()
	add_child(actor)
	if not actor.setup(&"rin", "rin", "", 2.4, ""):
		get_tree().quit(2)
		return
	actor.face(1)
	actor.ground_y = 305.0
	actor.set_process(false)
	var reach: Array[Dictionary] = []
	var rig := actor.rig
	var contact := rig.hand_source_point(&"front", Vector2(96.5, 37.5))
	var shoulder := rig.bone(&"arm_front_upper")
	var wrist := rig.bone(&"hand_front")
	var max_reach := rig.rest(&"arm_front_lower").length() + rig.rest(&"hand_front").length()
	var skeleton := rig._skeleton
	for pose: StringName in [&"lean", &"crouch", &"squat"]:
		actor.set_pose(pose)
		for frame in 75:
			actor._process(1.0 / 60.0)
		print("NE242_SHOULDER ", pose, " ", shoulder.global_position)
		for x: int in [566, 570, 574, 578, 582]:
			actor.position = Vector2(x, 305)
			for y: int in [245, 247, 249]:
				for angle: float in [-2.4, -1.8, -1.3, -0.8, 0.0, 0.8, 1.3, 1.8, 2.4]:
					var accepted := true
					var margin := INF
					var points: Array[Vector2] = []
					for frame in 18:
						actor._process(1.0 / 30.0)
						for px: float in [584.0, 592.0, 600.0]:
							var target := Vector2(px, y)
							var inverse := skeleton.global_transform.affine_inverse()
							var local_angle := inverse.basis_xform(Vector2.from_angle(angle)).angle()
							var local_wrist := inverse * target - contact.rotated(local_angle)
							margin = minf(margin, max_reach - local_wrist.distance_to(inverse * shoulder.global_position))
							if not rig.place_hand(&"front", target, angle, 1.0, contact):
								accepted = false
							if frame == 17:
								points.append(wrist.global_position)
					if accepted:
						reach.append({"pose": pose, "x": x, "y": y, "angle": angle, "margin": margin, "wrists": str(points)})
	reach.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return a["margin"] > b["margin"])
	print("NE242_CALIBRATION ", JSON.stringify({"contact": str(contact), "length": max_reach, "shoulder": str(shoulder.global_position), "matches": reach}))
	actor.free()
	get_tree().quit(0 if not reach.is_empty() else 1)
