from pathlib import Path
import json

base = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_bytes())
runtime = read(base / 'runtime.json')
current = read(base / 'source.json')
parent = (base / 'baseline.txt').read_text().strip()
report = {}


def compare_stock(name, file, rows, support, same_fields):
    folder = base / name
    for path in sorted((folder / 'stock').glob('*/' + file)):
        label = path.parent.name
        case = folder / 'candidate' / label
        if name == 'jump' and not (case / file).is_file():
            case = folder / 'retry' / label
        old, new = (read(p)[rows] for p in (path, case / file))
        assert len(old) == len(new) and len(new) > 0, label
        command = read(case / 'command.json')
        assert command['source'] == parent
        assert all(command['worktree_sha256'][key] == current[key] for key in runtime)
        for before, after in zip(old, new, strict=True):
            for key in same_fields:
                assert before[key] == after[key], (label, key, before[key], after[key])
            if name == 'hits':
                assert all(before['bones'][bone] == after['bones'][bone] for bone in before['bones']
                           if not bone.startswith('foot_')), label
            if not after['ground']:
                assert before == after, (label, 'The air poses differ')
            if label.startswith('dash-'):
                assert before == after, (label, 'The previously verified ground dash differs')
        take_peak = lambda history: max(value for row in history if row['ground'] for value in row[support])
        peak_before, peak_after = take_peak(old), take_peak(new)
        is_landing = name == 'hits' or label.startswith(('jump-', 'airdash-'))
        if is_landing:
            assert peak_before > 1.6 and peak_after < 0.65, (label, peak_before, peak_after)
            assert any(before[support] != after[support] for before, after in zip(old, new, strict=True)), label
        def landmark(history):
            frame = max((row for row in history if row['ground']), key=lambda row: max(row[support]))
            return frame.get('i', frame.get('frame'))
        report[label] = {'frames': len(new), 'before': peak_before, 'after': peak_after,
                         'candidate': case.relative_to(base).as_posix(),
                         'max_before_frame': landmark(old), 'airborne_unchanged': sum(not row['ground'] for row in new),
                         'grounded_unchanged': sum(a == b for a, b in zip(old, new, strict=True) if a['ground'])}
        print(label, report[label])


compare_stock('hits', 'trace.json', 'trace', 'boot_depth',
              ('i', 'state', 'face', 'origin', 'velocity', 'ground', 'weapon', 'health', 'guard', 'shield',
               'broken', 'parry_flash', 'block_flash', 'alpha', 'emitter', 'muzzle', 'hurt_dir', 'projectile'))
compare_stock('jump', 'motion.json', 'rows', 'sole',
              ('action', 'frame', 'root', 'velocity', 'facing', 'aim', 'state', 'ground', 'dash_time',
               'chest', 'hip', 'head', 'muzzle', 'rounds', 'chest_rotation', 'hip_rotation', 'weapon'))
assert len(report) == 20
(base / 'results.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
