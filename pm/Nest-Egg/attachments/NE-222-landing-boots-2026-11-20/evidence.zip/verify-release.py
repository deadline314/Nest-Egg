from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess

root=Path.cwd()
base=Path(__file__).resolve().parent
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
folder=base/'official-final'
folder.mkdir()
source=json.loads((base/'source.json').read_bytes())
runtime=json.loads((base/'runtime.json').read_bytes())
expected=(base/'baseline.txt').read_text().strip()
sha=lambda path:sha256(path.read_bytes()).hexdigest()

def held():
    return all(sha(shared/path)==digest for path,digest in source.items()) and all(sha(root/path)==source[path] for path in runtime)

assert held()
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
    (folder/'profile'/key).mkdir(parents=True)
    env[key]=str(folder/'profile'/key)
env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',SHARDS='5',
           LOG_DIR=str(folder/'shards'),GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
command=['C:/Program Files/Git/bin/bash.exe','-c',
         f'python3() {{ python "$@"; }}; export -f python3; tools/run_tests_changed.sh {expected}']
(folder/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (folder/'raw.log').open('wb') as log:
    proc=subprocess.run(command,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1500)
raw=(folder/'raw.log').read_text(encoding='utf-8')
errors=[line for line in raw.splitlines() if 'ERROR:' in line]
for path in (folder/'shards').glob('shard_*.log'):
    errors.extend(line for line in path.read_text(encoding='utf-8',errors='replace').splitlines() if 'SCRIPT ERROR:' in line)
receipt={'exit':proc.returncode,'errors':errors,'source_held':held()}
(folder/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(raw,receipt,flush=True)
assert receipt=={'exit':0,'errors':[],'source_held':True}





