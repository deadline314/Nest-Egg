extends "res://tools/ch1_flow_probe.gd"

const ENEMY_SHOT := preload("res://data/projectiles/grunt_shot.tres")
const BONES: Array[StringName] = [&"head", &"chest", &"hip", &"arm_front_upper", &"arm_front_lower",
	&"hand_front", &"arm_back_upper", &"arm_back_lower", &"hand_back", &"foot_front", &"foot_back"]
var _side := 1
var _lens := 0.0
var _mode := "hurt"
var _slot := ""
var _app: Node
var _player: Player
var _rig: CharacterRig
var _trace: Array[Dictionary] = []
var _parries := 0
var _shoe_outlines: Dictionary[int, PackedVector2Array] = {}


func _run() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--slot="): _slot = arg.trim_prefix("--slot=")
		if arg.begins_with("--side="): _side = int(arg.trim_prefix("--side="))
		if arg.begins_with("--lens="): _lens = float(arg.trim_prefix("--lens="))
		if arg.begins_with("--mode="): _mode = arg.trim_prefix("--mode=")
	if not _slot.is_absolute_path() or _side not in [-1, 1] or _mode not in ["hurt", "rear", "block", "parry", "break"]:
		get_tree().quit(2)
		return
	Settings.use_storage("user://guard_pose.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	_app = preload("res://scenes/main.tscn").instantiate()
	_app.set("_run_store", RunSaveStore.new(_slot))
	add_child(_app)
	for frame in STEP_LIMIT:
		if _app.get("_screen") is MainMenu and not bool(_app.call("_route_pending")): break
		await _settle(1)
	var menu := _app.get("_screen") as MainMenu
	if menu == null:
		get_tree().quit(2)
		return
	await _settle(8)
	menu._continue_button.pressed.emit()
	for frame in STEP_LIMIT:
		var screen := _app.get("_screen") as Level
		if screen != null and screen.is_initialized() and screen.data.id == &"ch1_street" and not bool(_app.call("_route_pending")):
			_level = screen
			break
		await _settle(1)
	if _level == null or _level.player == null:
		get_tree().quit(2)
		return
	_player = _level.player
	_rig = _player._visual.rig
	for object in get_tree().get_nodes_in_group(&"enemies"):
		object.process_mode = Node.PROCESS_MODE_DISABLED
	_level._lighting._lightning_gap = 1.0e9
	_player.global_position.x = 472.0
	_player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(_player, true)
	var aim := &"aim_right" if _side > 0 else &"aim_left"
	AimInput.restore_direction(Vector2(_side, 0))
	Input.action_press(aim)
	_level.camera.snap_to_target()
	await _settle(70)
	if _lens > 0.0:
		var camera := _level.camera
		camera.set_physics_process(false)
		camera.limit_enabled = false
		camera.position_smoothing_enabled = false
		camera.offset = Vector2.ZERO
		camera.zoom = Vector2.ONE * _lens
		camera.global_position = _player.global_position + Vector2(0, -36)
		camera.force_update_scroll()
		await _settle(2)
	_check(_rig != null and _player.is_on_floor() and _player.facing == _side, "real chapter-one street, requested facing and floor")
	_check(_player.loadout.active_weapon().id == &"pistol" and _rig.weapon_root().visible, "the original P-9 and its visible grip are loaded")
	EventBus.player_parried.connect(func(_point: Vector2) -> void: _parries += 1)
	await _drive_hit()
	Input.action_release(aim)
	AimInput.set_virtual_gamepad(_player, false)
	var out := FileAccess.open(_out_dir.path_join("trace.json"), FileAccess.WRITE)
	out.store_string(JSON.stringify({"outcome": _mode, "side": _side, "lens": _lens, "trace": _trace,
		"parries": _parries, "failures": _failures, "adapter": RenderingServer.get_video_adapter_name(),
		"rendering_method": RenderingServer.get_current_rendering_method(), "hdr": get_viewport().use_hdr_2d}, "  ") + "\n")
	out.close()
	_app.call("_quit", int(_failures > 0))


func _drive_hit() -> void:
	var hp := _player.health.current
	var stamina := _player.guard
	var cost := float(ENEMY_SHOT.damage) * _player.tuning.guard_cost_per_damage
	var unguarded := _mode in ["hurt", "rear"]
	if not unguarded:
		Input.action_press(&"block")
		var wait := 3 if _mode == "parry" else 20
		await _settle(wait)
		_check(_player.is_blocking and _player.is_parry_window() == (_mode == "parry"), "real early or late block input")
	if _mode == "break":
		_player.guard = cost * 0.5
	await _observe(0, true, null)
	var incoming := -_side if _mode == "rear" else _side
	var shot := ProjectilePool.spawn(ENEMY_SHOT, _player.global_position + Vector2(incoming * 23.0, -22.0),
		Vector2(-incoming, 0.0), Combat.Team.ENEMY)
	_check(shot != null, "existing hostile projectile entered the real pool")
	var reflected := false
	for frame in range(1, 49):
		await _observe(frame, frame <= 12 or frame in [18, 24, 30, 40, 48], shot)
		reflected = reflected or (is_instance_valid(shot) and shot.team == Combat.Team.PLAYER)
		if frame == 15:
			Input.action_release(&"block")
		if frame == 12:
			match _mode:
				"hurt", "rear":
					_check(_player.health.current == hp - int(ENEMY_SHOT.damage) and not reflected, "unguarded hit reduces only health")
					var expected_side := -1.0 if _mode == "rear" else 1.0
					_check(_rig.animator._hurt_dir == expected_side, "the visible flinch follows the incoming direction")
				"block": _check(_player.health.current == hp and is_equal_approx(_player.guard, stamina - cost) and not reflected, "late block spends guard only")
				"parry": _check(_player.health.current == hp and is_equal_approx(_player.guard, stamina) and reflected and _parries == 1, "early block reflects once without damage or guard loss")
				"break": _check(_player.state == Player.State.STAGGERED and _player.guard <= 0.0 and _player.health.current == hp and not reflected, "depleted guard takes a real break and causes stagger")
	_check(_player.state == Player.State.NORMAL and not _player.is_blocking and _rig.weapon_root().visible, "normal armed pose recovered")


func _observe(index: int, image: bool, shot: Projectile) -> void:
	await RenderingServer.frame_post_draw
	var origin := _player.global_position
	var canvas := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	var positions: Dictionary = {}
	for tag in BONES:
		var joint := _rig.bone(tag)
		if joint == null:
			_check(false, "missing original protagonist bone " + String(tag))
			continue
		var point := canvas * joint.global_position
		positions[String(tag)] = [joint.global_position.x - origin.x, joint.global_position.y - origin.y, joint.rotation, point.x, point.y]
	var emitter := _player._visual.shield_wrist_local()
	var planted: Array = []
	if _player.is_on_floor():
		for foot: StringName in [&"foot_front", &"foot_back"]:
			planted.append(_shoe_ground_delta(foot, origin.y))
	_trace.append({"i": index, "physics": Engine.get_physics_frames(), "state": _player.state, "face": _player.facing,
		"ground": _player.is_on_floor(), "origin": [origin.x, origin.y], "velocity": [_player.velocity.x, _player.velocity.y],
		"weapon": _rig.weapon_root().visible, "health": _player.health.current, "guard": _player.guard,
		"shield": _player.is_blocking, "broken": _player.is_guard_broken(), "parry_flash": _player._visual._parry_flash,
		"block_flash": _player._visual._block_flash, "alpha": _player._visual.modulate.a, "bones": positions, "boot_depth": planted,
		"emitter": [emitter.x, emitter.y], "muzzle": [_player.muzzle_position().x, _player.muzzle_position().y],
		"hurt_dir": _rig.animator._hurt_dir,
		"projectile": int(shot.team) if is_instance_valid(shot) and shot.active else -1})
	if image:
		_capture("frame-%02d" % index)
	await _settle(1)


func _shoe_ground_delta(foot: StringName, floor_y: float) -> float:
	var shoe := _rig.contact_part(foot)
	if shoe == null or shoe.texture == null:
		_check(false, "missing original boot texture " + String(foot))
		return INF
	var key := shoe.texture.get_instance_id()
	if not _shoe_outlines.has(key):
		var image := shoe.texture.get_image()
		var boundary := PackedVector2Array()
		for x in image.get_width():
			var top := -1
			var bottom := -1
			for y in image.get_height():
				if image.get_pixel(x, y).a >= 0.5:
					if top < 0: top = y
					bottom = y
			if top >= 0:
				boundary.append(Vector2(x + 0.5, top + 0.5))
				boundary.append(Vector2(x + 0.5, bottom + 0.5))
		_shoe_outlines[key] = Geometry2D.convex_hull(boundary)
	var lowest := -INF
	for point: Vector2 in _shoe_outlines[key]:
		lowest = maxf(lowest, shoe.to_global(CharacterRig.part_source_point(shoe, point)).y - floor_y)
	return lowest
