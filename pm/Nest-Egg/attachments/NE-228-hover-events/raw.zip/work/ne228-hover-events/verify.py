from pathlib import Path
import json,hashlib,subprocess,os,time,shutil
w=Path('work/ne228-hover-events');rows=json.loads((w/'native-receipt.json').read_text());assert len(rows)==2 and all(r['exit_code']==r['expected'] and r['engine_errors']==0 and r['leaks']==0 and r['completed'] for r in rows)
for p,h in json.loads((w/'native-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
shutil.copyfile(w/'native-frozen-source.json',w/'verification-frozen-source.json')
env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6',LOG_DIR=str((w/'changed-shards').resolve()));cmd=['tools/run_tests_changed.sh','7a29f7535f60cef70cbb3c6deafb2790fb897975'];start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
(w/'changed-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2));print(r.returncode,flush=True)
