from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil,re
root=Path.cwd();w=root/'work/ne228-hover-events';out=root/'pm/Nest-Egg/attachments/NE-228-hover-events';base='7a29f7535f60cef70cbb3c6deafb2790fb897975';native=Path('/workspace/Nest-Egg/work/batch1020b');sha=lambda b:hashlib.sha256(b).hexdigest()
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
receipt=json.loads((w/'changed-receipt.json').read_text());assert receipt['exit_code']==0
text=(w/'changed.log').read_text();assert 'new failures: 0' in text and 'Detected script errors' not in text
assert json.loads((w/'original-test-reconstruction.json').read_text())['existing_assertions_inputs_waits_byte_exact_and_in_order']
rows=json.loads((w/'native-receipt.json').read_text());assert len(rows)==2 and all(r['exit_code']==r['expected'] and r['engine_errors']==0 and r['leaks']==0 and r['completed'] for r in rows)
view=json.loads((w/'viewed.json').read_text());assert view['individually_viewed'] and len(view['files'])==8
harness=['tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']
for p in harness:assert (root/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p]),p
files={}
for p in w.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in x or x=='__pycache__' for x in p.relative_to(w).parts):files['work/ne228-hover-events/'+str(p.relative_to(w))]=p.read_bytes()
for p in native.glob('ne228-1022-hover-events-*'):
 if 'profile' in p.name:continue
 if p.is_dir():
  for f in p.rglob('*'):
   if f.is_file():files['native/'+str(f.relative_to(native))]=f.read_bytes()
 elif p.is_file():files['native/'+p.name]=p.read_bytes()
paths=list(json.loads((w/'verification-frozen-source.json').read_text()))+harness+['design/20-campaign-experience/RADIO_HOVER_VISIBILITY.md']
for p in paths:files['source/final/'+p]=(root/p).read_bytes()
for p in ['autoload/event_bus.gd','ui/dialogue_layer.gd','ui/kit/background_hover_guard.gd','tests/helpers/hud_background_hover_checks.gd']:files['source/before/'+p]=subprocess.check_output(['git','show',base+':'+p])
refs=root/'pm/Nest-Egg/attachments/NE-229-recovery-references'
for p in ['hollow-knight-game-menu.jpg','hades-main-menu.jpg','sources.json']:files['references/'+p]=(refs/p).read_bytes()
validation={'base':base,'additional_checks':9,'unit':'final76/6 before,76/0 after; earlier75/5 before,75/0 after retained','affected':receipt,'affected_summary':[l for l in text.splitlines() if 'checks:' in l or re.search(r'Running \d+ groups',l)],'native':rows,'viewed':view,'harness_unchanged':harness,'observed_gap':'original immediate visible radio root with guard false and same actual tooltip id; native before snapshot proves both. After snapshot guard true and tooltip id0. Close inverse also synchronously fixed.','prior_failures':'BG50 first50:55025/1 explosion budget; second50:55025/2 original radio hover checks; diagnostic same10 groups8774/0. Raw runs and observer retained; original two failures lacked failure-time state, so same-call gap is demonstrated without inventing unique original cause.','scope':'actual authored pawnshop Level, production HDR environment, real engine tooltip, explicit radio text fixtures, visible mouse, isolated run and presentation reset. Observer ALWAYS, Level PAUSABLE. Sync snapshot precedes render; screenshots after original typewriter completion may look correct on both versions because old polling already ran. No claim of captured overlap frame, natural human chapter, physical GPU/controller or full joint acceptance.'}
out.mkdir(parents=True,exist_ok=True);(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
validation['first_affected_run']=json.loads((w/'first-changed-receipt.json').read_text())
validation['first_affected_failure']='Actual selector76 groups,90856 checks,1 unchangedAmmoTray crossing29.6px >24 threshold,555s. Earlier commentary said88 incorrectly and was corrected. Raw head preserved.'
validation['ammo_comparison']=json.loads((w/'ammo-comparison.json').read_text())
validation['resource_envelope']=json.loads((w/'resource-envelope.json').read_text())
(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for p,b in files.items():assert sha(z.read(p))==sha(b),p
m={'archive_bytes':(out/'raw.zip').stat().st_size,'archive_sha256':sha((out/'raw.zip').read_bytes()),'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for source,dest in [('tooltip-before-radio','tooltip'),('radio-visible','radio'),('actual-tooltip-window','tooltip-window')]:shutil.copyfile(native/'ne228-1022-hover-events-after-v2'/(source+'.png'),root/('pm/Nest-Egg/images/NE-228-hover-events-'+dest+'.png'))
r={'entries':len(files),'bytes':m['archive_bytes'],'sha256':m['archive_sha256']};(w/'package-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
