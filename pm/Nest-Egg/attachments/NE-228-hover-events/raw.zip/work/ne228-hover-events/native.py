from pathlib import Path
import subprocess,os,json,time,hashlib,re
w=Path('work/ne228-hover-events');paths=['autoload/event_bus.gd','ui/dialogue_layer.gd','ui/kit/background_hover_guard.gd'];final={p:Path(p).read_bytes() for p in paths};rows=[];env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen'
files=paths+['tests/helpers/hud_background_hover_checks.gd','work/ne228-hover-events/native.gd','tools/viewport_capture.gd']
(w/'native-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2))
def run(label,expected):
 name='ne228-1022-hover-events-'+label+'-v2';cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/ne228-hover-events/native.tscn'];start=time.monotonic()
 with (w/('native-'+label+'-wrapper.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=500)
 b=Path('/workspace/Nest-Egg/work/batch1020b');log=(b/(name+'.log')).read_text();report=json.loads((b/name/'result.json').read_text());rec={'name':name,'command':cmd,'exit_code':r.returncode,'expected':expected,'seconds':time.monotonic()-start,'engine_errors':log.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log)),'checks':report['checks'],'failures':report['failures'],'completed':report['completed']};rows.append(rec);(w/'native-receipt.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rec),flush=True);assert r.returncode==expected and rec['engine_errors']==0 and rec['leaks']==0 and rec['completed'];assert len(list((b/name).glob('*.png')))==4
try:
 for p in paths:Path(p).write_bytes((w/(Path(p).stem+'-before.gd')).read_bytes())
 run('before',1)
finally:
 for p,b in final.items():Path(p).write_bytes(b)
run('after',0)
