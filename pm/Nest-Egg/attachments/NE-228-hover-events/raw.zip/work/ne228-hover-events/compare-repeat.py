from pathlib import Path
import subprocess,os,json,time,shutil,hashlib
w=Path('work/ne228-hover-events');assert json.loads((w/'changed-receipt.json').read_text())['exit_code']==1
for f in ['changed.log','changed-receipt.json']:shutil.copyfile(w/f,w/('first-'+f))
shutil.copytree(w/'changed-shards',w/'first-changed-shards',dirs_exist_ok=True)
paths=['autoload/event_bus.gd','ui/dialogue_layer.gd','ui/kit/background_hover_guard.gd','tests/helpers/hud_background_hover_checks.gd'];final={p:Path(p).read_bytes() for p in paths};rows=[]
env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1')
def cpu_state():return {'cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'cpu_stat':Path('/sys/fs/cgroup/cpu.stat').read_text(),'time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
try:
 for label in ['baseline','current']:
  for p in paths:Path(p).write_bytes(subprocess.check_output(['git','show','7a29f753:'+p]) if label=='baseline' else final[p])
  cmd=['tools/run_tests_parallel.sh','--only=AmmoTraySuite'];e=env.copy();e['LOG_DIR']=str((w/(label+'-ammo-shards')).resolve());start=time.monotonic()
  with (w/(label+'-ammo.log')).open('w') as f:r=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=400)
  log=(w/(label+'-ammo-shards')/'shard_0.log').read_text();row={'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'source_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths},'summary':[l for l in log.splitlines() if l.startswith('checks:') or l.startswith('FAIL:')]};rows.append(row);(w/'ammo-comparison.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
finally:
 for p,b in final.items():Path(p).write_bytes(b)
assert len(rows)==2 and all(r['exit_code']==0 for r in rows),'paired comparison requires investigation'
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
budget={'before':cpu_state(),'shards':2,'reason':'4CPU quota; reserve capacity for engine workers; original predicates/inputs/waits, selector, filters and known-failure list unchanged'}
(w/'resource-envelope.json').write_text(json.dumps(budget,indent=2))
env.update(SHARDS='2',LOG_DIR=str((w/'changed-shards').resolve()));cmd=['tools/run_tests_changed.sh','7a29f7535f60cef70cbb3c6deafb2790fb897975'];start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=3600)
(w/'changed-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'shards':2},indent=2));budget['after']=cpu_state();(w/'resource-envelope.json').write_text(json.dumps(budget,indent=2));assert r.returncode==0
print('RESOURCE_BOUNDED_FULL_PASS',flush=True)
