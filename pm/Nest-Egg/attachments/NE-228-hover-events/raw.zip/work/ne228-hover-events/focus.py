from pathlib import Path
import subprocess,os,json,time,hashlib
w=Path('work/ne228-hover-events');paths=['autoload/event_bus.gd','ui/dialogue_layer.gd','ui/kit/background_hover_guard.gd'];final={p:Path(p).read_bytes() for p in paths};rows=[];env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1')
def run(label):
 e=env.copy();e['LOG_DIR']=str((w/(label+'-shards')).resolve());cmd=['tools/run_tests_parallel.sh','--only=CombatHudSuite'];start=time.monotonic()
 with (w/(label+'.log')).open('w') as f:r=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=200)
 rows.append({'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start});(w/'focus-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);return r.returncode
try:
 for p in paths:Path(p).write_bytes((w/(Path(p).stem+'-before.gd')).read_bytes())
 assert run('negative')==1
finally:
 for p,b in final.items():Path(p).write_bytes(b)
assert run('fixed')==0
