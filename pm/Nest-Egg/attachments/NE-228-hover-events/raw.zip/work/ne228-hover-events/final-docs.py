from pathlib import Path
import json
w=Path('work/ne228-hover-events');out=Path('pm/Nest-Egg/attachments/NE-228-hover-events');r=json.loads((w/'changed-receipt.json').read_text());assert r['exit_code']==0
text=(w/'changed.log').read_text();summary=[l for l in text.splitlines() if l.startswith('checks:')][-1];assert 'new failures: 0' in summary
packet=json.loads((w/'package-receipt.json').read_text())
(out/'README.md').write_text(f'''# NE-228：通訊可見性與背景說明同步

通訊面板顯示／隱藏與來源離樹時，同步更新背景Hover守門，保留原實際可見性查詢與每格後備輪詢。延遲但尚未顯示不擋背景；關閉其中一個來源不能解除其他可見來源。[設計與參照](../../../../design/20-campaign-experience/RADIO_HOVER_VISIBILITY.md)、[完整收據](validation.json)、[原檔](raw.zip)、[逐項SHA](manifest.json)。

最終原CombatHud只新增9項，修前76／6、修後76／0；初版新增8項75／5→75／0也完整保留。既有原斷言、輸入、等待逐位元且順序相同；沒有延長原兩物理影格、清空原佇列或放寬判斷。原runner、selector、filters與known_failures不變。

原生最終v2修前13／5、修後13／0；兩程序0引擎ERROR、0退出洩漏診斷，八張原圖逐張檢視，包括各自真正引擎Tooltip視窗PNG。原生v1修後12／0的圖片只顯示逐字中途，另留原檔；v2只等原typewriter自然完成並新增完整文字見證，不改產品時長。新同步snapshot在任何等待／渲染前：原版radio_visible=true、guard=false，Tooltip仍是原instance；新版guard=true、Tooltip id0。關閉原版guard仍true，新版即false。

畫面讀回是在後續render：原版輪詢在下一次畫面更新也已收起Tooltip，因此前後radio圖都可正常分層。圖與同次呼叫快照不是同一時點，不聲稱拍到Tooltip壓字影格。同步狀態與真實視窗生命週期由原生負控制證明，不能拿後畫面正常說原同步已正確。

原選擇器、固定基準7a29f753：{summary}；程序含準備{r['seconds']:.2f}秒。全部分片原log在zip，沒有把刻意容錯ERROR當成原生無ERROR。

本票原選擇器實際是76組；首輪六程序90,856項有1項未改動的彈帶切換點超標（29.6畫面像素，原嚴格小於24），555秒。未修改7a與本次來源獨立同一彈帶套件各33／0；未重現不稱已修復彈帶根因。容器cpu.max=400000/100000，實際四核心配額；最後同來源改兩程序保留引擎背景工作空間，沒有改選擇器、原判準、輸入、等待或已知失敗清單。前後cpu.stat與實際分組保留。先前口頭把組數說成88已更正，全部正式收據按原76組。driver標記FULL指選出範圍全跑，不是全專案88組。

先前BG-50第一輪50組55,025／1是獨立爆炸效能超標；第二輪55,025／2是原通訊守門斷言。同一原十組加唯讀觀察8774／0，兩項在該次未重現，但明確看到同呼叫可見root／guard不同步。原兩項缺失敗當刻快照，故不逕稱唯一原根因。全部失敗、探針與先前7a完整CI96007／0／0、550秒的job log保留。BG-50暖檔修正與另一批HUD空間調整仍在各自分支，沒有混入此提交。

實際重看Hollow Knight暫停圖與Hades主選單圖，借用活動資訊層次；不從圖片推論Tooltip事件或偏好民調。原圖、既有來源URL／SHA都收於zip，來源對照仍可回到NE-229原附件。

軟體Forward+／HDR／Vulkan llvmpipe，Dummy音訊；真當舖Level與真引擎Tooltip，通訊台詞為明示顯示fixture，已隔離設定、指定可見滑鼠並重設演出。觀察節點ALWAYS、Level保留PAUSABLE。這不是正式故事producer、人工自然通關、實體手把／硬體GPU或完整角色關節驗收，整票原未勾條件保持。

原檔{packet['entries']}項、{packet['bytes']:,} bytes，zip SHA `{packet['sha256']}`，逐項解出核對完成。
''')
p=Path('pm/Nest-Egg/[NE-228]重整全遊戲介面體驗.md');s=p.read_text();assert '# Commit-22' not in s
s+='''\n\n# Commit-22

## 內文

通訊剛顯示時，背景說明原本要等後續畫面更新才收起；剛關閉時也可能晚恢復。現在依面板真正可見性同步收起／恢復。延遲而尚未顯示的通訊不阻擋背景，關閉其中一個來源不會解除另一個可見來源，最後來源離開場景也立即恢復。

先讀User-guide並重看Hollow Knight與Hades原參照圖，活動資訊層級與同步時序的證據分開。原失敗沒有當刻快照，不補造唯一根因；新增同次呼叫負控制，用真正引擎Tooltip核對。[設計與參照](../../design/20-campaign-experience/RADIO_HOVER_VISIBILITY.md)、[全部成功／失敗、原生快照與八張逐張檢視原圖](attachments/NE-228-hover-events/README.md)。

### 測試結果

| 項目 | 結果 |
|---|---|
| 原戰鬥HUD＋9項 | 修前76／6；修後76／0，原斷言／輸入／等待保持 |
| 原生同步狀態與真Tooltip | 修前13／5；修後13／0；兩程序0引擎ERROR、0退出洩漏診斷 |
| 首輪原76組回歸 | 90,856項／1項未改動的彈帶超標（29.6像素，原小於24）；原暖檔、通訊守門與其餘75組通過 |
| 該彈帶套件隔離比較 | 未修改main與本次來源各33／0；未重現首次超標，門檻與程式保持 |
'''+f'| 原選擇器、基準7a29f753 | {summary} |\n'+'''
後續渲染時舊輪詢也會收起說明，原生圖用來看清實際界面，失敗與修復時點以同次呼叫快照判斷；沒有稱圖片拍到重疊。軟體Vulkan、顯示fixture與人工／實體條件分開，本票保持進行中。

### 本作原生畫面

![真正引擎工具提示已出現的前置狀態](images/NE-228-hover-events-tooltip.png)
![原工具提示視窗本體](images/NE-228-hover-events-tooltip-window.png)
![通訊逐字完整後的讀回；同步狀態另見原始快照](images/NE-228-hover-events-radio.png)
''';p.write_text(s)
p=Path('pm/user_guide.md');s=p.read_text();line='2026-10-22（NE-228）：通訊真正可見性改變時同步更新背景說明守門，不等畫面輪詢；延遲未顯示、多來源與離樹一併核對。[原76／6→76／0、原生13／5→13／0與八張原圖](Nest-Egg/attachments/NE-228-hover-events/README.md)。畫面讀回晚於同次呼叫，舊版下一格也會正確，不能宣稱後圖拍到重疊；原兩項偶發失敗的唯一根因不補造。BG-50與HUD空間修改保存在各自分支，此項不代勾整票。\n\n';assert line not in s;p.write_text(line+s)
print(summary)
