extends "res://tests/smoke_test.gd"
func _check(condition:bool,message:String)->void:
	if message in ["通訊前說明正常出現（前置條件）","可以播放通訊","通訊面板出現時守門啟動","通訊出現時已顯示的背景說明立即收起"]:
		var layers:Array=[]
		for id:int in DialogueLayer._radio_layers:
			var node:Variant=DialogueLayer._radio_layers[id].get_ref()
			if is_instance_valid(node):layers.append({"id":id,"is_story_layer":is_same(node,Story._layer),"inside_tree":node.is_inside_tree(),"process_mode":node.process_mode,"can_process":node.can_process(),"cinematic":String(node._cinematic_id),"radio_active":node._radio_active,"radio_wait":node._radio_wait,"radio_hold":node._radio_hold,"root_visible":node._radio_root.visible,"root_visible_tree":node._radio_root.is_visible_in_tree(),"alpha":node._radio_root.modulate.a,"queue":node._radio_queue})
		var guards:Array=[]
		for node in get_tree().root.get_children():
			if node is Level and node.hud!=null:guards.append({"level":node.get_instance_id(),"blocked":node.hud.hover_guard.blocked,"can_process":node.hud.hover_guard.can_process(),"process_mode":node.hud.hover_guard.process_mode})
		print("RADIO_HOVER_DIAG ",JSON.stringify({"check":message,"passed":condition,"physics_frame":Engine.get_physics_frames(),"process_frame":Engine.get_process_frames(),"time_usec":Time.get_ticks_usec(),"time_scale":Engine.time_scale,"paused":get_tree().paused,"locked":GameplayLock.is_locked(),"current_cinematic":String(Story._current_cinematic),"radio_visible":DialogueLayer.radio_visible(),"layers":layers,"guards":guards}))
	super._check(condition,message)
