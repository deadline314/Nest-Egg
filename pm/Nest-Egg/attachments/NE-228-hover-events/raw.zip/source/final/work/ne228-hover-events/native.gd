extends Node
const Capture := preload("res://tools/viewport_capture.gd")
const Hover := preload("res://tests/helpers/hud_background_hover_checks.gd")
var out := ""
var checks := 0
var failures := 0
var snapshots: Array = []
func _ready()->void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	Engine.max_fps=60
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
	_run.call_deferred()
func check(value:bool,label:String)->void:
	checks+=1
	if not value:failures+=1
	print("HOVER_CHECK ",value," ",label)
func frames(count:int)->void:
	for i in count:await get_tree().process_frame
func state(label:String,level:Level)->void:
	var tip:=Hover._tooltip(level.hud.credits_tag)
	snapshots.append({"label":label,"physics_frame":Engine.get_physics_frames(),"process_frame":Engine.get_process_frames(),"time_usec":Time.get_ticks_usec(),"radio_visible":DialogueLayer.radio_visible(),"blocked":level.hud.hover_guard.blocked,"tooltip_id":tip.get_instance_id() if is_instance_valid(tip) else 0,"paused":get_tree().paused,"radio_alpha":Story._layer._radio_root.modulate.a})
	print("HOVER_STATE ",JSON.stringify(snapshots.back()))
func shot(label:String)->void:
	await RenderingServer.frame_post_draw
	check(Capture.image(get_viewport()).save_png(out.path_join(label+".png"))==OK,"native capture "+label)
func _run()->void:
	DirAccess.make_dir_recursive_absolute(out)
	add_child(LightKit.create_environment())
	GameState.start_new_run(GameState.difficulties[1])
	GameState.story_autosave=false
	Story.auto_skip=true
	var level:=Level.new()
	level.process_mode=Node.PROCESS_MODE_PAUSABLE
	level.configure(load("res://data/levels/ch1_pawnshop.tres") as LevelData)
	add_child(level)
	await frames(12)
	# This is a declared presentation fixture, without campaign result production.
	Story.reset_active_presentation(&"hover_fixture")
	await frames(4)
	Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
	var target:Control=level.hud.credits_tag
	Hover._park(get_viewport())
	await frames(2)
	var rect:Rect2=target.get_global_transform_with_canvas()*Rect2(Vector2.ZERO,target.size)
	Hover._move(get_viewport(),rect.get_center())
	var deadline:=Time.get_ticks_msec()+3000
	while Hover._tooltip(target)==null and Time.get_ticks_msec()<deadline:await get_tree().process_frame
	check(Hover._tooltip(target)!=null and not level.hud.hover_guard.blocked,"real engine tooltip is visible before the radio fixture")
	state("tooltip-before-radio",level)
	await shot("tooltip-before-radio")
	var tooltip:=Hover._tooltip(target)
	if tooltip!=null:
		check(Capture.image(tooltip).save_png(out.path_join("actual-tooltip-window.png"))==OK,"actual engine tooltip window capture")
	var lines:Array[Dictionary]=[{"name":"芽","color":Palette.CYAN,"portrait":"res://art/portraits/mei.png","text":"通訊顯示時，背景操作說明應同步收起。"}]
	var layer:DialogueLayer=Story._layer
	layer.enqueue_radio(&"ne228_hover_fixture",lines)
	state("radio-open-same-call",level)
	check(DialogueLayer.radio_visible() and level.hud.hover_guard.blocked,"actual panel visibility synchronously guards the background")
	check(Hover._tooltip(target)==null,"the actual existing tooltip retires in the same call")
	var read_deadline:=Time.get_ticks_msec()+10000
	while layer._radio_text.visible_ratio<1.0 and Time.get_ticks_msec()<read_deadline:await get_tree().process_frame
	check(layer._radio_text.visible_ratio>=1.0,"the actual typewriter completes before the readable radio capture")
	await shot("radio-visible")
	layer.cancel_radio()
	state("radio-close-same-call",level)
	check(not level.hud.hover_guard.blocked,"closing synchronously releases this visible owner")
	await frames(2)
	await shot("radio-closed")
	var other:=DialogueLayer.new()
	add_child(other)
	other.enqueue_radio(&"ne228_other_fixture",lines)
	check(DialogueLayer.radio_visible() and level.hud.hover_guard.blocked,"another actual layer also guards synchronously")
	layer.enqueue_radio(&"ne228_parallel_fixture",lines)
	layer.cancel_radio()
	check(other._radio_root.visible and level.hud.hover_guard.blocked,"closing one owner never clears another visible owner")
	remove_child(other)
	check(not DialogueLayer.radio_visible() and not level.hud.hover_guard.blocked,"removing the final visible owner releases its guard")
	other.queue_free()
	level.queue_free()
	await frames(4)
	check(not is_instance_valid(level),"the actual level and tooltip owner finish teardown")
	FileAccess.open(out.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify({"completed":true,"checks":checks,"failures":failures,"snapshots":snapshots,"scope":"actual authored pawnshop Level, production HDR environment, real engine tooltip and explicit radio presentation fixtures; isolated run, visible mouse and presentation reset declared. No Story result, human route, physical GPU/controller or rendered joint acceptance. Sync state snapshot precedes render; radio image waits for the original typewriter to complete."},"\t"))
	print("checks: %d, failures: %d"%[checks,failures])
	get_tree().quit(1 if failures else 0)
