from pathlib import Path

root=Path.cwd()
base=Path(__file__).resolve().parent
path=root/"autoload/input_bindings.gd"
original=path.read_text(encoding="utf-8")
updated=original

def replace(old,new):
    global updated
    assert updated.count(old)==1,old
    updated=updated.replace(old,new)

replace('''	JOY_BUTTON_DPAD_UP: "十字↑", JOY_BUTTON_DPAD_DOWN: "十字↓",
	JOY_BUTTON_DPAD_LEFT: "十字←", JOY_BUTTON_DPAD_RIGHT: "十字→",
}

const FACE_BUTTON_POSITIONS''','''}

const PAD_ARROWS: Dictionary[int, String] = {
	JOY_BUTTON_DPAD_UP: "↑", JOY_BUTTON_DPAD_DOWN: "↓",
	JOY_BUTTON_DPAD_LEFT: "←", JOY_BUTTON_DPAD_RIGHT: "→",
}

const PAD_TERMS := {
	"zh": {"direction_pad": "十字", "left_stick": "左搖桿", "right_stick": "右搖桿",
		"menu": "%s 選單", "button": "按鈕 %d"},
	"ja": {"direction_pad": "十字キー", "left_stick": "左スティック", "right_stick": "右スティック",
		"menu": "%s メニュー", "button": "ボタン %d"},
	"en": {"direction_pad": "D-pad ", "left_stick": "Left stick ", "right_stick": "Right stick ",
		"menu": "%s menu", "button": "Button %d"},
}

const FACE_BUTTON_POSITIONS''')
replace('''		var language := Story.language if is_instance_valid(Story) else StoryLocale.SOURCE_LANGUAGE
		var labels: Dictionary = MOUSE_LABELS.get(language, MOUSE_LABELS[StoryLocale.SOURCE_LANGUAGE])''','''		var labels: Dictionary = MOUSE_LABELS.get(_input_language(), MOUSE_LABELS[StoryLocale.SOURCE_LANGUAGE])''')
replace('''		return "%s 選單" % joy_label(&"pause")''','''		return _pad_terms(_input_language())["menu"] % joy_label(&"pause")''')
replace('''func _stick_label(axis: int, direction: float) -> String:
	var stick := "右搖桿" if axis in [JOY_AXIS_RIGHT_X, JOY_AXIS_RIGHT_Y] else "左搖桿"''','''func _input_language() -> String:
	return Story.language if is_instance_valid(Story) else StoryLocale.SOURCE_LANGUAGE


func _pad_terms(language: String) -> Dictionary:
	return PAD_TERMS.get(language, PAD_TERMS[StoryLocale.SOURCE_LANGUAGE])


func _stick_label(axis: int, direction: float) -> String:
	var terms := _pad_terms(_input_language())
	var stick: String = terms["right_stick"] if axis in [JOY_AXIS_RIGHT_X, JOY_AXIS_RIGHT_Y] else terms["left_stick"]''')
replace('''func _button_label(button: int) -> String:
	var name := Input.get_joy_name(active_device).to_lower() if active_device >= 0 else ""''','''func _button_label(button: int) -> String:
	var language := _input_language()
	var terms := _pad_terms(language)
	if PAD_ARROWS.has(button):
		return terms["direction_pad"] + PAD_ARROWS[button]
	var fallback: String = JOY_BUTTON_LABELS.get(button, "")
	if fallback.is_empty():
		fallback = terms["button"] % button
	var name := Input.get_joy_name(active_device).to_lower() if active_device >= 0 else ""''')
assert updated.count('JOY_BUTTON_LABELS.get(button, "按鈕 %d" % button)')==3
updated=updated.replace('JOY_BUTTON_LABELS.get(button, "按鈕 %d" % button)','fallback')
replace('''		var language := Story.language if is_instance_valid(Story) else StoryLocale.SOURCE_LANGUAGE
		var positions: Dictionary = FACE_BUTTON_POSITIONS.get(language, FACE_BUTTON_POSITIONS[StoryLocale.SOURCE_LANGUAGE])''','''		var positions: Dictionary = FACE_BUTTON_POSITIONS.get(language, FACE_BUTTON_POSITIONS[StoryLocale.SOURCE_LANGUAGE])''')
(base/"input-candidate.gd.txt").write_text(updated,encoding="utf-8",newline="\n")
