param([Parameter(Mandatory)][string]$Label,[string]$Resolution='1280x720')
$ErrorActionPreference='Stop'
$e=$PSScriptRoot.Replace('\','/')
$d='D:/NestEggVerification/ne218-baseline-20261117'
$out="$e/$Label"
New-Item -ItemType Directory -Path "$out/profile" | Out-Null
$env:APPDATA="$out/profile"
$env:LOCALAPPDATA=$env:APPDATA
$engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$py='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
& $py -B "$d/tools/comfyui/gpu_lock.py" -- $engine --path $d --rendering-method forward_plus --rendering-driver vulkan --resolution $Resolution --fixed-fps 60 --audio-driver Dummy --quit-after 3000 "$e/probe.tscn" -- "--out=$out" *> "$out/raw.log"
$code=$LASTEXITCODE
$code | Set-Content -LiteralPath "$out/exit.txt"
Get-Content -LiteralPath "$out/raw.log" -Tail 24
exit $code
