extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/level_01.tres")
const LABELS := {
	"zh": ["十字", "左搖桿", "右搖桿", "%s 選單", "按鈕 63"],
	"ja": ["十字キー", "左スティック", "右スティック", "%s メニュー", "ボタン 63"],
	"en": ["D-pad ", "Left stick ", "Right stick ", "%s menu", "Button 63"],
}
var _out: String
var _checks := 0
var _failures: Array[String] = []
var _records: Array[Dictionary] = []


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path():
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://pad_direction_probe.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.auto_skip = true
	for language: String in LABELS:
		await _observe(language)
	var result := {"adapter": RenderingServer.get_video_adapter_name(),
		"renderer": RenderingServer.get_current_rendering_method(), "window_size": [get_window().size.x, get_window().size.y],
		"font_scale": Settings.get_ui_text_scale(), "checks": _checks, "failures": _failures, "rows": _records}
	var file := FileAccess.open(_out.path_join("summary.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(result, "  ") + "\n")
	file.close()
	print("PAD_DIRECTIONS ", _checks, " checks ", _failures.size(), " failures")
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(not _failures.is_empty()))


func _observe(language: String) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.language = language
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	for i in 5:
		await get_tree().process_frame
	var motion := InputEventJoypadMotion.new()
	motion.device = 999
	motion.axis = JOY_AXIS_RIGHT_X
	motion.axis_value = 0.0
	Input.parse_input_event(motion)
	Input.flush_buffered_events()
	motion = motion.duplicate() as InputEventJoypadMotion
	motion.axis_value = 0.9
	Input.parse_input_event(motion)
	Input.flush_buffered_events()
	await get_tree().process_frame
	_check(InputBindings.using_gamepad and InputBindings.active_device == 999, language + "/synthetic_pad")
	var prefix: Array = LABELS[language]
	var actions: Array[StringName] = [&"ui_up", &"ui_down", &"ui_left", &"ui_right"]
	var arrows := ["↑", "↓", "←", "→"]
	for i in actions.size():
		_check(InputBindings.primary_label(actions[i]) == prefix[0] + arrows[i], language + "/" + str(actions[i]))
	_check(InputBindings.joy_label(&"aim_up") == prefix[2] + "↑", language + "/aim_up")
	_check(InputBindings.joy_label(&"aim_right") == prefix[2] + "→", language + "/aim_right")
	_check(InputBindings._stick_label(JOY_AXIS_LEFT_X, -1.0) == prefix[1] + "←", language + "/move_left_axis")
	_check(InputBindings.joy_label(&"map") == prefix[3] % "Start", language + "/map")
	_check(InputBindings.joy_label(&"quests") == prefix[3] % "Start", language + "/quests")
	_check(InputBindings._button_label(63) == prefix[4], language + "/unknown_button")
	var bag := level.player.consumables
	var quick := bag.quick_use_item()
	_check(bag.add(quick), language + "/actual_bag_updates")
	var label := level.hud._items_label
	await RenderingServer.frame_post_draw
	var quick_hint: String = prefix[0] + "↑"
	_check(label.visible and label.text.ends_with(quick_hint), language + "/hud_caption")
	_check(label.tooltip_text.contains(quick_hint), language + "/hud_tooltip")
	var rect := label.get_global_rect()
	_check(get_viewport().get_visible_rect().encloses(rect) and rect.size.x >= label.get_minimum_size().x,
		language + "/hud_caption_fits")
	_check(Capture.image(get_viewport()).save_png(_out.path_join(language + "-pad.png")) == OK, language + "/native_frame")
	_records.append({"language": language, "caption": label.text, "tooltip": label.tooltip_text,
		"map": InputBindings.joy_label(&"map"), "aim": InputBindings.joy_label(&"aim_up"),
		"size": [rect.size.x,rect.size.y], "render_size": [get_viewport().size.x,get_viewport().size.y]})
	var key := InputEventKey.new()
	key.keycode = KEY_K
	key.physical_keycode = KEY_K
	key.pressed = true
	Input.parse_input_event(key)
	Input.flush_buffered_events()
	await get_tree().process_frame
	_check(not InputBindings.using_gamepad and label.text.ends_with(InputBindings.code_label(KEY_Q)),
		language + "/keyboard_refresh")
	key = key.duplicate() as InputEventKey
	key.pressed = false
	Input.parse_input_event(key)
	Input.flush_buffered_events()
	level.queue_free()
	for i in 5:
		await get_tree().process_frame


func _check(condition: bool, message: String) -> void:
	_checks += 1
	if not condition:
		print("FAIL ", message)
		_failures.append(message)
