from pathlib import Path
from statistics import median
import hashlib, json, os, shutil, subprocess, sys

root=Path.cwd()
base=Path('C:/NE/ne275-grip-20261119')
out=root/'work/ne275-base-redraw-frame-pairs-20261119'
change=root/'work/ne275-texture-redraw-20261119'
assert json.loads((change/'integration/verification.json').read_text())=={'exit':0,'errors':[],'source_held':True}
project=Path('D:/NestEggVerification/evidence-20261117/st15-runtime-locale-20261119/runtime')
changed=json.loads((change/'paths.json').read_text())
backup={name:(project/name).read_bytes() for name in (*changed,'core/melee_art.gd')}
out.mkdir(exist_ok=True)
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
source=root/'work/ne275-historic-frames-20261119.gd'
weapon_names=('blade','dagger','glaive','maul','whip')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
variants=('before','after')
held={}
for label in variants:
    held[label]={'source_sha256':{name:sha(change/(label+'.gd')) for name in changed}}

script=out/'probe.gd'
text=source.read_text(encoding='utf-8')
text=text.replace('dedicated != _tag.begins_with("after")', 'not dedicated')
script.write_text(text,encoding='utf-8',newline='\n')
scene=out/'probe.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{script.as_posix()}" id="1"]\n[node name="GripBenchmark" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')

def run(label,trial):
    tag=f'{label}-{trial}'
    target=out/tag
    target.mkdir()
    profile=out/f'{label}-profile'
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(profile/key)
    for name in changed:
        shutil.copyfile(change/(label+'.gd'),project/name)
    args=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',engine,'--path',str(project),
          '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720',
          '--quit-after','22000',scene.as_posix(),'--','--out='+str(target),'--tag='+tag,'--quality=high','--perf']
    (target/'command.json').write_text(json.dumps(args,indent=2)+'\n')
    with (target/'raw.log').open('wb') as log:
        p=subprocess.run(args,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    raw=(target/'raw.log').read_text(encoding='utf-8')
    print(tag,p.returncode,raw[-680:],flush=True)
    assert p.returncode==0 and 'SCRIPT ERROR' not in raw
    assert f'NE275_HISTORIC_TIMING: {tag} weapons=5 failures=0' in raw
    data=json.loads((target/'grip-timings.json').read_text(encoding='utf-8'))
    assert data['resolution']==[1280,720] and data['vsync']==data['max_fps']==data['failures']==0
    assert '9070 XT' in data['gpu'] and data['renderer']=='forward_plus'
    assert not data['reduced_flashes'] and not data['reduced_ui_motion']
    assert sorted(data['records'])==sorted(weapon_names)
    for item in data['records'].values():
        assert item['drawn'] and item['dedicated_attachment'] and len(item['samples_ms'])==600 and item['physics_steps']>=10 and item['scene_draw_calls']>0
    assert all(sha(project/name)==digest for name,digest in held[label]['source_sha256'].items())
    return {weapon:median(data['records'][weapon]['samples_ms']) for weapon in weapon_names}

pairs=[]
try:
    shutil.copyfile(root/'core/melee_art.gd',project/'core/melee_art.gd')
    for label in variants:
        run(label,'warm')
    for index in range(6):
        order=variants if index%2==0 else variants[::-1]
        values={label:run(label,f'p{index+1}') for label in order}
        pairs.append({'order':list(order),**values})
finally:
    for name,payload in backup.items():
        (project/name).write_bytes(payload)
records={}
for weapon in weapon_names:
    starts=[p['before'][weapon] for p in pairs]
    ends=[p['after'][weapon] for p in pairs]
    changes=[(a/b-1)*100 for a,b in zip(ends,starts)]
    records[weapon]={'before_median_ms':median(starts),'before_min_ms':min(starts),'before_max_ms':max(starts),
                     'after_median_ms':median(ends),'after_min_ms':min(ends),'after_max_ms':max(ends),
                     'paired_median_pct':median(changes),'paired_min_pct':min(changes),'paired_max_pct':max(changes)}
summary={'scope':'Five current melee weapons on identical hardware, source and scenario. Only the request to redraw the textured reflective Sprite2D differs. Whole rendered idle frame, warm shaders, production scripts uninstrumented.','sources':held,'probe_sha256':sha(script),'pairs':pairs,'results':records}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(records,indent=2),flush=True)
