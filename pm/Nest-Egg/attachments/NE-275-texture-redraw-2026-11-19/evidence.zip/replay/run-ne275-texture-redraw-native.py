from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

root=Path.cwd()
prior=root/'work/bg50-cold-prefetch-20261119/integration/publish/result.json'
assert json.loads(prior.read_bytes())['main_origin_head_equal']
base=root/'work/ne275-texture-redraw-20261119'
project=Path('D:/NestEggVerification/evidence-20261117/st15-runtime-locale-20261119/runtime')
held='game/player/melee_held.gd'
art='core/melee_art.gd'
backup={name:(project/name).read_bytes() for name in (held,art)}
assert (base/'before.gd').read_bytes()==(root/held).read_bytes()
results={}
try:
    shutil.copyfile(root/art,project/art)
    for phase in ('before','after'):
        out=base/f'native-{phase}'
        out.mkdir()
        shutil.copyfile(base/f'{phase}.gd',project/held)
        script=out/'probe.gd'
        script.write_text((root/'work/ne275-texture-redraw-native.gd').read_text(encoding='utf-8-sig'),encoding='utf-8',newline='\n')
        scene=script.with_suffix('.tscn')
        scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{script.as_posix()}" id="1"]\n[node name="BaseRedraw" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')
        env=os.environ.copy()
        for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
            env[key]=str(out/'profile'/key)
        args=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
              '--path',str(project),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
              '--fixed-fps','60','--resolution','1280x720','--quit-after','3500',scene.as_posix(),'--','--out='+str(out),'--tag='+phase]
        (out/'command.json').write_text(json.dumps(args,indent=2)+'\n')
        (out/'source.json').write_text(json.dumps({name:hashlib.sha256((project/name).read_bytes()).hexdigest() for name in (held,art)},indent=2)+'\n')
        with (out/'raw.log').open('wb') as log:
            proc=subprocess.run(args,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=160)
        raw=(out/'raw.log').read_text(encoding='utf-8')
        print(phase,proc.returncode,raw[-1450:],flush=True)
        assert proc.returncode==0 and 'ERROR:' not in raw and 'NE275_BASE_REDRAW cases=7 failures=0' in raw
        result=json.loads((out/'base-redraw.json').read_bytes())
        assert result['failures']==0 and '9070 XT' in result['gpu']
        results[phase]=result['cases']
finally:
    for name,payload in backup.items():
        (project/name).write_bytes(payload)
assert all((project/name).read_bytes()==payload for name,payload in backup.items())
summary={}
for id,old in results['before'].items():
    new=results['after'][id]
    assert all(old[key]==new[key] for key in ('idle','attack','facing','textured','visible_attack'))
    assert old['idle_draws']>=59 and old['attack_draws']>=74
    expected=(old['idle_draws'],old['attack_draws']) if id=='fallback' else (0,0)
    assert (new['idle_draws'],new['attack_draws'])==expected,(id,old['idle_draws'],old['attack_draws'],new['idle_draws'],new['attack_draws'])
    matching={}
    for phase in ('idle','attack'):
        a=base/f'native-before/{id}-{phase}.png'
        b=base/f'native-after/{id}-{phase}.png'
        matching[phase]=a.read_bytes()==b.read_bytes()
    summary[id]={'before':[old['idle_draws'],old['attack_draws']], 'after':[new['idle_draws'],new['attack_draws']],
                 'pose_rows':len(old['idle'])+len(old['attack']), 'same_image_bytes':matching}
(base/'verified.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
