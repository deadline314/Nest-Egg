
from pathlib import Path
from collections import Counter
import json
base=Path(__file__).resolve().parent
prev=base.parent/'evidence-20261121-ne224-enforcer-waist'
def read(path,count):
    rows=json.loads(path.read_bytes())['failures']
    return {(r['joint'],r['pose'],r['zoom'],r['facing'],r['frame']):bool(r['center_alpha']<128 or r['enclosed_pixels'] or r['loose_pieces'])
            for r in rows if r['joint']=='neck' and r['frame']<count}
for name,old in (('dressed',prev/'final-neck/report.json'),('whole',base/'stock-whole/report.json'),
                 ('isolated',base/'stock-isolated/report.json')):
    before=read(old,36)
    result={}
    for version in ('try-a','try-b','try-c','try-d','try-e'):
        path=base/f'{version}-{name}'/'report.json'
        if not path.is_file():
            continue
        after=read(path,36)
        result[version]={'flags':len(after),'gaps':sum(after.values()),'new_flags':sorted(set(after)-set(before)),
                         'new_gaps':sorted(k for k,v in after.items() if v and not before.get(k,False)),
                         'remaining_by_pose':dict(Counter(k[1] for k,ok in after.items() if ok))}
    print(name,len(before),sum(before.values()),json.dumps(result))


