
from hashlib import sha256
from math import pi, sin
from pathlib import Path
import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent
root=Path('art/characters/enforcer/parts/torso.png')
assert sha256(root.read_bytes()).hexdigest()=='dcfe403ebd7efbd71ff58a362af02731dfafe58d066c59a978b2123016cd6d28'
with Image.open(root) as image:
    old=np.asarray(image.convert('RGBA'))
patch=old.copy()

import sys
mode=sys.argv[1]
if mode in ('a','d'):
    for y in range(72,101):
        shift=round(12*max(0.0,sin(pi*(y-72)/28))**0.6)
        margin=patch[y,220:244]
        source=old[y,220-shift:244-shift]
        grow=(margin[:,3]<235)&(source[:,3]>margin[:,3])
        margin[grow]=source[grow]
if mode in ('a','c','e'):
    for y,left,right in ((115,224,236),(116,227,236),(117,230,236)):
        margin=patch[y,left:right]
        margin[margin[:,3]<235]=old[114,177]
if mode=='e':
    for x in range(163,178):
        edge=23+int(np.flatnonzero(old[23:52,x,3]>=235)[0])
        up=round(7*max(0.0,sin(pi*(x-163)/14))**0.7)
        margin=patch[edge-up:edge,x]
        color=old[edge+6,x]
        margin[(margin[:,3]<235)&(margin[:,3]<color[3])]=color

changed=np.any(patch!=old,axis=2)
assert np.all(old[changed,3]<235) and np.all(patch[changed,3]>old[changed,3])
print(int(changed.sum()))
Image.fromarray(patch).save(base/('torso-'+mode+'.png'))


