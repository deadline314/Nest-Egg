
from pathlib import Path
from PIL import Image,ImageDraw
import json

base=Path(__file__).resolve().parent
sheet=Image.new('RGB',(572,572),'#212532')
draw=ImageDraw.Draw(sheet)
for row,facing in enumerate((1,-1)):
    for col,mode in enumerate(('stock','final')):
        folder=base/f'{mode}-whole'
        group=next(g for g in json.loads((folder/'frames.json').read_bytes()) if g['pose']=='block' and g['zoom']==3.4)
        x,y,_,_=next(c['rect'] for c in group['cells'] if c['facing']==facing)
        cx,cy=(83 if facing==1 else 44),66
        with Image.open(folder/group['samples'][12]['file']) as image:
            crop=image.crop((x+cx-26,y+cy-26,x+cx+26,y+cy+26)).convert('RGBA')
        bg=Image.new('RGBA',crop.size,'#a8b0c0')
        bg.alpha_composite(crop)
        at=(8+col*286,8+row*284)
        draw.text(at,f'{"Before" if col==0 else "With overlap"} / block / {"right" if facing==1 else "left"}',fill='white')
        sheet.paste(bg.convert('RGB').resize((260,260),Image.Resampling.NEAREST),(at[0],at[1]+17))
sheet.save(base/'guard-compare.png')

