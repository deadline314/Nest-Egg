
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json

import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent
root=Path.cwd()
previous=base.parent/'evidence-20261121-ne224-enforcer-waist'
assets=root/'art/characters/enforcer/parts'
outputs=root/'art_src/characters/enforcer'
def read(path):
    return json.loads(path.read_bytes())
def key(failure):
    return tuple(failure[name] for name in ('char','joint','pose','zoom','facing','frame'))
def gap(failure):
    return failure['center_alpha']<128 or failure['enclosed_pixels'] or failure['loose_pieces']
def digest(asset):
    return sha256(asset.read_bytes()).hexdigest()

summary={}
for mode,count,stock in (
    ('dressed',3840,previous/'final-neck'),('isolated',3840,base/'stock-isolated'),
    ('whole',3840,base/'stock-whole'),('adjacent',5760,previous/'final-adjacent'),
):
    old,new=(read(p/'report.json') for p in (stock,base/f'final-{mode}'))
    assert old['samples']==new['samples']==count
    a,b=({key(row) for row in d['failures']} for d in (old,new))
    ca,cb=({key(row) for row in d['failures'] if gap(row)} for d in (old,new))
    summary[mode]={'samples':count,'old_flags':len(a),'new_flags':len(b),'old_gap_count':len(ca),'new_gap_count':len(cb),
                   'newly_flagged':sorted(b-a),'new_gaps':sorted(cb-ca),
                   'before_poses':dict(Counter(f[2] for f in ca)), 'after_poses':dict(Counter(f[2] for f in cb))}
print(json.dumps(summary,indent=2))
assert all(not report['newly_flagged'] and not report['new_gaps'] for report in summary.values())
assert summary['whole']['before_poses']['block']==240 and summary['whole']['after_poses'].get('block',0)==0
assert summary['dressed']['old_gap_count']==summary['dressed']['new_gap_count']==2
assert summary['isolated']['old_gap_count']==summary['isolated']['new_gap_count']==0
for name in ('dressed','isolated','whole','adjacent','damage'):
    assert 'ERROR:' not in (base/f'final-{name}.log').read_text(encoding='utf-8-sig'),name
for name in ('normal.log','import.log'):
    assert 'ERROR:' not in (base/name).read_text(encoding='utf-8-sig'),name
assert digest(base/'normal-before.png')==digest(base/'normal-before-rebuilt.png')
assert digest(assets/'torso_n.png')==digest(base/'normal-after.png')
assert digest(assets/'torso.png')==digest(outputs/'overrides/torso.png')==digest(base/'torso-d.png')
assert digest(outputs/'neck_overlap/torso-before.png')==digest(previous/'cut-check/enforcer/parts/torso.png')
old,new,old_normal,normal=(np.asarray(Image.open(p).convert('RGBA')) for p in (base/'torso-before.png',assets/'torso.png',base/'normal-before.png',assets/'torso_n.png'))
changed=np.any(old!=new,axis=2)
assert changed.sum()==285 and np.array_equal(new[:,:,3],normal[:,:,3])
assert np.all(old[changed,3]<235) and np.all(new[changed,3]>old[changed,3])
summary['source']={'diffuse':digest(assets/'torso.png'),'normal':digest(assets/'torso_n.png'),'changed_alpha_texels':int(changed.sum()),
                   'changed_normal_texels':int(np.any(old_normal!=normal,axis=2).sum())}
(base/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')

