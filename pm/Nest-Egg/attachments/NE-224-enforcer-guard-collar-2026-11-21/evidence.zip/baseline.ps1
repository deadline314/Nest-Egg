param([string]$Mode='stock')
$ErrorActionPreference='Stop'
$root='C:/Users/stanl/Github/Nest-Egg'
$ev=$PSScriptRoot.Replace('\','/')
$shared='D:/NestEggVerification/ne218-baseline-20261117'
$py='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
$godot='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$common=@('--path',$shared,'--rendering-method','forward_plus','--rendering-driver','vulkan','--resolution','1280x720','--max-fps','120','--quit-after','12000')
$env:APPDATA="$ev/$Mode-profile/AppData"
$env:LOCALAPPDATA="$ev/$Mode-profile/Local"
function Capture([string]$View,[int]$Frames,[string[]]$Extra) {
    $out="$ev/$Mode-$View"
    & $py -B "$root/tools/comfyui/gpu_lock.py" -- $godot @common "$ev/probe.tscn" -- "--out=$out" --chars=enforcer --joints=neck "--frames=$Frames" @Extra *> "$out.log"
    if ($LASTEXITCODE -ne 0 -or (Select-String -Pattern 'ERROR:' -Quiet -LiteralPath "$out.log")) { throw "Godot capture failed for $out" }
    & $py -B "$root/tools/check_joint_frames.py" $out *> "$out-check.log"
    if ($LASTEXITCODE -gt 1) { throw "Geometry check failed to run for $out" }
    Get-Content -LiteralPath "$out-check.log" -TotalCount 3
}
Capture -View 'isolated' -Frames 120 -Extra @('--pair-only')
Capture -View 'whole' -Frames 120 -Extra @('--diagnostic-whole-rig')
