extends "res://tests/smoke_test.gd"
const Observer=preload("res://work/ne264-cpu-observer/canonical_observer.gd")
func _run() -> void:
	Enemy.activation_culling_enabled=false
	Story.auto_skip=true
	var suite:=Observer.new(self)
	await suite.run()
	var output:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):output=arg.trim_prefix("--out=")
	FileAccess.open(output.path_join("observer.json"),FileAccess.WRITE).store_string(JSON.stringify(suite.rows,"\t")+"\n")
	suite=null
	await _finish()
