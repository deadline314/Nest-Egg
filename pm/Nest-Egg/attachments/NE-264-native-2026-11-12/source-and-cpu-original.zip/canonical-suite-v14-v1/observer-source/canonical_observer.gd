extends AmmoTraySuite
var active: Level
var rows: Array = []
var saw_run := false
func start_level(data: LevelData, difficulty_index := 1) -> Level:
	active=await super.start_level(data,difficulty_index)
	saw_run=false
	if not runner.get_tree().physics_frame.is_connected(_observe_run_start):
		runner.get_tree().physics_frame.connect(_observe_run_start)
	return active
func end_level(level: Level) -> void:
	if runner.get_tree().physics_frame.is_connected(_observe_run_start):
		runner.get_tree().physics_frame.disconnect(_observe_run_start)
	await super.end_level(level)
	active=null
func _observe_run_start() -> void:
	if is_instance_valid(active) and not saw_run and Input.is_action_pressed(&"move_right"):
		saw_run=true
		_capture(false,"first physics publication after run input, before manual UI step")
func check(condition: bool, message: String) -> void:
	if message.begins_with("跑離畫面邊緣後") and is_instance_valid(active):
		_capture(condition,message)
	super.check(condition,message)
func _capture(condition: bool, message: String) -> void:
	if is_instance_valid(active):
		var player:=active.player
		var tray:=active.hud.ammo_tray
		var tag:=active.hud.vitals_tag
		var canvas:=tray.get_viewport().get_canvas_transform()
		var anchor:Vector2=canvas*player.global_position
		var cache:HudPlacement.FollowState=tray._placement
		var head:Sprite2D=cache.get("_head")
		rows.append({"assertion":message,"condition":condition,"world":[player.global_position.x,player.global_position.y],"anchor":[anchor.x,anchor.y],"canvas":[canvas.x.x,canvas.x.y,canvas.y.x,canvas.y.y,canvas.origin.x,canvas.origin.y],"facing":player.facing,"desired_above":HudPlacement.above_target(anchor.x,-float(player.facing),tray.get_viewport_rect().size.x),"above":tray._above,"side":tray._side,"draw_side":tray._draw_side,"tag_above":tag._above,"guide_y":cache.guide_y,"foot_y":cache.foot_y,"guide_ready":cache.guide_ready,"cached_head_valid":is_instance_valid(head),"cached_head_tree":head.is_inside_tree() if is_instance_valid(head) else false,"cached_head_visible":head.is_visible_in_tree() if is_instance_valid(head) else false,"cached_head_texture":head.texture!=null if is_instance_valid(head) else false,"physics":Engine.get_physics_frames(),"process":Engine.get_process_frames()})
