from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
here=Path(__file__).resolve().parent
epoch,role=sys.argv[1:3]
out=here/epoch;out.mkdir()
manifest=json.loads((here/(sys.argv[3] if len(sys.argv)>3 else 'canonical-v9-base.json')).read_text(encoding='utf-8'))
tree=Path(manifest['tree'])
leaf=tree/'work/ne264-cpu-observer';leaf.mkdir(exist_ok=True)
for name in ['canonical_observer.gd','canonical_runner.gd','canonical_runner.tscn']:
    (leaf/name).write_bytes((here/name).read_bytes())
    dest=out/'observer-source'/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes((here/name).read_bytes())
def hashes():return {p:hashlib.sha256((tree/p).read_bytes()).hexdigest() for p in manifest['files']}
before=hashes();assert before==manifest['files']
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
(out/'runner-original.py').write_bytes(Path(__file__).read_bytes())
command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(tree)]
command+=['--editor','--quit'] if role=='import' else ['res://work/ne264-cpu-observer/canonical_runner.tscn','--','--out='+str(out)]
env=os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA']:
    p=out/'profile'/key;p.mkdir(parents=True);env[key]=str(p)
(out/'command.json').write_text(json.dumps({'command':command,'scope':'CPU only; same permanent assertions with read-only final-state observer'},indent=2)+'\n',encoding='utf-8')
started=time.monotonic()
with (out/'engine.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=600)
after=hashes()
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
log=(out/'engine.log').read_text(encoding='utf-8',errors='replace')
errors=[x for x in log.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|ObjectDB.*leaked|resources still in use|RID allocations',x)]
receipt={'exit':result.returncode,'wall_seconds':time.monotonic()-started,'source_unchanged':before==after,'diagnostics':errors,'passed':result.returncode==0 and before==after and not errors}
(out/'exit.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt));sys.exit(0 if receipt['passed'] else 1)
