extends Node
const Capture := preload("res://tools/viewport_capture.gd")
func _ready() -> void:
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): out=arg.trim_prefix("--out=")
	var script := load("res://work/ne264-aim-producer/probe.gd") as GDScript
	var good := script!=null and script.can_instantiate()
	var values := [0.0,0.0003,0.0031308,0.02,0.25,0.8,1.0,2.0]
	var raw := Image.create(values.size(),1,false,Image.FORMAT_RGBAF)
	for x in values.size(): raw.set_pixel(x,0,Color(values[x],values[x],values[x],0.5))
	var encoded := Capture.encode(raw,true)
	var rgbh := Image.create(2,1,false,Image.FORMAT_RGBH)
	rgbh.set_pixel(0,0,Color(0.25,0.0,2.0,1.0))
	rgbh.set_pixel(1,0,Color(0.5,1.0,0.125,1.0))
	FileAccess.open(out.path_join("known-rgbh.raw"),FileAccess.WRITE).store_buffer(rgbh.get_data())
	var record := {"scope":"CPU parser and float transfer known input only; no native UI acceptance", "parsed":good,"format_ids":{"rgba8":Image.FORMAT_RGBA8,"rgbaf":Image.FORMAT_RGBAF,"rgbah":Image.FORMAT_RGBAH},"source_values":values,"source_format":raw.get_format(),"source_bytes_base64":Marshalls.raw_to_base64(raw.get_data()),"encoded_rgba8_base64":Marshalls.raw_to_base64(encoded.get_data()),"encoded_format":encoded.get_format()}
	FileAccess.open(out.path_join("parse.json"),FileAccess.WRITE).store_string(JSON.stringify(record,"\t")+"\n")
	FileAccess.open(out.path_join("known-rgbh.json"),FileAccess.WRITE).store_string(JSON.stringify({"scope":"CPU Image RGBH known answers; no GPU","format":rgbh.get_format(),"size":[2,1],"path":"known-rgbh.raw","bytes":rgbh.get_data().size(),"sha256":FileAccess.get_sha256(out.path_join("known-rgbh.raw")),"expected_rgb":[[0.25,0.0,2.0],[0.5,1.0,0.125]]},"\t")+"\n")
	print("NE264_PARSE ",good)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if good else 1)
