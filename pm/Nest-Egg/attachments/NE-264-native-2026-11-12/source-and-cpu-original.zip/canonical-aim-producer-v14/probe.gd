extends Node
## NE264: natural production HUD update and actual post-draw readback only.
const Capture := preload("res://tools/viewport_capture.gd")
var out := ""
var requested := Vector2i(1280,720)
var cap := 60
var mode := "all"
var run_aim := "right"
var level: Level
var player: Player
var tray: AmmoTray
var tag: VitalsTag
var checks: Array = []
var events: Array = []
var frames: Array = []
var buffered_images: Array[Image] = []
var static_rows: Array = []
var phase_baselines: Array = []
var phase_summaries: Array = []
var before_mixed: Dictionary = {}
var before_mixed_image: Image
var last_delta := 0.0
var head_sprite: Sprite2D
var head_used := Rect2()
var head_textures: Dictionary = {}
var head_texture_rows: Array = []

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): out = arg.trim_prefix("--out=")
		elif arg.begins_with("--width="): requested.x = int(arg.trim_prefix("--width="))
		elif arg.begins_with("--height="): requested.y = int(arg.trim_prefix("--height="))
		elif arg.begins_with("--process-cap="): cap = int(arg.trim_prefix("--process-cap="))
		elif arg.begins_with("--mode="): mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--run-aim="): run_aim = arg.trim_prefix("--run-aim=")
	process_priority = 1000
	call_deferred("_run")

func _process(delta: float) -> void: last_delta = delta
func _rect(r: Rect2) -> Array: return [r.position.x,r.position.y,r.size.x,r.size.y]
func _vec(v: Vector2) -> Array: return [v.x,v.y]
func _xf(t: Transform2D) -> Array: return [t.x.x,t.x.y,t.y.x,t.y.y,t.origin.x,t.origin.y]
func _check(value: bool, label: String) -> void:
	checks.append({"ok":value,"label":label})
	print("CHECK ",value," ",label)
func _input_action(action: StringName, pressed: bool) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = pressed
	event.strength = 1.0 if pressed else 0.0
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	events.append({"action":String(action),"pressed":pressed,"physics":Engine.get_physics_frames(),"process":Engine.get_process_frames(),"usec":Time.get_ticks_usec()})
func _aim(right: bool) -> void:
	_input_action(&"aim_left",not right)
	_input_action(&"aim_right",right)
func _settle(count: int) -> void:
	for i in count: await get_tree().process_frame
	await RenderingServer.frame_post_draw

func _alpha(item: CanvasItem) -> float:
	var alpha := item.self_modulate.a
	var node: Node = item
	while node != null:
		if node is CanvasItem: alpha *= (node as CanvasItem).modulate.a
		node = node.get_parent()
	return alpha

func _head_shape(parameter: StringName) -> Array:
	var value: Variant = head_sprite.get_instance_shader_parameter(parameter)
	return _vec(value) if value is Vector2 else [0.0,0.0]

func _snapshot() -> Dictionary:
	var texture_key := str(head_sprite.texture.get_instance_id())
	head_textures[texture_key] = head_sprite.texture
	var viewport := get_viewport()
	var final := viewport.get_final_transform()
	var world_to_ui := viewport.get_canvas_transform()
	var tray_to_ui := tray.get_global_transform_with_canvas()
	var tag_to_ui := tag.get_global_transform_with_canvas()
	var icons: Array = []
	var count := tray.icon_count()
	var icon_bounds := Rect2()
	for i in count:
		var local: Rect2 = tray._icon_draw_rect(i,count,1.0)
		var ui: Rect2 = tray_to_ui * local
		icons.append({"local":_rect(local),"logical":_rect(ui),"screen":_rect(final*ui)})
		icon_bounds = ui if i==0 else icon_bounds.merge(ui)
	var reserve: Rect2 = tray._baseline_rect(tray._reserve_anchor(),float(tray.get("_obstacle_reserve_width")),tray._reserve_right_aligned())
	reserve = tray_to_ui * reserve
	var extent := Vector2(tag._content_width()+VitalsTag.PAD*2.0,VitalsTag.PAD+VitalsTag.PIP_H+3.0+VitalsTag.GUARD_H+VitalsTag.PAD)
	var pop := 1.0+0.18*ease(tag.presence.pop,0.5)
	var plate := Rect2(tag._pos+extent*(1.0-pop)*0.5,extent*pop)
	plate = tag_to_ui * plate
	var guard := Rect2(tag._pos+Vector2(VitalsTag.PAD,VitalsTag.PAD+VitalsTag.PIP_H+3.0),Vector2(tag._content_width()-VitalsTag.PIP_SKEW,VitalsTag.GUARD_H))
	guard = tag_to_ui * guard
	var head_world := head_sprite.global_transform * head_used if is_instance_valid(head_sprite) else Rect2()
	var head := world_to_ui * head_world
	var body := world_to_ui * player._visual.rig.visual_bounds()
	var feet := Rect2(body.position.x,body.end.y-8.0,body.size.x,8.0)
	var bar := level.hud.weapon_bar.get_global_rect()
	var source := icon_bounds.merge(reserve).merge(plate).merge(body).grow(4.0)
	var crop: Rect2 = final*source
	var roi := Rect2i(Vector2i(floori(crop.position.x),floori(crop.position.y)),Vector2i(ceili(crop.end.x)-floori(crop.position.x),ceili(crop.end.y)-floori(crop.position.y)))
	var aim_start: Vector2 = world_to_ui*player.muzzle_position()
	var aim_end: Vector2 = world_to_ui*player.aim_point
	return {"process":Engine.get_process_frames(),"physics":Engine.get_physics_frames(),"usec":Time.get_ticks_usec(),"process_delta":last_delta,"actual_max_fps":Engine.max_fps,"time_scale":Engine.time_scale,"paused":get_tree().paused,"player_alive":not player.is_dead(),"player_physics_processing":player.is_physics_processing(),"player_can_process":player.can_process(),"player_visible":player.is_visible_in_tree(),"health":player.health.current,"max_health":player.health.max_health,"player_state":player.state,"player_position":_vec(player.global_position),"velocity":_vec(player.velocity),"on_floor":player.is_on_floor(),"facing":player.facing,"aim":_vec(player.aim_dir),"aim_start_logical":_vec(aim_start),"aim_end_logical":_vec(aim_end),"tray_showing":tray.is_showing(),"tray_visible":tray.is_visible_in_tree(),"tray_alpha":tray.presence.alpha*_alpha(tray),"tray_processing":tray.is_processing(),"tray_can_process":tray.can_process(),"tray_has_pos":tray._has_pos,"tray_has_mag":bool(tray.get("_has_mag")),"tray_above":tray._above,"tray_guide_y":tray._placement.guide_y,"tray_foot_y":tray._placement.foot_y,"tray_guide_ready":tray._placement.guide_ready,"tag_guide_y":tag._placement.guide_y,"tag_foot_y":tag._placement.foot_y,"tag_guide_ready":tag._placement.guide_ready,"tray_guide_x":tray._placement.guide_x,"tag_guide_x":tag._placement.guide_x,"tray_lower_y":tray._placement.lower_y,"tag_lower_y":tag._placement.lower_y,"tray_lower_mode":tray._placement.lower_mode,"tag_lower_mode":tag._placement.lower_mode,"tag_side":tag._side,"tray_side":tray.side(),"tray_draw_side":tray._draw_side,"far_slot_local":_vec(tray._slot_position(count-1)) if count>0 else [],"icons":icons,"reserve_text":"∞" if tray.reserve<0 else str(tray.reserve),"reserve_logical":_rect(reserve),"reserve_screen":_rect(final*reserve),"tag_visible":tag.is_visible_in_tree(),"tag_alpha":tag.presence.alpha*_alpha(tag),"tag_processing":tag.is_processing(),"tag_can_process":tag.can_process(),"tag_has_pos":tag._has_pos,"tag_above":tag._above,"tag_pop":tag.presence.pop,"tag_shake":float(tag.get("_shake_left")),"tag_health":tag.health,"tag_max_health":tag.max_health,"plate_logical":_rect(plate),"plate_screen":_rect(final*plate),"guard_logical":_rect(guard),"guard_screen":_rect(final*guard),"guard_ratio":tag.guard_ratio,"head_logical":_rect(head),"head_screen":_rect(final*head),"head_effective_alpha":_alpha(head_sprite) if head_sprite!=null else 0.0,"head_visible":head_sprite.is_visible_in_tree() if head_sprite!=null else false,"player_visual_visible":player._visual.is_visible_in_tree(),"materialize_left":float(player._visual.get("_materialize_left")),"head_used_texture_rect":_rect(head_used),"head_texture_key":texture_key,"head_sprite_rect":_rect(head_sprite.get_rect()),"head_to_world":_xf(head_sprite.global_transform),"head_to_logical":_xf(world_to_ui*head_sprite.global_transform),"head_flip_h":head_sprite.flip_h,"head_flip_v":head_sprite.flip_v,"head_hframes":head_sprite.hframes,"head_vframes":head_sprite.vframes,"head_region_enabled":head_sprite.region_enabled,"head_full_rect_logical":_rect(world_to_ui*head_sprite.global_transform*head_sprite.get_rect()),"head_sway_a_shape":_head_shape(&"sway_a_shape"),"head_sway_b_shape":_head_shape(&"sway_b_shape"),"body_logical":_rect(body),"feet_logical":_rect(feet),"weapon_bar_logical":_rect(bar),"weapon_bar_alpha":level.hud.weapon_bar.modulate.a,"weapon_bar_making_way":level.hud.weapon_bar.is_making_way(),"viewport_logical":_rect(viewport.get_visible_rect()),"window_size":[get_window().size.x,get_window().size.y],"native_window_size":_vec(DisplayServer.window_get_size(get_window().get_window_id())),"final_transform":_xf(final),"canvas_transform":_xf(world_to_ui),"tray_to_logical":_xf(tray_to_ui),"tag_to_logical":_xf(tag_to_ui),"roi_requested_screen":[roi.position.x,roi.position.y,roi.size.x,roi.size.y]}

func _validate(row: Dictionary) -> bool:
	return row.player_alive and row.player_physics_processing and row.player_can_process and row.player_visible and row.health>0 and not row.paused and row.time_scale==1.0 and row.tray_showing and row.tray_visible and row.tray_alpha>=0.95 and row.tray_processing and row.tray_can_process and row.tray_has_pos and row.tray_has_mag and not row.icons.is_empty() and not row.reserve_text.is_empty() and row.tag_visible and row.tag_alpha>=0.95 and row.tag_processing and row.tag_can_process and row.tag_has_pos and row.tag_health>0 and row.tag_max_health>0 and row.head_effective_alpha>=0.95 and row.head_visible and row.player_visual_visible and row.materialize_left<=0.0

func _place(x: float, right: bool) -> void:
	_input_action(&"move_right",false)
	_input_action(&"move_left",false)
	_input_action(&"jump",false)
	player.global_position = Vector2(x,318.0) # Initial arrangement only; physics must actually land.
	player.velocity = Vector2.ZERO
	_aim(right)
	for i in 4: await get_tree().physics_frame
	level.camera.snap_to_target()
	await _settle(65)
	_check(player.is_on_floor() and not player.is_dead(),"fixture naturally grounded alive")

func _static_shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	var row := _snapshot()
	var raw := get_viewport().get_texture().get_image()
	var path := out.path_join(name+".png")
	var err := Capture.encode(raw,get_viewport().use_hdr_2d).save_png(path)
	row["name"]=name
	row["path"]=name+".png"
	row["sha256"]=FileAccess.get_sha256(path)
	row["actual_readback_size"]=[raw.get_width(),raw.get_height()]
	static_rows.append(row)
	_check(err==OK and _validate(row),"static drawable/alive guard "+name)

func _collect(phase: String, limit: int, stop_beside := false, jump_phase := false, settle_turn := false, mixed_phase := false) -> void:
	var previous: Vector2 = tray._slot_position(tray.icon_count()-1)
	var baseline := before_mixed if mixed_phase else _snapshot()
	baseline["phase"]=phase
	phase_baselines.append(baseline)
	var largest := 0.0
	var first50_largest := 0.0
	var first40_largest := 0.0
	var stable_draws := 0
	var settled_turn := false
	var sampled := 0
	var begun_above := tray._above
	var saw_air := false
	var landed := false
	for i in limit:
		if mixed_phase and i==2: _input_action(&"jump",true)
		if mixed_phase and i==6: _aim(true)
		await RenderingServer.frame_post_draw
		var row := _snapshot()
		row["phase"]=phase
		row["sample"]=i
		var now: Vector2 = tray._slot_position(tray.icon_count()-1)
		row["far_displacement_logical"]=now.distance_to(previous)
		largest = maxf(largest,float(row.far_displacement_logical))
		if i<40:first40_largest=maxf(first40_largest,float(row.far_displacement_logical))
		if (not mixed_phase and i<50) or (mixed_phase and i>=2 and i<52):first50_largest=maxf(first50_largest,float(row.far_displacement_logical))
		sampled=i+1
		previous=now
		saw_air = saw_air or not player.is_on_floor()
		landed = landed or (saw_air and player.is_on_floor())
		var readback_start := Time.get_ticks_usec()
		var raw := get_viewport().get_texture().get_image()
		var requested_roi: Array = row.roi_requested_screen
		var roi := Rect2i(int(requested_roi[0]),int(requested_roi[1]),int(requested_roi[2]),int(requested_roi[3])).intersection(Rect2i(Vector2i.ZERO,raw.get_size()))
		buffered_images.append(raw.get_region(roi))
		row["readback_usec"]=Time.get_ticks_usec()-readback_start
		row["roi_screen"]=[roi.position.x,roi.position.y,roi.size.x,roi.size.y]
		row["actual_readback_size"]=[raw.get_width(),raw.get_height()]
		row["roi_format"]=raw.get_format()
		row["roi_buffer_index"]=buffered_images.size()-1
		row["drawable_alive_guard"]=_validate(row)
		frames.append(row)
		if mixed_phase and i>=51:
			var view := get_viewport()
			var anchor: Vector2 = view.get_canvas_transform()*player.global_position
			var desired := HudPlacement.above_target(anchor.x,-float(player.facing),view.get_visible_rect().size.x)
			var at_goal := absf(tray._above-desired)<0.01 and absf(tag._above-desired)<0.01 and absf(tray._draw_side-tray.side())<0.01 and absf(tag._side+float(player.facing))<0.01
			stable_draws = stable_draws+1 if landed and at_goal and float(row.far_displacement_logical)<0.25 else 0
			if stable_draws>=3:
				settled_turn=true
				break
		if settle_turn and i>=39:
			var target_side := -float(player.facing)
			var at_goal := tray._above<0.01 and tag._above<0.01 and absf(tray._draw_side-tray.side())<0.01 and absf(tag._side-target_side)<0.01
			stable_draws = stable_draws+1 if at_goal and float(row.far_displacement_logical)<0.25 else 0
			if stable_draws>=3:
				settled_turn=true
				break
		if stop_beside and tray._above<0.01: break
		if jump_phase and not mixed_phase and landed and i>=49:break
	_check(largest<24.0,phase+" original logical far-slot threshold <24 (actual %.6f)"%largest)
	if mixed_phase:
		_check(saw_air and landed and settled_turn,"mixed public jump lands and final side/above/position reaches three stable draws within fixed 120draw limit")
	if settle_turn:
		_check(first40_largest<24.0,"turn original first40 logical threshold <24 (actual %.6f)"%first40_largest)
		_check(settled_turn,"turn additionally reaches actual side/above and three stable published draws within fixed additional 90 draw bound")
	if jump_phase:
		_check(first50_largest<24.0,"jump original first 50 draw threshold <24 (actual %.6f)"%first50_largest)
		_check(saw_air and landed,"public held jump has actual air and landing; complete trace bounded at 90 draws")
	phase_summaries.append({"phase":phase,"sampled":sampled,"limit":limit,"largest_logical":largest,"first50_largest_logical":first50_largest,"first40_largest_logical":first40_largest,"settled_turn":settled_turn,"stable_draws":stable_draws})
	if stop_beside: _check(begun_above>0.99 and tray._above<0.01,"public run crosses above-to-beside threshold")
	_check(frames.filter(func(r: Dictionary)->bool:return r.phase==phase).all(func(r: Dictionary)->bool:return r.drawable_alive_guard),phase+" every post-draw frame has live visible HUD and player")

func _collect_aim() -> void:
	var previous: Vector2 = tray._slot_position(tray.icon_count()-1)
	var previous_plate := Vector2(before_mixed.plate_logical[0],before_mixed.plate_logical[1])
	before_mixed["phase"]="aim-transition"
	phase_baselines.append(before_mixed)
	var largest := 0.0
	var stable_draws := 0
	var complete := false
	for i in 240:
		if i==60: _input_action(&"move_right",true)
		if i==180:
			_input_action(&"move_right",false)
			_input_action(&"aim_up",false)
			_aim(true)
		await RenderingServer.frame_post_draw
		var row := _snapshot()
		row["phase"]="aim-transition"
		row["sample"]=i
		var now: Vector2 = tray._slot_position(tray.icon_count()-1)
		row["far_displacement_logical"]=now.distance_to(previous)
		var plate := Vector2(row.plate_logical[0],row.plate_logical[1])
		row["plate_displacement_logical"]=plate.distance_to(previous_plate)
		previous=now
		previous_plate=plate
		largest=maxf(largest,float(row.far_displacement_logical))
		var raw := get_viewport().get_texture().get_image()
		var requested_roi: Array = row.roi_requested_screen
		var roi := Rect2i(int(requested_roi[0]),int(requested_roi[1]),int(requested_roi[2]),int(requested_roi[3])).intersection(Rect2i(Vector2i.ZERO,raw.get_size()))
		buffered_images.append(raw.get_region(roi))
		row["roi_screen"]=[roi.position.x,roi.position.y,roi.size.x,roi.size.y]
		row["actual_readback_size"]=[raw.get_width(),raw.get_height()]
		row["roi_format"]=raw.get_format()
		row["roi_buffer_index"]=buffered_images.size()-1
		row["drawable_alive_guard"]=_validate(row)
		frames.append(row)
		if i>=209:
			var view := get_viewport()
			var anchor: Vector2 = view.get_canvas_transform()*player.global_position
			var desired := HudPlacement.above_target(anchor.x,-float(player.facing),view.get_visible_rect().size.x)
			var at_goal := absf(tray._above-desired)<0.01 and absf(tag._above-desired)<0.01 and absf(tray._draw_side-tray.side())<0.01 and absf(tag._side+float(player.facing))<0.01
			stable_draws=stable_draws+1 if at_goal and player.is_on_floor() and float(row.far_displacement_logical)<0.25 and float(row.plate_displacement_logical)<0.25 else 0
			if stable_draws>=3:
				complete=true
				break
	_check(largest<24.0,"aim-transition original logical far-slot threshold <24 (actual %.6f)"%largest)
	_check(complete,"aim-transition original right to UP first draw, natural run, then right and three stable published draws within fixed 240draw limit")
	_check(frames.all(func(r: Dictionary)->bool:return r.drawable_alive_guard),"aim-transition all draws live visible")
	phase_summaries.append({"phase":"aim-transition","sampled":frames.size(),"limit":240,"largest_logical":largest,"stable_draws":stable_draws,"complete":complete})

func _run() -> void:
	if DisplayServer.get_name()=="headless" or RenderingServer.get_current_rendering_method()!="forward_plus":
		get_tree().quit(2)
		return
	var profile := OS.get_environment("NE264_PROFILE_ROOT").replace("\\","/").to_lower()
	if profile.is_empty() or not OS.get_user_data_dir().replace("\\","/").to_lower().begins_with(profile+"/"):
		get_tree().quit(2)
		return
	_check(out.is_absolute_path(),"absolute output")
	Engine.max_fps=cap
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	get_window().size=requested
	DisplayMode.ensure_scaling(get_window())
	Settings.use_storage("user://ne264-native.cfg")
	Settings.set_hud_auto_hide(false) # Actual public preference; no HP/damage spoof.
	GameState.story_autosave=false
	GameState.start_new_run(GameState.difficulties[1])
	add_child(LightKit.create_environment())
	var data := (load("res://data/levels/ch1_street.tres") as LevelData).duplicate(true) as LevelData
	data.layout_path="res://work/ne264-aim-producer/street-quiet-map.json"
	data.intro_scene=&""
	data.show_chapter_card=false
	data.story_triggers=PackedStringArray()
	data.persistent_world=false
	level=Level.new()
	level.configure(data)
	add_child(level)
	await _settle(65)
	player=level.player
	tray=level.hud.ammo_tray
	tag=level.hud.vitals_tag
	AimInput.set_virtual_gamepad(player,true)
	var candidates := player._visual.rig.find_children("head","Sprite2D",true,false)
	for candidate in candidates:
		if candidate.is_visible_in_tree() and (candidate as Sprite2D).texture!=null:
			if head_sprite!=null: _check(false,"head drawable ambiguous")
			head_sprite=candidate as Sprite2D
	_check(head_sprite!=null,"actual textured head Sprite2D resolved (not Bone2D)")
	if head_sprite!=null:
		var used := head_sprite.texture.get_image().get_used_rect()
		head_used=Rect2(head_sprite.get_rect().position+Vector2(used.position),Vector2(used.size))
	_check(get_tree().get_nodes_in_group(&"enemies").is_empty(),"explicit quiet fixture contains no active hostiles")
	var width := level._layout.width*data.tile_size
	if mode in ["static","all","smoke"]:
		for shot in [["left-facing-right",24.0,true],["left-facing-left",24.0,false],["right-facing-left",float(width)-24.0,false],["right-facing-right",float(width)-24.0,true]]:
			await _place(float(shot[1]),bool(shot[2]))
			await _static_shot(str(shot[0]))
			if mode=="smoke":break
	if mode in ["dynamic","all"]:
		await _place(20.0,true)
		_aim(false)
		await _collect("turn",90,false,false,true)
		await _settle(15)
		_input_action(&"jump",true)
		await _collect("jump",90,false,true)
		_input_action(&"jump",false)
		await _place(20.0,true)
		if run_aim=="up":
			_input_action(&"aim_right",false)
			_input_action(&"aim_up",true)
			await _settle(60)
			_check(tray._above>0.99 and tag._above>0.99 and player.facing==1,"public up-aim fixture remains above at left edge before real run")
		_input_action(&"move_right",true)
		await _collect("run-aim-up" if run_aim=="up" else "run",240,true)
		_input_action(&"move_right",false)
	if mode=="aim":
		await _place(20.0,true)
		before_mixed=_snapshot()
		var source := get_viewport().get_texture().get_image()
		var requested_roi: Array = before_mixed.roi_requested_screen
		var roi := Rect2i(int(requested_roi[0]),int(requested_roi[1]),int(requested_roi[2]),int(requested_roi[3])).intersection(Rect2i(Vector2i.ZERO,source.get_size()))
		before_mixed_image=source.get_region(roi)
		before_mixed["roi_screen"]=[roi.position.x,roi.position.y,roi.size.x,roi.size.y]
		before_mixed["roi_format"]=source.get_format()
		before_mixed["actual_readback_size"]=[source.get_width(),source.get_height()]
		_input_action(&"aim_right",false)
		_input_action(&"aim_up",true)
		await _collect_aim()
		_input_action(&"jump",false)
		var filename := "before-mixed-input.raw"
		FileAccess.open(out.path_join(filename),FileAccess.WRITE).store_buffer(before_mixed_image.get_data())
		before_mixed["raw_path"]=filename
		before_mixed["raw_bytes"]=before_mixed_image.get_data_size()
		before_mixed["raw_sha256"]=FileAccess.get_sha256(out.path_join(filename))
	for action in [&"aim_left",&"aim_right",&"aim_up",&"jump",&"move_left",&"move_right"]:_input_action(action,false)
	# Preserve each actual head Texture2D used in recorded draws. Decode and
	# write after the interaction, so alpha extraction adds no measured-frame IO.
	for key in head_textures:
		var texture: Texture2D = head_textures[key]
		var image := texture.get_image()
		var native_format := image.get_format()
		var compressed := image.is_compressed()
		if compressed:
			_check(image.decompress()==OK,"actual head image decompresses")
		image.convert(Image.FORMAT_RGBA8)
		var mip_offsets: Array = []
		for level in image.get_mipmap_count()+1: mip_offsets.append(image.get_mipmap_offset(level))
		var filename := "head-texture-"+str(key)+".rgba8"
		FileAccess.open(out.path_join(filename),FileAccess.WRITE).store_buffer(image.get_data())
		head_texture_rows.append({"key":str(key),"resource_path":texture.resource_path,"path":filename,"sha256":FileAccess.get_sha256(out.path_join(filename)),"size":[image.get_width(),image.get_height()],"native_format":native_format,"native_compressed":compressed,"decoded_format":image.get_format(),"has_mipmaps":image.has_mipmaps(),"mipmap_count":image.get_mipmap_count(),"mip_offsets":mip_offsets,"scope":"actual Texture2D get_image RGBA8 decode; alpha is not a full rendered replacement"})
	# Store original floating ROI bytes only after interactive measurements end.
	# PNG conversion is an offline reader job, never in a measured natural frame.
	for i in buffered_images.size():
		var image := buffered_images[i]
		var path := "frame-%04d.raw"%i
		var bytes := image.get_data()
		FileAccess.open(out.path_join(path),FileAccess.WRITE).store_buffer(bytes)
		frames[i]["raw_path"]=path
		frames[i]["raw_bytes"]=bytes.size()
		frames[i]["raw_sha256"]=FileAccess.get_sha256(out.path_join(path))
	var result := {"scope":"quiet production street HUD fixture; synthetic public right to UP from first draw, move at60, return right at180 through natural stable tail; actual natural process and post-draw floats; not natural chapter play, physical controller or performance", "requested_size":[requested.x,requested.y],"process_cap":cap,"actual_engine_max_fps":Engine.max_fps,"run_aim":run_aim,"physics_ticks_per_second":Engine.physics_ticks_per_second,"renderer":RenderingServer.get_current_rendering_method(),"device":RenderingServer.get_video_adapter_name(),"hdr_2d":get_viewport().use_hdr_2d,"head_texture_rows":head_texture_rows,"format_ids":{"rgba8":Image.FORMAT_RGBA8,"rgbaf":Image.FORMAT_RGBAF,"rgbah":Image.FORMAT_RGBAH},"user_data_dir":OS.get_user_data_dir(),"checks":checks,"events":events,"static":static_rows,"frames":frames,"phase_baselines":phase_baselines,"phase_summaries":phase_summaries}
	FileAccess.open(out.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify(result,"\t")+"\n")
	remove_child(level)
	level.free()
	buffered_images.clear()
	await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if checks.all(func(r: Dictionary)->bool:return r.ok) else 1)
