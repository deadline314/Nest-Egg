"""D-only leaf; native requires explicit flag and an authorized GPU window."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,subprocess,sys,time,urllib.request
sys.stdout.reconfigure(encoding="utf-8")
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
D=Path("D:/NestEggVerification/ne264-canonical-v9-20261112")
p=argparse.ArgumentParser();p.add_argument("epoch");p.add_argument("--native",action="store_true");p.add_argument("--width",type=int,default=1280);p.add_argument("--height",type=int,default=720);p.add_argument("--process-cap",type=int,default=60);p.add_argument("--mode",choices=["aim"],default="aim")
p.add_argument("--run-aim",choices=["right","up"],default="right")
a=p.parse_args();assert re.fullmatch(r"[A-Za-z0-9_-]+",a.epoch)
TARGET=D/"work/ne264-aimfull-producer";TARGET.mkdir(parents=True,exist_ok=True)
OUT=TARGET/a.epoch;OUT.mkdir();(OUT/".gdignore").touch()
for name in ["probe.gd","probe.tscn","parse.gd","parse.tscn"]:(TARGET/name).write_bytes((HERE/'canonical-aimfull-producer-v14'/name).read_bytes())
(TARGET/"street-quiet-map.json").write_bytes((HERE/"prepared-v3/street-quiet-map.json").read_bytes())
expected=json.loads((HERE/"canonical-v14-fixture.json").read_text(encoding="utf-8"))
for r in expected["sources"]:assert hashlib.sha256((D/r["path"]).read_bytes()).hexdigest()==r["d_sha256"],r["path"]
context=Path("C:/Users/stanl/Github/Nest-Egg/work/st3-facts-adoption-v1/c-native-context-v23.json")
c_expected=json.loads(context.read_text(encoding="utf-8"))["files"]
def hashes(root,paths):return {path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in sorted(paths)}
c_before=hashes(REPO,c_expected);assert c_before==c_expected
paths={p.relative_to(D).as_posix() for folder in ["ui","core","game","autoload","data"] for p in (D/folder).rglob("*") if p.is_file() and p.suffix in {".gd",".gdshader",".json",".tres"}}
paths.update({"project.godot","tests/suite/test_ui_screens.gd"})
paths.update("work/ne264-aimfull-producer/"+name for name in ["probe.gd","probe.tscn","parse.gd","parse.tscn","street-quiet-map.json"])
paths.update({"tests/suite/test_ammo_tray.gd","art/shaders/character_light.gdshader","art/characters/rin/character.json","art/rigs/humanoid_tall.json","art/characters/rin/parts/head.png","art/characters/rin/parts/head_half.png","art/characters/rin/parts/head_closed.png"})
full_expected=json.loads((HERE/"canonical-v14-context.json").read_text(encoding="utf-8"))["files"]
full_before=hashes(D,full_expected);assert full_before==full_expected
(OUT/"runtime-context-before.json").write_bytes((json.dumps(full_before,indent=2)+"\n").encode())
before=hashes(D,paths)
for path in paths:
    dest=OUT/"source"/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((D/path).read_bytes())
(OUT/"runner.py").write_bytes(Path(__file__).read_bytes())
(OUT/"guard-original.py").write_bytes((HERE/"route_locked_launch.py").read_bytes())
(OUT/"try-lock-original.py").write_bytes((HERE/"route_try_lock.py").read_bytes())
(OUT/"fixture-manifest.json").write_bytes((json.dumps(expected,indent=2)+"\n").encode())
(OUT/"candidate-manifest.json").write_bytes((HERE/'candidate-v14/manifest.json').read_bytes())
(OUT/"c-context-expected.json").write_bytes(context.read_bytes())
(OUT/"c-before.json").write_bytes((json.dumps(c_before,indent=2)+"\n").encode())
def queue(phase):
    result={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"ports":{}}
    for port in [8188,8189]:
        try:
            body=urllib.request.urlopen(f"http://127.0.0.1:{port}/queue",timeout=3).read();doc=json.loads(body)
            result["ports"][str(port)]={"status":"reachable","running":len(doc["queue_running"]),"pending":len(doc["queue_pending"]),"body_bytes":len(body),"body_sha256":hashlib.sha256(body).hexdigest()}
            original=OUT/f"queue-{phase}-{port}-private-original.json"
            assert not original.exists()
            original.write_bytes(body)
        except Exception as e:result["ports"][str(port)]={"status":"connection_refused" if "10061" in str(e) else "unknown","error":str(e)}
    return result
engine=["C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(D)]
if a.native:
    q=queue("before");(OUT/"queue-before.json").write_bytes((json.dumps(q,indent=2)+"\n").encode())
    assert all(r["status"]=="connection_refused" or r["status"]=="reachable" and r["running"]==r["pending"]==0 for r in q["ports"].values()),"busy or unknown external queue; native not started"
    engine += ["--rendering-method","forward_plus","--rendering-driver","vulkan","res://work/ne264-aimfull-producer/probe.tscn","--","--out="+str(OUT),f"--width={a.width}",f"--height={a.height}",f"--process-cap={a.process_cap}","--mode="+a.mode,"--run-aim="+a.run_aim]
    command=[sys.executable,str(HERE/"route_try_lock.py"),"--",sys.executable,str(HERE/"route_locked_launch.py"),str(OUT),"--",*engine]
else:
    command=[*engine,"--headless","res://work/ne264-aimfull-producer/parse.tscn","--","--out="+str(OUT)]
(OUT/"command.json").write_bytes((json.dumps({"command":command,"scope":"native HUD functional only, no performance claim" if a.native else "headless parser/known input only"},indent=2)+"\n").encode())
env=dict(os.environ,APPDATA=str(OUT/"profile"),LOCALAPPDATA=str(OUT/"profile/local"),PYTHONIOENCODING="utf-8",NE264_PROFILE_ROOT=str(OUT/"profile"))
start=time.monotonic()
with (OUT/"run.log").open("wb") as log:code=subprocess.run(command,cwd=D,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
full_after=hashes(D,full_expected)
(OUT/"runtime-context-after.json").write_bytes((json.dumps(full_after,indent=2)+"\n").encode())
after=hashes(D,paths);c_after=hashes(REPO,c_expected)
(OUT/"c-after.json").write_bytes((json.dumps(c_after,indent=2)+"\n").encode())
post=queue("after") if a.native else None
if post:(OUT/"queue-after.json").write_bytes((json.dumps(post,indent=2)+"\n").encode())
log=(OUT/"run.log").read_text(encoding="utf-8",errors="replace")
diagnostics=[line for line in log.splitlines() if re.search(r"SCRIPT ERROR|^ERROR:|ObjectDB.*leaked|resources still in use|RID allocations",line)]
receipt={"native":a.native,"exit":code,"wall_seconds":time.monotonic()-start,"sources_unchanged":before==after,"before":before,"after":after,"c_sources_unchanged":c_before==c_after==c_expected,"diagnostics":diagnostics,"engine_clean":code==0 and not diagnostics}
receipt["full_runtime_context_unchanged"]=full_before==full_after==full_expected
receipt["queue_qualified"]=not a.native or all(r["status"]=="connection_refused" and "10061" in r.get("error","") or r["status"]=="reachable" and r["running"]==r["pending"]==0 for r in post["ports"].values())
(OUT/"exit.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
print(json.dumps({k:v for k,v in receipt.items() if k not in {"before","after"}},indent=2));print(log[-2500:])
sys.exit(0 if receipt["engine_clean"] and receipt["sources_unchanged"] and receipt["full_runtime_context_unchanged"] and receipt["c_sources_unchanged"] and receipt["queue_qualified"] else 1)
