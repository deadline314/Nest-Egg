extends Node
var out := ""
var level: Level
var rows: Array = []
var events: Array = []
var last_delta := 0.0
func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
	process_priority=1000
	call_deferred("_run")
func _process(delta: float) -> void:last_delta=delta
func _input_action(action: StringName, pressed: bool) -> void:
	var event := InputEventAction.new()
	event.action=action;event.pressed=pressed;event.strength=1.0 if pressed else 0.0
	Input.parse_input_event(event);Input.flush_buffered_events()
	events.append({"action":String(action),"pressed":pressed,"process":Engine.get_process_frames(),"physics":Engine.get_physics_frames(),"usec":Time.get_ticks_usec()})
func _v(v: Vector2) -> Array:return [v.x,v.y]
func _r(r: Rect2) -> Array:return [r.position.x,r.position.y,r.size.x,r.size.y]
func _sample(phase: String, index: int) -> void:
	var p := level.player;var tray := level.hud.ammo_tray;var tag := level.hud.vitals_tag
	var canvas := get_viewport().get_canvas_transform()
	var sprite := p._visual.rig.contact_part(&"head")
	var head := (canvas*sprite.global_transform*sprite.get_rect()).grow(1)
	var icons: Array = []
	for i in tray.icon_count():icons.append(_r(tray._icon_draw_rect(i,tray.icon_count(),1)))
	var pop := 1.0+0.18*ease(tag.presence.pop,0.5)
	var size := Vector2(tag._content_width()+VitalsTag.PAD*2,19)
	rows.append({"phase":phase,"sample":index,"process":Engine.get_process_frames(),"physics":Engine.get_physics_frames(),"usec":Time.get_ticks_usec(),"delta":last_delta,"muzzle":_v(canvas*p.muzzle_position()),"aim":_v(canvas.basis_xform(p.aim_dir)),"head":_r(head),"icons":icons,"reserve":_r(tray._baseline_rect(tray._reserve_anchor(),tray._obstacle_reserve_width,tray._reserve_right_aligned())),"plate":_r(Rect2(tag._pos+size*(1-pop)*0.5,size*pop)),"far":_v(tray._slot_position(tray.icon_count()-1)),"foot":_v(canvas*p.global_position),"canvas":[canvas.x.x,canvas.x.y,canvas.y.x,canvas.y.y,canvas.origin.x,canvas.origin.y],"ammo_side":tray.side(),"draw_side":tray._draw_side,"tag_side":tag._side,"guide_x":tray._placement.guide_x,"lower_y":tray._placement.lower_y,"lower_mode":tray._placement.lower_mode,"tag_lower_mode":tag._placement.lower_mode,"guide_y":tray._placement.guide_y,"ammo_above":tray._above,"tag_above":tag._above,"facing":p.facing,"alive":not p.is_dead(),"processing":p.is_physics_processing() and tray.is_processing() and tag.is_processing(),"alpha":minf(tray.presence.alpha,tag.presence.alpha)})
func _frames(count: int, phase := "") -> void:
	for i in count:
		await get_tree().process_frame
		await get_tree().create_timer(0).timeout # genuine post-process publication
		if not phase.is_empty():_sample(phase,i)
func _run() -> void:
	Engine.max_fps=30
	Settings.use_storage("user://ne264-aim-cpu.cfg")
	Settings.set_hud_auto_hide(false)
	GameState.story_autosave=false
	GameState.start_new_run(GameState.difficulties[1])
	var data := (load("res://data/levels/ch1_street.tres") as LevelData).duplicate(true)
	data.layout_path="res://work/ne264-route-producer/street-quiet-map.json"
	data.intro_scene=&"";data.show_chapter_card=false;data.story_triggers=PackedStringArray();data.persistent_world=false
	level=Level.new();level.configure(data);add_child(level)
	await _frames(20)
	var p := level.player
	AimInput.set_virtual_gamepad(p,true)
	p.global_position=Vector2(20,318);p.velocity=Vector2.ZERO # initial fixture only
	_input_action(&"aim_right",true)
	for i in 5:await get_tree().physics_frame
	level.camera.snap_to_target()
	await _frames(65)
	_sample("before-up",0)
	_input_action(&"aim_right",false);_input_action(&"aim_up",true)
	await _frames(60,"up")
	_input_action(&"move_right",true)
	await _frames(120,"up-run")
	_input_action(&"move_right",false)
	_input_action(&"aim_up",false);_input_action(&"aim_right",true)
	await _frames(60,"right")
	for action in [&"aim_right",&"aim_up",&"move_right"]:_input_action(action,false)
	FileAccess.open(out.path_join("aim-trace.json"),FileAccess.WRITE).store_string(JSON.stringify({"scope":"CPU natural process/physics and real public inputs, after-process publication; no rendering or pixels; never manually invokes UI/physics","rows":rows,"events":events},"\t")+"\n")
	remove_child(level);level.free()
	await AudioRelease.settle(get_tree())
	get_tree().quit()
