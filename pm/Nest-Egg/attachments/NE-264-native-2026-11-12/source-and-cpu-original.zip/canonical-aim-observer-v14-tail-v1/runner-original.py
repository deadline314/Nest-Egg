from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
here=Path(__file__).resolve().parent
context=json.loads((here/'canonical-v14-context.json').read_text(encoding='utf-8'));tree=Path(context['tree'])
out=here/sys.argv[1];out.mkdir()
leaf=tree/'work/ne264-aim-cpu-v14-tail';leaf.mkdir()
for name in ['aim_cpu_probe_v14_tail.gd','aim_cpu_probe_v14_tail.tscn']:
    (leaf/name).write_bytes((here/name).read_bytes());(out/name).write_bytes((here/name).read_bytes())
def hashes():return {p:hashlib.sha256((tree/p).read_bytes()).hexdigest() for p in context['files']}
before=hashes();assert before==context['files']
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(tree),'res://work/ne264-aim-cpu-v14-tail/aim_cpu_probe_v14_tail.tscn','--','--out='+str(out)]
env=dict(os.environ,APPDATA=str(out/'profile'),LOCALAPPDATA=str(out/'profile/local'))
(out/'command.json').write_text(json.dumps({'command':command,'scope':'read-only natural CPU input/geometry observation, no GPU/draw proof'},indent=2)+'\n',encoding='utf-8')
start=time.monotonic()
with (out/'engine.log').open('wb') as log:result=subprocess.run(command,env=env,cwd=tree,stdout=log,stderr=subprocess.STDOUT,timeout=180)
after=hashes();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
log=(out/'engine.log').read_text(encoding='utf-8',errors='replace');errors=[line for line in log.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|ObjectDB.*leaked|resources still in use|RID allocations',line)]
receipt={'exit':result.returncode,'wall_seconds':time.monotonic()-start,'source_unchanged':before==after,'diagnostics':errors,'passed':result.returncode==0 and before==after and not errors}
(out/'exit.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');(out/'runner-original.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(receipt));sys.exit(0 if receipt['passed'] else 1)
