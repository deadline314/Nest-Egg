from pathlib import Path
import hashlib,json,math,sys
from reader_route_v4 import intersects
here=Path(__file__).resolve().parent
root=here/sys.argv[1];out=here/sys.argv[2];out.mkdir()
def hit(o,d,r):
    low=0;high=math.inf
    for i in range(2):
        if abs(d[i])<1e-12:
            if not r[i]<=o[i]<=r[i]+r[i+2]:return False
        else:
            a=(r[i]-o[i])/d[i];b=(r[i]+r[i+2]-o[i])/d[i];low=max(low,min(a,b));high=min(high,max(a,b))
    return low<=high
assert hit([10,10],[0,-1],[9,0,2,2]) and not hit([10,10],[0,-1],[20,0,2,2])
doc=json.loads((root/'aim-trace.json').read_text(encoding='utf-8'));receipt=json.loads((root/'exit.json').read_text(encoding='utf-8'))
assert receipt['passed'] and receipt['source_unchanged']
rows=doc['rows'];failures=[];peak=0;peak_row=None;mutual=[]
for i,r in enumerate(rows):
    if not r['alive'] or not r['processing'] or r['alpha']<.95:failures.append({'row':i,'kind':'liveness'})
    shapes=[(f'icon{k}',s) for k,s in enumerate(r['icons'])]+[('reserve',r['reserve']),('plate',r['plate'])]
    for name,s in shapes:
        if hit(r['muzzle'],r['aim'],s):failures.append({'row':i,'phase':r['phase'],'sample':r['sample'],'kind':'ray','shape':name})
        if intersects(s,r['head']):failures.append({'row':i,'phase':r['phase'],'sample':r['sample'],'kind':'head','shape':name})
        if s[0]<0 or s[1]<0 or s[0]+s[2]>640 or s[1]+s[3]>360:failures.append({'row':i,'kind':'view','shape':name})
    for name,s in shapes[:-1]:
        if intersects(s,r['plate']):mutual.append({'row':i,'phase':r['phase'],'sample':r['sample'],'shape':name})
    if i:
        prior=rows[i-1];assert r['process']>prior['process'] and r['usec']>prior['usec']
        move=math.dist(r['far'],prior['far'])
        if move>peak:peak=move;peak_row=i
        if move>=24:failures.append({'row':i,'phase':r['phase'],'sample':r['sample'],'kind':'motion','actual':move})
record={'scope':'independent read-only CPU published-process geometry, not Forward+ or pixels; original <24 plus true recorded head/aim/view/liveness; mutual rectangle inventory is separately reported, not an invented opaque-pixel proof','rows':len(rows),'trace_sha256':hashlib.sha256((root/'aim-trace.json').read_bytes()).hexdigest(),'peak':peak,'peak_row':peak_row,'failures':failures,'mutual_rectangle_inventory':mutual,'last':rows[-1],'passed':not failures}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');(out/'reader-original.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k:v for k,v in record.items() if k not in ['last','mutual_rectangle_inventory']},indent=2));sys.exit(0 if record['passed'] else 1)
