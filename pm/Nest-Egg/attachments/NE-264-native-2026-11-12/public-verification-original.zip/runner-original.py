from pathlib import Path
import hashlib,json,subprocess,sys,time,zipfile
here=Path(__file__).resolve().parent;packet=here/'delivery-final-v1';out=here/'public-verification-final-v1';out.mkdir()
commands=[['verify_native.py','--raw-root','D:/NestEggDeliveries/NE264-20261112/v14-native-v1','--receipt',str(out/'native-receipt.json')],['verify_legacy.py'],['verify_tests.py']]
sources={name:hashlib.sha256((packet/name).read_bytes()).hexdigest() for name in ['verify_native.py','verify_legacy.py','verify_tests.py']}
results=[]
for args in commands:
    command=[sys.executable,str(packet/args[0]),*args[1:]];started=time.monotonic()
    with (out/(args[0]+'.log')).open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    results.append({'command':command,'exit':result.returncode,'wall_seconds':time.monotonic()-started})
    print(json.dumps(results[-1]),flush=True)
    assert result.returncode==0
assert sources=={name:hashlib.sha256((packet/name).read_bytes()).hexdigest() for name in sources}
(out/'receipt.json').write_text(json.dumps({'passed':True,'source_before':sources,'source_after':sources,'runs':results,'scope':'independent read-only extraction/NP/source/log checks, no new game execution'},indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'runner-original.py').write_bytes(Path(__file__).read_bytes())
with zipfile.ZipFile(packet/'public-verification-original.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in out.iterdir():
        if p.is_file():z.writestr(p.name,p.read_bytes())
print('all three public readers passed; original stdout/receipts sealed')
