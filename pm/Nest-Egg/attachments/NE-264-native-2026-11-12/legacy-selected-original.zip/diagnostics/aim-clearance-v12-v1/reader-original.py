"""Read-only NE264 aim-direction criterion on the six original captures."""
from pathlib import Path
import hashlib,json,math
here=Path(__file__).resolve().parent
index=json.loads((here/'NATIVE-V12-INDEX.json').read_text(encoding='utf-8'))
out=here/'aim-clearance-v12-v1';out.mkdir()
def hit(origin,direction,rect):
    low=0.0;high=math.inf
    for axis in range(2):
        a=rect[axis];b=a+rect[axis+2]
        if direction[axis]==0:
            if origin[axis]<a or origin[axis]>b:return False
        else:
            p=(a-origin[axis])/direction[axis];q=(b-origin[axis])/direction[axis]
            low=max(low,min(p,q));high=min(high,max(p,q))
    return low<=high
assert hit([10,10],[1,0],[20,9,2,2])
assert not hit([10,10],[1,0],[0,9,2,2])
assert hit([10,10],[0,-1],[9,0,2,2])
assert not hit([10,10],[0,-1],[20,0,2,2])
cases=[];failures=[];first=None
for case in index['cases']:
    root=Path(case['capture']);raw=(root/'result.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==case['result_sha256']
    report=json.loads(raw);rows=report['static']+report['phase_baselines']+report['frames']
    for row in rows:
        a,b,c,d,_,_=row['canvas_transform'];x,y=row['aim'];direction=[a*x+c*y,b*x+d*y]
        assert math.hypot(*direction)>0
        if first is None:first=(row['aim_start_logical'],direction)
        shapes=[(f'icon{i}',icon['logical']) for i,icon in enumerate(row['icons'])]+[('reserve',row['reserve_logical']),('plate',row['plate_logical'])]
        for name,rect in shapes:
            if hit(row['aim_start_logical'],direction,rect):failures.append({'case':case['case'],'phase':row.get('phase',row.get('name')),'sample':row.get('sample'),'shape':name,'rect':rect,'muzzle':row['aim_start_logical'],'forward_direction':direction})
    cases.append({'case':case['case'],'rows':len(rows),'result_sha256':case['result_sha256'],'ray_rect_checks':sum(len(r['icons'])+2 for r in rows)})
origin,direction=first;length=math.hypot(*direction);point=[origin[i]+direction[i]*10/length for i in range(2)]
injected=[point[0]-2,point[1]-2,4,4]
assert hit(origin,direction,injected),'meaningful on-ray HUD negative must be rejected'
record={'scope':'actual forward shooting direction from recorded muzzle and actual aim_dir transformed by the recorded canvas basis; closed rectangle intersection with all attached icons/reserve/plate. Infinite forward ray, no invented distance/angle tolerance. Read-only metadata check, no new rendering, physical-input or performance claim.','cases':cases,'failures':failures,'known_answers':4,'negative_control':{'scope':'metadata-only injected plate on one actual recorded forward ray, not a native image','rect':injected,'rejected':True},'passed':not failures}
(out/'audit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');(out/'reader-original.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'cases':cases,'failures':failures,'passed':not failures},indent=2))
