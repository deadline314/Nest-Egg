"""Read-only natural-render HUD geometry validation; previews are explicitly derived."""
from pathlib import Path
import argparse,base64,hashlib,json,math
import numpy as np
from PIL import Image

def sha(b):return hashlib.sha256(b).hexdigest()
def rect_end(r):return [r[0]+r[2],r[1]+r[3]]
def encloses(a,b):return b[0]>=a[0] and b[1]>=a[1] and b[0]+b[2]<=a[0]+a[2] and b[1]+b[3]<=a[1]+a[3]
def intersects(a,b):return a[0]<b[0]+b[2] and a[0]+a[2]>b[0] and a[1]<b[1]+b[3] and a[1]+a[3]>b[1]
def mapped(r,t):
    points=[(r[0],r[1]),(r[0]+r[2],r[1]),(r[0],r[1]+r[3]),(r[0]+r[2],r[1]+r[3])]
    x=[t[0]*x+t[2]*y+t[4] for x,y in points];y=[t[1]*x+t[3]*y+t[5] for x,y in points]
    return [min(x),min(y),max(x)-min(x),max(y)-min(y)]
def close(a,b):return all(abs(x-y)<=0.001 for x,y in zip(a,b))
def srgb(rgb):return np.where(rgb<=0.0031308,12.92*rgb,1.055*np.maximum(rgb,0)**(1/2.4)-0.055)
def parse_check(root):
    report=json.loads((root/"parse.json").read_text(encoding="utf-8"))
    assert report["parsed"] and report["source_format"]==11 and report["encoded_format"]==5
    source=np.frombuffer(base64.b64decode(report["source_bytes_base64"]),dtype="<f4").reshape(-1,4)
    encoded=np.frombuffer(base64.b64decode(report["encoded_rgba8_base64"]),dtype=np.uint8).reshape(-1,4).astype(np.float64)/255
    expected=np.clip(srgb(source[:,:3].astype(np.float64)),0,1)
    error=float(np.abs(expected-encoded[:,:3]).max())
    alpha_error=float(np.abs(source[:,3]-encoded[:,3]).max())
    assert error<=1/255+0.00001 and alpha_error<=1/255+0.00001
    return {"scope":"parser and known float transfer only; not native UI acceptance","passed":True,"max_rgb_error":error,"max_alpha_error":alpha_error}
def visible(row):
    assert row["player_alive"] and row["health"]>0 and row["max_health"]>=row["health"] and not row["paused"] and row["time_scale"]==1
    assert row["player_physics_processing"] and row["player_can_process"] and row["player_visible"]
    assert row["tray_showing"] and row["tray_visible"] and row["tray_alpha"]>=0.95 and row["tray_processing"] and row["tray_can_process"] and row["tray_has_pos"] and row["tray_has_mag"] and row["icons"]
    assert row["tag_visible"] and row["tag_alpha"]>=0.95 and row["tag_processing"] and row["tag_can_process"] and row["tag_has_pos"] and row["tag_health"]>0 and row["tag_max_health"]>0
    assert row["head_visible"] and row["player_visual_visible"] and row["head_effective_alpha"]>=0.95 and row["materialize_left"]<=0
    assert row["tag_pop"]==0 and row["tag_shake"]==0,"bounds fixture must not hide unmodelled damage/pop geometry"
    logical=row["viewport_logical"]
    for icon in row["icons"]:
        assert encloses(logical,icon["logical"]),"icon clipped"
        assert close(mapped(icon["local"],row["tray_to_logical"]),icon["logical"])
        assert close(mapped(icon["logical"],row["final_transform"]),icon["screen"])
    for name in ["reserve","plate","guard"]:
        assert encloses(logical,row[name+"_logical"]),name+" clipped"
        assert close(mapped(row[name+"_logical"],row["final_transform"]),row[name+"_screen"])
    assert row["reserve_text"]
    return True
def validate_static(row,root):
    visible(row)
    assert row["on_floor"],"static player not really grounded"
    assert row["head_logical"][2]>0 and row["head_logical"][3]>0
    for bound in [i["logical"] for i in row["icons"]]+[row["reserve_logical"],row["plate_logical"]]:
        assert not intersects(bound,row["head_logical"]),"HUD overlaps actual head alpha-used bounds"
    assert not intersects(row["feet_logical"],row["weapon_bar_logical"]),"weapon bar overlaps actual rendered feet envelope"
    data=(root/row["path"]).read_bytes();assert sha(data)==row["sha256"]
    with Image.open(root/row["path"]) as image:assert list(image.size)==row["actual_readback_size"]==row["window_size"]
def raw_image(root,row,formats):
    raw=(root/row["raw_path"]).read_bytes();assert sha(raw)==row["raw_sha256"] and len(raw)==row["raw_bytes"]
    # Same original Image format mapping as published verify_capture_precision.py.
    # Opaque Vulkan viewport readback is normally RGBH, not necessarily RGBAH.
    layout={14:("<f2",3),15:("<f2",4),10:("<f4",3),11:("<f4",4),5:("u1",4)}.get(row["roi_format"])
    assert layout,"unknown original format"
    dtype,channels=layout
    w,h=row["roi_screen"][2:]
    data=np.frombuffer(raw,dtype=dtype).reshape(h,w,channels)
    assert np.isfinite(data).all()
    data=data.astype(np.float64)/(255 if dtype=="u1" else 1)
    return np.concatenate([data,np.ones((h,w,1))],axis=2) if channels==3 else data
def movement(rows,baseline):
    points=[baseline["far_slot_local"]]+[r["far_slot_local"] for r in rows]
    displacement=[math.dist(a,b) for a,b in zip(points,points[1:])]
    assert max(displacement,default=0)<24.0,"original logical per-draw threshold; includes first post-input draw"
    return displacement

def head_sources(root,report):
    textures={}
    for entry in report['head_texture_rows']:
        raw=(root/entry['path']).read_bytes()
        assert sha(raw)==entry['sha256']
        w,h=entry['size']
        assert entry['decoded_format']==5 and len(raw)==w*h*4
        rgba=np.frombuffer(raw,dtype=np.uint8).reshape(h,w,4)
        assert np.count_nonzero(rgba[:,:,3])>0,'actual head alpha is empty; never accept an empty mask'
        assert entry['key'] not in textures
        textures[entry['key']]=entry
    assert textures
    return textures

def head_guard(row,textures):
    assert row['head_texture_key'] in textures
    assert row['head_hframes']==row['head_vframes']==1 and not row['head_region_enabled']
    assert row['head_sway_a_shape'][0]==row['head_sway_b_shape'][0]==0,'source-alpha affine proof requires no shader vertex/UV warp on this drawable'
    a,b,c,d,e,f=row['canvas_transform']
    g,h,i,j,k,l=row['head_to_world']
    composed=[a*g+c*h,b*g+d*h,a*i+c*j,b*i+d*j,a*k+c*l+e,b*k+d*l+f]
    assert close(composed,row['head_to_logical']),'world/canvas head transform composition mismatch'
    assert close(mapped(row['head_sprite_rect'],row['head_to_logical']),row['head_full_rect_logical']),'head affine/AABB mismatch'
    # The full quad, including transparent canvas and a one-logical-pixel AA
    # margin, is a conservative superset. Zero rectangle intersection proves
    # separation. A nonzero intersection is refused, never divided away.
    x,y,w,h=row['head_full_rect_logical']
    conservative=[x-1,y-1,w+2,h+2]
    for shape in [i['logical'] for i in row['icons']]+[row['reserve_logical'],row['plate_logical']]:
        assert not intersects(shape,conservative),'HUD intersects conservative real head quad; inspect exact alpha/PNG, do not report acceptance'
def capture_check(root,previews=None):
    report=json.loads((root/"result.json").read_text(encoding="utf-8"))
    assert report["renderer"]=="forward_plus" and "9070 XT" in report["device"] and report["hdr_2d"]
    assert all(c["ok"] for c in report["checks"]),"producer has an original failed assertion"
    textures=head_sources(root,report)
    receipt=json.loads((root/"exit.json").read_text(encoding="utf-8"))
    assert receipt["exit"]==0 and receipt["engine_clean"] and not receipt["diagnostics"] and receipt["before"]==receipt["after"] and receipt["c_sources_unchanged"]
    assert receipt["queue_qualified"]
    assert receipt['full_runtime_context_unchanged']
    full_before=json.loads((root/'runtime-context-before.json').read_text(encoding='utf-8'))
    assert full_before==json.loads((root/'runtime-context-after.json').read_text(encoding='utf-8'))
    candidate=json.loads((root/'candidate-manifest.json').read_text(encoding='utf-8'))
    for entry in candidate['paths']:
        assert full_before[entry['path']]==entry['candidate_sha256']
        assert sha((root/'source'/entry['path']).read_bytes())==entry['candidate_sha256']
    locked=json.loads((root/'locked-engine.json').read_text(encoding='utf-8'))
    assert locked['engine_started'] and locked['engine_exit']==0 and locked['inside_lock_before_clear'] and locked['inside_lock_after_clear']
    expected=json.loads((root/"c-context-expected.json").read_text(encoding="utf-8"))["files"]
    assert json.loads((root/"c-before.json").read_text(encoding="utf-8"))==json.loads((root/"c-after.json").read_text(encoding="utf-8"))==expected
    for name in ["queue-before.json","queue-after.json"]:
        queue=json.loads((root/name).read_text(encoding="utf-8"))
        assert set(queue["ports"])=={"8188","8189"}
        assert all(r["status"]=="connection_refused" and "10061" in r.get("error","") or r["status"]=="reachable" and r["running"]==r["pending"]==0 for r in queue["ports"].values())
    for row in report["static"]:
        validate_static(row,root)
        head_guard(row,textures)
    results=[]
    for phase in ["turn","jump","run","run-aim-up"]:
        rows=[r for r in report["frames"] if r["phase"]==phase]
        if not rows:continue
        assert len(rows)<={"turn":90,"jump":90,"run":240,"run-aim-up":240}[phase]
        for row in rows:
            visible(row)
            head_guard(row,textures)
            raw_image(root,row,report["format_ids"])
        assert all(b["process"]>a["process"] and b["usec"]>=a["usec"] for a,b in zip(rows,rows[1:])),"not separate natural published process frames"
        baseline=next(r for r in report["phase_baselines"] if r["phase"]==phase)
        visible(baseline)
        head_guard(baseline,textures)
        assert baseline["process"]<rows[0]["process"]
        displacement=movement(rows,baseline)
        largest=max(displacement,default=0)
        assert largest<24.0,(phase,largest,"original logical per-draw threshold")
        if phase=="jump":assert len(rows)>=50 and max(displacement[:50])<24.0
        if phase=="turn":
            assert len(rows)>=40 and max(displacement[:40])<24.0
            summary=next(s for s in report['phase_summaries'] if s['phase']==phase)
            assert summary['settled_turn'] and summary['stable_draws']>=3
            assert abs(summary['first40_largest_logical']-max(displacement[:40]))<0.001
        assert all(abs(value-row["far_displacement_logical"])<=0.001 for value,row in zip(displacement,rows))
        if phase=="jump":assert any(not r["on_floor"] and r["velocity"][1]<0 for r in rows) and rows[-1]["on_floor"]
        if phase in ["run","run-aim-up"]:assert rows[-1]["tray_above"]<0.01 and baseline["tray_above"]>0.99 and any(abs(r["velocity"][0])>20 for r in rows)
        if phase=="run-aim-up":assert all(abs(r["aim"][0])<0.001 and r["aim"][1]<-0.99 and r["facing"]==1 for r in rows)
        if phase=="turn":assert rows[0]["tray_draw_side"]<rows[-1]["tray_draw_side"]
        peak=displacement.index(largest) if displacement else 0
        results.append({"phase":phase,"drawn_samples":len(rows),"largest_logical":largest,"peak_sample":peak,"threshold":24.0,"observed_process_delta_range":[min(r["process_delta"] for r in rows),max(r["process_delta"] for r in rows)],"readback_usec_max":max(r["readback_usec"] for r in rows)})
        if previews:
            for index in sorted({0,peak,len(rows)-1}):
                row=rows[index];image=raw_image(root,row,report["format_ids"])
                rgb=np.clip(srgb(image[:,:,:3]),0,1);alpha=np.clip(image[:,:,3:4],0,1)
                rgba=np.rint(np.concatenate([rgb,alpha],axis=2)*255).astype(np.uint8)
                previews.mkdir(parents=True,exist_ok=True)
                Image.fromarray(rgba).save(previews/(phase+f"-{index:03d}-derived.png"))
    return {"scope":"natural post-draw HUD; original first40/first50 and entire tail logical <24; head separation uses full actual unwarped quad as conservative superset, with nonempty original Texture2D source alpha; not exact rendered alpha or performance", "static_images":len(report["static"]),"head_texture_sources":len(textures),"phases":results,"passed":True}

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("root",type=Path);p.add_argument("--parse",action="store_true");p.add_argument("--previews",type=Path)
    a=p.parse_args();print(json.dumps(parse_check(a.root) if a.parse else capture_check(a.root,a.previews),ensure_ascii=False,indent=2))
