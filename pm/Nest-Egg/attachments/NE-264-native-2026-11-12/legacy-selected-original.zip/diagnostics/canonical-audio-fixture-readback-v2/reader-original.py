from pathlib import Path
import hashlib,json,re,subprocess,sys
here=Path(__file__).resolve().parent
capture=here/'canonical-audio-fixture-control-v1'
out=here/'canonical-audio-fixture-readback-v2';out.mkdir()
context=json.loads((here/'canonical-v11-source-context-final-v2.json').read_text(encoding='utf-8'));tree=Path(context['tree'])
receipt=json.loads((capture/'exit.json').read_text(encoding='utf-8'))
log=(capture/'engine.log').read_text(encoding='utf-8')
assert receipt['exit']==0 and receipt['source_unchanged']
assert json.loads((capture/'source-before.json').read_text(encoding='utf-8'))==json.loads((capture/'source-after.json').read_text(encoding='utf-8'))==context['files']
assert 'checks: 242, failures: 0' in log
assert not re.search(r'SCRIPT ERROR|^FAIL:|ObjectDB.*leaked|resources still in use|RID allocations',log,re.M)
shell='source tools/test_filters.sh; if has_unexpected_errors "$1"; then exit 1; else exit 0; fi'
command=['C:/Program Files/Git/bin/bash.exe','-c',shell,'fixture-control',str(capture/'engine.log')]
result=subprocess.run(command,cwd=tree,capture_output=True)
(out/'filter.stdout').write_bytes(result.stdout);(out/'filter.stderr').write_bytes(result.stderr)
(out/'published-test-filters-original.sh').write_bytes((tree/'tools/test_filters.sh').read_bytes())
(out/'reader-original.py').write_bytes(Path(__file__).read_bytes())
record={'scope':'read-only classification correction, no engine rerun or original artifact mutation','actual_engine_exit':receipt['exit'],'checks':242,'failures':0,'source_guard_count':len(context['files']),'source_unchanged':True,'source_filter_command':command,'published_filter_sha256':hashlib.sha256((tree/'tools/test_filters.sh').read_bytes()).hexdigest(),'engine_log_sha256':hashlib.sha256((capture/'engine.log').read_bytes()).hexdigest(),'original_wrapper_receipt_sha256':hashlib.sha256((capture/'exit.json').read_bytes()).hexdigest(),'filter_exit':result.returncode,'expected_error_lines':[line for line in log.splitlines() if line.startswith('ERROR:')],'erratum':'original strict CPU observer wrapper rejected two intentional SoundLab invalid-layout fixture ERROR lines. Published test_filters.sh accepts these exact test_audio_ lines. Original wrapper refusal remains; this independent reader does not call the log zero-ERROR.','passed':result.returncode==0}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k not in ['source_filter_command','expected_error_lines']}));sys.exit(0 if record['passed'] else 1)
