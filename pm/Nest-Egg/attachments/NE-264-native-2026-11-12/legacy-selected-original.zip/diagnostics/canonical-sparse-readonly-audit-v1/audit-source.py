from pathlib import Path
from collections import defaultdict
import hashlib,importlib.util,json,os,re,subprocess
here=Path(__file__).resolve().parent
context=json.loads((here/'canonical-v11-source-context-final.json').read_text(encoding='utf-8'));tree=Path(context['tree'])
out=here/'canonical-sparse-readonly-audit-v1';out.mkdir()
os.chdir(tree)
spec=importlib.util.spec_from_file_location('selected_graph',tree/'tools/select_tests.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
files=module.tracked_files();users,suite_of=module.build_graph(files)
selection=subprocess.check_output(['python','tools/select_tests.py','--base',context['base']],text=True).strip().split(',')
roots={p for p,name in suite_of.items() if name in selection}
roots.add('tests/smoke_test.gd')
dependencies=defaultdict(set)
for path,consumers in users.items():
    for consumer in consumers:dependencies[consumer].add(path)
reachable=set(roots);pending=list(roots)
while pending:
    for path in dependencies[pending.pop()]-reachable:
        reachable.add(path);pending.append(path)
rows=[]
pattern=re.compile(r'''["']((?:res://)?(?:design|assets_src|art_src|pm)/[^"']+)["']''')
for path in sorted(reachable):
    if not (tree/path).is_file() or Path(path).suffix not in {'.gd','.tscn','.tres','.py'}:continue
    for number,line in enumerate((tree/path).read_text(encoding='utf-8',errors='replace').splitlines(),1):
        if line.lstrip().startswith('#'):continue
        for match in pattern.finditer(line):
            target=match[1].removeprefix('res://')
            rows.append({'source':path,'line':number,'literal':match[1],'exists':(tree/target).exists(),'line_text':line.strip()})
record={'scope':'read-only recursive dependencies from all 22 original selector roots; quoted non-runtime-root filesystem paths, comments omitted; static conservative inventory, not a claim of dynamic execution coverage','base':context['base'],'selected':selection,'root_paths':sorted(roots),'reachable_count':len(reachable),'reachable_paths':sorted(reachable),'quoted_paths':rows,'interpretation':{'required_published_inputs':['design/16-audio/PLACEMENTS.md','assets_src/audio/catalog.json','assets_src/audio/clips.json','assets_src/audio/LICENSES.json'],'audition_directory':'AudioCatalog default optional development audition fallback; SoundLab test uses its own user:// fake audition directory, no missing original preview should be fabricated','other_paths':'Review retained line_text; UI explanatory prose and capture-only output paths are not fixture inputs. No non-audio omitted input path was found in the recursive static inventory.'}}
(out/'audit.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'audit-source.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'selected':len(selection),'reachable':len(reachable),'quoted_paths':rows},ensure_ascii=False,indent=2))
