"""One nonblocking acquisition of the existing primary checkout GPU lock."""
from pathlib import Path
import json,os,subprocess,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg')
sys.path.insert(0,str(primary/'tools/comfyui'))
import comfy_guard
assert sys.argv[1]=='--'
command=sys.argv[2:]
out=Path(command[2])  # python route_locked_launch.py OUT -- Godot...
comfy_guard.LOCK_PATH.parent.mkdir(parents=True,exist_ok=True)
handle=open(comfy_guard.LOCK_PATH,'a+b')
acquired=False
try:
    handle.seek(0)
    try:
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        acquired=True
    except OSError as error:
        (out/'lock-refused.json').write_text(json.dumps({'acquired':False,'canonical_lock':str(comfy_guard.LOCK_PATH),'error':str(error),'engine_started':False},indent=2)+'\n',encoding='utf-8')
        sys.exit(2)
    (out/'lock-acquired.json').write_text(json.dumps({'acquired':True,'nonblocking':True,'canonical_lock':str(comfy_guard.LOCK_PATH)},indent=2)+'\n',encoding='utf-8')
    sys.exit(subprocess.call(command))
finally:
    if acquired:
        handle.seek(0)
        if os.name=='nt':msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
        else:fcntl.flock(handle.fileno(),fcntl.LOCK_UN)
    handle.close()
