"""Invoked inside the PRIMARY gpu_lock; verify queues again before Godot."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,urllib.request

out=Path(sys.argv[1]);assert sys.argv[2]=='--'
command=sys.argv[3:]
def queue(phase):
    ports={}
    for port in [8188,8189]:
        try:
            raw=urllib.request.urlopen(f'http://127.0.0.1:{port}/queue',timeout=3).read()
            doc=json.loads(raw)
            private=out/f'queue-locked-{phase}-{port}-private-original.json'
            assert not private.exists();private.write_bytes(raw)
            ports[str(port)]={'status':'reachable','running':len(doc['queue_running']),'pending':len(doc['queue_pending']),'body_bytes':len(raw),'body_sha256':hashlib.sha256(raw).hexdigest()}
        except Exception as error:
            ports[str(port)]={'status':'connection_refused' if '10061' in str(error) else 'unknown','error':str(error)}
    result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'inside primary C gpu_lock','ports':ports}
    (out/f'queue-locked-{phase}.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    return all(p['status']=='connection_refused' and '10061' in p.get('error','') or p['status']=='reachable' and p['running']==p['pending']==0 for p in ports.values())

before=queue('before')
timed_out=False
code=None
if before:
    try:
        # This is the exact owned Godot child inside the lock. Never leave an
        # orphan engine when the outer wrapper reaches its longer deadline.
        code=subprocess.run(command,timeout=150).returncode
    except subprocess.TimeoutExpired:
        timed_out=True
        code=-9
after=queue('after') if before else None
receipt={'engine_started':before,'engine_exit':code,'owned_engine_timeout':timed_out,'inside_lock_before_clear':before,'inside_lock_after_clear':after,'command':command}
(out/'locked-engine.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
sys.exit(code if code is not None else 2)
