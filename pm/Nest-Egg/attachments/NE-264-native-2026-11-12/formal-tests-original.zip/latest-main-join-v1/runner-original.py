"""Own D only: preserve v14, restore its four bases, then fast-forward main."""
from pathlib import Path
import hashlib,json,subprocess
here=Path(__file__).resolve().parent;tree=Path('D:/NestEggVerification/ne264-canonical-v9-20261112')
out=here/'latest-main-join-v1';out.mkdir()
old=json.loads((here/'canonical-v14-context.json').read_text(encoding='utf-8'))
before={p:hashlib.sha256((tree/p).read_bytes()).hexdigest() for p in old['files']};assert before==old['files']
assert json.loads((here/'canonical-affected-v14-v1/exit.json').read_text())['passed']
manifest=json.loads((here/'final-four-v1/manifest.json').read_text(encoding='utf-8'))
paths=[r['path'] for r in manifest['paths']]
def git(*args):return subprocess.check_output(['git',*args],cwd=tree,stderr=subprocess.STDOUT)
assert sorted(git('diff','--name-only').decode().splitlines())==sorted(paths)
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in manifest['paths']:
    path=row['path'];raw=(tree/path).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['native_v14_sha256']
    dest=out/'original-v14'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
head_before=git('rev-parse','HEAD').decode().strip();assert head_before==old['base']
commands=[]
for args in [('restore','--source=HEAD','--worktree','--',*paths),('fetch','origin','main'),('rebase','origin/main')]:
    result=git(*args);commands.append({'command':['git',*args],'output':result.decode('utf-8',errors='replace')})
head_after=git('rev-parse','HEAD').decode().strip();assert head_after==git('rev-parse','origin/main').decode().strip()
changes=git('diff','--name-only',head_before,head_after,'--','ui','core','game','autoload','data','tests','project.godot').decode().splitlines()
for row in manifest['paths']:
    path=row['path'];assert hashlib.sha256((tree/path).read_bytes()).hexdigest()==row['base_sha256'],path
    raw=(here/'final-four-v1/candidate'/path).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['candidate_sha256']
    (tree/path).write_bytes(raw)
assert sorted(git('diff','--name-only').decode().splitlines())==sorted(paths)
tracked=git('ls-files','-z').decode().split('\0')
files={p:hashlib.sha256((tree/p).read_bytes()).hexdigest() for p in sorted(tracked) if p and (tree/p).is_file()}
context={'base':head_after,'tree':str(tree),'scope':'actual latest fetched origin/main plus only final four; final helper differs from actual native v14 only in three comment locations; old native C393/D10162 epochs unchanged','changed':paths,'files':files}
(out/'context.json').write_text(json.dumps(context,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'adoption.json').write_text(json.dumps({'before_head':head_before,'actual_latest_main':head_after,'commands':commands,'published_runtime_and_test_changes':changes,'source_count':len(files),'only_delta':paths,'final_manifest':manifest},indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'runner-original.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'actual_latest_main':head_after,'source_count':len(files),'published_runtime_and_test_changes':changes,'only_delta':paths},indent=2))
