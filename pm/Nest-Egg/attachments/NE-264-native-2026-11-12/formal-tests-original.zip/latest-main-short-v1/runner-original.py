from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time

here=Path(__file__).resolve().parent
context=json.loads((here/'latest-main-join-v1/context.json').read_text(encoding='utf-8'))
tree=Path(context['tree'])
out=here/sys.argv[1]
out.mkdir()
def sha(data):return hashlib.sha256(data).hexdigest()
def hashes():return {p:sha((tree/p).read_bytes()) for p in context['files']}
before=hashes()
assert before==context['files']
base=subprocess.check_output(['git','rev-parse','origin/main'],cwd=tree,text=True).strip()
assert base==context['base']
generated=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=tree,text=True).splitlines()
assert all(p.endswith('.gd.uid') for p in generated),generated
(out/'generated-import-uids.json').write_text(json.dumps({p:sha((tree/p).read_bytes()) for p in generated},indent=2)+'\n',encoding='utf-8')
# These are editor-generated UIDs absent from the published tree. Keep their
# original bytes, but do not mislabel them as ticket source changes.
exclude=tree/'.git/info/exclude'
with exclude.open('a',encoding='utf-8',newline='\n') as f:
    for p in generated:f.write('/'+p+'\n')
status=subprocess.check_output(['git','diff','--name-only',base],cwd=tree,text=True).splitlines()
assert sorted(status)==sorted(context['changed']),status
selected=subprocess.run([sys.executable,'tools/select_tests.py','--base',base,'--explain'],cwd=tree,capture_output=True)
(out/'selector.stdout').write_bytes(selected.stdout)
(out/'selector.stderr').write_bytes(selected.stderr)
assert selected.returncode==0
for path in context['changed']+['tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt','tests/smoke_test.gd','tests/smoke_test.tscn']:
    dest=out/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes((tree/path).read_bytes())
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
(out/'runner-original.py').write_bytes(Path(__file__).read_bytes())
command=['C:/Program Files/Git/bin/bash.exe','tools/run_tests_parallel.sh','--only=AmmoTraySuite,DeathFlowSuite,CutsceneSuite']
env=os.environ.copy()
env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='2',LOG_DIR=(out/'logs').as_posix(),PYTHONIOENCODING='utf-8')
(out/'logs').mkdir()
(out/'command.json').write_text(json.dumps({'cwd':str(tree),'command':command,'base':base,'changed':status,'env':{k:env[k] for k in ['GODOT','SHARDS','LOG_DIR','PYTHONIOENCODING']},'scope':'latest actual origin/main plus final four (only helper comments differ from native v14); original AmmoTray/DeathFlow/Cutscene join only, not a second full affected22 claim; headless functional, not performance'},indent=2)+'\n',encoding='utf-8')
started=time.monotonic()
with (out/'full.log').open('wb') as log:
    result=subprocess.run(command,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT)
after=hashes()
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
raw=(out/'full.log').read_text(encoding='utf-8',errors='replace')
script_errors=[]
for path in (out/'logs').glob('shard_*.log'):
    script_errors += [str(path)+':'+line for line in path.read_text(encoding='utf-8',errors='replace').splitlines() if 'SCRIPT ERROR' in line]
receipt={'exit':result.returncode,'wall_seconds':time.monotonic()-started,'source_unchanged':before==after,'script_errors':script_errors,'summary':re.findall(r'^checks:.*$',raw,re.M),'passed':result.returncode==0 and before==after and not script_errors}
(out/'exit.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt));sys.exit(0 if receipt['passed'] else 1)
