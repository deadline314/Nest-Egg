"""Separate public one-shot / reload acceptance; never mutates capture bytes."""
from pathlib import Path
import argparse,json
import numpy as np
from PIL import Image
import reader_route_v4 as common

def ammo_sequence(report,baseline,rows):
    initial=report['shot_before']
    assert initial>1 and initial==baseline['clip'] and not baseline['player_reloading']
    assert report['shot_seen'] and report['reload_seen'] and report['reload_done']
    assert all(r['active_weapon']==baseline['active_weapon'] and r['active_slot']==baseline['active_slot'] for r in rows)
    clips=[r['clip'] for r in rows]
    assert min(clips)==initial-1 and max(clips)==initial and clips[-1]==initial
    shot=next(i for i,r in enumerate(rows) if r['clip']==initial-1)
    reload=next(i for i,r in enumerate(rows) if r['player_reloading'])
    assert shot<=reload and any(not r['player_reloading'] and r['clip']==initial for r in rows[reload+1:])
    assert all(r['clip']==initial and not r['player_reloading'] for r in rows[-3:])
    actions=[e for e in report['events'] if baseline['usec']<e['usec']<rows[-1]['usec']]
    press=next(e for e in actions if e['action']=='shoot' and e['pressed'])
    release=next(e for e in actions if e['action']=='shoot' and not e['pressed'])
    reload_press=next(e for e in actions if e['action']=='reload' and e['pressed'])
    assert baseline['usec']<press['usec']<rows[0]['usec']
    assert rows[shot]['usec']<release['usec']<=reload_press['usec']
    assert reload_press['usec']<rows[reload]['usec']
    return initial,shot,reload

def validate(root,previews=None):
    common.capture_check(root)
    report=json.loads((root/'result.json').read_text(encoding='utf-8'))
    assert report['process_cap']==report['actual_engine_max_fps']==60
    rows=report['frames'];assert 8<=len(rows)<=120
    assert all(r['phase']=='shoot-reload' and r['sample']==i for i,r in enumerate(rows))
    assert len(report['phase_baselines'])==1
    baseline=report['phase_baselines'][0]
    textures=common.head_sources(root,report)
    for row in [baseline]+rows:
        common.visible(row);common.head_guard(row,textures)
    for row in rows:common.raw_image(root,row,report['format_ids'])
    assert all(a['process']<b['process'] and a['usec']<b['usec'] for a,b in zip([baseline]+rows,rows))
    motion=common.movement(rows,baseline)
    assert all(abs(d-r['far_displacement_logical'])<.001 for d,r in zip(motion,rows))
    assert max(motion)<24
    assert all(d<.25 for d in motion[-3:])
    initial,shot,reload=ammo_sequence(report,baseline,rows)
    if previews:
        previews.mkdir(parents=True,exist_ok=True)
        for index in sorted({shot,reload,motion.index(max(motion)),len(rows)-1}):
            image=common.raw_image(root,rows[index],report['format_ids'])
            rgb=np.clip(common.srgb(image[:,:,:3]),0,1);alpha=np.clip(image[:,:,3:4],0,1)
            Image.fromarray(np.rint(np.concatenate([rgb,alpha],axis=2)*255).astype(np.uint8)).save(previews/f'shoot-reload-{index:03d}-derived.png')
    return {'scope':'real public shoot/reload events, natural process/postdraw, exact one-round cost and completed reload, original <24/head/inside/liveness gates; synthetic input, not physical controller','draws':len(rows),'initial_clip':initial,'least_clip':initial-1,'final_clip':rows[-1]['clip'],'shot_sample':shot,'reload_sample':reload,'largest_logical':max(motion),'passed':True}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('root',type=Path);parser.add_argument('--previews',type=Path)
    args=parser.parse_args();print(json.dumps(validate(args.root,args.previews),indent=2))
