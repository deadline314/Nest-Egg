"""Mixed-input scope v2: actual public reversal publication; safe vertical delay has no required halfway side value."""
from pathlib import Path
import argparse,json,math
import reader_route_v4 as common

def validate(root):
    # This validates source/queue/renderer/texture headers. The matrix reader
    # intentionally does not treat an unknown phase as motion acceptance.
    common.capture_check(root)
    report=json.loads((root/'result.json').read_text(encoding='utf-8'))
    assert report['process_cap']==report['actual_engine_max_fps']==30
    rows=report['frames']
    assert 54<=len(rows)<=120 and all(r['phase']=='mixed' and r['sample']==i for i,r in enumerate(rows))
    assert len(report['phase_baselines'])==1
    before=report['phase_baselines'][0]
    assert before['phase']=='mixed' and before['process']<rows[0]['process']
    textures=common.head_sources(root,report)
    for row in [before]+rows:
        common.visible(row);common.head_guard(row,textures)
        common.raw_image(root,row,report['format_ids'])
        assert row['actual_max_fps']==30
    for a,b in zip([before]+rows,rows):
        assert a['process']<b['process'] and a['usec']<b['usec']
    movement=common.movement(rows,before)
    assert all(abs(value-row['far_displacement_logical'])<.001 for value,row in zip(movement,rows))
    summary=report['phase_summaries'][0]
    assert summary['phase']=='mixed' and summary['settled_turn'] and summary['stable_draws']>=3
    assert abs(max(movement[2:52])-summary['first50_largest_logical'])<.001
    events=[r for r in report['events'] if before['usec']<=r['usec']<=rows[-1]['usec']]
    left=next(r for r in events if r['action']=='aim_left' and r['pressed'])
    jump=next(r for r in events if r['action']=='jump' and r['pressed'])
    reverse=next(r for r in events if r['action']=='aim_right' and r['pressed'])
    assert before['usec']<left['usec']<rows[0]['usec']
    assert rows[1]['usec']<jump['usec']<rows[2]['usec']
    assert rows[5]['usec']<reverse['usec']<rows[6]['usec']
    assert any(r['velocity'][1]<0 and not r['on_floor'] for r in rows[2:]) and rows[-1]['on_floor']
    assert any(r['tray_draw_side']>before['tray_draw_side']+0.001 for r in rows[:2]),'first public reversal must actually begin before the jump'
    assert any(r['facing']==-1 for r in rows[:6]) and any(r['facing']==1 for r in rows[6:]),'public reversals must reach the real Player'
    assert rows[-1]['tray_draw_side']<-.99
    return {'scope':'public aim reversal, two actual published draws then held jump, reverse again before draw6; original logical <24, exact head conservative bounds and entire flight/settle; no physical controller or performance claim','draws':len(rows),'first50_after_jump_max':max(movement[2:52]),'whole_trace_max':max(movement),'first_input_displacement':movement[0],'passed':True}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('root',type=Path)
    args=parser.parse_args();print(json.dumps(validate(args.root),indent=2))
