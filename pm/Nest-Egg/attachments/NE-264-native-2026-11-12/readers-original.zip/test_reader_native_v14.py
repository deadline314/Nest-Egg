"""Analytic known answers plus the real v12 filled-guard rejection."""
from pathlib import Path
import copy,json
import reader_native_v14 as reader

here=Path(__file__).resolve().parent
out=here/'reader-native-v14-controls-v1';out.mkdir()
checks=[]
for name,origin,direction,rect,expected in [
    ('forward',[10,10],[1,0],[20,9,2,2],True),
    ('behind',[10,10],[1,0],[0,9,2,2],False),
    ('up',[10,10],[0,-1],[9,0,2,2],True),
    ('parallel-clear',[10,10],[0,-1],[20,0,2,2],False),
    ('diagonal',[0,0],[1,-1],[9,-11,2,2],True),
    ('zero-distance-inside',[10,10],[1,0],[9,9,2,2],True),
]:
    assert reader.hit(origin,direction,rect)==expected
    checks.append({'name':name,'passed':True})
index=json.loads((here/'NATIVE-V12-INDEX.json').read_text(encoding='utf-8'))
root=Path(index['cases'][0]['capture']);raw=(root/'result.json').read_bytes()
report=json.loads(raw)
assert reader.common.sha(raw)==index['cases'][0]['result_sha256']
fails=reader.ray_failures(report)
assert fails
guard=next(r for r in report['frames'] if r['phase']=='run-aim-up' and r['sample']==0)
a,b,c,d,_,_=guard['canvas_transform'];x,y=guard['aim']
direction=[a*x+c*y,b*x+d*y]
assert guard['guard_ratio']==1 and guard['tag_alpha']>=.95 and guard['tag_pop']==guard['tag_shake']==0
assert reader.hit(guard['aim_start_logical'],direction,guard['guard_logical'])
checks.append({'name':'real-v12-opaque-full-guard-original-ray-rejected','passed':True,'result_sha256':reader.common.sha(raw),'muzzle':guard['aim_start_logical'],'direction':direction,'actual_filled_guard':guard['guard_logical'],'conflicts':len(fails)})
(out/'reader_native_v14.py').write_bytes((here/'reader_native_v14.py').read_bytes())
(out/'control-original.py').write_bytes(Path(__file__).read_bytes())
(out/'result.json').write_text(json.dumps({'scope':'read-only known analytic inputs and original v12 metadata/filled-guard failure, no new native acceptance','checks':checks,'passed':True},indent=2)+'\n',encoding='utf-8')
print(f'{len(checks)}/0; real v12 opaque guard rejected')
