"""Original continuous-aim gates plus original full-viewport/PNG verification."""
from pathlib import Path
import argparse,json,sys,traceback
import numpy as np
from PIL import Image
import reader_native_v14 as original

def full_check(root,report):
    records=report['full_viewports'];assert [r['sample'] for r in records]==[180,229]
    results=[]
    for entry in records:
        row=report['frames'][entry['sample']]
        assert all(entry[k]==row[k] for k in ['process','physics','usec'])
        assert entry['size']==row['actual_readback_size']==[1280,720]
        assert entry['format']==14 and not entry['has_mipmaps'] and entry['mipmap_count']==0
        raw=(root/entry['raw_path']).read_bytes()
        assert len(raw)==entry['raw_bytes']==1280*720*3*2
        assert original.common.sha(raw)==entry['raw_sha256']
        pixels=np.frombuffer(raw,dtype='<f2').reshape(720,1280,3).astype(np.float64)
        assert np.isfinite(pixels).all()
        x,y,w,h=row['roi_screen'];roi=original.common.raw_image(root,row,report['format_ids'])
        assert np.array_equal(pixels[y:y+h,x:x+w],roi[:,:,:3]),'full bytes and original ROI must be the same draw'
        encoded=(root/entry['png_path']).read_bytes();assert original.common.sha(encoded)==entry['png_sha256']
        with Image.open(root/entry['png_path']) as image:
            assert image.size==(1280,720) and image.mode=='RGBA'
            png=np.asarray(image)
        assert (png[:,:,3]==255).all(),'RGBH original is implicitly opaque; no original alpha channel exists'
        expected=np.clip(original.common.srgb(pixels),0,1)*255
        error=float(np.abs(expected-png[:,:,:3].astype(np.float64)).max())
        assert error<=1.00001,'float-linear sRGB before 8bit quantization, at most one encoded unit from CPU/Godot rounding'
        results.append({'sample':entry['sample'],'size':entry['size'],'format':14,'channels':3,'full_roi_bytes_same_draw':True,'max_srgb_quantization_error_in_8bit_units':error,'original_alpha':'implicit opaque RGBH; no native alpha bytes','png_alpha':255,'resize':False,'raw_sha256':entry['raw_sha256'],'png_sha256':entry['png_sha256']})
    return results

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('out',type=Path);a=p.parse_args();a.out.mkdir()
    receipt={'capture':str(a.root),'passed':False}
    for name in ['reader_aimfull_v14.py','reader_native_v14.py','reader_route_v4.py','reader_mixed_v2.py','reader_shoot_v11.py']:
        (a.out/name).write_bytes(Path(__file__).with_name(name).read_bytes())
    try:
        receipt['original_gates']=original.validate(a.root,'aim')
        receipt['full_viewports']=full_check(a.root,json.loads((a.root/'result.json').read_text(encoding='utf-8')))
        receipt['passed']=True
    except Exception as exc:receipt['error']=repr(exc);receipt['traceback']=traceback.format_exc()
    (a.out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,indent=2));sys.exit(0 if receipt['passed'] else 1)
