"""Read-only original native gates plus actual forward ray clearance."""
from pathlib import Path
import argparse,hashlib,json,math,sys,traceback
import reader_route_v4 as common
import reader_mixed_v2 as mixed
import reader_shoot_v11 as shoot

def hit(origin,direction,rect):
    low=0.;high=math.inf
    for axis in range(2):
        if abs(direction[axis])<1e-12:
            if not rect[axis]<=origin[axis]<=rect[axis]+rect[axis+2]:return False
        else:
            a=(rect[axis]-origin[axis])/direction[axis]
            b=(rect[axis]+rect[axis+2]-origin[axis])/direction[axis]
            low=max(low,min(a,b));high=min(high,max(a,b))
    return low<=high

def ray_failures(report):
    failures=[]
    rows=report['static']+report['phase_baselines']+report['frames']
    for i,row in enumerate(rows):
        a,b,c,d,_,_=row['canvas_transform'];x,y=row['aim']
        direction=[a*x+c*y,b*x+d*y]
        assert math.hypot(*direction)>0
        shapes=[(f'icon{j}',s['logical']) for j,s in enumerate(row['icons'])]+[('reserve',row['reserve_logical']),('plate',row['plate_logical'])]
        for name,rect in shapes:
            if hit(row['aim_start_logical'],direction,rect):
                failures.append({'row':i,'phase':row.get('phase',row.get('name')),'sample':row.get('sample'),'shape':name,'rect':rect,'muzzle':row['aim_start_logical'],'forward':direction})
    return failures

def aim_validate(root,report):
    common.capture_check(root)
    rows=report['frames'];before=report['phase_baselines'][0]
    assert len(report['phase_baselines'])==1 and before['phase']=='aim-transition'
    assert 212<=len(rows)<=240 and all(r['phase']=='aim-transition' and r['sample']==i for i,r in enumerate(rows))
    assert report['process_cap']==60==report['actual_engine_max_fps']
    textures=common.head_sources(root,report)
    for row in [before]+rows:
        common.visible(row);common.head_guard(row,textures);common.raw_image(root,row,report['format_ids'])
    movement=common.movement(rows,before)
    for a,b,move in zip([before]+rows,rows,movement):
        assert a['process']<b['process'] and a['usec']<b['usec']
        assert abs(move-b['far_displacement_logical'])<.001
        assert abs(math.dist(a['plate_logical'][:2],b['plate_logical'][:2])-b['plate_displacement_logical'])<.001
    events=[e for e in report['events'] if before['usec']<e['usec']<rows[-1]['usec']]
    up=next(e for e in events if e['action']=='aim_up' and e['pressed'])
    run=next(e for e in events if e['action']=='move_right' and e['pressed'])
    right=next(e for e in events if e['action']=='aim_right' and e['pressed'])
    assert before['usec']<up['usec']<rows[0]['usec']
    assert rows[59]['usec']<run['usec']<rows[60]['usec']
    assert rows[179]['usec']<right['usec']<rows[180]['usec']
    assert before['aim'][0]>.99 and all(r['aim'][1]<-.99 for r in rows[:180])
    assert all(r['aim'][0]>.99 for r in rows[180:])
    assert any(r['velocity'][0]>20 for r in rows[60:180])
    assert rows[-1]['on_floor'] and all(r['far_displacement_logical']<.25 and r['plate_displacement_logical']<.25 for r in rows[-3:])
    summary=report['phase_summaries'][0]
    assert summary['complete'] and summary['stable_draws']>=3 and summary['sampled']==len(rows)
    return {'draws':len(rows),'largest_logical':max(movement),'first_input':movement[0],'stable_tail':3}

def validate(root,role):
    report=json.loads((root/'result.json').read_text(encoding='utf-8'))
    if role=='aim':result=aim_validate(root,report)
    elif role=='mixed':result=mixed.validate(root)
    elif role=='shoot':result=shoot.validate(root)
    else:result=common.capture_check(root)
    failures=ray_failures(report)
    assert not failures,('actual forward ray intersects attached drawable conservative envelope',failures)
    result['aim_clearance']={'rows':len(report['static'])+len(report['phase_baselines'])+len(report['frames']),'conflicts':failures,'scope':'actual muzzle plus aim_dir through numeric canvas basis; whole attached primitive rectangle supersets. Zero intersection proves clearance; an intersection is conservatively rejected, not asserted to be an opaque pixel.'}
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('out',type=Path);p.add_argument('--role',choices=['matrix','aim','mixed','shoot'],required=True)
    args=p.parse_args();args.out.mkdir()
    for name in ['reader_native_v14.py','reader_route_v4.py','reader_mixed_v2.py','reader_shoot_v11.py']:
        (args.out/name).write_bytes(Path(__file__).with_name(name).read_bytes())
    receipt={'capture':str(args.root),'role':args.role,'capture_result_sha256':common.sha((args.root/'result.json').read_bytes()),'passed':False}
    try:
        receipt['result']=validate(args.root,args.role)
        report=json.loads((args.root/'result.json').read_text(encoding='utf-8'))
        preview=args.out/'derived-previews';preview.mkdir()
        for phase in sorted({r['phase'] for r in report['frames']}):
            rows=[r for r in report['frames'] if r['phase']==phase]
            peak=max(range(len(rows)),key=lambda i:rows[i]['far_displacement_logical'])
            indices={0,peak,len(rows)-1}
            if phase=='aim-transition':indices.update([1,59,60,179,180,181,209])
            if phase=='mixed':indices.update([2,4,6])
            for index in sorted(indices):
                image=common.raw_image(args.root,rows[index],report['format_ids'])
                rgba=common.np.concatenate([common.np.clip(common.srgb(image[:,:,:3]),0,1),common.np.clip(image[:,:,3:4],0,1)],axis=2)
                common.Image.fromarray(common.np.rint(rgba*255).astype(common.np.uint8)).save(preview/f'{phase}-{index:03d}-derived.png')
        receipt['passed']=True
    except Exception as exc:
        receipt['error']=repr(exc);receipt['traceback']=traceback.format_exc()
    (args.out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,indent=2));sys.exit(0 if receipt['passed'] else 1)
