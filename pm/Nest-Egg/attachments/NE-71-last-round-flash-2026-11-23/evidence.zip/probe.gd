extends Node

const WAREHOUSE := preload("res://data/levels/ch1_warehouse.tres")
const PISTOL := preload("res://data/weapons/pistol.tres")
const RAILGUN := preload("res://data/weapons/railgun.tres")
const Capture := preload("res://tools/viewport_capture.gd")

var _passes := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	run.call_deferred()


func run() -> void:
	Settings.use_storage("user://last-round-flash-native.cfg")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_prologue_exit", true, false)
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(WAREHOUSE)
	add_child(level)
	await _frames(24)
	var player := level.player
	player.loadout.reset(PISTOL)
	var rail_slot := player.loadout.equip(RAILGUN)
	player.loadout.set_ammo(rail_slot, 1, 0)
	AimInput.set_virtual_gamepad(player, true)
	AimInput.restore_direction(Vector2.RIGHT)
	await _frames(21)
	_check(player.loadout.active_weapon() == RAILGUN and player.aim_dir.is_equal_approx(Vector2.RIGHT),
			"actual warehouse player holds the last railgun round with a level right aim")
	var round: Projectile = ProjectilePool._free.back() if not ProjectilePool._free.is_empty() else null
	var loaded_muzzle := player.muzzle_position()
	Input.action_press(&"shoot")
	player._process_normal(0.0)
	Input.action_release(&"shoot")
	_check(round != null and round.active and round.spec == RAILGUN.projectile
			and player.loadout.active_weapon() == PISTOL and player.loadout.mag_in(rail_slot) == 0,
			"normal shoot input fires the last rail projectile and returns to the pistol")
	var origin := round.global_position if round != null else Vector2.INF
	_check(origin.distance_to(loaded_muzzle) < 1.0, "projectile leaves the equipped railgun barrel")
	AimInput.restore_direction(Vector2.LEFT)
	player._update_aim(0.0)
	player._visual.firing_muzzle()
	var current := player.muzzle_position()
	_check(origin.distance_to(current) > 25.0 and player.aim_dir.is_equal_approx(Vector2.LEFT),
			"the replacement pistol points back through the opposite side of the player")
	var has_stored_flash := player._visual.get("_fire_origin") is Vector2
	var flash: Vector2 = player._visual.get("_fire_origin") if has_stored_flash else current
	var direction: Vector2 = player._visual.get("_fire_direction") if has_stored_flash else player.aim_dir
	_check(player._visual._fire_flash > 0.0 and flash.is_equal_approx(origin), "the visible flash stays where the railgun fired")
	_check(direction.is_equal_approx(Vector2.RIGHT), "the visible flash keeps the original direction")
	if DisplayServer.get_name() != "headless":
		player._visual.queue_redraw()
		await RenderingServer.frame_post_draw
		print("SHOT SCREEN %s FLASH SCREEN %s PISTOL SCREEN %s" % [
			get_viewport().get_canvas_transform() * origin, get_viewport().get_canvas_transform() * flash,
			get_viewport().get_canvas_transform() * current])
		_check(Capture.image(get_viewport()).save_png(_out.path_join("flash.png")) == OK,
				"captured the actual Forward+ frame containing the last shot")
	level.queue_free()
	await _frames(6)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_passes + _fails, _fails])
	get_tree().quit(int(_fails != 0))


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	_passes += int(ok)
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)
