from pathlib import Path
from PIL import Image
from scipy.ndimage import distance_transform_edt
import numpy as np
import json
import sys

root=Path.cwd()
base=Path(__file__).resolve().parent
role,variant=sys.argv[1:3]
output=base/f"{role}-{variant}"
output.mkdir(exist_ok=True)
sys.path.insert(0,str(root/"tools/comfyui"))
from cut_layers import part_transform, render_part

profiles={
 "egret":{"torso":[(457.85,176.89,2.6),(463.59,176.54,2.65),(469.33,176.20,2.55),
                    (475.07,175.85,2.55),(452.46,182.98,2.5)],
          "arm_upper":[(439.90,349.43,2.8),(438.75,355.07,2.7),(437.60,360.70,2.6),(436.46,366.33,2.4)]},
 "ali":{"torso":[(434.1,194.0,1.55)]},
}
spec=json.loads((root/f"tools/comfyui/specs/{role}_side.json").read_bytes())
scale=spec["tex_px_per_wp"]/spec["illustration_px_per_wp"]
joints={name:np.asarray(point,float)*scale for name,point in spec["joints"].items()}
measure={}
for piece,coords in profiles[role].items():
    p=root/f"art_src/characters/{role}/overrides/refined/{piece}.png"
    if not p.is_file():
        p=root/f"art_src/characters/{role}/07_refined/{piece}.png"
    with Image.open(p) as image:
        src=np.asarray(image.convert("RGBA"))
    derived=src.copy()
    alpha=src[:,:,3]
    sy,sx=distance_transform_edt(alpha<128, return_distances=False, return_indices=True)
    for u,v,reach in coords:
        near_x,near_y=sx[round(v),round(u)],sy[round(v),round(u)]
        x0,x1=int(min(u,near_x)-reach-2),int(max(u,near_x)+reach+3)
        y0,y1=int(min(v,near_y)-reach-2),int(max(v,near_y)+reach+3)
        yy,xx=np.ogrid[y0:y1,x0:x1]
        dx,dy=u-near_x,v-near_y
        step=np.clip(((xx+.5-near_x)*dx+(yy+.5-near_y)*dy)/max(dx**2+dy**2,.01),0.,1.)
        distance=np.hypot(xx+.5-near_x-step*dx,yy+.5-near_y-step*dy)
        coverage=np.clip((reach-distance)*255.,0,255).astype(np.uint8)
        area=np.s_[y0:y1,x0:x1]
        local=derived[area]
        mask=(coverage>local[:,:,3]) & (alpha[area]<128)
        if role=="egret" and piece=="arm_upper":
            mask &= xx<=440
        local[mask,:3]=src[sy[area][mask],sx[area][mask],:3]
        local[mask,3]=coverage[mask]
    before,after=[Image.fromarray(arr) for arr in (src,derived)]
    rule=spec["parts"][piece]
    reference,revised=[part_transform(img,rule,joints,scale) for img in (before,after)]
    assert all(np.array_equal(left,right) for left,right in zip(reference,revised)), (role,piece,reference,revised)
    old,new=[render_part(img,reference,scale,crop_phase=rule.get("crop_phase")) for img in (before,after)]
    with Image.open(root/f"art/characters/{role}/parts/{piece}.png") as image:
        assert np.array_equal(np.asarray(image.convert("RGBA")),old),(role,piece)
    assert np.array_equal(derived[alpha>=128],src[alpha>=128])
    Image.fromarray(new).save(output/f"{piece}.png")
    after.save(output/f"source-{piece}.png")
    measure[piece]=[int(np.count_nonzero(np.any(old!=new,axis=2))),int(np.count_nonzero(np.any(src!=derived,axis=2)))]
(output/"build.json").write_text(json.dumps(measure,indent=2)+"\n")
print(role,measure)

