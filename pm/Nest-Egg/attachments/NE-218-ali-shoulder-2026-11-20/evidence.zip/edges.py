from collections import defaultdict
from pathlib import Path
from PIL import Image
from functools import lru_cache
import json
import numpy as np
import sys

base=Path(__file__).resolve().parent
stock=base.parent/"evidence-20261120-ne218-npc-neck/ali-stock/frames"
after=base/sys.argv[1]/"frames"
read=lambda p:json.loads((p/"report.json").read_bytes())
key=lambda row:(row["file"],tuple(row["rect"]))
before_rows=read(stock)["failures"]
after_rows=read(after)["failures"]
before_flags={key(row) for row in before_rows}
new_edge=[row for row in after_rows if key(row) not in before_flags and row["enclosed_pixels"]==0 and row["loose_pieces"]==0]
@lru_cache(maxsize=4)
def alpha(path):
    with Image.open(path) as image:
        return np.asarray(image.getchannel("A"))
rows=[]
for issue in sorted(new_edge, key=key):
    file=issue["file"]
    x,y,w,h=issue["rect"]
    old=alpha(stock/file)[y:y+h,x:x+w]
    new=alpha(after/file)[y:y+h,x:x+w]
    rows.append({"file":file,"pose":issue["pose"],"joint":issue["joint"],"frame":issue["frame"],
                 "zoom":issue["zoom"],"facing":issue["facing"],
                 "lost_stock_opaque":int(np.count_nonzero((old>=128)&(new<128))),
                 "additional_opaque":int(np.count_nonzero((old<128)&(new>=128)))})
summary={"before_count":len(before_rows),"after_count":len(after_rows),"new_edge_notch_flags":len(rows),
         "with_alpha_loss":sum(row["lost_stock_opaque"]>0 for row in rows),"rows":rows}
(base/(sys.argv[1]+"-edges.json")).write_text(json.dumps(summary,indent=2)+"\n")
print({k:v for k,v in summary.items() if k!="rows"})
