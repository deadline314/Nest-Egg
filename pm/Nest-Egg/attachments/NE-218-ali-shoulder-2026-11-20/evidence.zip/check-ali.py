from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw
import sys

base=Path(__file__).resolve().parent
prior=base.parent/"evidence-20261120-ne218-npc-neck"
root=Path.cwd()
sys.path.insert(0,str(root/"tools/comfyui"))
from cut_layers import part_transform, render_part

spec=json.loads((root/"tools/comfyui/specs/ali_side.json").read_bytes())
scale=spec["tex_px_per_wp"]/spec["illustration_px_per_wp"]
joints={name:np.asarray(point,float)*scale for name,point in spec["joints"].items()}
rule=spec["parts"]["torso"]
candidate=base/"ali-patch-b"
sources=(root/"art_src/characters/ali/overrides/refined/torso.png",candidate/"source-torso.png")
approved_for_comparison=base/"stock-source.png"
images=[Image.open(path).convert("RGBA") for path in (approved_for_comparison,sources[1])]
assert sources[0].read_bytes()==sources[1].read_bytes()
transforms=[part_transform(image,rule,joints,scale) for image in images]
assert all(np.array_equal(old,new) for old,new in zip(*transforms))
source_old,source_new=[np.asarray(x) for x in images]
assert np.array_equal(source_old[source_old[:,:,3]>=128],source_new[source_old[:,:,3]>=128])
metrics={"source_pixels":int(np.count_nonzero(np.any(source_old!=source_new,axis=2)))}
for name in ("torso","torso_n"):
    ref=base/f"preinstall/art/characters/ali/parts/{name}.png"
    old,new=[np.asarray(Image.open(path).convert("RGBA")) for path in (ref,candidate/f"{name}.png")]
    assert old.shape==new.shape
    if name=="torso":
        for image,transform,expected in zip(images,transforms,(old,new)):
            assert np.array_equal(render_part(image,transform,scale,crop_phase=rule.get("crop_phase")),expected)
        assert np.all(new[:,:,3]>=old[:,:,3])
    metrics[name]={"shape":list(old.shape),"changed":int(np.count_nonzero(np.any(old!=new,axis=2)))}
before,rejected,after=[json.loads((folder/"run.json").read_bytes()) for folder in (
    prior/"ali-stock",prior/"ali-preview-a",base/"ali-preview-b")]
assert before["enclosed"]==rejected["enclosed"]==8 and after["enclosed"]==0
assert before["samples"]==after["samples"]==16800 and before["loose"]==after["loose"]==0
edges=json.loads((base/"ali-preview-b-edges.json").read_bytes())
assert edges["with_alpha_loss"]==0
live=[json.loads((base/f"guest-{version}/guest.json").read_bytes()) for version in ("stock","preview-b")]
assert live[0]==live[1] and len(live[0]["rows"])==16 and live[0]["flags_unchanged"]
assert live[0]["rendering_method"]=="forward_plus" and live[0]["hdr_2d"] and "9070 XT" in live[0]["adapter"]
assert len([row for row in live[0]["rows"] if row["talking"]])==8
assert len([row for row in live[0]["rows"] if row["listening"]])==8
detail=Image.new("RGB",(696,362),(37,40,48))
d=ImageDraw.Draw(detail)
for i,folder in enumerate((prior/"ali-stock",base/"ali-preview-b")):
    x=12+i*342
    d.text((x,10),"Before" if i==0 else "After",fill=(233,236,240))
    with Image.open(folder/"frames/sit_talk_3.4_050.png") as frame:
        tile=frame.convert("RGBA").crop((948,31,996,79)).resize((336,336),Image.Resampling.NEAREST)
    checker=Image.new("RGBA",tile.size)
    grid=ImageDraw.Draw(checker)
    for row in range(0,336,28):
        for col in range(0,336,28):
            grid.rectangle((col,row,col+27,row+27),fill=((160,114,155,255) if (row+col)//28%2 else (232,174,212,255)))
    checker.alpha_composite(tile)
    detail.paste(checker.convert("RGB"),(x,25))
detail.save(base/"ali-shoulder-detail.png")
report={"materials":metrics,"audit":{"samples":after["samples"],"enclosed":[8,0],"loose":[0,0],
        "edge_only":[before["edge_notch_only"],after["edge_notch_only"]],"new_edge_flags":edges["new_edge_notch_flags"],
        "edge_flags_with_alpha_loss":edges["with_alpha_loss"]},"stage":live[1]}
(base/"ali-delivery.json").write_text(json.dumps(report,indent=2)+"\n")
print(metrics,report["audit"],len(live[1]["rows"]))
