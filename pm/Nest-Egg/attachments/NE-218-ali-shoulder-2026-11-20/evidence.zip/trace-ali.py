from pathlib import Path
import sys
import json
import numpy as np
from PIL import Image
from scipy import ndimage

base=Path(__file__).resolve().parent
root=Path.cwd()
sys.path.insert(0,str(root/"tools/comfyui"))
from cut_layers import part_transform

def decode(piece, xy):
    transform=np.asarray(piece["to_cell"])
    local=np.linalg.solve(transform[:,:2],xy-transform[:,2])
    if "rect_origin" in piece:
        return local-piece["rect_origin"]
    vertices=np.asarray(piece["vertices"])
    uv=np.asarray(piece["uv"])
    for t in piece["triangles"]:
        target=vertices[t]
        w=np.linalg.solve((target[1:]-target[0]).T,local-target[0])
        if min(w)>=-1e-5 and w.sum()<=1.00001:
            return (1-w.sum())*uv[t[0]]+w@uv[t[1:]]
    return None

spec=json.loads((root/"tools/comfyui/specs/ali_side.json").read_bytes())
scale=spec["tex_px_per_wp"]/spec["illustration_px_per_wp"]
joints={name:np.asarray(point,float)*scale for name,point in spec["joints"].items()}
for label,frame,index in (("ali-trace",50,7),("ali-rear-talk",37,8),("ali-rear-listen",24,8)):
    trace,=json.loads((base/f"{label}/frames/frames.json").read_bytes())
    cell=trace["cells"][0]
    radius=cell["radius"]
    fname=trace["samples"][frame]["file"]
    sides=[]
    for stage in ("stock","preview-a"):
        with Image.open(base/f"ali-{stage}/frames"/fname) as img:
            left=index*128+64-radius
            tile=np.asarray(img.getchannel("A"))[64-radius:64+radius,left:left+2*radius]
        solid=tile>=128
        holes=ndimage.binary_fill_holes(solid,structure=np.ones((3,3)))&~solid
        sides.append((tile,holes))
    focus=sides[0][1]|sides[1][1]
    for y,x in zip(*np.where(focus)):
        old,new=[int(layer[0][y,x]) for layer in sides]
        print(label, "alpha",old,new)
        for oy,ox in ((0,0),(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)):
            cy,cx=y+oy,x+ox
            position=np.array([cx,cy])+64-radius+0.5
            coords={}
            for mesh in cell["geometry_sample"]:
                uv=decode(mesh,position)
                if uv is None:
                    continue
                part=Path(mesh["texture"]).stem
                p=root/f"art_src/characters/ali/overrides/refined/{part}.png"
                if not p.is_file():
                    p=root/f"art_src/characters/ali/07_refined/{part}.png"
                if not p.is_file() or part not in spec["parts"]:
                    continue
                image=Image.open(p).convert("RGBA")
                matrix=part_transform(image,spec["parts"][part],joints,scale)[0]
                sample=(matrix[:,:2]@uv+matrix[:,2])/scale
                coords[mesh["node"] if "node" in mesh else part]=sample.round(2).tolist()
            print(f"  ({ox:+},{oy:+})",*[int(layer[0][cy,cx]) for layer in sides],coords)

