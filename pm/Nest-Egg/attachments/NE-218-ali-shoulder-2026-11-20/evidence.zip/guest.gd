extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const SCENES := [&"ch2_t_s18_name", &"ch2_t_s18_wrong"]
var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		printerr("Expected native rendering and an absolute output path")
		get_tree().quit(1)
		return
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://ali_guest_coverage.cfg")
	var flags := GameState.world_flags.duplicate(true)
	for id: StringName in SCENES:
		if not await _observe(id):
			printerr("Cannot validate seated Ali in ", id)
			get_tree().quit(1)
			return
	if GameState.world_flags != flags:
		printerr("Direct stage playback wrote story flags")
		get_tree().quit(1)
		return
	var out := FileAccess.open(_out.path_join("guest.json"), FileAccess.WRITE)
	out.store_string(JSON.stringify({"adapter": RenderingServer.get_video_adapter_name(),
		"rendering_method": RenderingServer.get_current_rendering_method(), "hdr_2d": get_viewport().use_hdr_2d,
		"flags_unchanged": true, "rows": _rows}, "  ") + "\n")
	out.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit()


func _observe(id: StringName) -> bool:
	var scene: Dictionary = Story._scenes.get(id, {})
	if scene.get("mode") != "animated" or not CutsceneChecker.staging_problems(str(id), scene).is_empty():
		return false
	var player := CutscenePlayer.new()
	add_child(player)
	player.play(id, scene)
	var expect_talk := id == SCENES[0]
	var observed := 0
	for step in 240:
		await get_tree().process_frame
		var ali: CutsceneActor = player._actors.get(&"ali")
		if not is_instance_valid(ali) or ali.pose != &"sit" or ali.rig == null:
			continue
		if not ali._input.talking and not ali._listen_flag:
			continue
		var animator := ali.rig.animator as NpcAnimator
		if not animator._use_npc or animator._pose_now != &"sit":
			continue
		if ali._input.talking != expect_talk or ali._listen_flag == expect_talk:
			return false
		observed += 1
		if observed not in [12, 24, 37, 49, 50, 51, 52, 60]:
			continue
		await RenderingServer.frame_post_draw
		var key := "%s_%02d" % ["talk" if expect_talk else "listen", observed]
		var shoulder := ali.get_viewport().get_canvas_transform() * ali.rig.bone(&"arm_front_upper").global_position
		if not shoulder.is_finite() or not ali.is_visible_in_tree() or not ali.rig.is_visible_in_tree():
			return false
		if Capture.image(get_viewport()).save_png(_out.path_join(key + ".png")) != OK:
			return false
		_rows.append({"key":key, "scene":str(id), "steps_sha256":JSON.stringify(scene["steps"]).sha256_text(),
			"frame":observed, "pose":str(ali.pose), "talking":ali._input.talking, "listening":ali._listen_flag, "facing":ali.facing,
			"stage_position":[ali.position.x,ali.position.y], "front_joint":[shoulder.x,shoulder.y]})
		if observed == 60:
			break
	player.skip()
	while player.is_running():
		await get_tree().process_frame
	player.queue_free()
	await get_tree().process_frame
	return observed == 60
