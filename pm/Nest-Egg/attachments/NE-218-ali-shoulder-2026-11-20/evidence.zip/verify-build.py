from pathlib import Path
from runpy import run_path
import sys
root=Path.cwd()
runner=root/"art_src/characters/ali/shoulder_overlap/rebuild.py"
out=run_path(str(runner))["build"](runner.parents[1])
assert out==Path(sys.argv[1]).read_bytes()
print("Ali approved raised sleeve and four seated source pixels rebuilt byte-identical")
