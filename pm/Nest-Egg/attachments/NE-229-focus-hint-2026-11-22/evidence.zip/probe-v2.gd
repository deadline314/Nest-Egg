extends "res://tests/smoke_test.gd"

var _out := ""


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://skip_modal_probe.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	super._ready()


func _run() -> void:
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(load("res://data/levels/ch1_prologue.tres") as LevelData)
	add_child(level)
	await _frames(30)
	var menu := level._pause_menu
	await _send_key(KEY_ESCAPE)
	await _frames(12)
	var hint := menu._root.get_node("FocusHintBar") as FocusHintBar
	var target := menu._map_button
	target.grab_focus()
	await _frames(12)
	_check(hint.text() == target.tooltip_text and hint.text().contains("快捷鍵"), "keyboard focus starts with the current shortcut hint")
	await _shot("keyboard")
	var motion := InputEventJoypadMotion.new()
	motion.axis = JOY_AXIS_RIGHT_X
	motion.axis_value = 0.8
	get_viewport().push_input(motion, true)
	await _frames(8)
	print("FOCUS_SWITCH controller=", InputBindings.using_gamepad, " focused=", target.has_focus(),
		" tooltip=", target.tooltip_text, " shown=", hint.text())
	_check(target.has_focus() and InputBindings.using_gamepad, "the controller changes without moving focus")
	_check(hint.text() == target.tooltip_text and not hint.text().contains("快捷鍵"), "visible hint updates after switching to the controller")
	await _shot("controller")
	await _send_key(KEY_F24)
	await _frames(8)
	print("FOCUS_SWITCH controller=", InputBindings.using_gamepad, " focused=", target.has_focus(),
		" tooltip=", target.tooltip_text, " shown=", hint.text())
	_check(target.has_focus() and not InputBindings.using_gamepad and hint.text() == target.tooltip_text,
		"keyboard restores the hint for the same focused control")
	var previous := InputBindings.get_code(&"map", 0)
	InputBindings.set_code(&"map", 0, KEY_F23)
	await _frames(8)
	print("FOCUS_REBIND focused=", target.has_focus(), " tooltip=", target.tooltip_text, " shown=", hint.text())
	_check(target.has_focus() and hint.text() == target.tooltip_text and hint.text().contains(InputBindings.primary_label(&"map")),
		"rebinding refreshes the visible hint without moving focus")
	await _shot("rebound")
	InputBindings.set_code(&"map", 0, previous)
	await _frames(8)
	var mouse := InputEventMouseMotion.new()
	mouse.relative = Vector2(36.0, 0.0)
	mouse.position = Vector2(20.0, 20.0)
	get_viewport().push_input(mouse, true)
	await _frames(6)
	InputBindings.bindings_changed.emit()
	await _frames(6)
	_check(hint.text().is_empty(), "refreshing bindings does not reveal the hint hidden by mouse motion")
	menu.close()
	await _frames(2)
	level.queue_free()
	await _frames(2)
	await _finish()

func _send_key(code: Key) -> void:
	var press := InputEventKey.new()
	press.keycode = code
	press.physical_keycode = code
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _send_button(button: JoyButton) -> void:
	var press := InputEventJoypadButton.new()
	press.button_index = button
	press.pressure = 1.0
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	release.pressure = 0.0
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _shot(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join(name + ".png")) == OK, "saved " + name)