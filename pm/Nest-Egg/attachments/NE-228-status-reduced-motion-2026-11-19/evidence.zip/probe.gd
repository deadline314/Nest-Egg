extends ScenarioBase

var _checks: Dictionary = {}


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	await open_arena("res://data/lighting/warehouse_interior.tres")
	player.health.setup(player._max_health, player.tuning.hurt_invulnerability)
	GameState.kills = 7
	var inventory := level._inventory
	var index := inventory.page_index(StatusPage)
	var status := inventory._pages[index] as StatusPage
	var portrait := status._portrait
	var chest := portrait._rig.bone(&"chest")
	var value := status._values[&"kills"]
	inventory.open()
	inventory.select_tab(index)
	_check(inventory.is_open() and get_tree().paused, "normal inventory entry opens the status page")
	_check(value.text.begins_with("7"), "the final count is visible immediately")
	await settle(5)
	await RenderingServer.frame_post_draw
	var pose := chest.transform
	var still := _picture(portrait._viewport)
	_check(still.get_used_rect().has_area(), "the first portrait frame is drawn")
	capture("reduced-first")
	await settle(36)
	await RenderingServer.frame_post_draw
	var held := _picture(portrait._viewport)
	_check(held.get_data() == still.get_data() and chest.transform == pose, "reduced motion keeps the portrait pixels and pose static")
	_check(portrait._viewport.render_target_update_mode != SubViewport.UPDATE_WHEN_VISIBLE,
		"a static pose stops continuous viewport updates")
	capture("reduced-held")
	portrait.size += Vector2(24.0, 18.0)
	await settle(4)
	await RenderingServer.frame_post_draw
	var resized := _picture(portrait._viewport)
	_check(resized.get_size() != held.get_size() and resized.get_used_rect().has_area() and chest.transform == pose,
		"a static portrait redraws at the resized resolution")
	capture("reduced-resized")
	Settings.set_reduce_ui_motion(false)
	await settle(36)
	await RenderingServer.frame_post_draw
	_check(_picture(portrait._viewport).get_data() != resized.get_data() and chest.transform != pose and
		portrait._viewport.render_target_update_mode == SubViewport.UPDATE_WHEN_VISIBLE, "normal motion resumes the live portrait")
	capture("normal-motion")
	Settings.set_reduce_ui_motion(true)
	inventory.close()
	_check(not get_tree().paused, "closing the status page resumes play")
	await settle(3)
	inventory.open()
	inventory.select_tab(index)
	await settle(5)
	await RenderingServer.frame_post_draw
	_check(_picture(portrait._viewport).get_used_rect().has_area() and value.text.begins_with("7"),
		"the reopened status page retains a visible portrait and current count")
	capture("reopened")
	inventory.close()
	var size := get_window().size
	var report := {"checks": _checks, "failures": failures, "adapter": RenderingServer.get_video_adapter_name(),
		"size": [size.x, size.y], "scale": Settings.get_ui_text_scale()}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)


func _picture(viewport: SubViewport) -> Image:
	return viewport.get_texture().get_image()


func _check(condition: bool, label: String) -> void:
	_checks[label] = condition
	if not condition:
		failures += 1
		print("NE228 motion probe: ", label)
