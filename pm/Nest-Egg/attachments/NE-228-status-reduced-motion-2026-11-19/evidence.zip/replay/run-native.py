from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = root / 'work/ne228-reduced-motion-20261119'
variant = sys.argv[1]
assert variant in ('before', 'after', 'preflight')
paths = ('ui/inventory/count_up_label.gd', 'ui/inventory/hd_portrait.gd')
if variant == 'preflight':
    shared = Path('D:/NestEggVerification/evidence-20261117/st15-runtime-locale-20261119/runtime')
backup = {name: (shared / name).read_bytes() for name in paths}
for name, contents in backup.items():
    assert contents == (base / ('before' if variant == 'preflight' else variant) / name).read_bytes()
out = base / f'native-{variant}-real-health'
out.mkdir()
probe = base / 'probe.gd'
scene = base / 'probe.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n'
                 '[node name="ReducedMotion" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')
env = os.environ.copy()
for name in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[name] = str(out / 'profile' / name)
command = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '1600',
           scene.as_posix(), '--', '--out=' + str(out)]
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
try:
    if variant == 'preflight':
        for name in paths:
            (shared / name).write_bytes((base / 'after' / name).read_bytes())
    with (out / 'raw.log').open('wb') as log:
        result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=160)
finally:
    if variant == 'preflight':
        for name, contents in backup.items():
            (shared / name).write_bytes(contents)
raw = (out / 'raw.log').read_text(encoding='utf-8')
print(raw[-2500:], flush=True)
report = json.loads((out / 'report.json').read_text(encoding='utf-8'))
print(json.dumps(report, ensure_ascii=False), flush=True)
assert '9070 XT' in report['adapter'] and report['size'] == [1280, 720] and report['scale'] == 1.2
assert 'SCRIPT ERROR' not in raw and 'ERROR:' not in raw
if variant == 'before':
    assert result.returncode == 1 and report['failures'] >= 3
    assert not report['checks']['the final count is visible immediately']
    assert not report['checks']['reduced motion keeps the portrait pixels and pose static']
    assert not report['checks']['a static pose stops continuous viewport updates']
else:
    assert result.returncode == 0 and report['failures'] == 0
