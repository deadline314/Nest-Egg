extends ScenarioBase

const PROFILES := ["transfer", "blackout", "market"]
const LEVELS := "res://data/levels"
const CHAPTERS := [&"ch1_kasa", &"ch2_heron"]
const MIN_CONTRAST := ContrastProbe.MIN_ENEMY_CONTRAST
const MARK := Vector2(400.0, FLOOR_Y - 0.08)
var roster: Dictionary = {}
var results: Dictionary = {}
var quality := "high"
var light_on := false

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
		elif arg.begins_with("--quality="):
			quality = arg.trim_prefix("--quality=")
		elif arg == "--player-light":
			light_on = true
	if not out_dir.is_absolute_path() or DirAccess.make_dir_recursive_absolute(out_dir) != OK:
		get_tree().quit(2)
		return
	_run.call_deferred()

func _run() -> void:
	Settings.use_storage("user://roster_light_audit.cfg")
	Settings.set_light_quality(LightQuality.Tier.LOW if quality == "low" else LightQuality.Tier.HIGH)
	Settings.set_brightness(0.5)
	Story.auto_skip = true
	Story._layer.visible = false
	add_child(LightKit.create_environment())
	for file in DirAccess.get_files_at(LEVELS):
		if not file.ends_with(".tres") or not file.begins_with("ch1_") and not file.begins_with("ch2_"):
			continue
		var level_data := load(LEVELS.path_join(file)) as LevelData
		if level_data == null or not level_data.chapter in CHAPTERS:
			continue
		var layout := LevelBuilder.parse(level_data)
		for item in layout.spawns:
			_include(item["resource"])
		if not layout.boss_spawn.is_empty():
			_include(layout.boss_spawn["resource"])
	if roster.is_empty():
		push_error("No roles found in the first two chapters")
		get_tree().quit(2)
		return
	for profile in PROFILES:
		await _sample_profile(profile)
	var evidence := {"adapter": RenderingServer.get_video_adapter_name(),
		"engine": Engine.get_version_info().string, "hdr_2d": get_viewport().use_hdr_2d,
		"quality": quality, "player_light": light_on, "profiles": results, "roles": roster.keys(), "capture_errors": failures}
	var output := FileAccess.open(out_dir.path_join("lighting.json"), FileAccess.WRITE)
	if output == null:
		get_tree().quit(2)
		return
	output.store_string(JSON.stringify(evidence, "  ") + "\n")
	output.close()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)

func _include(resource: Resource) -> void:
	if resource is EnemyData:
		var id: String = resource.rig_skin if not resource.rig_skin.is_empty() else String(resource.id)
		roster["enemy-" + id] = resource
	elif resource is NpcData and resource.kind == NpcData.Kind.PERSON and not resource.rig_id.is_empty():
		roster["npc-" + resource.rig_id] = resource

func _sample_profile(profile: String) -> void:
	await open_arena("res://data/lighting/%s.tres" % profile, 20.5 if light_on else 8.0)
	AimInput.set_virtual_gamepad(player,true)
	AimInput.restore_direction(Vector2.RIGHT)
	var camera := level.camera
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * 2.8
	camera.offset = Vector2.ZERO
	camera.global_position = MARK - Vector2(0.0, 28.0)
	camera.reset_smoothing()
	camera.force_update_scroll()
	level._lighting._lightning_gap = 1.0e9
	if not light_on:
		player.set_physics_process(false)
		player.hide()
		player._light.hide()
	var visible_profile := level._lighting.zone_id_at(MARK.x)
	if visible_profile != StringName(profile):
		push_error("Lighting profile mismatch at the audit mark: %s %s" % [visible_profile, profile])
		failures += 1
	var records: Dictionary = {}
	for id in roster:
		var source: Resource = roster[id]
		var actor: Node2D
		if source is EnemyData:
			actor = level._create_enemy(source)
		else:
			var data := source.duplicate() as NpcData
			data.spawn_requires_flag = &""
			data.spawn_unless_flag = &""
			var npc := NpcActor.new()
			npc.configure(data, Vector2i(25, 19))
			actor = npc
		actor.position = MARK
		level._entities.add_child(actor)
		for step in 5:
			await get_tree().physics_frame
		if not is_instance_valid(actor) or not actor.is_visible_in_tree():
			push_error("Missing visible actor: " + id)
			failures += 1
			continue
		actor.process_mode = Node.PROCESS_MODE_DISABLED
		var rig: CharacterRig = actor.rig if actor is Enemy else actor._actor.rig
		if rig != null:
			var fill := LightKit.enemy_fill if actor is Enemy else LightKit.character_fill
			var cap := LightKit.enemy_light_cap if actor is Enemy else LightKit.character_light_cap
			rig._apply_fill(fill)
			rig._apply_light_cap(cap)
		var pos := actor.global_position
		var bounds := rig.visual_bounds() if rig != null else Rect2(pos - Vector2(15,40),Vector2(30,40))
		await RenderingServer.frame_post_draw
		var probe := ContrastProbe.capture(get_viewport())
		var old_box := probe.character_contrast(pos, actor is NpcActor)
		var rendered_box := probe.contrast(bounds, ContrastProbe.RING)
		capture("%s-%s" % [profile,id])
		records[id] = {"source": source.resource_path, "actual_profile": String(visible_profile),
			"rig": rig.skin_id if rig != null else "", "feet": [pos.x,pos.y],
			"screen_box": str(probe._screen_rect(bounds)),
			"bounds_contrast": rendered_box, "old_box_contrast": old_box,
			"below_enemy_gate": actor is Enemy and old_box < MIN_CONTRAST}
		actor.queue_free()
		await settle(3)
	results[profile] = records
	await finish()




