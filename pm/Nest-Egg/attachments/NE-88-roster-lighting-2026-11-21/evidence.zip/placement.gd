extends Node

const CHAPTERS := [&"ch1_kasa", &"ch2_heron"]
const DIRECTORY := "res://data/levels"


func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() != 1 or not args[0].is_absolute_path():
		push_error("Pass the absolute destination for the chapter placement index.")
		get_tree().quit(2)
		return
	var levels := {}
	for file in DirAccess.get_files_at(DIRECTORY):
		if not file.ends_with(".tres") or not (file.begins_with("ch1_") or file.begins_with("ch2_")):
			continue
		var data := load(DIRECTORY.path_join(file)) as LevelData
		if data == null:
			push_error("Invalid level: " + file)
			get_tree().quit(2)
			return
		if data.chapter not in CHAPTERS:
			continue
		var layout := LevelBuilder.parse(data)
		var actors: Array[Dictionary] = []
		var reinforcements: Array[Dictionary] = []
		var power_switches: Array[Dictionary] = []
		for item in layout.spawns:
			var cell: Vector2i = item.cell
			var source: Resource = item.resource
			if source is EnemyData or source is NpcData and source.kind == NpcData.Kind.PERSON:
				actors.append(_actor(source, cell))
			elif source is MechanismData and source.kind == MechanismData.Kind.ENCOUNTER:
				for enemy in source.reinforcements:
					if enemy != null:
						reinforcements.append({"encounter_cell": [cell.x, cell.y], "encounter": String(source.id),
							"enemy": String(enemy.id), "rig": enemy.rig_skin, "source": enemy.resource_path})
			elif source is MechanismData and source.kind == MechanismData.Kind.POWER_SWITCH:
				var profile := "blackout" if source.blackout_profile == null else String(source.blackout_profile.id)
				power_switches.append({"cell": [cell.x, cell.y], "id": String(source.id),
					"profile": profile, "x_interval": [cell.x - source.power_range_tiles.x, cell.x + source.power_range_tiles.y]})
		var boss := {} if layout.boss_spawn.is_empty() else _actor(layout.boss_spawn.resource, layout.boss_spawn.cell)
		var zones: Array[Dictionary] = []
		for zone in data.lighting_zones:
			if zone != null and zone.profile != null:
				zones.append({"first_column": zone.start_tile, "profile": String(zone.profile.id)})
		levels[String(data.id)] = {"map": data.layout_path, "size": [layout.width, layout.height],
			"actors": actors, "boss": boss, "zones": zones,
			"boss_profile": String(data.boss_lighting.id) if data.boss_lighting != null else "",
			"reinforcements": reinforcements, "power_switches": power_switches, "warnings": Array(layout.warnings)}
	if levels.is_empty():
		push_error("No chapter layouts were indexed.")
		get_tree().quit(2)
		return
	var output := FileAccess.open(args[0], FileAccess.WRITE)
	if output == null:
		push_error("Could not write index: " + args[0])
		get_tree().quit(2)
		return
	output.store_string(JSON.stringify(levels, "  ") + "\n")
	output.close()
	get_tree().quit()


func _actor(source: Resource, cell: Vector2i) -> Dictionary:
	var result := {"id": String(source.id), "source": source.resource_path, "cell": [cell.x, cell.y]}
	if source is EnemyData:
		result.merge({"type": "enemy", "rig": source.rig_skin})
	else:
		result.merge({"type": "npc", "rig": source.rig_id,
			"requires": String(source.spawn_requires_flag), "unless": String(source.spawn_unless_flag)})
	return result
