from pathlib import Path
import hashlib,json,os,subprocess,sys

root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-transitions-20261118')
project=base/'runtime'
old=base/'v20-rear-shoulder/native-screen'
variant=root/'work/ne267-chen-neck-source-boundary-20261119'/sys.argv[1]
out=variant/'formal-native'
out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
parts=[row['part'] for row in read(variant/'source.json')]
source=[f'art/characters/guest_chen/parts/{part}.png' for part in parts]
static=[p.relative_to(root).as_posix() for p in (root/'art/characters/guest_chen').rglob('*') if p.is_file()]
static.extend(('art/rigs/guest_chen.json','art/motion/guest_chen.json','tools/rig_joint_audit.gd'))
backup={name:(project/name).read_bytes() for name in static}
root_before={name:sha(root/name) for name in static}
prefix=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project)]
selection=[('arms','lean'),('body','hammer'),('arms','hammer'),('body','transitions'),('arms','transitions'),
           ('body','lean'),('arms','seated-performance'),('body','seated-performance'),('arms','crouch'),('body','crouch')]

def run(target,cmd,args=[]):
    target.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(target/'profile'/key)
    (target/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with (target/'raw.log').open('wb') as log:
        proc=subprocess.run(cmd+args,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=220)
    raw=(target/'raw.log').read_text(encoding='utf-8')
    assert proc.returncode==0 and 'ERROR:' not in raw,raw[-2000:]

def failures(folder):
    report=read(folder/'report.json')
    return {(r['joint'],r['pose'],r['facing'],r['zoom'],r['frame']):r for r in report['failures']}

def frames(folder):
    return {(g['pose'],g['zoom'],c['joint'],c['facing'],s['frame']) for g in read(folder/'frames.json') for c in g['cells'] for s in g['samples']}

if len(sys.argv)>2:
    selection=[key for key in selection if '-'.join(key) in sys.argv[2:]]
    assert selection
receipts=[]
try:
    for name in static:
        (project/name).write_bytes((root/name).read_bytes())
    for name in source:
        (project/name).write_bytes((variant/Path(name).name).read_bytes())
    meta='art/characters/guest_chen/character.json'
    (project/meta).write_bytes((variant/'character.json').read_bytes())
    run(out/'normals',prefix+['--headless','res://tools/art/paint_normals.tscn','--','--only=guest_chen'])
    allowed={meta}|set(source+[name.removesuffix('.png')+'_n.png' for name in source])
    assert {name for name in static if sha(project/name)!=root_before[name]}==allowed
    for name in allowed:
        if name.endswith('_n.png'):
            (variant/Path(name).name).write_bytes((project/name).read_bytes())
    guard={name:sha(project/name) for name in static}
    run(out/'import',prefix+['--headless','--editor','--quit'])
    for scope,case in selection:
        initial=old/(scope+'-'+case)
        dest=out/(scope+'-'+case)
        cmd=read(initial/'command.json')
        cmd[-1]='--out='+str(dest)
        run(dest,cmd)
        checker=[sys.executable,'-B','-X','utf8',str(root/'tools/check_joint_frames.py'),str(dest)]
        with (dest/'checker.log').open('wb') as log:
            proc=subprocess.run(checker,stdout=log,stderr=subprocess.STDOUT,timeout=160)
        before,after=failures(initial),failures(dest)
        assert frames(initial)==frames(dest) and proc.returncode==(1 if after else 0)
        assert all(sha(project/name)==digest for name,digest in guard.items())
        new=set(after)-set(before)
        row={'scope':scope,'case':case,'samples':len(frames(dest)),'before':len(before),'after':len(after),'new':len(new),
             'remaining_enclosed':sum(r['enclosed_pixels']>0 for r in after.values())}
        receipts.append(row)
        (out/'results.json').write_text(json.dumps(receipts,indent=2)+'\n')
        print(row,flush=True)
        if new:
            (dest/'new-failures.json').write_text(json.dumps([after[k] for k in sorted(new)],indent=2)+'\n')

finally:
    for name,data in backup.items():
        (project/name).write_bytes(data)


