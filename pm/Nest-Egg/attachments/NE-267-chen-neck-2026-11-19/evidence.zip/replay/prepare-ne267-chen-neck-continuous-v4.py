from pathlib import Path
import hashlib
import json
import sys

import numpy as np
from PIL import Image, ImageDraw

root=Path.cwd()
base=root/'work/ne267-chen-neck-source-boundary-20261119'
sys.path.insert(0,str(root/'tools/comfyui'))
from cut_layers import part_transform, render_part

work=root/'art_src/characters/guest_chen'
torso_path=root/'art_src/characters/guest_chen_torso_20261118/approved_torso.png'
source=Image.open(work/'base_rgba.png').convert('RGBA')
head=Image.open(work/'07_refined/head.png').convert('RGBA')
torso=Image.open(torso_path).convert('RGBA')
spec=json.loads((root/'tools/comfyui/specs/guest_chen_side.json').read_bytes())
k=spec['tex_px_per_wp']/spec['illustration_px_per_wp']
joints={key:np.asarray(point,float)*k for key,point in spec['joints'].items()}
head_base=np.asarray(head)
author=np.asarray(source)
poly=[(447,201),(463,190),(499,189),(542,194),(575,200),(573,220),(550,232),
      (538,244),(532,257),(514,258),(500,243),(486,230),(470,224),(451,215)]
matte=Image.new('L',source.size)
ImageDraw.Draw(matte).polygon(poly,fill=255)
ys=np.arange(source.height)[:,None]
fade=np.minimum(1.0,np.maximum(0.0,(257-ys)/6.0))
fill_alpha=np.rint(author[:,:,3] * np.minimum(np.asarray(matte)/255,fade)).astype(np.uint8)
mask=(head_base[:,:,3]<fill_alpha)&(head_base[:,:,3]<128)
new_head=head_base.copy()
new_head[mask]=author[mask]
new_head[:,:,3][mask]=fill_alpha[mask]
neck_rows=np.arange(218,247)
ramp=np.clip((neck_rows-218)/7,0,1)*np.clip((247-neck_rows)/11,0,1)
shift=np.rint(16*ramp).astype(int)
shift_map=[]
for y,offset in zip(neck_rows,shift):
    if offset==0:
        continue
    x=np.arange(526,575)
    sample=x-offset
    covered=(fill_alpha[y,sample]>new_head[y,x,3])&(head_base[y,x,3]<128)
    new_head[y,x[covered]]=author[y,sample[covered]]
    new_head[y,x[covered],3]=fill_alpha[y,sample[covered]]
    shift_map.append([int(y),int(offset),int(covered.sum())])

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def build(name,clipped):
    out=base/name
    out.mkdir()
    sources=[('head',head,Image.fromarray(new_head),{'source_changed_pixels':int(np.any(new_head!=head_base,axis=2).sum()),'author_neck_polygon':poly,'registered_neck_underlap_rows':shift_map})]
    if clipped:
        shirt=np.asarray(torso).copy()
        xs=np.arange(source.width)[None,:]
        outside=(xs>=534)&(ys>=189)&(ys<=246)&(author[:,:,3]<shirt[:,:,3])&(author[:,:,3]<128)
        shirt[:,:,3][outside]=author[:,:,3][outside]
        sources.append(('torso',torso,Image.fromarray(shirt),{'source_changed_pixels':int(outside.sum()),'keep_native_silhouette_in':[534,189,575,246]}))
    entry=root/'art/characters/guest_chen/character.json'
    character=json.loads(entry.read_bytes())
    records=[]
    for label,prior,art,detail in sources:
        t0=part_transform(prior,spec['parts'][label],joints,k)
        ref=render_part(prior,t0,k)
        old=Image.open(root/'art/characters/guest_chen/parts'/f'{label}.png').convert('RGBA')
        assert np.array_equal(ref,np.asarray(old)),label
        t1=part_transform(art,spec['parts'][label],joints,k)
        assert t0[1]==t1[1] and np.array_equal(t0[0],t1[0]) and np.array_equal(t0[3],t1[3])
        transform=(t0[0],t0[1],max(t0[2],t1[2]),t0[3])
        frame=render_part(art,transform,k)
        original_unchanged=ref[:,:,3]>=128
        if label=='head':
            frame[:t0[2]][original_unchanged]=ref[original_unchanged]
        Image.fromarray(frame).save(out/f'{label}.png')
        art.save(out/f'approved_{label}.png')
        character['textures'][label]['size']=list(frame.shape[1::-1])
        records.append({'part':label,'old_size':list(old.size),'new_size':list(frame.shape[1::-1]),
                        'pivot':character['textures'][label]['pivot'],**detail})
    (out/'character.json').write_text(json.dumps(character,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'source.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,records)
build('head-neck-continuous-v4',False)
