from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path.cwd()
evidence=Path('D:/NestEggVerification/evidence-20261117')
base=evidence/'ne267-transitions-20261118'
project=Path('D:/NestEggVerification/ne218-baseline-20261117')
variant=root/'work/ne267-chen-neck-source-boundary-20261119/head-neck-continuous-v4'
out=variant/'native-review-final'
out.mkdir()
previous=evidence/'ne267-source-delivery-20261118/s19-soup-v1/native'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
totals=read(variant/'formal-native/results.json')
assert len(totals)==10 and sum(x['samples'] for x in totals)==28800 and sum(x['after'] for x in totals)<166 and not any(x['new'] or x['remaining_enclosed'] for x in totals)
parts={f'art/characters/guest_chen/parts/{name}':variant/name for name in ('head.png','head_n.png')}
parts['art/characters/guest_chen/character.json']=variant/'character.json'
scene_source='data/story/ch2_heron.json'
static=['art/rigs/guest_chen.json','art/motion/guest_chen.json','art/rigs/npc_animations.json','data/cutscene/stages/ch2_guest_book_room.json',
        'game/cutscene/cutscene_player.gd','game/cutscene/cutscene_actor.gd','game/cutscene/stage_prop_hold.gd','game/rig/npc_animator.gd',
        'tools/rig_preview.gd','tools/rig_preview.tscn']
assert all(sha(project/name)==sha(root/name) for name in (*static,*parts))
observer=out/'observer.gd'
observer.write_bytes((previous/'observer.gd').read_bytes())
scene=observer.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{observer.as_posix()}" id="1"]\n[node name="GuestSoup" type="Node2D"]\nscript = ExtResource("1")\n',encoding='utf-8')
prefix=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project)]
settings=['--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--fixed-fps','60']
receipts={}

def run(target,label,args):
    target.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(target/'profile'/key)
    cmd=prefix+args
    (target/(label+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
    with (target/(label+'.log')).open('wb') as log:
        proc=subprocess.run(cmd,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=200)
    raw=(target/(label+'.log')).read_text(encoding='utf-8')
    assert proc.returncode==0 and 'ERROR:' not in raw and 'WARNING:' not in raw,(label,raw[-1400:])

for edition in ('after',):
    folder=out/edition
    guard={name:sha(project/name) for name in (*static,*parts,scene_source)}
    run(folder,'scene',settings+['--resolution','1280x720','--quit-after','10000',scene.as_posix(),'--','--out='+str(folder)])
    report=read(folder/'scenes.json')
    assert not report['failures'] and len(report['scenes'])==3
    for facing in ('left','right'):
        for light in ('bright','dark'):
            for page in (0,):
                target=folder/f'{facing}-{light}-{page}'
                options=['--chars=guest_chen','--npc','--zoom=3.7','--seat-sag=0.367','--settle-seconds=3',f'--npc-page={page}','--out='+str(target/'native.png')]
                if facing=='left': options.append('--left')
                if light=='bright': options.append('--bright')
                run(target,'preview',settings+['--resolution','640x360','res://tools/rig_preview.tscn','--',*options])
                assert (target/'native.png').is_file()
    assert all(sha(project/name)==digest for name,digest in guard.items())
    receipts[edition]={'source':guard,'captures':len(list(folder.glob('*.png'))),'contact_count':sum(len(scene['held_contacts']) for scene in report['scenes']),
                       'visual_cases':4,'scene_failures':report['failures']}
    print(edition,{k:v for k,v in receipts[edition].items() if k!='source'},flush=True)
(out/'compare.json').write_text(json.dumps(receipts,indent=2)+'\n')
