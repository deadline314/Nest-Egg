from pathlib import Path
import json

base = Path(__file__).resolve().parent
foot_keys = {"sole", "foot_angles", "foot", "knees", "front_boot_screen", "back_boot_screen"}
reports = {}
read = lambda path: json.loads(path.read_bytes())
prev = base.parent / "evidence-20261121-ne222-kneel-transition"
baseline = (base / "baseline.txt").read_text().strip()
prior_source = read(prev / "published-source.json")
current_source = read(base / "source.json")
early_head = (prev / "baseline.txt").read_text().strip()


def review(rows, mode):
    moving = [row for row in rows if row["action"] == mode and row["gait"]]
    worst = max(moving, key=lambda row: max(row["sole"]))
    return {"moving_frames": len(moving), "deepest_frame": worst["frame"], "deepest": max(worst["sole"]),
            "through_one": sum(max(row["sole"]) > 1.0 for row in moving)}


sources = {path.parent.name: path for path in (base / "stock").glob("*/motion.json")}
sources.update({path.parent.name: path for path in (base / "stock-before-trigger").glob("*/motion.json")})
for original in sorted(sources.values()):
    name = original.parent.name
    edited = base / "candidate" / name / "motion.json"
    before_command, after_command = (read(p.parent / "command.json") for p in (original, edited))
    assert before_command["source"] in (baseline, early_head) and after_command["source"] == baseline
    assert before_command["seed_sha256"] == after_command["seed_sha256"]
    assert before_command["argv"][-4:] == after_command["argv"][-4:]
    for command, source in ((before_command, prior_source), (after_command, current_source)):
        assert all(source[key] == digest for key, digest in command["worktree_sha256"].items())
    before, after = (read(p) for p in (original, edited))
    assert before["checks_failed"] == after["checks_failed"] == 0
    assert before["mode"] == after["mode"] and before["side"] == after["side"]
    before_rows, after_rows = before["rows"], after["rows"]
    assert len(before_rows) == len(after_rows) == 112
    suspended = 0
    for old, new in zip(before_rows, after_rows, strict=True):
        assert old.keys() == new.keys()
        assert all(old[key] == new[key] for key in old if key not in foot_keys), (name, old["action"], old["frame"])
        if not old["gait"] or not old["ground"] or max(old["sole"]) < 0.0:
            assert old == new, (name, old["action"], old["frame"])
        if old["gait"] and not any(old["stance"]) and max(old["sole"]) < 0.0:
            suspended += 1
    stock = review(before_rows, before["mode"])
    candidate = review(after_rows, after["mode"])
    assert stock["deepest"] > 1.7 and candidate["deepest"] < 0.65, (name, stock, candidate)
    if before["mode"] == "run":
        assert suspended > 0, name
    reports[name] = {"frames": len(after_rows), "unchanged_suspended_frames": suspended,
                     "stock_path": original.parent.relative_to(base).as_posix(),
                     "stock": stock, "candidate": candidate}
assert len(reports) == 8
(base / "results.json").write_text(json.dumps(reports, indent=2) + "\n", encoding="utf-8")
print(json.dumps(reports))
