from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import re
import subprocess

base = Path(__file__).resolve().parent
root = Path.cwd()
game = base.parent / "ne218-baseline-20261117"
source = "game/rig/humanoid_animator.gd"
earlier = json.loads((base.parent / "evidence-20261121-ne222-kneel-transition/published-source.json").read_bytes())
target = game / source
stock = target.read_bytes()
updated = (root / source).read_bytes()
assert sha256(stock).hexdigest() == earlier[source] and stock != updated
reports = base / "benchmark"
reports.mkdir()
log_data = []
try:
    for index, version in enumerate(("stock", "candidate", "candidate", "stock", "stock", "candidate")):
        folder = reports / f"{index + 1}-{version}"
        folder.mkdir()
        env = os.environ.copy()
        for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
            path = folder / key
            path.mkdir()
            env[key] = str(path)
        target.write_bytes(stock if version == "stock" else updated)
        command = ["C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--headless", "--path", str(game),
                   "res://tools/rig_perf_probe.tscn", "--", "--count=8", "--frames=1800", "--skin=rin"]
        with (folder / "engine.log").open("wb") as log:
            process = subprocess.run(command, cwd=game, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=150)
        text = (folder / "engine.log").read_text(encoding="utf-8")
        assert process.returncode == 0 and "SCRIPT ERROR" not in text and "ERROR:" not in text, text[-2000:]
        plain, rigged = re.search(r"剛體 ([\d.]+) µs/格，關節網格 ([\d.]+) µs/格", text).groups()
        log_data.append({"version": version, "rigid_us": float(plain), "mesh_us": float(rigged),
                         "source_sha256": sha256(target.read_bytes()).hexdigest()})
        print(log_data[-1], flush=True)
finally:
    target.write_bytes(stock)
    assert target.read_bytes() == stock
averages = {version: {key: median(row[key] for row in log_data if row["version"] == version)
                      for key in ("rigid_us", "mesh_us")} for version in ("stock", "candidate")}
result = {"frames_per_case": 1800, "rigs": 8, "samples": log_data, "medians": averages}
(reports / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(averages)
