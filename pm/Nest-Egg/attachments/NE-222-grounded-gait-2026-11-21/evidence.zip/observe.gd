extends "res://tools/ch1_flow_probe.gd"

var store_path := ""
var side := 1
var app: Node
var player: Player
var rig: CharacterRig
var rows: Array[Dictionary] = []
var lens := 0.0
var mode := ""
var anchor_x := 472.0
var shoe_outlines: Dictionary[int, PackedVector2Array] = {}
var sole_local := {}


func _run() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--slot="):
			store_path = arg.trim_prefix("--slot=")
		elif arg.begins_with("--side="):
			side = int(arg.trim_prefix("--side="))
		elif arg.begins_with("--lens="):
			lens = float(arg.trim_prefix("--lens="))
		elif arg.begins_with("--mode="):
			mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--anchor-x="):
			anchor_x = float(arg.trim_prefix("--anchor-x="))
	if not store_path.is_absolute_path() or side not in [-1, 1] or mode not in ["walk","run"]:
		get_tree().quit(2)
		return
	app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	app.set("_run_store", RunSaveStore.new(store_path))
	add_child(app)
	for frame in STEP_LIMIT:
		if app.get("_screen") is MainMenu and not bool(app.call("_route_pending")):
			break
		await get_tree().process_frame
	var menu := app.get("_screen") as MainMenu
	if menu == null:
		get_tree().quit(2)
		return
	await _settle(8)
	menu._continue_button.pressed.emit()
	for frame in STEP_LIMIT:
		var current := app.get("_screen") as Level
		if current != null and current.is_initialized() and current.data.id == &"ch1_street" and not bool(app.call("_route_pending")):
			_level = current
			break
		await get_tree().process_frame
	if _level == null or _level.player == null:
		get_tree().quit(2)
		return
	player = _level.player
	rig = player._visual.rig
	player.global_position = Vector2(anchor_x, player.global_position.y)
	player.velocity = Vector2.ZERO
	_level.camera.snap_to_target()
	var aim := &"aim_right" if side > 0 else &"aim_left"
	AimInput.set_virtual_gamepad(player, true)
	Input.action_release(&"aim_right")
	Input.action_release(&"aim_left")
	AimInput.restore_direction(Vector2(side,0))
	Input.action_press(aim)
	await _settle(36)
	_check(player.facing == side and player.is_on_floor(), "real safe street floor and requested facing")
	if lens > 0.0:
		_level.camera.set_physics_process(false)
		_level.camera.position_smoothing_enabled = false
		_level.camera.offset = Vector2.ZERO
	await _gait_sequence()
	Input.action_release(aim)
	AimInput.set_virtual_gamepad(player, false)
	var file := FileAccess.open(_out_dir.path_join("motion.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks_failed":_failures,"side":side,"mode":mode,"rows":rows, "sole_local":sole_local},"  ") + "\n")
	file.close()
	app.call("_quit", int(_failures > 0))


func _gait_sequence() -> void:
	await _record("rest", 0, true)
	var direction := &"move_right" if side > 0 else &"move_left"
	var strength := 0.46 if mode == "walk" else 1.0
	var first_x := player.global_position.x
	Input.action_press(direction, strength)
	for frame in range(1, 89):
		await _record(mode, frame, frame in [3, 6, 10, 14, 19, 27, 36, 50, 62, 76, 87])
	_check(player.facing == side and absf(absf(player.velocity.x) - strength * player.tuning.run_speed) < 3.0,
		"real horizontal movement settles at the requested input strength")
	_check((player.global_position.x - first_x) * side > 70.0, "real travel stays on the original street")
	Input.action_release(direction)
	for frame in range(1, 24):
		await _record("stop", frame, frame in [2, 5, 8, 12, 20])
	_check(absf(player.velocity.x) < 0.01 and player.is_on_floor(), "grounded stop settles without shifting the route")


func _record(label: String, frame: int, shot: bool) -> void:
	if lens > 0.0:
		_level.camera.zoom = Vector2.ONE * lens
		_level.camera.global_position = player.global_position + Vector2(0, -32)
		_level.camera.force_update_scroll()
	await RenderingServer.frame_post_draw
	var root := player.global_position
	var sole_front := _lowest_shoe(&"foot_front",root.y)
	var sole_back := _lowest_shoe(&"foot_back",root.y)
	var feet := {"front": _p(rig.bone(&"foot_front").global_position-root),
		"back": _p(rig.bone(&"foot_back").global_position-root)}
	var chest := rig.bone(&"chest")
	var hip := rig.bone(&"hip")
	var head := rig.bone(&"head")
	var canvas := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	rows.append({"action":label,"frame":frame,"root":_p(root),"velocity":_p(player.velocity),"facing":player.facing,"aim":_p(player.aim_dir),
		"state":player.state,"ground":player.is_on_floor(),"dash_time":player._dash_left,"physics":Engine.get_physics_frames(),
		"foot":feet,"sole":[sole_front,sole_back],
		"gait": rig.animator._gait_on, "weight": rig.animator._gait_w,
		"cycle": rig.animator._cycle, "duty": rig.animator._gait_duty,
		"stance": rig.animator._was_stance.duplicate(),
"chest":_p(chest.global_position-root),"hip":_p(hip.global_position-root),
		"head":_p(head.global_position-root),"muzzle":_p(player.muzzle_position()-root),"rounds":player.loadout.mag_in(player.loadout.active_slot),
		"knees":[rig.bone(&"leg_front_lower").rotation,rig.bone(&"leg_back_lower").rotation],"foot_angles":[rig.animator.foot_angle(&"foot_front"),rig.animator.foot_angle(&"foot_back")],"chest_rotation":chest.rotation,"hip_rotation":hip.rotation,
		"head_screen":_p(canvas*head.global_position),"root_screen":_p(canvas*root),
		"front_boot_screen":_p(canvas*rig.bone(&"foot_front").global_position),
		"back_boot_screen":_p(canvas*rig.bone(&"foot_back").global_position),
		"weapon":rig.weapon_root().visible,"zoom":_p(_level.camera.zoom),
		"camera":_p(_level.camera.global_position),"camera_center":_p(_level.camera.get_screen_center_position()),
		"camera_left":_level.camera.limit_left})
	if shot:
		_capture("%s-%03d" % [label,frame])
	await get_tree().process_frame


func _p(vector: Vector2) -> Array:
	return [vector.x, vector.y]


func _lowest_shoe(bone: StringName, floor_world: float) -> float:
	var shoe := rig.contact_part(bone)
	if not is_instance_valid(shoe):
		_check(false, "live boot sprite unavailable: " + str(bone))
		return INF
	var key := shoe.texture.get_instance_id()
	if not shoe_outlines.has(key):
		var image := shoe.texture.get_image()
		var boundary := PackedVector2Array()
		for x in image.get_width():
			var top := -1
			var bottom := -1
			for y in image.get_height():
				if image.get_pixel(x,y).a < 0.5:
					continue
				if top < 0:
					top = y
				bottom = y
			if top >= 0:
				boundary.append(Vector2(x+0.5,top+0.5))
				boundary.append(Vector2(x+0.5,bottom+0.5))
		shoe_outlines[key] = Geometry2D.convex_hull(boundary)
	if not sole_local.has(String(bone)):
		var contact: Array[Array] = []
		for point: Vector2 in shoe_outlines[key]:
			contact.append(_p(rig.bone(bone).to_local(shoe.to_global(CharacterRig.part_source_point(shoe,point)))))
		sole_local[String(bone)] = contact
	var low := -INF
	for source_point: Vector2 in shoe_outlines[key]:
		low = maxf(low, shoe.to_global(CharacterRig.part_source_point(shoe,source_point)).y-floor_world)
	return low
