extends "res://tests/smoke_test.gd"

const PAWNSHOP := preload("res://data/levels/ch1_pawnshop.tres")
const Capture := preload("res://tools/viewport_capture.gd")
const MOD_WEAPONS := {
	"mag_boost": "pistol", "quick_reload": "pistol", "steady_barrel": "rifle",
	"technique_blade": "melee/melee_blade", "technique_dagger": "melee/melee_dagger",
	"technique_glaive": "melee/melee_glaive", "technique_maul": "melee/melee_maul",
	"technique_whip": "melee/melee_whip",
}
var _authored: Dictionary = {}
var _picture := ""


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--copy="):
			_authored = JSON.parse_string(FileAccess.get_file_as_string(arg.trim_prefix("--copy=")))
		elif arg.begins_with("--image="):
			_picture = arg.trim_prefix("--image=")
	_check(_authored.has_all(["copy","short","labels"]), "three-language source examples are available")
	if _authored.is_empty():
		await _finish()
		return
	Settings.use_storage("user://mods_locale_proof.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	for language in ["zh","ja","en"]:
		await _case(language)
	await _finish()


func _case(language: String) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	Progression.restore({"credits": 0})
	for flag in [&"ch1_prologue_done",&"ch1_dinner_done",&"ch1_heard_brief"]:
		GameState.set_flag(flag)
	for scene in Story.scene_ids():
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.configure(PAWNSHOP)
	add_child(level)
	await _frames(12)
	var station: ShopStation
	for child in level.find_children("*","Area2D",true,false):
		if child is ShopStation:
			station = child
			break
	_check(station != null, language + " uses the formal pawnshop counter")
	if station == null:
		level.queue_free()
		await _frames(4)
		return
	level.player.global_position = station.global_position
	await _frames(12)
	await _tap(KEY_E)
	var screen := station._screen
	_check(screen != null and screen.is_open(), language + " opens the real counter")
	if screen == null or not screen.is_open():
		level.queue_free()
		await _frames(4)
		return
	var index := screen.page_index(UpgradesPage)
	screen.select_tab(index)
	var page := screen._pages[index] as UpgradesPage
	for file: String in _authored["copy"]:
		var mod_id := file.get_file()
		var res: Variant = load("res://data/%s.tres" % file)
		var is_arm := file.begins_with("arm_shield/")
		var expected: Array = _authored["copy"][file]
		var row_id: StringName
		if is_arm:
			row_id = StringName("arm_shield:%s" % mod_id)
		else:
			var weapon := load("res://data/weapons/%s.tres" % MOD_WEAPONS[mod_id]) as WeaponData
			level.player.loadout.reset(weapon)
			row_id = StringName("%s:%s" % [weapon.id,mod_id])
		page.refresh()
		var found := page._entries.find_custom(func(item: InventoryEntry) -> bool: return item.id == row_id)
		_check(found >= 0, "%s catalog offers %s" % [language,mod_id])
		if found < 0:
			continue
		var entry := page._entries[found]
		var shown_name: String = res.display_name if language == "zh" else expected[0 if language == "en" else 1]
		var shown_body: String = res.description if language == "zh" else expected[2 if language == "en" else 3]
		_check(entry.title.contains(shown_name), "%s shop shows the authored name for %s" % [language,mod_id])
		_check(entry.detail_body.contains(shown_body), "%s shows the full description for %s" % [language, mod_id])
		_check(entry.detail_stats.size() > 1 and entry.hint == entry.detail_stats[1],
			"%s mod hover gives the primary effect for %s" % [language, mod_id])
		if is_arm:
			var width := ItemCard.CARD_SIZE.x - ItemCard.ICON_CELL.x - 24.0
			_check(entry.title == shown_name and ItemCard.fit_text(UiKit.font(), entry.title, width, UiKit.scaled_size(12)) == entry.title,
				"%s shield part name fits the visible card for %s" % [language, mod_id])
		_check(not entry.action_enabled and entry.action_label.contains(str(res.cost)) and entry.action_hint.contains(str(res.cost)), "%s exact price and shortfall for %s" % [language,mod_id])
	for file: String in _authored["short"]:
		var weapon := load("res://data/weapons/%s.tres" % file) as WeaponData
		var expected: Array = _authored["short"][file]
		var name: String = weapon.call("short_name_for",language) if weapon.has_method("short_name_for") else weapon.short_name
		_check(name == (weapon.short_name if language == "zh" else expected[0 if language == "en" else 1]),
			"%s HUD label %s" % [language,weapon.id])
		_check(UiKit.font().get_string_size(name,HORIZONTAL_ALIGNMENT_LEFT,-1,UiKit.FS_BODY).x <= 70.0, "%s HUD label %s fits the row" % [language,weapon.id])
	var part := Progression.find_arm_shield_part(&"reaction_chip")
	var balance := Progression.credits
	Progression.add_credits(part.cost)
	page.refresh()
	var target := page._entries.find_custom(func(item: InventoryEntry) -> bool: return item.id == &"arm_shield:reaction_chip")
	for attempt in page._entries.size():
		if page._selected == target:
			break
		await _tap(KEY_DOWN)
	if language == "en" and _picture.is_absolute_path() and DisplayServer.get_name() != "headless":
		for i in 4:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_picture) == OK, "native arm shield mod screenshot")
	await _tap(KEY_ENTER)
	_check(Progression.has_arm_shield_part(part.id) and Progression.credits == balance,
		language + " buys one real chip at the original price")
	await _tap(KEY_ESCAPE)
	_check(not get_tree().paused, language + " closes the counter")
	level.queue_free()
	await _frames(5)


func _tap(code: int) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = true
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await get_tree().physics_frame
	await get_tree().process_frame
	event.pressed = false
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await get_tree().process_frame

