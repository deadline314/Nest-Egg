extends "res://tools/ch1_flow_probe.gd"

const WATCH := [&"head", &"hair_back_1", &"hair_back_2", &"armor_jacket", &"armor_torso", &"foot_front"]
const CAPTURE := preload("res://tools/viewport_capture.gd")
var _store := ""
var _main: Node
var _report := {}


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.id == &"ch1_street", "open a real street save through Main continue")
	if _level == null or _level.player == null:
		_finish_resolution()
		return
	var level_rig: CharacterRig = _level.player._visual.rig
	_check(level_rig != null and level_rig.skin_id == "rin", "the normal gameplay player is Rin")
	await RenderingServer.frame_post_draw
	_report["gameplay"] = _inspect(level_rig, get_viewport().get_final_transform())
	await _shot("gameplay")
	var inv: InventoryScreen = _level._inventory
	inv.open()
	await _settle(35)
	var index := inv.page_index(StatusPage)
	inv.select_tab(index)
	await _settle(65)
	var preview: HdPortrait = (inv._pages[index] as StatusPage)._portrait
	_check(preview != null and preview.is_visible_in_tree(), "the real status portrait is visible")
	await RenderingServer.frame_post_draw
	var parent_screen := get_viewport().get_final_transform() * preview.get_global_transform_with_canvas()
	var display := preview.size * parent_screen.get_scale().abs()
	var target := preview._viewport.size
	_check(target.x >= ceili(display.x - 0.001) and target.y >= ceili(display.y - 0.001), "portrait texture covers the actual displayed pixels")
	var sub_canvas := Transform2D(0.0, Vector2(display) / Vector2(target), 0.0, Vector2.ZERO)
	_report["inventory"] = _inspect(preview._rig, sub_canvas)
	_report["inventory"]["logical"] = _size(preview.size)
	_report["inventory"]["display"] = _size(display)
	_report["inventory"]["target"] = _size(Vector2(target))
	_report["inventory"]["rendered"] = _size(Vector2(preview._viewport.get_texture().get_image().get_size()))
	preview.set_process(false)
	await _shot("inventory")
	var legacy_target := Vector2i((preview.size * HdPortrait.RENDER_SCALE).ceil())
	if legacy_target != target:
		var holder_transform := preview._holder.transform
		preview._viewport.size = legacy_target
		preview._holder.scale = Vector2.ONE * float(legacy_target.y) * HdPortrait.FILL / HdPortrait.RIG_HEIGHT
		preview._holder.position = Vector2(float(legacy_target.x) * 0.5, float(legacy_target.y) * (1.0 + HdPortrait.FILL) * 0.5)
		await _settle(4)
		_report["inventory"]["legacy_control_target"] = _size(Vector2(preview._viewport.get_texture().get_image().get_size()))
		await _shot("inventory-legacy-target")
		preview._viewport.size = target
		preview._holder.transform = holder_transform
	preview.set_process(true)
	inv.close()
	await _settle(30)
	_finish_resolution()


func _inspect(rig: CharacterRig, outer: Transform2D) -> Dictionary:
	var textures := {}
	for part: CanvasItem in rig._parts:
		if part.name not in WATCH or not part.is_visible_in_tree():
			continue
		var texture := part.get("texture") as Texture2D
		if texture == null:
			continue
		var source := texture
		var normal := Vector2.ZERO
		if texture is CanvasTexture:
			source = texture.diffuse_texture
			if texture.normal_texture != null:
				normal = texture.normal_texture.get_size()
		var transform := outer * part.get_global_transform_with_canvas()
		textures[String(part.name)] = {"path": source.resource_path, "texture": _size(source.get_size()),
			"normal": _size(normal), "projected_texture": _size(transform.get_scale().abs() * source.get_size()),
			"screen_anchor": _size(transform.origin)}
	_check(textures.has("head") and textures.has("armor_jacket"), "head and jacket pixels are both sampled from real art")
	return {"parts": textures, "main_window": _size(Vector2(get_viewport().get_texture().get_image().get_size()))}


func _shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	_check(CAPTURE.image(get_viewport()).save_png(_out_dir.path_join(name + ".png")) == OK, "save native " + name)


func _size(value: Vector2) -> Array:
	return [value.x,value.y]


func _finish_resolution() -> void:
	var file := FileAccess.open(_out_dir.path_join("resolution.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures":_failures,"contexts":_report},"  ")+"\n")
	file.close()
	_main.call("_quit", 0 if _failures == 0 else 1)
