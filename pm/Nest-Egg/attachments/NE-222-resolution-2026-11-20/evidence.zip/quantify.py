from pathlib import Path
from hashlib import sha256
import json
from PIL import Image

root=Path.cwd()
p=Path(__file__).resolve().parent
read=lambda f:json.loads(f.read_bytes())
a=read(p/'native-1080/run.json')
b=read(p/'native-large/run.json')
a,b=(r['resolution']['contexts'] for r in (a,b))
stage=read(p/'stage-1080/result.json')
samples={str(row['tick']):row['art_dimensions'] for row in stage['rows'] if 'art_dimensions' in row}
assert list(samples)==['65','339']
spec=read(root/'tools/comfyui/specs/rin_side.json')
assert spec['illustration_px_per_wp']==spec['tex_px_per_wp']==28.86
config=read(root/'art/characters/rin/character.json')
assert abs(config['texture_scale']-1/spec['tex_px_per_wp'])<.00001
assert a['inventory']['target']==a['inventory']['rendered']==[576,768]
assert b['inventory']['target']==b['inventory']['rendered']==[755,1006]
for run in (a,b):
    assert run['inventory']['legacy_control_target']==[384,512]
    assert all(actual<=target for actual,target in zip(run['inventory']['display'],run['inventory']['target'],strict=True))
contexts={'gameplay1080':a['gameplay'],'gameplay_large':b['gameplay'],'inventory1080':a['inventory'],'inventory_large':b['inventory'],**samples}
keys=list(a['gameplay']['parts'])
records={}
for name in keys:
    observed=[item['parts'][name] for item in contexts.values()]
    runtime_file=root/observed[0]['path'].removeprefix('res://')
    norm_file=runtime_file.with_name(runtime_file.stem+'_n.png')
    source_file=root/'art_src/characters/rin_field/07_refined'/runtime_file.name
    raw=[{'path':f.relative_to(root).as_posix(),'size':list(Image.open(f).size),'sha256':sha256(f.read_bytes()).hexdigest()}
       for f in (source_file,runtime_file,norm_file)]
    assert raw[0]['size']==[1056,1536]
    assert all(row['texture']==row['normal']==raw[1]['size']==raw[2]['size'] for row in observed)
    assert all(row['path']==observed[0]['path'] for row in observed)
    assert all(all(screen<=source for screen,source in zip(row['projected_texture'],row['texture'])) for row in observed)
    records[name]=raw
out={'source_density':spec['illustration_px_per_wp'],'export_density':spec['tex_px_per_wp'],'data':records,'contexts':contexts}
(p/'art-resolution-report.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
for route,obs in contexts.items():
    print(route,obs['main_window'],{k:[round(n,1) for n in obs['parts'][k]['projected_texture']] for k in ('head','hair_back_1','armor_jacket')})
