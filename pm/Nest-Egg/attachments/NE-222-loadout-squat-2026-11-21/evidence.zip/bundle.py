from hashlib import sha256
from pathlib import Path
import json
import re
from shutil import copy2
from zipfile import ZIP_DEFLATED, ZipFile

root = Path.cwd()
base = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: sha256(path.read_bytes()).hexdigest()
runtime = read(base / "runtime.json")
source = read(base / "source.json")
cases = sorted(path.name for path in (base / "exact-kneel").iterdir() if path.is_dir())
assert len(cases) == 4
modes = ("exact-kneel", "candidate-final")
state_keys = ("action", "frame", "aim", "facing", "root", "velocity", "ground", "state", "rounds", "weapon", "slot", "crouching", "dash_time")
stats = {}
shots = {}
native_checks = 0
samples = 0
for case in cases:
    dirs = [base / mode / case for mode in modes]
    old, new = [read(path / "motion.json")["rows"] for path in dirs]
    assert len(old) == len(new) == 140
    for folder in dirs:
        log = (folder / "engine.log").read_text(encoding="utf-8")
        assert re.search(r"Using Device.*AMD Radeon RX 9070 XT", log) and "Forward+" in log
        assert "FAIL " not in log and "SCRIPT ERROR:" not in log and "ERROR:" not in log
        native_checks += len(re.findall(r"^PASS ", log, re.M))
        assert read(folder / "motion.json")["checks_failed"] == 0
    command = read(dirs[1] / "command.json")
    for key in runtime:
        assert command["worktree_sha256"][key] == source[key] == sha(root / key)
    for x, y in zip(old, new, strict=True):
        assert {key: x[key] for key in state_keys} == {key: y[key] for key in state_keys}, (case, x["action"], x["frame"])
    # The four firearm windows before changing to blade and both settled poses must be exact.
    pose_keys = ("back_hand", "front_hand", "muzzle", "hip", "head", "chest", "foot", "foot_angles",
                 "sole", "kneel_weight", "back_knee", "front_knee", "hand_grip", "rear_grip", "parts")
    for x, y in [*zip(old[:80], new[:80]), (old[119], new[119]), *zip(old[120:], new[120:])]:
        assert {key: x[key] for key in pose_keys} == {key: y[key] for key in pose_keys}, (case, x["action"], x["frame"])
    stock, blade = old[99], new[99]
    assert stock["action"] == blade["action"] == "blade_down" and stock["frame"] == blade["frame"] == 20
    assert stock["kneel_weight"] == 1.0 and stock["parts"] == "kneel"
    assert blade["kneel_weight"] == 0.0 and blade["parts"] == ""
    assert max(map(abs, blade["foot_angles"])) < 0.01
    assert abs(blade["sole"][0] - blade["sole"][1]) < 0.01
    assert stock["back_knee"][1] - blade["back_knee"][1] > 8.0
    for phase in new[80:120]:
        assert min(phase["sole"]) > -0.08 and max(phase["sole"]) < 0.57, (case, phase["sole"])
    stats[case] = {"stock_blade_rear_knee_y": stock["back_knee"][1],
                   "ordinary_squat_rear_knee_y": blade["back_knee"][1],
                   "ordinary_squat_front_and_back_sole": blade["sole"], "shoe_angles": blade["foot_angles"],
                   "during_both_loadout_changes_depth_range": [
                       min(min(row["sole"]) for row in new[80:120]), max(max(row["sole"]) for row in new[80:120])],
                   "exact_preserved_firearm_and_standing_frames": 101}
    shots[case] = {mode: [folder / name for name in (
        "blade_down-005.png", "blade_down-011.png", "blade_down-020.png", "back_to_pistol-005.png",
        "back_to_pistol-020.png", "stand-020.png")] for mode, folder in zip(modes, dirs)}
    samples += len(old)

audit = {"matched_frames": samples, "native_assertions": native_checks, "cases": stats,
         "comparison": "All sampled inputs, live weapon choices, round counts, and player positions are identical.",
         "regression": "Four settled and moving-in-place gun windows, the returned pistol kneel, and the release to stand retain their original rig measurements.",
         "bounds": "The two soles are assessed from the painted shoe geometry; positive depth means below the physical level surface."}
(base/"paired-results.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
print(json.dumps(audit, ensure_ascii=False), flush=True)
if __name__ == "__main__":
    import sys
    if "--native-only" in sys.argv:
        raise SystemExit(0)

    official = base/"official-release"
    assert read(official/"verification.json") == {"exit":0,"errors":[],"source_held":True}
    report = (official/"raw.log").read_text(encoding="utf-8")
    suite_count = int(re.search(r"Running (\d+) groups", report)[1])
    total, seconds = re.search(r"checks: (\d+), new failures: 0, known failures .*?0\s+\(wall time (\d+) s\)", report).groups()
    assert any("an unarmed squat keeps" in path.read_text(encoding="utf-8", errors="replace") for path in (official/"shards").glob("*.log")) or "ProtagonistMotionSuite" in report
    ticket = Path("pm/Nest-Egg/[NE-222]逐一檢查主角動作與部件並修正.md")
    attachment = Path("pm/Nest-Egg/attachments/NE-222-loadout-squat-2026-11-21/evidence.zip")
    images = Path("pm/Nest-Egg/images")
    chosen = (
        ("NE-222-loadout-blade-before-20261121.png", base / modes[0] / "kneel--1-3.4" / "blade_down-020.png"),
        ("NE-222-loadout-blade-after-20261121.png", base / modes[1] / "kneel--1-3.4" / "blade_down-020.png"),
        ("NE-222-loadout-squat-gameplay-20261121.png", base / modes[1] / "kneel-1-0.0" / "blade_down-020.png"),
        ("NE-222-loadout-return-pistol-20261121.png", base / modes[1] / "kneel-1-3.4" / "back_to_pistol-020.png"),
    )
    assert not (root/attachment).exists()
    original = (root/ticket).read_text(encoding="utf-8")
    assert "# Commit-78（" in original and "# Commit-79（" not in original
    (root/attachment).parent.mkdir(parents=True)
    with ZipFile(root/attachment,"x",compression=ZIP_DEFLATED,compresslevel=6) as archive:
        for name in ("observe.gd","observe.tscn","run.py","bundle.py","paired-results.json","source.json","baseline.txt"):
            archive.write(base/name,name)
        for case in cases:
            for mode in modes:
                folder = base/mode/case
                for path in [*(folder / name for name in ("command.json","engine.log","motion.json")), *shots[case][mode]]:
                    archive.write(path,path.relative_to(base).as_posix())
        for path in (official/"command.json",official/"raw.log",official/"verification.json",*(official/"shards").glob("*.log")):
            archive.write(path,path.relative_to(base).as_posix())
    with ZipFile(root/attachment) as archive:
        assert archive.testzip() is None
        print("Members and bytes",len(archive.namelist()),(root/attachment).stat().st_size)
    for name,png in chosen:
        assert not (root/images/name).exists() and png.read_bytes()[:8] == bytes.fromhex("89504e470d0a1a0a")
        copy2(png,root/images/name)

    section = """
---

# Commit-79（持刀與空手時使用雙腳支撐的蹲姿）

## 內文

凜蹲下時切換長刀，會從原本的單膝姿勢平順轉成雙腳放平的蹲姿，後膝離開地面；空手沿用相同姿勢。切回槍械時恢復原來的單膝跪瞄。動畫使用既有的腳掌輪廓與腿部求解，並在換姿勢時混合支撐權重。

### 測試結果

- RX 9070 XT Forward+ 從同一份港街存檔實際以快捷鍵切換 P-9、K-7、長刀與 P-9。兩面向、正常鏡頭及 3.4 倍，共 {samples} 格前後配對、{native_checks} 項原生檢查。兩次換武器期間，雙腳靴底距實際地面的範圍為 −0.05 至 0.50 世界單位；蹲定時兩靴底高度差小於 0.01，後膝提高約 9.35。原槍械四段瞄準、回持槍時的跪定姿勢和起身後的骨點一致；角色座標、輸入方向、彈量、物理狀態逐格一致。
- 自動測試涵蓋雙面向空手時的各腳掌角度與接地，以及重新拿槍後的跪姿。受影響 Godot 回歸 {suite_count} 組、{test_count} 項，0 新失敗、0 已知失敗、0 腳本錯誤，{seconds} 秒。

[原尺寸畫面、逐格骨點、足底支撐及測試](attachments/NE-222-loadout-squat-2026-11-21/evidence.zip)

![原版持長刀時仍跪地](images/NE-222-loadout-blade-before-20261121.png)

![修後同一格持長刀以雙腳支撐](images/NE-222-loadout-blade-after-20261121.png)

![正常遊戲鏡頭下的持刀蹲姿](images/NE-222-loadout-squat-gameplay-20261121.png)

![重新持槍後的單膝跪瞄](images/NE-222-loadout-return-pistol-20261121.png)
"""
    (root/ticket).write_text(original.rstrip() + "\n\n\n" + section.lstrip("\n").format(
        samples=samples,native_checks=native_checks,suite_count=suite_count,test_count=f"{int(total):,}",seconds=seconds),encoding="utf-8")
    paths = [*runtime,"design/12-cast-redraw/RIG_QUALITY.md",ticket.as_posix(),attachment.as_posix(),
             *((images/name).as_posix() for name,_ in chosen)]
    (base/"delivery.json").write_text(json.dumps(paths,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
