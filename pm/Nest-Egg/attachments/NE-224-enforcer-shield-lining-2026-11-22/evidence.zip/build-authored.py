from pathlib import Path
from PIL import Image
import json
import numpy as np
import sys

root=Path.cwd()
e=Path(__file__).resolve().parent
sys.path.insert(0,str(root/"tools/comfyui"))
from cut_layers import part_transform, render_part

character=root/"art/characters/enforcer/parts"
head_source=root/"art_src/characters/enforcer/overrides/refined/head.png"
shield_source=root/"art_src/characters/enforcer/carry/riot_shield.png"
spec=json.loads((root/"tools/comfyui/specs/enforcer_side.json").read_bytes())
part=spec["parts"]["head"]
scale=spec["tex_px_per_wp"]/spec["illustration_px_per_wp"]
joints={name:np.asarray(point)*scale for name,point in spec["joints"].items()}
prior=np.asarray(Image.open(head_source).convert("RGBA"))
old=np.asarray(Image.open(character/"head.png").convert("RGBA"))
fixed=part_transform(Image.fromarray(prior),part,joints,scale)
assert np.array_equal(render_part(Image.fromarray(prior),fixed,scale,crop_phase=part["crop_phase"]),old)
for shift in (14,16,18):
    edits=prior.copy()
    for y in range(52,87):
        reach=min(shift,2*(y-52),2*(86-y))
        if not reach:
            continue
        rgba=prior[y]
        last=int(np.flatnonzero(rgba[:,3]>=128)[-1])
        cols=np.arange(last+1,last+reach+4)
        underlay=rgba[cols-reach]
        keep=underlay[:,3]>rgba[cols,3]
        edits[y,cols[keep],:3]=np.minimum(underlay[keep,:3],[27,51,79])
        edits[y,cols[keep],3]=underlay[keep,3]
    image=Image.fromarray(edits)
    transform=part_transform(image,part,joints,scale)
    fresh=render_part(image,transform,scale,crop_phase=part["crop_phase"])
    assert np.array_equal(fixed[3],transform[3])
    assert fresh.shape[0]==old.shape[0] and fresh.shape[1]>=old.shape[1]
    overlap=fresh[:,:old.shape[1]]
    assert np.array_equal(overlap[old[:,:,3]>=235],old[old[:,:,3]>=235])
    print("helmet",shift,transform[1:3], int(np.any(edits!=prior,axis=2).sum()))
    image.save(e/f"authored-head-{shift}.png")
    Image.fromarray(fresh).save(e/f"cut-head-{shift}.png")

shield=np.asarray(Image.open(shield_source).convert("RGBA"))
shield_original=np.asarray(Image.open(character/"riot_shield.png").convert("RGBA"))
factor=5
assert np.array_equal(np.asarray(Image.fromarray(shield).resize((40*factor,88*factor),Image.Resampling.LANCZOS)),shield_original)
print("shield section",shield[10:22,8:13,3].tolist())
for opacity in (180,225,255):
    work=shield.copy()
    for y in range(11,22):
        reach=min(opacity, 90*(y-11),90*(21-y))
        if reach<=shield[y,10,3]:
            continue
        work[y,10,:3]=np.minimum(shield[y,11,:3],[34,43,52])
        work[y,10,3]=reach
    authored=Image.fromarray(work)
    authored.save(e/f"authored-shield-{opacity}.png")
    authored.resize((40*factor,88*factor),Image.Resampling.LANCZOS).save(e/f"cut-shield-{opacity}.png")

