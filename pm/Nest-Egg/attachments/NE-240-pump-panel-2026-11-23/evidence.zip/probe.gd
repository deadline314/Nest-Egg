extends "res://tools/ch3_flow_probe.gd"

const PANEL := &"ch3_branch_panel"
const CLOSED := &"sluice_hall__branch_panel_closed"
const ISOLATED := &"ch3_wet_branch_isolated"
const POWERED := &"ch3_lift_powered"
var _seen_actions: Dictionary = {}
var _observing := false


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Enemy.activation_culling_enabled = false
	Settings.set_skip_cutscenes(false)
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip = false
	_carry_ch2_results()
	await _enter("pump")
	var source := _object(PANEL)
	var panel: PropNode
	for node in get_tree().get_nodes_in_group(PropNode.GROUP):
		if node is PropNode and node.data.id == CLOSED:
			panel = node
			break
	_check(source != null and panel != null, "the published Chapter 3 pump room owns both the actor and the prop")
	if source != null and panel != null:
		await _panel_cases(source, panel)
	print("PUMP_PANEL_PROBE failures=%d" % _failures)
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if _failures else 0)


func _panel_cases(source: NpcActor, panel: PropNode) -> void:
	await _panel_press(source, -1, [])
	_check(not GameState.has_flag(ISOLATED) and not GameState.has_flag(POWERED), "wet panel refuses changing either line")
	await _talk(&"ch3_drain_wheel", ["drain"])
	_check(GameState.has_flag(&"ch3_pump_low"), "actual upper route valve drains the pump")
	var offsets: Array = []
	_level.player.global_position = source.global_position + Vector2(-24.0, 0.0)
	for i in 16:
		await get_tree().physics_frame
	var actor_y := _level.player.global_position.y
	var station_y := actor_y - panel.global_position.y
	for x in [-22.0, -18.0, -14.0, -10.0, 20.0, 24.0, 28.0]:
		var station := panel.to_global(Vector2(x, station_y))
		offsets.append({ "x": x, "legal": WorldPropAction.route_clear(_level.player, station) })
	print("PANEL_GEOMETRY ", JSON.stringify({
		"source": [source.global_position.x, source.global_position.y],
		"prop": [panel.global_position.x, panel.global_position.y],
		"prop_size": [panel.data.size.x, panel.data.size.y],
		"offset_to_floor": station_y,
		"stand_on_floor": _level.player.is_on_floor(),
		"stations_from_left": offsets,
	}))
	var credits := Progression.credits
	var items := StoryItems.snapshot()
	if OS.get_cmdline_user_args().has("--panel-preview"):
		_preview_power(station_y)
	_observing = true
	_observe.call_deferred()
	await _panel_press(source, 1, ["main", "leave"])
	_check(not GameState.has_flag(ISOLATED) and not GameState.has_flag(POWERED), "wrong switch gives a retry and preserves the pump state")
	await _panel_press(source, -1, ["branch", "power"])
	_observing = false
	_check(GameState.has_flag(ISOLATED) and GameState.has_flag(POWERED), "right order isolates the branch and powers the main")
	_check(Progression.credits == credits and StoryItems.snapshot() == items, "no new credits or items from the pump puzzle")
	_check(not _level.player.interaction.active and _level.player._visual.interaction_action == null,
		"native player's hand and control are released")
	await _panel_press(source, 1, [])
	_check(GameState.has_flag(ISOLATED) and GameState.has_flag(POWERED), "revisit keeps the actual completed flags")
	print("PANEL_ACTIONS ", JSON.stringify(_seen_actions))


func _panel_press(source: NpcActor, side: int, choices: Array) -> void:
	_level.player.global_position = source.global_position + Vector2(side * 24.0, 0.0)
	_level.player.velocity = Vector2.ZERO
	for i in 18:
		await get_tree().physics_frame
	var event: Variant
	var pad := OS.get_cmdline_user_args().has("--simulated-pad")
	if pad:
		var button := InputEventJoypadButton.new()
		button.device = 999
		button.button_index = JOY_BUTTON_X
		event = button
	else:
		var key := InputEventKey.new()
		key.keycode = KEY_E
		key.physical_keycode = KEY_E
		event = key
	event.pressed = true
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await get_tree().physics_frame
	await get_tree().physics_frame
	event.pressed = false
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	_check(source._talking, "%s starts the panel from side %d" % ["virtual pad" if pad else "actual E", side])
	await _drive(choices, func() -> bool: return not source._talking)
	for i in 42:
		await get_tree().physics_frame


func _observe() -> void:
	while _observing:
		await get_tree().process_frame
		var action: WorldPropAction = _level.player._visual.interaction_action
		if action == null or action.done or action._spec.is_empty():
			continue
		var key := str(action._spec.get("scene")) + ":" + action.phase
		var row: Dictionary = _seen_actions.get(key, {"count":0, "contacts":0, "error":0.0})
		row["count"] += 1
		row["contacts"] = maxi(row["contacts"],action.contacts_completed)
		if action.contacts_completed > 0:
			row["error"] = maxf(row["error"],action.contact_error)
		_seen_actions[key] = row



## Local trial using the current exact stage. Only the new authored step is injected in memory.
func _preview_power(station_y: float) -> void:
	WorldPropAction.definition("pump_wheel_drain")
	var scene := "ch3_t_c02_powered"
	var id := "pump_main_breaker"
	WorldPropAction._table[id] = {
		"scene": scene, "level": "res://data/levels/ch3_pump.tres",
		"source": "res://data/npcs/ch3_branch_panel.tres", "prop": String(CLOSED),
		"kind": "press", "station": [-7.0, station_y], "facing": 1,
		"hand_angle": -30, "button": [10.2, 15.3],
	}
	var row: Dictionary = Story._scenes[scene].duplicate(true)
	row["steps"].push_front({"do":"world_action", "id":id})
	Story._scenes[scene] = row
