extends "probe.gd"

const COLORS := [Color("#ffb23f"), Color("#448ada"), Color("#36a06d")]
var _capture_board := false


func _run() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--lamp-preview="):
			var compare := FileAccess.get_file_as_string(argument.trim_prefix("--lamp-preview="))
			PropReaction._table = JSON.parse_string(compare)
			PropReaction._table_loaded = true
		elif argument == "--capture-board":
			_capture_board = true
	await super._run()


func _panel_cases(source: NpcActor, panel: PropNode) -> void:
	await _panel_press(source, -1, [])
	_check(not GameState.has_flag(ISOLATED) and not GameState.has_flag(POWERED), "wet panel refuses either line")
	await _record(panel, "waiting", 0, false)
	await _talk(&"ch3_drain_wheel", ["drain"])
	_check(GameState.has_flag(&"ch3_pump_low"), "the authored upper valve sets low water")
	await _panel_press(source, 1, ["main", "leave"])
	_check(not GameState.has_flag(ISOLATED) and not GameState.has_flag(POWERED), "wrong switch leaves both flag values")
	await _record(panel, "after_wrong_choice", 0, false)
	var credits := Progression.credits
	var items := StoryItems.snapshot()
	await _panel_press(source, -1, ["branch", "leave"])
	_check(GameState.has_flag(ISOLATED) and not GameState.has_flag(POWERED), "leave with the branch isolated before powering")
	await _record(panel, "isolated", 1, true)
	await _panel_press(source, 1, ["power"])
	_check(GameState.has_flag(ISOLATED) and GameState.has_flag(POWERED), "the actual main power action completes")
	await _record(panel, "powered", 2, true)
	_check(Progression.credits == credits and StoryItems.snapshot() == items, "the puzzle pays no credits or items")
	await _enter("pump")
	var reloaded: PropNode
	for node in get_tree().get_nodes_in_group(PropNode.GROUP):
		if node is PropNode and node.data.id == CLOSED:
			reloaded = node
			break
	_check(reloaded != null and GameState.has_flag(POWERED), "re-entering the real room reconstructs its completed props")
	if reloaded != null:
		await _record(reloaded, "return", 2, true)
		await _panel_press(_object(PANEL), -1, [])
		_check(GameState.has_flag(POWERED), "revisit keeps the main powered")


func _record(panel: PropNode, label: String, state: int, open: bool) -> void:
	var reaction := panel.get_node("Reaction_pump_branch_panel") as PropReaction
	_check(reaction != null and is_instance_valid(reaction._light), label + " owns its actual state light")
	if reaction == null:
		return
	var color := reaction._lamp_color()
	var state_flag: String = reaction._lamp_state.get("flag", "")
	_check(color.is_equal_approx(COLORS[state]), label + " lamp shows the expected color")
	_check(reaction._swapped == open and reaction._swap_node.visible == open, label + " original door state matches its outcome")
	_check(is_equal_approx(reaction._lamp_at.y, 18.0), label + " indicator lines up with either casing")
	if state > 0:
		_check(is_zero_approx(float(reaction._lamp_state["pulse"])), label + " state light stays steady")
	print("PANEL_LAMP ",JSON.stringify({
		"label":label, "color":color.to_html(false), "flag":state_flag, "open":reaction._swapped,
		"lamp_x":reaction._lamp_at.x, "lamp_y":reaction._lamp_at.y,
		"first_contact":GameState.has_flag(ISOLATED), "powered":GameState.has_flag(POWERED),
	}))
	if _capture_board and label in ["waiting", "isolated", "powered"]:
		var camera := get_viewport().get_camera_2d()
		camera.set_physics_process(false)
		camera.zoom=Vector2.ONE * 3.4
		camera.global_position=panel.global_position+Vector2(15.0,26.0)
		camera.reset_smoothing()
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		_capture(label)
		camera.set_physics_process(true)

