extends Node

const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://title-language-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.set_language("en")
	GameState.difficulty = GameState.difficulties[1]
	var actual_main := preload("res://scenes/main.tscn").instantiate()
	add_child(actual_main)
	var menu: MainMenu
	for frame in 240:
		for child in actual_main.get_children():
			if child is MainMenu:
				menu = child
				break
		if menu != null:
			break
		await _frames(1)
	_check(is_instance_valid(menu), "the real entry scene boots to its main menu")
	if menu == null:
		await _finish(actual_main)
		return
	for frame in 240:
		if not Transition.is_active():
			break
		await _frames(1)
	await _frames(3)
	_check(not Transition.is_active(), "the actual startup transition finishes before any menu input")
	_check(menu._start_button.text == "New game" and menu._hint.text == "Choose a difficulty and start the prologue.",
			"main-menu label and current focus hint use English")
	_check(_has_label(menu._main_page, "Move") and menu.get_viewport().gui_get_focus_owner() == menu._start_button,
			"the actual main menu shows vertical navigation and focuses its primary action")
	await _picture("menu-en.png")
	await _key(KEY_ENTER)
	_check(menu._difficulty_page.visible and menu.get_viewport().gui_get_focus_owner() == menu._cards[1],
			"Enter opens the real difficulty page at its saved difficulty")
	_check((menu._cards[1].content.get_child(0) as Label).text == "Standard"
			and menu._cards[1].tooltip_text == "The intended balance of combat and exploration.",
			"the visible difficulty and its original Hover description use English")
	_check(_has_label(menu._difficulty_page, "HP 4") and _has_label(menu._difficulty_page, "Checkpoint healing: Off"),
			"hardcore stats and checkpoint behavior are translated from the selected data")
	_check(_has_label(menu._difficulty_page, InputBindings.primary_label(&"ui_left") + "/")
			and _has_label(menu._difficulty_page, "Difficulty"), "the difficulty page identifies horizontal navigation")
	_check(_fits(menu), "all cards, stats, and the button row fit within the 120 percent layout")
	await _joy(JOY_BUTTON_DPAD_RIGHT)
	_check(menu.get_viewport().gui_get_focus_owner() == menu._cards[2] and InputBindings.using_gamepad,
			"the real controller D-pad moves focus to the next difficulty")
	await _joy(JOY_BUTTON_A)
	_check(menu._selected == GameState.difficulties[2], "controller confirmation selects the original hardcore resource")
	_check(_has_label(menu._difficulty_page, InputBindings.primary_label(&"ui_left") + "/"),
			"the difficulty hint refreshes to the active pad device")
	await _picture("difficulty-en.png")
	await _joy(JOY_BUTTON_B)
	_check(menu._main_page.visible and menu.get_viewport().gui_get_focus_owner() == menu._start_button,
			"controller back restores focus to New game")
	actual_main.queue_free()
	await _frames(6)
	Story.set_language("ja")
	var translated := MainMenu.new()
	add_child(translated)
	await _frames(6)
	await _key(KEY_ENTER)
	_check(translated._start_button.text == "任務を開始"
			and translated._confirm_button.text == "出発" and _has_label(translated._difficulty_page, "難易度を選択"),
			"Japanese title and controls use their own language")
	_check(translated._cards[0].tooltip_text.begins_with("体力が多く")
			and _has_label(translated._difficulty_page, "チェックポイント回復なし"), "Japanese difficulty descriptions and stats are available")
	_check(_fits(translated), "Japanese cards and buttons fit at 120 percent")
	await _picture("difficulty-ja.png")
	await _finish(translated)


func _fits(menu: MainMenu) -> bool:
	for card in menu._cards:
		var cell := card.get_global_rect()
		if cell.end.x > menu._ui.size.x + 0.5 or cell.end.y > menu._confirm_button.get_global_rect().position.y + 0.5:
			return false
		for node in card.content.get_children():
			if node is Label and (node as Label).get_global_rect().end.x > cell.end.x + 0.5:
				return false
	return true


func _has_label(root: Node, fragment: String) -> bool:
	if root is Label and (root as Label).text.contains(fragment):
		return true
	for child in root.get_children():
		if _has_label(child, fragment):
			return true
	return false


func _picture(file: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(file)) == OK, "captured actual " + file)


func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _press(event)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	await _press(event)


func _press(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish(screen: Node) -> void:
	screen.queue_free()
	await _frames(7)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))
