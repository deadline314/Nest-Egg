from pathlib import Path
import hashlib,json,shutil,py_compile
P=Path(__file__).resolve().parent
C=P.parents[1]
OWN=['probe.gd','probe.tscn','parser.gd','parser.tscn','expected.json','read_pending.py','.gdignore']
trees=[Path('D:/NestEggVerification/ne296-aerial-jump-20261113'),Path('D:/NestEggVerification/bg20-bg21-native-review-20261113')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
archive=P/'transition-preparation-v3'
assert not archive.exists()
archive.mkdir()
for name in OWN+['execute_pending_state_v29.py','preparation-manifest-v3.json']:
    shutil.copyfile(P/name,archive/name)
(archive/'original-manifest.json').write_text(json.dumps({n:sha(archive/n) for n in OWN+['execute_pending_state_v29.py','preparation-manifest-v3.json']},indent=2)+'\n',encoding='utf8')
probe=(P/'probe.gd').read_text(encoding='utf8')
old='if not await _until(func() -> bool: return not _main.call("_route_pending")):'
assert probe.count(old)==1
probe=probe.replace(old,'if not await _until(_menu_ready):')
probe=probe.replace('"original Main route guard becomes ready before public continue"','"original Main menu completes transition and naturally focuses usable Continue"')
probe=probe.replace('# Reuse original route-ready precondition, never its skip tail.','# Public Main route after full original menu transition/focus readiness; no skip.')
helper='''func _menu_ready() -> bool:
	if _main.call("_route_pending") or Transition.is_active():
		return false
	var screen := _main.get("_screen") as MainMenu
	if not is_instance_valid(screen) or not screen.is_inside_tree():
		return false
	var button := screen.get("_continue_button") as Button
	return is_instance_valid(button) and button.is_inside_tree() and button.is_visible_in_tree() and not button.disabled and button.has_focus()

'''
assert 'func _menu_ready()' not in probe
probe=probe.replace('func _continue() -> void:',helper+'func _continue() -> void:')
probe=probe.replace('"route_pending": _main.call("_route_pending"),','"transition_active": Transition.is_active(), "menu_ready": _menu_ready(), "route_pending": _main.call("_route_pending"),')
(P/'probe.gd').write_text(probe,encoding='utf8',newline='\n')
for tree in trees:
    for name in OWN:shutil.copyfile(P/name,tree/'work/ne297-pending-npc-v1'/name)
candidate=C/'work/ne297-candidate-v4/manifest.json'
data=json.loads(candidate.read_text(encoding='utf8'))
assert len(data['files'])==13
assert {n:sha(trees[1]/n) for n in data['files']}==data['files']
runner=(P/'execute_pending_state_v29.py').read_text(encoding='utf8')
runner=runner.replace("'execute_pending_state_v29.py','preparation-manifest-v3.json'","'execute_pending_final_v29.py','preparation-manifest-v4.json'")
runner=runner.replace("GODOT=Path(","CANDIDATE=C/'work/ne297-candidate-v4/manifest.json'\nCANDIDATE_SHA="+repr(sha(candidate))+"\nGODOT=Path(")
marker="    return {'C_guard':str(GUARD)"
assert marker in runner
runner=runner.replace(marker,"    assert sha(CANDIDATE)==CANDIDATE_SHA\n    candidate=json.loads(CANDIDATE.read_text(encoding='utf8'));assert len(candidate['files'])==13\n    actual_candidate={k:sha(TREES['new']/k) for k in candidate['files']};assert actual_candidate==candidate['files'],'NE297 v4 candidate13 drift'\n    return {'candidate13':actual_candidate,'candidate_manifest_sha256':sha(CANDIDATE),'C_guard':str(GUARD)")
(P/'execute_pending_final_v29.py').write_text(runner,encoding='utf8',newline='\n')
manifest={'status':'CPU prepared; execution results belong to new tags only','original_preserved':str(archive),'candidate_manifest':str(candidate),'candidate_manifest_sha256':sha(candidate),'candidate13':data['files'],'own_files':{n:sha(P/n) for n in OWN},'runner_sha256':sha(P/'execute_pending_final_v29.py'),'change':'Only full original menu transition/focus readiness; same exact seven dialogue lines, Owner, native capture, clocks and gates','original_old_slot_source':str(P/'epochs/old-write-v1/saved-after-exit'),'no_product_change':True}
(P/'preparation-manifest-v4.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
for name in ['execute_pending_final_v29.py','read_pending.py']:py_compile.compile(str(P/name),doraise=True)
save=P/'save-v3';assert not save.exists();save.mkdir()
for name in ['slot.json','slot.json.bak','pending-original.json','pending-old-proof.json']:
    source=P/'epochs/old-write-v1/saved-after-exit'/name
    if source.exists():shutil.copyfile(source,save/name)
(P/'save-v3-original-copy.json').write_text(json.dumps({p.name:sha(p) for p in save.iterdir()},indent=2)+'\n',encoding='utf8')
print(json.dumps({'ready':True,'candidate_count':len(data['files']),'manifest':str(P/'preparation-manifest-v4.json'),'save':str(save)},indent=2))
