from pathlib import Path
import json,hashlib,shutil,py_compile
P=Path(__file__).resolve().parent
OWN=['probe.gd','probe.tscn','parser.gd','parser.tscn','expected.json','read_pending.py','.gdignore']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
archive=P/'transfer-control-preparation-v5';assert not archive.exists();archive.mkdir()
for n in OWN+['execute_pending_value_v29.py','preparation-manifest-v5.json']:shutil.copyfile(P/n,archive/n)
(archive/'original-manifest.json').write_text(json.dumps({n:sha(archive/n) for n in OWN+['execute_pending_value_v29.py','preparation-manifest-v5.json']},indent=2)+'\n',encoding='utf8')
s=(P/'parser.gd').read_text(encoding='utf8')
s=s.replace('\tvar wrong_version:', '\tvar transferred: Dictionary = persisted.duplicate(true)\n\ttransferred["transferred"] = ["a"]\n\tvar wrong_version:')
s=s.replace('var ok := Probe._saved_value_equal(original, persisted) and', 'var ok := not Probe._saved_value_equal(original, transferred) and Probe._saved_value_equal(original, persisted) and')
s=s.replace('{"raw_equality":', '{"transfer_rejected": not Probe._saved_value_equal(original, transferred), "raw_equality":')
(P/'parser.gd').write_text(s,encoding='utf8',newline='\n')
for t in ['D:/NestEggVerification/ne296-aerial-jump-20261113','D:/NestEggVerification/bg20-bg21-native-review-20261113']:
    for n in OWN:shutil.copyfile(P/n,Path(t)/'work/ne297-pending-npc-v1'/n)
r=(P/'execute_pending_value_v29.py').read_text(encoding='utf8').replace("'execute_pending_value_v29.py','preparation-manifest-v5.json'","'execute_pending_complete_v29.py','preparation-manifest-v6.json'")
(P/'execute_pending_complete_v29.py').write_text(r,encoding='utf8',newline='\n')
m=json.loads((P/'preparation-manifest-v5.json').read_text(encoding='utf8'));m.update({'previous_source_archive':str(archive),'status':'CPU prepared with explicit extra/missing/item/transfer/version negative controls','own_files':{n:sha(P/n) for n in OWN},'runner_sha256':sha(P/'execute_pending_complete_v29.py')})
(P/'preparation-manifest-v6.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf8')
py_compile.compile(str(P/'execute_pending_complete_v29.py'),doraise=True)
print('TRANSFER_CONTROL_PREPARED')
