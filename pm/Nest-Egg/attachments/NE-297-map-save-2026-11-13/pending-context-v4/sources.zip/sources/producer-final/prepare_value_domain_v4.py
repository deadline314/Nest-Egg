from pathlib import Path
import hashlib,json,shutil,py_compile
P=Path(__file__).resolve().parent
OWN=['probe.gd','probe.tscn','parser.gd','parser.tscn','expected.json','read_pending.py','.gdignore']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
archive=P/'value-domain-preparation-v4';assert not archive.exists();archive.mkdir()
for n in OWN+['execute_pending_final_v29.py','preparation-manifest-v4.json']:shutil.copyfile(P/n,archive/n)
(archive/'original-manifest.json').write_text(json.dumps({n:sha(archive/n) for n in OWN+['execute_pending_final_v29.py','preparation-manifest-v4.json']},indent=2)+'\n',encoding='utf8')
s=(P/'probe.gd').read_text(encoding='utf8')
old='\t_check(Progression.credits == prior["credits"] and StoryItems.snapshot() == prior["items"] and actor.capture_state()["claimed"] == prior["claimed"], "reward-free Egret does not create extra credit, custody or claims")'
assert s.count(old)==1
new='''	var item_snapshot := StoryItems.snapshot()
	var claims: Array = actor.capture_state()["claimed"]
	_put("pending-equality-witness.json", {"credits_equal": Progression.credits == prior["credits"], "raw_items_equal": item_snapshot == prior["items"], "saved_value_items_equal": _saved_value_equal(item_snapshot, prior["items"]), "claims_equal": claims == prior["claimed"], "actual_items": item_snapshot, "prior_items": prior["items"], "actual_custody_type": typeof(item_snapshot["custody_version"]), "prior_custody_type": typeof(prior["items"]["custody_version"]), "actual_item_element_type": typeof(item_snapshot["owned"][0]), "prior_item_element_type": typeof(prior["items"]["owned"][0])})
	_check(Progression.credits == prior["credits"], "reward-free Egret preserves all actual credits")
	_check(_saved_value_equal(item_snapshot, prior["items"]), "reward-free Egret preserves the exact saved custody value")
	_check(claims == prior["claimed"], "reward-free Egret preserves all claimed rewards")'''
s=s.replace(old,new)
s=s.replace('func _menu_ready() -> bool:', '''static func _saved_value_equal(actual: Variant, persisted: Variant) -> bool:
	# Compare in the original JSON save value domain, not typed StringName/int vs parsed String/float containers.
	return JSON.parse_string(JSON.stringify(actual)) == persisted

func _menu_ready() -> bool:''')
(P/'probe.gd').write_text(s,encoding='utf8',newline='\n')
parser='''extends Node
const Probe := preload("res://work/ne297-pending-npc-v1/probe.gd")
func _ready() -> void:
	var original := {"custody_version": 1, "owned": [&"a", &"b"], "held": [&"a"], "unseen": [], "transferred": []}
	var persisted: Dictionary = JSON.parse_string(JSON.stringify(original))
	var changed: Dictionary = persisted.duplicate(true)
	changed["held"] = ["b"]
	var wrong_version: Dictionary = persisted.duplicate(true)
	wrong_version["custody_version"] = 2.0
	var missing: Dictionary = persisted.duplicate(true)
	missing.erase("unseen")
	var extra: Dictionary = persisted.duplicate(true)
	extra["unexpected"] = true
	var ok := Probe._saved_value_equal(original, persisted) and not Probe._saved_value_equal(original, changed) and not Probe._saved_value_equal(original, wrong_version) and not Probe._saved_value_equal(original, missing) and not Probe._saved_value_equal(original, extra)
	print("NE297_VALUE_DOMAIN_CONTROL ", JSON.stringify({"raw_equality": original == persisted, "same_save_value": Probe._saved_value_equal(original, persisted), "changed_item_rejected": not Probe._saved_value_equal(original, changed), "changed_version_rejected": not Probe._saved_value_equal(original, wrong_version), "missing_rejected": not Probe._saved_value_equal(original, missing), "extra_rejected": not Probe._saved_value_equal(original, extra), "original_version_type": typeof(original["custody_version"]), "parsed_version_type": typeof(persisted["custody_version"]), "original_item_type": typeof(original["owned"][0]), "parsed_item_type": typeof(persisted["owned"][0])}))
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	if ok:
		print("NE297_PENDING_PARSER_OK")
	get_tree().quit(0 if ok else 1)
'''
(P/'parser.gd').write_text(parser,encoding='utf8',newline='\n')
for tree in [Path('D:/NestEggVerification/ne296-aerial-jump-20261113'),Path('D:/NestEggVerification/bg20-bg21-native-review-20261113')]:
    for n in OWN:shutil.copyfile(P/n,tree/'work/ne297-pending-npc-v1'/n)
runner=(P/'execute_pending_final_v29.py').read_text(encoding='utf8').replace("'execute_pending_final_v29.py','preparation-manifest-v4.json'","'execute_pending_value_v29.py','preparation-manifest-v5.json'")
(P/'execute_pending_value_v29.py').write_text(runner,encoding='utf8',newline='\n')
prior=json.loads((P/'preparation-manifest-v4.json').read_text(encoding='utf8'))
prior.update({'status':'CPU prepared; new parser includes five save-value domain controls','previous_source_archive':str(archive),'own_files':{n:sha(P/n) for n in OWN},'runner_sha256':sha(P/'execute_pending_value_v29.py'),'change':'Only custody equality converts actual typed snapshot into the same canonical JSON value domain as the immutable prior witness; controls reject changed item/version/missing/extra keys. No product or saved-slot mutation.'})
(P/'preparation-manifest-v5.json').write_text(json.dumps(prior,indent=2)+'\n',encoding='utf8')
py_compile.compile(str(P/'execute_pending_value_v29.py'),doraise=True)
save=P/'save-v4';assert not save.exists();save.mkdir()
for n in ['slot.json','slot.json.bak','pending-original.json','pending-old-proof.json']:
    src=P/'epochs/old-write-v1/saved-after-exit'/n
    if src.exists():shutil.copyfile(src,save/n)
(P/'save-v4-original-copy.json').write_text(json.dumps({p.name:sha(p) for p in save.iterdir()},indent=2)+'\n',encoding='utf8')
print('VALUE_DOMAIN_PREPARED; original slot untouched; no product changes')
