extends Node
const Probe := preload("res://work/ne297-pending-npc-v1/probe.gd")
func _ready() -> void:
	var original := {"custody_version": 1, "owned": [&"a", &"b"], "held": [&"a"], "unseen": [], "transferred": []}
	var persisted: Dictionary = JSON.parse_string(JSON.stringify(original))
	var changed: Dictionary = persisted.duplicate(true)
	changed["held"] = ["b"]
	var transferred: Dictionary = persisted.duplicate(true)
	transferred["transferred"] = ["a"]
	var wrong_version: Dictionary = persisted.duplicate(true)
	wrong_version["custody_version"] = 2.0
	var missing: Dictionary = persisted.duplicate(true)
	missing.erase("unseen")
	var extra: Dictionary = persisted.duplicate(true)
	extra["unexpected"] = true
	var ok := not Probe._saved_value_equal(original, transferred) and Probe._saved_value_equal(original, persisted) and not Probe._saved_value_equal(original, changed) and not Probe._saved_value_equal(original, wrong_version) and not Probe._saved_value_equal(original, missing) and not Probe._saved_value_equal(original, extra)
	print("NE297_VALUE_DOMAIN_CONTROL ", JSON.stringify({"transfer_rejected": not Probe._saved_value_equal(original, transferred), "raw_equality": original == persisted, "same_save_value": Probe._saved_value_equal(original, persisted), "changed_item_rejected": not Probe._saved_value_equal(original, changed), "changed_version_rejected": not Probe._saved_value_equal(original, wrong_version), "missing_rejected": not Probe._saved_value_equal(original, missing), "extra_rejected": not Probe._saved_value_equal(original, extra), "original_version_type": typeof(original["custody_version"]), "parsed_version_type": typeof(persisted["custody_version"]), "original_item_type": typeof(original["owned"][0]), "parsed_item_type": typeof(persisted["owned"][0])}))
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	if ok:
		print("NE297_PENDING_PARSER_OK")
	get_tree().quit(0 if ok else 1)
