"""NE297 pending-NPC exact-source epochs. Preparation is not engine authorization."""
import argparse,hashlib,json,msvcrt,os,re,socket,subprocess,sys,time,urllib.error,urllib.request
from pathlib import Path
P=Path(__file__).resolve().parent
C=Path('C:/Users/stanl/Github/Nest-Egg')
TREES={'old':Path('D:/NestEggVerification/ne296-aerial-jump-20261113'),'new':Path('D:/NestEggVerification/bg20-bg21-native-review-20261113')}
GUARD=C/'work/ne296-adoption-v1/c-native-context-v29.json'
GUARD_SHA='a3df1f1a2c27952545453a3d1b8a422a42755deddcc86088a70c1dc62e1d81d0'
CANDIDATE=C/'work/ne297-candidate-v4/manifest.json'
CANDIDATE_SHA='c90bb247e971973875e483e5b3d266b59e8c6b5345fc12d81241d7bba1bea11f'
GODOT=Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
PREFIXES=['art','audio','autoload','core','data','game','scenes','ui','shaders','addons','config','tools','tests','work/ne297-pending-npc-v1']
OWN=['probe.gd','probe.tscn','parser.gd','parser.tscn','expected.json','read_pending.py','.gdignore']
ENV=['APPDATA','LOCALAPPDATA','USERPROFILE','TMP','TEMP']

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def put(out,name,value):
    q=out/name;assert not q.exists(),q;q.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
def queues():
    result={}
    for port in [8188,8189]:
        try:
            with urllib.request.urlopen(f'http://127.0.0.1:{port}/queue',timeout=3) as f:value=json.load(f)
            assert isinstance(value['queue_running'],list) and isinstance(value['queue_pending'],list)
            result[str(port)]={'status':'response','running':len(value['queue_running']),'pending':len(value['queue_pending'])}
        except urllib.error.URLError as e:
            code=getattr(e.reason,'winerror',None) or getattr(e.reason,'errno',None);result[str(port)]={'status':'refused10061' if code==10061 else 'unknown','error':str(e)}
        except (OSError,ValueError,KeyError,AssertionError) as e:result[str(port)]={'status':'unknown','error':str(e)}
    a,b=result['8188'],result['8189'];result['clear']=a.get('status')=='response' and a.get('running')==a.get('pending')==0 and (b.get('status')=='refused10061' or b.get('status')=='response' and b.get('running')==b.get('pending')==0)
    return result

def processes():
    command=['powershell','-NoProfile','-NonInteractive','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -like '*Godot*' } | Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Compress"]
    r=subprocess.run(command,capture_output=True);assert r.returncode==0;text=r.stdout.decode('utf8',errors='replace').strip();data=json.loads(text) if text else [];return data if isinstance(data,list) else [data]
def ours(rows):return [x for x in rows if 'res://work/ne297-pending-npc-v1/' in (x.get('CommandLine') or '')]
def git(tree,args):
    env=os.environ.copy();env['GIT_OPTIONAL_LOCKS']='0';return subprocess.check_output(['git',*args],cwd=tree,env=env)
def snapshot():
    assert sha(GUARD)==GUARD_SHA;guard=json.loads(GUARD.read_text(encoding='utf8'));assert guard['count']==len(guard['files'])==463
    primary={k:sha(C/k) for k in guard['files']};assert primary==guard['files'],'primary C463 drift'
    expected=json.loads((P/'expected.json').read_text(encoding='utf8'));trees={}
    for name,tree in TREES.items():
        files={}
        for prefix in PREFIXES:
            directory=tree/prefix
            if not directory.exists():continue
            for folder,dirs,names in os.walk(directory):
                dirs[:]=[x for x in dirs if x not in ['.godot','.git','__pycache__']]
                for filename in names:
                    f=Path(folder)/filename
                    if f.suffix=='.pyc':continue
                    files[f.relative_to(tree).as_posix()]=sha(f)
        for f in tree.iterdir():
            if f.is_file() and f.name!='.git':files[f.name]=sha(f)
        assert all(sha(tree/'work/ne297-pending-npc-v1'/k)==sha(P/k) for k in OWN),'producer copies differ'
        for k,digest in expected['cases'][name]['source_sha256'].items():assert files[k]==digest,('referenced source changed; needs new preparation epoch',name,k)
        trees[name]={'head':git(tree,['rev-parse','HEAD']).decode().strip(),'tracked_diff_sha256':hashlib.sha256(git(tree,['diff','--no-ext-diff','--binary'])).hexdigest(),'files':files}
    assert sha(CANDIDATE)==CANDIDATE_SHA
    candidate=json.loads(CANDIDATE.read_text(encoding='utf8'));assert len(candidate['files'])==13
    actual_candidate={k:sha(TREES['new']/k) for k in candidate['files']};assert actual_candidate==candidate['files'],'NE297 v4 candidate13 drift'
    return {'candidate13':actual_candidate,'candidate_manifest_sha256':sha(CANDIDATE),'C_guard':str(GUARD),'C_guard_sha256':sha(GUARD),'primary_C':primary,'trees':trees,'own':{k:sha(P/k) for k in OWN+['execute_pending_final_v29.py','preparation-manifest-v4.json']},'godot_sha256':sha(GODOT),'comfy_guard_sha256':sha(C/'tools/comfyui/comfy_guard.py'),'scope':'actual both old/new runtime dirs+tools/tests/root configs+seven own leaf files; .godot/pycache/transient userdata and historical PM/art_src evidence excluded','prefixes':PREFIXES,'prospective_UIDs':['work/ne297-pending-npc-v1/probe.gd.uid','work/ne297-pending-npc-v1/parser.gd.uid'],'performance_claim':False}
def engine(out,args):
    name='old' if args.mode in ['parser-old','write'] else 'new';tree=TREES[name];env=os.environ.copy()
    for key in ENV:
        q=out/'userdata'/key;q.mkdir(parents=True);env[key]=str(q)
    env['PYTHONUTF8']='1';put(out,'environment.json',{k:env[k] for k in ENV+['PYTHONUTF8']})
    command=[str(GODOT),'--path',str(tree),'--audio-driver','Dummy','--log-file',str(out/'godot.log')]
    if args.mode.startswith('parser'):command+=['--headless','res://work/ne297-pending-npc-v1/parser.tscn']
    else:
        command+=['--headless'] if args.mode=='write' else ['--windowed','--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan']
        command+=['res://work/ne297-pending-npc-v1/probe.tscn','--','--mode='+args.mode,'--save-dir='+str(args.save_dir),'--story-language=zh']
    put(out,'command.json',{'argv':command,'cwd':str(tree),'mode':args.mode,'tree':name})
    start=time.monotonic()
    with (out/'process.log').open('xb') as log:
        process=subprocess.Popen(command,cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP);put(out,'started.json',{'cli_pid':process.pid})
        try:code=process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            put(out,'timeout-processes.json',processes());subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True);process.wait(timeout=15);code='timeout'
    text=(out/'process.log').read_text(encoding='utf8',errors='replace')
    diagnostics=[line for line in text.splitlines() if re.search(r'SCRIPT ERROR|Parse Error|^ERROR:|^WARNING:|ObjectDB.*leak|were leaked|resources still in use|RID.*leak',line)]
    put(out,'process.json',{'exit_code':code,'seconds':time.monotonic()-start,'diagnostics':diagnostics,'log_sha256':sha(out/'process.log')})
    assert code==0 and not diagnostics,(code,diagnostics)
    assert ('NE297_PENDING_PARSER_OK' in text) if args.mode.startswith('parser') else (f'QUEST_RESUME mode={args.mode} failures=0' in text)
    if args.mode=='write':
        saved=out/'saved-after-exit';saved.mkdir()
        for filename in ['slot.json','slot.json.bak','pending-original.json','pending-old-proof.json']:
            f=args.save_dir/filename
            if f.exists():
                data=f.read_bytes();(saved/filename).write_bytes(data)
        envelope=json.loads((args.save_dir/'slot.json').read_text(encoding='utf8'));assert hashlib.sha256(envelope['payload'].encode('utf8')).hexdigest()==envelope['checksum'];payload=json.loads(envelope['payload']);assert payload['cinematic']=='ch1_t_egret_1' and payload['cinematic_context']=={'framing_source':'person','source_id':'npc:ch1_egret@54,17','talk_index':0},'final old slot must still be the genuine pending source'

def main(args):
    assert args.root_explicit_handoff,'CPU preparation is not authorization';out=P/'epochs'/args.tag;assert out.parent==P/'epochs' and not out.exists();out.mkdir(parents=True)
    if not args.mode.startswith('parser'):
        args.save_dir=args.save_dir.resolve();assert args.save_dir.is_relative_to(P.resolve()),'only explicitly owned save leaf'
        if args.mode=='write':assert not args.save_dir.exists();args.save_dir.mkdir(parents=True)
        else:assert (args.save_dir/'slot.json').is_file() and (args.save_dir/'pending-old-proof.json').is_file()
    current=processes();assert not ours(current),'existing owned consumer';put(out,'processes-before.json',current)
    before=snapshot();put(out,'source-before.json',before);outside=queues();put(out,'queue-before-lock.json',outside)
    if not outside['clear']:put(out,'completion.json',{'started':False,'accepted':False,'reason':'outer queue busy or unknown','engine_started':False});return 2
    sys.path.insert(0,str(C/'tools/comfyui'));import comfy_guard
    assert comfy_guard.LOCK_PATH.resolve()==(C/'assets_src/work/comfy.lock').resolve()
    error=None;started=False
    with comfy_guard.LOCK_PATH.open('a+b') as lock:
        lock.seek(0)
        try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:put(out,'completion.json',{'started':False,'accepted':False,'reason':'canonical lock busy','engine_started':False});return 2
        try:
            inner=queues();put(out,'queue-inside-before.json',inner)
            if not inner['clear']:error='inner queue busy or unknown'
            else:
                assert snapshot()==before;print('START NE297_PENDING '+args.mode,flush=True);started=True
                try:engine(out,args)
                except Exception as e:error=repr(e)
        finally:
            put(out,'queue-inside-after.json',queues());lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
    put(out,'queue-after-unlock.json',queues());after=snapshot();put(out,'source-after.json',after)
    current=processes();put(out,'processes-after.json',current);source_exact=before==after;owned_empty=not ours(current);clear=json.loads((out/'queue-inside-after.json').read_text())['clear'] and json.loads((out/'queue-after-unlock.json').read_text())['clear']
    put(out,'completion.json',{'mode':args.mode,'started':started,'error':error,'accepted':started and error is None and source_exact and owned_empty and clear,'both_tree_runtime_exact':source_exact,'primary_C463_exact':before['primary_C']==after['primary_C'],'tree_counts':{k:len(v['files']) for k,v in before['trees'].items()},'four_queue_gate_passed':clear and started,'owned_empty':owned_empty,'main_lock_released':True,'engine_exited':owned_empty,'performance_claim':False})
    print('DONE NE297_PENDING '+args.mode+'; lock released; accepted='+str(started and error is None and source_exact and owned_empty and clear),flush=True)
    if error:print(error,flush=True)
    return 0 if started and error is None and source_exact and owned_empty and clear else 1
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=['parser-old','parser-new','write','continue'],required=True);p.add_argument('--tag',required=True);p.add_argument('--save-dir',type=Path);p.add_argument('--root-explicit-handoff',action='store_true');a=p.parse_args();assert a.mode.startswith('parser') or a.save_dir is not None;raise SystemExit(main(a))
