extends Node
const Probe := preload("res://work/ne297-pending-npc-v1/probe.gd")
func _ready() -> void:
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	print("NE297_PENDING_PARSER_OK")
	get_tree().quit(0)
