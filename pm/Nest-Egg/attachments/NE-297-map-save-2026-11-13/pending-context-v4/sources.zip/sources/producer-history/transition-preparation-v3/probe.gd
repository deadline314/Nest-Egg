extends "res://tools/quest_resume_probe.gd"
## Arranged source-authentic pending NPC save, never a natural chapter playthrough.
const ROOF := "res://data/levels/ch1_rooftop.tres"
const TARGET := &"ch1_t_egret_1"
const NPC_ID := &"ch1_egret"
const SPEC_PATH := "res://work/ne297-pending-npc-v1/expected.json"
var _spec: Dictionary
var _starts := 0
var _finishes := 0
var _events: Array[Dictionary] = []
var _read: Array[Dictionary] = []
var _last_where := ""
var _states: Array[Dictionary] = []
var _periodic_states := 0
var _next_state_msec := 0
var _wait_phase := "unspecified"

func _run() -> void:
	if _mode not in ["write", "continue"]:
		AudioRelease.begin_shutdown()
		await AudioRelease.settle(get_tree())
		get_tree().quit(2)
		return
	_spec = JSON.parse_string(FileAccess.get_file_as_string(SPEC_PATH))
	_check(not _spec.is_empty() and Story.language == "zh", "source-exact Chinese fixture specification loaded")
	Story.scene_started.connect(_started)
	Story.scene_finished.connect(_finished)
	await super._run()

func _started(id: StringName, mode: StringName) -> void:
	if _events.size() < 64:
		_events.append({"event": "start", "id": String(id), "mode": String(mode), "context": Story.current_presentation_context()})
	else:
		_check(false, "bounded event witness overflow")
	if id == TARGET:
		_starts += 1

func _finished(id: StringName) -> void:
	if _events.size() < 64:
		_events.append({"event": "finish", "id": String(id)})
	if id == TARGET:
		_finishes += 1

func _actor() -> NpcActor:
	var level := _level()
	if level == null:
		return null
	for node: Node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and node.data.id == NPC_ID and level.is_ancestor_of(node):
			return node
	return null

func _until(predicate: Callable) -> bool:
	var deadline := Time.get_ticks_msec() + LIMIT_MSEC
	while Time.get_ticks_msec() < deadline and not predicate.call():
		if _periodic_states < 2 and Time.get_ticks_msec() >= _next_state_msec:
			_sample(_wait_phase + "/waiting")
			_periodic_states += 1
			_next_state_msec = Time.get_ticks_msec() + 1000
		await _settle(1)
	return predicate.call()

func _put(name: String, value: Variant) -> void:
	var file := FileAccess.open(_save_dir.path_join(name), FileAccess.WRITE)
	_check(file != null, "write owned witness " + name)
	if file != null:
		file.store_string(JSON.stringify(value, "\t"))
		file.close()

func _context_ok(raw: Dictionary, source: String) -> bool:
	return raw.get("framing_source") == "person" and raw.get("source_id") == source and int(raw.get("talk_index", -1)) == 0

func _write() -> void:
	GameState.story_autosave = false
	Story.auto_skip = false
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_dinner_done") # Explicit fixture precondition only.
	Progression.add_credits(17)
	var seed := Level.new()
	seed.configure(load(ROOF) as LevelData)
	add_child(seed)
	seed.player.set_physics_process(false)
	for enemy: Node in get_tree().get_nodes_in_group(&"enemies"):
		if seed.is_ancestor_of(enemy):
			enemy.set_physics_process(false)
	await _settle(3)
	var store: RunSaveStore = _main.get("_run_store")
	_check(store.write(RunSnapshot.capture(ROOF, seed.run_snapshot())), "real old Level writes an arranged source-area seed through Main-owned store")
	seed.queue_free()
	await _settle(3)
	_main.call("_on_continue_requested")
	if not await _until(func() -> bool: return _level() != null and _level().is_initialized() and not _main.call("_route_pending")):
		_check(false, "old Main source area initializes without skipping a presentation")
		return
	var actor := _actor()
	_check(actor != null and actor.cell == Vector2i(54, 17) and actor.state_key() == _spec["cases"]["old"]["source_id"], "original authored rooftop Egret is the old source")
	if actor == null:
		return
	_check(actor.current_talk_index() == 0 and actor.data.talks[0].scene == &"ch1_dispatch_brief" and not actor.data.talks[0].has_reward(), "actual original dispatch talk and reward-free contract selected")
	_level().player.global_position = actor.global_position + Vector2(-30, 0) # Declared test placement; physics/overlap remains real.
	_level().player.velocity = Vector2.ZERO
	if not await _until(func() -> bool: return actor.interaction_available() and Story.framing.is_interaction_target(actor)):
		_put("interaction-refusal.json", {"cell": [actor.cell.x, actor.cell.y], "actor": var_to_str(actor.global_transform), "player": var_to_str(_level().player.global_transform), "overlap_count": actor.get_overlapping_bodies().size(), "paused": get_tree().paused, "available": actor.interaction_available(), "context": Story.current_presentation_context()})
		_check(false, "true physics overlap and original framing admit public interact")
		return
	await get_tree().physics_frame
	Input.action_press(&"interact") # Original NpcActor._physics_process -> _talk, no fictional interact() API.
	await get_tree().physics_frame
	Input.action_release(&"interact")
	if not await _until(func() -> bool: return Story._current_cinematic == TARGET and _main.get("_cinematic") == String(TARGET)):
		_check(false, "public interact starts the genuine source-owned pending presentation")
		return
	var context := Story.current_presentation_context()
	_check(_starts == 1 and _finishes == 0 and _context_ok(context, _spec["cases"]["old"]["source_id"]), "pending scene owns the actual old person source and talk index")
	_check(actor.talk_count == 0 and actor.get("_talking") and not GameState.has_flag(&"ch1_heard_brief"), "uncompleted NPC result has not been installed")
	_main.call("_save_run")
	var decoded := RunSaveCodec.decode(FileAccess.get_file_as_string(store.path))
	_check(decoded.has("data"), "actual pending Main slot is checksum valid")
	if not decoded.has("data"):
		return
	var saved: Dictionary = decoded["data"]
	_check(saved.get("cinematic") == String(TARGET) and _context_ok(saved.get("cinematic_context", {}), _spec["cases"]["old"]["source_id"]), "real store retains the original source context without rewriting it")
	var original := FileAccess.open(_save_dir.path_join("pending-original.json"), FileAccess.WRITE)
	if original != null:
		original.store_buffer(FileAccess.get_file_as_bytes(store.path))
		original.close()
	_put("pending-old-proof.json", {"starts": _starts, "finishes": _finishes, "events": _events, "source_id": actor.state_key(), "cell": [actor.cell.x, actor.cell.y], "talks": actor.talk_count, "claimed": actor.capture_state()["claimed"], "context": context, "saved_context": saved.get("cinematic_context"), "scene": saved.get("cinematic"), "heard": GameState.has_flag(&"ch1_heard_brief"), "credits": Progression.credits, "items": StoryItems.snapshot(), "slot_sha256": FileAccess.get_sha256(store.path), "scope": "arranged source-area seed, real authored NPC public interact, pending Main save; no completed reward"})
	_completed = true

func _continue() -> void:
	Story.auto_skip = false
	if DisplayServer.get_name() != "headless":
		get_window().mode = Window.MODE_WINDOWED
		get_window().size = Vector2i(1280, 720)
		DisplayMode.ensure_scaling(get_window())
	var prior: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(_save_dir.path_join("pending-old-proof.json")))
	_wait_phase = "initial-menu-ready"
	_sample("before-original-route-ready-wait")
	if not await _until(func() -> bool: return not _main.call("_route_pending")):
		_sample("menu-ready-timeout")
		_put("pending-state-witness.json", _states)
		_check(false, "original Main route guard becomes ready before public continue")
		return
	_sample("ready-before-public-continue")
	_main.call("_on_continue_requested") # Reuse original route-ready precondition, never its skip tail.
	_wait_phase = "original-pending-predicate"
	_sample("after-public-continue-request")
	if not await _until(func() -> bool: return _level() != null and _level().is_initialized() and _actor() != null and Story._current_cinematic == TARGET):
		_sample("original-pending-predicate-timeout")
		_put("pending-state-witness.json", _states)
		_check(false, "new Main naturally resumes the original pending scene")
		return
	_sample("original-pending-predicate-true")
	_put("pending-state-witness.json", _states)
	var actor := _actor()
	var context := Story.current_presentation_context()
	_check(actor.cell == Vector2i(54, 49) and _level().npc_sources.has(actor) and actor.data.resource_path == _spec["actor_resource"], "real new authored actor remains its registered source")
	_check(actor.get("_talking") and actor.get("_presentation_index") == 0 and _context_ok(context, _spec["cases"]["new"]["source_id"]), "strict resume owns the relocated live NPC; no generic fallback")
	_check(_starts == 1 and _finishes == 0 and actor.talk_count == 0 and not GameState.has_flag(&"ch1_heard_brief"), "cold resume is still pending before reading")
	await _drive()
	_sample("after-original-dialogue-driver")
	_put("pending-state-witness.json", _states)
	if _failures > 0:
		return
	await _settle(30)
	_check(_starts == 1 and _finishes == 1 and actor.talk_count == 1 and not actor.get("_talking"), "original pending source completes exactly once including NPC waiter")
	_check(GameState.has_flag(&"ch1_heard_brief") and Story.was_seen(TARGET), "real terminal result and seen state publish")
	_check(Progression.credits == prior["credits"] and StoryItems.snapshot() == prior["items"] and actor.capture_state()["claimed"] == prior["claimed"], "reward-free Egret does not create extra credit, custody or claims")
	_main.call("_save_run")
	await _settle(10)
	_main.call("_save_run")
	var store: RunSaveStore = _main.get("_run_store")
	var decoded := RunSaveCodec.decode(FileAccess.get_file_as_string(store.path))
	_check(decoded.has("data"), "completed Main save remains checksum valid")
	if not decoded.has("data"):
		return
	var saved: Dictionary = decoded["data"]
	_check(saved.get("cinematic", "").is_empty() and saved["runtime"]["world"].get(actor.state_key(), {}).get("talks", -1) == 1 and saved["story"]["flags"].get("ch1_heard_brief") == true, "disk clears pending state and retains exactly one real NPC completion")
	_put("pending-new-proof.json", {"starts": _starts, "finishes": _finishes, "events": _events, "source_id": actor.state_key(), "cell": [actor.cell.x, actor.cell.y], "context_during_resume": context, "talks": actor.talk_count, "claimed": actor.capture_state()["claimed"], "heard": GameState.has_flag(&"ch1_heard_brief"), "credits": Progression.credits, "items": StoryItems.snapshot(), "read_lines": _read, "slot_sha256": FileAccess.get_sha256(store.path), "pending_cleared": saved.get("cinematic", "").is_empty(), "scope": "actual pending-NPC restore and one terminal result through Main; no real monetary reward configured"})
	_completed = true

func _drive() -> void:
	var deadline := Time.get_ticks_msec() + LIMIT_MSEC
	var expected: Array = _spec["cases"]["new"]["lines"]
	while Time.get_ticks_msec() < deadline and (_finishes < 1 or Story.is_cinematic_active() or _actor().get("_talking")):
		var player: CutscenePlayer = Story._player if is_instance_valid(Story._player) else null
		if player != null and player.choice_active():
			_check(false, "unexpected choice cannot be fabricated or auto-selected")
			return
		if player != null and player.scene_id == TARGET and player._dialogue.visible and player._dialogue.is_complete() and player._dialogue._frame.modulate.a == 1.0 and player._current_where != _last_where:
			if _read.size() >= expected.size():
				_check(false, "extra dialogue beyond the source-exact expected sequence")
				return
			var line: Dictionary = expected[_read.size()]
			_check(player._current_where == line["where"] and player._dialogue._text.text == line["text"] and player._dialogue._name.text == line["name"], "fully revealed source-exact line " + str(line["step_index"]))
			if _failures > 0:
				return
			_last_where = player._current_where
			_read.append({"where": player._current_where, "text": player._dialogue._text.text, "name": player._dialogue._name.text, "complete": true, "frame_alpha": player._dialogue._frame.modulate.a})
			if _read.size() == 1 and DisplayServer.get_name() != "headless":
				await _shot()
			var event := InputEventKey.new()
			event.keycode = KEY_ENTER
			event.physical_keycode = KEY_ENTER
			event.pressed = true
			Input.parse_input_event(event)
			await _settle(1)
			event = InputEventKey.new()
			event.keycode = KEY_ENTER
			event.physical_keycode = KEY_ENTER
			event.pressed = false
			Input.parse_input_event(event)
		await _settle(1)
	_check(_read.size() == expected.size() and _finishes == 1, "all exact authored lines read once before the original finish")

func _shot() -> void:
	for i in 3:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
	var viewport := get_viewport()
	var image := viewport.get_texture().get_image()
	_check(image != null and image.get_size() == Vector2i(1280,720) and image.get_format() == Image.FORMAT_RGBH and viewport.use_hdr_2d, "pending actual original Image supports the native raw contract")
	if image == null or image.get_size() != Vector2i(1280,720) or image.get_format() != Image.FORMAT_RGBH or not viewport.use_hdr_2d:
		return
	var file := FileAccess.open(_save_dir.path_join("pending-first-line.rgbh"), FileAccess.WRITE)
	if file == null:
		_check(false, "raw output is writable")
		return
	file.store_buffer(image.get_data())
	file.close()
	_put("pending-first-line.json", {"format": image.get_format(), "size": [image.get_width(),image.get_height()], "bytes": image.get_data().size(), "hdr_2d": viewport.use_hdr_2d, "context": Story.current_presentation_context(), "actor_source": _actor().state_key(), "text": Story._player._dialogue._text.text, "name": Story._player._dialogue._name.text, "renderer": RenderingServer.get_current_rendering_method(), "adapter": RenderingServer.get_video_adapter_name()})
	_check(preload("res://tools/viewport_capture.gd").encode(image, viewport.use_hdr_2d).save_png(_save_dir.path_join("pending-first-line.png")) == OK, "encode the same persisted raw with canonical helper")

func _node_state(node: Node) -> Dictionary:
	if not is_instance_valid(node):
		return {"valid": false}
	var script := node.get_script() as Script
	var result := {"valid": true, "class": node.get_class(), "script": script.resource_path if script != null else "", "name": String(node.name), "inside": node.is_inside_tree(), "path": str(node.get_path()) if node.is_inside_tree() else "(unparented)", "queued": node.is_queued_for_deletion()}
	if node is Level:
		var level := node as Level
		result["level_path"] = level.data.resource_path if level.data != null else ""
		result["initialized"] = level.is_initialized()
		result["resumed_completed"] = level.get("_resumed_presentation_completed")
		result["resumed_settled"] = level.get("_resumed_presentation_settled")
	return result

func _runtime_state(raw: Variant) -> Dictionary:
	if not raw is Dictionary:
		return {"type": typeof(raw)}
	var value: Dictionary = raw
	return {"empty": value.is_empty(), "level": value.get("level", ""), "cinematic": value.get("cinematic", ""), "context": value.get("cinematic_context", {}), "layout_revision": value.get("layout_revision", 1), "position": value.get("position", []), "health": value.get("health", -1)}

func _sample(label: String) -> void:
	if _states.size() >= 8:
		return
	var actor := _actor()
	var actor_state := {"present": actor != null}
	if actor != null:
		actor_state["source_id"] = actor.state_key()
		actor_state["cell"] = [actor.cell.x, actor.cell.y]
		actor_state["talking"] = actor.get("_talking")
		actor_state["talk_index"] = actor.get("_presentation_index")
		actor_state["talks"] = actor.talk_count
		actor_state["data"] = actor.data.resource_path
	var store := _main.get("_run_store") as RunSaveStore
	_states.append({"label": label, "ticks_metadata_only": Time.get_ticks_msec(), "screen": _node_state(_main.get("_screen") as Node), "pending_screen": _node_state(_main.get("_pending_screen") as Node), "continue_data": _runtime_state(_main.get("_continue_data")), "resume_runtime": _runtime_state(_main.get("_resume_runtime")),
		"main": {"route_pending": _main.call("_route_pending"), "active_run": _main.get("_active_run"), "level_path": _main.get("_level_path"), "cinematic": _main.get("_cinematic"), "context": _main.get("_cinematic_context"), "request": _main.get("_cinematic_request"), "restore_publish_pending": _main.get("_restore_publish_pending"), "publishing_restore": _main.get("_publishing_restore"), "publishing_results": _main.call("_publishing_results"), "destination_pending": _main.get("_destination_pending"), "save_queued": _main.get("_save_queued")},
		"story": {"active": Story.is_cinematic_active(), "scene": String(Story._current_cinematic), "request": Story.current_presentation_request(), "context": Story.current_presentation_context(), "heard": GameState.has_flag(&"ch1_heard_brief"), "dinner": GameState.has_flag(&"ch1_dinner_done")}, "actor": actor_state, "tree_paused": get_tree().paused, "gameplay_locked": GameplayLock.is_locked(), "store_issues": Array(store.issues) if store != null else []})

