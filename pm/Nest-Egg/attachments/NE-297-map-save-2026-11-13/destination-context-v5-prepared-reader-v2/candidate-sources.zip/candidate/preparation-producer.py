from pathlib import Path
import hashlib,json,subprocess,difflib
C=Path('C:/Users/stanl/Github/Nest-Egg');D=Path('D:/NestEggVerification/ne294-generator-foundation-20261113');P=Path(__file__).resolve().parent
FILES=['core/run_destination.gd','core/run_snapshot.gd','tests/helpers/map_layout_migration_checks.gd']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before=P/'before';assert not before.exists();before.mkdir()
for n in FILES:
    q=before/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((D/n).read_bytes())
(P/'before-manifest.json').write_text(json.dumps({n:sha(D/n) for n in FILES},indent=2)+'\n',encoding='utf8')
s=(D/FILES[0]).read_text(encoding='utf8')
start=s.index('\tvar area := {"consumed": {}, "damage": {}, "world": {}}')
end=s.index('\tentry["world"] = ',start)
s=s[:start]+'''	# A fresh destination entry belongs to its own map revision, never the source room's.
	var source_revision: Variant = entry.get("layout_revision", 1)
	if not RunSaveCodec.valid_version(source_revision) or source_revision > 2:
		return {"error": "run/runtime/layout_revision：不支援的來源修訂；原存檔保留"}
	var definition := MapLayoutMigration.read(destination)
	if definition.has("error"):
		return definition
	var id := String(destination.id)
	var prior: Variant = state["area_states"].get(id, {"consumed": {}, "damage": {}, "world": {}})
	if not prior is Dictionary:
		return {"error": "run/state/area_states/%s：必須是物件" % id}
	var migrated := MapLayoutMigration.area(prior, definition)
	if migrated.has("error"):
		return migrated
	var checkpoint_here: bool = state["has_checkpoint"] and (str(state["checkpoint_level_path"]).is_empty() or state["checkpoint_level_path"] == path)
	if checkpoint_here and prior.get("layout_revision", 1) != definition["revision"]:
		var checkpoint := MapLayoutMigration.checkpoint(state["checkpoint_world"], RunSaveCodec.vector(state["checkpoint_position"]), definition, LevelBuilder.parse(destination))
		if checkpoint.has("error"):
			return checkpoint
		state["checkpoint_world"] = checkpoint["world"]
		var at: Vector2 = checkpoint["position"]
		state["checkpoint_position"] = [at.x, at.y]
	var area: Dictionary = migrated["data"] if destination.persistent_world else MapLayoutMigration.area({}, definition)["data"]
	if not destination.persistent_world and checkpoint_here:
		area["world"] = state["checkpoint_world"].duplicate(true)
	# Keep checkpoint metadata and the saved area in the same revision so reads cannot translate twice.
	if destination.persistent_world or definition["revision"] > 1:
		state["area_states"][id] = area.duplicate(true)
	if definition["revision"] > 1:
		entry["layout_revision"] = definition["revision"]
	else:
		entry.erase("layout_revision")
'''+s[end:]
(D/FILES[0]).write_text(s,encoding='utf8',newline='\n')
s=(D/FILES[1]).read_text(encoding='utf8')
needle='\tif relocated:\n\t\t_reset_location(result)'
assert s.count(needle)==1
s=s.replace(needle,'''	if relocated:
		var source_revision: Variant = result["runtime"].get("layout_revision", 1)
		if not RunSaveCodec.valid_version(source_revision) or source_revision > 2:
			return {"error": "run/runtime/layout_revision：不支援的來源修訂；原存檔保留"}
		_reset_location(result)''')
needle='for key in ["loose", "enemies", "encounters", "encounter_members_version"]:'
assert s.count(needle)==1
s=s.replace(needle,'for key in ["loose", "enemies", "encounters", "encounter_members_version", "layout_revision"]:')
(D/FILES[1]).write_text(s,encoding='utf8',newline='\n')
s=(D/FILES[2]).read_text(encoding='utf8')
needle='\tawait _direct_level(suite, data, old, runtime)'
assert s.count(needle)==1
s=s.replace(needle,'\t_destination_entries(suite, data, old)\n'+needle)
addition='''

static func _entry_runtime(revision: int) -> Dictionary:
	var area := {"consumed": {}, "damage": {}, "world": {}}
	var result := {"position": [-1, -1], "velocity": [0, 0], "health": 4, "loadout": {}, "area": area, "world": {}, "enemies": [], "loose": [], "encounters": {}, "encounter_members_version": preload("res://game/level/encounter_snapshot.gd").MEMBERS_VERSION}
	if revision > 1:
		area["layout_revision"] = revision
		result["layout_revision"] = revision
	return result


static func _destination_entries(suite: TestSuite, revised: LevelData, old_area: Dictionary) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	var producer := preload("res://core/run_destination.gd")
	var owners := var_to_bytes([GameState._install_source(), Progression.snapshot(), StoryItems.snapshot()])
	for source_revision: int in [1, 2]:
		for target: String in [revised.resource_path, "res://data/levels/level_01.tres"]:
			var original := RunSnapshot.capture(target, _entry_runtime(source_revision))
			var untouched := original.duplicate(true)
			var prepared: Dictionary = producer.prepare(original, target)
			suite.check(prepared.has("data") and original == untouched, "destination revision %d to %s prepares a copy" % [source_revision, target])
			if not prepared.has("data"):
				continue
			var entry: Dictionary = prepared["data"]["runtime"]
			var expected := 2 if target == revised.resource_path else 1
			suite.check(entry.get("layout_revision", 1) == expected and entry["area"].get("layout_revision", 1) == expected and entry["position"] == [-1, -1], "fresh destination runtime and area use the target revision without moving the entrance sentinel")
			var checked := RunSnapshot.prepare(prepared["data"])
			suite.check(checked.has("data") and checked["data"]["runtime"]["position"] == [-1, -1], "actual run reader preserves the fresh destination entry rather than applying legacy relocation")
			if checked.has("data"):
				suite.check(RunSnapshot.prepare(checked["data"]).get("data") == checked["data"], "destination run preparation is idempotent")
	var original := RunSnapshot.capture(revised.resource_path, _entry_runtime(2))
	original["state"]["area_states"][String(revised.id)] = old_area.duplicate(true)
	original["state"]["has_checkpoint"] = true
	original["state"]["checkpoint_level_path"] = revised.resource_path
	original["state"]["checkpoint_position"] = [72, 304]
	original["state"]["checkpoint_world"] = {"gate@17,18": true}
	var untouched := original.duplicate(true)
	var migrated: Dictionary = producer.prepare(original, revised.resource_path)
	suite.check(migrated.has("data") and original == untouched, "destination area and checkpoint migration leaves the original source snapshot unchanged")
	if migrated.has("data"):
		var ready: Dictionary = migrated["data"]
		var area: Dictionary = ready["runtime"]["area"]
		suite.check(area["consumed"].has("health@200,816") and area["world"].has("gate@17,50") and ready["state"]["area_states"][String(revised.id)] == area, "destination runtime and persistent area preserve the same migrated rewards and mechanisms")
		suite.check(ready["state"]["checkpoint_world"].has("gate@17,50") and not ready["state"]["checkpoint_world"].has("gate@17,18"), "cross-area checkpoint world is migrated before its revision marker advances")
		var again: Dictionary = producer.prepare(ready, revised.resource_path)
		suite.check(again.has("data") and again["data"]["state"]["checkpoint_world"] == ready["state"]["checkpoint_world"] and again["data"]["state"]["checkpoint_position"] == ready["state"]["checkpoint_position"] and again["data"]["runtime"]["area"] == area, "preparing the destination again never moves checkpoint or rewards twice")
	for invalid: Variant in [3, true, 1.5]:
		var broken := original.duplicate(true)
		broken["state"]["area_states"][String(revised.id)]["layout_revision"] = invalid
		var before := broken.duplicate(true)
		suite.check(producer.prepare(broken, revised.resource_path).has("error") and broken == before, "invalid destination revision %s refuses without changing the original" % str(invalid))
	var conflict := original.duplicate(true)
	conflict["state"]["area_states"][String(revised.id)]["world"] = {"gate@8,18": false, "gate@10,18": true}
	suite.check(producer.prepare(conflict, revised.resource_path).has("error"), "destination migration cannot overwrite colliding durable mechanism keys")
	var future_source := original.duplicate(true)
	future_source["runtime"]["layout_revision"] = 3
	suite.check(producer.prepare(future_source, revised.resource_path).has("error"), "a future source revision is not erased by a destination reset")
	var missing := RunSnapshot.capture(revised.resource_path, _entry_runtime(2))
	missing["level"] = "res://data/levels/no_such_level_ne297.tres"
	var recovered := RunSnapshot.prepare(missing)
	suite.check(recovered.has("data") and recovered["data"]["level"] == CampaignEdition.current().first_level and recovered["data"]["runtime"]["health"] == 4 and recovered["data"]["runtime"].get("layout_revision", 1) == recovered["data"]["runtime"]["area"].get("layout_revision", 1), "missing revision2 area safely falls back without carrying its stale runtime revision")
	missing["runtime"]["layout_revision"] = 3
	suite.check(RunSnapshot.prepare(missing).has("error"), "unknown future runtime stays refused even when its old area resource is missing")
	suite.check(owners == var_to_bytes([GameState._install_source(), Progression.snapshot(), StoryItems.snapshot()]), "destination and fallback preparation never install changes into live owners")
'''
s+=addition
(D/FILES[2]).write_text(s,encoding='utf8',newline='\n')
old=json.loads((C/'work/ne297-candidate-v4/manifest.json').read_text(encoding='utf8'))
files=dict(old['files']);files['core/run_destination.gd']=sha(D/'core/run_destination.gd')
for n in FILES:files[n]=sha(D/n)
out=C/'work/ne297-candidate-v5';assert not out.exists();out.mkdir()
manifest={'base':old['base'],'tree':str(D),'files':files,'note':'Unexecuted destination/fallback revision producer correction; preserves strict reader, entrance sentinel, source snapshot, checkpoint and owners. Original v4 and changed-v1 red retained. No engine run.'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
diff=''
for n in FILES:
    a=(before/n).read_text(encoding='utf8');b=(D/n).read_text(encoding='utf8');diff+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='before/'+n,tofile='candidate/'+n))
(P/'candidate.diff').write_text(diff,encoding='utf8',newline='\n')
(P/'proposal.json').write_text(json.dumps({'status':'unexecuted; no Godot/parser permitted yet','changed_files':{n:{'before':sha(before/n),'after':sha(D/n)} for n in FILES},'candidate_count':len(files),'candidate_manifest':str(out/'manifest.json'),'root_causes':['source revision remains on fresh destination while area comes from a different revision','legacy destination preparation is incorrectly interpreted as old geometry and moves [-1,-1] entrance sentinel','missing-level fallback resets area but retains stale source layout_revision'],'callers':['Main._on_area_requested','Main._on_retry_requested persistent/nonpersistent','Main._enter_next_level','SkipCompletion._prepare_route','RunSnapshot.prepare missing-level fallback'],'new_controls':'source1/2 to target1/2; reader idempotence; persistent reward/health keys; cross-area checkpoint once; bad boolean/fraction/future area/source revisions; colliding mechanism keys; missing revision2/future source; no live owner installation','expected_additional_diagnostics':'Two deliberate missing-level fallback warnings through the existing RunSnapshot behavior; no filter modified'},indent=2)+'\n',encoding='utf8')
print(json.dumps({'candidate':str(out/'manifest.json'),'count':len(files),'changed':FILES,'engine_started':False},indent=2))
