extends "res://tests/smoke_test.gd"
func _run() -> void:
    Enemy.activation_culling_enabled = false
    Story.auto_skip = true
    GameState.story_autosave = false
    GameState.start_new_run(GameState.difficulties[1])
    preload("res://tests/helpers/story_result_plan_checks.gd").run(EconomySuite.new(self))
    await preload("res://tests/helpers/map_layout_migration_checks.gd").run(RunSaveSuite.new(self))
    await _finish()
