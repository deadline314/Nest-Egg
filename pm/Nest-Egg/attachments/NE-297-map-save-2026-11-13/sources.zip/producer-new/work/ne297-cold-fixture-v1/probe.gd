extends "res://tools/quest_resume_probe.gd"
# Arranged save fixture, not a natural campaign or NPC receipt replay.
const AREA_PATH := "res://data/levels/ch1_warehouse.tres"

func _write() -> void:
    GameState.story_autosave = false
    Story.auto_skip = true
    GameState.start_new_run(GameState.difficulties[1])
    _check(StoryItems.acquire(&"ch1_data_disk", false), "arranged legacy fixture includes the real owned and held story item")
    GameState.set_flag(&"ledger_disk_obtained")
    Progression.add_credits(17)
    var data := load(AREA_PATH) as LevelData
    var layout := LevelBuilder.parse(data)
    var area := {"consumed": {}, "damage": {}, "world": {}}
    var enemies := 0
    var consumed := 0
    for spawn: Dictionary in layout.spawns:
        var resource: Resource = spawn["resource"]
        var cell: Vector2i = spawn["cell"]
        var key := "%s@%d,%d" % [resource.get("id"), cell.x, cell.y]
        if resource is EnemyData:
            if enemies == 0: area["consumed"][key] = true
            elif enemies == 1: area["damage"][key] = 1
            enemies += 1
        elif consumed < 2 and (resource is CreditPileData or resource is ConsumableData or resource is StoryItemData or resource is WeaponData):
            area["consumed"][key] = true
            consumed += 1
    if not layout.health_pickups.is_empty():
        var feet: Vector2 = layout.health_pickups[0]
        area["consumed"]["health@%d,%d" % [roundi(feet.x), roundi(feet.y)]] = true
    GameState.area_states[String(data.id)] = area
    _check(not layout.checkpoints.is_empty(), "old authored area has an actual checkpoint")
    if layout.checkpoints.is_empty(): return
    GameState.has_checkpoint = true
    GameState.checkpoint_level_path = AREA_PATH
    GameState.checkpoint_position = layout.checkpoints[0]
    GameState.checkpoint_progress = Progression.snapshot()
    var level := Level.new()
    level.configure(data)
    add_child(level)
    for actor in level._entities.get_children():
        if actor is Enemy: actor.set_physics_process(false)
    level.player.set_physics_process(false)
    level.set_process(false)
    await _settle(3)
    level.player.health.current = 4
    var nav := QuestMapState.for_run()
    nav.reveal(AREA_PATH, [Vector2i(floori(layout.player_start.x / data.tile_size), ceili(layout.player_start.y / data.tile_size) - 1), Vector2i(77, 16)])
    nav.activate(AREA_PATH, layout.checkpoints[0], data.tile_size)
    var snapshot := RunSnapshot.capture(AREA_PATH, level.run_snapshot())
    _check(not snapshot["runtime"].has("layout_revision") and not snapshot["navigation"].has("layout_revisions"), "old real Level capture contains no new revision stamps")
    var store: RunSaveStore = _main.get("_run_store")
    _check(store.write(snapshot), "old source writes the complete save atomically through its real validator")
    var file := FileAccess.open(_save_dir.path_join("expect.json"), FileAccess.WRITE)
    _check(file != null, "old capture expectation is writable")
    if file != null:
        file.store_string(JSON.stringify(snapshot, "\t"))
        file.close()
    level.queue_free()
    await _settle(3)
    _completed = true

func _continue() -> void:
    get_window().mode = Window.MODE_WINDOWED
    get_window().size = Vector2i(1280, 720)
    var old: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(_save_dir.path_join("expect.json")))
    await _press_continue(AREA_PATH)
    var level := _level()
    if level == null: return
    var migration: Variant = load("res://core/navigation/map_layout_migration.gd")
    var definition: Dictionary = migration.read(level.data)
    _check(definition.get("revision") == 2 and level.is_initialized(), "new Main cold continue installs the actual revised map")
    var moved: Dictionary = migration.area(old["state"]["area_states"]["ch1_warehouse"], definition)
    for key: String in moved["data"]["consumed"]:
        _check(level._area["consumed"].has(key), "consumed state survives cold read: " + key)
    for key: String in moved["data"]["damage"]:
        var actor := level._tracked.get(key) as Enemy
        _check(actor != null and actor.lost_health() == int(moved["data"]["damage"][key]), "actual enemy damage survives cold read: " + key)
    var nav := QuestMapState.for_run()
    for key: String in old["navigation"]["explored"][AREA_PATH]:
        var translated: String = migration.explored_key(key, definition)
        _check(nav.explored.get(AREA_PATH, {}).has(translated), "fog cell survives cold read: " + key)
    for key: String in old["navigation"]["activated"]:
        _check(nav.activated.has(migration.checkpoint_key(key, definition)), "phone activation survives cold read: " + key)
    _check(GameState.has_flag(&"ledger_disk_obtained") and level.player.has_air_jump(), "saved ability flag and real Player capability agree after cold continue")
    _check(StoryItems.holds(&"ch1_data_disk") and StoryItems.snapshot()["held"].size() == old["story"]["items"]["held"].size(), "cold continue retains existing item custody without duplication")
    _check(Progression.credits == 17, "cold continue preserves arranged credits without paying again")
    _check(level.player.health.current == 4, "cold continue preserves actual saved health")
    _check(level._layout.fits_body(level.player.position, Player.BODY_SIZE), "new entrance contains the real player body without a solid overlap")
    _check(nav.issues.is_empty(), "cold navigation restore reports no lost valid state")
    await RenderingServer.frame_post_draw
    var raw := get_viewport().get_texture().get_image()
    _check(raw.get_size() == Vector2i(1280, 720) and raw.get_format() == Image.FORMAT_RGBH and not raw.has_mipmaps(), "cold continuation captures actual native 1280x720 HDR image")
    if raw.get_size() == Vector2i(1280, 720) and raw.get_format() == Image.FORMAT_RGBH:
        var binary := FileAccess.open(_save_dir.path_join("continued.rgbh"), FileAccess.WRITE)
        binary.store_buffer(raw.get_data())
        binary.close()
        preload("res://tools/viewport_capture.gd").encode(raw, get_viewport().use_hdr_2d).save_png(_save_dir.path_join("continued.png"))
        var metadata := {"size": [raw.get_width(), raw.get_height()], "format": raw.get_format(), "bytes": raw.get_data().size(), "hdr_2d": get_viewport().use_hdr_2d,
            "player": [level.player.position.x, level.player.position.y], "checkpoint": [GameState.checkpoint_position.x, GameState.checkpoint_position.y], "layout_revision": definition["revision"],
            "world": GameState.checkpoint_world, "window": [get_window().size.x, get_window().size.y], "navigation": nav.snapshot()}
        var receipt := FileAccess.open(_save_dir.path_join("continued.json"), FileAccess.WRITE)
        receipt.store_string(JSON.stringify(metadata, "\t"))
        receipt.close()
    _completed = true
