extends RefCounted

const FIXTURE := "res://tests/fixtures/map_revision_2.tres"
const TEST_PATH := "res://data/levels/ne297_test_only.tres"


static func run(suite: TestSuite) -> void:
	var data := (load(FIXTURE) as LevelData).duplicate(false) as LevelData
	data.take_over_path(TEST_PATH)
	var definition := MapLayoutMigration.read(data)
	suite.check(not definition.has("error") and definition.get("revision") == 2, "authored layout revision reads without changing the save format (%s)" % definition)
	if definition.has("error"):
		data.take_over_path("")
		return
	var old := {"consumed": {"grunt@14,18": true, "pistol@16,18": true, "health@200,304": true},
		"damage": {"grunt@8,18": 1}, "world": {"switch@6,18": true, "gate@17,18": true}}
	var untouched := old.duplicate(true)
	var moved := MapLayoutMigration.area(old, definition)
	suite.check(old == untouched and moved.has("data"), "area migration prepares a copy without mutating the old save")
	if not moved.has("data"):
		data.take_over_path("")
		return
	var area: Dictionary = moved["data"]
	suite.check(area["consumed"].has("grunt@14,50") and area["consumed"].has("pistol@16,50"), "consumed actors and weapon rewards keep their new spawn keys")
	suite.check(area["consumed"].has("health@200,816") and not area["consumed"].has("health@200,336"), "built-in health keys move pixel feet rather than pretending to be cells")
	suite.check(area["damage"].get("grunt@10,50") == 1 and area["world"].get("gate@17,50") == true, "explicit spawn overrides preserve damage and mechanism state")
	suite.check(MapLayoutMigration.area(area, definition).get("data") == area, "a second preparation never translates already migrated keys again")
	suite.check(MapLayoutMigration.spawn_key("npc:doctor@3,18", definition) == "npc:doctor@3,50", "NPC namespace and talk history retain their actor identity")
	suite.check(MapLayoutMigration.checkpoint_key(TEST_PATH + "@4,19", definition) == TEST_PATH + "@4,51", "activated checkpoints use surface rows, not spawn rows")
	suite.check(MapLayoutMigration.explored_key("4,18", definition) == "4,50", "explored cells use grid coordinates")
	suite.check(MapLayoutMigration.spawn_key("grunt@4294967300,18", definition) == "grunt@4294967300,18", "oversized cell keys cannot wrap through Vector2i into another actor")
	suite.check(MapLayoutMigration.spawn_key("health@4294967496,304", definition) == "health@4294967496,304", "oversized pixel keys cannot wrap into a real collected health pickup")
	var conflict := MapLayoutMigration.keys({"gate@8,18": false, "gate@10,18": true}, definition)
	suite.check(conflict.has("error"), "conflicting migrated keys refuse instead of silently overwriting durable state")
	var future := old.duplicate(true)
	future["layout_revision"] = 3
	suite.check(MapLayoutMigration.area(future, definition).has("error"), "unknown future area revisions preserve the original save")
	var runtime := {"position": [200, 304], "velocity": [10, -20], "health": 4, "area": old, "world": old["world"],
		"enemies": [{"snapshot_id": "enemy:0", "resource": "res://data/enemies/grunt.tres", "key": "grunt@8,18", "position": [136, 304], "lost": 1}],
		"loose": [{"kind": "credit", "value": 7, "position": [280, 304]}], "encounters": {}, "encounter_members_version": preload("res://game/level/encounter_snapshot.gd").MEMBERS_VERSION}
	var layout := LevelBuilder.parse(data)
	var migrated := MapLayoutMigration.runtime(runtime, data, layout)
	suite.check(migrated.has("data") and runtime["position"] == [200, 304], "runtime migration leaves its source unmodified")
	if migrated.has("data"):
		var ready: Dictionary = migrated["data"]
		suite.check(ready["position"] == [40.0, 816.0] and ready["velocity"] == [0, 0], "old player positions return to a safe entrance in the same area")
		suite.check(ready["enemies"][0]["key"] == "grunt@10,50" and ready["enemies"][0]["snapshot_id"] == "enemy:0" and ready["enemies"][0]["lost"] == 1, "alive enemy identities and health loss survive re-anchoring")
		suite.check(ready["enemies"][0]["position"] == [168.0, 816.0], "moving enemies use their actual new authored spawn")
		suite.check(ready["loose"][0]["value"] == 7 and ready["loose"][0]["position"] == ready["position"], "uncollected loose rewards remain reachable without changing their value")
		suite.check(MapLayoutMigration.runtime(ready, data, layout).get("data") == ready, "runtime preparation is idempotent")
		suite.check(not preload("res://game/level/encounter_snapshot.gd").prepare(ready, data, layout).has("error"), "strict encounter membership still validates the migrated real spawn")
	var catalog := QuestCatalog.new()
	var maps := QuestMapIndex.new()
	maps.add_area(data)
	var navigation := QuestMapState.new()
	navigation.restore({"version": 1, "pinned_id": "", "explored": {TEST_PATH: {"4,18": true}}, "activated": {TEST_PATH + "@4,19": true}}, catalog, maps)
	suite.check(navigation.knows(TEST_PATH, Vector2i(4, 50)) and navigation.activated.has(TEST_PATH + "@4,51"), "old navigation and phone activations follow their actual new cells")
	var saved := navigation.snapshot()
	navigation.restore(saved, catalog, maps)
	suite.check(navigation.knows(TEST_PATH, Vector2i(4, 50)) and navigation.issues.is_empty(), "saved layout revisions prevent navigation from moving twice")
	await _direct_level(suite, data, old, runtime)
	await _rejection_is_atomic(suite, data, future, false)
	await _rejection_is_atomic(suite, data, {}, true)
	GameState.start_new_run(GameState.difficulties[1])
	data.take_over_path("")


static func _direct_level(suite: TestSuite, data: LevelData, old: Dictionary, runtime: Dictionary) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	GameState.area_states[String(data.id)] = old.duplicate(true)
	var level := Level.new()
	level.configure(data)
	var resume := runtime.duplicate(true)
	resume["loose"] = []
	level.configure_resume(resume)
	suite.runner.get_tree().root.add_child(level)
	for actor in suite.runner.get_tree().get_nodes_in_group(&"enemies"):
		if level.is_ancestor_of(actor):
			actor.set_physics_process(false)
	await suite.frames(3)
	var ready := is_instance_valid(level.player) and level._initialization_complete
	suite.check(ready, "direct Level resumes use the same migration before spawning actors")
	if not ready:
		await suite.end_level(level)
		return
	suite.check(level.player.health.current == 4, "direct resume retains actual saved player health")
	suite.check(level._area["consumed"].has("health@200,816"), "direct resume keeps the already collected health marker")
	var health_count := 0
	var weapon_count := 0
	for node in level._entities.get_children():
		health_count += 1 if node is HealthPickup else 0
		weapon_count += 1 if node is WeaponPickup else 0
	suite.check(health_count == 0 and weapon_count == 0, "already collected health and weapons are not spawned again")
	suite.check(level._tracked.has("grunt@10,50") and not level._tracked.has("grunt@14,50"), "alive and killed enemy state stays distinct after direct resume")
	var enemy := level._tracked.get("grunt@10,50") as Enemy
	suite.check(enemy != null and enemy.lost_health() == 1, "actual resumed enemies retain saved damage")
	await suite.end_level(level)


static func _rejection_is_atomic(suite: TestSuite, data: LevelData, previous: Dictionary, bad_checkpoint: bool) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	GameState.current_level_path = "preserved_previous_level"
	GameState.pending_portal = &"preserved_pending_portal"
	if not previous.is_empty():
		GameState.area_states[String(data.id)] = previous.duplicate(true)
	if bad_checkpoint:
		GameState.has_checkpoint = true
		GameState.checkpoint_level_path = data.resource_path
		GameState.checkpoint_position = Vector2(72, 304)
		GameState.checkpoint_world = {"gate@8,18": false, "gate@10,18": true}
	var before := {"areas": GameState.area_states.duplicate(true), "world": GameState.checkpoint_world.duplicate(true), "position": GameState.checkpoint_position}
	var level := Level.new()
	level.configure(data)
	suite.runner.get_tree().root.add_child(level)
	await suite.frames(2)
	suite.check(level.player == null and not level._initialization_complete, "refused migration never builds a partial live player")
	suite.check(GameState.current_level_path == "preserved_previous_level" and GameState.pending_portal == &"preserved_pending_portal", "refused migration cannot change the live route or consume its pending portal")
	suite.check(GameState.area_states == before["areas"] and GameState.checkpoint_world == before["world"] and GameState.checkpoint_position == before["position"], "refused area or checkpoint preparation leaves all durable dictionaries untouched")
	await suite.end_level(level)
