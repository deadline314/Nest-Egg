class_name QuestMapState
extends RefCounted
## 僅保存導覽狀態，不保存或推進故事。主流程可把 snapshot 放入既有存檔。

signal changed

const VERSION := 1
static var _shared: QuestMapState
static var _run_areas: Dictionary
var pinned_id := ""
var explored: Dictionary = {}
var activated: Dictionary = {}
var revision := 0
## 地形只依各區探索變化失效；釘選與復原點不會改變地形。
var _exploration_revisions: Dictionary = {}
var _restore_revision := 0
var issues := PackedStringArray()
## Definitions share this run lifetime; every UI receives its own mutable copy.
var _source_catalog: QuestCatalog
var _catalog_paths: Array[String] = []


static func for_run() -> QuestMapState:
	# 新遊戲會建立新的 area_states；死亡、重試與章節切換沿用同一份。
	if _shared == null or not is_same(_run_areas, GameState.area_states):
		_run_areas = GameState.area_states
		_shared = QuestMapState.new()
	return _shared


## Story reload is the existing source-change boundary, including language reloads.
static func invalidate_catalog() -> void:
	if _shared != null:
		_shared._source_catalog = null
		_shared._catalog_paths.clear()


func catalog_copy(paths: Array[String] = Story.CHAPTER_PATHS) -> QuestCatalog:
	if _source_catalog == null or _catalog_paths != paths:
		_source_catalog = null
		_catalog_paths.clear()
		var loaded := QuestCatalog.new()
		loaded.load_story_sources(paths)
		if not loaded.issues.is_empty():
			return loaded  # Rejected loads remain retryable, with their original path issues.
		_source_catalog = loaded
		_catalog_paths = paths.duplicate()
	var result := QuestCatalog.new()
	result.quests.assign(_source_catalog.quests.duplicate(true))
	result.issues = _source_catalog.issues.duplicate()
	return result


func pin(id: String, catalog: QuestCatalog) -> void:
	pinned_id = id if not catalog.find(id).is_empty() else ""
	_touch()


func target(catalog: QuestCatalog, chapter: String, flags: Dictionary) -> Dictionary:
	var pinned := catalog.find(pinned_id)
	if not pinned.is_empty() and pinned["chapter"] == chapter and QuestCatalog.all_flags(pinned.get("visible_flags", []), flags) and QuestCatalog.status(pinned, flags) != "completed":
		return pinned
	for quest in catalog.list_for(chapter, "main", false, flags):
		if QuestCatalog.status(quest, flags) == "active":
			return quest
	return {}


func reveal(path: String, cells: Array[Vector2i]) -> void:
	if not explored.has(path):
		explored[path] = {}
	var dirty := false
	for cell in cells:
		var key := "%d,%d" % [cell.x, cell.y]
		if not explored[path].has(key):
			explored[path][key] = true
			dirty = true
	if dirty:
		_exploration_revisions[path] = exploration_revision(path) + 1
		_touch()


func exploration_revision(path: String) -> int:
	return int(_exploration_revisions.get(path, _restore_revision))


func knows(path: String, cell: Vector2i) -> bool:
	return explored.get(path, {}).has("%d,%d" % [cell.x, cell.y])


func activate(path: String, position: Vector2, tile: int) -> void:
	var key := "%s@%d,%d" % [path, int(position.x / tile), int(position.y / tile)]
	if not activated.has(key):
		activated[key] = true
		_touch()


func snapshot() -> Dictionary:
	var result := {"version": VERSION, "pinned_id": pinned_id, "explored": explored.duplicate(true), "activated": activated.duplicate(true)}
	var paths: Dictionary = {}
	for path: String in explored:
		paths[path] = true
	for key: String in activated:
		paths[key.get_slice("@", 0)] = true
	var versions: Dictionary = {}
	for path: String in paths:
		var data := RunSaveCodec.resource(path, "level", "res://data/levels/") as LevelData
		if data != null:
			var definition := MapLayoutMigration.read(data)
			if not definition.has("error") and definition["revision"] > 1:
				versions[path] = definition["revision"]
	if not versions.is_empty():
		result["layout_revisions"] = versions
	return result


func restore(raw: Variant, catalog: QuestCatalog, maps: QuestMapIndex, notify := true) -> void:
	# 讀檔可把探索倒退；即使格數一樣也必須失效。
	_restore_revision = revision + 1
	_exploration_revisions.clear()
	pinned_id = ""
	explored.clear()
	activated.clear()
	issues.clear()
	if not raw is Dictionary or raw.get("version") != VERSION:
		issues.append("navigation.version: 格式不符，改用預設導覽狀態。")
	else:
		var id: Variant = raw.get("pinned_id", "")
		if id is String and (id.is_empty() or not catalog.find(id).is_empty()):
			pinned_id = id
		else:
			issues.append("navigation.pinned_id: 找不到任務，改為追蹤主線。")
		var versions: Variant = raw.get("layout_revisions", {})
		var valid_versions := versions is Dictionary
		if not valid_versions:
			issues.append("navigation.layout_revisions: 修訂表無效，改用未探索狀態。")
		var areas: Variant = raw.get("explored", {}) if valid_versions else {}
		if areas is Dictionary:
			for path: Variant in areas:
				if not path is String or not maps.areas.has(path) or not areas[path] is Dictionary:
					issues.append("navigation.explored.%s: 無效區域，已略過。" % str(path))
					continue
				var layout: LevelLayout = maps.areas[path]["layout"]
				var migration := _map_migration(path, versions, maps)
				if migration.has("error"):
					issues.append(migration["error"])
					continue
				for key: Variant in areas[path]:
					var mapped: Variant = MapLayoutMigration.explored_key(key, migration["definition"]) if key is String and migration["needed"] else key
					var cell := _parse_cell(mapped, layout)
					if cell != Vector2i(-1, -1) and areas[path][key] == true:
						if not explored.has(path):
							explored[path] = {}
						explored[path][mapped] = true
					else:
						issues.append("navigation.explored.%s.%s: 無效格座標，已略過。" % [path, key])
		else:
			issues.append("navigation.explored: 必須是物件，改用未探索狀態。")
		var points: Variant = raw.get("activated", {}) if valid_versions else {}
		if points is Dictionary:
			for key: Variant in points:
				var mapped: Variant = key
				if key is String:
					var path: String = key.get_slice("@", 0)
					if maps.areas.has(path):
						var migration := _map_migration(path, versions, maps)
						if migration.has("error"):
							issues.append(migration["error"])
							continue
						if migration["needed"]:
							mapped = MapLayoutMigration.checkpoint_key(key, migration["definition"])
				if key is String and points[key] == true and maps.checkpoint_keys.has(mapped):
					activated[mapped] = true
				else:
					issues.append("navigation.activated.%s: 找不到存檔點，已略過。" % str(key))
		else:
			issues.append("navigation.activated: 必須是物件，改用未啟用狀態。")
	for issue in issues:
		push_warning("[QuestMap] %s" % issue)
	if notify:
		_touch()
	else:
		revision += 1


static func _map_migration(path: String, versions: Dictionary, maps: QuestMapIndex) -> Dictionary:
	var definition := MapLayoutMigration.read(maps.areas[path]["data"])
	if definition.has("error"):
		return definition
	var version: Variant = versions.get(path, 1)
	if not RunSaveCodec.valid_version(version) or version > definition["revision"]:
		return {"error": "navigation.layout_revisions.%s: 不支援的版面修訂，改用未探索狀態。" % path}
	return {"definition": definition, "needed": version != definition["revision"]}


static func _parse_cell(key: Variant, layout: LevelLayout) -> Vector2i:
	if not key is String:
		return Vector2i(-1, -1)
	var parts: PackedStringArray = key.split(",")
	if parts.size() != 2 or not parts[0].is_valid_int() or not parts[1].is_valid_int():
		return Vector2i(-1, -1)
	var cell := Vector2i(int(parts[0]), int(parts[1]))
	return cell if cell.x >= 0 and cell.y >= 0 and cell.x < layout.width and cell.y < layout.height else Vector2i(-1, -1)


func _touch() -> void:
	revision += 1
	changed.emit()
