from pathlib import Path
import argparse,hashlib,json,msvcrt,os,re,subprocess,sys,time,urllib.error,urllib.request
ROOT=Path('C:/Users/stanl/Github/Nest-Egg');TREE=Path('D:/NestEggVerification/ne296-aerial-jump-20261113')
p=argparse.ArgumentParser();p.add_argument('epoch');p.add_argument('--kind',choices=['old-write','new-read'],required=True);a=p.parse_args()
if a.kind=='new-read':TREE=Path('D:/NestEggVerification/bg20-bg21-native-review-20261113')
OUT=ROOT/'work/ne297-runtime'/a.epoch;OUT.mkdir(parents=True,exist_ok=False)
def save(n,v):(OUT/n).write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def sources():
 names=subprocess.check_output(['git','ls-files','-z'],cwd=TREE).decode().split('\0')
 names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=TREE).decode().split('\0')
 return {n:sha(TREE/n) for n in sorted(set(names)) if n and (TREE/n).is_file() and (n=='project.godot' or n.startswith(('work/ne297-cold-fixture-v1/',)) or n.split('/')[0] in {'art','audio','autoload','core','data','game','scenes','tests','tools','ui'})}
def queues():
 rows=[];opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 for port in [8188,8189]:
  try:
   with opener.open(f'http://127.0.0.1:{port}/queue',timeout=3) as response:raw=response.read()
   v=json.loads(raw);assert isinstance(v['queue_running'],list) and isinstance(v['queue_pending'],list)
   rows.append({'port':port,'state':'empty' if not v['queue_running'] and not v['queue_pending'] else 'busy','running':len(v['queue_running']),'pending':len(v['queue_pending']),'response_sha256':hashlib.sha256(raw).hexdigest()})
  except urllib.error.URLError as e:rows.append({'port':port,'state':'refused' if getattr(e.reason,'winerror',None)==10061 else 'unknown'})
  except Exception as e:rows.append({'port':port,'state':'unknown','error':type(e).__name__})
 return rows
def clear(q):return len(q)==2 and q[0]['state']=='empty' and q[1]['state'] in ['empty','refused']
guardpath=ROOT/'work/ne296-adoption-v1/c-native-context-v29.json';assert sha(guardpath)=='a3df1f1a2c27952545453a3d1b8a422a42755deddcc86088a70c1dc62e1d81d0'
guard=json.loads(guardpath.read_bytes())['files'];assert len(guard)==463 and all(sha(ROOT/n)==v for n,v in guard.items())
before=sources();save('source-before.json',before);save('c-before.json',guard)
save('git-source.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=TREE).decode().strip(),'diff':subprocess.check_output(['git','diff','--binary'],cwd=TREE).decode()})
env=os.environ.copy();env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
for key in ['APPDATA','LOCALAPPDATA','USERPROFILE','TMP','TEMP']:
 env[key]=str(OUT/'userdata'/key);Path(env[key]).mkdir(parents=True,exist_ok=True)
godot='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
argv=[godot,'--path',str(TREE)]+(['--headless'] if a.kind=='old-write' else ['--windowed','--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan'])+['res://work/ne297-cold-fixture-v1/probe.tscn','--','--mode='+('write' if a.kind=='old-write' else 'continue'),'--save-dir='+str(ROOT/'work/ne297-runtime/cold-save-v3')]
save('command.json',{'argv':argv,'cwd':str(TREE),'environment':{k:env[k] for k in ['APPDATA','LOCALAPPDATA','USERPROFILE','TMP','TEMP','PYTHONUTF8']},'kind':a.kind})
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
outer=queues();save('outer-queue-before.json',outer)
if not clear(outer):save('blocked.json',{'engine_started':False,'reason':'busy/unknown queues; no lock acquired'});print('BLOCKED; no engine started');sys.exit(3)
sys.path.insert(0,str(ROOT/'tools/comfyui'));import comfy_guard
assert comfy_guard.LOCK_PATH==ROOT/'assets_src/work/comfy.lock'
lock=open(comfy_guard.LOCK_PATH,'a+b');held=False;started=False;code=None;error=None;begin=time.monotonic()
try:
 lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1);held=True
 inner=queues();save('inner-queue-before.json',inner);assert clear(inner)
 assert sources()==before and all(sha(ROOT/n)==v for n,v in guard.items())
 with (OUT/'engine.log').open('wb') as log:
  child=subprocess.Popen(argv,cwd=TREE,env=env,stdout=log,stderr=subprocess.STDOUT);started=True;save('process.json',{'pid':child.pid,'argv':argv})
  try:code=child.wait(timeout=1800 if a.kind=='changed' else 300)
  except subprocess.TimeoutExpired:
   r=subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(OUT/'owned-timeout.log').write_bytes(r.stdout);child.wait(timeout=30);raise
except Exception as e:error=repr(e)
finally:
 save('inner-queue-after.json',queues())
 if held:lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
 lock.close();save('outer-queue-after.json',queues())
after=sources();save('source-after.json',after);save('c-after.json',{n:sha(ROOT/n) for n in guard})
raw=(OUT/'engine.log').read_text(encoding='utf-8',errors='replace') if started else ''
diags=[l for l in raw.splitlines() if re.search(r'ERROR:|SCRIPT ERROR|WARNING:|ObjectDB.*leak|RID allocations.*leaked|resources still in use at exit',l)]
added=sorted(set(after)-set(before));changed=sorted(n for n in set(before)&set(after) if before[n]!=after[n]);removed=sorted(set(before)-set(after))
sourceok=before==after or (a.kind=='import' and not changed and not removed and all(n.endswith('.uid') for n in added))
queueok=started and all(clear(json.loads((OUT/n).read_bytes())) for n in ['outer-queue-before.json','inner-queue-before.json','inner-queue-after.json','outer-queue-after.json'])
receipt={'kind':a.kind,'started':started,'exit_code':code,'error':error,'seconds':round(time.monotonic()-begin,3),'source_count':len(before),'source_exact':before==after,'added':added,'changed':changed,'removed':removed,'c_unchanged':all(sha(ROOT/n)==v for n,v in guard.items()),'all_four_queue_gates':queueok,'diagnostics':diags,'accepted':code==0 and error is None and sourceok and queueok and not diags and all(sha(ROOT/n)==v for n,v in guard.items())}
save('receipt.json',receipt);print(json.dumps(receipt,ensure_ascii=False,indent=2));sys.exit(0 if receipt['accepted'] else 1)
