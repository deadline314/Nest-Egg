extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")


func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var fixed := args.has("--fixed-test")
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	Enemy.activation_culling_enabled = false
	var suite := StrikeEnemiesSuite.new(self)
	for extend_stop in [false, true]:
		var enemy := await suite._setup("chain_hook", 110.0)
		var player := suite.level.player
		var hp := player.health.current
		_check(await suite.wait_state(enemy, &"reel", 500), "authored hook enters reel")
		_check(player.is_pulled() and hp - player.health.current == 1, "hook begins an authentic pull and takes one health")
		if extend_stop:
			# Hold the actual player and hook through a deterministic clock overlap.
			Fx.freeze([player, enemy], 0.26)
		var x0 := player.global_position.x
		var started := Time.get_ticks_msec()
		if fixed:
			_check(await suite.call("_wait_for_pull_steps", player, 10), "sees 10 steps of the real pull timer")
		else:
			await suite.physics_frames(10)
		var move := player.global_position.x - x0
		print("HOOK_RECEIPT extended=", extend_stop, " wall_ms=", Time.get_ticks_msec() - started,
			" move=", move, " frozen=", Fx.is_frozen(player), " pull_left=", player._pull_left)
		_check(move > 4.0, ("extended stop" if extend_stop else "natural hit") + ": the pull moves the player toward the hook owner")
		for arg: String in args:
			if extend_stop and arg.begins_with("--image="):
				await RenderingServer.frame_post_draw
				_check(Capture.image(get_viewport()).save_png(arg.trim_prefix("--image=")) == OK, "native hook scene captured")
		var link := enemy.get("_link") as Hurtbox
		_check(is_instance_valid(link), "link remains live for the counterattack")
		if is_instance_valid(link):
			link.receive(suite.hit())
		await suite.physics_frames(2)
		_check(not player.is_pulled() and enemy.is_stunned(), "breaking the active chain releases the real pull")
		await suite._finish(enemy)
	await _finish()
