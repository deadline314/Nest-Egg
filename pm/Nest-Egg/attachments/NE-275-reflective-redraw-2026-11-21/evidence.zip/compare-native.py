from hashlib import sha256
from pathlib import Path
import json

from PIL import Image, ImageChops

base=Path(__file__).resolve().parent
expected={"blade","dagger","glaive","maul","whip","fallback","restored"}
checks={}
for quality,stock in (("high","stock"),("low","stock-low")):
    tags=(stock,"final-"+quality)
    records=[]
    for tag in tags:
        assert (base/(tag+".exit")).read_text().strip()=="0"
        log=(base/(tag+".log")).read_text(encoding="utf-8")
        assert "Forward+" in log and "AMD Radeon RX 9070 XT" in log
        assert not any(line.startswith(("SCRIPT ERROR:","ERROR:")) for line in log.splitlines())
        report=json.loads((base/tag/"reflective.json").read_bytes())
        assert report["failures"]==0 and report["hdr_2d"] and report["quality"]==quality
        assert set(report["records"])==expected
        records.append(report["records"])
    before,after=records
    assert all(row["base_draws"]==row["parent_draws"]==row["physics"]==120 for row in before.values())
    images={}
    for name in expected:
        prior=before[name]
        live=after[name]
        assert live["textured"]==prior["textured"]==(name!="fallback")
        assert live["physics"]==live["parent_draws"]==120
        assert live["base_draws"]==(0 if live["textured"] else 120)
        assert live["initial_grip"]==prior["initial_grip"] and live["final_grip"]==prior["final_grip"]
        sources=[base/tag/(name+"-idle.png") for tag in tags]
        exact=sha256(sources[0].read_bytes()).digest()==sha256(sources[1].read_bytes()).digest()
        frames=[Image.open(path).convert("RGB") for path in sources]
        difference=ImageChops.difference(*frames).getbbox()
        images[name]={"byte_equal":exact,"difference_bounds":difference}
    checks[quality]={"stock":before,"candidate":after,"frames":images}
(base/"visual-verification.json").write_text(json.dumps(checks,indent=2)+"\n",encoding="utf-8")
for quality,row in checks.items():
    print(quality,row["frames"])
