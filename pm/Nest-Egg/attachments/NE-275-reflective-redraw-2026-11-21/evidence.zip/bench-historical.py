from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import re
import subprocess
import sys

current=Path.cwd()
evidence=Path(__file__).resolve().parent
historical=evidence.parent/"ne275-historical-perf-20261121"
old_rev="a42eaa524ea406e3b81c77ccc30208769c6b3a1f"
godot="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
weapons=("blade","dagger","glaive","maul","whip")
subject="game/player/melee_held.gd"


def git(root,*args):
    return subprocess.check_output(["git",*args],cwd=root)


assert git(historical,"rev-parse","HEAD").decode().strip()==old_rev
assert not git(historical,"diff","--name-only")
assert (evidence/"historical-import.exit").read_text().strip()=="0"
expected=(evidence/"melee-held-final.gd.txt").read_bytes()
assert (current/subject).read_bytes()==expected
assert git(current,"branch","--show-current").decode().strip()=="codex/ticket-work-20261121-reflective-redraw"
new_rev=git(current,"rev-parse","HEAD").decode().strip()


def run(tag,root):
    inspect=root/subject
    expected_code=expected if root==current else None
    if expected_code is not None:
        assert inspect.read_bytes()==expected_code
    folder=evidence/("historical-timing-"+tag)
    folder.mkdir()
    env=os.environ.copy()
    for key in ("APPDATA","LOCALAPPDATA","XDG_DATA_HOME","XDG_CONFIG_HOME","TEMP","TMP","TMPDIR"):
        dest=evidence/("timing-current-profile" if root==current else "timing-old-profile")/key
        dest.mkdir(parents=True,exist_ok=True)
        env[key]=str(dest)
    command=[sys.executable,"-B",str(current/"tools/comfyui/gpu_lock.py"),"--",godot,"--path",str(root),
             "--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy",
             "--resolution","1280x720","--quit-after","22000",str(evidence/"timing.tscn"),"--",
             "--out="+str(folder),"--tag="+tag,"--quality=high","--perf"]
    (folder/"command.json").write_text(json.dumps(command,indent=2)+"\n")
    with (folder/"raw.log").open("wb") as output:
        result=subprocess.run(command,env=env,stdout=output,stderr=subprocess.STDOUT,cwd=root,timeout=180)
    assert result.returncode==0,(tag,result.returncode)
    raw=(folder/"raw.log").read_text(encoding="utf-8")
    assert re.search(r"Forward\+.*9070 XT",raw)
    errors=[line for line in raw.splitlines() if re.match(r"^(?:SCRIPT )?ERROR:",line)]
    if errors:
        cutoff=raw.index("NE275_HISTORIC_TIMING:")
        assert root==historical and all(re.fullmatch(r"ERROR: \d+ resources still in use at exit .+",line)
                                       and raw.index(line)>cutoff for line in errors),(tag,errors)
    metrics=json.loads((folder/"grip-timings.json").read_bytes())
    assert metrics["resolution"]==[1280,720] and metrics["renderer"]=="forward_plus"
    assert metrics["vsync"]==metrics["max_fps"]==metrics["failures"]==0
    assert not metrics["reduced_flashes"] and not metrics["reduced_ui_motion"]
    assert set(metrics["records"])==set(weapons)
    timing={}
    for weapon,row in metrics["records"].items():
        samples=sorted(row["samples_ms"])
        assert row["drawn"] and row["dedicated_attachment"]==(root==current) and row["scene_draw_calls"]>0
        assert row["physics_steps"]>=10 and len(samples)==600 and min(samples)>0
        timing[weapon]={"p50":median(samples),"p99":samples[593]}
    print(tag,{k:round(v["p50"],4) for k,v in timing.items()},flush=True)
    return timing


run("before-warm",historical)
run("after-warm",current)
trials=[]
for i in range(1,11):
    order=("before","after") if i%2 else ("after","before")
    samples={name:run(f"{name}-{i:02d}",historical if name=="before" else current) for name in order}
    trials.append({"order":order,"samples":samples})
assert (current/subject).read_bytes()==expected
assert git(current,"rev-parse","HEAD").decode().strip()==new_rev
assert git(historical,"rev-parse","HEAD").decode().strip()==old_rev
data={}
for weapon in weapons:
    data[weapon]={}
    for metric in ("p50","p99"):
        before=[t["samples"]["before"][weapon][metric] for t in trials]
        after=[t["samples"]["after"][weapon][metric] for t in trials]
        paired=[100*(a/b-1) for a,b in zip(after,before,strict=True)]
        data[weapon][metric]={"reference_ms":median(before),"current_ms":median(after),
                              "median_percent":median(paired),"all_pair_percent":paired}
(evidence/"historical-summary.json").write_text(json.dumps({"baseline":old_rev,"parent":new_rev,
    "product_sha256":sha256(expected).hexdigest(),"result":data,"trials":trials},indent=2)+"\n")
print(json.dumps(data,indent=2),flush=True)
