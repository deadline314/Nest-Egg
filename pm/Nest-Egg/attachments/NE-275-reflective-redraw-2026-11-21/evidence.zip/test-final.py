from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys

root=Path.cwd()
base=Path(__file__).resolve().parent
relative=Path("game/player/melee_held.gd")
path=root/relative
stock=path.read_bytes()
assert stock==(base/"melee-held-stock.gd.txt").read_bytes()
old=b"\t_base_sprite.queue_redraw()"
where=b"\t\t_base_sprite.transform = Transform2D.IDENTITY"
end=b"\r\n" if b"\r\n" in stock else b"\n"
assert stock.count(old)==stock.count(where)==1
candidate=stock.replace(old+end,b"").replace(where,where+end+b"\t\t_base_sprite.queue_redraw()")
(base/"melee-held-final.gd.txt").write_bytes(candidate)
path.write_bytes(candidate)
try:
    for tag, patch in (("final-high",candidate), ("stock-low",stock), ("final-low",candidate)):
        assert path.read_bytes() in (stock,candidate)
        path.write_bytes(patch)
        env=os.environ.copy()
        profile=base/(tag+"-profile")
        profile.mkdir()
        env["APPDATA"]=str(profile)
        q=tag.split("-")[-1]
        command=[sys.executable,"-B",str(root/"tools/comfyui/gpu_lock.py"),"--",
                 "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(root),
                 "--fixed-fps","60","--resolution","1280x720","--audio-driver","Dummy",str(base/"reflective.tscn"),
                 "--","--out="+str(base/tag),"--quality="+q,"--perf"]
        with (base/(tag+".log")).open("wb") as log:
            run=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
        (base/(tag+".exit")).write_text(str(run.returncode)+"\n",encoding="ascii")
        assert run.returncode==0,tag
    (base/"final-variant-source.json").write_text(json.dumps({"path":relative.as_posix(),
        "stock":sha256(stock).hexdigest(), "final":sha256(candidate).hexdigest()},indent=2)+"\n")
finally:
    assert path.read_bytes() in (stock,candidate)
    path.write_bytes(stock)
print("Restored the baseline after the three native renderer captures.")
