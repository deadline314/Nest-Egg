from pathlib import Path
import json
import shutil
import subprocess

current=Path.cwd()
base=Path(__file__).resolve().parent
expected=Path("D:/NestEggVerification/ne275-historical-perf-20261121")
worktree=expected.resolve(strict=True)
repo_store=base.parent.resolve(strict=True)
assert worktree==expected and worktree.parent==repo_store
receipt=json.loads((base/"historical-summary.json").read_bytes())
assert len(receipt["trials"])==10
old=receipt["baseline"]
assert old=="a42eaa524ea406e3b81c77ccc30208769c6b3a1f"


def git(root,*args):
    return subprocess.check_output(["git",*args],cwd=root)


listed=git(current,"worktree","list","--porcelain").decode("utf-8")
expected_item=f"worktree {worktree.as_posix()}\nHEAD {old}\ndetached\n"
assert expected_item in listed
assert git(worktree,"rev-parse","HEAD").decode().strip()==old
assert not git(worktree,"status","--porcelain","--untracked-files=no")
generated=[Path(p) for p in git(worktree,"ls-files","--others","--exclude-standard","-z").decode().split("\0") if p]
store=(base/"historical-generated").resolve()
assert store.parent==base
for item in generated:
    assert not item.is_absolute() and ".." not in item.parts and item.suffix in {".uid",".import"}
    original=worktree/item
    assert original.resolve(strict=True)==original and original.is_file() and not original.is_symlink()
    assert not (store/item).exists()
for item in generated:
    destination=store/item
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.move(worktree/item,destination)
assert not git(worktree,"status","--porcelain","--untracked-files=all")
subprocess.run(["git","worktree","remove",str(worktree)],cwd=current,check=True)
assert not worktree.exists()
assert f"worktree {worktree.as_posix()}\n" not in git(current,"worktree","list","--porcelain").decode("utf-8")
(base/"historical-worktree-cleanup.json").write_text(json.dumps({"path":worktree.as_posix(),"head":old,
    "generated":[p.as_posix() for p in generated],"removed":True},indent=2)+"\n")
print("Removed the verified detached benchmark worktree.")
