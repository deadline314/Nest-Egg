# NE-267：S08租攤窗口與實際蓋章私有交接

本單位可供root採用與正式回歸，尚未提交或發布。所有寫入僅在本證據目錄與獨立runtime；沒有修改主checkout、共享D樹或票。獨立runtime絕對路徑：`D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118/runtime-ownership-v7`，依root要求暫保留，由root決定清理。此runtime仍含舊guest_chen實驗，**不得整樹覆蓋或採用任何guest_chen檔案**。

## 最小採用

**只採 `adoption-v2/` 的29檔**，逐檔原始/candidate SHA與大小在 `adoption-v2-manifest.json`，最小文字diff在 `adoption-v2.diff`，實際主線原始bytes在 `before-v2/`。這份before來自 `7258c940873ef4b63c4e3f565745070df0ceea97`，不是遭拒的V6袖片。舊 `adoption/` 28檔缺活動合成範例同步，已被v2取代，保留追溯。

29檔包括：

- `tools/story/ch2_source.py`、`ch2_stages.py`：將首訪與回訪接到同一正式Frame，只新增兩筆FORMAL_FRAMES與一個Stage；原作者台詞、結果和dispatcher原位保留。
- 新 `tools/story/rent_window_staging.py`：只負責此窗口的分層、座面、真手持章、落章、印記、放回及解除reach；使用既有actor/reach/prop_hold/prop_visible/prop_release/sfx，不新增generic能力。
- `data/story/ch2_heron.json`、新 `data/cutscene/stages/ch2_rent_window.json`：正式來源重建。
- `data/story_contracts/ch2.json`：只改 `ch2_t_s08_contract.rule.mode` 為animated。回訪原本就是animated overlay，此次改正式舞台，不是再改結果契約。
- `tests/fixtures/story_contracts_data_only/ch2.json`：活動合成作者範例的同一筆mode同步。該source.py明記Synthetic author content；不是封存原始fixtures。若不做此同步，既有19項Python契約測試中，活動範例以新spec搭舊mode會真實拒收。
- 新 `tools/story/test_ch2_rent_window_staging.py` 六項必要斷言。
- 新 `tools/assets/build_rent_window_contacts.py`、`assets_src/pipeline/rent_window_contacts.json` 與receipt：受限原素材切件及來源SHA。
- 九個PNG與九個`.png.import`，僅在 `art/environment/scene_props/rent_window_contacts/`。

結構差集已驗證：只有兩個S08 scene的呈現欄位變更（首訪lines/mode/pose_policy/steps；回訪overlay/pose_policy/steps），其餘188場、全章其餘欄位、原三句與回訪中/日/英對白、when/results/completion_policy、交易與dispatcher完全一致。既有data僅上述故事與正式catalog兩檔有差；沒有其他生成漂移。96個人物零件、portrait、rig、motion及結果框架/封存來源guard逐檔相同，詳細清單在manifest；`migration-5a.json`、兩份 `story_result_*_originals.json`、通用validator未改。

## 素材與接觸

無新生整人、無模型生成、無GPU生成。沿用既有window_clerk、Rin、窗口原圖、正常尺寸辦公椅、S18已存在平放紙張、原Noto字型及既有mat_wood音效。原窗口308×504不改；其印章依限定polygon裁出49×53。原位印章只以同原圖相鄰44×51原材質區塊移除；其外全部RGBA不變。窗口back/front夾住演員，工作區開口露出手與桌面；紙上印記為「暫未核准」。

`source-contact-pixels.json` 保存已核對的不透明來源像素：手(68,22) alpha254；椅墊(158,163) alpha245；章柄(23,12)/章底(23,50)/紙面(48,43)皆alpha255。各位置採pixel centre，無以透明空白當接點。

`asset-selfcheck-v1/receipt.json` 四項CPU來源自檢全過：同像素九PNG重跑保持bytes/mtime、損毀來源拒收且不碰既有輸出、任一不同既有輸出先驗拒收且整套不改寫、移除fixture輸出後重建九張逐RGBA完全相同。原始素材沒有覆寫；這些自檢只操作自己的小fixture。

## CPU與真Main結果

`cpu-final-v1/receipt.json`：正式故事builder，以及六項S08、19項既有獨立契約、六項完成policy測試皆實際EOF0；重建後正式三份生成JSON的SHA不變。原19項在活動合成範例未同步前的mode拒收已定位，未修改generic或封存來源繞過。

`persistence-v1/receipt.json` 三個真正Main/NPC程序均EOF0、0診斷，總26項：

1. 主線原版dialogue S08，從真NPC `_talk()` 開始；未完成時由Main原writer寫出真正pending-primary，完成後另存真正completed-primary（6項）。沒有手造結果旗標或直接塞物品。
2. 逐byte拷貝原pending檔，以新Frame冷讀、完成並回訪；item與flag各發布一次，counter只在完成後落定，回訪無再發布（11項）。
3. 逐byte拷貝原完成檔，以新Frame冷讀不重播結果，真NPC回訪無新item/flag，控制鎖釋放（9項）。

冷讀輸入SHA：pending `e11d06f2a3fb001d0b35afde0a9714c27e6c1769e3da97bd513e9ff3bf5cf2c5`；完成 `e2a3d11d3958c0869d05f3cb9c854aecac3198aa7f919d4cbcb37f1aa79e29e0`。原始完整檔在該資料夾original-slot/。兩份私有故事資料的原版交換皆try/finally復原，主線bytes始終保持。此三案使用既有 `_finish_story()` 的正常略過入口；完整自然呈現的取樣另列，不能代稱真人遊測。

另外沿**未修改的既有** `tests/probes/ch2_evidence_completion.gd` 只跑contract accepted與accepted_read兩案，均實際EOF0、0diagnostics、37＋7項通過，證據在 `existing-accepted-v1/receipt.json`。此路用ui_accept完成新Frame，不呼叫略過；第一次真IO拒收不授物，重試原子寫入成功才發布一次item/flag，兩個發布時刻皆核對磁碟完整checksum、三份world counter與live facts一致，後續冷讀保持。沒有改原探針、沒有改契約門檻，來源SHA保持。

## 原生證據與限制

最終取樣 **`native-prop-normals-v3/`**：RX9070XT、Forward+ Vulkan、640×360，實際EOF0、0ERROR、私有來源hash保持。九張PNG及對應原生float raw、raw格式/HDR/sha在captures/result.json；三句原對白完整顯示，首訪坐姿/持章/落章/放回/收手及回訪各有取樣。

- 111次原生真掌心/章柄接觸樣本，最大誤差0.0000682394 stagepx；沿既有0.25門檻。
- 印記出現時仍真手持，章底與紙面來源點重合。紙張材質落於桌面，解除手持後原章放回。
- 兩腳材質底至地板約+0.33 stagepx；臀部實際deformed UV材質至真椅墊約−0.7173～−0.2496 stagepx，沿原1px門檻。沒有調pose、骨長或閾值。
- window_clerk各可見零件的真正CanvasTexture diffuse/normal逐張記錄；章、紙、印記、椅的原生diffuse/normal也逐張記錄。實際import部分半解析度（章24×26、印記48×48、椅122×165），source_width保留原畫布對應。
- `native-v3-all9.png` 為九圖全色QA並排，已逐張檢視；`native-v2-contact-detail-v2.png` 是同素材先一輪的放大接觸QA；`asset-nine-three-backgrounds.png` 九張黑/灰/白底均已檢視。這些QA不是新美術來源。
- `native-original-before-v2/` 是原版真Main/NPC首句完整對白與raw，實際EOF0。`before-after-context.png` 明記before真Main原相機、after正式Frame視覺observer各自相機，**不是同相機像素差分**。首版before等待不足而只截到半句，已保留但不作完整字幕驗收。
- `native-first/` 保留首輪五個座面失敗：當時把椅墊位置誤估302.6。經原椅圖放大網格確認實際不透明頂面(158.5,163.5)對應300.04後，僅修資料與observer座面來源對應；v2及v3原生通過，沒有把容差放寬。`chair-material-grid.png` 保留來源證據。

視覺observer直接播放正式CutscenePlayer，使用合成台詞推進，**不經Story結果owner**；結果由上面真Main另驗。這裡不宣稱全角色、所有關節、所有過渡或實體手把驗收完成，也不把0ERROR當全美術驗收。椅子與下半身被正式前窗遮擋，支撐是實際UV/不透明來源量測；紙本在櫃台上，未新增Rin拿取紙本的動畫。音效使用Dummy，未做真人聽感驗收。

## 重跑與採用順序

root先依29檔manifest核對before後個別採入，跑受影響/正式88組與整合後必要原生；不要整樹拷貝。主線合入後builder與六項測試直接可跑；來源自檢入口 `check_asset_rebuild.py` 使用私有fixture。觀察者已在各原生資料夾封存精確source/command，不可把較新的observer冒稱當時source。

私有重跑：`run_probe_revision.py --name <新目錄>`、`run_persistence.py --name <新目錄>`、`run_native_before.py --name <新目錄>`。後兩者已改為固定讀本交接before-v2並鎖定兩份原始SHA，所以root日後合入新Frame也仍能重建舊控制；只暫換私有runtime，finally還原。所有Godot命令均沿主checkout的共享gpu_lock，未啟停或更動ComfyUI。

根目錄規範要求的 `design/00-vision/director-notes.md` 實際不存在，已回報root；已依AGENTS及scene-staging/continuity-qa/rig-animation/free-asset-pipeline等適用技能執行。
