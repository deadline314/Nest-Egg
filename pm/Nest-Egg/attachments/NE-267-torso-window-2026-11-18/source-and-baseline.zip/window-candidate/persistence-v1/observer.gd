extends "res://tests/probes/ch2_evidence_completion.gd"
## 真Main/NPC的原始pending-primary與完成存檔控制；只使用隔離slot。
const EVIDENCE := &"ch2_evidence_contract"
const TARGET := &"ch2_t_s08_contract"
const REVISIT := &"ch2_t_s08_contract_revisit"
var _notice_counts := [0, 0]

func _notices() -> void:
	StoryItems.acquired.connect(func(item: StoryItemData) -> void:
		if item.id == EVIDENCE:
			_notice_counts[0] += 1
			StoryItems.mark_seen(item.id))
	GameState.flag_changed.connect(func(id: StringName, _value: Variant) -> void:
		if id == EVIDENCE: _notice_counts[1] += 1)

func _run() -> void:
	_main = load("res://game/main.gd").new()
	_store = RunSaveStore.new(_save_dir.path_join("slot.json"))
	_main.set("_run_store", _store)
	add_child(_main)
	await _frames(8)
	if _mode == "write_original":
		_check(Story._scenes[String(TARGET)].mode == "dialogue", "writer uses the unchanged original dialogue presentation")
		_main.call("_on_start_requested", GameState.difficulties[1])
		await _frames(90)
		await _finish_story()
		await _wait_control()
		_main.call("_on_area_requested", "res://data/levels/ch2_market.tres")
		await _frames(12)
		await _finish_story()
		await _wait_control()
		var npc := _evidence_actor()
		_check(npc != null, "real original market evidence object exists")
		if npc == null: await _done(); return
		_player().global_position = npc.global_position + Vector2(-32, 0)
		_player().set_physics_process(false)
		_notices()
		var done := [false]
		var talk := func() -> void:
			await npc._talk()
			done[0] = true
		talk.call()
		for i in 300:
			if Story._current_cinematic == TARGET: break
			await _frames(1)
		_check(Story._current_cinematic == TARGET and not StoryItems.holds(EVIDENCE), "genuine original S08 reading is pending before its result")
		_main.call("_save_run")
		var pending := FileAccess.get_file_as_bytes(_store.path)
		var saved: Dictionary = RunSaveCodec.decode(pending.get_string_from_utf8()).get("data", {})
		_check(saved.get("cinematic") == String(TARGET) and not GameState.has_flag(EVIDENCE), "true original primary stores unread S08 without granting evidence")
		FileAccess.open(_save_dir.path_join("pending-primary.json"), FileAccess.WRITE).store_buffer(pending)
		await _finish_story()
		for i in 300:
			if done[0] and npc.talk_count == 1: break
			await _frames(1)
		_check(done[0] and npc.talk_count == 1 and StoryItems.holds(EVIDENCE) and GameState.has_flag(EVIDENCE), "original completion installs its evidence exactly once")
		_check(_notice_counts == [1, 1], "original completion publishes one item and one flag")
		_main.call("_save_run")
		FileAccess.open(_save_dir.path_join("completed-primary.json"), FileAccess.WRITE).store_buffer(FileAccess.get_file_as_bytes(_store.path))
		await _done()
		return
	_main.call("_on_continue_requested")
	for i in 300:
		if _level() != null and _level().is_initialized(): break
		await _frames(1)
	await _frames(12)
	_check(Story._scenes[String(TARGET)].mode == "animated", "cold reader uses the new formal S08 Frame")
	var npc := _evidence_actor()
	_check(npc != null and _level().data.resource_path == "res://data/levels/ch2_market.tres", "cold original bytes restore the same market object")
	if npc == null: await _done(); return
	_notices()
	if _mode == "read_pending":
		_check(Story._current_cinematic == TARGET and npc.talk_count == 0, "old pending-primary resumes original unread S08 with unsettled counter")
		_check(not StoryItems.holds(EVIDENCE) and not GameState.has_flag(EVIDENCE), "resuming pending evidence does not grant it before completion")
		await _finish_story()
		for i in 300:
			if npc.talk_count == 1 and not Story.is_cinematic_active(): break
			await _frames(1)
		_check(StoryItems.holds(EVIDENCE) and GameState.has_flag(EVIDENCE) and Story._completed.has(TARGET) and npc.talk_count == 1, "resumed new Frame completes the same original result once")
		_check(_notice_counts == [1, 1], "resumed result publishes one item/flag only")
	elif _mode == "read_completed":
		_check(StoryItems.holds(EVIDENCE) and GameState.has_flag(EVIDENCE) and Story._completed.has(TARGET) and npc.talk_count == 1, "old completed-primary stays completed under the new Frame")
		_check(Story._current_cinematic != TARGET and _notice_counts == [0, 0], "old completed result is not replayed or published again")
	else:
		_check(false, "known isolated reader mode")
	var notices_before := _notice_counts.duplicate()
	var count := npc.talk_count
	_check(Story.resolve_dispatch(npc.data.talks[0].scene) == REVISIT, "completed original dispatcher offers the unchanged revisit")
	_player().global_position = npc.global_position + Vector2(-32, 0)
	_player().set_physics_process(false)
	var revisited := [false]
	var visit := func() -> void:
		await npc._talk()
		revisited[0] = true
	visit.call()
	for i in 300:
		if Story._current_cinematic == REVISIT: break
		await _frames(1)
	_check(Story._current_cinematic == REVISIT, "real original object enters the new seated revisit")
	await _finish_story()
	for i in 300:
		if revisited[0]: break
		await _frames(1)
	_check(revisited[0] and npc.talk_count == count + 1, "ordinary revisit settles only its ordinary talk counter")
	_check(_notice_counts == notices_before and StoryItems.holds(EVIDENCE) and GameState.has_flag(EVIDENCE), "revisit does not republish or duplicate the original evidence")
	_check(not get_tree().paused and not GameplayLock.is_locked(), "new Frame and cold revisit release their own control locks")
	await _done()
