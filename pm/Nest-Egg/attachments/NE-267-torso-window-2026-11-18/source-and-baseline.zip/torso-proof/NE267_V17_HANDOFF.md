# NE-267 軀幹原圖補回 V17 交接

可採用的範圍是陳女士軀幹來源局部改善。尚有 280 個原有接點失敗，全部保留於 `retained-failures-280.json`，不可將這份交接寫成整角色、S19實景或真人驗收完成。

## 修改與採用

基準是 main `7258c940873ef4b63c4e3f565745070df0ceea97` 原始袖片與軀幹；未沿用已拒收的 V6 袖片。

`adoption/` 僅9個檔案。`adoption-manifest.json` 保存每檔 main 原值SHA、候選SHA與位元組數；最後封裝再次核對 main 原值，全部相符。採用前請再核對 manifest；不可複製整個私有 runtime/cache。

- 遊戲只換 `art/characters/guest_chen/parts/torso.png` 與 `torso_n.png`。
- 配方只加 `source_rebuilds: ["art_src/characters/guest_chen_torso_20261118/rebuild.py"]`，最小差異見 `recipe.diff`。
- 新來源目錄含 `.gdignore`、`approved_torso.png`、`claim-mask.png`、`provenance.json`、`rebuild.py`、`self_check.py`。
- `overrides/refined/torso.png` 由 callback 原bytes發布，是衍生產物，不在9檔交付中。
- 不改 generic 工具、spec、骨架、角色定義、動作、其他零件、checker或門檻。

## 來源與原因

V6 新增44例（坐站42、敲擊2）全在zoom3.7。補袖片外緣會把原先開放缺口包成封閉1像素孔；有36例閉孔與8例邊緣缺口。診斷保留於本工作目錄的 `new44-details.json`、`new44-source-locations.json`、原生原圖頁與幾何trace；不是憑總失敗數挑選。

V17 不改袖片；補回原始軀幹左右既有材料間被漏切的長槽。白色遮罩只標3,009個來源像素，來源bbox `[370,397,422,533]`（右下為exclusive）。每個補點取同一張 `base_rgba.png` 的原RGBA，沒有合成人物或新生成材料。原不透明來源、遮罩外像素、每一來源列的左右外側界限均逐像素保持。這不宣稱所有內側輪廓保持：原漏切槽的內側界線就是修補範圍。

來源仍1024×1536；切件仍233×302，pivot `(117.1,278.8)`、affine/取樣格與原版完全相同。原圖SHA `d5db7c3a6a417c8bdd4f3aa53e81e65a2fd8f589029ccc3cf7f7f7bf925e96f2`。批准來源PNG SHA `d1d69dac350bcd677e6d5a1299e43ba9d738f94e1be8e01132beb6ff61b48178`。

## 已實際完成的原生驗證

Godot4.7.2、RX9070XT、Forward+、Vulkan；每次通過共享GPU鎖，APPDATA/LOCALAPPDATA/XDG均私有。120格、左右朝向、zoom1與3.7、seat_sag0.298。五種NPC坐姿表演及坐下/站起、靠牆、蹲、敲擊；四個肩肘接點加neck/waist。

完整sample key逐筆相同；28,800 keys，2,700→280，修復2,420，保留280，新增0。

| 動作組 | keys | 原失敗 | 候選失敗 | 修復 | 新增 |
|---|---:|---:|---:|---:|---:|
| 五種坐姿表演 | 14400 | 544 | 12 | 532 | 0 |
| 坐下與站起 | 5760 | 668 | 24 | 644 | 0 |
| 靠牆 | 2880 | 166 | 116 | 50 | 0 |
| 蹲 | 2880 | 648 | 0 | 648 | 0 |
| 敲擊 | 2880 | 674 | 128 | 546 | 0 |

`joint-comparison-28800.json` 保存分組與完整原生資料路徑，`fixed-keys-2420.json` 與 `retained-failures-280.json` 保存差集。所有正式原生程序exit0、0SCRIPT ERROR與0ERROR；保留失敗的原checker仍exit1，只有無失敗的蹲組exit0；沒有加入known exemption。

16張640×360原生全色PNG（前後×兩頁NPC動作×左右×明暗）及command/raw log保存在 `../colors/`。四張1280×772 contact page均已實際看過，保持1:1原圖、不重取樣；身份、年齡特徵、衣服、手腕與其他件保持，未見新增肢體、材料凸出或重複袖片。既有靠牆/敲擊等細小缺口仍保留原始失敗紀錄。來源黑/灰/白審視圖 `source-review-nearest3.png` 為明確標示的nearest×3診斷，不是原生截圖。

Normal由既有 `NormalMapMaker` 實際生成；9件生成後其他8件bytes保持。`../normal-binding-scene/result.json` 另以原CharacterRig建立角色，核對torso實際CanvasTexture normal通道、res路徑、233×302與diffuse/normal原檔SHA：normal `83249579ad906c84995ab37345c08cadaa1dd3320e4f372d9f732b3e59138a32`，diffuse `3ec9b72533d45b5390cb023f92e362a23a117c25add33e49de3b03caa8fccc26`。

## CPU 可重建契約

`cpu-proof.json`：實際自檢、callback兩次及完整重新切件均exit0。11項重新切件結果（9個diffuse+character+rig）除了本次torso候選，其餘與main內容完全一致。重新切件torso PNG原bytes等於交付貼圖。

callback沿用既有 `registered_layer_bytes`：重建RGBA逐像素驗證批准PNG後，發布批准PNG原始bytes，不呼叫PNG encoder重編碼。自檢patch encoder強制丟錯仍成功；損毀批准PNG、來源變更、spec內容變更與不同既有輸出均拒收，不截斷/覆寫既有輸出。相同輸出重跑mtime保持。JSON/Python輸入只將CRLF轉LF後核對，其餘內容與PNG必須精確原bytes。保留原14個輸入版本守衛，沒有改正規工具。

主專案採用後可用既有Python：

```powershell
D:/ComfyUI/.venv-rocm/Scripts/python.exe -B -X utf8 art_src/characters/guest_chen_torso_20261118/self_check.py --scratch D:/NestEggVerification/evidence-20261117/ne267-transitions-20261118/v17-torso/formal-hook
D:/ComfyUI/.venv-rocm/Scripts/python.exe -B -X utf8 art_src/characters/guest_chen_torso_20261118/rebuild.py
```

## 保留的拒收與診斷歷史

V10、V12、V13、V14袖片候選與V15、V16軀幹候選有新增樣本，均拒收；V11改變canvas在CPU即拒收，從未採用。所有候選/raw/log留在私有工作目錄。早期定位器曾把zoom1誤配zoom3.7幾何，後來新增完整720張雙倍率A/A trace，與原V6 PNG逐張一致，定位器改以pose+zoom+frame查詢。這個修正不改候選原生拒收結果；不要沿用未重算的V10/V13縮放1來源定位。

封裝第一次獨立fixture缺少切件轉接依賴，保留於 `../formal-hook-rejected-fixture-v1/`；補齊唯讀工具副本後重跑通過，沒有改共用工具。額外normal probe第一次使用`--script`繞開專案autoload，因此Fx編譯失敗，保留 `../normal-binding/`；只終止經命令列確認的自有probe Godot，改用正常場景後實際成功。這兩次是診斷環境拒收，不隱藏成綠燈。

沒有修改root/shared來源、他人runtime或服務，沒有commit/push。主代理仍需執行採用後受影響正式測試、S08合成驗證、票務與Git交付；本包不自行宣稱整票完成。
