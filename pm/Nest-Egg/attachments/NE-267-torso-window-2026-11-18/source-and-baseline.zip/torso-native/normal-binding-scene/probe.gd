extends Node2D
func _ready() -> void:
	call_deferred("_verify")
func _verify() -> void:
	var rig := CharacterRig.new()
	add_child(rig)
	if not rig.setup("guest_chen", "npc"):
		get_tree().quit(2)
		return
	var found := false
	for part in rig._parts:
		if str(part.name) != "torso":
			continue
		var texture = part.texture
		if not texture is CanvasTexture or texture.normal_texture == null:
			push_error("V17 軀幹缺少實際 CanvasTexture normal 通道")
			get_tree().quit(3)
			return
		var normal := texture.normal_texture as Texture2D
		var expected := "res://art/characters/guest_chen/parts/torso_n.png"
		if normal.resource_path != expected or normal.get_size() != Vector2(233,302):
			push_error("V17 軀幹 normal 掛載或畫布不同")
			get_tree().quit(4)
			return
		print(JSON.stringify({"part":str(part.name),"canvas_texture":true,"normal_path":normal.resource_path,"normal_size":[normal.get_width(),normal.get_height()],"normal_source_sha256":FileAccess.get_sha256(expected),"diffuse_source_sha256":FileAccess.get_sha256("res://art/characters/guest_chen/parts/torso.png")}))
		found = true
	if not found:
		push_error("V17 未找到軀幹")
	rig.queue_free()
	get_tree().quit(0 if found else 5)
