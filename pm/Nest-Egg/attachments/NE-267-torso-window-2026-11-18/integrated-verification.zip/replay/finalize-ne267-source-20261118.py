from pathlib import Path
import hashlib, json, shutil, subprocess

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne267-combined-20261118')
folder = base / 'source-finalization'
folder.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((base / 'source-adopted.json').read_text())
adjustments = json.loads((base / 'integrated-build-v2/import-policy-adjustments.json').read_text())
for row in adjustments:
    name = row['path']
    assert sha(root / name) == row['integrated_sha256']
    assert (root / name).read_bytes().replace(b'\r\n', b'\n') == (shared / name).read_bytes()
    shutil.copyfile(shared / name, root / name)
    source[name] = sha(shared / name)
    row['final_sha256'] = source[name]
    row['newline_normalized_by_godot'] = True
paths = [root / row['path'] for row in adjustments]
before = {str(p): {'sha256': sha(p), 'mtime_ns': p.stat().st_mtime_ns} for p in paths}
command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', '-B', '-X', 'utf8', 'tools/assets/build_rent_window_contacts.py']
run = subprocess.run(command, cwd=root, capture_output=True, timeout=120)
(folder / 'asset-repeat.log').write_bytes(run.stdout + run.stderr)
assert run.returncode == 0 and all(sha(p) == before[str(p)]['sha256'] and p.stat().st_mtime_ns == before[str(p)]['mtime_ns'] for p in paths)
record = json.loads((root / 'art_src/characters/guest_chen_torso_20261118/provenance.json').read_text(encoding='utf-8'))
for name in list(record['inputs']) + ['art_src/characters/guest_chen/overrides/refined/torso.png']:
    source[name] = sha(shared / name)
assert all(sha(shared / name) == digest for name, digest in source.items())
(base / 'source-final.json').write_text(json.dumps(source, indent=2) + '\n')
(folder / 'import-adjustments.json').write_text(json.dumps(adjustments, indent=2) + '\n')
(folder / 'result.json').write_text(json.dumps({'asset_repeat_exit': run.returncode, 'all_9_import_bytes_and_mtime_held': True, 'source_files': len(source), 'all_source_held': True}, indent=2) + '\n')
print('Final integrated source guarded; repeated assets build preserves all nine final import bytes and mtimes.', flush=True)
