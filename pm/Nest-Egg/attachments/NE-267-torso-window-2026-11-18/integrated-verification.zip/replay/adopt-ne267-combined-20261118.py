from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
evidence = Path('D:/NestEggVerification/evidence-20261117')
out = evidence / 'ne267-combined-20261118'
out.mkdir(exist_ok=False)
torso = evidence / 'ne267-transitions-20261118/v17-torso/formal-hook'
window = evidence / 'ne267-candidate-20261118/rent-window-v1'
rows = []
for row in json.loads((torso / 'adoption-manifest.json').read_text(encoding='utf-8')):
    rows.append(dict(row, source=str(torso / 'adoption' / row['path']), sha256=row['after_sha256']))
for row in json.loads((window / 'adoption-v2-manifest.json').read_text(encoding='utf-8'))['files']:
    rows.append(dict(row, source=str(window / 'adoption-v2' / row['path']), sha256=row['candidate_sha256']))
assert len(rows) == len({row['path'] for row in rows}) == 38
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
baseline = json.loads((evidence / 'st8-current-close-20261118/ci-source.json').read_text())
assert all(sha(shared / name) == digest for name, digest in baseline.items()), 'shared baseline drift'
for row in rows:
    assert sha(Path(row['source'])) == row['sha256'], row['path']
    for target_root in (root, shared):
        assert sha(target_root / row['path']) == row['before_sha256'], str(target_root / row['path'])
workflow_name = '.github/workflows/tests.yml'
workflow = (root / workflow_name).read_bytes()
assert (shared / workflow_name).read_bytes() == workflow
needle = b'          python3 tools/run_ch2_evidence_completion.py --godot'
assert workflow.count(needle) == 1
newline = b'\r\n' if b'\r\n' in workflow else b'\n'
patched = workflow.replace(needle, b'          python3 tools/story/test_ch2_rent_window_staging.py' + newline + needle)
for label, target_root in (('root', root), ('shared', shared)):
    for row in rows:
        target = target_root / row['path']
        if target.is_file():
            backup = out / 'before' / label / row['path']
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(target, backup)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(row['source'], target)
        assert sha(target) == row['sha256']
    backup = out / 'before' / label / workflow_name
    backup.parent.mkdir(parents=True, exist_ok=True)
    backup.write_bytes(workflow)
    (target_root / workflow_name).write_bytes(patched)
baseline.update({row['path']: row['sha256'] for row in rows})
baseline[workflow_name] = hashlib.sha256(patched).hexdigest()
assert all(sha(shared / name) == digest for name, digest in baseline.items())
(out / 'source-adopted.json').write_text(json.dumps(baseline, indent=2) + '\n')
(out / 'adoption-manifest.json').write_text(json.dumps(rows, indent=2) + '\n')
(out / 'result.json').write_text(json.dumps({'files': 38, 'workflow_added_test': True, 'baseline': '7258c940873ef4b63c4e3f565745070df0ceea97', 'source_files': len(baseline), 'shared_source_held': True}, indent=2) + '\n')
print('Adopted 38 disjoint files and one CI command into root/shared; all input and output hashes verified.', flush=True)
