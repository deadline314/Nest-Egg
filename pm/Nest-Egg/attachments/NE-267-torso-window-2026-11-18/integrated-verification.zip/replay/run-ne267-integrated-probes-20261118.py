from pathlib import Path
import hashlib, json, os, subprocess, sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne267-combined-20261118')
sys.path.insert(0, str(root / 'tools'))
from runtime_probe import run_case
sys.path.insert(0, str(root / 'tools/comfyui'))
from comfy_guard import server_lock
engine = Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = [row['path'] for row in json.loads((base / 'adoption-manifest.json').read_text())]
paths += [p.relative_to(shared).as_posix() for name in ('ch2_window_clerk', 'rin') for p in (shared / ('art/characters/' + name)).rglob('*.png')]
paths += ['art/rigs/ch2_window_clerk.json', 'art/motion/ch2_window_clerk.json', 'core/story_result_catalog.gd', 'game/story_result_sources.gd', 'tests/probes/ch2_evidence_completion.gd', 'tools/runtime_probe.py']
source = {name: sha(shared / name) for name in paths}
(base / 'probe-runtime-sources.json').write_text(json.dumps(source, indent=2) + '\n')
folder = base / 'native-window'
env = os.environ.copy()
env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(folder / 'profile' / key)
command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--', str(engine), '--path', str(shared), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '640x360', '--fixed-fps', '60', str(folder / 'observer.tscn'), '--', '--out=' + str(folder / 'captures')]
(folder / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (folder / 'raw.log').open('wb') as log:
    process = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=600)
raw = (folder / 'raw.log').read_bytes()
result = {'exit': process.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'errors': [s.decode(errors='replace') for s in raw.splitlines() if b'ERROR:' in s], 'source_held': all(sha(shared / n) == h for n, h in source.items()), 'pngs': len(list((folder / 'captures').glob('*.png')))}
(folder / 'engine-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
assert result['exit'] == result['script_errors'] == 0 and not result['errors'] and result['source_held']
for name, modes, scene in [('accepted-controls', ('contract--accepted', 'contract--accepted_read'), 'res://tests/probes/ch2_evidence_completion.tscn'), ('original-cold-read', ('read_pending', 'read_completed'), str(base / 'original-cold-read/observer.tscn'))]:
    folder = base / name
    receipt = {'cases': []}
    for mode in modes:
        slot = folder / ('slot' if name == 'accepted-controls' else mode + '-slot')
        with server_lock():
            case = run_case(mode, engine, folder, 180, project=shared, scene=scene, slot=slot)
        receipt['cases'].append(case)
        receipt['source_held'] = all(sha(shared / n) == h for n, h in source.items())
        (folder / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print(name, mode, case['passed'], case.get('result', {}).get('checks'), flush=True)
        assert case['passed'] and receipt['source_held'], case
