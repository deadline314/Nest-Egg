from pathlib import Path
import hashlib, json, shutil

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne267-combined-20261118')
candidate = Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118/rent-window-v1')
folder = base / 'native-window'
folder.mkdir(exist_ok=False)
source = candidate / 'native-prop-normals-v3/observer.gd'
assert source.is_file()
shutil.copyfile(source, folder / 'observer.gd')
(folder / 'observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="' + (folder / 'observer.gd').as_posix() + '" id="1"]\n[node name="RentWindowObserver" type="Node2D"]\nscript=ExtResource("1")\n', encoding='utf-8')
controls = base / 'accepted-controls'
controls.mkdir(exist_ok=False)
cold = base / 'original-cold-read'
cold.mkdir(exist_ok=False)
old = candidate / 'persistence-v1'
for mode, name in [('read_pending', 'pending-primary.json'), ('read_completed', 'completed-primary.json')]:
    slot = cold / (mode + '-slot')
    slot.mkdir()
    shutil.copyfile(old / 'original-slot' / name, slot / 'slot.json')
shutil.copyfile(candidate / 'persistence_probe.gd', cold / 'observer.gd')
(cold / 'observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="' + (cold / 'observer.gd').as_posix() + '" id="1"]\n[node name="PersistenceObserver" type="Node"]\nscript=ExtResource("1")\n', encoding='utf-8')
manifest = {str(p.relative_to(base)): hashlib.sha256(p.read_bytes()).hexdigest() for p in list(folder.glob('*')) + list(cold.rglob('*')) if p.is_file()}
(base / 'probe-sources.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Frozen original observer; copied byte-identical genuine old pending/completed slots.', flush=True)
