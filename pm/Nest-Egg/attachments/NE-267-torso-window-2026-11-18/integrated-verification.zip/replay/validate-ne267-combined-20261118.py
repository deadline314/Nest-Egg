from pathlib import Path
import hashlib, json, os, subprocess

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/ne267-combined-20261118')
cpu = out / 'adopted-cpu'
cpu.mkdir(exist_ok=False)
python = 'D:/ComfyUI/.venv-rocm/Scripts/python.exe'
godot = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
env = os.environ.copy()
env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1', GODOT=godot)
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(cpu / 'profile' / key)
results = []
def run(label, command, cwd, timeout=180):
    (cpu / (label + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
    with (cpu / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
    raw = (cpu / (label + '.log')).read_bytes()
    record = {'label': label, 'exit': result.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'errors': [s.decode(errors='replace') for s in raw.splitlines() if b'ERROR:' in s]}
    results.append(record)
    (cpu / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    assert result.returncode == 0 and not record['script_errors'] and not record['errors'], raw[-2500:]

run('torso-selfcheck', [python, '-B', '-X', 'utf8', 'art_src/characters/guest_chen_torso_20261118/self_check.py', '--scratch', str(cpu)], root)
run('torso-callback', [python, '-B', '-X', 'utf8', 'art_src/characters/guest_chen_torso_20261118/rebuild.py'], root)
source = json.loads((out / 'source-adopted.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for label, path in [('assets', 'tools/assets/build_rent_window_contacts.py'), ('story', 'tools/story/build_ch2_story.py'), ('window-tests', 'tools/story/test_ch2_rent_window_staging.py'), ('contract-tests', 'tools/story/test_story_contracts.py'), ('policy-tests', 'tools/story/test_chapter_completion_policies.py')]:
    run(label, [python, '-B', '-X', 'utf8', path], root)
assert all(sha(root / name) == row['sha256'] for row in json.loads((out / 'adoption-manifest.json').read_text()) for name in [row['path']]), 'root generated drift'
run('shared-textures-normals', [python, '-B', '-X', 'utf8', 'tools/comfyui/build_character.py', '--recipe', 'tools/comfyui/recipes/guest_chen.json', '--from', 'textures', '--to', 'normals'], shared, 600)
run('shared-import', [python, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--', godot, '--headless', '--path', str(shared), '--editor', '--quit'], shared, 600)
record = json.loads((root / 'art_src/characters/guest_chen_torso_20261118/provenance.json').read_text(encoding='utf-8'))
for name in list(record['inputs']) + ['art_src/characters/guest_chen/overrides/refined/torso.png']:
    source[name] = sha(shared / name)
assert all(sha(shared / name) == digest for name, digest in source.items()), 'shared generated drift'
(out / 'source-final.json').write_text(json.dumps(source, indent=2) + '\n')
print('All adopted CPU checks, standard character build, import and final source guard passed.', flush=True)
