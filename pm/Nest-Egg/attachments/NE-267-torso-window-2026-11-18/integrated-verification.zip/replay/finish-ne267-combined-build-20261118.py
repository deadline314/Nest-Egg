from pathlib import Path
import hashlib, json, os, shutil, subprocess

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/ne267-combined-20261118')
folder = out / 'integrated-build-v2'
folder.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rows = json.loads((out / 'adoption-manifest.json').read_text())
source = json.loads((out / 'source-adopted.json').read_text())
adjustments = []
for row in rows:
    actual = sha(root / row['path'])
    if actual != row['sha256']:
        assert row['path'].startswith('art/environment/scene_props/rent_window_contacts/') and row['path'].endswith('.png.import'), row['path']
        old = Path(row['source']).read_text(encoding='utf-8')
        new = (root / row['path']).read_text(encoding='utf-8')
        import re
        assert re.sub(r'process/size_limit=\d+', 'process/size_limit=VALUE', old) == re.sub(r'process/size_limit=\d+', 'process/size_limit=VALUE', new)
        assert sha(shared / row['path']) == actual
        shutil.copyfile(root / row['path'], shared / row['path'])
        source[row['path']] = actual
        adjustments.append({'path': row['path'], 'candidate_sha256': row['sha256'], 'integrated_sha256': actual, 'reason': 'Existing import policy uses final authored stage size, rather than missing-stage default.'})
assert len(adjustments) == 9
(folder / 'import-policy-adjustments.json').write_text(json.dumps(adjustments, indent=2) + '\n')
paths = [p.relative_to(root).as_posix() for p in (root / 'art/characters/guest_chen').rglob('*') if p.is_file() and (p.suffix == '.png' or p.name == 'character.json')]
paths += ['art/rigs/guest_chen.json', 'art/motion/guest_chen.json']
runtime = {name: sha(root / name) for name in paths}
assert all(sha(shared / name) == digest for name, digest in runtime.items())
(folder / 'runtime-before.json').write_text(json.dumps(runtime, indent=2) + '\n')
python = 'D:/ComfyUI/.venv-rocm/Scripts/python.exe'
godot = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
env = os.environ.copy()
env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1', GODOT=godot)
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(folder / 'profile' / key)
results = []
import_command = [python, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--', godot, '--headless', '--path', str(shared), '--editor', '--quit']
for label, command in [('import-before-build', import_command), ('character', [python, '-B', '-X', 'utf8', 'tools/comfyui/build_character.py', '--recipe', 'tools/comfyui/recipes/guest_chen.json', '--from', 'textures', '--to', 'normals']), ('import-after-build', import_command)]:
    (folder / (label + '-command.json')).write_text(json.dumps(command, indent=2) + '\n')
    with (folder / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=600)
    raw = (folder / (label + '.log')).read_bytes()
    record = {'label': label, 'exit': result.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'errors': [s.decode(errors='replace') for s in raw.splitlines() if b'ERROR:' in s]}
    results.append(record)
    (folder / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    assert result.returncode == 0 and not record['script_errors'] and not record['errors'], raw[-2500:]
assert all(sha(shared / name) == digest for name, digest in runtime.items()), 'runtime rebuild drift'
record = json.loads((root / 'art_src/characters/guest_chen_torso_20261118/provenance.json').read_text(encoding='utf-8'))
for name in list(record['inputs']) + ['art_src/characters/guest_chen/overrides/refined/torso.png']:
    source[name] = sha(shared / name)
assert all(sha(shared / name) == digest for name, digest in source.items()), 'shared generated drift'
(out / 'source-final.json').write_text(json.dumps(source, indent=2) + '\n')
print('Standard build preserved all runtime bytes; final import and source guard passed.', flush=True)
