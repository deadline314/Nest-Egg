from pathlib import Path
import json, os, subprocess, zipfile

root = Path.cwd()
base = Path('D:/NestEggVerification/evidence-20261117/ne267-combined-20261118')
folder = base / 'archive-joint-replay'
folder.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
python = 'D:/ComfyUI/.venv-rocm/Scripts/python.exe'
checker = root / 'tools/check_joint_frames.py'
control = subprocess.run([python,'-B',str(checker),'--self-check'],cwd=root,env=env,capture_output=True,timeout=120)
(folder / 'negative-control.log').write_bytes(control.stdout+control.stderr)
assert control.returncode == 0
results = []
for archive in sorted((base / 'packages').glob('joints-*.zip')):
    extracted = folder / archive.stem
    extracted.mkdir()
    with zipfile.ZipFile(archive) as z:
        for entry in z.infolist():
            assert (extracted / entry.filename).resolve().is_relative_to(extracted.resolve())
        z.extractall(extracted)
    for group in ('arms','body'):
        for edition in ('before','after'):
            data = extracted / group / edition
            original = json.loads((data / 'report.json').read_text(encoding='utf-8'))
            command = [python,'-B',str(checker),str(data)]
            run = subprocess.run(command,cwd=root,env=env,capture_output=True,timeout=180)
            (folder / (archive.stem+'-'+group+'-'+edition+'.log')).write_bytes(run.stdout+run.stderr)
            actual = json.loads((data / 'report.json').read_text(encoding='utf-8'))
            assert actual == original, (archive.name,group,edition,'replayed report differs')
            assert run.returncode == int(actual['failed_samples']>0)
            results.append({'archive':archive.name,'group':group,'edition':edition,'exit':run.returncode,'samples':actual['samples'],'failures':actual['failed_samples'],'report_exact':True})
            print(archive.name,group,edition,actual['samples'],actual['failed_samples'],flush=True)
            (folder / 'result.json').write_text(json.dumps({'negative_control_exit':control.returncode,'cases':results},indent=2)+'\n')
assert sum(row['samples'] for row in results if row['edition']=='before')==28800
assert sum(row['failures'] for row in results if row['edition']=='before')==2700
assert sum(row['failures'] for row in results if row['edition']=='after')==280
print('Replayed all 57,600 archived before/after joint checks with exact original reports; existing one-pixel negative controls remain active.',flush=True)
