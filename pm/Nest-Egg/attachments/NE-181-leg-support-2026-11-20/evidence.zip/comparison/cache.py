from pathlib import Path
from hashlib import md5,sha256
from shutil import copyfile
from subprocess import run
import json
import os
import re
import sys

repo=Path.cwd()
base=Path(__file__).resolve().parent
shared=base.parent/'ne218-baseline-20261117'
mini=base/'normal-cache'
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
mode=sys.argv[1]
assert mode in ('build','update')
contains=lambda meta,name: re.search(r'^'+name+r'="res://(.+\.ctex)"',meta,re.M)[1]
paths=[Path('art/characters/enforcer/parts')/(part+'_n.png') for part in ('arm_lower','head','leg_upper')]
records={}
if mode=='build':
    mini.mkdir(exist_ok=False)
    (mini/'project.godot').write_text('config_version=5\n\n[application]\nconfig/name="Exact Normal Import"\n',encoding='utf-8')
for name in paths:
    cfg=Path(str(name)+'.import')
    source_md5=md5((repo/name).read_bytes()).hexdigest()
    source_sha=sha256((repo/name).read_bytes()).hexdigest()
    assert sha256((shared/name).read_bytes()).hexdigest()==source_sha
    settings=(repo/cfg).read_text(encoding='utf-8')
    assert (shared/cfg).read_text(encoding='utf-8')==settings
    path=Path(contains(settings,'path'))
    assert path.parts[:2]==('.godot','imported')
    records[name.as_posix()]={'cache':path.as_posix(),'source_md5':source_md5,'source_sha256':source_sha}
    if mode=='build':
        (mini/name).parent.mkdir(parents=True,exist_ok=True)
        copyfile(repo/name,mini/name)
        copyfile(repo/cfg,mini/cfg)
if mode=='build':
    profile=mini/'profile'
    profile.mkdir()
    (profile/'.gdignore').write_text('')
    env=os.environ.copy()
    for var in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        location=profile/var
        location.mkdir()
        env[var]=str(location)
    command=[engine,'--headless','--editor','--path',str(mini),'--import']
    with (base/'normal-cache-import.log').open('wb') as log:
        proc=run(command,env=env,stdout=log,stderr=log,cwd=mini,timeout=90)
    assert proc.returncode==0 and 'ERROR:' not in (base/'normal-cache-import.log').read_text(encoding='utf-8')
for name,record in records.items():
    path=Path(record['cache'])
    meta=path.with_suffix('.md5')
    assert (mini/path).is_file() and record['source_md5'] in (mini/meta).read_text()
    cfg=Path(name+'.import')
    assert (mini/cfg).read_text(encoding='utf-8')==(repo/cfg).read_text(encoding='utf-8')
    record['compiled_sha256']=sha256((mini/path).read_bytes()).hexdigest()
if mode=='build':
    (base/'normal-cache-source.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
else:
    assert records==json.loads((base/'normal-cache-source.json').read_bytes())
    for root,label in ((shared,'verification-checkout'),):
        for record in records.values():
            path=Path(record['cache'])
            meta=path.with_suffix('.md5')
            for relative in (path,meta):
                destination=root/relative
                assert destination.is_file() and destination.resolve().is_relative_to(root.resolve())
                if destination.read_bytes()==(mini/relative).read_bytes():
                    continue
                backup=base/'normal-cache-previous'/label/relative.name
                assert not backup.exists()
                backup.parent.mkdir(parents=True,exist_ok=True)
                copyfile(destination,backup)
                copyfile(mini/relative,destination)
            assert record['source_md5'] in (root/meta).read_text()
            assert sha256((root/path).read_bytes()).hexdigest()==record['compiled_sha256']
print(json.dumps(records,indent=2))
