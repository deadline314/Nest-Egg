extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const ENEMIES := ["salvage_arm", "tangle_wire"]
const DT := 1.0 / 60.0
var _out := ""
var _rows: Array[Dictionary] = []
var _failing: Array[String] = []

func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	var data := LevelData.new()
	data.id = &"cover_test"
	data.show_chapter_card = false
	data.layout_path = "res://tests/fixtures/cover_map.json"
	level.configure(data)
	add_child(level)
	for frame in 120:
		if level.is_initialized():
			break
		await get_tree().process_frame
	if not is_instance_valid(level.player):
		get_tree().quit(2)
		return
	level.player.global_position = Vector2(905, 320)
	level.player.velocity = Vector2.ZERO
	level.camera.snap_to_target()
	for enemy_id: String in ENEMIES:
		for direction: int in [-1, 1]:
			for reduced: bool in [false, true]:
				await _measure(level, enemy_id, direction, reduced)
	var result := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
	result.store_string(JSON.stringify({"cases":_rows, "failures":_failing, "hdr":get_viewport().use_hdr_2d,
		"adapter":RenderingServer.get_video_adapter_name()}, "  "))
	result.close()
	level.queue_free()
	await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(not _failing.is_empty()))


func _measure(level: Level, enemy_id: String, direction: int, reduced: bool) -> void:
	Settings.set_reduce_flashes(reduced)
	var enemy_data := load("res://data/enemies/%s.tres" % enemy_id) as EnemyData
	var enemy := level._create_enemy(enemy_data) as ChainEnemy
	enemy.position = Vector2(985,320)
	level._entities.add_child(enemy)
	enemy.set_physics_process(false)
	enemy.facing = direction
	if enemy_id == "tangle_wire":
		enemy.fsm.transition(&"retract")
	for frame in 12:
		enemy._drive_creature(DT)
	enemy._update_hurt_parts()
	var label := "%s-%s-%s" % [enemy_id, "left" if direction < 0 else "right", "reduced" if reduced else "default"]
	var part := enemy._tentacle_parts[0]
	var limb := enemy.chain._chains[0]
	var neighbor := enemy.chain._chains[1]["polygon"] as Polygon2D
	var mesh := limb["polygon"] as Polygon2D
	var tint: Color = limb["tint"]
	var old_tint: Color = mesh.self_modulate
	var hp := enemy.chain.life_of(0)
	var neighbor_tint := neighbor.self_modulate
	if not _check(part.part_id == &"tentacle_0" and hp > 1 and is_equal_approx(tint.a, 1.0), label + " actual limb"):
		enemy.queue_free()
		return
	await _capture(label + "-before")
	var shot := DamageInfo.create(1, Combat.Team.PLAYER, &"rifle_shot")
	shot.ignore_invulnerability = true
	shot.origin = level.player.muzzle_position()
	part.receive(shot)
	enemy.chain.animate(DT, enemy._creature_state(), enemy.velocity)
	var first_time := float(limb["flash"])
	var first: Color = mesh.self_modulate
	await _capture(label + "-hit")
	var first_hp := enemy.chain.life_of(0)
	_check(first_hp == hp - 1 and first_time > 0.0 and enemy.chain.is_alive(0), label + " one accepted hit")
	_check(neighbor.self_modulate.is_equal_approx(neighbor_tint), label + " adjacent limb does not flash")
	var second_tick := 0.0
	for frame in 12:
		enemy.chain.animate(DT, enemy._creature_state(), enemy.velocity)
		if frame == 0:
			second_tick = mesh.self_modulate.r / tint.r
	_check(absf(float(limb["flash"])) < 0.0001 and mesh.self_modulate.is_equal_approx(tint), label + " returns to original tint")
	_rows.append({"label":label,"id":enemy_id,"direction":direction,"reduced":reduced,
		"health_loss":hp-first_hp,"before":_rgba(old_tint),"base":_rgba(tint),"first":_rgba(first),
		"first_time":first_time,"second_red_gain":second_tick,"finish":_rgba(mesh.self_modulate),
		"tip":[enemy.chain.tip_of(0).x,enemy.chain.tip_of(0).y],"options_scale":Settings.flash_scale()})
	enemy.queue_free()
	await get_tree().process_frame


func _check(ok: bool, text: String) -> bool:
	if not ok:
		_failing.append(text)
	return ok


func _rgba(color: Color) -> Array:
	return [color.r,color.g,color.b,color.a]


func _capture(label: String) -> void:
	await RenderingServer.frame_post_draw
	_check(Capture.image(get_viewport()).save_png(_out.path_join(label + ".png")) == OK, label + " saved")
