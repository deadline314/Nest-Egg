from hashlib import sha256
from pathlib import Path
import json
import math
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
label = sys.argv[1]
out = base / label
out.mkdir()
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    path = out / key
    path.mkdir()
    env[key] = str(path)
paths = [
    "autoload/settings.gd", "game/creature/chain_creature.gd", "game/enemies/chain_enemy.gd",
    "data/enemies/salvage_arm.tres", "data/enemies/tangle_wire.tres",
    "art/creatures/salvage_arm.json", "art/creatures/tangle_wire.json", "tests/fixtures/cover_map.json",
]
sha = lambda path: sha256(path.read_bytes()).hexdigest()
source = {p: sha(game / p) for p in paths}
command = [sys.executable, "-B", str(game / "tools/comfyui/gpu_lock.py"), "--",
           "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(game),
           "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--audio-driver", "Dummy",
           "--fixed-fps", "60", "--resolution", "1280x720", "--quit-after", "1300", str(base / "observe.tscn"),
           "--", f"--out={out}"]
(out / "command.json").write_text(json.dumps({"argv": command, "source": source}, indent=2) + "\n", encoding="utf-8")
with (out / "engine.log").open("wb") as log:
    process = subprocess.run(command, cwd=game, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=140)
raw = (out / "engine.log").read_text(encoding="utf-8", errors="replace")
print(raw[-8000:], flush=True)
assert all(sha(game / p) == digest for p, digest in source.items())
assert process.returncode == 0 and not re.search(r"^SCRIPT ERROR:|^ERROR:", raw, re.M)
report = json.loads((out / "result.json").read_bytes())
assert report["hdr"] and "9070 XT" in report["adapter"]
assert not report["failures"], report["failures"]
assert len(report["cases"]) == 8 and len(list(out.glob("*.png"))) == 16
for row in report["cases"]:
    scale = .25 if row["reduced"] else 1.0
    assert row["options_scale"] == scale
    expected = 1.0 + .9 * (1.0 if label.startswith("stock") else scale) * row["first_time"] / .07
    assert row["health_loss"] == 1 and row["base"] == row["finish"] == row["before"]
    assert all(math.isclose(observed, original * expected, abs_tol=0.00001)
               for observed, original in zip(row["first"][:3], row["base"][:3]))
    assert row["first"][3] == 1
print("Eight actual enemy-part damage and mesh-pulse cases:", [round(row["first"][0]/row["base"][0],5) for row in report["cases"]])
