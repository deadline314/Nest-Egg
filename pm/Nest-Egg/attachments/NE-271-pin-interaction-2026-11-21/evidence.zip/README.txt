原生對照的主檔取自 v6 正常遊玩後退出的存檔。維修架零穩定度、裂盾和通訊器損壞都已保存，插銷尚未拔。舊版和修正版都從主選單繼續，向掃證器走到同一座標，再送一次實際的合成 X 事件。加在修正版末尾的第二次 X 是獨立動作。

重播時以完整 Godot 專案執行 overlap-baseline 或 overlap-candidate 裡的 pin.tscn。先把 ZIP 解到獨立證據目錄，把腳本中的原證據根目錄 D:/NestEggVerification/evidence-20261121-ne271-controller-events 改成解開的根目錄，把 overlap-start-slot.json 複製成各自獨立的 save/slot.json。參數為 --from-save --ch3-janus --gamepad --save-dir=該獨立目錄 --out=截圖目錄 --press-on-process。使用 --audio-driver Dummy --fixed-fps 60，啟動前為每次執行設定獨立的 APPDATA 與 LOCALAPPDATA。

舊版重播用 receipt.json 的 baseline。修正版用含本張票的 commit。v5 和 v8 為同硬體的普通難度整場記錄；v6 和 v7 為繞背受阻的完整記錄。腳本從真存檔續玩，必要敘事等待可依原探針呼叫跳過，沒有實體裝置操作。
