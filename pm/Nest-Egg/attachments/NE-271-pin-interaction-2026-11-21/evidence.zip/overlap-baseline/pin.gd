extends "D:/NestEggVerification/evidence-20261121-ne271-controller-events/v7/ch3-live-route.gd"


func _chapter_three_janus() -> void:
	var boss: JanusBoss
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		if enemy is JanusBoss:
			boss = enemy
			break
	if not _assert_route(boss != null and boss.halted and boss.comm_broken and not boss.pin_pulled,
			"cold Continue restored the original halted Janus with the broken communicator"):
		return
	var scanner := _npc(&"ch3_scanner_gate")
	await _walk_to(scanner.global_position.x, 1.0)
	await _frames(4)
	var pin: Vector2 = boss.global_position + (boss.call(&"_pin_local") as Vector2)
	print("OVERLAP player=", _player().global_position, " scanner=", scanner.global_position,
		" pin=", pin, " scanner_can=", scanner.interaction_available(),
		" scanner_target=", Story.framing.is_interaction_target(scanner))
	if not _assert_route(scanner.interaction_available() and boss.pin_reachable(), "both original gate interactions are reachable"):
		return
	Story.scene_started.connect(func(id: StringName, _mode: StringName) -> void: print("OVERLAP_SCENE ", id))
	Input.parse_input_event(InputEventJoypadMotion.new())
	await _shot("cold-before-pin")
	var process_clock := "--press-on-process" in OS.get_cmdline_user_args()
	if process_clock:
		await get_tree().process_frame
	print("PIN_GATE process=", process_clock, " paused=", get_tree().paused,
		" locked=", GameplayLock.is_locked(), " reachable=", boss.pin_reachable(),
		" joy=", InputBindings.using_gamepad, " fsm=", boss.fsm.current)
	_pad_press(&"interact")
	print("PIN_SENT pressed=", Input.is_action_pressed(&"interact"), " edge=", Input.is_action_just_pressed(&"interact"))
	for tick in 8:
		await _frames(1)
		print("PIN_TICK ", tick, " pressed=", Input.is_action_pressed(&"interact"),
			" edge=", Input.is_action_just_pressed(&"interact"), " pulled=", boss.pin_pulled,
			" locked=", GameplayLock.is_locked(), " paused=", get_tree().paused)
		if tick == 5:
			_pad_release(&"interact")
	_assert_route(boss.pin_pulled and GameState.has_flag(&"ch3_janus_disabled"),
		"the raw X button pulled the pin and saved the original shutdown")