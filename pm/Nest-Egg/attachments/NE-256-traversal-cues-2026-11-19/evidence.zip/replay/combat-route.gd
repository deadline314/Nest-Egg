extends Node
## 序章真輸入探針（ST-16）：從真正的 Main 新遊戲入口開始，用移動、跳躍、射擊、近戰、格擋、衝刺與互動鍵玩完序章，
## 走出店門進當舖，沿途截圖並檢查每一項練習是否靠真的動作完成。瞄準用手把右搖桿的輸入（AimInput 的手把路徑）。
## 用法：godot --path . res://tools/prologue_play_probe.tscn -- --out=<絕對路徑資料夾>
##   [--save-dir=<絕對路徑>]：存檔寫到這個資料夾（不碰玩家的存檔），供 prologue_resume_probe 在另一個程序繼續。
##   [--stop-after=<旗標>]：練到這個旗標就像玩家一樣從 Main 正常退出（會存檔）。
##   [--gamepad]：先送一個真的手把按鍵事件，提示改顯示手把按鍵（截圖檔名加 -pad）。

const LIMIT := 1800

var _out := ""
var _main: Node
var _failures := 0
var _played: Array[StringName] = []
var _save_dir := ""
var _stop_after := &""
var _gamepad := false


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--save-dir="):
			_save_dir = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--stop-after="):
			_stop_after = StringName(arg.trim_prefix("--stop-after="))
		elif arg == "--gamepad":
			_gamepad = true
	if not _save_dir.is_empty() and (not _save_dir.is_absolute_path() or DirAccess.make_dir_recursive_absolute(_save_dir) != OK):
		push_error("[ProloguePlayProbe] --save-dir 要是可寫入的絕對路徑：%s" % _save_dir)
		get_tree().quit(2)
		return
	if not _out.is_empty():
		DirAccess.make_dir_recursive_absolute(_out)
	if "--camera-audit" in OS.get_cmdline_user_args():
		var profile := &"level_wide" if "--camera-wide" in OS.get_cmdline_user_args() else &"level"
		var tuning := CameraTuning.profile(profile)
		CameraTuning._profiles[CameraTuning.DEFAULT_PROFILE] = tuning
		var observer = load("C:/Users/stanl/Github/Nest-Egg/work/ne256-live-route-camera-20261119/observer.gd").new()
		observer.route = self
		observer.profile = profile
		add_child(observer)
	_run.call_deferred()


func _check(ok: bool, what: String) -> void:
	print("%s %s" % ["PASS" if ok else "FAIL", what])
	if not ok:
		_failures += 1


var _accept_radio := false
var _radio_ticks := 0
var _radio_captured := false

func _frames(n: int) -> void:
	for i in n:
		await get_tree().physics_frame
		if _accept_radio and Story._layer.is_radio_frozen():
			_radio_ticks += 1
			if _radio_ticks == 10 and not _radio_captured:
				await _capture_route_radio()
			if _radio_ticks > 15 and _radio_ticks % 12 == 0:
				_send_action(&"ui_accept")
		else:
			_radio_ticks = 0


func _send_action(action: StringName) -> void:
	var key := InputEventAction.new()
	key.action = action
	key.pressed = true
	Input.parse_input_event(key)
	var release := InputEventAction.new()
	release.action = action
	Input.parse_input_event(release)


func _shot(name: String) -> void:
	print("SHOT %s gamepad=%s" % [name, InputBindings.using_gamepad])
	if _out.is_empty() or DisplayServer.get_name() == "headless":
		return
	if _gamepad:
		name += "-pad"
	await _frames(4)
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	print("saved %s (%s)" % [name, error_string(image.save_png(_out.path_join(name + ".png")))])


func _level() -> Level:
	var screen: Variant = _main.get("_screen")
	return screen as Level if screen is Level else null


func _player() -> Player:
	var level := _level()
	return level.player if level != null else null


## 玩家讀完演出就按略過（等同 Esc）；選擇題選預設。
func _finish_story(shot := "") -> void:
	var shown := false
	for i in LIMIT:
		if not Story.is_cinematic_active():
			return
		if not shot.is_empty() and not shown:
			await _frames(60)
			await _shot(shot)
			shown = true
		Story.skip_cinematic()
		await _frames(6)


func _walk_to(x: float, tolerance := 6.0) -> void:
	for i in LIMIT:
		var player := _player()
		if player == null:
			return
		await _finish_story()
		var dx := x - player.global_position.x
		if absf(dx) <= tolerance:
			break
		var action := &"move_right" if dx > 0.0 else &"move_left"
		Input.action_press(action)
		await _frames(1)
		Input.action_release(action)
	Input.action_release(&"move_right")
	Input.action_release(&"move_left")
	await _frames(4)


func _press(action: StringName, hold := 2) -> void:
	Input.action_press(action)
	await _frames(hold)
	Input.action_release(action)
	await _frames(2)


func _aim(direction: Vector2) -> void:
	AimInput.using_gamepad = true
	for name in [&"aim_left", &"aim_right", &"aim_up", &"aim_down"]:
		Input.action_release(name)
	if direction.x > 0.0:
		Input.action_press(&"aim_right", direction.x)
	elif direction.x < 0.0:
		Input.action_press(&"aim_left", -direction.x)
	if direction.y < 0.0:
		Input.action_press(&"aim_up", -direction.y)
	elif direction.y > 0.0:
		Input.action_press(&"aim_down", direction.y)


func _station(id: StringName) -> TrainingStation:
	for node in _level().find_children("*", "TrainingStation", true, false):
		if (node as TrainingStation).data.id == id:
			return node
	return null


func _npc(id: StringName) -> NpcActor:
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if (node as NpcActor).data.id == id:
			return node
	return null


## 送一個真的手把按鍵事件（像玩家拿起手把按了一下），讓提示改顯示手把的按鍵。
func _touch_gamepad() -> void:
	var press := InputEventJoypadButton.new()
	press.device = 0
	press.button_index = JOY_BUTTON_GUIDE
	press.pressed = true
	Input.parse_input_event(press)
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	Input.parse_input_event(release)
	await _frames(2)


## 練到 --stop-after 指定的旗標時，從 Main 正常退出（Main 退出前會存檔）。回傳 true 代表探針已結束。
func _stop_if(flag: StringName) -> bool:
	if _stop_after != flag or not GameState.has_flag(flag):
		return false
	print("PROLOGUE_STOPPED_AT %s level=%s deaths=%d" % [flag, _level().data.resource_path if _level() != null else "", GameState.deaths])
	print("PROLOGUE_PLAY_PROBE failures=%d" % _failures)
	_main.call("_quit", 1 if _failures > 0 else 0)
	return true


func _wait_flag(flag: StringName, frames := 600) -> bool:
	for i in frames:
		if GameState.has_flag(flag):
			return true
		await _frames(1)
	return GameState.has_flag(flag)


func _run() -> void:
	if "--from-save" in OS.get_cmdline_user_args():
		await _route_from_save()
		return
	Story.scene_started.connect(func(id: StringName, _mode: StringName) -> void: _played.append(id))
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	if not _save_dir.is_empty():
		_main.set("_run_store", RunSaveStore.new(_save_dir.path_join("slot.json")))
	add_child(_main)
	await _frames(30)
	# 軟體算圖時選單轉場很慢：轉場還沒結束時 Main 會忽略開始，所以每秒重按一次，最多等兩分鐘。
	var deadline := Time.get_ticks_msec() + 120000
	var started := false
	var difficulty_id := &"standard"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--select-difficulty="):
			difficulty_id = StringName(arg.trim_prefix("--select-difficulty="))
	while Time.get_ticks_msec() < deadline and (_level() == null or _player() == null):
		if not started and not bool(_main.call("_route_pending")):
			var menu := _main.get("_screen") as MainMenu
			if difficulty_id == &"standard":
				_main.call("_on_start_requested", GameState.difficulties[1])
			elif menu != null:
				var choices := GameState.difficulties.filter(func(data: DifficultyData) -> bool: return data.id == difficulty_id)
				if choices.size() != 1:
					_check(false, "the requested difficulty is a real menu option")
					_main.call("_quit", 2)
					return
				menu._start_button.pressed.emit()
				var choice := menu._cards[GameState.difficulties.find(choices[0])]
				choice.button_pressed = true
				choice.pressed.emit()
				await _shot("ne178-difficulty-menu")
				menu._confirm_button.pressed.emit()
			started = _main.get("_active_run")
		await _frames(30)
	var level := _level()
	_check(level != null and level.data.resource_path == "res://data/levels/ch1_prologue.tres", "a new game from Main enters the prologue")
	_note_difficulty()
	if level == null:
		print("PROLOGUE_PLAY_PROBE failures=%d" % _failures)
		get_tree().quit(1)
		return
	await _frames(90)
	await _finish_story("ST-16-p01-door")
	var deaths := GameState.deaths
	# 暫停選單的略過：短按先確認（預設焦點「繼續練習」），這裡取消，回到原步、不改進度。
	var menu: PauseMenu = level._pause_menu
	for i in LIMIT:
		if not GameplayLock.is_locked() and not Story.is_cinematic_active():
			break
		await _frames(1)
	await _frames(30)
	# 演出會吃掉確認鍵，所以等操作交回玩家才拿起手把按一下（像玩家一樣），之後的提示都改顯示手把按鍵。
	if _gamepad:
		await _touch_gamepad()
	menu.open()
	_check(menu._root.visible, "the pause menu opens once the opening hands over control")
	menu._skip_button.button_down.emit()
	menu._skip_button.button_up.emit()
	menu._skip_button.pressed.emit()
	await _frames(40)  # 選單有淡入動畫
	await _shot("ST-16-skip-confirm")
	menu._cancel_skip()
	menu.close()
	_check(not GameState.has_flag(&"ch1_prologue_skipped"), "cancelling the prologue skip keeps the practice")
	# P01→P02：走到工作桌（真的移動才算），再跳上兩格高的搬貨台。
	var bench := _station(&"ch1_training_workbench")
	await _walk_to(bench.global_position.x)
	_check(await _wait_flag(&"ch1_prologue_bench_done", 60), "walking to the workbench completes the movement practice")
	if _stop_if(&"ch1_prologue_bench_done"):
		return
	await _finish_story("ST-16-p02-talk")
	var platform := _station(&"ch1_training_platform")
	# 像玩家一樣：沒跳上去就退回助跑再跳（最多四次）。
	for attempt in 4:
		await _walk_to(platform.global_position.x - 46.0, 4.0)
		await _frames(20)
		if attempt == 0:
			await _shot("ST-16-p02-jump-prompt")
		Input.action_press(&"move_right")
		Input.action_press(&"jump")
		# 像玩家一樣在空中收方向：到了搬貨台上方就放開右鍵，落在台上。
		for i in 70:
			if i == 16:
				Input.action_release(&"jump")
			if _player().global_position.x >= platform.global_position.x - 6.0:
				Input.action_release(&"move_right")
			if GameState.has_flag(&"ch1_prologue_jump_done"):
				break
			await _frames(1)
		Input.action_release(&"jump")
		Input.action_release(&"move_right")
		if GameState.has_flag(&"ch1_prologue_jump_done"):
			break
		var p := _player()
		print("jump attempt %d missed: player %s state %s, platform %s, locked %s, story %s" % [attempt, p.global_position, p.state, platform.global_position, GameplayLock.is_locked(), Story.is_cinematic_active()])
	_check(await _wait_flag(&"ch1_prologue_jump_done", 60), "a real jump onto the cargo platform completes the jump practice")
	if _stop_if(&"ch1_prologue_jump_done"):
		return
	await _finish_story()
	# P03：射擊線，用手把瞄準右方開槍打低靶。
	var range_mark := _station(&"ch1_training_range")
	await _walk_to(range_mark.global_position.x)
	await _finish_story("ST-16-p03-range")
	_check(_npc(&"ch1_old_k_backyard").is_present() and not _npc(&"ch1_old_k_prologue").is_present(), "Old K moves to the backyard line once the tool is down")
	var target := _station(&"ch1_training_target")
	await _walk_to(target.global_position.x - 120.0)
	_aim(Vector2.RIGHT)
	await _frames(10)
	await _shot("ST-16-p03-aim")
	for i in 6:
		await _press(&"shoot", 3)
		if GameState.has_flag(&"ch1_prologue_shot_done"):
			break
		await _frames(20)
	_check(await _wait_flag(&"ch1_prologue_shot_done", 120), "a real shot hits the low target")
	if _stop_if(&"ch1_prologue_shot_done"):
		return
	await _finish_story()
	# P04：橡膠靶近戰、訓練器格擋（先被打停一次，再舉盾擋下）、衝刺穿線。
	var area := _station(&"ch1_training_area")
	await _walk_to(area.global_position.x)
	await _finish_story("ST-16-p04-intro")
	var dummy := _station(&"ch1_training_dummy")
	await _walk_to(dummy.global_position.x - 22.0)
	_aim(Vector2.RIGHT)
	for i in 6:
		await _press(&"melee", 3)
		if GameState.has_flag(&"ch1_prologue_melee_done"):
			break
		await _frames(20)
	_check(await _wait_flag(&"ch1_prologue_melee_done", 120), "a real melee hit on the rubber dummy")
	if _stop_if(&"ch1_prologue_melee_done"):
		return
	await _finish_story()
	var trainer := _station(&"ch1_training_trainer")
	await _walk_to(trainer.global_position.x - 34.0)
	var health := _player().health.current
	for i in 300:
		if GameState.has_flag(&"ch1_prologue_fall_shown"):
			break
		if trainer._phase == &"warn" and i % 30 == 0:
			await _shot("ST-16-p04-trainer-warn")
		await _frames(1)
	_check(GameState.has_flag(&"ch1_prologue_fall_shown") and _player().health.current == health and GameState.deaths == deaths, "an unblocked strike stops the trainer without hurting or killing")
	await _finish_story("ST-16-p04-fall")
	_aim(Vector2.RIGHT)
	Input.action_press(&"block")
	_check(await _wait_flag(&"ch1_prologue_guard_done", 600), "holding block toward the trainer blocks its strike")
	if _stop_if(&"ch1_prologue_guard_done"):
		return
	Input.action_release(&"block")
	await _finish_story()
	var dash := _station(&"ch1_training_dash")
	await _walk_to(dash.global_position.x - 40.0)
	Input.action_press(&"move_right")
	await _frames(2)
	await _press(&"dash", 3)
	await _frames(20)
	Input.action_release(&"move_right")
	_check(await _wait_flag(&"ch1_prologue_dash_done", 120), "a real dash across the training line")
	if _stop_if(&"ch1_prologue_dash_done"):
		return
	await _finish_story()
	# P05→P06：回櫃台和老 K 說話兩次，從旁邊的門回店裡。
	var old_k := _npc(&"ch1_old_k_counter")
	_check(old_k.is_present() and not _npc(&"ch1_old_k_backyard").is_present(), "Old K is back at the counter after the dash")
	await _walk_to(old_k.global_position.x + 14.0)
	await _press(&"interact")
	await _finish_story("ST-16-p05-service")
	_check(GameState.has_flag(&"ch1_prologue_service_heard"), "Old K explains the recovery service")
	await _frames(70)
	if "--audio-route-audit" in OS.get_cmdline_user_args():
		print("NE154_WRAPUP before=", _player().global_position, " old_k=", old_k.global_position,
			" selected=", Story.framing._nearest_interaction(), " talk_ready=",old_k.interaction_available())
		await _walk_to(old_k.global_position.x, 2.0)
		await _frames(10)
		print("NE154_WRAPUP aligned=", _player().global_position, " selected=", Story.framing._nearest_interaction())
	await _press(&"interact")
	await _finish_story("ST-16-p06-call")
	_check(GameState.has_flag(&"ch1_prologue_exit"), "the wrap-up call hands over the exit")
	if _stop_if(&"ch1_prologue_exit"):
		return
	var exit: Portal = _level()._portals.get(&"prologue_exit")
	await _walk_to(exit.global_position.x)
	await _press(&"interact")
	deadline = Time.get_ticks_msec() + 120000
	while Time.get_ticks_msec() < deadline and not (_level() != null and _level().data.resource_path == "res://data/levels/ch1_pawnshop.tres" and _player() != null):
		await _frames(1)
	await _frames(150)
	await _shot("ST-16-pawnshop-arrival")
	_check(_level() != null and _level().data.resource_path == "res://data/levels/ch1_pawnshop.tres", "the prologue door leads into the pawnshop")
	_check(GameState.deaths == 0 and not GameState.has_flag(&"ch1_first_death_done"), "the prologue never counted a death or the first registration")
	var missing := PacingEstimate.PROLOGUE_PATH.filter(func(id: StringName) -> bool: return not _played.has(id))
	_check(missing.is_empty(), "the pacing path matches the scenes a real run plays (missing %s)" % [missing])
	if _failures == 0:
		if "--ch3-cold" in OS.get_cmdline_user_args():
			_check_chapter_three_entry()
		elif "--ch2-close" in OS.get_cmdline_user_args():
			await _chapter_two_close()
		elif "--ch2-yong" in OS.get_cmdline_user_args():
			await _chapter_two_yong()
		elif "--ch2-loading-ground" in OS.get_cmdline_user_args():
			await _chapter_two_loading_ground()
		elif "--ch2-tea-stall" in OS.get_cmdline_user_args():
			await _chapter_two_tea_stall()
		elif "--ch2-loading" in OS.get_cmdline_user_args():
			await _chapter_two_loading()
		elif "--ch2-market" in OS.get_cmdline_user_args():
			await _chapter_two_market()
		elif "--ch2-open" in OS.get_cmdline_user_args():
			await _chapter_two_open()
		elif "--vault-bridge" in OS.get_cmdline_user_args():
			await _chapter_one_vault_bridge()
		elif "--handoff" in OS.get_cmdline_user_args():
			await _chapter_one_handoff()
		elif "--upper-vault" in OS.get_cmdline_user_args():
			await _chapter_one_vault_exit()
		elif "--vault" in OS.get_cmdline_user_args():
			await _chapter_one_vault()
		elif "--raft" in OS.get_cmdline_user_args():
			await _chapter_one_raft()
		elif "--flood" in OS.get_cmdline_user_args():
			await _chapter_one_flood()
		elif "--warehouse" in OS.get_cmdline_user_args():
			await _chapter_one_warehouse()
		elif "--blockade" in OS.get_cmdline_user_args():
			await _chapter_one_blockade()
		elif "--street" in OS.get_cmdline_user_args():
			await _chapter_one_street()
		else:
			await _chapter_one_start()
	print("NE97_ROUTE %s deaths=%d failures=%d" % [_visits, GameState.deaths, _failures])
	print("PROLOGUE_PATH_PLAYED %s" % [_played])
	print("PROLOGUE_PLAY_PROBE failures=%d" % _failures)
	if not _save_dir.is_empty():
		_main.call("_quit", 1 if _failures > 0 else 0)
	else:
		get_tree().quit(1 if _failures > 0 else 0)


var _visits: Array[String] = []


func _chapter_one_start() -> void:
	print("NE97_JOYPADS ", Input.get_connected_joypads())
	_visits.append(_level().data.resource_path.get_file())
	await _walk_to(1378.0)
	for tick in 1200:
		if GameState.has_flag(&"ch1_dinner_done"):
			break
		await _frames(1)
	await _shot("ne97-dinner")
	if not _assert_route(GameState.has_flag(&"ch1_dinner_done"), "walked into the free dinner"):
		return
	if not await _route_portal(&"pawn_stairs"):
		return
	await _walk_to(210.0)
	await _route_jump(1, 30)
	await _walk_to(451.0)
	await _route_jump(1, 28)
	await _walk_to(54.0 * 16.0 - 14.0)
	await _press(&"interact")
	await _finish_story("ne97-rooftop-brief")
	if not _assert_route(GameState.has_flag(&"ch1_heard_brief"), "actually interacted with Egret on the rooftop"):
		return
	await _walk_to(508.0)
	if "--camera-settle" in OS.get_cmdline_user_args():
		await _capture_traversal_cue("朝左看見對面的屋頂，再跳回去。", Vector2(428.0, 800.0), "roof")
		_aim(Vector2.LEFT)
		await _frames(42)
		_check_traversal_landing(Vector2(428.0, 800.0), "roof")
		await _shot("ne256-roof-return-before-jump")
	await _route_jump(-1, 29)
	await _walk_to(277.0)
	await _route_jump(-1, 30)
	if not await _route_portal(&"roof_stairs"):
		return
	if not await _route_portal(&"pawn_front"):
		return
	await _walk_to(34.0 * 16.0 + 8.0)
	if not await _route_portal(&"street_booth"):
		return
	await _route_checkpoint()
	await _route_portal(&"booth_street")


func _capture_traversal_cue(message: String, feet: Vector2, label: String) -> void:
	if "--traversal-cues" not in OS.get_cmdline_user_args():
		return
	await _frames(24)
	var prompt: WorldPrompt
	for fixture in _level()._entities.get_children():
		if fixture is HintSign and fixture.text == message:
			for child in fixture.get_children():
				if child is WorldPrompt:
					prompt = child
			break
	var visible := prompt != null and prompt._alpha >= 0.95 and prompt._layout_allowed and prompt._display_text == message
	var before := "--traversal-cues-before" in OS.get_cmdline_user_args()
	_assert_route((prompt == null if before else visible) and _player().is_on_floor() and not GameplayLock.is_locked(),
		"the authored %s cue is readable at the original takeoff without freezing movement" % label)
	print("NE256_TRAVERSAL ", label, " cue_visible=", visible, " landing_hint_pixel=", _level().get_viewport().get_canvas_transform() * feet)
	await _shot("ne256-traversal-" + label)


func _check_traversal_landing(feet: Vector2, label: String) -> void:
	if "--traversal-cues" in OS.get_cmdline_user_args():
		var viewport := _level().get_viewport()
		var pixel := viewport.get_canvas_transform() * feet
		_assert_route(viewport.get_visible_rect().has_point(pixel), "the indicated %s landing is visibly inside the view before takeoff" % label)
		print("NE256_TRAVERSAL_INTENDED ", label, " ", pixel)


func _assert_route(ok: bool, label: String) -> bool:
	var description := "no active player" if _player() == null else "%s at %s health=%d" % [_level().data.id, _player().global_position, _player().health.current]
	_check(ok, "NE97 %s [%s]" % [label, description])
	return ok


func _note_difficulty() -> void:
	if not "--difficulty-audit" in OS.get_cmdline_user_args():
		return
	print("NE178_DIFFICULTY ", JSON.stringify({"id": String(GameState.difficulty.id),
		"max_hp": GameState.difficulty.player_max_health, "checkpoint_heals": GameState.difficulty.checkpoint_heals,
		"life_budget": GameState.difficulty.lives, "deaths": GameState.deaths}))
	var observed := _player()
	if observed != null:
		observed.health.damaged.connect(func(info: DamageInfo) -> void:
			print("NE178_DAMAGE ", String(info.source_id), " amount=", info.amount,
				" health=", observed.health.current, " at=", observed.global_position))


func _route_jump(direction: int, ticks: int) -> void:
	var move := &"move_right" if direction > 0 else &"move_left"
	Input.action_press(move)
	Input.action_press(&"jump")
	await _frames(ticks)
	Input.action_release(&"jump")
	Input.action_release(move)
	await _frames(12)


func _route_portal(id: StringName) -> bool:
	var current := _level()
	var portal: Portal = current._portals.get(id)
	if not _assert_route(portal != null, "found portal %s" % id):
		return false
	var destination := portal.data.target_level
	for tick in 1300:
		if _level() != current or _player() == null:
			break
		var dx := portal.global_position.x - _player().global_position.x
		if absf(dx) <= 6.0:
			break
		var movement := &"move_right" if dx > 0.0 else &"move_left"
		Input.action_press(movement)
		await _frames(1)
		Input.action_release(movement)
	if _level() == current and is_instance_valid(portal):
		await _press(&"interact")
	for tick in 2400:
		if _level() != null and _level().data.resource_path == destination and _player() != null:
			await _frames(30)
			await _finish_story()
			_visits.append(destination.get_file())
			await _shot("ne97-%s" % id)
			return _assert_route(true, "entered through %s" % id)
		await _frames(1)
	return _assert_route(false, "could not enter through %s" % id)


func _route_checkpoint() -> void:
	var booth := _level().find_children("*", "Checkpoint", true, false).front() as Checkpoint
	await _walk_to(booth.global_position.x)
	await _press(&"interact")
	for tick in 600:
		if Story._layer.is_radio_frozen():
			Story._layer.advance_radio()
		if GameState.has_flag(&"ch1_recording_heard"):
			break
		await _frames(1)
	_assert_route(GameState.has_flag(&"ch1_recording_heard"), "activated the authored checkpoint and finished its recording")


func _route_from_save() -> void:
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_main.set("_run_store", RunSaveStore.new(_save_dir.path_join("slot.json")))
	add_child(_main)
	for tick in 2400:
		var menu := _main.get("_screen") as MainMenu
		if menu != null and menu.is_inside_tree() and not _main.call("_route_pending") and menu._continue_button != null and menu._continue_button.has_focus():
			break
		await _frames(1)
	var menu := _main.get("_screen") as MainMenu
	if not _assert_route(menu != null and is_instance_valid(menu._continue_button) and menu.is_visible_in_tree(), "the real Continue button is available"):
		_main.call("_quit", 2)
		return
	await _frames(24)
	menu._continue_button.pressed.emit()
	for tick in 2400:
		var recovering := "--recover-then-vault" in OS.get_cmdline_user_args()
		if _player() != null and (not recovering or not _player().is_dead()):
			break
		if recovering and Story.is_cinematic_active():
			await _finish_story("ne178-hardcore-second-recovery")
		elif recovering and tick % 45 == 0:
			_send_action(&"ui_accept")
		await _frames(1)
	if _assert_route(_player() != null, "continued from the actual earlier main slot"):
		_note_difficulty()
		await _frames(30)
		if "--ch1-completed-cold" in OS.get_cmdline_user_args():
			await _chapter_one_completed_cold()
		elif "--pawn-collection-audit" in OS.get_cmdline_user_args():
			await _pawn_collection_audit()
		elif "--warehouse-guidance" in OS.get_cmdline_user_args():
			await _warehouse_guidance()
		elif "--ch3-cold" in OS.get_cmdline_user_args():
			_check_chapter_three_entry()
		elif "--ch2-close" in OS.get_cmdline_user_args():
			await _chapter_two_close()
		elif "--ch2-yong" in OS.get_cmdline_user_args():
			await _chapter_two_yong()
		elif "--ch2-loading-ground" in OS.get_cmdline_user_args():
			await _chapter_two_loading_ground()
		elif "--ch2-tea-stall" in OS.get_cmdline_user_args():
			await _chapter_two_tea_stall()
		elif "--ch2-loading" in OS.get_cmdline_user_args():
			await _chapter_two_loading()
		elif "--ch2-market" in OS.get_cmdline_user_args():
			await _chapter_two_market()
		elif "--ch2-open" in OS.get_cmdline_user_args():
			await _chapter_two_open()
		elif "--vault-bridge" in OS.get_cmdline_user_args():
			await _chapter_one_vault_bridge()
		elif "--handoff" in OS.get_cmdline_user_args():
			await _chapter_one_handoff()
		elif "--upper-vault" in OS.get_cmdline_user_args():
			await _chapter_one_vault_exit()
		elif "--vault" in OS.get_cmdline_user_args():
			await _chapter_one_vault()
		elif "--raft" in OS.get_cmdline_user_args():
			await _chapter_one_raft()
		elif "--flood" in OS.get_cmdline_user_args():
			await _chapter_one_flood()
		elif "--warehouse" in OS.get_cmdline_user_args():
			await _chapter_one_warehouse()
		elif "--blockade" in OS.get_cmdline_user_args():
			await _chapter_one_blockade()
		elif "--street" in OS.get_cmdline_user_args():
			await _chapter_one_street()
		else:
			await _chapter_one_start()
	print("NE97_ROUTE %s deaths=%d failures=%d" % [_visits, GameState.deaths, _failures])
	_main.call("_quit", 1 if _failures > 0 else 0)


func _chapter_one_completed_cold() -> void:
	var intact := _level().data.id == &"ch2_pawnshop" and GameState.has_flag(&"ch1_complete") \
			and GameState.has_flag(&"watchdog_defeated") and GameState.has_flag(&"ch1_flood_gate_open") \
			and GameState.has_flag(&"ledger_disk_obtained") and GameState.has_flag(&"ch1_handoff_done") \
			and StoryItems.was_transferred(&"ch1_data_disk") and StoryItems.holds(&"ch1_delivery_receipt")
	print("NE178_COLD_CHAPTER1 ", JSON.stringify({"id": String(GameState.difficulty.id), "deaths": GameState.deaths,
		"lives_left": GameState.lives_left, "health": _player().health.current, "intact": intact,
		"optional_encounter": GameState.has_flag(&"ch1_street_route_open")}))
	_assert_route(intact, "cold Continue retained the real chapter ending, boss, flood, disk, and handoff")
	await _shot("ne178-cold-chapter-2")


func _pawn_collection_audit() -> void:
	if _level().data.id == &"ch1_street":
		var entry := _level()._portals.get(&"street_home") as Portal
		if entry != null and not entry.is_armed():
			await _walk_to(entry.global_position.x + 70.0)
		if not await _route_portal(&"street_home"):
			return
	var pawnbroker := _level()
	var umbrella: PropNode
	for node in get_tree().get_nodes_in_group(PropNode.GROUP):
		if node is PropNode and node.data.id == &"harbor_street__umbrella_stand":
			umbrella = node
			break
	if not _assert_route(is_instance_valid(umbrella), "the authored umbrella stand still exists at the pawnshop door"):
		return
	print("NE178_UMBRELLA_POSITION ", umbrella.global_position, " size=", umbrella.data.size)
	await _walk_to(umbrella.global_position.x + 10.0, 4.0)
	await _shot("ne178-pawn-umbrella")
	if "--pawn-umbrella-after" in OS.get_cmdline_user_args() or "--pawn-umbrella-cold" in OS.get_cmdline_user_args():
		if not await _inspect_pawn_umbrella(pawnbroker):
			return
		if "--pawn-umbrella-cold" in OS.get_cmdline_user_args():
			await _route_portal(&"pawn_front")
			return
	await _walk_to(750.0)
	var before := Progression.credits
	for name in ["fare", "guitar", "raincoat", "watch"]:
		var target := StringName("ch1_label_" + name)
		var seen := StringName(String(target) + "_seen")
		if not await _input_talk(target, [], func() -> bool: return GameState.has_flag(seen)):
			return
	_assert_route(GameState.has_flag(&"sq8_first_labels_done") and Progression.credits == before,
			"reading the four existing labels including the fare jar completes only the no-reward collection")
	var basement := pawnbroker._portals.get(&"pawn_basement") as Portal
	if not _assert_route(basement != null and not basement.is_open(), "the real basement portal remains locked"):
		return
	var toasts: Array[String] = []
	EventBus.toast_requested.connect(func(message: String) -> void: toasts.append(message))
	await _walk_to(basement.global_position.x, 2.0)
	await _press(&"interact")
	await _frames(15)
	_assert_route(_level() == pawnbroker and basement.data.locked_text in toasts,
			"interacting at the real basement gives the leak clue without entering")
	print("NE178_BASEMENT_INTERACTION ", JSON.stringify({"toast": basement.data.locked_text in toasts,
		"scene": String(Story._current_cinematic), "gameplay_locked": GameplayLock.is_locked()}))
	await _shot("ne178-pawn-basement-lock")
	if "--pawn-expect-arbitration" in OS.get_cmdline_user_args():
		if not _assert_route(not Story.is_cinematic_active() and not GameplayLock.is_locked(), "the basement press does not also read the fare jar"):
			return
		await _frames(155)
		toasts.clear()
		await _walk_to(basement.global_position.x + 19.0, 2.0)
		var jar := _npc(&"ch1_label_fare")
		if not _assert_route(basement.interaction_available() and jar.interaction_available(), "both original interactions are in reach for the next press"):
			return
		await _press(&"interact")
		await _frames(12)
		print("NE178_FARE_INTERACTION ", JSON.stringify({"toast": basement.data.locked_text in toasts,
			"scene": String(Story._current_cinematic), "gameplay_locked": GameplayLock.is_locked()}))
		_assert_route(not (basement.data.locked_text in toasts) and Story._current_cinematic == &"ch1_t_label_fare_revisit",
				"the press nearer the fare jar only reads its existing label")
		await _shot("ne178-pawn-fare-sole-interaction")
	if "--pawn-umbrella-after" in OS.get_cmdline_user_args():
		await _finish_story()
		await _route_portal(&"pawn_front")


func _inspect_pawn_umbrella(pawnbroker: Level) -> bool:
	var read := _npc(&"ch1_umbrella_stand")
	var front := pawnbroker._portals[&"pawn_front"] as Portal
	var cold := "--pawn-umbrella-cold" in OS.get_cmdline_user_args()
	var credits := Progression.credits
	var items := StoryItems.snapshot()
	var flags := GameState.world_flags.duplicate(true)
	var shown: Array[StringName] = []
	Story.scene_started.connect(func(id: StringName, mode: StringName) -> void:
		if String(id).begins_with("ch1_t_umbrella_stand"):
			shown.append(id)
			print("NE178_UMBRELLA_TALK ", id, " mode=", mode, " gameplay_locked=", GameplayLock.is_locked()))
	if not _assert_route(read != null and read.interaction_available() and not front.interaction_available(),
			"the stand can be read without overlapping the open front door"):
		return false
	if not cold:
		if not _assert_route(not Story.was_seen(&"ch1_t_umbrella_stand") and shown.is_empty(), "walking past the stand does not play it"):
			return false
		await _press(&"interact")
		await _frames(24)
		if "--pawn-expect-arbitration" in OS.get_cmdline_user_args() and not _assert_route(DialogueLayer.radio_visible(true), "the inspection uses the existing dismissible notice"):
			return false
		var before := _player().global_position.x
		await _walk_to(before + 12.0, 3.0)
		if not _assert_route(_player().global_position.x > before + 6.0 and not GameplayLock.is_locked(),
				"the short first inspection leaves normal movement available"):
			return false
		await _shot("ne178-pawn-umbrella-intro")
		for tick in 800:
			if read.talk_count == 1 and read.interaction_available():
				break
			await _frames(1)
	await _press(&"interact")
	await _frames(24)
	await _shot("ne178-pawn-umbrella-revisit")
	for tick in 420:
		if read.talk_count >= (3 if cold else 2):
			break
		await _frames(1)
	var expected := [&"ch1_t_umbrella_stand_revisit"] if cold else [&"ch1_t_umbrella_stand", &"ch1_t_umbrella_stand_revisit"]
	return _assert_route(shown == expected and read.talk_count >= (3 if cold else 2) and items == StoryItems.snapshot()
			and credits == Progression.credits and flags == GameState.world_flags and _level() == pawnbroker,
			"the normal and repeat inspections leave inventory, money, location and quest flags unchanged")


func _warehouse_guidance() -> void:
	var level := _level()
	var cleared := "--warehouse-guidance-cleared" in OS.get_cmdline_user_args()
	if not _assert_route(level.data.id == &"ch1_warehouse" and GameState.has_flag(&"ch1_street_route_open") == cleared,
			"the genuine warehouse slot retains its original optional street encounter result"):
		return
	var guidance := level.hud.quest_guidance
	await _finish_story()
	await _frames(40)
	var quest := guidance.catalog.find("ch1_take_disk")
	var step := QuestCatalog.current_step(quest, GameState.world_flags)
	var location: Dictionary = step.get("location", {})
	print("NE223_WAREHOUSE_GUIDANCE ", JSON.stringify({"step": step.get("complete_flag"),
		"location": location.get("level"), "active": guidance._target.get("id"), "caption": guidance._label.text,
		"arrow": guidance._arrow.text, "street_clear": GameState.has_flag(&"ch1_street_route_open")}))
	var before := "--warehouse-guidance-before" in OS.get_cmdline_user_args()
	var expected := "ch1_street_route_open" if before else "watchdog_defeated"
	_assert_route(guidance._target.get("id") == "ch1_take_disk" and step.get("complete_flag") == expected and guidance._row.visible,
			"the visible quest points to the expected real objective")
	await _shot("ne223-warehouse-guidance")


func _chapter_one_street() -> void:
	if not _assert_route(_level().data.id == &"ch1_street", "continued on the actual street"):
		return
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	_aim(Vector2.RIGHT)
	_accept_radio = true
	for step in [[42.75, 46.4], [46.6, 51.9], [51.9, 55.2], [55.2, 59.9]]:
		await _walk_to(step[0] * 16.0, 5.0)
		print("NE97_STREET_JUMP_FROM ", _player().global_position, " grounded=", _player().is_on_floor())
		await _fight_jump(step[1] * 16.0)
		print("NE97_STREET_STEP ", step, " at ", _player().global_position, " hp=", _player().health.current)
	if not _assert_route(_player().global_position.y < 610.0, "climbed the street terraces using jump and movement"):
		return
	await _shot("ne97-street-approach")
	if "--landmark-only" in OS.get_cmdline_user_args():
		_assert_route(_radio_captured and GameState.has_flag(&"ch1_dinner_done") and GameState.has_flag(&"ch1_heard_brief"),
			"started and cleared the frozen street call using Accept and reached the first encounter approach")
		return
	await _fight_jump(68.3 * 16.0, true)
	if not _assert_route(_player().global_position.y < 520.0, "reached the occupied terrace by jumping onto the final ledge"):
		return
	for step in [71.0, 84.0, 104.0, 120.0, 137.0]:
		if step == 137.0 and "--camera-look-down" in OS.get_cmdline_user_args():
			if not await _camera_street_drops():
				return
		if not await _fight_step(step*16.0, 1200):
			return
	await _shot("ne97-street-plaza")
	print("NE97_STREET_PREBLOCKADE ", _player().global_position)


func _camera_street_drops() -> bool:
	var player := _player()
	if "--verify-drop-sign" in OS.get_cmdline_user_args():
		var ring := _level().hud.ammo_ring
		if "--preview-reload-obstacle" in OS.get_cmdline_user_args():
			PromptLayout.add_obstacle(ring, _camera_reload_obstacle.bind(ring))
		await _walk_to(1900.0, 2.0)
		_aim(Vector2.RIGHT)
		await _frames(30)
		var hint: WorldPrompt
		for fixture in _level()._entities.get_children():
			if fixture is HintSign and fixture.text == "往斜下方瞄準，先看清落點。":
				for child in fixture.get_children():
					if child is WorldPrompt:
						hint = child
				break
		var showing := hint != null and hint._alpha >= 0.95 and hint._layout_allowed \
				and hint._display_text == "往斜下方瞄準，先看清落點。"
		var before := "--drop-sign-before" in OS.get_cmdline_user_args()
		print("NE256_SIGN ", JSON.stringify({"before": before, "exists": hint != null, "showing": showing,
				"grounded": player.is_on_floor(), "locked": GameplayLock.is_locked()}))
		if hint != null:
			var box := hint.base_rect()
			box.position += hint._nudge
			var reload := _camera_reload_obstacle(ring)
			print("NE256_SIGN_HUD ", JSON.stringify({"ammo": ring.ammo, "reload_visible": reload.has_area(),
				"overlap": box.intersects(reload), "box": str(box), "reload": str(reload)}))
		if not _assert_route((hint == null if before else showing) and player.is_on_floor() and not GameplayLock.is_locked(),
				"the authentic street shows its short landing hint on the safe approach without locking movement"):
			return false
		await _shot("ne256-drop-sign")
		if "--verify-live-reload" in OS.get_cmdline_user_args():
			if not _check_camera_hint_clearance(hint, ring, "low"):
				return false
			_send_action(&"reload")
			await _frames(14)
			if not _check_camera_hint_clearance(hint, ring, "reloading"):
				return false
			await _shot("ne256-drop-sign-reloading")
			await _frames(90)
			if not _assert_route(not _camera_reload_obstacle(ring).has_area() and ring.ammo == ring.max_ammo,
					"a real completed reload fills the magazine and frees the hint space"):
				return false
	for edge_x: float in [1950.0, 2031.0]:
		await _walk_to(edge_x, 2.0)
		await _frames(24)
		if not _assert_route(player.is_on_floor() and not player.is_dead() and absf(player.global_position.x - edge_x) < 9.0,
				"approached the authored terrace edge on foot"):
			return false
		var from := player.global_position
		_aim(Vector2.RIGHT)
		await _frames(30)
		await _shot("ne256-street-%d-forward" % int(edge_x))
		_aim(Vector2(1.0, 1.0).normalized())
		await _frames(48)
		await _shot("ne256-street-%d-down" % int(edge_x))
		var view := _level().get_viewport().get_visible_rect()
		var projected := _level().get_viewport().get_canvas_transform() * (from + Vector2(57.0, 80.0 if edge_x < 2000.0 else 96.0))
		print("NE256_EDGE ", JSON.stringify({"foot": [from.x,from.y], "landing_in_view": view.has_point(projected),
				"target_pixel": [projected.x, projected.y], "camera_zoom": _level().camera.tuning.zoom}))
		Input.action_press(&"move_right")
		for tick in 115:
			await _frames(1)
			if player.is_dead() or (player.is_on_floor() and player.global_position.y > from.y + 60.0):
				break
		Input.action_release(&"move_right")
		if not _assert_route(player.is_on_floor() and not player.is_dead() and player.global_position.y > from.y + 60.0,
				"walked off the terrace onto the actual lower platform"):
			return false
	return true


func _camera_reload_obstacle(ring: AmmoRing) -> Rect2:
	if not ring.is_visible_in_tree() or ring.presence.alpha <= 0.01 or not ring._has_mag:
		return Rect2()
	if not ring._reloading and (ring._done_left > 0.0 or not ring.is_low() or ring.ammo <= 0 or ring.reserve == 0):
		return Rect2()
	var label := ("RECHARGE" if ring.is_energy else "RELOAD") if ring._reloading else "%s 換彈" % InputBindings.code_label(InputBindings.get_code(&"reload", 0))
	var width := UiKit.font().get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, 8).x
	var bounds := Rect2(ring._point + Vector2(-18, -16), Vector2(maxf(36.0, width + 4.0), 43.0))
	return ring.get_viewport().get_canvas_transform().affine_inverse() * bounds


func _check_camera_hint_clearance(hint: WorldPrompt, ring: AmmoRing, phase: String) -> bool:
	var box := hint.base_rect()
	box.position += hint._nudge
	var reserve := ring.call("_prompt_obstacle_rect") as Rect2
	var visible_label := _camera_reload_obstacle(ring)
	var reloading := phase == "reloading"
	var clear := ring._reloading == reloading and hint._alpha > 0.95 and hint._layout_allowed \
			and visible_label.has_area() and reserve == visible_label and not box.intersects(visible_label)
	print("NE256_HUD_CLEARANCE ", JSON.stringify({"phase": phase,"clear": clear,"ammo": ring.ammo,
			"during_reload":ring._reloading,"hint_displayed": hint._alpha > 0.95 and hint._layout_allowed}))
	return _assert_route(clear, "real %s feedback and the world sign both remain readable" % phase)


func _fight_jump(target_x: float, sprint := false, double_jump := false) -> void:
	var player := _player()
	var direction := &"move_right" if target_x >= player.global_position.x else &"move_left"
	Input.action_press(direction)
	Input.action_press(&"jump")
	var passed := false
	for tick in 190:
		if _player() != player:
			break
		if double_jump and tick == 32:
			Input.action_release(&"jump")
		elif double_jump and tick == 36:
			Input.action_press(&"jump")
		if sprint and tick == 30 and not player.is_on_floor():
			Input.action_press(&"dash")
		elif sprint and tick == 31:
			Input.action_release(&"dash")
		if not passed and (absf(player.global_position.x - target_x) < 6.0 or (sprint and player.global_position.x > target_x)):
			passed = true
			Input.action_release(direction)
		if not GameplayLock.is_locked() and tick >= 17 and player.is_on_floor():
			break
		await _frames(1)
	Input.action_release(direction)
	Input.action_release(&"jump")
	await _frames(4)


func _fight_step(target_x: float, ticks: int) -> bool:
	var player := _player()
	var difficulty_audit := "--difficulty-audit" in OS.get_cmdline_user_args()
	var last_x := player.global_position.x
	for tick in ticks:
		if _player() != player or player.is_dead():
			break
		var delta_x := target_x - player.global_position.x
		if target_x >= 160.0*16.0 and player.global_position.x > 149.0*16.0 and player.global_position.x < 152.0*16.0 and player.global_position.y > 610.0 and player.is_on_floor():
			await _fight_jump(156.0 * 16.0, true)
			continue
		if absf(delta_x) < 8.0:
			break
		if difficulty_audit and tick > 0 and tick % 60 == 0:
			if absf(last_x - player.global_position.x) < 8.0 and player.is_on_floor() and not GameplayLock.is_locked():
				Input.action_release(&"shoot")
				_aim(Vector2(signf(delta_x), 0.0))
				await _fight_jump(player.global_position.x + clampf(delta_x, -68.0, 68.0))
				if _player() != player or player.is_dead():
					break
			last_x = player.global_position.x
		var nearest: Enemy
		var best := 250.0 * 250.0
		var from := player.aim_origin()
		for node in get_tree().get_nodes_in_group(&"enemies"):
			var enemy := node as Enemy
			if enemy == null or enemy.is_dying():
				continue
			var to := enemy.hurtbox.center()
			var distance := from.distance_squared_to(to)
			if distance >= best:
				continue
			var ray := PhysicsRayQueryParameters2D.create(from, to, Layers.WORLD)
			if not player.get_world_2d().direct_space_state.intersect_ray(ray).is_empty():
				continue
			nearest = enemy
			best = distance
		if difficulty_audit and nearest != null and nearest.data.id == &"ch1_inspector" and best < 75.0 * 75.0 and nearest.fsm.current in [&"windup", &"leap"]:
			var incoming := nearest.global_position - player.global_position
			_aim(Vector2(signf(incoming.x), 0.0))
			Input.action_release(&"shoot")
			Input.action_press(&"block")
			await _frames(1)
			continue
		if difficulty_audit:
			Input.action_release(&"block")
		if player.loadout.is_dry() and not player.loadout.is_reloading() and tick % 20 == 0:
			_send_action(&"reload")
		if player.health.current <= 4 and tick % 45 == 0 and player.consumables.count(&"med_injector") > 0:
			_send_action(&"use_item")
		var movement := &"move_right" if delta_x > 0.0 else &"move_left"
		if nearest != null:
			if tick % 60 == 0:
				print("NE97_COMBAT ", nearest.data.id, " hp=", nearest.health.current, " player=", player.global_position,
					" med=", player.health.current, " mag=", player.loadout.mag_in(player.loadout.active_slot), " locked=", GameplayLock.is_locked(),
					" enemy=", nearest.hurtbox.center(), " aim=", player.aim_dir, " muzzle=", player.muzzle_position())
			var center := nearest.hurtbox.center()
			_aim((center - player.muzzle_position()).normalized())
			if best < 45.0 * 45.0:
				var near_ledge := from.x < 68.0*16.0 or (from.x > 150.0*16.0 and from.x < 158.0*16.0)
				movement = &"move_right" if near_ledge or center.x < from.x else &"move_left"
				if tick % 25 == 0 and movement == &"move_right":
					Input.action_press(&"dash")
				if tick % 24 == 0:
					Input.action_press(&"melee")
				Input.action_release(&"shoot")
				Input.action_press(movement)
			else:
				Input.action_press(&"shoot")
		else:
			Input.action_release(&"shoot")
		if nearest == null or best > 136.0*136.0:
			Input.action_press(movement)
		await _frames(1)
		Input.action_release(movement)
		Input.action_release(&"melee")
		Input.action_release(&"dash")
	Input.action_release(&"shoot")
	if difficulty_audit:
		Input.action_release(&"block")
	return _assert_route(_player() == player and not player.is_dead() and absf(player.global_position.x-target_x) < 10.0, "combat walking reaches X %.1f" % target_x)


func _capture_route_radio() -> void:
	var player := _player()
	var queue: Array = Story._layer.get("_radio_queue")
	if player == null or queue.is_empty() or queue.front()["id"] != &"ch1_g06_lamp":
		return
	_radio_captured = true
	var row := {"has_lock": Story._layer.is_radio_frozen(), "scene": str(queue.front()["id"]),
		"has_floor": player.is_on_floor(), "px": player.global_position.x, "py": player.global_position.y,
		"vy": player.velocity.y, "hp": player.health.current, "deaths": GameState.deaths,
		"renderer": RenderingServer.get_current_rendering_method(), "adapter": RenderingServer.get_video_adapter_name()}
	print("NE97_RADIO ", JSON.stringify(row))
	if not _out.is_empty() and DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		var frame := preload("res://tools/viewport_capture.gd").image(get_viewport())
		_check(frame.save_png(_out.path_join("ne97-street-radio.png")) == OK, "saved the real first street radio frame")


func _chapter_one_blockade() -> void:
	if not _assert_route(_level().data.id == &"ch1_street", "continued before the actual blockade"):
		return
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	_aim(Vector2.RIGHT)
	_accept_radio = true
	await _walk_to(121.5 * 16.0, 7.0)
	await _frames(45)
	_send_action(&"use_item")
	await _frames(10)
	print("NE97_MED_ITEM ", _player().global_position, " health=", _player().health.current)
	var difficulty_audit := "--difficulty-audit" in OS.get_cmdline_user_args()
	for step in [[135.0, 139.3], [139.9, 145.0], [145.2, 150.1], [149.9, 154.3]]:
		if not await _fight_step(step[0] * 16.0, 850):
			return
		if difficulty_audit:
			await _walk_to(step[0] * 16.0 - 3.0, 2.0)
			_aim(Vector2.RIGHT)
		await _frames(8)
		print("NE97_BLOCKADE_FROM ", _player().global_position, " grounded=", _player().is_on_floor())
		await _fight_jump(step[1] * 16.0)
		print("NE97_BLOCKADE_STEP ", step, " at ", _player().global_position, " hp=", _player().health.current)
	if not _assert_route(_player().global_position.y < 601.0, "reached the street blockade from the lower road"):
		return
	await _shot("ne97-blockade-approach")
	if "--bypass-hardcore-blockade" in OS.get_cmdline_user_args():
		await _cross_blockade()
		return
	if difficulty_audit and GameState.difficulty.id == &"hardcore":
		await _hardcore_blockade()
		return
	for step in [160.0, 167.0, 177.0, 182.0, 190.0, 198.0, 204.0]:
		if not await _fight_step(step*16.0, 1250):
			return
	_assert_route(GameState.has_flag(&"ch1_street_route_open"), "the original wave clearance saved the street route open flag")
	await _route_portal(&"street_warehouse")


func _cross_blockade() -> void:
	if _assert_route(await _guarded_run(3256.0, 840),
			"crossed the open street by dashing and guarding without combat clearance"):
		await _route_portal(&"street_warehouse")


func _guarded_run(target_x: float, ticks: int, no_dash_at_end := 0.0) -> bool:
	var player := _player()
	_aim(Vector2.RIGHT)
	Input.action_press(&"move_right")
	for tick in ticks:
		if _player() != player or player.is_dead() or player.global_position.x >= target_x:
			break
		if tick % 8 == 0 and player.global_position.x < target_x - no_dash_at_end \
				and player._dash_cooldown_left <= 0.0 and player.is_on_floor():
			Input.action_release(&"block")
			Input.action_press(&"dash")
		else:
			Input.action_release(&"dash")
			Input.action_press(&"block")
		await _frames(1)
	Input.action_release(&"move_right")
	Input.action_release(&"block")
	Input.action_release(&"dash")
	return _player() == player and not player.is_dead() and player.global_position.x >= target_x


func _hardcore_blockade() -> void:
	var player := _player()
	var danger := false
	for tick in 3300:
		if _player() != player or player.is_dead() or GameState.has_flag(&"ch1_street_route_open"):
			break
		var best := 300.0 * 300.0
		var target: Enemy
		var incoming := Vector2.INF
		var body := player.aim_origin()
		for node in get_tree().get_nodes_in_group(&"enemies"):
			var enemy := node as Enemy
			if enemy == null or enemy.is_dying():
				continue
			var distance := body.distance_squared_to(enemy.hurtbox.center())
			if distance < best and player.get_world_2d().direct_space_state.intersect_ray(
					PhysicsRayQueryParameters2D.create(body, enemy.hurtbox.center(), Layers.WORLD)).is_empty():
				target = enemy
				best = distance
			if enemy.data.id == &"ch1_inspector" and distance < 62.0 * 62.0 and enemy.fsm.is_in(&"leap"):
				incoming = enemy.hurtbox.center()
		var projectiles := ProjectilePool.container()
		if incoming == Vector2.INF and is_instance_valid(projectiles):
			for node in projectiles.get_children():
				var shot := node as Projectile
				if shot == null or not shot.active or shot.team != Combat.Team.ENEMY:
					continue
				var toward := body - shot.global_position
				if toward.length_squared() < 58.0 * 58.0 and toward.normalized().dot(shot.velocity.normalized()) > 0.88:
					incoming = shot.global_position
					break
		if player.health.current <= 2 and tick % 30 == 0 and player.consumables.count(&"med_injector") > 0:
			_send_action(&"use_item")
		if incoming != Vector2.INF:
			_aim((incoming - body).normalized())
			Input.action_release(&"shoot")
			Input.action_press(&"block")
			danger = true
		else:
			if danger:
				Input.action_release(&"block")
				danger = false
			if target != null:
				_aim((target.hurtbox.center() - player.muzzle_position()).normalized())
				if player.loadout.is_dry() and not player.loadout.is_reloading() and tick % 20 == 0:
					_send_action(&"reload")
				Input.action_press(&"shoot")
				if best < 35.0 * 35.0 and tick % 14 == 0:
					_send_action(&"melee")
			else:
				Input.action_release(&"shoot")
			if player.global_position.x < 2850.0 and (target == null or (best > 188.0 * 188.0)):
				Input.action_press(&"move_right")
		await _frames(1)
		Input.action_release(&"move_right")
	Input.action_release(&"shoot")
	Input.action_release(&"block")
	if not _assert_route(_player() == player and not player.is_dead() and GameState.has_flag(&"ch1_street_route_open"),
			"guarded real incoming shots and cleared the hardcore blockade"):
		return
	if await _fight_step(204.0 * 16.0, 1250):
		await _route_portal(&"street_warehouse")


func _chapter_one_warehouse() -> void:
	if not _assert_route(_level().data.id == &"ch1_warehouse", "continued naturally from street into warehouse"):
		return
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	_aim(Vector2.RIGHT)
	_accept_radio = true
	await _walk_to(152.0, 7.0)
	_send_action(&"use_item")
	await _frames(10)
	for step in [[12.9, 17.1], [17.6, 24.0]]:
		if not await _fight_step(step[0] * 16.0, 850):
			return
		await _frames(6)
		await _fight_jump(step[1] * 16.0)
		print("NE97_WH_FRONT_STEP ", step, " at ", _player().global_position, " hp=", _player().health.current)
	for step in [30.0, 38.0, 45.0]:
		if not await _fight_step(step * 16.0, 1200):
			return
	await _frames(6)
	await _fight_jump(50.3*16.0)
	if not _assert_route(_player().global_position.x >= 46.0*16.0, "reached the watchdog forecourt over the freight containers"):
		return
	var dog: PatternBoss
	for node in get_tree().get_nodes_in_group(&"enemies"):
		if node is PatternBoss and node.data.id == &"watchdog":
			dog = node
	if not _assert_route(dog != null and not dog.is_dying(), "found the original Watchdog"):
		return
	await _watchdog_live(dog)


func _watchdog_live(dog: PatternBoss) -> void:
	var original_player := _player()
	var script: Script = load("C:/Users/stanl/Github/Nest-Egg/work/ne97-campaign-route-20261119/watchdog-driver.gd")
	var driver: Node = script.new()
	add_child(driver)
	driver.use_current_fight(_level(), dog)
	var phase := -1
	var motion := &""
	var hits := 0
	for tick in 12000:
		if _player() != original_player or original_player.is_dead() or not is_instance_valid(dog) or dog.is_dying():
			break
		if dog.phase != phase:
			phase = dog.phase
			await _shot("ne97-watchdog-phase-%d" % phase)
		if dog.fsm.current != motion:
			motion = dog.fsm.current
			if hits < 5 or tick % 300 < 8:
				print("NE97_WATCHDOG state=", motion, " move=", dog.current_move(), " hp=", dog.health.current, " player=", original_player.health.current)
				hits += 1
		if not GameplayLock.is_locked():
			if original_player.loadout.is_dry() and not original_player.loadout.is_reloading() and tick % 20 == 0:
				_send_action(&"reload")
			if original_player.health.current <= 4 and tick % 30 == 0 and original_player.consumables.count(&"med_injector") > 0:
				_send_action(&"use_item")
			driver.drive_frame()
		await _frames(1)
	driver.release_driver()
	driver.queue_free()
	if not _assert_route(_player() == original_player and not original_player.is_dead() and (not is_instance_valid(dog) or dog.is_dying()), "defeated the authored Watchdog with ordinary inputs"):
		return
	await _frames(120)
	_assert_route(GameState.has_flag(&"watchdog_defeated"), "the actual Watchdog channel opened and saved the isolation wall")
	await _shot("ne97-watchdog-gate-open")


func _chapter_one_flood() -> void:
	if not _assert_route(_level().data.id == &"ch1_warehouse" and GameState.has_flag(&"watchdog_defeated"), "cold Continue retained the original watchdog gate completion"):
		return
	_aim(Vector2.RIGHT)
	_accept_radio = true
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	var warehouse := _level()
	await _walk_to(77.5*16.0)
	await _press(&"interact")
	for tick in 750:
		if GameState.checkpoint_applies(warehouse.data.resource_path) and not _player().is_on_phone():
			break
		await _frames(1)
	if not _assert_route(GameState.checkpoint_applies(warehouse.data.resource_path), "actual phone call saves a new warehouse checkpoint"):
		return
	await _shot("ne97-warehouse-phone")
	if not await _flood_switch(&"ch1_switch_a"):
		return
	await _frames(12)
	var owners: Array[String] = []
	for lock in GameplayLock.get("_locks").values():
		var owner: Node = lock["owner"].get_ref()
		owners.append(str(owner.name) if is_instance_valid(owner) else "missing")
	print("NE240_SWITCH_CONFLICT ", JSON.stringify({"x":_player().global_position.x, "npc_scene":str(Story._current_cinematic),
		"in_pump_range":_npc(&"ch1_pump_service").interaction_available(), "locks":owners, "player_state":_player().state}))
	if "--overlap-only" in OS.get_cmdline_user_args():
		await _shot("ne240-after-gate-key")
		if "--expect-separated" in OS.get_cmdline_user_args():
			if not _assert_route(owners.is_empty() and not Story.is_cinematic_active() and not GameState.has_flag(&"ch1_pump_case_reset"),
				"one gate press left movement free and pump maintenance pending"):
				return
			var pump := _npc(&"ch1_pump_service")
			await _walk_to(pump.global_position.x, 5.0)
			await _press(&"interact")
			await _frames(18)
			_assert_route(Story._current_cinematic == &"ch1_t_pump_check" and not GameState.has_flag(&"ch1_pump_case_reset"),
				"a separate press at the pump opened its real optional maintenance")
			await _shot("ne240-separate-pump-key")
		return
	if not await _flood_high_ledge():
		return
	if not await _flood_switch(&"ch1_switch_b"):
		return
	var use_guard := "--difficulty-audit" in OS.get_cmdline_user_args() and GameState.difficulty.id == &"hardcore"
	if use_guard:
		if not _assert_route(await _guarded_run(1846.0, 680), "guarded past the optional enemies after opening the second switch"):
			return
	elif not await _fight_step(116.0*16.0, 1550):
		return
	await _walk_to(123.5*16.0, 5.0)
	for tick in 2400:
		if _level() != warehouse and _player() != null:
			break
		if Story.is_cinematic_active():
			await _finish_story("ne97-first-registration")
		await _frames(2)
	if not _assert_route(GameState.has_flag(&"ch1_flood_gate_open") and GameState.deaths == 1 and _level() != warehouse and GameState.has_flag(&"ch1_first_death_done"),
		"actual flood plate fills, drowns once and the first-registration returns to the warehouse checkpoint"):
		return
	await _shot("ne97-warehouse-flood-return")


func _flood_switch(id: StringName) -> bool:
	for node in get_tree().get_nodes_in_group(WorldState.GROUP):
		if node is MechanismSwitch and node.data.id == id:
			await _walk_to(node.global_position.x, 5.0)
			await _press(&"interact")
			return _assert_route(node.active, "ordinary interaction opened %s" % id)
	return _assert_route(false, "could not find %s" % id)


func _flood_high_ledge(steps := 3) -> bool:
	var jumps := [[96.8, 99.5], [99.6, 102.5], [102.6, 107.1]]
	for step in jumps.slice(0, steps):
		if not await _fight_step(step[0]*16.0, 950):
			return false
		await _frames(8)
		await _fight_jump(step[1]*16.0)
		print("NE97_FLOOD_LEDGE ", step, " at ", _player().global_position, " hp=", _player().health.current)
	var target_height := 698.0 if steps == 3 else 713.0
	return _assert_route(_player().global_position.y < target_height, "reached the raised approach by normal jumping")


func _chapter_one_raft() -> void:
	if not _assert_route(_level().data.id == &"ch1_warehouse" and GameState.has_flag(&"ch1_flood_gate_open") and GameState.deaths == 1,
		"cold Continue preserves the real flooded raft and first death"):
		return
	_aim(Vector2.RIGHT)
	_accept_radio = true
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	var hardcore := "--difficulty-audit" in OS.get_cmdline_user_args() and GameState.difficulty.id == &"hardcore"
	var settle := "--camera-settle" in OS.get_cmdline_user_args()
	if "--resume-raft-stairs" in OS.get_cmdline_user_args():
		if _assert_route(_player().global_position.x > 2160.0 and _player().global_position.y > 770.0,
				"cold Continue restored the actual foot of the warehouse stairs"):
			await _raft_stairs(settle, hardcore)
		return
	if not await _flood_high_ledge(2 if hardcore else 3):
		return
	if hardcore:
		if not _assert_route(await _guarded_run(1919.0, 650), "guarded across the opened flooded approach"):
			return
	elif settle:
		await _walk_to(1774.0, 2.0)
		_aim(Vector2(1.0, 1.0).normalized())
		await _frames(48)
		await _shot("ne256-raft-down-aim-before-drop")
		await _walk_to(120.0 * 16.0)
	elif not await _fight_step(120.0*16.0, 1600):
		return
	await _frames(48)
	if not _assert_route(_player().is_on_floor() and absf(_player().global_position.y - 784.0) < 8.0,
		"stood on the real one-way raft over the flooded pit"):
		return
	await _shot("ne97-flooded-raft")
	if hardcore:
		if not _assert_route(await _guarded_run(2178.0, 650), "crossed the actual floating deck to the main stairs"):
			return
		await _frames(16)
		await _walk_to(2180.0, 4.0)
	elif not await _fight_step(136.4*16.0, 1650):
		return
	await _raft_stairs(settle, hardcore)


func _raft_stairs(settle: bool, hardcore: bool) -> void:
	if hardcore:
		var player := _player()
		for tick in 300:
			if _player() != player or player.is_dead():
				break
			var guard: Enemy
			for node in get_tree().get_nodes_in_group(&"enemies"):
				var enemy := node as Enemy
				if enemy != null and not enemy.is_dying() and enemy.data.id == &"sweeper" \
						and player.global_position.distance_squared_to(enemy.global_position) < 120.0 * 120.0:
					guard = enemy
					break
			if guard == null:
				break
			_aim((guard.hurtbox.center() - player.muzzle_position()).normalized())
			Input.action_press(&"shoot")
			if player.loadout.is_dry() and not player.loadout.is_reloading() and tick % 20 == 0:
				_send_action(&"reload")
			if guard.global_position.distance_squared_to(player.global_position) < 35.0 * 35.0 and tick % 16 == 0:
				_send_action(&"melee")
			await _frames(1)
		Input.action_release(&"shoot")
		if not _assert_route(_player() == player and not player.is_dead(), "cleared the active guard at the stair base"):
			return
		await _walk_to(2180.0, 4.0)
	for step in [[140.0,45], [145.3,41], [140.4,37], [145.3,33], [140.4,29], [145.3,25], [140.4,21], [146.0,17]]:
		if settle and step[1] == 37:
			await _capture_traversal_cue("水梯要折返，先瞄向下一塊踏板。", Vector2(2246.0, 592.0), "stair")
		_aim(Vector2(signf(step[0]*16.0 - _player().global_position.x), 0.0))
		if settle:
			await _frames(42)
			if step[1] == 37:
				_check_traversal_landing(Vector2(2246.0, 592.0), "stair")
				await _shot("ne256-raft-west-platform-before-jump")
		await _fight_jump(step[0]*16.0)
		if not _assert_route(absf(_player().global_position.y - step[1]*16.0) < 8.0, "landed on the real warehouse stair platform at row %d" % step[1]):
			return
	await _route_portal(&"wh_vault")


func _chapter_one_vault() -> void:
	if not _assert_route(_level().data.id == &"ch1_vault" and not _player().has_air_jump(), "continued before the vault with the usual single jump"):
		return
	_aim(Vector2.RIGHT)
	_accept_radio = true
	var kills: Array[StringName] = []
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void:
		kills.append(id)
		print("NE97_KILL ", id))
	await _walk_to(7.5*16.0)
	await _press(&"interact")
	for tick in 750:
		if GameState.checkpoint_applies(_level().data.resource_path) and not _player().is_on_phone():
			break
		await _frames(1)
	if not _assert_route(GameState.checkpoint_applies(_level().data.resource_path), "saved at the real vault phone"):
		return
	for step in [[11.0,45], [16.0,41], [12.0,37], [17.0,33]]:
		_aim(Vector2(signf(step[0]*16.0 - _player().global_position.x), 0.0))
		await _fight_jump(step[0]*16.0)
		if not _assert_route(absf(_player().global_position.y - step[1]*16.0) < 8.0, "landed on real vault side platform row %d" % step[1]):
			return
	var difficulty_audit := "--difficulty-audit" in OS.get_cmdline_user_args()
	var hardcore := difficulty_audit and GameState.difficulty.id == &"hardcore"
	if hardcore:
		if not _assert_route(await _guarded_run(409.0, 850, 100.0), "crossed under the optional vault guards with the original defensive inputs"):
			return
	elif not await _fight_step(24.0*16.0, 1150):
		return
	if difficulty_audit:
		if not hardcore and not await _fight_step(413.0, 950):
			return
		await _walk_to(413.0, 2.0)
		for tick in 85:
			if _player().is_on_floor() and absf(_player().global_position.y - 528.0) < 4.0:
				break
			await _frames(1)
		if not _assert_route(_player().is_on_floor() and absf(_player().global_position.y - 528.0) < 4.0,
				"took off from the actual lower vault shelf after waiting for a landing"):
			return
	await _fight_jump(29.8*16.0)
	if not _assert_route(_player().global_position.y < 472.0, "reached the vault combat shelf"):
		return
	for tile in [32.0,38.0,41.0,47.0]:
		if not await _fight_step(tile*16.0, 1750):
			return
	await _chapter_one_vault_exit()


func _chapter_one_vault_exit() -> void:
	if not _assert_route(_level().data.id == &"ch1_vault" and StoryItems.holds(&"ch1_data_disk") and _player().has_air_jump(),
		"the actual vault disk pickup is held and grants the air jump"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	if "--difficulty-audit" in OS.get_cmdline_user_args():
		var catalog := _level().hud.quest_guidance.catalog
		var quest := catalog.find("ch1_take_disk")
		var result := QuestCatalog.status(quest, GameState.world_flags)
		print("NE223_DISK_GUIDANCE ", JSON.stringify({"status": result, "street_clear": GameState.has_flag(&"ch1_street_route_open"),
			"watchdog": GameState.has_flag(&"watchdog_defeated"), "flood": GameState.has_flag(&"ch1_flood_gate_open"),
			"disk": StoryItems.holds(&"ch1_data_disk")}))
		_assert_route(result == "completed", "the real disk closes the warehouse quest without requiring a street fight")
	await _shot("ne97-vault-disk")
	if "--camera-vault-disk-only" in OS.get_cmdline_user_args():
		return
	await _walk_to(49.0*16.0, 5.0)
	await _frames(18)
	await _fight_jump(52.8*16.0)
	if not _assert_route(absf(_player().global_position.y - 400.0) < 8.0, "reached the vault double jump takeoff ledge"):
		return
	await _fight_jump(54.0*16.0, false, true)
	if not _assert_route(absf(_player().global_position.y - 288.0) < 8.0, "the real air jump climbs the 112-pixel vault step"):
		return
	await _shot("ne97-vault-air-jump-landing")
	await _fight_jump(61.5*16.0, false, true)
	if not _assert_route(absf(_player().global_position.y - 272.0) < 8.0, "cleared the central vault column"):
		return
	await _chapter_one_vault_bridge()


func _chapter_one_vault_bridge() -> void:
	_accept_radio = true
	_aim(Vector2.RIGHT)
	if _player().consumables.count(&"med_injector") > 0 and _player().health.current <= 4:
		_send_action(&"use_item")
		await _frames(10)
	await _fight_jump(68.1*16.0, true, true)
	if not _assert_route(absf(_player().global_position.y - 208.0) < 8.0, "landed on the vault upper walkway"):
		return
	for tile in [72.0,84.0,96.0,109.0]:
		if not await _fight_step(tile*16.0, 1450):
			return
	await _fight_jump(116.0*16.0)
	await _route_portal(&"wh_upper")


func _chapter_one_handoff() -> void:
	if not _assert_route(_level().data.id == &"ch1_handoff" and StoryItems.holds(&"ch1_data_disk"), "entered handoff with the genuine recovered disk"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	if not await _input_talk(&"ch1_handoff_cabinet", ["deliver"], func() -> bool: return StoryItems.was_transferred(&"ch1_data_disk")):
		return
	if not await _input_talk(&"ch1_handoff_cabinet", ["take"], func() -> bool: return StoryItems.holds(&"ch1_delivery_receipt")):
		return
	if not await _input_talk(&"ch1_handoff_cabinet", ["save"], func() -> bool: return GameState.has_flag(&"ch1_handoff_done")):
		return
	if not _assert_route(StoryItems.holds(&"ch1_market_summary") and not StoryItems.holds(&"ch1_data_disk"), "the real cabinet kept custody and issued the receipt and summary"):
		return
	await _shot("ne97-handoff-receipt")
	if not await _route_portal(&"handoff_lounge"):
		return
	if not await _input_talk(&"ch1_ali_lounge", ["order"], func() -> bool: return GameState.has_flag(&"ch1_met_ali")):
		return
	if not await _input_talk(&"ch1_ali_lounge", ["evening"], func() -> bool: return GameState.has_flag(&"ch1_lounge_evening_done")):
		return
	if not await _route_portal(&"lounge_exit"):
		return
	if not await _input_talk(&"ch1_ali_stall", ["stay", "accept"], func() -> bool: return GameState.has_flag(&"ch1_supper_done")):
		return
	await _shot("ne97-ch1-supper")
	if not await _route_portal(&"stall_home"):
		return
	for tick in 3400:
		if _level() != null and _level().data.id == &"ch2_pawnshop" and _player() != null:
			break
		if Story.is_cinematic_active():
			await _finish_story()
		await _frames(1)
	if not _assert_route(_level() != null and _level().data.id == &"ch2_pawnshop" and GameState.has_flag(&"ch1_complete"),
		"normal chapter ending transferred to the real chapter 2 pawnshop"):
		return
	await _shot("ne97-ch2-campaign-entry")


func _input_talk(id: StringName, choices: Array, completed: Callable, offset := -12.0) -> bool:
	var actor := _npc(id)
	if not _assert_route(actor != null and actor.is_present(), "found real conversation target %s" % id):
		return false
	await _walk_to(actor.global_position.x + offset, 5.0)
	for tick in 180:
		if actor.interaction_available() and not GameplayLock.is_locked():
			break
		await _frames(1)
	if not _assert_route(actor.interaction_available(), "the real interaction is ready after its cooldown"):
		return false
	await _press(&"interact")
	var pending := choices.duplicate()
	var saw_scene := false
	for tick in 4450:
		if completed.call() and pending.is_empty() and not Story.is_cinematic_active():
			break
		if Story.is_cinematic_active():
			if not saw_scene:
				saw_scene = true
				print("NE97_REAL_TALK ", id, " ", Story._current_cinematic)
			var cutscene: CutscenePlayer = Story._player
			if cutscene != null and cutscene.choice_active():
				var wanted: String = pending.front() if not pending.is_empty() else str(cutscene._choice_step.get("default", ""))
				var index := cutscene._choice_options.find_custom(func(option: Dictionary) -> bool: return str(option.get("id", "")) == wanted)
				if not _assert_route(index >= 0, "%s offers real choice %s" % [id,wanted]):
					return false
				if not pending.is_empty():
					pending.pop_front()
				cutscene.choose(index)
			elif tick % 8 == 0:
				_send_action(&"ui_accept")
		await _frames(1)
	return _assert_route(saw_scene and pending.is_empty() and completed.call(), "completed the real interaction at %s" % id)


func _chapter_two_open() -> void:
	var prior_deaths := 2 if GameState.difficulty.id == &"hardcore" else 1
	if not _assert_route(_level().data.id == &"ch2_pawnshop" and GameState.has_flag(&"ch1_complete") and StoryItems.was_transferred(&"ch1_data_disk")
		and StoryItems.holds(&"ch1_delivery_receipt") and StoryItems.holds(&"ch1_market_summary") and GameState.deaths == prior_deaths,
		"cold Chapter 2 Continue retains chapter completion, custody, receipt, summary and the original difficulty's deaths"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	await _finish_story("ne97-ch2-morning")
	var wallet := Progression.credits
	if not await _input_talk(&"ch2_old_k", ["settle"], func() -> bool: return GameState.has_flag(&"ch2_morning_settled")):
		return
	if not _assert_route(Progression.credits == wallet+720, "the formal morning settlement adds 720 credits once"):
		return
	if not await _input_talk(&"ch2_radio", ["antenna","power","antenna","speaker","middle","save"],
		func() -> bool: return GameState.has_flag(&"ch2_radio_repaired") and StoryItems.holds(&"ch2_radio_clip")):
		return
	await _shot("ne97-ch2-radio-repaired")
	if not await _route_portal(&"pawn_stairs"):
		return
	await _walk_to(210.0)
	await _route_jump(1, 30)
	await _walk_to(451.0)
	await _route_jump(1, 28)
	if not await _input_talk(&"ch2_egret", [], func() -> bool: return GameState.has_flag(&"ch2_brief_done") and StoryItems.holds(&"ch2_check_card")):
		return
	await _walk_to(508.0)
	await _route_jump(-1, 29)
	await _walk_to(277.0)
	await _route_jump(-1, 30)
	if not await _route_portal(&"roof_stairs") or not await _route_portal(&"pawn_front") or not await _route_portal(&"street_market"):
		return
	if not await _input_talk(&"ch2_patroller", [], func() -> bool: return GameState.has_flag(&"ch2_gate_checked")):
		return
	await _shot("ne97-ch2-market-arrival")


func _chapter_two_market() -> void:
	if not _assert_route(_level().data.id == &"ch2_market_gate" and GameState.has_flag(&"ch2_gate_checked"), "continued after the original market gate check"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	var kills: Array[StringName] = []
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void:
		kills.append(id)
		print("NE97_KILL ", id))
	for tile in [32.0,44.0,57.0,70.0,83.0,94.5]:
		if not await _fight_step(tile*16.0, 1750):
			return
	_assert_route(kills.has(&"ch2_escort") and kills.has(&"ch2_bill_thrower"),"ground route fights and defeats both unique chapter two enemy types")
	var booth := _level().find_children("*", "Checkpoint", true, false).front() as Checkpoint
	await _walk_to(booth.global_position.x)
	await _press(&"interact")
	for tick in 750:
		if GameState.checkpoint_applies(_level().data.resource_path) and not _player().is_on_phone():
			break
		await _frames(1)
	if not _assert_route(GameState.checkpoint_applies(_level().data.resource_path), "real entrance booth saves the market checkpoint"):
		return
	await _shot("ne97-market-b3-after-ground-fights")
	if not await _route_portal(&"gate_market"):
		return
	if not await _input_talk(&"ch2_vig", ["ask"], func() -> bool: return GameState.has_flag(&"ch2_market_contact_done") and StoryItems.holds(&"ch2_evidence_receipt")):
		return
	if not await _input_talk(&"ch2_rent_window", [], func() -> bool: return StoryItems.holds(&"ch2_evidence_contract")):
		return
	await _shot("ne97-ch2-market-contract")


func _chapter_two_loading() -> void:
	if not _assert_route(_level().data.id == &"ch2_market" and StoryItems.holds(&"ch2_evidence_receipt") and StoryItems.holds(&"ch2_evidence_contract"),
		"the real market stop kept receipt and contract"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	if not await _route_portal(&"market_stairs"):
		return
	if not await _input_talk(&"ch2_ali_home", ["wash","right","left"], func() -> bool: return GameState.has_flag(&"sq1_soup_practice_done")):
		return
	await _shot("ne97-ch2-ali-kitchen")
	if not await _route_portal(&"home_roof"):
		return
	if not _assert_route(_player().global_position.y < 390.0, "Ali's rear window exits onto the real market awning"):
		return
	if not await _route_portal(&"market_canopy"):
		return
	if not _assert_route(_player().global_position.y < 475.0, "the upper canopy drops onto the loading bypass over the ground fights"):
		return
	await _shot("ne97-ch2-loading-upper-bypass")
	if not await _input_talk(&"ch2_sc1_lever", [], func() -> bool: return GameState.has_flag(&"ch2_sc1_open")):
		return
	if not await _input_talk(&"ch2_collection_book", [], func() -> bool: return StoryItems.holds(&"ch2_evidence_collection")):
		return
	if not await _input_talk(&"ch2_drying_desk", ["total","principal","contract","collection","north"],
		func() -> bool: return GameState.has_flag(&"ch2_market_reconciled")):
		return
	await _shot("ne97-ch2-desk-correct")
	await _route_portal(&"loading_ledger")


func _chapter_two_tea_stall() -> void:
	var banyan := _npc(&"ch2_banyan")
	if not _assert_route(_level().data.id == &"ch2_market" and banyan != null, "the original Banyan is at his market stall"):
		return
	await _walk_to(banyan.global_position.x - 96.0)
	await _frames(40)
	var character := banyan.get("_actor") as CutsceneActor
	var pot: PropNode
	for node in get_tree().get_nodes_in_group(PropNode.GROUP):
		if node is PropNode and node.data.id == &"neon_market__tea_urn":
			pot = node
			break
	if not _assert_route(pot != null and character != null, "the native tea urn and Banyan rig are present"):
		return
	if "--tea-placement-preview" in OS.get_cmdline_user_args():
		var preview := pot.data.duplicate() as PropData
		preview.size = Vector2(17.7, 42.0)
		preview.steam_offset = Vector2(7.8, 7.2)
		pot.queue_free()
		pot = _level().call("_place_prop", preview, Vector2(1164.0, 534.0), false) as PropNode
		await _frames(2)
	print("NE242_TEA_URN rect=", Rect2(pot.global_position, pot.data.size), " vent=", pot.steam_world_position(), " rig=", banyan.global_position)
	var check_placement := "--verify-tea-placement" in OS.get_cmdline_user_args()
	var furthest := Vector2.ZERO
	for sample in 5:
		await _shot("ne242-tea-stall-%02d" % sample)
		for step in 8:
			var hand := character.hand_contact_global(&"front")
			var error := (hand - pot.steam_world_position()).abs()
			furthest = furthest.max(error)
			print("NE242_TEA_HAND ", hand, " facing=", character.facing)
			await _frames(4)
	print("NE242_TEA_STALL npc=", banyan.global_position, " facing=", banyan.data.facing, " loop=", banyan.data.loop)
	if check_placement:
		print("NE242_TEA_MAX_ERROR ", furthest)
		_assert_route(furthest.x < 4.0 and furthest.y < 4.0 and is_equal_approx(pot.global_position.y + pot.data.size.y, banyan.global_position.y),
			"the real work hand moves near the lid across forty samples, while both feet of the tea stand rest on the market floor")
		await _walk_to(banyan.global_position.x - 12.0, 4.0)
		await _frames(28)
		_assert_route(character._input.npc_loop == &"" and character.facing == -1, "Banyan looks left and stops working when approached")
		await _shot("ne242-tea-talk-left")
	if not await _input_talk(&"ch2_banyan", [], func() -> bool: return GameState.has_flag(&"ch2_banyan_heard")):
		return
	if check_placement:
		await _walk_to(banyan.global_position.x - 96.0)
		await _frames(28)
		_assert_route(character._input.npc_loop == &"stir" and character.facing == 1, "Banyan resumes work facing the original stand once the player moves away")
		await _walk_to(banyan.global_position.x + 12.0, 4.0)
		await _frames(28)
		_assert_route(character._input.npc_loop == &"" and character.facing == 1, "Banyan also pauses for an approach from the other side")
		await _input_talk(&"ch2_banyan", [], func() -> bool: return Story._completed.has(&"ch2_t_s08_banyan_revisit"), 12.0)
		await _walk_to(banyan.global_position.x + 96.0)
		await _frames(28)
		_assert_route(character._input.npc_loop == &"stir" and character.facing == 1, "work resumes after the unchanged revisit and departure")
		await _shot("ne242-tea-work-revisit")


func _chapter_two_loading_ground() -> void:
	if not _assert_route(_level().data.id == &"ch2_market" and StoryItems.holds(&"ch2_evidence_receipt") and StoryItems.holds(&"ch2_evidence_contract"),
		"the actual market papers are present before the lower freight route"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	if not await _route_portal(&"market_cargo"):
		return
	if not _assert_route(_level().data.id == &"ch2_loading" and absf(_player().global_position.y - 576.0) < 1.0,
		"the original ground entrance reaches the lower freight floor"):
		return
	var kills: Array[StringName] = []
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void:
		kills.append(id)
		print("NE97_FREIGHT_GROUND_KILL ", id))
	if not await _fight_step(44.0 * 16.0, 1700):
		return
	if not _assert_route(kills.count(&"ch2_escort") == 1 and kills.count(&"ch2_bill_thrower") == 1,
		"the first lower freight encounter defeats an escort and thrower"):
		return
	await _shot("ne97-ch2-lower-first-fight")
	for tile in [56.0, 62.0, 73.0, 82.0, 91.0]:
		if not await _fight_step(tile * 16.0, 1750):
			return
	if not _assert_route(kills.count(&"ch2_escort") == 3 and kills.count(&"ch2_bill_thrower") == 2 and GameState.deaths == 1,
		"both lower encounters defeat all five original enemies without adding a death"):
		return
	await _shot("ne97-ch2-lower-cleared")
	if not await _input_talk(&"ch2_collection_book", [], func() -> bool: return StoryItems.holds(&"ch2_evidence_collection")):
		return
	if not await _input_talk(&"ch2_drying_desk", ["principal", "contract", "collection", "north"],
		func() -> bool: return GameState.has_flag(&"ch2_market_reconciled")):
		return
	await _route_portal(&"loading_ledger")


func _chapter_two_yong() -> void:
	if not _assert_route(_level().data.id == &"ch2_ledger_front" and GameState.has_flag(&"ch2_market_reconciled"), "the actual three papers reconcile and unlock the ledger forecourt"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	var level := _level()
	var booth := level.find_children("*", "Checkpoint", true, false).front() as Checkpoint
	await _walk_to(booth.global_position.x)
	await _press(&"interact")
	for tick in 750:
		if GameState.checkpoint_applies(level.data.resource_path) and not _player().is_on_phone():
			break
		await _frames(1)
	if not _assert_route(GameState.checkpoint_applies(level.data.resource_path), "actual ledger forecourt booth saves the checkpoint"):
		return
	if not await _input_talk(&"ch2_ledger_door", [], func() -> bool: return GameState.has_flag(&"ch2_yong_intro_seen")):
		return
	if not await _route_portal(&"front_office"):
		return
	var yong: PatternBoss
	for node in get_tree().get_nodes_in_group(&"enemies"):
		if node is PatternBoss and node.data.id == &"yong":
			yong = node
	if not _assert_route(yong != null and yong.health.current == yong.data.max_health
			and _player().health.max_health == GameState.difficulty.player_max_health,
			"real Yong starts at his authored health and the player keeps the selected difficulty cap"):
		return
	if "--inspect-cabinet" in OS.get_cmdline_user_args():
		await _inspect_cabinet()
		return
	await _yong_live(yong)


func _inspect_cabinet() -> void:
	var cabinet := _npc(&"ch2_ledger_cabinet")
	if not _assert_route(cabinet != null, "found the original cabinet inside Yong's office"):
		return
	await _walk_to(cabinet.global_position.x - 12.0, 5.0)
	await _frames(12)
	var prompt: WorldPrompt = cabinet.get("_prompt")
	if not _assert_route(cabinet.interaction_available() and prompt.get("_alpha") > 0.3, "the actual nearby cabinet hint is visible and ready"):
		return
	print("NE265_CABINET_PROMPT ", prompt.get("_display_text"), " closed=", not GameState.has_flag(&"ch2_yong_subdued"))
	await _shot("ne265-cabinet-prompt")
	await _input_talk(&"ch2_ledger_cabinet", [], func() -> bool: return Story._completed.has(&"ch2_t_s13_locked"))
	_assert_route(not GameState.has_flag(&"ch2_yong_subdued") and not StoryItems.holds(&"ch2_original_ledger"), "inspecting the locked cabinet leaves the fight and original ledger intact")


func _yong_live(yong: PatternBoss) -> void:
	var original_player := _player()
	var keep_link := "--keep-yong-link" in OS.get_cmdline_user_args()
	var script: Script = load("C:/Users/stanl/Github/Nest-Egg/work/ne97-campaign-route-20261119/yong-driver.gd")
	var driver: Node = script.new()
	add_child(driver)
	driver.use_current_fight(_level(), yong)
	var stage := ""
	var disarmed := false
	for tick in 14500:
		if _player() != original_player or original_player.is_dead() or not is_instance_valid(yong) or yong.call(&"is_subdued"):
			break
		if str(yong.get("stage")) != stage:
			stage = str(yong.get("stage"))
			print("NE97_YONG stage=", stage, " hp=", yong.health.current, " player=", original_player.health.current)
			await _shot("ne97-yong-stage-%s" % stage)
		if not disarmed and yong.call(&"is_disarmed"):
			disarmed = true
			await _shot("ne97-yong-real-disarm")
			if "--trace-cabinet" in OS.get_cmdline_user_args():
				var cabinet := _npc(&"ch2_ledger_cabinet")
				var prompt: WorldPrompt = cabinet.get("_prompt")
				print("NE265_CABINET_PROMPT ", prompt.get("_display_text"), " closed=", not GameState.has_flag(&"ch2_yong_subdued"), " alpha=", prompt.get("_alpha"))
		if Story.is_cinematic_active():
			var cutscene: CutscenePlayer = Story._player
			if cutscene != null and cutscene.choice_active():
				var id := str(cutscene._choice_step.get("default", ""))
				if Story._current_cinematic == &"ch2_t_s12_choice":
					id = "keep" if keep_link else "cut"
				var index := cutscene._choice_options.find_custom(func(option: Dictionary) -> bool: return str(option.get("id", "")) == id)
				if index >= 0:
					print("NE97_YONG choice=", id)
					cutscene.choose(index)
			elif tick % 8 == 0:
				_send_action(&"ui_accept")
		elif not GameplayLock.is_locked():
			if original_player.loadout.is_dry() and not original_player.loadout.is_reloading() and tick % 15 == 0:
				_send_action(&"reload")
			if original_player.health.current <= 4 and tick % 30 == 0 and original_player.consumables.count(&"med_injector") > 0:
				_send_action(&"use_item")
			driver.drive_frame()
		await _frames(1)
	driver.release_driver()
	driver.queue_free()
	if not _assert_route(_player() == original_player and not original_player.is_dead() and is_instance_valid(yong) and yong.call(&"is_subdued"),
		"normal health run subdues the authored Yong with the original combat and hold interactions"):
		return
	await _frames(40)
	if keep_link:
		_assert_route(GameState.has_flag(&"ch2_yong_subdued") and GameState.has_flag(&"yong_revival_done") and GameState.has_flag(&"yong_link_isolated")
			and not GameState.has_flag(&"yong_link_revoked") and GameState.get_flag(&"yong_link_choice") == "keep"
			and GameState.get_flag(&"xiaowei_read_count") == 1 and not GameState.has_flag(&"xiaowei_yellow_umbrella_recognized") and disarmed,
			"Yong survives revival, correct pause and disarm, with the retained link inactive and Xiaowei forgetting her umbrella")
	else:
		_assert_route(GameState.has_flag(&"ch2_yong_subdued") and GameState.has_flag(&"yong_link_revoked") and disarmed,
			"the original lock parts, isolation and power-cell owner publish the real cut-route result")
	await _shot("ne97-yong-subdued-and-saved")


func _chapter_two_close() -> void:
	if not _assert_route(_level().data.id == &"ch2_ledger_office" and GameState.has_flag(&"ch2_yong_subdued"), "the actual Yong subdued outcome is in the current whole-run save"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	var wallet := Progression.credits
	if not await _input_talk(&"ch2_ledger_cabinet", [], func() -> bool: return StoryItems.holds(&"ch2_original_ledger") and GameState.has_flag(&"ch2_egret_transport_done")):
		return
	if not _assert_route(Progression.credits == wallet + 120 and StoryItems.holds(&"ch2_clinic_index") and StoryItems.holds(&"ch2_ali_page"),
		"the original ledger cabinet publishes its one-time 120 payout and the evidence"):
		return
	if "--trace-cabinet" in OS.get_cmdline_user_args():
		await _shot("ne265-cabinet-real-opened")
		return
	if not await _route_portal(&"office_family"):
		return
	var restored := func() -> bool: return GameState.has_flag(&"ch2_egret_returned") and int(GameState.get_flag(&"egret_restoration_count")) == 214
	if not await _input_talk(&"ch2_egret_booth", [], restored, 12.0):
		return
	await _shot("ne97-ch2-egret-214")
	if not await _route_portal(&"gate_lounge"):
		return
	wallet = Progression.credits
	if not await _input_talk(&"ch2_terminal", [], func() -> bool: return GameState.has_flag(&"ch2_audit_submitted")):
		return
	if not _assert_route(Progression.credits == wallet + 250, "the real terminal posts the once-only 250 audit award"):
		return
	if not await _input_talk(&"ch2_ali_lounge", ["correct"], func() -> bool: return str(GameState.get_flag(&"ali_ledger_action")) == "correct" and not StoryItems.holds(&"ch2_ali_page")):
		return
	await _shot("ne97-ch2-audit-submitted")
	if not await _route_portal(&"lounge_gate") or not await _route_portal(&"gate_street") or not await _route_portal(&"street_home") or not await _route_portal(&"pawn_stairs"):
		return
	await _walk_to(210.0)
	await _route_jump(1, 30)
	await _walk_to(451.0)
	await _route_jump(1, 28)
	if not await _input_talk(&"ch2_egret", ["go"], func() -> bool: return GameState.has_flag(&"ch2_heron_closed")):
		return
	for tick in 3000:
		if _level() != null and _level().data.id == &"ch3_pawnshop" and _player() != null:
			break
		if Story.is_cinematic_active():
			await _finish_story()
		await _frames(1)
	if not _assert_route(_level() != null and _level().data.id == &"ch3_pawnshop" and GameState.has_flag(&"ch2_heron_closed"), "Chapter 2 naturally ends and saves the original Chapter 3 pawnshop"):
		return
	await _frames(40)
	await _shot("ne97-ch3-campaign-entry")


func _check_chapter_three_entry() -> void:
	_assert_route(_level().data.id == &"ch3_pawnshop" and GameState.has_flag(&"ch1_complete") and GameState.has_flag(&"ch2_heron_closed"),
		"a cold Main really continued at the official Chapter 3 pawnshop after both closures")
	if "--difficulty-audit" in OS.get_cmdline_user_args():
		var prior_deaths := 2 if GameState.difficulty.id == &"hardcore" else 1
		var kept := GameState.deaths >= prior_deaths and _player().health.current > 0 \
			and _player().health.max_health == GameState.difficulty.player_max_health \
			and int(GameState.get_flag(&"egret_restoration_count")) == 214
		print("NE97_COLD_CHAPTER2 ", JSON.stringify({"id":GameState.difficulty.id,"health":_player().health.current,
			"max_health":_player().health.max_health,"deaths":GameState.deaths,"starting_deaths":prior_deaths,"intact":kept}))
		_assert_route(kept, "the saved third chapter kept difficulty, health, deaths and Egret's count")
	else:
		_assert_route(GameState.deaths == 1 and _player().health.current == 6 and int(GameState.get_flag(&"egret_restoration_count")) == 214,
			"chapter handoff preserves standard-health, one flood death and Egret's exact 214 count")
	if "--keep-yong-link" in OS.get_cmdline_user_args():
		_assert_route(GameState.has_flag(&"ch2_yong_subdued") and GameState.has_flag(&"ch2_audit_submitted") and GameState.has_flag(&"yong_revival_done")
			and not GameState.has_flag(&"yong_link_revoked") and GameState.get_flag(&"yong_link_choice") == "keep"
			and GameState.get_flag(&"xiaowei_read_count") == 1 and not GameState.has_flag(&"xiaowei_yellow_umbrella_recognized")
			and Story.resolve_dispatch(&"ch3_dispatch_notice") == &"ch3_t_c03_notice_keep",
			"cold Continue preserves the retained link, cost to Xiaowei, audit and matching clinic notice")
	else:
		_assert_route(GameState.has_flag(&"ch2_yong_subdued") and GameState.has_flag(&"yong_link_revoked") and GameState.has_flag(&"ch2_audit_submitted"),
			"the original boss, cut route and audit survive cold Continue together")
