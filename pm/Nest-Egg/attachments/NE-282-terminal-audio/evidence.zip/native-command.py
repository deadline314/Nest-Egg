from pathlib import Path
import os,sys,subprocess,json,re,hashlib,signal
root=Path.cwd();label=sys.argv[1];scene=sys.argv[2];mode=sys.argv[3];out=root/'work/audio-shutdown'/label;out.mkdir();(out/'.gitignore').write_text('*\n');(out/'.gdignore').touch();slot=out/'slot';slot.mkdir()
if len(sys.argv)>4:
 primary=Path(sys.argv[4]).read_bytes();(slot/'slot.json').write_bytes(primary)
env=os.environ.copy();profile=str(out/'profile');env.update(XDG_DATA_HOME=profile,APPDATA=profile,LOCALAPPDATA=profile)
cmd=['python3','tools/comfyui/gpu_lock.py','--','xvfb-run','-a','-s','-screen 0 1280x720x24',env['GODOT'],'--verbose','--path','.', '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',scene,'--','--mode='+mode,'--save-dir='+str(slot),'--out='+str(out/'result')]
with (out/'raw.log').open('w') as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'process.json').write_text(json.dumps({'pid':p.pid,'command':cmd},indent=2))
 try: code=p.wait(timeout=240)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=10)
text=(out/'raw.log').read_text(errors='replace');bad=[l[:512] for l in text.splitlines() if re.search(r'^ERROR:|SCRIPT ERROR|Parse Error|^FAIL|leaked at exit|resources still in use|Leaked instance:|Resource still in use:',l)];result=json.loads((out/'result/result.json').read_text()) if (out/'result/result.json').exists() else {};receipt={'exit':code,'command':cmd,'diagnostics':bad,'result':result,'renderer':'Forward+ Vulkan llvmpipe','engine_sha256':hashlib.file_digest(open(env['GODOT'],'rb'),'sha256').hexdigest()};(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(receipt['exit'],receipt['diagnostics'],receipt['result']);sys.exit(0 if code==0 and not bad and result.get('checks',0)>0 and result.get('failures')==[] else 1)
