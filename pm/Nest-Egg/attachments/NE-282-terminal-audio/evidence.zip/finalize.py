from pathlib import Path
import json,re,zipfile,hashlib,shutil,subprocess
r=Path.cwd();w=r/'work/audio-shutdown';d=r/'pm/Nest-Egg/attachments/NE-282-terminal-audio';d.mkdir(parents=True,exist_ok=True)
a=json.loads((w/'public-final/receipt.json').read_text());assert len(a['cases'])==8 and all(x['passed'] for x in a['cases'])
controls=[]
for name,count in [('handoff-final',2),('channel-final',17),('yong-final',7),('janus-final',7)]:
 b=json.loads((w/name/'receipt.json').read_text());assert len(b['cases'])==count and all(x['passed'] for x in b['cases']);controls.extend(b['cases'])
c=(w/'affected-console.log').read_text();g=int(re.search(r'Running (\d+) groups',c)[1]);checks,new,known,seconds=map(int,re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',c).groups());assert new==known==0
native=[json.loads((w/f/'receipt.json').read_text()) for f in ('native-main','native-settle')];assert all(x['exit']==0 and not x['diagnostics'] and x['result']['failures']==[] for x in native)
old=json.loads((w/'before/receipt.json').read_text());assert old['git_clean'] and old['result']['checks']==9 and len(old['result']['failures'])==3
ids=[int(m[1]) for p in (r/'pm/Nest-Egg').glob('[[]NE-*') if (m:=re.search(r'\[NE-(\d+)\]',p.name))];assert max(ids) in (281,282)
shutil.copyfile(w/'native-main/result/menu.png',r/'pm/Nest-Egg/images/NE-282-before-quit.png')
extra=['.github/workflows/tests.yml','design/20-campaign-experience/AUDIO_MIX_LIFETIME.md']
with zipfile.ZipFile(d/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in w.rglob('*'):
  if not p.is_file() or any('profile' in part or part.startswith('data_') or part in ('__pycache__','.godot') for part in p.relative_to(w).parts) or p.name in ('.gitignore','.gdignore'):continue
  z.write(p,str(p.relative_to(w)))
 for name in extra:z.write(r/name,'source-final/'+name)
 for name in ['game/main.gd','autoload/sfx.gd','autoload/music.gd','autoload/ambience.gd','core/audio/audio_release.gd','core/audio/crossfade_player.gd']:
  z.writestr('source-before/'+name,subprocess.check_output(['git','show','53e86de1:'+name]))
 for name in ['receipt.json','isolation.log']:
  z.write(r/'work/yong-box-save/after'/name,'discovery/isolation/'+name)
 z.write(r/'work/yong-box-save/probe.gd','discovery/isolation/probe.gd')
 z.writestr('discovery/isolation/wip.patch',subprocess.check_output(['git','diff','stash@{0}^1','stash@{0}']))
 z.write('/workspace/.nest-egg-env/ci-godot/dist/receipt.json','engine-receipt.json')
a.update(affected={'groups':g,'checks':checks,'failures':0,'seconds':seconds},existing_cases=len(controls),existing_checks=sum(x['result']['checks'] for x in controls),native=native,negative=old,archive_sha256=hashlib.sha256((d/'evidence.zip').read_bytes()).hexdigest())
(d/'receipt.json').write_text(json.dumps(a,indent=2,ensure_ascii=False)+'\n')
(d/'README.md').write_text(f'''# NE-282：程序終止後拒絕晚到播放

原隔離箱修正樣本8項行為全過，卻退出留下4個物件／2個資源；beep_02.ogg的Vorbis播放鏈由NE-281新增的詳細診斷指出。discovery保留原輸出、場景、53e86de1上未合併的隔離箱差異，不把該差異當成本票已交付功能，也不把退出有外洩算通過。

乾淨53e86de1受控負案例先讓三類原音訊正常播放，再以真正Main接受退出。確認原播放器全停後，明示送入晚到要求。三者仍獲准，9項有3項失敗，16物件／5資源外洩，包含原beep_02.ogg、原配樂與環境音。這證明一個具體的停止後再播放窗口，不宣稱舊CI41057307449當時的所有因果已確定。

Main接受終止便關閉接收，早於保存、演出取消與釋放畫面；直接settle的工具也先關閉接收。真正音效／交叉淡化播放入口拒絕新串流，配樂／環境音不再改成新的開始狀態。原停止、兩次混音與400ms上限、引擎修補均維持，不靠關閉日常音效或延長固定等待。

- 公開Main／settle兩入口×0／5／20／60 FPS，8程序72項全過；每程序含三項正常播放控制、三項真停止確認與三項晚到拒絕。
- 原交接櫃2、第一章通道17、阿勇7、守門人7，共33程序384項全過，嚴格退出檢查保留。
- 必要受影響{g}組、{checks:,}項、0新增／已知失敗、{seconds}秒；完整6份退出輸出另檢DummyTexture0。
- 原生Forward+／軟體Vulkan兩入口，18項全過、0嚴格診斷；兩張原圖看過。主選單截圖只是退出前的原畫面，不以靜態圖證明聲音聽感。

引擎為與CI相同固定來源／修補／選項、本機編譯器的4.7.2 custom build，雜湊見engine-receipt。真正播放／混音使用Dummy輸出，不代表實體喇叭、硬體效能或其他作業系統已驗。沒有修改選擇器或已知失敗，沒有靜音、略過錯誤或用零退出碼冒充成功。

終止接收是單一程序的永久狀態，只用於結束程序，不是換區、暫停或回主選單的API。正常音訊操作與既有流程由上述控制及回歸驗證。新增八程序已納入CI。

[evidence.zip](evidence.zip)包含受控負案例、每項原始trace／退出輸出、原隔離箱發現、全部來源與既有回歸。[receipt.json](receipt.json)記錄實際驗證邊界與校驗碼。
''')
p=r/'pm/Nest-Egg/[NE-282]阻止退出後重新播放音訊.md';assert not p.exists() or p.read_text().startswith('# [NE-282] 阻止退出後重新播放音訊')
p.write_text(f'''# [NE-282] 阻止退出後重新播放音訊

> 狀態：完成

## 內文

### 需求
退出已經停掉聲音後，晚到的提示或場景回呼仍可能重新開啟音效、配樂與環境音，讓程序帶著播放資源離開。接受退出後停止新的播放要求，保留日常遊戲的聲音及原退出收尾。

### 來源
2026-11-02，依使用者持續完成票券且不破壞原功能的要求，從原隔離箱退出的真實外洩及受控晚到播放重現發現。[設計與範圍](../../design/20-campaign-experience/AUDIO_MIX_LIFETIME.md)。

### 驗收條件
- [x] 真正接受程序退出後，音效、配樂及環境音的晚到要求不會重新建立播放。
- [x] 一般播放仍成功，回主選單、換區、保存與續玩的既有流程通過。
- [x] 主程式與共用退出工具在多種幀率都保留原停止及有上限的收尾，不以日常靜音交付。
- [x] 保留停止前後及晚到要求的真實紀錄、原失敗與退出診斷，必要回歸全過。

### 測試流程
1. 正常播放原音效、主選單配樂與環境音。
2. 接受退出，確認原播放器已停，再送入晚到要求。
3. 確認沒有重新播放且程序無外洩，核對不同幀率及共用工具退出。

---

# 跟其他票的關係

- Blocks：無
- Blocked by：無
- Related：NE-280、NE-281

---

# Commit-1（退出開始便停止接受新播放）

## 內文

原本停掉所有聲音後，晚到的回呼還能重新播放。現在一經接受程序退出，就不再接受新音效、配樂或環境音；正常遊戲不受影響，退出仍保留原有上限的收尾。

乾淨原版受控9項有3項失敗，留下16物件／5資源；修後8程序72項及原生兩程序18項全過、無嚴格診斷。既有交接櫃、第一章通道、阿勇與守門人共33程序384項，以及受影響{g}組{checks:,}項皆全過。

![退出前原生主選單；播放與退出由收據驗證](images/NE-282-before-quit.png)

[原失敗、前後播放紀錄、原圖與完整證據](attachments/NE-282-terminal-audio/README.md)。混音使用Dummy輸出，不代稱實體裝置試聽。
''')
for glob,oldline,newline in [('[NE-281]*','- Related：無','- Related：NE-282'),('[NE-280]*','- Related：NE-154、NE-213、BG-50、NE-233','- Related：NE-154、NE-213、BG-50、NE-233、NE-282')]:
 p=next(p for p in (r/'pm/Nest-Egg').iterdir() if p.name.startswith(glob.removesuffix('*')));s=p.read_text();assert oldline in s or newline in s;p.write_text(s.replace(oldline,newline,1))
print(g,checks,sum(x['result']['checks'] for x in controls))
