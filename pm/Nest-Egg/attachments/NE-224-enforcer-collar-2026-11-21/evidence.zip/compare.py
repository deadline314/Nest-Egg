from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import re

import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent
root=Path.cwd()
prior=base.parent/'evidence-20261121-ne224-joints-current'
sha=lambda path: sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_bytes())
def key(f): return (f['char'],f['joint'],f['pose'],f['zoom'],f['facing'],f['frame'])
def gap(f): return f['center_alpha']<128 or f['enclosed_pixels'] or f['loose_pieces']

results={}
for scope,num in (('dressed',3840),('isolated',3840),('whole',1152),('adjacent',3456)):
    old=read(base/f'stock-{scope}'/'report.json') if scope!='adjacent' else read(prior/'native-stock/report.json')
    new=read(base/f'final-{scope}'/'report.json')
    assert new['samples']==num
    current=[f for f in old['failures'] if scope!='adjacent' or f['char']=='enforcer' and f['joint'] in ('shoulder_front','shoulder_back','waist')]
    previous={key(f) for f in current if gap(f)}
    repaired={key(f) for f in new['failures'] if gap(f)}
    added=sorted(repaired-previous)
    results[scope]={'samples':num,'before':[len(current),len(previous)],'after':[new['failed_samples'],len(repaired)],
                    'new_gap_keys':added,'remaining_gaps_by_action':dict(Counter(k[2] for k in repaired))}
    assert not added,(scope,added)
assert results['dressed']['before'][1] == 1920 and results['dressed']['after'][1] < 100
assert results['isolated']['after'][1] == 0
assert results['whole']['before'][1] == 570 and results['whole']['after'][1] < 170

for suffix in ('final-dressed','final-isolated','final-whole','final-adjacent','final-damage','normal','import'):
    assert 'ERROR:' not in (base/(suffix+'.log')).read_text(encoding='utf-8'),suffix
backup=root/'art_src/characters/enforcer/neck_overlap/torso-before.png'
new=root/'art_src/characters/enforcer/overrides/torso.png'
actual_composite=root/'art/characters/enforcer/parts/torso.png'
actual_normal=root/'art/characters/enforcer/parts/torso_n.png'
assert sha(new)==sha(actual_composite)==sha(base/'torso-trial.png')
assert sha(actual_normal)==sha(base/'normal-after.png')
assert sha(backup)==sha(base/'cut-check/enforcer/parts/torso.png')
assert sha(base/'normal-before.png')==sha(base/'normal-before-rebuilt.png')
old,patched,original_normal,baked=(np.asarray(Image.open(p).convert('RGBA')) for p in (backup,new,base/'normal-before.png',actual_normal))
changed=np.any(old!=patched,axis=2)
assert changed.sum()==712 and np.array_equal(patched[:,:,3],baked[:,:,3])
assert np.all(old[changed,3]<235) and np.all(old[changed,3]<patched[changed,3])
results['source']={'old':sha(backup),'diffuse':sha(actual_composite),'normal':sha(actual_normal),
                   'diffuse_pixels':int(changed.sum()),'normal_pixels':int(np.any(original_normal!=baked,axis=2).sum()),
                   'grid':[251,371]}
(base/'verification.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results))
