from pathlib import Path
from PIL import Image
import numpy as np

target=Path(__file__).resolve().parent/'torso-trial.png'
original=np.asarray(Image.open('art/characters/enforcer/parts/torso.png').convert('RGBA'))
candidate=original.copy()
for y in range(90,117):
    edge=original[y,180:239]
    opaque=np.flatnonzero(edge[:,3]>=235)
    if len(opaque)==0:
        continue
    span=candidate[y,180:181+opaque[-1]]
    replace=span[:,3] < 235
    span[replace]=original[y,177]
assert np.array_equal(candidate[original[:,:,3]>=235],original[original[:,:,3]>=235])
print('changed', np.count_nonzero(np.any(candidate!=original,axis=2)))
Image.fromarray(candidate).save(target)
