from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
import json,numpy as np
base=Path(__file__).resolve().parent
panels=[('stock-dressed','idle',12),('final-dressed','idle',12),('stock-whole','block',0),
        ('final-whole','block',0),('stock-whole','aim_up',29),('final-whole','aim_up',29)]
sheet=Image.new('RGB',(480,751),(34,36,45))
draw=ImageDraw.Draw(sheet)
for i,(scope,pose,n) in enumerate(panels):
 groups=json.loads((base/scope/'frames.json').read_bytes())
 group=next(g for g in groups if g['pose']==pose and g['zoom']==3.4)
 c=next(c for c in group['cells'] if c['facing']==1)
 x,y,w,h=c['rect']
 radius=c['radius']
 assert (w,h)==(128,128)
 with Image.open(base/scope/group['samples'][n]['file']) as frame:
  crop=frame.crop((x+40,y+38,x+96,y+94)).convert('RGBA')
 paper=Image.new('RGBA',crop.size,(117,116,134,255))
 paper.alpha_composite(crop)
 ox,oy=8+i%2*240,8+i//2*250
 sheet.paste(paper.resize((224,224),Image.Resampling.NEAREST).convert('RGB'),(ox,oy+16))
 draw.text((ox,oy),f'{scope} {pose} f{n}',fill='#f9fafc')
sheet.save(base/'final-contact.png')

