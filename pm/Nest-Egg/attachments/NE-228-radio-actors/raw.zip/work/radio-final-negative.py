from pathlib import Path
import subprocess,os,json,hashlib,re,time
w=Path('work/batch1024');n=Path('work/batch1020b')
while True:
 p=w/'radio-affected-receipt.json'
 if p.exists():
  d=json.loads(p.read_text())
  if d['exit'] is not None:
   assert d['exit']==0,d
   break
 time.sleep(10)
while (w/'world-repair-headless-running').exists():time.sleep(1)
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='ne228-radio-framing-1024'
frozen=json.loads((w/'radio-final-source.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for p,h in frozen.items():assert sha(Path(p).read_bytes())==h,p
paths=['ui/dialogue_layer.gd','ui/quest_guidance.gd'];fixed={p:Path(p).read_bytes() for p in paths};old={p:subprocess.check_output(['git','show',d['base']+':'+p]) for p in paths}
name='ne228-1024-radio-v6-before-final';cmd=['python',str(w/'native-large.py'),name,'res://work/batch1024/radio-clearance.tscn','--scenario=repair','--save-dir='+str((w/'radio-before-final-save').resolve())]
try:
 for p in paths:Path(p).write_bytes(old[p])
 with (w/'radio-before-final-driver.log').open('w') as f:r=subprocess.run(cmd,env={**os.environ,'NE_NATIVE_PROJECT':'../..'},stdout=f,stderr=subprocess.STDOUT,timeout=800)
finally:
 unexpected=[]
 for p in paths:
  if Path(p).read_bytes()==old[p]:Path(p).write_bytes(fixed[p])
  else:unexpected.append(p)
 assert not unexpected,('Unexpected concurrent edits preserved',unexpected)
t=(n/(name+'.log')).read_text();rec={'name':name,'base':d['base'],'exit':r.returncode,'checks':len(re.findall('^PASS |^FAIL ',t,re.M)),'failures':len(re.findall('^FAIL ',t,re.M)),'engine_errors':t.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',t)),'before_sha256':{p:sha(b) for p,b in old.items()},'restored_sha256':{p:sha(Path(p).read_bytes()) for p in paths},'command':cmd};(w/'radio-before-final-receipt.json').write_text(json.dumps(rec,indent=2))
assert rec['exit']==1 and rec['failures']>=1 and rec['engine_errors']==0 and rec['leaks']==0,rec
for p,h in frozen.items():assert sha(Path(p).read_bytes())==h,p
print('FINAL_NEGATIVE_RESTORED',json.dumps(rec),flush=True)
