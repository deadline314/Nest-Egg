from pathlib import Path
import subprocess,os,json,hashlib,time,re,struct
w=Path('work/batch1024');native=Path('work/batch1020b');rows=[]
while True:
 p=w/'radio-pair-control.json'
 if p.exists():
  pair=json.loads(p.read_text())
  if len(pair)==2:
   assert pair[0]['exit']==1 and pair[1]['exit']==0,pair
   break
 time.sleep(10)
source_paths=['ui/dialogue_layer.gd','tests/suite/test_combat_hud.gd','work/batch1024/radio-clearance.gd']
frozen={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in source_paths};(w/'radio-final-source.json').write_text(json.dumps(frozen,indent=2))
env={**os.environ,'NE_NATIVE_PROJECT':'../..'}
for suffix,args in [('en-reduced',['--language=en','--text-scale=1.2','--reduce-motion']),('ja-1080',['--language=ja','--text-scale=1.2','--size=1920x1080']),('zh-wide',['--text-scale=1.2','--size=2560x1080'])]:
 name='ne228-1024-radio-'+suffix;cmd=['python',str(native/'native.py'),name,'res://work/batch1024/radio-clearance.tscn','--scenario=repair','--save-dir='+str((w/(name+'-save')).resolve()),*args];start=time.monotonic()
 with (w/(name+'-driver.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=800)
 t=(native/(name+'.log')).read_text();images=[]
 for p in (native/name).glob('*.png'):
  with p.open('rb') as f:header=f.read(24)
  images.append({'path':str(p.resolve()),'size':struct.unpack('>II',header[16:24]),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 record={'name':name,'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start,'checks':len(re.findall('^PASS |^FAIL ',t,re.M)),'failures':len(re.findall('^FAIL ',t,re.M)),'engine_errors':t.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',t)),'images':images};rows.append(record);(w/'radio-final-matrix.json').write_text(json.dumps(rows,indent=2));print(name,record['checks'],record['failures'],r.returncode,flush=True);assert r.returncode==0 and record['failures']==0 and record['engine_errors']==0 and record['leaks']==0
for p,h in frozen.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();env.update(GODOT=str((native/'godot472/Godot_v4.7.2-stable_linux.x86_64').resolve()),SHARDS='2',LOG_DIR=str((w/'radio-affected-shards').resolve()));start=time.monotonic();(w/'radio-affected-receipt.json').write_text(json.dumps({'base':base,'exit':None,'shards':2},indent=2))
with (w/'radio-affected.log').open('w') as f:r=subprocess.run(['tools/run_tests_changed.sh',base],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2700)
(w/'radio-affected-receipt.json').write_text(json.dumps({'base':base,'exit':r.returncode,'seconds':time.monotonic()-start,'shards':2},indent=2));assert r.returncode==0
for p,h in frozen.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
print('RADIO_FINAL_ALL_GREEN',flush=True)
