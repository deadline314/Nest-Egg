from pathlib import Path
import subprocess,os,json,hashlib,re,time,shutil
w=Path('work/batch1024');sha=lambda b:hashlib.sha256(b).hexdigest();old_frozen=json.loads((w/'radio-final-source.json').read_text())
for p,h in old_frozen.items():assert sha(Path(p).read_bytes())==h,p
assert 'checks: 299, failures: 0' in (w/'radio-collectibles-final-ja2.log').read_text()
rows=json.loads((w/'radio-final-matrix.json').read_text());assert len(rows)==4 and all(r['exit']==0 and r['failures']==0 and r['engine_errors']==0 and r['leaks']==0 for r in rows)
view=json.loads((w/'radio-viewed-final.json').read_text());assert len(view['files'])==8 and view['individually_viewed']
for x in view['files']:assert sha(Path(x['file']).read_bytes())==x['sha256']
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();story='data/story/ch1_kasa.json';assert Path(story).read_bytes()==subprocess.check_output(['git','show',base+':'+story])
(w/'radio-native-core-source-v6.json').write_text(json.dumps(old_frozen,indent=2));frozen={**old_frozen,'data/story_items/i18n.json':sha(Path('data/story_items/i18n.json').read_bytes())};(w/'radio-final-source.json').write_text(json.dumps(frozen,indent=2));(w/'radio-native-reuse.json').write_text(json.dumps({'previous_radio_source_exact':old_frozen,'final_extra_source':{'data/story_items/i18n.json':frozen['data/story_items/i18n.json']},'canonical_radio_authored_source':{story:sha(Path(story).read_bytes())},'changed_item_texts':['ch1_market_summary/ja/body','ch3_report_p17/ja/body','ch3_tour_card/ja/body'],'scope':'Four V6 radio processes82/0 and8viewedPNG reused: all 8 source/probe/capture inputs byte exact; only three unrelated plot-item Japanese body strings changed. Original299panelcontract rerun, entire original76selector rerun. Does not claim full InventoryPage body entry was verified.'},indent=2))
env={**os.environ,'GODOT':str(Path('work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64').resolve()),'SHARDS':'6','LOG_DIR':str((w/'radio-affected-v7-6-shards').resolve())};rec={'base':base,'exit':None,'shards':6,'log_dir':env['LOG_DIR'],'command':['tools/run_tests_changed.sh',base],'reason':'After real preexisting Japanese panel-contract failure, preserve all original assertions and compact only3JAtexts. Original76groups rerun. Six workers fit16GiB; previous4workers averaged~2CPU of4quota while awaiting physics, Melee440.7s dominated its worker. Native rendering serial.'};(w/'radio-affected-receipt.json').write_text(json.dumps(rec,indent=2));start=time.monotonic()
with (w/'radio-affected.log').open('w') as f:r=subprocess.run(rec['command'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=3000)
rec.update(exit=r.returncode,seconds=time.monotonic()-start);(w/'radio-affected-receipt.json').write_text(json.dumps(rec,indent=2));assert r.returncode==0,rec
for p,h in frozen.items():assert sha(Path(p).read_bytes())==h,p
with (w/'radio-final-negative-v7-driver.log').open('w') as f:r=subprocess.run(['python',str(w/'radio-final-negative.py')],stdout=f,stderr=subprocess.STDOUT,timeout=1000)
assert r.returncode==0
print('V7_ALL_REQUIRED_AND_FINAL_NEGATIVE_DONE',flush=True)
