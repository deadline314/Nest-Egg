from pathlib import Path
import subprocess,os,time,json,hashlib,re
w=Path('work/batch1024');native=Path('work/batch1020b');exit_file=native/'ne228-1024-radio-v6-wide-check.exit'
while not exit_file.exists():time.sleep(2)
assert exit_file.read_text()=='0'
p=Path('tests/suite/test_combat_hud.gd');s=p.read_text();assert '_test_radio_crowded_gutter' not in s;s=s.replace('\tawait _test_radio_tall_clearance(true)\n','\tawait _test_radio_tall_clearance(true)\n\tawait _test_radio_crowded_gutter()\n')+(w/'radio-gutter-test.txt').read_text();p.write_text(s)
ui=Path('ui/dialogue_layer.gd');fixed=ui.read_bytes();old=(w/'dialogue-layer-fixed-v5.gd').read_bytes();expected=json.loads((w/'v5-radio-final-source.json').read_text())['ui/dialogue_layer.gd'];assert hashlib.sha256(old).hexdigest()==expected
cmd=[str((native/'godot472/Godot_v4.7.2-stable_linux.x86_64').resolve()),'--headless','res://tests/smoke_test.tscn','--','--only=CombatHudSuite'];rows=[]
for before in [True,False]:
 name='radio-gutter-'+('negative' if before else 'positive');data=old if before else fixed
 assert ui.read_bytes()==fixed;ui.write_bytes(data)
 try:
  with (w/(name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 finally:
  assert ui.read_bytes()==data,'Concurrent UI changes preserved: cannot restore'
  ui.write_bytes(fixed)
 t=(w/(name+'.log')).read_text();row={'name':name,'exit':r.returncode,'summary':[x for x in t.splitlines() if x.startswith('checks:')],'script_errors':t.count('SCRIPT ERROR:'),'source_ui_sha256':hashlib.sha256(data).hexdigest()};rows.append(row);(w/'radio-gutter-control.json').write_text(json.dumps(rows,indent=2));print(row,flush=True);assert row['script_errors']==0;assert r.returncode==(1 if before else 0)
with (w/'radio-final-matrix-v6-driver.log').open('w') as f:r=subprocess.run(['python',str(w/'radio-final-matrix.py')],stdout=f,stderr=subprocess.STDOUT,timeout=6000)
assert r.returncode==0
with (w/'radio-final-negative-v6-driver.log').open('w') as f:r=subprocess.run(['python',str(w/'radio-final-negative.py')],stdout=f,stderr=subprocess.STDOUT,timeout=1000)
assert r.returncode==0
print('V6_ALL_VERIFICATION_DONE',flush=True)
