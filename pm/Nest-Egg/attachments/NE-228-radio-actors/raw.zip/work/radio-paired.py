from pathlib import Path
import subprocess,os,json,hashlib
w=Path('work/batch1024');p=Path('ui/dialogue_layer.gd');fixed=p.read_bytes();old=(w/'dialogue-layer-before.gd').read_bytes();(w/'dialogue-layer-fixed-v1.gd').write_bytes(fixed);rows=[];env={**os.environ,'NE_NATIVE_PROJECT':'../..'}
try:
 p.write_bytes(old)
 name='ne228-1024-radio-before-v3';cmd=['python','work/batch1020b/native.py',name,'res://work/batch1024/radio-clearance.tscn','--scenario=repair','--save-dir='+str((w/'radio-before-v3-save').resolve())]
 with (w/'radio-before-v3-driver.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
 rows.append({'name':name,'exit':r.returncode,'source_sha256':hashlib.sha256(old).hexdigest()})
finally:
 assert p.read_bytes()==old,'Unexpected concurrent source edit: preserve it instead of restoring'
 p.write_bytes(fixed)
(w/'radio-pair-control.json').write_text(json.dumps(rows,indent=2));assert rows[-1]['exit']==1
name='ne228-1024-radio-after-v3';cmd=['python','work/batch1020b/native.py',name,'res://work/batch1024/radio-clearance.tscn','--scenario=repair','--save-dir='+str((w/'radio-after-v3-save').resolve())]
with (w/'radio-after-v3-driver.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
rows.append({'name':name,'exit':r.returncode,'source_sha256':hashlib.sha256(fixed).hexdigest()});(w/'radio-pair-control.json').write_text(json.dumps(rows,indent=2));assert r.returncode==0
print('PAIRED_NATIVE_GREEN',flush=True)
