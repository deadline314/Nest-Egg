from pathlib import Path
import os,subprocess,json,hashlib,time,shutil
w=Path('work/batch1024');frozen=json.loads((w/'radio-final-source.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for pid in [7703,7705]:
 for attempt in range(100):
  p=Path('/proc')/str(pid)/'stat'
  if not p.exists() or p.read_text().split()[2]=='Z':break
  time.sleep(0.1)
 else:raise RuntimeError('Previous owned worker did not exit')
for p,h in frozen.items():assert sha(p)==h,p
rows=json.loads((w/'radio-final-matrix.json').read_text());assert len(rows)==4 and all(r['exit']==0 and r['failures']==0 and r['engine_errors']==0 and r['leaks']==0 for r in rows)
for name in ['radio-affected.log','radio-affected-receipt.json']:
 p=w/name
 if p.exists():shutil.copy2(p,w/('v6-shards2-interrupted-'+name))
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert base.startswith('b45aa58e')
rec={'base':base,'exit':None,'shards':4,'command':['tools/run_tests_changed.sh',base],'reason':'4 CPU quota cores and 16GiB limit; two original headless workers consumed only ~1.65cores/1.2GiB. Identical original76selected suites and frozen source; previous 61second partial intentionally interrupted, archived and not counted as passed.'};(w/'radio-affected-receipt.json').write_text(json.dumps(rec,indent=2));env={**os.environ,'GODOT':str((Path('work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64')).resolve()),'SHARDS':'4','LOG_DIR':str((w/'radio-affected-v6-4-shards').resolve())};start=time.monotonic()
with (w/'radio-affected.log').open('w') as f:r=subprocess.run(rec['command'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=3000)
rec.update(exit=r.returncode,seconds=time.monotonic()-start);(w/'radio-affected-receipt.json').write_text(json.dumps(rec,indent=2));assert r.returncode==0,rec
for p,h in frozen.items():assert sha(p)==h,p
with (w/'radio-final-negative-v6-driver.log').open('w') as f:r=subprocess.run(['python',str(w/'radio-final-negative.py')],stdout=f,stderr=subprocess.STDOUT,timeout=1000)
assert r.returncode==0
print('V6_AFFECTED4_AND_NEGATIVE_DONE',flush=True)
