from pathlib import Path
import subprocess,os,json,hashlib,re
w=Path('work/batch1024');base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();frozen=json.loads((w/'radio-final-source.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();paths=[p for p in frozen if not p.startswith('work/')];fixed={p:Path(p).read_bytes() for p in paths};old={p:subprocess.check_output(['git','show',base+':'+p]) for p in paths};rows=[]
for p,b in fixed.items():assert sha(b)==frozen[p]
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='ne228-radio-framing-1024'
for before in [True,False]:
 name='collectibles-'+('baseline' if before else 'current')
 try:
  if before:
   for p,b in old.items():Path(p).write_bytes(b)
  cmd=[str(Path('work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64').resolve()),'--headless','res://tests/smoke_test.tscn','--','--only=CollectiblesSuite']
  with (w/(name+'.log')).open('w') as f:r=subprocess.run(cmd,env={**os.environ,'XDG_DATA_HOME':str((w/(name+'-profile')).resolve())},stdout=f,stderr=subprocess.STDOUT,timeout=300)
 finally:
  if before:
   for p,b in old.items():
    assert Path(p).read_bytes()==b,('Concurrent edits retained',p)
    Path(p).write_bytes(fixed[p])
 t=(w/(name+'.log')).read_text();rec={'name':name,'base':base,'exit':r.returncode,'checks_summary':[x for x in t.splitlines() if x.startswith('checks:')],'failures':[x for x in t.splitlines() if x.startswith('FAIL:')],'script_errors':t.count('SCRIPT ERROR:'),'product_sha256':{p:sha((old if before else fixed)[p]) for p in paths}};rows.append(rec);(w/'collectibles-pair.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rec),flush=True)
for p,b in fixed.items():assert Path(p).read_bytes()==b,p
