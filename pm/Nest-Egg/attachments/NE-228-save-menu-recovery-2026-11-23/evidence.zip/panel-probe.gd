extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const CASES := ["unsupported", "unreadable", "backup", "new_run", "edition"]
const NEXT_LEVEL := "res://data/levels/ch2_pawnshop.tres"
const COPY := {
	"en": [
		"This version cannot read your save. It was kept. Use a compatible game version.",
		"Could not read your save. It was kept. You can start a new game.",
		"Your backup was recovered. You can continue.",
		"Your new game was recovered. You can continue.",
		"Open Prologue–Chapter 2 to continue. That save stays intact.",
	],
	"ja": [
		"このセーブは読み込めません。元のデータは残っています。対応するバージョンを使ってください。",
		"セーブを読み込めませんでした。元のデータは残っています。新しく始めることもできます。",
		"バックアップから復元しました。ゲームを再開できます。",
		"開始した新しいゲームを復元しました。続きから再開できます。",
		"再開するには「序章～第2章」を開いてください。セーブは保持されます。",
	],
}

var _out := ""
var _language := "en"
var _checks := 0
var _failures := 0


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=")
		if argument.begins_with("--language="):
			_language = argument.trim_prefix("--language=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://save-menu-read-status.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	Story.set_language(_language)
	GameState.story_autosave = false
	GameState.start_new_run(GameState.difficulties[1])
	var development := CampaignEdition.current()
	var edition := development.describe("through-ch1_kasa")
	var saved := RunSnapshot.capture(development.first_level,
			{"position": [-1, -1], "health": 4, "world": {}, "loadout": {}})
	var expected: Array = COPY[_language]
	for index in CASES.size():
		var kind: String = CASES[index]
		var store := RunSaveStore.new("user://save-menu-cases".path_join(kind).path_join("slot.json"))
		store.validator = RunSnapshot.prepare
		var absolute := ProjectSettings.globalize_path(store.path)
		DirAccess.make_dir_recursive_absolute(absolute.get_base_dir())
		var seed_ok := true
		match kind:
			"unsupported":
				seed_ok = _write(store.path, '{"version":999}')
			"unreadable":
				seed_ok = _write(store.path, '{"version":1}')
			"backup":
				seed_ok = store.write(saved, true) and _write(store.path, '{"version":1}')
			"new_run":
				var renewed := saved.duplicate(true)
				renewed["progression"]["credits"] = 52
				seed_ok = store.write(saved, true) and _write(store.path + ".freshbak", RunSaveCodec.encode(renewed)) and store._begin_new_run(absolute)
			"edition":
				var later := saved.duplicate(true)
				later["release"] = "through-ch2_heron"
				later["level"] = NEXT_LEVEL
				seed_ok = _write(store.path, RunSaveCodec.encode(later))
				CampaignEdition.override_current(edition)
		_check(seed_ok, kind + " creates a real isolated save fixture")
		var original := FileAccess.get_sha256(store.path)
		var backup := FileAccess.get_sha256(store.path + ".bak") if FileAccess.file_exists(store.path + ".bak") else ""
		var main: Node = load("res://game/main.gd").new()
		main.set("_run_store", store)
		add_child(main)
		var menu: MainMenu
		for frame in 180:
			menu = main.get("_screen") as MainMenu
			if menu != null and not GameplayLock.is_locked():
				break
			await get_tree().process_frame
		_check(menu != null, kind + " original Main opens its title")
		if menu != null:
			var resume := kind in ["backup", "new_run"]
			_check(menu.continue_available == resume and menu.overwrite_required, kind + " only a valid recovery exposes Continue and all occupied slots still request confirmation")
			_check(menu.save_notice == expected[index], kind + " shows the localized outcome: " + menu.save_notice)
			var notice: Label
			for label: Label in menu._main_page.find_children("*", "Label", true, false):
				if label.text == menu.save_notice and label.is_visible_in_tree():
					notice = label
					break
			var panel := notice.get_parent() as PanelContainer if notice != null else null
			_check(notice != null and panel != null and notice.get_visible_line_count() == notice.get_line_count()
					and get_viewport().get_visible_rect().encloses(panel.get_global_rect())
					and (menu._dev_button == null or not panel.get_global_rect().intersects(menu._dev_button.get_global_rect())),
					kind + " has a readable panel clear of the title actions at 120 percent")
			_check((kind == "new_run" and not FileAccess.file_exists(store.path + ".newrun")
					and main.get("_continue_data")["progression"]["credits"] == 52)
					or (kind != "new_run" and FileAccess.get_sha256(store.path) == original
					and (backup.is_empty() or FileAccess.get_sha256(store.path + ".bak") == backup)),
					kind + " recovers only a previously confirmed new run and preserves other original files")
			if kind in ["backup", "edition"]:
				await RenderingServer.frame_post_draw
				_check(Capture.image(get_viewport()).save_png(_out.path_join(kind + ".png")) == OK, kind + " captures real screen")
		main.queue_free()
		for frame in 10:
			await get_tree().process_frame
		CampaignEdition.override_current(development)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _failures])
	get_tree().quit(1 if _failures else 0)


func _write(path: String, contents: String) -> bool:
	var file := FileAccess.open(path, FileAccess.WRITE)
	return file != null and file.store_string(contents)


func _check(passed: bool, message: String) -> void:
	_checks += 1
	_failures += int(not passed)
	if not passed:
		printerr("FAIL: ", message)
