extends Node

const EXPECTED := {
	"zh": "舊版只保存故事，無法繼續整輪。可開始新遊戲，原故事檔會保留。",
	"ja": "旧版はストーリーのみを保存します。元のデータを残したまま、新しく始められます。",
	"en": "The old save contains story progress only. You can start a new game and keep it.",
}
var _checks := 0
var _failures := 0


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://legacy-story-menu-probe.cfg")
	Settings.set_reduce_ui_motion(true)
	GameState.story_autosave = false
	var path := GameState.STORY_SAVE_PATH
	var fixture := FileAccess.open(path, FileAccess.WRITE)
	_check(fixture != null and fixture.store_string("{}"), "seed the isolated old story file")
	if fixture != null:
		fixture.close()
	fixture = null
	var original := FileAccess.get_sha256(path)
	for language in EXPECTED:
		Story.set_language(language)
		var main: Node = load("res://game/main.gd").new()
		var slot := RunSaveStore.new("user://isolated-legacy-test/" + language + "/slot.json")
		main.set("_run_store", slot)
		add_child(main)
		var menu: MainMenu
		for frame in 180:
			menu = main.get("_screen") as MainMenu
			if menu != null and not GameplayLock.is_locked():
				break
			await get_tree().process_frame
		_check(menu != null and menu.save_notice == EXPECTED[language]
				and not menu.continue_available and not menu.overwrite_required
				and FileAccess.get_sha256(path) == original and not slot.exists(),
				language + " shows the old-story notice and keeps the original file")
		main.queue_free()
		for frame in 8:
			await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _failures])
	get_tree().quit(1 if _failures else 0)


func _check(passed: bool, message: String) -> void:
	_checks += 1
	_failures += int(not passed)
	if not passed:
		printerr("FAIL: ", message)
