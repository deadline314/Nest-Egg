extends Node

const BOOTH := preload("res://data/levels/ch1_booth_alley.tres")
const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://end-screens-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.set_language("en")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.register_death()
	GameState.set_flag(&"ch1_first_death_done")
	GameState.set_flag(&"ch1_prologue_exit")
	Progression.credits = 1000
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(BOOTH)
	add_child(level)
	await _frames(25)
	var lethal := DamageInfo.create(9999, Combat.Team.ENEMY, &"grunt_shot")
	lethal.ignore_invulnerability = true
	level.player.health.take_damage(lethal)
	var death: DeathScreen
	for frame in 360:
		for child in level.get_children():
			if child is DeathScreen:
				death = child
				break
		if death != null and death._sequence_buttons != null and death._sequence_buttons.visible:
			break
		await _frames(1)
	_check(death != null and level.died and GameState.deaths == 2 and not GameState.has_checkpoint,
			"ordinary lethal damage opens the actual death screen with no active checkpoint")
	if death == null:
		level.queue_free()
		await _finish()
		return
	var retry := death.get_viewport().gui_get_focus_owner() as Button
	_check(retry != null and death.is_ancestor_of(retry) and retry.text == "Restart area",
			"the focused retry describes the actual area restart, not a missing checkpoint")
	_check(_has_label(death, "NEST Restoration Log #2") and _has_label(death, "Mission failed"),
			"the actual English recovery record and state are visible")
	var bar := death.find_child("FocusHintBar", true, false) as FocusHintBar
	_check(retry != null and bar != null and bar.text() == "Start this area again." and retry.tooltip_text == bar.text(),
			"focused recovery guidance and Hover agree")
	_check(retry != null and bar != null and bar.get_global_rect().position.y >= retry.get_global_rect().end.y - 0.5,
			"the 120 percent recovery hint remains beneath the action row")
	var protected := false
	for node in death.find_children("*", "PanelContainer", true, false):
		if node is UiPanel and is_instance_valid(retry) and node.is_ancestor_of(retry):
			protected = true
			break
	_check(protected, "the recovery title and actions share a surface above the world notification")
	await _picture("death-en.png")
	var retried := [0]
	level.retry_requested.connect(func() -> void: retried[0] += 1)
	await _joy(JOY_BUTTON_A)
	_check(retried[0] == 1, "the original retry action receives one controller confirmation")
	level.queue_free()
	await _frames(6)

	Story.set_language("ja")
	var original_edition := CampaignEdition.current()
	CampaignEdition.override_current(original_edition.describe("through-ch3_clearwater"))
	var victory := VictoryScreen.new()
	victory.chapter = &"ch3_clearwater"
	add_child(victory)
	await _frames(9)
	_check(_has_label(victory, "リザルト") and _has_label(victory, "難易度　標準")
			and _has_label(victory, "クリア時間"), "the actual results, difficulty and stats are Japanese")
	var teaser := victory._rows.back() as Label
	_check(teaser.text.contains(str(Story.chapter_info(victory.chapter).get("teaser", "")))
			and teaser.text.ends_with("このエディションはここまでです。進行状況を保存しました。"),
			"the authored preview and the release notice use the same Japanese locale")
	_check(victory.get_global_rect().encloses(teaser.get_global_rect()) and teaser.get_line_count() == teaser.get_visible_line_count(),
			"the whole chapter teaser and edition notice fit at 120 percent")
	_check(victory._buttons[0].text == "もう一度遊ぶ" and victory._buttons[1].text == "メインメニューへ"
			and victory._buttons.all(func(button: Button) -> bool: return victory.get_global_rect().encloses(button.get_global_rect())),
			"both result actions are visible and localized")
	var exits := [0]
	victory.menu_requested.connect(func() -> void: exits[0] += 1)
	await _joy(JOY_BUTTON_DPAD_RIGHT)
	_check(victory.get_viewport().gui_get_focus_owner() == victory._buttons[1], "controller changes focus on the results screen")
	await _picture("victory-ja.png")
	await _joy(JOY_BUTTON_A)
	_check(exits[0] == 1, "the original results action receives one controller confirmation")
	victory.queue_free()
	CampaignEdition.override_current(original_edition)
	await _finish()


func _has_label(root: Node, text: String) -> bool:
	if root is Label and (root as Label).text.contains(text):
		return true
	for child in root.get_children():
		if _has_label(child, text):
			return true
	return false


func _picture(file: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(file)) == OK, "captured actual " + file)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish() -> void:
	await _frames(7)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))
