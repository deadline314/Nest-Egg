extends Node

const BOOTH := "res://data/levels/ch1_booth_alley.tres"
const MainScript := preload("res://game/main.gd")

var _checks := 0
var _failures := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://caption-probe.cfg")
	Story.set_language("en")
	Story.auto_skip = true
	Transition.instant = true
	var main := MainScript.new()
	main.set("_run_store", RunSaveStore.new("user://caption-probe-slot.json"))
	add_child(main)
	await _frames(3)
	main._on_start_requested(GameState.difficulties[1])
	await _frames(18)
	main._on_area_requested(BOOTH)
	await _frames(20)
	var level := main.get("_screen") as Level
	_check(level != null and level.data.resource_path == BOOTH, "Main loads the actual booth area into an isolated campaign")
	if level == null or level.data.resource_path != BOOTH:
		await _finish(main)
		return
	GameState.register_death()
	GameState.set_flag(&"ch1_first_death_done")
	var lethal := DamageInfo.create(9999, Combat.Team.ENEMY, &"grunt_shot")
	lethal.ignore_invulnerability = true
	level.player.health.take_damage(lethal)
	var death: DeathScreen
	for frame in 360:
		for node in level.get_children():
			if node is DeathScreen:
				death = node
				break
		if death != null and death._sequence_buttons != null and death._sequence_buttons.visible:
			break
		await _frames(1)
	_check(death != null and level.died and GameState.deaths == 2 and not GameState.has_checkpoint,
			"actual lethal damage opens record number two without creating a checkpoint")
	if death == null:
		await _finish(main)
		return
	var title := "NEST Restoration Log #2"
	var shown := false
	for node in death.find_children("*", "Label", true, false):
		if (node as Label).text == title:
			shown = true
			break
	_check(shown, "the player sees the localized title in the death screen")
	Transition.instant = false
	var captured := [""]
	var covered := func() -> void: captured[0] = Transition._caption.text
	Transition.covered.connect(covered, CONNECT_ONE_SHOT)
	var event := InputEventJoypadButton.new()
	event.button_index = JOY_BUTTON_A
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(1)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	for frame in 360:
		if not captured[0].is_empty() and not Transition.is_active():
			break
		await _frames(1)
	print("RETRY_CAPTION_RECEIVED ", captured[0])
	_check(shown and captured[0] == title, "the actual covering transition uses the same localized record title")
	var next := main.get("_screen") as Level
	_check(is_instance_valid(next) and next != level and next.data.resource_path == BOOTH
			and not next.player.is_dead() and not Transition.is_active(),
			"retry reloads the original area through Main and releases the transition")
	if Transition.covered.is_connected(covered):
		Transition.covered.disconnect(covered)
	await _finish(main)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_failures += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish(main: Node) -> void:
	Transition.abort()
	Transition.instant = false
	main.queue_free()
	await _frames(9)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _failures])
	get_tree().quit(int(_failures != 0))
