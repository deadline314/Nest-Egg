from pathlib import Path
import json

scope = Path(__file__).resolve().parent
older_bar = scope.parent / "evidence-20261120-ne228-weapon-hints"
older_map = scope.parent / "evidence-20261120-ne228-map-hint-language"
read = lambda file: json.loads(file.read_bytes())
comparison = {}
expected = {"zh": ("滾輪↑", "滾輪↓", "右鍵"), "ja": ("ホイール↑", "ホイール↓", "右クリック"),
            "en": ("Wheel ↑", "Wheel ↓", "Right click")}
for locale, (up, down, click) in expected.items():
    before_bar = read(older_bar / f"candidate-{locale}/run.json")
    before_map = read(older_map / f"candidate-v6-{locale}/run.json")
    after_bar = read(scope / f"bar/candidate-{locale}/run.json")
    after_map = read(scope / f"map/candidate-{locale}/run.json")
    receipts = before_bar, before_map, after_bar, after_map
    assert all(r["exit"] == 0 and not r["errors"] and r["resolution"]["language"] == locale for r in receipts)
    assert len({r["input_save"] for r in receipts}) == 1
    old_bar, old_map, bar, map_ = (r["resolution"]["samples"] for r in receipts)
    assert old_bar["default"]["prev"] == "滾輪↑" and old_bar["default"]["next"] == "滾輪↓"
    assert bar["default"]["prev"] == up and bar["default"]["next"] == down
    assert all(row["hovered"] and row["cursor_on_row"] for row in bar.values())
    assert up in bar["default"]["text"] and down in bar["default"]["text"]
    assert old_bar["remapped"]["text"] == bar["remapped"]["text"] and bar["remapped"]["prev"] == "V" and bar["remapped"]["next"] == "N"
    assert old_bar["equipped"]["text"] == bar["equipped"]["text"] == bar["equipped-after"]["text"]
    assert old_map["reflect"]["text"] == map_["reflect"]["text"] and old_map["reflect"]["keycaps"] == ["右鍵"]
    assert map_["reflect"]["keycaps"] == [click] and map_["reflect-rebound"]["keycaps"] == ["B"]
    assert all(row["near"] and row["visible"] and row["fits"] for row in map_.values())
    comparison[locale] = {"old": [old_bar["default"]["prev"], old_bar["default"]["next"], old_map["reflect"]["keycaps"][0]],
                          "current": [up, down, click], "kept_remapped": ["V", "N", "B"]}
(scope / "comparison.json").write_text(json.dumps(comparison, ensure_ascii=False, indent=2) + "\n", "utf-8")
print({language: len(items["current"]) for language, items in comparison.items()})
