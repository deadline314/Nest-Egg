extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const FRAMES := 1800
const BONE := &"hand_front"
const AREAS := [
	["ch1_pawnshop", "ch1_old_k", "old_k", "wipe_hands"],
	["ch1_rooftop", "ch1_egret", "egret", "yawn"],
	["ch1_lounge", "ch1_ali_lounge", "ali", "wipe_hands"],
	["ch1_stall", "ch1_ali_stall", "ali", "stir"],
]

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://live-npc-hold.cfg")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_prologue_exit", true, false)
	add_child(LightKit.create_environment())
	for target: Array in AREAS:
		if target[0] == "ch1_stall":
			GameState.set_flag(&"ch1_lounge_evening_done", true, false)
		await _sample_area(String(target[0]), StringName(target[1]), String(target[2]), StringName(target[3]))
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))


func _sample_area(area: String, id: StringName, skin: String, loop: StringName) -> void:
	var level := Level.new()
	level.configure(load("res://data/levels/" + area + ".tres") as LevelData)
	add_child(level)
	await _wait(30)
	var npc: NpcActor
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and node.data.id == id and level.is_ancestor_of(node):
			npc = node
			break
	_check(npc != null and npc.data.rig_id == skin and npc._present and is_instance_valid(npc._actor)
			and npc._actor.rig != null and npc._actor.rig.is_valid(), area + " contains its original authored character")
	if npc == null or not is_instance_valid(npc._actor) or npc._actor.rig == null:
		level.queue_free()
		await _wait(6)
		return
	level.player.global_position = npc.global_position + Vector2(-108.0, -6.0)
	level.player.set_physics_process(false)
	await _wait(100)
	var rig := npc._actor.rig
	var animator := rig.animator as NpcAnimator
	var hand := rig.bone(BONE)
	var head := rig.bone(&"head")
	if animator == null or hand == null or head == null:
		_check(false, area + " contains the actual NPC animator and landmarks")
		level.queue_free()
		await _wait(6)
		return
	var motion := 0.0
	var peak_step := 0.0
	var finite := true
	var loop_frames := 0
	var visible_frames := 0
	var last := hand.global_position
	var started := npc._time
	for frame in FRAMES:
		await get_tree().process_frame
		var sample := hand.global_position
		finite = finite and sample.is_finite() and head.global_position.is_finite()
		if finite:
			var traveled := last.distance_to(sample)
			motion += traveled
			peak_step = maxf(peak_step, traveled)
			last = sample
		loop_frames += int(animator._use_npc and animator._loop_name == loop)
		var canvas_pos := get_viewport().get_canvas_transform() * head.global_position
		visible_frames += int(npc.is_visible_in_tree() and get_viewport().get_visible_rect().has_point(canvas_pos))
		if frame == FRAMES / 2 and DisplayServer.get_name() != "headless":
			await RenderingServer.frame_post_draw
			_check(Capture.image(get_viewport()).save_png(_out.path_join(area + ".png")) == OK, "captured " + area)
	var elapsed := npc._time - started
	print("NPC ", JSON.stringify({"area": area, "id": String(id), "loop": String(loop), "game_seconds": elapsed,
		"sample_frames": FRAMES, "loop_frames": loop_frames, "visible_frames": visible_frames,
		"hand_travel": motion, "peak_hand_step": peak_step}))
	_check(finite and motion > 1.0 and elapsed >= 29.0 and elapsed <= 31.0,
			area + " keeps a moving finite rig through about 30 simulated game seconds")
	_check(loop_frames >= FRAMES - 2 and visible_frames >= FRAMES - 2, area + " maintains the authored work loop in view")
	level.queue_free()
	await _wait(8)


func _wait(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)
