from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import os
import re
import subprocess
import sys

root = Path.cwd()
scratch = Path(__file__).resolve().parent
project = Path("C:/Users/stanl/.codex/worktrees/nestegg-candidate-verification/Nest-Egg")
scope = ["tools/rig_joint_audit.gd", "tools/check_joint_frames.py", "art/characters/old_k",
         "art/characters/ali", "art/characters/egret", "art/rigs", "art/motion", "game/rig", "core/character"]
diff = subprocess.check_output(["git", "diff", "--name-only", "c72b32806..HEAD", "--", *scope], cwd=root)
assert not diff, diff.decode()
assert not subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"], cwd=project)
assert subprocess.check_output(["git", "rev-parse", "--short=9", "HEAD"], cwd=project).strip() == b"c72b32806"
for case, cast, pose in (
    ("seated-talk", "old_k,ali,egret", "sit_talk"),
    ("sitting-listen", "old_k,ali,egret", "sit_listen"),
    ("work-old-k-and-ali", "old_k,ali", "loop:wipe_hands"),
    ("work-ali", "ali", "loop:stir"),
    ("lookout-egret", "egret", "lean"),
):
    with TemporaryDirectory(prefix="joint-pass-", dir=scratch) as output:
        target = Path(output).resolve()
        assert target.parent == scratch.resolve() and target.name.startswith("joint-pass-")
        profile = target / "profile"
        profile.mkdir()
        environment = dict(os.environ, APPDATA=str(profile), LOCALAPPDATA=str(profile))
        command = [
            sys.executable, "-B", str(project / "tools/comfyui/gpu_lock.py"), "--",
            "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(project),
            "--audio-driver", "Dummy", "--rendering-method", "forward_plus", "--rendering-driver", "vulkan",
            str(scratch / "probe.tscn"), "--", f"--out={target}", f"--chars={cast}",
            "--npc-performance", f"--npc-pose={pose}", "--zooms=1.0,3.4", "--frames=60",
        ]
        with (scratch / (case + "-render.log")).open("wb") as raw:
            result = subprocess.run(command, cwd=project, env=environment, stdout=raw,
                                    stderr=subprocess.STDOUT, timeout=240)
        log = (scratch / (case + "-render.log")).read_text(encoding="utf-8")
        assert result.returncode == 0 and "RX 9070 XT" in log and log.count("JOINT_FRAMES") == 2
        assert not re.search(r"(?m)^(?:SCRIPT )?ERROR:", log)
        analysis = subprocess.run([sys.executable, "-B", str(root / "tools/check_joint_frames.py"), str(target)],
                                  cwd=root, capture_output=True, timeout=90)
        assert analysis.returncode in (0, 1)
        report = json.loads((target / "report.json").read_bytes())
        names = [(item["char"], item["joint"], item["pose"], item["zoom"], item["facing"])
                 for item in report["failures"]
                 if item["center_alpha"] < 128 or item["enclosed_pixels"] or item["loose_pieces"]]
        assert report["samples"] == len(cast.split(",")) * 14 * 2 * 2 * 60
        summary = {"name": case, "samples": report["samples"], "edge": report["edge_notch_only_samples"],
                   "non_edge": len(names),
                   "non_edge_by_joint": [{"case": list(name), "count": count} for name, count in Counter(names).most_common()]}
        print(json.dumps(summary), flush=True)
        (scratch / (case + "-summary.json")).write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
        if names:
            classified = [sample for sample in report["failures"]
                          if sample["center_alpha"] < 128 or sample["enclosed_pixels"] or sample["loose_pieces"]]
            (scratch / (case + "-locations.json")).write_text(json.dumps(classified, indent=1) + "\n", encoding="utf-8")
