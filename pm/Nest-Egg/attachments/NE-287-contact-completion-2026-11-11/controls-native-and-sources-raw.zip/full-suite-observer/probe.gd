extends "res://tests/smoke_test.gd"

var _snapshots: Array = []

func _check(ok: bool, message: String) -> void:
	if message.begins_with("natural choreography sets"):
		for child in get_children():
			if child is CutscenePlayer:
				var stage: StageLibrary.Stage = child._stage
				var expected: Vector2 = preload("res://tests/helpers/kitchen_choreography_checks.gd")._mat_support(stage)
				var actual: Vector2 = stage.prop_node("kettle").position
				var actor: CutsceneActor = child._actors[&"k"]
				var reach: CutsceneReach = actor._reaches[0]
				_snapshots.append({"ok": ok, "actual": [actual.x, actual.y], "expected": [expected.x, expected.y],
					"distance": actual.distance_to(expected), "state": stage.prop_state("kettle"),
					"steps": child.steps_run, "pose": str(actor.pose), "speed": child.speed,
					"scale": Engine.time_scale, "paused": get_tree().paused})
	super._check(ok, message)

func _finish() -> void:
	print("KITCHEN_SUITE_OBSERVER ", JSON.stringify(_snapshots))
	await super._finish()
