extends Node
class Suite extends TestSuite:
	func run() -> void:
		pass
var checks := 0
var failures: Array = []
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	await preload("res://tests/helpers/reach_completion_checks.gd").run(Suite.new(self))
	AudioRelease.begin_shutdown()
	for frame in 4:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("NE287_UNIT ", JSON.stringify({"checks":checks,"failures":failures}))
	get_tree().quit(0 if failures.is_empty() else 1)
func _frames(count: int) -> void:
	for frame in count:
		await get_tree().physics_frame
func _check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures.append(message)
