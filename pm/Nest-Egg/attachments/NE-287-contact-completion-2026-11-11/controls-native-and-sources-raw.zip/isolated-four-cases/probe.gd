extends Node

class ProbeSuite extends TestSuite:
	func run() -> void:
		pass

var checks: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	await preload("res://tests/helpers/kitchen_choreography_checks.gd").run(ProbeSuite.new(self))
	AudioRelease.begin_shutdown()
	for step in 4:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("KITCHEN_RESULTS ", JSON.stringify(checks))
	get_tree().quit(1 if checks.any(func(row: Dictionary) -> bool: return not row.ok) else 0)

func _frames(count: int) -> void:
	for step in count:
		await get_tree().physics_frame

func _check(ok: bool, message: String) -> void:
	var row := {"ok": ok, "message": message}
	if message.begins_with("natural choreography sets"):
		for child in get_children():
			if child is CutscenePlayer:
				var stage: StageLibrary.Stage = child._stage
				var expected: Vector2 = preload("res://tests/helpers/kitchen_choreography_checks.gd")._mat_support(stage)
				var actual: Vector2 = stage.prop_node("kettle").position
				row.merge({"actual": [actual.x, actual.y], "expected": [expected.x, expected.y],
					"distance": actual.distance_to(expected), "state": stage.prop_state("kettle"),
					"held": stage.prop_held("kettle"), "steps": child.steps_run})
	checks.append(row)
