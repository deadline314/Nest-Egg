extends Node

class LateCaller extends Node:
	signal done
	var player: CutscenePlayer
	var result: Dictionary = {}
	func _process(_delta: float) -> void:
		set_process(false)
		await player._do_reach({"id":"k", "hand":"front", "time":0.4, "contact":[64,39], "angle":PI/2,
			"space":"stage", "to":[235.1105710814095,149.49848116646416]})
		var actor: CutsceneActor = player._actors[&"k"]
		var reach: CutsceneReach = actor._reaches[0]
		result = {"elapsed_on_return": reach._elapsed, "duration": reach._duration,
			"settled_on_return": actor.hand_target_settled(&"front"),
			"target_on_return": [reach.target.x,reach.target.y]}
		player._do_prop_release({"id":"kettle"})
		done.emit()

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var player := CutscenePlayer.new()
	add_child(player)
	player._root = Control.new()
	player.add_child(player._root)
	player._running = true
	player._stage = StageLibrary.build(&"ch1_pawnshop_kitchen")
	player.add_child(player._stage)
	var actor := CutsceneActor.new()
	assert(actor.setup(&"k", "old_k", "", 4.0, ""))
	player._stage.actors.add_child(actor)
	actor.position = Vector2(200,304)
	actor.ground_y = 304
	actor.face(1)
	player._actors[&"k"] = actor
	assert(actor.set_hand_target({"hand":"front", "time":0.0, "contact":[64,39], "angle":PI/2,
		"space":"stage", "to":[200,149.49848116646416]}))
	for step in 2:
		await get_tree().process_frame
	var stage := player._stage
	var kettle := stage.prop_node("kettle") as StageLayers._Sprite
	kettle.position += stage.to_local(actor.hand_contact_global(&"front")) - stage.to_local(kettle.to_global(kettle.source_point(Vector2(350,200))))
	var issue := stage.hold_prop("kettle", actor, &"front", Vector2(350,200))
	assert(issue.is_empty(), issue)
	var caller := LateCaller.new()
	caller.process_mode = Node.PROCESS_MODE_ALWAYS
	caller.process_priority = 100
	caller.player = player
	add_child(caller)
	await caller.done
	for step in 2:
		await get_tree().process_frame
	var expected := preload("res://tests/helpers/kitchen_choreography_checks.gd")._mat_support(stage)
	var actual := kettle.position
	caller.result.merge({"actual": [actual.x,actual.y], "expected": [expected.x,expected.y],
		"distance": actual.distance_to(expected), "held": stage.prop_held("kettle"),
		"fixture_only": true, "fixed_simulation_fps": 6, "late_process_priority": 100})
	print("LATE_REACH ", JSON.stringify(caller.result))
	var passed: bool = caller.result.distance < .08 and caller.result.settled_on_return
	player.cancel()
	caller.queue_free()
	AudioRelease.begin_shutdown()
	for step in 4:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if passed else 1)
