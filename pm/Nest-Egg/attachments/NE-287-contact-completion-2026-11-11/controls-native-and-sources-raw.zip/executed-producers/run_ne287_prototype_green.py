from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT=Path('C:/Users/stanl/Github/Nest-Egg')
PROJECT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
OUT=ROOT/'work/ne287-prototype-green'
OUT.mkdir()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
before=json.loads((ROOT/'work/ne286-ne267-official-v3/test-source-before.json').read_bytes())
owned=['game/cutscene/cutscene_reach.gd','game/cutscene/cutscene_actor.gd','game/cutscene/cutscene_player.gd']
for name in owned:
    before[name]=sha(PROJECT/name)
    (OUT/Path(name).name).write_bytes((PROJECT/name).read_bytes())
assert {name:sha(PROJECT/name) for name in before}==before
environment=os.environ.copy()
for key,folder in [('APPDATA','roaming'),('LOCALAPPDATA','local')]:
    target=OUT/'user'/folder;target.mkdir(parents=True);environment[key]=str(target)
probe=PROJECT/'work/ne286-late-reach-control-v2/probe.gd'
(OUT/'probe.gd').write_bytes(probe.read_bytes())
command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(PROJECT),'--audio-driver','Dummy','--fixed-fps','6','res://work/ne286-late-reach-control-v2/probe.tscn']
(OUT/'before.json').write_text(json.dumps(dict(command=command,runner_sha256=sha(Path(__file__)),producer_sha256=sha(probe),source_before=before),indent=2)+'\n',encoding='utf-8',newline='\n')
started=time.monotonic()
with (OUT/'run.log').open('xb') as log:
    process=subprocess.run(command,cwd=PROJECT,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=60)
text=(OUT/'run.log').read_text(encoding='utf-8',errors='replace')
errors=[line for line in text.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|leaked at exit',line,re.I)]
after={name:sha(PROJECT/name) for name in before}
record=dict(exit=process.returncode,seconds=time.monotonic()-started,error_lines=errors,sources_unchanged=after==before,source_after=after)
(OUT/'exit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print('prototype',process.returncode,'errors',errors,'unchanged',after==before)
print(text)
assert process.returncode==0 and not errors and after==before
