from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path('C:/Users/stanl/Github/Nest-Egg')
PROJECT = Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
OUT = ROOT / 'work/ne286-kitchen-controls'
OUT.mkdir()
PROBE = PROJECT / 'work/ne286-kitchen-controls'
PROBE.mkdir(parents=True)
source = '''extends Node

class ProbeSuite extends TestSuite:
	func run() -> void:
		pass

var checks: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	await preload("res://tests/helpers/kitchen_choreography_checks.gd").run(ProbeSuite.new(self))
	AudioRelease.begin_shutdown()
	for step in 4:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("KITCHEN_RESULTS ", JSON.stringify(checks))
	get_tree().quit(1 if checks.any(func(row: Dictionary) -> bool: return not row.ok) else 0)

func _frames(count: int) -> void:
	for step in count:
		await get_tree().physics_frame

func _check(ok: bool, message: String) -> void:
	var row := {"ok": ok, "message": message}
	if message.begins_with("natural choreography sets"):
		for child in get_children():
			if child is CutscenePlayer:
				var stage: StageLibrary.Stage = child._stage
				var expected: Vector2 = preload("res://tests/helpers/kitchen_choreography_checks.gd")._mat_support(stage)
				var actual: Vector2 = stage.prop_node("kettle").position
				row.merge({"actual": [actual.x, actual.y], "expected": [expected.x, expected.y],
					"distance": actual.distance_to(expected), "state": stage.prop_state("kettle"),
					"held": stage.prop_held("kettle"), "steps": child.steps_run})
	checks.append(row)
'''
(PROBE / 'probe.gd').write_text(source, encoding='utf-8', newline='\n')
(PROBE / 'probe.tscn').write_text('''[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://work/ne286-kitchen-controls/probe.gd" id="1"]
[node name="KitchenControl" type="Node"]
script = ExtResource("1")
''', encoding='utf-8', newline='\n')
for path in PROBE.iterdir():
    (OUT / path.name).write_bytes(path.read_bytes())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
frozen = json.loads((ROOT / 'work/ne286-ne267-official-v3/test-source-before.json').read_bytes())
assert {name: sha(PROJECT / name) for name in frozen} == frozen
path = PROJECT / 'game/cutscene/cutscene_player.gd'
current = path.read_bytes()
old = subprocess.check_output(['git', 'show', '2189222d:game/cutscene/cutscene_player.gd'], cwd=ROOT)
records = []
try:
    for name, version, fps in [('new-unlimited', current, 0), ('old-unlimited', old, 0),
                               ('old-15fps', old, 15), ('new-15fps', current, 15)]:
        path.write_bytes(version)
        case = OUT / name
        case.mkdir()
        (case / 'cutscene_player.gd').write_bytes(version)
        environment = os.environ.copy()
        for key, folder in [('APPDATA', 'roaming'), ('LOCALAPPDATA', 'local')]:
            target = case / 'user' / folder
            target.mkdir(parents=True)
            environment[key] = str(target)
        command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', str(PROJECT),
                   '--audio-driver', 'Dummy', '--max-fps', str(fps), 'res://work/ne286-kitchen-controls/probe.tscn']
        record = dict(case=name, command=command, cutscene_sha256=sha(path), runner_sha256=sha(Path(__file__)))
        (case / 'before.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
        started = time.monotonic()
        with (case / 'run.log').open('xb') as log:
            process = subprocess.run(command, cwd=PROJECT, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=210)
        log = (case / 'run.log').read_text(encoding='utf-8', errors='replace')
        errors = [line for line in log.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|leaked at exit', line, re.I)]
        records.append(dict(record, exit=process.returncode, seconds=time.monotonic() - started, errors=errors,
                            results=[json.loads(line.split('KITCHEN_RESULTS ', 1)[1]) for line in log.splitlines() if line.startswith('KITCHEN_RESULTS ')]))
        (OUT / 'summary.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
        print(name, process.returncode, 'errors', len(errors), 'seconds', records[-1]['seconds'], flush=True)
        assert not errors
finally:
    path.write_bytes(current)
    assert {name: sha(PROJECT / name) for name in frozen} == frozen
