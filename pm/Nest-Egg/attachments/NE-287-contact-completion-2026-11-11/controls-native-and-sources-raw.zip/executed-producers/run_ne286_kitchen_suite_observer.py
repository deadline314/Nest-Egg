from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path('C:/Users/stanl/Github/Nest-Egg')
PROJECT = Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
OUT = ROOT / 'work/ne286-kitchen-suite-observer'
OUT.mkdir()
PROBE = PROJECT / 'work/ne286-kitchen-suite-observer'
PROBE.mkdir(parents=True)
source = '''extends "res://tests/smoke_test.gd"

var _snapshots: Array = []

func _check(ok: bool, message: String) -> void:
	if message.begins_with("natural choreography sets"):
		for child in get_children():
			if child is CutscenePlayer:
				var stage: StageLibrary.Stage = child._stage
				var expected: Vector2 = preload("res://tests/helpers/kitchen_choreography_checks.gd")._mat_support(stage)
				var actual: Vector2 = stage.prop_node("kettle").position
				var actor: CutsceneActor = child._actors[&"k"]
				var reach: CutsceneReach = actor._reaches[0]
				_snapshots.append({"ok": ok, "actual": [actual.x, actual.y], "expected": [expected.x, expected.y],
					"distance": actual.distance_to(expected), "state": stage.prop_state("kettle"),
					"steps": child.steps_run, "pose": str(actor.pose), "speed": child.speed,
					"scale": Engine.time_scale, "paused": get_tree().paused})
	super._check(ok, message)

func _finish() -> void:
	print("KITCHEN_SUITE_OBSERVER ", JSON.stringify(_snapshots))
	await super._finish()
'''
(PROBE / 'probe.gd').write_text(source, encoding='utf-8', newline='\n')
(PROBE / 'probe.tscn').write_text('''[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://work/ne286-kitchen-suite-observer/probe.gd" id="1"]
[node name="KitchenSuiteObserver" type="Node"]
script = ExtResource("1")
''', encoding='utf-8', newline='\n')
for path in PROBE.iterdir():
    (OUT / path.name).write_bytes(path.read_bytes())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
frozen = json.loads((ROOT / 'work/ne286-ne267-official-v3/test-source-before.json').read_bytes())
before = {name: sha(PROJECT / name) for name in frozen}
assert before == frozen
environment = os.environ.copy()
for key, folder in [('APPDATA', 'roaming'), ('LOCALAPPDATA', 'local')]:
    target = OUT / 'user' / folder
    target.mkdir(parents=True)
    environment[key] = str(target)
command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', str(PROJECT),
           '--audio-driver', 'Dummy', 'res://work/ne286-kitchen-suite-observer/probe.tscn', '--', '--only=CutsceneSuite']
(OUT / 'before.json').write_text(json.dumps(dict(command=command, source_sha256=before,
    producer_sha256=sha(PROBE / 'probe.gd'), runner_sha256=sha(Path(__file__))), indent=2) + '\n', encoding='utf-8', newline='\n')
started = time.monotonic()
with (OUT / 'run.log').open('xb') as log:
    process = subprocess.run(command, cwd=PROJECT, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=300)
log = (OUT / 'run.log').read_text(encoding='utf-8', errors='replace')
errors = [line for line in log.splitlines() if re.search(r'SCRIPT ERROR|Parse Error', line, re.I)]
after = {name: sha(PROJECT / name) for name in frozen}
record = dict(exit=process.returncode, seconds=time.monotonic() - started, script_errors=errors,
              source_unchanged=after == before, source_after=after,
              snapshots=[json.loads(line.split('KITCHEN_SUITE_OBSERVER ', 1)[1]) for line in log.splitlines() if line.startswith('KITCHEN_SUITE_OBSERVER ')])
(OUT / 'exit.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print('full original CutsceneSuite', process.returncode, 'seconds', record['seconds'], 'script errors', len(errors), 'stable', after == before, 'snapshot', record['snapshots'], flush=True)
assert not errors and after == before
