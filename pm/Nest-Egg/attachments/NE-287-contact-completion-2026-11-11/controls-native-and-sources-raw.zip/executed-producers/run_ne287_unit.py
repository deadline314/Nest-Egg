from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT=Path('C:/Users/stanl/Github/Nest-Egg')
PROJECT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
OUT=ROOT/'work/ne287-unit'
OUT.mkdir()
PROBE=PROJECT/'work/ne287-unit'
PROBE.mkdir(parents=True)
source='''extends Node
class Suite extends TestSuite:
	func run() -> void:
		pass
var checks := 0
var failures: Array = []
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	await preload("res://tests/helpers/reach_completion_checks.gd").run(Suite.new(self))
	AudioRelease.begin_shutdown()
	for frame in 4:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("NE287_UNIT ", JSON.stringify({"checks":checks,"failures":failures}))
	get_tree().quit(0 if failures.is_empty() else 1)
func _frames(count: int) -> void:
	for frame in count:
		await get_tree().physics_frame
func _check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures.append(message)
'''
(PROBE/'probe.gd').write_text(source,encoding='utf-8',newline='\n')
(PROBE/'probe.tscn').write_text('''[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://work/ne287-unit/probe.gd" id="1"]
[node name="ContactCompletionUnit" type="Node"]
script = ExtResource("1")
''',encoding='utf-8',newline='\n')
for path in PROBE.iterdir():(OUT/path.name).write_bytes(path.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
environment=os.environ.copy()
for key,folder in [('APPDATA','roaming'),('LOCALAPPDATA','local')]:
    target=OUT/'user'/folder;target.mkdir(parents=True);environment[key]=str(target)
names=['game/cutscene/cutscene_reach.gd','game/cutscene/cutscene_actor.gd','game/cutscene/cutscene_player.gd','tests/helpers/reach_completion_checks.gd','tests/suite/test_cutscene.gd']
before={n:sha(PROJECT/n) for n in names}
for name in names:
    target=OUT/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((PROJECT/name).read_bytes())
command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(PROJECT),'--audio-driver','Dummy','res://work/ne287-unit/probe.tscn']
(OUT/'before.json').write_text(json.dumps(dict(command=command,source_before=before,runner_sha256=sha(Path(__file__)),producer_sha256=sha(PROBE/'probe.gd')),indent=2)+'\n',encoding='utf-8',newline='\n')
started=time.monotonic()
with (OUT/'run.log').open('xb') as log:process=subprocess.run(command,cwd=PROJECT,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=120)
text=(OUT/'run.log').read_text(encoding='utf-8',errors='replace')
errors=[line for line in text.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|leaked at exit',line,re.I)]
after={n:sha(PROJECT/n) for n in names}
record=dict(exit=process.returncode,seconds=time.monotonic()-started,error_lines=errors,sources_unchanged=before==after)
(OUT/'exit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(record);print(text)
assert process.returncode==0 and not errors and before==after
