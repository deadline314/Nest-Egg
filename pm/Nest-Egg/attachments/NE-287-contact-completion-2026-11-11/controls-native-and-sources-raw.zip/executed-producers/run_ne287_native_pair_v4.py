from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT=Path('C:/Users/stanl/Github/Nest-Egg')
PROJECT=Path('D:/NE232/diag-main-f52')
OUT=ROOT/'work/ne287-native-pair-v4'
OUT.mkdir()
PROBE=PROJECT/'work/ne287-native-pair-v4'
PROBE.mkdir(parents=True)
(PROBE/'viewport_capture.gd').write_bytes((ROOT/'tools/viewport_capture.gd').read_bytes())
(PROJECT/'work/.gdignore').touch()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
names=['game/cutscene/cutscene_player.gd','game/cutscene/cutscene_actor.gd','game/cutscene/cutscene_reach.gd']
original={name:(PROJECT/name).read_bytes() for name in names}
base={name:subprocess.check_output(['git','show',f'1549787c:{name}'],cwd=ROOT) for name in names}
new={name:(ROOT/name).read_bytes() for name in names}
for name in names[1:]:
    assert (ROOT/'work/ne287-prototype'/Path(name).name).read_bytes()==base[name]
player=new[names[0]].decode('utf-8')
live=player[player.index('func _live_step_actor('):player.index('func _do_reach(')]
wait=player[player.index('func _wait_hand_contact('):player.index('func _do_prop(step:')]
pure=base[names[0]].decode('utf-8')
assert pure.count('func _do_reach(step: Dictionary) -> void:')==1
pure=pure.replace('func _do_reach(step: Dictionary) -> void:',live+'func _do_reach(step: Dictionary) -> void:')
old='\t\tawait _wait_time(float(step.get("time", CutsceneReach.DEFAULT_TIME)))\n'
assert pure.count(old)==1
pure=pure.replace(old,'\t\tawait _wait_hand_contact(weakref(actor), actor.actor_id, StringName(step["hand"]))\n\n\n'+wait.rstrip()+'\n')
new[names[0]]=pure.encode('utf-8')
for kind,files in [('diag-original',original),('old',base),('new',new)]:
    for name,data in files.items():
        target=OUT/kind/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
template=(ROOT/'work/ne286-late-reach-control-v2/probe.gd').read_text(encoding='utf-8')
template=template.replace('var expected := preload("res://tests/helpers/kitchen_choreography_checks.gd")._mat_support(stage)', 'var surface := (stage.prop_node("kettle_mat") as StageLayers._Rect)._rect\n\tvar expected := Vector2(surface.get_center().x, surface.position.y)')
needle='\tprint("LATE_REACH ", JSON.stringify(caller.result))'
insert='''	await RenderingServer.frame_post_draw
	var raw := get_viewport().get_texture().get_image()
	var picture := preload("res://work/ne287-native-pair-v4/viewport_capture.gd").encode(raw, get_viewport().use_hdr_2d)
	var image_path := __OUTPUT__
	FileAccess.open(image_path + ".bin", FileAccess.WRITE).store_buffer(raw.get_data())
	assert(picture.save_png(image_path) == OK)
	caller.result.merge({"renderer":RenderingServer.get_current_rendering_method(), "hdr_2d":get_viewport().use_hdr_2d,
		"raw_format":raw.get_format(), "image_size":[raw.get_width(),raw.get_height()], "not_full_story_playthrough":true})
	FileAccess.open(image_path + ".json", FileAccess.WRITE).store_string(JSON.stringify(caller.result, "  ") + "\\n")
'''
assert needle in template
records=[]
try:
    for kind,files in [('old',base),('new',new)]:
        case=OUT/kind
        for name,data in files.items():(PROJECT/name).write_bytes(data)
        source=template.replace(needle,insert.replace('__OUTPUT__',json.dumps((case/'scene.png').as_posix()))+needle)
        source=source.replace('func _ready() -> void:', 'func _ready() -> void:\n\tif OS.get_cmdline_user_args().has("--compile-only"):\n\t\tget_tree().quit()\n\t\treturn')
        (PROBE/'probe.gd').write_text(source,encoding='utf-8',newline='\n')
        (PROBE/'probe.tscn').write_text('''[gd_scene load_steps=2 format=3]
[ext_resource type="Script" path="res://work/ne287-native-pair-v4/probe.gd" id="1"]
[node name="NativeContactControl" type="Node"]
script = ExtResource("1")
''',encoding='utf-8',newline='\n')
        for path in PROBE.iterdir():(case/path.name).write_bytes(path.read_bytes())
        active={name:sha(PROJECT/name) for name in names}
        environment=os.environ.copy()
        for key,folder in [('APPDATA','roaming'),('LOCALAPPDATA','local')]:
            target=case/'user'/folder;target.mkdir(parents=True);environment[key]=str(target)
        command=[sys.executable,str(ROOT/'tools/comfyui/gpu_lock.py'),'--',
            'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(PROJECT),
            '--audio-driver','Dummy','--rendering-method','forward_plus','--resolution','1280x720',
            '--fixed-fps','6','res://work/ne287-native-pair-v4/probe.tscn']
        (case/'before.json').write_text(json.dumps(dict(command=command,source_before=active,
            producer_sha256=sha(PROBE/'probe.gd'),runner_sha256=sha(Path(__file__)),
            viewport_capture_sha256=sha(PROBE/'viewport_capture.gd'),
            context='owned f52 diagnostic copy with these exact stage sources; not an exact published HEAD'),indent=2)+'\n',encoding='utf-8',newline='\n')
        check_command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(PROJECT),'res://work/ne287-native-pair-v4/probe.tscn','--','--compile-only']
        with (case/'check-only.log').open('xb') as check_log:
            checked=subprocess.run(check_command,cwd=PROJECT,env=environment,stdout=check_log,stderr=subprocess.STDOUT,timeout=30)
        check_text=(case/'check-only.log').read_text(encoding='utf-8',errors='replace')
        assert checked.returncode==0 and not re.search(r'SCRIPT ERROR|ERROR:',check_text,re.I),check_text
        started=time.monotonic()
        with (case/'run.log').open('xb') as log:process=subprocess.run(command,cwd=PROJECT,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=90)
        text=(case/'run.log').read_text(encoding='utf-8',errors='replace')
        errors=[line for line in text.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|leaked at exit',line,re.I)]
        after={name:sha(PROJECT/name) for name in names}
        record=dict(case=kind,exit=process.returncode,expected_exit=1 if kind=='old' else 0,seconds=time.monotonic()-started,error_lines=errors,sources_unchanged=after==active,source_after=after)
        records.append(record)
        (case/'exit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
        print(kind,record,flush=True)
        assert process.returncode==record['expected_exit'] and not errors and after==active and (case/'scene.png').is_file()
finally:
    for name,data in original.items():(PROJECT/name).write_bytes(data)
    assert all((PROJECT/name).read_bytes()==data for name,data in original.items())
    (OUT/'summary.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
