from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path('C:/Users/stanl/Github/Nest-Egg')
PROJECT = Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
OUT = ROOT / 'work/ne286-late-reach-old-control'
OUT.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
frozen = json.loads((ROOT / 'work/ne286-ne267-official-v3/test-source-before.json').read_bytes())
assert {name: sha((PROJECT / name).read_bytes()) for name in frozen} == frozen
target = PROJECT / 'game/cutscene/cutscene_player.gd'
current = target.read_bytes()
old = subprocess.check_output(['git', 'show', '2189222d:game/cutscene/cutscene_player.gd'], cwd=ROOT)
probe = PROJECT / 'work/ne286-late-reach-control-v2/probe.gd'
(OUT / 'probe.gd').write_bytes(probe.read_bytes())
(OUT / 'cutscene_player.gd').write_bytes(old)
environment = os.environ.copy()
for key, folder in [('APPDATA','roaming'),('LOCALAPPDATA','local')]:
    path = OUT / 'user' / folder
    path.mkdir(parents=True)
    environment[key] = str(path)
command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(PROJECT),
           '--audio-driver','Dummy','--fixed-fps','6','res://work/ne286-late-reach-control-v2/probe.tscn']
expected = dict(frozen)
expected['game/cutscene/cutscene_player.gd'] = sha(old)
try:
    target.write_bytes(old)
    before = {name: sha((PROJECT / name).read_bytes()) for name in expected}
    assert before == expected
    (OUT/'before.json').write_text(json.dumps(dict(command=command, source_before=before,
        runner_sha256=sha(Path(__file__).read_bytes()), producer_sha256=sha(probe.read_bytes())),indent=2)+'\n',encoding='utf-8',newline='\n')
    started = time.monotonic()
    with (OUT/'run.log').open('xb') as log:
        process = subprocess.run(command,cwd=PROJECT,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    log = (OUT/'run.log').read_text(encoding='utf-8',errors='replace')
    after = {name: sha((PROJECT / name).read_bytes()) for name in expected}
    errors = [line for line in log.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|leaked at exit',line,re.I)]
    record = dict(exit=process.returncode,seconds=time.monotonic()-started,errors=errors,sources_unchanged=after==before)
    (OUT/'exit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(record)
    print(log)
    assert process.returncode == 1 and not errors and after == before
finally:
    target.write_bytes(current)
    assert {name: sha((PROJECT / name).read_bytes()) for name in frozen} == frozen
