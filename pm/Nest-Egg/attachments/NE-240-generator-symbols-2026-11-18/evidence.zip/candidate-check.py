from pathlib import Path
import sys, types, json
root = Path(sys.argv[1])
sys.path.insert(0,str(root/'tools/level'))
module = types.ModuleType('build_ch1')
module.__file__ = str(root/'tools/level/build_ch1.py')
sys.modules['build_ch1'] = module
source = Path(sys.argv[2]).read_text(encoding='utf-8')
exec(compile(source,module.__file__,'exec'),module.__dict__)
import check_channel_generation
result=check_channel_generation.chapter(int(sys.argv[3]))
print(json.dumps(result))
raise SystemExit(bool(result['failures']))
