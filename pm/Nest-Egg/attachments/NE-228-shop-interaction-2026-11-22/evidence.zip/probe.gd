extends "res://tests/smoke_test.gd"

var _out := ""


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://skip_modal_probe.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	super._ready()


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(load("res://data/levels/ch1_pawnshop.tres") as LevelData)
	add_child(level)
	await _frames(260)
	var shop: ShopStation
	for child in level._entities.get_children():
		if child is ShopStation:
			shop = child
			break
	var ledger: NpcActor
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and node.data.id == &"ch1_ledger_box":
			ledger = node
			break
	_check(shop != null and ledger != null, "the actual pawnshop contains both fixtures")
	if shop == null or ledger == null:
		await _finish()
		return
	level.player.global_position = shop.global_position + Vector2(-15, 0)
	level.player.velocity = Vector2.ZERO
	await _frames(90)
	Story.auto_skip = false
	var scene := Story.resolve_dispatch(&"ch1_dispatch_ledger_box")
	print("SHOP_OVERLAP player=", level.player.global_position, " shop=", shop.global_position,
		" ledger=", ledger.global_position, " shop_reach=", shop._player_in_range, " ledger_reach=", ledger.interaction_available(),
		" scene=", scene)
	_check(not get_tree().paused and shop._player_in_range and ledger.interaction_available(), "both original world interactions are available")
	await _shot("overlap")
	await _interact()
	await _frames(6)
	var shop_open := is_instance_valid(shop._screen) and shop._screen._is_open
	print("SHOP_PRESS shop_open=", shop_open, " story=", Story._current_cinematic,
		" paused=", get_tree().paused, " target=", str(Story.framing.interaction_prompt_target()))
	_check(shop_open and Story._current_cinematic == &"", "one press opens the closer shop and no ledger scene")
	await _shot("press")
	if shop_open:
		await _send_key(KEY_ESCAPE)
		await _frames(20)
		_check(not shop._screen._is_open, "standard keyboard Back closes the shop")
	if Story.is_cinematic_active():
		Story.skip_cinematic()
	await _frames(30)
	level.player.global_position = ledger.global_position
	level.player.velocity = Vector2.ZERO
	await _frames(60)
	_check(not shop._player_in_range and ledger.interaction_available(), "moving closer to the ledger leaves the shop area")
	await _interact()
	await _frames(10)
	print("LEDGER_PRESS shop_open=", is_instance_valid(shop._screen) and shop._screen._is_open,
		" story=", Story._current_cinematic, " paused=", get_tree().paused)
	var ledger_open := Story.is_cinematic_active() and Story._current_cinematic == scene
	_check(ledger_open and (not is_instance_valid(shop._screen) or not shop._screen._is_open),
		"a separate nearby press still starts the original ledger scene")
	await _shot("ledger")
	if Story.is_cinematic_active():
		Story.skip_cinematic()
	await _frames(15)
	level.queue_free()
	await _frames(4)
	await _finish()


func _interact() -> void:
	var press := InputEventKey.new()
	press.keycode = KEY_E
	press.physical_keycode = KEY_E
	press.pressed = true
	Input.parse_input_event(press)
	Input.flush_buffered_events()
	await _frames(3)
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	Input.parse_input_event(release)
	Input.flush_buffered_events()

func _send_key(code: Key) -> void:
	var press := InputEventKey.new()
	press.keycode = code
	press.physical_keycode = code
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _send_button(button: JoyButton) -> void:
	var press := InputEventJoypadButton.new()
	press.button_index = button
	press.pressure = 1.0
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	release.pressure = 0.0
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _shot(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join(name + ".png")) == OK, "saved " + name)