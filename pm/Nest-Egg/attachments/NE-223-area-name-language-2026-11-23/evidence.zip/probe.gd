extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const PUMP := "res://data/levels/ch3_pump.tres"
const PLAZA := "res://data/levels/ch3_plaza.tres"
const PAWN := "res://data/levels/ch3_pawnshop.tres"

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://area-names-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.set_language("en")
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	var data := load(PUMP) as LevelData
	Story._seen[data.intro_scene] = true
	for scene: String in data.story_triggers:
		Story._seen[StringName(scene)] = true
	GameState.pending_portal = &"pump_plaza"
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(data)
	add_child(level)
	for frame in 240:
		if is_instance_valid(level.hud) and level.hud.toast_banner.is_showing():
			break
		await _frames(1)
	var hud := level.hud
	_check(is_instance_valid(hud) and level._entry_portal == &"pump_plaza", "the real pump room consumes its original entry portal")
	if not is_instance_valid(hud):
		await _finish()
		return
	var toast := hud.toast_banner._label.text
	print("ARRIVAL ", toast)
	_check(hud.toast_banner.is_showing() and toast == "Sump and Pump Room", "arrival displays the English area name")
	await _frames(18)
	await _picture("arrival-en.png")
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		enemy.set_physics_process(false)
	var panel: NpcActor
	for actor: Node in level._entities.get_children():
		if actor is NpcActor and (actor as NpcActor).data.id == &"ch3_branch_panel":
			panel = actor
			break
	_check(is_instance_valid(panel), "the route is sampled inside the real pump room")
	if is_instance_valid(panel):
		level.player.global_position = panel.global_position + Vector2(-112, 0)
		level.player.velocity = Vector2.ZERO
		print("ROUTE FIXTURE ", level.player.global_position, " panel ", panel.global_position)
	await _frames(36)
	var guide := hud.quest_guidance
	guide.state.pin("ch3_clinic", guide.catalog)
	for frame in 135:
		if guide._arrow.visible and not hud.toast_banner.is_showing():
			break
		await _frames(1)
	var step := QuestCatalog.current_step(guide._target, GameState.world_flags)
	var destination: String = (step.get("location", {}) as Dictionary).get("level", "")
	var exit := guide.maps.next_exit(PUMP, destination, GameState.world_flags)
	var portal := exit.get("resource") as PortalData
	_check(guide.state.pinned_id == "ch3_clinic" and destination == PAWN and portal != null and portal.target_level == PLAZA,
			"the original quest reaches the pawnshop by the original plaza exit")
	print("ARROW ", guide._arrow.text, " | ", guide._arrow.tooltip_text, " visible=", guide._arrow.visible)
	_check(guide._arrow.visible and guide._arrow.text.ends_with(" To Pawnshop (Sunday)"),
			"the HUD arrow names the far destination in English")
	_check(guide._arrow.tooltip_text == "Leads to Plaza Freight Lift.",
			"the HUD arrow help names the next exit in English")
	await _picture("route-en.png")
	await _key(KEY_M)
	await _frames(7)
	var pause: PauseMenu = level._pause_menu
	var screen: QuestMapScreen = pause._navigation
	_check(is_instance_valid(screen) and screen._page == "region" and get_tree().paused,
			"M opens the normal paused area map")
	if not is_instance_valid(screen):
		await _finish()
		return
	var heading := screen._body.get_child(0).get_child(0).get_child(1) as Label
	print("REGION ", heading.text)
	_check(heading.text == "Sump and Pump Room", "the regional map heading uses the same English name")
	screen.show_page("world")
	await _frames(8)
	var marker := _world_marker(screen, PAWN)
	_check(marker != null and marker.text.contains("Pawnshop (Sunday)")
			and marker.tooltip_text.begins_with("Open the map for Pawnshop (Sunday)."),
			"the real world marker and help share the English name")
	if marker != null:
		marker.grab_focus()
		await _frames(3)
	var focus_held := marker != null and marker.has_focus()
	Story.set_language("ja")
	await _frames(8)
	marker = _world_marker(screen, PAWN)
	if marker != null:
		print("WORLD ", marker.text, " | ", marker.tooltip_text)
	_check(marker != null and marker.text.contains("質屋（日曜）")
			and marker.tooltip_text.begins_with("質屋（日曜）の地図を開きます。"),
			"switching to Japanese updates the actual open world map and help")
	_check(focus_held and marker != null and marker.has_focus() and screen._page == "world"
			and screen.state.pinned_id == "ch3_clinic", "the open map keeps its page, selected area focus and pinned quest")
	_check(screen._area_caption.text == "集水槽とポンプ室", "the location caption also refreshes on the open map")
	await _picture("world-ja.png")
	if marker != null:
		await _key(KEY_ENTER)
		await _frames(7)
		_check(screen._page == "region" and screen._map_path == PAWN,
				"Enter opens the same region from the Japanese area marker")
	await _key(KEY_ESCAPE)
	await _key(KEY_ESCAPE)
	await _key(KEY_ESCAPE)
	pause.close()
	level.queue_free()
	await _frames(6)
	await _finish()


func _world_marker(screen: QuestMapScreen, path: String) -> Button:
	for marker in screen._canvas._markers:
		if marker.get_meta(&"nav_key", "") == "area:" + path:
			return marker
	return null


func _key(key: Key, hold_frames := 3) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(hold_frames)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(4)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	if not ok:
		printerr("FAIL: ", message)


func _finish() -> void:
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(1 if _fails else 0)
