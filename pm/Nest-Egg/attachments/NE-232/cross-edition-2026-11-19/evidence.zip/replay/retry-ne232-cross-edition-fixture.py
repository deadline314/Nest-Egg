from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

root=Path.cwd()
out=root/'work/ne232-cross-edition-20261119'
assert out.is_dir()
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
old='99dfc03b2f2c0e2ea597fc6826d8e4ba8f3b5a8c'
edition_names=('ch1_kasa','ch2_heron','ch3_clearwater')
script=out/'fixture-v2.gd'
shutil.copyfile(root/'work/ne232-cross-edition-fixture.gd',script)
scene=out/'fixture-v2.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{script.as_posix()}" id="1"]\n[node name="ChapterEndFixture" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')

def digest(path: Path) -> str:
    with path.open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

def capture_json(path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def profile_env(profile):
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(profile/key)
    return env

def runs_path(profile):
    return profile/'APPDATA/Godot/app_userdata/Nest Egg/runs'

catalog=json.loads((out/'candidates.json').read_bytes())
for ed in edition_names[:2]:
    evidence=out/('fixture-v2-'+ed)
    evidence.mkdir()
    profile=evidence/'profile'
    proj=Path(catalog[ed]['stage'])/'project'
    assert json.loads((proj/'data/release/edition.json').read_bytes())['source_sha']==old
    args=[engine,'--headless','--path',str(proj),'--max-fps','240',
          '--quit-after','5000','--log-file',str(evidence/'engine.log'),str(scene)]
    capture_json(evidence/'command.json',args)
    result=subprocess.run(args,cwd=proj,env=profile_env(profile),capture_output=True,timeout=240)
    (evidence/'stdout.log').write_bytes(result.stdout+result.stderr)
    log=(evidence/'engine.log').read_text(encoding='utf-8')
    print(ed,result.returncode,log[-1450:],flush=True)
    assert result.returncode==0 and not re.search(r'SCRIPT ERROR|ERROR:|ObjectDB instances leaked|resources still in use',log)
    slot=runs_path(profile)/f'through-{ed}/slot-1.json'
    assert slot.is_file() and f'NE232_FIXTURE through-{ed} ' in log and digest(slot) in log
    shutil.copyfile(slot,evidence/'chapter-complete.json')
