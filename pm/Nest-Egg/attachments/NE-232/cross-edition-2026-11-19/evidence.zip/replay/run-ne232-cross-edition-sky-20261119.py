from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

root=Path.cwd()
base=root/'work/ne232-cross-edition-20261119'
out=base/'native-v2'
out.mkdir()
catalog=json.loads((base/'candidates.json').read_bytes())
sys.path.insert(0,str(root/'tools/comfyui'))
from comfy_guard import server_lock

def digest(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

def payload(slot):
    item=json.loads(slot.read_bytes())
    assert item['version']==1 and hashlib.sha256(item['payload'].encode()).hexdigest()==item['checksum']
    return json.loads(item['payload'])

def write(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def slot(profile,edition):
    return profile/'APPDATA/Godot/app_userdata/Nest Egg/runs'/f'through-{edition}'/'slot-1.json'

def run(name,ed,profile):
    step=out/name
    step.mkdir()
    exe=Path(catalog[ed]['exe'])
    assert digest(exe)==catalog[ed]['sha256'] and [exe]==list(exe.parent.iterdir())
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(profile/key)
    engine_log=step/'engine.log'
    args=[str(exe),'--windowed','--resolution','1280x720','--rendering-method','forward_plus',
          '--rendering-driver','vulkan','--log-file',str(engine_log)]
    write(step/'command.json',{'argv':args,'profile':str(profile),'sha256':digest(exe),'cwd':str(exe.parent)})
    write(out/'active.json',{'phase':name,'edition':ed,'exe':str(exe)})
    print('READY',name,flush=True)
    start=time.monotonic()
    with server_lock(),(step/'stdout.log').open('wb') as stdout:
        proc=subprocess.run(args,cwd=exe.parent,env=env,stdout=stdout,stderr=subprocess.STDOUT,timeout=240)
    raw=engine_log.read_text(encoding='utf-8')
    errors=[line for line in raw.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|ObjectDB instances leaked|resources still in use',line)]
    record={'exit':proc.returncode,'errors':errors,'sha_held':digest(exe)==catalog[ed]['sha256'],
            'adapter':'AMD Radeon RX 9070 XT' in raw and 'Forward+' in raw,
            'import_notice_in_log':'[RunSave] 從其他累積版本接續' in raw,'elapsed_seconds':time.monotonic()-start}
    write(step/'exit.json',record)
    assert record['exit']==0 and record['sha_held'] and record['adapter'] and record['errors']==[],record
    return record

changes={'ch1_kasa':('ch2_heron','res://data/levels/ch2_pawnshop.tres'),
         'ch2_heron':('ch3_clearwater','res://data/levels/ch3_pawnshop.tres')}
results={}
for old, (new, level) in changes.items():
    profile=out/f'forward-{old}'
    previous=slot(profile,old)
    previous.parent.mkdir(parents=True)
    shutil.copyfile(base/f'fixture-v2-{old}'/'chapter-complete.json',previous)
    previous_sha=digest(previous)
    current=slot(profile,new)
    before=payload(previous)
    assert before['chapter_complete'] and before['release']==f'through-{old}'
    record=run(f'{old}-to-{new}',new,profile)
    assert record['import_notice_in_log'] and digest(previous)==previous_sha
    after=payload(current)
    assert after['level']==level and after['release']==f'through-{new}' and not after['chapter_complete']
    assert before['progression']['credits']==after['progression']['credits']
    assert before['difficulty']==after['difficulty']
    shutil.copyfile(current,out/f'{new}-imported.json')
    record=run(f'{new}-reopen',new,profile)
    assert not record['import_notice_in_log'] and digest(previous)==previous_sha
    reopened=payload(current)
    own_keys=('release','level','difficulty','progression')
    assert all(after[field]==reopened[field] for field in own_keys)
    shutil.copyfile(current,out/f'{new}-reopened.json')

    reverse=out/f'reverse-{new}'
    future=slot(reverse,new)
    future.parent.mkdir(parents=True)
    shutil.copyfile(current,future)
    held=digest(future)
    record=run(f'{new}-seen-by-{old}',old,reverse)
    assert not record['import_notice_in_log']
    assert not slot(reverse,old).exists() and digest(future)==held
    results[old]={'next':new,'entry':level,'credits':after['progression']['credits'],
                  'old_slot_sha256':previous_sha,'new_slot_sha256':held,'own_stable_fields':own_keys,
                  'reverse_created_slot':False}
    write(out/'results.json',results)
    print(f'{old} -> {new} verified',flush=True)
write(out/'active.json',{'phase':'complete'})
