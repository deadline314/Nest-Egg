extends Node
## Creates a chapter-complete fixture using the archived version's actual Main route.
## Normal campaign play is outside this data setup.

const MainScript = preload("res://game/main.gd")

func _ready() -> void:
	_run.call_deferred()

func _wait_for(main: Node, predicate: Callable) -> bool:
	for frame in 2400:
		if predicate.call(main.get("_screen")):
			return true
		await get_tree().process_frame
	return false

func _run() -> void:
	var edition := CampaignEdition.current()
	var terminals := {"through-ch1_kasa": "res://data/levels/ch1_pawnshop_dawn.tres",
		"through-ch2_heron": "res://data/levels/ch2_rooftop.tres"}
	var terminal: String = terminals.get(edition.id, "")
	if terminal.is_empty() or FileAccess.file_exists(edition.slot_path()):
		push_error("fixture requires a supported edition and an empty isolated slot")
		get_tree().quit(2)
		return
	Story.auto_skip = true
	Transition.instant = true
	var main := MainScript.new()
	add_child(main)
	if not await _wait_for(main, func(screen): return screen is MainMenu):
		push_error("main menu did not load")
		get_tree().quit(1)
		return
	for frame in 12:
		await get_tree().process_frame
	main.call("_on_start_requested", GameState.difficulties[1])
	if not await _wait_for(main, func(screen): return screen is Level):
		push_error("new campaign level did not load")
		get_tree().quit(1)
		return
	Progression.add_credits(246 if edition.id == "through-ch1_kasa" else 357)
	main.call("_on_area_requested", terminal)
	if not await _wait_for(main, func(screen): return screen is Level and screen.data.resource_path == terminal):
		push_error("actual terminal level did not load: " + terminal)
		get_tree().quit(1)
		return
	var level := main.get("_screen") as Level
	level.completed.emit()
	if not await _wait_for(main, func(screen): return screen is VictoryScreen):
		push_error("edition finale did not produce a completion card")
		get_tree().quit(1)
		return
	var data := RunSaveCodec.decode(FileAccess.get_file_as_string(edition.slot_path()))
	var saved: Dictionary = data.get("data", {})
	if saved.get("release") != edition.id or saved.get("level") != terminal or not saved.get("chapter_complete"):
		push_error("main did not write a compatible chapter-complete fixture")
		get_tree().quit(1)
		return
	print("NE232_FIXTURE " + edition.id + " " + terminal + " " + FileAccess.get_sha256(edition.slot_path()))
	main.call("_quit")
