from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
ROOT=Path('C:/Users/stanl/Github/Nest-Egg');FIRST=ROOT/'work/ne232-os-input-ch1-20261112';OUT=ROOT/'work/ne232-os-cold-resume-ch1-20261112'
assert not OUT.exists();OUT.mkdir()
exe=next((FIRST/'clean').glob('*.exe'));slot=FIRST/'user/roaming/Godot/app_userdata/Nest Egg/runs/through-ch1_kasa/slot-1.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
before=json.loads(slot.read_bytes());payload=json.loads(before['payload']);assert payload['level']=='res://data/levels/ch1_prologue.tres'
(OUT/'slot-before.json').write_bytes(slot.read_bytes());identity=sha(exe)
env=os.environ.copy();env.update(APPDATA=str(FIRST/'user/roaming'),LOCALAPPDATA=str(FIRST/'user/local'))
cmd=[sys.executable,str(ROOT/'tools/comfyui/gpu_lock.py'),'--',str(exe),'--windowed','--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan','--log-file',str(OUT/'engine.log')]
(OUT/'executed-runner.py').write_bytes(Path(__file__).read_bytes());write('command-before.json',dict(command=cmd,cwd=str(exe.parent),exe_sha256=identity,slot_before_sha256=sha(slot),scope='same candidate cold new process, actual OS menu Continue; no cross-version or controller claim'))
start=time.monotonic()
with (OUT/'stdout.log').open('xb') as f:proc=subprocess.run(cmd,cwd=exe.parent,env=env,stdout=f,stderr=subprocess.STDOUT)
raw=(OUT/'engine.log').read_text(encoding='utf-8',errors='replace');errors=[line for line in raw.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|ObjectDB instances leaked|resources still in use',line)]
(OUT/'slot-after.json').write_bytes(slot.read_bytes());after=json.loads(json.loads(slot.read_bytes())['payload'])
stable=['level','chapter_complete','difficulty','release','story','navigation','progression']
write('exit.json',dict(exit=proc.returncode,seconds=time.monotonic()-start,error_lines=errors,exe_unchanged=sha(exe)==identity,stable_fields={key:payload[key]==after[key] for key in stable},engine_log_sha256=sha(OUT/'engine.log')))
assert proc.returncode==0 and not errors and sha(exe)==identity and all(payload[k]==after[k] for k in stable)
print('cold resume exited cleanly; seven authority fields unchanged')
