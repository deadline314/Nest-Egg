from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
ROOT=Path('C:/Users/stanl/Github/Nest-Egg')
stage=Path('D:/NE232/0.1.261112-candidate-through-ch1_kasa-99dfc03b2f2c0e2ea597fc6826d8e4ba8f3b5a8c')
out=ROOT/'work/ne232-os-input-ch1-20261112';assert not out.exists();out.mkdir()
clean=out/'clean';clean.mkdir();manifest=json.loads((stage/'export-manifest.json').read_bytes());artifact=manifest['artifacts']['windows']
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(name,data):(out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
source=stage/'artifacts'/artifact['file'];assert sha(source)==artifact['sha256'];exe=clean/artifact['file'];shutil.copyfile(source,exe)
environment=os.environ.copy()
for key,part in [('APPDATA','roaming'),('LOCALAPPDATA','local')]:
 folder=out/'user'/part;folder.mkdir(parents=True);environment[key]=str(folder)
command=[sys.executable,str(ROOT/'tools/comfyui/gpu_lock.py'),'--',str(exe),'--windowed','--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan','--log-file',str(out/'engine.log')]
(out/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
save('command-before.json',dict(command=command,cwd=str(clean),runner_sha256=sha(Path(__file__)),exe_sha256=sha(exe),scope='native real-time Windows EXE with OS keyboard/mouse via sky, isolated user data; no physical gamepad claim'))
start=time.monotonic()
with (out/'stdout.log').open('xb') as f:proc=subprocess.run(command,cwd=clean,env=environment,stdout=f,stderr=subprocess.STDOUT)
raw=(out/'engine.log').read_text(encoding='utf-8',errors='replace')
errors=[line for line in raw.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|ObjectDB instances leaked|resources still in use',line)]
save('exit.json',dict(exit=proc.returncode,seconds=time.monotonic()-start,error_lines=errors,exe_unchanged=sha(exe)==artifact['sha256'],engine_log_sha256=sha(out/'engine.log')))
print('OS-input candidate exited',proc.returncode,'errors',len(errors),flush=True)
assert proc.returncode==0 and not errors
