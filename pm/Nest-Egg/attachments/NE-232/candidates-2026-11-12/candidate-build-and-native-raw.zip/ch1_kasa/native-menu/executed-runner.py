from pathlib import Path
import argparse, hashlib, json, os, re, shutil, subprocess, sys, time
ROOT=Path('C:/Users/stanl/Github/Nest-Egg')
p=argparse.ArgumentParser();p.add_argument('--through',required=True,choices=['ch1_kasa','ch2_heron','ch3_clearwater']);a=p.parse_args()
stage=Path('D:/NE232')/('0.1.261112-candidate-through-'+a.through+'-99dfc03b2f2c0e2ea597fc6826d8e4ba8f3b5a8c')
manifest=json.loads((stage/'export-manifest.json').read_bytes())
out=ROOT/'work'/('ne232-native-menu-'+a.through+'-20261112');assert not out.exists();out.mkdir()
clean=out/'clean';clean.mkdir();movie=out/'frames';movie.mkdir()
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(name,value):(out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
artifact=manifest['artifacts']['windows'];source=stage/'artifacts'/artifact['file'];assert sha(source)==artifact['sha256']
executable=clean/artifact['file'];shutil.copyfile(source,executable);assert list(clean.iterdir())==[executable]
environment=os.environ.copy()
for key,part in [('APPDATA','roaming'),('LOCALAPPDATA','local')]:
 folder=out/'user'/part;folder.mkdir(parents=True);environment[key]=str(folder)
command=[sys.executable,str(ROOT/'tools/comfyui/gpu_lock.py'),'--',str(executable),
 '--windowed','--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan',
 '--write-movie',str(movie/'menu.png'),'--fixed-fps','30','--quit-after','90','--disable-vsync']
before=dict(executable_sha256=sha(executable),manifest_sha256=sha(stage/'export-manifest.json'),
 runner_sha256=sha(Path(__file__)),command=command,cwd=str(clean),clean_files_before=[executable.name],
 scope='native Windows embedded-PCK startup menu only; fixed 30Hz MovieMaker, no real-time performance or human/controller route acceptance')
save('command-before.json',before);start=time.monotonic()
with (out/'process.log').open('xb') as f:process=subprocess.run(command,cwd=clean,env=environment,stdout=f,stderr=subprocess.STDOUT)
log=(out/'process.log').read_text(encoding='utf-8',errors='replace')
errors=[line for line in log.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|ObjectDB instances leaked|resources still in use|Assertion failed',line,re.I)]
frames=sorted(movie.glob('*.png'))
receipt=dict(exit=process.returncode,seconds=time.monotonic()-start,error_lines=errors,frames=len(frames),
 renderer_forward_plus='Forward+' in log,gpu_rx9070xt=bool(re.search(r'RX\s*9070\s*XT',log,re.I)),
 executable_unchanged=sha(executable)==before['executable_sha256'],
 files={str(path.relative_to(out)).replace('\\','/'):dict(bytes=path.stat().st_size,sha256=sha(path)) for path in sorted(out.rglob('*')) if path.is_file() and 'user' not in path.relative_to(out).parts})
save('receipt.json',receipt)
assert process.returncode==0 and not errors and receipt['renderer_forward_plus'] and receipt['gpu_rx9070xt'] and receipt['executable_unchanged'] and len(frames)>=80,receipt
print('native menu captured',a.through,len(frames),str(frames[-1]),flush=True)
