from pathlib import Path
import json,os,subprocess,sys,time
ROOT=Path('C:/Users/stanl/Github/Nest-Egg');OUT=ROOT/'work/ne232-os-key-diagnostic';assert not OUT.exists();OUT.mkdir()
project=OUT/'project';project.mkdir()
(project/'project.godot').write_text('''config_version=5
[application]
config/name="Nest Egg OS Key Diagnostic"
run/main_scene="res://probe.tscn"
[display]
window/size/viewport_width=800
window/size/viewport_height=300
[rendering]
renderer/rendering_method="forward_plus"
''',encoding='utf-8',newline='\n')
source='''extends Node
var _events: FileAccess
func _ready() -> void:
	_events = FileAccess.open(__EVENTS__, FileAccess.WRITE)
	InputMap.add_action("diagnostic_physical_p")
	var physical := InputEventKey.new()
	physical.physical_keycode = KEY_P
	InputMap.action_add_event("diagnostic_physical_p", physical)
	InputMap.add_action("diagnostic_logical_p")
	var logical := InputEventKey.new()
	logical.keycode = KEY_P
	InputMap.action_add_event("diagnostic_logical_p", logical)
	var label := Label.new()
	label.text = "OS keyboard diagnostic only.\nNo game files or input bindings are changed.\nObserve P, Escape, Return; close window afterward."
	label.position = Vector2(25, 30)
	add_child(label)
func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var row := {"stage":"input","pressed":event.pressed,"echo":event.echo,
			"keycode":event.keycode,"physical_keycode":event.physical_keycode,"unicode":event.unicode,
			"logical_p":event.is_action_pressed("diagnostic_logical_p"),
			"physical_p":event.is_action_pressed("diagnostic_physical_p"),"text":event.as_text()}
		_events.store_line(JSON.stringify(row));_events.flush()
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey:
		_events.store_line(JSON.stringify({"stage":"unhandled","pressed":event.pressed,
			"keycode":event.keycode,"physical_keycode":event.physical_keycode}));_events.flush()
'''.replace('__EVENTS__',json.dumps((OUT/'events.jsonl').as_posix()))
(project/'probe.gd').write_text(source,encoding='utf-8',newline='\n')
(project/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://probe.gd" id="1"]\n[node name="Diagnostic" type="Node"]\nscript=ExtResource("1")\n',encoding='utf-8',newline='\n')
env=os.environ.copy();env.update(APPDATA=str(OUT/'user/roaming'),LOCALAPPDATA=str(OUT/'user/local'))
for k in ['APPDATA','LOCALAPPDATA']:Path(env[k]).mkdir(parents=True)
cmd=[sys.executable,str(ROOT/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project),'--audio-driver','Dummy']
(OUT/'command.json').write_text(json.dumps(dict(command=cmd,cwd=str(project)),indent=2),encoding='utf-8')
start=time.monotonic()
with (OUT/'process.log').open('xb') as f:proc=subprocess.run(cmd,cwd=project,env=env,stdout=f,stderr=subprocess.STDOUT)
(OUT/'exit.json').write_text(json.dumps(dict(exit=proc.returncode,seconds=time.monotonic()-start),indent=2),encoding='utf-8')
print('diagnostic exited',proc.returncode)
