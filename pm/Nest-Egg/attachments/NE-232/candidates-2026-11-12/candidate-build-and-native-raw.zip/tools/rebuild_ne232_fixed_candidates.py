"""Build new immutable cumulative candidates after the cache fix is published."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import sys
import time

ROOT = Path('C:/Users/stanl/Github/Nest-Egg')
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
TEMPLATES = Path('D:/NE232/templates-4.7.2')
VERSION = '0.1.261112-candidate'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True)
    parser.add_argument('--through', choices=['ch1_kasa', 'ch2_heron', 'ch3_clearwater'], required=True)
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{40}', args.source):
        raise SystemExit('full immutable source SHA required')
    subprocess.run(['git', 'merge-base', '--is-ancestor', args.source, 'origin/main'], cwd=ROOT, check=True)
    stage = Path('D:/NE232') / f'{VERSION}-through-{args.through}-{args.source}'
    out = ROOT / 'work' / f'ne232-fixed-{args.through}-{args.source[:8]}'
    if stage.exists() or out.exists():
        raise SystemExit('preserving existing stage/receipts; choose a new version for a different attempt')
    out.mkdir()
    sources = {}
    for path in sorted((ROOT / 'tools/release').glob('*.py')):
        relative = path.relative_to(ROOT).as_posix()
        committed = subprocess.check_output(['git', 'show', f'{args.source}:{relative}'], cwd=ROOT)
        if hashlib.sha256(committed).hexdigest() != sha(path):
            raise SystemExit(f'build tool differs from published source: {relative}')
        sources[relative] = sha(path)
    records = []
    common = [sys.executable, 'tools/release/campaign_build.py']
    commands = [
        common + ['prepare', '--source', args.source, '--through', args.through,
                  '--version', VERSION, '--out-root', 'D:/NE232'],
        common + ['import-stage', '--stage', str(stage), '--godot', ENGINE, '--templates', str(TEMPLATES)],
        common + ['export', '--stage', str(stage), '--godot', ENGINE, '--templates', str(TEMPLATES), '--candidate'],
    ]
    (out / 'command-before.json').write_text(json.dumps(dict(source=args.source, stage=str(stage),
        version=VERSION, through=args.through, runner_sha256=sha(Path(__file__)),
        build_tool_sha256=sources, commands=commands), indent=2) + '\n', encoding='utf-8', newline='\n')
    for name, command in zip(['prepare', 'import', 'export'], commands):
        started = time.monotonic()
        log = out / f'{name}.log'
        with log.open('xb') as stream:
            process = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        records.append(dict(step=name, exit=process.returncode, seconds=time.monotonic() - started,
                            log=log.name, log_sha256=sha(log)))
        (out / 'receipts.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8', newline='\n')
        print(name, process.returncode, records[-1]['seconds'], flush=True)
        if process.returncode:
            return process.returncode
    print('candidate export complete; not human/controller chapter acceptance', stage, flush=True)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
