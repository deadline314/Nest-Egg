extends Node
var _events: FileAccess
func _ready() -> void:
	_events = FileAccess.open("C:/Users/stanl/Github/Nest-Egg/work/ne232-os-key-diagnostic/events.jsonl", FileAccess.WRITE)
	InputMap.add_action("diagnostic_physical_p")
	var physical := InputEventKey.new()
	physical.physical_keycode = KEY_P
	InputMap.action_add_event("diagnostic_physical_p", physical)
	InputMap.add_action("diagnostic_logical_p")
	var logical := InputEventKey.new()
	logical.keycode = KEY_P
	InputMap.action_add_event("diagnostic_logical_p", logical)
	var label := Label.new()
	label.text = "OS keyboard diagnostic only.
No game files or input bindings are changed.
Observe P, Escape, Return; close window afterward."
	label.position = Vector2(25, 30)
	add_child(label)
func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var row := {"stage":"input","pressed":event.pressed,"echo":event.echo,
			"keycode":event.keycode,"physical_keycode":event.physical_keycode,"unicode":event.unicode,
			"logical_p":event.is_action_pressed("diagnostic_logical_p"),
			"physical_p":event.is_action_pressed("diagnostic_physical_p"),"text":event.as_text()}
		_events.store_line(JSON.stringify(row));_events.flush()
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey:
		_events.store_line(JSON.stringify({"stage":"unhandled","pressed":event.pressed,
			"keycode":event.keycode,"physical_keycode":event.physical_keycode}));_events.flush()
