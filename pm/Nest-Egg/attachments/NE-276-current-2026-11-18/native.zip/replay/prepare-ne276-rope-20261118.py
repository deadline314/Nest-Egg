from pathlib import Path
import hashlib, json
root=Path.cwd();base=Path('D:/NestEggVerification/evidence-20261117/ne276-current');base.mkdir(exist_ok=False)
source=root/'work/ne275-native-grip-20261118.gd';text=source.read_text()
assert hashlib.sha256(source.read_bytes()).hexdigest()=='382292824fec61016a0e592c5da22c4588e0bfa678f3751691aa0a2bf354ce7e'
assert text.count('for weapon_id in WEAPONS:')==1 and text.count('for recovery in 20:')==1
text=text.replace('for weapon_id in WEAPONS:','for weapon_id in ["whip"]:').replace('for recovery in 20:','for recovery in 60:')
text=text.replace('func observe(weapon_id: String, pose: String, frame: int) -> void:','func observe_grip(weapon_id: String, pose: String, frame: int) -> void:')
text=text.replace('var negative := false','var negative := false\nvar rope_negative := false\nvar lifecycle: Array[Dictionary] = []')
text=text.replace('elif argument == "--negative":','elif argument == "--rope-negative":\n\t\t\trope_negative = true\n\t\telif argument == "--negative":')
text=text.replace('var file := FileAccess.open(out_dir.path_join("grip.json"), FileAccess.WRITE)','await observe_lifecycle(camera)\n\tvar file := FileAccess.open(out_dir.path_join("grip.json"), FileAccess.WRITE)')
text=text.replace('"failures": _failures}', '"failures": _failures, "lifecycle": lifecycle}')
text+='''

func observe(weapon_id: String, pose: String, frame: int) -> void:
	observe_grip(weapon_id, pose, frame)
	var rope := player._visual.melee_held().whip()
	assert(rope != null and rope.is_laid())
	if rope_negative:
		var start := rope.node(0)
		for i in SoftWhip.NODES:
			rope._pos[i] = start + Vector2(side, 0) * rope.length() * float(i) / float(SoftWhip.NODES - 1)
	var nodes: Array = []
	for i in SoftWhip.NODES:
		var point := rope.node(i)
		nodes.append([point.x, point.y])
	var attack: Dictionary = player._melee_attack
	var target := player.global_position + Vector2(0, -Player.BODY_SIZE.y * 0.55)
	var reach := float(attack.get("range", 0))
	if reach > 0:
		target += player._melee_direction(attack) * reach
	rows[-1]["rope"] = {"nodes": nodes, "length": rope.length(), "floor": rope.floor_y,
		"straightness": rope.straightness(), "phase": int(player._melee_phase),
		"active": player._melee_phase == Player.MeleePhase.ACTIVE,
		"windup": player._melee_phase == Player.MeleePhase.WINDUP,
		"progress": player.melee_pose_progress(), "range": reach, "target": [target.x,target.y]}
	if rope.straightness() >= 0.99:
		_failures += 1

func observe_lifecycle(camera: Camera2D) -> void:
	var weapon := load("res://data/weapons/melee/melee_whip.tres") as WeaponData
	await arm_side(weapon, camera)
	assert(player._try_melee())
	for frame in 8:
		await step()
		observe("whip", "interrupt-start", frame)
	player._interrupt_melee()
	for frame in 70:
		await step()
		observe("whip", "interrupted", frame)
	await photo("whip-interrupted", camera)
	var held := player._visual.melee_held()
	lifecycle.append({"case":"interrupted", "tip_below_palm":held.whip().tip().y-held.hold().origin.y})
	player.loadout.reset(load("res://data/weapons/pistol.tres") as WeaponData)
	await settle(6)
	lifecycle.append({"case":"switched-out", "laid":held.whip().is_laid(), "visible":held.visible})
	await photo("whip-switched-out", camera)
	player.global_position.x += 160.0
	player.loadout.reset(weapon)
	await settle(3)
	lifecycle.append({"case":"switched-back", "laid":held.whip().is_laid(), "tip_palm_gap":held.whip().tip().distance_to(held.hold().origin)})
	await photo("whip-switched-back", camera)
'''
path=root/'work/ne276-native-rope-20261118.gd';assert not path.exists();path.write_text(text)
(base/'helper.json').write_text(json.dumps({'derived_from':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'scope':'Private playback adapter only; all three authored moves and 60 recovery steps; real original lifecycle APIs.'},indent=2)+'\n')
print('prepared',path)
