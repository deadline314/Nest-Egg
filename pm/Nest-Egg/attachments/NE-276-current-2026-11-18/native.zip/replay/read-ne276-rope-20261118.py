from pathlib import Path
import json,math,hashlib
from PIL import Image,ImageDraw

BASE=Path('D:/NestEggVerification/evidence-20261117/ne276-current')
POSES=['idle','walk','run','crouch','air','dash']
MOVES=['lash','return_lash','orbit']

def read(folder,negative=False):
    data=json.loads((folder/'grip.json').read_text());assert len(data['rows'])==541 and len(data['shots'])==61
    art=json.loads((folder.parent/'source/melee_art.json').read_text())['weapons']['melee_whip']
    nozzle=art['size'][0]-art['grip'][0]
    straight=[];bows=[];below=[];gaps=[];geometry=[];geometry_failures=[]
    for row in data['rows']:
        r=row['rope'];points=r['nodes'];length=r['length']
        assert len(points)==20 and math.isfinite(length) and length>0
        assert all(math.isfinite(v) for p in points for v in p)
        chord=[points[-1][i]-points[0][i] for i in [0,1]];span=math.hypot(*chord)
        ratio=span/length;assert abs(ratio-r['straightness'])<0.00001
        arc=sum(math.dist(a,b) for a,b in zip(points,points[1:]));assert arc>0
        geometric=span/arc
        if row['pose'] in MOVES or row['pose'] in [m+':recovery' for m in MOVES]:
            geometry.append(geometric)
            if geometric>=0.99:
                geometry_failures.append({'pose':row['pose'],'frame':row['frame'],'chord':span,'arc_length':arc,'payout_length':length,'chord_to_arc':geometric,'chord_to_payout':ratio})
        bow=max(abs((p[0]-points[0][0])*chord[1]-(p[1]-points[0][1])*chord[0])/max(span,0.000001) for p in points)/length
        straight.append(ratio);bows.append(bow);below.append(max(p[1]-min(r['floor'],320) for p in points))
        a,b,c,d,x,y=row['wrist'];u,v=row['offset']
        assert math.dist([a*u+c*v+x,b*u+d*v+y],row['origin'])<0.01 and row['closed'] and row['layer']
        assert row['facing']==data['side']
        origin=row['origin'];angle=row['angle']
        gap=math.dist([origin[0]+math.cos(angle)*data['side']*nozzle,origin[1]+math.sin(angle)*nozzle],points[0])
        assert gap<0.01;gaps.append(gap)
        if not negative:
            assert ratio<0.99 and below[-1]<=0.01
            assert max(math.dist(a,b) for a,b in zip(points,points[1:])) <= length/19+0.0001
            if r['active']:assert bow>=0.04
    if negative:
        assert data['failures']>0 and max(straight)>=0.99
        return {'negative_rejected':True,'max_straightness':max(straight),'side':data['side']}
    assert data['failures']==0
    moves={}
    for move in MOVES:
        rows=[r for r in data['rows'] if r['pose']==move]
        active=[r for r in rows if r['rope']['active']]
        assert active and len([r for r in data['rows'] if r['pose']==move+':recovery'])==60
        tip_gap=min(math.dist(r['rope']['nodes'][-1],r['rope']['target']) for r in active)
        assert tip_gap <= active[0]['rope']['range']*0.15
        wave=any((r['rope']['nodes'][4][0]-r['rope']['nodes'][0][0])*data['side']>2 and (r['rope']['nodes'][-1][0]-r['rope']['nodes'][0][0])*data['side']< -2 for r in rows if r['rope']['windup'])
        assert wave,(folder,move,'wave missing')
        moves[move]={'frames':len(rows),'active_frames':len(active),'tip_gap':tip_gap,'range':active[0]['rope']['range'],'wave_seen':wave}
    life={r['case']:r for r in data['lifecycle']}
    assert life['interrupted']['tip_below_palm']>4
    assert not life['switched-out']['laid'] and not life['switched-out']['visible']
    assert life['switched-back']['laid'] and life['switched-back']['tip_palm_gap']<50
    for shot,frame in zip(data['shots'],data['framing']):
        assert shot['name']==frame['name'] and frame['player_held']
        x,y,w,h=frame['screen_bounds'];assert x>=-.02 and y>=-.02 and x+w<=640.02 and y+h<=360.02
        with Image.open(folder/(shot['name']+'.png')) as image:assert image.size==(640,360)
    return {'frames':len(data['rows']),'shots':len(data['shots']),'side':data['side'],'max_straightness':max(straight),
            'min_active_bow':min(b for b,r in zip(bows,data['rows']) if r['rope']['active']),
            'max_below_floor':max(below),'max_nozzle_gap':max(gaps),'moves':moves,'lifecycle':data['lifecycle'],
            'nominal_length_checks_passed':True,'max_chord_to_arc':max(geometry),'arc_shape_accepted':not geometry_failures,'arc_shape_failures':geometry_failures}

def render():
    dest=BASE/'review';dest.mkdir(exist_ok=False);pages=[]
    for side in ['right','left']:
        folder=BASE/('native-'+side);data=json.loads((folder/'grip.json').read_text())
        for group in ['poses']+MOVES+['lifecycle']:
            if group=='poses':names=['whip-'+p for p in POSES]
            elif group=='lifecycle':names=['whip-interrupted','whip-switched-out','whip-switched-back']
            else:names=[s['name'] for s in data['shots'] if s['name'].startswith('whip-'+group+'-')]
            # Keep each 640x360 frame native size and split long films into pages of six.
            for start in range(0,len(names),6):
                selected=names[start:start+6];sheet=Image.new('RGB',(1280,40+math.ceil(len(selected)/2)*384),(18,21,29));draw=ImageDraw.Draw(sheet)
                draw.text((8,8),'NE276 '+side+' '+group+' / arranged playback, native-size full frames',fill='white')
                for i,name in enumerate(selected):
                    x=(i%2)*640;y=40+(i//2)*384;draw.text((x+4,y+2),name,fill='white')
                    with Image.open(folder/(name+'.png')) as image:sheet.paste(image,(x,y+22))
                name='%s-%s-%02d.png'%(side,group,start//6+1);path=dest/name;sheet.save(path)
                pages.append({'name':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'shots':selected})
    (dest/'pages.json').write_text(json.dumps(pages,indent=2)+'\n');return len(pages)

if __name__=='__main__':
    reports=[read(BASE/('native-'+side)) for side in ['right','left']]+[read(BASE/'negative-straight-rope',True)]
    (BASE/'independent.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps({'reports':reports,'pages':render()}),flush=True)
