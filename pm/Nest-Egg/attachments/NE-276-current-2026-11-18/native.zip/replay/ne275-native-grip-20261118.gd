extends "res://tools/melee_art_probe.gd"
## Private arranged playback; inherits the published whole-pose framing and native capture.
var side := 1
var rows: Array[Dictionary] = []
var shots: Array[Dictionary] = []
var negative := false

func _run() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--facing="):
			side = int(argument.trim_prefix("--facing="))
		elif argument == "--negative":
			negative = true
	assert(side in [-1, 1])
	Engine.max_physics_steps_per_frame = 1
	Story.auto_skip = true
	await open_arena("res://data/lighting/warehouse_interior.tres", 12.0)
	await clear_enemies()
	var camera := get_viewport().get_camera_2d()
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.limit_enabled = false
	for weapon_id in WEAPONS:
		var weapon := load("res://data/weapons/melee/melee_%s.tres" % weapon_id) as WeaponData
		for pose in ["idle", "walk", "run", "crouch", "air", "dash"]:
			await arm_side(weapon, camera)
			var action := &"move_right" if side == 1 else &"move_left"
			if pose in ["walk", "run"]:
				Input.action_press(action, 0.3 if pose == "walk" else 1.0)
			elif pose == "crouch":
				Input.action_press(&"move_down")
			elif pose == "air":
				Input.action_press(&"jump")
			elif pose == "dash":
				Input.action_press(&"dash")
			var count := 10 if pose in ["air", "dash"] else 30
			for frame in count:
				await step()
				observe(weapon_id, pose, frame)
				if frame == count - 1:
					await photo("%s-%s" % [weapon_id, pose], camera)
			for key in [action, &"move_down", &"jump", &"dash"]:
				Input.action_release(key)
			await settle(50)
			if negative:
				break
		if negative:
			break
		var set := MeleeData.set_of(weapon)
		var moves: Array = set.combo()
		if not set.extension_attack().is_empty():
			moves.append(set.extension_attack())
		var hold: Dictionary = set.call(&"hold")
		if not hold.is_empty():
			moves.append(str(hold["attack"]))
		for move in moves:
			await arm_side(weapon, camera)
			if not player._start_melee_attack(false):
				_failures += 1
				continue
			player._melee_attack = set.attack(str(move), move == set.extension_attack())
			var frame := 0
			while player.melee_pose_progress() >= 0.0 and frame < 240:
				await step()
				observe(weapon_id, str(move), frame)
				if frame % 3 == 0:
					await photo("%s-%s-%03d" % [weapon_id, move, frame], camera)
				frame += 1
			if frame < 2 or player.melee_pose_progress() >= 0.0:
				_failures += 1
			for recovery in 20:
				await step()
				observe(weapon_id, str(move) + ":recovery", recovery)
			await photo("%s-%s-recovered" % [weapon_id, move], camera)
	var file := FileAccess.open(out_dir.path_join("grip.json"), FileAccess.WRITE)
	assert(file != null)
	file.store_string(JSON.stringify({"side": side, "rows": rows, "shots": shots, "framing": _framing, "failures": _failures}, "\t"))
	file.close()
	print("NE275_GRIP frames=%d shots=%d failures=%d" % [rows.size(), shots.size(), _failures])
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if _failures > 0 else 0)

func arm_side(weapon: WeaponData, camera: Camera2D) -> void:
	await _arm(weapon, camera)
	AimInput.using_gamepad = true
	AimInput._last_stick_dir = Vector2(side, 0)
	player.facing = side
	player.aim_dir = Vector2(side, 0)
	await settle(30)

func step() -> void:
	await get_tree().physics_frame
	await get_tree().process_frame

func observe(weapon_id: String, pose: String, frame: int) -> void:
	var rig := player._visual.rig
	var held := player._visual.melee_held()
	var wrist := rig.bone(&"hand_front").global_transform
	var offset := rig.hand_grip_offset(&"hand_front")
	if negative:
		held._origin.x += 1.0
	var origin := held.hold().origin
	var sprite := rig.find_children("hand_front", "Sprite2D", true, false)[0] as Sprite2D
	var closed := false
	for entry in rig._hand_grips:
		if entry["bone"] == &"hand_front":
			closed = entry["closed"] and sprite.texture == entry["grip_texture"]
	var distance := origin.distance_to(wrist * offset)
	var layer := held.is_visible_in_tree() and held.z_index == sprite.z_index and held.get_index() == 0
	var ok := is_finite(distance) and distance < 0.01 and closed and layer and offset != Vector2.ZERO
	if not ok:
		_failures += 1
	var back := rig.hand_contact_global(&"back")
	rows.append({"weapon": weapon_id, "pose": pose, "frame": frame, "facing": player.facing,
		"wrist": [wrist.x.x, wrist.x.y, wrist.y.x, wrist.y.y, wrist.origin.x, wrist.origin.y],
		"offset": [offset.x, offset.y], "origin": [origin.x, origin.y], "distance": distance,
		"closed": closed, "layer": layer, "ok": ok, "second": rig.second_hand_on_weapon,
		"back_distance": back.distance_to(held.second_grip()), "velocity": [player.velocity.x, player.velocity.y],
		"angle": held.angle(), "lag": held.lag_from(rig.bone(&"hand_front").global_rotation)})

func photo(name: String, camera: Camera2D) -> void:
	var hands := await _capture_pose(name, camera)
	shots.append({"name": name, "hands": hands})
