from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path.cwd();capture=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/ne276-current')
published=json.loads(Path('D:/NestEggVerification/evidence-20261117/ne275-current/publish/result.json').read_text());assert published['main_origin_head_equal']
source=json.loads(Path('D:/NestEggVerification/evidence-20261117/ne275-current/source-base.json').read_text())
snapshot=lambda:{n:hashlib.sha256((capture/n).read_bytes()).hexdigest() for n in source}
assert snapshot()==source;(base/'source-base.json').write_text(json.dumps(source,indent=2)+'\n')
helper=capture/'work/ne276-native-rope-20261118.gd';assert not helper.exists();shutil.copyfile(root/'work/ne276-native-rope-20261118.gd',helper)
scene=helper.with_suffix('.tscn');assert not scene.exists()
scene.write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/ne276-native-rope-20261118.gd" id="1"]\n[node name="RopeReview" type="Node"]\nscript = ExtResource("1")\n')
runs=[]
for label,side,negative in [('native-right',1,False),('native-left',-1,False),('negative-straight-rope',1,True)]:
    out=base/label;out.mkdir(exist_ok=False);env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(out/'private-profile'/k)
    cmd=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(capture),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/ne276-native-rope-20261118.tscn','--','--out='+str(out),'--facing='+str(side)]
    if negative:cmd.append('--rope-negative')
    (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with (out/'raw.log').open('wb') as f:run=subprocess.run(cmd,cwd=capture,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
    raw=(out/'raw.log').read_bytes();row={'label':label,'exit':run.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'errors':[l.decode('utf-8',errors='replace') for l in raw.splitlines() if b'ERROR:' in l]}
    runs.append(row);(out/'result.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(row,ensure_ascii=False),flush=True)
    assert row['exit']==(1 if negative else 0) and row['script_errors']==0 and not row['errors']
assert snapshot()==source
(base/'native-runs.json').write_text(json.dumps({'runs':runs,'source_held_before_after_batch':True,'source_files':len(source),'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'root_commit':published['commit']},indent=2)+'\n')
print('NE276_NATIVE_COMPLETE',flush=True)
