from pathlib import Path
import hashlib,importlib.util,json,zipfile
root=Path.cwd();packet=root/'pm/Nest-Egg/attachments/NE-276-current-2026-11-18';base=Path('D:/NestEggVerification/evidence-20261117/ne276-current');out=base/'packet-reader';out.mkdir(exist_ok=False)
receipt=json.loads((packet/'packet.json').read_text());archive=packet/'native.zip'
with archive.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==receipt['archive_sha256']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==receipt['members']
    manifest=json.loads(z.read('manifest.json'))
    for n,item in manifest.items():
        assert '..' not in Path(n).parts and not n.startswith('/')
        data=z.read(n);assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
        if n.startswith(('native-right/','native-left/','negative-straight-rope/','source/','replay/')):
            path=out/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
spec=importlib.util.spec_from_file_location('rope_reader',out/'replay/read-ne276-rope-20261118.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
reports=[reader.read(out/('native-'+s)) for s in ['right','left']]+[reader.read(out/'negative-straight-rope',True)]
assert reports[0]['arc_shape_accepted'] and not reports[1]['arc_shape_accepted'] and len(reports[1]['arc_shape_failures'])==1
fixture=out/'native-right/grip.json';original=fixture.read_bytes();data=json.loads(original)
data['rows'][0]['rope']['nodes'][0][0]+=1;fixture.write_text(json.dumps(data))
try:reader.read(out/'native-right')
except AssertionError:negative=True
else:raise AssertionError('corrupt rope node accepted')
finally:fixture.write_bytes(original)
result={'packet_verified':True,'original_nominal_checks_passed':True,'arc_shape_accepted':False,'arc_shape_failures':reports[1]['arc_shape_failures'],'native_straight_rope_rejected':reports[-1]['negative_rejected'],'corrupt_node_rejected':negative}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
