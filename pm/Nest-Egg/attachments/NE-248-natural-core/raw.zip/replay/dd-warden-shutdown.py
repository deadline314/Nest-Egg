import subprocess,os,json,math
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');fields=json.loads((b/'warden-shutdown-fields-all/fields.json').read_text())['different'];runs=[]
def clean(subset):
 name='warden-shutdown-dd-%02d'%len(runs)
 with (b/(name+'-driver.log')).open('w') as f:
  result=subprocess.run(['python',str(b/'native.py'),name,'res://work/warden_shutdown_fields.tscn','--copy='+','.join(subset)],cwd=b/'audio',env=dict(os.environ,NE_NATIVE_PROJECT='audio'),stdout=f,stderr=subprocess.STDOUT)
 raw=(b/(name+'.log')).read_text();ok=result.returncode==0 and 'ERROR:' not in raw
 runs.append({'name':name,'fields':subset,'clean':ok,'returncode':result.returncode});(b/'warden-shutdown-dd.json').write_text(json.dumps({'current':fields,'runs':runs},indent=2)+'\n');print(name,subset,'CLEAN' if ok else 'FAIL',flush=True);return ok
# Find the smallest single partition that stays clean, then remove fields one by one.
while len(fields)>1:
 middle=(len(fields)+1)//2
 if clean(fields[:middle]):fields=fields[:middle];continue
 if clean(fields[middle:]):fields=fields[middle:];continue
 break
for field in list(fields):
 subset=[f for f in fields if f!=field]
 if clean(subset):fields=subset
(b/'warden-shutdown-dd.json').write_text(json.dumps({'minimal_clean_fields':fields,'runs':runs},indent=2)+'\n');print('MINIMAL',fields,flush=True)
