import subprocess,os,time,hashlib,json
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');p=b/'audio/game/projectiles/projectile.gd';names=['warden-natural-current-right-v9','warden-natural-current-left-v9']
while not (b/'warden-natural-current-left-v8.exit').exists():time.sleep(.5)
assert (b/'warden-v8-cancelled.json').exists()
assert hashlib.sha256(p.read_bytes()).hexdigest() == '8018c6058da731a9cfc2165f1e4365ce57264a8c28a7910a66ee3c4857712c50'
assert json.loads((b/'warden-point-control-restore-v7.json').read_text())['restored']
for name,side in zip(names,[1,-1]):
 r=subprocess.run(['python',str(b/'native.py'),name,'res://work/warden_natural_probe_v9.tscn','--side='+str(side),'--mode=current'],cwd=b/'audio',env=dict(os.environ,NE_NATIVE_PROJECT='audio'))
 assert r.returncode==0 and 'ERROR:' not in (b/(name+'.log')).read_text(),name+' did not finish clean; source unchanged'

normal=p.read_bytes();needle=b'hurtbox = hurtbox.resolve_along(global_position, velocity, 3.0, _is_path_blocked)';assert normal.count(needle)==1
point=normal.replace(needle,b'hurtbox = hurtbox.resolve_at(global_position)')
(b/'warden-natural-source/projectile-current.gd').write_bytes(normal);(b/'warden-natural-source/projectile-point-only.gd').write_bytes(point)
rows=[]
try:
 p.write_bytes(point)
 for side,label in [(1,'right'),(-1,'left')]:
  name='warden-natural-point-'+label+'-v9'
  r=subprocess.run(['python',str(b/'native.py'),name,'res://work/warden_natural_probe_v9.tscn','--side='+str(side),'--mode=point-only-diagnostic'],cwd=b/'audio',env=dict(os.environ,NE_NATIVE_PROJECT='audio'))
  rows.append({'name':name,'exit':r.returncode,'errors':(b/(name+'.log')).read_text().count('ERROR:')})
finally:
 p.write_bytes(normal)
 (b/'warden-point-control-restore-v9.json').write_text(json.dumps({'restored':p.read_bytes()==normal,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'point_only_sha256':hashlib.sha256(point).hexdigest(),'runs':rows},indent=2)+'\n')
print('point controls complete; original source restored',flush=True)
