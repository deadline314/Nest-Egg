extends ScenarioBase
func _ready() -> void:
	_run.call_deferred()
func _run() -> void:
	await open_arena("res://data/lighting/neutral.tres", 18)
	if not OS.get_cmdline_user_args().has("--no-boss"):
		spawn_enemy("res://data/enemies/warden.tres", 30)
	await wait(1.0)
	await finish()
	for frame in 30:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
	print("SHUTDOWN_CONTROL complete")
	get_tree().quit()
