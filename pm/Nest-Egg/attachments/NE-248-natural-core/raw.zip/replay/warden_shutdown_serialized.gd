extends Node
func _ready() -> void:
	_run.call_deferred()
func _run() -> void:
	add_child(LightKit.create_environment())
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(load("res://work/warden_arena.tres") as LevelData)
	add_child(level)
	await get_tree().create_timer(5.0).timeout
	level.queue_free()
	for frame in 30:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
	print("SERIALIZED_SHUTDOWN complete")
	await AudioRelease.settle(get_tree())
	get_tree().quit()
