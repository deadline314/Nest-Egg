extends Node
var out := ""
var selection := "ALL"
func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): out = arg.trim_prefix("--out=")
		if arg.begins_with("--copy="): selection = arg.trim_prefix("--copy=")
	_run.call_deferred()
func _run() -> void:
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	var source := load("res://data/levels/ch1_street.tres") as LevelData
	var data := LevelData.new()
	data.id = &"arena_test"
	data.layout_path = "res://tests/fixtures/arena_map.json"
	var zone := LightingZone.new()
	zone.profile = load("res://data/lighting/neutral.tres")
	data.lighting_zones = [zone]
	var different: Array[String] = []
	var copied: Array[String] = []
	for property in data.get_property_list():
		var name := str(property["name"])
		if not (int(property["usage"]) & PROPERTY_USAGE_SCRIPT_VARIABLE) or name in ["id", "layout_path", "intro_scene", "outro_scene"]: continue
		if data.get(name) != source.get(name):
			different.append(name)
			if selection == "ALL" or selection.split(",", false).has(name):
				data.set(name, source.get(name))
				copied.append(name)
	var record := FileAccess.open(out.path_join("fields.json"), FileAccess.WRITE)
	record.store_string(JSON.stringify({"different": different, "copied": copied}, "  "))
	record.close()
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(data)
	add_child(level)
	await get_tree().create_timer(5.0).timeout
	level.queue_free()
	for frame in 30:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
	print("FIELD_SHUTDOWN complete; copied=", copied)
	await AudioRelease.settle(get_tree())
	get_tree().quit()
