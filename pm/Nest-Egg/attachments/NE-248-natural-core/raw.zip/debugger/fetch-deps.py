import urllib.request,re,concurrent.futures,subprocess
from pathlib import Path
jobs=[('s/source-highlight','libsource-highlight4t64_', '3.1.9'),('e/elfutils','libdw1t64_','0.192')]
def fetch(job):
 folder,prefix,preferred=job;url='https://deb.debian.org/debian/pool/main/'+folder+'/'
 html=urllib.request.urlopen(url,timeout=20).read().decode();names=sorted(set(re.findall(r'href="('+re.escape(prefix)+r'[^\"]+_amd64.deb)"',html)))
 match=[n for n in names if preferred in n];name=(match or names)[0]
 urllib.request.urlretrieve(url+name,name);subprocess.run(['dpkg-deb','-x',name,'runtime'],check=True);return name
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for name in ex.map(fetch,jobs):print(name)
