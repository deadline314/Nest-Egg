extends Node
func _ready() -> void:
	_run.call_deferred()
func _run() -> void:
	var data := LevelData.new()
	data.id = &"arena_test"
	data.layout_path = "res://tests/fixtures/arena_map.json"
	var zone := LightingZone.new()
	zone.profile = load("res://data/lighting/neutral.tres")
	data.lighting_zones = [zone]
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(data)
	add_child(level)
	await get_tree().create_timer(5.0).timeout
	level.queue_free()
	for frame in 30:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
	print("STANDALONE_SHUTDOWN complete")
	get_tree().quit()
