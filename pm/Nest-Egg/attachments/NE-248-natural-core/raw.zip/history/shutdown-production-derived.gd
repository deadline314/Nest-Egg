extends Node
func _ready() -> void:
	_run.call_deferred()
func _run() -> void:
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	var data := (load("res://data/levels/ch1_street.tres") as LevelData).duplicate(true) as LevelData
	data.id = &"arena_test"
	data.layout_path = "res://tests/fixtures/arena_map.json"
	data.intro_scene = &""
	data.outro_scene = &""
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(data)
	add_child(level)
	await get_tree().create_timer(5.0).timeout
	level.queue_free()
	for frame in 30:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
	print("STANDALONE_SHUTDOWN complete")
	await AudioRelease.settle(get_tree())
	get_tree().quit()
