import json,hashlib
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');rows=[];sources=[]
for mode in ['current','point']:
 for label,side in [('right',1),('left',-1)]:
  name=f'warden-natural-{mode}-{label}-v7';d=json.loads((b/name/'report.json').read_text());raw=(b/(name+'.log')).read_text()
  assert 'ERROR:' not in raw,name
  assert (b/(name+'.exit')).read_text()==('0' if mode=='current' else '1'),name
  assert d['chapter']=='ch1_kasa' and d['initial_side']==side,name
  assert d['source_sha256']['res://work/warden_natural_probe_v7.gd']==hashlib.sha256((b/'audio/work/warden_natural_probe_v7.gd').read_bytes()).hexdigest(),name
  hp=90
  for hit in d['hits']:
   assert hit['source']=='player_pistol' and hit['before_hp']==hp and hit['after_hp']==hp-hit['amount'],(name,hit)
   hp=hit['after_hp']
  threshold=next(h for h in d['hits'] if h['after_hp']<=45)
  phase2=next(c['event'] for c in d['captures'] if c['name']=='phase2')
  assert phase2['t']>=threshold['t'] and phase2['t']-threshold['t']<.051,(name,threshold,phase2)
  cases={stage:[h for h in d['hits'] if h['stage']==stage] for stage in ['core','body','closed']}
  for stage,hits in cases.items():assert len(hits)==1,(name,stage,hits)
  core=cases['core'][0];body=cases['body'][0];closed=cases['closed'][0]
  assert core['state']=='core_recover' and core['phase']==2 and core['core_scale']==2 and core['body_scale']==1 and core['boss_facing']==-side,(name,core)
  assert (core['part'],core['weak'],core['amount'],core['marker']) == (('core',True,2,'weak') if mode=='current' else ('',False,1,'hit')),(name,core)
  assert body['state']=='core_recover' and body['core_scale']==2 and body['body_scale']==1 and (body['part'],body['weak'],body['amount'],body['marker'])==('',False,1,'hit'),(name,body)
  assert closed['core_scale']==1 and closed['body_scale']==1 and not closed['weak'] and closed['amount']==1 and closed['marker']=='hit',(name,closed)
  failed=[c['message'] for c in d['checks'] if not c['passed']]
  if mode=='current':assert not failed,(name,failed)
  else:assert len(failed)==2 and all(('exposed core' in message or 'exposed core' in message) for message in failed),(name,failed)
  capture=next(c for c in d['captures'] if c['name']=='core_hit');assert capture['event']['marker']==core['marker'],name
  rows.append({'name':name,'checks':len(d['checks']),'failures':len(failed),'core_facing':core['boss_facing'],'natural_phase2_after_hp':threshold['after_hp'],'core_hp':[core['before_hp'],core['after_hp']],'core_part':core['part'],'weak':core['weak'],'marker':core['marker'],'body_damage':body['amount'],'closed_damage':closed['amount'],'all_hp_accounted':90-hp,'clean_engine_log':True})
  sources.append(d['source_sha256'])
for path in sources[0]:
 if path=='res://game/projectiles/projectile.gd':continue
 assert len({s[path] for s in sources})==1,path
result={'scope':'independent raw-event accounting and same-probe/same-protected-source check; not art, hardware or human gameplay acceptance','runs':rows,'only_source_difference_between_controls':'one point-only resolver call in projectile.gd; patch is diagnostic, not an entire historical build'}
(b/'warden-natural-independent-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(rows))
