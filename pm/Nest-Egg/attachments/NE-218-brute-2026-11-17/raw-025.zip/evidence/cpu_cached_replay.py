from pathlib import Path
import sys,runpy
ROOT=Path('D:/NestEggVerification/role-20261117')
sys.path.insert(0,str(ROOT/'tools/comfyui'))
import comfy_guard,comfy_api,sam_masks
def refused(*a,**kw):
 raise RuntimeError('CPU cache-only replay needs an uncached model request; shared service lifecycle/model work was not authorized for this diagnostic.')
comfy_guard._start=refused
comfy_guard.restart_server=refused
for name in ['qwen','upload','run','_run_once']:setattr(comfy_api,name,refused)
sam_masks.segment=refused
sam_masks.segment_points=refused
tool=sys.argv.pop(1)
assert tool in ['make_parts.py','refine_parts.py']
runpy.run_path(str(ROOT/'tools/comfyui'/tool),run_name='__main__')
