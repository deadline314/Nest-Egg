extends "res://tools/rig_preview.gd"
## Diagnostic material isolation only; original source, pose and preview logic remain unchanged.
func _spawn(skin: String, weapon: String, pos: Vector2, pose: String, zoom: float, armor_ratio := 1.0) -> void:
	super._spawn(skin, weapon, pos, pose, zoom, armor_ratio)
	if not "--diagnostic-no-normals" in OS.get_cmdline_user_args(): return
	var changed := 0
	for node in _rigs.back().find_children("*", "CanvasItem", true, false):
		if not (node is Sprite2D or node is Polygon2D): continue
		if not node.texture is CanvasTexture: continue
		var texture: CanvasTexture = node.texture.duplicate()
		texture.normal_texture = null
		node.texture = texture
		changed += 1
	assert(changed > 0)
	print("DIAGNOSTIC normals removed from ", changed, " textures; pose=", pose)
