extends Node
## Real first-chapter level and unchanged Slasher AI. Only the test player,
## diagnostic camera, story overlay and non-target suspension are arranged.
const Capture := preload("res://tools/viewport_capture.gd")
const Held := preload("res://tools/held_lighting_state.gd")
const EXPECTED := {"windup": "collector_brute.windup_slash", "leap": "collector_brute.slash", "recover": "collector_brute.recover"}
var _out := ""
var _failures: Array[String] = []
var _records: Array[Dictionary] = []
var _pending: Array[Dictionary] = []
var _environment: WorldEnvironment
var _foot_only := false
var _foot_points: Array[Vector2] = []

func _ready() -> void:
	Settings.use_storage("user://ne218_brute_level_settings.cfg")
	_foot_only = "--diagnostic-foot-only" in OS.get_cmdline_user_args()
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	if OS.get_cmdline_user_args().has("--validate-only"):
		var data := load("res://data/enemies/collector_brute.tres") as EnemyData
		var valid := data != null and data.rig_skin == "collector_brute" and load("res://data/levels/ch1_street.tres") != null
		print("NE218_LEVEL_COMPILE valid=", valid, " (not native AI evidence)")
		get_tree().quit(0 if valid else 1)
		return
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		push_error("[NE218 Level] Native renderer and absolute --out required")
		get_tree().quit(2)
		return
	_environment = LightKit.create_environment()
	add_child(_environment)
	var overlay := CanvasLayer.new()
	add_child(overlay)
	var caption := Label.new()
	caption.position = Vector2(12, 12)
	caption.text = "NE218 / CH1 ORIGINAL AI / ARRANGED PLAYER + 999 HP / NOT HUMAN PLAY"
	caption.add_theme_font_size_override("font_size", 12)
	overlay.add_child(caption)
	_run.call_deferred()

func _check(ok: bool, message: String) -> void:
	if not ok:
		_failures.append(message)
		printerr("[NE218 Level] FAIL ", message)

func _run() -> void:
	DirAccess.make_dir_recursive_absolute(_out)
	var quality_before := Settings.get_light_quality()
	var brightness_before := Settings.get_brightness()
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Settings.set_brightness(0.5)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids(): Story._seen[StringName(id)] = true
	for direction in [-1, 1]: await _observe(direction)
	# Keep PNG encoding and raw disk writes outside the observed AI timelines.
	for item in _pending:
		var image: Image = item.image
		var raw_path := _out.path_join(item.stem + ".bin")
		var raw := FileAccess.open(raw_path, FileAccess.WRITE)
		raw.store_buffer(image.get_data())
		raw.close()
		_check(Capture.encode(image, get_viewport().use_hdr_2d).save_png(_out.path_join(item.stem + ".png")) == OK, "native PNG saved")
		item.metadata.raw_sha256 = FileAccess.get_sha256(raw_path)
		item.metadata.png_sha256 = FileAccess.get_sha256(_out.path_join(item.stem + ".png"))
	_pending.clear()
	Settings.set_light_quality(quality_before)
	Settings.set_brightness(brightness_before)
	var result := {"scope": "Actual ch1_street Level and unchanged collector_brute AI/stats/motions; player placed on nearby authored terrain with 999 HP and authored hurt invulnerability; non-target enemies suspended; diagnostic camera follows target; lightning/story overlays suppressed; not human play or a performance measurement",
		"engine": Engine.get_version_info().string, "adapter": RenderingServer.get_video_adapter_name(),
		"renderer": RenderingServer.get_current_rendering_method(), "hdr_2d": get_viewport().use_hdr_2d,
		"quality": "high", "brightness": 0.5, "time_scale": Engine.time_scale,
		"failures": _failures, "cases": _records}
	var file := FileAccess.open(_out.path_join("actions.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(result, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	print("NE218_LEVEL cases=%d failures=%d" % [_records.size(), _failures.size()])
	get_tree().quit(0 if _failures.is_empty() else 1)

func _observe(direction: int) -> void:
	seed(21861)
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(load("res://data/levels/ch1_street.tres") as LevelData)
	add_child(level)
	var target: Enemy
	for node in level._entities.get_children():
		if node is Enemy:
			if target == null and node.data.id == &"collector_brute": target = node
			else: node.process_mode = Node.PROCESS_MODE_DISABLED
	_check(target != null, "authored collector_brute exists")
	if target == null:
		level.queue_free()
		await get_tree().process_frame
		return
	for _registration_frame in 2: await get_tree().physics_frame
	var enemy_start := target.global_position
	var original_hp := target.health.current
	var player_x := enemy_start.x + 72.0 * direction
	var query := PhysicsRayQueryParameters2D.create(Vector2(player_x, enemy_start.y - 24), Vector2(player_x, enemy_start.y + 96), Layers.SOLID)
	var floor_hit := level.get_world_2d().direct_space_state.intersect_ray(query)
	_check(not floor_hit.is_empty(), "authored terrain beneath arranged player")
	level.player.health.setup(999, level.player.tuning.hurt_invulnerability)
	level.player.global_position = Vector2(player_x, floor_hit.position.y - 2 if not floor_hit.is_empty() else enemy_start.y)
	level.player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(level.player, true)
	level.hud.visible = false
	level._lighting._lightning_gap = 1.0e9
	for node in level.find_children("*", "", true, false):
		if node is WorldPrompt:
			node.visible = false
			node.process_mode = Node.PROCESS_MODE_DISABLED
		elif node is ChapterCard: node.queue_free()
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.offset = Vector2.ZERO
	camera.zoom = Vector2.ONE * 3.4
	camera.limit_left = -1000000
	camera.limit_top = -1000000
	camera.limit_right = 1000000
	camera.limit_bottom = 1000000
	var timeline: Array[Dictionary] = []
	var captures: Array[Dictionary] = []
	var states: Dictionary = {}
	var actions: Dictionary = {}
	var captured: Dictionary = {}
	var first_windup_facing := 0
	var start_frame := Engine.get_physics_frames()
	while Engine.get_physics_frames() - start_frame < 480:
		await get_tree().physics_frame
		camera.global_position = target.global_position + Vector2(0, -42)
		camera.reset_smoothing()
		camera.force_update_scroll()
		var state := str(target.fsm.current)
		states[state] = true
		var action := str(target._rig_input.action)
		if not action.is_empty(): actions[action] = true
		if state == "windup" and first_windup_facing == 0: first_windup_facing = target.facing
		timeline.append({"physics_frame": Engine.get_physics_frames(), "state": state, "state_time": target.fsm.time_in_state,
			"action": action, "action_t": target._rig_input.action_t, "facing": target.facing, "crouching": target._rig_input.crouching,
			"enemy_feet": [target.global_position.x, target.global_position.y], "player_feet": [level.player.global_position.x, level.player.global_position.y],
			"on_floor": target.is_on_floor(), "enemy_hp": target.health.current, "player_hp": level.player.health.current,
			"foot_materials": _foot_materials(target) if _foot_only and state == "windup" else []})
		var key := "%s-%d" % [state, mini(2, int(target.fsm.time_in_state / 0.2))]
		if not _foot_only and not captured.has(key) and captures.size() < 12:
			captured[key] = true
			await RenderingServer.frame_post_draw
			var probe := ContrastProbe.capture(get_viewport())
			var bounds := target.rig.visual_bounds()
			var stem := "face%d-%02d-%s" % [direction, captures.size(), target.fsm.current]
			var metadata := {"file": stem + ".png", "raw": stem + ".bin", "format": probe._image.get_format(),
				"size": [probe._image.get_width(), probe._image.get_height()], "trigger_state": state, "state": str(target.fsm.current),
				"state_time": target.fsm.time_in_state, "physics_frame": Engine.get_physics_frames(), "action": str(target._rig_input.action),
				"action_t": target._rig_input.action_t, "facing": target.facing, "crouching": target._rig_input.crouching,
				"enemy_feet": [target.global_position.x, target.global_position.y], "on_floor": target.is_on_floor(),
				"rig_fill": target.rig._fill, "light_cap": target.rig._light_cap,
				"profile": str(level._lighting.zone_id_at(level.player.global_position.x)),
				"world_environment_active": get_viewport().find_world_3d().environment == _environment.environment,
				"glow_enabled": _environment.environment.glow_enabled,
				"visual_world_bounds": [bounds.position.x, bounds.position.y, bounds.size.x, bounds.size.y],
				"canvas_transform_values": Held.transform_values(probe._to_screen), "density": probe._scale}
			captures.append(metadata)
			_pending.append({"image": probe._image, "stem": stem, "metadata": metadata})
	for required in ["patrol", "windup", "leap", "recover"]: _check(states.has(required), "real AI state " + required + " face " + str(direction))
	for required in EXPECTED.values(): _check(actions.has(required), "original authored clip " + required + " face " + str(direction))
	_check(first_windup_facing == direction, "first original windup faces arranged player")
	_check(target.health.current == original_hp, "enemy HP unchanged")
	_check(is_equal_approx(level.player.health.invulnerability_time, level.player.tuning.hurt_invulnerability), "authored hurt protection retained")
	var target_weak: WeakRef = weakref(target)
	var rig_weak: WeakRef = weakref(target.rig)
	var record := {"requested_first_facing": direction, "observed_first_windup_facing": first_windup_facing,
		"enemy_data_sha256": FileAccess.get_sha256("res://data/enemies/collector_brute.tres"),
		"level_data_sha256": FileAccess.get_sha256("res://data/levels/ch1_street.tres"),
		"spawn_feet": [enemy_start.x, enemy_start.y], "states": states.keys(), "actions": actions.keys(), "timeline": timeline, "captures": captures}
	level.queue_free()
	for _frame in 4: await get_tree().process_frame
	record.actor_freed = target_weak.get_ref() == null
	record.rig_freed = rig_weak.get_ref() == null
	_check(record.actor_freed and record.rig_freed, "actual Level actor/rig released")
	_records.append(record)


func _foot_materials(target: Enemy) -> Array[Dictionary]:
	var path := "res://art/characters/collector_brute/parts/foot.png"
	if _foot_points.is_empty():
		var image := Image.load_from_file(ProjectSettings.globalize_path(path))
		assert(image != null)
		for x in image.get_width():
			var lo := image.get_height()
			var hi := -1
			for y in image.get_height():
				if image.get_pixel(x, y).a * 255.0 >= 128.0:
					lo = mini(lo, y)
					hi = maxi(hi, y)
			if hi >= 0:
				for point in [Vector2(x, lo), Vector2(x + 1, lo), Vector2(x, hi + 1), Vector2(x + 1, hi + 1)]:
					_foot_points.append(point)
	var result: Array[Dictionary] = []
	for node in target.rig._parts:
		if str(node.name) not in ["foot_front", "foot_back"]: continue
		assert(node is Sprite2D)
		var sprite := node as Sprite2D
		var origin := sprite.get_rect().position
		var lowest := Vector2.ZERO
		var texture_point := Vector2.ZERO
		var max_y := -INF
		for point in _foot_points:
			var world := sprite.to_global(origin + point)
			if world.y > max_y:
				max_y = world.y
				lowest = world
				texture_point = point
		var query := PhysicsRayQueryParameters2D.create(Vector2(lowest.x, target.global_position.y - 32), Vector2(lowest.x, target.global_position.y + 32), Layers.SOLID)
		var hit := target.get_world_2d().direct_space_state.intersect_ray(query)
		result.append({"part": str(node.name), "source": path, "source_sha256": FileAccess.get_sha256(path),
			"policy": "Corners of native PNG pixels with alpha >=128; geometric material extent, not a new acceptance threshold or GPU timing",
			"part_world_transform": Held.transform_values(sprite.global_transform), "rect_origin": [origin.x, origin.y],
			"lowest_texture_corner": [texture_point.x, texture_point.y], "lowest_world": [lowest.x, lowest.y],
			"floor_hit": not hit.is_empty(), "terrain_y": hit.position.y if not hit.is_empty() else null,
			"material_below_terrain_wp": lowest.y - hit.position.y if not hit.is_empty() else null,
			"bone_global_angle": (target.rig.animator as HumanoidAnimator).foot_angle(StringName(node.name))})
	return result
