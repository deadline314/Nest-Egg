import os,subprocess,pathlib,json,hashlib,time,shutil
r=pathlib.Path("D:/NestEggVerification/role-20261117");ev=pathlib.Path(__file__).parent;baseline=json.loads((ev/"baseline-source.json").read_text(encoding="utf-8"));snapshot=ev/"candidates/v3-key-ownership/tested-files";assert not snapshot.exists();snapshot.mkdir()
paths=set(baseline["files"])
for root in ["art/characters/collector_brute","art_src/characters/collector_brute"]:
 paths.update(str(x.relative_to(r)).replace(chr(92),"/") for x in (r/root).rglob("*") if x.is_file())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
current={p:digest(r/p) for p in sorted(paths)}
for p in paths:
 dst=snapshot/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/p,dst)
(snapshot/"hashes.json").write_text(json.dumps(current,indent=2)+"\n",encoding="utf-8")
e=ev/"baseline-native/real-ai";e.mkdir(exist_ok=True);env=os.environ.copy();env.update(PYTHONUTF8="1",APPDATA=str(e/"user/Roaming"),LOCALAPPDATA=str(e/"user/Local"));base=["D:/ComfyUI/.venv-rocm/Scripts/python.exe","tools/comfyui/gpu_lock.py","--","C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(r)];records=[]
def run(name,args):
 cmd=base+args;start=time.time();proc=subprocess.run(cmd,cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(e/(name+".log")).write_bytes(proc.stdout);records.append({"name":name,"command":cmd,"exit":proc.returncode,"wall_seconds":time.time()-start});(e/"runs.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8");print(name,"exit",proc.returncode,flush=True);assert proc.returncode==0 and not any(x in proc.stdout for x in [b"SCRIPT ERROR",b"ERROR:"]),proc.stdout.decode("utf-8","replace")
try:
 for p,expected in baseline["files"].items():
  src=ev/"baseline-files"/p;assert digest(src)==expected;shutil.copy2(src,r/p)
 assert all(digest(r/p)==h for p,h in baseline["files"].items())
 run("import-original",["--headless","--editor","--quit"])
 before={p:digest(r/p) for p in baseline["files"]}
 run("native-original",["--rendering-driver","vulkan","--rendering-method","forward_plus","--quit-after","2400","res://work/ne218-brute-controls/level_action_probe.tscn","--","--out="+str(e)])
 after={p:digest(r/p) for p in baseline["files"]};assert before==after==baseline["files"];data=json.loads((e/"actions.json").read_text(encoding="utf-8"));assert not data["failures"],data["failures"]
 (e/"source-guard.json").write_text(json.dumps({"source_before":before,"source_after":after,"original74_exact":True},indent=2)+"\n",encoding="utf-8")
finally:
 for p,expected in current.items():
  assert digest(snapshot/p)==expected;shutil.copy2(snapshot/p,r/p)
 assert all(digest(r/p)==h for p,h in current.items())
 run("restore-v3-import",["--headless","--editor","--quit"])
 print("RESTORED v3 exact",len(current),flush=True)
