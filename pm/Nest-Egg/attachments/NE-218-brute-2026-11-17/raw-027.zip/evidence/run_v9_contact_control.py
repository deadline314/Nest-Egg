import os,subprocess,pathlib,json,hashlib,time,sys,shutil
r=pathlib.Path("D:/NestEggVerification/role-20261117");ev=pathlib.Path(__file__).parent;epoch=ev/"candidates/v9-contact-reference";epoch.mkdir(exist_ok=True);mode=sys.argv[1];assert mode in ["before","after"];e=epoch/mode;e.mkdir(exist_ok=True)
env=os.environ.copy();env.update(PYTHONUTF8="1",APPDATA=str(epoch/"user/Roaming"),LOCALAPPDATA=str(epoch/"user/Local"));base=["D:/ComfyUI/.venv-rocm/Scripts/python.exe","tools/comfyui/gpu_lock.py","--","C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(r)]
baseline=json.loads((ev/"baseline-source.json").read_text(encoding="utf-8"));paths=set(baseline["files"])|set(baseline["core_files"])|{"art/rigs/action_poses.json","data/enemies/collector_brute.tres","data/levels/ch1_street.tres","work/ne218-brute-controls/level_action_probe.gd"}
for root in ["art/characters/collector_brute","art_src/characters/collector_brute"]:
 paths.update(str(x.relative_to(r)).replace(chr(92),"/") for x in (r/root).rglob("*") if x.is_file() and not x.name.endswith(".import"))
def snap():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(paths)}
before=snap();cmd=base+["--rendering-driver","vulkan","--rendering-method","forward_plus","--quit-after","2400","res://work/ne218-brute-controls/level_action_probe.tscn","--","--diagnostic-foot-measure","--contact-film","--out="+str(e)];start=time.time();p=subprocess.run(cmd,cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(e/"native.log").write_bytes(p.stdout);after=snap();report={"mode":mode,"command":cmd,"exit":p.returncode,"wall_seconds":time.time()-start,"source_before":before,"source_after":after,"source_unchanged":before==after};(e/"run.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8");shutil.copy2(r/"work/ne218-brute-controls/level_action_probe.gd",e/"source-probe.gd");print(p.stdout.decode("utf-8","replace"));print(mode,"EXIT",p.returncode,"HELD",before==after,flush=True);assert p.returncode==0 and before==after and not any(x in p.stdout for x in [b"SCRIPT ERROR",b"ERROR:"]),"native run failed";result=json.loads((e/"actions.json").read_text(encoding="utf-8"));assert not result["failures"],result["failures"]
summary=[]
for case in result["cases"]:
 record={"facing":case["requested_first_facing"],"captures":len(case["captures"]),"states":case["states"],"actions":case["actions"],"actor_freed":case["actor_freed"],"rig_freed":case["rig_freed"],"feet":{}}
 for part in ["foot_front","foot_back"]:
  rows=[(tick,foot) for tick in case["timeline"] for foot in tick["foot_materials"] if foot["part"]==part and foot["floor_hit"] and tick["state"]=="windup"]
  tick,foot=max(rows,key=lambda row:row[1]["material_below_terrain_wp"]);record["feet"][part]={"windup_physics_samples":len(rows),"worst_material_below_terrain_wp":foot["material_below_terrain_wp"],"worst_state_time":tick["state_time"],"worst_foot_geometry":foot}
 summary.append(record)
(e/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8");print(json.dumps(summary,indent=2),flush=True)
