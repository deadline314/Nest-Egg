import os,subprocess,pathlib,json,hashlib,time
r=pathlib.Path("D:/NestEggVerification/role-20261117");ev=pathlib.Path(__file__).parent;e=ev/"candidates/v3-key-ownership/native";e.mkdir(exist_ok=True)
env=os.environ.copy();env.update(PYTHONUTF8="1",APPDATA=str(e/"user/Roaming"),LOCALAPPDATA=str(e/"user/Local"))
base=["D:/ComfyUI/.venv-rocm/Scripts/python.exe","tools/comfyui/gpu_lock.py","--","C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(r)]
commands=[("normals",["--headless","res://tools/art/paint_normals.tscn","--","--only=collector_brute"]),("import",["--headless","--editor","--quit"]),
("fixed60-keys-max",["--rendering-driver","vulkan","--rendering-method","forward_plus","--quit-after","600","res://work/ne218-brute-controls/preview_material_control.tscn","--","--chars=collector_brute","--diagnostic-fixed-60","--diagnostic-keys-max","--joints","--level=3","--zoom=7","--out="+str(e/"fixed60-keys-max.png")]),
("ai",["--rendering-driver","vulkan","--rendering-method","forward_plus","--quit-after","2400","res://work/ne218-brute-controls/level_action_probe.tscn","--","--out="+str(e/"ai")])]
baseline=json.loads((ev/"baseline-source.json").read_text(encoding="utf-8"));paths=set(baseline["files"])|set(baseline["core_files"])
for root in ["art/characters/collector_brute","art_src/characters/collector_brute"]:
 paths.update(str(x.relative_to(r)).replace(chr(92),"/") for x in (r/root).rglob("*") if x.is_file() and not x.name.endswith(".import"))
def snap():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(paths)}
records=[]
for name,args in commands:
 before=snap();start=time.time();cmd=base+args;p=subprocess.run(cmd,cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(e/(name+".log")).write_bytes(p.stdout);after=snap();record={"name":name,"command":cmd,"exit":p.returncode,"wall_seconds":time.time()-start,"source_before":before,"source_after":after,"unchanged":before==after};records.append(record);(e/"runs.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8");print(name,"exit",p.returncode,"held",before==after,flush=True)
 assert p.returncode==0 and not any(x in p.stdout for x in [b"SCRIPT ERROR",b"ERROR:"]),p.stdout.decode("utf-8","replace")
 if name not in ["normals","import"]:assert before==after
 if name=="ai":
  result=json.loads((e/"ai/actions.json").read_text(encoding="utf-8"));assert not result["failures"],result["failures"]
