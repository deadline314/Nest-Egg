import os,subprocess,pathlib,json,hashlib,time,shutil
r=pathlib.Path("D:/NestEggVerification/role-20261117");ev=pathlib.Path(__file__).parent;e=ev/"candidates/v3-key-ownership/traces";e.mkdir(exist_ok=True)
env=os.environ.copy();env.update(PYTHONUTF8="1",APPDATA=str(e/"user/Roaming"),LOCALAPPDATA=str(e/"user/Local"))
base=["D:/ComfyUI/.venv-rocm/Scripts/python.exe","tools/comfyui/gpu_lock.py","--","C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(r)]
baseline=json.loads((ev/"baseline-source.json").read_text(encoding="utf-8"));paths=set(baseline["files"])|set(baseline["core_files"])
for root in ["art/characters/collector_brute","art_src/characters/collector_brute"]:
 paths.update(str(x.relative_to(r)).replace(chr(92),"/") for x in (r/root).rglob("*") if x.is_file() and not x.name.endswith(".import"))
def snap():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(paths)}
records=[]
for name,joint,frame,zoom,whole in [("neck0-pair","neck",0,"3.4",False),("neck4-pair","neck",4,"1",False),("ankle7-pair","ankle_front",7,"3.4",False),("neck0-whole","neck",0,"3.4",True)]:
 out=e/name;out.mkdir(exist_ok=True);before=snap();args=["--rendering-driver","vulkan","--rendering-method","forward_plus","res://tools/rig_joint_audit.tscn","--","--chars=collector_brute","--frames=8","--zooms="+zoom,"--pair-only","--trace-joint="+joint,"--trace-frame="+str(frame),"--out="+str(out)]
 if whole:args.append("--diagnostic-whole-rig")
 cmd=base+args;p=subprocess.run(cmd,cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(e/(name+".log")).write_bytes(p.stdout);after=snap();records.append({"name":name,"command":cmd,"exit":p.returncode,"source_before":before,"source_after":after,"unchanged":before==after});(e/"runs.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8");print(name,"exit",p.returncode,"held",before==after,flush=True);assert p.returncode==0 and before==after and not any(x in p.stdout for x in [b"SCRIPT ERROR",b"ERROR:"]),p.stdout.decode("utf-8","replace")
