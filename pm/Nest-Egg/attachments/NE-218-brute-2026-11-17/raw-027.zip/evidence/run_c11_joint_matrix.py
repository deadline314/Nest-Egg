import os,subprocess,pathlib,json,hashlib,time
r=pathlib.Path("D:/NestEggVerification/role-20261117");ev=pathlib.Path(__file__).parent;e=ev/"candidates/v11-ground-plane/joint-matrix";e.mkdir(exist_ok=False)
env=os.environ.copy();env.update(PYTHONUTF8="1",APPDATA=str(e/"user/Roaming"),LOCALAPPDATA=str(e/"user/Local"))
base=["D:/ComfyUI/.venv-rocm/Scripts/python.exe","tools/comfyui/gpu_lock.py","--","C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(r)]
baseline=json.loads((ev/"baseline-source.json").read_text(encoding="utf-8"));paths=set(baseline["files"])|set(baseline["core_files"])
for root in ["art/characters/collector_brute","art_src/characters/collector_brute"]:
 paths.update(str(x.relative_to(r)).replace(chr(92),"/") for x in (r/root).rglob("*") if x.is_file() and not x.name.endswith(".import"))
def snap():return {p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(paths)}
paths.update(["tools/rig_joint_audit.gd", "tools/rig_preview.gd", "tools/check_joint_frames.py", "tests/helpers/crouch_feet_checks.gd"])
records=[]
for mode in ["pair","as-worn"]:
 out=e/mode;out.mkdir(exist_ok=True);before=snap();args=["--rendering-driver","vulkan","--rendering-method","forward_plus","res://tools/rig_joint_audit.tscn","--","--chars=collector_brute","--frames=120","--zooms=1,3.4","--out="+str(out)]
 if mode=="pair":args.append("--pair-only")
 cmd=base+args;start=time.time();p=subprocess.run(cmd,cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(e/(mode+".log")).write_bytes(p.stdout);after=snap();record={"mode":mode,"command":cmd,"exit":p.returncode,"wall_seconds":time.time()-start,"source_before":before,"source_after":after,"unchanged":before==after};records.append(record);(e/"runs.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8");print(mode,"native exit",p.returncode,"held",before==after,flush=True)
 assert p.returncode==0 and before==after and not any(x in p.stdout for x in [b"SCRIPT ERROR",b"ERROR:"]),p.stdout.decode("utf-8","replace")
 check=["D:/ComfyUI/.venv-rocm/Scripts/python.exe","tools/check_joint_frames.py",str(out)];q=subprocess.run(check,cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(e/(mode+"-checker.log")).write_bytes(q.stdout);record["checker_command"]=check;record["checker_exit"]=q.returncode;report=json.loads((out/"report.json").read_text(encoding="utf-8"));record["samples"]=report["samples"];record["failed_samples"]=report["failed_samples"];(e/"runs.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8");print(mode,"raw",report["failed_samples"],"/",report["samples"],flush=True)
