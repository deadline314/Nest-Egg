import json,sys,hashlib
from pathlib import Path
import numpy as np
from PIL import Image
from scipy import ndimage
R=Path("D:/NestEggVerification/role-20261117"); E=Path(__file__).parent/"candidates/v6-neck-source-underlap";sys.path.insert(0,str(R/"tools/comfyui"));from cut_layers import part_transform
spec=json.loads((R/"tools/comfyui/specs/collector_brute_side.json").read_text(encoding="utf-8"));char=json.loads((R/"art/characters/collector_brute/character.json").read_text(encoding="utf-8"));names={p["name"]:p["texture"] for p in char["parts"]};k=spec["tex_px_per_wp"]/spec["illustration_px_per_wp"];joints={n:np.asarray(v)*k for n,v in spec["joints"].items()};source=R/"art_src/characters/collector_brute";cache={}
def rgba(p):
 if str(p) not in cache:cache[str(p)]=np.asarray(Image.open(p).convert("RGBA"))
 return cache[str(p)]
def at(a,x,y):return a[y,x].tolist() if 0<=x<a.shape[1] and 0<=y<a.shape[0] else None
def mapping(cell,pixel):
 out=[]
 for part in cell["geometry_sample"]:
  transform=np.asarray(part["to_cell"]);uv=None;triangle=None
  if "vertices" in part:
   vertices=np.asarray(part["vertices"]);uvs=np.asarray(part["uv"]);screen=np.c_[vertices,np.ones(len(vertices))]@transform.T
   for tri in part["triangles"]:
    try:w=np.linalg.solve(np.vstack([screen[tri].T,np.ones(3)]),[* (np.asarray(pixel)+.5),1])
    except np.linalg.LinAlgError:continue
    if w.min()>=-1e-6:uv=w@uvs[tri];triangle=tri;break
  else:uv=np.linalg.solve(transform[:,:2],np.asarray(pixel)+.5-transform[:,2])-part["rect_origin"]
  if uv is None:continue
  name=names[part["part"]];img=Image.open(source/"07_refined"/(name+".png"));A,*_=part_transform(img,spec["parts"][name],joints,k);xy=(A@[*uv,1])/k;sx,sy=np.round(xy).astype(int);rx,ry=np.floor(uv-.5).astype(int);runtime=rgba(R/"art/characters/collector_brute/parts"/(name+".png"));entry={"part":part["part"],"texture":name,"uv":uv.tolist(),"source_xy":xy.tolist(),"source_nearest":[int(sx),int(sy)],"source_rgba":at(rgba(source/"07_refined"/(name+".png")),sx,sy),"base_rgba":at(rgba(source/"base_rgba.png"),sx,sy),"P_rgba":at(rgba(source/"04_stages/P.png"),sx,sy),"triangle":triangle,"runtime_alpha_2x2":runtime[ry:ry+2,rx:rx+2,3].tolist() if rx>=0 and ry>=0 else None};out.append(entry)
 return out
records=[]
for name,joint,frame,zoom,pose in [("neck32-pair","neck",32,3.4,"dead")]:
 trace=E/"traces"/name;groups=json.loads((trace/"frames.json").read_text(encoding="utf-8"));g=next(g for g in groups if g["pose"]==pose);im=rgba(trace/f"{pose}_{zoom:.1f}_{frame:03}.png");original=rgba(E/"native/neck-pair"/f"{pose}_{zoom:.1f}_{frame:03}.png")
 for cell in g["cells"]:
  if cell["joint"]!=joint:continue
  x,y,w,h=cell["rect"];alpha=im[y:y+h,x:x+w,3];prior=original[y:y+h,x:x+w,3];r=cell["radius"];band=alpha[64-r:64+r,64-r:64+r]>=128;holes=ndimage.binary_fill_holes(band)&~band;yy,xx=np.where(holes);points=[]
  for py,px in zip(yy+64-r,xx+64-r):points.append({"cell_xy":[int(px),int(py)],"alpha":int(alpha[py,px]),"original_alpha":int(prior[py,px]),"parts":mapping(cell,[int(px),int(py)])})
  record={"trace":name,"joint":joint,"pose":pose,"frame":frame,"zoom":zoom,"facing":cell["facing"],"alpha_exact_to_original":bool(np.array_equal(alpha,prior)),"mask_exact_to_original":bool(np.array_equal(alpha>=128,prior>=128)),"points":points};records.append(record)
  crop=Image.fromarray(im[y:y+h,x:x+w]);crop.resize((384,384),Image.Resampling.NEAREST).save(E/"traces"/f"{name}-face{cell['facing']}-3x-nearest.png")
(E/"traces/mapping.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8");print(json.dumps(records,indent=2))
