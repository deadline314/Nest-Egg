extends HumanoidAnimator
var _diagnostic_contact := false
func update(delta: float, input: RigInput) -> void:
	_diagnostic_contact = input.on_floor and input.crouching and not input.dead and not _crouch_feet.is_empty()
	super.update(delta, input)
func _step_legs() -> void:
	super._step_legs()
	if not _diagnostic_contact: return
	var shift := _ground_y - _lowest_foot_y()
	_ground_shift += shift
	_rig.bone(&"hip").position.y += shift
	_forward_kinematics()
