extends "res://work/ne218-brute-controls/contact_order_trace.gd"
## Private alternative: compensate the final base/action leg targets before pose blending.
func _apply_action(delta: float, input: RigInput, target: Dictionary) -> void:
	super._apply_action(delta, input, target)
	if _crouch_feet.is_empty() or not bool(_motion["grounding"]) or not input.on_floor or input.crouching or input.dead or input.dashing:
		return
	for chain in LEG_CHAINS:
		if _action_w > 0.0 and _action_pose.has(chain[2]):
			continue
		var angle := 0.0
		var parent := _rig.parent_of(chain[2])
		while parent != &"":
			angle += float(target.get(parent, _angles.get(parent, 0.0)))
			parent = _rig.parent_of(parent)
		target[chain[2]] = -angle
