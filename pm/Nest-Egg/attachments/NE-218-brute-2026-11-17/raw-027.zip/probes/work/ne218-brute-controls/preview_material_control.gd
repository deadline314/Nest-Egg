extends "res://tools/rig_preview.gd"
## Diagnostic material isolation only; original source, pose and preview logic remain unchanged.
func _ready() -> void:
	if "--diagnostic-fixed-60" in OS.get_cmdline_user_args(): seed(21861)
	super._ready()
	if not "--diagnostic-fixed-60" in OS.get_cmdline_user_args(): return
	set_process(false)
	for tick in 60: _process(1.0 / 60.0)
	if "--diagnostic-keys-max" in OS.get_cmdline_user_args():
		for rig in _rigs: rig.set_sway(&"keys", 0.5)
		print("DIAGNOSTIC authored keys sway maximum 0.5; pose frozen")
	var observations: Array = []
	for rig in _rigs:
		var bones := {}
		for name in rig.bone_order():
			var bone := rig.bone(name)
			bones[str(name)] = [bone.position.x, bone.position.y, bone.rotation]
		observations.append({"skin": rig.skin_id, "bones": bones, "mesh_count": rig.limb_meshes().size(), "rig_origin": [rig.global_position.x, rig.global_position.y], "rig_scale": [rig.global_scale.x, rig.global_scale.y]})
	var file := FileAccess.open(_out + ".fixed60.json", FileAccess.WRITE)
	assert(file != null)
	file.store_string(JSON.stringify({"kind": "diagnostic fixed60 animation steps; original preview input/pose logic", "rigs": observations}, "  "))
	print("DIAGNOSTIC fixed60 pose, source unchanged")

func _spawn(skin: String, weapon: String, pos: Vector2, pose: String, zoom: float, armor_ratio := 1.0) -> void:
	if "--diagnostic-death-grid" in OS.get_cmdline_user_args() and pose.begins_with("death:"):
		var index := int(pose.trim_prefix("death:"))
		pos = Vector2(160 + (index % 2) * 320, 140 + (index / 2) * 170)
	super._spawn(skin, weapon, pos, pose, zoom, armor_ratio)
	if not "--diagnostic-no-normals" in OS.get_cmdline_user_args(): return
	var changed := 0
	for node in _rigs.back().find_children("*", "CanvasItem", true, false):
		if not (node is Sprite2D or node is Polygon2D): continue
		if not node.texture is CanvasTexture: continue
		var texture: CanvasTexture = node.texture.duplicate()
		texture.normal_texture = null
		node.texture = texture
		changed += 1
	assert(changed > 0)
	print("DIAGNOSTIC normals removed from ", changed, " textures; pose=", pose)
