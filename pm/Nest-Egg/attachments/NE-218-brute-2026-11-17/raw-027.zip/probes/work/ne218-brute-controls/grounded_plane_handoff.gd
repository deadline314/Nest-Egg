extends Node
const BASE := preload("res://work/ne218-brute-controls/contact_grounded_plane.gd")
const POST := preload("res://work/ne218-brute-controls/contact_post_ik.gd")
const SHARED := preload("res://work/ne218-brute-controls/contact_shared_reference.gd")
const MIX := preload("res://work/ne218-brute-controls/contact_planted_mix.gd")
var _out := ""
var _records: Array[Dictionary] = []
func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	_run.call_deferred()
func _run() -> void:
	for mode in ["current", "grounded_plane"]:
		for facing in [-1, 1]:
			for exit_to in ["idle", "run"]:
				var rig := CharacterRig.new()
				add_child(rig)
				assert(rig.setup("collector_brute"))
				seed(21861)
				if mode == "grounded_plane": rig.animator = BASE.new(rig)
				elif mode == "post_ik": rig.animator = POST.new(rig)
				elif mode == "planted_mix": rig.animator = MIX.new(rig)
				elif mode == "shared_reference": rig.animator = SHARED.new(rig)
				else: rig.animator = HumanoidAnimator.new(rig)
				var input := RigInput.new()
				input.facing = facing
				input.aim_dir = Vector2(facing, 0)
				input.on_floor = true
				input.run_speed = 76.0
				input.velocity.x = 38.0 * facing
				for frame in 180: rig.animate(1.0 / 60.0, input)
				var samples: Array[Dictionary] = []
				for phase in ["enter", "exit"]:
					input.crouching = phase == "enter"
					input.velocity.x = 0.0 if phase == "enter" or exit_to == "idle" else 38.0 * facing
					input.action = &"collector_brute.windup_slash" if phase == "enter" else &""
					for frame in 45:
						input.action_t = minf(1.0, float(frame + 1) / 21.0)
						rig.animate(1.0 / 60.0, input)
						var anim := rig.animator as HumanoidAnimator
						samples.append({"phase": phase, "frame": frame, "gait_weight": anim._gait_w,
							"front_ankle_y": anim.bone_pos(&"foot_front").y, "back_ankle_y": anim.bone_pos(&"foot_back").y,
							"lowest_ankle_error": anim._lowest_foot_y() - anim.ground_level(),
							"hip_y": rig.bone(&"hip").position.y, "ground_shift": anim._ground_shift,
							"foot_front_angle": anim.foot_angle(&"foot_front"), "foot_back_angle": anim.foot_angle(&"foot_back")})
				_records.append({"mode": mode, "facing": facing, "exit_to": exit_to, "samples": samples})
				rig.free()
	var file := FileAccess.open(_out, FileAccess.WRITE)
	file.store_string(JSON.stringify({"scope": "CPU original walk38/run_speed76 to configured crouch and back; only private animator diagnostic subclasses differ", "records": _records}, "  ") + "\n")
	file.close()
	print("CROUCH_HANDOFF_DIAGNOSTIC cases=", _records.size())
	get_tree().quit()
