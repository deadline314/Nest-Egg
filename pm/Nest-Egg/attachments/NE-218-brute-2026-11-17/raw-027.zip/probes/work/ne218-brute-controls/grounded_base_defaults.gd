extends Node
const BASE := preload("res://work/ne218-brute-controls/contact_grounded_base.gd")
const Original := preload("res://work/ne218-brute-controls/original_humanoid_animator.gd")
const POSES := ["idle", "run", "aim_up", "crouch", "jump", "block", "stagger", "dead"]
var _out := ""
var _records: Array[Dictionary] = []
var _failures := 0
func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	_run.call_deferred()
func _run() -> void:
	for skin in ["rin", "collector_brute", "enforcer"]:
		var path := HumanoidAnimator.MOTION_PATH % skin
		var source := RigLibrary.load_json(path)
		for mode in ["omitted", "empty"]:
			var fixture := source.duplicate(true)
			if mode == "empty": fixture["crouch"]["feet"] = []
			else: (fixture["crouch"] as Dictionary).erase("feet")
			RigLibrary._json_cache[path] = fixture
			for facing in [-1, 1]:
				for pose in POSES:
					var a := CharacterRig.new()
					var b := CharacterRig.new()
					add_child(a)
					add_child(b)
					assert(a.setup(skin) and b.setup(skin))
					seed(21861)
					var original_animator = Original.new(a)
					seed(21861)
					b.animator = BASE.new(b)
					var input := RigInput.new()
					input.facing = facing
					input.on_floor = pose != "jump"
					input.crouching = pose == "crouch"
					input.dead = pose == "dead"
					input.blocking = pose == "block"
					input.staggered = pose == "stagger"
					input.velocity = Vector2(75.0 * facing, 0) if pose == "run" else Vector2(0, -80.0) if pose == "jump" else Vector2.ZERO
					input.aim_dir = Vector2(0, -1) if pose == "aim_up" else Vector2(facing, 0)
					var old_values: Array = []
					var new_values: Array = []
					var worst := 0.0
					for frame in 120:
						original_animator.update(1.0 / 60.0, input)
						b.animator.update(1.0 / 60.0, input)
						for bone in a.bone_order():
							var aa := a.bone(bone)
							var bb := b.bone(bone)
							old_values.append([aa.position.x, aa.position.y, aa.rotation])
							new_values.append([bb.position.x, bb.position.y, bb.rotation])
							worst = maxf(worst, aa.position.distance_to(bb.position))
							worst = maxf(worst, absf(aa.rotation - bb.rotation))
					var old_json := JSON.stringify(old_values)
					var new_json := JSON.stringify(new_values)
					var equal := old_json == new_json
					if not equal: _failures += 1
					_records.append({"skin": skin, "mode": mode, "facing": facing, "pose": pose, "frames": 120, "bone_samples": old_values.size(), "exact": equal, "worst_position_or_rotation_delta": worst, "original_signature": old_json.sha256_text(), "candidate_signature": new_json.sha256_text()})
					a.free()
					b.free()
			RigLibrary._json_cache[path] = source
	var file := FileAccess.open(_out, FileAccess.WRITE)
	file.store_string(JSON.stringify({"scope": "Exact original 2236b4.. body implementation adapter only removes its global class_name; same source/input/seed with omitted or [] optional field", "cases": _records, "failures": _failures}, "  ") + "\n")
	file.close()
	print("DEFAULT_FEET_COMPARE cases=%d failures=%d" % [_records.size(), _failures])
	get_tree().quit(0 if _failures == 0 else 1)
