extends "res://work/ne218-brute-controls/contact_order_trace.gd"
## Private control: blend grounded foot orientations in rig coordinates.
func _place_feet(offsets: Array[Vector2], angles: Array[float], weight: float, floor_sag: float, reach_ratio: float, blend_shift := false, extra_sag := 0.0) -> void:
	super._place_feet(offsets, angles, weight, floor_sag, reach_ratio, blend_shift, extra_sag)
	if _crouch_feet.is_empty():
		return
	var changed := false
	for i in LEG_CHAINS.size():
		var foot: StringName = LEG_CHAINS[i][2]
		if _action_pose.has(foot) or not _rig.has_bone(foot):
			continue
		var desired := lerp_angle(0.0, angles[i], weight)
		var current := float(_global_angle[foot])
		if not is_equal_approx(current, desired):
			_rig.bone(foot).rotation += wrapf(desired - current, -PI, PI)
			changed = true
	if changed:
		_forward_kinematics()
	diagnostic["after_grounded_rotation"] = _snapshot()
