extends "res://work/ne218-brute-controls/contact_order_trace.gd"
## Private alternative: the grounded base and gait use the same foot plane.
func _post_pose(delta: float, input: RigInput) -> void:
	super._post_pose(delta, input)
	if _crouch_feet.is_empty() or not bool(_motion["grounding"]) or not input.on_floor or input.crouching or input.dead or input.dashing:
		return
	var changed := false
	for chain in LEG_CHAINS:
		if _action_w > 0.0 and _action_pose.has(chain[2]):
			continue
		var angle := float(_global_angle.get(chain[2], 0.0))
		if not is_zero_approx(angle):
			_rig.bone(chain[2]).rotation -= angle
			changed = true
	if changed: _forward_kinematics()
