extends Node
const BASE := preload("res://work/ne218-brute-controls/contact_grounded_plane.gd")
const BEFORE := preload("res://work/ne218-brute-controls/before_contact_humanoid.gd")
var _out := ""
func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	_run.call_deferred()
func _run() -> void:
	var path := HumanoidAnimator.MOTION_PATH % "collector_brute"
	var source := RigLibrary.load_json(path)
	var fixture := source.duplicate(true)
	fixture["crouch"]["feet"] = [-0.8, -1.3]
	fixture["move"]["duty"] = 0.4
	RigLibrary._json_cache[path] = fixture
	var records: Array[Dictionary] = []
	var failures := 0
	for facing in [-1, 1]:
		var a := CharacterRig.new()
		var b := CharacterRig.new()
		add_child(a)
		add_child(b)
		assert(a.setup("collector_brute") and b.setup("collector_brute"))
		seed(21861)
		var before = BEFORE.new(a)
		seed(21861)
		b.animator = BASE.new(b)
		var input := RigInput.new()
		input.on_floor = true
		input.facing = facing
		input.velocity.x = 76.0 * facing
		input.run_speed = 76.0
		input.aim_dir = Vector2(facing, 0)
		for frame in 180:
			before.update(1.0 / 60.0, input)
			b.animator.update(1.0 / 60.0, input)
		var old_values: Array = []
		var new_values: Array = []
		var old_flight := 0
		var new_flight := 0
		var worst_delta := 0.0
		var samples: Array = []
		for frame in 240:
			before.update(1.0 / 60.0, input)
			b.animator.update(1.0 / 60.0, input)
			var old_clear: float = before.ground_level() - before._lowest_foot_y()
			var new_clear := b.animator.ground_level() - b.animator._lowest_foot_y()
			if old_clear > 0.1: old_flight += 1
			if new_clear > 0.1: new_flight += 1
			samples.append({"frame": frame, "original_clearance": old_clear, "candidate_clearance": new_clear})
			for name in a.bone_order():
				var aa := a.bone(name)
				var bb := b.bone(name)
				old_values.append([aa.position.x, aa.position.y, aa.rotation])
				new_values.append([bb.position.x, bb.position.y, bb.rotation])
				worst_delta = maxf(worst_delta, aa.position.distance_to(bb.position))
				worst_delta = maxf(worst_delta, absf(aa.rotation - bb.rotation))
		var exact := JSON.stringify(old_values) == JSON.stringify(new_values)
		var valid := exact and old_flight > 0 and new_flight == old_flight
		if not valid: failures += 1
		records.append({"facing": facing, "frames": 240, "duty": 0.4, "original_flight_frames": old_flight, "candidate_flight_frames": new_flight, "exact_bone_signature": exact, "worst_delta": worst_delta, "samples": samples})
		a.free()
		b.free()
	RigLibrary._json_cache[path] = source
	var file := FileAccess.open(_out, FileAccess.WRITE)
	file.store_string(JSON.stringify({"scope": "Configured field, authored duty0.4 positive flight control; original949 adapter vs shared contact reference; complete full-weight gait remains unchanged", "records": records, "failures": failures}, "  ") + "\n")
	file.close()
	print("GAIT_FLIGHT_CONTROL cases=2 failures=", failures)
	get_tree().quit(0 if failures == 0 else 1)
