# Collector brute crouch foot material

The original first-chapter Slasher windup uses the original crouch leg angles. Ankle-origin grounding leaves the boot materials tilted into the authored platform. Read-only native PNG-corner/actual Sprite transform/world terrain measurements found 1.84552 world pixels at the front boot and 3.72638 at the back boot, with unchanged source assets and AI.

The optional per-character `crouch.feet` field contains the front/back local foot angles. An empty array or omitted field preserves the existing pose behavior. Configured values are two finite numeric radians within [-PI, PI]. Load-time validation reports the character/path/field once and falls back to the legacy empty array. The animator owns a copy of the validated array; no per-frame validation or warnings are introduced.

Configured foot targets participate in the existing body pose blend, return to zero outside crouch, and reset before a stale-input death pose. Existing explicit action and keyed death tracks, and later NPC/gait/kneeling IK retain their established priority. Collision geometry, enemy states, movement, authored clip timing, terrain queries, renderer and acceptance thresholds remain unchanged.

Small proof is in `foot-diagnostic/REVIEW.json`: true original functional red 28/4; same test green 28/0; extended action/death/interrupt green 38/0; valid/corrupt load controls 305/0 with one expected isolated error; 96 original-vs-candidate omitted/empty behavior cases exactly match. Large native matrices, material contact and quiet performance remain to be completed after local review.
