extends HumanoidAnimator
var _diagnostic_contact := false
func update(delta: float, input: RigInput) -> void:
	_diagnostic_contact = input.on_floor and input.crouching and not input.dead and not _crouch_feet.is_empty()
	super.update(delta, input)
func _place_feet(offsets: Array[Vector2], angles: Array[float], weight: float, floor_sag: float, reach_ratio: float, blend_shift := false, extra_sag := 0.0) -> void:
	if _diagnostic_contact:
		_ground_shift = clampf(_ground_y - _lowest_foot_y(), -GROUND_MAX_SHIFT, GROUND_MAX_SHIFT)
		blend_shift = true
	super._place_feet(offsets, angles, weight, floor_sag, reach_ratio, blend_shift, extra_sag)
