extends HumanoidAnimator
## Private observational adapter only; every original stage delegates unchanged.
var diagnostic: Dictionary = {}
func _snapshot() -> Dictionary:
 var bones: Dictionary = {}
 for name in [&"hip", &"leg_front_upper", &"leg_front_lower", &"foot_front", &"leg_back_upper", &"leg_back_lower", &"foot_back"]:
  var bone := _rig.bone(name)
  var pos := bone_pos(name)
  bones[str(name)] = {"position": [pos.x, pos.y], "local_angle": bone.rotation, "world_angle": float(_global_angle.get(name, 0.0))}
 return {"ground_shift": _ground_shift, "ground_y": _ground_y, "gait_weight": _gait_w, "idle_pin_weight": _idle_pin_w, "planted": minf(1.0, _gait_w + _idle_pin_w), "bones": bones}
func update(delta: float, input: RigInput) -> void:
 diagnostic = {"delta": delta, "velocity": [input.velocity.x, input.velocity.y], "on_floor": input.on_floor, "crouching": input.crouching, "dead": input.dead, "action": str(input.action), "action_t": input.action_t}
 super.update(delta, input)
 diagnostic["final"] = _snapshot()
func _apply_action(delta: float, input: RigInput, target: Dictionary) -> void:
 diagnostic["target_before_action"] = {"front": target.get(&"foot_front"), "back": target.get(&"foot_back")}
 super._apply_action(delta, input, target)
 diagnostic["target_after_action"] = {"front": target.get(&"foot_front"), "back": target.get(&"foot_back")}
 diagnostic["action_foot_keys"] = {"front": _action_pose.get(&"foot_front"), "back": _action_pose.get(&"foot_back")}
func _step_legs() -> void:
 diagnostic["before_step"] = _snapshot()
 super._step_legs()
 diagnostic["after_step_and_c9"] = _snapshot()
func _place_feet(offsets: Array[Vector2], angles: Array[float], weight: float, floor_sag: float, reach_ratio: float, blend_shift := false, extra_sag := 0.0) -> void:
 diagnostic["place_request"] = {"weight": weight, "offsets": [[offsets[0].x, offsets[0].y], [offsets[1].x, offsets[1].y]], "angles": angles, "floor_sag": floor_sag, "extra_sag": extra_sag}
 diagnostic["before_place"] = _snapshot()
 super._place_feet(offsets, angles, weight, floor_sag, reach_ratio, blend_shift, extra_sag)
 diagnostic["after_place_before_c9"] = _snapshot()
func _plant_feet(delta: float) -> void:
 diagnostic["before_plant"] = _snapshot()
 super._plant_feet(delta)
 diagnostic["after_plant"] = _snapshot()
