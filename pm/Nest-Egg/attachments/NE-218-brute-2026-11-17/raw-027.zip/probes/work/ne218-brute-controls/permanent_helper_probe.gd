extends Node
var _checks := 0
var _failures := 0
class LocalSuite extends TestSuite:
	func run() -> void:
		preload("res://tests/helpers/crouch_feet_checks.gd").run(self)
func _ready() -> void:
	_run.call_deferred()
func _check(ok: bool, message: String) -> void:
	_checks += 1
	if not ok:
		_failures += 1
		printerr("FAIL ", message)
func _run() -> void:
	LocalSuite.new(self).run()
	print("PERMANENT_CROUCH_FEET checks=%d failures=%d" % [_checks, _failures])
	get_tree().quit(0 if _failures == 0 else 1)
