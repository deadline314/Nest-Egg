extends Node
## CPU behavior check. Configures the optional field in memory; no source files change.
var _out := ""
var _checks := 0
var _failures: Array[String] = []
var _observations: Array[Dictionary] = []
var _motion: Dictionary
const SKIN := "collector_brute"
const MOTION := "res://art/motion/collector_brute.json"
const FEET := [&"foot_front", &"foot_back"]

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	_run.call_deferred()

func _check(ok: bool, message: String) -> void:
	_checks += 1
	if not ok:
		_failures.append(message)
		printerr("CROUCH_FEET_FAIL ", message)

func _rig(configured: bool) -> CharacterRig:
	seed(21861)
	var data := _motion.duplicate(true)
	if configured: data["crouch"]["feet"] = [-0.8, -1.3]
	else: (data["crouch"] as Dictionary).erase("feet")
	RigLibrary._json_cache[MOTION] = data
	var rig := CharacterRig.new()
	add_child(rig)
	_check(rig.setup(SKIN), "original rig builds")
	RigLibrary._json_cache[MOTION] = _motion
	return rig

func _step(rig: CharacterRig, input: RigInput, count: int) -> void:
	for frame in count: rig.animate(1.0 / 60.0, input)

func _locals(rig: CharacterRig) -> Array:
	return [float((rig.animator as HumanoidAnimator)._angles[FEET[0]]), float((rig.animator as HumanoidAnimator)._angles[FEET[1]])]

func _run() -> void:
	_motion = RigLibrary.load_json(MOTION)
	for facing in [-1, 1]:
		var rig := _rig(true)
		var input := RigInput.new()
		input.facing = facing
		input.on_floor = true
		input.aim_dir = Vector2(facing, 0)
		_step(rig, input, 180)
		input.crouching = true
		input.action = &"collector_brute.windup_slash"
		input.action_t = 1.0
		_step(rig, input, 90)
		var angles := [(rig.animator as HumanoidAnimator).foot_angle(FEET[0]), (rig.animator as HumanoidAnimator).foot_angle(FEET[1])]
		_observations.append({"case": "configured crouch", "facing": facing, "global_foot_angles": angles, "local_foot_angles": _locals(rig)})
		_check(absf(angles[0]) < 0.001 and absf(angles[1]) < 0.001, "configured crouch keeps boots horizontal: " + str(angles))
		input.facing = -facing
		input.aim_dir = Vector2(-facing, 0)
		_step(rig, input, 90)
		_check(absf((rig.animator as HumanoidAnimator).foot_angle(FEET[0])) < 0.001 and absf((rig.animator as HumanoidAnimator).foot_angle(FEET[1])) < 0.001, "turning preserves configured foot pose")
		input.crouching = false
		input.action = &""
		_step(rig, input, 90)
		var returned := _locals(rig)
		_check(absf(returned[0]) < 0.001 and absf(returned[1]) < 0.001, "return clears crouch-local foot angles")
		rig.free()
		for mode in ["hurt", "death", "air", "dash"]:
			rig = _rig(true)
			input = RigInput.new()
			input.facing = facing
			input.on_floor = true
			input.crouching = true
			input.action = &"collector_brute.windup_slash"
			input.action_t = 1.0
			_step(rig, input, 90)
			if mode == "death": input.dead = true # Deliberately stale crouch + action, as a real interrupted FSM can leave.
			else:
				input.crouching = false
				input.action = &""
				input.hurt = mode == "hurt"
				input.staggered = mode == "hurt"
				input.on_floor = mode != "air"
				input.dashing = mode == "dash"
				input.velocity.y = -80.0 if mode == "air" else 0.0
			_step(rig, input, 90)
			var feet := _locals(rig)
			_observations.append({"case": mode, "facing": facing, "local_foot_angles": feet})
			_check(absf(feet[0]) < 0.001 and absf(feet[1]) < 0.001, mode + " interrupt clears configured foot angles")
			rig.free()
		var legacy := _rig(false)
		input = RigInput.new()
		input.crouching = true
		input.on_floor = true
		input.facing = facing
		_step(legacy, input, 90)
		var target := (legacy.animator as HumanoidAnimator)._body_pose(0, input, Vector2.ZERO, 0)
		_check(not target.has(FEET[0]) and not target.has(FEET[1]), "unconfigured motion has no new foot target")
		_observations.append({"case": "legacy", "facing": facing, "global_foot_angles": [(legacy.animator as HumanoidAnimator).foot_angle(FEET[0]), (legacy.animator as HumanoidAnimator).foot_angle(FEET[1])]})
		legacy.free()
	_action_override_checks()
	RigLibrary._json_cache[MOTION] = _motion
	var file := FileAccess.open(_out, FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks": _checks, "failures": _failures, "observations": _observations}, "  ") + "\n")
	file.close()
	print("CROUCH_FEET checks=%d failures=%d" % [_checks, _failures.size()])
	get_tree().quit(0 if _failures.is_empty() else 1)


func _action_override_checks() -> void:
	var path := HumanoidAnimator.ACTIONS_PATH
	var original := RigLibrary.load_json(path)
	var fixture := original.duplicate(true)
	fixture["actions"]["collector_brute.foot_control"] = {"duration": 0.2, "blend": 14, "keys": [{"t": 0.0, "bones": {"foot_front": 0.4, "foot_back": -0.2}}, {"t": 1.0, "bones": {"foot_front": 0.4, "foot_back": -0.2}}]}
	RigLibrary._json_cache[path] = fixture
	for facing in [-1, 1]:
		var rig := _rig(true)
		var input := RigInput.new()
		input.facing = facing
		input.on_floor = true
		input.crouching = true
		input.action = &"collector_brute.foot_control"
		input.action_t = 1.0
		_step(rig, input, 90)
		var feet := _locals(rig)
		_check(absf(feet[0] - 0.4) < 0.001 and absf(feet[1] + 0.2) < 0.001, "explicit action foot keys retain priority")
		input.crouching = false
		input.action = &""
		_step(rig, input, 90)
		feet = _locals(rig)
		_check(absf(feet[0]) < 0.001 and absf(feet[1]) < 0.001, "released action foot keys return to configured base")
		input.crouching = true
		input.action = &"collector_brute.foot_control"
		_step(rig, input, 90)
		input.dead = true
		_step(rig, input, 90)
		feet = _locals(rig)
		_check(absf(feet[0]) < 0.001 and absf(feet[1]) < 0.001, "death clears actual stale action foot keys")
		rig.free()
	# Existing keyed death poses remain authoritative after the optional base targets.
	var approved_motion := _motion
	_motion = _motion.duplicate(true)
	_motion["death"]["keys"] = {"supine": {"duration": 0.4, "rest_height": 3.0, "frames": [{"t": 0.0, "bones": {"foot_front": 0.3, "foot_back": -0.4}}, {"t": 1.0, "bones": {"foot_front": 0.3, "foot_back": -0.4}}]}}
	var keyed_rig := _rig(true)
	_motion = approved_motion
	var dead := RigInput.new()
	dead.dead = true
	dead.crouching = true
	_step(keyed_rig, dead, 90)
	var keyed := _locals(keyed_rig)
	_check(absf(keyed[0] - 0.3) < 0.001 and absf(keyed[1] + 0.4) < 0.001, "explicit keyed death foot tracks retain priority")
	keyed_rig.free()
	RigLibrary._json_cache[path] = original
