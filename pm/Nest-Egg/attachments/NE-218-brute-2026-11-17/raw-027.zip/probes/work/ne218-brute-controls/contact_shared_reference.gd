extends HumanoidAnimator
var _diagnostic_gait := false
func _step_legs() -> void:
	_diagnostic_gait = true
	super._step_legs()
	_diagnostic_gait = false
func _place_feet(offsets: Array[Vector2], angles: Array[float], weight: float, floor_sag: float, reach_ratio: float, blend_shift := false, extra_sag := 0.0) -> void:
	super._place_feet(offsets, angles, weight, floor_sag, reach_ratio, blend_shift, extra_sag)
	if not _diagnostic_gait or _crouch_feet.is_empty(): return
	# A planted base has zero clearance; preserve the gait's authored airborne lift.
	var reference := _ground_y - minf(offsets[0].y, offsets[1].y) * weight
	var shift := clampf(_ground_shift + reference - _lowest_foot_y(), -GROUND_MAX_SHIFT, GROUND_MAX_SHIFT)
	var change := shift - _ground_shift
	if is_zero_approx(change): return
	_ground_shift = shift
	_rig.bone(&"hip").position.y += change
	_forward_kinematics()
