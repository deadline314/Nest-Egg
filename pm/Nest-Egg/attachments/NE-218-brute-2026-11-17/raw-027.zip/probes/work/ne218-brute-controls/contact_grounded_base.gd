extends "res://work/ne218-brute-controls/contact_order_trace.gd"
## Private alternative: a grounded base pose precedes the existing action blend.
func _body_pose(delta: float, input: RigInput, velocity: Vector2, aim_angle: float) -> Dictionary:
	var pose := super._body_pose(delta, input, velocity, aim_angle)
	if _crouch_feet.is_empty() or not bool(_motion["grounding"]) or not input.on_floor or input.crouching or input.dead or input.dashing:
		return pose
	for chain in LEG_CHAINS:
		var angle := 0.0
		var parent := _rig.parent_of(chain[2])
		while parent != &"":
			angle += float(pose.get(parent, _angles.get(parent, 0.0)))
			parent = _rig.parent_of(parent)
		pose[chain[2]] = -angle
	return pose
