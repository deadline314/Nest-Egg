extends Node
## Isolated corrupt-data control: exactly one expected error is part of this probe.
var _out := ""
var _checks := 0
var _failures: Array[String] = []
func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	_run.call_deferred()
func _check(ok: bool, message: String) -> void:
	_checks += 1
	if not ok:
		_failures.append(message)
		printerr("CROUCH_FEET_VALIDATION_FAIL ", message)
func _run() -> void:
	var path := HumanoidAnimator.MOTION_PATH % "collector_brute"
	var original := RigLibrary.load_json(path)
	var original_json := JSON.stringify(original)
	var valid: Array = [[], [0, 0], [-0.8, -1.3], [-PI, PI], [PI, -PI]]
	var invalid: Array = [null, {}, 0, "0", true, [0], [0, 0, 0], [false, 0], ["0.5", 0], [NAN, 0], [INF, 0], [0, -INF], [PI + 0.01, 0], [0, -PI - 0.01]]
	for value: Variant in valid:
		_check(HumanoidAnimator.crouch_feet_problem(value).is_empty(), "valid empty/two-angle value")
		var fixture := original.duplicate(true)
		fixture["crouch"]["feet"] = value
		RigLibrary._json_cache[path] = fixture
		var loaded := HumanoidAnimator._load_motion("collector_brute")
		_check(loaded["crouch"]["feet"] == value, "load retains valid angle values")
	for value: Variant in invalid:
		_check(not HumanoidAnimator.crouch_feet_problem(value).is_empty(), "invalid value has a specific problem")
		var fixture := original.duplicate(true)
		fixture["crouch"]["feet"] = value
		RigLibrary._json_cache[path] = fixture
		for repetition in 2:
			var loaded := HumanoidAnimator._load_motion("collector_brute")
			_check((loaded["crouch"]["feet"] as Array).is_empty(), "invalid load falls back to legacy []")
		_check(RigLibrary._reported.has("motion.crouch.feet:collector_brute"), "invalid field is reported once for this character")
		var rig := CharacterRig.new()
		add_child(rig)
		_check(rig.setup("collector_brute"), "corrupt optional field preserves a usable rig")
		var input := RigInput.new()
		input.on_floor = true
		input.crouching = true
		for frame in 30: rig.animate(1.0 / 60.0, input)
		for bone in rig.bone_order():
			_check(rig.bone(bone).position.is_finite() and is_finite(rig.bone(bone).rotation), "corrupt optional field produces finite animation")
		rig.free()
	RigLibrary._json_cache[path] = original
	_check(JSON.stringify(original) == original_json, "cached approved motion is unmodified")
	var file := FileAccess.open(_out, FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks": _checks, "failures": _failures, "valid_cases": valid.size(), "invalid_cases": invalid.size(), "expected_error_key": "motion.crouch.feet:collector_brute", "expected_error_messages": 1, "raw_source_files_unchanged": true}, "  ") + "\n")
	file.close()
	print("CROUCH_FEET_VALIDATION checks=%d failures=%d expected_error_messages=1" % [_checks, _failures.size()])
	get_tree().quit(0 if _failures.is_empty() else 1)
