extends ScenarioBase
## NE-71 情境：同屏很多骨架角色時的效能。放 N 個凜、再放 N 個小兵外觀（舊 Q 版骨架），各量測 3 秒的
## 每影格處理時間（毫秒）、繪製呼叫數與貼圖記憶體，印在輸出裡。
## 用法：screenshot.tscn -- --out=<資料夾> --scenario=rin_perf [--count=12]

var _count := 10
var _out := ""
var _records: Array[Dictionary] = []

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
		if arg.begins_with("--quality="):
			Settings.set_light_quality({"low": 0, "high": 2}[arg.trim_prefix("--quality=")])
	assert(_out.is_absolute_path() and DisplayServer.get_name() != "headless")
	assert(DirAccess.make_dir_recursive_absolute(_out) == OK)
	out_dir = _out
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	Engine.max_fps = 0
	Story.auto_skip = true
	add_child(LightKit.create_environment())
	_native.call_deferred()

func _native() -> void:
	await run()
	assert(_records.size() == 4)
	var writer := FileAccess.open(_out.path_join("frames.json"), FileAccess.WRITE)
	assert(writer != null)
	writer.store_string(JSON.stringify({"scope": "Existing rin_perf scenario, four collector_brute cases at unchanged alternating idle/run inputs; frame wall samples added and uncapped native rendering; ten visual rigs all within the camera in a neutral lit arena with the normal LightKit WorldEnvironment, not ten combat AI", "adapter": RenderingServer.get_video_adapter_name(), "renderer": RenderingServer.get_current_rendering_method(), "hdr_2d": get_viewport().use_hdr_2d, "count": _count, "records": _records}, "  ") + "\n")
	writer.close()
	get_tree().quit(1 if failures > 0 else 0)



func run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--count="):
			_count = int(arg.trim_prefix("--count="))
	await open_arena("", 6.0)
	var camera := get_viewport().get_camera_2d()
	camera.set_physics_process(false)
	camera.zoom = Vector2.ONE
	camera.snap_to_target()
	for skin: String in ["collector_brute", "collector_brute", "collector_brute", "collector_brute"]:
		var holder := Node2D.new()
		level._entities.add_child(holder)
		var puppets: Array[CharacterRig] = []
		var inputs: Array[RigInput] = []
		for i in _count:
			var rig := CharacterRig.new()
			holder.add_child(rig)
			rig.position = Vector2((10.0 + i * 2.2) * 16.0, FLOOR_Y)
			rig.setup(skin)
			rig.set_weapon("rifle")
			var input := RigInput.new()
			input.velocity = Vector2(150, 0) if i % 2 == 0 else Vector2.ZERO
			puppets.append(rig)
			inputs.append(input)
		await wait(1.0)
		var within_view := 0
		var to_screen := get_viewport().get_canvas_transform()
		for rig in puppets:
			if get_viewport().get_visible_rect().encloses(to_screen * rig.visual_bounds()): within_view += 1
		print("VISIBLE_RIGS ", within_view, "/", _count, " viewport=", get_viewport().get_visible_rect(), " camera_zoom=", camera.zoom)
		assert(within_view == _count)
		var wall_samples: Array[float] = []
		var process_samples: Array[float] = []
		var last := Time.get_ticks_usec()
		var frames := 0
		var process_ms := 0.0
		var draw_calls := 0
		var elapsed := 0.0
		while elapsed < 3.0:
			var dt := get_process_delta_time()
			for i in puppets.size():
				puppets[i].animate(dt, inputs[i])
			await get_tree().process_frame
			var now := Time.get_ticks_usec()
			wall_samples.append(float(now - last) / 1000.0)
			last = now
			process_samples.append(Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0)
			elapsed += get_process_delta_time()
			process_ms += Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0
			draw_calls += int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME))
			frames += 1
		print("PERF %s x%d: process %.2f ms/frame, draw calls %d/frame, frames %d, video memory %.1f MB" % [
			skin, _count, process_ms / frames, draw_calls / frames, frames, Performance.get_monitor(Performance.RENDER_TEXTURE_MEM_USED) / 1048576.0])
		var vertices := 0
		for mesh in puppets[0].limb_meshes(): vertices += mesh.vertex_count()
		_records.append({"case": _records.size(), "skin": skin, "frames": frames, "wall_ms": wall_samples, "process_ms": process_samples, "mean_draw_calls": float(draw_calls) / frames, "renderer_texture_bytes": Performance.get_monitor(Performance.RENDER_TEXTURE_MEM_USED), "all_rigs_within_view": within_view, "world_environment_active": get_viewport().find_world_3d().environment != null, "mesh_vertices_each": vertices, "mesh_parts_each": puppets[0].limb_meshes().size()})
		await RenderingServer.frame_post_draw
		capture("case-%d" % _records.size())
		holder.queue_free()
		await settle(10)
	await finish()
