extends Node
func _ready() -> void:
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): out = arg.trim_prefix("--out=")
	assert(out.is_absolute_path())
	assert(DirAccess.make_dir_recursive_absolute(out) == OK)
	var rows: Array[Dictionary] = []
	for name in DirAccess.get_files_at("res://art/characters/collector_brute/parts"):
		if not name.ends_with(".png"): continue
		var path := "res://art/characters/collector_brute/parts/" + name
		var texture := load(path) as Texture2D
		assert(texture != null)
		var image := texture.get_image()
		assert(image != null)
		var mipmaps := image.has_mipmaps()
		if image.is_compressed(): assert(image.decompress() == OK)
		image.clear_mipmaps()
		image.convert(Image.FORMAT_RGBA8)
		var output := out.path_join(name + ".rgba")
		var file := FileAccess.open(output, FileAccess.WRITE)
		assert(file != null)
		file.store_buffer(image.get_data())
		file.close()
		rows.append({"source": path, "source_sha256": FileAccess.get_sha256(path), "file": name + ".rgba", "width": image.get_width(), "height": image.get_height(), "mipmaps": mipmaps, "raw_sha256": FileAccess.get_sha256(output)})
	assert(not rows.is_empty())
	var writer := FileAccess.open(out.path_join("textures.json"), FileAccess.WRITE)
	assert(writer != null)
	writer.store_string(JSON.stringify({"adapter": RenderingServer.get_video_adapter_name(), "records": rows}, "  ") + "\n")
	writer.close()
	print("IMPORTED_CHARACTER_TEXTURES ", rows.size())
	get_tree().quit()
