from pathlib import Path
import hashlib
import json

base = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/candidates/v11-ground-plane')
source = base / 'native/actions.json'
data = json.loads(source.read_text(encoding='utf8'))
out = base / 'alpha'
out.mkdir(exist_ok=False)
rows, joins = [], []
digest = hashlib.sha256(source.read_bytes()).hexdigest()
for case in data['cases']:
    windup = [c for c in case['captures'] if c['state'] == 'windup']
    assert windup and all(c['canvas_transform_values'] == windup[0]['canvas_transform_values'] and c['density'] == windup[0]['density'] for c in windup)
    selected = [(r, windup[0], 'fixed windup camera, all native windup captures identical') for r in case['timeline'] if r['state'] == 'windup']
    for capture in case['captures']:
        if capture['state'] == 'windup':
            continue
        hits = [r for r in case['timeline'] if r['physics_frame'] == capture['physics_frame'] + 1 and r['state'] == capture['state'] and abs(r['state_time'] - capture['state_time']) < 1e-8 and r['facing'] == capture['facing'] and r['enemy_feet'] == capture['enemy_feet'] and r['action'] == capture['action'] and abs(r['action_t'] - capture['action_t']) < 1e-8]
        assert len(hits) <= 1
        joins.append({'capture': capture['file'], 'matches': len(hits), 'reason': 'next physics signal, exact action/time/actor/facing; final capture may lack a subsequent timeline row'})
        if hits:
            selected.append((hits[0], capture, 'exact native capture and next physics-signal pose'))
    for row, capture, proof in selected:
        for foot in row['foot_materials']:
            rows.append({'id': f"c11-face{case['requested_first_facing']}-frame{row['physics_frame']}-{row['state']}-{foot['part']}", 'epoch': 'production_c11', 'phase': row['state'], 'facing': row['facing'], 'on_floor': row['on_floor'], 'state_time': row['state_time'], 'geometry_physics_frame': row['physics_frame'], 'capture_file': capture['file'], 'camera_proof': proof, 'source_actions': str(source), 'source_actions_sha256': digest, 'canvas': capture['canvas_transform_values'], 'density': capture['density'], 'size': capture['size'], 'foot': foot})
assert len(rows) == 240
(out / 'cases.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf8')
(out / 'joins.json').write_text(json.dumps(joins, indent=2) + '\n', encoding='utf8')
print('Prepared production C11 alpha cases', len(rows))
