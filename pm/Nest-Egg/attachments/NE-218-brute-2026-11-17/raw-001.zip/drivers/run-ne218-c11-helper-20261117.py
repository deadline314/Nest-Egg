from pathlib import Path
import hashlib
import json
import os
import subprocess

r = Path('D:/NestEggVerification/role-20261117')
e = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/candidates/v11-ground-plane/helper')
e.mkdir(exist_ok=False)
core = r / 'game/rig/humanoid_animator.gd'
candidate = core.read_bytes()
before = (e.parent / 'source-before/game/rig/humanoid_animator.gd').read_bytes()
helper = r / 'tests/helpers/crouch_feet_checks.gd'
held = hashlib.sha256(helper.read_bytes()).hexdigest()
(e / 'c11.gd').write_bytes(candidate)
(e / 'c9.gd').write_bytes(before)
(e / 'helper.gd').write_bytes(helper.read_bytes())
env = os.environ.copy()
for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
    env[key] = str(e / 'private-profile' / key)
records = []
try:
    for name, data in [('c9-control', before), ('c11', candidate)]:
        core.write_bytes(data)
        command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', str(r), 'res://work/ne218-brute-controls/permanent_helper_probe.tscn']
        with (e / (name + '.log')).open('wb') as log:
            process = subprocess.run(command, cwd=r, env=env, stdout=log, stderr=subprocess.STDOUT)
        raw = (e / (name + '.log')).read_bytes()
        records.append({'name': name, 'command': command, 'exit': process.returncode, 'core_held': core.read_bytes() == data, 'script_errors': raw.count(b'SCRIPT ERROR:')})
        print(name, process.returncode, flush=True)
finally:
    core.write_bytes(candidate)
receipt = {'cases': records, 'candidate_restored': core.read_bytes() == candidate, 'helper_held': hashlib.sha256(helper.read_bytes()).hexdigest() == held}
(e / 'results.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
assert receipt['candidate_restored'] and receipt['helper_held'] and len(records) == 2 and records[0]['exit'] == 1 and records[1]['exit'] == 0 and all(c['core_held'] and c['script_errors'] == 0 for c in records)
