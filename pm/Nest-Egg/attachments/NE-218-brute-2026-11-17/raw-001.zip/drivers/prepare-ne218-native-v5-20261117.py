from pathlib import Path
import json
import shutil
import subprocess
import time

base = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/candidates/v11-ground-plane')
while not (base / 'performance-native-v4/source-held.json').is_file():
    time.sleep(2)
assert json.loads((base / 'performance-native-v4/source-held.json').read_text())['source_held']
for name, root in [('baseline', Path('D:/NestEggVerification/ne218-baseline-20261117')), ('c11', Path('D:/NestEggVerification/role-20261117'))]:
    path = root / 'work/ne218-performance/scenario.gd'
    saved = base / 'performance-native-v4/source' / name / 'scenario.gd'
    saved.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, saved)
    text = path.read_text()
    assert 'open_arena("res://data/lighting/transfer.tres", 6.0)' in text
    text = text.replace('open_arena("res://data/lighting/transfer.tres", 6.0)', 'open_arena("", 6.0)')
    text = text.replace('with the normal LightKit environment', 'in a neutral lit arena with the normal LightKit WorldEnvironment')
    path.write_text(text, encoding='utf8', newline='\n')
(base / 'performance-native-v4/review-invalid.json').write_text(json.dumps({'accepted': False, 'reason': 'Story auto_skip did not restore visible characters. Transfer post-processing crushes dark arena pixels; V5 uses the existing neutral lighting fallback identically for both versions. Raw V4 diagnostic data retained.'}, indent=2) + '\n')
driver = Path('work/run-ne218-c11-native-performance-v4-20261117.py')
next_driver = Path('work/run-ne218-c11-native-performance-v5-20261117.py')
next_driver.write_text(driver.read_text().replace('performance-native-v4', 'performance-native-v5'), encoding='utf8')
subprocess.run(['D:/ComfyUI/.venv-rocm/Scripts/python.exe', '-X', 'utf8', str(next_driver)], check=True)
