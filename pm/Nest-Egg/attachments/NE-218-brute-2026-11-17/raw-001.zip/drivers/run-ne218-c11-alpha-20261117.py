from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('D:/NestEggVerification/role-20261117')
OUT = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/candidates/v11-ground-plane/alpha')
assert (OUT / "cases.json").is_file()
paths = [p for p in subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'core', 'game', 'data', 'ui', 'art', 'tools', 'project.godot'], cwd=ROOT).decode('utf8').split('\0') if p and (ROOT / p).is_file()]
paths += [p.relative_to(ROOT).as_posix() for p in (ROOT / 'work/ne218-brute-controls').glob('*.gd')]
paths += [p.relative_to(ROOT).as_posix() for p in (ROOT / 'work/ne218-brute-controls').glob('*.tscn')]
paths = sorted(set(paths))
case_before = hashlib.sha256((OUT / "cases.json").read_bytes()).hexdigest()
def snapshot():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
(OUT / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
env = os.environ.copy()
for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
    env[key] = str(OUT / 'private-profile' / key)
command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(ROOT), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--resolution', '1280x720', 'res://work/ne218-brute-controls/frozen_foot_alpha.tscn', '--', '--out=' + str(OUT)]
(OUT / 'request.json').write_text(json.dumps({'command': command, 'scope': 'Read-only frozen live-AI transform replay using actual imported alpha/shader/filter; not another live AI or performance run. Production C11 source and 240 exact join cases guarded.'}, indent=2) + '\n', encoding='utf8')
start = time.monotonic()
with (OUT / 'raw.log').open('wb') as log:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
after = snapshot()
assert case_before == hashlib.sha256((OUT / "cases.json").read_bytes()).hexdigest()
(OUT / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
raw = (OUT / 'raw.log').read_bytes()
receipt = {'exit': result.returncode, 'elapsed_s': time.monotonic() - start, 'source_held': before == after, 'source_count': len(before), 'script_errors': raw.count(b'SCRIPT ERROR:')}
(OUT / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt), flush=True)
assert result.returncode == 0 and before == after and receipt['script_errors'] == 0
