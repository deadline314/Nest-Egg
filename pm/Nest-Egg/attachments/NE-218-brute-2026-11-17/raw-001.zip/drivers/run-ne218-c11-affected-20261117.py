from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('D:/NestEggVerification/role-20261117')
OUT = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/candidates/v11-ground-plane/affected-main')
OUT.mkdir(exist_ok=False)
dependency = Path('D:/NestEggVerification/evidence-20261117/bg17/affected-fc32/result.json')
print('Waiting for original BG17 affected run EOF before another game suite process', flush=True)
while not dependency.is_file():
    time.sleep(5)
completed = json.loads(dependency.read_text(encoding='utf8'))
assert completed['exit'] == 0 and completed['source_unchanged'], completed
BASE = 'd7417bc8e28fae2637ef5db5456957bad8689bd7'
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode('utf8').split('\0')
paths = [p for p in tracked if p and not p.startswith(('pm/', 'design/', '.github/')) and (ROOT / p).is_file()]
untracked = [p for p in subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0') if p]
paths = sorted(set(paths + untracked))
candidate = subprocess.check_output(['git', 'diff', '--name-only', '-z'], cwd=ROOT).decode().rstrip('\0').split('\0')
def snapshot():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
(OUT / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
env = os.environ.copy()
env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', SHARDS='1', LOG_DIR=str(OUT / 'shards'), PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
for name, args in [('actual', ['--base', BASE]), ('candidate-only', ['--files', *candidate])]:
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', '-X', 'utf8', 'tools/select_tests.py', *args]
    with (OUT / ('selection-' + name + '.log')).open('wb') as log:
        subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
actual = (OUT / 'selection-actual.log').read_text(encoding='utf8').strip()
require_same = actual == (OUT / 'selection-candidate-only.log').read_text(encoding='utf8').strip()
assert require_same
command = ['C:/Program Files/Git/bin/bash.exe', '-c', 'python3() { python "$@"; }; export -f python3; tools/run_tests_changed.sh ' + BASE]
request = {'base': BASE, 'command': command, 'SHARDS': 1, 'candidate_paths': candidate, 'extra_untracked': untracked, 'selection_equal_without_untracked_uid': require_same, 'group_count': len(actual.split(',')), 'scope': 'Original changed entry, complete actual selection. Single process reduces memory pressure; no suite omitted. Candidate selection agrees with actual untracked fixtures; unrelated private work does not expand selected groups. No product source edits during execution.'}
(OUT / 'request.json').write_text(json.dumps(request, indent=2) + '\n', encoding='utf8')
start = time.monotonic()
with (OUT / 'runner.log').open('wb') as log:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
after = snapshot()
(OUT / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
(OUT / 'result.json').write_text(json.dumps({'exit': result.returncode, 'elapsed_s': time.monotonic() - start, 'source_unchanged': before == after, 'source_count': len(before)}, indent=2) + '\n', encoding='utf8')
print('NE218_C11_AFFECTED', result.returncode, 'sourceheld', before == after, len(before), flush=True)
assert before == after and result.returncode == 0
