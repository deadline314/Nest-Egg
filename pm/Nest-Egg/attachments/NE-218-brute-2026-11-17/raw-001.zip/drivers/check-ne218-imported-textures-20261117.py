from pathlib import Path
import hashlib
import json
import os
import subprocess
import numpy as np
from PIL import Image

out = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/candidates/v11-ground-plane/imported-textures')
out.mkdir(exist_ok=False)
records = []
for name, root in [('baseline', Path('D:/NestEggVerification/ne218-baseline-20261117')), ('c11', Path('D:/NestEggVerification/role-20261117'))]:
    folder = out / name
    folder.mkdir()
    paths = [p for p in (root / 'art/characters/collector_brute').rglob('*') if p.is_file()]
    paths += list((root / 'work/ne218-texture-cache-check').glob('*'))
    def snapshot():
        return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    before = snapshot()
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
        env[key] = str(folder / 'private-profile' / key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--quit-after', '600', 'res://work/ne218-texture-cache-check/check.tscn', '--', '--out=' + str(folder)]
    with (folder / 'raw.log').open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (folder / 'raw.log').read_bytes()
    assert process.returncode == 0 and b'SCRIPT ERROR:' not in raw and before == snapshot()
    data = json.loads((folder / 'textures.json').read_text(encoding='utf8'))
    comparisons = []
    for row in data['records']:
        source = root / row['source'].removeprefix('res://')
        original = np.asarray(Image.open(source).convert('RGBA'))
        loaded = np.frombuffer((folder / row['file']).read_bytes(), dtype=np.uint8).reshape(row['height'], row['width'], 4)
        same_size = original.shape == loaded.shape
        alpha = same_size and np.array_equal(original[:, :, 3], loaded[:, :, 3])
        opaque = original[:, :, 3] == 255
        rgb = same_size and np.array_equal(original[:, :, :3][opaque], loaded[:, :, :3][opaque])
        comparisons.append({'source': row['source'], 'same_size': same_size, 'alpha_exact': alpha, 'opaque_rgb_exact': rgb, 'source_sha_held': hashlib.sha256(source.read_bytes()).hexdigest() == row['source_sha256'], 'loaded_rgba_sha_held': hashlib.sha256((folder / row['file']).read_bytes()).hexdigest() == row['raw_sha256']})
    receipt = {'name': name, 'command': command, 'exit': process.returncode, 'source_before': before, 'source_after': snapshot(), 'comparisons': comparisons, 'scope': 'Actual Vulkan imported texture readback versus source PNG dimensions, all alpha bytes and fully opaque RGB. Transparent RGB edge filling is not treated as source corruption.'}
    (folder / 'verification.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
    records.append(receipt)
    print(name, len(comparisons), all(all(r[k] for k in ['same_size', 'alpha_exact', 'opaque_rgb_exact', 'source_sha_held', 'loaded_rgba_sha_held']) for r in comparisons), flush=True)
    assert all(all(r[k] for k in ['same_size', 'alpha_exact', 'opaque_rgb_exact', 'source_sha_held', 'loaded_rgba_sha_held']) for r in comparisons)
(out / 'results.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf8')
