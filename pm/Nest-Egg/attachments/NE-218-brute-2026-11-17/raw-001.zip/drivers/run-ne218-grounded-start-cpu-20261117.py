from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('D:/NestEggVerification/role-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/foot-diagnostic/grounded-start-cpu-v1')
out.mkdir(exist_ok=False)
paths = ['game/rig/humanoid_animator.gd', 'art/motion/collector_brute.json', 'art/rigs/collector_brute.json', 'art/characters/collector_brute/character.json']
paths += [p.relative_to(root).as_posix() for p in (root / 'work/ne218-brute-controls').glob('*.gd')]
paths += [p.relative_to(root).as_posix() for p in (root / 'work/ne218-brute-controls').glob('*.tscn')]
def snapshot():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in sorted(paths)}
before = snapshot()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
env = os.environ.copy()
for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
    env[key] = str(out / 'private-profile' / key)
results = []
for name in ['actions', 'flight', 'defaults', 'handoff']:
    command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', str(root), 'res://work/ne218-brute-controls/grounded_start_' + name + '.tscn', '--', '--out=' + str(out / (name + '.json'))]
    with (out / (name + '.log')).open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (out / (name + '.log')).read_bytes()
    results.append({'case': name, 'command': command, 'exit': process.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:')})
    print(name, process.returncode, flush=True)
after = snapshot()
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
(out / 'results.json').write_text(json.dumps({'source_held': before == after, 'cases': results}, indent=2) + '\n', encoding='utf8')
assert before == after and all(r['exit'] == 0 and r['script_errors'] == 0 for r in results)
