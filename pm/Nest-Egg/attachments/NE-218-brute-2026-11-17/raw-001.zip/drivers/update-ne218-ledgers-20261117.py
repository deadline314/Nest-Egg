from pathlib import Path
import json
import re
from PIL import Image

root = Path('D:/NestEggVerification/role-20261117')
workspace = Path('C:/Users/stanl/Github/Nest-Egg')
for skin in ['collector_brute', 'collector_gunner', 'egret', 'ali', 'sweeper']:
    relative = Path('pm/Nest-Egg/attachments/NE-218-ledger') / (skin + '.md')
    old = (root / relative).read_text(encoding='utf8')
    data = json.loads((root / 'art/characters' / skin / 'character.json').read_text(encoding='utf8'))
    spec = json.loads((root / 'tools/comfyui/specs' / (skin + '_side.json')).read_text(encoding='utf8'))
    descriptions = {}
    for line in old.splitlines():
        columns = [c.strip() for c in line.split('|')[1:-1]]
        if len(columns) == 8 and columns[0] not in ['顯示名稱', '---']:
            descriptions[columns[0]] = columns[-1]
    descriptions['hip_trim'] = '腰帶固定髖部、鑰匙沿用局部擺動；腿部不再重複持有'
    descriptions['apron'] = '獨立圍裙；依專屬掛點與姿勢彎曲'
    rows = ['## 零件', '', '| 顯示名稱 | 貼圖 | 尺寸 | 支點 | 視覺位移（世界像素） | 骨頭 | 圖層 | 狀態 | 來源群組與切法 |', '|---|---|---|---|---|---|---|---|---|']
    for part in data['parts']:
        texture = data['textures'][part['texture']]
        with Image.open(root / 'art/characters' / skin / texture['file']) as image:
            assert list(image.size) == texture['size']
        description = descriptions.get(part['name'], texture.get('note', '依正式外觀資料'))
        if skin == 'collector_brute' and part['texture'] == 'leg_upper':
            description = '身體：hip→knee；腰帶與鑰匙由獨立腰部飾片持有'
        rows.append('| ' + ' | '.join(map(str, [part['name'], part['texture'], texture['size'], texture['pivot'], part.get('offset', [0, 0]), part['bone'], part.get('z', 0), '常態', description])) + ' |')
    replacement = '\n'.join(rows) + '\n'
    text, count = re.subn(r'## 零件\n.*?(?=\n## 接點)', lambda _: replacement, old, flags=re.S)
    assert count == 1
    landmarks = {'頭－頸－胸': 'neck', '胸－腰－骨盆': 'waist', '肩': 'shoulder', '肘': 'elbow', '腕': 'palm', '髖': 'hip', '膝': 'knee', '踝': 'ankle'}
    for label, joint in landmarks.items():
        assert joint in spec['joints']
        text, count = re.subn(r'(?m)^\| ' + re.escape(label) + r' \| \[[^\]]+\]', lambda _, l=label, j=joint: '| ' + l + ' | ' + str(spec['joints'][j]), text)
        assert count == 1
    text += '\n## 姿勢替換與眼睛\n\n'
    poses = data.get('pose_parts', {})
    if poses:
        text += '| 姿勢 | 邏輯部件 | 替換貼圖 | 尺寸 | 支點 | 骨頭 | 圖層 |\n|---|---|---|---|---|---|---|\n'
        for pose, definition in poses.items():
            for variant in definition['parts']:
                base = next(p for p in data['parts'] if p['name'] == variant['slot'])
                texture = data['textures'][variant['texture']]
                text += '| ' + ' | '.join(map(str, [pose, variant['slot'], variant['texture'], texture['size'], texture['pivot'], variant.get('bone', base['bone']), variant.get('z', base.get('z', 0))])) + ' |\n'
    else:
        text += '沒有額外姿勢貼圖替換。\n'
    if data.get('eye_states'):
        text += '\n眼睛替換保留同一個頭部部件：\n\n```json\n' + json.dumps(data['eye_states'], ensure_ascii=False, indent=2) + '\n```\n'
    text += '\n尺寸、支點、位移與姿勢替換依目前正式外觀資料核對；來源座標依目前角色規格核對。法線沿用同名 `_n` 貼圖；實際載入驗證另見本票交付紀錄。\n'
    for destination_root in [root, workspace]:
        assert (destination_root / relative).read_text(encoding='utf8') == old
        (destination_root / relative).write_text(text, encoding='utf8', newline='\n')
    print(skin, len(data['parts']), 'base parts;', sum(len(v['parts']) for v in poses.values()), 'pose replacements')
