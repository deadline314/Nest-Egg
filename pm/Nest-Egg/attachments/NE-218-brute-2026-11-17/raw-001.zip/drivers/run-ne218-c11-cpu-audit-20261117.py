from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

out = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/candidates/v11-ground-plane/cpu-cost-and-audit')
out.mkdir(exist_ok=False)
roots = {'baseline': Path('D:/NestEggVerification/ne218-baseline-20261117'), 'c11': Path('D:/NestEggVerification/role-20261117')}
destination = roots['baseline'] / 'work/ne218-brute-controls'
destination.mkdir(exist_ok=False)
(destination / '.gdignore').write_text('')
for name in ['anim_audit.gd', 'anim_audit.tscn']:
    shutil.copyfile(roots['c11'] / 'work/ne218-brute-controls' / name, destination / name)
source_paths = ['game/rig/humanoid_animator.gd', 'game/rig/character_rig.gd', 'game/rig/npc_animator.gd', 'art/motion/collector_brute.json', 'art/rigs/collector_brute.json', 'tools/rig_perf_probe.gd', 'work/ne218-brute-controls/anim_audit.gd']
def snapshot():
    return {name: {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in source_paths} for name, root in roots.items()}
before = snapshot()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
env = os.environ.copy()
for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
    env[key] = str(out / 'private-profile' / key)
records = []
for index, name in enumerate(['baseline', 'c11', 'c11', 'baseline'] * 3, 1):
    root = roots[name]
    command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', str(root), 'res://tools/rig_perf_probe.tscn', '--', '--count=10', '--frames=600', '--skin=collector_brute']
    with (out / (str(index) + '-' + name + '.log')).open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (out / (str(index) + '-' + name + '.log')).read_bytes()
    match = re.search(r'剛體 ([0-9.]+) µs/格，關節網格 ([0-9.]+) µs/格.*網格頂點 ([0-9]+)', raw.decode('utf8', errors='replace'))
    assert process.returncode == 0 and b'SCRIPT ERROR:' not in raw and match
    record = {'name': name, 'order': index, 'command': command, 'exit': process.returncode, 'rigid_us_per_frame': float(match[1]), 'mesh_us_per_frame': float(match[2]), 'vertices': int(match[3]), 'scope': 'Unmodified original CPU-only house rig_perf_probe, ten rigs,600steps; not GPU/full-frame acceptance. Original output is rounded to one decimal.'}
    records.append(record)
    print(name, index, record['mesh_us_per_frame'], flush=True)
    (out / 'cpu-runs.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf8')
audits = []
for name, root in roots.items():
    command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', str(root), '--quit-after', '600', 'res://work/ne218-brute-controls/anim_audit.tscn', '--', '--audit', '--out=' + str(out / (name + '-audit'))]
    with (out / (name + '-audit.log')).open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (out / (name + '-audit.log')).read_bytes()
    audits.append({'name': name, 'command': command, 'exit': process.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:')})
    print(name, 'audit', process.returncode, flush=True)
after = snapshot()
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
(out / 'audits.json').write_text(json.dumps({'source_held': before == after, 'audits': audits}, indent=2) + '\n', encoding='utf8')
assert before == after and all(r['script_errors'] == 0 for r in audits)
