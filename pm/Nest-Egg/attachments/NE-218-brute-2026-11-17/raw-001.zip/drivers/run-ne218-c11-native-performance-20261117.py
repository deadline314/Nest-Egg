from pathlib import Path
import hashlib
import json
import math
import os
import subprocess
import time
import psutil

out = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/candidates/v11-ground-plane/performance-native-v1')
out.mkdir(exist_ok=False)
completed = json.loads((out.parent / 'affected-main/result.json').read_text(encoding='utf8'))
assert completed['exit'] == 0 and completed['source_unchanged']
roots = {'baseline': Path('D:/NestEggVerification/ne218-baseline-20261117'), 'c11': Path('D:/NestEggVerification/role-20261117')}
paths = {}
for name, root in roots.items():
    paths[name] = [p for p in subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'core', 'game', 'data', 'ui', 'art', 'tools', 'project.godot'], cwd=root).decode('utf8').split('\0') if p and (root / p).is_file()]
    paths[name] += [p.relative_to(root).as_posix() for p in (root / 'work/ne218-performance').glob('*')]
def snapshot(name):
    return {p: hashlib.sha256((roots[name] / p).read_bytes()).hexdigest() for p in paths[name]}
def workload():
    rows = []
    for p in psutil.process_iter(['pid', 'name']):
        try:
            if 'godot' in p.info['name'].lower():
                cpu = p.cpu_times()
                rows.append({'pid': p.pid, 'name': p.info['name'], 'cwd': p.cwd(), 'cpu_s': cpu.user + cpu.system, 'rss_bytes': p.memory_info().rss})
        except psutil.Error:
            pass
    return {'available_ram': psutil.virtual_memory().available, 'godot': rows}
before = {name: snapshot(name) for name in roots}
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
records = []
for quality in ['low', 'high']:
    for index, name in enumerate(['baseline', 'c11', 'c11', 'baseline'], 1):
        root = roots[name]
        folder = out / (quality + '-' + str(index) + '-' + name)
        folder.mkdir()
        env = os.environ.copy()
        for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
            env[key] = str(folder / 'private-profile' / key)
        command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '1280x720', 'res://work/ne218-performance/scenario.tscn', '--', '--count=10', '--quality=' + quality, '--out=' + str(folder)]
        start_load = workload()
        start = time.monotonic()
        peak = 0
        with (folder / 'raw.log').open('wb') as log:
            process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
            while process.poll() is None:
                try:
                    children = psutil.Process(process.pid).children(recursive=True)
                    for p in children:
                        if p.name() == 'Godot_v4.7.2-stable_win64.exe':
                            peak = max(peak, p.memory_info().rss)
                except psutil.Error:
                    pass
                time.sleep(0.2)
        raw = (folder / 'raw.log').read_bytes()
        receipt = {'quality': quality, 'epoch': name, 'order': index, 'command': command, 'exit': process.returncode, 'elapsed_s': time.monotonic() - start, 'peak_native_rss_bytes': peak, 'workload_before': start_load, 'workload_after': workload(), 'script_errors': raw.count(b'SCRIPT ERROR:'), 'scope': 'Own affected suite has natural EOF before this native ABBA. Other-project workload is recorded, not terminated or claimed absent. Existing house scenario with ten visual rigs and actual uncapped full-frame rendering, not ten combat AI or a GPU-only timer.'}
        (folder / 'run.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
        assert process.returncode == 0 and receipt['script_errors'] == 0
        frames = json.loads((folder / 'frames.json').read_text(encoding='utf8'))
        assert len(frames['records']) == 4 and '9070' in frames['adapter'] and frames['renderer'] == 'forward_plus' and frames['hdr_2d']
        assert all(len(r['wall_ms']) == r['frames'] and r['frames'] > 30 and all(math.isfinite(v) and v > 0 for v in r['wall_ms']) for r in frames['records'])
        records.append(receipt)
        (out / 'runs.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf8')
        print(quality, index, name, process.returncode, [round(sum(r['wall_ms']) / r['frames'], 4) for r in frames['records']], flush=True)
after = {name: snapshot(name) for name in roots}
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
(out / 'source-held.json').write_text(json.dumps({'source_held': before == after, 'source_counts': {n: len(s) for n, s in before.items()}}, indent=2) + '\n', encoding='utf8')
assert before == after
