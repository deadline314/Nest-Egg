extends Node
## Diagnostic replay of real recorded foot transforms, using the actual imported
## rig part, normal/diffuse CanvasTexture and character shader. No source edits.
var _out := ""
func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	_run.call_deferred()
func transform(values: Array) -> Transform2D:
	return Transform2D(Vector2(values[0], values[1]), Vector2(values[2], values[3]), Vector2(values[4], values[5]))
func _run() -> void:
	assert(_out.is_absolute_path() and DisplayServer.get_name() != "headless")
	var cases: Array = JSON.parse_string(FileAccess.get_file_as_string(_out.path_join("cases.json")))
	var records: Array[Dictionary] = []
	for c: Dictionary in cases:
		assert(FileAccess.get_sha256(c.source_actions) == c.source_actions_sha256)
		var data: Dictionary = c.foot
		assert(FileAccess.get_sha256(data.source) == data.source_sha256)
		var viewport := SubViewport.new()
		viewport.size = Vector2i(c.size[0], c.size[1])
		viewport.transparent_bg = true
		viewport.canvas_item_default_texture_filter = get_viewport().canvas_item_default_texture_filter
		viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
		add_child(viewport)
		var rig := CharacterRig.new()
		viewport.add_child(rig)
		assert(rig.setup("collector_brute"))
		var foot: Sprite2D
		for part in rig._parts:
			if str(part.name) == data.part:
				assert(part is Sprite2D)
				foot = part as Sprite2D
		assert(foot != null and foot.offset == Vector2(data.rect_origin[0], data.rect_origin[1]))
		var texture := foot.texture as CanvasTexture
		assert(texture != null and texture.diffuse_texture != null)
		var shape_a: Variant = foot.get_instance_shader_parameter("sway_a_shape")
		var shape_b: Variant = foot.get_instance_shader_parameter("sway_b_shape")
		var shader := (foot.material as ShaderMaterial).shader
		assert(shader.code.contains("instance uniform vec2 sway_a_shape = vec2(0.0);") and shader.code.contains("instance uniform vec2 sway_b_shape = vec2(0.0);"))
		assert(shape_a == null or (typeof(shape_a) == TYPE_VECTOR2 and shape_a.x == 0))
		assert(shape_b == null or (typeof(shape_b) == TYPE_VECTOR2 and shape_b.x == 0))
		foot.reparent(viewport)
		var scale := Transform2D(0.0, Vector2.ONE * float(c.density), 0.0, Vector2.ZERO)
		foot.transform = scale * transform(c.canvas) * transform(data.part_world_transform)
		var material_id := (foot.material as ShaderMaterial).shader.resource_path
		rig.queue_free()
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var image := viewport.get_texture().get_image()
		var file := str(c.id).validate_filename() + ".png"
		assert(image.save_png(_out.path_join(file)) == OK)
		records.append({"id": c.id, "file": file, "facing": c.facing, "state_time": c.state_time,
			"geometry_physics_frame": c.geometry_physics_frame, "foot": data.part, "epoch": c.epoch,
			"source_actions_sha256": c.source_actions_sha256, "foot_source_sha256": data.source_sha256,
			"texture_resource": texture.diffuse_texture.resource_path, "material_resource": material_id,
			"canvas_filter": viewport.canvas_item_default_texture_filter, "sway_a_instance": shape_a, "sway_b_instance": shape_b, "unset_sway_default": "vec2(0.0), asserted against actual shader source", "source_part_filter": foot.texture_filter,
			"floor_native_y": (transform(c.canvas) * Vector2(0, float(data.terrain_y)) * float(c.density)).y,
			"actual_image_format": image.get_format(), "actual_image_size": [image.get_width(), image.get_height()]})
		viewport.queue_free()
		await get_tree().process_frame
	var result := {"scope": "Read-only diagnostic replay, not a second live AI sample: frozen live native physics foot transforms + fixed windup camera; actual imported CanvasTexture/shader/filter, alpha threshold unchanged", "engine": Engine.get_version_info().string, "adapter": RenderingServer.get_video_adapter_name(), "renderer": RenderingServer.get_current_rendering_method(), "records": records}
	var file := FileAccess.open(_out.path_join("masks.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(result, "  ") + "\n")
	file.close()
	print("FROZEN_FOOT_ALPHA masks=", records.size())
	get_tree().quit()
