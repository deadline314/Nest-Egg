from pathlib import Path
import json
from math import isclose

root = Path(__file__).resolve().parent
before, after = [json.loads((root / name / "result.json").read_bytes()) for name in ("stock-v2","candidate-v2")]
states = lambda data: {(row["mode"], row["step"]):row for row in data["rows"]}
old, new = states(before), states(after)
assert set(old) == set(new) and len(old) == 24
for key, item in old.items():
    assert item["awake"]
    assert all(item[p] == new[key][p] for p in ("awake","boss_phase","health","max_health","name","ratio","motion","flashes")), key

for mode in ("motion","both"):
    first = new[mode,"entry"]
    assert old[mode,"entry"]["scale_x"] < 1.0 if mode == "motion" else old[mode,"entry"]["alpha"] < 1.0
    assert first["visible"] and first["scale_x"] == first["alpha"] == 1.0 and not first["tween_running"]
    assert old[mode,"defeated"]["visible"] and not new[mode,"defeated"]["visible"]
for mode in ("motion","flashes","both"):
    for phase in ("phase","low"):
        row = new[mode,phase]
        assert old[mode,phase]["phase_flash"] > 0 and old[mode,phase]["trail"] > old[mode,phase]["ratio"]
        assert row["visible"] and row["phase_flash"] == 0 and not row["pulse"]
        assert isclose(row["trail"],row["ratio"],rel_tol=0,abs_tol=1e-5)
    assert old[mode,"low"]["pulse"]
assert 0 < new["flashes","entry"]["alpha"] < 1.0 and new["flashes","entry"]["tween_running"]
assert new["flashes","defeated"]["visible"]
assert new["standard","entry"]["scale_x"] < 1 and new["standard","phase"]["phase_flash"] > 0
assert new["standard","low"]["pulse"] and new["standard","defeated"]["visible"]
assert new["toggle","entry-toggle"]["scale_x"] == 1.0 and not new["toggle","entry-toggle"]["tween_running"]
assert old["toggle","feedback-toggle"]["pulse"] and not new["toggle","feedback-toggle"]["pulse"]
assert new["toggle","feedback-normal"]["pulse"] and new["toggle","feedback-normal"]["phase_flash"] == 0
assert old["toggle","exit-toggle"]["visible"] and not new["toggle","exit-toggle"]["visible"]
(root/"paired.json").write_text(json.dumps({
    "native_pairs":len(old),"same_combat_state_and_health":True,
    "original_reduced_modes_still_flash_and_pulse":3,"fixed_reduced_modes_still_flash_or_pulse":0,
    "full_visibility_with_reduced_motion":True,
    "toggle_completes_enter_and_exit":True,
    "scenes":[{"case":f"{k[0]}/{k[1]}","before":old[k],"after":new[k]} for k in old]},indent=2)+"\n")
print("Warehouse boss bar: 24 matching combat states including five accessibility settings paths")

