from pathlib import Path
import os
import re
import subprocess
import sys

scope = Path(__file__).resolve().parent
shared = Path("D:/NestEggVerification/ne218-baseline-20261117")
mode = sys.argv[1]
assert mode in ("stock", "candidate")
folder = scope / (mode + "-focus")
folder.mkdir(exist_ok=False)
env = os.environ.copy()
for var in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR", "XDG_DATA_HOME", "XDG_CONFIG_HOME"):
    subdir = folder / var
    subdir.mkdir()
    env[var] = str(subdir)
path = Path("tests/suite/test_combat_hud.gd")
fixture = (scope/"candidate-source"/path).read_bytes()
stored = (shared/path).read_bytes()
if mode == "stock":
    assert stored == subprocess.check_output(["git","show","HEAD:"+path.as_posix()],cwd=shared)
else:
    assert stored == fixture
try:
    if mode == "stock":
        (shared/path).write_bytes(fixture)
    args = ["C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(shared), "--headless", "res://tests/smoke_test.tscn",
            "--", "--only=CombatHudSuite"]
    with (folder/"raw.log").open("wb") as log:
        outcome = subprocess.run(args, env=env, cwd=shared, stdout=log, stderr=subprocess.STDOUT, timeout=150)
finally:
    if mode == "stock":
        (shared/path).write_bytes(stored)
text = (folder/"raw.log").read_text(encoding="utf-8")
print("\n".join([line for line in text.splitlines() if re.search(r"checks:|FAIL|ERROR:",line)]))
assert not re.search(r"^(?:SCRIPT )?ERROR:",text,re.M)
assert outcome.returncode == int(mode == "stock")
