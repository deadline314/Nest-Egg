extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const WAREHOUSE := preload("res://data/levels/ch1_warehouse.tres")
var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	for key: String in OS.get_cmdline_user_args():
		if key.begins_with("--out="):
			_out = key.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		printerr("Boss bar proof needs native rendering and an absolute output")
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://boss_bar_fixture.cfg")
	Settings.set_brightness(0.5)
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	DirAccess.make_dir_recursive_absolute(_out)
	for mode: String in ["standard", "motion", "flashes", "both", "toggle"]:
		if not await _observe(mode):
			printerr("Warehouse boss bar fixture failed for ", mode)
			get_tree().quit(1)
			return
	var file := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"rows":_rows, "adapter":RenderingServer.get_video_adapter_name(),
		"renderer":RenderingServer.get_current_rendering_method(),"hdr_2d":get_viewport().use_hdr_2d}, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)


func _observe(mode: String) -> bool:
	seed(882418)
	Settings.set_reduce_ui_motion(mode in ["motion", "both"])
	Settings.set_reduce_flashes(mode in ["flashes", "both"])
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(WAREHOUSE)
	add_child(level)
	var target: PatternBoss
	for node in level._entities.get_children():
		if node is PatternBoss and node.data.id == &"watchdog":
			target = node
		elif node is Enemy:
			node.process_mode = Node.PROCESS_MODE_DISABLED
	if target == null:
		return false
	for node in level.find_children("*", "", true, false):
		if node is ChapterCard:
			node.queue_free()
	var bar := level.hud.boss_bar
	var player := level.player
	player.health.setup(999, 0.0)
	player.global_position = target.global_position + Vector2(-85, 0)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	level._lighting._lightning_gap = 1.0e9
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.limit_enabled = false
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	camera.global_position = target.global_position + Vector2(-30, -43)
	camera.reset_smoothing()
	camera.force_update_scroll()
	target._wake()
	if not await _record(mode, "entry", target, bar):
		return false
	if mode == "toggle":
		Settings.set_reduce_ui_motion(true)
		if not await _record(mode, "entry-toggle", target, bar):
			return false
		Settings.set_reduce_ui_motion(false)
	for tick in 34:
		await get_tree().process_frame
	if not _deal_damage(target, 0.46) or not await _record(mode, "phase", target, bar):
		return false
	if not _deal_damage(target, 0.15) or not await _record(mode, "low", target, bar):
		return false
	if mode == "toggle":
		Settings.set_reduce_flashes(true)
		if not await _record(mode, "feedback-toggle", target, bar):
			return false
		Settings.set_reduce_flashes(false)
		if not await _record(mode, "feedback-normal", target, bar):
			return false
	if not _deal_damage(target, 0.0) or not await _record(mode, "defeated", target, bar):
		return false
	if mode == "toggle":
		Settings.set_reduce_ui_motion(true)
		if not await _record(mode, "exit-toggle", target, bar):
			return false
	level.queue_free()
	await get_tree().process_frame
	return true


func _deal_damage(target: PatternBoss, fraction: float) -> bool:
	var result := maxi(0, roundi(target.health.max_health * fraction))
	var hit := DamageInfo.create(target.health.current - result, Combat.Team.PLAYER, &"p9")
	hit.ignore_invulnerability = true
	return target.health.take_damage(hit) and target.health.current == result


func _record(mode: String, status: String, target: PatternBoss, bar: BossBar) -> bool:
	await RenderingServer.frame_post_draw
	var file_name := mode + "-" + status + ".png"
	var result := Capture.image(get_viewport()).save_png(_out.path_join(file_name))
	_rows.append({"mode":mode, "step":status, "file":file_name, "awake":target.is_awake(),
		"boss_phase":target.phase, "health":target.health.current, "max_health":target.health.max_health,
		"visible":bar.visible, "name":bar._name, "ratio":bar.ratio(), "scale_x":bar.scale.x,
		"alpha":bar.modulate.a, "phase_flash":bar._flash, "trail":bar._bar._trail, "pulse":bar._bar._pulse,
		"motion":Settings.get_reduce_ui_motion(), "flashes":Settings.get_reduce_flashes(),
		"tween_running":bar._tween != null and bar._tween.is_running()})
	return result == OK
