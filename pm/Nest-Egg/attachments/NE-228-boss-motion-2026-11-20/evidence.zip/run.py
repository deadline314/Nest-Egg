from pathlib import Path
import json
import os
import re
import subprocess
import sys

project = Path.cwd()
scope = Path(__file__).resolve().parent
label = sys.argv[1]
folder = scope / label
folder.mkdir()
profile = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    child = folder / key
    child.mkdir()
    profile[key] = str(child)
godot = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
command = [sys.executable, "-B", str(project / "tools/comfyui/gpu_lock.py"), "--", godot, "--path", str(project),
           "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--fixed-fps", "60",
           "--audio-driver", "Dummy", "--resolution", "1280x720", "--quit-after", "2400", str(scope / "watchdog-bar.tscn"),
           "--", f"--out={folder}"]
(folder / "command.json").write_text(json.dumps(command, indent=2) + "\n")
with (folder / "engine.log").open("wb") as log:
    result = subprocess.run(command, env=profile, stdout=log, stderr=subprocess.STDOUT, timeout=240)
raw = (folder / "engine.log").read_text(encoding="utf-8", errors="replace")
print(raw[-8000:])
assert result.returncode == 0 and not re.search(r"^(?:SCRIPT )?ERROR:", raw, re.M)
data = json.loads((folder / "result.json").read_bytes())
assert data["hdr_2d"] and "9070 XT" in data["adapter"] and len(data["rows"]) == 24
