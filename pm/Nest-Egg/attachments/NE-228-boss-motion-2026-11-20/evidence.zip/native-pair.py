from pathlib import Path
from shutil import copy2
import subprocess
import sys

scope = Path(__file__).resolve().parent
root = Path.cwd()
names = ("ui/boss_bar.gd", "ui/kit/segment_bar.gd")
for name in names:
    assert (root/name).read_bytes() == (scope/"candidate-source"/name).read_bytes()

def run(tag):
    subprocess.run([sys.executable,str(scope/"run.py"),tag],cwd=root,check=True)

try:
    for name in names:
        pristine = subprocess.check_output(["git","show","c99a6c248:"+name],cwd=root)
        (root/name).write_bytes(pristine)
    run("stock-v2")
finally:
    for name in names:
        copy2(scope/"candidate-source"/name, root/name)
run("candidate-v2")
