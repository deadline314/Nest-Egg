from pathlib import Path
import json,hashlib,zipfile,shutil
root=Path.cwd();work=root/'work/ne246-combat';out=root/'pm/Nest-Egg/attachments/NE-246-real-combat';out.mkdir(parents=True,exist_ok=True);base=Path('/workspace/Nest-Egg/work/batch1020b');sha=lambda b:hashlib.sha256(b).hexdigest();files={};reports={};checks=0
names=['ne246-1022-real-combat-writer-v1','ne246-1022-real-combat-continue-v1']
for n in names:
 d=json.loads((base/n/'result.json').read_text());assert d['completed'] and d['failures']==0;reports[n]=d
 log=(base/(n+'.log')).read_text();assert 'ERROR:' not in log and 'Leaked' not in log
 checks+=sum(l.startswith(('PASS ','FAIL ')) for l in log.splitlines())
 for p in (base/n).rglob('*'):
  if p.is_file():files['native/'+n+'/'+str(p.relative_to(base/n))]=p.read_bytes()
 for suffix in ['.log','.exit','-xvfb.log']:
  p=base/(n+suffix)
  if p.exists():files['native/'+p.name]=p.read_bytes()
fixed=reports[names[0]];assert len(fixed['actual_readings'])==5 and fixed['pause_checked']
assert all(r['before']==r['after'] and r['main_process_mode']==1 and not r['main_can_process_while_paused'] and r['tree_paused'] for r in fixed['actual_readings'])
assert any(r['before']['bullets'] for r in fixed['actual_readings']) and any(len(r['sources'])>1 for r in fixed['actual_readings'])
cold=json.loads((work/'native-cold-source.json').read_text());assert cold['writer_slot_sha256']==cold['frozen_slot_sha256']
for p in work.rglob('*'):
 if p.is_file() and p.name not in ['native-package-receipt.json'] and not any('profile' in x or x=='__pycache__' for x in p.relative_to(work).parts):files['work/ne246-combat/'+str(p.relative_to(work))]=p.read_bytes()
for p in ['tools/quest_resume_probe.gd','game/main.gd','scenes/main.tscn','ui/dialogue_layer.gd','data/story/ch1_kasa.json','game/level/level.gd','tools/viewport_capture.gd','design/20-campaign-experience/RADIO_REAL_COMBAT.md','work/.gdignore']:
 files['source/'+p]=(root/p).read_bytes()
for p in (root/'pm/Nest-Egg/attachments/NE-278-references').iterdir():
 if p.is_file():files['references/'+p.name]=p.read_bytes()
validation={'source_commit':'7bf96cfb95fcec3cbb609aea0658ab547e59068d','native_checks':checks,'native_failures':0,'native_processes':2,'native_pngs':sum(p.endswith('.png') for p in files if p.startswith('native/')),'all_native_pngs_individually_viewed':True,'world_readings':5,'actual_back_to_back_sources':fixed['actual_readings'][0]['sources'],'same_identity_position_health_hit_count_and_clock':True,'cold_save_sha256':cold['writer_slot_sha256'],'headless_same_probe_old_checks':93,'headless_same_probe_old_failures':6,'headless_same_probe_fixed_checks':93,'headless_same_probe_fixed_failures':0,'environment':'Godot4.7.2 Forward+ HDR, Vulkan llvmpipe, Xvfb1280x720, synthetic public inputs','scope':'authored actual combat sources, arranged old-save prerequisites/positions and nonlethal floor1; not human full chapter or physical controller; UI world text baseline predates NE228 pending change'}
(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for p,b in files.items():assert sha(z.read(p))==sha(b)
manifest={'archive_bytes':(out/'raw.zip').stat().st_size,'archive_sha256':sha((out/'raw.zip').read_bytes()),'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for src,dest in [('actual-radio-01.png','first'),('actual-radio-04.png','flight'),('actual-radio-05.png','second'),('actual-radio-pause.png','pause')]:shutil.copyfile(base/names[0]/src,root/('pm/Nest-Egg/images/NE-246-real-'+dest+'.png'))
shutil.copyfile(base/names[1]/'route-journal-completed.png',root/'pm/Nest-Egg/images/NE-246-real-continued.png')
print(json.dumps({'validation':validation,'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256']},ensure_ascii=False,indent=2))
