from pathlib import Path
import subprocess,os,json,shutil,hashlib
root=Path.cwd();out=root/'work/ne246-combat';env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen';saved=out/'native-v1-save';rows=[]
files=['tools/quest_resume_probe.gd','work/ne246-combat/probe.gd','work/ne246-combat/combat_base.gd','work/ne246-combat/phone_base.gd','ui/dialogue_layer.gd','data/story/ch1_kasa.json']
(out/'native-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')
for mode,name in [('write','ne246-1022-real-combat-writer-v1'),('continue','ne246-1022-real-combat-continue-v1')]:
 if mode=='continue':
  shutil.copytree(saved,out/'native-v1-writer-frozen')
  (out/'native-cold-source.json').write_text(json.dumps({'writer_slot_sha256':hashlib.sha256((saved/'slot.json').read_bytes()).hexdigest(),'frozen_slot_sha256':hashlib.sha256((out/'native-v1-writer-frozen/slot.json').read_bytes()).hexdigest()},indent=2)+'\n')
 command=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/ne246-combat/probe.tscn','--mode='+mode,'--save-dir='+str(saved)]
 with (out/(name+'-wrapper.log')).open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1850)
 rows.append({'mode':mode,'command':command,'name':name,'exit_code':r.returncode});(out/'native-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True);assert r.returncode==0
