from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
ROOT=Path('C:/Users/stanl/Github/Nest-Egg');PROJECT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg');OUT=ROOT/'work/ne228-menu-native-pair-v1'
official=ROOT/'work/ne228-menu-official';result=json.loads((official/'exit.json').read_bytes());assert result['exit']==0 and result['sources_unchanged']
candidate=json.loads((official/'candidate.json').read_bytes());assert not OUT.exists()
before=(official/'original-main_menu.gd').read_bytes();after=(ROOT/'work/ne228-start-guidance/candidate-main_menu.gd').read_bytes();target=PROJECT/'ui/main_menu.gd';assert target.read_bytes()==after
assert subprocess.check_output(['git','diff','--name-only'],cwd=PROJECT).decode().strip()=='ui/main_menu.gd'
OUT.mkdir();(OUT/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
save(OUT/'candidate-context.json',dict(base=candidate['base'],scope='clean published runtime plus one existing main-menu focus/hover sentence; no pending melee/NPC',before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),runner_sha256=sha(Path(__file__)),movie_clock='fixed 30Hz, not real-time performance'))
try:
 for label,data in [('before',before),('after',after)]:
  case=OUT/label;case.mkdir();frames=case/'frames';frames.mkdir();target.write_bytes(data);(case/'executed-main_menu.gd').write_bytes(data)
  env=os.environ.copy()
  for key,part in [('APPDATA','roaming'),('LOCALAPPDATA','local')]:
   p=case/'user'/part;p.mkdir(parents=True);env[key]=str(p)
  command=[sys.executable,str(ROOT/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(PROJECT),'--windowed','--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan','--write-movie',str(frames/'menu.png'),'--fixed-fps','30','--quit-after','90','--disable-vsync']
  save(case/'command-before.json',dict(command=command,cwd=str(PROJECT),source_before_sha256=sha(target)))
  start=time.monotonic()
  with (case/'process.log').open('xb') as f:proc=subprocess.run(command,cwd=PROJECT,env=env,stdout=f,stderr=subprocess.STDOUT)
  log=(case/'process.log').read_text(encoding='utf-8',errors='replace');errors=[line for line in log.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|ObjectDB instances leaked|resources still in use',line)]
  pngs=sorted(frames.glob('*.png'));record=dict(exit=proc.returncode,seconds=time.monotonic()-start,error_lines=errors,frames=len(pngs),sources_unchanged=target.read_bytes()==data,renderer_forward_plus='Forward+' in log,gpu_rx9070xt=bool(re.search(r'RX\s*9070\s*XT',log,re.I)),process_log_sha256=sha(case/'process.log'),files={p.relative_to(case).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in case.rglob('*') if p.is_file() and p.relative_to(case).parts[0]!='user'})
  save(case/'receipt.json',record)
  assert proc.returncode==0 and not errors and len(pngs)==90 and record['sources_unchanged'] and record['renderer_forward_plus'] and record['gpu_rx9070xt'],'native menu pair rejected; raw evidence preserved'
  print(label,'native menu90frames clean',flush=True)
finally:
 target.write_bytes(after)
 assert target.read_bytes()==after
