extends Node
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var output := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--output="): output = arg.trim_prefix("--output=")
	var main: Node = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	for i in 90:
		await get_tree().process_frame
	var menu := main.get("_screen") as MainMenu
	if menu == null or not menu.is_visible_in_tree() or not menu.get("_main_page").visible:
		push_error("[NE228Menu] Actual Main route did not publish its visible main page")
		main.call("_quit", 2)
		return
	await RenderingServer.frame_post_draw
	var raw := get_viewport().get_texture().get_image()
	var png := preload("res://tools/viewport_capture.gd").encode(raw, get_viewport().use_hdr_2d)
	var status := png.save_png(output + ".png")
	FileAccess.open(output + ".bin", FileAccess.WRITE).store_buffer(raw.get_data())
	var button: Button = menu.get("_start_button")
	var hint: Label = menu.get("_hint")
	var observation := {"fixture": true, "actual_main_scene": main.scene_file_path,
		"renderer": RenderingServer.get_current_rendering_method(), "hdr_2d": get_viewport().use_hdr_2d,
		"format": raw.get_format(), "size": [raw.get_width(), raw.get_height()], "observed_process_frames": 90,
		"button_focused": button.has_focus(), "tooltip": button.tooltip_text, "focus_hint": hint.text,
		"png_status": status, "quit_via_actual_menu_signal": true, "fixed_clock_not_performance": true}
	FileAccess.open(output + ".json", FileAccess.WRITE).store_string(JSON.stringify(observation, "  ") + "\n")
	menu.quit_requested.emit()
