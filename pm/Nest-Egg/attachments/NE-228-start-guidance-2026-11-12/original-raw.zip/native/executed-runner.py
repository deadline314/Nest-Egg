from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
ROOT=Path('C:/Users/stanl/Github/Nest-Egg');PROJECT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg');OUT=ROOT/'work/ne228-menu-native-pair-v2'
official=ROOT/'work/ne228-menu-official';result=json.loads((official/'exit.json').read_bytes());assert result['exit']==0 and result['sources_unchanged']
candidate=json.loads((official/'candidate.json').read_bytes());assert not OUT.exists()
before=(official/'original-main_menu.gd').read_bytes();after=(ROOT/'work/ne228-start-guidance/candidate-main_menu.gd').read_bytes();target=PROJECT/'ui/main_menu.gd';assert target.read_bytes()==after
OUT.mkdir();PROBE=PROJECT/'work/ne228-menu-native-pair-v2';PROBE.mkdir();(PROJECT/'work/.gdignore').touch()
producer='''extends Node
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var output := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--output="): output = arg.trim_prefix("--output=")
	var main: Node = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	for i in 90:
		await get_tree().process_frame
	var menu := main.get("_screen") as MainMenu
	if menu == null or not menu.is_visible_in_tree() or not menu.get("_main_page").visible:
		push_error("[NE228Menu] Actual Main route did not publish its visible main page")
		main.call("_quit", 2)
		return
	await RenderingServer.frame_post_draw
	var raw := get_viewport().get_texture().get_image()
	var png := preload("res://tools/viewport_capture.gd").encode(raw, get_viewport().use_hdr_2d)
	var status := png.save_png(output + ".png")
	FileAccess.open(output + ".bin", FileAccess.WRITE).store_buffer(raw.get_data())
	var button: Button = menu.get("_start_button")
	var hint: Label = menu.get("_hint")
	var observation := {"fixture": true, "actual_main_scene": main.scene_file_path,
		"renderer": RenderingServer.get_current_rendering_method(), "hdr_2d": get_viewport().use_hdr_2d,
		"format": raw.get_format(), "size": [raw.get_width(), raw.get_height()], "observed_process_frames": 90,
		"button_focused": button.has_focus(), "tooltip": button.tooltip_text, "focus_hint": hint.text,
		"png_status": status, "quit_via_actual_menu_signal": true, "fixed_clock_not_performance": true}
	FileAccess.open(output + ".json", FileAccess.WRITE).store_string(JSON.stringify(observation, "  ") + "\\n")
	menu.quit_requested.emit()
'''
(PROBE/'probe.gd').write_text(producer,encoding='utf-8',newline='\n');(PROBE/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/ne228-menu-native-pair-v2/probe.gd" id="1"]\n[node name="NE228MenuObservation" type="Node"]\nscript=ExtResource("1")\n',encoding='utf-8',newline='\n')
for p in PROBE.iterdir():(OUT/p.name).write_bytes(p.read_bytes())
(OUT/'executed-runner.py').write_bytes(Path(__file__).read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
save(OUT/'context.json',dict(base=candidate['base'],before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),scope='real Main scene/menu/focus/hover; programmed observer and actual menu quit signal, not human input or performance',rejected_first_harness='work/ne228-menu-native-pair-v1: forced quit-after bypassed Main shutdown; 4 ObjectDB/1 resource messages retained'))
try:
 for label,data in [('before',before),('after',after)]:
  case=OUT/label;case.mkdir();target.write_bytes(data);(case/'executed-main_menu.gd').write_bytes(data);env=os.environ.copy()
  for key,part in [('APPDATA','roaming'),('LOCALAPPDATA','local')]:
   p=case/'user'/part;p.mkdir(parents=True);env[key]=str(p)
  command=[sys.executable,str(ROOT/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(PROJECT),'--windowed','--resolution','1280x720','--fixed-fps','30','res://work/ne228-menu-native-pair-v2/probe.tscn','--','--output='+str(case/'menu').replace('\\','/')]
  save(case/'command-before.json',dict(command=command,cwd=str(PROJECT),source_before_sha256=sha(target),producer_sha256=sha(PROBE/'probe.gd')))
  start=time.monotonic()
  with (case/'process.log').open('xb') as f:proc=subprocess.run(command,cwd=PROJECT,env=env,stdout=f,stderr=subprocess.STDOUT)
  log=(case/'process.log').read_text(encoding='utf-8',errors='replace');errors=[line for line in log.splitlines() if re.search(r'SCRIPT ERROR|ERROR:|ObjectDB.*leak|resources still in use',line)]
  record=dict(exit=proc.returncode,seconds=time.monotonic()-start,error_lines=errors,sources_unchanged=target.read_bytes()==data,renderer_forward_plus='Forward+' in log,gpu_rx9070xt=bool(re.search(r'RX\s*9070\s*XT',log,re.I)),files={p.relative_to(case).as_posix():dict(sha256=sha(p),bytes=p.stat().st_size) for p in case.rglob('*') if p.is_file() and p.relative_to(case).parts[0]!='user'})
  save(case/'receipt.json',record)
  assert proc.returncode==0 and not errors and record['sources_unchanged'] and record['renderer_forward_plus'] and record['gpu_rx9070xt'],'native real-menu observation rejected; raw preserved'
  observation=json.loads((case/'menu.json').read_bytes());assert observation['button_focused'] and observation['tooltip']==observation['focus_hint'] and observation['hdr_2d'] and observation['png_status']==0
  print(label,'actual Main menu captured and quit cleanly',flush=True)
finally:
 target.write_bytes(after)
