extends ScenarioBase

const AREAS := {
	"ch1_street": Vector2(1064, 512),
	"ch1_warehouse": Vector2(604, 784),
	"ch1_vault": Vector2(1160, 208),
}

var _enemy: Enemy
var _records: Dictionary = {}
var _changes: Array = []
var _active := ""


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	for area: String in AREAS:
		await _visit(area, AREAS[area])
	var size := get_window().size
	var report := {"records": _records, "failures": failures, "size": [size.x, size.y],
		"adapter": RenderingServer.get_video_adapter_name()}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)


func _visit(area: String, expected: Vector2) -> void:
	_active = area
	_changes.clear()
	GameState.start_new_run(GameState.difficulties[1])
	var data := load("res://data/levels/%s.tres" % area) as LevelData
	level = Level.new()
	level.configure(data)
	add_child(level)
	player = level.player
	level._next_story_trigger = level._layout.story_triggers.size()
	level.hud.visible = false
	for child in level.get_children():
		if child is ChapterCard:
			child.queue_free()
	var nearest := 32.0
	_enemy = null
	for node in level._entities.get_children():
		var child := node as Enemy
		if child != null and child.data.id == &"sweeper":
			var distance := child.global_position.distance_to(expected)
			if distance < nearest:
				_enemy = child
				nearest = distance
	if not _check(_enemy != null and _enemy.rig != null and _enemy.rig.skin_id == "sweeper", "find the authored Sweeper and dedicated rig"):
		await finish()
		return
	for node in level._entities.get_children():
		var other := node as Enemy
		if other == null or other == _enemy:
			continue
		other.set_physics_process(false)
		other.hurtbox.enabled = false
		for part: Hurtbox in other.hurtbox.parts:
			part.enabled = false
		if other.contact != null:
			other.contact.active = false
	player.health.grant_invulnerability(30.0)
	await settle(5)
	_records[_active] = {"source": data.resource_path, "spawn": [_enemy.global_position.x, _enemy.global_position.y], "frames": {}}
	var start := _enemy.global_position
	var player_spot := Vector2.ZERO
	var attempts := []
	var saw_player := false
	var camera := level.camera
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	for shift in [-108.0, 108.0, -76.0, 76.0, -55.0, 55.0]:
		var x: float = start.x + shift
		var ground := player.get_world_2d().direct_space_state.intersect_ray(
			PhysicsRayQueryParameters2D.create(Vector2(x, start.y - 5), Vector2(x, start.y + 34), Layers.SOLID))
		if ground.is_empty():
			continue
		player_spot = ground.position - Vector2(0.0, 0.25)
		player.global_position = player_spot
		player.velocity = Vector2.ZERO
		camera.global_position = (start + player_spot) * 0.5 + Vector2(0, -20)
		camera.reset_smoothing()
		camera.force_update_scroll()
		if await _until(func() -> bool: return _enemy.fsm.is_in(&"aim"), 45):
			saw_player = true
			break
		attempts.append({"x": x, "ground": [player_spot.x, player_spot.y], "player": str(player.global_position),
			"enemy": str(_enemy.global_position), "visible": _enemy.call(&"_can_see_target", 200.0, 50.0),
			"process": int(_enemy.process_mode)})
		player_spot = Vector2.ZERO
	_records[_active]["approach_attempts"] = attempts
	if not _check(saw_player, "acquire the player naturally from unobstructed ground"):
		await finish()
		return
	_enemy.health.damaged.connect(func(info: DamageInfo) -> void:
		_changes.append({"source": String(info.source_id), "health": _enemy.health.current, "team": int(info.team)}))
	await _sample("tracking")
	_check(await _until(func() -> bool: return _enemy.fsm.is_in(&"aim") and _enemy.call(&"_is_locked"), 60), "complete natural aim lock")
	await _sample("locked")
	_check(await _until(func() -> bool: return _enemy.fsm.is_in(&"recover"), 60), "shoot and recover naturally")
	_check(ProjectilePool.active_count() > 0, "the shot spawns a real projectile")
	await _sample("shot")
	_check(await _until(func() -> bool: return _enemy.fsm.is_in(&"patrol"), 60), "start patrol again")
	await _sample("patrol")
	await _shoot_once()
	_check(_changes.size() >= 1 and _enemy.health.current > 0, "player fire hits and leaves a live target")
	await _sample("hit")
	for index in range(5):
		if not is_instance_valid(_enemy) or _enemy.is_dying():
			break
		await wait(0.32)
		await _shoot_once()
	_check(is_instance_valid(_enemy) and _enemy.is_dying(), "player fire defeats the target")
	await _sample("defeated")
	await settle(22)
	await _sample("drop")
	var credits := 0
	for child in level._entities.get_children():
		if child is CreditPickup and child.cell == Vector2i(-1, -1):
			credits += child.value
	_records[_active]["credit_value"] = credits
	_records[_active]["hits"] = _changes.duplicate()
	_records[_active]["kills"] = GameState.kills
	_check(credits == 8 and GameState.kills == 1, "one kill creates an eight-credit pickup")
	await finish()


func _until(condition: Callable, frames: int) -> bool:
	for frame in range(frames):
		if condition.call():
			return true
		await get_tree().process_frame
	return false


func _shoot_once() -> void:
	var old_hits := _changes.size()
	var target := _enemy.hurtbox.center()
	var motion := InputEventMouseMotion.new()
	motion.position = get_viewport().get_final_transform() * player.get_canvas_transform() * target
	motion.global_position = motion.position
	Input.parse_input_event(motion)
	Input.warp_mouse(motion.position)
	await settle(2)
	Input.action_press(&"shoot")
	await settle(2)
	Input.action_release(&"shoot")
	_check(await _until(func() -> bool: return _changes.size() > old_hits, 30), "a normal weapon projectile reaches the Sweeper")


func _sample(label: String) -> void:
	await RenderingServer.frame_post_draw
	var frame := {"player": [player.global_position.x, player.global_position.y]}
	if is_instance_valid(_enemy):
		var screen := _enemy.get_global_transform_with_canvas().origin
		var tint: float = _enemy.rig.get("_fill")
		var render_tint: Color = (_enemy.rig.get("_skeleton") as CanvasItem).modulate
		frame.merge({"anchor": [screen.x, screen.y], "state": str(_enemy.fsm.current), "health": _enemy.health.current,
			"facing": _enemy.facing, "fill": tint, "hit_modulate": render_tint.r, "dying": _enemy.is_dying()})
	_records[_active]["frames"][label] = frame
	capture("%s-%s" % [_active, label])


func _check(condition: bool, message: String) -> bool:
	if not condition:
		failures += 1
		push_error("%s: %s" % [_active, message])
	return condition
