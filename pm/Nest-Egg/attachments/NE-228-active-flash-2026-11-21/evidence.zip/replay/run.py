from hashlib import sha256
from pathlib import Path
import json
import math
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
label = sys.argv[1]
out = base / label
out.mkdir()
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    path = out / key
    path.mkdir()
    env[key] = str(path)
paths = ["game/level/post_process.gd","game/level/post_process.gdshader","data/feel/screen_fx.json","autoload/settings.gd",
         "game/player/player.gd","core/flash_guard.gd","ui/pause_menu.gd","ui/settings_screen.gd","data/levels/ch1_warehouse.tres","data/projectiles/watchdog_bark.tres"]
sha = lambda path: sha256(path.read_bytes()).hexdigest()
source = {p:sha(game / p) for p in paths}
argv = [sys.executable,"-B",str(game/"tools/comfyui/gpu_lock.py"),"--",
        "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(game),
        "--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy",
        "--fixed-fps","60","--resolution","1280x720","--quit-after","3300",str(base/"observe.tscn"),"--",f"--out={out}"]
(out/"command.json").write_text(json.dumps({"argv":argv,"source":source},indent=2)+"\n",encoding="utf-8")
with (out/"engine.log").open("wb") as log:
    proc = subprocess.run(argv,cwd=game,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=230)
raw=(out/"engine.log").read_text(encoding="utf-8",errors="replace")
print(raw[-8000:],flush=True)
report = json.loads((out/"result.json").read_bytes())
assert all(sha(game/p)==digest for p,digest in source.items())
assert proc.returncode==0 and not re.search(r"^SCRIPT ERROR:|^ERROR:",raw,re.M), (proc.returncode,report["failures"])
assert report["hdr"] and "9070 XT" in report["adapter"] and not report["failures"]
rows = {(row["mode"],row["label"]): row for row in report["rows"]}
assert len(rows)==14 and len(list(out.glob("*.png")))==14
for mode in ("default-high","reduced-high"):
    pre, first, back, resumed, restored, new=(rows[mode,k] for k in ("paused","toggle-first","toggle-back","resumed","restored","new-cue"))
    assert pre["amount"]>0 and pre["time"]==first["time"]==back["time"] and resumed["time"]<pre["time"]
    assert pre["paused"] and first["paused"] and back["paused"] and not resumed["paused"]
    assert pre["sources"]==first["sources"]==back["sources"]==["watchdog_bark"]
    assert pre["health"]==first["health"]==back["health"]==resumed["health"]==4 and pre["flash_count"]==first["flash_count"]==back["flash_count"]==1
    assert restored["amount"]==0 and new["amount"]>0
    values=("amount","chromatic","vignette")
    if label.startswith("stock"):
        assert pre["amount"]==first["amount"]==back["amount"] and pre["amount"]>0
    else:
        factor=1 if mode.startswith("reduced") else 0.25
        assert all(math.isclose(first[k],pre[k]*factor,rel_tol=1e-6) and math.isclose(back[k],first[k],rel_tol=1e-6) for k in values)
    print(mode, [row["amount"] for row in (pre, first, back, resumed)], flush=True)
print("Actual display setting toggled twice for original incoming damage over the frozen Warehouse.",flush=True)
