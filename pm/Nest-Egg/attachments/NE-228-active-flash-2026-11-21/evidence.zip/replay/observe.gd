extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const WAREHOUSE := preload("res://data/levels/ch1_warehouse.tres")
const BARK := preload("res://data/projectiles/watchdog_bark.tres")

var _out := ""
var _rows: Array[Dictionary] = []
var _failures: Array[String] = []


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://active-flash-fixture.cfg")
	Settings.set_brightness(0.5)
	Story.auto_skip = true
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	for mode: String in ["default-high", "reduced-high"]:
		await _observe(mode)
	var file := FileAccess.open(_out.path_join("result.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"adapter":RenderingServer.get_video_adapter_name(),
		"hdr":get_viewport().use_hdr_2d,"rows":_rows,"failures":_failures},"  "))
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(not _failures.is_empty()))


func _observe(mode: String) -> void:
	seed(95044)
	Settings.set_reduce_flashes(mode.begins_with("reduced"))
	Settings.set_light_quality(LightQuality.Tier.HIGH if mode.ends_with("high") else LightQuality.Tier.LOW)
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(WAREHOUSE)
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(level)
	for frame in 200:
		if level.is_initialized():
			break
		await get_tree().process_frame
	var player := level.player
	var post := level._post
	var dog: PatternBoss
	for node in level._entities.get_children():
		if node is Enemy:
			if node is PatternBoss and node.data.id == &"watchdog":
				dog = node
			node.process_mode = Node.PROCESS_MODE_DISABLED
	if dog == null or post == null or not post.is_active():
		_check(false, mode+" actual boss and screen pass exist")
		level.queue_free()
		await get_tree().process_frame
		return
	player.global_position = Vector2(840,780)
	player.velocity = Vector2.ZERO
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	camera.global_position = Vector2(917,733)
	camera.reset_smoothing()
	camera.force_update_scroll()
	level._lighting._lightning_gap = 1.0e9
	var sources: Array[String] = []
	player.health.damaged.connect(func(info: DamageInfo) -> void: sources.append(String(info.source_id)))
	for frame in 26:
		await get_tree().process_frame
	_check(player.health.current == 6 and not GameplayLock.is_locked(), mode+" original player and HUD become controllable")
	FlashGuard.reset()
	await _record(mode, "before", player, dog, post, sources)
	var hitbox := player.hurtbox.center()
	var spawned := WeaponSystem.fire_spread(BARK, hitbox + Vector2(66,0), Vector2.LEFT, 1,0,0,Combat.Team.ENEMY)
	_check(spawned == 1, mode+" original Watchdog bark projectile spawned through pool")
	for frame in 86:
		if not sources.is_empty() and float(post.parameter(&"pulse_amount")) > 0:
			break
		await get_tree().process_frame
	_check(sources == ["watchdog_bark"] and player.health.current == 4, mode+" real projectile hit removes two HP")
	_check(FlashGuard.accepted == 1 and post._pulse_time_total == 0.28, mode+" original hit passes flash budget")
	_press(&"pause")
	await get_tree().process_frame
	var menu := _find_pause(level)
	if menu == null or not get_tree().paused:
		_check(false, mode + " actual warehouse pause menu opens")
		return
	var settings_button: BaseButton
	for button in menu.find_children("*", "Button", true, false):
		if button is Button and button.text == "設定":
			settings_button = button
			break
	if settings_button == null:
		_check(false, mode + " actual pause menu has settings")
		return
	settings_button.grab_focus()
	_press(&"ui_accept")
	await get_tree().process_frame
	var options := menu._settings
	if options == null:
		_check(false, mode + " settings opened through button")
		return
	for index in options._tabs.get_tab_count():
		if options._tabs.get_tab_title(index) == "顯示":
			options._tabs.current_tab = index
			break
	await get_tree().process_frame
	options._reduce_flashes.grab_focus()
	for frame in 18:
		await get_tree().process_frame
	await _record(mode, "paused", player, dog, post, sources)
	_press(&"ui_accept")
	await _record(mode, "toggle-first", player, dog, post, sources)
	_check(Settings.get_reduce_flashes() != mode.begins_with("reduced"), mode+ " real display option changes")
	_press(&"ui_accept")
	await _record(mode, "toggle-back", player, dog, post, sources)
	_check(Settings.get_reduce_flashes() == mode.begins_with("reduced"), mode+ " real display option changes back")
	_press(&"ui_cancel")
	await get_tree().process_frame
	_check(menu._settings == null, mode + " settings closes through Esc")
	_press(&"pause")
	for frame in 2:
		await get_tree().process_frame
	await _record(mode, "resumed", player, dog, post, sources)
	_check(not get_tree().paused and player.health.current == 4, mode+ " ordinary resume keeps health")
	for frame in 80:
		if post._pulse_left == 0.0 and float(post.parameter(&"pulse_amount")) == 0.0:
			break
		await get_tree().process_frame
	await _record(mode, "restored", player, dog, post, sources)
	FlashGuard.reset()
	EventBus.screen_pulse.emit(&"parry")
	await _record(mode, "new-cue", player, dog, post, sources)
	level.queue_free()
	await get_tree().process_frame


func _find_pause(level: Level) -> PauseMenu:
	for child in level.get_children():
		if child is PauseMenu:
			return child
	return null


func _press(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	var release := InputEventAction.new()
	release.action = action
	Input.parse_input_event(release)



func _record(mode: String, label: String, player: Player, dog: PatternBoss, post: PostProcess, sources: Array[String]) -> void:
	await RenderingServer.frame_post_draw
	var file := "%s-%s.png" % [mode,label]
	_check(Capture.image(get_viewport()).save_png(_out.path_join(file))==OK,mode+" "+label+" capture")
	var mask = post.parameter(&"pulse_edge_mix") if post._cache.has(&"pulse_edge_mix") else 0.0
	var screen := get_viewport().get_canvas_transform()
	var visible_boss := screen * (dog.global_position + Vector2(0,-35))
	_rows.append({"mode":mode,"label":label,"file":file,"health":player.health.current,"boss":dog.health.current,
		"sources":sources.duplicate(),"amount":post.parameter(&"pulse_amount"),"edge":mask,
		"chromatic":post.parameter(&"pulse_aberration"),"vignette":post.parameter(&"pulse_vignette"),
		"time":post._pulse_left,"flash_count":FlashGuard.accepted,"reduced":Settings.get_reduce_flashes(),
		"boss_anchor":[visible_boss.x,visible_boss.y],"paused":get_tree().paused})


func _check(ok: bool, problem: String) -> void:
	if not ok:
		_failures.append(problem)