import importlib.util,json,os,pathlib,subprocess,time,hashlib
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026')
r=w/'handoff-baseline-9055'
state=w/'ne280-validation-progress.json'
def progress(stage):
 state.write_text(json.dumps({'stage':stage,'time':time.time()},indent=2)+'\n');print(stage,flush=True)
def run(tag,command,cwd,env):
 progress(tag)
 with (w/(tag+'.log')).open('w') as log:
  code=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 (w/(tag+'.exit')).write_text(str(code)+'\n')
 if code:raise RuntimeError(tag+' failed with '+str(code))
progress('waiting_for_live_build')
while not (w/'godot-audio-safe-build.exit').exists():time.sleep(3)
assert (w/'godot-audio-safe-build.exit').read_text().strip()=='0'
progress('verifying_exact_source_and_publishing_local_engine')
loader=importlib.util.spec_from_file_location('audio_build',r/'tools/godot_audio/build.py')
m=importlib.util.module_from_spec(loader);loader.loader.exec_module(m)
spec,patch,fingerprint=m.recipe();root=w/'godot-audio-build'
source,verified=m.prepare_source(root,w/'godot-source-ed1daf0bf.tar.gz',spec,patch)
m.prepare_accesskit(root,source,spec)
command=json.loads((w/'godot-build-command.json').read_text())['command']
compiler=subprocess.run(['g++','--version'],check=True,capture_output=True,text=True).stdout.splitlines()[0]
engine=m.publish(source,root,spec,fingerprint,command,verified,compiler)
assert m.verify_cached(root,fingerprint,spec)==engine
(w/'ne280-engine-receipt.json').write_bytes((root/'dist/receipt.json').read_bytes())
env=os.environ.copy();env.update(GODOT=str(engine),SHARDS='8')
run('ne280-builder-checks-final',['python','tools/godot_audio/test_build.py'],r,env)
run('ne280-engine-cache-verify',['python','tools/godot_audio/build.py','--work-dir',str(root),'--verify-only'],r,env)
run('ne280-audio-load-patched-v1',['python','tools/godot_audio/run_audio_load.py','--engine',str(engine),'--output',str(w/'audio-lifetime-patched-v1'),'--cases','8','--seconds','12'],r,env)
run('ne280-scope-final',['bash','tools/run_tests_changed.sh'],r,env)
env['LOG_DIR']=str(w/'ne280-full-v1-shards')
run('ne280-full-v1',['bash','tools/run_tests_parallel.sh'],r,env)
run('handoff-native-audiofix-v1',['python',str(w/'run_handoff_final_audiofix_v1.py')],w/'kitchen-worktree',env)
env['LOG_DIR']=str(w/'handoff-final-affected-audiofix-v1-shards')
run('handoff-final-affected-audiofix-v1',['bash','tools/run_tests_changed.sh'],w/'kitchen-worktree',env)
progress('all_required_local_tests_completed_review_visuals_before_delivery')
