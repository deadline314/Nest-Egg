extends Node2D

var voices: Array[AudioStreamPlayer2D] = []
var capture: AudioEffectCapture
var started := 0
var last_sample := 0
var samples_seen := 0
var peak := 0.0
var frames := 0
var seconds := 12.0
var output := ""

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			output = arg.trim_prefix("--out=")
		elif arg.begins_with("--seconds="):
			seconds = clampf(float(arg.trim_prefix("--seconds=")), 1.0, 60.0)
	Engine.max_fps = 500
	Engine.physics_ticks_per_second = 120
	capture = AudioEffectCapture.new()
	capture.buffer_length = 0.2
	AudioServer.add_bus_effect(0, capture)
	var data := PackedByteArray()
	data.resize(8820)
	for i in 4410:
		data.encode_s16(i * 2, roundi(sin(TAU * 220.0 * i / 44100.0) * 8192.0))
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = 44100
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_end = 4410
	stream.data = data
	var camera := Camera2D.new()
	camera.position = Vector2(320, 180)
	add_child(camera)
	for i in 32:
		var voice := AudioStreamPlayer2D.new()
		voice.stream = stream
		voice.volume_db = -30.0
		voice.max_distance = 2000.0
		voice.position = Vector2(320, 180)
		add_child(voice)
		voice.play()
		voices.append(voice)
	started = Time.get_ticks_msec()
	print("AUDIO_LIFETIME_BEGIN ", JSON.stringify({"engine": Engine.get_version_info(), "driver": AudioServer.get_driver_name(), "voices": voices.size(), "seconds": seconds}))

func _process(_delta: float) -> void:
	frames += 1
	var now := Time.get_ticks_msec()
	var elapsed := float(now - started) / 1000.0
	for i in voices.size():
		voices[i].position.x = 320.0 + sin(elapsed * 4.0 + i) * 120.0
		voices[i].volume_db = -30.0 + sin(elapsed * 3.0 + i)
	if now - last_sample >= 200:
		last_sample = now
		var available := capture.get_frames_available()
		if available > 0:
			var samples := capture.get_buffer(available)
			samples_seen += samples.size()
			for sample in samples:
				peak = maxf(peak, maxf(absf(sample.x), absf(sample.y)))
	if elapsed >= seconds:
		var result := {"frames": frames, "seconds": elapsed, "samples_seen": samples_seen, "peak": peak,
			"audio_active": samples_seen > 1024 and peak > 0.001, "engine": Engine.get_version_info()}
		print("AUDIO_LIFETIME_RESULT ", JSON.stringify(result))
		if not output.is_empty():
			var file := FileAccess.open(output, FileAccess.WRITE)
			file.store_string(JSON.stringify(result, "  "))
			file.close()
		get_tree().quit(0 if result["audio_active"] else 1)
