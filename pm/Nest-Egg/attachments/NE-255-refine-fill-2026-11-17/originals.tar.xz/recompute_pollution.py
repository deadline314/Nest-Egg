"""Recompute the exact reviewed HSV region; no source or product file is changed."""
import argparse
import hashlib
import json
from pathlib import Path

import cv2
import numpy as np
from PIL import Image


def measure(path):
    with Image.open(path) as image:
        assert image.mode == "RGBA" and image.size == (832, 1216), (path, image.mode, image.size)
        part = np.array(image)
    hsv = cv2.cvtColor(part[:, :, :3], cv2.COLOR_RGB2HSV)
    y, x = np.mgrid[:1216, :832]
    reviewed = (x >= 306) & (x < 337) & (y >= 385) & (y < 490)
    polluted = reviewed & (part[:, :, 3] > 127) & (hsv[:, :, 0] >= 130) & (hsv[:, :, 0] <= 175) & (hsv[:, :, 1] > 45)
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "polluted_pixels_in_reviewed_area": int(polluted.sum()), "coordinates_yx": np.argwhere(polluted).tolist()}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--before", required=True, type=Path)
    parser.add_argument("--after", required=True, type=Path)
    args = parser.parse_args()
    result = {"opencv_version": cv2.__version__, "dimensions": [832, 1216],
              "bbox_xyxy_end_exclusive": [306, 385, 337, 490],
              "conversion": "cv2.COLOR_RGB2HSV; uint8 OpenCV H=0..179, S/V=0..255",
              "predicate": "alpha > 127 AND 130 <= H <= 175 AND S > 45; V unrestricted",
              "before": measure(args.before), "candidate": measure(args.after)}
    print(json.dumps(result, indent=2))
