extends Node

func _ready() -> void:
	_run.call_deferred()

func _run() -> void:
	var options := {}
	for raw in OS.get_cmdline_user_args():
		var bits := raw.split("=", true, 1)
		if bits.size() == 2:
			options[bits[0]] = bits[1]
	var out: String = options.get("--out", "").replace("\\", "/")
	if not out.is_absolute_path() or options.get("--role") not in ["import", "blocked"]:
		get_tree().quit(2)
		return
	var locale: String = options["--story-language"]
	var role: String = options["--role"]
	var edition := CampaignEdition.current().describe("through-ch2_heron")
	edition.version = "0.1.261112-candidate"
	CampaignEdition.override_current(edition)
	Settings.set_ui_text_scale(1.2)
	Transition.instant = true
	var main := preload("res://game/main.gd").new()
	add_child(main)
	for i in 100:
		await get_tree().process_frame
	var menu := main.get("_screen") as MainMenu
	if menu == null:
		push_error("real main menu did not load")
		get_tree().quit(1)
		return
	var notice: Label
	var version: Label
	for candidate in menu.find_children("*", "Label", true, false):
		var label := candidate as Label
		if label.text == menu.save_notice:
			notice = label
		elif label.text.begins_with(edition.version):
			version = label
	if notice == null or version == null:
		push_error("missing compatibility or version label")
		get_tree().quit(1)
		return
	var next_button: Button = menu.get("_continue_button")
	var height := notice.get_line_height() * notice.get_line_count()
	var view := get_viewport().get_visible_rect()
	var content := {
		"locale": Story.language,
		"role": role,
		"edition": edition.id,
		"text_scale": Settings.get_ui_text_scale(),
		"notice": notice.text,
		"notice_height": height,
		"available_height": notice.size.y,
		"version_label": version.text,
		"continue_visible": next_button != null and next_button.visible,
		"continue_label": next_button.text if next_button != null else "",
		"hover": next_button.tooltip_text if next_button != null else "",
		"fits": notice.visible and version.visible and view.encloses(notice.get_global_rect())
			and view.encloses(version.get_global_rect()) and (height <= notice.size.y + 0.5),
		"adapter": RenderingServer.get_video_adapter_name(),
	}
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	if image.save_png(out.path_join("menu.png")) != OK:
		push_error("writing menu evidence failed")
		get_tree().quit(1)
		return
	FileAccess.open(out.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify(content,"\t"))
	print("NE228_SAVE_NOTICE ", locale, " ", role, " fits=", content["fits"], " continue=", content["continue_visible"])
	main.call("_quit")
