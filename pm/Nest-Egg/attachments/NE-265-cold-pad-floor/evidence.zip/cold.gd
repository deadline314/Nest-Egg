extends Node
## Exact original primary from an explicitly declared terminal-state fixture.
var _main: Node
var _slot := ""
var _out := ""
var _checks := 0
var _failures: Array[String] = []
var _pads: Array[Dictionary] = []
func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="): _slot = arg.trim_prefix("--save-dir=")
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Transition.instant = true
	_run.call_deferred()
func _check(ok: bool, what: String) -> void:
	_checks += 1
	print("PASS " + what if ok else "FAIL " + what)
	if not ok: _failures.append(what)
func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_slot.path_join("slot.json")))
	add_child(_main)
	for i in 8: await get_tree().physics_frame
	_main.call("_on_continue_requested")
	var level := _main.get("_screen") as Level
	_check(level != null and level.data.id == &"ch2_ledger_office", "real Main cold-loads the exact original office primary")
	if level == null: _done(); return
	var boss: PatternBoss
	for node: Node in level.channel_sources:
		if is_instance_valid(node) and node is PatternBoss and node.data.id == &"yong": boss = node
	_check(boss != null, "the original non-completed boss is restored")
	if boss == null: _done(); return
	for i in 12: await get_tree().physics_frame
	_check(boss.is_awake() and boss.mark != null and boss.mark.active, "cold original proximity wakes the real boss and activates its original pads")
	for index in boss.mark.pad_count():
		var at := boss.mark.pad_position(index)
		var pad: Dictionary = boss.mark._pads[index]
		var start_y := float(pad["row"]) * 16.0 - 8.0 if int(pad["row"]) >= 0 else boss.global_position.y - 24.0
		var expected := level._layout.floor_below(int(at.x / 16), ceili(start_y / 16.0))
		_pads.append({"index": index, "row": pad["row"], "position": [at.x, at.y], "expected_y": expected})
		_check(at.is_finite() and is_equal_approx(at.y, expected), "cold pad rests on its original authored ground: %d" % index)
	_check(not GameState.has_flag(&"ch2_yong_subdued") and not level.player.is_dead(), "restoration does not complete or kill either original participant")
	if DisplayServer.get_name() != "headless":
		level.camera.set_process(false)
		level.camera.position_smoothing_enabled = false
		level.camera.position = Vector2(512, 280)
		level.camera.reset_smoothing()
		for i in 4: await get_tree().physics_frame
		var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
		DirAccess.make_dir_recursive_absolute(_out)
		image.save_png(_out.path_join("pads.png"))
	_done()
func _done() -> void:
	DirAccess.make_dir_recursive_absolute(_out)
	FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify({"checks": _checks, "failures": _failures, "pad_samples": _pads}, "  "))
	_main.call("_quit", 0 if _failures.is_empty() else 1)
