extends Node

const CAPTURE := preload("res://tools/viewport_capture.gd")
const PUMP := preload("res://data/levels/ch3_pump.tres")
var _out := ""
var _language := "zh"
var _trimmed_expected := false

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--language="):
			_language = arg.trim_prefix("--language=")
		elif arg == "--trims":
			_trimmed_expected = true
	_run.call_deferred()

func _run() -> void:
	Story.set_language(_language)
	TranslationServer.set_locale(_language)
	Story.auto_skip = true
	Settings.set_ui_text_scale(1.2)
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch3_departure_done")
	GameState.set_flag(&"ch3_interlock_seen")
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(PUMP)
	add_child(level)
	for i in 35:
		await get_tree().process_frame
	var guidance := level.hud.quest_guidance
	var label := guidance._label
	var font := label.get_theme_font(&"font")
	var font_size := label.get_theme_font_size(&"font_size")
	var width := font.get_string_size(label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	var trims := width > label.size.x
	var step := QuestCatalog.current_step(guidance._target, GameState.world_flags)
	var actual: Dictionary = step.get("location", {})
	var displayed := guidance._row.visible and label.visible and guidance._row.modulate.a >= 0.99
	var cell: Array = actual.get("cell", [])
	var target_ok: bool = step.get("complete_flag") == "ch3_pump_low" and actual.get("level") == PUMP.resource_path and cell.size() == 2 and int(cell[0]) == 30 and int(cell[1]) == 28
	var full_tooltip: bool = guidance._row.tooltip_text.begins_with(QuestCatalog.display_text(step,"title"))
	var ok: bool = displayed and trims == _trimmed_expected and target_ok and full_tooltip
	await RenderingServer.frame_post_draw
	CAPTURE.image(get_viewport()).save_png(_out.path_join("pump-objective.png"))
	var result := {"valid":ok,"locale":_language,"label":label.text,"font_size":font_size,"width":width,"available":label.size.x,
		"visible":displayed,"trims":trims,"cell":actual,"flag":step.get("complete_flag"),"whole_tooltip":full_tooltip,
		"adapter":RenderingServer.get_video_adapter_name()}
	FileAccess.open(_out.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
	print(result)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if ok else 1)
