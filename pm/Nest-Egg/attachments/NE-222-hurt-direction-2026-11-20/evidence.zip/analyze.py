from pathlib import Path
import json
import math

base = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_bytes())
parent = (base / 'baseline.txt').read_text().strip()
previous = read(base.parent / 'evidence-20261120-ne95-watchdog-phase-flash/published-source.json')
source = read(base / 'source.json')
runtime = read(base / 'runtime.json')
states = ('state', 'face', 'ground', 'origin', 'velocity', 'weapon', 'health', 'guard',
          'shield', 'broken', 'projectile')
outcomes = ('hurt', 'block', 'parry', 'break', 'rear')
summary = {}


def load(label, name):
    folder = base / label / name
    trace = read(folder / 'trace.json')
    assert len(trace['trace']) == 49 and trace['rendering_method'] == 'forward_plus' and trace['hdr']
    assert [row['i'] for row in trace['trace']] == list(range(49))
    assert trace['failures'] == (1 if label == 'rear-control-final' else 0)
    return trace


def verify_source(label, name, manifest):
    run = read(base / label / name / 'command.json')
    assert run['source'] == parent
    assert run['worktree_sha256'] == {path: manifest[path] for path in runtime}


for outcome in outcomes:
    for side in (-1, 1):
        for zoom in (0.0, 3.4):
            name = f'{outcome}-{side}-{zoom}'
            baseline = 'rear-control-final' if outcome == 'rear' else 'stock'
            old = load(baseline, name)
            new = load('candidate', name)
            verify_source('candidate', name, source)
            if outcome == 'rear':
                verify_source(baseline, name, previous)
            before, after = old['trace'], new['trace']
            assert old['parries'] == new['parries'] == (1 if outcome == 'parry' else 0), name
            comparison = []
            for a, b in zip(before, after, strict=True):
                assert all(math.isfinite(part) for joint in b['bones'].values() for part in joint), name
                for field in states:
                    if a[field] != b[field]:
                        comparison.append([a['i'], field, a[field], b[field]])
            assert not comparison, (name, comparison[:8])
            shoe_depth = max(value for row in after for value in row['boot_depth'])
            assert shoe_depth < 2.10, (name, shoe_depth)
            evidence = {'checks': len(after), 'max_part_below_floor': shoe_depth, 'pose_compared': len(after)}
            if outcome == 'rear':
                hit = next(index for index, row in enumerate(after) if row['health'] < after[0]['health'])
                assert before[hit + 4]['hurt_dir'] == 1 and after[hit + 4]['hurt_dir'] == -1
                chest = lambda row: row['bones']['chest'][2]
                base_chest = chest(before[0])
                old_delta = math.degrees(chest(before[hit + 4]) - base_chest)
                new_delta = math.degrees(chest(after[hit + 4]) - chest(after[0]))
                assert new_delta - old_delta > 2.0, (name, old_delta, new_delta)
                evidence.update(hit_frame=hit, frame=hit + 4, old_chest_delta=old_delta, new_chest_delta=new_delta)
            else:
                assert all(a['bones'] == b['bones'] for a, b in zip(before, after, strict=True)), name
            summary[name] = evidence
            print(name, evidence)
(Path(__file__).resolve().parent / 'results.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
