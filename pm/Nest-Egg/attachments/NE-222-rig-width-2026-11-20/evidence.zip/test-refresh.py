from pathlib import Path
from hashlib import sha256
from statistics import median
import json, os, re, subprocess

base=Path(__file__).resolve().parent
root=base.parent/'ne218-baseline-20261117'
mesh='game/rig/rig_part_mesh.gd'
target=root/mesh
old_evidence=base.parent/'evidence-20261120-ne222-rig-budget'
release=base.parent/'evidence-20261120-ne223-locale-width'
receipt=json.loads((release/'publish/result.json').read_bytes())
manifest=json.loads((release/'published-source.json').read_bytes())
digest=lambda path: sha256(path.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==receipt['commit']
assert all(digest(root/file)==expected for file, expected in manifest.items())
before=target.read_bytes()
after=(base/'refresh.gd').read_bytes()

def run(name, variant, kind='speed'):
    target.write_bytes(variant)
    out=base/name
    out.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
        (out/key).mkdir()
        env[key]=str(out/key)
    scenes={'geometry': str(old_evidence/'geometry.tscn'),
            'speed': 'res://tools/rig_perf_probe.tscn',
            'memory': str(old_evidence/'memory.tscn')}
    flags={'geometry':['--bytes='+str(out/'trajectory.dat')],
           'speed':['--count=10','--frames=1800','--skin=rin'],'memory':[]}
    command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--audio-driver','Dummy',
             '--path',str(root),scenes[kind],'--',*flags[kind]]
    with (out/'engine.log').open('wb') as log:
        proc=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    raw=(out/'engine.log').read_text(encoding='utf-8',errors='replace')
    assert proc.returncode==0 and not re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit',raw,re.M),raw[-2500:]
    if kind=='geometry':
        return digest(out/'trajectory.dat')
    if kind=='memory':
        return json.loads(raw.split('RIG_MEMORY ',1)[1].splitlines()[0])
    match=re.search(r'剛體 ([\d.]+) µs/格，關節網格 ([\d.]+) µs/格.*每隻多 ([\d.]+) µs.*網格頂點 (\d+)',raw)
    assert match,raw[-2500:]
    rigid_time,mesh_time,extra,vertices=match.groups()
    return {'rigid':float(rigid_time),'mesh':float(mesh_time),'extra_us':float(extra),'vertices':int(vertices)}

try:
    shape=run('candidate-geometry',after,'geometry')
    assert shape==digest(old_evidence/'reference-geometry.dat'),shape
    memory=run('candidate-memory',after,'memory')
    warm={label:run('warm-'+label,variant) for label,variant in [('before',before),('after',after)]}
    variants=[('before',before),('after',after)]
    pairs=[]
    for index in range(6):
        ordered=variants if index%2==0 else list(reversed(variants))
        pair={label:run(f'pair-{index+1}-{label}',variant) for label,variant in ordered}
        pairs.append(pair)
        print(index+1,pair,flush=True)
    pair_differences=[line['after']['extra_us']-line['before']['extra_us'] for line in pairs]
    mesh_differences=[line['after']['mesh']-line['before']['mesh'] for line in pairs]
    after_median=median(line['after']['extra_us'] for line in pairs)
    report={'before':sha256(before).hexdigest(),'after':sha256(after).hexdigest(),'geometry':shape,'memory':memory,
        'warm':warm,'pairs':pairs,'median_extra_change_us':median(pair_differences),'median_total_mesh_change_us':median(mesh_differences),
        'candidate_median_us':after_median,'historical_target_us':36.15}
    (base/'proof.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report),flush=True)
finally:
    target.write_bytes(before)
    assert all(digest(root/file)==expected for file,expected in manifest.items())
