from pathlib import Path
from subprocess import run, check_output, STDOUT
import hashlib,json,os,re,sys
from PIL import Image,ImageChops
p=Path(__file__).resolve().parent
root=p.parent/'ne218-baseline-20261117'
base=p.parent/'evidence-20261120-ne223-locale-width'
file='game/rig/rig_part_mesh.gd'
manifest=json.loads((base/'published-source.json').read_bytes())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert all(sha(root/name)==digest for name,digest in manifest.items())
assert check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==json.loads((base/'publish/result.json').read_bytes())['commit']
before=(root/file).read_bytes()
candidate=(p/'refresh.gd').read_bytes()
exe=r'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
folder=p/'native'
folder.mkdir()
results={}
try:
    for tag,code in [('before',before),('after',candidate)]:
        (root/file).write_bytes(code)
        for direction in ['left','right']:
            out=folder/f'{tag}-{direction}'
            out.mkdir()
            env=os.environ.copy()
            for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
                (out/key).mkdir()
                env[key]=str(out/key)
            cmd=[sys.executable,str(root/'tools/comfyui/gpu_lock.py'),'--',exe,'--path',str(root),'--fixed-fps','60',
                 'res://tools/rig_preview.tscn','--','--out='+str(out/'rin.png'),'--chars=rin','--cloth','--bright']
            if direction=='left': cmd.append('--left')
            with (out/'engine.log').open('wb') as log:
                proc=run(cmd,cwd=root,env=env,stdout=log,stderr=STDOUT,timeout=120)
            capture=(out/'engine.log').read_text(encoding='utf-8')
            if proc.returncode!=0 or re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit',capture,re.M):
                raise RuntimeError(capture[-2500:])
            assert (out/'rin.png').is_file()
            results[f'{tag}-{direction}']={'command':cmd,'sha256':sha(out/'rin.png')}
    for direction in ['left','right']:
        a=Image.open(folder/f'before-{direction}/rin.png').convert('RGBA')
        b=Image.open(folder/f'after-{direction}/rin.png').convert('RGBA')
        assert a.tobytes()==b.tobytes(),direction
    (folder/'result.json').write_text(json.dumps({'same_rendered_pixels':True,'cases':results},indent=2)+'\n')
    print('four native frames, exact equality for both faces',flush=True)
finally:
    (root/file).write_bytes(before)
    assert all(sha(root/name)==digest for name,digest in manifest.items())

