from pathlib import Path
import subprocess,json,hashlib,zipfile,shutil,re
root=Path.cwd();work=root/'work/ne228-bubbles';out=root/'pm/Nest-Egg/attachments/NE-228-world-text';out.mkdir(parents=True,exist_ok=True);base=Path('/workspace/Nest-Egg/work/batch1020b');sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads((work/'delivery-receipt.json').read_text());assert receipt['exit_code']==0
for p,h in json.loads((work/'delivery-frozen-source.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
native=json.loads((work/'final-native-validation.json').read_text());assert [r['failures'] for r in native]==[7,0,0,0];assert all(r['completed'] and r['engine_errors']==0 and r['leaks']==0 and r['individually_viewed'] for r in native)
assert all(x['original_checks_byte_exact'] for x in json.loads((work/'original-tests-reconstruction.json').read_text()))
text=(work/'delivery-changed.log').read_text();assert 'new failures: 0' in text and 'known failures' in text and 'Detected script errors' not in text
files={}
for p in work.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in x or x=='__pycache__' for x in p.relative_to(work).parts):files['work/ne228-bubbles/'+str(p.relative_to(work))]=p.read_bytes()
for d in sorted(base.glob('ne228-1022-world-text*')):
 if d.is_dir() and not d.name.endswith('-profile'):
  for p in d.rglob('*'):
   if p.is_file():files['native/'+d.name+'/'+str(p.relative_to(d))]=p.read_bytes()
 elif d.is_file():files['native/'+d.name]=d.read_bytes()
paths=list(json.loads((work/'delivery-frozen-source.json').read_text()))+['ui/quest_guidance.gd','game/main.gd','scenes/main.tscn','tools/viewport_capture.gd','tests/helpers/contextual_priority_checks.gd','tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt','design/20-campaign-experience/WORLD_TEXT_READABILITY.md']
for p in paths:files['source/final/'+p]=(root/p).read_bytes()
for p in ['game/level/world_prompt.gd','game/level/map_bubbles.gd','game/level/prompt_layout.gd','tests/suite/test_world_prompt.gd','tests/suite/test_map_bubbles.gd','tools/quest_resume_probe.gd']:
 files['source/before/'+p]=subprocess.check_output(['git','show','59c2642e:'+p])
for p in ['tests/helpers/contextual_priority_checks.gd','tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']:
 assert (root/p).read_bytes()==subprocess.check_output(['git','show','59c2642e:'+p]),p
validation={'tested_code_base':'7bf96cfb95fcec3cbb609aea0658ab547e59068d','integration_docs':'456471960eac10ad46b6973cf0d6bfd071ad6245','affected_receipt':receipt,'affected_summary':[l for l in text.splitlines() if 'checks:' in l or 'Running 60' in l],'native':native,'original_bubble_only_negative':'32 checks, 6 expected failures; old MapBubbles with final surrounding layout','original_two_test_suites_byte_exact':True,'additional_checks':14,'original_contextual_priority_helper_and_harness_unchanged':True,'all_final_native_pngs_individually_viewed':24,'research':'9 actual Steam images individually viewed; Night in Woods forest and Oxenfree cave show multiline; remaining images composition only; official Godot4.7 TextParagraph XML source after docs site403','history':'v1 short booth selected; v2 actual long sign and EN/JA fixtures exposed goal overlap and framing blackbar; v3 visually passed but baseline full regression failed once; metadata corrected retaining original assertions,475 passed; v4 final native follows PAUSABLE shared observer; work import class collision and rejected checks preserved','scope':'native software Vulkan Forward+ with public UI actions; authored ZH conversation/sign, EN/JA explicit rendering fixtures, held player physics for stable sign composition; not full chapters, human hardware or entire NE228 acceptance'}
(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for p,b in files.items():assert sha(z.read(p))==sha(b)
manifest={'archive_bytes':(out/'raw.zip').stat().st_size,'archive_sha256':sha((out/'raw.zip').read_bytes()),'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for case,src,dest in [('before','authored-ambient','before-bubble'),('after','authored-ambient','after-bubble'),('before','authored-booth','before-sign'),('after','authored-booth','after-sign'),('1080','authored-booth','1080-sign'),('smooth','authored-booth','smooth-sign'),('after','fixture-english','fixture-en'),('after','fixture-japanese','fixture-ja')]:shutil.copyfile(base/('ne228-1022-world-text-v4-'+case)/(src+'.png'),root/('pm/Nest-Egg/images/NE-228-world-text-'+dest+'.png'))
for app in ['481510','388880']:shutil.copyfile(work/('references/'+app+'-1.jpg'),root/('pm/Nest-Egg/images/NE-228-world-text-ref-'+app+'.jpg'))
summary={'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256'],'validation':validation};(work/'package-receipt.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
