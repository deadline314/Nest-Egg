extends "res://work/ne228-bubbles/phone_base.gd"

func _save_report() -> void:
	FileAccess.open(out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify({"completed": _completed, "failures": _failures, "rows": rows, "scope": "formal Main and authored home/booth, arranged routing/positions; explicit extra language fixtures; software Forward+ and public pause, not human chapter or physical hardware"}, "\t"))

func _capture(name: String) -> void:
	await _shot(name)
	var viewport := get_viewport()
	var view := viewport.get_canvas_transform().affine_inverse() * Rect2(Vector2.ZERO, viewport.get_visible_rect().size)
	rows[-1]["view"] = [view.position.x, view.position.y, view.size.x, view.size.y]
	rows[-1]["prompts"] = []
	for prompt: WorldPrompt in PromptLayout._prompts:
		if not _level().is_ancestor_of(prompt) or not prompt.is_showing():
			continue
		var box := Rect2(prompt.base_rect().position + prompt._nudge, prompt.base_rect().size)
		rows[-1]["prompts"].append({"text": prompt._display_text, "box": [box.position.x, box.position.y, box.size.x, box.size.y]})
		_check(view.grow(0.5).encloses(box), "visible invitation stays fully inside the current view")
		_check(box.size.x <= view.size.x * 0.6, "visible invitation keeps room for gameplay")
	_save_report()

func _calm() -> void:
	for i in 6:
		await get_tree().process_frame
	var deadline := Time.get_ticks_msec() + 60000
	while Time.get_ticks_msec() < deadline:
		if Story._layer.is_radio_frozen() or Story.is_cinematic_active():
			await _read_to_end()
		if not DialogueLayer.radio_visible() and not Story.is_cinematic_active() and Story._layer._radio_queue.is_empty() and not GameplayLock.is_locked():
			return
		await get_tree().process_frame
	_check(false, "authored reading actually ends before world text inspection")

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	Settings.set_ui_text_scale(1.0)
	Settings.set_ui_font("pixel")
	for arg in OS.get_cmdline_user_args():
		if arg == "--1080":
			get_window().size = Vector2i(1920, 1080)
			DisplayMode.ensure_scaling(get_window())
			Settings.set_ui_text_scale(1.2)
		elif arg == "--smooth":
			Settings.set_ui_font("smooth")
			Settings.set_ui_text_scale(1.2)
	await _until(func() -> bool: return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested", GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE), "real Main starts the formal run")
	await _skip_cinematics()
	await _enter(PAWNSHOP)
	var old_k: NpcActor
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and _level().is_ancestor_of(node) and node.data.id == &"ch1_old_k":
			old_k = node
	_check(old_k != null, "authored Old K is present")
	if old_k == null:
		return
	_level().player.global_position = old_k.global_position + Vector2(-65, 0)
	_level().camera.snap_to_target()
	var host := _level()._bubbles
	_check(await _until(func() -> bool: return host._active.any(func(b: Dictionary) -> bool: return str(b["text"]).length() > 20 and float(b["age"]) > 0.2 and not b["leaving"]), 20.0), "actual authored ambient sentence appears near its speaker")
	await _capture("authored-ambient")
	for bubble in host._active:
		if str(bubble["text"]).length() <= 20:
			continue
		var size: Vector2 = (bubble["rect"] as Rect2).size if bubble.has("rect") else host._font.get_string_size(str(bubble["text"]), HORIZONTAL_ALIGNMENT_LEFT, -1, MapBubbles.FONT_SIZE) + MapBubbles.PADDING * 2.0
		var view := get_viewport().get_canvas_transform().affine_inverse() * Rect2(Vector2.ZERO, get_viewport().get_visible_rect().size)
		_check(size.x <= view.size.x * 0.6, "authored ambient sentence keeps a bounded reading width")
	await _enter(BOOTH)
	await _calm()
	var checkpoint: Checkpoint
	for node in _level().find_children("*", "", true, false):
		if node is Checkpoint:
			checkpoint = node
	_check(checkpoint != null, "authored phone checkpoint exists")
	if checkpoint == null:
		return
	_level().player.global_position = checkpoint.global_position + Vector2(8, 0)
	_level().player.velocity = Vector2.ZERO
	_level().camera.snap_to_target()
	await _calm()
	await get_tree().create_timer(1.2).timeout
	await _capture("authored-booth")
	await _press(&"pause")
	_check(_level()._pause_menu._root.visible and get_tree().paused, "public pause opens over the same world")
	_check(not PromptLayout._prompts.any(func(p: WorldPrompt) -> bool: return p.is_showing()), "pause suspends all world invitations")
	await _capture("pause")
	await _press(&"ui_cancel")
	_check(not get_tree().paused, "public back restores the same world")
	await get_tree().create_timer(0.5).timeout
	await _capture("resumed")
	_completed = true
	_save_report()
