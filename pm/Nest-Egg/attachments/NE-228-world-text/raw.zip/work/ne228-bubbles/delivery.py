from pathlib import Path
import json,hashlib,subprocess,os,time
out=Path('work/ne228-bubbles')
files=['game/level/world_prompt.gd','game/level/map_bubbles.gd','game/level/prompt_layout.gd','game/level/world_text_layout.gd','game/level/world_text_layout.gd.uid','tests/suite/test_world_prompt.gd','tests/suite/test_map_bubbles.gd','tools/quest_resume_probe.gd','work/.gdignore']
(out/'delivery-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2))
env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6',LOG_DIR=str(out.resolve()/'delivery-shards'))
cmd=['tools/run_tests_changed.sh','7bf96cfb'];start=time.monotonic()
with (out/'delivery-changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1000)
(out/'delivery-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2))
raise SystemExit(r.returncode)
