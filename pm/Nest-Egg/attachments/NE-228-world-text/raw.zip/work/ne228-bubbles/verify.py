from pathlib import Path
import subprocess,os,json,hashlib,time
root=Path.cwd();out=root/'work/ne228-bubbles';source=root/'game/level/map_bubbles.gd';final=source.read_bytes();env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6');rows=[]
def run(name,command,extra,timeout):
 child=env.copy();child.update(extra);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,env=child,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 rows.append({'name':name,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'verification.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True);return r.returncode
try:
 source.write_bytes((out/'map_bubbles-before.gd').read_bytes())
 status=run('old-bubble-negative',['tools/run_tests_parallel.sh','--only=MapBubblesSuite'],{'LOG_DIR':str(out/'negative-shards')},180)
 assert status==1
finally:
 source.write_bytes(final);assert source.read_bytes()==final
assert run('editor-import',[env['GODOT'],'--headless','--editor','--path',str(root),'--quit'],{'XDG_DATA_HOME':str(out/'editor-profile')},240)==0
files=['game/level/world_prompt.gd','game/level/map_bubbles.gd','game/level/prompt_layout.gd','game/level/world_text_layout.gd','tests/suite/test_world_prompt.gd','tests/suite/test_map_bubbles.gd']
(out/'frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')
raise SystemExit(run('changed',['tools/run_tests_changed.sh','59c2642e'],{'LOG_DIR':str(out/'changed-shards')},900))
