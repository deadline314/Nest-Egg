from pathlib import Path
import subprocess,json
root=Path.cwd();out=root/'work/ne228-bubbles';rows=[]
for name,cwd,command in [('world-text',root,['python','work/ne228-bubbles/native-v4.py']),('real-radio',Path('/workspace/Nest-Egg/work/batch1022/kitchen'),['python','work/ne246-combat/native.py'])]:
 with (out/(name+'-final-driver.log')).open('w') as log:r=subprocess.run(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,timeout=4000)
 rows.append({'name':name,'cwd':str(cwd),'command':command,'exit_code':r.returncode});(out/'native-queue-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert r.returncode==0
