from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();out=root/'work/ne228-bubbles';native=Path('/workspace/Nest-Egg/work/batch1020b');paths=['game/level/world_prompt.gd','game/level/map_bubbles.gd','game/level/prompt_layout.gd'];final={p:(root/p).read_bytes() for p in paths};env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/quests';rows=[]
try:
 for case,args in [('before',[]),('after',[]),('1080',['--1080']),('smooth',['--smooth'])]:
  for p in paths:(root/p).write_bytes((out/(Path(p).stem+'-before.gd')).read_bytes() if case=='before' else final[p])
  name='ne228-1022-world-text-v2-'+case;command=['python',str(native/'native.py'),name,'res://work/ne228-bubbles/probe-v2.tscn','--mode=write','--save-dir='+str(out/('v2-'+case+'-save')),*args]
  with (out/(case+'-wrapper.log')).open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1850)
  row={'case':case,'command':command,'exit_code':r.returncode,'source':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}};rows.append(row);(out/'native-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print(case,r.returncode,flush=True)
  report=json.loads((native/name/'result.json').read_text());assert report['completed'];assert r.returncode==(1 if case=='before' else 0)
finally:
 for p,b in final.items():(root/p).write_bytes(b);assert (root/p).read_bytes()==b
