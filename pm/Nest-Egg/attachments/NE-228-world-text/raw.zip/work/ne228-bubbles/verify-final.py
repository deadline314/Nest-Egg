from pathlib import Path
import subprocess,os,json,hashlib,time
root=Path.cwd();out=root/'work/ne228-bubbles';source=root/'game/level/map_bubbles.gd';final=source.read_bytes();env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6');rows=[]
def run(name,command,timeout):
 child=env.copy();child['LOG_DIR']=str(out/(name+'-shards'));start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,env=child,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 rows.append({'name':name,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start});(out/'final-verification.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True);return r.returncode
files=['game/level/world_prompt.gd','game/level/map_bubbles.gd','game/level/prompt_layout.gd','game/level/world_text_layout.gd','game/level/world_text_layout.gd.uid','tests/suite/test_world_prompt.gd','tests/suite/test_map_bubbles.gd','work/.gdignore']
(out/'final-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')
try:
 source.write_bytes((out/'map_bubbles-before.gd').read_bytes())
 assert run('final-old-bubble-negative',['tools/run_tests_parallel.sh','--only=MapBubblesSuite'],180)==1
 assert 'Detected script errors' not in (out/'final-old-bubble-negative.log').read_text()
finally:
 source.write_bytes(final);assert source.read_bytes()==final
raise SystemExit(run('final-changed',['tools/run_tests_changed.sh','59c2642e'],900))
