from pathlib import Path
import json
r=json.loads(Path('work/ne228-bubbles/package-receipt.json').read_text());v=r['validation'];summary=v['affected_summary'][-1]
p=Path('pm/Nest-Egg/attachments/NE-228-world-text/README.md');p.write_text(f'''# NE-228 世界文字換行與避讓

真正Main的老K飯熟氣泡與電話亭長路牌，同條件修前32項／7失敗，修改後720p像素33／0、1080p／120%像素33／0、720p／120%平滑34／0。四輪24原圖已逐張看過，0引擎／腳本ERROR及0資源洩漏訊息。真正公開暫停時Main不處理、遊玩時計保持，恢復後文字顯示正常。

原受影響選擇器基準7bf96cfb，60組：{summary}。兩個修改套件原斷言逐字重建一致，新增14項；原baseline／碰撞契約的helper、runner、selector、filters和known failures不變。第一輪完整受影響63,204項有1個baseline失敗，修產品metadata後475／0，再跑上述最終整輪。舊MapBubbles負控制32項／6預期失敗，只換回該檔，其餘最終排版保留；不稱整套舊版。

圖片研究先看Night in the Woods森林交談、Oxenfree洞穴多選項的有限欄寬、多行和指向；其餘兩作環境圖與Eastward三圖只作構圖。九張官方Steam下載原圖、URL／SHA與官方Godot4.7 TextParagraph.xml皆在raw。官方文件站403後未重試，改讀公開官方引擎XML契約。

v1只拍到短提示，v2真正長路牌才發現HUD目標與黑邊問題；v3修safe_rect但完整回歸仍抓到baseline。v4保留全部原斷言修產品，並使用7bf96cfb的正式暫停政策。所有中途失敗、誤匯入work舊class的快取與錯誤、原生v1–v4、失敗整輪及最終整輪原始shards完整保留。work/.gdignore須保留後才重新匯入，避免快照的同名class變成正式來源。

[validation.json](validation.json)列範圍與結果，[manifest.json](manifest.json)逐檔SHA，[raw.zip](raw.zip)有{r['entries']}檔、{r['bytes']:,} bytes，SHA256 `{r['sha256']}`；解壓並核對全部雜湊。source/final與delivery-frozen逐檔核對，source/before來自59c2642e。整合45647196只多NE-246文件與證據，沒有另改測試中的產品。

環境是Godot4.7.2、Forward+ HDR、llvmpipe軟體Vulkan及Xvfb。英文／日文是明示完整長句的排版fixture，暫時隱藏同場原有路牌以便核對；不是全章翻譯驗收。固定玩家物理只用於穩定長牌構圖；本次不稱實體裝置、真人完整流程、所有動作或整票完成。
''')
p=Path('pm/Nest-Egg/[NE-228]重整全遊戲介面體驗.md');s=p.read_text();assert '# Commit-20' not in s;s+='''
# Commit-20

## 內文

世界氣泡與長路牌原本橫跨畫面、透出背景字，還可能被避讓推到畫外或黑邊。現在完整句子依畫面寬度換行，按鍵帽保持完整；人物、氣泡與其他提示互相讓位，任務列也沿既有規則讓開。沒空間時暫時收起文字，互動資格保留，空間恢復便重新顯示。

正式老K對話與電話亭長提示在同條件原生對照重現7個問題，修改後720p、1080p、放大文字和平滑字型全部通過；四輪24張原圖逐張檢視，公開暫停／返回與時計保持正常。英文／日文另列排版樣本，不冒稱全章驗收。

''' + f'最終原受影響60組：{summary}。原斷言逐字保留；中途1個baseline失敗修正後重新全跑，負控制與歷史失敗完整保存。\n\n' + '''[研究九圖、所有原生對照、失敗與最終原始測試](attachments/NE-228-world-text/README.md)。本批完成世界文字範圍，整票原驗收保持。

| 修前 | 修後 |
|---|---|
| ![長氣泡覆蓋角色與其他文字](images/NE-228-world-text-before-bubble.png) | ![完整換行並讓開角色](images/NE-228-world-text-after-bubble.png) |
| ![長路牌跨畫面](images/NE-228-world-text-before-sign.png) | ![電話亭原句與完整按鍵帽](images/NE-228-world-text-after-sign.png) |

![1080p與放大文字](images/NE-228-world-text-1080-sign.png)
![平滑字型與放大文字](images/NE-228-world-text-smooth-sign.png)
![英文長句排版樣本](images/NE-228-world-text-fixture-en.png)
![日文長句排版樣本](images/NE-228-world-text-fixture-ja.png)

研究圖為不同作品的正式畫面，只引用有限欄寬與指向，不推論對方內部程式。

![Night in the Woods森林交談](images/NE-228-world-text-ref-481510.jpg)
![Oxenfree洞穴多選項](images/NE-228-world-text-ref-388880.jpg)
''';p.write_text(s)
p=Path('pm/user_guide.md');s=p.read_text();i=s.index('\n2026-10-22（NE-246）');s=s[:i]+'''\n2026-10-22（NE-228）：世界文字要完整換行並同時避開人物、其他文字、HUD與黑邊；先夾回畫面再無界限推開仍會失敗。[正式長氣泡／路牌四組原生24圖與全部中途失敗](Nest-Egg/attachments/NE-228-world-text/README.md)，原baseline契約抓到的問題改產品metadata，保留原斷言後重跑整輪。英文／日文為明示排版fixture，不當全章翻譯。共同工具7bf96cfb完整CI實際為95,973項、0新／已知失敗、638秒（[CI39767506903](https://github.com/deadline314/Nest-Egg/actions/runs/39767506903)）；較早59c2642e的95,976項另有原始紀錄，不混算。
''' +s[i:];p.write_text(s)
