from pathlib import Path
from hashlib import sha256
from PIL import Image
import json
import numpy as np
base=Path(__file__).resolve().parent
root=Path.cwd()
prior=base.parent/'evidence-20261122-ne224-raised-aim'
def load(path):
    return json.loads(path.read_bytes())
def keys(report):
    return {(r['pose'],r['zoom'],r['facing'],r['frame'],r['joint']):
        bool(r['enclosed_pixels'] or r['loose_pieces'] or r['center_alpha']<128) for r in report['failures']}
summary={}
for mode in ('whole','dressed','isolated','adjacent'):
    before=(prior/'final-adjacent' if mode=='adjacent' else base/f'baseline-{mode}')/'report.json'
    b,a=load(before),load(base/f'final-{mode}'/'report.json')
    before_rows,after_rows=keys(b),keys(a)
    assert not set(after_rows)-set(before_rows),mode
    assert not [p for p,v in after_rows.items() if v and not before_rows.get(p)],mode
    assert a['samples']==b['samples']
    summary[mode]=dict(samples=a['samples'],closed_before=sum(before_rows.values()),closed_after=sum(after_rows.values()),
        edge_before=len(before_rows)-sum(before_rows.values()),edge_after=len(after_rows)-sum(after_rows.values()),
        remaining=[list(p) for p,v in after_rows.items() if v])
assert (summary['whole']['closed_before'],summary['whole']['closed_after']) == (100,0)
assert not summary['whole']['remaining']
assert summary['dressed']['closed_before']==12 and summary['dressed']['closed_after']==0
assert summary['isolated']['closed_after']==0
assert summary['adjacent']['closed_before']-summary['adjacent']['closed_after']>=24

street={}
for variant in ('before','after'):
    folder=base/f'street-{variant}'
    assert (folder/'exit.txt').read_text().strip()=='0'
    info=load(folder/'street.json')
    assert info['rendering_method']=='forward_plus' and info['hdr_2d'] and 'RX 9070 XT' in info['adapter']
    street[variant]={r['key']:{key:value for key,value in r.items() if key!='physics_frame'} for r in info['rows']}
    assert len(street[variant])==36
assert street['before']==street['after']
summary['street_count']=36

changed={}
for filename in ('torso.png','torso_n.png','head.png','head_n.png'):
    name='art/characters/enforcer/parts/'+filename
    previous=base/filename
    before=np.asarray(Image.open(previous).convert('RGBA'))
    after=np.asarray(Image.open(root/name).convert('RGBA'))
    assert before.shape==after.shape
    change=np.any(before!=after,axis=2)
    changed[filename]=dict(count=int(change.sum()),before=sha256(previous.read_bytes()).hexdigest(),after=sha256((root/name).read_bytes()).hexdigest())
    if filename=='head.png':
        assert changed[filename]['count']==34
    if filename=='torso.png':
        assert changed[filename]['count']==15 and not np.any(change&(before[:,:,3]>=235))
summary['texture_differences']=changed

# Zoom in on the native frames with the same integer crop and scale for both cases.
sheet=Image.new('RGB',(720,640),'#565c62')
for side in (0,1):
    for variant in ('baseline','final'):
        image=Image.open(base/f'{variant}-whole/dead_3.4_015.png').convert('RGBA')
        x=23+side*256
        region=(x,29,x+90,109)
        cut=image.crop(region).resize((360,320),Image.Resampling.NEAREST)
        sheet.paste(cut,((variant=='final')*360,side*320),cut)
sheet.save(base/'shoulder-comparison.png')
(base/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print('paired street cases',len(street['after']), 'texture differences',changed)