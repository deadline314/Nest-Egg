param([Parameter(Mandatory)][string]$Label)
$ErrorActionPreference='Stop'
$e=$PSScriptRoot.Replace('\','/')
$d='D:/NestEggVerification/ne218-baseline-20261117'
$out="$e/$Label"
New-Item -ItemType Directory -Path "$out/profile" | Out-Null
$env:APPDATA="$out/profile"
$env:LOCALAPPDATA="$out/profile"
$engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$python='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
& $python -B "$d/tools/comfyui/gpu_lock.py" -- $engine --path $d --rendering-method forward_plus --rendering-driver vulkan --resolution 1280x720 --fixed-fps 60 --audio-driver Dummy --quit-after 3500 "$e/street.tscn" -- "--out=$out" *> "$out/raw.log"
$code=$LASTEXITCODE
Set-Content "$out/exit.txt" $code
Get-Content "$out/raw.log" -Tail 17
exit $code