from pathlib import Path
from PIL import Image
import numpy as np

e=Path(__file__).resolve().parent
src=Path("art_src/characters/enforcer/overrides/torso.png")
img=lambda path:np.asarray(Image.open(path).convert("RGBA"))
base=img(src)
assert np.array_equal(base,img(Path("art/characters/enforcer/parts/torso.png")))
for trial,patch in {
    1:{35:(173,174,155),36:(173,175,190),37:(174,176,177)},
    2:{34:(173,173,115),35:(172,174,175),36:(173,176,210),37:(174,177,190),38:(176,177,170)},
    3:{34:(173,173,128),35:(171,175,180),36:(172,176,226),37:(173,177,210),38:(176,178,186)},
}.items():
    candidate=base.copy()
    for row,(left,right,opacity) in patch.items():
        for column in range(left,right+1):
            if opacity>base[row,column,3]:
                candidate[row,column,:3]=base[40,column,:3]
                candidate[row,column,3]=opacity
    changed=np.any(candidate!=base,axis=2)
    assert changed.any() and np.all(candidate[:,:,3]>=base[:,:,3])
    Image.fromarray(candidate).save(e/f"torso-elbow-{trial}.png")
    print(trial,int(changed.sum()))
script=(e/"forearm-matrix.gd").read_text(encoding="utf-8")
script=script.replace('const POSES := ["idle", "run", "aim_up", "crouch", "jump", "block", "stagger", "dead"]',
                      'const POSES := ["aim_up"]')
(e/"torso-elbow.gd").write_text(script,encoding="utf-8")
scene=(e/"forearm-matrix.tscn").read_text(encoding="utf-8").replace("/forearm-matrix.gd","/torso-elbow.gd")
(e/"torso-elbow.tscn").write_text(scene,encoding="utf-8")
run=(e/"run-forearm-matrix.ps1").read_text(encoding="utf-8").replace("armor_forearm:$e/forearm-end-","torso:$e/torso-elbow-")
run=run.replace("/forearm-matrix.tscn","/torso-elbow.tscn")
(e/"run-torso-elbow.ps1").write_text(run,encoding="utf-8")
