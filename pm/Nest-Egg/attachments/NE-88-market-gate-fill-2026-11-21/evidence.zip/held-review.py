from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import json
import math
import sys

import numpy as np

base = Path(__file__).resolve().parent


def exposure(data, frame, enemy):
    width, height = int(frame["width"]), int(frame["height"])
    n = len(data) // (2 * width * height)
    assert n in (3, 4) and len(data) == 2 * width * height * n
    rgb = np.frombuffer(data, dtype="<f2").reshape(height, width, n)
    a, b, c, d, ox, oy = frame["canvas_transform_values"]
    scale = frame["density"]
    x, y, w, h = enemy["visual_world_bounds_values"]
    points = [(scale * (a * xx + c * yy + ox), scale * (b * xx + d * yy + oy))
              for xx in (x, x + w) for yy in (y, y + h)]
    x0 = max(0, math.floor(min(p[0] for p in points)))
    y0 = max(0, math.floor(min(p[1] for p in points)))
    x1 = min(width, math.ceil(max(p[0] for p in points)))
    y1 = min(height, math.ceil(max(p[1] for p in points)))
    crop = rgb[y0:y1, x0:x1, :3]
    assert crop.size and np.isfinite(crop).all()
    pixels = int(np.count_nonzero(np.all(crop >= 0.92, axis=2)))
    return {"pixels": pixels, "rect": [x0, y0, x1, y1], "total": int(crop.size // 3)}


def analyze(case):
    data = base / case / "ch2_market_gate"
    raw_index = (data / "tour-index.json").read_bytes()
    index = json.loads(raw_index)
    stats = defaultdict(list)
    assert len(index["shots"]) == 28
    for shot in index["shots"]:
        records = shot["bg55"]["records"]
        assert shot["bg55"]["controls_valid"], shot["file"]
        assert records[0]["raw_sha256"] == records[1]["raw_sha256"] == records[3]["raw_sha256"], shot["file"]
        assert records[2]["raw_sha256"] == records[4]["raw_sha256"], shot["file"]
        for frame in (records[0], records[2]):
            if not frame["enemies"]:
                continue
            raw = (data / frame["files"]["raw"]).read_bytes()
            assert sha256(raw).hexdigest() == frame["raw_sha256"], shot["file"]
            for enemy in frame["enemies"]:
                assert enemy["skin"] == enemy["id"], enemy["skin"]
                stats[frame["label"]].append({
                    "id": enemy["id"], "feet": enemy["feet"], "cell": shot["file"], "files": frame["files"],
                    "fixed": enemy["contrast"], "full": max(enemy["aux_full_visual_parts"][k] for k in ("bright", "dark")),
                    "exposure": exposure(raw, frame, enemy),
                    "sha256": frame["raw_sha256"], "fill": frame["enemy_fill_scale"]})
    assert len(stats["A0"]) == len(stats["product"]) and stats["A0"]
    assert {(r["id"], tuple(r["feet"]), r["cell"]) for r in stats["A0"]} == {
        (r["id"], tuple(r["feet"]), r["cell"]) for r in stats["product"]}
    report = {}
    for variant, rows in stats.items():
        assert {r["id"] for r in rows} == {"ch2_bill_thrower", "ch2_escort"}
        report[variant] = {"lowest_fixed": min(r["fixed"] for r in rows),
                           "lowest_full": min(r["full"] for r in rows),
                           "actors": len(rows), "white_pixels": sum(r["exposure"]["pixels"] for r in rows),
                           "worst": min(rows, key=lambda r: r["fixed"])}
    (base / (case + "-review.json")).write_text(json.dumps({"index_sha256": sha256(raw_index).hexdigest(),
        "stats": dict(stats), "report": report}, indent=2) + "\n", encoding="utf-8")
    return report


for name in sys.argv[1:]:
    print(name, json.dumps(analyze(name), indent=2))

