extends "res://tools/bg55_enemy_readability_probe.gd"

var fill_candidate := 1.0

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://actual_market_fill.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--candidate-fill="):
			fill_candidate = float(arg.trim_prefix("--candidate-fill="))
	super._ready()


func _tour(level_id: String) -> bool:
	var profile := load("res://data/lighting/market_gate.tres") as LightingProfile
	var original := profile.enemy_fill_scale
	profile.enemy_fill_scale = fill_candidate
	var okay := await super._tour(level_id)
	profile.enemy_fill_scale = original
	return okay
