extends Node

const PUMP := preload("res://data/levels/ch3_pump.tres")
const CAPTURE := preload("res://tools/viewport_capture.gd")
var _out: String
var _unlocked := false
var _one_jump := false

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg == "--unlocked":
			_unlocked = true
		elif arg == "--one-jump":
			_one_jump = true
	_run.call_deferred()

func _frames(count: int) -> void:
	for i in count:
		await get_tree().physics_frame

func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.set_language("zh")
	Story.auto_skip = true
	GameState.set_flag(&"ch3_freight_ready")
	GameState.set_flag(&"ch3_pump_low")
	if _unlocked:
		GameState.set_flag(&"ledger_disk_obtained")
	GameState.pending_portal = &"pump_shaft"
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(PUMP)
	add_child(level)
	await _frames(90)
	var player := level.player
	var spawn := player.global_position
	Input.action_press(&"move_right")
	for i in 400:
		await _frames(1)
		if player.global_position.x >= 650:
			break
	Input.action_release(&"move_right")
	await _frames(25)
	var start := player.global_position
	var top := start.y
	var before := Progression.credits
	Input.action_press(&"jump")
	for i in 28:
		await _frames(1)
		top = minf(top, player.global_position.y)
	if not _one_jump:
		Input.action_release(&"jump")
		await _frames(2)
		Input.action_press(&"jump")
	for i in 90:
		await _frames(1)
		top = minf(top, player.global_position.y)
	Input.action_release(&"jump")
	var final := player.global_position
	var gained := Progression.credits - before
	var expected := 10 if _unlocked and not _one_jump else 0
	var ok := player.has_air_jump() == _unlocked and spawn.x < 120 and absf(spawn.y - 256) < 2 and absf(start.y - 256) < 2 and absf(start.x - 664) < 26 and gained == expected
	await RenderingServer.frame_post_draw
	CAPTURE.image(get_viewport()).save_png(_out.path_join("pump-credit-route.png"))
	var output := {"air_jump": _unlocked, "single_jump": _one_jump, "valid": ok, "spawn": [spawn.x, spawn.y], "jump_start": [start.x, start.y], "highest_y": top, "landing": [final.x,final.y], "credit_gain": gained, "gpu": RenderingServer.get_video_adapter_name()}
	FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify(output, "\t"))
	print(output)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if ok else 1)
