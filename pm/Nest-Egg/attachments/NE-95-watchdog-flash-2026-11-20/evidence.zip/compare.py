import json
from pathlib import Path
import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent

def summary(tag):
    path=base/tag
    doc=json.loads((path/"result.json").read_bytes())
    data={}
    for row in doc["samples"]:
        name=row["label"]
        if not row["accepted"]:
            continue
        x,y=row["impact"]["head_pixel"]
        values=[]
        for phase in ["before", "0","1","2","3","4"]:
            image=np.array(Image.open(path/f"{name}-{phase}.png").convert("RGB"))
            xx_center,yy_center=x*2.0,y*2.0
            yy,xx=np.ogrid[:image.shape[0],:image.shape[1]]
            mask=((xx-xx_center)/64.0)**2+((yy-yy_center)/53.0)**2<1
            rgb=image[mask]
            white=np.count_nonzero(rgb.min(axis=1)>=245)
            full_white=np.count_nonzero(image.min(axis=2)>=245)
            contrast=np.percentile(rgb @ np.array([0.2126,0.7152,0.0722]),[25,50,75,90])
            values.append({"phase":phase,"roi_white":int(white),"frame_white":int(full_white),"luma":[round(float(v),2) for v in contrast]})
        data[name]={"center":[x,y],"impact":row["impact"],"shots":values}
    return data

pairs={tag:summary(tag) for tag in ("reference","control","local-light-only","no-hit-lights","no-muzzle","candidate")}
for name in pairs["reference"]:
    print(name, pairs["reference"][name]["center"],flush=True)
    for tag in pairs:
        row=pairs[tag][name]
        print(f"{tag:9}",[sample["roi_white"] for sample in row["shots"]],
              [sample["frame_white"] for sample in row["shots"]],row["shots"][1]["luma"],flush=True)
(base/"isolation-metrics.json").write_text(json.dumps(pairs,indent=2)+"\n",encoding="utf-8")
