extends "res://tools/ch1_flow_probe.gd"

const LEVEL_PATH := "res://data/levels/ch1_warehouse.tres"
var _dog: PatternBoss
var _head: Hurtbox
var _hit: Dictionary
var _samples: Array[Dictionary] = []
var _variant := "stock"


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--variant="):
			_variant = arg.trim_prefix("--variant=")
	Transition.instant = true
	super._ready()


func _run() -> void:
	seed(95253)
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	_level = Level.new()
	_level.configure(load(LEVEL_PATH) as LevelData)
	add_child(_level)
	await _settle(45)
	for node: Node in _level._entities.get_children():
		if node is PatternBoss and (node as PatternBoss).data.id == &"watchdog":
			_dog = node as PatternBoss
	for node in get_tree().get_nodes_in_group(&"enemies"):
		if node != _dog:
			node.queue_free()
	_check(_dog != null and _level.player != null, "the real warehouse loads its watchdog and player")
	if _dog == null or _level.player == null:
		await _finish()
		return
	for part in _dog.hurtbox.parts:
		if part.part_id == &"head":
			_head = part
	if _head == null:
		_check(false, "the real barking head exists")
		await _finish()
		return
	var player := _level.player
	var camera := get_viewport().get_camera_2d()
	camera.set_physics_process(false)
	camera.limit_enabled = false
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * 2.0
	AimInput.set_virtual_gamepad(player, true)
	player.health.setup(9999, 0.0)
	_dog.data = _dog.data.duplicate()
	_dog.data.move_speed = 0.0
	_dog.data.attack_cooldown = 999.0
	_dog.health.setup(9999, 0)
	if _variant in ["no-hit-lights", "local-light-only"]:
		_dog.vfx._data = _dog.vfx._data.duplicate(true)
		_dog.vfx._data["hit"]["light"] = 0.0
	if _variant == "no-hit-lights":
		EventBus.hit_confirmed.disconnect(Fx._on_hit_confirmed)
	if _variant == "no-muzzle":
		var weapon := player.loadout.active_weapon().duplicate() as WeaponData
		weapon.muzzle_light_energy = 0.0
		weapon.muzzle_flare_size = 0.0
		player.loadout._weapons[player.loadout.active_slot] = weapon
	_head.hit_received.connect(_on_head)
	for reduced: bool in [false,true]:
		Settings.set_reduce_flashes(reduced)
		for offset: float in [-45.0,45.0,150.0]:
			await _sample(player,camera,offset,reduced)
	await _finish()


func _sample(player: Player, camera: Camera2D, offset: float, reduced: bool) -> void:
	var label := ("reduced" if reduced else "normal") + ("-left-" if offset<0.0 else "-right-") + str(absf(offset))
	_dog.fsm.transition(&"idle")
	player.global_position = Vector2(_dog.global_position.x + offset, player.global_position.y)
	player.velocity = Vector2.ZERO
	camera.global_position = (_dog.global_position + player.global_position) * 0.5 + Vector2(0,-25)
	camera.reset_smoothing()
	await _settle(100)
	_dog.set("_move_id", &"bark")
	_dog.fsm.transition(&"windup")
	await _settle(18)
	AimInput.restore_direction((_head.center() - player.aim_origin()).normalized())
	await _settle(4)
	player.loadout.set_ammo(player.loadout.active_slot, player.loadout.active_weapon().magazine_size, -1)
	var shot_origin := player.muzzle_position()
	_hit.clear()
	var ammo := player.loadout.mag_in(player.loadout.active_slot)
	_capture(label+"-before")
	Input.action_press(&"shoot")
	await _settle(1)
	Input.action_release(&"shoot")
	for step in 28:
		if not _hit.is_empty():
			break
		await _settle(1)
	var accepted := not _hit.is_empty() and player.loadout.mag_in(player.loadout.active_slot) < ammo
	_check(accepted,"real shot hits the barking head at "+label)
	_samples.append({"label":label,"offset":offset,"reduced":reduced,"shot":str(shot_origin),"accepted":accepted,"impact":_hit.duplicate()})
	if accepted:
		for offset_frame in 5:
			await RenderingServer.frame_post_draw
			_capture(label+"-"+str(offset_frame))
			await _settle(1)


func _on_head(info: DamageInfo) -> void:
	if _variant == "no-creature-flash":
		_dog.creature._flash_left = 0.0
		_dog.creature._update_flash(0.0)
	var projected := get_viewport().get_canvas_transform() * _head.center()
	_hit = {"part":String(info.part),"weak":info.weak_hit,"health":_dog.health.current,
		"head_world":str(_head.center()),"head_pixel":[projected.x,projected.y],"damage":info.amount}


func _finish() -> void:
	var state := FileAccess.open(_out_dir.path_join("result.json"),FileAccess.WRITE)
	state.store_string(JSON.stringify({"variant":_variant,"failures":_failures,"samples":_samples},"  ")+"\n")
	state.close()
	AudioRelease.begin_shutdown()
	if is_instance_valid(_level):
		_level.queue_free()
	await _settle(6)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures == 0 else 1)
