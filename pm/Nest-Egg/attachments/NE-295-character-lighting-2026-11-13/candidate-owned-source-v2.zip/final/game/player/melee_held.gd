class_name MeleeHeld
extends Node2D
## 手上的近戰武器（NE-275）：握在拳頭裡、有自己的重量。
##
## 握：握把對在掌心（骨架的握點），這個節點排在前手的後面、手臂的前面，所以握拳的手指會蓋在握把上。
## 拿：不出招時每把武器有自己的拿法（朝哪裡、跟著手臂晃多少），不是筆直沿著前臂垂下來；
##     尖端與握把尾端都不會低於腳下的地面，太低就把武器抬起來，鞭子的細線只畫到地面為止。
## 揮：出招時武器的方向以前臂為準，但不是和前臂綁死——武器的角度用一個有阻尼的彈簧去追目標：
##     手臂突然加速時刀尖落在後面（拖曳），手臂停下時多甩過去一點再回來（跟隨）。重的武器彈簧軟、拖得多。
## 每把武器的數字在 data/weapon_art/melee.json 的 hold（見 MeleeArt.hold_spec）；沒寫的武器用下面的預設。
## 鞭類武器（NE-276）：握把照上面的方式握，鞭身是一條一直在模擬的軟繩（SoftWhip），從握把的出線口接出去；
##     出招時不換畫法，只給鞭梢一個沿著招式路徑走的目標點去拉它。
##
## 只管看得到的樣子：招式打得到的距離、判定與時間照招式資料，和這裡無關。

## 預設拿法（朝右時的角度，弧度；0 是水平朝前、正的是往下）。second 是另一隻手握在離握把多遠的地方（世界像素，0＝單手）。
const DEFAULT := {"carry": 0.5, "couple": 0.3, "freq": 8.0, "damp": 0.6, "lag": 0.5, "swing": 0.0, "second": 0.0}
## 尖端離地面至少留這麼多（世界像素）。
const FLOOR_MARGIN := 1.5
## 彈簧每一小步最多走多少相位（弧度）。
const SPRING_STEP := 0.25
## 進出招式時「拿法」與「跟著前臂」之間的過渡速度（每秒）。
const BLEND_SPEED := 14.0
## 鞭身平常放出來的長度佔招式距離的比例（其餘收在握把裡）；出招時放到「要打的距離」的幾倍（多出來的是鬆弛，到位時中段仍有弧度）。
const WHIP_IDLE_SHARE := 0.3
## 鞭身發光的上限（鞭身會甩過主角的頭頂，太亮會讓頭部的全白比例超標）。
const WHIP_GLOW_MAX := 1.3
const WHIP_SLACK := 1.07
## 出招時鞭梢的目標點繞一圈的角度（朝右空間，弧度；正的是往下）：從垂著、往後、過頭頂、到前方。
const WHIP_SWEEP_FROM := PI * 0.5
const WHIP_SWEEP_TO := TAU
## 鞭梢的拉力（每個小步往目標靠近的比例）：往後帶時輕、甩出去到出招時重。
const WHIP_PULL_BACK := 0.08
const WHIP_PULL_THROW := 0.24
## 目標點在前搖的這個比例就到達最遠點、之後停在那裡等鞭梢追上（鞭梢要花幾格才到，出招那一刻剛好到位）。
const WHIP_ARRIVE := 0.75
## 招式進度裡「往後帶」結束、開始甩出去的時間點（前搖佔 0～0.4，出招 0.4～0.7）。
const WHIP_THROW_AT := 0.16
const WHIP_ACTIVE_FROM := 0.4
const WHIP_ACTIVE_TO := 0.7
## 雙手招式時後手離前手至少多遠（世界像素，一個拳頭）。
const SECOND_MIN := 5.0
## 後手握在桿尾那一段時，離桿的末端至少留多少（世界像素）。
const SECOND_TAIL_MARGIN := 2.0
const SECOND_STEP := 0.5
## 搆不到的點的懲罰（比任何搆得到的點都差）。
const OUT_OF_REACH := 1000.0

var _visual: PlayerVisual
var _weapon: WeaponData
var _spec: Dictionary = DEFAULT
var _tip := 0.0
var _butt := 0.0
## 武器最粗的地方的一半（錘頭很厚：中心線在地面以上不夠，整個錘頭都要在地面以上）。
var _half_width := 0.0
## 朝右空間裡武器現在的角度與角速度。
var _angle := 0.0
var _speed := 0.0
var _swing_blend := 0.0
var _facing := 0
var _settled := false
var _second_along := NAN
var _origin := Vector2.ZERO
var _direction := Vector2.RIGHT
var _reach := -1.0
var _shown := false
var _whip: SoftWhip
var _base_sprite: ReflectiveBase
var _base_scale := Vector2.ONE


## A real Sprite transform supplies the normal basis. The parent draws only glow.
class ReflectiveBase extends Sprite2D:
	var held: MeleeHeld

	func _draw() -> void:
		if texture == null and held._shown and held._weapon != null:
			var inverse := global_transform.affine_inverse()
			MeleeArt.draw(self, inverse * held._origin, inverse.basis_xform(held._direction).normalized(), held._weapon, 1.0, 1.0, held._reach, MeleeArt.REFLECTIVE)


func setup(visual: PlayerVisual) -> void:
	_visual = visual
	LightKit.mark_emissive(self)
	_base_sprite = ReflectiveBase.new()
	_base_sprite.name = "ReflectiveBase"
	_base_sprite.held = self
	_base_sprite.centered = false
	_base_sprite.show_behind_parent = true
	add_child(_base_sprite)
	visual.rig.bind_attachment(_base_sprite)


## 每個物理影格在骨架動完之後呼叫：更新握點、武器的角度與要不要畫。
func update(delta: float) -> void:
	_shown = _visual.shows_melee_weapon()
	visible = _shown
	if not _shown:
		_settled = false
		if _whip != null:
			_whip.clear()
		return
	var player := _visual.player
	var rig := _visual.rig
	var weapon := player.loadout.active_weapon()
	if weapon != _weapon:
		_adopt(weapon)
	var hand := rig.bone(&"hand_front")
	var forearm := rig.bone(&"arm_front_lower")
	_origin = hand.global_transform * rig.hand_grip_offset(&"hand_front")
	var facing := 1 if player.facing >= 0 else -1
	var along := hand.global_position - forearm.global_position
	# 一律換到「朝右」的空間裡算角度，朝左時左右對調。
	var arm_angle := Vector2(along.x * facing, along.y).angle()
	var in_move := not player.melee_pose().is_empty()
	# 有武器路徑的招式（NE-277）：武器朝路徑的方向，手去握它；沒有路徑的招式照舊以前臂為準。
	var path := player.melee.path_now() if in_move else PackedFloat32Array()
	if not path.is_empty():
		arm_angle = path[0] + path[2]
		_swing_blend = 1.0  # 有路徑的招式從第一格就朝路徑（起點就是拿法）；角度仍由彈簧去追，保留拖曳與跟隨
	_swing_blend = move_toward(_swing_blend, 1.0 if in_move else 0.0, delta * BLEND_SPEED)
	var carry := float(_spec["carry"]) + float(_spec["couple"]) * angle_difference(PI * 0.5, arm_angle)
	var target := lerp_angle(carry, arm_angle + float(_spec["swing"]), smoothstep(0.0, 1.0, _swing_blend))
	if not _settled or facing != _facing:
		_second_along = NAN
		# 剛拿出來、或轉身：直接到位，不要掃過半圈。
		_angle = target
		_speed = 0.0
		_settled = true
		_facing = facing
	else:
		_follow(target, delta)
	_reach = -1.0
	if _swing_blend < 1.0:
		_keep_above_floor(player.global_position.y - FLOOR_MARGIN)
	_direction = Vector2(cos(_angle) * facing, sin(_angle))
	_update_base()
	if weapon.melee_shape == "whip":
		_step_whip(delta, player, facing)
	elif _whip != null:
		_whip.clear()
	queue_redraw()
	_base_sprite.queue_redraw()


## 這把武器的軟鞭身（不是鞭類或還沒拿出來時是 null 或還沒垂好）。
func whip() -> SoftWhip:
	return _whip


## 鞭身的一步：握把釘在出線口；出招時鞭梢的目標點從垂著的位置往後、過頭頂、到招式的最遠點，拉力隨進度加重，收招放開。
func _step_whip(delta: float, player: Player, facing: int) -> void:
	if _whip == null:
		_whip = SoftWhip.new()
	_whip.floor_y = player.global_position.y - 0.5
	var nozzle := _origin + _direction * _tip
	var idle_length := maxf(12.0, _weapon.melee_length * WHIP_IDLE_SHARE)
	var target := nozzle
	var pull := 0.0
	var rope := idle_length
	var progress := player.melee_pose_progress() if not player.melee_pose().is_empty() else -1.0
	if progress >= 0.0 and progress < WHIP_ACTIVE_TO:
		var attack: Dictionary = player._melee_attack
		var aim: Vector2 = player._melee_direction(attack)
		var chest := player.global_position + Vector2(0.0, -Player.BODY_SIZE.y * 0.55)
		var reach_point := chest + aim * float(attack["range"])
		var full := nozzle.distance_to(reach_point)
		if progress >= WHIP_ACTIVE_FROM:
			target = reach_point
			pull = WHIP_PULL_THROW
		else:
			# 目標點繞著握把轉一圈：垂著（朝下）→ 身後 → 頭頂 → 前方；半徑一路放長到要打的距離。
			var u := progress / WHIP_ACTIVE_FROM
			var aim_angle := Vector2(aim.x * facing, aim.y).angle()
			var sweep := lerpf(WHIP_SWEEP_FROM, WHIP_SWEEP_TO + aim_angle, smoothstep(0.0, WHIP_ARRIVE, u))
			var radius := lerpf(idle_length, full, smoothstep(0.0, WHIP_ARRIVE, u))
			target = nozzle + Vector2(cos(sweep) * facing, sin(sweep)) * radius
			pull = WHIP_PULL_BACK if u < WHIP_THROW_AT / WHIP_ACTIVE_FROM else lerpf(WHIP_PULL_BACK, WHIP_PULL_THROW,
					smoothstep(WHIP_THROW_AT / WHIP_ACTIVE_FROM, 1.0, u))
		rope = maxf(idle_length, nozzle.distance_to(target) * WHIP_SLACK)
	_whip.step(delta, nozzle, _direction, rope, target, pull)


## 雙手武器另一隻手要握的地方（世界座標）；單手武器或現在沒有在畫時回傳 false。
func has_second_grip() -> bool:
	return _shown and _settled and float(_spec["second"]) > 0.0


func second_grip() -> Vector2:
	return _origin + _direction * (_second_along if is_finite(_second_along) else float(_spec["second"]))


## 雙手招式時後手在桿上的握點：桿上離 shoulder（後肩）在 [near, far]（手臂搆得到）之內、距離最接近 ideal（手肘自然彎著）的一點；
## 範圍內都沒有點時取離範圍最近的一點（交給手臂 IK 判斷握不握得到）。
## 可以握的地方是前手往刃尖方向「一個拳頭」到外觀資料的 second，以及前手往桿尾方向那一段（長柄的戰戟：刺擊時後手握在桿尾）；
## 握把離桿尾不到兩個拳頭的武器（錘）只有前面那一段。每半個像素試一次（最多幾十次，只在雙手招式時算）。
func second_grip_near(shoulder: Vector2, ideal := 0.0, near := 0.0, far := INF, shaft_side := 0) -> Vector2:
	var second := float(_spec["second"])
	var best := -SECOND_MIN if shaft_side < 0 else minf(SECOND_MIN, second)
	var best_error := INF
	var tail_end := _butt - SECOND_TAIL_MARGIN
	var s := -tail_end if tail_end >= SECOND_MIN else best
	while s <= second + 0.001:
		if (shaft_side == 0 or signf(s) == shaft_side) and (absf(s) >= SECOND_MIN - 0.001 or s == minf(SECOND_MIN, second)):
			var distance := shoulder.distance_to(_origin + _direction * s)
			var outside := maxf(near - distance, distance - far)
			var error := absf(distance - ideal) if outside <= 0.0 else OUT_OF_REACH + outside
			if outside <= 0.0 and is_finite(_second_along):
				error = absf(s - _second_along) + absf(distance - ideal) * 0.01
			if error < best_error:
				best_error = error
				best = s
		s += SECOND_STEP
	return _origin + _direction * best


func remember_second_grip(point: Vector2) -> void:
	_second_along = (point - _origin).dot(_direction)


## 武器最遠的一點（世界座標）：刃尖或錘頭；鞭子是鞭梢。量「畫面上的武器打得到多遠」用。
func tip_point() -> Vector2:
	if _whip != null and _whip.is_laid():
		return _whip.tip()
	return _origin + _direction * _tip


## 握把的位置與刃尖的方向（世界座標）：origin 是掌心，x 軸指向刃尖。
func hold() -> Transform2D:
	return Transform2D(_direction, _direction.orthogonal(), _origin)


## 武器現在比「該在的方向」落後多少（弧度，朝右空間；量測與測試用）。
func lag_from(target_angle: float) -> float:
	return angle_difference(target_angle, _angle)


func angle() -> float:
	return _angle


func _adopt(weapon: WeaponData) -> void:
	_weapon = weapon
	_second_along = NAN
	_spec = DEFAULT.duplicate()
	_spec.merge(MeleeArt.hold_spec(weapon), true)
	var entry := MeleeArt.art(weapon)
	_base_sprite.texture = entry.get("lit_texture")
	if entry.is_empty():
		_tip = weapon.melee_length
		_butt = 5.0
		_half_width = 1.5
	else:
		_base_scale = (entry["size"] as Vector2) / _base_sprite.texture.get_size()
		_base_sprite.offset = -(entry["grip"] as Vector2) / _base_scale
		_tip = float((entry["size"] as Vector2).x) - float((entry["grip"] as Vector2).x)
		_butt = float((entry["grip"] as Vector2).x)
		_half_width = float((entry["size"] as Vector2).y) * 0.5
	_settled = false


func _update_base() -> void:
	if _base_sprite.texture == null:
		_base_sprite.transform = Transform2D.IDENTITY
		return
	var down := Vector2(-_direction.y, _direction.x) * (-1.0 if _direction.x < 0.0 else 1.0)
	_base_sprite.transform = global_transform.affine_inverse() * Transform2D(_direction * _base_scale.x, down * _base_scale.y, _origin)


## 有阻尼的彈簧：角度追目標；落後超過上限就拉住（不讓刀甩到身體後面去）。
func _follow(target: float, delta: float) -> void:
	var omega := TAU * float(_spec["freq"])
	# 彈簧硬（匕首 14 Hz）時一個物理影格一步會算到發散、每一格左右跳：切成小步，每步不超過 0.25 弧度的相位。
	var steps := maxi(1, ceili(omega * delta / SPRING_STEP))
	var step := delta / float(steps)
	for i in steps:
		var error := angle_difference(_angle, target)
		_speed += (omega * omega * error - 2.0 * float(_spec["damp"]) * omega * _speed) * step
		_angle = wrapf(_angle + _speed * step, -PI, PI)
	var limit := float(_spec["lag"])
	var behind := angle_difference(target, _angle)
	if absf(behind) > limit:
		_angle = wrapf(target + signf(behind) * limit, -PI, PI)
		_speed = 0.0


## 不出招時武器的兩端都要在地面以上：太低就往水平的方向抬；鞭子的細線另外只畫到地面。
func _keep_above_floor(floor_y: float) -> void:
	var room := floor_y - _origin.y - _half_width
	if room <= 0.0:
		return
	var rise := sin(_angle)
	if _tip > 0.0 and rise * _tip > room:
		var limit := asin(clampf(room / _tip, -1.0, 1.0))
		_angle = limit if cos(_angle) >= 0.0 else PI - limit
		_speed = minf(_speed, 0.0) if cos(_angle) >= 0.0 else maxf(_speed, 0.0)
	elif _butt > 0.0 and -rise * _butt > room:
		var limit := -asin(clampf(room / _butt, -1.0, 1.0))
		_angle = limit if cos(_angle) >= 0.0 else -PI - limit
		_speed = 0.0
	if _weapon != null and _weapon.melee_shape == "whip" and sin(_angle) > 0.05:
		_reach = clampf((floor_y - _origin.y - 1.0) / sin(_angle), _tip, _weapon.melee_length)


func _draw() -> void:
	if not _shown or _weapon == null:
		return
	var player := _visual.player
	var glow := PlayerVisual.MELEE_GLOW_SWING if player.is_melee_swinging() else PlayerVisual.MELEE_GLOW
	# ReflectiveBase is lit by the same material as the hands. Only emission lives here.
	var inverse := global_transform.affine_inverse()
	if _weapon.melee_shape == "whip" and _whip != null and _whip.is_laid():
		# 握把是圖；鞭身不再是一條直線，由軟鞭自己畫。
		MeleeArt.draw(self, inverse * _origin, inverse.basis_xform(_direction).normalized(), _weapon, glow, 1.0, 0.01, MeleeArt.EMISSION)
		_whip.draw(self, inverse, _weapon.color, minf(glow, WHIP_GLOW_MAX))
		return
	MeleeArt.draw(self, inverse * _origin, inverse.basis_xform(_direction).normalized(), _weapon, glow, 1.0, _reach, MeleeArt.EMISSION)
