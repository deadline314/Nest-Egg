class_name MeleeWeaponsSuite
extends EnemySuiteBase
## 近戰武器（NE-117）：武器是資料（.tres 指向 data/melee/<id>.json）；判定只在出招區間、同一目標只算一次、
## 距離與死角、電量消耗與充電、任兩把有取捨、武器欄與背包能顯示、既有槍械不受影響。

const WEAPONS: Array[String] = ["melee_dagger", "melee_blade", "melee_maul", "melee_glaive", "melee_whip"]


func run() -> void:
	_test_growth_contract()
	_test_data()
	_test_maul_drawing()
	_test_balance()
	_test_step_counts()
	_test_attack_poses()
	_test_loadout()
	await _test_reflective_held_materials()
	await _test_reach_and_dead_zone()
	await _test_single_hit_and_windows()
	await _test_charge()
	await _test_ui()
	await _test_gun_unchanged()
	await _test_real_shot_preflight()
	await _test_interruptions()
	await _test_blocked_contact()
	await _test_held_input()
	await _test_late_target_hitstop()
	await _test_optional_tails()
	await _test_frozen_paid_tail_refusal()
	await _test_command_paths()
	await _test_refusals_and_extra_interruptions()
	await _test_paid_cancels_and_facing()
	await _test_weapon_guard_transition()
	await _test_tail_contacts()
	await _test_whiff_and_reduced_feedback()
	await _test_multi_target_hitstop()
	AimInput.using_gamepad = false


func _weapon(id: String) -> WeaponData:
	return load("res://data/weapons/melee/%s.tres" % id) as WeaponData


func _test_maul_drawing() -> void:
	var weapon := _weapon("melee_maul")
	var grip_offset := Vector2.ZERO
	for part: Dictionary in RigLibrary.character("rin").get("parts", []):
		if part.get("name") == "hand_front":
			grip_offset = RigLibrary.vec2(part.get("grip_offset"))
	var shaft_reaches_head := false
	var grip_crosses_authored_palm := false
	var head_materials: Array[Color] = []
	for segment in MeleeArt.segments(weapon):
		var a: Vector2 = segment.a
		var b: Vector2 = segment.b
		if segment.c == MeleeArt.STEEL and is_zero_approx(a.y) and is_zero_approx(b.y):
			shaft_reaches_head = a.x <= 0.0 and b.x >= weapon.melee_length * 0.82
		if segment.c == MeleeArt.GRIP:
			grip_crosses_authored_palm = a.x < grip_offset.x and b.x > grip_offset.x
		if not segment.glow and minf(a.x, b.x) > weapon.melee_length * 0.73 and not head_materials.has(segment.c):
			head_materials.append(segment.c)
	check(shaft_reaches_head, "the maul shaft visibly extends into the head instead of barely meeting its edge")
	check(grip_crosses_authored_palm, "the maul grip runs across the authored palm position, not only behind the wrist")
	check(head_materials.size() >= 3, "the maul head has separate non-emissive body, bevel and hydraulic detail")
	print("NE236_MAUL_DRAWING ", JSON.stringify({"shaft_reaches_head":shaft_reaches_head, "grip_crosses_authored_palm":grip_crosses_authored_palm, "head_materials":head_materials.size()}))


func _test_data() -> void:
	for id in WEAPONS:
		var weapon := _weapon(id)
		check(weapon != null and weapon.is_melee() and weapon.is_valid(), "%s is a valid melee weapon" % id)
		if weapon == null:
			continue
		var errors := MeleeData.set_of(weapon).validate()
		check(errors.is_empty(), "%s melee data has no errors: %s" % [id, ", ".join(errors)])
		check(not weapon.description.is_empty() and not weapon.short_name.is_empty(), "%s has a one-line description" % id)
		check(WeaponSounds.name_for(weapon.id, &"empty") != &"", "%s falls back to the default empty-click sound" % id)
		check(WeaponSystem.fire(weapon, Vector2.ZERO, Vector2.RIGHT, Combat.Team.PLAYER) == 0, "%s fires no bullets" % id)
	var bad := WeaponData.new()
	bad.melee_profile = "test_no_such_attack"
	var fallback := MeleeData.set_of(bad).attack("whatever")
	check(float(fallback["windup"]) > 0.0, "a missing profile falls back to safe defaults instead of crashing")


## 速度、威力、距離、衝擊力四軸：任兩把都要各有勝負，沒有哪一把全面勝過其他。
func _test_balance() -> void:
	var stats: Dictionary = {}
	for id in WEAPONS:
		var set := MeleeData.set_of(_weapon(id))
		var first := set.attack(str(set.combo()[0]))
		var impact := 0.0
		for attack_id: Variant in set.combo():
			impact = maxf(impact, float(set.attack(str(attack_id))["impact"]))
		stats[id] = {"speed": -float(first["windup"]), "dps": set.damage_per_second(), "reach": set.max_range(), "impact": impact}
	for a in WEAPONS:
		for b in WEAPONS:
			if a >= b:
				continue
			var a_wins := 0
			var b_wins := 0
			for axis: String in ["speed", "dps", "reach", "impact"]:
				if float(stats[a][axis]) > float(stats[b][axis]):
					a_wins += 1
				elif float(stats[a][axis]) < float(stats[b][axis]):
					b_wins += 1
			check(a_wins > 0 and b_wins > 0, "%s and %s trade off (wins %d vs %d)" % [a, b, a_wins, b_wins])
	check(float(stats["melee_dagger"]["speed"]) > float(stats["melee_blade"]["speed"]), "the dagger starts swinging fastest")
	check(float(stats["melee_whip"]["reach"]) > float(stats["melee_glaive"]["reach"]) and float(stats["melee_glaive"]["reach"]) > float(stats["melee_blade"]["reach"]), "whip reaches farther than the glaive, glaive farther than the blade")
	check(float(stats["melee_maul"]["impact"]) > float(stats["melee_blade"]["impact"]), "the maul hits hardest")
	var stagger := MeleeData.set_of(_weapon("melee_maul")).attack("smash")
	check(int(stagger["stagger"]) >= 3 and float(stagger["impact"]) >= 9.0, "the maul can stagger enemies (impact tier)")


func _test_loadout() -> void:
	var loadout := Loadout.new()
	loadout.reset(load("res://data/weapons/pistol.tres") as WeaponData)
	loadout.equip(_weapon("melee_blade"))
	loadout.equip(_weapon("melee_whip"))
	check(loadout.weapon_in(1).id == &"melee_blade" and loadout.active_weapon().id == &"melee_whip", "melee weapons are picked up and equipped like guns")
	loadout.select(1)
	check(loadout.active_weapon().id == &"melee_blade", "a melee weapon can be switched to")
	var restored := Loadout.new()
	restored.restore(loadout.snapshot(), load("res://data/weapons/pistol.tres") as WeaponData)
	check(restored.find_slot(&"melee_whip") >= 0 and restored.active_weapon().id == &"melee_blade", "the loadout snapshot keeps melee weapons")


## 瞄準方向固定（模擬手把右搖桿），不受測試環境的滑鼠位置影響。
func _aim(player: Player, dir: Vector2) -> void:
	AimInput.using_gamepad = true
	AimInput._last_stick_dir = dir.normalized()
	player.aim_dir = dir.normalized()
	player.facing = 1 if dir.x >= 0.0 else -1


func _arm(weapon_id: String) -> Player:
	var player := level.player
	player.loadout.equip(_weapon(weapon_id))
	_aim(player, Vector2.RIGHT)
	player._melee_cooldown_left = 0.0
	return player


func _test_reflective_held_materials() -> void:
	await open_level(10.0)
	for id in WEAPONS:
		var player := _arm(id)
		for facing: int in [1, -1]:
			_aim(player, Vector2(facing, 0))
			await physics_frames(4)
			var rig := player._visual.rig
			var held := player._visual.melee_held()
			var base := held.get_node("ReflectiveBase") as Sprite2D
			var art := MeleeArt.art(_weapon(id))
			check(held.is_visible_in_tree() and base.texture == art["lit_texture"] and base.material == rig._light_material,
				"lighting: %s/%d held base uses actual hand material and lit texture" % [id, facing])
			check(held.material == LightKit.emissive_material() and base.show_behind_parent,
				"lighting: %s/%d glow stays separate and above the reflective base" % [id, facing])
			check(base.global_position.distance_to(held._origin) < 0.001
				and (base.global_transform.basis_xform(Vector2(base.texture.get_width(), 0)) - held._direction * (art["size"] as Vector2).x).length() < 0.001,
				"lighting: %s/%d splitting passes preserves true grip and blade direction/length" % [id, facing])
			var material := base.material
			await physics_frames(2)
			check(base.material == material and rig._attachments.size() == 1, "lighting: swapping weapons reuses its single base binding")
	await end_level(level)


## 輕型的接續較多、重型較少（NE-236）：連段段數含付費尾招；起手最快的武器段數最多，單擊最重的段數比它少。
func _test_step_counts() -> void:
	var steps: Dictionary = {}
	var windup: Dictionary = {}
	var impact: Dictionary = {}
	for id in WEAPONS:
		var set := MeleeData.set_of(_weapon(id))
		steps[id] = set.combo(true).size()
		windup[id] = float(set.attack(str(set.combo()[0]))["windup"])
		var heaviest := 0.0
		for attack_id: Variant in set.combo(true):
			heaviest = maxf(heaviest, float(set.attack(str(attack_id), str(attack_id) == set.extension_attack()).get("impact", 0.0)))
		impact[id] = heaviest
	var fastest: String = WEAPONS[0]
	var hardest: String = WEAPONS[0]
	for id in WEAPONS:
		fastest = id if float(windup[id]) < float(windup[fastest]) else fastest
		hardest = id if float(impact[id]) > float(impact[hardest]) else hardest
	for id in WEAPONS:
		check(int(steps[fastest]) >= int(steps[id]), "the fastest weapon (%s) has at least as many follow-ups as %s (%d vs %d)" % [fastest, id, steps[fastest], steps[id]])
	check(int(steps[hardest]) < int(steps[fastest]), "the hardest-hitting weapon (%s) has fewer steps than the fastest (%d vs %d)" % [hardest, steps[hardest], steps[fastest]])


## 每一招（含付費尾招）都有自己的角色動作，關鍵格對齊招式三段：前搖結束（0.4）、出招結束（0.7）、收招結束（1.0），
## 而且出招前後的姿勢不同（真的有揮出去），不是同一個姿勢停著（NE-237）。
func _test_attack_poses() -> void:
	var actions: Dictionary = RigLibrary.load_json(HumanoidAnimator.ACTIONS_PATH).get("actions", {})
	for id in WEAPONS:
		var set := MeleeData.set_of(_weapon(id))
		for attack_id: Variant in set.combo(true):
			var attack := set.attack(str(attack_id), str(attack_id) == set.extension_attack())
			var action_id := PlayerVisual.MELEE_ACTION_PREFIX + str(attack.get("pose", ""))
			var action: Dictionary = actions.get(action_id, {})
			var keys: Dictionary = {}
			for key: Variant in action.get("keys", []):
				keys[roundi(float((key as Dictionary).get("t", -1.0)) * 100.0)] = (key as Dictionary).get("bones", {})
			var phases := keys.has(40) and keys.has(70) and keys.has(100)
			check(phases and str(keys.get(40)) != str(keys.get(70)),
					"%s/%s has its own %s with windup, strike and recovery keys" % [id, attack_id, action_id])


## 揮空不冒充命中、減特效仍讀得出命中（NE-236／NE-237）：每把近戰武器對空揮一次——沒有命中聲、命中標記、頓幀；
## 再把震動關掉、打開「減少閃光」，打到人一樣有命中聲、命中標記與扣血。
func _test_whiff_and_reduced_feedback() -> void:
	var shake_before := Settings.get_feel_scale("shake")
	var flashes_before := Settings.get_reduce_flashes()
	var heard: Array[StringName] = []
	var markers: Array[StringName] = []
	var listen := func(id: StringName) -> void: heard.append(id)
	var mark := func(kind: StringName) -> void: markers.append(kind)
	Sfx.sound_played.connect(listen)
	EventBus.hit_marker.connect(mark)
	for id in WEAPONS:
		for reduced: bool in [false, true]:
			Settings.set_feel_scale("shake", 0.0 if reduced else shake_before)
			Settings.set_reduce_flashes(reduced)
			await open_level(10.0)
			var player := _arm(id)
			var set := MeleeData.set_of(_weapon(id))
			var hit_sound := StringName(str((set.attack(str(set.combo()[0])).get("sounds", {}) as Dictionary).get("hit", "melee_hit")))
			await physics_frames(3)
			# 對空揮：前方沒有人。
			heard.clear()
			markers.clear()
			var stops := int(Feel.counters.get("hitstops", 0)) + int(Feel.counters.get("freezes", 0))
			player._try_melee()
			for i in 200:
				if player._melee_phase == Player.MeleePhase.NONE:
					break
				await physics_frames(1)
			var stops_after := int(Feel.counters.get("hitstops", 0)) + int(Feel.counters.get("freezes", 0))
			check(not heard.has(hit_sound) and markers.is_empty() and stops_after == stops,
					"%s whiff fakes no hit (reduced %s): sounds %s markers %s stops %d" % [id, reduced, heard, markers, stops_after - stops])
			# 打到人：命中聲、命中標記、扣血、擊退都在。
			var enemy := _dummy(maxf(24.0, set.max_range() * 0.6))
			await physics_frames(3)
			player._melee_cooldown_left = 0.0
			heard.clear()
			markers.clear()
			var before := enemy.health.current
			var pushed := 0.0
			player._try_melee()
			# 這一下接在剛才那一下後面，是連段的下一段：每一段有自己的命中聲（NE-261），要聽的是這一段的。
			hit_sound = StringName(str((player._melee_attack.get("sounds", {}) as Dictionary).get("hit", hit_sound)))
			for i in 200:
				pushed = maxf(pushed, absf(enemy.velocity.x))
				if player._melee_phase == Player.MeleePhase.NONE:
					break
				await physics_frames(1)
			# 輕擊只閃白不推人（NE-102），所以看命中聲、命中標記與扣血；推開的距離只記錄。
			check(heard.has(hit_sound) and not markers.is_empty() and enemy.health.current < before,
					"%s hit still reads with reduced effects %s: sounds %s markers %s damage %d push %.0f" % [id, reduced, heard, markers, before - enemy.health.current, pushed])
			await end_level(level)
	Sfx.sound_played.disconnect(listen)
	EventBus.hit_marker.disconnect(mark)
	Settings.set_feel_scale("shake", shake_before)
	Settings.set_reduce_flashes(flashes_before)


## 一揮打到好幾個目標，全畫面頓幀最多一次（NE-237）：不會因為目標多就疊出很長的停頓。
func _test_multi_target_hitstop() -> void:
	await open_level(10.0)
	var player := _arm("melee_maul")
	var set := MeleeData.set_of(_weapon("melee_maul"))
	var reach := set.max_range()
	for offset: float in [reach * 0.4, reach * 0.55, reach * 0.7]:
		_dummy(offset)
	await physics_frames(3)
	var hitstops := int(Feel.counters.get("hitstops", 0))
	player._try_melee()
	for i in 200:
		if player._melee_phase == Player.MeleePhase.NONE:
			break
		await physics_frames(1)
	await physics_frames(2)
	var added := int(Feel.counters.get("hitstops", 0)) - hitstops
	check(added <= 1, "one swing through three targets stops the whole screen at most once (%d)" % added)
	await end_level(level)


func _dummy(offset_px: float) -> Enemy:
	var enemy := spawn(GRUNT_PATH, 10.0)
	enemy.position = Vector2(level.player.global_position.x + offset_px, FLOOR_Y)
	enemy.data = enemy.data.duplicate()
	enemy.data.detect_range = 0.0
	enemy.data.attack_range = 0.0
	enemy.data.move_speed = 0.0
	enemy.health.setup(999, 0.0)
	return enemy


## 揮一次並等到收招結束，回傳目標損失的生命。
func _swing_at(weapon_id: String, offset_px: float, aim := Vector2.RIGHT) -> int:
	await open_level(10.0)
	var player := _arm(weapon_id)
	_aim(player, aim)
	var enemy := _dummy(offset_px)
	await physics_frames(3)
	var before := enemy.health.current
	player._try_melee()
	var frames_left := 200
	while player._melee_phase != Player.MeleePhase.NONE and frames_left > 0:
		await physics_frames(1)
		frames_left -= 1
	var lost := before - enemy.health.current
	enemy.queue_free()
	await physics_frames(3)
	await end_level(level)
	return lost


func _test_reach_and_dead_zone() -> void:
	check(await _swing_at("melee_dagger", 80.0) == 0, "the dagger cannot reach 80 px")
	check(await _swing_at("melee_dagger", 14.0) > 0, "the dagger hits at close range")
	check(await _swing_at("melee_glaive", 50.0) > 0, "the glaive hits at 50 px")
	check(await _swing_at("melee_glaive", 14.0) == 0, "the glaive has a dead zone up close")
	check(await _swing_at("melee_whip", 85.0) > 0, "the whip hits at 85 px")
	check(await _swing_at("melee_whip", 18.0) == 0, "the whip cannot hit at point-blank range")
	check(await _swing_at("melee_blade", 85.0) == 0, "the blade cannot reach 85 px")


func _test_single_hit_and_windows() -> void:
	await open_level(10.0)
	var player := _arm("melee_blade")
	var enemy := _dummy(24.0)
	await physics_frames(3)
	var before := enemy.health.current
	player._try_melee()
	check(enemy.health.current == before, "the wind-up deals no damage")
	var attack: Dictionary = player._melee_attack
	var guard := 0
	while player._melee_phase != Player.MeleePhase.NONE and guard < 120:
		await physics_frames(1)
		guard += 1
	check(before - enemy.health.current == int(attack["damage"]), "a sweeping swing hits the same target only once (%d damage)" % (before - enemy.health.current))
	# 出招區間內才走進範圍的目標也算（持續判定），但出招結束後走進來的不算。
	enemy.queue_free()  # 命中會讓玩家頓幀；第二次揮擊只留下要測的目標
	await physics_frames(2)
	var late := _dummy(120.0)
	await physics_frames(3)
	player._melee_cooldown_left = 0.0
	player._melee_combo_left = 0.0
	player._try_melee()
	while player._melee_phase == Player.MeleePhase.WINDUP:
		await physics_frames(1)
	late.global_position.x = player.global_position.x + 24.0
	await physics_frames(2)
	check(late.health.current < 999 or player._melee_phase != Player.MeleePhase.ACTIVE, "a target stepping in during the active window can be hit")
	while player._melee_phase != Player.MeleePhase.NONE:
		await physics_frames(1)
	var hp_after := late.health.current
	late.global_position.x = player.global_position.x + 20.0
	await physics_frames(6)
	check(late.health.current == hp_after, "nothing is hit after the active window ends")
	late.queue_free()
	await physics_frames(3)
	await end_level(level)


func _test_charge() -> void:
	await open_level(10.0)
	var player := _arm("melee_maul")
	var weapon := player.loadout.active_weapon()
	var swings := 0
	for i in weapon.magazine_size + 2:
		player._melee_cooldown_left = 0.0
		player._melee_combo_left = 0.0
		player._try_melee()
		if player._melee_phase != Player.MeleePhase.NONE:
			swings += 1
		player._end_melee()
		await physics_frames(2)
	check(swings == weapon.magazine_size, "the maul swings %d times then needs charging (swung %d)" % [weapon.magazine_size, swings])
	check(player.loadout.is_reloading(), "an empty charge starts recharging")
	await physics_frames(int(weapon.reload_time * 60.0) + 20)
	check(player.loadout.mag_in(player.loadout.active_slot) == weapon.magazine_size, "the charge is full again after recharging")
	var free := _arm("melee_blade")
	check(not free.loadout.active_weapon().has_magazine(), "a charge-free blade never runs out")
	await physics_frames(3)
	await end_level(level)


func _test_ui() -> void:
	await open_level(10.0)
	var player := _arm("melee_blade")
	player.loadout.equip(_weapon("melee_maul"))
	var bar := WeaponBar.new()
	level.add_child(bar)
	bar.update_from(player.loadout)
	check(bar.row_count() == Loadout.MAX_SLOTS and bar.row_state(1) == AmmoIcons.State.FULL, "the weapon bar shows melee weapons")
	for id in WEAPONS:
		var weapon := _weapon(id)
		check(MeleeArt.item_icon(weapon).get_size() == Vector2(MeleeArt.ITEM_SIZE), "%s has a card icon" % id)
		check(AmmoIcons.for_weapon(weapon).get_size() == Vector2(MeleeArt.AMMO_SIZE), "%s has a weapon-bar icon" % id)
	var page := WeaponsPage.new()
	check(page._kind_text(_weapon("melee_blade")) == "近戰", "inventory cards label melee weapons")
	bar.queue_free()
	await physics_frames(3)
	await end_level(level)


func _test_gun_unchanged() -> void:
	await open_level(10.0)
	var player := level.player
	_aim(player, Vector2.RIGHT)
	check(not player.holds_melee_weapon(), "the starting pistol is not a melee weapon")
	var enemy := _dummy(24.0)
	await physics_frames(3)
	var before := enemy.health.current
	player._try_melee()
	var guard := 0
	while player._melee_phase != Player.MeleePhase.NONE and guard < 120:
		await physics_frames(1)
		guard += 1
	check(before - enemy.health.current == int(MeleeData.attack(str(MeleeData.combo()[0]))["damage"]), "the melee key with a gun still uses the default light slash")
	var mag := player.loadout.mag_in(player.loadout.active_slot)
	player._fire_cooldown_left = 0.0
	player._try_fire()
	check(player.loadout.mag_in(player.loadout.active_slot) == mag - 1, "the pistol still fires")
	enemy.queue_free()
	await physics_frames(3)
	await end_level(level)


## 實際裝備與傷害事件：不能把舊招式／buffer 帶到新武器或復原後。
func _test_interruptions() -> void:
	await open_level(10.0)
	var player := _arm("melee_maul")
	player._try_melee()
	player._try_melee()
	player.loadout.select(0)
	check(player._melee_phase == Player.MeleePhase.NONE and player._melee_buffer_left == 0.0 and player._melee_index == -1,
		"switching weapons immediately discards the old melee attack and buffer")
	check(player._melee_cooldown_left > 0.0, "switching cannot erase an unpaid windup/recovery")
	var ammo := player.loadout.mag_in(0)
	player._try_fire()
	check(player.loadout.mag_in(0) == ammo, "switching to a gun cannot bypass unpaid melee recovery")
	player = _arm("melee_blade")
	player._try_melee()
	player._try_melee()
	var incoming := DamageInfo.create(1, Combat.Team.ENEMY, &"test", Vector2.LEFT)
	incoming.ignore_invulnerability = true
	player.health.take_damage(incoming)
	check(player._melee_phase == Player.MeleePhase.NONE and player._melee_buffer_left == 0.0 and player._melee_combo_left == 0.0,
		"ordinary damage immediately interrupts melee and removes the continuation")
	Fx.thaw_all()
	player._melee_cooldown_left = 0.0
	player._try_melee()
	player._try_melee()
	player.health.kill(incoming)
	check(player._melee_phase == Player.MeleePhase.NONE and player._melee_buffer_left == 0.0 and player._melee_index == -1,
		"death immediately clears the attack and its queued input")
	check(not player._try_melee(), "dead players cannot start or buffer melee through the public command")
	await end_level(level)


func _test_blocked_contact() -> void:
	await open_level(10.0)
	var player := _arm("melee_blade")
	var enemy := _dummy(24.0)
	enemy.hurtbox.guard = func(_info: DamageInfo) -> int: return Hurtbox.Guard.BLOCK
	await physics_frames(3)
	var before := enemy.health.current
	player._try_melee()
	var ticks := 0
	while player._melee_phase != Player.MeleePhase.RECOVERY and ticks < 120:
		await physics_frames(1)
		ticks += 1
	check(enemy.health.current == before and not player._melee_landed and not player._melee_feedback_done,
		"a blocked contact is not damage, a hit cancel, or melee hit feedback")
	check(player._melee_hit_ids.size() == 1, "a blocked target is contacted only once per swing")
	await end_level(level)


## action_press 是輪詢路徑合成輸入，並非實體手把；兩個近戰按鍵的 hold 規則相同。
func _test_held_input() -> void:
	for id in WEAPONS:
		for action: StringName in [&"melee", &"shoot"]:
			await open_level(10.0)
			var player := _arm(id)
			Progression.add_credits(1000)
			Progression.buy_upgrade(player.loadout.active_weapon(), Progression.find_upgrade(MeleeData.set_of(player.loadout.active_weapon()).extension_upgrade()))
			var offset := 50.0 if id == "melee_glaive" else 72.0 if id == "melee_whip" else 20.0
			var enemy := _dummy(offset)
			await physics_frames(3)
			Input.action_press(action)
			var advanced := false
			var starts := 0
			var previous_phase := Player.MeleePhase.NONE
			for tick in 180:
				enemy.global_position.x = player.global_position.x + offset
				await physics_frames(1)
				advanced = advanced or player._melee_index > 0
				if player._melee_phase == Player.MeleePhase.WINDUP and previous_phase != Player.MeleePhase.WINDUP:
					starts += 1
				previous_phase = player._melee_phase
			Input.action_release(action)
			check(enemy.health.current < 999, "%s hold %s includes real landed contacts" % [id, action])
			check(not advanced, "%s holding %s never selects an unrequested later/heavy attack" % [id, action])
			check(starts > 1, "%s holding %s repeats the short first attack after full recovery" % [id, action])
			await end_level(level)


## 第三物件必須真的持續跑 physics，不能只檢查它不在 freeze 名單。
class PhysicsPulse extends Node:
	var ticks := 0
	func _physics_process(_delta: float) -> void:
		ticks += 1


## 自然 ACTIVE sweep：不手動判定、不提前 thaw；晚進的真 Hurtbox 保留自身受擊反應。
func _test_late_target_hitstop() -> void:
	await open_level(10.0)
	var player := _arm("melee_blade")
	var first := _dummy(24.0)
	var late := _dummy(150.0)
	var unrelated := PhysicsPulse.new()
	level.add_child(unrelated)
	var late_hits: Array[Dictionary] = []
	late.health.damaged.connect(func(info: DamageInfo) -> void:
		late_hits.append({"frame": Engine.get_physics_frames(), "amount": info.amount,
			"velocity_x": late.velocity.x, "velocity_y": late.velocity.y,
			"flash": late._flash_left, "flinch": late._flinch_left, "stun": late._stun_left,
			"true_attacker": info.attacker != null and info.attacker.get_ref() == player,
			"freeze_attacker": info.freeze_attacker, "third_ticks": unrelated.ticks,
			"phase": player._melee_phase}))
	await physics_frames(3)
	player._try_melee()
	var guard := 120
	while not player._melee_feedback_done and guard > 0:
		await physics_frames(1)
		guard -= 1
	await level.get_tree().process_frame
	check(player._melee_landed and first.health.current < 999, "the first natural sweep target receives damage and contact feedback")
	check(player._melee_phase == Player.MeleePhase.ACTIVE, "the second Hurtbox enters while the real attack is ACTIVE")
	var pause: Array = Fx._frozen.get(player, [])
	check(not pause.is_empty(), "the first real contact actually pauses the attacker")
	var maximum_ms := int(ceil(0.1 * Settings.get_feel_scale("hitstop") * Feel.preset_scale("hitstop") * 1000.0)) + 10
	check(pause.is_empty() or int(pause[0]) - Time.get_ticks_msec() <= maximum_ms, "first target freeze has a finite configured bound")
	var third_before := unrelated.ticks
	var before := late.health.current
	late.global_position.x = player.global_position.x + 24.0
	guard = 120
	while late_hits.is_empty() and player._melee_phase != Player.MeleePhase.NONE and guard > 0:
		await physics_frames(1)
		guard -= 1
	await level.get_tree().process_frame
	check(late_hits.size() == 1 and late.health.current < before, "natural ACTIVE physics sweeps damage the late real Hurtbox")
	if not late_hits.is_empty():
		var hit := late_hits[0]
		check(not is_zero_approx(float(hit["velocity_x"])), "the late enemy receives nonzero actual knockback")
		check(float(hit["flash"]) > 0.0 or float(hit["flinch"]) > 0.0 or float(hit["stun"]) > 0.0, "the late enemy keeps its own actual hit reaction")
		check(bool(hit["true_attacker"]) and not bool(hit["freeze_attacker"]), "the late hit retains the real attacker without requesting another attacker freeze")
		check(int(hit["phase"]) == Player.MeleePhase.ACTIVE, "late damage originates from the naturally running ACTIVE phase")
	check(not Fx._frozen.has(player) and player.is_physics_processing(), "the attacker runs after its first contact pause and is not refrozen by the late enemy")
	check(not Fx._frozen.has(unrelated) and unrelated.ticks > third_before, "the unrelated third object actually advances physics during contact pauses")
	guard = 120
	while player._melee_phase != Player.MeleePhase.NONE and guard > 0:
		await physics_frames(1)
		guard -= 1
	check(player._melee_phase == Player.MeleePhase.NONE and late_hits.size() == 1, "the complete natural swing recovers and damages the late target exactly once")
	if not late_hits.is_empty():
		check(before - late.health.current == int(late_hits[0]["amount"]), "late health loss equals the one real damage event")
	print("NE236_NATURAL_LATE_HIT ", JSON.stringify({"first_health": first.health.current,
		"first_pause_deadline": pause[0] if not pause.is_empty() else -1, "late_before": before, "late_after": late.health.current, "hits": late_hits,
		"third_before": third_before, "third_after": unrelated.ticks, "attacker_frozen": Fx._frozen.has(player)}))
	await end_level(level)


func _test_growth_contract() -> void:
	var saved := Progression.snapshot()
	Progression.reset_run()
	Progression.add_credits(1000)
	for id in WEAPONS:
		var weapon := _weapon(id)
		var set := MeleeData.set_of(weapon)
		var upgrade := Progression.find_upgrade(set.extension_upgrade())
		check(upgrade != null and upgrade.validate().is_empty(), "%s has a valid catalog technique" % id)
		if upgrade == null:
			continue
		check(upgrade.applies_to(weapon) and not upgrade.applies_to(load("res://data/weapons/pistol.tres")) and not upgrade.applies_to(_weapon(WEAPONS[(WEAPONS.find(id) + 1) % WEAPONS.size()])), "%s technique applies only to its own weapon" % id)
		var before := Progression.credits
		check(Progression.buy_upgrade(weapon, upgrade) and Progression.credits == before - upgrade.cost, "%s purchase pays the exact catalog price" % id)
		check(not Progression.buy_upgrade(weapon, upgrade) and Progression.credits == before - upgrade.cost, "%s duplicate purchase is rejected without spending" % id)
		var tuned := Progression.tuned(weapon)
		check(tuned.fire_interval == weapon.fire_interval and tuned.magazine_size == weapon.magazine_size, "%s unlock is not a passive damage/charge buff" % id)
		var page := UpgradesPage.new()
		var entry := page._entry_for(tuned, upgrade)
		page.free() # 型錄描述檢查不留下未進 tree 的 UI 節點。
		check(entry.dimmed and not entry.action_enabled and entry.detail_body.contains("按住") and entry.detail_body.contains("護盾"), "%s existing upgrade card explains optional input and energy" % id)
	var prices := EconomyReport.price_list()
	check(prices.required == 570 and prices.optional == 540 and prices.upgrades == 910 and prices.optional_list.size() == 5, "optional melee costs remain visible without raising the original 570-credit required budget")
	print("NE237_ECONOMY ",JSON.stringify(prices))
	var bought := Progression.snapshot()
	var install := Progression.prepare_install(bought)
	print("NE237_INSTALL_CONTRACT ", install.get("error", "accepted"))
	check(not install.has("error") or str(install.get("error", "")).contains("unknown weapon"), "strict install accepts the melee catalog or reports the explicit NE-230 missing-catalog dependency")
	Progression.reset_run()
	Progression.restore(bought)
	for id in WEAPONS:
		check(Progression.has_upgrade(_weapon(id), MeleeData.set_of(_weapon(id)).extension_upgrade()), "%s snapshot restores the unlock (not a real exit/resume test)" % id)
	var foreign := bought.duplicate(true)
	foreign.upgrades.melee_blade = ["technique_dagger"]
	check(Progression.prepare_install(foreign).has("error"), "strict install rejects a technique saved under the wrong weapon")
	Progression.reset_run()
	var first := Progression.find_upgrade(&"technique_dagger")
	check(not Progression.buy_upgrade(_weapon(WEAPONS[0]), first) and Progression.credits == 0, "insufficient credits do not buy or spend")
	Progression.restore(saved)


func _finish_swing(player: Player) -> void:
	var ticks := 240
	while player._melee_phase != Player.MeleePhase.NONE and ticks > 0:
		await physics_frames(1)
		ticks -= 1
	check(ticks > 0, "the actual melee action finishes within four seconds")


func _test_optional_tails() -> void:
	for id in WEAPONS:
		await open_level(10.0)
		var player := _arm(id)
		var weapon := player.loadout.active_weapon()
		var set := MeleeData.set_of(weapon)
		Progression.add_credits(1000)
		check(Progression.buy_upgrade(weapon, Progression.find_upgrade(set.extension_upgrade())), "%s tail bought through public progression" % id)
		var chain := set.combo(true)
		for index in chain.size():
			var before_guard := player.guard
			check(player._try_melee() and player._melee_index == index, "%s explicit tap selects step %d" % [id, index])
			var attack: Dictionary = player._melee_attack
			check(is_equal_approx(before_guard - player.guard, float(attack.guard_cost)), "%s step %d pays its real guard cost" % [id, index])
			if index == chain.size() - 1:
				check(float(attack.cancel_after) == float(attack.recovery) and float(attack.guard_cost) > 0.0, "%s optional tail must pay full recovery and energy" % id)
				player._try_melee() # 不能借尾招循環 buffer 取消。
			await _finish_swing(player)
		check(player._melee_index == -1 and player._melee_buffer_left == 0.0, "%s terminal action clears continuation and cannot loop" % id)
		await end_level(level)
	# 有電量的錘：缺護盾的尾招拒絕不先消耗電量。
	await open_level(10.0)
	var player := _arm("melee_maul")
	Progression.add_credits(1000)
	Progression.buy_upgrade(player.loadout.active_weapon(), Progression.find_upgrade(&"technique_maul"))
	for step in 2:
		player._try_melee()
		await _finish_swing(player)
	player.guard = 29.0
	player._guard_regen_delay_left = 10.0
	var charge := player.loadout.mag_in(player.loadout.active_slot)
	check(not player._try_melee() and player.guard == 29.0 and player.loadout.mag_in(player.loadout.active_slot) == charge, "insufficient tail energy rejects atomically before charge spending")
	check(player._melee_phase == Player.MeleePhase.NONE and player._melee_index == -1 and player._melee_commands.remaining() == 0.0, "energy refusal clears the chain and command")
	await end_level(level)


func _event_tap(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	Input.flush_buffered_events()


func _test_command_paths() -> void:
	for event_path in [false, true]:
		await open_level(10.0)
		var player := _arm("melee_blade")
		if event_path:
			_event_tap(&"melee")
		else:
			Input.action_press(&"melee")
		await physics_frames(2)
		Input.action_release(&"melee")
		print("COMMAND_DIAG event=", event_path, " phase=", player._melee_phase, " index=", player._melee_index, " pending=", player._melee_commands.remaining())
		check(player._melee_phase != Player.MeleePhase.NONE and player._melee_index == 0, "event=%s starts exactly one first swing" % event_path)
		var ticks := 120
		while player._melee_phase != Player.MeleePhase.RECOVERY and ticks > 0:
			await physics_frames(1)
			ticks -= 1
		# 揮空收招末端才點按，防止超過短 buffer。
		while player._melee_time < float(player._melee_attack.recovery) - 0.08:
			await physics_frames(1)
		if event_path:
			_event_tap(&"shoot")
		else:
			Input.action_press(&"shoot")
		await physics_frames(2)
		Input.action_release(&"shoot")
		ticks = 40
		while player._melee_index == 0 and ticks > 0:
			await physics_frames(1)
			ticks -= 1
		check(player._melee_index == 1, "event=%s second input starts the second swing once" % event_path)
		await _finish_swing(player)
		check(player._melee_index == 1, "event=%s event/poll dedup does not fabricate a third tap" % event_path)
		await end_level(level)
	# 真正的 mapped JoypadButton 事件，合成而非實體手把。
	await open_level(10.0)
	var player := _arm("melee_blade")
	var joy: InputEventJoypadButton
	for binding in InputMap.action_get_events(&"melee"):
		if binding is InputEventJoypadButton:
			joy = binding.duplicate()
			break
	check(joy != null, "melee has an actual mapped controller button")
	if joy != null:
		joy.pressed = true
		Input.parse_input_event(joy)
		await level.get_tree().process_frame
		await level.get_tree().process_frame
		await physics_frames(2)
		joy = joy.duplicate()
		joy.pressed = false
		Input.parse_input_event(joy)
		check(player._melee_index == 0 and player._melee_phase != Player.MeleePhase.NONE, "synthetic mapped controller event starts the same first swing")
	await end_level(level)
	# 局部凍結仍接受短點按；長凍結的 command 到期不能保存到恢復之後。
	await open_level(10.0)
	player = _arm("melee_blade")
	player._try_melee()
	Fx.freeze([player], MeleeData.buffer_time() + 0.15)
	_event_tap(&"melee")
	await level.get_tree().process_frame
	check(player._melee_commands.remaining() > 0.0 and player.process_mode == Node.PROCESS_MODE_DISABLED, "input child receives a tap while actual Fx freezes the attacker")
	var expiry := Time.get_ticks_msec() + int(MeleeData.buffer_time() * 1000.0) + 30
	while Time.get_ticks_msec() < expiry:
		await level.get_tree().process_frame
	print("FROZEN_BUFFER_DIAG remaining=",player._melee_commands.remaining()," time=",Time.get_ticks_msec())
	check(player._melee_commands.remaining() == 0.0, "buffer expires by monotonic time while the parent is frozen")
	Fx.thaw_all()
	await _finish_swing(player)
	check(player._melee_index == 0, "an expired frozen command cannot advance the chain")
	await end_level(level)


func _test_refusals_and_extra_interruptions() -> void:
	await open_level(10.0)
	var player := _arm("melee_blade")
	player._try_melee()
	player.mount_vehicle(null)
	check(player._melee_phase == Player.MeleePhase.WINDUP, "an invalid mount request does not erase the paid swing")
	Input.action_press(&"block")
	player._update_blocking()
	check(not player.is_blocking and player._melee_phase == Player.MeleePhase.WINDUP, "guard cannot cancel the unpaid windup")
	Input.action_release(&"block")
	player._try_melee()
	check(player.begin_phone_call(1), "a grounded player can use the real phone command")
	check(player._melee_phase == Player.MeleePhase.NONE and player._melee_commands.remaining() == 0.0, "phone entry clears the active action and command")
	check(not player._try_melee(), "phone state rejects melee")
	await end_level(level)
	await open_level(10.0)
	player = _arm("melee_blade")
	player._try_melee()
	player._try_melee()
	player._guard_break()
	check(player._melee_phase == Player.MeleePhase.NONE and player._melee_index == -1 and not player._try_melee(), "guard break clears action and rejects staggered commands")
	await end_level(level)
	await open_level(10.0)
	player = _arm("melee_blade")
	var vehicle := Vehicle.new()
	vehicle.configure(load("res://data/vehicles/bulwark.tres"))
	level.add_child(vehicle)
	player._try_melee()
	player._try_melee()
	player.mount_vehicle(vehicle)
	check(player.state == Player.State.MOUNTED and player._melee_phase == Player.MeleePhase.NONE and player._melee_commands.remaining() == 0.0 and not player._try_melee(), "valid vehicle mount interrupts and mounted input is rejected")
	player.dismount_vehicle(false)
	player._melee_cooldown_left = 0.0
	player._try_melee()
	var token := GameplayLock.acquire(level)
	_event_tap(&"melee")
	check(player._melee_commands.remaining() == 0.0 and player._melee_phase == Player.MeleePhase.NONE and not player._try_melee(), "real gameplay lock clears input and refuses both event and direct paths")
	GameplayLock.release(token)
	level.get_tree().paused = true
	_event_tap(&"melee")
	check(player._melee_commands.remaining() == 0.0 and not player._try_melee(), "paused input refuses event and direct paths")
	level.get_tree().paused = false
	player.loadout.select(0)
	player._melee_cooldown_left = 0.0
	player._try_melee()
	var ammo := player.loadout.mag_in(0)
	player._try_fire()
	check(player.loadout.mag_in(0) == ammo, "direct gun command cannot cancel melee windup")
	await end_level(level)


## Actual physics owns raising/cancelling and projectile contact. No direct guard,
## contact query, phase advancement, hitstop release or altered weapon timings.
func _test_weapon_guard_transition() -> void:
	var reaches := {"melee_dagger":14.0, "melee_blade":24.0, "melee_maul":20.0, "melee_glaive":50.0, "melee_whip":70.0}
	var spec := load("res://data/projectiles/grunt_shot.tres") as ProjectileSpec
	for id in WEAPONS:
		for face in [1, -1]:
			for outcome in ["block", "parry", "rear"]:
				await open_level(10.0)
				var player := _arm(id)
				for arg in OS.get_cmdline_user_args():
					if arg.begins_with("--weapon-guard-evidence-out="):
						# Software rendering can consume 4.2 wall seconds before the
						# real presentation tween has finished. Await its real signal.
						for child in level.get_children():
							if child is ChapterCard:
								await child.finished
				_aim(player, Vector2(face, 0.0))
				var target := _dummy(float(reaches[id]) * face)
				await physics_frames(3)
				var label := "%s face=%d %s" % [id, face, outcome]
				check(player._try_melee(), label + " begins a paid real swing")
				var attack := player._melee_attack.duplicate(true)
				var ticks := 180
				var hitstop_seen := false
				while not player.is_melee_cancellable() and ticks > 0:
					hitstop_seen = hitstop_seen or Fx._frozen.has(player)
					await physics_frames(1)
					ticks -= 1
				check(ticks > 0 and hitstop_seen and target.health.current == 999 - int(attack.damage)
					and (player._melee_landed or (player._melee_phase == Player.MeleePhase.NONE and float(attack.cancel_after) >= float(attack.recovery))),
					label + " naturally lands and pays through local hitstop to its cancel window")
				# The return recipient is a different real Enemy, not a mocked receive().
				target.queue_free()
				var recipient := _dummy(100.0 * face)
				var return_hits: Array[int] = []
				recipient.health.damaged.connect(func(info: DamageInfo) -> void: return_hits.append(info.amount))
				await physics_frames(2)
				_guard_input(face < 0, true)
				ticks = 60
				while not player.is_blocking and ticks > 0:
					await physics_frames(1)
					ticks -= 1
				check(ticks > 0 and player._melee_phase == Player.MeleePhase.NONE and player._melee_index == -1
					and player._melee_commands.remaining() == 0.0, label + " real held block cancels only after payment and clears the old chain")
				if outcome != "parry":
					ticks = 60
					while player._block_time <= player.parry_window_length() + 0.03 and ticks > 0:
						await physics_frames(1)
						ticks -= 1
					check(ticks > 0 and player.is_blocking and not player.is_parry_window(), label + " naturally reaches the normal guard window")
				var hp := player.health.current
				var energy := player.guard
				var damage_hits: Array[int] = []
				player.health.damaged.connect(func(info: DamageInfo) -> void: damage_hits.append(info.amount))
				var side: int = -face if outcome == "rear" else face
				var shot := ProjectilePool.spawn(spec, player.global_position + Vector2(side * 20.0, -22.0), Vector2(-side, 0.0), Combat.Team.ENEMY)
				check(shot != null, label + " spawns through the real projectile pool")
				ticks = 90
				var reflected := false
				while shot != null and shot.active and ticks > 0:
					await physics_frames(1)
					reflected = reflected or shot.team == Combat.Team.PLAYER
					ticks -= 1
				check(ticks > 0, label + " contact and any return flight naturally finish")
				if outcome == "parry":
					check(reflected and return_hits == [spec.damage * 2] and recipient.health.current == 999 - spec.damage * 2,
						label + " window reflects a real projectile into exactly one doubled-damage enemy hit")
					check(player.health.current == hp and damage_hits.is_empty() and is_equal_approx(player.guard, energy),
						label + " parry preserves player health and energy")
				elif outcome == "block":
					check(not reflected and return_hits.is_empty() and player.health.current == hp and damage_hits.is_empty()
						and is_equal_approx(energy - player.guard, spec.damage * player.tuning.guard_cost_per_damage),
						label + " late front contact spends exactly guard cost without health damage or return hit")
				else:
					check(not reflected and return_hits.is_empty() and damage_hits == [spec.damage] and player.health.current == hp - spec.damage
						and is_equal_approx(player.guard, energy), label + " rear contact deals one health hit without spending directional guard")
				var charge := player.loadout.mag_in(player.loadout.active_slot)
				var contact_hp := player.health.current
				var contact_guard := player.guard
				# Both production command paths must refuse a tap while the shield is held.
				_event_tap(&"melee")
				Input.action_press(&"shoot")
				await physics_frames(2)
				Input.action_release(&"shoot")
				check(player._melee_commands.remaining() == 0.0 and player._melee_phase == Player.MeleePhase.NONE
					and player.loadout.mag_in(player.loadout.active_slot) == charge, label + " event melee and polled shoot cannot queue or spend through a held shield")
				await _guard_capture(id, face, outcome, player)
				_guard_input(face < 0, false)
				await physics_frames(18)
				check(player._melee_phase == Player.MeleePhase.NONE and player._melee_index == -1
					and player.loadout.mag_in(player.loadout.active_slot) == charge, label + " lowering shield cannot replay a refused or old combo")
				print("NE236_WEAPON_GUARD ", JSON.stringify({"weapon":id, "face":face, "outcome":outcome, "input":"event" if face < 0 else "poll",
					"natural_hitstop":hitstop_seen, "health_before":hp, "health_after":contact_hp, "guard_before":energy,
					"guard_after":contact_guard, "reflected":reflected, "return_hits":return_hits, "player_hits":damage_hits,
					"pending":player._melee_commands.remaining(), "final_index":player._melee_index}))
				await end_level(level)
		# A held shield during a miss cannot erase windup, active or full recovery.
		await open_level(10.0)
		var player := _arm(id)
		check(player._try_melee(), id + " whiff starts naturally")
		var recovery := float(player._melee_attack.recovery)
		_guard_input(false, true)
		var ticks := 180
		var recovery_frames := 0
		var early_shield := false
		while player._melee_phase != Player.MeleePhase.NONE and ticks > 0:
			early_shield = early_shield or player.is_blocking
			if player._melee_phase == Player.MeleePhase.RECOVERY:
				recovery_frames += 1
			await physics_frames(1)
			ticks -= 1
		await physics_frames(2)
		check(ticks > 0 and not early_shield and recovery_frames >= int(recovery * 60.0) - 1,
			id + " held shield never cancels a whiff before its real full recovery (%d frames)" % recovery_frames)
		check(player.is_blocking and player._melee_index == -1 and player._melee_commands.remaining() == 0.0,
			id + " natural completion raises shield and clears the expired swing")
		print("NE236_GUARD_WHIFF ", JSON.stringify({"weapon":id, "recovery_seconds":recovery, "recovery_frames":recovery_frames,
			"early_shield":early_shield, "blocking":player.is_blocking, "index_on_raise":player._melee_index}))
		_guard_input(false, false)
		await physics_frames(2)
		_event_tap(&"melee")
		await physics_frames(2)
		check(player._melee_index == 0, id + " a new tap immediately after lowering begins a fresh first swing, not the old missed chain")
		print("NE236_GUARD_FRESH_TAP ", JSON.stringify({"weapon":id, "phase":player._melee_phase, "index":player._melee_index}))
		await _finish_swing(player)
		await physics_frames(3)
		await end_level(level)


func _guard_input(event_path: bool, pressed: bool) -> void:
	if event_path:
		var event := InputEventAction.new()
		event.action = &"block"
		event.pressed = pressed
		Input.parse_input_event(event)
	else:
		if pressed:
			Input.action_press(&"block")
		else:
			Input.action_release(&"block")


func _guard_capture(id: String, face: int, outcome: String, player: Player) -> void:
	for arg in OS.get_cmdline_user_args():
		if not arg.begins_with("--weapon-guard-evidence-out="):
			continue
		var out := arg.trim_prefix("--weapon-guard-evidence-out=")
		DirAccess.make_dir_recursive_absolute(out)
		var camera := runner.get_viewport().get_camera_2d()
		camera.set_physics_process(false)
		camera.zoom = Vector2.ONE * 3.4
		camera.global_position = player.global_position + Vector2(face * 26.0, -34.0)
		camera.reset_smoothing()
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		var image := preload("res://tools/viewport_capture.gd").image(runner.get_viewport())
		var name := "NE-236-weapon-guard-%s-%s-%s.png" % [id, "left" if face < 0 else "right", outcome]
		check(image.save_png(out.path_join(name)) == OK, "native guard capture saves " + name)
		print("NE236_GUARD_CAPTURE ", JSON.stringify({"image":name, "renderer":RenderingServer.get_current_rendering_method(),
			"adapter":RenderingServer.get_video_adapter_name(), "width":image.get_width(), "height":image.get_height(),
			"zoom":str(camera.zoom), "blocking":player.is_blocking, "block_time":player._block_time,
			"health":player.health.current, "guard":player.guard, "phase":player._melee_phase}))


func _test_paid_cancels_and_facing() -> void:
	await open_level(10.0)
	var player := _arm("melee_blade")
	var enemy := _dummy(20.0)
	await physics_frames(3)
	player._try_melee()
	var direction := player._melee_direction(player._melee_attack)
	_aim(player, Vector2.LEFT)
	await physics_frames(1)
	check(player.facing == 1 and player._melee_direction(player._melee_attack).is_equal_approx(direction), "aim changes during windup do not rotate the paid swing")
	var ticks := 120
	while not player.is_melee_cancellable() and ticks > 0:
		await physics_frames(1)
		ticks -= 1
	check(player._melee_landed and ticks > 0, "locked original-facing swing lands and reaches its paid cancel window")
	Input.action_press(&"block")
	player._update_blocking()
	Input.action_release(&"block")
	check(player.is_blocking and player._melee_phase == Player.MeleePhase.NONE and player._melee_index == -1 and player._melee_commands.remaining() == 0.0, "guard at a paid cancel window ends the old action and chain")
	await end_level(level)
	await open_level(10.0)
	player = level.player # 槍械的預設近戰，有真命中後才准許射擊取消。
	_aim(player, Vector2.RIGHT)
	enemy = _dummy(20.0)
	await physics_frames(3)
	player._try_melee()
	ticks = 120
	while not player.is_melee_cancellable() and ticks > 0:
		await physics_frames(1)
		ticks -= 1
	var ammo := player.loadout.mag_in(0)
	player._try_fire()
	check(player.loadout.mag_in(0) == ammo - 1 and player._melee_phase == Player.MeleePhase.NONE and player._melee_index == -1, "gun fire after a landed paid cancel consumes ammo and clears the melee chain")
	await end_level(level)
	await open_level(10.0)
	player = _arm("melee_maul")
	enemy = _dummy(20.0)
	enemy._is_finishable = true
	await physics_frames(3)
	var charge := player.loadout.mag_in(player.loadout.active_slot)
	check(player._try_melee() and player.state == Player.State.NORMAL and player.loadout.mag_in(player.loadout.active_slot) == charge - 1, "armed melee never replaces a paid swing with a free nearby finisher")
	var info := DamageInfo.create(999, Combat.Team.ENEMY, &"test")
	player.health.kill(info)
	_event_tap(&"melee")
	await level.get_tree().process_frame
	check(player._melee_commands.remaining() == 0.0 and not player._try_melee(), "dead state rejects buffered event and direct commands")
	await end_level(level)


func _test_tail_contacts() -> void:
	var offsets := [20.0, 24.0, 24.0, 50.0, 72.0]
	for id in WEAPONS:
		await open_level(10.0)
		var player := _arm(id)
		var weapon := player.loadout.active_weapon()
		var set := MeleeData.set_of(weapon)
		Progression.add_credits(1000)
		Progression.buy_upgrade(weapon, Progression.find_upgrade(set.extension_upgrade()))
		for step in set.combo().size():
			player._try_melee()
			await _finish_swing(player)
		var target := _dummy(offsets[WEAPONS.find(id)])
		var far := _dummy(220.0)
		var close: Enemy
		if id in ["melee_glaive", "melee_whip"]:
			close = _dummy(14.0)
		await physics_frames(3)
		check(player._try_melee() and player._melee_index == set.combo().size(), "%s actual tail starts for contact testing" % id)
		var expected := int(player._melee_attack.damage)
		var limit := 240
		while player._melee_phase != Player.MeleePhase.ACTIVE and limit > 0:
			await physics_frames(1)
			limit -= 1
		check(limit > 0 and player._melee_landed, "%s tail deals damage only at its actual active window" % id)
		if player._melee_phase == Player.MeleePhase.ACTIVE:
			player._melee_hit_pass()
		await _finish_swing(player)
		check(999 - target.health.current == expected, "%s entire sweep plus repeated query hits a HealthComponent exactly once" % id)
		check(far.health.current == 999, "%s tail cannot hit a distant target" % id)
		if is_instance_valid(close):
			check(close.health.current == 999, "%s optional tail preserves its close dead zone" % id)
		await end_level(level)


## Real callers, not direct pool/fire substitutes. No frame runs between corruption
## and the attempt, so every observable side effect belongs to that one attempt.
func _test_real_shot_preflight() -> void:
	await open_level(10.0)
	var player := level.player
	var vehicle := Vehicle.new()
	vehicle.configure((load("res://data/vehicles/bulwark.tres") as VehicleData).duplicate(true))
	level._entities.add_child(vehicle)
	var sounds := [0]
	var on_sound := func(_id: StringName) -> void: sounds[0] += 1
	Sfx.sound_played.connect(on_sound)
	var saved_marks := InputFeel._marks.duplicate()
	for fault: String in ["spec_nan", "spec_huge", "spec_damage", "spec_style", "spec_identity", "missing_spec", "sound", "direction", "bloom", "combined_spread", "rate_nan", "rate_zero", "rate_huge"]:
		var weapon := (load("res://data/weapons/rifle.tres") as WeaponData).duplicate(true)
		weapon.id = StringName("test_no_such_weapon_preflight_" + fault)
		weapon.projectile = weapon.projectile.duplicate() # External resources are not deep-cloned by duplicate(true).
		weapon.recoil = 64.0 # Valid test data makes accidental recoil observable.
		player.loadout.reset(weapon)
		weapon = player.loadout.active_weapon()
		player.velocity = Vector2.ZERO
		player._visual._fire_flash = 0.0
		player._visual._input.recoil = 0.0
		vehicle._muzzle_flash = 0.0
		player._fire_cooldown_left = 0.0
		player._melee_cooldown_left = 0.0
		player.aim_dir = Vector2.RIGHT
		player.aim_bloom = 0.0
		player.cyber.debug_set_ability(null)
		match fault:
			"spec_nan": weapon.projectile.speed = NAN
			"spec_huge": weapon.projectile.speed = 1e308
			"spec_damage": weapon.projectile.damage = 2147483647
			"spec_style": weapon.projectile.visual_style = "test_no_such_style"
			"spec_identity": weapon.projectile.source_id = &""
			"missing_spec": weapon.projectile = null
			"sound": weapon.fire_sound = &"test_no_such_sound"
			"direction": player.aim_dir = Vector2(NAN, 0.0)
			"bloom": player.aim_bloom = NAN
			"combined_spread":
				weapon.random_spread_degrees = 360.0
				player.aim_bloom = 1.0
			"rate_nan", "rate_zero", "rate_huge":
				var ability := CyberAbilityData.new()
				ability.magnitude = NAN if fault == "rate_nan" else (-1.0 if fault == "rate_zero" else 1e308)
				player.cyber.debug_set_ability(ability)
				player.cyber._active_left = 1.0
		InputFeel.mark(&"shoot")
		var before := _shot_state(player, vehicle, sounds[0])
		var bloom_before := player.aim_bloom
		player._try_fire()
		var after := _shot_state(player, vehicle, sounds[0])
		for key: String in before:
			check(before[key] == after[key], "real Player rejects %s before %s changes" % [fault, key])
		check((is_nan(bloom_before) and is_nan(player.aim_bloom)) or bloom_before == player.aim_bloom, "real Player rejects %s before bloom changes" % fault)
		print("NE237_SHOT_PREFLIGHT ", JSON.stringify({"caller":"Player", "fault":fault, "before":before, "after":after}))
		# Player-only bloom/overclock inputs are not vehicle inputs.
		if fault not in ["bloom", "combined_spread", "rate_nan", "rate_zero", "rate_huge"]:
			player.velocity = Vector2.ZERO # Isolate this caller from the preceding rejected-shot red.
			vehicle.data.weapon = weapon
			vehicle.aim_dir = player.aim_dir
			vehicle._fire_cooldown = 0.0
			before = _shot_state(player, vehicle, sounds[0])
			vehicle._try_fire()
			after = _shot_state(player, vehicle, sounds[0])
			for key: String in before:
				check(before[key] == after[key], "real Vehicle rejects %s before %s changes" % [fault, key])
			print("NE237_SHOT_PREFLIGHT ", JSON.stringify({"caller":"Vehicle", "fault":fault, "before":before, "after":after}))
		player.velocity = Vector2.ZERO
		player.aim_dir = Vector2.RIGHT
		player.aim_bloom = 0.0
		player.cyber.debug_set_ability(null)
		vehicle.aim_dir = Vector2.RIGHT
	# Exhaustion is graceful degradation of an accepted shot, not unsafe data.
	var valid := (load("res://data/weapons/rifle.tres") as WeaponData).duplicate(true)
	player.loadout.reset(valid)
	vehicle.data.weapon = valid
	for i in ProjectilePool.MAX_SIZE:
		ProjectilePool.spawn(valid.projectile, Vector2(160.0, 280.0), Vector2.RIGHT, Combat.Team.PLAYER)
	check(ProjectilePool.active_count() == ProjectilePool.MAX_SIZE, "the real projectile pool is exhausted for the valid-shot control")
	var mag := player.loadout.mag_in(player.loadout.active_slot)
	var sound_before: int = sounds[0]
	player._fire_cooldown_left = 0.0
	player._try_fire()
	check(player.loadout.mag_in(player.loadout.active_slot) == mag - valid.ammo_per_shot and player._fire_cooldown_left == valid.fire_interval, "a valid full-pool Player shot still pays ammo and cooldown")
	check(sounds[0] > sound_before and player._visual._input.recoil == 1.0, "a valid full-pool Player shot retains accepted feedback")
	sound_before = sounds[0]
	vehicle._fire_cooldown = 0.0
	vehicle._try_fire()
	check(vehicle._fire_cooldown == valid.fire_interval and vehicle._muzzle_flash == 0.07 and sounds[0] > sound_before, "a valid full-pool Vehicle shot retains cooldown and feedback")
	check(ProjectilePool.active_count() == ProjectilePool.MAX_SIZE, "full-pool caller controls do not exceed the work/storage budget")
	Sfx.sound_played.disconnect(on_sound)
	InputFeel._marks = saved_marks
	await end_level(level)


func _shot_state(player: Player, vehicle: Vehicle, sound_count: int) -> Dictionary:
	return {"mag":player.loadout.mag_in(player.loadout.active_slot), "cooldown":player._fire_cooldown_left,
		"velocity":player.velocity, "visual_flash":player._visual._fire_flash, "visual_recoil":player._visual._input.recoil,
		"vehicle_cooldown":vehicle._fire_cooldown, "vehicle_flash":vehicle._muzzle_flash,
		"sounds":sound_count, "particles":Fx.particle_count(), "projectiles":ProjectilePool.active_count(),
		"muzzle_marks":WeaponSystem._last_muzzle_fx.duplicate(), "input_marks":InputFeel._marks.duplicate(), "input_samples":InputFeel.samples}


## The paid role belongs to the frozen chain, even if live definitions or their
## extension label are edited after the preceding real action has finished.
func _test_frozen_paid_tail_refusal() -> void:
	for id: String in ["melee_dagger", "melee_maul"]:
		for fault: String in ["guard_cost", "cancel_after", "missing_tail", "role_relabel"]:
			await open_level(10.0)
			var player := _arm(id)
			var weapon := player.loadout.active_weapon()
			var set := MeleeData.set_of(weapon)
			Progression.add_credits(1000)
			check(Progression.buy_upgrade(weapon, Progression.find_upgrade(set.extension_upgrade())), "%s/%s unlocks a real optional tail" % [id, fault])
			var base_count := set.combo().size()
			var tail_id := str(set.combo(true).back())
			for step in base_count:
				check(player._try_melee() and player._melee_index == step, "%s/%s naturally executes preceding step %s" % [id, fault, step])
				await _finish_swing(player)
			check(player._melee_chain.size() == base_count + 1 and str(player._melee_chain.back()) == tail_id, "%s/%s has the paid tail in its frozen chain" % [id, fault])
			var live := set.live_attack(tail_id)
			var saved_tail := live.duplicate(true)
			var saved_extension: Dictionary = (set._data.extension as Dictionary).duplicate(true)
			match fault:
				"guard_cost": live[String("guard_cost")] = 0.0
				"cancel_after": live[String("cancel_after")] = 0.0
				"missing_tail": (set._data.attacks as Dictionary).erase(tail_id)
				"role_relabel":
					live[String("guard_cost")] = 0.0
					(set._data.extension as Dictionary)[String("attack")] = str(set.combo()[0])
			var original_path := set.path
			set.path += "/test_no_such_attack_live_tail" # Label only this deliberate, post-load negative control.
			var charge := player.loadout.mag_in(player.loadout.active_slot)
			var guard_before := player.guard
			var input_before := InputFeel.samples
			check(not player._try_melee(), "%s/%s refuses a corrupted frozen paid tail, never a free fallback" % [id, fault])
			check(player._melee_phase == Player.MeleePhase.NONE and player._melee_index == -1 and player._melee_chain.is_empty(), "%s/%s refusal clears only the stale continuation" % [id, fault])
			check(player.guard == guard_before and player.loadout.mag_in(player.loadout.active_slot) == charge and InputFeel.samples == input_before, "%s/%s refuses before guard, charge or input resolution" % [id, fault])
			check(player._melee_commands.remaining() == 0.0 and player._melee_buffer_left == 0.0, "%s/%s leaves no buffered free tail" % [id, fault])
			print("NE237_FROZEN_TAIL ", JSON.stringify({"weapon":id,"fault":fault,"tail":tail_id,"phase":player._melee_phase,"guard_before":guard_before,"guard_after":player.guard,"charge_before":charge,"charge_after":player.loadout.mag_in(player.loadout.active_slot)}))
			# Restore authoritative cached JSON before any await or next fixture.
			set.path = original_path
			(set._data.attacks as Dictionary)[tail_id] = saved_tail
			set._data[String("extension")] = saved_extension
			player._end_melee(false)
			check(set.validate().is_empty(), "%s/%s restores the original valid live definition" % [id, fault])
			var fallback := set.attack("test_no_such_attack_base_move")
			check(not fallback.is_empty() and float(fallback.guard_cost) == 0.0 and float(fallback.windup) > 0.0, "normal missing-base fallback is still a safe light attack")
			await end_level(level)
