"""One-time portable NE295 packet; copies original bytes, never rewrites an epoch."""
from pathlib import Path
import json,hashlib,zipfile,shutil
TREE=Path(__file__).resolve().parents[2]
OUT=TREE/'pm/Nest-Egg/attachments/NE-295-character-lighting-2026-11-13'
assert not OUT.exists()
OUT.mkdir(parents=True)
INDEX={'base':'92521d0cf3c18bd3dad4b13a316844e70bfaecd0','candidate_version':2,'product_manifest_sha256':'440a3a3644dbe5914b83fe78f1cd6f80bfe704bbfe3d20bd0019e46dddd04620','archives':[],'selected':{},'final_epochs':{}}
def sha(b):return hashlib.sha256(b).hexdigest()
def archive(name,paths,kind):
 paths=sorted(set(paths));dst=OUT/name;rows={}
 with zipfile.ZipFile(dst,'x',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
  for p in paths:
   b=p.read_bytes();n=p.relative_to(TREE).as_posix();z.writestr(n,b);rows[n]={'bytes':len(b),'sha256':sha(b)}
 with zipfile.ZipFile(dst) as z:
  assert z.testzip() is None
  assert len(z.infolist())==len(rows)
  for m in z.infolist():assert sha(z.read(m))==rows[m.filename]['sha256']
 assert dst.stat().st_size<90_000_000
 INDEX['archives'].append({'file':name,'kind':kind,'bytes':dst.stat().st_size,'sha256':sha(dst.read_bytes()),'uncompressed_bytes':sum(r['bytes'] for r in rows.values()),'members':rows})
# Current actual replay tools plus frozen historical source copies and original source ZIPs.
source=[];epochs=[]
for folder in sorted((TREE/'work').glob('ne295-*')):
 if not folder.is_dir() or folder.name in ['ne295-delivery-v1','ne295-reader-drafts-v1']:continue
 for p in folder.rglob('*'):
  if not p.is_file() or 'userdata' in p.parts or '__pycache__' in p.parts:continue
  if (p.parent/'exit.json').is_file() and p.name=='exit.json':epochs.append(p.parent)
  suffix=p.suffix.lower()
  if suffix in ['.gd','.tscn','.py','.gdshader','.gdshaderinc','.txt','.cpp','.diff','.patch','.md','.uid'] or p.name=='.gdignore':source.append(p)
  elif p.parent==folder and suffix in ['.json','.zip']:source.append(p)
# Avoid duplicate raw-bearing source ZIPs (existing source containers here are all <1MB).
for p in source:assert p.stat().st_size<20_000_000,p
archive('source-tools-and-history.zip',source,'exact private producers/readers/history and pinned engine source')
for ep in sorted(set(epochs)):
 rel=ep.relative_to(TREE).as_posix();stem=ep.parent.name+'--'+ep.name
 paths=[p for p in ep.rglob('*') if p.is_file() and 'userdata' not in p.relative_to(ep).parts and p.suffix not in ['.raw','.png']]
 archive(stem+'--receipts.zip',paths,'original epoch receipts/logs/reports, including rejected epochs')
 captures=ep/'captures'
 if captures.is_dir():
  groups={}
  for p in captures.rglob('*'):
   if p.is_file() and p.suffix in ['.raw','.png']:
    bits=p.relative_to(captures).parts;group=bits[0] if len(bits)>1 else 'root';groups.setdefault(group,[]).append(p)
  for group,files in groups.items():archive(stem+'--'+group+'.zip',files,'original native float bytes and same-frame PNG, no resize')
# Include explicit final and original base product bytes with a familiar small exact source archive.
p=TREE/'work/ne295-v2-candidate/candidate-owned-source-v2.zip';shutil.copyfile(p,OUT/'candidate-owned-source-v2.zip')
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 rows={m.filename:{'bytes':m.file_size,'sha256':sha(z.read(m))} for m in z.infolist()}
INDEX['archives'].append({'file':'candidate-owned-source-v2.zip','kind':'final22+exact base18+manifest','bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'uncompressed_bytes':sum(r['bytes'] for r in rows.values()),'members':rows})
# A small visible original selection; the archives retain every version and every raw/PNG.
selections={
 'rooftop-old-context.png':'work/ne295-final-renderers-v1/cause-v1/captures/context/A0-main.png',
 'rooftop-world-context.png':'work/ne295-final-renderers-v1/cause-v1/captures/context/B0-main.png',
 'rooftop-rin-lighting.png':'work/ne295-final-renderers-v1/cause-v1/captures/normal/N0-original-main.png',
 'held.png':'work/ne295-final-renderers-v1/appearance-v2/captures/held/A0.png',
 'held-right-light.png':'work/ne295-final-renderers-v1/appearance-v2/captures/held/B0.png',
 'debris-and-chain.png':'work/ne295-final-renderers-v1/appearance-v2/captures/debris_dissolve/A0.png',
 'dissolve.png':'work/ne295-final-renderers-v1/appearance-v2/captures/debris_dissolve-transitions/dissolve-progress35.png',
 'worm.png':'work/ne295-final-renderers-v1/appearance-v2/captures/worm/A0.png',
 'forearm-final.png':'work/ne295-renderer-coverage-v1/basis-native-v3/captures/forearm/actual-old.png',
 'sit-actual.png':'work/ne295-renderer-coverage-v1/basis-native-v3/captures/sit_pose/actual-old.png'}
for i in range(3):
 for role in ['scene','head','body','body-source-alpha1']:selections[f'death-{i}-{role}.png']=f'work/ne295-final-renderers-v1/death-v2/captures/death/{i}-{role}.png'
(OUT/'selected').mkdir()
for label,relative in selections.items():
 b=(TREE/relative).read_bytes();(OUT/'selected'/label).write_bytes(b);INDEX['selected']['selected/'+label]={'source':relative,'bytes':len(b),'sha256':sha(b)}
INDEX['final_epochs']={
 'basis':{'epoch':'work/ne295-renderer-coverage-v1/basis-native-v3','reader':'work/ne295-renderer-coverage-v1/read_basis.py','result':'reader.json','records':55},
 'appearance':{'epoch':'work/ne295-final-renderers-v1/appearance-v2','reader':'work/ne295-final-renderers-v1/read_appearance_v3.py','result':'reader-v3.json','records':37},
 'worm':{'epoch':'work/ne295-final-renderers-v1/worm-v1','reader':'work/ne295-final-renderers-v1/read_worm.py','result':'reader.json','records':16},
 'death':{'epoch':'work/ne295-final-renderers-v1/death-v2','reader':'work/ne295-death-v1/read_v5.py','result':'reader-v5.json','records':12},
 'cause':{'epoch':'work/ne295-final-renderers-v1/cause-v1','reader':'work/ne295-final-renderers-v1/read_final_cause.py','result':'reader.json','records':16,'additional_isolated_ROIs':32}}
INDEX['archive_bytes']=sum(x['bytes'] for x in INDEX['archives']);INDEX['zip_file_entries']=sum(len(x['members']) for x in INDEX['archives'])
(OUT/'index.json').write_bytes((json.dumps(INDEX,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'packet':str(OUT),'archives':len(INDEX['archives']),'bytes':INDEX['archive_bytes'],'zip_file_entries':INDEX['zip_file_entries'],'selected':len(INDEX['selected'])},indent=2))
