"""Meaningful mutations of original natural-death pixels; never modifies originals."""
import argparse,importlib.util,json
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('death_reader',HERE.parent/'ne295-death-v1/read_v5.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def verify(folder):
 folder=Path(folder);v=json.loads((folder/'death.json').read_bytes());r=v['records'][1];part=r['before']['parts'][1];alpha=r['before']['opacity'];body=m.common.image(folder,r['images'][2]);ref=m.common.image(folder,r['images'][3]);m.body_alpha_check(body,alpha,part,ref)
 rows=[{'control':'original','result':'PASS'}]
 for name,image,geometry in [('empty',np.zeros_like(body),part),('double fade',body*np.array([1,1,1,alpha]),part),('old body no fade',ref,part),('misaligned geometry',body,{**part,'polygon':(np.asarray(part['polygon'])+100).tolist()})]:
  try:m.body_alpha_check(image,alpha,geometry,ref)
  except AssertionError as e:rows.append({'control':name,'result':'REJECT','reason':str(e)})
  else:raise AssertionError('negative accepted: '+name)
 return {'checks':len(rows),'failures':0,'raw_modified':False,'controls':rows}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder');p.add_argument('--out',required=True);a=p.parse_args();v=verify(a.folder);Path(a.out).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,indent=2))
