extends Node


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	var failures := 0
	for path: String in ["res://game/player/melee_held.gd", "res://core/melee_art.gd", "res://game/rig/character_rig.gd",
			"res://game/npc/npc_actor.gd", "res://game/player/world_prop_action.gd", "res://game/rig/rig_debris.gd",
			"res://game/creature/chain_creature.gd", "res://game/creature/worm_creature.gd", "res://game/enemies/cloud_serpent.gd",
			"res://tests/helpers/character_lighting_checks.gd", "res://tests/suite/test_melee_weapons.gd"]:
		var script := load(path) as Script
		if script == null or not script.can_instantiate():
			failures += 1
	print("NE295_FULL_AUTOLOAD_PARSE failures=", failures)
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 2)
