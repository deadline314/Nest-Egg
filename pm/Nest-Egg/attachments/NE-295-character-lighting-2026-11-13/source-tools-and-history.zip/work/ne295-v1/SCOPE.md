# NE295 candidate v1 — prepared, engine not yet run

Canonical linked worktree HEAD: `78c367b1efc2f7945196d9373b24c3d8377394ba`. Only the 20 paths in `candidate-v1.json` are candidates (13 runtime paths, six existing suites, one test helper). No primary C product, PM, index, save data, combat timing, armor membership or NPC art WIP was copied. The preliminary audit stays pinned to its original 8b bytes.

The exact unified diff includes the two newly added source files. `git diff --check` passes. The original selector stdout is retained; the final frozen candidate selects 75 groups. An earlier informal 76-group report preceded this freeze and is not the final scope. No suite has been run yet.

After Root's explicit START, only these two CPU engine entries are planned:

```
python work/ne295-v1/run_phase.py import-v1 --kind import
python work/ne295-v1/run_phase.py contracts-v1 --kind contracts
```

The second is a normal scene with full project autoloads. It reuses the newly added permanent helpers and the exact new MeleeWeapons method through the original smoke assertion collector, then shuts down through AudioRelease. It is not a substitute for the original affected selector. A separate parser entry exists but is unnecessary if contracts loads cleanly. Every phase has five isolated user environment paths, outer/inner before/after queue counts for both ports, nonblocking canonical primary lock, immutable full runtime/source and C459/v28 receipts, strict diagnostics and exact owned-process cleanup. Import may only add UIDs for pre-existing inputs; those original changes are explicitly listed before later freezes. No native capture or performance claim is authorized by these commands.

The world NPC, attachment and pooled-debris tests observe actual renderer bindings rather than inventing brightness values. Shader pixel behavior still requires native A/A, directional light/occluder single-factor and restore controls, including the Root-provided original rooftop `actual-c02-r02` Rin/Egret pose. Native testing must retain hand/grip/pose/normal/glow witnesses and separately read reflective base versus emission. The worm normal branch now uses matching rolled samples and the actual strip texture axes: the pinned engine's canvas shader only rotates normals by the item transform, not by each curved mesh section. Flat/missing normals and collapsed geometry retain safe neutral fallbacks.

`CharacterRig.bind_attachment(CanvasItem, Color)` / `unbind_attachment(CanvasItem)` do not change texture, region, pivot, transform or z; foreign materials and inherited-material items are not overridden. Weak references are pruned after free. Attachments remain outside body/armor/bounds, receive fill/cap and real flash once, and can restore their base tint. `set_local_lighting(Color)` only affects an independent rig's local cap and keeps fill=1; white restores the published stage default. BG57 owns the actual stage ambient/lights and texture-quality lifecycle.

The current candidate deliberately does not claim to have diagnosed the observed bright Rin hand. Normal headers and shared material routing are necessary evidence, not proof of native normal response or valid exposure. No acceptance checkbox is changed by this preparation.
