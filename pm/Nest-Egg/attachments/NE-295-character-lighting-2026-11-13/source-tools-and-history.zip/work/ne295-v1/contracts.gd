extends "res://tests/smoke_test.gd"


func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var checks := preload("res://tests/helpers/character_lighting_checks.gd")
	checks.rig_attachments(RigMeshSuite.new(self))
	checks.npc_context(NpcSuite.new(self))
	checks.debris(HitReactionSuite.new(self))
	checks.dissolve(EnemyVfxSuite.new(self))
	checks.worm(ChainCreatureSuite.new(self))
	await MeleeWeaponsSuite.new(self)._test_reflective_held_materials()
	print("checks: %d, failures: %d" % [_checks, _failures.size()])
	for failure in _failures:
		printerr("FAIL: " + failure)
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures.is_empty() else 1)
