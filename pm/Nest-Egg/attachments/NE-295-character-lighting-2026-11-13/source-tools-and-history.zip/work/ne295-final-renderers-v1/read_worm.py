"""Known normal channels on the unchanged actual WormCreature drawable."""
import argparse,importlib.util,json
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('common',HERE.parent/'ne295-cause-v1/read.py');common=importlib.util.module_from_spec(s);s.loader.exec_module(common)
def verify(folder):
 folder=Path(folder);r=json.loads((folder.parent/'exit.json').read_bytes());assert r['strict_clean'] and r['exit']==0 and r['source_fixed'] and r['c_fixed'] and r['c_count']==463 and r['all_four_queues_clear'] and not r['diagnostics'] and not r['owned_after']
 assert (folder.parent/'source-before.json').read_bytes()==(folder.parent/'source-after.json').read_bytes()
 v=json.loads((folder/'worm.json').read_bytes());assert v['complete'] and not v['failures'] and len(v['records'])==16
 assert v['renderer']=='forward_plus' and 'RX9070XT' in v['adapter'].replace(' ','')
 out=[]
 for shape in ['reset-trail','curved-trail']:
  rows={r['label']:r for r in v['records'] if r['shape']==shape};images={k:common.image(folder,r['image']) for k,r in rows.items()}
  for k,r in rows.items():
   assert r['before']==r['after'];assert r['image']['format']==15 and [r['image']['width'],r['image']['height']]==[1280,720];assert np.any(images[k][...,3]>.99)
   assert r['before']['polygon']==rows['actualA']['before']['polygon'] and r['before']['uv']==rows['actualA']['before']['uv']
   if r['before']['normal_bytes'] is not None:
    assert r['before']['normal_format']==11;rgba=np.frombuffer(bytes.fromhex(r['before']['normal_bytes']),dtype='<f4');assert len(rgba)==4
  common.restored(images['known-low'],images['known-high']);common.restored(images['flat-current'],images['flat-published']);common.restored(images['actualA'],images['actual-restored'])
  negative=int(np.any(images['old-low']!=images['old-high'],axis=-1).sum());assert negative>0,'old Z-contract mutation must be rejected'
  out.append({'shape':shape,'blue_channel_invariance_exact':True,'flat_default_identity_exact':True,'actual_restore_exact':True,'old_Z_contract_negative_changed_pixels':negative})
 return {'passed':True,'records':16,'results':out,'scope':v['scope'],'not_claimed':'not a full analytical per-triangle curved-normal oracle or natural traversal'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder');p.add_argument('--out',required=True);a=p.parse_args();v=verify(a.folder);Path(a.out).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,indent=2))
