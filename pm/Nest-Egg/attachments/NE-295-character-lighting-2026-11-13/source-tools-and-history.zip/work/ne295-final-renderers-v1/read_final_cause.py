"""Final22 causal replay plus explicit actual/clone instance-parameter contract."""
import argparse,importlib.util,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('common',HERE.parent/'ne295-cause-v1/read.py');common=importlib.util.module_from_spec(s);s.loader.exec_module(common)
def check_flag(part):
 assert 'mesh_normal_basis' in part and 'copy_mesh_normal_basis' in part
 assert part['mesh_normal_basis']==part['copy_mesh_normal_basis'],'clone lost actual instance flag'
 if part['kind']=='Polygon2D': assert part['mesh_normal_basis'] is True,'real mesh has no actual basis flag'
def verify(folder):
 folder=Path(folder);v=common.verify(folder);r=json.loads((folder/'capture.json').read_bytes())
 for row in r['records']:
  for part in row['parts']:check_flag(part)
 v.update({'final_candidate_version':2,'actual_clone_mesh_flags_verified':True,'scope':'same original rooftop16/32, final22 candidate; not full campaign or performance'})
 return v
def self_test():
 check_flag({'kind':'Polygon2D','mesh_normal_basis':True,'copy_mesh_normal_basis':True});n=1
 for x in [{'kind':'Polygon2D','mesh_normal_basis':True,'copy_mesh_normal_basis':False},{'kind':'Polygon2D','mesh_normal_basis':False,'copy_mesh_normal_basis':False}]:
  try:check_flag(x)
  except AssertionError:n+=1
  else:raise AssertionError('flag mutation accepted')
 return {'checks':n,'failures':0,'engine_runs':0}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder',nargs='?');p.add_argument('--self-test',action='store_true');p.add_argument('--out',required=True);a=p.parse_args();v=self_test() if a.self_test else verify(a.folder);Path(a.out).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,indent=2))
