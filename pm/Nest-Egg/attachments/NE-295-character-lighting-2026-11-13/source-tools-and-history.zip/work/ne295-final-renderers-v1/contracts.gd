extends "res://work/ne295-v1/contracts.gd"
func _run() -> void:
	for path in ["res://work/ne295-renderer-coverage-v1/appearance_capture.gd", "res://work/ne295-worm-oracle-v1/capture.gd", "res://work/ne295-death-v1/capture.gd"]:
		var source := load(path) as Script
		_check(source != null and source.can_instantiate(), "final renderer producer compiles: " + path)
	await super._run()
