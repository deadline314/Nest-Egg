"""Read actual component gallery floats; no rectangle exposure denominator."""
import argparse, importlib.util, json, hashlib
from PIL import Image
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('common',HERE.parent/'ne295-cause-v1/read.py');common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)

def composite_image(folder,meta):
 # Full additive composite alpha is accumulated render data, not coverage or an exposure denominator.
 assert meta['format']==15 and meta['width']==1280 and meta['height']==720 and meta['has_mipmaps'] is False
 raw=(folder/meta['raw']).read_bytes();assert len(raw)==meta['bytes']==1280*720*8 and hashlib.sha256(raw).hexdigest()==meta['raw_sha256']
 im=np.frombuffer(raw,dtype='<f2').reshape(720,1280,4).astype(float);assert np.isfinite(im).all() and np.all(im[...,3]>=0)
 assert common.digest(folder/meta['png'])==meta['png_sha256']
 png=np.asarray(Image.open(folder/meta['png']).convert('RGBA'),dtype=float)/255
 rgb=im[...,:3];expected=np.where(rgb<=.0031308,rgb*12.92,1.055*np.maximum(rgb,0)**(1/2.4)-.055)
 assert np.max(np.abs(png[...,:3]-np.clip(expected,0,1)))<=1/255+.00001
 assert np.max(np.abs(png[...,3]-np.clip(im[...,3],0,1)))<=1/255+.00001
 return im

def receipt(folder):
 r=json.loads((folder.parent/'exit.json').read_bytes());assert r['strict_clean'] and r['exit']==0 and r['source_fixed'] and r['c_fixed'] and r['c_count']==463 and r['all_four_queues_clear'] and not r['diagnostics'] and not r['owned_after']
 assert (folder.parent/'source-before.json').read_bytes()==(folder.parent/'source-after.json').read_bytes()
 return r

def verify(folder):
 folder=Path(folder);r=receipt(folder);v=json.loads((folder/'appearance.json').read_bytes());assert v['complete'] and not v['failures'] and len(v['records'])==37
 assert v['renderer']=='forward_plus' and 'RX9070XT' in v['adapter'].replace(' ','')
 pages={};result={}
 for row in v['records']:
  assert row['before']==row['after'];assert row['image']['format']==15 and [row['image']['width'],row['image']['height']]==[1280,720]
  im=composite_image(folder,row['image']) if row['page']=='held' else common.image(folder,row['image']);assert np.any(im[...,3]>0)
  pages.setdefault(row['page'],{})[row['label']]=(row,im)
 for name,rows in pages.items():
  a=rows['A0'][1]
  for label in ['A1','A2','A3','HIGH']: common.restored(a,rows[label][1])
  common.restored(rows['B0'][1],rows['B1'][1])
  assert np.any(a!=rows['B0'][1]),'directional negative: no actual response'
  assert np.any(a!=rows['O'][1]),'occlusion negative: no actual response'
  assert np.any(a!=rows['LOW'][1]),'normal toggle did not change actual rendering'
  result[name]={'direction_changed_pixels':int(np.any(a!=rows['B0'][1],axis=-1).sum()),'occlusion_changed_pixels':int(np.any(a!=rows['O'][1],axis=-1).sum()),'normal_changed_pixels':int(np.any(a!=rows['LOW'][1],axis=-1).sum()),'AABA_HIGH_restore_exact':True,'scope':'whole arranged page response, not isolated per-part exposure'}
 held=pages['held'];bindings=held['A0'][0]['before']
 for row in bindings:
  if row['kind']=='melee':
   assert row['glow_unshaded'] and row['base']['material_id']==row['rig_material_id'] and row['base']['visible'] and row['attachment_count']>0
  if row['id'] in ['bowl','disc','paper']:
   assert row['binding']['material_id']==row['rig_material_id'] and row['binding']['visible']
   assert np.float32(row['binding']['self_modulate'][3])==np.float32(.8)
  if row['kind']=='rig' and row['skin']=='rin' and 'sit' in row['id']: assert row['active_pose']=='sit'
 assert next(x for x in bindings if x['id']=='bowl')['binding']['normal_id'] is not None
 assert next(x for x in bindings if x['id']=='disc')['binding']['normal_id'] is None
 switch=held['same-player-whip'][0]['before'][0];back=held['same-player-blade-restored'][0]['before'][0]
 assert switch['instance']==back['instance'] and switch['weapon']=='melee_whip' and back['weapon']=='melee_blade'
 assert switch['base']['material_id']==back['base']['material_id']==back['rig_material_id']
 assert held['actual-flash-recovered'][0]['before'][0]['base']['self_modulate']==held['A0'][0]['before'][0]['base']['self_modulate']
 assert held['actual-flash'][0]['before'][0]['flash_left']>0 and held['actual-flash-recovered'][0]['before'][0]['flash_left']<=0
 reuse=pages['debris_dissolve']['A0'][0]['pool_reuse'];assert reuse['same_instance'] and reuse['material_reset'] and reuse['fill_reset_to_default']
 assert 'dissolve-zero' in pages['debris_dissolve'] and 'dissolve-progress35' in pages['debris_dissolve']
 w=pages['worm'];half=next(x for x in w['opacity-half'][0]['before'] if x['kind']=='worm');full=next(x for x in w['opacity-restored'][0]['before'] if x['kind']=='worm')
 assert half['head_effective_alpha']==half['body_effective_alpha']==.5 and full['head_effective_alpha']==full['body_effective_alpha']==1
 common.restored(w['HIGH'][1],w['opacity-restored'][1])
 return {'passed':True,'records':37,'pages':result,'pool_reuse':reuse,'scope':v['scope'],'composite_alpha_semantics':'held page contains original additive glow; original HDR alpha is finite nonnegative accumulated data, PNG clamps to8bit, never used as coverage or exposure denominator','not_claimed':['whole campaign interaction','per-part exposure percentage','physical input','performance']}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder');p.add_argument('--out',required=True);a=p.parse_args();v=verify(a.folder);Path(a.out).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps(v,indent=2))
