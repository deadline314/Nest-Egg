"""CPU-only candidate files/diff; never writes the active 22 product paths."""
from pathlib import Path
import difflib
import hashlib
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
old = json.loads((ROOT / "work/ne295-v1/delivery-manifest-v1.json").read_bytes())
assert all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == row["sha256"] for name, row in old["files"].items())
paths = ["art/shaders/character_light_response.gdshaderinc", "art/shaders/character_light.gdshader", "art/shaders/dissolve.gdshader",
         "game/rig/character_rig.gd", "game/creature/worm_belly.gdshader", "tests/helpers/character_lighting_checks.gd"]
before = {name: (ROOT / name).read_text(encoding="utf-8") for name in paths}
after = dict(before)
include = paths[0]
after[include] += '''
// Rigid sprites keep the published normal response. Actual mesh owners opt in once at setup.
instance uniform bool mesh_normal_basis = false;

vec3 character_mesh_normal(vec3 encoded, vec2 position, vec2 sampled_uv) {
	if (!mesh_normal_basis) { return encoded; }
	vec2 dx = dFdx(position);
	vec2 dy = dFdy(position);
	vec2 ux = dFdx(sampled_uv);
	vec2 uy = dFdy(sampled_uv);
	float det = ux.x * uy.y - ux.y * uy.x;
	if (abs(det) <= 0.000001) { return encoded; }
	vec2 tangent = (dx * uy.y - dy * ux.y) / det;
	vec2 bitangent = (dy * ux.x - dx * uy.x) / det;
	if (dot(tangent, tangent) <= 0.000001 || dot(bitangent, bitangent) <= 0.000001) { return encoded; }
	vec2 xy = encoded.xy * vec2(2.0, -2.0) - vec2(1.0, -1.0);
	xy = normalize(tangent) * xy.x + normalize(bitangent) * xy.y;
	// Preserve original NORMAL_MAP Z; Godot decodes only XY, then applies item/canvas axes.
	return vec3(xy * vec2(0.5, -0.5) + vec2(0.5), encoded.z);
}
'''
shader = paths[1]
after[shader] = after[shader].replace("varying vec4 sway_tint;", "varying vec4 sway_tint;\nvarying vec2 normal_surface_position;")
needle = "\t}\n}\n\nvoid fragment()"
assert after[shader].count(needle) == 1
after[shader] = after[shader].replace(needle, "\t}\n\tnormal_surface_position = VERTEX;\n}\n\nvoid fragment()")
after[shader] = after[shader].replace("void fragment() {", "void fragment() {\n\tvec2 sampled_normal_uv = UV;")
after[shader] = after[shader].replace("\t\tNORMAL_MAP = texture(NORMAL_TEXTURE, uv).rgb;", "\t\tNORMAL_MAP = texture(NORMAL_TEXTURE, uv).rgb;\n\t\tsampled_normal_uv = uv;")
after[shader] = after[shader].replace("\n}\n\nvoid light()", "\n\tNORMAL_MAP = character_mesh_normal(NORMAL_MAP, normal_surface_position, sampled_normal_uv);\n}\n\nvoid light()")
dissolve = paths[2]
after[dissolve] = after[dissolve].replace("varying vec2 world_pos;", "varying vec2 world_pos;\nvarying vec2 normal_surface_position;")
after[dissolve] = after[dissolve].replace("\tbase_tint = COLOR;", "\tbase_tint = COLOR;\n\tnormal_surface_position = VERTEX;")
after[dissolve] = after[dissolve].replace("void fragment() {", "void fragment() {\n\tNORMAL_MAP = character_mesh_normal(texture(NORMAL_TEXTURE, UV).rgb, normal_surface_position, UV);")
rig = paths[3]
needle = "\t\tpart.material = _light_material"
assert after[rig].count(needle) == 1
after[rig] = after[rig].replace(needle, needle + '\n\t\tif part is Polygon2D: part.set_instance_shader_parameter(&"mesh_normal_basis", true)')
needle = "\t\t\talternate.material = _light_material"
assert after[rig].count(needle) == 1
after[rig] = after[rig].replace(needle, needle + '\n\t\t\tif alternate is Polygon2D: alternate.set_instance_shader_parameter(&"mesh_normal_basis", true)')
worm = paths[4]
after[worm] = after[worm].replace("vec3 a = texture(NORMAL_TEXTURE, scale_uv).rgb * 2.0 - 1.0;\n\tvec3 b = texture(NORMAL_TEXTURE, other_uv).rgb * 2.0 - 1.0;",
    "vec2 a_xy = texture(NORMAL_TEXTURE, scale_uv).rg * vec2(2.0, -2.0) - vec2(1.0, -1.0);\n\tvec2 b_xy = texture(NORMAL_TEXTURE, other_uv).rg * vec2(2.0, -2.0) - vec2(1.0, -1.0);\n\t// Match default CanvasTexture decoding: reconstruct Z from XY, not authored blue.\n\tvec3 a = vec3(a_xy, sqrt(max(0.0, 1.0 - dot(a_xy, a_xy))));\n\tvec3 b = vec3(b_xy, sqrt(max(0.0, 1.0 - dot(b_xy, b_xy))));")
after[worm] = after[worm].replace("normalize(tangent) * n.x - normalize(bitangent) * n.y", "normalize(tangent) * n.x + normalize(bitangent) * n.y")
after[worm] = after[worm].replace("n.xy = vec2(planar.x, -planar.y);", "n.xy = planar;")
after[worm] = after[worm].replace("NORMAL_MAP = n * 0.5 + 0.5;", "// NORMAL_MAP Z is used directly by Godot; only XY uses encoded/green-flipped storage.\n\tNORMAL_MAP = vec3(n.xy * vec2(0.5, -0.5) + vec2(0.5), n.z);")
test = paths[5]
needle = '\ts.check(rig.setup("rin"), "lighting: Rin attachment fixture builds")'
assert after[test].count(needle) == 1
after[test] = after[test].replace(needle, needle + '''
	var meshes := 0
	var rigid := 0
	for part: CanvasItem in rig._parts:
		if part is Polygon2D:
			meshes += 1
			s.check(part.get_instance_shader_parameter(&"mesh_normal_basis") == true, "lighting: real mesh opts into its deformed normal basis")
		elif part is Sprite2D:
			rigid += 1
			s.check(part.get_instance_shader_parameter(&"mesh_normal_basis") != true, "lighting: rigid sprite retains original normal basis")
	s.check(meshes > 0 and rigid > 0, "lighting: both real renderer kinds were exercised")''')
diff, files = [], {}
for name in paths:
    assert after[name] != before[name]
    target = HERE / "files" / (name + ".txt")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(after[name].encode())
    files[name] = {"before_sha256": hashlib.sha256((ROOT / name).read_bytes()).hexdigest(), "candidate_sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "candidate_file": str(target.relative_to(HERE))}
    diff.extend(difflib.unified_diff(before[name].splitlines(True), after[name].splitlines(True), "a/" + name, "b/" + name))
(HERE / "candidate-v2.diff").write_bytes("".join(diff).encode())
(HERE / "manifest.json").write_bytes((json.dumps({"live_product_files_written": 0, "old_delivery_count": 22, "changed_paths": len(files), "files": files}, indent=2) + "\n").encode())

def default_normal(rgb):
    xy = np.asarray(rgb[:2]) * [2, -2] - [1, -1]
    n = np.r_[xy, np.sqrt(max(0., 1 - xy @ xy))]
    return n / np.linalg.norm(n)

def old_candidate(rgb):
    n = np.asarray(rgb) * 2 - 1
    n /= np.linalg.norm(n)
    encoded = n * .5 + .5
    engine = np.r_[encoded[:2] * [2, -2] - [1, -1], encoded[2]]
    return engine / np.linalg.norm(engine)

flat = [.5, .5, 1]
assert np.array_equal(default_normal(flat), old_candidate(flat))
golden = default_normal([.68, .26, .2])
assert np.allclose(golden, [.36, .48, .8], rtol=0, atol=1e-14)
assert np.array_equal(golden, default_normal([.68, .26, .8]))
assert np.linalg.norm(old_candidate([.68, .26, .2]) - old_candidate([.68, .26, .8])) > .1
assert np.linalg.norm(old_candidate([.68, .26, .8]) - golden) > .01
(HERE / "worm-channel-cpu.json").write_bytes((json.dumps({"checks": 5, "failures": 0, "engine_runs": 0,
    "golden": golden.tolist(), "scope": "pinned canvas.glsl default XY/sqrt decoding vs current candidate double-Z encoding; requires same-geometry native confirmation"}, indent=2) + "\n").encode())
print(json.dumps({"changed_paths": len(files), "live_files_written": 0, "worm_CPU": "5/0"}, indent=2))
