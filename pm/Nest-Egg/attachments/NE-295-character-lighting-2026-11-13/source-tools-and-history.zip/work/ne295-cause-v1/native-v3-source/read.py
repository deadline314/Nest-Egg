"""Read original NE295 rooftop floats. No Godot, source edits or inferred whole-ticket pass."""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import tempfile

import numpy as np
from PIL import Image

# Same native Image enum mapping as the published BG55 reader.
FORMATS = {14: ("<f2", 3), 15: ("<f2", 4), 10: ("<f4", 3), 11: ("<f4", 4)}
CONTEXT = ["A0", "A1", "B0", "A2", "B1"]
NORMAL = ["N0-original", "L0", "L1", "O-occluded", "L2-restored", "R0", "F-flat-instance", "R1-restored", "U0-unshaded-right", "U1-unshaded-left", "N1-scene-restored"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def image(folder, meta, check_png=True):
    width, height = meta["width"], meta["height"]
    assert type(width) is int and type(height) is int and 0 < width <= 1280 and 0 < height <= 720
    assert meta["format"] in FORMATS and meta["has_mipmaps"] is False
    dtype, channels = FORMATS[meta["format"]]
    raw = (folder / meta["raw"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == meta["raw_sha256"]
    assert len(raw) == meta["bytes"] == width * height * channels * np.dtype(dtype).itemsize
    pixels = np.frombuffer(raw, dtype=dtype).reshape(height, width, channels).astype(np.float64)
    assert np.isfinite(pixels).all(), "non-finite HDR"
    if channels == 4:
        assert np.all((pixels[..., 3] >= 0) & (pixels[..., 3] <= 1)), "invalid native alpha"
    if check_png:
        assert digest(folder / meta["png"]) == meta["png_sha256"]
        shown = np.asarray(Image.open(folder / meta["png"]).convert("RGBA"), dtype=np.float64) / 255
        assert shown.shape[:2] == (height, width)
        rgb = pixels[..., :3]
        expected = np.where(rgb <= 0.0031308, rgb * 12.92, 1.055 * np.maximum(rgb, 0) ** (1 / 2.4) - 0.055)
        # Published viewport-capture encoding guard: at most one 8-bit quantization step.
        assert np.max(np.abs(shown[..., :3] - np.clip(expected, 0, 1))) <= 1 / 255 + 0.00001
        if channels == 4:
            assert np.max(np.abs(shown[..., 3] - pixels[..., 3])) <= 1 / 255 + 0.00001
    return pixels


def part_geometry(part, canvas):
    assert part["transform"] == part["copy_transform"], "copy/source transform mismatch"
    assert part["view_transform"] == canvas, "different main/copy canvas"
    assert part["color"] == part["copy_color"] and part["effective_modulate"] == part["copy_modulate"], "modulation lost"
    assert part["texture_id"] == part["copy_texture_id"] and part["material_id"] == part["copy_material_id"], "binding lost"
    assert part["copy_has_script"] is False, "copy contains behavior"
    if "view_size" in part:
        assert part["view_size"] == [1280, 720] and part["view_msaa"] == part["main_msaa"]
        assert part["visible"] and not part["use_parent_material"]
    x, y, w, h = part["roi"]
    assert all(type(v) is int for v in [x, y, w, h]) and x >= 0 and y >= 0 and w > 0 and h > 0 and x + w <= 1280 and y + h <= 720
    assert [w, h] == [part["isolated"]["width"], part["isolated"]["height"]]


def native_geometry(value):
    assert value["window_mode"] == 0 and value["window_size"] == [1280, 720], "wrong actual window"
    assert value["image_size"] == [1280, 720], "wrong actual Image readback"
    assert value["image_format"] == 14 and value["image_bytes"] == 1280 * 720 * 6 and value["image_has_mipmaps"] is False
    assert len(value["texture_reported_size"]) == 2 and all(type(v) is int and v > 0 for v in value["texture_reported_size"])
    assert value["keep_aspect"] and value["content_scale_size"] == [640, 360] and value["hdr_2d"]
    for field in ["final_transform", "canvas_transform", "final_x_canvas"]:
        assert len(value[field]) == 6 and np.isfinite(value[field]).all()
    assert len(value["viewport_visible_rect"]) == 4 and np.isfinite(value["viewport_visible_rect"]).all()


def opaque(pixels):
    assert pixels.shape[2] == 4
    alpha = pixels[..., 3]
    assert not np.any(alpha[0] > 0) and not np.any(alpha[-1] > 0) and not np.any(alpha[:, 0] > 0) and not np.any(alpha[:, -1] > 0), "mask touches frozen ROI border"
    mask = alpha >= 0.999
    assert mask.any(), "empty opaque drawable"
    return mask


def restored(first, again):
    assert first.shape == again.shape and np.array_equal(first, again), "A/A or restoration differs"


def shadow_response(lit, blocked, mask):
    assert np.array_equal(lit[..., 3], blocked[..., 3]), "occlusion changed alpha"
    reduction = lit[..., :3][mask] - blocked[..., :3][mask]
    assert reduction.max() > 0 and reduction.mean() > 0, "occluder has no observed darkening"
    return float(reduction.max())


def basis_audit(part):
    """Geometry diagnostic, not an assertion that a brighter material is wrong."""
    if "polygon" not in part:
        return {"kind": "rigid Sprite2D", "deformed_texture_axis_degrees": 0.0}
    vertices = np.asarray(part["polygon"], dtype=np.float64)
    uv = np.asarray(part["uv"], dtype=np.float64)
    assert vertices.shape == uv.shape and vertices.ndim == 2 and vertices.shape[1] == 2
    xx, xy, yx, yy, ox, oy = part["transform"]
    transform = np.array([[xx, yx], [xy, yy]])
    world = vertices @ transform.T + [ox, oy]
    item_x = transform[:, 0] / np.linalg.norm(transform[:, 0])
    angles, skipped = [], 0
    for face in part["triangles"]:
        assert len(face) == 3 and all(type(i) is int and 0 <= i < len(vertices) for i in face)
        a, b, c = face
        duv = np.column_stack((uv[b] - uv[a], uv[c] - uv[a]))
        if abs(np.linalg.det(duv)) < 1e-12:
            skipped += 1
            continue
        derivative = np.column_stack((world[b] - world[a], world[c] - world[a])) @ np.linalg.inv(duv)
        tangent = derivative[:, 0]
        if np.linalg.norm(tangent) < 1e-12:
            skipped += 1
            continue
        tangent /= np.linalg.norm(tangent)
        angle = np.degrees(np.arctan2(item_x[0] * tangent[1] - item_x[1] * tangent[0], item_x @ tangent))
        angles.append(abs(float(angle)))
    assert angles, "no nondegenerate UV triangles"
    return {"kind": part["script"], "nondegenerate_triangles": len(angles), "skipped_triangles": skipped,
            "max_texture_axis_vs_item_axis_degrees": max(angles), "mean_degrees": float(np.mean(angles)),
            "interpretation": "item-normal basis versus actual deformed UV tangent; no native shading verdict by itself"}


def verify(folder):
    folder = Path(folder)
    report = json.loads((folder / "capture.json").read_bytes())
    assert report["schema"] == "ne295-cause-v1" and report["level"] == "ch1_rooftop"
    assert report["capture_complete"] and not report["failures"] and report["size"] == [1280, 720] and report["hdr"]
    assert report["renderer"] == "forward_plus" and "RX9070XT" in report["adapter"].replace(" ", "")
    assert report["initial_egret_world_context"] is True and report["player_origin"] == [776.0, 288.0]
    assert [p["phase"] for p in report["window_phases"]] == ["before-level", "before-sampling"]
    for phase in report["window_phases"]:
        native_geometry(phase)
    assert report["window_phases"][0]["msaa_2d"] == report["window_phases"][1]["msaa_2d"]
    receipt = json.loads((folder.parent / "exit.json").read_bytes())
    assert receipt["strict_clean"] and receipt["exit"] == 0 and receipt["source_fixed"] and receipt["c_fixed"]
    assert receipt["c_count"] == 463 and receipt["all_four_queues_clear"] and not receipt["diagnostics"] and not receipt["owned_after"]
    before = json.loads((folder.parent / "source-before.json").read_bytes())
    assert before == json.loads((folder.parent / "source-after.json").read_bytes())
    for name in ["outer-before", "inner-before", "inner-after", "outer-after"]:
        rows = json.loads((folder.parent / (name + ".json")).read_bytes())
        assert [row["port"] for row in rows] == [8188, 8189]
        assert rows[0]["state"] == "empty" and rows[0]["running"] == rows[0]["pending"] == 0
        assert (rows[1]["state"] == "empty" and rows[1]["running"] == rows[1]["pending"] == 0) or (rows[1]["state"] == "refused" and rows[1]["winerror"] == 10061)
    records = report["records"]
    assert len(records) == 16
    assert [(r["group"], r["label"]) for r in records] == [("context", n) for n in CONTEXT] + [("normal", n) for n in NORMAL]
    samples, part_images, stats, raw_group_bytes = {}, {}, [], {}
    for record in records:
        native_geometry(record["native_geometry"])
        assert record["native_geometry"]["msaa_2d"] == report["window_phases"][0]["msaa_2d"]
        state = record["before"]
        assert record["native_geometry"]["final_x_canvas"] == state["canvas"]
        assert state == record["after"] and state["owners"]["valid"] and state["player_alive"]
        assert state["player"] == [776, 288] and state["facing"] == 1 and state["aim"] == [1, 0]
        assert state["egret_visible"] and state["egret_skin"] == "egret"
        assert [p["name"] for p in record["parts"]] == ["hand_front", "arm_front_lower"]
        main = image(folder, record["main"])
        assert main.shape == (720, 1280, 3) and record["main"]["format"] == 14
        key = record["label"]
        samples[key] = main
        raw_group_bytes[record["group"]] = raw_group_bytes.get(record["group"], 0) + record["main"]["bytes"]
        for part in record["parts"]:
            part_geometry(part, state["canvas"])
            isolated = image(folder, part["isolated"])
            assert part["isolated"]["format"] == 15
            mask = opaque(isolated)
            raw_group_bytes[record["group"]] += part["isolated"]["bytes"]
            part_images[key, part["name"]] = isolated
            rgb = isolated[..., :3][mask]
            stats.append({"label": key, "part": part["name"], "opaque_pixels": int(mask.sum()), "isolated_rgb_mean": rgb.mean(axis=0).tolist(),
                          "isolated_peak": float(rgb.max()), "scope": "actual drawable copy under explicit isolated lighting; not visible main-scene segmentation"})
    for a, b in [("A0", "A1"), ("A0", "A2"), ("B0", "B1"), ("L0", "L1"), ("L0", "L2-restored"), ("R0", "R1-restored"), ("N0-original", "N1-scene-restored")]:
        restored(samples[a], samples[b])
        for name in ["hand_front", "arm_front_lower"]:
            restored(part_images[a, name], part_images[b, name])
    assert [r["before"]["egret_world"] for r in records[:5]] == [False, False, True, False, True]
    assert np.any(samples["A0"] != samples["B0"]), "changed NPC context has no observed pixels"
    assert all(count <= 90_000_000 for count in raw_group_bytes.values()), "raw group exceeds the declared chunk limit"
    assert np.array_equal(part_images["U0-unshaded-right", "hand_front"], part_images["U1-unshaded-left", "hand_front"]), "unshaded negative control responds to lamp position"
    deltas = []
    for name in ["hand_front", "arm_front_lower"]:
        a, b = part_images["L0", name], part_images["R0", name]
        mask = opaque(a)
        assert np.array_equal(a[..., 3], b[..., 3]), "lighting changed alpha"
        response = float(np.abs(a[..., :3] - b[..., :3])[mask].max())
        assert response > 0, f"no observed directional response on {name}"
        occluded = part_images["O-occluded", name]
        deltas.append({"part": name, "left_right_max_float_delta": response,
                       "occluder_max_float_reduction": shadow_response(a, occluded, mask),
                       "flat_normal_max_float_delta": float(np.abs(part_images["R0", name][..., :3] - part_images["F-flat-instance", name][..., :3])[mask].max())})
    return {"passed": True, "samples": 16, "original_main_size": [1280, 720], "raw_pixel_area_correct": True,
            "context_changed_pixels": int(np.any(samples["A0"] != samples["B0"], axis=-1).sum()), "raw_group_bytes": raw_group_bytes, "isolated_parts": stats,
            "directional_response": deltas, "basis_diagnostic": {p["name"]: basis_audit(p) for p in records[5]["parts"]},
            "lighting_ticket_accepted": False, "reason": "first causal scope only; full originals and main/isolated distinction require review"}


def self_test(output):
    checks = 0
    with tempfile.TemporaryDirectory() as temporary:
        folder = Path(temporary)
        pixels = np.full((2, 3, 3), 0.25, dtype="<f2")
        raw = pixels.tobytes()
        (folder / "known.raw").write_bytes(raw)
        meta = {"width": 3, "height": 2, "format": 14, "has_mipmaps": False, "raw": "known.raw", "bytes": len(raw), "raw_sha256": hashlib.sha256(raw).hexdigest()}
        assert np.array_equal(image(folder, meta, False), pixels)
        checks += 1

        def rejects(call):
            nonlocal checks
            try:
                call()
            except (AssertionError, ValueError, KeyError):
                checks += 1
                return
            raise AssertionError("negative accepted")

        restored(pixels, pixels.copy())
        checks += 1
        unrestored = pixels.copy()
        unrestored[0, 0, 0] = 0.5
        rejects(lambda: restored(pixels, unrestored))

        for field, value in [("width", 4), ("format", 15), ("has_mipmaps", True), ("raw_sha256", "0" * 64)]:
            bad = dict(meta, **{field: value})
            rejects(lambda: image(folder, bad, False))
        bad_pixels = pixels.copy()
        bad_pixels[0, 0, 0] = np.nan
        (folder / "nan.raw").write_bytes(bad_pixels.tobytes())
        bad = dict(meta, raw="nan.raw", raw_sha256=digest(folder / "nan.raw"))
        rejects(lambda: image(folder, bad, False))
        alpha = np.zeros((6, 6, 4))
        alpha[2:4, 2:4, 3] = 1
        assert opaque(alpha).sum() == 4
        checks += 1
        rejects(lambda: opaque(np.zeros_like(alpha)))
        clipped = alpha.copy()
        clipped[0, 2, 3] = 0.01
        rejects(lambda: opaque(clipped))
        lit = alpha.copy()
        lit[2:4, 2:4, :3] = 0.5
        blocked = lit.copy()
        blocked[2:4, 2:4, :3] = 0.25
        assert shadow_response(lit, blocked, opaque(lit)) == 0.25
        checks += 1
        rejects(lambda: shadow_response(lit, lit, opaque(lit)))
        rejects(lambda: shadow_response(blocked, lit, opaque(lit)))
        transform = [1, 0, 0, 1, 0, 0]
        geometry = {"window_mode": 0, "window_size": [1280, 720], "image_size": [1280, 720], "texture_reported_size": [2560, 1440], "keep_aspect": True,
                    "image_format": 14, "image_bytes": 1280 * 720 * 6, "image_has_mipmaps": False,
                    "content_scale_size": [640, 360], "hdr_2d": True, "viewport_visible_rect": [0, 0, 640, 360],
                    "final_transform": [2, 0, 0, 2, 0, 0], "canvas_transform": transform, "final_x_canvas": [2, 0, 0, 2, 0, 0]}
        native_geometry(geometry)
        checks += 1
        for field, value in [("image_size", [2560, 1440]), ("window_mode", 2), ("keep_aspect", False), ("image_format", 15),
                             ("image_bytes", 1280 * 720 * 12)]:
            bad = dict(geometry, **{field: value})
            rejects(lambda: native_geometry(bad))
        part = {"transform": transform, "copy_transform": transform, "view_transform": transform, "color": [1, 1, 1, 1], "copy_color": [1, 1, 1, 1],
                "effective_modulate": [1, 1, 1, 1], "copy_modulate": [1, 1, 1, 1], "texture_id": 1, "copy_texture_id": 1,
                "material_id": 2, "copy_material_id": 2, "copy_has_script": False, "roi": [10, 10, 6, 6], "isolated": {"width": 6, "height": 6}}
        part_geometry(part, transform)
        checks += 1
        for field, value in [("copy_transform", [1, 0, 0, 1, 1, 0]), ("view_transform", [2, 0, 0, 2, 0, 0]),
                             ("copy_color", [1, 1, 1, 0.5]), ("copy_texture_id", 9), ("copy_material_id", 9), ("copy_has_script", True)]:
            bad = copy.deepcopy(part)
            bad[field] = value
            rejects(lambda: part_geometry(bad, transform))
        fixture = {"script": "known rigid UV triangle", "polygon": [[0, 0], [2, 0], [0, 2]], "uv": [[0, 0], [2, 0], [0, 2]], "triangles": [[0, 1, 2]], "transform": transform}
        assert basis_audit(fixture)["max_texture_axis_vs_item_axis_degrees"] == 0
        fixture["polygon"] = [[0, 0], [0, 2], [-2, 0]]
        assert abs(basis_audit(fixture)["max_texture_axis_vs_item_axis_degrees"] - 90) < 1e-9
        checks += 2
    result = {"cpu_component_checks": checks, "failures": 0, "engine_runs": 0, "native_verdict": None,
              "scope": "known RGBH byte layout/finite values, exact mask geometry/modulation, blank/clipped masks and known UV-basis controls"}
    Path(output).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", nargs="?")
    parser.add_argument("--out", required=True)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    result = self_test(args.out) if args.self_test else verify(args.folder)
    if not args.self_test:
        Path(args.out).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "isolated_parts"}, indent=2))
