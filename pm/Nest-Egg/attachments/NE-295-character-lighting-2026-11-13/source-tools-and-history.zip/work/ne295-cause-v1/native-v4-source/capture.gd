extends Node
## One fixed rooftop pose. All edits below are explicit in-memory diagnostic factors.

const Capture := preload("res://tools/viewport_capture.gd")
const Held := preload("res://tools/held_lighting_state.gd")
const PARTS := [&"hand_front", &"arm_front_lower"]
const SIZE := Vector2i(1280, 720)
var _out := ""
var _level: Level
var _rig: CharacterRig
var _egret: NpcActor
var _views: Array[Dictionary] = []
var _saved_lights: Array[Dictionary] = []
var _lamp: PointLight2D
var _occluder: LightOccluder2D
var _target := Vector2.ZERO
var _records: Array[Dictionary] = []
var _failures: Array[String] = []
var _input_before := false
var _initial_egret_world := false
var _window_phases: Array[Dictionary] = []
var _main_size := Vector2i.ZERO


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
	_input_before = get_viewport().is_input_disabled()
	_run.call_deferred()


func _require(condition: bool, message: String) -> bool:
	if not condition:
		_failures.append(message)
		push_error("[NE295 cause] " + message)
	return condition


func _run() -> void:
	var valid := _out.is_absolute_path() and DisplayServer.get_name() != "headless"
	if _require(valid, "requires native viewport and absolute output"):
		valid = _require(DirAccess.make_dir_recursive_absolute(_out) == OK, "cannot create output")
		if valid: valid = await _observe()
	if _out.is_absolute_path(): _write_json("capture.json", {"schema": "ne295-cause-v1", "scope": "one arranged rooftop c02r02; not natural play, performance or whole-ticket acceptance",
		"engine": Engine.get_version_info().string, "adapter": RenderingServer.get_video_adapter_name(), "renderer": RenderingServer.get_current_rendering_method(),
		"hdr": get_viewport().use_hdr_2d, "size": [_main_size.x, _main_size.y],
		"texture_reported_size": [get_viewport().get_texture().get_width(), get_viewport().get_texture().get_height()],
		"window_phases": _window_phases,
		"level": "ch1_rooftop", "player_origin": [776.0, 288.0], "initial_egret_world_context": _initial_egret_world,
		"view_color_scope": "isolated actual drawable copies have the same material/transform, actual ambient and one diagnostic lamp; no scene fog/postprocess/foreground",
		"lamp_energy": 0.15, "lamp_height": LightKit.LIGHT_HEIGHT, "records": _records, "failures": _failures, "capture_complete": valid and _records.size() == 16})
	if is_instance_valid(_level): _level.queue_free()
	for entry in _views:
		(entry.view as SubViewport).queue_free()
	for frame in 4: await get_tree().process_frame
	_views.clear()
	_saved_lights.clear()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if valid and _failures.is_empty() and _records.size() == 16 else 2)


func _observe() -> bool:
	Settings.use_storage("user://ne295-settings.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	# Fixture geometry only: do not write fullscreen preferences or alter KEEP/AA/HDR.
	get_window().mode = Window.MODE_WINDOWED
	get_window().size = SIZE
	await _settle(2)
	_window_phases.append(_native_geometry("before-level", get_viewport().get_texture().get_image()))
	get_viewport().set_disable_input(true)
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	for id in Story.scene_ids(): Story._seen[StringName(id)] = true
	Story._layer.visible = false
	GameState.start_new_run(GameState.difficulties[1])
	get_tree().node_added.connect(_on_node_added)
	_level = Level.new()
	_level.configure(load("res://data/levels/ch1_rooftop.tres") as LevelData)
	add_child(_level)
	_hold(_level.player)
	_rig = _level.player._visual.rig
	var input := RigInput.new()
	input.on_floor = true
	input.facing = 1
	input.aim_dir = Vector2.RIGHT
	_level.player.facing = 1
	_level.player.aim_dir = Vector2.RIGHT
	_level.player.velocity = Vector2.ZERO
	for tick in 24: _rig.animate(1.0 / 60.0, input)
	_level.player.global_position = Vector2(776, 288)
	_level.hud.hide()
	for node in _level.find_children("*", "", true, false):
		if node is WorldPrompt:
			node.hide()
			node.set_process(false)
		elif node is ChapterCard: node.queue_free()
		elif node is Enemy: _hold(node)
		elif node is NpcActor and node.data.rig_id == "egret": _egret = node
	if not _require(_egret != null and _egret._actor != null and _egret._actor.rig != null, "real rooftop Egret is missing"): return false
	_initial_egret_world = _egret._actor.rig.use_level_lighting
	if not _require(_initial_egret_world, "candidate world NPC context was not active"): return false
	var camera := get_viewport().get_camera_2d() as LevelCamera
	if not _require(camera != null, "missing real level camera"): return false
	camera.set_physics_process(false)
	camera.offset = Vector2.ZERO
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	camera.global_position = Vector2(780.000061035156, 290.25)
	camera.reset_smoothing()
	camera.force_update_scroll()
	_level._lighting._lightning_gap = 1.0e9
	await _settle(24)
	# Its CutsceneActor deliberately uses ALWAYS, so Level.DISABLED alone cannot hold it.
	_hold(_egret)
	_level._lighting.snap()
	Held.preserve_physics_bodies(_level)
	_level.process_mode = Node.PROCESS_MODE_DISABLED
	_rig._apply_fill(LightKit.character_fill)
	_rig._apply_light_cap(LightKit.character_light_cap)
	_level.player._light.energy = LightKit.player_light_energy
	Held.sync(_level)
	await _settle(2)
	var initial_image := get_viewport().get_texture().get_image()
	_main_size = initial_image.get_size()
	_window_phases.append(_native_geometry("before-sampling", initial_image))
	if not _require(initial_image.get_size() == SIZE and initial_image.get_format() == Image.FORMAT_RGBH
		and not initial_image.has_mipmaps() and initial_image.get_data().size() == SIZE.x * SIZE.y * 6 and get_window().size == SIZE
		and get_viewport().use_hdr_2d and RenderingServer.get_current_rendering_method() == "forward_plus", "wrong native geometry/renderer/HDR"): return false
	if not _require(_level.player.health.current > 0 and not _level.player.is_dead(), "arranged player is not alive"): return false
	var egret_screen := (get_viewport().get_final_transform() * get_viewport().get_canvas_transform()) * _egret._actor.rig.visual_bounds()
	if not _require(_egret.is_visible_in_tree() and egret_screen.has_area() and Rect2(Vector2.ZERO, Vector2(SIZE)).encloses(egret_screen), "Egret not fully in the observed native view"): return false
	for name in PARTS:
		var part: CanvasItem
		for item in _rig._parts:
			if item.name == name and item.is_visible_in_tree(): part = item
		if not _require(part != null, "missing actual drawable " + name): return false
		if not await _make_view(part): return false
	_target = _rig.bone(&"hand_front").global_position
	for node in _level.find_children("*", "Light2D", true, false):
		_saved_lights.append({"node": node, "enabled": node.enabled, "visible": node.visible})
	_lamp = _new_lamp(_level)
	_occluder = _new_occluder(_level)
	for label in ["A0", "A1", "B0", "A2", "B1"]:
		_set_egret(label.begins_with("B"))
		if not await _sample("context", label): return false
	if not await _sample("normal", "N0-original"): return false
	for state in _saved_lights: (state.node as Light2D).enabled = false
	_set_probe(-1, false)
	if not await _sample("normal", "L0"): return false
	if not await _sample("normal", "L1"): return false
	_set_probe(-1, true)
	if not await _sample("normal", "O-occluded"): return false
	_set_probe(-1, false)
	if not await _sample("normal", "L2-restored"): return false
	_set_probe(1, false)
	if not await _sample("normal", "R0"): return false
	for entry in _views:
		var original := entry.texture as CanvasTexture
		if not _require(original != null and original.normal_texture != null, "normal control lacks real CanvasTexture normal"): return false
		var flat := original.duplicate() as CanvasTexture
		flat.normal_texture = null
		(entry.source as CanvasItem).set("texture", flat)
	if not await _sample("normal", "F-flat-instance"): return false
	for entry in _views: (entry.source as CanvasItem).set("texture", entry.texture)
	if not await _sample("normal", "R1-restored"): return false
	var hand := _views[0].source as CanvasItem
	var hand_material := hand.material
	hand.material = LightKit.emissive_material()
	if not await _sample("normal", "U0-unshaded-right"): return false
	_set_probe(-1, false)
	if not await _sample("normal", "U1-unshaded-left"): return false
	hand.material = hand_material
	_lamp.enabled = false
	_occluder.visible = false
	for entry in _views:
		(entry.lamp as PointLight2D).enabled = false
		(entry.occluder as LightOccluder2D).visible = false
	for state in _saved_lights:
		(state.node as Light2D).enabled = state.enabled
		(state.node as Light2D).visible = state.visible
	return await _sample("normal", "N1-scene-restored")


func _hold(node: Node) -> void:
	node.set_process(false)
	node.set_physics_process(false)
	for child in node.get_children(): _hold(child)


func _on_node_added(node: Node) -> void:
	if not (node is Player or node is Enemy) or not is_instance_valid(_level) or not _level.is_ancestor_of(node): return
	if node.is_node_ready(): _hold(node)
	else: node.ready.connect(_hold.bind(node), CONNECT_ONE_SHOT)


func _set_egret(world: bool) -> void:
	var rig := _egret._actor.rig
	rig.use_level_lighting = world
	rig._apply_fill(LightKit.character_fill if world else 1.0)
	rig._apply_light_cap(LightKit.character_light_cap if world else LightKit.character_light_cap_for(1.0, 1.0))


func _new_lamp(parent: Node) -> PointLight2D:
	var lamp := LightKit.create_point_light(Color.WHITE, 100.0, 0.15, true, false)
	parent.add_child(lamp)
	lamp.enabled = false
	return lamp


func _new_occluder(parent: Node) -> LightOccluder2D:
	var result := LightOccluder2D.new()
	result.occluder = OccluderPolygon2D.new()
	result.occluder.cull_mode = OccluderPolygon2D.CULL_DISABLED
	result.occluder.polygon = PackedVector2Array([Vector2(-1,-60), Vector2(1,-60), Vector2(1,60), Vector2(-1,60)])
	result.hide()
	parent.add_child(result)
	return result


func _set_probe(side: int, blocked: bool) -> void:
	var position := _target + Vector2(40.0 * side, -5.0)
	_lamp.global_position = position
	_lamp.enabled = true
	_occluder.global_position = _target + Vector2(-20, 0)
	_occluder.visible = blocked
	for entry in _views:
		(entry.lamp as PointLight2D).global_position = position
		(entry.lamp as PointLight2D).enabled = true
		(entry.occluder as LightOccluder2D).global_position = _occluder.global_position
		(entry.occluder as LightOccluder2D).visible = blocked


func _make_view(part: CanvasItem) -> bool:
	if not _require(part is Sprite2D or part is Polygon2D, "unsupported drawable"): return false
	if not _require(not part is Polygon2D or (part as Polygon2D).get_bone_count() == 0, "GPU skin needs full skeleton copy; not accepted here"): return false
	for name in [&"sway_a_shape", &"sway_b_shape"]:
		var value: Variant = part.get_instance_shader_parameter(name)
		if not _require(not value is Vector2 or value.x == 0.0, "active selected-part sway needs expanded proof"): return false
	var ancestor: Node = part
	while ancestor is CanvasItem:
		if not _require(is_equal_approx(ancestor.modulate.a, 1.0) and ancestor.clip_children == CanvasItem.CLIP_CHILDREN_DISABLED, "ancestor alpha/clip unsupported"): return false
		ancestor = ancestor.get_parent()
	var view := SubViewport.new()
	view.size = _main_size
	view.world_2d = World2D.new()
	view.world_3d = World3D.new()
	view.transparent_bg = true
	view.use_hdr_2d = true
	view.disable_3d = true
	view.canvas_item_default_texture_filter = get_viewport().canvas_item_default_texture_filter
	view.canvas_item_default_texture_repeat = get_viewport().canvas_item_default_texture_repeat
	view.msaa_2d = get_viewport().msaa_2d
	view.snap_2d_transforms_to_pixel = get_viewport().snap_2d_transforms_to_pixel
	view.snap_2d_vertices_to_pixel = get_viewport().snap_2d_vertices_to_pixel
	view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(view)
	view.canvas_transform = get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	var ambient := CanvasModulate.new()
	ambient.color = _level._lighting._modulate.color
	view.add_child(ambient)
	var copy := part.duplicate(0) as Node2D
	for child in copy.get_children():
		copy.remove_child(child)
		child.free()
	copy.process_mode = Node.PROCESS_MODE_DISABLED
	view.add_child(copy)
	copy.global_transform = part.get_global_transform()
	copy.modulate = _effective_modulate(part)
	var parent := part.get_parent()
	while parent is CanvasItem:
		if copy.texture_filter == CanvasItem.TEXTURE_FILTER_PARENT_NODE and parent.texture_filter != CanvasItem.TEXTURE_FILTER_PARENT_NODE:
			copy.texture_filter = parent.texture_filter
		if copy.texture_repeat == CanvasItem.TEXTURE_REPEAT_PARENT_NODE and parent.texture_repeat != CanvasItem.TEXTURE_REPEAT_PARENT_NODE:
			copy.texture_repeat = parent.texture_repeat
		parent = parent.get_parent()
	for name in [&"sway_a", &"sway_a_shape", &"sway_b", &"sway_b_shape", &"sway_padding", &"sway_bounds"]:
		var value: Variant = part.get_instance_shader_parameter(name)
		if value != null: copy.set_instance_shader_parameter(name, value)
	var local: Rect2 = part.get_rect() if part is Sprite2D else _polygon_bounds(part.polygon)
	var geometry: Rect2 = (view.canvas_transform * part.get_global_transform()) * local
	var start := Vector2i(floor(geometry.position.x) - 4, floor(geometry.position.y) - 4)
	var end := Vector2i(ceil(geometry.end.x) + 4, ceil(geometry.end.y) + 4)
	var rect := Rect2i(start, end - start)
	if not _require(Rect2i(Vector2i.ZERO, _main_size).encloses(rect), "selected part ROI clipped"): return false
	_views.append({"view": view, "copy": copy, "source": part, "rect": rect, "texture": part.get("texture"),
		"lamp": _new_lamp(view), "occluder": _new_occluder(view)})
	return true


func _polygon_bounds(points: PackedVector2Array) -> Rect2:
	var result := Rect2(points[0], Vector2.ZERO)
	for point in points: result = result.expand(point)
	return result


func _settle(frames: int) -> void:
	for frame in frames: await get_tree().process_frame
	await RenderingServer.frame_post_draw


func _sample(group: String, label: String) -> bool:
	for entry in _views:
		(entry.copy as CanvasItem).set("texture", (entry.source as CanvasItem).get("texture"))
		(entry.copy as CanvasItem).material = (entry.source as CanvasItem).material
		(entry.copy as CanvasItem).self_modulate = (entry.source as CanvasItem).self_modulate
		(entry.copy as CanvasItem).modulate = _effective_modulate(entry.source)
	var before := _witness()
	await _settle(2)
	var main := get_viewport().get_texture().get_image()
	if not _require(main.get_format() == Image.FORMAT_RGBH and main.get_size() == SIZE
		and not main.has_mipmaps() and main.get_data().size() == SIZE.x * SIZE.y * 6, "expected true RGBH native main"): return false
	var record := {"group": group, "label": label, "draw": Engine.get_frames_drawn(), "before": before, "after": _witness(),
		"native_geometry": _native_geometry(group + "/" + label, main),
		"main": _save_image(group + "/" + label + "-main", main), "parts": []}
	for entry in _views:
		var source := entry.source as CanvasItem
		var view := entry.view as SubViewport
		var image := view.get_texture().get_image()
		if not _require(image.get_format() == Image.FORMAT_RGBAH and image.get_size() == _main_size, "expected unquantized RGBAH part viewport"): return false
		var crop := image.get_region(entry.rect)
		var part := _part_witness(source)
		part["copy_transform"] = Held.transform_values((entry.copy as CanvasItem).get_global_transform())
		part["copy_color"] = _color((entry.copy as CanvasItem).self_modulate)
		part["copy_modulate"] = _color((entry.copy as CanvasItem).modulate)
		part["copy_material_id"] = (entry.copy as CanvasItem).material.get_instance_id()
		part["copy_texture_id"] = (entry.copy as CanvasItem).get("texture").get_instance_id()
		part["copy_has_script"] = (entry.copy as CanvasItem).get_script() != null
		part["view_transform"] = Held.transform_values(view.canvas_transform)
		part["view_size"] = [view.size.x, view.size.y]
		part["view_msaa"] = view.msaa_2d
		part["main_msaa"] = get_viewport().msaa_2d
		part["roi"] = [entry.rect.position.x, entry.rect.position.y, entry.rect.size.x, entry.rect.size.y]
		part["isolated"] = _save_image(group + "/" + label + "-" + str(source.name), crop)
		(record.parts as Array).append(part)
	_records.append(record)
	return _require(before == record.after, "source pose/lighting changed during the same sample")


func _part_witness(part: CanvasItem) -> Dictionary:
	var texture := part.get("texture") as Texture2D
	var canvas := texture as CanvasTexture
	var material := part.material as ShaderMaterial
	var result := {"name": str(part.name), "path": str(part.get_path()), "kind": part.get_class(), "script": part.get_script().resource_path if part.get_script() != null else "",
		"transform": Held.transform_values(part.get_global_transform()), "color": _color(part.self_modulate), "modulate": _color(part.modulate), "mask": part.light_mask,
		"effective_modulate": _color(_effective_modulate(part)),
		"visible": part.is_visible_in_tree(), "use_parent_material": part.use_parent_material,
		"texture_id": texture.get_instance_id(), "texture_size": [texture.get_width(), texture.get_height()], "normal_id": canvas.normal_texture.get_instance_id() if canvas != null and canvas.normal_texture != null else null,
		"material_id": part.material.get_instance_id(), "shader": material.shader.resource_path if material != null else "CanvasItemMaterial/unshaded",
		"fill": material.get_shader_parameter("fill") if material != null else null, "cap": material.get_shader_parameter("light_cap") if material != null else null}
	if part is Polygon2D:
		result["polygon"] = _vectors(part.polygon)
		result["uv"] = _vectors(part.uv)
		var triangles: Array = []
		for indices in part.polygons: triangles.append(Array(indices))
		result["triangles"] = triangles
	else:
		var rect: Rect2 = part.get_rect()
		result["rect"] = [rect.position.x, rect.position.y, rect.size.x, rect.size.y]
	return result


func _witness() -> Dictionary:
	var parts: Array = []
	for entry in _views: parts.append(_part_witness(entry.source))
	var egret_bounds := _egret._actor.rig.visual_bounds()
	return {"player": [_level.player.global_position.x, _level.player.global_position.y], "facing": _level.player.facing,
		"player_alive": _level.player.health.current > 0 and not _level.player.is_dead(),
		"aim": [_level.player.aim_dir.x, _level.player.aim_dir.y], "canvas": Held.transform_values(get_viewport().get_final_transform() * get_viewport().get_canvas_transform()),
		"parts": parts, "egret_world": _egret._actor.rig.use_level_lighting, "egret_fill": _egret._actor.rig._fill, "egret_cap": _egret._actor.rig._light_cap,
		"egret_visible": _egret.is_visible_in_tree(), "egret_skin": _egret._actor.rig.skin_id,
		"egret_clock": _egret._actor._t, "egret_processing": _egret.is_processing(),
		"egret_actor_processing": _egret._actor.is_processing(),
		"egret_physics_processing": _egret.is_physics_processing(),
		"egret_actor_physics_processing": _egret._actor.is_physics_processing(),
		"egret_bones": _bone_witness(_egret._actor.rig),
		"egret_bounds": [egret_bounds.position.x, egret_bounds.position.y, egret_bounds.size.x, egret_bounds.size.y],
		"player_fill": _rig._fill, "player_cap": _rig._light_cap, "owners": Held.snapshot(_level)}


func _bone_witness(rig: CharacterRig) -> Dictionary:
	var result := {}
	for name in rig._order:
		result[str(name)] = Held.transform_values(rig.bone(name).global_transform)
	return result


func _save_image(stem: String, image: Image) -> Dictionary:
	DirAccess.make_dir_recursive_absolute(_out.path_join(stem.get_base_dir()))
	var bytes := image.get_data()
	var path := _out.path_join(stem)
	var writer := FileAccess.open(path + ".raw", FileAccess.WRITE)
	if writer == null:
		_require(false, "cannot open raw output " + stem)
		return {}
	writer.store_buffer(bytes)
	writer.close()
	if Capture.encode(image, true).save_png(path + ".png") != OK: _require(false, "cannot save PNG " + stem)
	return {"raw": stem + ".raw", "png": stem + ".png", "raw_sha256": FileAccess.get_sha256(path + ".raw"), "png_sha256": FileAccess.get_sha256(path + ".png"),
		"width": image.get_width(), "height": image.get_height(), "format": image.get_format(), "bytes": bytes.size(), "has_mipmaps": image.has_mipmaps()}


func _color(value: Color) -> Array:
	return [value.r, value.g, value.b, value.a]


func _native_geometry(phase: String, image: Image) -> Dictionary:
	var viewport := get_viewport()
	var window := get_window()
	var visible := viewport.get_visible_rect()
	return {"phase": phase, "draw": Engine.get_frames_drawn(), "window_mode": window.mode,
		"window_size": [window.size.x, window.size.y],
		"viewport_visible_rect": [visible.position.x, visible.position.y, visible.size.x, visible.size.y],
		"texture_reported_size": [viewport.get_texture().get_width(), viewport.get_texture().get_height()],
		"image_size": [image.get_width(), image.get_height()], "image_format": image.get_format(),
		"image_bytes": image.get_data().size(), "image_has_mipmaps": image.has_mipmaps(),
		"final_transform": Held.transform_values(viewport.get_final_transform()),
		"canvas_transform": Held.transform_values(viewport.get_canvas_transform()),
		"final_x_canvas": Held.transform_values(viewport.get_final_transform() * viewport.get_canvas_transform()),
		"keep_aspect": window.content_scale_aspect == Window.CONTENT_SCALE_ASPECT_KEEP,
		"content_scale_size": [window.content_scale_size.x, window.content_scale_size.y],
		"msaa_2d": viewport.msaa_2d, "hdr_2d": viewport.use_hdr_2d}


func _effective_modulate(part: CanvasItem) -> Color:
	var result := Color.WHITE
	var item: CanvasItem = part
	while item != null:
		result *= item.modulate
		if item.top_level: break
		item = item.get_parent() as CanvasItem
	return result


func _vectors(values: PackedVector2Array) -> Array:
	var result: Array = []
	for value in values: result.append([value.x, value.y])
	return result


func _write_json(name: String, value: Dictionary) -> void:
	var file := FileAccess.open(_out.path_join(name), FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify(value, "  ") + "\n")
		file.close()


func _exit_tree() -> void:
	get_viewport().set_disable_input(_input_before)
