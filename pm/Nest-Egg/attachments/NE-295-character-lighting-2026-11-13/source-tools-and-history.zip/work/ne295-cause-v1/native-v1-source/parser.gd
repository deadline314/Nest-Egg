extends Node


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	var script := load("res://work/ne295-cause-v1/capture.gd") as Script
	var valid := script != null and script.can_instantiate()
	print("NE295_CAUSE_FULL_AUTOLOAD_PARSE valid=", valid)
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if valid else 2)
