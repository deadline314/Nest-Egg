"""Independent actual-geometry/known-normal reader. No game source edits or Godot."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("causal_reader", HERE.parent / "ne295-cause-v1/read.py")
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
CASES = ["open", "grip", "mirror", "forearm", "sit_mesh"]
LABELS = ["actual-old", "identity-old", "actual-reference", "known-old", "known-reference", "known-normal-old", "known-normal-reference", "known-direction", "flat-old", "flat-reference", "actual-restored"]


def half_interval(values):
    """Enclose original half-float rounding, not an image/noise allowance."""
    v = np.asarray(values, dtype=np.float16)
    return np.nextafter(v, np.float16(-np.inf)).astype(float), np.nextafter(v, np.float16(np.inf)).astype(float)


def expected_normals(geometry, shape):
    vertices = np.asarray(geometry["pixel_vertices"], dtype=float)
    world = np.asarray(geometry["world_vertices"], dtype=float)
    uv = np.asarray(geometry["uv"], dtype=float)
    assert vertices.shape == world.shape == uv.shape and vertices.shape[1] == 2
    height, width = shape
    expected = np.zeros((height, width, 3))
    interior = np.zeros((height, width), dtype=bool)
    for face in geometry["faces"]:
        a, b, c = face
        plane = np.column_stack((vertices[b] - vertices[a], vertices[c] - vertices[a]))
        tex = np.column_stack((uv[b] - uv[a], uv[c] - uv[a]))
        if abs(np.linalg.det(plane)) < 1e-9 or abs(np.linalg.det(tex)) < 1e-9:
            continue
        x0, y0 = np.maximum(np.floor(vertices[face].min(axis=0)).astype(int), 0)
        x1, y1 = np.minimum(np.ceil(vertices[face].max(axis=0)).astype(int), [width, height])
        if x0 >= x1 or y0 >= y1:
            continue
        yy, xx = np.mgrid[y0:y1, x0:x1]
        points = np.stack((xx + .5, yy + .5), axis=-1)
        weights = (points - vertices[a]) @ np.linalg.inv(plane).T
        bary = np.stack((1 - weights[..., 0] - weights[..., 1], weights[..., 0], weights[..., 1]), axis=-1)
        # Derivatives must not cross a triangle edge; use real physical edge distance.
        area2 = abs(np.linalg.det(plane))
        altitudes = area2 / np.array([np.linalg.norm(vertices[c] - vertices[b]), np.linalg.norm(vertices[a] - vertices[c]), np.linalg.norm(vertices[b] - vertices[a])])
        inside = (bary * altitudes > 1.5).all(axis=-1)
        derivative = np.column_stack((world[b] - world[a], world[c] - world[a])) @ np.linalg.inv(tex)
        tangent = derivative[:, 0] / np.linalg.norm(derivative[:, 0])
        # Known encoded RGB (.8,.5,.8) decodes in the pinned engine to (.6,0,.8).
        normal = np.array([.6 * tangent[0], .6 * tangent[1], .8])
        normal /= np.linalg.norm(normal)
        expected[y0:y1, x0:x1][inside] = normal
        interior[y0:y1, x0:x1] |= inside
    return expected, interior


def diagnose_case(folder, rows):
    images = {r["label"]: common.image(folder, r["raw"]) for r in rows}
    assert list(images) == LABELS
    for row in rows:
        assert row["before"] == row["after"]
        assert row["raw"]["format"] == 15 and row["raw"]["width"] == 1280 and row["raw"]["height"] == 720
    common.restored(images["actual-old"], images["actual-restored"])
    common.restored(images["actual-old"], images["identity-old"])
    common.restored(images["flat-old"], images["flat-reference"])
    expected, inside = expected_normals(rows[0]["before"], (720, 1280))
    opaque = images["known-reference"][..., 3] >= .999
    mask = inside & opaque
    assert mask.any(), "no opaque triangle interiors"
    normal_ref = images["known-normal-reference"][..., :3]
    low, high = half_interval(normal_ref)
    low, high = low * 2 - 1, high * 2 - 1
    # Only float32 arithmetic plus the independently enclosed original half rounding.
    epsilon = np.finfo(np.float32).eps * 16
    within = ((expected >= low - epsilon) & (expected <= high + epsilon)).all(axis=-1)
    original = images["known-normal-old"][..., :3] * 2 - 1
    ref_error = np.linalg.norm(normal_ref * 2 - 1 - expected, axis=-1)
    old_error = np.linalg.norm(original - expected, axis=-1)
    direction = images["known-direction"][..., :3]
    d0, d1 = half_interval(direction)
    d0, d1 = d0 * 2 - 1, d1 * 2 - 1
    terms0, terms1 = expected * d0, expected * d1
    dot0 = np.maximum(np.minimum(terms0, terms1).sum(axis=-1), 0)
    dot1 = np.maximum(np.maximum(terms0, terms1).sum(axis=-1), 0)
    observed = images["known-reference"][..., 0]
    o0, o1 = half_interval(observed)
    lambert = (o1 + epsilon >= dot0) & (o0 - epsilon <= dot1)
    return {"case": rows[0]["case"], "opaque_interior_pixels": int(mask.sum()), "normal_enclosure_passed": bool(within[mask].all()),
            "normal_outside_enclosure": int((mask & ~within).sum()), "lambert_enclosure_passed": bool(lambert[mask].all()),
            "lambert_outside_enclosure": int((mask & ~lambert).sum()), "original_normal_max_error": float(old_error[mask].max()),
            "reference_normal_max_error": float(ref_error[mask].max()), "original_normal_mean_error": float(old_error[mask].mean()),
            "actual_reference_changed_pixels": int(np.any(images["actual-old"] != images["actual-reference"], axis=-1).sum()),
            "source_geometry": rows[0]["before"], "flat_identity_exact": True, "actual_restore_exact": True}


def verify(folder):
    folder = Path(folder)
    receipt = json.loads((folder.parent / "exit.json").read_bytes())
    assert receipt["strict_clean"] and receipt["exit"] == 0 and receipt["source_fixed"] and receipt["c_fixed"]
    assert receipt["c_count"] == 463 and receipt["all_four_queues_clear"] and not receipt["diagnostics"] and not receipt["owned_after"]
    assert (folder.parent / "source-before.json").read_bytes() == (folder.parent / "source-after.json").read_bytes()
    for name in ["outer-before", "inner-before", "inner-after", "outer-after"]:
        queues = json.loads((folder.parent / (name + ".json")).read_bytes())
        assert queues[0]["port"] == 8188 and queues[0]["state"] == "empty" and queues[0]["running"] == queues[0]["pending"] == 0
        assert queues[1]["port"] == 8189
        assert (queues[1]["state"] == "empty" and queues[1]["running"] == queues[1]["pending"] == 0) or (queues[1]["state"] == "refused" and queues[1]["winerror"] == 10061)
    report = json.loads((folder / "basis.json").read_bytes())
    assert report["complete"] and not report["failures"] and len(report["records"]) == 55
    assert report["renderer"] == "forward_plus" and "RX9070XT" in report["adapter"].replace(" ", "")
    assert report["window_size"] == report["view_size"] == [1280, 720]
    results = []
    for case in CASES:
        rows = [r for r in report["records"] if r["case"] == case]
        assert sum(row["raw"]["bytes"] for row in rows) < 90_000_000
        results.append(diagnose_case(folder, rows))
    return {"capture_controls_valid": True, "reference_validation_passed": all(r["normal_enclosure_passed"] and r["lambert_enclosure_passed"] for r in results), "results": results, "product_adopted": False,
            "scope": "RAM reference test; inspect expected normal/Lambert enclosures and actual visual differences before any product change"}


def self_test():
    geometry = {"pixel_vertices": [[10, 10], [30, 10], [10, 30]], "world_vertices": [[0, 0], [0, 20], [-20, 0]],
                "uv": [[0, 0], [20, 0], [0, 20]], "faces": [[0, 1, 2]]}
    n, mask = expected_normals(geometry, (40, 40))
    assert mask.any() and np.allclose(n[mask], [0, .6, .8], rtol=0, atol=1e-14)
    assert not np.allclose(n[mask], [.6, 0, .8])
    flat = np.tile([0, 0, 1.0], (mask.sum(), 1))
    assert np.array_equal(flat[:, :2], np.zeros_like(flat[:, :2]))
    lo, hi = half_interval(np.array([.3, .5, .8]))
    assert np.all(lo < [.3, .5, .8]) and np.all(hi > [.3, .5, .8])
    return {"checks": 4, "failures": 0, "native_runs": 0, "scope": "known rotated triangle, original item-basis negative, flat identity and exact format rounding bounds"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", nargs="?")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    value = self_test() if args.self_test else verify(args.folder)
    Path(args.out).write_bytes((json.dumps(value, indent=2) + "\n").encode())
    print(json.dumps({k: v for k, v in value.items() if k != "results"}, indent=2))
    if not args.self_test and not value["reference_validation_passed"]:
        raise SystemExit(2)
