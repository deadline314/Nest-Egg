extends Node

func _ready() -> void:
	_run.call_deferred()

func _run() -> void:
	var source := load("res://work/ne295-renderer-coverage-v1/basis_capture.gd") as Script
	var valid := source != null and source.can_instantiate()
	print("NE295_BASIS_PARSE valid=", valid)
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if valid else 2)
