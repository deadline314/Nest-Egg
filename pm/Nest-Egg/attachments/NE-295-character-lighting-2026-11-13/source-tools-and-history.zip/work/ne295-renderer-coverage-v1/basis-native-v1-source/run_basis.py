"""One explicitly authorized NE295 rooftop parser/native phase; primary lock and four queue gates.

Derived from immutable NE295 import/contracts runner SHA 5dfa49eb592ad509e52095b374f936679f4229075c8eadc6e123b09878d8e939. No model/service operations.
"""
import argparse
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request

TREE = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ROOT = Path("C:/Users/stanl/Github/Nest-Egg")
BASE = "92521d0cf3c18bd3dad4b13a316844e70bfaecd0"
GUARD = ROOT / "work/ne296-adoption-v1/c-native-context-v29.json"
GUARD_SHA = "a3df1f1a2c27952545453a3d1b8a422a42755deddcc86088a70c1dc62e1d81d0"
ENGINE = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
PREFIXES = ("autoload/", "core/", "data/", "game/", "ui/", "art/", "audio/", "scenes/", "tests/", "tools/", "assets_src/audio/")


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())


def snapshot():
    names = subprocess.check_output(["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"], cwd=TREE).decode().split("\0")
    names = {n for n in names if n and (n.startswith(PREFIXES) or n.startswith("project.godot"))}
    names.update(p.relative_to(TREE).as_posix() for p in HERE.iterdir() if p.is_file())
    names.add("work/ne295-v1/candidate-v1.json")
    names.update("work/ne295-cause-v1/" + n for n in ("capture.gd", "read.py"))
    return {n: {"bytes": (TREE / n).stat().st_size, "sha256": sha(TREE / n)} for n in sorted(names) if (TREE / n).is_file()}


def queues():
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    rows = []
    for port in (8188, 8189):
        try:
            with opener.open(f"http://127.0.0.1:{port}/queue", timeout=3) as response:
                raw = response.read()
            value = json.loads(raw)
            assert isinstance(value["queue_running"], list) and isinstance(value["queue_pending"], list)
            running, pending = len(value["queue_running"]), len(value["queue_pending"])
            rows.append({"port": port, "state": "empty" if running == pending == 0 else "busy", "running": running, "pending": pending,
                         "response_sha256": hashlib.sha256(raw).hexdigest()})
        except urllib.error.URLError as error:
            code = getattr(error.reason, "winerror", None)
            rows.append({"port": port, "state": "refused" if code == 10061 else "unknown", "winerror": code})
        except Exception as error:
            rows.append({"port": port, "state": "unknown", "error": type(error).__name__})
    return rows


def clear(rows):
    return len(rows) == 2 and rows[0]["state"] == "empty" and rows[1]["state"] in ("empty", "refused")


def owned_processes():
    path = str(TREE)
    alternate = path.replace("/", "\\")
    command = ("Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'Godot*' -and "
               f"($_.CommandLine -like '*{path}*' -or $_.CommandLine -like '*{alternate}*') }} | "
               "Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress")
    result = subprocess.run(["powershell", "-NoProfile", "-Command", command], capture_output=True, text=True, check=True)
    value = json.loads(result.stdout) if result.stdout.strip() else []
    return value if isinstance(value, list) else [value]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("epoch")
    parser.add_argument("--kind", required=True, choices=("parser", "native"))
    args = parser.parse_args()
    assert re.fullmatch(r"[A-Za-z0-9_-]+", args.epoch)
    out = HERE / args.epoch
    out.mkdir(exist_ok=False)
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=TREE).decode().strip() == BASE
    assert sha(GUARD) == GUARD_SHA
    guard = json.loads(GUARD.read_bytes())["files"]
    assert len(guard) == 463 and all(sha(ROOT / name) == value for name, value in guard.items())
    (out / "c-guard-original.json").write_bytes(GUARD.read_bytes())
    write(out / "c-before.json", guard)
    original_manifest = TREE / "work/ne295-v1/candidate-v1.json"
    candidate = json.loads(original_manifest.read_bytes())
    assert candidate["count"] == 20 and all(sha(TREE / name) == row["final_sha256"] for name, row in candidate["files"].items())
    (out / "candidate-original.json").write_bytes(original_manifest.read_bytes())
    before = snapshot()
    write(out / "source-before.json", before)
    assert not owned_processes()
    environment = os.environ.copy()
    for key in ("APPDATA", "LOCALAPPDATA", "USERPROFILE", "TMP", "TEMP"):
        directory = out / "userdata" / key
        directory.mkdir(parents=True, exist_ok=True)
        environment[key] = str(directory)
    command = [ENGINE, "--audio-driver", "Dummy", "--path", str(TREE)]
    command += ["--headless", "res://work/ne295-renderer-coverage-v1/parse_basis.tscn"] if args.kind == "parser" else ["--resolution", "1280x720", "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "res://work/ne295-renderer-coverage-v1/basis_capture.tscn", "--", "--out=" + str(out / "captures")]
    write(out / "command.json", {"argv": command, "cwd": str(TREE), "base": BASE, "environment": {k: environment[k] for k in ("APPDATA", "LOCALAPPDATA", "USERPROFILE", "TMP", "TEMP")},
                                  "scope": "Five actual isolated Rin drawable cases with RAM basis/known-normal diagnostics; no product adoption or performance claim"})
    lock_path = ROOT / "assets_src/work/comfy.lock"
    lock_sources = {str(ROOT / "tools/comfyui" / name): sha(ROOT / "tools/comfyui" / name) for name in ("gpu_lock.py", "comfy_guard.py")}
    write(out / "lock-consumers.json", {"primary_lock": str(lock_path), "sources": lock_sources})
    lock, held, started, code, error = None, False, False, None, None
    gates = {}
    start = time.monotonic()
    try:
        gates["outer-before"] = queues()
        write(out / "outer-before.json", gates["outer-before"])
        assert clear(gates["outer-before"]), "busy/unknown outer queue: no engine"
        lock = lock_path.open("a+b")
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        held = True
        gates["inner-before"] = queues()
        write(out / "inner-before.json", gates["inner-before"])
        assert clear(gates["inner-before"]), "busy/unknown inner queue: no engine"
        assert snapshot() == before and all(sha(ROOT / n) == value for n, value in guard.items())
        with (out / "engine.log").open("wb") as log:
            process = subprocess.Popen(command, cwd=TREE, env=environment, stdout=log, stderr=subprocess.STDOUT)
            started = True
            write(out / "process.json", {"pid": process.pid})
            try:
                code = process.wait(timeout=240)
            except subprocess.TimeoutExpired:
                cleanup = subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True)
                (out / "owned-timeout-cleanup.log").write_bytes(cleanup.stdout + cleanup.stderr)
                code = process.wait(timeout=30)
                raise
    except Exception as failure:
        error = repr(failure)
    finally:
        try:
            if held:
                gates["inner-after"] = queues()
                write(out / "inner-after.json", gates["inner-after"])
        finally:
            if held:
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            if lock is not None:
                lock.close()
            gates["outer-after"] = queues()
            write(out / "outer-after.json", gates["outer-after"])
    after = snapshot()
    write(out / "source-after.json", after)
    write(out / "c-after.json", {n: sha(ROOT / n) for n in guard})
    remaining = owned_processes()
    write(out / "owned-after.json", remaining)
    added = sorted(set(after) - set(before))
    changed = sorted(n for n in before if after.get(n) != before[n])
    prospective = args.kind == "import" and not changed and all(n.endswith(".uid") and n[:-4] in before for n in added)
    log = (out / "engine.log").read_text(encoding="utf-8", errors="replace") if started else ""
    diagnostics = [line for line in log.splitlines() if re.search(r"ERROR:|SCRIPT ERROR|WARNING:|^FAIL|leaked at exit|resources still in use|RID allocations.*leaked", line)]
    c_same = all(sha(ROOT / n) == value for n, value in guard.items())
    consumers_same = all(sha(name) == value for name, value in lock_sources.items())
    queues_clear = len(gates) == 4 and all(clear(rows) for rows in gates.values())
    clean = started and code == 0 and error is None and not remaining and not diagnostics and c_same and consumers_same and queues_clear and (before == after or prospective)
    receipt = {"base": BASE, "kind": args.kind, "exit": code, "strict_clean": clean, "engine_started": started, "error": error,
               "wall_seconds": time.monotonic() - start, "before_count": len(before), "after_count": len(after), "source_fixed": before == after,
               "prospective_import_UIDs": added if prospective else [], "added": added, "changed": changed, "c_count": len(guard), "c_fixed": c_same,
               "lock_consumers_fixed": consumers_same, "all_four_queues_clear": queues_clear, "diagnostics": diagnostics, "owned_after": remaining}
    write(out / "exit.json", receipt)
    print(json.dumps(receipt, indent=2), flush=True)
    return 0 if clean else 1


if __name__ == "__main__":
    raise SystemExit(main())
