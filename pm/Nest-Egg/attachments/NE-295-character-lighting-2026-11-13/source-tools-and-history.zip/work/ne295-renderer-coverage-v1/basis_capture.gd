extends "res://work/ne295-cause-v1/capture.gd"
## Actual isolated drawable, not a rebuilt mesh. Private RAM shader reference only.

var _basis_view: SubViewport
var _basis_rig: CharacterRig
var _basis_target: Node2D
var _basis_material: ShaderMaterial
var _basis_original_material: Material
var _basis_original_texture: Texture2D
var _basis_rows: Array[Dictionary] = []
var _basis_sources: Dictionary = {}


func _run() -> void:
	var valid := _require(_out.is_absolute_path() and DisplayServer.get_name() != "headless", "native basis observer requires absolute output")
	if valid:
		DirAccess.make_dir_recursive_absolute(_out)
		get_window().mode = Window.MODE_WINDOWED
		get_window().size = SIZE
		Settings.use_storage("user://ne295-basis-settings.cfg")
		Settings.set_light_quality(LightQuality.Tier.HIGH)
		get_viewport().set_disable_input(true)
		await _settle(2)
		_basis_view = SubViewport.new()
		_basis_view.size = SIZE
		_basis_view.world_2d = World2D.new()
		_basis_view.world_3d = World3D.new()
		_basis_view.transparent_bg = true
		_basis_view.use_hdr_2d = true
		_basis_view.disable_3d = true
		_basis_view.msaa_2d = get_viewport().msaa_2d
		_basis_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
		add_child(_basis_view)
		_basis_view.canvas_transform = Transform2D(0.0, Vector2(2, 2), 0.0, Vector2.ZERO)
		var ambient := CanvasModulate.new()
		ambient.color = Color.BLACK
		_basis_view.add_child(ambient)
		var light := _new_lamp(_basis_view)
		light.global_position = Vector2(260, 165)
		light.texture_scale = 500.0 * 2.0 / LightKit.TEXTURE_SIZE
		light.energy = 0.15
		light.shadow_enabled = false
		light.enabled = true
		for case in ["open", "grip", "mirror", "forearm", "sit_pose"]:
			if not await _basis_case(case):
				valid = false
				break
	_write_json("basis.json", {"schema": "ne295-basis-v1", "scope": "final product-v2 actual isolated Rin drawables versus frozen v1 RAM derivative oracle; original known-old diagnostic remains negative",
		"adapter": RenderingServer.get_video_adapter_name(), "renderer": RenderingServer.get_current_rendering_method(),
		"window_size": [get_window().size.x, get_window().size.y], "view_size": [SIZE.x, SIZE.y],
		"canvas": Held.transform_values(_basis_view.canvas_transform) if _basis_view != null else [],
		"sources": _basis_sources, "records": _basis_rows, "failures": _failures,
		"complete": valid and _basis_rows.size() == 55})
	_basis_original_material = null
	_basis_original_texture = null
	_basis_material = null
	_basis_target = null
	_basis_rig = null
	if _basis_view != null: _basis_view.queue_free()
	await _settle(4)
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if valid and _failures.is_empty() and _basis_rows.size() == 55 else 2)


func _basis_case(case: String) -> bool:
	_basis_rig = CharacterRig.new()
	_basis_view.add_child(_basis_rig)
	if not _require(_basis_rig.setup("rin", "npc" if case == "sit_pose" else "humanoid"), "Rin fixture failed"): return false
	_basis_rig.facing = -1 if case == "mirror" else 1
	_basis_rig.scale *= 4.0
	_basis_rig.set_weapon("pistol" if case == "grip" else "")
	var input := RigInput.new()
	input.on_floor = true
	input.facing = _basis_rig.facing
	input.aim_dir = Vector2(input.facing, 0)
	input.npc_pose = &"sit" if case == "sit_pose" else &"stand"
	if case == "sit_pose": input.two_handed = false
	var pose_before := _pose_witness()
	for tick in 90 if case == "sit_pose" else 24: _basis_rig.animate(1.0 / 60.0, input)
	# RigInput's ordinary facing setter retains canonical scale; enlarge only after warmup.
	_basis_rig.scale = Vector2(4.6 * input.facing, 4.6)
	if case == "sit_pose":
		_basis_sources["sit_activation"] = {"before": pose_before, "after": _pose_witness(), "two_handed": input.two_handed, "animator_is_npc": _basis_rig.animator is NpcAnimator}
		if not _require(_basis_rig._active_pose_set == &"sit", "actual authored sit pose was not active"): return false
		for part: CanvasItem in _basis_rig._parts:
			if str(part.name) == "Pose_sit__armor_thigh" and part.is_visible_in_tree(): _basis_target = part as Node2D
		if not _require(_basis_target is Sprite2D, "published Rin sit replacement must be the actual Sprite"): return false
	else:
		for part: CanvasItem in _basis_rig._parts:
			if part.name == (&"arm_front_lower" if case == "forearm" else &"hand_front") and part.visible:
				_basis_target = part as Node2D
	if not _require(_basis_target != null, "actual selected drawable is missing"): return false
	for part: CanvasItem in _basis_rig._parts: part.visible = part == _basis_target
	if _basis_rig._weapon_root != null: _basis_rig._weapon_root.hide()
	for child in _basis_target.get_children():
		if child is CanvasItem: child.hide()
	var geometry := _basis_geometry()
	var bounds := Rect2(Vector2(geometry.world_vertices[0][0], geometry.world_vertices[0][1]), Vector2.ZERO)
	for point in geometry.world_vertices: bounds = bounds.expand(Vector2(point[0], point[1]))
	_basis_rig.position += Vector2(320, 180) - bounds.get_center()
	_basis_original_material = _basis_target.material
	_basis_original_texture = _basis_target.get("texture") as Texture2D
	_basis_material = (_basis_original_material as ShaderMaterial).duplicate() as ShaderMaterial
	var original_code := FileAccess.get_file_as_string("res://work/ne295-renderer-coverage-v1/reference-original-v1.txt")
	var code := original_code.replace("varying vec4 sway_tint;", "varying vec4 sway_tint;\nvarying vec2 ne295_position;\nuniform bool ne295_basis = false;\nuniform int ne295_diagnostic = -1;")
	code = code.replace("sway_tint = COLOR;", "ne295_position = VERTEX;\n\tsway_tint = COLOR;")
	var fragment := FileAccess.get_file_as_string("res://work/ne295-renderer-coverage-v1/basis_reference.gdshader")
	code = code.replace("\n}\n\nvoid light()", "\n" + fragment + "\n}\n\nvoid light()")
	code = code.replace("LIGHT = character_light_response(COLOR.rgb, NORMAL, LIGHT_DIRECTION, LIGHT_COLOR, LIGHT_ENERGY);",
		"if (ne295_diagnostic == 1) { LIGHT = vec4(NORMAL * 0.5 + 0.5, 1.0); }\n" +
		"else if (ne295_diagnostic == 2) { LIGHT = vec4(LIGHT_DIRECTION * 0.5 + 0.5, 1.0); }\n" +
		"else if (ne295_diagnostic == 0) { LIGHT = vec4(vec3(max(dot(NORMAL, LIGHT_DIRECTION), 0.0)), 1.0); }\n" +
		"else { LIGHT = character_light_response(COLOR.rgb, NORMAL, LIGHT_DIRECTION, LIGHT_COLOR, LIGHT_ENERGY); }")
	if not _require(code != original_code and code.contains(fragment), "RAM basis shader adapter did not apply"): return false
	var shader := Shader.new()
	shader.code = code
	_basis_material.shader = shader
	_basis_material.set_shader_parameter("fill", _basis_rig._fill)
	_basis_material.set_shader_parameter("light_cap", _basis_rig._light_cap)
	_basis_sources[case] = {"actual_product_code": CharacterRig.LIGHT_SHADER.code, "actual_product_sha256": CharacterRig.LIGHT_SHADER.code.sha256_text(), "source_code": original_code, "reference_code": code, "source_sha256": original_code.sha256_text(), "reference_sha256": code.sha256_text()}
	for label in ["actual-old", "identity-old", "actual-reference", "known-old", "known-reference", "known-normal-old", "known-normal-reference", "known-direction", "flat-old", "flat-reference", "actual-restored"]:
		var actual: bool = label.begins_with("actual")
		_basis_target.material = _basis_original_material if label in ["actual-old", "actual-restored"] else _basis_material
		_basis_material.set_shader_parameter("ne295_basis", label.ends_with("reference") or (label == "identity-old" and _basis_target is Polygon2D))
		_basis_material.set_shader_parameter("ne295_diagnostic", -1 if actual or label == "identity-old" else (2 if label == "known-direction" else (1 if label.begins_with("known-normal") else 0)))
		if actual or label == "identity-old": _basis_target.set("texture", _basis_original_texture)
		else: _basis_target.set("texture", _basis_texture(Color(0.5, 0.5, 1.0) if label.begins_with("flat") else Color(0.68, 0.26, 0.8)))
		var before := _basis_geometry()
		await _settle(2)
		var image := _basis_view.get_texture().get_image()
		if not _require(image.get_size() == SIZE and image.get_format() == Image.FORMAT_RGBAH, "basis requires original1280 RGBAH"): return false
		_basis_rows.append({"case": case, "label": label, "draw": Engine.get_frames_drawn(), "before": before, "after": _basis_geometry(),
			"raw": _save_image(case + "/" + label, image), "known_encoded_normal": [0.5, 0.5, 1.0] if label.begins_with("flat") else [0.68, 0.26, 0.8]})
		if not _require(before == _basis_rows[-1].after, "basis source geometry changed during sampling"): return false
	_basis_original_material = null
	_basis_original_texture = null
	_basis_material = null
	_basis_target = null
	_basis_rig.queue_free()
	await _settle(3)
	_basis_rig = null
	return true


func _basis_texture(normal: Color) -> CanvasTexture:
	var texture := (_basis_original_texture as CanvasTexture).duplicate() as CanvasTexture
	var image := Image.create(1, 1, false, Image.FORMAT_RGBAF)
	image.fill(normal)
	texture.normal_texture = ImageTexture.create_from_image(image)
	return texture


func _basis_geometry() -> Dictionary:
	var points := PackedVector2Array()
	var uvs := PackedVector2Array()
	var faces: Array = []
	var transform := _basis_target.global_transform
	if _basis_target is Sprite2D:
		var rect := (_basis_target as Sprite2D).get_rect()
		points = PackedVector2Array([rect.position, Vector2(rect.end.x, rect.position.y), rect.end, Vector2(rect.position.x, rect.end.y)])
		var size: Vector2 = _basis_target.texture.get_size()
		uvs = PackedVector2Array([Vector2.ZERO, Vector2(size.x, 0), size, Vector2(0, size.y)])
		faces = [[0, 1, 2], [0, 2, 3]]
	else:
		var polygon := _basis_target as Polygon2D
		points = polygon.polygon
		uvs = polygon.uv
		for indices in polygon.polygons:
			for index in range(1, indices.size() - 1): faces.append([indices[0], indices[index], indices[index + 1]])
		if polygon.get_bone_count() > 0:
			for geometry: Dictionary in _basis_rig.active_pose_mesh_geometries():
				if geometry.mesh == polygon:
					points = geometry.vertices
					transform = _basis_rig._skeleton.global_transform
	var world: Array = []
	var screen: Array = []
	for point in points:
		var positioned := transform * point
		world.append([positioned.x, positioned.y])
		var pixel := _basis_view.canvas_transform * positioned
		screen.append([pixel.x, pixel.y])
	return {"path": str(_basis_target.get_path()), "kind": _basis_target.get_class(), "script": _basis_target.get_script().resource_path if _basis_target.get_script() != null else "",
		"world_vertices": world, "pixel_vertices": screen, "uv": _vectors(uvs), "faces": faces,
		"item_transform": Held.transform_values(_basis_target.global_transform), "geometry_transform": Held.transform_values(transform),
		"self_modulate": _color(_basis_target.self_modulate), "material_id": _basis_target.material.get_instance_id(), "texture_id": _basis_target.get("texture").get_instance_id(),
		"normal_map": _basis_normal_witness()}


func _basis_normal_witness() -> Dictionary:
	var texture := _basis_target.get("texture") as CanvasTexture
	if texture == null or texture.normal_texture == null: return {"present": false}
	var normal := texture.normal_texture
	var result := {"present": true, "size": [normal.get_width(), normal.get_height()], "resource_path": normal.resource_path}
	if normal.get_width() == 1 and normal.get_height() == 1:
		var image := normal.get_image()
		result["format"] = image.get_format()
		result["bytes_hex"] = image.get_data().hex_encode()
		result["rgba"] = _color(image.get_pixel(0, 0))
	return result


func _pose_witness() -> Dictionary:
	var slots: Dictionary = {}
	for key in _basis_rig._pose_slots:
		var alternatives: Dictionary = _basis_rig._pose_slots[key]["alternatives"]
		var visible: Array = []
		for pose_key in alternatives:
			var item: CanvasItem = alternatives[pose_key]
			visible.append({"pose": str(pose_key), "name": str(item.name), "visible": item.is_visible_in_tree(), "class": item.get_class()})
		slots[str(key)] = visible
	return {"sets": _basis_rig._pose_sets.keys(), "active": str(_basis_rig.active_pose_parts()), "slots": slots}
