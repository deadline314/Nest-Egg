extends "res://work/ne295-cause-v1/capture.gd"
## Bounded component renderer gallery. It does not impersonate a campaign interaction.

var _gallery_view: SubViewport
var _stage: Node2D
var _entries: Array[Dictionary] = []
var _gallery_rows: Array[Dictionary] = []
var _page := ""
var _gallery_lamp: PointLight2D
var _gallery_occluder: LightOccluder2D
var _switch_player: Player
var _dissolve_rig: CharacterRig
var _worm: WormCreature
var _reuse: Dictionary = {}
var _fill_before := 1.0
var _cap_before := 0.5
var _normals_before := true


func _run() -> void:
	var valid: bool = _require(_out.is_absolute_path() and DisplayServer.get_name() != "headless", "gallery needs native renderer and absolute output")
	if valid:
		DirAccess.make_dir_recursive_absolute(_out)
		get_window().mode = Window.MODE_WINDOWED
		get_window().size = SIZE
		get_viewport().set_disable_input(true)
		Settings.use_storage("user://ne295-renderer-settings.cfg")
		Settings.set_light_quality(LightQuality.Tier.HIGH)
		_fill_before = LightKit.character_fill
		_cap_before = LightKit.character_light_cap
		_normals_before = LightQuality.normal_maps()
		LightKit.character_fill = 2.5
		LightKit.character_light_cap = 0.35
		LitTextures.set_enabled(true)
		await _settle(2)
		_gallery_view = SubViewport.new()
		_gallery_view.size = SIZE
		_gallery_view.world_2d = World2D.new()
		_gallery_view.world_3d = World3D.new()
		_gallery_view.transparent_bg = true
		_gallery_view.use_hdr_2d = true
		_gallery_view.disable_3d = true
		_gallery_view.msaa_2d = get_viewport().msaa_2d
		_gallery_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
		add_child(_gallery_view)
		_gallery_view.canvas_transform = Transform2D(0.0, Vector2(2, 2), 0.0, Vector2.ZERO)
		var ambient := CanvasModulate.new()
		ambient.color = Color(0.25, 0.25, 0.25)
		_gallery_view.add_child(ambient)
		_gallery_view.add_child(LightKit.create_environment())
		for page in ["held", "debris_dissolve", "worm"]:
			_page = page
			_stage = Node2D.new()
			_gallery_view.add_child(_stage)
			_entries.clear()
			_switch_player = null
			_dissolve_rig = null
			_worm = null
			_reuse = {}
			Fx.bind_container(_stage)
			valid = await _build_gallery_page()
			if valid:
				_hold(_stage)
				_gallery_lamp = _new_lamp(_stage)
				_gallery_lamp.texture_scale = 800.0 * 2.0 / LightKit.TEXTURE_SIZE
				_gallery_occluder = _new_occluder(_stage)
				for label in ["A0", "A1", "B0", "A2", "B1", "O", "A3", "LOW", "HIGH"]:
					_gallery_lamp.global_position = Vector2(500 if label.begins_with("B") else 140, 30)
					_gallery_lamp.enabled = true
					_gallery_occluder.global_position = Vector2(220, 100)
					_gallery_occluder.visible = label == "O"
					# Explicit renderer toggle; BG57 separately verifies actual Settings lifecycle.
					LitTextures.set_enabled(label != "LOW")
					if not await _gallery_sample(label):
						valid = false
						break
			if valid and page == "held": valid = await _switch_and_flash()
			if valid and page == "debris_dissolve":
				_dissolve_rig.set_dissolve(0.0)
				valid = await _gallery_sample("dissolve-zero")
				_dissolve_rig.set_dissolve(0.35)
				valid = await _gallery_sample("dissolve-progress35")
				_gallery_lamp.global_position = Vector2(500, 30)
				if valid: valid = await _gallery_sample("dissolve-light-right")
			if valid and page == "worm":
				_worm.set_opacity(0.5)
				valid = await _gallery_sample("opacity-half")
				_worm.set_opacity(1.0)
				if valid: valid = await _gallery_sample("opacity-restored")
			_entries.clear()
			_switch_player = null
			_dissolve_rig = null
			_worm = null
			_stage.queue_free()
			await _settle(4)
			RigDebris.clear_pool()
			if not valid: break
	_write_json("appearance.json", {"schema": "ne295-appearance-v1", "scope": "actual component gallery in original1280 RGBAH SubViewport; not Main/campaign/player-input or Settings lifecycle acceptance",
		"adapter": RenderingServer.get_video_adapter_name(), "renderer": RenderingServer.get_current_rendering_method(),
		"window_size": [get_window().size.x, get_window().size.y], "quality_toggle_scope": "controlled LitTextures renderer toggle; reuse BG57 final Settings/Stage evidence separately",
		"records": _gallery_rows, "failures": _failures, "complete": valid and _gallery_rows.size() == 37})
	_entries.clear()
	LightKit.character_fill = _fill_before
	LightKit.character_light_cap = _cap_before
	LitTextures.set_enabled(_normals_before)
	if _gallery_view != null: _gallery_view.queue_free()
	await _settle(4)
	RigDebris.clear_pool()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if valid and _failures.is_empty() and _gallery_rows.size() == 37 else 2)


func _rig_at(skin: String, point: Vector2, posture := &"stand") -> CharacterRig:
	var rig := CharacterRig.new()
	_stage.add_child(rig)
	if not _require(rig.setup(skin, "npc" if posture == &"sit" else "humanoid"), "gallery rig setup failed: " + skin): return null
	rig.position = point
	var input := RigInput.new()
	input.on_floor = true
	input.facing = 1
	input.aim_dir = Vector2.RIGHT
	input.npc_pose = posture
	if posture == &"sit": input.two_handed = false
	for tick in 90 if posture == &"sit" else 24: rig.animate(1.0 / 60.0, input)
	if posture == &"sit" and not _require(rig.active_pose_parts() == &"sit", "gallery real sit did not activate"): return null
	rig._apply_fill(2.5)
	rig._apply_light_cap(0.35)
	_entries.append({"id": skin + "-" + str(posture) + "-" + str(_entries.size()), "node": rig, "kind": "rig"})
	return rig


func _player_at(point: Vector2, weapon_id: String) -> Player:
	var player := Player.new()
	player.configure(load("res://data/player/player_tuning.tres") as PlayerTuning, 6, {})
	_stage.add_child(player)
	_hold(player)
	player.position = point
	player.facing = 1
	player.aim_dir = Vector2.RIGHT
	player.loadout.equip(load("res://data/weapons/melee/" + weapon_id + ".tres") as WeaponData)
	for light in player.find_children("*", "Light2D", true, false): light.enabled = false
	var input := RigInput.new()
	input.on_floor = true
	input.facing = 1
	input.aim_dir = Vector2.RIGHT
	input.melee_grip = true
	for tick in 24:
		player._visual.rig.animate(1.0 / 60.0, input)
		player._visual.melee_held().update(1.0 / 60.0)
	player._visual.rig._apply_fill(2.5)
	player._visual.rig._apply_light_cap(0.35)
	_entries.append({"id": weapon_id, "node": player, "kind": "melee"})
	return player


func _build_gallery_page() -> bool:
	if _page == "held":
		_switch_player = _player_at(Vector2(100, 145), "melee_blade")
		_player_at(Vector2(300, 145), "melee_whip")
		_rig_at("rin", Vector2(500, 145), &"sit")
		for i in 3:
			var rig := _rig_at("rin", Vector2(100 + 200 * i, 315))
			if rig == null: return false
			var item: Node2D
			if i == 2:
				var paper := PropPaperVisual.new()
				paper.progress = 1.0
				item = paper
			else:
				var sprite := Sprite2D.new()
				var path := "res://art/environment/scene_props/ali_kitchen_contacts/bowl.png" if i == 0 else "res://art/items/world/ch1_data_disk.png"
				sprite.texture = WorldPropAction._held_texture(path, load(path) as Texture2D)
				sprite.scale = Vector2.ONE * (6.0 / sprite.texture.get_width())
				item = sprite
			rig.add_child(item)
			item.z_index = rig.hand_draw_z(&"front")
			item.global_position = rig.bone(&"hand_front").global_position
			if not _require(rig.bind_attachment(item, Color(0.7, 0.8, 0.9, 0.8)), "actual held attachment did not bind"): return false
			_entries.append({"id": ["bowl", "disc", "paper"][i], "node": item, "kind": "attachment", "rig": rig})
	elif _page == "debris_dissolve":
		var donor := _rig_at("trooper", Vector2(110, 160))
		_dissolve_rig = _rig_at("trooper", Vector2(310, 160))
		if donor == null or _dissolve_rig == null: return false
		var armor := donor._armor[0][0] as CanvasItem
		var texture := armor.get("texture") as Texture2D
		var offset: Vector2 = armor.pivot_offset if armor is RigPartMesh else armor.offset
		var piece := RigDebris.spawn(texture, armor.get_global_transform(), offset, Vector2.ZERO, armor.self_modulate, donor._fill, donor._light_cap, armor.light_mask)
		if not _require(piece != null, "actual armor debris spawn failed"): return false
		_stage.add_child(piece)
		_hold(piece)
		piece.position = Vector2(500, 100)
		_entries.append({"id": "armor-debris", "node": piece._sprite, "kind": "sprite"})
		if not await _gallery_sample("armor-before-reuse", false): return false
		var identity := piece.get_instance_id()
		piece._recycle()
		await _settle(2)
		_entries.pop_back()
		var chain := ChainCreature.new()
		_stage.add_child(chain)
		chain.position = Vector2(500, 280)
		if not _require(chain.setup("salvage_arm"), "actual chain setup failed"): return false
		chain.animate(1.0 / 60.0)
		if not _require(chain.sever(0, Vector2.RIGHT), "actual chain sever failed"): return false
		await _settle(2)
		if not _require(is_instance_valid(piece) and piece.get_parent() == _stage and piece.get_instance_id() == identity, "actual chain did not reuse the armor pool entry"): return false
		_hold(piece)
		_reuse = {"same_instance": piece.get_instance_id() == identity, "material_reset": piece._sprite.material == null,
			"fill_reset_to_default": piece._sprite.material == null, "tint": _color(piece._sprite.self_modulate), "mask": piece._sprite.light_mask}
		_entries.append({"id": "chain-reused-debris", "node": piece._sprite, "kind": "sprite"})
		_entries.append({"id": "severed-chain", "node": chain, "kind": "chain"})
	elif _page == "worm":
		_worm = WormCreature.new()
		_stage.add_child(_worm)
		if not _require(_worm.setup("cloud_serpent"), "actual worm setup failed"): return false
		_worm.position = Vector2(510, 175)
		_worm.reset_trail(Vector2.RIGHT)
		for tick in 60:
			_worm.position = Vector2(510 - 120 * float(tick) / 60, 175 - 40 * sin(float(tick) / 60 * PI))
			_worm.animate(1.0 / 60.0)
		_entries.append({"id": "curved-worm", "node": _worm, "kind": "worm"})
	return _require(not _entries.is_empty(), "empty gallery page")


func _switch_and_flash() -> bool:
	var rig := _switch_player._visual.rig
	_switch_player.loadout.equip(load("res://data/weapons/melee/melee_whip.tres") as WeaponData)
	_switch_player._visual.melee_held().update(1.0 / 60.0)
	if not await _gallery_sample("same-player-whip"): return false
	_switch_player.loadout.equip(load("res://data/weapons/melee/melee_blade.tres") as WeaponData)
	_switch_player._visual.melee_held().update(1.0 / 60.0)
	if not await _gallery_sample("same-player-blade-restored"): return false
	rig.flash()
	if not await _gallery_sample("actual-flash"): return false
	var input := RigInput.new()
	input.on_floor = true
	input.facing = 1
	input.aim_dir = Vector2.RIGHT
	input.melee_grip = true
	rig.animate(0.1, input)
	_switch_player._visual.melee_held().update(1.0 / 60.0)
	return await _gallery_sample("actual-flash-recovered")


func _gallery_sample(label: String, with_light := true) -> bool:
	# Publish fresh shader-instance default values before the fixed-state witness.
	await _settle(2)
	var before := _gallery_bindings()
	await _settle(2)
	var image := _gallery_view.get_texture().get_image()
	if not _require(image.get_size() == SIZE and image.get_format() == Image.FORMAT_RGBAH and not image.has_mipmaps(), "gallery original Image size/format mismatch"): return false
	var after := _gallery_bindings()
	var transition: bool = label.begins_with("same-player") or label.begins_with("actual-flash") or label.begins_with("dissolve-")
	var group := _page + "-transitions" if transition else _page
	_gallery_rows.append({"page": _page, "label": label, "draw": Engine.get_frames_drawn(), "before": before, "after": after,
		"view": {"size": [ _gallery_view.size.x, _gallery_view.size.y ], "canvas": Held.transform_values(_gallery_view.canvas_transform), "final": Held.transform_values(_gallery_view.get_final_transform()), "msaa_2d": _gallery_view.msaa_2d, "image_format": image.get_format(), "image_bytes": image.get_data().size(), "texture_declared_size": _vectors(PackedVector2Array([_gallery_view.get_texture().get_size()]))},
		"lamp": {"active": with_light, "position": [ _gallery_lamp.position.x, _gallery_lamp.position.y ] if is_instance_valid(_gallery_lamp) else [], "height": LightKit.LIGHT_HEIGHT, "energy": 0.15},
		"pool_reuse": _reuse, "image": _save_image(group + "/" + label, image)})
	return _require(before == after, "gallery source binding changed during sample")


func _gallery_bindings() -> Array:
	var result: Array = []
	for entry in _entries:
		var node := entry.node as Node2D
		var row := {"id": entry.id, "kind": entry.kind, "instance": node.get_instance_id(), "transform": Held.transform_values(node.global_transform), "modulate": _color(node.modulate)}
		if entry.kind == "rig":
			var rig := node as CharacterRig
			row["fill"] = rig._fill
			row["cap"] = rig._light_cap
			row["skin"] = rig.skin_id
			row["active_pose"] = str(rig._active_pose_set)
			row["parts"] = []
			for part: CanvasItem in rig._parts:
				if part.visible: (row.parts as Array).append(_binding(part))
		elif entry.kind == "melee":
			var player := node as Player
			var held := player._visual.melee_held()
			row["weapon"] = str(player.loadout.active_weapon().id)
			row["base"] = _binding(held._base_sprite)
			row["glow_unshaded"] = held.material == LightKit.emissive_material()
			row["attachment_count"] = player._visual.rig._attachments.size()
			row["rig_material_id"] = player._visual.rig._light_material.get_instance_id()
			row["flash_left"] = player._visual.rig._flash_left
		elif entry.kind in ["attachment", "sprite"]:
			row["binding"] = _binding(node)
			if entry.has("rig"): row["rig_material_id"] = (entry.rig as CharacterRig)._light_material.get_instance_id()
		elif entry.kind == "worm":
			var worm := node as WormCreature
			row["head"] = _binding(worm._head)
			row["body"] = _binding(worm._mesh)
			row["head_effective_alpha"] = worm.modulate.a * worm._head.modulate.a * worm._head.self_modulate.a
			row["body_effective_alpha"] = worm._mesh.modulate.a * worm._mesh.self_modulate.a
		result.append(row)
	return result


func _binding(item: CanvasItem) -> Dictionary:
	var texture := item.get("texture") as Texture2D if item is Sprite2D or item is Polygon2D else null
	var canvas := texture as CanvasTexture
	return {"instance": item.get_instance_id(), "path": str(item.get_path()), "material_id": item.material.get_instance_id() if item.material != null else null,
		"self_modulate": _color(item.self_modulate), "mask": item.light_mask, "visible": item.is_visible_in_tree(),
		"transform": Held.transform_values(item.get_global_transform()), "mesh_normal_basis": item.get_instance_shader_parameter(&"mesh_normal_basis"), "texture_size": _vectors(PackedVector2Array([texture.get_size()])) if texture != null else [], "z_index": item.z_index, "texture_id": texture.get_instance_id() if texture != null else null,
		"normal_id": canvas.normal_texture.get_instance_id() if canvas != null and canvas.normal_texture != null else null,
		"polygon": _vectors((item as Polygon2D).polygon) if item is Polygon2D else []}
