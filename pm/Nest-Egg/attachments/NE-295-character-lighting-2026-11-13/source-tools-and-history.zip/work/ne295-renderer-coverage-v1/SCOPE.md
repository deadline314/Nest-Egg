# NE295 renderer representatives — proposed minimum, CPU only

Keep the 20 candidate source paths fixed. This is component/caller rendering verification, not a natural campaign route, physical input test, all-character animation acceptance or performance result. Do not change C, PM, source thresholds or the original causal epochs.

## First causal scope

Finish the existing rooftop 16-full/32-ROI scope with the proven background `window_life.gdshader` TIME pinned in a private RAM material. Preserve source/fixed shader code and SHA, original uniforms, actual per-draw bindings and full-scene A/A = 0. The prior complete native-v4 raw stays rejected for full A/A, even though its isolated hand and mesh repeats were identical. The observed white mechanical hand is lit: normal/occluder/directional controls all responded and the deliberate unshaded control did not.

## Remaining real renderer paths

Use the same existing HDR readback, raw metadata, fixed-pose setup and independent reader. Arrange a bounded component gallery with a documented ambient/fill/cap, a real directional-positioned PointLight and an actual LightOccluder. Preserve the real texture, normal, material, tint, alpha and item transform. Group originals by page so every raw chunk is under 90 MB. No new global manager or general screenshot framework.

| Representative | Actual owner/API | Required observation |
|---|---|---|
| Rin open hand / pistol grip / authored sit pose | CharacterRig.animate, actual grip texture, set_pose_parts | Sprite and actual deformed pose/limb paths keep normal and material; real full-body image and actual geometry; no speculative normal-basis change |
| Blade and whip | Player.loadout.equip + actual PlayerVisual/MeleeHeld | Image base and procedural whip/handle paths receive light/shadow; original glow remains; grip/length not altered. Existing permanent contracts cover all five weapons and both facings |
| Authored bowl, legacy disc and claimed paper | WorldPropAction._held_texture and actual rig attachment binding/release; retain existing WorldPropAction/cutscene tests | Existing bowl CanvasTexture normal retained, missing-normal flat fallback is valid, original tint/alpha/region/geometry retained, release and switch do not leave a material |
| Trooper armor debris then chain fragment reuse | CharacterRig.set_armor_ratio / actual RigDebris spawn and ChainCreature.sever | Detached armor retains source tint/fill/cap/mask; real pooled reuse resets those values for chain segment; same drawable snapshot, not transient flash |
| Surviving dissolve body | CharacterRig.set_dissolve | Same actual part before and during dissolve still receives light/shadow; intact normal/fill/cap and original tint/alpha, while burn edge remains emission; unchanged geometry and visible coverage |
| Curved cloud-serpent belly plus head | WormCreature.setup/reset_trail/animate and real body mesh | Record actual body vertices/UV and belly-roll material inputs; compare original shader bytes as a RAM reference to candidate with identical geometry/normal/light. Straight/curved and belly roll must distinguish UV alignment from simple brightness |
| Cloud-serpent death and restored opacity | Actual HealthComponent lethal damage -> CloudSerpent death tween | Natural tween samples preserve matching single head/body opacity until removal. Do not set FSM/HP/phase as a result or hand-step the tween; set only the arranged spawn/fixture prerequisites |

For each page: same-source repeated A, a single lamp-direction or occlusion factor, restored A, repeated B. Keep actual full originals and nonempty component/mask witnesses. Exposure/appearance claims require the actual visible drawable, not a background-containing rectangle denominator. Keep light response separate from the deliberately emissive negative control.

At minimum HIGH -> LOW -> HIGH runs on the same original drawable/texture source must show the intended normal enable/disable and a clean restore; coordinate the quality owner with BG57 rather than inventing another one. World Egret context is covered by the causal scope. Independent stage context and StagePropHold will reuse BG57's final same-dependency native evidence when exact CharacterRig/shader dependency hashes match; do not call a sprite-only gallery a real actor-stage test.

The native gallery has not started. Final per-page sample counts and source manifest will be frozen before the next explicit GPU handoff; no automatic new matrices or unrelated tickets. The original affected selector chose 75 suites; Root will run the canonical final multi-ticket union once, retaining the NE295 selector and candidate manifest separately.
