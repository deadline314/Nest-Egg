"""Offline one-off adapter of the already exercised primary-lock protocol."""
from pathlib import Path
import hashlib
import json

here = Path(__file__).resolve().parent
source = here.parent / "ne295-cause-v1/run.py"
code = source.read_text(encoding="utf-8")
code = code.replace("res://work/ne295-cause-v1/parser.tscn", "res://work/ne295-renderer-coverage-v1/parse_basis.tscn")
code = code.replace("res://work/ne295-cause-v1/capture.tscn", "res://work/ne295-renderer-coverage-v1/basis_capture.tscn")
needle = "    return {n: {"
assert code.count(needle) == 1
code = code.replace(needle, '    names.update("work/ne295-cause-v1/" + n for n in ("capture.gd", "read.py"))\n' + needle)
code = code.replace("One rooftop fixed-pose causal capture; raw/independent reader and actual visual review required; no whole-ticket or performance claim",
                    "Five actual isolated Rin drawable cases with RAM basis/known-normal diagnostics; no product adoption or performance claim")
output = here / "run_basis.py"
output.write_bytes(code.encode())
(here / "runner-provenance.json").write_bytes((json.dumps({"source": str(source), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "output": output.name, "output_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    "changes": ["only scene paths/scope and explicit borrowed source closure", "primary lock/C463/four queues/source gates/environment/exit diagnostics remain the same"]}, indent=2) + "\n").encode())
