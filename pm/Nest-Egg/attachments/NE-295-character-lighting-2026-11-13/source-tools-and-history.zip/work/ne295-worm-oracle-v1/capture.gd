extends "res://work/ne295-cause-v1/capture.gd"
## Actual WormCreature mesh, no remeshing or runtime source replacement.
var _v: SubViewport
var _w: WormCreature
var _rows: Array[Dictionary] = []

func _run() -> void:
	var valid: bool = _require(DisplayServer.get_name() != "headless", "native worm renderer required")
	DirAccess.make_dir_recursive_absolute(_out)
	get_window().mode = Window.MODE_WINDOWED
	get_window().size = SIZE
	Settings.use_storage("user://ne295-worm-settings.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	_v = SubViewport.new()
	_v.size = SIZE
	_v.world_2d = World2D.new()
	_v.world_3d = World3D.new()
	_v.transparent_bg = true
	_v.use_hdr_2d = true
	_v.disable_3d = true
	_v.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(_v)
	_v.canvas_transform = Transform2D(0.0, Vector2(2,2), 0.0, Vector2.ZERO)
	var ambient := CanvasModulate.new()
	ambient.color = Color.BLACK
	_v.add_child(ambient)
	var lamp := _new_lamp(_v)
	lamp.position = Vector2(250, 100)
	lamp.enabled = true
	lamp.energy = 0.15
	lamp.shadow_enabled = false
	for shape in ["reset-trail", "curved-trail"]:
		if valid: valid = await _one(shape)
	_write_json("worm.json", {"complete": valid and _rows.size() == 16, "records": _rows, "failures": _failures,
		"renderer": RenderingServer.get_current_rendering_method(), "adapter": RenderingServer.get_video_adapter_name(),
		"scope": "actual WormCreature reset/curved trail same-geometry RGBAF normal-channel controls; no natural locomotion claim"})
	_w = null
	_v.queue_free()
	await _settle(4)
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if valid and _failures.is_empty() else 2)

func _one(shape: String) -> bool:
	_w = WormCreature.new()
	_v.add_child(_w)
	if not _require(_w.setup("cloud_serpent"), "real worm setup failed"): return false
	_w.position = Vector2(400,180)
	_w.reset_trail(Vector2.RIGHT)
	_w.animate(0.0)
	if shape == "curved-trail":
		for tick in 60:
			_w.position = Vector2(400 - tick * 1.5, 180 - sin(float(tick)/60.0 * PI) * 40)
			_w.animate(1.0/60.0)
	_hold(_w)
	var mesh := _w._mesh
	var original_texture := mesh.texture
	var original_material := mesh.material
	var head_visible: bool = _w._head.visible
	_w._head.hide()
	for label in ["actualA", "known-low", "known-high", "old-low", "old-high", "flat-current", "flat-published", "actual-restored"]:
		var actual: bool = label.begins_with("actual")
		if actual:
			mesh.texture = original_texture
			mesh.material = original_material
		else:
			var image := Image.create(1,1,false,Image.FORMAT_RGBAF)
			image.fill(Color(0.5,0.5,1.0) if label.begins_with("flat") else Color(0.68,0.26,0.2 if label.ends_with("low") else 0.8))
			var texture := CanvasTexture.new()
			var white := Image.create(1,1,false,Image.FORMAT_RGBAF)
			white.fill(Color.WHITE)
			texture.diffuse_texture = ImageTexture.create_from_image(white)
			texture.normal_texture = ImageTexture.create_from_image(image)
			mesh.texture = texture
			var code: String = (original_material as ShaderMaterial).shader.code
			if label.begins_with("old"): code = FileAccess.get_file_as_string("res://work/ne295-worm-oracle-v1/candidate-v1.txt")
			if label == "flat-published": code = FileAccess.get_file_as_string("res://work/ne295-worm-oracle-v1/published.txt")
			code += "\nvoid light() { LIGHT = vec4(NORMAL * 0.5 + 0.5, 1.0); }\n"
			var shader := Shader.new()
			shader.code = code
			var material := ShaderMaterial.new()
			material.shader = shader
			mesh.material = material
		var before := _geometry()
		await _settle(2)
		var image := _v.get_texture().get_image()
		if not _require(image.get_size() == SIZE and image.get_format() == Image.FORMAT_RGBAH, "original1280 RGBAH required"): return false
		_rows.append({"shape": shape, "label": label, "before": before, "after": _geometry(), "image": _save_image(shape + "/" + label, image)})
		if not _require(before == _rows[-1].after, "worm geometry drifted"): return false
	mesh.texture = original_texture
	mesh.material = original_material
	_w._head.visible = head_visible
	_w.queue_free()
	await _settle(3)
	return true

func _geometry() -> Dictionary:
	var mesh := _w._mesh
	var texture := mesh.texture as CanvasTexture
	var n: Image = texture.normal_texture.get_image() if texture != null and texture.normal_texture != null and texture.normal_texture.get_width() == 1 else null
	return {"polygon": _vectors(mesh.polygon), "uv": _vectors(mesh.uv), "transform": Held.transform_values(mesh.global_transform),
		"canvas": Held.transform_values(_v.canvas_transform), "material_id": mesh.material.get_instance_id(), "shader_code_sha256": (mesh.material as ShaderMaterial).shader.code.sha256_text(),
		"texture_id": mesh.texture.get_instance_id(), "normal_format": n.get_format() if n != null else null, "normal_bytes": n.get_data().hex_encode() if n != null else null,
		"head_hidden_only_for_body_control": not _w._head.visible, "process_mode": _w.process_mode, "width": _w._width}
