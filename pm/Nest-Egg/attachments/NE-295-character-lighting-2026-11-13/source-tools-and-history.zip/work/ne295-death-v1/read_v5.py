"""Actual natural death alpha witnesses; no whole-scene rectangle denominator."""
import argparse
import importlib.util
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("common", HERE.parent / "ne295-cause-v1/read.py")
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
spec2 = importlib.util.spec_from_file_location("full_composite", HERE.parent / "ne295-final-renderers-v1/read_appearance_v3.py")
full_composite = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(full_composite)


def alpha_check(image, expected):
    assert image.shape[-1] == 4 and np.isfinite(image).all()
    alpha = image[..., 3]
    assert np.any(alpha > 0), "empty actual part alpha"
    observed = np.float16(alpha.max())
    low = float(np.nextafter(observed, np.float16(-np.inf)))
    high = float(np.nextafter(observed, np.float16(np.inf)))
    assert low <= expected <= high, "part fade does not contain its original scalar within one format ULP"
    return {"nonempty_pixels": int((alpha > 0).sum()), "maximum_alpha": float(observed), "expected_single_alpha": expected}



def isolated_body_mask(part):
    # The frozen WormCreature.setup emits [2i,2i+1,2i+3,2i+2] quads.
    # Use the actual first neck quad, erode its edges by1 physical pixel and
    # exclude every other actual quad's AABB expanded by1. No alpha-based selection.
    assert part['source_transform']==[1,0,0,1,0,0] and part['view_canvas']==[2,0,0,2,0,0]
    assert part['view_msaa']==part['source_view_msaa']
    assert part['polygons']==part['copy_polygons'] and part['uv']==part['copy_uv']
    xy=np.asarray(part['polygon'],dtype=float)*2
    assert len(xy)>=4 and len(xy)%2==0
    topology=part['polygons'];assert topology and all(len(q)==4 for q in topology)
    q=xy[topology[0]];edges=np.roll(q,-1,axis=0)-q
    next_edges=np.roll(edges,-1,axis=0)
    turn=edges[:,0]*next_edges[:,1]-edges[:,1]*next_edges[:,0]
    assert (turn>0).all() or (turn<0).all(), 'neck quad is not strictly convex'
    yy,xx=np.mgrid[0:720,0:1280];points=np.stack([xx+.5,yy+.5],-1)
    signed=np.stack([e[0]*(points[...,1]-a[1])-e[1]*(points[...,0]-a[0]) for a,e in zip(q,edges)],-1)/np.linalg.norm(edges,axis=1)
    mask=(signed>1).all(-1)|(signed<-1).all(-1)
    for indices in topology[1:]:
        other=xy[indices];lo=other.min(0)-1;hi=other.max(0)+1
        mask &= ~((points[...,0]>=lo[0])&(points[...,0]<=hi[0])&(points[...,1]>=lo[1])&(points[...,1]<=hi[1]))
    assert mask.any(), 'no provably single-layer body interior'
    return mask

def body_alpha_check(image,expected,part,reference):
    mask=isolated_body_mask(part) & (reference[...,3]==1.0)
    assert mask.any(), "no opaque source texels in provably single-layer geometry"
    # Existing single-fade test remains exact to one original half format ULP.
    cropped=image[mask].reshape(1,-1,4)
    result=alpha_check(cropped,expected)
    alpha=cropped[...,3].astype(np.float16)
    low=np.nextafter(alpha,np.float16(-np.inf)).astype(float);high=np.nextafter(alpha,np.float16(np.inf)).astype(float)
    assert np.all((low<=expected)&(high>=expected)), "one or more original opaque single-layer texels did not fade exactly once"
    result.update({'geometry_only_single_layer_pixels':int(mask.sum()),'whole_body_max_alpha_retained':float(image[...,3].max()),'selection':'actual convex neck topology interior1px, outside all other actual quad expanded AABBs1px, AND separate same-frame source-alpha1 reference exactly opaque; never selects on faded image alpha'})
    return result


def verify(folder):
    folder = Path(folder)
    receipt = json.loads((folder.parent / "exit.json").read_bytes())
    assert receipt["strict_clean"] and receipt["exit"] == 0 and receipt["source_fixed"] and receipt["c_fixed"]
    assert receipt["c_count"] == 463 and receipt["all_four_queues_clear"] and not receipt["diagnostics"] and not receipt["owned_after"]
    assert (folder.parent / "source-before.json").read_bytes() == (folder.parent / "source-after.json").read_bytes()
    data = json.loads((folder / "death.json").read_bytes())
    assert data["complete"] and not data["failures"] and len(data["records"]) == 3
    assert data["renderer"] == "forward_plus" and "RX9070XT" in data["adapter"].replace(" ", "")
    assert data["health_before_hit"] > 0 and data["health_after_hit"] == 0
    result, previous = [], 2.0
    for index, row in enumerate(data["records"]):
        assert row["stage"] == index and row["before"] == row["after"]
        state = row["before"]
        assert state["enemy_dying"] and state["alive_target"]
        opacity = state["opacity"]
        assert 0 < opacity < previous and state["body_opacity"] == opacity and state["head_local_opacity"] == 1.0
        previous = opacity
        assert len(state["parts"]) == 3 and len(row["images"]) == 4
        images = [full_composite.composite_image(folder, row["images"][0])] + [common.image(folder, entry) for entry in row["images"][1:]]
        assert all(image.shape == (720, 1280, 4) for image in images)
        assert [p["reference_alpha1"] for p in state["parts"]]==[False,False,True]
        assert state["parts"][1]["polygon"]==state["parts"][2]["polygon"] and state["parts"][1]["uv"]==state["parts"][2]["uv"] and state["parts"][1]["source_texture_id"]==state["parts"][2]["source_texture_id"] and state["parts"][1]["source_material_id"]==state["parts"][2]["source_material_id"]
        for part in state["parts"]:
            assert part["source_transform"] == part["copy_transform"]
            expected_modulate = part["source_effective_modulate"].copy()
            if part["reference_alpha1"]: expected_modulate[3]=1.0
            assert expected_modulate == part["copy_modulate"]
            assert part["source_texture_filter"]==part["copy_texture_filter"] and part["source_texture_repeat"]==part["copy_texture_repeat"]
            assert part["self_modulate"] == part["copy_self_modulate"]
            assert part["source_texture_id"] == part["copy_texture_id"] and part["source_material_id"] == part["copy_material_id"]
            assert part["copy_has_script"] is False
        result.append({"stage": index, "head": alpha_check(images[1], opacity), "body": body_alpha_check(images[2], opacity, state["parts"][1], images[3])})
    assert data["records"][0]["before"]["opacity"] >= .999
    assert .4 <= data["records"][1]["before"]["opacity"] <= .6
    assert 0 < data["records"][2]["before"]["opacity"] <= .15
    return {"passed": True, "natural_tween_samples": 3, "actual_originals": 12, "parts": result, "whole_scene_alpha": "actual glow/death FX additive composite; never used as coverage. Both isolated part images still0..1. Head original maximum and geometry-only nonoverlapped neck maximum obey original one-ULP single-fade gate; overlapped body alpha retained as raw", "scope": "natural Enemy FSM, actual Hurtbox damage and single opacity on original head/body drawables"}


def self_test():
    image = np.zeros((8, 8, 4))
    image[2:6, 2:6, 3] = .5
    alpha_check(image, .5)
    checks = 1
    for candidate in [np.zeros_like(image), image * .5]:
        try:
            alpha_check(candidate, .5)
        except AssertionError:
            checks += 1
        else:
            raise AssertionError("empty/double-fade negative was accepted")
    return {"checks": checks, "failures": 0, "native_runs": 0}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", nargs="?")
    parser.add_argument("--out", required=True)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    value = self_test() if args.self_test else verify(args.folder)
    Path(args.out).write_bytes((json.dumps(value, indent=2) + "\n").encode())
    print(json.dumps(value, indent=2))
