extends "res://work/ne295-cause-v1/capture.gd"
## Natural FSM -> actual Hurtbox lethal hit -> unstepped original death Tween.

var _death_view: SubViewport
var _death_stage: Node2D
var _enemy: Enemy
var _player: Player
var _copy_views: Array[Dictionary] = []
var _death_rows: Array[Dictionary] = []
var _pending_images: Array[Array] = []
var _pre_witness: Dictionary = {}
var _started := false
var _capture_stage := 0
var _kill_before := 0
var _kill_after := 0


func _run() -> void:
	var valid: bool = _require(_out.is_absolute_path() and DisplayServer.get_name() != "headless", "death observer requires native absolute output")
	if valid:
		DirAccess.make_dir_recursive_absolute(_out)
		get_window().mode = Window.MODE_WINDOWED
		get_window().size = SIZE
		Settings.use_storage("user://ne295-death-settings.cfg")
		get_viewport().set_disable_input(true)
		Settings.set_light_quality(LightQuality.Tier.HIGH)
		_death_view = _death_subview()
		_death_stage = Node2D.new()
		_death_view.add_child(_death_stage)
		Fx.bind_container(_death_stage)
		var ambient := CanvasModulate.new()
		ambient.color = Color(0.25, 0.25, 0.25)
		_death_view.add_child(ambient)
		_death_view.add_child(LightKit.create_environment())
		var floor := StaticBody2D.new()
		floor.collision_layer = Layers.WORLD
		floor.position = Vector2(320, 325)
		var shape := CollisionShape2D.new()
		var rectangle := RectangleShape2D.new()
		rectangle.size = Vector2(640, 50)
		shape.shape = rectangle
		floor.add_child(shape)
		_death_stage.add_child(floor)
		_player = Player.new()
		_player.configure(load("res://data/player/player_tuning.tres") as PlayerTuning, 6, {})
		_player.position = Vector2(340, 300)
		_death_stage.add_child(_player)
		_hold(_player)
		_player.hide() # Only a live, static target; not a player/UI visibility acceptance.
		var data := load("res://data/enemies/cloud_serpent.tres") as EnemyData
		_enemy = data.behavior.new() as Enemy
		_enemy.configure(data)
		_enemy.position = Vector2(320, 316)
		Enemy.activation_culling_enabled = false
		_death_stage.add_child(_enemy)
		RenderingServer.frame_pre_draw.connect(_before_death_draw)
		RenderingServer.frame_post_draw.connect(_after_death_draw)
		var deadline := Time.get_ticks_msec() + 8000
		while Time.get_ticks_msec() < deadline and _capture_stage < 3:
			await get_tree().process_frame
			if not _started and is_instance_valid(_enemy) and _enemy.fsm.is_in(&"erupt") and _enemy.hurtbox.enabled:
				# Follow the existing permanent test's actual damage path, never set HP/FSM.
				var info := DamageInfo.new()
				info.amount = _enemy.health.current
				info.team = Combat.Team.PLAYER
				info.source_id = &"ne295_arranged_hit"
				info.origin = _player.global_position
				info.impact = 0.0
				_kill_before = _enemy.health.current
				_enemy.hurtbox.receive(info)
				_kill_after = _enemy.health.current
				_started = _enemy.is_dying()
				if _started: _prepare_death_copies()
		valid = _require(_started and _kill_before > 0 and _kill_after == 0 and _capture_stage == 3, "natural death did not yield initial/mid/late native draws")
		RenderingServer.frame_pre_draw.disconnect(_before_death_draw)
		RenderingServer.frame_post_draw.disconnect(_after_death_draw)
		for index in _death_rows.size():
			var files: Array = []
			for image_index in 4:
				files.append(_save_image("death/" + str(index) + "-" + ["scene", "head", "body", "body-source-alpha1"][image_index], _pending_images[index][image_index]))
			_death_rows[index]["images"] = files
	_write_json("death.json", {"schema": "ne295-death-v2", "scope": "arranged live target/spawn; natural Enemy FSM, actual Hurtbox hit and original Tween plus separate same-geometry source-alpha1 body reference; no live process/FSM/HP/phase stepping",
		"adapter": RenderingServer.get_video_adapter_name(), "renderer": RenderingServer.get_current_rendering_method(),
		"health_before_hit": _kill_before, "health_after_hit": _kill_after,
		"records": _death_rows, "failures": _failures, "complete": valid and _death_rows.size() == 3})
	_pending_images.clear()
	_copy_views.clear()
	_enemy = null
	_player = null
	if _death_view != null: _death_view.queue_free()
	for child in get_children():
		if child is SubViewport: child.queue_free()
	await _settle(4)
	RigDebris.clear_pool()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if valid and _failures.is_empty() else 2)


func _death_subview() -> SubViewport:
	var view := SubViewport.new()
	view.size = SIZE
	view.world_2d = World2D.new()
	view.world_3d = World3D.new()
	view.transparent_bg = true
	view.use_hdr_2d = true
	view.disable_3d = true
	view.msaa_2d = get_viewport().msaa_2d
	view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(view)
	view.canvas_transform = Transform2D(0.0, Vector2(2, 2), 0.0, Vector2.ZERO)
	return view


func _prepare_death_copies() -> void:
	var worm := _enemy.get("worm") as WormCreature
	for index in 3:
		var source: Node2D = worm._head if index == 0 else worm._mesh
		var view := _death_subview()
		var copy := source.duplicate(0) as Node2D
		for child in copy.get_children():
			copy.remove_child(child)
			child.free()
		view.add_child(copy)
		_copy_views.append({"source": source, "copy": copy, "view": view, "reference_alpha1": index == 2})


func _before_death_draw() -> void:
	_pre_witness = {}
	if not _started or not is_instance_valid(_enemy) or _capture_stage >= 3: return
	var worm := _enemy.get("worm") as WormCreature
	if worm == null: return
	for item in _copy_views:
		var source := item.source as Node2D
		var copy := item.copy as Node2D
		copy.global_transform = source.global_transform
		copy.modulate = _effective_modulate(source)
		if bool(item.reference_alpha1): copy.modulate.a = 1.0
		copy.self_modulate = source.self_modulate
		if source is Polygon2D:
			(copy as Polygon2D).polygon = source.polygon
			(copy as Polygon2D).uv = source.uv
			(copy as Polygon2D).polygons = source.polygons
	_pre_witness = _death_witness()


func _after_death_draw() -> void:
	if _pre_witness.is_empty() or not is_instance_valid(_enemy): return
	var alpha: float = _pre_witness.opacity
	var wanted: bool = alpha >= 0.999 if _capture_stage == 0 else (alpha >= 0.4 and alpha <= 0.6 if _capture_stage == 1 else alpha > 0.0 and alpha <= 0.15)
	if not wanted: return
	var after := _death_witness()
	var images: Array = [_death_view.get_texture().get_image()]
	for item in _copy_views: images.append((item.view as SubViewport).get_texture().get_image())
	if not _require(_pre_witness == after, "death source changed between same-frame pre/post draw"): return
	for image: Image in images:
		if not _require(image.get_size() == SIZE and image.get_format() == Image.FORMAT_RGBAH, "death original must be1280 RGBAH"): return
	_pending_images.append(images)
	_death_rows.append({"stage": _capture_stage, "draw": Engine.get_frames_drawn(), "before": _pre_witness, "after": after})
	_capture_stage += 1


func _death_witness() -> Dictionary:
	var worm := _enemy.get("worm") as WormCreature
	var parts: Array = []
	for item in _copy_views:
		var source := item.source as Node2D
		var copy := item.copy as Node2D
		parts.append({"reference_alpha1": bool(item.reference_alpha1), "view_canvas": Held.transform_values((item.view as SubViewport).canvas_transform), "view_size": [ (item.view as SubViewport).size.x, (item.view as SubViewport).size.y ], "view_msaa": (item.view as SubViewport).msaa_2d, "source_view_msaa": _death_view.msaa_2d,
			"uv": _vectors((source as Polygon2D).uv) if source is Polygon2D else [], "copy_uv": _vectors((copy as Polygon2D).uv) if copy is Polygon2D else [], "polygons": _death_topology(source), "copy_polygons": _death_topology(copy),
			"source_texture_filter": source.texture_filter, "copy_texture_filter": copy.texture_filter, "source_texture_repeat": source.texture_repeat, "copy_texture_repeat": copy.texture_repeat, "source_transform": Held.transform_values(source.global_transform), "copy_transform": Held.transform_values(copy.global_transform),
			"source_effective_modulate": _color(_effective_modulate(source)), "copy_modulate": _color(copy.modulate),
			"self_modulate": _color(source.self_modulate), "copy_self_modulate": _color(copy.self_modulate),
			"source_texture_id": source.get("texture").get_instance_id(), "copy_texture_id": copy.get("texture").get_instance_id(),
			"source_material_id": source.material.get_instance_id() if source.material != null else null,
			"copy_material_id": copy.material.get_instance_id() if copy.material != null else null,
			"polygon": _vectors((source as Polygon2D).polygon) if source is Polygon2D else [], "copy_has_script": copy.get_script() != null})
	return {"opacity": worm.modulate.a, "body_opacity": worm._mesh.modulate.a, "head_local_opacity": worm._head.modulate.a,
		"alive_target": _player.health.current > 0, "enemy_dying": _enemy.is_dying(), "parts": parts}


func _death_topology(item: Node2D) -> Array:
	var result: Array = []
	if item is Polygon2D:
		for indices in (item as Polygon2D).polygons: result.append(Array(indices))
	return result
