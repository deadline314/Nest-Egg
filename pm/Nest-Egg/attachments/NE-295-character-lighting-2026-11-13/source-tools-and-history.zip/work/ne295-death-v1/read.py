"""Actual natural death alpha witnesses; no whole-scene rectangle denominator."""
import argparse
import importlib.util
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("common", HERE.parent / "ne295-cause-v1/read.py")
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)


def alpha_check(image, expected):
    assert image.shape[-1] == 4 and np.isfinite(image).all()
    alpha = image[..., 3]
    assert np.any(alpha > 0), "empty actual part alpha"
    observed = np.float16(alpha.max())
    low = float(np.nextafter(observed, np.float16(-np.inf)))
    high = float(np.nextafter(observed, np.float16(np.inf)))
    assert low <= expected <= high, "part fade does not contain its original scalar within one format ULP"
    return {"nonempty_pixels": int((alpha > 0).sum()), "maximum_alpha": float(observed), "expected_single_alpha": expected}


def verify(folder):
    folder = Path(folder)
    receipt = json.loads((folder.parent / "exit.json").read_bytes())
    assert receipt["strict_clean"] and receipt["exit"] == 0 and receipt["source_fixed"] and receipt["c_fixed"]
    assert receipt["c_count"] == 463 and receipt["all_four_queues_clear"] and not receipt["diagnostics"] and not receipt["owned_after"]
    assert (folder.parent / "source-before.json").read_bytes() == (folder.parent / "source-after.json").read_bytes()
    data = json.loads((folder / "death.json").read_bytes())
    assert data["complete"] and not data["failures"] and len(data["records"]) == 3
    assert data["renderer"] == "forward_plus" and "RX9070XT" in data["adapter"].replace(" ", "")
    assert data["health_before_hit"] > 0 and data["health_after_hit"] == 0
    result, previous = [], 2.0
    for index, row in enumerate(data["records"]):
        assert row["stage"] == index and row["before"] == row["after"]
        state = row["before"]
        assert state["enemy_dying"] and state["alive_target"]
        opacity = state["opacity"]
        assert 0 < opacity < previous and state["body_opacity"] == opacity and state["head_local_opacity"] == 1.0
        previous = opacity
        assert len(state["parts"]) == 2 and len(row["images"]) == 3
        images = [common.image(folder, entry) for entry in row["images"]]
        assert all(image.shape == (720, 1280, 4) for image in images)
        for part in state["parts"]:
            assert part["source_transform"] == part["copy_transform"]
            assert part["source_effective_modulate"] == part["copy_modulate"]
            assert part["self_modulate"] == part["copy_self_modulate"]
            assert part["source_texture_id"] == part["copy_texture_id"] and part["source_material_id"] == part["copy_material_id"]
            assert part["copy_has_script"] is False
        result.append({"stage": index, "head": alpha_check(images[1], opacity), "body": alpha_check(images[2], opacity)})
    assert data["records"][0]["before"]["opacity"] >= .999
    assert .4 <= data["records"][1]["before"]["opacity"] <= .6
    assert 0 < data["records"][2]["before"]["opacity"] <= .15
    return {"passed": True, "natural_tween_samples": 3, "actual_originals": 9, "parts": result, "scope": "natural Enemy FSM, actual Hurtbox damage and single opacity on original head/body drawables"}


def self_test():
    image = np.zeros((8, 8, 4))
    image[2:6, 2:6, 3] = .5
    alpha_check(image, .5)
    checks = 1
    for candidate in [np.zeros_like(image), image * .5]:
        try:
            alpha_check(candidate, .5)
        except AssertionError:
            checks += 1
        else:
            raise AssertionError("empty/double-fade negative was accepted")
    return {"checks": checks, "failures": 0, "native_runs": 0}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", nargs="?")
    parser.add_argument("--out", required=True)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    value = self_test() if args.self_test else verify(args.folder)
    Path(args.out).write_bytes((json.dumps(value, indent=2) + "\n").encode())
    print(json.dumps(value, indent=2))
