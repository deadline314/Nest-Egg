extends Node

const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://localized-av-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Settings.set_reduce_flashes(false)
	Settings.set_volume(&"Master", 0.0)
	Story.set_language("en")
	var menu := MainMenu.new()
	add_child(menu)
	await _frames(5)
	menu._open_settings()
	await _frames(6)
	var screen := menu._ui.get_child(menu._ui.get_child_count() - 1) as SettingsScreen
	_check(screen != null and screen._tabs.current_tab == 0, "the real title settings overlay opens on Audio")
	if screen == null:
		menu.queue_free()
		await _finish()
		return
	_check(_has_text(screen._tabs.get_current_tab_control(), "Master") and _has_text(screen._tabs.get_current_tab_control(), "Sound effects")
			and screen._slider_values[&"Master"].text == "Muted", "audio names and the actual muted value are English")
	var slide: HSlider = screen._sliders[&"Master"]
	_check(slide.has_focus() and slide.tooltip_text == "Overall volume.", "the first Audio slider has the localized help")
	await _picture("audio-en.png")
	await _key(KEY_RIGHT)
	_check(absf(Settings.get_volume(&"Master") - 0.05) < 0.001 and screen._slider_values[&"Master"].text == "5%",
			"normal keyboard adjustment changes the actual audio setting")
	var reset := _button(screen, "Reset defaults")
	if reset != null:
		reset.grab_focus()
		await _key(KEY_ENTER)
	_check(reset != null and absf(Settings.get_volume(&"Master") - 0.8) < 0.001
			and screen._status.text == "Audio restored to defaults.", "reset changes the audio values and confirms in English")
	await _joy(JOY_BUTTON_RIGHT_SHOULDER)
	await _joy(JOY_BUTTON_RIGHT_SHOULDER)
	_check(screen._tabs.current_tab == 2 and screen._fullscreen.has_focus(), "two actual page inputs open Display with its first control focused")
	_check(screen._fullscreen.text == "Fullscreen" and screen._hud_auto_hide.text == "Auto-hide HUD"
			and screen._reduce_flashes.text == "Reduce flashes" and _has_text(screen._tabs.get_current_tab_control(), "Story language"),
			"English display labels cover accessibility, language and HUD")
	var option := screen._quality_option
	var lower := option.get_item_index(LightQuality.Tier.LOW)
	_check(lower >= 0 and option.get_item_text(lower) == "Low"
			and option.get_item_tooltip(lower).contains("normal maps"), "low quality shows its translated tradeoff using the original tier ID")
	option.select(lower)
	option.item_selected.emit(lower)
	screen._reduce_flashes.grab_focus()
	await _frames(4)
	_check(screen._status.text == screen._reduce_flashes.tooltip_text and screen._status.text.begins_with("Dim hit"),
			"display focus uses the same localized description as Hover")
	await _key(KEY_ENTER)
	_check(Settings.get_reduce_flashes() and Settings.get_light_quality() == LightQuality.Tier.LOW,
			"the actual toggle and quality selection reach their original settings")
	await _picture("display-en.png")
	screen.close()
	await _frames(7)
	Story.set_language("ja")
	menu._open_settings()
	await _frames(5)
	screen = menu._ui.get_child(menu._ui.get_child_count() - 1) as SettingsScreen
	_check(screen != null and screen._sliders[&"Master"].tooltip_text.begins_with("すべて"), "Japanese Audio opens with Japanese guidance")
	if screen != null:
		await _joy(JOY_BUTTON_RIGHT_SHOULDER)
		await _joy(JOY_BUTTON_RIGHT_SHOULDER)
		_check(screen._fullscreen.text == "フルスクリーン" and screen._reduce_flashes.text == "閃光を減らす"
				and screen._story_language_option.tooltip_text == "再起動後に反映されます。",
				"Japanese Display and language preference use their own locale")
		_check(screen._text_scale_option.get_item_id(1) == 120 and screen._text_scale_option.get_item_text(1) == "拡大（120%）",
				"the localized text size still points to the original scale")
		await _picture("display-ja.png")
		screen.close()
	menu.queue_free()
	await _finish()


func _button(node: Node, caption: String) -> Button:
	for child in node.find_children("*", "Button", true, false):
		if (child as Button).text == caption:
			return child as Button
	return null


func _has_text(node: Node, caption: String) -> bool:
	if node is Label and (node as Label).text == caption:
		return true
	for child in node.get_children():
		if _has_text(child, caption):
			return true
	return false


func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _tap(event)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	await _tap(event)


func _tap(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish() -> void:
	await _frames(7)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))
