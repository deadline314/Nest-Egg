from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json

base = Path(__file__).resolve().parent
source = base.parent/'ne218-baseline-20261117'
target = base/'bench-project'
catalog = base/'fixture.json'
fixture = json.loads(catalog.read_bytes())
inputs = [*(source/'audio').rglob('*'),source/'icon.png',source/'icon.png.import']
copied = {}
for file in inputs:
    if not file.is_file():
        continue
    name = file.relative_to(source).as_posix()
    if name in fixture['runtime'] or name in fixture['assets']:
        continue
    destination = target/name
    assert not destination.exists(), name
    destination.parent.mkdir(parents=True,exist_ok=True)
    copyfile(file,destination)
    value = sha256(file.read_bytes()).hexdigest()
    assert value == sha256(destination.read_bytes()).hexdigest(), name
    copied[name] = value
assert 'icon.png' in copied and 'audio/music/calm_transfer.ogg.import' in copied
fixture['assets'].update(copied)
catalog.write_text(json.dumps(fixture,indent=2)+'\n',encoding='utf-8')
print(len(copied),'additional editor runtime files',flush=True)
