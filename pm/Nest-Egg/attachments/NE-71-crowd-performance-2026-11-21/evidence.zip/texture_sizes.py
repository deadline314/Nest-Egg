from pathlib import Path
import json
import struct

base = Path(__file__).resolve().parent
older = base/'asset-import/art/characters/ne71_before_rin'
newer = base/'bench-project/art/characters/rin'

def textures(root):
    files = {}
    for file in sorted(root.rglob('*.png')):
        raw = file.read_bytes()
        assert raw.startswith(b'\x89PNG\r\n\x1a\n'), file
        width,height = struct.unpack('>II',raw[16:24])
        files[file.relative_to(root).as_posix()] = {'width':width,'height':height,'disk_bytes':len(raw)}
    return {'files':files,'count':len(files),'disk_bytes':sum(x['disk_bytes'] for x in files.values()),
            'texels':sum(x['width']*x['height'] for x in files.values())}

result = {'historical':textures(older),'current':textures(newer)}
(base/'texture-sizes.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print({k:{x:y for x,y in v.items() if x!='files'} for k,v in result.items()},flush=True)
