from pathlib import Path
from statistics import mean
import json

base = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_bytes())
order = [(1,'old'),(2,'current'),(3,'current'),(4,'old')]
runs = {f'{index}-{variant}':read(base/f'measure-{index}-{variant}/report.json') for index,variant in order}
fields = ('fps','median_frame_ms','p99_ms','draw_calls','texture_bytes','video_bytes','engine_process_ms','engine_physics_ms')
results = {}
for lighting in ('transfer','blackout','market'):
    group = {'old':[],'current':[]}
    for key,run in runs.items():
        sample = run['profiles'][lighting]
        condition = key.split('-',1)[1]
        assert sample['visible_minimum']==11 and sample['player_visible'] and sample['projectiles_peak']>0
        assert sample['rin']==('ne71_before_rin' if condition=='old' else 'rin')
        assert sample['frames'] > 100 and sample['median_frame_ms'] > 0.0
        group[condition].append(sample)
    avg = {version:{stat:mean(row[stat] for row in rows) for stat in fields} for version,rows in group.items()}
    change = {k:avg['current'][k]/avg['old'][k]-1.0 for k in ('fps','median_frame_ms','p99_ms')}
    verified = change['fps'] >= -0.10 and change['median_frame_ms'] <= 0.10 and change['p99_ms'] <= 0.15
    totals = sum(row['frames'] for rows in group.values() for row in rows)
    results[lighting] = {'average':avg,'relative_change':change,'frames':totals,'passed':verified}
result = {'samples':sum(x['frames'] for x in results.values()),'profiles':results,
          'passed':all(item['passed'] for item in results.values())}
(base/'comparison.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2),flush=True)
