from hashlib import md5, sha256
from pathlib import Path
import json
import re
import subprocess
import tarfile

base = Path(__file__).resolve().parent
mini = base/'asset-import'
mini.mkdir()
(mini/'project.godot').write_text('config_version=5\n[application]\nconfig/name="Original Rin asset import"\n',encoding='utf-8')
revision = '705a9c640fb5cdd115a9ce67cd1fd4bb02d60262'
alias = 'ne71_before_rin'
rig_path = 'art/rigs/humanoid_tall.json'
motion_path = 'art/motion/rin.json'
skin_prefix = 'art/characters/rin/'
original = base/'original-art.tar'
subprocess.run(['git','archive','--format=tar','--output='+str(original),revision,rig_path,motion_path,skin_prefix.rstrip('/')],check=True)
records = {}
with tarfile.open(original,'r') as archive:
    for member in archive:
        if not member.isfile():
            continue
        old = member.name
        if old == rig_path:
            dest = f'art/rigs/{alias}.json'
        elif old == motion_path:
            dest = f'art/motion/{alias}.json'
        else:
            assert old.startswith(skin_prefix), old
            dest = f'art/characters/{alias}/'+old.removeprefix(skin_prefix)
        if not dest.endswith(('.png','.png.import','.json')):
            continue
        source = archive.extractfile(member).read()
        rewritten = source
        if dest.endswith('/character.json'):
            skin = json.loads(source)
            assert skin['id']=='rin' and skin['rig']=='res://'+rig_path
            skin['id'] = alias
            skin['rig'] = f'res://art/rigs/{alias}.json'
            rewritten = (json.dumps(skin,ensure_ascii=False,indent=2)+'\n').encode()
        elif dest.endswith('.png.import'):
            old_resource = 'res://'+old.removesuffix('.import')
            new_resource = 'res://'+dest.removesuffix('.import')
            old_digest = md5(old_resource.encode()).hexdigest()
            new_digest = md5(new_resource.encode()).hexdigest()
            ini = source.decode()
            assert old_digest in ini, old
            rewritten = re.sub(r'^uid=.*\n','',ini,flags=re.M).replace(old_resource,new_resource).replace(old_digest,new_digest).encode()
        target = mini/dest
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(rewritten)
        records[old] = {'source_sha256':sha256(source).hexdigest(),'installed_sha256':sha256(rewritten).hexdigest(),'path':dest}
(base/'original-assets.json').write_text(json.dumps({'revision':revision,'original':records},indent=2)+'\n',encoding='utf-8')
print(revision,len(records),'historical assets')
