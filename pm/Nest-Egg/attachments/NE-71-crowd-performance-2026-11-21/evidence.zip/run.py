from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
root = Path.cwd()
target = base/'bench-project'
fixture = json.loads((base/'fixture.json').read_bytes())
settings = 'rehearsal' in sys.argv[1:]
manifest = fixture['runtime'] | fixture['assets']
sha = lambda file: sha256(file.read_bytes()).hexdigest()
assert all(sha(target/path)==digest for path,digest in manifest.items())
visual = target/'game/player/player_visual.gd'
normal = visual.read_bytes()
key = b'const SKIN_ID := "rin"'
assert normal.count(key) == 1
old_skin = normal.replace(key,b'const SKIN_ID := "ne71_before_rin"',1)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
order = [(1,'old'),(2,'current')] if settings else [(1,'old'),(2,'current'),(3,'current'),(4,'old')]
for order_number,variant in order:
    name = f"{'rehearsal-clean' if settings else 'measure'}-{order_number}-{variant}"
    run = base/name
    run.mkdir()
    env = os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','TEMP','TMP','TMPDIR','XDG_CONFIG_HOME','XDG_DATA_HOME'):
        (run/key).mkdir()
        env[key] = str(run/key)
    command = [sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',engine,
               '--path',str(target),'--rendering-method','forward_plus','--rendering-driver','vulkan',
               '--audio-driver','Dummy','--resolution','1280x720',str(base/'probe.tscn'),'--',f'--out={run}']
    if variant=='old':
        command.append('--historical')
    if settings:
        command.append('--rehearsal')
    try:
        if variant=='old':
            visual.write_bytes(old_skin)
        (run/'command.json').write_text(json.dumps({'argv':command,'commit':fixture['commit'],'visual_sha256':sha(visual)},indent=2)+'\n',encoding='utf-8')
        with (run/'raw.log').open('wb') as log:
            outcome = subprocess.run(command,cwd=target,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
        raw = (run/'raw.log').read_text(encoding='utf-8',errors='replace')
        assert outcome.returncode==0 and not re.search(r'^(?:SCRIPT )?ERROR:|^FAIL ',raw,re.M), raw[-4500:]
        data = json.loads((run/'report.json').read_bytes())
        assert data['failures']==0 and 'RX 9070 XT' in data['adapter'] and data['window']==[1280,720] and data['vsync']==0
        assert set(data['profiles']) == ({'transfer'} if settings else {'transfer','blackout','market'})
        for report in data['profiles'].values():
            assert report['visible_minimum']==11 and report['player_visible'] and report['projectiles_peak']>0
        print(name,{key: round(value['fps'],2) for key,value in data['profiles'].items()},flush=True)
    finally:
        if variant=='old':
            assert sha(visual)==sha256(old_skin).hexdigest()
            visual.write_bytes(normal)
    assert all(sha(target/path)==digest for path,digest in manifest.items())
