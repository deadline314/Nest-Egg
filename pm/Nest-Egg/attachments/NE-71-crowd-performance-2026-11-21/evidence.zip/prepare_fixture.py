from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import os
import subprocess

base = Path(__file__).resolve().parent
root = Path.cwd()
upstream = base.parent/'evidence-20261121-ne71-turn-shot'
source = base.parent/'ne218-baseline-20261117'
target = base/'bench-project'
mini = base/'asset-import'
manifest = json.loads((upstream/'published-source.json').read_bytes())
receipt = json.loads((upstream/'publish/result.json').read_bytes())
expected = receipt['commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip() == expected
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == expected
sha = lambda file: sha256(file.read_bytes()).hexdigest()
assert all(sha(source/path)==digest for path,digest in manifest.items())
target.mkdir()
for same in manifest:
    output = target/same
    output.parent.mkdir(parents=True,exist_ok=True)
    copyfile(source/same,output)
assert all(sha(target/path)==digest for path,digest in manifest.items())
(target/'.godot').mkdir(exist_ok=True)
for name in ('.gdignore','global_script_class_cache.cfg','uid_cache.bin','extension_list.cfg'):
    old = source/'.godot'/name
    if old.is_file():
        copyfile(old,target/'.godot'/name)
copytree(source/'.godot/imported',target/'.godot/imported')

profile = base/'import-profile'
env = os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','TEMP','TMP','TMPDIR','XDG_CONFIG_HOME','XDG_DATA_HOME'):
    (profile/key).mkdir(parents=True)
    env[key] = str(profile/key)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
command = [engine,'--headless','--path',str(mini),'--editor','--import']
with (base/'import.log').open('wb') as log:
    result = subprocess.run(command,cwd=mini,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=75)
assert result.returncode == 0 and 'ERROR:' not in (base/'import.log').read_text(encoding='utf-8',errors='replace')

assets = {}
for file in [*(mini/'art').rglob('*'),*(mini/'.godot/imported').glob('*')]:
    if not file.is_file():
        continue
    relative = file.relative_to(mini)
    destination = target/relative
    assert not destination.exists(),relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    copyfile(file,destination)
    assets[relative.as_posix()] = sha(destination)
assert len(assets) >= 117
(base/'fixture.json').write_text(json.dumps({'commit':expected,'assets':assets,'runtime':manifest},indent=2)+'\n',encoding='utf-8')
print(expected,len(manifest),len(assets),flush=True)
