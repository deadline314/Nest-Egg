extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const PLAZA := "res://data/levels/ch3_plaza.tres"
const PUMP := "res://data/levels/ch3_pump.tres"
const LADDER := &"plaza_ladder"

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://portal-language-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	await _exercise("en", "Take the outside ladder to the pump room bridge",
			"Restore freight lift power to lower the outside ladder from here.", false)
	await _exercise("ja", "外はしごでポンプ室の上の橋へ",
			"貨物リフトの電源を戻せば、ここから外はしごを下ろせる。", true)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(1 if _fails else 0)


func _exercise(language: String, action: String, reason: String, pad: bool) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	var data := load(PLAZA) as LevelData
	Story._seen[data.intro_scene] = true
	for scene: String in data.story_triggers:
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(data)
	add_child(level)
	await _frames(215)
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		enemy.set_physics_process(false)
	var door := level._portals.get(LADDER) as Portal
	_check(is_instance_valid(door) and not door.is_open() and door.data.target_level == PUMP,
			"the original outer ladder waits for the original condition")
	if not is_instance_valid(door):
		level.queue_free()
		await _frames(8)
		return
	var player := level.player
	player.global_position = door.global_position + Vector2(-3, -1)
	player.velocity = Vector2.ZERO
	InputBindings._set_device(false, -1)
	if pad:
		await _tap(_joy(JOY_BUTTON_RIGHT_SHOULDER))
	for frame in 125:
		if door._prompt.is_showing() and door._prompt._alpha >= 0.8:
			break
		await _frames(1)
	var shown := door._prompt._display_text
	print("PROMPT ", language, " ", shown, " visible=", door._prompt.is_showing(),
			" alpha=", door._prompt._alpha, " range=", door.interaction_available())
	_check(door._prompt.is_showing() and door._prompt._alpha >= 0.8
			and shown == InputBindings.primary_label(&"interact") + " " + action,
			language + " uses the actual active key and original ladder action")
	await _picture("ladder-" + language + ".png")

	var requests := PackedStringArray()
	var on_area := func(path: String) -> void: requests.append(path)
	level.area_requested.connect(on_area)
	await _interact(pad)
	await _frames(15)
	var banner := level.hud.toast_banner
	print("LOCK ", language, " ", banner._label.text, " visible=", banner.is_showing(),
			" size=", banner.size, " pos=", banner.position)
	_check(requests.is_empty() and banner.is_showing() and banner._label.text == reason,
			language + " denies the actual key and names the unlock condition")
	_check(banner.is_showing() and banner.get_global_rect().position.x >= 6.0
			and banner.get_global_rect().end.x <= 634.0, language + " keeps the lock message within the screen at 120%")
	var maps := level.hud.quest_guidance.maps
	var marker: Dictionary
	for edge in maps.edges(PLAZA):
		if edge["resource"].id == LADDER:
			marker = edge
			break
	_check(not marker.is_empty() and maps.marker_text(marker, GameState.world_flags, language) == reason,
			language + " map help names the same actual lock condition")
	await _picture("locked-" + language + ".png")

	GameState.set_flag(door.data.requires_flag, true, false)
	_check(door.is_open(), "the original flag opens the ladder")
	await _interact(pad)
	await _frames(8)
	_check(requests == PackedStringArray([PUMP]) and GameState.pending_portal == door.data.target_portal,
			language + " the same key requests the original map and entry portal")
	level.queue_free()
	InputBindings.clear_held_inputs()
	await _frames(8)


func _interact(pad: bool) -> void:
	if pad:
		await _tap(_joy(InputBindings.get_joy_button(&"interact") as JoyButton))
	else:
		var key := InputEventKey.new()
		key.keycode = KEY_E
		key.physical_keycode = KEY_E
		await _tap(key)


func _joy(button: JoyButton) -> InputEventJoypadButton:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	return event


func _tap(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	if not ok:
		printerr("FAIL: ", message)
