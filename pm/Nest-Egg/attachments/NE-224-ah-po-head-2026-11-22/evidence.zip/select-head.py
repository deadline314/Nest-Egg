from collections import Counter
from pathlib import Path
from hashlib import sha256
from PIL import Image
import json
import numpy as np

base=Path(__file__).resolve().parent
modes=("whole","dressed","isolated")
read=lambda p:json.loads(p.read_bytes())
key=lambda row:(row["pose"],row["joint"],row["frame"],row["facing"],row["zoom"])
parts=Path.cwd()/"art/characters/ah_po/parts"
rgba=lambda path:np.asarray(Image.open(path).convert("RGBA"))
sha=lambda p:sha256(p.read_bytes()).hexdigest()

def flags(folder):
    log=(folder/"raw.log").read_text(encoding="utf-8-sig")
    assert "RX 9070 XT" in log and "Forward+" in log and "ERROR:" not in log
    data=read(folder/"report.json")
    assert data["samples"]==33600 and all(row["char"]=="ah_po" for row in data["failures"])
    return {key(row):row for row in data["failures"]}

def real(rows):
    return {key for key,row in rows.items() if row["enclosed_pixels"] or row["loose_pieces"] or row["center_alpha"]<128}

original={mode:flags(base/("head-wide-before-"+mode)) for mode in modes}
options={"trial":("ah-po-head-final.png","candidate-normal.png"),
         "low-fringe":("ah-po-head-low-fringe.png","low-fringe-normal.png")}
review={}
for option,(photo,normal) in options.items():
    records={}
    for mode in modes:
        before=original[mode]
        after=flags(base/f"head-wide-{option}-{mode}")
        old_hard,new_hard=real(before),real(after)
        records[mode]={"samples":33600,"before_hard":len(old_hard),"after_hard":len(new_hard),
            "new_hard":sorted(new_hard-old_hard),"before_flags":len(before),"after_flags":len(after),
            "new_edge":sorted(set(after)-set(before)-new_hard),
            "removed_by_joint":dict(Counter(item[0]+"/"+item[1] for item in old_hard-new_hard))}
    review[option]=records
safe=[(option,records) for option,records in review.items() if all(not record["new_hard"] for record in records.values())]
assert safe,review
chosen,records=min(safe,key=lambda value:(value[1]["whole"]["after_hard"],len(value[1]["whole"]["new_edge"])))
photo,normal=options[chosen]
stock,texture=rgba(parts/"head.png"),rgba(base/photo)
norm=rgba(base/normal)
assert stock.shape==texture.shape==norm.shape==(168,195,4)
assert np.array_equal(rgba(parts/"head_n.png"),rgba(base/"baseline-normal.png"))
assert np.array_equal(texture[:,:,3],norm[:,:,3])
assert all(len(record["new_hard"])==0 for record in records.values()) and records["whole"]["after_hard"]<1579
assert not records["whole"]["new_edge"]
document={"chosen":chosen,"diffuse":photo,"normal":normal,"diffuse_sha":sha(base/photo),"normal_sha":sha(base/normal),
          "changed_texels":int(np.count_nonzero(np.any(stock!=texture,axis=2))),"controls":review}
(base/"selected-head.json").write_text(json.dumps(document,indent=2)+"\n",encoding="utf-8")
(base/"head-wide-comparison.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8")
for label,results in review.items():
    print(label,[(mode,count["before_hard"],count["after_hard"],len(count["new_hard"]),len(count["new_edge"])) for mode,count in results.items()])
print("SELECTED",chosen,photo,normal,document["changed_texels"])
