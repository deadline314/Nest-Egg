from pathlib import Path
from hashlib import sha256
from PIL import Image
import json,numpy as np,os,shutil,subprocess,sys

root=Path.cwd()
base=Path(__file__).resolve().parent
shared=base.with_name("ne218-baseline-20261117")
prior=base.with_name("evidence-20261122-ne224-heavy-fall-helmet")
before=json.loads((prior/"published-source.json").read_bytes())
parent=json.loads((prior/"publish/result.json").read_bytes())["commit"]
branch="codex/ne224-ah-po-head-edges"
placeholder="codex/ticket-work-20261120-next"
override="art_src/characters/ah_po/overrides/head.png"
design="design/12-cast-redraw/RIG_QUALITY.md"
part="art/characters/ah_po/parts/"
runtime=[part+"head.png",part+"head_n.png"]
load=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
image=lambda p:np.asarray(Image.open(p).convert("RGBA"))

def git(*args,cwd=root):
    return subprocess.check_output(["git",*args],cwd=cwd).decode("utf-8").strip()

def run(script,args,filename):
    with (base/filename).open("wb") as output:
        subprocess.run([sys.executable,"-X","utf8","-B",script,*args],cwd=root,
                       stdout=output,stderr=subprocess.STDOUT,check=True)

assert git("branch","--show-current")==placeholder
assert parent==git("rev-parse","HEAD")==git("rev-parse","origin/main")==git("rev-parse","HEAD",cwd=shared)
assert not git("status","--porcelain","--untracked-files=no")
assert all(sha(shared/name)==digest for name,digest in before.items())
assert all(sha(root/name)==before[name] for name in runtime)
assert not (root/override).exists()
chosen=load(base/"selected-head.json")
assert chosen["chosen"] in {"trial","low-fringe"}
texture=base/chosen["diffuse"]
normal=base/chosen["normal"]
assert texture.parent==base and normal.parent==base
assert sha(texture)==chosen["diffuse_sha"] and sha(normal)==chosen["normal_sha"]
stock,candidate=image(root/runtime[0]),image(texture)
assert stock.shape==candidate.shape==(168,195,4)
fringe={(49,190),(50,189),(50,190),(51,189),(51,190)}
collar={(row,col) for row in range(138,141) for col in range(74,77)}
mask=np.any(stock!=candidate,axis=2)
changed={tuple(x) for x in np.argwhere(mask)}
assert fringe<=changed and changed<=fringe|collar and np.all(stock[:,:,3][mask]<235)
assert np.array_equal(image(base/"baseline-normal.png"),image(root/runtime[1]))
assert np.array_equal(image(normal)[:,:,3],candidate[:,:,3])
stats=load(base/"head-wide-comparison.json")
assert stats["whole"]["samples"]==stats["dressed"]["samples"]==stats["isolated"]["samples"]==33600
assert stats["whole"]["before_hard"]==1579 and stats["whole"]["after_hard"]<1579 and stats["whole"]["new_hard"]==[]
assert stats["dressed"]["new_hard"]==stats["isolated"]["new_hard"]==[]

git("switch","-c",branch)
git("branch","-d",placeholder)
for path in runtime:
    destination=base/"source-before"/path
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(root/path,destination)
(root/override).parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(texture,root/override)
rebuilt=base/"rebuilt/ah_po"
assert not rebuilt.exists()
spec="tools/comfyui/specs/ah_po_side.json"
run("tools/comfyui/cut_layers.py",["--spec",spec,"--work","art_src/characters/ah_po","--char",str(rebuilt),
                                  "--rig",str(base/"rebuilt-rig.json")],"rebuild.log")
# The recipe applies validated final overrides after the cutter writes its generated parts.
target=rebuilt/"parts/head.png"
assert image(target).shape==candidate.shape and np.array_equal(image(root/override),candidate)
shutil.copyfile(root/override,target)
current=load(root/"art/characters/ah_po/character.json")["textures"]["head"]
new=load(rebuilt/"character.json")["textures"]["head"]
assert all(current[key]==new[key] for key in ("size","pivot","file"))
glow=part+"head_glow.png"
if "glow" in current:
    assert current["glow"]==new["glow"] and np.array_equal(image(root/glow),image(rebuilt/"parts/head_glow.png"))
for name,artifact in zip(runtime,[rebuilt/"parts/head.png",normal]):
    for directory in (root,shared):
        target=directory/name
        temp=target.with_name(target.name+".head-install")
        shutil.copyfile(artifact,temp)
        os.replace(temp,target)
    before[name]=sha(root/name)
assert all(sha(shared/name)==digest for name,digest in before.items())
run("tools/comfyui/check_spec.py",["--recipe","tools/comfyui/recipes/ah_po.json"],"spec.log")
run("tools/comfyui/check_parts.py",["ah_po","--normals"],"parts.log")
assert "0 error(s), 0 warning(s)" in (base/"spec.log").read_text(encoding="utf-8")
assert "OK   ah_po" in (base/"parts.log").read_text(encoding="utf-8")
doc=(root/design).read_text(encoding="utf-8").rstrip()
note="""

### 麵攤阿婆額前髮尾與後衣領

阿婆轉頭時，把額前飄出輪廓的半透明碎點收回，並補合坐著聽話時的後衣領。保留原髮型、臉部、掛點及動作，按相同流程更新法線。
"""
(root/design).write_text(doc+note,encoding="utf-8",newline="\n")
assert set(git("diff","--name-only").splitlines())==set(runtime)|{design}
(base/"baseline.txt").write_text(parent+"\n")
(base/"runtime.json").write_text(json.dumps(runtime)+"\n")
(base/"source.json").write_text(json.dumps(before,indent=2)+"\n")
shutil.copyfile(prior/"verify.py",base/"verify.py")
script=(prior/"publish.py").read_text(encoding="utf-8")
for stock,value in (
    ("codex/ne224-heavy-fall-helmet",branch),
    ("NE224_heavy_fall_helmet_20261122","NE224_ah_po_head_edges_20261122"),
    ("art: close the heavy gunner helmet gap during the fall","art: refine Ah Po hair and collar edges"),
    ("remove the exposed shoulder pixel during the heavy gunner fall","refine detached fringe pixels and the collar on Ah Po"),
):
    assert stock in script
    script=script.replace(stock,value)
(base/"publish.py").write_text(script,encoding="utf-8")
git("diff","--check")
print("FROZEN NOODLE STALL HEAD",parent,len(before),runtime)
