from pathlib import Path
from collections import Counter
import json

base=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_bytes())
selection=read(base/"selected-head.json")
selected=read(base/"head-wide-comparison.json")
assert selected==selection["controls"][selection["chosen"]]

def rows(folder):
    report=read(base/folder/"report.json")
    assert report["samples"]==33600
    return {(r["pose"],r["joint"],r["frame"],r["facing"],r["zoom"]):
            (r["enclosed_pixels"],r["loose_pieces"],r["center_alpha"]) for r in report["failures"]}

def hard(flags):
    return {k for k,v in flags.items() if v[0] or v[1] or v[2]<128}

measurements={}
for mode in ("whole","dressed","isolated"):
    before,probe,installed=map(rows,(f"head-wide-before-{mode}",f"head-wide-{selection['chosen']}-{mode}",f"final-{mode}"))
    old_hard,probe_hard,final_hard=map(hard,(before,probe,installed))
    assert not (set(installed)-set(before))
    assert set(installed)<=set(probe) and all(probe[key]==value for key,value in installed.items())
    assert not (final_hard-old_hard) and not (final_hard-probe_hard)
    extra=sorted(probe_hard-final_hard)
    assert extra==[("sit_talk","neck",119,-1,3.4),("sit_talk","neck",119,1,3.4)]
    measurements[mode]={"samples":33600,"before_hard":len(old_hard),"after_hard":len(final_hard),"new_hard":[],
        "before_flags":len(before),"after_flags":len(installed),"extra_resolved_after_import":extra,
        "removed_by_joint":dict(Counter(key[0]+"/"+key[1] for key in old_hard-final_hard))}
(base/"installed-head-comparison.json").write_text(json.dumps(measurements,indent=2)+"\n",encoding="utf-8")
print("INSTALLED HEAD",[(mode,stat["before_hard"],stat["after_hard"]) for mode,stat in measurements.items()])
