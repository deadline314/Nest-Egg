from collections import Counter
from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
import json,numpy as np

base=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
key=lambda r:(r["pose"],r["joint"],r["frame"],r["facing"],r["zoom"])

def load(folder):
    report=read(folder/"report.json")
    assert report["samples"]==33600
    rows={key(row):row for row in report["failures"]}
    hard={name for name,r in rows.items() if r["enclosed_pixels"] or r["loose_pieces"] or r["center_alpha"]<128}
    return rows,hard

record=read(base/"installed-head-comparison.json")["whole"]
for mode in ("whole",):
    stock=base/"head-wide-before-whole"
    trial=base/"final-whole"
    a,old=load(stock)
    b,new=load(trial)
    removed=old-new
    assert len(old)==record["before_hard"] and len(new)==record["after_hard"]
    assert not new-old
    candidates=[a[k] for k in sorted(removed) if k[3]==1]
    loose=next(r for r in candidates if r["joint"]=="neck" and r["loose_pieces"])
    collar=next(r for r in candidates if r["joint"]=="shoulder_back" and r["enclosed_pixels"])
    picture=Image.new("RGB",(640,684),"#192337")
    draw=ImageDraw.Draw(picture)
    for index,item in enumerate((loose,collar)):
        for col,folder in enumerate((stock,trial)):
            x,y,w,h=item["rect"]
            crop=Image.open(folder/item["file"]).convert("RGBA").crop((x+24,y+12,x+104,y+92))
            if col==0:
                slab=np.array(crop)[:,:,3]>=128
                if item["loose_pieces"]:
                    labels,_=ndimage.label(slab,structure=np.ones((3,3),bool))
                    inside=labels[16:72,12:68]
                    border=set(np.unique(np.concatenate((inside[0,:],inside[-1,:],inside[:,0],inside[:,-1]))))
                    ids=set(np.unique(inside))-border-{0}
                    assert ids
                    point=np.argwhere(np.isin(labels,list(ids)))[0]
                else:
                    holes=ndimage.binary_fill_holes(slab,structure=np.ones((3,3),bool))&~slab
                    assert holes.any()
                    point=np.argwhere(holes)[0]
            matte=Image.new("RGBA",crop.size,"#574b61")
            matte.alpha_composite(crop)
            ox,oy=col*320,index*342
            picture.paste(matte.convert("RGB").resize((320,320),Image.Resampling.NEAREST),(ox,oy+22))
            ly,lx=map(int,point)
            px,py=ox+4*lx+2,oy+4*ly+24
            draw.rectangle((px-11,py-11,px+11,py+11),outline="#ffac62",width=2)
            draw.text((ox+7,oy+5),("FRINGE" if index==0 else "COLLAR")+(" | BEFORE" if col==0 else " | AFTER"),fill="#e4eeff")
    picture.save(base/"ah-po-head-compare.png")

