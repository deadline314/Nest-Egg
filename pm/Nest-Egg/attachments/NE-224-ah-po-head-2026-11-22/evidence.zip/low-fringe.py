from pathlib import Path
from PIL import Image
import numpy as np
base=Path('D:/NestEggVerification/evidence-20261122-ne224-shop-npcs')
source=np.array(Image.open(base/'ah-po-head-final.png'))
for y,x,opacity in ((49,190,33),(50,189,33),(50,190,0),(51,189,15),(51,190,0)):
    source[y,x,3]=opacity
Image.fromarray(source).save(base/'ah-po-head-low-fringe.png')
