from pathlib import Path
from PIL import Image
import numpy as np
base=Path('D:/NestEggVerification/evidence-20261122-ne224-shop-npcs')
stock=np.array(Image.open('art/characters/ah_po/parts/head.png').convert('RGBA'))
collar=np.array(Image.open(base/'head-collar-edge.png'))
fringe=np.array(Image.open(base/'head-fringe-edge.png'))
collar_mask=np.any(collar!=stock,axis=2)
fringe_mask=np.any(fringe!=stock,axis=2)
assert not (collar_mask&fringe_mask).any()
assert np.all(np.max(stock[:,:,3][collar_mask|fringe_mask])<235)
result=stock.copy()
result[collar_mask]=collar[collar_mask]
result[fringe_mask]=fringe[fringe_mask]
print('combined source pixels',int((collar_mask|fringe_mask).sum()))
Image.fromarray(result).save(base/'ah-po-head-final.png')
