from pathlib import Path
from PIL import Image
import numpy as np
base=Path('D:/NestEggVerification/evidence-20261122-ne224-shop-npcs')
stock=np.array(Image.open('art/characters/ah_po/parts/head.png').convert('RGBA'))
combined=np.array(Image.open(base/'head-local-edge.png'))
collar=stock.copy()
collar[138:141,74:77]=combined[138:141,74:77]
assert np.all(collar[:,:,3]>=stock[:,:,3])
Image.fromarray(collar).save(base/'head-collar-edge.png')
fringe=stock.copy()
for y,x,alpha in ((49,190,78),(50,189,102),(50,190,57),(51,189,65),(51,190,24)):
    assert fringe[y,x,3]>alpha
    fringe[y,x,3]=alpha
Image.fromarray(fringe).save(base/'head-fringe-edge.png')
print('changed collar/fringe',np.count_nonzero(np.any(collar!=stock,axis=2)),np.count_nonzero(np.any(fringe!=stock,axis=2)))
