from pathlib import Path
from PIL import Image
import numpy as np
base=Path('D:/NestEggVerification/evidence-20261122-ne224-shop-npcs')
source=np.array(Image.open('art/characters/ah_po/parts/head.png').convert('RGBA'))
stock=source.copy()
for y,opacity in enumerate((190,220,218,186,124),47):
    for x,alpha in ((188,opacity),(187,opacity-23),(186,opacity-48)):
        if alpha>source[y,x,3]:
            source[y,x,:3]=stock[y,189,:3]
            source[y,x,3]=alpha
for y,opacities in {138:(152,194,220),139:(146,184,223),140:(105,146,188)}.items():
    for x,alpha in enumerate(opacities,74):
        if alpha>source[y,x,3]:
            source[y,x,:3]=stock[y,78,:3]
            source[y,x,3]=alpha
assert not np.any(source[:,:,3]<stock[:,:,3])
print('candidate pixels changed',np.count_nonzero(np.any(source!=stock,axis=2)))
Image.fromarray(source).save(base/'head-local-edge.png')
