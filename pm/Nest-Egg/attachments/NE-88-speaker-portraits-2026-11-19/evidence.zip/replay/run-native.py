from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = root / 'work/ne88-speaker-portrait-20261119'
out = base / 'live-native'
out.mkdir()
probe = base / 'probe.gd'
scene = base / 'probe.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n'
                 '[node name="SpeakerPortraits" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
command = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '4500',
           scene.as_posix(), '--', '--out=' + str(out)]
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (out / 'raw.log').open('wb') as log:
    result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=160)
raw = (out / 'raw.log').read_text(encoding='utf-8')
print(raw[-5000:], flush=True)
report = json.loads((out / 'report.json').read_text(encoding='utf-8'))
print(json.dumps({key:value for key,value in report.items() if key!='samples'}, ensure_ascii=False), flush=True)
print('samples', sorted(report['samples']), flush=True)
assert '9070 XT' in report['adapter'] and report['size'] == [1280, 720] and report['scale'] == 1.2
assert 'SCRIPT ERROR' not in raw and 'ERROR:' not in raw
assert set(report['catalog']) == {'zh', 'ja', 'en'} and len(report['samples']) == 13 and len(report['live']) == 6
assert not report['errors'] and result.returncode == report['capture_failures'] == 0
