extends ScenarioBase

const CHAPTERS := [&"ch1_kasa", &"ch2_heron"]
const TEXT_MODES := [&"dialogue", &"cinematic", &"radio"]
const SYSTEM_IDS := ["voice", "terminal", "label", "note", "broadcast", "weather", "system"]
const SYSTEM_PORTRAIT := "res://art/portraits/system.png"

var _errors: Array[String] = []
var _catalog: Dictionary = {}
var _samples: Dictionary = {}
var _live: Dictionary = {}


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	await open_arena("res://data/lighting/market.tres")
	for language: String in [StoryLocale.SOURCE_LANGUAGE, "ja", "en"]:
		if not Story.set_language(language):
			_errors.append("unsupported language %s" % language)
			continue
		_audit_language(StringName(language))
	for key: String in _samples.keys():
		await _draw_sample(key, _samples[key])
	Story.set_language(StoryLocale.SOURCE_LANGUAGE)
	Story.auto_skip = false
	for item in [[&"ch1_t_oldk_1", "old_k"], [&"ch1_t_egret_2", "egret"], [&"ch1_g06_lamp", "lamp"],
		[&"ch2_t_s08_banyan", "banyan"], [&"ch2_s09_hawker", "hawker_far"], [&"ch2_t_s08_screen", "shen"]]:
		await _play_scene(item[0], item[1])
	var size := get_window().size
	var report := {"catalog": _catalog, "samples": _samples, "live": _live, "errors": _errors, "capture_failures": failures,
		"adapter": RenderingServer.get_video_adapter_name(), "size": [size.x, size.y], "scale": Settings.get_ui_text_scale()}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _errors.is_empty() and failures == 0 else 1)


func _audit_language(language: StringName) -> void:
	var scenes: Dictionary = Story.audit_data()["scenes"]
	var counts := {"lines": 0, "scenes": 0, "variants": 0, "chapter_lines": {}}
	for id: String in Story.scene_ids():
		var chapter: StringName = Story._scene_chapter.get(id, &"")
		var mode := Story.scene_mode(StringName(id))
		if chapter not in CHAPTERS or mode not in TEXT_MODES:
			continue
		counts["scenes"] += 1
		var samples := [0]
		for variant in StoryReactions.variants_of(scenes[id]):
			samples.append(StoryReactions.threshold(variant))
			counts["variants"] += 1
		for deaths: int in samples:
			for line in Story.resolved_lines(StringName(id), deaths):
				counts["lines"] += 1
				var chapter_lines: Dictionary = counts["chapter_lines"]
				chapter_lines[chapter] = int(chapter_lines.get(chapter, 0)) + 1
				_check_line(language, id, mode, deaths, line)
	_catalog[language] = counts


func _check_line(language: StringName, id: String, mode: StringName, deaths: int, line: Dictionary) -> void:
	var speaker := str(line["speaker"])
	var path := str(line["portrait"])
	if path.is_empty() or not ResourceLoader.exists(path, "Texture2D"):
		_errors.append("%s %s %s lacks portrait %s" % [language, id, speaker, path])
		return
	if path == SYSTEM_PORTRAIT and speaker not in SYSTEM_IDS:
		_errors.append("%s %s assigns the system portrait to %s" % [language, id, speaker])
	if language != StringName(StoryLocale.SOURCE_LANGUAGE) or (mode != &"radio" and speaker in SYSTEM_IDS):
		return
	var key := "%s-%s" % [mode, speaker]
	if not _samples.has(key):
		_samples[key] = {"scene": id, "mode": mode, "deaths": deaths, "line": line}


func _draw_sample(key: String, sample: Dictionary) -> void:
	var line: Dictionary = sample["line"].duplicate()
	line.erase("delay")
	var lines: Array[Dictionary] = [line]
	var layer: DialogueLayer = Story._layer
	var is_radio: bool = sample["mode"] == &"radio"
	if is_radio:
		layer.enqueue_radio(&"portrait_review", lines)
		layer._radio_text.visible_ratio = 1.0
	else:
		layer.start_cinematic(&"portrait_review", lines)
		layer.advance()
	await settle(11)
	var portrait: TextureRect = layer._radio_portrait if is_radio else layer._portrait
	var speaker: Label = layer._radio_name if is_radio else layer._name
	if not portrait.is_visible_in_tree() or portrait.texture == null or portrait.texture.resource_path != str(line["portrait"]):
		_errors.append("%s displays the wrong portrait for %s" % [key, sample["scene"]])
	if not speaker.is_visible_in_tree() or not speaker.text.contains(str(line["name"])):
		_errors.append("%s displays the wrong speaker for %s" % [key, sample["scene"]])
	sample["portrait_size"] = [portrait.size.x, portrait.size.y]
	sample["header"] = speaker.text
	await RenderingServer.frame_post_draw
	capture(key)
	if is_radio:
		layer.cancel_radio()
	else:
		layer.cancel_cinematic()


func _play_scene(id: StringName, expected: String) -> void:
	if not Story.play(id, false):
		_errors.append("could not play authored scene %s" % id)
		return
	await settle(16)
	var layer: DialogueLayer = Story._layer
	var is_radio := Story.scene_mode(id) == &"radio"
	var portrait: TextureRect = layer._radio_portrait if is_radio else layer._portrait
	var speaker: Label = layer._radio_name if is_radio else layer._name
	var source := Story.speaker(expected)
	var shown := portrait.texture.resource_path if portrait.texture != null else ""
	if not portrait.is_visible_in_tree() or shown != str(source["portrait"]) or not speaker.text.contains(str(source["name"])):
		_errors.append("authored scene %s shows the wrong portrait or speaker" % id)
	_live[id] = {"speaker": expected, "head": speaker.text, "portrait": shown, "mode": Story.scene_mode(id)}
	await RenderingServer.frame_post_draw
	capture("scene-" + String(id))
	Story.reset_active_presentation(&"portrait_review")
	await settle(3)
