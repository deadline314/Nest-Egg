from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json
import re

root=Path.cwd()
base=Path(__file__).resolve().parent
def read(path):
    return json.loads((base/path).read_bytes())
def text(path):
    return (base/path).read_text(encoding='utf-8-sig')

bad=read('reproduced-with-pool/missing-primary.json')
native=read('restored-native/missing-primary.json')
unarmed=read('loss-of-fallback/missing-primary.json')
assert len(bad)==len(native)==5 and len(unarmed)==4
for i, row in enumerate(native):
    assert row['health']==6 and row['armed'] and row['shot'] and row['rounds_spent']==1
    if i < 3:
        assert not bad[i]['armed'] and native[i]['weapon']=='pistol'
        assert native[i]['snapshot']['mag']==[12] and native[i]['snapshot']['reserve']==[-1]
        assert not unarmed[i]['armed'] and not unarmed[i]['shot'] and unarmed[i]['rounds_spent']==0
        assert all(unarmed[i]['snapshot'][key]==[] for key in ('weapons','mag','reserve'))
    else:
        assert row==bad[i]
assert unarmed[-1]==native[-2]
assert text('reproduced-with-pool/engine.log').count('SCRIPT ERROR:')==4
assert text('loss-of-fallback/engine.log').count('暫時空手（無法載入')==3
assert not re.search(r'^(?:SCRIPT )?ERROR:',text('restored-native/engine.log'),re.M)
assert not re.search(r'^(?:SCRIPT )?ERROR:',text('loss-of-fallback/engine.log'),re.M)
assert text('focus-stock.log').count('FAIL:')==6
assert read('official-release/verification.json')=={'exit':0,'errors':[],'source_held':True}
official=text('official-release/raw.log')
suites=int(re.search(r'Running (\d+) groups',official)[1])
check=re.search(r'checks:\s*(\d+), new failures: 0, known failures [^:]*: 0.*wall time (\d+) s',official)
assert check and suites==34
checks,seconds=int(check[1]),int(check[2])

ticket=next((root/'pm/Nest-Egg').glob('[[]NE-303]*')).relative_to(root)
archive=Path('pm/Nest-Egg/attachments/NE-303-missing-primary-2026-11-21/evidence.zip')
image=Path('pm/Nest-Egg/images/NE-303-restored-p9-20261121.png')
prev=(root/ticket).read_text(encoding='utf-8')
assert prev.count('- [ ]')==3 and '> 狀態：進行中' in prev and '# Commit-' not in prev
assert not (root/archive.parent).exists() and not (root/image).exists()
raw=[base/path for path in ('adopt.py','bundle.py','observe.gd','observe.tscn','run.py','focus-stock.log',
                            'official-release/command.json','official-release/raw.log','official-release/verification.json')]
for folder in ('reproduced-with-pool','restored-native','loss-of-fallback','official-release/shards'):
    raw.extend(file for file in sorted((base/folder).iterdir()) if file.is_file())
(root/archive).parent.mkdir()
with ZipFile(root/archive,'x',compression=ZIP_DEFLATED) as bundle:
    for file in raw:
        bundle.write(file,file.relative_to(base).as_posix())
with ZipFile(root/archive) as bundle:
    assert bundle.testzip() is None
(root/image).write_bytes((base/'restored-native/inventory.png').read_bytes())
section=f'''
---

# Commit-1

## 內文

原本武器欄在預設和存檔都沒有武器時，會把空值塞進武器資料並讀取彈匣。現在先保留有效存檔武器。只有確實沒有可用武器時才載入 P-9，並記錄缺少的欄位和退回結果。緊急 P-9 本身遺失時，武器欄、彈匣和備彈維持一致的空狀態。

### 測試結果

- 原版在三種缺件案例中共出現四個腳本錯誤。修後三種案例皆用真正的玩家發射 P-9，彈匣由 12 扣為 11。有效的存檔步槍保留 9 發與 21 發備彈，正式設定的 P-9 也照常開火。
- 隔離程序暫時移走緊急 P-9 資源。三種無武器案例均正確空手，重新計算改裝和射擊都能安全完成，有效的存檔步槍仍能開火。測試結束後以雜湊核對武器資源已還原。
- RX 9070 XT Forward+ 實際查看復原後的背包與子彈。新回歸在原版重現 6 項失敗，修後受影響回歸 {suites} 套、{checks:,} 項全過，{seconds} 秒。

[原生畫面、缺件案例與回歸紀錄](attachments/NE-303-missing-primary-2026-11-21/evidence.zip)

![玩家設定遺失後恢復的 P-9 與射出一發後的彈匣](images/NE-303-restored-p9-20261121.png)
'''
(root/ticket).write_text(prev.replace('> 狀態：進行中','> 狀態：完成').replace('- [ ]','- [x]').rstrip()
                         +'\n\n\n'+section.lstrip('\n'),encoding='utf-8')
paths=[*map(Path,read('runtime.json')),Path('design/07-weapons-inventory/DESIGN.md'),ticket,archive,image]
(base/'delivery.json').write_text(json.dumps([path.as_posix() for path in paths],ensure_ascii=False,indent=2)+'\n',
                                  encoding='utf-8')
print(len(raw),(root/archive).stat().st_size)
