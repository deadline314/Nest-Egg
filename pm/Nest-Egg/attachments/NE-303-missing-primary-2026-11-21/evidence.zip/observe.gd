extends Node2D

var output := ""
var missing_pistol := false
var rows: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			output = arg.trim_prefix("--out=")
		elif arg == "--missing-pistol":
			missing_pistol = true
	if not output.is_absolute_path():
		get_tree().quit(2)
		return
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	_run.call_deferred()


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	var projectiles := Node2D.new()
	add_child(projectiles)
	ProjectilePool.bind_container(projectiles)
	var cases := {
		"missing_tuning": {"tuning":null,"snapshot":{}},
		"blank_weapon": {"tuning":PlayerTuning.new(),"snapshot":{"weapons":"bad"}},
		"missing_saved_weapon": {"tuning":PlayerTuning.new(),"snapshot":{"weapons":["res://data/weapons/missing_from_supply_test.tres"]}},
		"valid_saved_weapon": {"tuning":PlayerTuning.new(),"snapshot":{"weapons":["res://data/weapons/rifle.tres"],"mag":[9],"reserve":[21],"active":0}},

	}
	if not missing_pistol:
		cases["normal_tuning"] = {"tuning":load("res://data/player/player_tuning.tres"),"snapshot":{}}
	for name: String in cases:
		var case: Dictionary = cases[name]
		var player := Player.new()
		player.position = Vector2(320,240)
		player.configure(case["tuning"],6,case["snapshot"])
		add_child(player)
		player.set_physics_process(false)
		player.loadout.retune()
		var logical := player.loadout.snapshot()
		var weapon := player.loadout.active_weapon()
		var armed := weapon != null
		var lodged := player.loadout.mag_in(Loadout.PRIMARY)
		var free: Array[Projectile] = ProjectilePool._free
		var observed := free.back() as Projectile if not free.is_empty() else null
		player._try_fire()
		var fired := observed != null and observed.active and observed.team == Combat.Team.PLAYER
		rows.append({"case":name,"armed":armed,"weapon":str(weapon.id) if armed else "",
			"shot":fired,"rounds_spent":lodged - player.loadout.mag_in(Loadout.PRIMARY),"snapshot":logical,"health":player.health.current})
		if name == "missing_tuning" and DisplayServer.get_name() != "headless":
			var inventory := InventoryScreen.new()
			inventory.configure(player)
			add_child(inventory)
			inventory.open()
			for _frame in 16:
				await get_tree().process_frame
			await RenderingServer.frame_post_draw
			preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(output.path_join("inventory.png"))
			inventory.close()
			inventory.queue_free()
		player.queue_free()
		await get_tree().process_frame
	var file := FileAccess.open(output.path_join("missing-primary.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(rows,"  ") + "\n")
	file.close()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)


