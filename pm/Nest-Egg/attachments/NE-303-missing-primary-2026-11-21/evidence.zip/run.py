from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

base=Path(__file__).resolve().parent
game=(base.parent/'ne218-baseline-20261117').resolve(strict=True)
dest=base/sys.argv[1]
dest.mkdir()
native='native' in sys.argv[2:]
missing='missing-pistol' in sys.argv[2:]
expect_stock='stock' in sys.argv[2:]
assert not (native and missing)
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','TEMP','TMP','TMPDIR'):
    folder=dest/key
    folder.mkdir()
    env[key]=str(folder)
paths=['game/player/loadout.gd','game/player/player.gd','data/player/player_tuning.tres','data/weapons/pistol.tres']
sha=lambda file:sha256(file.read_bytes()).hexdigest()
source={path:sha(game/path) for path in paths}
argv=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(game)]
if native:
    argv=[sys.executable,'-B',str(game/'tools/comfyui/gpu_lock.py'),'--',*argv,
          '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720']
else:
    argv+=['--headless']
argv+=['--max-fps','120','--quit-after','2500',str(base/'observe.tscn'),'--','--out='+str(dest)]
pistol=game/'data/weapons/pistol.tres'
backup=pistol.with_name('pistol.tres.ne303-diagnostic')
if missing:
    assert pistol.resolve(strict=True) == game/'data/weapons/pistol.tres'
    assert not backup.exists()
    argv+=['--missing-pistol']
(dest/'command.json').write_text(json.dumps({'argv':argv,'source':source,'temporarily_missing':missing},indent=2)+'\n')
try:
    if missing:
        pistol.rename(backup)
        assert not pistol.exists()
    with (dest/'engine.log').open('wb') as log:
        proc=subprocess.run(argv,env=env,cwd=game,stdout=log,stderr=subprocess.STDOUT,timeout=100)
finally:
    if missing and backup.exists():
        backup.rename(pistol)
raw=(dest/'engine.log').read_text(encoding='utf-8')
assert source=={path:sha(game/path) for path in paths}
assert proc.returncode==0, (proc.returncode,raw[-4500:])
errors=re.findall(r'^(?:SCRIPT )?ERROR:.*',raw,re.M)
assert bool(errors)==expect_stock,raw[-4500:]
if expect_stock:
    assert all('magazine_size' in line for line in errors)
rows=json.loads((dest/'missing-primary.json').read_bytes())
assert len(rows)==(4 if missing else 5)
print(rows,flush=True)
