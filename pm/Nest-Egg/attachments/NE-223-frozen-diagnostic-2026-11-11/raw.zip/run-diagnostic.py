"""Bounded diagnostic only: real world freeze, plus an explicit ALWAYS negative control."""
from pathlib import Path
import hashlib, json, os, subprocess, sys

root=Path(__file__).resolve().parents[1]
out=root/'pm/Nest-Egg/attachments/NE-223-frozen-diagnostic-2026-11-11'
out.mkdir(parents=True,exist_ok=True)
(out/'.gdignore').touch()
normal=root/'tools/quest_map_perf_probe.gd'
negative=root/'work/ne223_perf_always_negative.gd'
original=normal.read_bytes()
data=original.replace(b'level.process_mode = Node.PROCESS_MODE_PAUSABLE',b'level.process_mode = Node.PROCESS_MODE_ALWAYS',1)
data=data.replace(b'"res://tools/quest_map_perf_probe.gd"',b'"res://work/ne223_perf_always_negative.gd"',1)
negative.write_bytes(data)
scene=root/'work/ne223_perf_always_negative.tscn'
scene.write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/ne223_perf_always_negative.gd" id="1"]\n[node name="Negative" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8',newline='\n')
sys.path.insert(0,str(root/'tools/comfyui'))
import comfy_guard
stages=[]
for name,width,height,scene_path in [('always-negative',1280,720,'res://work/ne223_perf_always_negative.tscn'),
                                    ('native-1280',1280,720,'res://tools/quest_map_perf_probe.tscn'),
                                    ('native-1920',1920,1080,'res://tools/quest_map_perf_probe.tscn')]:
 target=out/name
 target.mkdir(exist_ok=False)
 userdir=root/'work'/f'ne223-corrected-{name}-user'
 userdir.mkdir(exist_ok=True)
 env=dict(os.environ,APPDATA=str(userdir),PYTHONUTF8='1')
 command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--resolution',f'{width}x{height}',
          '--rendering-method','forward_plus','--rendering-driver','vulkan',scene_path,'--',f'--out={target}',
          '--rounds=4',f'--width={width}',f'--height={height}','--shared-workload']
 (target/'command.json').write_text(json.dumps(command,indent=2),encoding='utf-8',newline='\n')
 with comfy_guard.server_lock():
  with (target/'run.log').open('wb') as stream:
   result=subprocess.run(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
 report=json.loads((target/f'quest-map-perf-{width}.json').read_text(encoding='utf-8'))
 frozen=[row['unchanged'] for row in report['freeze_samples']]
 if name=='always-negative':
  assert result.returncode==1 and len(report['issues'])==4 and frozen==[False]*4,(result.returncode,report['issues'],frozen)
 else:
  assert result.returncode==0 and not report['issues'] and frozen==[True]*4,(result.returncode,report['issues'],frozen)
  assert all(not row['before']['level_can_process'] and not row['before']['player_can_process'] for row in report['freeze_samples'])
  assert 'SCRIPT ERROR' not in (target/'run.log').read_text(encoding='utf-8')
 assert report['resolution']==[width,height] and report['adapter']=='AMD Radeon RX 9070 XT'
 stages.append({'name':name,'exit':result.returncode,'issues':report['issues'],'world_frozen':frozen,'scope':'shared-load diagnostic; not isolated performance or physical input acceptance'})
 print(json.dumps(stages[-1],ensure_ascii=True),flush=True)
assert normal.read_bytes()==original,'Product probe changed during the run'
(out/'validation.json').write_text(json.dumps(stages,ensure_ascii=False,indent=2),encoding='utf-8',newline='\n')
(out/'tested-normal-source.gd.txt').write_bytes(original)
(out/'tested-negative-source.gd.txt').write_bytes(data)
print('All three diagnostic programs behaved as expected',flush=True)
