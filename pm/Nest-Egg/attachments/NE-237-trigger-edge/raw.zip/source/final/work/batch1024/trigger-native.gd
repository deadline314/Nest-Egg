extends "res://work/batch1024/trigger-probe.gd"
var _observed: Array[String] = []
func _ready() -> void:
	get_window().size = Vector2i(1280, 720)
	get_window().position = Vector2i(32, 32)
	super._ready()
func _check(condition: bool, message: String) -> void:
	_observed.append(("PASS " if condition else "FAIL ") + message)
	super._check(condition, message)
func _end_level(level: Level) -> void:
	get_tree().paused = true
	var overlay := CanvasLayer.new()
	overlay.layer = 200
	add_child(overlay)
	var background := ColorRect.new()
	background.color = Color(0.02, 0.03, 0.04, 1.0)
	background.position = Vector2(12, 12)
	background.size = Vector2(616, 150)
	overlay.add_child(background)
	var label := Label.new()
	label.position = Vector2(20, 20)
	label.add_theme_font_size_override("font_size", 9)
	label.size = Vector2(600, 130)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.text = "NE-237 SYNTHETIC TRIGGER CONTROL / INSTRUMENTED FIXTURE\nActor held still; command-latch checks, not human combat or physical pad\n\n" + "\n".join(_observed)
	overlay.add_child(label)
	await get_tree().process_frame
	await get_tree().process_frame
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	DirAccess.make_dir_recursive_absolute(out)
	var picture := preload("res://work/batch1024/window_capture.gd").image(get_window())
	_check(picture != null and picture.get_size() == Vector2i(1280, 720) and picture.save_png(out.path_join("trigger-command.png")) == OK, "actual native window saved")
	overlay.free()
	get_tree().paused = false
	await super._end_level(level)
