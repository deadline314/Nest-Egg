extends "res://tests/smoke_test.gd"
## Focused control: use the original runner's fixture and assertion machinery.
func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var suite := MeleeSuite.new(self)
	await preload("res://tests/helpers/melee_trigger_edge_checks.gd").run(suite)
	await _finish()
