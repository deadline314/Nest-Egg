from pathlib import Path
import subprocess,os,json
r=Path('/workspace/Nest-Egg');t=r/'work/batch1024/trigger-worktree';p=t/'game/player/melee_command_input.gd';final=p.read_bytes();base=subprocess.check_output(['git','show','be4e5db5:game/player/melee_command_input.gd'],cwd=t);naive=base.replace(b'\t\tif event.is_action_pressed(action):\n\t\t\t_held_actions[action] = true\n\t\t\tqueue_command()\n',b'\t\tif event.is_action_pressed(action):\n\t\t\tvar was_pressed: bool = _held_actions.get(action, false)\n\t\t\t_held_actions[action] = true\n\t\t\tif not was_pressed:\n\t\t\t\tqueue_command()\n');assert naive!=base
(r/'work/batch1024/trigger-naive-source.gd').write_bytes(naive)
try:
 p.write_bytes(naive)
 with (r/'work/batch1024/trigger-control-naive.log').open('w') as f:s=subprocess.run(['/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64','--headless','res://work/batch1024/trigger-probe.tscn'],cwd=t,env={**os.environ,'XDG_DATA_HOME':str(r/'work/batch1024/trigger-naive-profile')},stdout=f,stderr=subprocess.STDOUT,timeout=60)
 print('NAIVE_EXIT',s.returncode)
finally:p.write_bytes(final)
assert p.read_bytes()==final
