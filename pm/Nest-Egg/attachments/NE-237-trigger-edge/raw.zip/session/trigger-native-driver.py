from pathlib import Path
import subprocess,os,json,hashlib,re,time
r=Path('/workspace/Nest-Egg');w=r/'work/batch1024';t=w/'trigger-worktree';n=r/'work/batch1020b';p=t/'game/player/melee_command_input.gd';final=p.read_bytes();base=subprocess.check_output(['git','show','be4e5db5:game/player/melee_command_input.gd'],cwd=t);rows=[];sha=lambda b:hashlib.sha256(b).hexdigest()
for tag,source,failures in [('before',base,1),('after',final,0)]:
 try:
  p.write_bytes(source);name='ne237-1024-trigger-v2-'+tag
  with (w/('trigger-native-'+tag+'-console.log')).open('w') as f:s=subprocess.run(['python',str(w/'native-large.py'),name,'res://work/batch1024/trigger-native.tscn'],cwd=r,env={**os.environ,'NE_NATIVE_PROJECT':'../batch1024/trigger-worktree'},stdout=f,stderr=subprocess.STDOUT,timeout=300)
  log=(n/(name+'.log')).read_text();m=re.search(r'checks: (\d+), failures: (\d+)',log);row={'tag':tag,'exit':s.returncode,'checks':int(m[1]) if m else None,'failures':int(m[2]) if m else None,'errors':log.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log)),'command_source_sha256':sha(source)};rows.append(row);(w/'trigger-native.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True);assert row['checks']==5 and row['failures']==failures and row['exit']==failures and row['errors']==row['leaks']==0
 finally:p.write_bytes(final)
assert p.read_bytes()==final
