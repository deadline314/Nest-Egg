from pathlib import Path
import cv2
import numpy as np
from PIL import Image
from scipy.ndimage import binary_dilation
p=Path(__file__).resolve().parent
res=p.parent/'ne218-baseline-20261117/art/characters/rin/parts'
a=np.array(Image.open(res/'pelvis.png').convert('RGBA'))
g=np.array(Image.open(res/'pelvis_glow.png').convert('RGBA'))
hsv=cv2.cvtColor(a[:,:,:3],cv2.COLOR_RGB2HSV).astype(int)
Y,X=np.indices(a.shape[:2])
near=(Y>=20)&(Y<=58)&(X>=154)&(X<=167)&(a[:,:,3]>=245)
hue,sat,val=np.moveaxis(hsv,-1,0)
cyan=near&(hue>=82)&(hue<=102)&(sat>=145)&(val>=120)
a_new=cyan & (g[:,:,3]==0)
nb=binary_dilation(cyan,structure=np.array([[0,0,0],[0,1,1],[0,0,0]])) & near & (g[:,:,3]==0)
for name,pixels in (('trim',a_new),('trim-edge',nb),('trim-wide',binary_dilation(nb,structure=np.ones((1,5),bool))&near&(g[:,:,3]==0))):
    out=g.copy()
    for y,x in zip(*np.nonzero(pixels)):
        candidates=np.flatnonzero(cyan[y])
        if not len(candidates): continue
        nearest=candidates[np.argmin(abs(candidates-x))]
        rgb=a[y,nearest,:3]
        out[y,x,:3]=rgb
        out[y,x,3]=176 if cyan[y,x] else 112
    old=g[:,:,3]>0
    assert np.array_equal(out[old],g[old])
    assert np.all(a[:,:,3][out[:,:,3]>0]>128)
    combined=out[:,:,3]>0
    print(name,'added source glow pixels',int(combined.sum()-old.sum()),'alpha',tuple(np.unique(out[:,:,3])))
    Image.fromarray(out).save(p/f'{name}.png')
