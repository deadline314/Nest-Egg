from pathlib import Path
from PIL import Image
import numpy as np
p=Path(__file__).resolve().parent
for i in range(3):
    d=p/f'trim-t{i}-f-1'
    on,off,repeat=[np.asarray(Image.open(d/f'transfer_stand_{mode}.png').convert('RGB'),dtype=int)
                   for mode in ('on','off','repeat')]
    mask=(on>=247).all(axis=-1)&~(off>=247).all(axis=-1)&(abs(on-repeat).max(axis=-1)<=2)
    crop=np.zeros(mask.shape,bool)
    crop[368:458,1118:1218]=True
    for y,x in zip(*np.nonzero(mask&crop)):
        print(i,(x,y),'before',off[y,x],'after',on[y,x])
