from pathlib import Path
from hashlib import sha256
from shutil import copyfile
from subprocess import run
import json
import os
import sys

import numpy as np
from PIL import Image

p=Path(__file__).resolve().parent
root=Path.cwd()
shared=p.parent/'ne218-baseline-20261117'
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'tools/comfyui'))
from cut_layers import part_transform,render_part,validate_final_override
from cut_rig_parts import glow_layer
dir=Path('art/characters/rin/parts')
diffuse=dir/'pelvis.png'
normal=dir/'pelvis_n.png'
glow=dir/'pelvis_glow.png'
source=Path('art_src/characters/rin_field/overrides/refined/pelvis.png')
override=Path('art_src/characters/rin_field/overrides/pelvis_glow.png')
spec=json.loads((root/'tools/comfyui/specs/rin_side.json').read_bytes())
assert not (root/override).exists()
assert json.loads((root/'tools/comfyui/recipes/rin.json').read_bytes())['work']==override.parent.parent.as_posix()
asset=Image.open(root/source).convert('RGBA')
factor=spec['tex_px_per_wp']/spec['illustration_px_per_wp']
assert factor==1
joints={name:np.array(point)*factor for name,point in spec['joints'].items()}
part=spec['parts']['pelvis']
matrix, w,h,pivot=part_transform(asset,part,joints,factor)
original=render_part(asset,(matrix,w,h,pivot),factor,crop_phase=part.get('crop_phase'))
assert np.array_equal(original,np.asarray(Image.open(root/diffuse).convert('RGBA')))
thr=spec.get('glow_threshold',{})
layer=glow_layer(original[:,:,:3],original[:,:,3],spec['glow']['pelvis'],
                 thr.get('sat',140),thr.get('val',190))
existing=np.array(Image.open(root/glow).convert('RGBA'))
assert np.array_equal(existing,layer)
patch_path=p/'trim.png'
candidate=np.array(Image.open(patch_path).convert('RGBA'))
touched=(candidate!=existing).any(axis=-1)
old=existing[:,:,3]>0
new=touched & ~old
assert not np.any(touched&old) and new.sum()==64
assert (candidate[new,3]==176).all() and (original[new,3]>=245).all()
assert np.array_equal(candidate[new,:3],original[new,:3])
validate_final_override(patch_path,root/glow)
valid=p/'release-draft'
target=valid/override
target.parent.mkdir(parents=True)
copyfile(patch_path,target)
mini=p/'import-project'
(mini/dir).mkdir(parents=True)
copyfile(p.parent/'evidence-20261120-ne250-stage-motion/release-import-project/project.godot',mini/'project.godot')
copyfile(target,mini/glow)
copyfile(root/Path(str(glow)+'.import'),mini/Path(str(glow)+'.import'))
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    folder=p/'import-profile'/key
    folder.mkdir(parents=True)
    env[key]=str(folder)
with (p/'texture-import.log').open('wb') as log:
    cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--editor','--path',str(mini),'--import']
    r=run(cmd,cwd=shared,env=env,stdout=log,stderr=log,timeout=95)
assert r.returncode==0 and 'ERROR:' not in (p/'texture-import.log').read_text(encoding='utf-8')
assert len(list((mini/'.godot/imported').glob('*.ctex')))==1
sha=lambda p:sha256(p.read_bytes()).hexdigest()
assert sha(mini/glow)==sha(target)==sha(patch_path)
doc={'variant':'trim','before':sha(root/glow),'after':sha(target),'diffuse_held':sha(root/diffuse),
     'normal_held':sha(root/normal),'refined_held':sha(root/source),'registration':[w,h,*pivot],
     'original_emissive':int(old.sum()),'extra_emissive':int(new.sum()),'extra_alpha':176,
     'bounded_source':override.as_posix(),'game_output':glow.as_posix()}
(p/'prepared.json').write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps(doc),flush=True)
