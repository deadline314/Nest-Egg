from pathlib import Path
from math import dist
import json,sys
from PIL import Image
import numpy as np

p=Path(__file__).resolve().parent
patterns=['trim-t*-f*','soft-a*-t*-f*','release-t*-f*'] if len(sys.argv)==1 else [sys.argv[1]]
read=lambda f:json.loads(f.read_bytes())
rec={}
def rgb(f,case,phase,box):
    return np.asarray(Image.open(f/f'{case}_{phase}.png').convert('RGB').crop(box),dtype=np.int16)
def delta(a,b):
    return abs(a-b).max(axis=-1)
def clipped(a):
    return (a>=247).all(axis=-1)
for pattern in patterns:
    for cand in sorted(p.glob(pattern)):
        suffix=cand.name[cand.name.index('-t'):]
        origin=p/f'base{suffix}'
        if not (origin/'profiles.json').is_file() or not (cand/'profiles.json').is_file():
            continue
        coords=read(origin/'profiles.json')
        rival=read(cand/'profiles.json')
        rows=[]
        for field,poses in coords.items():
            for pose,point in poses.items():
                assert dist(point,rival[field][pose])<.03,(cand.name,field,pose,point,rival[field][pose])
                x,y=map(lambda a:round(a*2),point)
                box=(max(0,x-60),max(0,y-48),min(x+60,1280),min(y+60,720))
                scene=f'{field}_{pose}'
                prior,now=(rgb(f,scene,'on',box) for f in (origin,cand))
                old_off,new_off=(rgb(f,scene,'off',box) for f in (origin,cand))
                old_rep,new_rep=(rgb(f,scene,'repeat',box) for f in (origin,cand))
                repeat=(delta(prior,old_rep)<=2)&(delta(now,new_rep)<=2)
                pair=repeat&(delta(old_off,new_off)<=3)
                assert pair.mean()>.97,(cand.name,scene,pair.mean())
                old_resp=pair&(delta(prior,old_off)>=5)
                new_resp=pair&(delta(now,new_off)>=5)
                new_pixels=pair & (delta(prior,now)>=5) & new_resp
                all_new_white=pair & clipped(now) & ~clipped(prior)
                clip=all_new_white & new_resp & (delta(prior,now)>=5)
                incidental=all_new_white & ~clip
                row=dict(scene=field,pose=pose,old=int(old_resp.sum()),new=int(new_resp.sum()),
                   changed_from_original=int(new_pixels.sum()),new_white=int(clip.sum()),old_white=int((pair&clipped(prior)).sum()),
                   incidental_white=int(incidental.sum()),
                   unchanged_when_off=round(float(pair.mean()),5),box=list(box))
                rows.append(row)
                print(cand.name,field,pose,row['old'],row['new'],row['changed_from_original'],row['new_white'],row['old_white'])
        rec[cand.name]=rows
(p/'paired-comparison.json').write_text(json.dumps(rec,indent=2)+'\n',encoding='utf-8')


