extends "D:/NestEggVerification/evidence-20261120-ne71-lighting/profile.gd"

var _trial_path := ""
var _face := 1

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--glow="):
			_trial_path=arg.trim_prefix("--glow=")
		elif arg.begins_with("--face="):
			_face = -1 if int(arg.trim_prefix("--face=")) < 0 else 1
	add_child(LightKit.create_environment())
	super._ready()

func _review(field: Array) -> void:
	var tag: String = field[0]
	var map: String = field[1]
	var location := Vector2((int(field[2])+0.5)*16.0,int(field[3])*16.0)
	GameState.start_new_run(GameState.difficulties[1])
	seed(710311)
	level = Level.new()
	level.configure(load("res://data/levels/%s.tres" % map) as LevelData)
	add_child(level)
	await settle(25)
	player = level.player
	await clear_enemies()
	player.global_position = location-Vector2(0,5)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player,true)
	var aim: StringName = &"aim_left" if _face < 0 else &"aim_right"
	Input.action_press(aim)
	snap_camera()
	await wait(3.9)
	_check(player.facing == _face,tag+" aiming faces the requested side")
	var rig: CharacterRig=player._visual.rig
	var pelvis: CanvasItem
	for part in rig._parts:
		if part.name==&"armor_pelvis":
			for child in part.get_children():
				if child is CanvasItem and child.material==CharacterRig._glow_material():
					pelvis=child
					break
	_check(pelvis!=null and pelvis.is_visible_in_tree(),tag+" real pelvis glow is present")
	if pelvis==null: return
	var image := Image.load_from_file(_trial_path)
	var live_texture := pelvis.get("texture") as Texture2D
	_check(image!=null and live_texture!=null and Vector2(image.get_size())==live_texture.get_size(),tag+" trial matches the real canvas")
	if image==null or live_texture==null or Vector2(image.get_size())!=live_texture.get_size(): return
	pelvis.set("texture",ImageTexture.create_from_image(image))
	var rows: Dictionary = {}
	for action: String in ["stand","crouch"]:
		if action=="crouch":
			Input.action_press(&"move_down")
			await settle(40)
			_check(player.is_crouching,tag+" real down input starts crouch")
		var origin:=rig.bone(&"hip").get_global_transform_with_canvas().origin
		rows[action]=[origin.x,origin.y]
		get_tree().paused=true
		await _take("%s_%s_on"%[tag,action])
		pelvis.visible=false
		await _take("%s_%s_off"%[tag,action])
		pelvis.visible=true
		await _take("%s_%s_repeat"%[tag,action])
		if action=="stand":
			var env:=LightKit.environment()
			_check(env.glow_enabled,tag+" native gameplay environment has bloom enabled")
			env.glow_enabled=false
			await _take(tag+"_stand_no_bloom_on")
			pelvis.visible=false
			await _take(tag+"_stand_no_bloom_off")
			pelvis.visible=true
			env.glow_enabled=true
		get_tree().paused=false
	Input.action_release(&"move_down")
	Input.action_release(aim)
	AimInput.set_virtual_gamepad(player,false)
	_results[tag]=rows
	await finish()



