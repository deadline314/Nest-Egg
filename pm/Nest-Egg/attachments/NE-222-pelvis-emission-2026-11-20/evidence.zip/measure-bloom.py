from pathlib import Path
from math import dist
import json
from PIL import Image
import numpy as np
from scipy.ndimage import distance_transform_edt
p=Path(__file__).resolve().parent
read=lambda f:json.loads(f.read_bytes())
facts=[]
def rgb(folder,scene,mode,rect):
    return np.asarray(Image.open(folder/f'{scene}_stand_{mode}.png').convert('RGB').crop(rect),dtype=np.int16)
def diff(a,b):
    return np.abs(a-b).max(axis=-1)
def white(a):
    return (a>=247).all(axis=-1)
for facing in (-1,1):
    base=p/f'bloom-base-f{facing}'
    candidate=p/f'bloom-candidate-f{facing}'
    if not all((f/'profiles.json').is_file() for f in (base,candidate)):
        continue
    coords=read(base/'profiles.json')
    other=read(candidate/'profiles.json')
    for mapname,poses in coords.items():
        point=poses['stand']
        assert dist(point,other[mapname]['stand'])<.03
        x,y=map(lambda a:round(a*2),point)
        box=(max(0,x-70),max(0,y-60),min(1280,x+70),min(720,y+70))
        states=['on','off','repeat','no_bloom_on','no_bloom_off']
        a,b=({k:rgb(folder,mapname,k,box) for k in states} for folder in (base,candidate))
        stable=(diff(a['on'],a['repeat'])<=2)&(diff(b['on'],b['repeat'])<=2)&(diff(a['off'],b['off'])<=3)
        assert (diff(a['on'],a['repeat'])<=2).mean()>.999
        assert (diff(b['on'],b['repeat'])<=2).mean()>.999
        assert stable.mean()>.95
        original=diff(a['on'],a['off'])
        current=diff(b['on'],b['off'])
        no_bloom=diff(b['no_bloom_on'],b['no_bloom_off'])
        old_no_bloom=diff(a['no_bloom_on'],a['no_bloom_off'])
        affected=stable & (diff(a['on'],b['on'])>=5) & (current>=5)
        clip=int((affected & white(b['on']) & ~white(a['on'])).sum())
        core=stable & (no_bloom>=5)
        # The projected material contribution remains when bloom is disabled.
        # The extra visible ring beyond it is measured from the same pose and atlas.
        spread=stable & (current>=4) & (no_bloom<=2)
        radius=distance_transform_edt(~core)[spread]
        new_spread=spread & (original<=2)
        row=dict(facing=facing,scene=mapname,box=list(box),original=int((stable&(original>=5)).sum()),
           candidate=int((stable&(current>=5)).sum()),added=int(affected.sum()),added_white=clip,
           core=int(core.sum()),previous_core=int((stable&(old_no_bloom>=5)).sum()),halo=int(spread.sum()),
           new_halo=int(new_spread.sum()),max_halo_distance=round(float(radius.max(initial=0)),3),
           sample_agreement=round(float(stable.mean()),5),
           largest_bloom_gain=int(np.abs((b['on']-b['off'])-(b['no_bloom_on']-b['no_bloom_off']))[affected].max(initial=0)))
        facts.append(row)
        print(row)
(p/'bloom-measurements.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8')

