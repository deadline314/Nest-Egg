from pathlib import Path
import json

directory = Path(__file__).resolve().parent
read = lambda path: json.loads((directory / path).read_bytes())
results = {}
for side in ("left", "right"):
    original, candidate = (read(f"{version}-{side}/run.json") for version in ("original", "candidate"))
    assert original["input_save"] == candidate["input_save"]
    assert original["resolution"]["target"] == candidate["resolution"]["target"]
    assert all(run["exit"] == 0 and not run["errors"] and not run["resolution"]["failures"] for run in (original, candidate))
    old, new = ({row["name"]: row for row in run["resolution"]["samples"]} for run in (original, candidate))
    assert len(old) == len(new) == 7 and old.keys() == new.keys()
    for name in old:
        assert {k: v for k, v in old[name].items() if k != "gun_light"} == {k: v for k, v in new[name].items() if k != "gun_light"}, (side, name)
    a, b = ({name: row["gun_light"] for name, row in rows.items()} for rows in (old, new))
    assert a["lifting"]["requested"] and a["lifting"]["drawn"]
    assert not b["lifting"]["requested"] and b["lifting"]["drawn"]
    assert 0.0 < b["lifting"]["energy"] < a["lifting"]["energy"]
    for name in ("reload-complete", "rifle-holding", "throwing-reselected"):
        assert a[name]["requested"] and a[name]["drawn"] and a[name]["energy"] > 0.0
        assert not b[name]["requested"] and not b[name]["drawn"] and b[name]["energy"] == b[name]["level"] == 0.0
        assert a[name]["fixture_reach"] == b[name]["fixture_reach"]
    assert a["ready"]["requested"] and a["ready"]["drawn"] and a["ready"] == b["ready"]
    results[side] = {"samples": len(new), "target": original["resolution"]["target"],
                     "original_energy": {name: light["energy"] for name, light in a.items()},
                     "candidate_energy": {name: light["energy"] for name, light in b.items()}}
(directory / "comparison.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
print(json.dumps(results, indent=2))
