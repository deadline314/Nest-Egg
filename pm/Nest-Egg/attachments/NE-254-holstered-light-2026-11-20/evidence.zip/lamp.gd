extends "D:/NestEggVerification/evidence-20261120-ne254-holstered-light/carry_probe.gd"


func _observe(name: String) -> void:
	await super._observe(name)
	var lamp := _player._weapon_light
	_samples[-1]["gun_light"] = {
		"requested":lamp._active,"drawn":lamp._light.enabled,"energy":lamp._light.energy if lamp._light.enabled else 0.0,
		"level":lamp._level,"direction":str(Vector2.from_angle(lamp.rotation)),"fixture_reach":lamp.reach()}


func _finish_carry() -> void:
	super._finish_carry()