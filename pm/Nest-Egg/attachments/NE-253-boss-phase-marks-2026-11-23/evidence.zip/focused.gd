extends "res://tests/smoke_test.gd"

func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var chapter_one := preload("./ch1-probe.gd").new(self)
	await chapter_one._test_watchdog_phases()
	var chapter_two := preload("./ch2-probe.gd").new(self)
	await chapter_two._test_cut_route()
	await chapter_two._test_keep_route()
	await _finish()
