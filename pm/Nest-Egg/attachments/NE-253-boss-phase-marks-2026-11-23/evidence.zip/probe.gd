extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const AREA := "res://data/levels/ch1_warehouse.tres"
var _out := ""
var _checks := 0
var _fails := 0


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	GameState.story_autosave = false
	Story.auto_skip = true
	Enemy.activation_culling_enabled = false
	Settings.use_storage("user://watchdog-phase-marks-native.cfg")
	Settings.set_reduce_ui_motion(true)
	add_child(LightKit.create_environment())
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(load(AREA) as LevelData)
	add_child(level)
	for frame in 240:
		if level.is_initialized() and not GameplayLock.is_locked() and not Story.is_cinematic_active():
			break
		await get_tree().process_frame
	var dog: PatternBoss
	for enemy in level._entities.get_children():
		if enemy is PatternBoss and (enemy as PatternBoss).data.id == &"watchdog":
			dog = enemy
		elif enemy is Enemy:
			enemy.set_physics_process(false)
	_check(dog != null, "loaded the real watchdog in the original warehouse")
	if dog != null:
		await _exercise(level, dog)
	level.queue_free()
	for frame in 8:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(1 if _fails else 0)


func _exercise(level: Level, dog: PatternBoss) -> void:
	var player := level.player
	player.health.setup(999, 0.0)
	player.global_position = dog.global_position + Vector2(-90.0, 0.0)
	player.velocity = Vector2.ZERO
	level.camera.snap_to_target()
	for frame in 150:
		if dog.is_awake() and dog.fsm.is_in(&"idle"):
			break
		await get_tree().physics_frame
	print("ACTORS ", player.global_position, " ", dog.global_position, " state ", dog.fsm.current)
	var bar := level.hud.boss_bar
	_check(dog.is_awake() and bar.is_open(), "approaching the original watchdog opens the actual boss HUD")
	var marks := Array(bar.phase_marks)
	print("WATCHDOG ", bar.ratio(), " marks ", marks)
	_check(marks.size() == 2 and is_equal_approx(float(marks[0]), 0.6) and is_equal_approx(float(marks[1]), 0.3),
			"the health bar draws the real 60 and 30 percent marks")
	_hit(dog, int(dog.health.max_health * 0.45))
	for frame in 3:
		await get_tree().physics_frame
	print("WATCHDOG ", bar.ratio(), " phase ", dog.phase, " crossed ", bar._crossed)
	_check(dog.phase == 1 and bar._crossed.has(0) and not bar._crossed.has(1),
			"the first phase activates at the first mark only")
	_check(is_equal_approx(bar.ratio(), float(dog.health.current) / dog.health.max_health),
			"the display continues to track the real health")
	await RenderingServer.frame_post_draw
	_check(Capture.image(get_viewport()).save_png(_out.path_join("watchdog-phase-two.png")) == OK, "captured actual phase two")
	_hit(dog, int(dog.health.max_health * 0.3))
	for frame in 3:
		await get_tree().physics_frame
	print("WATCHDOG ", bar.ratio(), " phase ", dog.phase, " crossed ", bar._crossed)
	_check(dog.phase == 2 and bar._crossed.has(1) and not dog.is_leashed(),
			"the second mark crosses with the original chain break")


func _hit(dog: PatternBoss, amount: int) -> void:
	var info := DamageInfo.create(amount, Combat.Team.PLAYER, &"watchdog_phase_probe")
	info.ignore_invulnerability = true
	info.bypass_guard = true
	dog.hurtbox.receive(info)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	if not ok:
		printerr("FAIL: ", message)
