from collections import Counter
from pathlib import Path
import json
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
source_file = 'tools/scenarios/watchdog_fight_scenario.gd'
expected = (base / 'baseline.txt').read_text().strip()
expected_digest = json.loads((base / 'source.json').read_bytes())[source_file]
cases = [f'final-{device}-{difficulty}' for device in ('mouse', 'pad') for difficulty in range(3)]
all_cases = cases + ['native-movie']
pattern = re.compile(r'^WATCHDOG_FIGHT difficulty=(\w+) result=(\w+) time=([\d.]+)s damage_taken=(\d+)'
                     r' hits=(\d+) deaths_equiv=(\d+) yanks=(\d+) back_hits=(\d+) blocked_shots=(\d+)', re.M)


def result(label):
    folder = base / label
    raw = (folder / 'engine.log').read_text(encoding='utf-8', errors='replace')
    entry, = pattern.findall(raw)
    assert not re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit', raw, re.M), label
    data = json.loads((folder / 'fight.json').read_bytes())
    assert '9070' in data['adapter'] and data['rendering_method'] == 'forward_plus' and data['hdr']
    difficulty, outcome = entry[:2]
    seconds = float(entry[2])
    damage, hits, equivalent_deaths, yanks, back_hits, blocked = map(int, entry[3:])
    samples = data['trace']
    assert samples and [r[0] for r in samples] == list(range(2, 2 * len(samples) + 1, 2)), label
    phase = Counter(r[1] for r in samples)
    assert data['alive'] == (outcome == 'timeout'), label
    if label != 'standard':
        assert (folder / 'source.txt').read_text().strip() == expected
        assert (folder / 'scenario-sha.txt').read_text().strip() == expected_digest
        assert outcome == 'win' and back_hits > 0 and sorted(phase) == [0, 1, 2], label
        details = folder / 'joints.json'
        if not details.is_file():
            subprocess.run([sys.executable, '-B', str(base / 'joints.py'), str(folder)], check=True)
        geometry = json.loads(details.read_bytes())
    else:
        assert outcome == 'timeout' and back_hits == 0
        geometry = json.loads((folder / 'joints.json').read_bytes())
    return dict(label=label, difficulty=difficulty, outcome=outcome, seconds=seconds, damage=damage,
                hits=hits, equivalent_deaths=equivalent_deaths, yanks=yanks, back_hits=back_hits, blocked=blocked,
                phase_samples=phase, facings=sorted({r[5] for r in samples}),
                poses=sorted({r[4] for r in samples}), joint_samples=sum(geometry['tested'].values()),
                flags=len(geometry['flags']))

summary = {case: result(case) for case in ['standard', *all_cases]}
(base / 'results.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
for label, row in summary.items():
    print(label, row['seconds'], row['damage'], row['back_hits'], row['joint_samples'], row['flags'], row['facings'])
