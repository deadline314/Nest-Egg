extends WatchdogFightScenario

var _parts: Array[String] = []
var _sprites: Array[Sprite2D] = []
var _trace: Array = []
var _capture_frames: Dictionary = {}
var _sample_frame := 0


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
	if not out_dir.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	seed(218253)
	Settings.use_storage("user://watchdog_native.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Story.auto_skip = true
	add_child(LightKit.create_environment())
	run.call_deferred()


func _drive() -> void:
	super._drive()
	if not is_instance_valid(_dog.creature) or _dog.creature.creature_id != "watchdog":
		return
	if _sprites.is_empty():
		for part_name: String in _dog.creature.part_names():
			var sprite := _dog.creature.joint_of(part_name).get_child(0) as Sprite2D
			if sprite == null or sprite.texture == null:
				push_error("Watchdog part has no runtime texture: " + part_name)
				get_tree().quit(3)
				return
			_parts.append(part_name)
			_sprites.append(sprite)
	_sample_frame += 1
	if _sample_frame % 2 != 0:
		return
	var pose: Array = []
	var origin := _dog.global_position
	for sprite: Sprite2D in _sprites:
		if not sprite.is_visible_in_tree():
			pose.append(null)
			continue
		var matrix := sprite.global_transform
		var corner := matrix * sprite.offset - origin
		pose.append([matrix.x.x, matrix.x.y, matrix.y.x, matrix.y.y, corner.x, corner.y])
	_trace.append([_sample_frame, _dog.phase, String(_dog.fsm.current), String(_dog.current_move()),
		String(_dog.creature.state), _dog.facing, _dog.health.current, _dog.is_on_floor(),
		[origin.x, origin.y], pose])


func _capture_now(label: String) -> void:
	_capture_frames[label] = _sample_frame
	super._capture_now(label)


func finish() -> void:
	var won := not is_instance_valid(_dog) or _dog.is_dying()
	var output := FileAccess.open(out_dir.path_join("fight.json"), FileAccess.WRITE)
	if output == null:
		get_tree().quit(2)
		return
	output.store_string(JSON.stringify({"parts": _parts, "trace": _trace, "events": _events,
		"capture_frames": _capture_frames, "adapter": RenderingServer.get_video_adapter_name(),
		"rendering_method": RenderingServer.get_current_rendering_method(), "hdr": get_viewport().use_hdr_2d,
		"alive": not won}, "", true, true) + "\n")
	output.close()
	if _sprites.is_empty() or _trace.is_empty():
		get_tree().quit(3)
		return
	AudioRelease.begin_shutdown()
	await super.finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if won and failures == 0 else 1)
