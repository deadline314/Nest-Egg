from argparse import ArgumentParser
from collections import Counter, defaultdict
from pathlib import Path
import json

import cv2
import numpy as np
from PIL import Image

parser = ArgumentParser()
parser.add_argument('folder', type=Path)
parser.add_argument('--root', type=Path, default=Path.cwd())
args = parser.parse_args()
manifest = json.loads((args.root / 'art/creatures/watchdog.json').read_bytes())
textures = args.root / manifest['dir'].removeprefix('res://')
data = json.loads((args.folder / 'fight.json').read_bytes())
by_name = {part['name']: part for part in manifest['parts']}
names = data['parts']
assert set(names) == set(by_name) and len(names) == len(by_name)
child_specs = [(name, by_name[name]['parent']) for name in names if 'parent' in by_name[name]]
alpha = {part['name']: np.asarray(Image.open(textures / part['file']).convert('RGBA'))[..., 3].copy()
         for part in by_name.values()}
step = 0.125
threshold = 128
radius = 8.0
axis = np.arange(-radius, radius + step, step, dtype=np.float32)
delta_x, delta_y = np.meshgrid(axis, axis)
disk = (delta_x ** 2 + delta_y ** 2) <= radius ** 2


def mask(name, matrix, x, y):
    ax, ay, bx, by, tx, ty = matrix
    determinant = ax * by - ay * bx
    dx = x - tx
    dy = y - ty
    map_x = ((by * dx - bx * dy) / determinant - 0.5).astype(np.float32)
    map_y = ((ax * dy - ay * dx) / determinant - 0.5).astype(np.float32)
    return (cv2.remap(alpha[name], map_x, map_y, cv2.INTER_LINEAR) >= threshold) & disk


hits = []
counts = Counter()
tested = Counter()
state_frames = Counter()
for frame, phase, state, move, pose, facing, health, floor, _, matrices in data['trace']:
    state_frames[(phase, state, pose, facing)] += 1
    transforms = dict(zip(names, matrices, strict=True))
    for name, parent in child_specs:
        child_matrix, parent_matrix = transforms[name], transforms[parent]
        if child_matrix is None:
            assert name == 'turret' and phase >= 1, (name, frame, phase)
            continue
        assert parent_matrix is not None, (name, parent, frame)
        ax, ay, bx, by, tx, ty = child_matrix
        px, py = by_name[name]['pivot']
        center_x, center_y = tx + ax * px + bx * py, ty + ay * px + by * py
        x, y = delta_x + center_x, delta_y + center_y
        child_mask, parent_mask = mask(name, child_matrix, x, y), mask(parent, parent_matrix, x, y)
        tested[name] += 1
        if (child_mask & parent_mask).any():
            continue
        if child_mask.any() and parent_mask.any():
            distance = cv2.distanceTransform((~parent_mask).astype(np.uint8), cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
            gap = float(distance[child_mask].min()) * step
            if gap <= 0.375:
                continue
        else:
            gap = None
        counts[name] += 1
        hits.append(dict(frame=frame, phase=phase, state=state, move=move, pose=pose, facing=facing, part=name,
                         gap_world=gap, child=int(child_mask.sum()), parent=int(parent_mask.sum())))

report = {'resolution_world': step, 'solid_min_alpha': threshold, 'radius_world': radius, 'tested': dict(tested),
          'counts': dict(counts), 'state_frames': [{'phase': p, 'state': s, 'pose': a, 'facing': f, 'frames': n}
                                                   for (p, s, a, f), n in sorted(state_frames.items())], 'flags': hits}
(args.folder / 'joints.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(sum(tested.values()), 'paired samples;', sum(counts.values()), 'flags', counts)
by_part = defaultdict(list)
for item in hits:
    by_part[item['part']].append(item)
for name, values in by_part.items():
    finite = sorted(filter(lambda row: row['gap_world'] is not None, values), key=lambda row: row['gap_world'])
    print(name, 'states', Counter((row['state'], row['pose']) for row in values), 'max', finite[-1] if finite else None)
