from pathlib import Path
from hashlib import sha256
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
root = Path.cwd()
output = base / sys.argv[1]
output.mkdir()
profile = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP', 'TMPDIR'):
    folder = output / key
    folder.mkdir()
    profile[key] = str(folder)
sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
(output / 'source.txt').write_text(sha + '\n', encoding='utf-8')
path = root / 'tools/scenarios/watchdog_fight_scenario.gd'
(output / 'scenario-sha.txt').write_text(sha256(path.read_bytes()).hexdigest() + '\n', encoding='utf-8')
(output / 'scenario.gd').write_bytes(path.read_bytes())
godot = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
record_movie = '--movie' in sys.argv[2:]
movie = ['--write-movie', str(output / 'fight.avi')] if record_movie else []
options = [arg for arg in sys.argv[2:] if arg != '--movie']
args = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--', godot,
        '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan',
        '--fixed-fps', '60', '--resolution', '1280x720', '--audio-driver', 'Dummy', *movie,
        '--quit-after', '18360', str(base / 'fight.tscn'), '--', f'--out={output}', *options]
with (output / 'engine.log').open('wb') as log:
    result = subprocess.run(args, env=profile, stdout=log, stderr=subprocess.STDOUT, timeout=800)
raw = (output / 'engine.log').read_text(encoding='utf-8', errors='replace')
print(raw[-10000:])
assert result.returncode == 0 and not re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit', raw, re.M)
data = json.loads((output / 'fight.json').read_bytes())
assert data['rendering_method'] == 'forward_plus' and '9070' in data['adapter'] and data['hdr']
assert data['trace'] and not data['alive'] and 'result=win' in raw
print(len(data['trace']), '2-frame samples; phases', sorted({row[1] for row in data['trace']}))
