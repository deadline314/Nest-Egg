extends Node
## 序章真輸入探針（ST-16）：從真正的 Main 新遊戲入口開始，用移動、跳躍、射擊、近戰、格擋、衝刺與互動鍵玩完序章，
## 走出店門進當舖，沿途截圖並檢查每一項練習是否靠真的動作完成。瞄準用手把右搖桿的輸入（AimInput 的手把路徑）。
## 用法：godot --path . res://tools/prologue_play_probe.tscn -- --out=<絕對路徑資料夾>
##   [--save-dir=<絕對路徑>]：存檔寫到這個資料夾（不碰玩家的存檔），供 prologue_resume_probe 在另一個程序繼續。
##   [--stop-after=<旗標>]：練到這個旗標就像玩家一樣從 Main 正常退出（會存檔）。
##   [--gamepad]：先送一個真的手把按鍵事件，提示改顯示手把按鍵（截圖檔名加 -pad）。

const LIMIT := 1800

var _out := ""
var _main: Node
var _failures := 0
var _played: Array[StringName] = []
var _save_dir := ""
var _stop_after := &""
var _gamepad := false


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--save-dir="):
			_save_dir = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--stop-after="):
			_stop_after = StringName(arg.trim_prefix("--stop-after="))
		elif arg == "--gamepad":
			_gamepad = true
	if not _save_dir.is_empty() and (not _save_dir.is_absolute_path() or DirAccess.make_dir_recursive_absolute(_save_dir) != OK):
		push_error("[ProloguePlayProbe] --save-dir 要是可寫入的絕對路徑：%s" % _save_dir)
		get_tree().quit(2)
		return
	if not _out.is_empty():
		DirAccess.make_dir_recursive_absolute(_out)
	_run.call_deferred()


func _check(ok: bool, what: String) -> void:
	print("%s %s" % ["PASS" if ok else "FAIL", what])
	if not ok:
		_failures += 1


var _accept_radio := false
var _radio_ticks := 0
var _radio_captured := false

func _frames(n: int) -> void:
	for i in n:
		await get_tree().physics_frame
		if _accept_radio and Story._layer.is_radio_frozen():
			_radio_ticks += 1
			if _radio_ticks == 10 and not _radio_captured:
				await _capture_route_radio()
			if _radio_ticks > 15 and _radio_ticks % 12 == 0:
				_send_action(&"ui_accept")
		else:
			_radio_ticks = 0


func _send_action(action: StringName) -> void:
	var key := InputEventAction.new()
	key.action = action
	key.pressed = true
	Input.parse_input_event(key)
	var release := InputEventAction.new()
	release.action = action
	Input.parse_input_event(release)


func _shot(name: String) -> void:
	print("SHOT %s gamepad=%s" % [name, InputBindings.using_gamepad])
	if _out.is_empty() or DisplayServer.get_name() == "headless":
		return
	if _gamepad:
		name += "-pad"
	await _frames(4)
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	print("saved %s (%s)" % [name, error_string(image.save_png(_out.path_join(name + ".png")))])


func _level() -> Level:
	var screen: Variant = _main.get("_screen")
	return screen as Level if screen is Level else null


func _player() -> Player:
	var level := _level()
	return level.player if level != null else null


## 玩家讀完演出就按略過（等同 Esc）；選擇題選預設。
func _finish_story(shot := "") -> void:
	var shown := false
	for i in LIMIT:
		if not Story.is_cinematic_active():
			return
		if not shot.is_empty() and not shown:
			await _frames(60)
			await _shot(shot)
			shown = true
		Story.skip_cinematic()
		await _frames(6)


func _walk_to(x: float, tolerance := 6.0) -> void:
	for i in LIMIT:
		var player := _player()
		if player == null:
			return
		await _finish_story()
		var dx := x - player.global_position.x
		if absf(dx) <= tolerance:
			break
		var action := &"move_right" if dx > 0.0 else &"move_left"
		Input.action_press(action)
		await _frames(1)
		Input.action_release(action)
	Input.action_release(&"move_right")
	Input.action_release(&"move_left")
	await _frames(4)


func _press(action: StringName, hold := 2) -> void:
	Input.action_press(action)
	await _frames(hold)
	Input.action_release(action)
	await _frames(2)


func _aim(direction: Vector2) -> void:
	AimInput.using_gamepad = true
	for name in [&"aim_left", &"aim_right", &"aim_up", &"aim_down"]:
		Input.action_release(name)
	if direction.x > 0.0:
		Input.action_press(&"aim_right", direction.x)
	elif direction.x < 0.0:
		Input.action_press(&"aim_left", -direction.x)
	if direction.y < 0.0:
		Input.action_press(&"aim_up", -direction.y)
	elif direction.y > 0.0:
		Input.action_press(&"aim_down", direction.y)


func _station(id: StringName) -> TrainingStation:
	for node in _level().find_children("*", "TrainingStation", true, false):
		if (node as TrainingStation).data.id == id:
			return node
	return null


func _npc(id: StringName) -> NpcActor:
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if (node as NpcActor).data.id == id:
			return node
	return null


## 送一個真的手把按鍵事件（像玩家拿起手把按了一下），讓提示改顯示手把的按鍵。
func _touch_gamepad() -> void:
	var press := InputEventJoypadButton.new()
	press.device = 0
	press.button_index = JOY_BUTTON_GUIDE
	press.pressed = true
	Input.parse_input_event(press)
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	Input.parse_input_event(release)
	await _frames(2)


## 練到 --stop-after 指定的旗標時，從 Main 正常退出（Main 退出前會存檔）。回傳 true 代表探針已結束。
func _stop_if(flag: StringName) -> bool:
	if _stop_after != flag or not GameState.has_flag(flag):
		return false
	print("PROLOGUE_STOPPED_AT %s level=%s deaths=%d" % [flag, _level().data.resource_path if _level() != null else "", GameState.deaths])
	print("PROLOGUE_PLAY_PROBE failures=%d" % _failures)
	_main.call("_quit", 1 if _failures > 0 else 0)
	return true


func _wait_flag(flag: StringName, frames := 600) -> bool:
	for i in frames:
		if GameState.has_flag(flag):
			return true
		await _frames(1)
	return GameState.has_flag(flag)


func _run() -> void:
	if "--from-save" in OS.get_cmdline_user_args():
		await _route_from_save()
		return
	Story.scene_started.connect(func(id: StringName, _mode: StringName) -> void: _played.append(id))
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	if not _save_dir.is_empty():
		_main.set("_run_store", RunSaveStore.new(_save_dir.path_join("slot.json")))
	add_child(_main)
	await _frames(30)
	# 軟體算圖時選單轉場很慢：轉場還沒結束時 Main 會忽略開始，所以每秒重按一次，最多等兩分鐘。
	var deadline := Time.get_ticks_msec() + 120000
	var started := false
	while Time.get_ticks_msec() < deadline and (_level() == null or _player() == null):
		if not started and not bool(_main.call("_route_pending")):
			_main.call("_on_start_requested", GameState.difficulties[1])
			started = _main.get("_active_run")
		await _frames(30)
	var level := _level()
	_check(level != null and level.data.resource_path == "res://data/levels/ch1_prologue.tres", "a new game from Main enters the prologue")
	if level == null:
		print("PROLOGUE_PLAY_PROBE failures=%d" % _failures)
		get_tree().quit(1)
		return
	await _frames(90)
	await _finish_story("ST-16-p01-door")
	var deaths := GameState.deaths
	# 暫停選單的略過：短按先確認（預設焦點「繼續練習」），這裡取消，回到原步、不改進度。
	var menu: PauseMenu = level._pause_menu
	for i in LIMIT:
		if not GameplayLock.is_locked() and not Story.is_cinematic_active():
			break
		await _frames(1)
	await _frames(30)
	# 演出會吃掉確認鍵，所以等操作交回玩家才拿起手把按一下（像玩家一樣），之後的提示都改顯示手把按鍵。
	if _gamepad:
		await _touch_gamepad()
	menu.open()
	_check(menu._root.visible, "the pause menu opens once the opening hands over control")
	menu._skip_button.button_down.emit()
	menu._skip_button.button_up.emit()
	menu._skip_button.pressed.emit()
	await _frames(40)  # 選單有淡入動畫
	await _shot("ST-16-skip-confirm")
	menu._cancel_skip()
	menu.close()
	_check(not GameState.has_flag(&"ch1_prologue_skipped"), "cancelling the prologue skip keeps the practice")
	# P01→P02：走到工作桌（真的移動才算），再跳上兩格高的搬貨台。
	var bench := _station(&"ch1_training_workbench")
	await _walk_to(bench.global_position.x)
	_check(await _wait_flag(&"ch1_prologue_bench_done", 60), "walking to the workbench completes the movement practice")
	if _stop_if(&"ch1_prologue_bench_done"):
		return
	await _finish_story("ST-16-p02-talk")
	var platform := _station(&"ch1_training_platform")
	# 像玩家一樣：沒跳上去就退回助跑再跳（最多四次）。
	for attempt in 4:
		await _walk_to(platform.global_position.x - 46.0, 4.0)
		await _frames(20)
		if attempt == 0:
			await _shot("ST-16-p02-jump-prompt")
		Input.action_press(&"move_right")
		Input.action_press(&"jump")
		# 像玩家一樣在空中收方向：到了搬貨台上方就放開右鍵，落在台上。
		for i in 70:
			if i == 16:
				Input.action_release(&"jump")
			if _player().global_position.x >= platform.global_position.x - 6.0:
				Input.action_release(&"move_right")
			if GameState.has_flag(&"ch1_prologue_jump_done"):
				break
			await _frames(1)
		Input.action_release(&"jump")
		Input.action_release(&"move_right")
		if GameState.has_flag(&"ch1_prologue_jump_done"):
			break
		var p := _player()
		print("jump attempt %d missed: player %s state %s, platform %s, locked %s, story %s" % [attempt, p.global_position, p.state, platform.global_position, GameplayLock.is_locked(), Story.is_cinematic_active()])
	_check(await _wait_flag(&"ch1_prologue_jump_done", 60), "a real jump onto the cargo platform completes the jump practice")
	if _stop_if(&"ch1_prologue_jump_done"):
		return
	await _finish_story()
	# P03：射擊線，用手把瞄準右方開槍打低靶。
	var range_mark := _station(&"ch1_training_range")
	await _walk_to(range_mark.global_position.x)
	await _finish_story("ST-16-p03-range")
	_check(_npc(&"ch1_old_k_backyard").is_present() and not _npc(&"ch1_old_k_prologue").is_present(), "Old K moves to the backyard line once the tool is down")
	var target := _station(&"ch1_training_target")
	await _walk_to(target.global_position.x - 120.0)
	_aim(Vector2.RIGHT)
	await _frames(10)
	await _shot("ST-16-p03-aim")
	for i in 6:
		await _press(&"shoot", 3)
		if GameState.has_flag(&"ch1_prologue_shot_done"):
			break
		await _frames(20)
	_check(await _wait_flag(&"ch1_prologue_shot_done", 120), "a real shot hits the low target")
	if _stop_if(&"ch1_prologue_shot_done"):
		return
	await _finish_story()
	# P04：橡膠靶近戰、訓練器格擋（先被打停一次，再舉盾擋下）、衝刺穿線。
	var area := _station(&"ch1_training_area")
	await _walk_to(area.global_position.x)
	await _finish_story("ST-16-p04-intro")
	var dummy := _station(&"ch1_training_dummy")
	await _walk_to(dummy.global_position.x - 22.0)
	_aim(Vector2.RIGHT)
	for i in 6:
		await _press(&"melee", 3)
		if GameState.has_flag(&"ch1_prologue_melee_done"):
			break
		await _frames(20)
	_check(await _wait_flag(&"ch1_prologue_melee_done", 120), "a real melee hit on the rubber dummy")
	if _stop_if(&"ch1_prologue_melee_done"):
		return
	await _finish_story()
	var trainer := _station(&"ch1_training_trainer")
	await _walk_to(trainer.global_position.x - 34.0)
	var health := _player().health.current
	for i in 300:
		if GameState.has_flag(&"ch1_prologue_fall_shown"):
			break
		if trainer._phase == &"warn" and i % 30 == 0:
			await _shot("ST-16-p04-trainer-warn")
		await _frames(1)
	_check(GameState.has_flag(&"ch1_prologue_fall_shown") and _player().health.current == health and GameState.deaths == deaths, "an unblocked strike stops the trainer without hurting or killing")
	await _finish_story("ST-16-p04-fall")
	_aim(Vector2.RIGHT)
	Input.action_press(&"block")
	_check(await _wait_flag(&"ch1_prologue_guard_done", 600), "holding block toward the trainer blocks its strike")
	if _stop_if(&"ch1_prologue_guard_done"):
		return
	Input.action_release(&"block")
	await _finish_story()
	var dash := _station(&"ch1_training_dash")
	await _walk_to(dash.global_position.x - 40.0)
	Input.action_press(&"move_right")
	await _frames(2)
	await _press(&"dash", 3)
	await _frames(20)
	Input.action_release(&"move_right")
	_check(await _wait_flag(&"ch1_prologue_dash_done", 120), "a real dash across the training line")
	if _stop_if(&"ch1_prologue_dash_done"):
		return
	await _finish_story()
	# P05→P06：回櫃台和老 K 說話兩次，從旁邊的門回店裡。
	var old_k := _npc(&"ch1_old_k_counter")
	_check(old_k.is_present() and not _npc(&"ch1_old_k_backyard").is_present(), "Old K is back at the counter after the dash")
	await _walk_to(old_k.global_position.x + 14.0)
	await _press(&"interact")
	await _finish_story("ST-16-p05-service")
	_check(GameState.has_flag(&"ch1_prologue_service_heard"), "Old K explains the recovery service")
	await _frames(70)
	await _press(&"interact")
	await _finish_story("ST-16-p06-call")
	_check(GameState.has_flag(&"ch1_prologue_exit"), "the wrap-up call hands over the exit")
	if _stop_if(&"ch1_prologue_exit"):
		return
	var exit: Portal = _level()._portals.get(&"prologue_exit")
	await _walk_to(exit.global_position.x)
	await _press(&"interact")
	deadline = Time.get_ticks_msec() + 120000
	while Time.get_ticks_msec() < deadline and not (_level() != null and _level().data.resource_path == "res://data/levels/ch1_pawnshop.tres" and _player() != null):
		await _frames(1)
	await _frames(150)
	await _shot("ST-16-pawnshop-arrival")
	_check(_level() != null and _level().data.resource_path == "res://data/levels/ch1_pawnshop.tres", "the prologue door leads into the pawnshop")
	_check(GameState.deaths == 0 and not GameState.has_flag(&"ch1_first_death_done"), "the prologue never counted a death or the first registration")
	var missing := PacingEstimate.PROLOGUE_PATH.filter(func(id: StringName) -> bool: return not _played.has(id))
	_check(missing.is_empty(), "the pacing path matches the scenes a real run plays (missing %s)" % [missing])
	if _failures == 0:
		if "--street" in OS.get_cmdline_user_args():
			await _chapter_one_street()
		else:
			await _chapter_one_start()
	print("NE97_ROUTE %s deaths=%d failures=%d" % [_visits, GameState.deaths, _failures])
	print("PROLOGUE_PATH_PLAYED %s" % [_played])
	print("PROLOGUE_PLAY_PROBE failures=%d" % _failures)
	if not _save_dir.is_empty():
		_main.call("_quit", 1 if _failures > 0 else 0)
	else:
		get_tree().quit(1 if _failures > 0 else 0)


var _visits: Array[String] = []


func _chapter_one_start() -> void:
	print("NE97_JOYPADS ", Input.get_connected_joypads())
	_visits.append(_level().data.resource_path.get_file())
	await _walk_to(1378.0)
	for tick in 1200:
		if GameState.has_flag(&"ch1_dinner_done"):
			break
		await _frames(1)
	await _shot("ne97-dinner")
	if not _assert_route(GameState.has_flag(&"ch1_dinner_done"), "walked into the free dinner"):
		return
	if not await _route_portal(&"pawn_stairs"):
		return
	await _walk_to(210.0)
	await _route_jump(1, 30)
	await _walk_to(451.0)
	await _route_jump(1, 28)
	await _walk_to(54.0 * 16.0 - 14.0)
	await _press(&"interact")
	await _finish_story("ne97-rooftop-brief")
	if not _assert_route(GameState.has_flag(&"ch1_heard_brief"), "actually interacted with Egret on the rooftop"):
		return
	await _walk_to(508.0)
	await _route_jump(-1, 29)
	await _walk_to(277.0)
	await _route_jump(-1, 30)
	if not await _route_portal(&"roof_stairs"):
		return
	if not await _route_portal(&"pawn_front"):
		return
	await _walk_to(34.0 * 16.0 + 8.0)
	if not await _route_portal(&"street_booth"):
		return
	await _route_checkpoint()
	await _route_portal(&"booth_street")


func _assert_route(ok: bool, label: String) -> bool:
	var description := "no active player" if _player() == null else "%s at %s health=%d" % [_level().data.id, _player().global_position, _player().health.current]
	_check(ok, "NE97 %s [%s]" % [label, description])
	return ok


func _route_jump(direction: int, ticks: int) -> void:
	var move := &"move_right" if direction > 0 else &"move_left"
	Input.action_press(move)
	Input.action_press(&"jump")
	await _frames(ticks)
	Input.action_release(&"jump")
	Input.action_release(move)
	await _frames(12)


func _route_portal(id: StringName) -> bool:
	var current := _level()
	var portal: Portal = current._portals.get(id)
	if not _assert_route(portal != null, "found portal %s" % id):
		return false
	var destination := portal.data.target_level
	for tick in 1300:
		if _level() != current or _player() == null:
			break
		var dx := portal.global_position.x - _player().global_position.x
		if absf(dx) <= 6.0:
			break
		var movement := &"move_right" if dx > 0.0 else &"move_left"
		Input.action_press(movement)
		await _frames(1)
		Input.action_release(movement)
	if _level() == current and is_instance_valid(portal):
		await _press(&"interact")
	for tick in 2400:
		if _level() != null and _level().data.resource_path == destination and _player() != null:
			await _frames(30)
			await _finish_story()
			_visits.append(destination.get_file())
			await _shot("ne97-%s" % id)
			return _assert_route(true, "entered through %s" % id)
		await _frames(1)
	return _assert_route(false, "could not enter through %s" % id)


func _route_checkpoint() -> void:
	var booth := _level().find_children("*", "Checkpoint", true, false).front() as Checkpoint
	await _walk_to(booth.global_position.x)
	await _press(&"interact")
	for tick in 600:
		if Story._layer.is_radio_frozen():
			Story._layer.advance_radio()
		if GameState.has_flag(&"ch1_recording_heard"):
			break
		await _frames(1)
	_assert_route(GameState.has_flag(&"ch1_recording_heard"), "activated the authored checkpoint and finished its recording")


func _route_from_save() -> void:
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_main.set("_run_store", RunSaveStore.new(_save_dir.path_join("slot.json")))
	add_child(_main)
	for tick in 2400:
		var menu := _main.get("_screen") as MainMenu
		if menu != null and menu.is_inside_tree() and not _main.call("_route_pending") and menu._continue_button != null and menu._continue_button.has_focus():
			break
		await _frames(1)
	var menu := _main.get("_screen") as MainMenu
	if not _assert_route(menu != null and is_instance_valid(menu._continue_button) and menu.is_visible_in_tree(), "the real Continue button is available"):
		_main.call("_quit", 2)
		return
	await _frames(24)
	menu._continue_button.pressed.emit()
	for tick in 2400:
		if _player() != null:
			break
		await _frames(1)
	if _assert_route(_player() != null, "continued from the actual earlier main slot"):
		await _frames(30)
		if "--street" in OS.get_cmdline_user_args():
			await _chapter_one_street()
		else:
			await _chapter_one_start()
	print("NE97_ROUTE %s deaths=%d failures=%d" % [_visits, GameState.deaths, _failures])
	_main.call("_quit", 1 if _failures > 0 else 0)


func _chapter_one_street() -> void:
	if not _assert_route(_level().data.id == &"ch1_street", "continued on the actual street"):
		return
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	_aim(Vector2.RIGHT)
	_accept_radio = true
	for step in [[42.75, 46.4], [46.6, 51.9], [51.9, 55.2], [55.2, 59.9]]:
		await _walk_to(step[0] * 16.0, 5.0)
		print("NE97_STREET_JUMP_FROM ", _player().global_position, " grounded=", _player().is_on_floor())
		await _fight_jump(step[1] * 16.0)
		print("NE97_STREET_STEP ", step, " at ", _player().global_position, " hp=", _player().health.current)
	if not _assert_route(_player().global_position.y < 610.0, "climbed the street terraces using jump and movement"):
		return
	await _shot("ne97-street-approach")
	if "--landmark-only" in OS.get_cmdline_user_args():
		_assert_route(_radio_captured and GameState.has_flag(&"ch1_dinner_done") and GameState.has_flag(&"ch1_heard_brief"),
			"started and cleared the frozen street call using Accept and reached the first encounter approach")
		return
	for step in [71.0, 84.0, 104.0, 120.0, 137.0]:
		if not await _fight_step(step*16.0, 1200):
			return
	await _shot("ne97-street-plaza")
	print("NE97_STREET_PREBLOCKADE ", _player().global_position)


func _fight_jump(target_x: float) -> void:
	var player := _player()
	var direction := &"move_right" if target_x >= player.global_position.x else &"move_left"
	Input.action_press(direction)
	Input.action_press(&"jump")
	var passed := false
	for tick in 190:
		if _player() != player:
			break
		if not passed and absf(player.global_position.x - target_x) < 6.0:
			passed = true
			Input.action_release(direction)
		if not GameplayLock.is_locked() and tick >= 17 and player.is_on_floor():
			break
		await _frames(1)
	Input.action_release(direction)
	Input.action_release(&"jump")
	await _frames(4)


func _fight_step(target_x: float, ticks: int) -> bool:
	var player := _player()
	for tick in ticks:
		if _player() != player or player.is_dead():
			break
		var delta_x := target_x - player.global_position.x
		if absf(delta_x) < 8.0:
			break
		var nearest: Enemy
		var best := 250.0 * 250.0
		var from := player.aim_origin()
		for node in get_tree().get_nodes_in_group(&"enemies"):
			var enemy := node as Enemy
			if enemy == null or enemy.is_dying():
				continue
			var to := enemy.hurtbox.center()
			var distance := from.distance_squared_to(to)
			if distance >= best:
				continue
			var ray := PhysicsRayQueryParameters2D.create(from, to, Layers.WORLD)
			if not player.get_world_2d().direct_space_state.intersect_ray(ray).is_empty():
				continue
			nearest = enemy
			best = distance
		if nearest != null:
			_aim((nearest.hurtbox.center() - from).normalized())
			Input.action_press(&"shoot")
			if best < 48.0 * 48.0 and tick % 24 == 0:
				Input.action_press(&"melee")
		else:
			Input.action_release(&"shoot")
		var movement := &"move_right" if delta_x > 0.0 else &"move_left"
		if nearest == null or best > 136.0*136.0:
			Input.action_press(movement)
		await _frames(1)
		Input.action_release(movement)
		Input.action_release(&"melee")
	Input.action_release(&"shoot")
	return _assert_route(_player() == player and not player.is_dead() and absf(player.global_position.x-target_x) < 10.0, "combat walking reaches X %.1f" % target_x)


func _capture_route_radio() -> void:
	var player := _player()
	var queue: Array = Story._layer.get("_radio_queue")
	if player == null or queue.is_empty() or queue.front()["id"] != &"ch1_g06_lamp":
		return
	_radio_captured = true
	var row := {"has_lock": Story._layer.is_radio_frozen(), "scene": str(queue.front()["id"]),
		"has_floor": player.is_on_floor(), "px": player.global_position.x, "py": player.global_position.y,
		"vy": player.velocity.y, "hp": player.health.current, "deaths": GameState.deaths,
		"renderer": RenderingServer.get_current_rendering_method(), "adapter": RenderingServer.get_video_adapter_name()}
	print("NE97_RADIO ", JSON.stringify(row))
	if not _out.is_empty() and DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		var frame := preload("res://tools/viewport_capture.gd").image(get_viewport())
		_check(frame.save_png(_out.path_join("ne97-street-radio.png")) == OK, "saved the real first street radio frame")
