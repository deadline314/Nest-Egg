from pathlib import Path
from statistics import median
import json
from math import dist

d=Path(__file__).resolve().parent
rows={}
for weapon in ('maul','whip'):
    runs=[json.loads((d/f'{tag}-{weapon}'/'contact-result.json').read_bytes()) for tag in ('before','after')]
    assert runs[0]['checks']==runs[1]['checks'] and all(x['failures']==[] for x in runs)
    for old,new in zip(*(x['rows'] for x in runs),strict=True):
        assert old['name']==new['name'] and old['side']==new['side']
        a,b=old['frames'],new['frames']
        first_ticks=[a[0]['tick'],b[0]['tick']]
        for x,y in zip(a,b,strict=True):
            assert x['tick']-first_ticks[0] == y['tick']-first_ticks[1]
            shared=('phase','progress','velocity','visible_progress','held_input','hold_mode','charged','on_floor','camera_position','camera_zoom')
            assert all(x[key]==y[key] for key in shared),(old['name'],x['tick']-first_ticks[0])
        assert old['contact_first_image'] == new['contact_first_image'] and old['contact_first_image']
        lhs,rhs = old['contact_hits'],new['contact_hits']
        assert lhs and rhs
        sample_drift = {'point':0.0, 'current':0.0, 'previous':0.0}
        for hit1,hit2 in zip(lhs,rhs,strict=True):
            for key in ('tick','mesh_tick','previous_tick'):
                assert hit1[key]-first_ticks[0] == hit2[key]-first_ticks[1]
            stable=('time','phase','window','from_fraction','to_fraction','amount','target_hp','part','source','target_transform','target_area_in_space')
            assert all(hit1[key]==hit2[key] for key in stable),(old['name'],stable)
            sample_drift['point'] = max(sample_drift['point'], dist(hit1['point'],hit2['point']))
            for key in ('current','previous'):
                limit = max(dist(x,y) for x,y in zip(hit1[key],hit2[key],strict=True))
                sample_drift[key] = max(sample_drift[key],limit)
        sfx = lambda x, zero: [(s['id'],s['matching'],s['tick']-zero) for s in x['contact_sounds']]
        assert sfx(old,first_ticks[0]) == sfx(new,first_ticks[1])
        rows[old['name']]={'frames':len(a),'contacts':len(lhs),'points':[x['point'] for x in lhs],
                           'amounts':[x['amount'] for x in lhs],'image':old['contact_first_image'],'independent_run_max_delta':sample_drift}

line=next(x[len('VERIFIED '):] for x in (d/'run.log').read_text('utf-8').splitlines() if x.startswith('VERIFIED '))
bench=json.loads(line)
assert len(bench)==5 and all(x['samples']==320 and x['contacts_checked']==1280 for x in bench.values())
for values in bench.values():
    values['old_median_us']=median(values['load_original_us'])
    values['new_median_us']=median(values['load_candidate_us'])
    assert values['new_median_us'] < values['old_median_us']
report={'rendered_cases':rows,'microbenchmark':bench}
(d/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))