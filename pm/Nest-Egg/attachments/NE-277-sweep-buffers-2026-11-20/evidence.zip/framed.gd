extends "res://tools/ne277_contact_probe.gd"


func _ready() -> void:
	seed(20261120)
	super._ready()


func _move(id: String, weapon: WeaponData, set: MeleeSet, move: String, side: int, held: bool) -> void:
	_camera.zoom = Vector2.ONE * 1.6
	await super._move(id, weapon, set, move, side, held)