extends "D:/NestEggVerification/evidence-20261120-ne277-sweep-buffers/framed.gd"

var _checked: SynchronizedSweep


class SynchronizedSweep extends "res://core/melee_contact_sweep.gd":
	const Stock = preload("D:/NestEggVerification/evidence-20261120-ne277-sweep-buffers/stock_sweep.gd")
	var old := Stock.new()
	var captures := 0
	var contacts := 0
	var failed := 0
	var _inside_capture := false

	func clear() -> void:
		super.clear()
		if not _inside_capture:
			old.clear()

	func capture(weapon: WeaponData, xf: Transform2D, facing: int, rope: SoftWhip, canvas: Transform2D, span := Vector2(-512.0, 512.0)) -> void:
		_inside_capture = true
		super.capture(weapon, xf, facing, rope, canvas, span)
		_inside_capture = false
		old.capture(weapon, xf, facing, rope, canvas, span)
		captures += 1
		if old.previous != previous or old.current != current or old.tick != tick or old.previous_tick != previous_tick:
			failed += 1

	func contact(box: Hurtbox, from_fraction := 0.0, to_fraction := 1.0) -> Vector2:
		var point := super.contact(box, from_fraction, to_fraction)
		contacts += 1
		if point != old.contact(box, from_fraction, to_fraction):
			failed += 1
		return point


func _move(id: String, weapon: WeaponData, set: MeleeSet, move: String, side: int, held: bool) -> void:
	if _checked == null:
		_checked = SynchronizedSweep.new()
		player._visual.melee_held()._contact_sweep = _checked
	await super._move(id, weapon, set, move, side, held)


func finish() -> void:
	_check(_checked != null and _checked.failed == 0 and _checked.contacts > 0 and _checked.captures > 0,
		"both sweep implementations consume the exact rendered poses and report identical live contacts")
	var stats := {"captures": _checked.captures, "contacts": _checked.contacts, "differences": _checked.failed}
	var file := FileAccess.open(out_dir.path_join("synchronized-comparison.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(stats,"  ")+"\n")
	file.close()
	await super.finish()