extends Node

const Original = preload("res://core/melee_contact_sweep.gd")
const Candidate = preload("D:/NestEggVerification/evidence-20261120-ne277-sweep-buffers/sweep_candidate.gd")
const TYPES := ["blade", "dagger", "glaive", "maul", "whip"]
const COUNT := 5000
const WAVES := 4

func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	var old := Original.new()
	var candidate := Candidate.new()
	var box := Hurtbox.new()
	box.setup(Combat.Team.ENEMY, null, Vector2(9, 13))
	add_child(box)
	var xforms: Array[Transform2D] = []
	for i in 64:
		xforms.append(Transform2D(sin(i * 0.122) * 1.4, Vector2(219+i*0.23, 102+cos(i * 0.25)*1.4)))
	var rope := SoftWhip.new()
	var summaries := {}
	for name: String in TYPES:
		var weapon := load("res://data/weapons/melee/melee_%s.tres" % name) as WeaponData
		var span := MeleeData.set_of(weapon).contact_span()
		for i in 320:
			var face := 1 if i % 128 < 64 else -1
			var xf := xforms[i % 64]
			var canvas := Transform2D(Vector2(face * 1.0, 0), Vector2(0, 1), Vector2(200, 100))
			var current_span := span if i%17 != 0 else Vector2(-1, 17)
			if i % 37 == 0:
				rope.clear()
				old.clear()
				candidate.clear()
			else:
				rope.step(1.0/60, xf.origin, Vector2(face,0), 28.0, xf.origin + Vector2(face*22,-5), 0.10)
			old.capture(weapon,xf,face,rope,canvas,current_span)
			candidate.capture(weapon,xf,face,rope,canvas,current_span)
			if old.current != candidate.current or old.previous != candidate.previous or old.tick != candidate.tick or old.previous_tick != candidate.previous_tick:
				_fail("%s poses differ at frame %d" % [name,i])
				return
			box.position = xf.origin + Vector2((i % 29) * face, (i % 15) - 7)
			for bounds: Vector2 in [Vector2.ZERO, Vector2(1,1), Vector2(0,1), Vector2(0.25,0.8)]:
				if old.contact(box,bounds.x,bounds.y) != candidate.contact(box,bounds.x,bounds.y):
					_fail("%s contacts differ at frame %d for %s" % [name,i,bounds])
					return
			if i % 16 == 0:
				await get_tree().physics_frame
		rope.step(1.0/60, Vector2(225,104), Vector2.RIGHT, 32.0, Vector2(257,104), 0.1)
		var a: Array[float] = []
		var b: Array[float] = []
		for wave in WAVES:
			if wave % 2 == 0:
				a.append(_measure(old,weapon,span,rope,xforms))
				b.append(_measure(candidate,weapon,span,rope,xforms))
			else:
				b.append(_measure(candidate,weapon,span,rope,xforms))
				a.append(_measure(old,weapon,span,rope,xforms))
		summaries[name] = {"samples":320, "contacts_checked":1280, "vertices":old.current.size(),"load_original_us":a,"load_candidate_us":b}
		print("%s: %s" % [name,summaries[name]])
	print("VERIFIED ",JSON.stringify(summaries))
	get_tree().quit(0)


func _measure(sweep: RefCounted, weapon: WeaponData, span: Vector2, rope: SoftWhip, xforms: Array[Transform2D]) -> float:
	for i in 500:
		sweep.capture(weapon,xforms[i%64],1,rope,Transform2D.IDENTITY,span)
	var begin := Time.get_ticks_usec()
	for i in COUNT:
		sweep.capture(weapon,xforms[i%64],1,rope,Transform2D.IDENTITY,span)
	return (Time.get_ticks_usec()-begin)/float(COUNT)


func _fail(message: String) -> void:
	push_error(message)
	get_tree().quit(1)