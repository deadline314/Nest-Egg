from pathlib import Path
import json, os, re, subprocess, sys

p = Path(__file__).resolve().parent
root = Path.cwd()
label = sys.argv[1]
for weapon, move in (('maul', 'smash'), ('whip', 'lash')):
    out = p/f'{label}-{weapon}'
    out.mkdir()
    env = os.environ.copy()
    for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'TEMP', 'TMP', 'TMPDIR'):
        folder = out/key
        folder.mkdir()
        env[key] = str(folder)
    command = [sys.executable, '-B', str(root/'tools/comfyui/gpu_lock.py'), '--',
               'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root),
               '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan',
               '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '1500',
               '--audio-driver', 'Dummy', str(p/'framed.tscn'), '--',
               '--out='+str(out), '--weapon='+weapon, '--move='+move, '--facing=both', '--capture']
    (out/'command.json').write_text(json.dumps(command, indent=2)+'\n')
    with (out/'engine.log').open('wb') as log:
        proc = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    raw = (out/'engine.log').read_text('utf-8')
    errors = re.findall(r'^(?:SCRIPT )?ERROR:.*|^.*leaked at exit.*', raw, re.M)
    result = out/'contact-result.json'
    res = json.loads(result.read_bytes()) if result.is_file() else {}
    receipt = {'engine_exit':proc.returncode, 'errors':errors, 'checks':res.get('checks'),
               'case_count':len(res.get('rows', [])), 'case_failures':res.get('failures')}
    (out/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(weapon, receipt, flush=True)
    assert proc.returncode == 0 and not errors and res.get('failures') == [] and len(res.get('rows', [])) == 2