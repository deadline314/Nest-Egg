extends Node

const WAREHOUSE := preload("res://data/levels/ch1_warehouse.tres")
const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://focus-return-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.set_language("en")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_prologue_exit")
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(WAREHOUSE)
	add_child(level)
	await _frames(30)
	var pause := level._pause_menu
	pause.open()
	await _frames(4)
	pause._map_button.grab_focus()
	await _frames(3)
	var hint := pause._root.get_node("FocusHintBar") as FocusHintBar
	_check(pause._map_button.has_focus() and hint.text() == pause._map_button.tooltip_text,
			"the real map action begins focused with its keyboard hint")
	var mouse := InputEventMouseMotion.new()
	mouse.position = Vector2(5, 5)
	mouse.relative = Vector2(4, 0)
	get_viewport().push_input(mouse, true)
	await _frames(4)
	_check(pause._map_button.has_focus() and hint.text().is_empty(), "pointer input hides the bar without changing focus")
	var key := InputEventKey.new()
	key.keycode = KEY_SHIFT
	key.pressed = true
	get_viewport().push_input(key, true)
	await _frames(4)
	_check(pause._map_button.has_focus() and not hint.text().is_empty()
			and hint.text() == pause._map_button.tooltip_text, "keyboard restores the original focused help without navigation")
	key = key.duplicate()
	key.pressed = false
	get_viewport().push_input(key, true)
	get_viewport().push_input(mouse.duplicate(), true)
	await _frames(3)
	_check(hint.text().is_empty(), "returning to the pointer hides the unchanged focus hint again")
	var stick := InputEventJoypadMotion.new()
	stick.device = 999
	stick.axis = JOY_AXIS_RIGHT_X
	stick.axis_value = 0.1
	get_viewport().push_input(stick, true)
	await _frames(3)
	_check(hint.text().is_empty() and not InputBindings.using_gamepad, "small stick drift leaves pointer mode alone")
	stick = stick.duplicate()
	stick.axis_value = 0.8
	get_viewport().push_input(stick, true)
	await _frames(4)
	_check(pause._map_button.has_focus() and not hint.text().is_empty() and hint.text() == pause._map_button.tooltip_text
			and InputBindings.using_gamepad, "accepted controller input restores the same focus with the new device's help")
	stick = stick.duplicate()
	stick.axis_value = 0.0
	get_viewport().push_input(stick, true)
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join("focus.png")) == OK,
				"captured the actual restored focus and map guidance")
	get_viewport().push_input(mouse.duplicate(), true)
	await _frames(3)
	stick = stick.duplicate()
	stick.axis_value = 0.8
	get_viewport().push_input(stick, true)
	get_viewport().push_input(mouse.duplicate(), true)
	await _frames(3)
	_check(hint.text().is_empty() and not InputBindings.using_gamepad,
			"a later pointer event wins over a queued same-frame controller update")
	stick = stick.duplicate()
	stick.axis_value = 0.0
	get_viewport().push_input(stick, true)
	pause._open_settings()
	await _frames(3)
	key = key.duplicate()
	key.pressed = true
	get_viewport().push_input(key, true)
	await _frames(4)
	_check(hint.text().is_empty(), "the underlying pause hint stays off while the settings own their focus")
	key = key.duplicate()
	key.pressed = false
	get_viewport().push_input(key, true)
	pause._settings.close()
	await _frames(3)
	pause.close()
	level.queue_free()
	await _frames(7)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)
