extends "D:/NestEggVerification/evidence-20261120-st16-pacing/pacing-clean.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
const TARGET := "彈匣看過了"
var _samples: Array[Dictionary] = []
var _target_text_scale := 1.0
var _reduce := false


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg == "--large":
			_target_text_scale = 1.2
			_reduce = true
	Settings.set_ui_text_scale(_target_text_scale)
	Settings.set_reduce_ui_motion(_reduce)
	super._ready()


func _shot(name: String) -> void:
	if name != "ST-16-p04-trainer-warn":
		return
	await _frames(4)
	await RenderingServer.frame_post_draw
	var level := _level()
	var viewport := get_viewport()
	var to_screen := viewport.get_canvas_transform()
	var aim := to_screen * level.player.aim_point
	for bubble in level._bubbles._active:
		var text := String(bubble["text"])
		if not text.begins_with(TARGET):
			continue
		var box := to_screen * Rect2(bubble["rect"])
		if not box.has_area():
			continue
		var caret := Rect2(aim - Vector2.ONE * 10.5, Vector2.ONE * 21.0)
		var paragraph: TextParagraph = bubble["paragraph"]
		var viewport_size := viewport.get_visible_rect().size
		var lesson := _station(&"ch1_training_trainer")._prompt
		var lesson_box := lesson.base_rect()
		lesson_box.position += lesson._nudge
		lesson_box = to_screen * lesson_box
		var record := {
			"lesson_visible": lesson.is_showing() and lesson._alpha > 0.5,
			"lesson_has_clear_text": not lesson_box.intersects(box),
			"lesson_alpha": lesson._alpha,
			"lesson_box": [lesson_box.position.x, lesson_box.position.y, lesson_box.size.x, lesson_box.size.y],
			"box": [box.position.x, box.position.y, box.size.x, box.size.y],
			"aim": [aim.x, aim.y],
			"character_count": text.length(),
			"visible_character_count": paragraph.get_range().y,
			"actual_age": bubble["age"],
			"prompt_line": text,
			"gap_at_base_aim_size": not box.intersects(caret),
			"fully_on_screen": Rect2(Vector2.ZERO, viewport_size).encloses(box),
			"view_size": [viewport_size.x, viewport_size.y],
			"reduced_motion": Settings.get_reduce_ui_motion(),
			"text_scale": Settings.get_ui_text_scale(),
			"armed_gamepad_source": InputBindings.using_gamepad,
		}
		_samples.append(record)
		var file := FileAccess.open(_out.path_join("samples.json"), FileAccess.WRITE)
		file.store_string(JSON.stringify(_samples, "  "))
		var image := CAPTURE.image(viewport)
		var name_part := "trainer-%02d.png" % _samples.size()
		_check(image.save_png(_out.path_join(name_part)) == OK, "saved exact reticle and bubble frame: " + name_part)
		_check(record.fully_on_screen and paragraph.get_range().y == text.length(), "active ambient line is complete and inside the actual gameplay view")
		print("NE228_READING %s" % JSON.stringify(record))
		break
