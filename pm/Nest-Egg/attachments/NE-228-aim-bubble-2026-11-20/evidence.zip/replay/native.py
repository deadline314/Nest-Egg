from pathlib import Path
from subprocess import run
import json
import os
import sys

base = Path(__file__).resolve().parent
shared = base.parent/'ne218-baseline-20261117'
python = Path(sys.executable)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
mode, scale = sys.argv[1:]
out = base/f'{mode}-{scale}'
out.mkdir(exist_ok=False)
size = '960x540' if scale == 'default' else '1280x540'
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    var = out/'profile'/key
    var.mkdir(parents=True)
    env[key]=str(var)
command = [str(python),str(shared/'tools/comfyui/gpu_lock.py'),'--',engine,
           '--path',str(shared),'--resolution',size,'--position','10,90','--fixed-fps','60',
           '--rendering-method','forward_plus','--rendering-driver','vulkan',str(base/'probe.tscn'),
           '--',f'--out={out.as_posix()}',f'--save-dir={(out/"save").as_posix()}']
if scale != 'default':
    command.extend(('--large','--gamepad'))
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
with (out/'raw.log').open('wb') as log:
    result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=195)
(out/'exit.txt').write_text(str(result.returncode)+'\n')
lines = (out/'raw.log').read_text(encoding='utf-8').splitlines()
print('\n'.join(line for line in lines if 'NE228_READING' in line or line.startswith(('PASS','FAIL','ERROR','SCRIPT'))))
assert result.returncode==0 and not any('ERROR:' in line or line.startswith('FAIL') for line in lines)
assert 'RX 9070 XT' in '\n'.join(lines) and (out/'samples.json').is_file()
