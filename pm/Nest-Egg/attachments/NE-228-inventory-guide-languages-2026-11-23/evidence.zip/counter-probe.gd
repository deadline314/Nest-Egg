extends "res://tests/smoke_test.gd"

const PAWNSHOP := preload("res://data/levels/ch1_pawnshop.tres")
const EXPECTED := {
	"zh": [["補給", "典當", "改裝"], "分頁", "信用點"],
	"ja": [["補給", "質入れ", "改造"], "切替", "クレジット"],
	"en": [["Stock", "Pawn", "Mods"], "Tabs", "Credits"],
}


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://counter_navigation_locale.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_prologue_done")
	GameState.set_flag(&"ch1_dinner_done")
	GameState.set_flag(&"ch1_heard_brief")
	for scene in Story.scene_ids():
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.configure(PAWNSHOP)
	add_child(level)
	await _frames(10)
	var station: ShopStation
	for object in level.find_children("*", "Area2D", true, false):
		if object is ShopStation:
			station = object
			break
	_check(station != null, "the authored pawnshop owns a real supply station")
	if station == null:
		level.queue_free()
		await _finish()
		return
	level.player.global_position = station.global_position
	await _frames(10)
	var expected_title := station.data.display_name
	var opening_count := 0
	for language in ["zh", "ja", "en"]:
		Story.set_language(language)
		var expected: Array = EXPECTED[language]
		await _press(KEY_E)
		var screen := station._screen
		_check(screen != null and screen.is_open(), language + " counter from a real interaction input")
		if screen == null or not screen.is_open():
			continue
		opening_count += 1
		_check(screen._title.text == expected_title and screen._tab_buttons.size() == 3, language + " the original counter title and its tabs")
		_check(screen._credits.text.begins_with(expected[2]) and screen._legend_label.text.contains(expected[1]), language + " localized credits and keyboard options")
		for i in screen._tab_buttons.size():
			var tab := screen._tab_buttons[i]
			_check(tab.text == expected[0][i] and not tab.tooltip_text.is_empty(), language + " counter tab " + str(i))
		_check(screen._tab_buttons.all(func(tab: Button) -> bool: return tab.tooltip_text.contains("¥%d" % Progression.credits)),
			language + " purchasing and pawning help still shows the current balance")
		InputBindings._set_device(true, 999)
		await get_tree().process_frame
		_check(screen._legend_label.text.contains(expected[1]) and screen._legend_label.get_combined_minimum_size().x <= screen._legend_label.size.x + 1.0,
			language + " controller options fit at 120%")
		_check(screen._frame.get_global_rect().grow(0.5).encloses(screen._tab_buttons.back().get_global_rect()),
			language + " actual counter tabs fit")
		screen.close()
		await _frames(4)
	_check(opening_count == 3, "the same counter opens and refreshes in all three languages")
	level.queue_free()
	await _frames(4)
	await _finish()


func _press(code: int) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.pressed = true
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await get_tree().process_frame
	await get_tree().physics_frame
	await get_tree().process_frame
	event.pressed = false
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	await get_tree().process_frame
