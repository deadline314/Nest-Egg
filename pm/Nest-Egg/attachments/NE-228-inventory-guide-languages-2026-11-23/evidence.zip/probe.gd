extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
const EXPECTED := {
	"zh": ["背包", ["武器與彈藥", "改裝", "消耗品", "義體", "劇情道具", "角色狀態"], "分頁", "確認", "信用點"],
	"ja": ["所持品", ["武器", "改造", "消耗品", "義体", "物語", "状態"], "切替", "決定", "クレジット"],
	"en": ["Inventory", ["Weapons", "Mods", "Supplies", "Cyberware", "Story", "Status"], "Tabs", "OK", "Credits"],
}
var _image_path := ""


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	var args := OS.get_cmdline_user_args()
	if args.size() == 1:
		_image_path = args[0]
	Settings.use_storage("user://backpack_shell_locale.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	for language in ["zh", "ja", "en"]:
		await _case(language)
	await _finish()


func _case(language: String) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	await _frames(8)
	InputBindings._set_device(false)
	InputBindings.clear_held_inputs()
	var bag := level._inventory
	bag.open()
	await get_tree().process_frame
	var expected: Array = EXPECTED[language]
	_check(bag.is_open() and bag._title.text == expected[0], language + " inventory title")
	_check(bag._credits.text.begins_with(expected[4]) and not bag._credits.tooltip_text.is_empty(), language + " credits")
	_check(bag._legend_label.text.contains(expected[2]) and bag._legend_label.text.contains(expected[3]), language + " keyboard directions")
	for i in bag._tab_buttons.size():
		var button := bag._tab_buttons[i]
		_check(button.text.trim_suffix(" ●") == expected[1][i] and not button.tooltip_text.is_empty(), language + " tab " + str(i))
		if i > 0:
			_check(bag._tab_buttons[i-1].get_global_rect().end.x <= button.get_global_rect().position.x,
				language + " tabs do not overlap")
	_check(bag._frame.get_global_rect().grow(0.5).encloses(bag._tab_buttons.back().get_global_rect()), language + " tabs fit")
	bag.select_tab(bag.page_index(ConsumablesPage))
	InputBindings._set_device(true, 999)
	await get_tree().process_frame
	_check(bag._legend_label.text.contains(expected[2]) and bag._legend_label.text.contains(expected[3]), language + " controller directions")
	var legend := bag._legend_label
	_check(legend.get_combined_minimum_size().x <= legend.size.x + 1.0, language + " controller directions fit")
	if language == "en" and _image_path.is_absolute_path():
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_image_path) == OK, "localized menu screenshot")
	print("BAG_LANGUAGE ", language, " | ", bag._title.text, " | ", bag._legend_label.text)
	bag.close()
	level.queue_free()
	await _frames(4)
