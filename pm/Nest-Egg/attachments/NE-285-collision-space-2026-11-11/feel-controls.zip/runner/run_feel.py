from pathlib import Path
import hashlib,json,os,subprocess,time,sys
root=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).resolve().parents[2];out=root/("work/"+sys.argv[1]);out.mkdir(exist_ok=False)
files=["autoload/fx.gd","tests/suite/test_feel.gd","tests/helpers/freeze_collision_space_checks.gd"]
def sha():return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
before=sha();cmd=["C:/Program Files/Git/bin/bash.exe","tools/run_tests_parallel.sh","--only=FeelSuite","1"]
env=dict(os.environ,GODOT="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",LOG_DIR=str(out/"logs"),PYTHONUTF8="1",PYTHONIOENCODING="utf-8");t=time.monotonic()

with (out/"process.log").open("wb") as log:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:code=p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True);code=124
after=sha();r={"command":cmd,"exit":code,"seconds":time.monotonic()-t,"before":before,"after":after,"stable":before==after}
(out/"receipt.json").write_bytes((json.dumps(r,indent=2)+"\n").encode());print(json.dumps(r));print((out/"process.log").read_text(errors="replace")[-4500:])

raise SystemExit(0 if code==0 and before==after else 1)
