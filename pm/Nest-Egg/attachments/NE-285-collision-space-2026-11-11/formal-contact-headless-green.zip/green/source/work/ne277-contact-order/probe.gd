extends "res://tools/ne277_feedback_probe.gd"
## Diagnostic only: original real Player/Enemy path, observers outside the paused subtree.
class LatePass extends MeleeModule:
	var pending := false
	func hit_pass() -> void:
		if not pending:
			pending = true
			_flush_pass.call_deferred()
	func _flush_pass() -> void:
		pending = false
		super.hit_pass()

class Watcher extends Node:
	var observe: Callable
	var label := ""
	func _physics_process(_delta: float) -> void:
		observe.call(label)

var _ledger: Array[Dictionary] = []
var _observing := false
var _late_pass := false
var _order := 0
var _last_process_physics := -1

func _ready() -> void:
	super._ready()
	if _only == "":
		_only = "maul"
	_sides = [1]
	_late_pass = "--late-pass" in OS.get_cmdline_user_args()

func _run() -> void:
	for priority in [-100000, 100000]:
		var watcher := Watcher.new()
		watcher.observe = _trace
		watcher.label = "physics_early" if priority < 0 else "physics_late"
		watcher.process_mode = Node.PROCESS_MODE_ALWAYS
		watcher.process_physics_priority = priority
		add_child(watcher)
	EventBus.hit_confirmed.connect(_hit_in_pass)
	if DisplayServer.get_name() != "headless":
		RenderingServer.frame_post_draw.connect(_rendered)
	await super._run()
	var file := FileAccess.open(out_dir.path_join("order-ledger.json"), FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify({"scope": "formal combat with explicit optional runtime late-pass control; CPU has no real postdraw observations", "runtime_control_late_pass": _late_pass, "display": DisplayServer.get_name(), "events": _ledger}, "\t"))
		file.close()

func _contact(id: String, weapon: WeaponData, set: MeleeSet, move: String, side: int, reduced: bool) -> void:
	if reduced or move != ("smash" if id == "maul" else "lash"):
		return
	if _late_pass:
		var previous := player.melee
		player.remove_child(previous)
		previous.queue_free()
		player.melee = LatePass.new(player)
		player.add_child(player.melee)
	_observing = true
	await super._contact(id, weapon, set, move, side, reduced)
	_observing = false

func _process(_delta: float) -> void:
	var tick := Engine.get_physics_frames()
	if tick != _last_process_physics:
		_last_process_physics = tick
		_trace("process")

func _hit_in_pass(_at: Vector2, _killed: bool) -> void:
	_trace("hit_confirmed_inside_hit_pass")
	if _observing and not _ledger.is_empty():
		_ledger[-1]["real_stack"] = get_stack()
		_deferred_one.call_deferred()

func _deferred_one() -> void:
	_trace("probe_deferred_one")
	_deferred_two.call_deferred()

func _deferred_two() -> void:
	_trace("probe_deferred_two")

func _rendered() -> void:
	_trace("frame_post_draw")

func _trace(label: String) -> void:
	if not _observing or not is_instance_valid(player) or player._visual.rig == null:
		return
	_order += 1
	var visual := player._visual
	var held := visual.melee_held()
	var row := {"order": _order, "event": label, "usec": Time.get_ticks_usec(), "physics": Engine.get_physics_frames(), "process": Engine.get_process_frames(), "phase": player.melee.phase, "phase_time": player.melee.time, "progress": player.melee.pose_progress(), "visual_action": str(visual._input.action), "visual_action_t": visual._input.action_t, "animator_time": visual.rig.animator._time, "player_mode": player.process_mode, "player_frozen": Fx.is_frozen(player), "visual_physics_enabled": visual.is_physics_processing(), "visual_can_process": visual.can_process(), "player_position": [player.global_position.x, player.global_position.y], "tip": [held.tip_point().x, held.tip_point().y]}
	var rope := held.whip()
	if rope != null and rope.is_laid():
		var points: Array = []
		for i in SoftWhip.NODES:
			points.append([rope.node(i).x, rope.node(i).y])
		row["world_rope"] = points
	for node in get_tree().get_nodes_in_group(&"enemies"):
		var enemy := node as Enemy
		if enemy == null or enemy.health.current <= 0:
			continue
		var center := enemy.hurtbox.center()
		var near := enemy.hurtbox.closest_point(held.tip_point())
		row["player_physics"] = _spaces(player, player.hurtbox)
		row["target_physics"] = _spaces(enemy, enemy.hurtbox)
		row["target"] = {"position": [enemy.global_position.x, enemy.global_position.y], "center": [center.x, center.y], "closest_to_tip": [near.x, near.y], "tip_gap": held.tip_point().distance_to(near), "frozen": Fx.is_frozen(enemy), "hp": enemy.health.current, "body_size": [enemy.data.body_size.x, enemy.data.body_size.y]}
		break
	_ledger.append(row)


func _spaces(body: CollisionObject2D, box: Hurtbox) -> Dictionary:
	var body_space := PhysicsServer2D.body_get_space(body.get_rid())
	var area_space := PhysicsServer2D.area_get_space(box.get_rid())
	return {"body_space": body_space.get_id(), "body_in_space": body_space.is_valid(),
		"hurtbox_space": area_space.get_id(), "hurtbox_in_space": area_space.is_valid(),
		"expected_space": body.get_world_2d().space.get_id(), "body_disable_mode": body.disable_mode,
		"hurtbox_disable_mode": box.disable_mode, "body_can_process": body.can_process(), "hurtbox_can_process": box.can_process()}
