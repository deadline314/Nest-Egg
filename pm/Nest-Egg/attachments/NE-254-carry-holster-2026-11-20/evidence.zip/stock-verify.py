from pathlib import Path
from hashlib import sha256
import json, subprocess
here=Path(__file__).resolve().parent
view=here/'stock-view'
before=Path(r'D:/NestEggVerification/evidence-20261120-ne228-hud-action-hints/published-source.json')
manifest=json.loads(before.read_bytes())
scope=json.loads((here/'runtime.json').read_bytes())
head=(here/'baseline.txt').read_text().strip()
for relative in scope:
    raw=subprocess.check_output(['git','show',f'{head}:{relative}'])
    if sha256(raw).hexdigest()!=manifest[relative]:
        raw=raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
    assert sha256(raw).hexdigest()==manifest[relative],relative
    (view/relative).write_bytes(raw)
issues=[relative for relative, expected in manifest.items() if sha256((view/relative).read_bytes()).hexdigest()!=expected]
assert not issues,issues
(here/'stock-source-check.json').write_text(json.dumps({'sha':head,'verified_files':len(manifest),'overrides':scope},indent=2)+'\n')
print(f'{head} exact source files {len(manifest)}')