from pathlib import Path
import json

base=Path(__file__).resolve().parent
rows={}
for side,face in (('right',1),('left',-1)):
    original,candidate=[json.loads((base/f'{phase}-{side}'/'run.json').read_bytes()) for phase in ('stock-v3','exact-v3')]
    assert original['input_save']==candidate['input_save']
    target=original['resolution']['target']
    assert candidate['resolution']['target']==target and target['id']=='crate_small'
    assert all(rep['exit']==0 and rep['errors']==[] and rep['resolution']['failures']==0 for rep in (original,candidate))
    old,new=[{row['name']:row for row in rep['resolution']['samples']} for rep in (original,candidate)]
    assert len(old)==len(new)==7 and old.keys()==new.keys()
    fields=('name','phase','facing','pose','equipped','ammo','reload','melee_ammo')
    assert all(a['facing']==b['facing']==face and all(a[k]==b[k] for k in fields) for a,b in zip(old.values(),new.values(),strict=True))
    assert old['reload-complete']['firearm_drawn'] and old['reload-complete']['weapon_file']=='pistol.png'
    assert old['rifle-holding']['firearm_drawn'] and old['rifle-holding']['weapon_file']=='rifle.png'
    assert old['melee-holding']['melee_drawn'] and old['throwing']['melee_attack']
    assert old['throwing-reselected']['firearm_drawn']
    assert all(not row['firearm_drawn'] and not row['melee_drawn'] and not row['melee_attack'] for row in new.values() if row['phase'])
    assert old['ready']['firearm_drawn'] and new['ready']==old['ready']
    rows[side]={'samples':len(new),'facing':face,'target':target,
                'displayed_during_carry_before':sum(row['phase'] and (row['firearm_drawn'] or row['melee_drawn']) for row in old.values()),
                'displayed_during_carry_after':sum(row['phase'] and (row['firearm_drawn'] or row['melee_drawn']) for row in new.values()),
                'extra_melee_before':old['throwing']['melee_attack'],'extra_melee_after':new['throwing']['melee_attack']}
(base/'comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))