extends "res://tools/ch1_flow_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
const CRATE_TILE := 95.0
var _store := ""
var _face := 1
var _main: Node
var _player: Player
var _samples: Array[Dictionary] = []
var _target_meta := {}


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--face="):
			_face = int(arg.trim_prefix("--face="))
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Story.auto_skip = false
	Transition.instant = true
	super._ready()


func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.player != null and _level.data.id == &"ch1_street", "read the ordinary first-chapter street save")
	if _level == null or _level.player == null:
		_finish_carry()
		return
	_player = _level.player
	_player.health.grant_invulnerability(60.0)
	_level._next_story_trigger = _level._layout.story_triggers.size()
	for node: Node in get_tree().get_nodes_in_group(&"enemies"):
		node.set_physics_process(false)
	var crate: Throwable
	for node: Node2D in get_tree().get_nodes_in_group(Throwable.GROUP):
		if node is Throwable and node.data.id == &"crate_small" and (crate == null or absf(node.position.x - CRATE_TILE * 16.0) < absf(crate.position.x - CRATE_TILE * 16.0)):
			crate = node
	_check(crate != null and absf(crate.position.x - CRATE_TILE * 16.0) < 16.0, "use the authored street-plaza crate")
	if crate == null:
		_finish_carry()
		return
	_player.global_position = Vector2(crate.global_position.x - 17.0 * _face, 511.0)
	_level.camera.snap_to_target()
	_player.loadout.equip(load("res://data/weapons/rifle.tres") as WeaponData)
	_player.loadout.equip(load("res://data/weapons/melee/melee_blade.tres") as WeaponData)
	_player.loadout.select(Loadout.PRIMARY)
	var pistol_slot := _player.loadout.active_slot
	var initial := _player.loadout.mag_in(pistol_slot)
	AimInput.set_virtual_gamepad(_player, true)
	var aim := &"aim_right" if _face > 0 else &"aim_left"
	var away := &"aim_left" if _face > 0 else &"aim_right"
	Input.action_press(away)
	await _settle(24)
	Input.action_press(&"shoot")
	for i in 15:
		await _settle(1)
		if _player.loadout.mag_in(pistol_slot) < initial:
			break
	Input.action_release(&"shoot")
	_check(_player.loadout.mag_in(pistol_slot) < initial, "fire the real pistol away from the target crate")
	Input.action_release(away)
	Input.action_press(aim)
	await _settle(6)
	var target := _player.carry.nearest_pickable()
	_check(target != null and _player.facing == _face, "select the live authored pickup from the requested side")
	if target == null:
		_finish_carry()
		return
	_target_meta = {"id":str(target.data.id),"position":str(target.global_position),"player":str(_player.global_position)}
	print("CARRY_TARGET ",JSON.stringify(_target_meta)," initial grid crate=",crate.global_position)
	await _send(&"reload")
	_check(_player.is_reloading(), "start the actual reload")
	await _press(&"interact")
	_check(_player.carry.held == target, "pick up that original map prop with the gameplay interaction")
	_check(_player.facing == _face, "the carry pose uses the requested direction")
	await _observe("lifting")
	for i in 80:
		if _player.carry.phase == PlayerCarry.Phase.HOLDING and not _player.is_reloading():
			break
		await _settle(1)
	_check(_player.carry.phase == PlayerCarry.Phase.HOLDING and _player.loadout.mag_in(pistol_slot) == initial,
		"the original carry and reload both finish on their normal clock")
	await _observe("reload-complete")
	await _send(&"weapon_next")
	_check(_player.loadout.active_weapon().id == &"rifle" and _player.carry.phase == PlayerCarry.Phase.HOLDING,
		"rifle selection still happens in the loadout while holding")
	await _observe("rifle-holding")
	await _send(&"weapon_next")
	var melee := _player.loadout.active_weapon()
	_check(melee != null and melee.is_melee() and _player.carry.phase == PlayerCarry.Phase.HOLDING,
		"melee selection still happens while holding")
	await _observe("melee-holding")
	if _face < 0:
		await _send(&"shoot")
	else:
		await _press(&"shoot")
	_check(_player.carry.phase == PlayerCarry.Phase.THROWING and not _player.carry.is_holding(),
		"the normal attack action throws the crate")
	await _observe("throwing")
	await _send(&"weapon_next")
	_check(_player.loadout.active_slot == pistol_slot and _player.carry.phase == PlayerCarry.Phase.THROWING,
		"pistol selection reaches the loadout during the release pose")
	await _observe("throwing-reselected")
	await _settle(22)
	_check(_player.carry.phase == PlayerCarry.Phase.NONE and _player.loadout.mag_in(pistol_slot) == initial,
		"release finishes without spending a round")
	await _observe("ready")
	Input.action_release(aim)
	AimInput.set_virtual_gamepad(_player, false)
	_finish_carry()


func _press(action: StringName) -> void:
	Input.action_press(action)
	await _settle(2)
	Input.action_release(action)
	await _settle(1)


func _send(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await _settle(1)
	var released := InputEventAction.new()
	released.action = action
	Input.parse_input_event(released)
	await _settle(1)


func _observe(name: String) -> void:
	await RenderingServer.frame_post_draw
	var visual := _player._visual
	var rig := visual.rig
	_samples.append({"name":name,"phase":int(_player.carry.phase),"facing":_player.facing,"pose":str(_player.carry.pose()),
		"equipped":str(_player.loadout.active_weapon().id),"weapon_file":str(rig.weapon_def().get("file","")),
		"firearm_drawn":rig._weapon_root.visible,"melee_drawn":visual.melee_held().visible,
		"ammo":_player.loadout.mag_in(Loadout.PRIMARY),"reload":_player.is_reloading(),"melee_attack":_player.melee.is_active(),"melee_ammo":_player.loadout.mag_in(_player.loadout.find_slot(&"melee_blade"))})
	var path := _out_dir.path_join(name+".png")
	_check(CAPTURE.image(get_viewport()).save_png(path) == OK, "write native "+name)


func _finish_carry() -> void:
	var f := FileAccess.open(_out_dir.path_join("carry.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"failures":_failures,"samples":_samples,"target":_target_meta},"  ")+"\n")
	f.close()
	_main.call("_quit",0 if _failures == 0 else 1)