from pathlib import Path
from collections import Counter
import json,sys
import numpy as np
from scipy import ndimage
from PIL import Image
p=Path(__file__).resolve().parent
run=sys.argv[1]
read=lambda f:json.loads(f.read_bytes())
structure=np.ones((3,3),bool)
def enclosed(a):
    solid=a>=128
    return ndimage.binary_fill_holes(solid,structure=structure)&~solid
def image(file):
    return np.asarray(Image.open(file).getchannel('A'))
def crop(array,cell):
    x,y,w,h=cell['rect']
    r=cell['radius']
    return array[y+h//2-r:y+h//2+r,x+w//2-r:x+w//2+r]
summary={}
cases=[]
for case in (sys.argv[2:] or ('talk-and-gesture','sit-transitions','work-loop')):
    ref=p/f'visible-{case}'
    after=p/f'{run}-{case}'
    b_index={(g['pose'],g['zoom']):g for g in read(ref/'frames.json')}
    agg=Counter()
    for group in read(after/'frames.json'):
        pose,zoom=group['pose'],group['zoom']
        original=b_index[pose,zoom]
        cells={(c['char'],c['joint'],c['facing']):c for c in original['cells']}
        assert group['samples']==original['samples'][:len(group['samples'])]
        for sample in group['samples']:
            first=image(ref/sample['file'])
            second=image(after/sample['file'])
            for current in group['cells']:
                actor,joint,facing=current['char'],current['joint'],current['facing']
                prev=cells[actor,joint,facing]
                a,b=crop(first,prev),crop(second,current)
                assert a.shape==b.shape
                ah,bh=enclosed(a),enclosed(b)
                fixed=ah&(b>=128)
                new=bh&~ah
                opened=ah&~bh&~fixed
                counts=Counter(total=1, flagged_before=bool(ah.any()),flagged_after=bool(bh.any()),
                    new_locations=int(new.sum()),fixed_locations=int(fixed.sum()),old_locations_open_on_new_edge=int(opened.sum()),
                    unchanged_holes=int((ah&bh).sum()),changed_alpha_pixels=int((a!=b).sum()))
                agg.update(counts)
                for key,val in counts.items():
                    summary.setdefault(f'{case}/{actor}/{joint}',Counter())[key]+=val
                if fixed.any() or new.any() or opened.any():
                    cases.append(dict(case=case,actor=actor,joint=joint,pose=pose,zoom=zoom,facing=facing,**sample,
                                      before_rect=prev['rect'],after_rect=current['rect'],radius=current['radius'],**counts))
    print(case,dict(agg))
print({key:dict(value) for key,value in summary.items() if value['fixed_locations'] or value['new_locations']})
(p/f'{run}-comparison.json').write_text(json.dumps(dict(summary=summary,locations=cases),indent=2)+'\n',encoding='utf-8')

