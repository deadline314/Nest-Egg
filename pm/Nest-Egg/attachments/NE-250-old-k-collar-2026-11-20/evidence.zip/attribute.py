from pathlib import Path
from collections import Counter, defaultdict
import json
import sys

import numpy as np
from PIL import Image
from scipy import ndimage

base = Path(__file__).resolve().parent
structure = np.ones((3, 3))

def read(path):
    return json.loads(path.read_bytes())

def enclosed(solid):
    return ndimage.binary_fill_holes(solid, structure=structure) & ~solid

def loose(solid):
    labels, size = ndimage.label(solid, structure)
    if size < 2:
        return np.zeros_like(solid)
    counts = np.bincount(labels.ravel())
    largest = 1 + counts[1:].argmax()
    border = set(labels[0]) | set(labels[-1]) | set(labels[:,0]) | set(labels[:,-1])
    return np.isin(labels, [i for i in range(1, size+1) if i != largest and i not in border])

def band(image, cell):
    x, y, w, h = cell['rect']
    r = cell['radius']
    return image[y+h//2-r:y+h//2+r, x+w//2-r:x+w//2+r]

def key(row):
    return row['char'], row['joint'], row['facing']

entries = []
for case in (sys.argv[1:] or ['talk-and-gesture','sit-transitions','work-loop']):
    paired, visible = base/case, base/('visible-'+case)
    index = {(group['pose'], group['zoom']): {key(cell):cell for cell in group['cells']}
             for group in read(visible/'frames.json')}
    paired_report = read(paired/'report.json')
    by_file = defaultdict(list)
    totals = Counter()
    for row in paired_report['failures']:
        if row['enclosed_pixels'] or row['center_alpha'] < 128 or row['loose_pieces']:
            by_file[row['file']].append(row)
    for name, rows in by_file.items():
        first = np.asarray(Image.open(paired/name).getchannel('A'))
        second = np.asarray(Image.open(visible/name).getchannel('A'))
        for row in rows:
            other = index[row['pose'],row['zoom']][key(row)]
            assert row['rect'] == other['rect'] and row['radius'] == other['radius']
            before = band(first, row)
            after = band(second, other)
            solid = after >= 128
            holes = enclosed(solid)
            floating = loose(solid)
            rad = row['radius']
            entry = {k: row[k] for k in ('file','char','pose','zoom','joint','facing','frame')}
            entry['clip'] = row['rect']
            missing = enclosed(before >= 128)
            if row['center_alpha'] < 128:
                missing[rad, rad] = True
            orig_loose = loose(before >= 128)
            counts = dict(covered=int((missing & solid).sum()),
                          enclosed=int((missing & holes).sum()),
                          open_edge=int((missing & ~solid & ~holes).sum()),
                          detached=int((orig_loose & floating).sum()))
            totals.update(k for k,n in counts.items() if n)
            entry.update(counts)
            entry['enclosed_points'] = [[int(x),int(y)] for y,x in zip(*np.nonzero(missing & holes))]
            entry['detached_points'] = [[int(x),int(y)] for y,x in zip(*np.nonzero(orig_loose & floating))]
            entries.append(entry)
    print(case,'samples',paired_report['samples'],'paired flags',paired_report['failed_samples'],'strict',sum(map(len,by_file.values())),'matching part of row',totals)
    whole_report = read(visible/'report.json')
    whole_strict = [r for r in whole_report['failures'] if r['enclosed_pixels'] or r['loose_pieces'] or r['center_alpha'] < 128]
    print(case,'live appearance whole strict',len(whole_strict),
          'by actor/joint and enclosed',Counter((r['char'],r['joint']) for r in whole_strict if r['enclosed_pixels']))
print('exact-location cases',Counter((r['char'],r['joint'],r['pose']) for r in entries if r['enclosed'] or r['detached']))
(base/('attribution-'+'-'.join(sys.argv[1:])+'.json')).write_text(json.dumps(entries, ensure_ascii=False, indent=1), encoding='utf-8')
