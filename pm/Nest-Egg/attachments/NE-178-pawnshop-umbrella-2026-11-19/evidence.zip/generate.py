from pathlib import Path
import json
from shutil import copyfile
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
out = base / 'generated'
out.mkdir(exist_ok=True)
sys.path[:0] = [str(root / 'tools/level'), str(root / 'tools/story')]
import build_ch1 as levels
import ch1_runtime_backend as story

levels.LEVEL_DIR = str(out / 'levels')
levels.NPC_DIR = str(out / 'npcs')
levels.THEME_DIR = str(out / 'themes')
for path in (levels.LEVEL_DIR, levels.NPC_DIR, levels.THEME_DIR):
    Path(path).mkdir(exist_ok=True)
area = levels.build_pawnshop()
assert not area.check()
assert not levels.reachable(area, (40, 19), [('傘桶', (79, 19)), ('前門', (74, 19))])
area.grid.write(area.id, (levels.LEVEL_DIR, 'ch1_pawnshop_map.json'), levels._map_extra(area))
levels.write_npc_files()
levels.write_level(area, show_card=True, display_name='當舖')
area.zones = [(0, 12, 'mezzanine_gray')]
levels.write_level(area, level_id='pawnshop_dawn', map_name='pawnshop', theme=False,
                   theme_path='res://data/environment/themes/ch1_pawnshop.tres', display_name='當舖（天亮）',
                   complete_after_intro='true', next_level='"res://data/levels/ch2_pawnshop.tres"')

names = ['levels/ch1_pawnshop.tres', 'levels/ch1_pawnshop_dawn.tres', 'levels/ch1_pawnshop_map.json',
         'npcs/ch1_umbrella_stand.tres', 'story/ch1_kasa.json']
document = story.compile_document()
document['chapter']['languages'] = ['zh', *story.story_i18n.LANGUAGES]
assert not story.story_i18n.apply(document, story.story_i18n.load_table(story.story_i18n.table_path('ch1_kasa')))
existing = json.loads((root / 'data/story/ch1_kasa.json').read_bytes())
for ident in ('ch1_t_umbrella_stand', 'ch1_t_umbrella_stand_revisit'):
    scene = document['scenes'][ident]
    assert scene['mode'] == 'radio' and scene['lines'] and scene['dismissible'] is True
    assert not {'freeze', 'results', 'set_flags'} & scene.keys()
    existing['scenes'][ident] = scene
assert document == existing
target = out / 'story/ch1_kasa.json'
target.parent.mkdir(exist_ok=True)
target.write_text(json.dumps(document, ensure_ascii=False, indent=1) + '\n', encoding='utf-8', newline='\n')
for name in names:
    source = out / name
    assert source.is_file()
    if '--apply' in sys.argv:
        copyfile(source, root / 'data' / name)
    print(name, source.stat().st_size)
