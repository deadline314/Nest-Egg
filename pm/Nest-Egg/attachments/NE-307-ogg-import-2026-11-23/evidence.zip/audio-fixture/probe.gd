extends SceneTree
const Bank := preload("res://core/audio/sound_bank.gd")
func _initialize() -> void:
	var bank := Bank.new()
	bank.load_bank()
	var streams := bank.variants(&"ch2_sink_rinse")
	print("AUDIO_PROBE import_registered=", ResourceLoader.exists("res://audio/sfx/ch2_sink_rinse_01.ogg"), " streams=", streams.size())
	if not streams.is_empty():
		print("AUDIO_PROBE duration=", streams[0].get_length(), " loop=", streams[0].loop)
	quit(0 if streams.size() == 1 and streams[0].get_length() > 0.0 else 1)
