extends "res://tests/smoke_test.gd"
func _ready() -> void:
	_start.call_deferred()
func _start() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	Engine.max_fps = 30
	await SupplySuite.new(self).run()
	await UiKitSuite.new(self).run()
	await AmmoTraySuite.new(self).run()
	await _finish()
