from pathlib import Path
import json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
w=Path('/workspace/Nest-Egg/work/batch1024')
def records(name):
 p=w/name
 rows=[json.loads(line.split('TRAY_STEP ',1)[1]) for line in p.read_text().splitlines() if line.startswith('TRAY_STEP ')]
 return p,rows
old_path,old=records('ammo-tray-prefix-main30.log');new_path,new=records('ammo-tray-prefix-main30-fixed.log')
old=[r for r in old if r['side']>0 and r['above']<0.5][:3]
# Six consecutive measured physics steps share only three renderer counters.
new=[r for r in new if r['side']==-1.0 and r['above']==1.0 and 4.3<r['distance']<4.8][-6:]
assert len(old)==3 and len(new)==6
assert [r['physics']-old[0]['physics'] for r in old]==[0,2,4]
assert [r['physics']-new[0]['physics'] for r in new]==list(range(6))
fig,ax=plt.subplots(figsize=(10,3.8),dpi=180)
for y,rows,color,label in [(1,old,'#b04d27','Original measurement: render-driven updates'),(0,new,'#087e8b','Controlled measurement: one 60Hz UI test step')]:
 xs=[r['physics']-rows[0]['physics'] for r in rows];ax.plot(xs,[y]*len(xs),'o-',color=color,ms=8,lw=2)
 for x,r in zip(xs,rows):ax.text(x,y+0.14,f"P {r['physics']}\nR {r['process']}",ha='center',va='bottom',fontsize=8,color=color)
 ax.text(-0.25,y-0.18,label,ha='left',va='top',fontsize=10,color=color)
ax.set_xlim(-0.35,5.35);ax.set_ylim(-0.65,1.65);ax.set_yticks([]);ax.set_xticks(range(6));ax.set_xlabel('Relative physics tick within each observed excerpt (60Hz)')
ax.set_title('Diagnostic clock domains at a requested 30fps',loc='left',weight='bold')
for side in ['top','left','right']:ax.spines[side].set_visible(False)
ax.grid(axis='x',alpha=.15)
fig.text(.05,.02,'P = engine physics counter; R = engine process counter. Different trace excerpts; no visual improvement comparison.\nProduction HUD is unchanged. Only the test drives its UI component at a fixed step.',fontsize=8)
fig.subplots_adjust(left=.06,right=.98,bottom=.27,top=.83)
fig.savefig(w/'tray-clock-domains.png');plt.close(fig)
(w/'tray-clock-domain-records.json').write_text(json.dumps({'original':old,'controlled':new,'source_logs':{str(p.name):hashlib.sha256(p.read_bytes()).hexdigest() for p in [old_path,new_path]},'scope':'Observed counter excerpts from different phases, explicitly not a matched-motion improvement graph.'},indent=2)+'\n')
