extends "res://tests/suite/test_ammo_tray.gd"
func run() -> void:
	await super.run()

func _test_screen_edge() -> void:
	var level := await start_level(PropsSuite.level_data())
	var tray := level.hud.ammo_tray
	var tag := level.hud.vitals_tag
	var player := level.player
	player.global_position.x = 20.0
	player.velocity = Vector2.ZERO
	AimInput.using_gamepad = true
	Input.action_press(&"aim_right")
	await frames(60)
	var view := tray.get_viewport_rect().size.x
	var to_screen := tray.get_viewport().get_canvas_transform()
	var head: Vector2 = to_screen * (player.global_position + HudPlacement.HEAD_OFFSET)
	check(head.x < HudPlacement.ROOM_NEEDED, "測試站位：主角在畫面左緣附近（頭 x=%.0f）" % head.x)
	# 主角從左緣一步步往內走：每個站位彈帶與標籤都同在背後或同在頭上，不會一個上一個下而疊在一起。
	var agree := true
	for x in range(20, 200, 3):
		player.global_position.x = float(x)
		await frames(15)
		if (tray._above > 0.5) != (tag._above > 0.5):
			agree = false
	check(agree, "彈帶與生命護盾標籤在每個站位都一起決定放背後或頭上")
	player.global_position.x = 20.0
	await frames(40)
	var inside := true
	for i in tray.icon_count():
		var rect := tray._icon_draw_rect(i, tray.icon_count(), 1.0)
		if rect.position.x < 0.0 or rect.end.x > view:
			inside = false
	check(inside, "面向右站在左緣：彈帶每一顆都在畫面內")
	check(tray._above > 0.99 and tray._pos.y < head.y, "背後放不下時彈帶移到頭頂上方")
	check(tag._above > 0.99 and tag._pos.y + 20.0 < tray._pos.y and tag._pos.x >= 0.0, "生命護盾標籤也移到頭頂，在彈帶上面一列")
	# 武器欄：和主角重疊時讓位變淡，沒有重疊時維持完整亮度（街道的實際空隙另由截圖確認）。
	var bar := level.hud.weapon_bar
	var feet: Vector2 = to_screen * (player.global_position + WeaponBar.PLAYER_BOX.position)
	var overlap := Rect2(feet, WeaponBar.PLAYER_BOX.size * to_screen.get_scale()).intersects(bar.get_global_rect())
	check(bar.is_making_way() == overlap, "武器欄只在和主角重疊時讓位（重疊=%s）" % overlap)
	# NE-256 拉近後，面向右時主角固定站在畫面左側（前方留 300 像素）；轉身面向左，主角才移到畫面右側、真的離開左下角。
	player.global_position.x = 300.0
	Input.action_release(&"aim_right")
	Input.action_press(&"aim_left")
	await frames(120)
	check(not bar.is_making_way(), "主角離開左下角後武器欄恢復完整亮度")
	Input.action_release(&"aim_left")
	Input.action_press(&"aim_right")
	player.global_position.x = 20.0
	await frames(120)
	# 轉身：彈帶從頭頂回到背後（右邊有空間），每一格的移動都很小。
	Input.action_release(&"aim_right")
	Input.action_press(&"aim_left")
	# 量離主角最遠的那一顆：舊做法轉身時它會一格內跳到另一邊。
	var far := tray.icon_count() - 1
	var largest := 0.0
	var last := tray._slot_position(far)
	for i in 40:
		await frames(1)
		var now := tray._slot_position(far)
		if now.distance_to(last) > largest:
			print("TRAY_STEP ", JSON.stringify({"distance":now.distance_to(last),"physics":Engine.get_physics_frames(),"process":Engine.get_process_frames(),"process_delta":tray.get_process_delta_time(),"slot":str(now),"last":str(last),"pos":str(tray._pos),"player":str(player.global_position),"canvas":str(tray.get_viewport().get_canvas_transform()),"above":tray._above,"side":tray._draw_side}))
		largest = maxf(largest, now.distance_to(last))
		last = now
	Input.action_release(&"aim_left")
	check(largest < 24.0, "轉身時彈帶平滑移動（每格最多 %.1f 畫面像素）" % largest)
	check(tray.side() > 0.0 and tray._above < 0.01, "面向左、背後（右側）有空間時回到背後")
	# 跳躍與落地：彈帶跟著主角平滑移動，不會一格內跳位置。
	player.velocity.y = -380.0
	largest = 0.0
	last = tray._slot_position(far)
	for i in 50:
		await frames(1)
		var now := tray._slot_position(far)
		if now.distance_to(last) > largest:
			print("TRAY_STEP ", JSON.stringify({"distance":now.distance_to(last),"physics":Engine.get_physics_frames(),"process":Engine.get_process_frames(),"process_delta":tray.get_process_delta_time(),"slot":str(now),"last":str(last),"pos":str(tray._pos),"player":str(player.global_position),"canvas":str(tray.get_viewport().get_canvas_transform()),"above":tray._above,"side":tray._draw_side}))
		largest = maxf(largest, now.distance_to(last))
		last = now
	check(largest < 24.0, "跳躍時彈帶平滑移動（每格最多 %.1f 畫面像素）" % largest)
	# 跑步穿過切換點：從左緣面向右往畫面中間跑，彈帶從頭頂回到背後，過程平滑。
	player.global_position.x = 20.0
	Input.action_press(&"aim_right")
	await frames(40)
	Input.action_press(&"move_right")
	largest = 0.0
	last = tray._slot_position(far)
	var was_above := tray._above
	for i in 240:
		await frames(1)
		var now := tray._slot_position(far)
		if now.distance_to(last) > largest:
			print("TRAY_STEP ", JSON.stringify({"distance":now.distance_to(last),"physics":Engine.get_physics_frames(),"process":Engine.get_process_frames(),"process_delta":tray.get_process_delta_time(),"slot":str(now),"last":str(last),"pos":str(tray._pos),"player":str(player.global_position),"canvas":str(tray.get_viewport().get_canvas_transform()),"above":tray._above,"side":tray._draw_side}))
		largest = maxf(largest, now.distance_to(last))
		last = now
		if tray._above < 0.01:
			break
	Input.action_release(&"move_right")
	Input.action_release(&"aim_right")
	check(was_above > 0.99 and tray._above < 0.01, "跑離畫面邊緣後彈帶從頭頂回到背後")
	check(largest < 24.0, "跑步經過切換點時彈帶平滑移動（每格最多 %.1f 畫面像素）" % largest)
	await end_level(level)
