extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const TEST_LEVEL := "res://data/levels/level_01.tres"
const SHOT := "res://data/projectiles/grunt_shot.tres"
const ID := &"grunt_shot"

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://defeat-language-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	DefeatCodex.persist = false
	await _exercise("en", "Bullseye", "Crouch or jump when the red line brightens and locks on.", "Details")
	await _exercise("ja", "ど真ん中", "赤い線が明るくなったら照準確定。しゃがむか跳んで避ける。", "詳細")
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(1 if _fails else 0)


func _exercise(language: String, title: String, hint: String, detail_caption: String) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	DefeatCodex.restore_unlocked([])
	Story.auto_skip = true
	var data := load(TEST_LEVEL) as LevelData
	Story._seen[data.intro_scene] = true
	for scene: String in data.story_triggers:
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(data)
	add_child(level)
	await _frames(215)
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		enemy.set_physics_process(false)
	var player := level.player
	player.health.setup(1, 0.0)
	var packed := load(SHOT) as ProjectileSpec
	var origin := player.global_position + Vector2(14, -Player.BODY_SIZE.y * 0.5)
	ProjectilePool.spawn(packed, origin, Vector2.LEFT, Combat.Team.ENEMY)
	var screen: DeathScreen
	for frame in 120:
		for node: Node in level.get_children():
			if node is DeathScreen:
				screen = node
				break
		if screen != null:
			break
		await _frames(1)
	_check(player.is_dead() and level._death_cause == ID and DefeatCodex.unlocked_ids() == [ID],
			"an actual Sweeper projectile unlocks the original defeat ID")
	_check(screen != null, "the level opens the normal death screen")
	if screen != null:
		await _frames(20)
		print("DEATH ", language, " ", screen._card["title"], " | ", screen._card["hint"])
		_check(screen._card["title"] == title and screen._card["hint"] == hint
				and _has_label(screen, title) and _has_label(screen, hint, true),
				"the actual death card shows its translated title and tactic")
		var box := screen._hint_slot.get_global_rect()
		var view := screen.get_viewport().get_visible_rect()
		var action := screen.get_viewport().gui_get_focus_owner() as Button
		_check(action != null and view.grow(0.5).encloses(box)
				and view.encloses(action.get_global_rect()),
				"the focused retry and its help stay on screen at 120%")
		var scroll := screen.get("_file_scroll") as ScrollContainer
		if scroll != null:
			var bar := scroll.get_v_scroll_bar()
			if bar.max_value > bar.page + 1.0:
				var start := scroll.scroll_vertical
				if language == "en":
					await _page_down()
				else:
					await _right_stick_down()
				_check(scroll.scroll_vertical > start and action.has_focus(),
						"PageDown or the right stick reads the card without losing retry focus")
		await _picture("death-" + language + ".png")
	level.queue_free()
	get_tree().paused = false
	await _frames(8)
	var menu := MainMenu.new()
	add_child(menu)
	await _frames(7)
	menu._open_codex()
	await _frames(9)
	var archive: CodexScreen
	for node: Node in menu.find_children("*", "", true, false):
		if node is CodexScreen:
			archive = node
			break
	_check(archive != null and archive._current_tab == 0, "the real title menu opens the defeat archive")
	if archive != null:
		var wall := archive._defeat_body.get_child(0) as ScrollContainer
		var grid := wall.get_child(0)
		var known := grid.get_child(0) as UiCard
		var hidden := grid.get_child(1) as UiCard
		known.grab_focus()
		await _frames(3)
		print("ARCHIVE ", language, " ", archive._detail_title.text, " | ", known.tooltip_text)
		_check(known.has_focus() and archive._detail_title.text == title and known.tooltip_text == hint
				and _has_label(archive, detail_caption),
				"archive hover, selected card and detail heading match the selected language")
		var back := archive._legend.get_parent().get_children().back() as Control
		_check(archive.get_viewport_rect().encloses(back.get_global_rect()),
				"the localized archive keeps the return action inside the view at 120%")
		await _picture("archives-" + language + ".png")
		hidden.grab_focus()
		await _frames(3)
		var expected_locked := "Unlocks the first time this defeats you." if language == "en" else "この敗因で一度倒れると解放されます。"
		_check(hidden.has_focus() and archive._detail_hint.text == expected_locked
				and hidden.tooltip_text == expected_locked and archive._detail_title.text == "？？？",
				"locked card explains unlock in the locale and preserves the hidden identity")
	menu.queue_free()
	await _frames(7)


func _has_label(root: Node, expected: String, substring := false) -> bool:
	for label: Node in root.find_children("*", "Label", true, false):
		if label is Label and label.is_visible_in_tree() and (label.text.contains(expected) if substring else label.text == expected):
			return true
	return false


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	if not ok:
		printerr("FAIL: ", message)


func _page_down() -> void:
	var event := InputEventKey.new()
	event.keycode = KEY_PAGEDOWN
	event.physical_keycode = KEY_PAGEDOWN
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(6)


func _right_stick_down() -> void:
	var event := InputEventJoypadMotion.new()
	event.axis = JOY_AXIS_RIGHT_Y
	event.axis_value = 0.95
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.axis_value = 0.0
	Input.parse_input_event(event)
	await _frames(6)
