from itertools import groupby
from pathlib import Path
from statistics import median
import json
import math
import sys

base = Path(__file__).resolve().parent
candidate = sys.argv[1]
stock = sys.argv[2] if len(sys.argv) > 2 else "stock-final"


def get_case(label):
    run = json.loads((base / label / "stage-walk.json").read_bytes())
    assert run["facts_unchanged"] and run["hdr"] and run["renderer"] == "forward_plus"
    assert "9070 XT" in run["adapter"] and len(run["rows"]) == 24
    return run


def report(rows):
    assert all(row["stage_grounded"] for row in rows)
    depths = [max(row["front"][1], row["back"][1]) - row["floor"] for row in rows]
    assert all(math.isfinite(depth) for depth in depths)
    return {
        "frames": len(rows),
        "gait_active": sum(row["gait"] for row in rows),
        "minimum_depth": min(depths),
        "median_depth": median(depths),
        "maximum_depth": max(depths),
        "max_depth_frame": rows[depths.index(max(depths))]["frame"],
        "frames_over_one": sum(depth > 1.0 for depth in depths),
    }


old, new = get_case(stock), get_case(candidate)
assert len(old["soles"]) == len(new["soles"]) == 280
for before, after in zip(old["rows"], new["rows"], strict=True):
    assert all(before[key] == after[key] for key in before if key != "shoulder")
for before, after in zip(old["soles"], new["soles"], strict=True):
    assert all(before[key] == after[key] for key in ("scene", "direction", "frame", "world", "floor", "speed"))
def groups(rows):
    sequence = sorted(rows, key=lambda row: (row["scene"], row["direction"], row["frame"]))
    return {key: list(group) for key, group in groupby(sequence, key=lambda row: (row["scene"], row["direction"]))}


before = groups(old["soles"])
after = groups(new["soles"])
result = {}
for (scene, side), rows in before.items():
    matched = after[scene, side]
    held = []
    for i in range(1, len(rows)):
        n0, n1 = matched[i - 1:i + 1]
        if min(n0["weight"], n1["weight"]) < 0.99:
            continue
        for foot in ("front", "back"):
            if any(max(row["front"][1], row["back"][1]) - row[foot][1] > 0.08 for row in (n0, n1)):
                continue
            original = abs(rows[i][foot][0] - rows[i - 1][foot][0])
            updated = abs(n1[foot][0] - n0[foot][0])
            held.append((original, updated))
    previous, current = zip(*held)
    result[f"{scene}/{side}"] = {"before": report(rows), "after": report(matched), "held_pairs": len(held),
                                 "median_held_slide_before": median(previous), "median_held_slide_after": median(current)}
(base / f"result-{candidate}.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
