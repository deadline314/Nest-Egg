extends ScenarioBase

var _records: Dictionary = {}


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	for profile in ["sunny_day", "warehouse_interior", "blackout"]:
		await open_arena("res://data/lighting/%s.tres" % profile)
		player.health.setup(player._max_health, player.tuning.hurt_invulnerability)
		var inventory := level._inventory
		var status_index := inventory.page_index(StatusPage)
		var status := inventory._pages[status_index] as StatusPage
		inventory.open()
		inventory.select_tab(status_index)
		status.refresh()
		await settle(10)
		await RenderingServer.frame_post_draw
		var portrait := status._portrait
		var image := portrait._viewport.get_texture().get_image()
		var colors := _measure(image)
		_records[profile] = {"level_fill": LightKit.character_fill, "portrait_fill": portrait._rig._fill,
			"last_pose": str(portrait._rig.bone(&"chest").transform), "pixels": colors}
		capture(profile)
		inventory.close()
		await finish()
		level = null
	var size := get_window().size
	var report := {"readings": _records, "adapter": RenderingServer.get_video_adapter_name(),
		"size": [size.x, size.y], "scale": Settings.get_ui_text_scale(), "capture_failures": failures}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)


func _measure(image: Image) -> Dictionary:
	var digest := HashingContext.new()
	digest.start(HashingContext.HASH_SHA256)
	digest.update(image.get_data())
	var opaque := 0
	var clipped := 0
	var box := image.get_used_rect()
	for y in range(box.position.y, box.end.y):
		for x in range(box.position.x, box.end.x):
			var color := image.get_pixel(x, y)
			if color.a >= 0.98:
				opaque += 1
				if minf(color.r, minf(color.g, color.b)) >= 0.98:
					clipped += 1
	return {"digest": digest.finish().hex_encode(), "opaque": opaque, "near_white": clipped,
		"size": [image.get_width(), image.get_height()]}
