from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
runner = root / 'work/run-ne97-street-combat-20261119.py'
route = root / 'work/ne97-campaign-route-20261119'
stages = {
    'street': ('before-radio-v2', ()),
    'blockade': ('native-combat-v2', ('--bypass-hardcore-blockade',)),
    'warehouse': ('native-blockade-v3', ('--defensive-watchdog', '--difficulty-audit')),
    'flood': ('native-warehouse-v2', ()),
}
results = []
version = next((arg.removeprefix('--version=') for arg in sys.argv[1:] if arg.startswith('--version=')), 'v1')
for mode in [arg for arg in sys.argv[1:] if not arg.startswith('--')] or stages:
    source, extra = stages[mode]
    slot = route / source / 'save/slot.json'
    expected = sha256(slot.read_bytes()).hexdigest()
    for profile in ('close', 'wide'):
        slug = f'native-ne256-projectile-{mode}-{profile}-{version}'
        flags = ['--camera-audit', '--camera-projectile-audit', *extra]
        if '--forecourt' in sys.argv:
            flags.append('--camera-forecourt-stop')
        if profile == 'wide':
            flags.append('--camera-wide')
        print(mode, profile, expected, flush=True)
        case = subprocess.run([sys.executable, '-B', str(runner), slug, source, mode, *flags], cwd=root)
        result = {'mode': mode, 'profile': profile, 'run': slug, 'exit': case.returncode, 'start_sha256': expected}
        assert sha256(slot.read_bytes()).hexdigest() == expected
        results.append(result)
        record = 'results.json' if version == 'v1' else f'results-{version}.json'
        (base / record).write_text(json.dumps(results, indent=2) + '\n')
    # A badly matched first pair means the observer needs correction before more runs.
    if mode == 'street':
        for result in results:
            path = route / result['run'] / 'camera-observations.json'
            data = json.loads(path.read_bytes())
            assert any(event.get('shot_match') == 'exact' for event in data['damage']), result
