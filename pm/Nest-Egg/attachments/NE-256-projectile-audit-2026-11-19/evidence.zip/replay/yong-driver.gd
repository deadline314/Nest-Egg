extends "res://tools/scenarios/yong_fight_scenario.gd"

var _guard_box := false


func use_current_fight(active_level: Level, yong: PatternBoss) -> void:
	level = active_level
	player = level.player
	_yong = yong
	_use_pad = true
	_guard_box = "--hardcore-box-guard" in OS.get_cmdline_user_args()
	AimInput.set_virtual_gamepad(player, true)
	player.health.damaged.connect(_on_player_damaged)


func drive_frame() -> void:
	_elapsed += get_physics_process_delta_time()
	_drive()
	if _guard_box:
		var at_box_stage := str(_yong.get("stage")) == "cut_box" and player.is_on_floor()
		var throwing := _yong.current_move() == &"paper_fan" and (_yong.fsm.is_in(&"windup") or _yong.fsm.is_in(&"act"))
		var defend := at_box_stage and (Input.is_action_pressed(&"interact") or throwing or _sheet_close())
		_set_action(&"block", defend)
		if defend:
			_set_action(&"jump", false)
			_set_stick(Vector2(signf(_yong.global_position.x - player.global_position.x), 0.0))
			if not Input.is_action_pressed(&"interact"):
				_set_action(&"shoot", false)


func release_driver() -> void:
	_release_all()
	Input.action_release(&"block")
	if is_instance_valid(player):
		AimInput.set_virtual_gamepad(player, false)
	print("NE97_YONG totals hit_count=", _hits_taken, ", damage=", _damage_taken, ", combat_seconds=", _elapsed)


func _on_player_damaged(info: DamageInfo) -> void:
	super._on_player_damaged(info)
	print("NE97_YONG_DAMAGE ", JSON.stringify({"source":info.source_id,"amount":info.amount,"health":player.health.current,
		"guard":player.guard,"position":player.global_position,"boss":_yong.global_position,
		"stage":_yong.get("stage"),"move":_yong.current_move()}))
