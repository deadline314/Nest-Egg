from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil,re
root=Path.cwd();w=root/'work/ne228-motion';base=Path('/workspace/Nest-Egg/work/batch1020b');out=root/'pm/Nest-Egg/attachments/NE-228-prompt-motion';out.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads((w/'changed-receipt.json').read_text());assert receipt['exit_code']==0
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
native=json.loads((w/'final-native-validation.json').read_text());assert len(native)==6 and all(r['completed'] and r['engine_errors']==0 and r['leaks']==0 and r['individually_viewed'] for r in native);assert all(r['exit_code']==r['expected'] for r in native)
assert all(r['original_assertions_byte_exact'] for r in json.loads((w/'original-test-reconstruction.json').read_text()))
t=(w/'changed.log').read_text();assert 'new failures: 0' in t and 'Detected script errors' not in t
harness=['tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt','tests/helpers/contextual_priority_checks.gd']
for p in harness:assert (root/p).read_bytes()==subprocess.check_output(['git','show','d9f6a85c:'+p]),p
files={}
for p in w.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in part or part=='__pycache__' for part in p.relative_to(w).parts):files['work/ne228-motion/'+str(p.relative_to(w))]=p.read_bytes()
for d in sorted(base.glob('ne228-1022-prompt-motion*'))+sorted(base.glob('ne228-1022-font-*')):
 if d.is_dir() and not d.name.endswith('-profile'):
  for p in d.rglob('*'):
   if p.is_file():files['native/'+d.name+'/'+str(p.relative_to(d))]=p.read_bytes()
 elif d.is_file():files['native/'+d.name]=d.read_bytes()
for p in (root/'work/ne228-bubbles/references').rglob('*'):
 if p.is_file():files['references/'+str(p.relative_to(root/'work/ne228-bubbles/references'))]=p.read_bytes()
paths=list(json.loads((w/'verification-frozen-source.json').read_text()))+harness+['game/level/world_text_layout.gd','game/level/map_bubbles.gd','design/20-campaign-experience/WORLD_PROMPT_MOTION.md','tools/viewport_capture.gd']
for p in paths:files['source/final/'+p]=(root/p).read_bytes()
for p in ['game/level/world_prompt.gd','game/level/prompt_layout.gd','ui/quest_guidance.gd','ui/kit/ui_banner.gd','ui/ui_kit.gd','tests/suite/test_world_prompt.gd','tests/suite/test_quest_map.gd']:files['source/before/'+p]=subprocess.check_output(['git','show','d9f6a85c:'+p])
summary=[l for l in t.splitlines() if 'checks:' in l or re.search(r'Running \d+ groups',l)]
validation={'base':'d9f6a85ca3e2aff29fb31b6d68a796aedc25da8f','affected':receipt,'affected_summary':summary,'native':native,'original_tests_byte_exact':True,'additional_checks':13,'harness_unchanged':harness,'font_public_native':{'original_errors':8,'retained_reference_errors':0,'fixed_errors':0},'history':'v1/v2 geometry and HUD assertions passed but font errors invalidate clean engine claim; v3 1080 only12 visible frames/24 failed; v4 moved settings after Main but font errors persisted; v5 retains original16 minimum and samples72 frames across real notification exit, before motion controls retain final font lifecycle fix; partial broad run stopped and retained','scope':'Forward+ HDR software Vulkan llvmpipe, actual Main and actual authored vault sign/disc with declared route prerequisites, positioned actors, survival floor1 and held actor physics for text animation only. Registered player reading rectangles are not full rendered-alpha silhouette/joint audits. No human, physical GPU/controller or full chapter acceptance.'}
(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for p,b in files.items():assert sha(z.read(p))==sha(b),p
manifest={'archive_bytes':(out/'raw.zip').stat().st_size,'archive_sha256':sha((out/'raw.zip').read_bytes()),'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for case,frame,dest in [('before',0,'before'),('after',0,'after'),('before1080',4,'before1080'),('1080',48,'1080'),('smooth',16,'smooth'),('reduced',16,'reduced')]:shutil.copyfile(base/('ne228-1022-prompt-motion-'+case+'-v5')/('motion-%02d.png'%frame),root/('pm/Nest-Egg/images/NE-228-prompt-motion-'+dest+'.png'))
r={'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256'],'validation':validation};(w/'package-receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='validation'},indent=2))
