from pathlib import Path
import subprocess,os,json,hashlib,time
root=Path.cwd();w=root/'work/ne228-motion';deadline=time.monotonic()+800
while True:
 rows=json.loads((w/'native-receipt.json').read_text()) if (w/'native-receipt.json').exists() else []
 if any(r["exit_code"]!=r["expected"] for r in rows):raise SystemExit("native matrix failed; no broad run")
 if len(rows)==6:break
 assert time.monotonic()<deadline
 time.sleep(1)
assert all(r['exit_code']==r['expected'] for r in rows)
for p,h in json.loads((w/'native-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
files=['game/level/world_prompt.gd','game/level/prompt_layout.gd','ui/quest_guidance.gd','ui/kit/ui_banner.gd','ui/ui_kit.gd','tests/suite/test_world_prompt.gd','tests/suite/test_quest_map.gd','tools/quest_resume_probe.gd','work/ne228-motion/probe.gd','work/ne228-motion/item_base.gd','work/ne228-motion/phone_base.gd']
(w/'verification-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2))
env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6',LOG_DIR=str(w/'changed-shards'))
cmd=['tools/run_tests_changed.sh','d9f6a85c'];start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1400)
(w/'changed-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2));print(r.returncode,flush=True)
