from pathlib import Path
import subprocess,os,json,time
root=Path.cwd();w=root/'work/ne228-motion';files=['game/level/world_prompt.gd','game/level/prompt_layout.gd'];final={p:Path(p).read_bytes() for p in files};env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1');rows=[]
def run(label):
 child=env.copy();child['LOG_DIR']=str(w/(label+'-shards'));cmd=['tools/run_tests_parallel.sh','--only=WorldPromptSuite'];start=time.monotonic()
 with (w/(label+'.log')).open('w') as f:r=subprocess.run(cmd,env=child,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 t=(w/(label+'.log')).read_text();rows.append({'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start});(w/'focus-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);assert 'Detected script errors' not in t;return r.returncode
try:
 for p in files:Path(p).write_bytes((w/(Path(p).stem+'-before.gd')).read_bytes())
 assert run('negative-v2')==1
finally:
 for p,b in final.items():Path(p).write_bytes(b)
assert run('fixed-v2')==0
