extends Node
func _ready()->void:
	await get_tree().process_frame
	var label:=UiKit.label("字型切換",11)
	label.add_theme_font_override("font",UiKit.font())
	add_child(label)
	await RenderingServer.frame_post_draw
	if OS.get_cmdline_user_args().has("--retain"):
		var previous:=UiKit._font.base_font
		Settings.set_ui_font("pixel")
		print("RETAIN ",previous!=null)
	else:
		Settings.set_ui_font("pixel")
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	print("FONT_END")
	get_tree().quit()
