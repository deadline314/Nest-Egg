from pathlib import Path
import json,time,subprocess
w=Path('work/ne228-motion');deadline=time.monotonic()+900
while not (w/'changed-receipt.json').exists():
 assert time.monotonic()<deadline
 time.sleep(1)
assert json.loads((w/'changed-receipt.json').read_text())['exit_code']==0,'affected tests failed'
for script in ['package.py','final-docs.py']:
 r=subprocess.run(['python',str(w/script)],check=True)
subprocess.run(['git','diff','--check'],check=True)
print('PACKET_READY',flush=True)
