from pathlib import Path
import json
w=Path('work/ne228-motion');r=json.loads((w/'package-receipt.json').read_text());v=r['validation'];summary=v['affected_summary'][-1];native=v['native'];positive=[n for n in native if n['expected']==0];checks=sum(n['checks'] for n in positive);frames=sum(n['frames'] for n in positive);viewed=sum(n['png_count'] for n in native)
out=Path('pm/Nest-Egg/attachments/NE-228-prompt-motion/README.md')
out.write_text(f'''# NE-228 世界提示動畫與閱讀優先

ST-9真正取資料盤後，長路牌最後位置安全，但第一格仍穿過凜；1080p短通知與長牌也會疊字。目標更新閃亮動畫會把已讓位的目標列alpha推回1；目的地標籤也沒讓出閱讀位置。現在先安全定位才淡入，只有完整直線路徑安全時才滑動，減少動態直接定位；通知保留整個滑行範圍，目標列與方向標籤讓位後按原規則恢復。

開始前讀User-guide最新取盤紀錄。Night in the Woods、Oxenfree、Eastward九張正式Steam圖沿用前批已看原圖，採用有限閱讀位置、完整多行與清楚指向；不從靜態研究圖推論對方動畫邏輯。參考原圖、URL及SHA都在raw，與本作證據分開。

## 最終驗證

| 項目 | 結果 |
|---|---|
| 原套件原斷言 | 兩份逐byte可重建；增加13項；原helper、runner、selector、filters及known failures不變 |
| 原生前後控制 | 舊四個排版檔、720p重現3項，1080p重現4項；兩組保留本次字型生命週期修正 |
| 四組修後原生 | {checks}項／0失敗，{frames}格逐格矩形帳；720p、1080p120%、平滑120%、減動態120% |
| 圖片 | 六組共{viewed}張原圖逐張檢視，包含寫入拒絕畫面與第0／4／16／48格 |
| 引擎與資源 | 最終六程序exit符合預期，0引擎／腳本ERROR、0洩漏診斷 |
| 原受影響整輪 | {summary} |
| 字型公開切換 | 同條件原版8個fd=null；持有參照控制0、正式修後0 |

每組保留72格，不刪原有「至少16格可見」條件。四組修後可見格數分別是{[n['visible_frames'] for n in positive]}；所有可見格不碰人物已登記的閱讀範圍與通知，所有需要讓位的HUD／方向標籤都已讓位。這是登記矩形檢查，不能稱成角色完整alpha輪廓或關節稽核。

## 原受影響整輪曾崩潰

第一輪原66組有一程序在Chapter2Expansion後出現root跨執行緒通知，接著SIGSEGV；整輪exit1，其餘59,884項／0斷言失敗不算整輪通過。未修改d9f6a85c在另一個本Session工作樹以同12套件順序對照，4,838／0、415.6秒，沒有重現該崩潰，但退出留下6 CanvasItem、16 ObjectDB、8 resource與6 Area RID的診斷，不能稱乾淨log。原過濾器對這些退出診斷的既有規則未改。後輪完整66組使用相同產品和原選擇器重跑，結果列在上表；成功重跑不能定位或抹掉前輪崩潰。

## 保留的失敗

早期減動態fixture在切設定後未重新結算layout，修後仍1失敗，原檔保留；更正fixture後同案原版41／3、修後41／0。目標列新增檢查原版343／3，修後與世界提示384／0；通知／方向標籤原版389／2，修後加UiKit共476／0。

v1／v2斷言只驗人物或人物＋目標列，且帶切字型引擎錯誤，不列乾淨原生通過。v2實看1080p後新增通知與方向標籤範圍；停止本Session尚未結束的舊整輪，原程序辨識與半輪輸出保留。v3在1080p24格僅12格可見，16格可見條件失敗；其餘幾項通過不抵銷此失敗。v4把設定移到Main建立後仍有8個引擎錯誤。獨立公開切字型控制證明需在同步重排期間保留舊資源，本次已修；最終v5延伸到72格橫跨真正通知退出，原格數檢查保留，六程序皆無引擎錯誤。

[validation.json](validation.json)保存精確命令與數值，[manifest.json](manifest.json)有逐檔SHA，[raw.zip](raw.zip)有{r['entries']}檔，{r['bytes']:,} bytes，SHA256 `{r['sha256']}`。已解壓測試並逐檔核對SHA。source/final與測試前freeze逐檔比對；source/before來自d9f6a85c。含原始失敗、完整最終shards、所有原生版本／探針、字型控制和前版完整CI原始log。

Godot4.7.2、Forward+ HDR、llvmpipe軟體Vulkan與Xvfb。真正Main、正式資料盤及中文長路牌，英文劇本＋實際120%文字；明示路線前置、位置、存活下限1，暫停角色物理僅讓文字動畫可重播。不是平衡、真人、實體GPU／手把、全章翻譯或整票驗收。最終平滑／減動態第0格另見右上取得小提示壓到人物氣泡，方向標籤初期也蓋人物；原圖保留，這兩項不是本批矩形通過的範圍，不宣稱全HUD已解決。戰鬥／角色動作也不能由文字矩形外推。
''')
p=Path('pm/Nest-Egg/[NE-228]重整全遊戲介面體驗.md');s=p.read_text();assert '# Commit-21' not in s;s+='''
# Commit-21

## 內文

路牌已避開人物的最後位置，出現與移動途中卻仍可能遮人。現在新提示先在安全處淡入，移動途中也避開人物、其他文字與HUD；減少動態直接定位。短通知出現時保留閱讀空間，通知結束後路牌回來。任務目標閃亮不再讓已收起的目標列突然透出，方向標籤也會讓出世界閱讀位置。

另外修正切換介面字型時的引擎錯誤；同條件公開切換從8錯誤變為0。原生前後對照在720p重現3項、1080p重現4項，修後四組放大文字／字型／減動態皆通過。''' + f'最終{checks}項、{frames}格、六輪{viewed}張圖逐張檢視，0引擎ERROR。原受影響整輪：{summary}。\n\n' + '''[實圖參考、連續畫面、全部中途失敗與原始測試](attachments/NE-228-prompt-motion/README.md)。保留原驗收狀態，不以雲端合成輸入代替實體流程。

| 同條件修前 | 修後 |
|---|---|
| ![出現第一格仍穿過人物](images/NE-228-prompt-motion-before.png) | ![第一格先避開人物與通知](images/NE-228-prompt-motion-after.png) |
| ![1080p通知與路牌疊字](images/NE-228-prompt-motion-before1080.png) | ![1080p通知結束後恢復清楚路牌](images/NE-228-prompt-motion-1080.png) |

![平滑字型與120%文字](images/NE-228-prompt-motion-smooth.png)
![減少介面動態與120%文字](images/NE-228-prompt-motion-reduced.png)
''';p.write_text(s)
p=Path('pm/user_guide.md');s=p.read_text();i=s.index('\n2026-10-22（ST-9）');s=s[:i]+'''\n2026-10-22（NE-228）：世界文字要驗出現與移動途中，不能只拍最後位置；閱讀讓位的alpha不能被目標更新的閃亮動畫寫回。短通知要保留完整滑動範圍，方向標籤遇到閱讀內容也讓位。[六輪連續圖與全部中途失敗](Nest-Egg/attachments/NE-228-prompt-motion/README.md)，原斷言逐字保留；切換字型要保留舊資源直到同步重排完成，否則原生引擎會報fd=null。''' +f'修後四組{checks}／0、{frames}格，六組{viewed}圖逐張看過。\n'+s[i:];p.write_text(s)
