extends "res://work/ne228-motion/item_base.gd"
var motion_frames:Array=[]
var _captured_motion:=false
func _ready()->void:
	Story.set_language("en")
	Settings.set_ui_font("pixel")
	Settings.set_ui_text_scale(1.0)
	for arg in OS.get_cmdline_user_args():
		if arg=="--1080":
			get_window().size=Vector2i(1920,1080)
			DisplayMode.ensure_scaling(get_window())
			Settings.set_ui_text_scale(1.2)
		elif arg=="--smooth":
			Settings.set_ui_font("smooth")
			Settings.set_ui_text_scale(1.2)
		elif arg=="--reduced":
			Settings.set_reduce_ui_motion(true)
			Settings.set_ui_text_scale(1.2)
	super._ready()
func _save_report()->void:
	super._save_report()
	var file:=out.path_join("result.json")
	var d:Dictionary=JSON.parse_string(FileAccess.get_file_as_string(file))
	d["motion_frames"]=motion_frames
	d["scope"]="actual Main and authored vault sign after actual disc collection; explicit prerequisite flags/positions/survival1, held actor physics for repeatable text animation only, public save retry; not combat balance or human/hardware acceptance"
	FileAccess.open(file,FileAccess.WRITE).store_string(JSON.stringify(d,"\t"))
func _shot(label:String)->void:
	if label!="write-accepted" or _captured_motion:
		await super._shot(label)
		return
	_captured_motion=true
	var prompt:WorldPrompt
	for entry:WorldPrompt in PromptLayout._prompts:
		if _level().is_ancestor_of(entry) and entry.text.contains("保險箱") and entry.text.contains("資料盤"):
			prompt=entry
	_check(prompt!=null,"actual authored vault instruction is present for continuous motion")
	if prompt==null:return
	var player:=_level().player
	player.set_physics_process(false)
	for enemy in _level().find_children("*","",true,false):
		if enemy is Enemy:enemy.set_physics_process(false)
	var anchor:=prompt.global_position-prompt.offset
	player.global_position=anchor+Vector2(-160,0)
	player.velocity=Vector2.ZERO
	_level().camera.snap_to_target()
	_check(await _until(func()->bool:return prompt._alpha<=0.0 and prompt._nudge.length()<0.01,5.0),"leaving actual hint range retires its previous reading position")
	player.global_position=anchor+Vector2(10,0)
	player.velocity=Vector2.ZERO
	_level().camera.snap_to_target()
	var clear:=true
	var visible_frames:=0
	var goal_clear:=true
	var covered_goal_frames:=0
	for frame in 24:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var box:=Rect2(prompt.base_rect().position+prompt._nudge,prompt.base_rect().size)
		var body:=player.prompt_obstacle_rect()
		var shown:=prompt.visible and prompt._layout_allowed and prompt._alpha>0.02 and not prompt._presentation_blocked()
		var overlap:=shown and box.intersects(body)
		var guidance:=_guidance()
		var goal_covered:=PromptLayout.covers(guidance.row_world_rect())
		covered_goal_frames+=int(goal_covered)
		goal_clear=goal_clear and (not goal_covered or guidance._row.modulate.a<=0.01)
		visible_frames+=int(shown)
		clear=clear and not overlap
		motion_frames.append({"frame":frame,"goal_covered":goal_covered,"goal_alpha":_guidance()._row.modulate.a,"yielding":_guidance().yielding,"shown":shown,"alpha":prompt._alpha,"overlap":overlap,"nudge":[prompt._nudge.x,prompt._nudge.y],"target":[prompt._nudge_target.x,prompt._nudge_target.y],"box":[box.position.x,box.position.y,box.size.x,box.size.y],"body":[body.position.x,body.position.y,body.size.x,body.size.y]})
		if frame in [0,4,16]:
			_check(preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(out.path_join("motion-%02d.png"%frame))==OK,"continuous native frame "+str(frame))
	_check(visible_frames>=16,"actual instruction is visible through the animation sample")
	_check(clear,"every visible native motion frame avoids the real player silhouette")
	_check(goal_clear,"every covered native objective frame yields without pulse alpha revival")
	rows.append({"name":"motion-summary","covered_goal_frames":covered_goal_frames,"player_clear":clear,"goal_clear":goal_clear})
	_save_report()
