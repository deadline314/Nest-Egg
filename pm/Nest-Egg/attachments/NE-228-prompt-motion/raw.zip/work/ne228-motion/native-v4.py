from pathlib import Path
import os,subprocess,json,hashlib
root=Path.cwd();w=root/'work/ne228-motion';env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/quests';files=['game/level/world_prompt.gd','game/level/prompt_layout.gd','ui/quest_guidance.gd','ui/kit/ui_banner.gd'];final={p:Path(p).read_bytes() for p in files};rows=[]
(w/'native-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files+['work/ne228-motion/probe.gd','work/ne228-motion/item_base.gd','work/ne228-motion/phone_base.gd','tools/quest_resume_probe.gd']},indent=2))
def run(label,args,expected):
 n='ne228-1022-prompt-motion-'+label+'-v4';cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',n,'res://work/ne228-motion/probe.tscn','--mode=write','--save-dir='+str(w/(label+'-v4-save')),*args]
 with (w/(label+'-wrapper.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
 rows.append({'label':label,'name':n,'command':cmd,'exit_code':r.returncode,'expected':expected});(w/'native-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);log=Path('/workspace/Nest-Egg/work/batch1020b')/(n+'.log');assert 'ERROR:' not in log.read_text(), 'native engine errors';assert r.returncode==expected
try:
 for p in files:Path(p).write_bytes((w/(Path(p).stem+'-before.gd')).read_bytes())
 run('before',[],1)
 run('before1080',['--1080'],1)
finally:
 for p,b in final.items():Path(p).write_bytes(b)
for label,args in [('after',[]),('1080',['--1080']),('smooth',['--smooth']),('reduced',['--reduced'])]:run(label,args,0)
