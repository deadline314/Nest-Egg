from pathlib import Path
import json,time,subprocess,os,hashlib,shutil
w=Path('work/ne228-motion');deadline=time.monotonic()+900
while not (w/'changed-receipt.json').exists() or not (w/'crash-baseline-receipt.json').exists():
 assert time.monotonic()<deadline
 time.sleep(1)
first=json.loads((w/'changed-receipt.json').read_text());baseline=json.loads((w/'crash-baseline-receipt.json').read_text());assert first['exit_code']!=0,first
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
for name in ['changed.log','changed-receipt.json','verification-frozen-source.json']:
 shutil.copy2(w/name,w/(name.replace('.log','-v5-crashed.log').replace('.json','-v5-crashed.json')))
shutil.move(w/'changed-shards',w/'changed-v5-crashed-shards')
env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6',LOG_DIR=str((w/'changed-shards').resolve()))
(w/'changed-receipt.json').unlink();cmd=['tools/run_tests_changed.sh','d9f6a85c'];start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1400)
(w/'changed-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'prior_run':'changed-v5-crashed.log','baseline_control_exit':baseline['exit_code'],'note':'Unchanged code, selector, harness, assertions and filters. A successful retry alone does not establish crash root cause.'},indent=2));print(r.returncode,flush=True)
