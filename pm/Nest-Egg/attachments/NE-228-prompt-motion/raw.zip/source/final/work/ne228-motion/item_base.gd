extends "res://work/ne228-motion/phone_base.gd"
const WAREHOUSE := "res://data/levels/ch1_vault.tres"
class FaultStore extends RunSaveStore:
	var mutate := false
	var reject := false
	var reject_rollback := false
	func _durable_phase(phase:DurablePhase,_absolute:String)->void:
		if mutate and phase==DurablePhase.PRIMARY_COMMITTED:
			Progression.add_credits(1)
	func _durable_rename(absolute:String,phase:DurablePhase)->Error:
		return ERR_CANT_CREATE if reject and phase==DurablePhase.PRIMARY_COMMITTED else super._durable_rename(absolute,phase)
	func _durable_rollback(absolute:String)->Error:
		return ERR_CANT_CREATE if reject_rollback else super._durable_rollback(absolute)

var before_disk := PackedByteArray()
var listener_case:=false
var recovery_case:=false
var rollback_case:=false
var credits_before:=0
var observed: Array = []
var cancel_case := false
var source_key := ""

func _ready() -> void:
	cancel_case=OS.get_cmdline_user_args().has("--cancel-case")
	listener_case=OS.get_cmdline_user_args().has("--listener-case")
	recovery_case=OS.get_cmdline_user_args().has("--postcommit-case")
	rollback_case=OS.get_cmdline_user_args().has("--rollback-case")
	super._ready()

func _shot(label: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(out.path_join(label + ".png")) == OK, "capture " + label)
	rows.append({"name":label,"owned":StoryItems.owns(&"ch1_data_disk"),"held":StoryItems.holds(&"ch1_data_disk"),"flag":GameState.has_flag(&"ledger_disk_obtained"),"paused":get_tree().paused})
	_save_report()

func _save_report() -> void:
	FileAccess.open(out.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify({"completed":_completed,"failures":_failures,"mode":_mode,"rows":rows,"notifications":observed,"scope":"actual Main and authored warehouse disc pickup; declared prerequisite route flags and player position, not route combat or whole chapter"},"\t"))

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	await _until(func() -> bool:return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested",GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE),"actual Main new run")
	await _skip_cinematics()
	for flag in [&"ch1_prologue_exit",&"ch1_dinner_done",&"ch1_heard_brief",&"ch1_street_route_open",&"watchdog_defeated",&"ch1_flood_gate_open"]:
		GameState.set_flag(flag)
	await _enter(WAREHOUSE)
	await _read_to_end()
	var pickup:CollectiblePickup
	for node in _level().find_children("*","",true,false):
		if node is CollectiblePickup and node.item.id==&"ch1_data_disk":pickup=node
	_check(pickup!=null,"actual authored disc pickup exists")
	if pickup==null:return
	_check(not StoryItems.owns(&"ch1_data_disk") and not GameState.has_flag(&"ledger_disk_obtained"),"target acquisition has not been injected")
	_main.call("_save_run")
	before_disk=FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json"))
	_check(not before_disk.is_empty(),"real baseline slot exists")
	credits_before=Progression.credits
	StoryItems.acquired.connect(func(item:StoryItemData)->void:
		if item.id==&"ch1_data_disk":
			if listener_case:
				Progression.add_credits(7)
				StoryItems.mark_seen(item.id)
			observed.append({"item":String(item.id),"disk_changed":FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json"))!=before_disk,"flag":GameState.has_flag(&"ledger_disk_obtained")}) )
	_check(DirAccess.make_dir_absolute(_save_dir.path_join("slot.json.tmp"))==OK,"real temp-file directory blocks save")
	_level().player.health.floor_health=1
	for key:String in _level()._tracked:
		if is_same(_level()._tracked[key],pickup):source_key=key
	var original_position:=pickup.global_position
	_level().player.global_position=original_position
	_level().player.velocity=Vector2.ZERO
	await get_tree().create_timer(0.65,true,false,true).timeout
	_check(not StoryItems.owns(&"ch1_data_disk") and not StoryItems.holds(&"ch1_data_disk"),"failed write keeps disc out of backpack")
	_check(not GameState.has_flag(&"ledger_disk_obtained"),"failed write keeps disc objective unfinished")
	_check(is_instance_valid(pickup) and not pickup.is_queued_for_deletion(),"failed write leaves actual pickup in world")
	_check(observed.is_empty(),"failed write announces no acquired item")
	_check(FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json"))==before_disk,"failed write preserves original slot bytes")
	await _shot("write-refused")
	var owner:Node=_main.get("_world_item_completion")
	_check(owner!=null and is_instance_valid(owner.get("_prompt")) and get_tree().paused,"refusal offers real persistent UI and owns pause")
	if owner==null or not is_instance_valid(owner.get("_prompt")):
		DirAccess.remove_absolute(_save_dir.path_join("slot.json.tmp"))
		_completed=true
		_save_report()
		return
	await _press(&"ui_accept")
	await get_tree().create_timer(0.2,true,false,true).timeout
	_check(not StoryItems.owns(&"ch1_data_disk") and FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json"))==before_disk,"public retry while IO is blocked still changes nothing")
	if cancel_case:
		(owner.get("_prompt").cancel_button as Button).grab_focus()
		await _press(&"ui_accept")
		_check(not get_tree().paused and not GameplayLock.is_locked() and is_instance_valid(pickup) and not StoryItems.owns(&"ch1_data_disk"),"public leave-item cancels only this pause and preserves world disc")
		await get_tree().create_timer(0.5,true,false,true).timeout
		_check(not is_instance_valid(owner.get("_prompt")),"same overlap does not immediately reopen refusal")
		_level().player.global_position=original_position+Vector2(-48,0)
		await get_tree().create_timer(0.2,true,false,true).timeout
		_level().player.global_position=original_position
		_level().player.velocity=Vector2.ZERO
		_check(await _until(func()->bool:return is_instance_valid(owner.get("_prompt")),3.0),"leaving and re-entering actual sensor offers collection again")
	DirAccess.remove_absolute(_save_dir.path_join("slot.json.tmp"))
	if recovery_case or rollback_case:
		var fault:=FaultStore.new(_save_dir.path_join("slot.json"))
		fault.validator=RunSnapshot.prepare
		fault.mutate=recovery_case
		fault.reject=rollback_case
		fault.reject_rollback=rollback_case
		_main.set("_run_store",fault)
	await _press(&"ui_accept")
	if recovery_case or rollback_case:
		_check(not StoryItems.owns(&"ch1_data_disk") and observed.is_empty(),"recovery does not install or announce an uncertain live result")
		_check(is_instance_valid(owner.get("_prompt")) and get_tree().paused,"recovery stays in the real paused prompt")
		var prompt:Control=owner.get("_prompt")
		if recovery_case:
			_check(not prompt.cancel_button.visible and bool(owner.get("_recovery")),"committed recovery offers reload rather than cancel")
			var committed:=RunSaveCodec.decode(FileAccess.get_file_as_string(_save_dir.path_join("slot.json")))
			_check(committed.has("data") and committed["data"]["story"]["items"]["held"].has("ch1_data_disk"),"post-commit source race retains the true committed disc file")
		else:
			_check(bool(owner.get("_reload_original")) and FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json.bak"))==before_disk,"rollback failure retains exact original backup and names original recovery")
		await _shot("committed-reload" if recovery_case else "original-reload")
		var fault:FaultStore=_main.get("_run_store")
		fault.mutate=false
		fault.reject=false
		fault.reject_rollback=false
		var old_player:=_level().player.get_instance_id()
		prompt.retry_button.grab_focus()
		await _press(&"ui_accept")
		_check(await _until(func()->bool:return _level()!=null and _level().player.get_instance_id()!=old_player and not bool(_main.call("_route_pending")),10.0),"public recovery reloads a newly constructed player")
		_check(await _control_ready(),"recovery transition and deferred authored reading finish before control checks")
		_check(StoryItems.holds(&"ch1_data_disk")==recovery_case and GameState.has_flag(&"ledger_disk_obtained")==recovery_case,"reload applies the truthful committed or original item result")
		_check(not get_tree().paused and not GameplayLock.is_locked(),"recovery releases only the old pickup lock")
		await _shot("reloaded")
		_completed=true
		_save_report()
		return
	_check(await _until(func()->bool:return StoryItems.holds(&"ch1_data_disk"),3.0),"public retry after removing IO fault actually acquires disc")
	_check(not is_instance_valid(pickup) or pickup.is_queued_for_deletion(),"accepted source is consumed")
	_check(GameState.has_flag(&"ledger_disk_obtained") and observed.size()==1 and observed[0]["disk_changed"] and observed[0]["flag"],"exactly one acquired observer sees matching durable and live flags")
	var saved:=RunSaveCodec.decode(FileAccess.get_file_as_string(_save_dir.path_join("slot.json")))
	_check(saved.has("data") and saved["data"]["story"]["items"]["held"].has("ch1_data_disk") and saved["data"]["story"]["flags"].get("ledger_disk_obtained")==true and saved["data"]["runtime"]["area"]["consumed"].get(source_key)==true,"real file contains item, objective and exact authored world source")
	await _read_to_end()
	if listener_case:
		await _settle(8)
		var current:=RunSaveCodec.decode(FileAccess.get_file_as_string(_save_dir.path_join("slot.json")))
		_check(Progression.credits==credits_before+7 and not StoryItems.is_new(&"ch1_data_disk"),"normal acquired callback changes survive installation")
		_check(current.has("data") and current["data"]["progression"]["credits"]==credits_before+7 and not current["data"]["story"]["items"]["unseen"].has("ch1_data_disk"),"callback changes are saved from the fresh live run")
	await _shot("write-accepted")
	_completed=true
	_save_report()

func _continue() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	await _until(func()->bool:return not bool(_main.call("_route_pending")))
	_main.call("_on_continue_requested")
	_check(await _wait_level(WAREHOUSE),"new Main publicly continues into saved vault")
	_check(await _control_ready(),"cold transition and deferred authored reading finish before control checks")
	_check(StoryItems.holds(&"ch1_data_disk") and GameState.has_flag(&"ledger_disk_obtained"),"cold continue retains item and objective")
	var found:=false
	for node in _level().find_children("*","",true,false):
		if node is CollectiblePickup and node.item.id==&"ch1_data_disk":found=true
	_check(not found,"cold continue has no duplicate authored disc pickup")
	_check(not get_tree().paused and not GameplayLock.is_locked(),"cold continue has no leaked pickup lock")
	await _shot("cold-continued")
	_completed=true
	_save_report()

func _control_ready() -> bool:
	var deadline:=Time.get_ticks_msec()+20000
	var stable:=0
	while Time.get_ticks_msec()<deadline:
		if Story._layer.is_radio_frozen():
			await _press(&"ui_accept")
		var ready:=not bool(_main.call("_route_pending")) and not Transition.is_active() and not GameplayLock.is_locked() and not get_tree().paused and not Story.is_cinematic_active()
		stable=stable+1 if ready else 0
		if stable>=6:return true
		await get_tree().process_frame
	return false
