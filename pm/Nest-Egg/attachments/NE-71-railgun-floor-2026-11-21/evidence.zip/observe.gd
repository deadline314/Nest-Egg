extends "res://tools/ch1_flow_probe.gd"

var store_path := ""
var side := 1
var app: Node
var player: Player
var rig: CharacterRig
var rows: Array[Dictionary] = []
var lens := 0.0
var mode := ""
var anchor_x := 472.0


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--slot="):
			store_path = arg.trim_prefix("--slot=")
		elif arg.begins_with("--side="):
			side = int(arg.trim_prefix("--side="))
		elif arg.begins_with("--lens="):
			lens = float(arg.trim_prefix("--lens="))
		elif arg.begins_with("--mode="):
			mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--anchor-x="):
			anchor_x = float(arg.trim_prefix("--anchor-x="))
	if not store_path.is_absolute_path() or side not in [-1, 1] or mode != "kneel":
		get_tree().quit(2)
		return
	app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	app.set("_run_store", RunSaveStore.new(store_path))
	add_child(app)
	for frame in STEP_LIMIT:
		if app.get("_screen") is MainMenu and not bool(app.call("_route_pending")):
			break
		await get_tree().process_frame
	var menu := app.get("_screen") as MainMenu
	if menu == null:
		get_tree().quit(2)
		return
	await _settle(8)
	menu._continue_button.pressed.emit()
	for frame in STEP_LIMIT:
		var current := app.get("_screen") as Level
		if current != null and current.is_initialized() and current.data.id == &"ch1_street" and not bool(app.call("_route_pending")) and not Transition.is_active():
			_level = current
			break
		await get_tree().process_frame
	if _level == null or _level.player == null:
		get_tree().quit(2)
		return
	player = _level.player
	rig = player._visual.rig
	player.global_position = Vector2(anchor_x, player.global_position.y)
	player.velocity = Vector2.ZERO
	_level.camera.snap_to_target()
	AimInput.set_virtual_gamepad(player, true)
	AimInput.restore_direction(Vector2(side,0))
	await _settle(36)
	_check(player.facing == side and player.is_on_floor(), "real safe street floor and requested facing")
	if lens > 0.0:
		_level.camera.set_physics_process(false)
		_level.camera.position_smoothing_enabled = false
		_level.camera.offset = Vector2.ZERO
	await _fire_sequence()
	AimInput.set_virtual_gamepad(player, false)
	var file := FileAccess.open(_out_dir.path_join("motion.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks_failed":_failures,"side":side,"mode":mode,"rows":rows, "device":"scripted game input"},"  ") + "\n")
	file.close()
	app.call("_quit", int(_failures > 0))



func _fire_sequence() -> void:
	var pistol := player.loadout.active_slot
	var railgun := player.loadout.equip(preload("res://data/weapons/railgun.tres"))
	_check(railgun >= 0 and railgun != pistol, "arranged railgun and P-9 in separate real inventory slots")
	_select(railgun)
	Input.action_press(&"move_down")
	for degrees: float in [0.0, 85.0, 91.5]:
		var ray := Vector2.from_angle(deg_to_rad(degrees))
		AimInput.restore_direction(Vector2(side * ray.x, ray.y))
		await _settle(78)
		await _measure_shot("railgun_%s" % str(degrees).replace(".","p"))
	_select(pistol)
	await _settle(78)
	await _measure_shot("pistol_down")
	Input.action_release(&"move_down")


func _measure_shot(label: String) -> void:
	if lens > 0.0:
		_level.camera.zoom = Vector2.ONE * lens
		_level.camera.global_position = player.global_position + Vector2(0.0, -32.0)
		_level.camera.force_update_scroll()
	await _draw_frame(label + "_before")
	var slot := player.loadout.active_slot
	var before := player.loadout.mag_in(slot)
	var muzzle := player.muzzle_position()
	var shoulder := player.aim_origin()
	var root := player.global_position
	var centroid := rig.hand_contact_global(&"front")
	var back := rig.hand_contact_global(&"back")
	var weapon := player.loadout.active_weapon()
	var direction := player.aim_dir
	var query := PhysicsRayQueryParameters2D.create(Vector2(muzzle.x, minf(muzzle.y, root.y) - 20.0), Vector2(muzzle.x, root.y + 14.0), Layers.WORLD)
	var surface := player.get_world_2d().direct_space_state.intersect_ray(query)
	var got_surface := not surface.is_empty()
	_check(got_surface, label + " got an actual terrain ray intersection at the muzzle x-coordinate")
	var floor_y: float = surface["position"].y if got_surface else root.y
	var ball := CircleShape2D.new()
	ball.radius = maxf(1.0, weapon.projectile.radius)
	var start_query := PhysicsShapeQueryParameters2D.new()
	start_query.shape = ball
	start_query.transform.origin = muzzle
	start_query.collision_mask = Layers.WORLD
	var overlapping := not player.get_world_2d().direct_space_state.get_rest_info(start_query).is_empty()
	var free: Array[Projectile] = ProjectilePool._free
	_check(not free.is_empty(), label + " known next projectile comes from the live stage pool")
	var projectile: Projectile = null if free.is_empty() else free.back()
	var events: Array[Dictionary] = []
	var expired := func(value: Projectile) -> void:
		events.append({"position": _p(value.global_position), "physics": Engine.get_physics_frames(), "id": value.get_instance_id()})
	if projectile != null:
		projectile.expired.connect(expired)
	var started := Engine.get_physics_frames()
	Input.action_press(&"shoot")
	await get_tree().process_frame
	Input.action_release(&"shoot")
	var first := _projectile_state(projectile)
	await _draw_frame(label + "_first")
	var spent := before - player.loadout.mag_in(slot)
	_check(spent == 1 and projectile != null and projectile.spec == weapon.projectile and projectile.team == Combat.Team.PLAYER, label + " fires exactly one live round")
	await _settle(5)
	await _draw_frame(label + "_sixth")
	var final := _projectile_state(projectile)
	if projectile != null:
		projectile.expired.disconnect(expired)
	rows.append({"label": label, "ground": player.is_on_floor(), "crouching": player.is_crouching,
		"root": _p(root), "muzzle": _p(muzzle),"aim_origin": _p(shoulder), "direction": _p(direction),
		"near_hand": _p(centroid), "far_hand": _p(back), "floor_y": floor_y, "depth": muzzle.y - floor_y,
		"facing": player.facing, "spawn_overlaps_world": overlapping, "radius": ball.radius,
		"started_physics": started, "spent":spent,"first":first,"sixth":final,"expired":events})


func _draw_frame(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	_capture(name)


func _projectile_state(projectile: Projectile) -> Dictionary:
	return {} if projectile == null else {"id": projectile.get_instance_id(), "position": _p(projectile.global_position),
		"velocity": _p(projectile.velocity), "live": projectile.active, "physics": Engine.get_physics_frames()}


func _p(vector: Vector2) -> Array:
	return [vector.x, vector.y]


func _select(slot: int) -> void:
	var key := InputEventKey.new()
	key.physical_keycode = KEY_1 + slot
	key.pressed = true
	Input.parse_input_event(key)
	var release := InputEventKey.new()
	release.physical_keycode = key.physical_keycode
	Input.parse_input_event(release)


