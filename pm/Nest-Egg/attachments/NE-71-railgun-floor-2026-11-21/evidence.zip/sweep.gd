extends Node


func _ready() -> void:
	call_deferred("_sweep")


func _sweep() -> void:
	var rows: Array[Dictionary] = []
	var tested := [&"pistol", &"rifle", &"smg", &"spread", &"laser", &"railgun", &"launcher", &"mech_cannon"]
	var rig := CharacterRig.new()
	add_child(rig)
	if not rig.setup("rin"):
		get_tree().quit(3)
		return
	var input := RigInput.new()
	input.crouching = true
	input.on_floor = true
	var floor_y := rig.skeleton_to_global(Vector2(0.0, rig.animator._dash_floor)).y
	for kind: StringName in tested:
		var weapon := load("res://data/weapons/%s.tres" % kind) as WeaponData
		if weapon == null or weapon.projectile == null:
			get_tree().quit(4)
			return
		rig.set_weapon(weapon.visual_id)
		if rig.weapon_def().is_empty():
			get_tree().quit(4)
			return
		for side: int in [-1, 1]:
			input.facing = side
			for degrees: float in [-105.0, -90.0, -45.0, 0.0, 30.0, 45.0, 60.0, 75.0, 85.0, 90.0, 95.0, 105.0]:
				var aim := Vector2.from_angle(deg_to_rad(degrees))
				input.aim_dir = Vector2(aim.x * side, aim.y)
				input.crouched_muzzle_clearance = 0.0
				for frame in 33:
					rig.animate(1.0 / 60.0, input)
				var old := rig.muzzle_global()
				var before := _grips(rig)
				var desired := maxf(1.0, weapon.projectile.radius) + 0.75
				input.crouched_muzzle_clearance = desired / rig.body_scale()
				rig.animate(1.0 / 60.0, input)
				var next := rig.muzzle_global()
				rows.append({"kind": String(kind), "angle": degrees, "side":side, "initial":floor_y-old.y,
					"new":floor_y-next.y,"shift":old.distance_to(next), "cross":(next-old).cross(input.aim_dir),
					"margin":desired,"grip":_grips(rig),"old_grip":before,
					"limits":_limits(rig, aim) if kind == &"railgun" else {}})
	var path := ProjectSettings.globalize_path("user://muzzle-angle-audit.json")
	var file := FileAccess.open(path,FileAccess.WRITE)
	if file == null:
		get_tree().quit(5)
		return
	file.store_string(JSON.stringify(rows,"  ")+"\n")
	file.close()
	print(path)
	get_tree().quit()

func _grips(rig: CharacterRig) -> Array[float]:
	var definition := rig.weapon_def()
	var foregrip := (RigLibrary.vec2(definition["foregrip"]) - RigLibrary.vec2(definition["grip"])) * rig.weapon_scale()
	return [rig.hand_contact_global(&"front").distance_to(rig.weapon_root().global_position),
		rig.hand_contact_global(&"back").distance_to(rig.weapon_root().to_global(foregrip))]


func _limits(rig: CharacterRig, aim: Vector2) -> Dictionary:
	var angle := aim.angle()
	var anchor := rig.weapon_anchor()
	var point: Vector2 = rig.animator._global_pos[anchor[0]] + (anchor[1] as Vector2).rotated(rig.animator._global_angle[anchor[0]])
	var weapon := rig.weapon_def()
	var tip := (RigLibrary.vec2(weapon["muzzle"]) - RigLibrary.vec2(weapon["grip"])) * rig.weapon_scale()
	var fore := (RigLibrary.vec2(weapon["foregrip"]) - RigLibrary.vec2(weapon["grip"])) * rig.weapon_scale()
	var rear: Dictionary = {}
	var front: Dictionary = {}
	for chain: Array in HumanoidAnimator.ARM_CHAINS:
		var hand: StringName = chain[2]
		var grip_offset := fore if hand == &"hand_back" else Vector2.ZERO
		var displacement: Vector2 = point + (grip_offset - rig.hand_grip_offset(hand)).rotated(angle) - rig.animator._global_pos[chain[0]]
		var length := rig.rest(chain[1]).length() + rig.rest(hand).length() - 0.01
		var folded := absf(rig.rest(chain[1]).length() - rig.rest(hand).length()) + 0.01
		var along := displacement.dot(aim)
		var across := absf(displacement.cross(aim))
		var unfold := sqrt(maxf(0.0, folded * folded - across * across))
		var span := sqrt(maxf(0.0, length * length - across * across))
		var row := {"along":along,"across":across,"short":folded,"long":length,
			"upper_fold": -along+unfold if across < folded else null, "lower_fold":-along-unfold if across < folded else null,
			"min": -along - span, "max": -along + span}
		if hand == &"hand_back":
			rear = row
		else:
			front = row
	return {"actual": (rig.weapon_root().position-point).dot(aim), "front":front,"rear":rear,
		"tip_y_without_reach":point.y+tip.rotated(angle).y,"floor":rig.animator._dash_floor,
		"scale": rig.body_scale()}
