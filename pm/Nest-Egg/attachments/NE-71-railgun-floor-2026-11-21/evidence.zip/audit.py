from pathlib import Path
from math import dist
import json

base = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_bytes())
reference = read(next((base/'diag-appdata').rglob('muzzle-angle-audit.json')))
candidate = read(next((base/'candidate-diag-appdata').rglob('muzzle-angle-audit.json')))
assert len(reference) == len(candidate) == 192
changed = []
for old,new in zip(reference,candidate,strict=True):
    assert (old['kind'],old['side'],old['angle']) == (new['kind'],new['side'],new['angle'])
    assert abs(old['initial']-new['initial']) < 0.0001
    if new['angle'] >= 0:
        assert new['new'] >= new['margin']-0.0001
    assert max(new['grip']) < 0.001
    if abs(old['new']-new['new']) > 0.001:
        assert new['new'] > old['new'] and abs(new['cross']-old['cross']) < 1.2
        changed.append({'weapon':new['kind'],'facing':new['side'],'angle':new['angle'],
                        'before':old['new'],'after':new['new'],'ray_offset':new['cross']-old['cross']})
assert len(changed) == 32 and {row['weapon'] for row in changed} == {'laser','launcher','mech_cannon','railgun'}
shots = []
for render in ('headless','native'):
    for directory in sorted((base/f'stock-{render}').glob('kneel-*')):
        new = base/f'candidate-{render}'/directory.name
        old_rows = read(directory/'motion.json')['rows']
        new_rows = read(new/'motion.json')['rows']
        assert len(old_rows) == len(new_rows) == 4
        for a,b in zip(old_rows,new_rows,strict=True):
            assert a['label'] == b['label'] and a['facing'] == b['facing'] and dist(a['direction'],b['direction']) < 0.0001
            assert a['spent'] == b['spent'] == 1
            assert dist(b['first']['position'],b['muzzle']) < 0.001
            label = b['label']
            if label == 'pistol_down':
                # The P-9 has authored random spread even for a static aim.
                assert abs(dist(a['first']['velocity'],[0,0])-dist(b['first']['velocity'],[0,0])) < 0.0001
            else:
                assert dist(a['first']['velocity'],b['first']['velocity']) < 0.0001
            if label in {'railgun_85p0','railgun_91p5'}:
                assert a['spawn_overlaps_world'] and not b['spawn_overlaps_world']
                assert abs(b['depth']) > b['radius']
                assert len(a['expired']) == len(b['expired']) == 1
                assert dist(a['expired'][0]['position'],a['muzzle']) < 0.001
                assert 0.1 < dist(b['expired'][0]['position'],b['muzzle']) < 0.8
                assert abs(b['floor_y'] - b['expired'][0]['position'][1] - b['radius']) < 0.25
                shots.append({'render':render,'facing':b['facing'],'label':label,'before_y':a['depth'],
                              'after_y':b['depth'],'impact_travel':dist(b['expired'][0]['position'],b['muzzle'])})
            else:
                assert not a['spawn_overlaps_world'] and not b['spawn_overlaps_world']
                assert dist(a['muzzle'],b['muzzle']) < 0.001 and a['depth'] == b['depth']
assert len(shots) == 8
summary = {'angles':len(candidate),'changed':changed,'shots':shots,
           'max_hand_error':max(max(row['grip']) for row in candidate)}
(base/'paired-audit.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(len(candidate),len(changed),len(shots),summary['max_hand_error'])
