extends "res://tests/probes/training_completion.gd"

func _shot(name: String) -> void:
	await super._shot(name)
	if name == "training-saved":
		await _frames(20)
		await super._shot("training-settled")

func _finish_story(shot := "") -> void:
	if _mode in ["read", "fall_read", "dash_read"] and Story.is_cinematic_active():
		await _frames(20)
		await super._shot("training-cold")
	await super._finish_story(shot)

func _done() -> void:
	Story.reset_active_presentation(&"menu")
	await _frames(2)
	if _level() != null:
		_check(not _player().interaction.active, "leaving the original dialogue releases its holster ownership")
		await super._shot("training-restored")
	await super._done()
