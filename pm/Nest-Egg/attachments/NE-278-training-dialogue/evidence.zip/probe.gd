extends "res://tests/probes/training_completion.gd"

func _shot(name: String) -> void:
	if name == "training-saved":
		_check(Story.scene_mode(Story._current_cinematic) == Story.MODE_DIALOGUE, "the actual training explanation is a map dialogue")
		var player := _player()
		_check(player.interaction.active and not player._visual.rig.weapon_root().visible, "the original training explanation holsters the actual equipped gun")
	await super._shot(name)
