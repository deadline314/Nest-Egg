from collections import Counter
from hashlib import sha256
from pathlib import Path
import json

import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent
root=Path.cwd()
sha=lambda path: sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_bytes())
def key(f): return (f['char'],f['joint'],f['pose'],f['zoom'],f['facing'],f['frame'])
def gap(f): return f['center_alpha']<128 or f['enclosed_pixels'] or f['loose_pieces']

results={}
for scope,num in (('dressed',3840),('isolated',3840),('whole',3840),('adjacent',4608)):
    old,new=(read(base/f'{mode}-{scope}'/'report.json') for mode in ('stock','final'))
    assert new['samples']==old['samples']==num
    old_flags={key(f) for f in old['failures']}
    new_flags={key(f) for f in new['failures']}
    previous={key(f) for f in old['failures'] if gap(f)}
    repaired={key(f) for f in new['failures'] if gap(f)}
    results[scope]={'samples':num,'before':[len(old_flags),len(previous)],'after':[len(new_flags),len(repaired)],
                    'new_flags':sorted(new_flags-old_flags),'new_gaps':sorted(repaired-previous),
                    'remaining_gaps_by_pose':dict(Counter(f[2] for f in repaired))}
print(results)
for scope,data in results.items():
    assert not data['new_gaps'] and not data['new_flags'],(scope,data)
assert results['whole']['before'][1]==746 and results['whole']['after'][1]<75
assert all(results[scope]['after'][1]==0 for scope in ('dressed','isolated','adjacent'))

for suffix in ('final-dressed','final-isolated','final-whole','final-adjacent','final-damage','normal','import'):
    assert 'ERROR:' not in (base/(suffix+'.log')).read_text(encoding='utf-8'),suffix
backup=root/'art_src/characters/warden/neck_overlap/torso-before.png'
previous=base/'torso-before.png'
new=root/'art_src/characters/warden/overrides/torso.png'
actual_diffuse=root/'art/characters/warden/parts/torso.png'
actual_normal=root/'art/characters/warden/parts/torso_n.png'
assert sha(new)==sha(actual_diffuse)==sha(base/'torso-tapered.png')
assert sha(actual_normal)==sha(base/'normal-after.png')
assert sha(backup)==sha(base/'cut-check/warden/parts/torso.png')
assert sha(base/'normal-before.png')==sha(base/'normal-before-rebuilt.png')
old,patched,original_normal,baked=(np.asarray(Image.open(p).convert('RGBA')) for p in (previous,new,base/'normal-before.png',actual_normal))
changed=np.any(old!=patched,axis=2)
assert changed.sum()==1269 and np.array_equal(patched[:,:,3],baked[:,:,3])
assert np.all(old[changed,3]<235) and np.all(old[changed,3]<patched[changed,3])
results['source']={'old':sha(previous),'diffuse':sha(actual_diffuse),'normal':sha(actual_normal),
                   'diffuse_pixels':int(changed.sum()),'normal_pixels':int(np.any(original_normal!=baked,axis=2).sum()),
                   'grid':[479,604]}
(base/'verification.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
