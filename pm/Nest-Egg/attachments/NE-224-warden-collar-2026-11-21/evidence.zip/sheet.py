from pathlib import Path
from PIL import Image,ImageDraw
import json

base=Path(__file__).resolve().parent
panels=(('idle',3.4,0,84,62,54),('stagger',1.0,12,70,62,20))
sheet=Image.new('RGB',(560,478),(32,35,46))
draw=ImageDraw.Draw(sheet)
for row,(pose,zoom,n,cx,cy,span) in enumerate(panels):
 for col,scope in enumerate(('stock-whole','final-whole')):
  stage=base/scope
  groups=json.loads((stage/'frames.json').read_bytes())
  group=next(g for g in groups if g['pose']==pose and g['zoom']==zoom)
  x,y,w,h=next(c['rect'] for c in group['cells'] if c['facing']==1)
  with Image.open(stage/group['samples'][n]['file']) as frame:
   detail=frame.crop((x+cx-span//2,y+cy-span//2,x+cx+span//2,y+cy+span//2)).convert('RGBA')
  bg=Image.new('RGBA',detail.size,(135,145,165,255))
  bg.alpha_composite(detail)
  ox,oy=8+col*280,8+row*235
  sheet.paste(bg.resize((208,208),Image.Resampling.NEAREST).convert('RGB'),(ox,oy+18))
  draw.text((ox,oy),f'{"Before" if col==0 else "With overlap"} / {pose} / {zoom}x',fill='#f9fafc')
sheet.save(base/'collar-compare.png')
