from pathlib import Path
from PIL import Image
import numpy as np

target=Path(__file__).resolve().parent/'torso-tapered.png'
original=np.asarray(Image.open('art/characters/warden/parts/torso.png').convert('RGBA'))
candidate=original.copy()
for row in range(109,158):
    end = 376 - max(0, 114-row)*3 - max(0, row-137)*3
    span=candidate[row,316:end]
    selected=span[:,3]<235
    span[selected]=original[row,314]
assert np.array_equal(original[original[:,:,3]>=235],candidate[original[:,:,3]>=235])
print('updated',np.count_nonzero(np.any(candidate!=original,axis=2)))
Image.fromarray(candidate).save(target)

