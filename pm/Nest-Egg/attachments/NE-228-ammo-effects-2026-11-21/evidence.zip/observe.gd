extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
var _out := ""
var _spread_roll := 0.0
var _rows: Array[Dictionary] = []
var _failures: Array[String] = []


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://ammo_fixture.cfg")
	Settings.set_brightness(0.5)
	Settings.set_hud_auto_hide(false)
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	for mode: String in ["normal", "motion", "flashes", "both", "toggle"]:
		await _observe(mode)
	var file := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"rows":_rows,"failures":_failures,
		"adapter":RenderingServer.get_video_adapter_name(),"hdr":get_viewport().use_hdr_2d}, "  "))
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(not _failures.is_empty()))


func _observe(mode: String) -> void:
	seed(506228)
	_spread_roll = 0.0
	Settings.set_reduce_ui_motion(mode in ["motion","both"])
	Settings.set_reduce_flashes(mode in ["flashes","both"])
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	for _frame in 120:
		if level.is_initialized():
			break
		await get_tree().process_frame
	var pile: CreditPickup
	for node in level._entities.get_children():
		if node is CreditPickup and pile == null and node._requires_flag == &"" and not node._elevated:
			pile = node
		elif node is Enemy:
			node.process_mode = Node.PROCESS_MODE_DISABLED
	if pile == null:
		_failures.append(mode + " missing authored position")
		level.queue_free()
		await get_tree().process_frame
		return
	for node in level.find_children("*","",true,false):
		if node is ChapterCard:
			node.queue_free()
	var player := level.player
	var tray := level.hud.ammo_tray
	player.global_position = pile.global_position + Vector2(-30,0)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	level._lighting._lightning_gap = 1.0e9
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	camera.global_position = pile.global_position + Vector2(-42,-43)
	camera.reset_smoothing()
	camera.force_update_scroll()
	for _frame in 24:
		await get_tree().process_frame
	await _record(mode,"before",player,tray)
	_check(player.loadout.mag_in(0)==12,mode+" authored opening magazine")
	_check(player.loadout.consume_ammo(),mode+" first real magazine spend")
	for round in 3:
		_check(player.loadout.consume_ammo(),mode+" real magazine spend "+str(round))
	_spread_roll = randf()
	await _record(mode,"shot",player,tray)
	if mode == "toggle":
		Settings.set_reduce_flashes(true)
		await _record(mode,"flash-toggle",player,tray)
		Settings.set_reduce_ui_motion(true)
		await _record(mode,"motion-toggle",player,tray)
		Settings.set_reduce_ui_motion(false)
		Settings.set_reduce_flashes(false)
		await _record(mode,"restored",player,tray)
	_check(player.loadout.start_reload(),mode+" real reload starts")
	var mid := false
	for _frame in 40:
		await get_tree().process_frame
		if player.loadout.reload_progress() >= 0.38:
			mid = true
			break
	_check(mid and tray._reloading, mode+" active reload")
	await _record(mode,"reload",player,tray)
	for _frame in 120:
		if not player.loadout.is_reloading() and not tray._reloading:
			break
		await get_tree().process_frame
	_check(player.loadout.mag_in(0)==12 and not tray._reloading,mode+" reload settles to full")
	await _record(mode,"refilled",player,tray)
	for round in 10:
		_check(player.loadout.consume_ammo(),mode+" low ammo arrange "+str(round))
	for _frame in 36:
		await get_tree().process_frame
	await _record(mode,"low-a",player,tray)
	for _frame in 12:
		await get_tree().process_frame
	await _record(mode,"low-b",player,tray)
	for round in 2:
		_check(player.loadout.consume_ammo(),mode+" empty arrange "+str(round))
	_check(player.loadout.cancel_reload(),mode+" cancel automatic reload for empty warning")
	for _frame in 33:
		await get_tree().process_frame
	await _record(mode,"empty-a",player,tray)
	for _frame in 13:
		await get_tree().process_frame
	await _record(mode,"empty-b",player,tray)
	var laser := load("res://data/weapons/laser.tres") as WeaponData
	var slot := player.loadout.equip(laser)
	_check(slot > 0 and tray.is_energy,mode+" actual equipment switches to authored energy weapon")
	for _frame in 4:
		await get_tree().process_frame
	await _record(mode,"switch",player,tray)
	for round in 10:
		_check(player.loadout.consume_ammo(),mode+" battery low arrange "+str(round))
	for _frame in 28:
		await get_tree().process_frame
	await _record(mode,"energy-low-a",player,tray)
	for _frame in 12:
		await get_tree().process_frame
	await _record(mode,"energy-low-b",player,tray)
	_check(player.loadout.consume_ammo() and player.loadout.consume_ammo() and player.loadout.cancel_reload(),mode+" energy empty arrange")
	for _frame in 30:
		await get_tree().process_frame
	await _record(mode,"energy-empty-a",player,tray)
	for _frame in 12:
		await get_tree().process_frame
	await _record(mode,"energy-empty-b",player,tray)
	level.queue_free()
	await get_tree().process_frame


func _record(mode: String, label: String, player: Player, tray: AmmoTray) -> void:
	await RenderingServer.frame_post_draw
	var picture := "%s-%s.png" % [mode,label]
	_check(Capture.image(get_viewport()).save_png(_out.path_join(picture))==OK, mode+" "+label+" captured")
	var live_ejects := 0
	for age in tray._eject_age:
		live_ejects += int(age < AmmoTray.EJECT_TIME)
	var slot := player.loadout.active_slot
	var cell := tray._battery_cell_rect(0) if tray.is_energy else tray._icon_draw_rect(0,2,1.0)
	var hint := tray._pos + Vector2(-16.0 if tray._draw_side < 0.0 else 0.0,7.0)
	_rows.append({"mode":mode,"label":label,"file":picture,"weapon":String(player.loadout.active_weapon().id),
		"actual":player.loadout.mag_in(slot),"ammo":tray.ammo,"cap":tray.max_ammo,"reserve":tray.reserve,
		"energy":tray.is_energy,"shown":tray.icon_count(),"low":tray.is_low(),"hint":tray._hint,
		"reloading":tray._reloading,"progress":player.loadout.reload_progress(),"refill":tray._refill,"blip":tray._blip_at,
		"spread_roll":_spread_roll,"slide":tray.slide(),"pop":tray._pop_left,"flip":tray._flip_left,"shells":live_ejects,"alpha":tray.presence.alpha,
		"cell":[cell.position.x,cell.position.y,cell.size.x,cell.size.y],"hint_at":[hint.x,hint.y],"time":tray._time,
		"motion":Settings.get_reduce_ui_motion(),"flashes":Settings.get_reduce_flashes()})


func _check(ok: bool, message: String) -> void:
	if not ok:
		_failures.append(message)
