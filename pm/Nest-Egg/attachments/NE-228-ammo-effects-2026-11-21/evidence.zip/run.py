from hashlib import sha256
from pathlib import Path
import json
import math
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
label = sys.argv[1]
out = base / label
out.mkdir()
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    path = out / key
    path.mkdir()
    env[key] = str(path)
paths = ["ui/ammo_tray.gd","ui/hud_presence.gd","ui/hud.gd","autoload/settings.gd",
         "game/player/player.gd","data/levels/ch1_street.tres","game/player/loadout.gd"]
sha = lambda path: sha256(path.read_bytes()).hexdigest()
source = {p:sha(game / p) for p in paths}
argv = [sys.executable,"-B",str(game/"tools/comfyui/gpu_lock.py"),"--",
        "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(game),
        "--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy",
        "--fixed-fps","60","--resolution","1280x720","--quit-after","3300",str(base/"observe.tscn"),"--",f"--out={out}"]
(out/"command.json").write_text(json.dumps({"argv":argv,"source":source},indent=2)+"\n",encoding="utf-8")
with (out/"engine.log").open("wb") as log:
    proc = subprocess.run(argv,cwd=game,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=230)
raw=(out/"engine.log").read_text(encoding="utf-8",errors="replace")
print(raw[-8000:],flush=True)
report = json.loads((out/"result.json").read_bytes())
assert all(sha(game/p)==digest for p,digest in source.items())
assert proc.returncode==0 and not re.search(r"^SCRIPT ERROR:|^ERROR:",raw,re.M), (proc.returncode,report["failures"])
assert report["hdr"] and "9070 XT" in report["adapter"] and not report["failures"]

rows = {(r["mode"], r["label"]): r for r in report["rows"]}
assert len(rows) == 68 and len(list(out.glob("*.png"))) == 68
assert all(row["ammo"] == row["actual"] and row["alpha"] > .95 for row in rows.values())
for mode in ("normal", "motion", "flashes", "both", "toggle"):
    shot = rows[mode,"shot"]
    switch = rows[mode,"switch"]
    assert rows[mode,"before"]["ammo"] == 12 and shot["ammo"] == 8 and shot["cap"] == 12
    reload = rows[mode,"reload"]
    assert reload["reloading"] and 0.38 <= reload["progress"] <= 0.48 and reload["refill"] > shot["refill"]
    assert rows[mode,"refilled"]["ammo"] == 12 and rows[mode,"refilled"]["refill"] == 10
    assert rows[mode,"low-a"]["ammo"] == 2 and rows[mode,"low-a"]["low"]
    assert rows[mode,"empty-a"]["ammo"] == 0 and not rows[mode,"empty-a"]["reloading"]
    assert switch["energy"] and switch["ammo"] == switch["cap"] == 12
    assert rows[mode,"energy-low-a"]["ammo"] == 2
    assert rows[mode,"energy-empty-a"]["ammo"] == 0 and not rows[mode,"energy-empty-a"]["reloading"]
    if label.startswith("stock") or mode not in ("both", "motion"):
        assert shot["shells"] == 4 and shot["slide"] > 0 and switch["flip"] > 0 and reload["pop"] > 0
    else:
        assert shot["shells"] == shot["slide"] == switch["flip"] == reload["pop"] == 0
if not label.startswith("stock"):
    assert rows["toggle","flash-toggle"]["shells"] == 4 and rows["toggle","flash-toggle"]["slide"] > 0
    for phase in ("motion-toggle","restored"):
        assert rows["toggle",phase]["shells"] == rows["toggle",phase]["slide"] == 0
print(f"{len(rows)} native ammo states rendered and recorded.", flush=True)
