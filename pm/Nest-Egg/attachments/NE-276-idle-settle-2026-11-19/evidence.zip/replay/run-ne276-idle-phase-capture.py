from pathlib import Path
import os,sys,subprocess,json,hashlib
root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119')
project=base.parent/'ne267-source-delivery-20261118/s19-runtime'
out=base/'phase-capture'
out.mkdir(exist_ok=False)
source=(root/'game/fx/soft_whip.gd').read_text(encoding='utf-8')
assert (project/'game/fx/soft_whip.gd').read_text(encoding='utf-8')==source
codes={'current':()}
step=source[source.index('func step('):source.index('## 畫在 CanvasItem')]
constants={key:next(line for line in source.splitlines() if line.startswith('const '+key+' :=')) for key in ('BEND_PROJECTION_DAMPING','KEEP_PER_SECOND_FREE')}
for name,replacements in codes.items():
    values=dict(constants)
    for const,value in replacements:
        values[const]=f'const {const} := {value}'
    kernel=step
    for const in values:
        kernel=kernel.replace(const,'TEST_'+const)
    script='extends SoftWhip\n\nvar samples: Array = []\n'+'\n'.join(values[key].replace('const ','const TEST_') for key in values)+'\n\n'+kernel
    script=script.replace('func step(', 'func _step_impl(').replace('_solve_bend(', '_screen_bend(')
    script+='''\nfunc step(delta: float, root: Vector2, handle_dir: Vector2, length_target: float, tip_target: Vector2, pull: float) -> void:
	_step_impl(delta, root, handle_dir, length_target, tip_target, pull)
	if samples.size() < 113:
		samples.append([delta, root.x, root.y, handle_dir.x, handle_dir.y, length_target, floor_y, tip().x, tip().y, pull])
'''
    (out/(name+'.gd')).write_text(script,encoding='utf-8')
probe='''extends "res://tests/smoke_test.gd"

class InjectedWhip extends EnvironmentSuite:
	var kernel: GDScript
	var delay: int
	var captured: SoftWhip

	func start_level(data: LevelData, difficulty_index := 1) -> Level:
		var level := await super.start_level(data, difficulty_index)
		await physics_frames(delay)
		captured = kernel.new()
		level.player._visual.melee_held()._whip = captured
		return level


func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var results := {}
	var destination := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			destination = arg.trim_prefix("--out=")
	var variants := SCRIPTS
	for key: String in variants:
		var trials := []
		for delay in [0,1,2,3,34,55,89,120]:
			seed(276)
			_failures.clear()
			_checks = 0
			var suite := InjectedWhip.new(self)
			suite.kernel = variants[key]
			suite.delay = delay
			await suite._test_soft_whip()
			var trace: Array = suite.captured.get("samples")
			trials.append({"delay": delay,"checks":_checks,"failures":Array(_failures),"trace":trace})
		results[key] = trials
		print("NE276_IDLE_PHASE ",key," ",JSON.stringify(trials.map(func(row: Dictionary) -> Dictionary: return {"delay": row.delay,"failures":row.failures})))
	FileAccess.open(destination, FileAccess.WRITE).store_string(JSON.stringify(results))
	await AudioRelease.settle(get_tree())
	get_tree().quit()
'''.replace('SCRIPTS','{'+','.join(f'"{key}":preload("{(out/(key+".gd")).as_posix()}")' for key in codes)+'}')
script=out/'observer.gd'
script.write_text(probe,encoding='utf-8')
scene=out/'observer.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{script.as_posix()}" id="1"]\n[node name="IdlePhase" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(out/'profile'/key)
args=[engine,'--headless','--path',str(project),'--audio-driver','Dummy','--fixed-fps','60','--quit-after','72000',str(scene),'--','--out='+str(out/'report.json')]
(out/'command.json').write_text(json.dumps(args,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
    proc=subprocess.run(args,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=520)
raw=(out/'raw.log').read_text(encoding='utf-8')
print('\n'.join(line for line in raw.splitlines() if line.startswith('NE276_IDLE_PHASE')),flush=True)
assert proc.returncode==0 and 'ERROR:' not in raw and (out/'report.json').exists(),raw[-1800:]
