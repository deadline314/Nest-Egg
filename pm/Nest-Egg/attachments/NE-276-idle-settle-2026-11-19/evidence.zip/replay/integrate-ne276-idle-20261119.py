from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path.cwd()
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
evidence=Path('D:/NestEggVerification/evidence-20261117')
base=evidence/'ne276-idle-repro-20261119'
prior=evidence/'ne267-source-delivery-20261118/s19-soup-v1/integration'
out=base/'integration'
out.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=read(prior/'publish/result.json')['commit']
source=read(prior/'published-source.json')
assert subprocess.check_output(['git','branch','--show-current'],cwd=root).strip()==b'codex/ticket-work-20261119-ne276-idle'
assert all(subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree).decode().strip()==expected for tree in (root,shared))
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root).strip()
assert all(sha(shared/name)==digest for name,digest in source.items())
solver='game/fx/soft_whip.gd'
helper='tests/helpers/soft_whip_native_checks.gd'
fixture='tests/fixtures/soft_whip_idle_inputs.json'
assert all(not (project/fixture).exists() for project in (root,shared))
reference=read(base/'phase-capture/report.json')['current']
capture=next(row for row in reference if row['delay']==3)
samples=capture['trace'][:110]
assert len(samples)==110 and len(capture['failures'])==1
assert all(len(row)==10 and abs(row[0]-1/60)<1e-12 and row[5:7]==[21.0,783.5] and row[-1]==0 for row in samples)
idle='''{
 "version": 1,
 "delta": 0.0166666666666667,
 "length": 21,
 "floor_y": 783.5,
 "grip_frames": [\n'''+ ',\n'.join('  '+json.dumps([round(value,9) for value in row[1:5]]) for row in samples)+'\n ]\n}\n'
helper_code=(root/helper).read_text(encoding='utf-8')
anchor='static func run(suite: TestSuite) -> void:\n'
assert helper_code.count(anchor)==1
helper_code=helper_code.replace(anchor,anchor+'\t_check_idle(suite)\n')
helper_code+='''

## 90 physics ticks of natural grip motion while equipping, then 20 more at rest.
static func _check_idle(suite: TestSuite) -> void:
	var path := "res://tests/fixtures/soft_whip_idle_inputs.json"
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	var valid: bool = data is Dictionary and data.get("version") == 1 and data.get("grip_frames") is Array and data.grip_frames.size() == 110
	suite.check(valid, "idle whip fixture contains the recorded grip motion: " + path)
	if not valid:
		return
	var whip := SoftWhip.new()
	whip.floor_y = float(data.floor_y)
	var before := Vector2.ZERO
	for i in data.grip_frames.size():
		var frame: Array = data.grip_frames[i]
		var root := Vector2(frame[0], frame[1])
		var handle := Vector2(frame[2], frame[3])
		whip.step(float(data.delta), root, handle, float(data.length), root, 0.0)
		if i == 89:
			before = whip.tip()
	var distance := whip.tip().distance_to(before)
	suite.check(distance < 1.5, "idle-whip recorded tip travel under 1.5 px in 20 ticks (%.5f)" % distance)
'''
candidate=evidence/'ne276-curvature-20261118/joint6-idle001.gd'
assert candidate.read_bytes()==(root/solver).read_bytes().replace(b'const KEEP_PER_SECOND_FREE := 0.02',b'const KEEP_PER_SECOND_FREE := 0.001')
for project in (root,shared):
    (project/fixture).write_bytes(idle.encode())
    (project/helper).write_bytes(helper_code.encode())
script=out/'observer.gd'
script.write_text('''extends "res://tests/smoke_test.gd"

func _run() -> void:
	preload("res://tests/helpers/soft_whip_native_checks.gd").run(EnvironmentSuite.new(self))
	print("IDLE_WHIP_CHECKS ", _checks, "/", _failures.size())
	for failure in _failures:
		print("FAIL: ", failure)
	get_tree().quit(0 if _failures.is_empty() else 1)
''',encoding='utf-8')
scene=script.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{script.as_posix()}" id="1"]\n[node name="WhipIdleReplay" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')
source |= {name:sha(shared/name) for name in (helper,fixture)}
paths=(solver,helper,fixture)
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'

def run(label,args,code=0):
    destination=out/label
    destination.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(destination/'profile'/key)
    env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',GODOT=engine,SHARDS='6',LOG_DIR=str(destination/'shards'))
    (destination/'command.json').write_text(json.dumps(args,indent=2)+'\n')
    with (destination/'raw.log').open('wb') as log:
        proc=subprocess.run(args,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=2400)
    raw=(destination/'raw.log').read_bytes()
    result={'exit':proc.returncode,'errors':[line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line],
            'source_held':all(sha(shared/name)==digest for name,digest in source.items()) and all(sha(root/name)==source[name] for name in paths)}
    (destination/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(label,result,raw.decode(errors='replace')[-1300:],flush=True)
    assert result=={'exit':code,'errors':[],'source_held':True}
    return raw.decode(errors='replace'),result

command=[engine,'--headless','--quit-after','600',scene.as_posix()]
red,_=run('baseline',command,code=1)
assert red.count('FAIL:')==1 and 'IDLE_WHIP_CHECKS 45/1' in red and 'idle-whip recorded tip travel' in red
for project in (root,shared):
    (project/solver).write_bytes(candidate.read_bytes())
source[solver]=sha(candidate)
(out/'source.json').write_text(json.dumps(source,indent=2)+'\n')
(out/'paths.json').write_text(json.dumps(paths,indent=2)+'\n')
green,_=run('candidate',command)
assert 'IDLE_WHIP_CHECKS 45/0' in green
selector=['C:/Program Files/Git/bin/bash.exe','-c',f'python3() {{ python "$@"; }}; export -f python3; tools/run_tests_changed.sh {expected}']
_,verify=run('official',selector)
(out/'verification.json').write_text(json.dumps(verify,indent=2)+'\n')
