from pathlib import Path
import os,json,subprocess
p=Path('D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119')
project=p.parent/'ne267-source-delivery-20261118/s19-runtime'
out=p/'replay-screen-v2'
out.mkdir()
base=(p/'phase-screen/current.gd').read_text(encoding='utf-8')
variants={'current':.85,'damp88':.88,'damp90':.90,'damp92':.92,'damp95':.95,'damp97':.97,'damp100':1.0,'air001':.85,'air0001':.85}
for name,value in variants.items():
 candidate=base.replace('TEST_BEND_PROJECTION_DAMPING := 0.85',f'TEST_BEND_PROJECTION_DAMPING := {value}')
 if name.startswith('air'):
  strength='0.001' if name=='air001' else '0.0001'
  candidate=candidate.replace('TEST_KEEP_PER_SECOND_FREE := 0.02','TEST_KEEP_PER_SECOND_FREE := '+strength)
 (out/(name+'.gd')).write_text(candidate,encoding='utf-8')
checker=Path('tests/helpers/soft_whip_native_checks.gd').read_text(encoding='utf-8')
checker=checker.replace('run(suite: TestSuite)','run(suite: TestSuite, kernel: GDScript)').replace('_replay(suite, case)','_replay(suite, case, kernel)').replace('case: Dictionary) -> void:','case: Dictionary, kernel: GDScript) -> void:').replace('var whip := SoftWhip.new()', 'var whip: SoftWhip = kernel.new()')
(out/'checks.gd').write_text(checker,encoding='utf-8')
probe='''extends "res://tests/smoke_test.gd"

func _run() -> void:
	var variants := SCRIPTS
	var checker := preload("CHECKS")
	var report := {}
	for key: String in variants:
		_failures.clear()
		_checks = 0
		checker.run(EnvironmentSuite.new(self), variants[key])
		report[key] = {"checks":_checks,"failures":Array(_failures)}
		print("NE276_REPLAY ", key, " ", JSON.stringify(report[key]))
	var path := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			path = arg.trim_prefix("--out=")
	FileAccess.open(path,FileAccess.WRITE).store_string(JSON.stringify(report))
	get_tree().quit()
'''.replace('CHECKS',(out/'checks.gd').as_posix()).replace('SCRIPTS','{'+','.join(f'"{key}":preload("{(out/(key+".gd")).as_posix()}")' for key in variants)+'}')
script=out/'observer.gd'
script.write_text(probe,encoding='utf-8')
scene=script.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{script.as_posix()}" id="1"]\n[node name="WhipReplay" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
 env[key]=str(out/'profile'/key)
args=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(project),'--quit-after','600',str(scene),'--','--out='+str(out/'report.json')]
(out/'command.json').write_text(json.dumps(args,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
 proc=subprocess.run(args,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
raw=(out/'raw.log').read_text(encoding='utf-8')
print('\n'.join(line for line in raw.splitlines() if line.startswith('NE276_REPLAY')),flush=True)
assert proc.returncode==0 and 'ERROR:' not in raw and (out/'report.json').is_file(),raw[-1800:]
