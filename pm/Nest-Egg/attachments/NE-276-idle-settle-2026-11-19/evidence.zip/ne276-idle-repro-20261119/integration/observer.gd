extends "res://tests/smoke_test.gd"

func _run() -> void:
	preload("res://tests/helpers/soft_whip_native_checks.gd").run(EnvironmentSuite.new(self))
	print("IDLE_WHIP_CHECKS ", _checks, "/", _failures.size())
	for failure in _failures:
		print("FAIL: ", failure)
	get_tree().quit(0 if _failures.is_empty() else 1)
