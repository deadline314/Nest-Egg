extends SoftWhip

var samples: Array = []
const TEST_BEND_PROJECTION_DAMPING := 0.85
const TEST_KEEP_PER_SECOND_FREE := 0.02

func _step_impl(delta: float, root: Vector2, handle_dir: Vector2, length_target: float, tip_target: Vector2, pull: float) -> void:
	if not _laid:
		_lay(root, length_target)
	_length = move_toward(_length, length_target, delta * (REEL_OUT if length_target > _length else REEL_IN))
	var segment := _length / float(NODES - 1)
	var dt := delta / float(SUBSTEPS)
	var gravity_step := Vector2(0.0, GRAVITY * dt * dt)
	var pulled := pull > 0.0
	var keep := pow(KEEP_PER_SECOND if pulled else TEST_KEEP_PER_SECOND_FREE, dt)
	var bend := not pulled and dt > 0.0
	var iterations := PULLED_ITERATIONS if pulled else FREE_ITERATIONS
	var frequency_step := TAU * BEND_HERTZ * dt
	var damping := 2.0 / frequency_step if bend else 0.0
	var softness := 1.0 / (frequency_step * frequency_step) if bend else 0.0
	for sub in SUBSTEPS:
		for i in range(1, NODES):
			var here := _pos[i]
			_pos[i] = here + (here - _prev[i]) * keep + gravity_step
			_prev[i] = here
			if bend:
				_prediction[i] = _pos[i]
		_prev[0] = _pos[0]
		_pos[0] = root
		# 出線口那一節順著握把出去（線是從握把裡放出來的，不會一出來就折）。
		_pos[1] = _pos[1].lerp(root + handle_dir * segment, HANDLE_STIFFNESS)
		if pulled:
			for k in PULL_FALLOFF.size():
				var index := NODES - 1 - k
				var goal := tip_target + (root - tip_target).normalized() * segment * float(k)
				_pos[index] = _pos[index].lerp(goal, clampf(pull * PULL_FALLOFF[k], 0.0, 0.9))
		# 被拉緊了：線再放出來一點（放到上限還是太緊，就把鞭梢往回收），鞭身保有弧度。
		var chord := _pos[0].distance_to(_pos[NODES - 1])
		if chord > _length * MAX_TAUT:
			_length = minf(chord / MAX_TAUT, maxf(_length, length_target * MAX_PAYOUT))
			segment = _length / float(NODES - 1)
		# 累積量只在當前子步有效，重用既有繪圖緩衝，不增加持續狀態。
		if bend:
			_points.fill(Vector2.ZERO)
		for iteration in iterations:
			# 端點距離上限和材料／段長一起求解，避免最後孤立壓短末節。
			var cap_chord := _pos[0].distance_to(_pos[NODES - 1])
			if cap_chord > _length * MAX_TAUT:
				_pos[NODES - 1] = _pos[0] + (_pos[NODES - 1] - _pos[0]) * (_length * MAX_TAUT / cap_chord)
			# 拉力保持起甩的傳波，放手後由材料彎曲約束卸掉摺角。
			if bend:
				_screen_bend(damping, softness)
			_pos[0] = root
			for i in range(1, NODES):
				var a := _pos[i - 1]
				var b := _pos[i]
				var gap := b - a
				var distance := gap.length()
				if distance < 0.0001:
					continue
				var fix := gap * ((distance - segment) / distance)
				if i == 1:
					_pos[i] = b - fix
				else:
					var half_fix := fix * 0.5
					_pos[i - 1] = a + half_fix
					_pos[i] = b - half_fix
			for i in range(1, NODES):
				if _pos[i].y > floor_y:
					_pos[i].y = floor_y
		# 有目標時先從鞭梢往握把修一遍（鞭梢盡量留在被拉到的地方），
		if pulled:
			for i in range(NODES - 2, 0, -1):
				var toward := _pos[i + 1]
				var back := _pos[i] - toward
				var span := back.length()
				if span > segment and span > 0.0001:
					_pos[i] = toward + back * (segment / span)
		# 最後從握把往鞭梢逐節把距離修到剛好一節：鞭身不會被拉長。
		for i in range(1, NODES):
			var from := _pos[i - 1]
			var gap := _pos[i] - from
			var distance := gap.length()
			if distance > segment and distance > 0.0001:
				_pos[i] = from + gap * (segment / distance)
		# 位置修正只少量回饋到速度，讓鬆弛的鞭身靜置後不再彈跳。
		if bend:
			for i in range(1, NODES):
				_prev[i] += (_pos[i] - _prediction[i]) * TEST_BEND_PROJECTION_DAMPING


## 三點高度的 XPBD 臨界阻尼投影；累積修正避免迭代次數改變材料硬度。
func _screen_bend(damping: float, softness: float) -> void:
	var denominator := 1.0 + damping + softness
	for j in range(1, NODES - 1):
		var a := _pos[j - 1]
		var b := _pos[j]
		var c := _pos[j + 1]
		var height := b - (a + c) * 0.5
		var old_height := _prev[j] - (_prev[j - 1] + _prev[j + 1]) * 0.5
		var weight := 0.0 if j == 1 else 1.0
		var inverse_mass := 1.25 + weight * 0.25
		var impulse := -(height + _points[j] * (inverse_mass * softness) + (height - old_height) * damping) / (inverse_mass * denominator)
		_points[j] += impulse
		_pos[j - 1] = a - impulse * (weight * 0.5)
		_pos[j] = b + impulse
		_pos[j + 1] = c - impulse * 0.5



func step(delta: float, root: Vector2, handle_dir: Vector2, length_target: float, tip_target: Vector2, pull: float) -> void:
	_step_impl(delta, root, handle_dir, length_target, tip_target, pull)
	if samples.size() < 113:
		samples.append([delta, root.x, root.y, handle_dir.x, handle_dir.y, length_target, floor_y, tip().x, tip().y, pull])
