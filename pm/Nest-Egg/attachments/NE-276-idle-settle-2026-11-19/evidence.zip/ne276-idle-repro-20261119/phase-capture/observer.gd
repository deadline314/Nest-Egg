extends "res://tests/smoke_test.gd"

class InjectedWhip extends EnvironmentSuite:
	var kernel: GDScript
	var delay: int
	var captured: SoftWhip

	func start_level(data: LevelData, difficulty_index := 1) -> Level:
		var level := await super.start_level(data, difficulty_index)
		await physics_frames(delay)
		captured = kernel.new()
		level.player._visual.melee_held()._whip = captured
		return level


func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var results := {}
	var destination := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			destination = arg.trim_prefix("--out=")
	var variants := {"current":preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/phase-capture/current.gd")}
	for key: String in variants:
		var trials := []
		for delay in [0,1,2,3,34,55,89,120]:
			seed(276)
			_failures.clear()
			_checks = 0
			var suite := InjectedWhip.new(self)
			suite.kernel = variants[key]
			suite.delay = delay
			await suite._test_soft_whip()
			var trace: Array = suite.captured.get("samples")
			trials.append({"delay": delay,"checks":_checks,"failures":Array(_failures),"trace":trace})
		results[key] = trials
		print("NE276_IDLE_PHASE ",key," ",JSON.stringify(trials.map(func(row: Dictionary) -> Dictionary: return {"delay": row.delay,"failures":row.failures})))
	FileAccess.open(destination, FileAccess.WRITE).store_string(JSON.stringify(results))
	await AudioRelease.settle(get_tree())
	get_tree().quit()
