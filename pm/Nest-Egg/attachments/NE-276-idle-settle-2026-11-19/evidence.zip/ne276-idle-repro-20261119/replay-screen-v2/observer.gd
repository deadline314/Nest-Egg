extends "res://tests/smoke_test.gd"

func _run() -> void:
	var variants := {"current":preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/replay-screen-v2/current.gd"),"damp88":preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/replay-screen-v2/damp88.gd"),"damp90":preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/replay-screen-v2/damp90.gd"),"damp92":preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/replay-screen-v2/damp92.gd"),"damp95":preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/replay-screen-v2/damp95.gd"),"damp97":preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/replay-screen-v2/damp97.gd"),"damp100":preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/replay-screen-v2/damp100.gd"),"air001":preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/replay-screen-v2/air001.gd"),"air0001":preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/replay-screen-v2/air0001.gd")}
	var checker := preload("D:/NestEggVerification/evidence-20261117/ne276-idle-repro-20261119/replay-screen-v2/checks.gd")
	var report := {}
	for key: String in variants:
		_failures.clear()
		_checks = 0
		checker.run(EnvironmentSuite.new(self), variants[key])
		report[key] = {"checks":_checks,"failures":Array(_failures)}
		print("NE276_REPLAY ", key, " ", JSON.stringify(report[key]))
	var path := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			path = arg.trim_prefix("--out=")
	FileAccess.open(path,FileAccess.WRITE).store_string(JSON.stringify(report))
	get_tree().quit()
