extends "res://work/ne228-framing/phone_base.gd"

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	var reduced := false
	for arg in OS.get_cmdline_user_args():
		if arg == "--1080":
			get_window().size = Vector2i(1920, 1080)
			DisplayMode.ensure_scaling(get_window())
			Settings.set_ui_text_scale(1.2)
		elif arg == "--reduced":
			reduced = true
	Settings.set_reduce_ui_motion(reduced)
	await _until(func() -> bool: return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested", GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE), "real Main starts the formal run")
	await _skip_cinematics()
	await _enter(PAWNSHOP)
	var old_k: NpcActor
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and _level().is_ancestor_of(node) and node.data.id == &"ch1_old_k":
			old_k = node
	_check(old_k != null and old_k.is_present(), "formal authored Old K is present")
	if old_k == null:
		return
	_level().player.global_position = old_k.global_position + Vector2(-65, 0)
	_level().player.velocity = Vector2.ZERO
	_check(await _until(func() -> bool: return Story.framing.selected_target() == old_k and Story.framing.amount > 0.1 and not Story.is_cinematic_active(), 4.0), "actual person approach previews framing without starting dialogue")
	_check(not _level().hud._framing_edge_root.visible, "framing hides the conflicting gameplay header")
	await _shot("person-approach")
	await _retreat(old_k)
	await _shot("approach-retreated")
	_level().player.global_position = old_k.global_position + Vector2(-24, 0)
	_check(await _until(func() -> bool: return old_k.interaction_available() and Story.framing.is_interaction_target(old_k)), "actual person sensor and nearest-source arbitration are ready")
	await _press(&"interact")
	_check(await _until(Story.is_cinematic_active), "public interact starts the authored Old K conversation")
	_check(Story.framing.scope_count() > 0 and not _level().hud._framing_edge_root.visible, "actual conversation owns its framing scope and hides header")
	await _shot("person-dialogue")
	await _read_to_end()
	_check(not GameplayLock.is_locked() and Story.framing.scope_count() == 0, "public reading completion releases its own gameplay and framing scopes")
	await _retreat(old_k)
	await _shot("dialogue-retreated")
	_completed = true
	_save_report()

func _retreat(person: NpcActor) -> void:
	var motion := InputEventAction.new()
	motion.action = &"move_left"
	motion.pressed = true
	Input.parse_input_event(motion)
	_check(await _until(func() -> bool: return _level().player.global_position.x < person.global_position.x - 110.0, 8.0), "public movement retreats beyond the original exit distance")
	motion = InputEventAction.new()
	motion.action = &"move_left"
	Input.parse_input_event(motion)
	var before := ContextualUiChecks._header_resume_state(_level())
	await get_tree().create_timer(CinematicFraming.CHECK_INTERVAL + CinematicFraming.EASE_SECONDS + 0.1).timeout
	_level().hud._process(0.0)
	var after := ContextualUiChecks._header_resume_state(_level())
	_check(not Story.is_cinematic_active() and not GameplayLock.is_locked() and Story.framing.selected_target() == null and _level().hud._framing_edge_root.visible, "formal Main restores header within unchanged original .48-second budget")
	_check(is_zero_approx(Story.framing.amount), "the actual bars finish returning to zero")
	rows.append({"name": "retreat-budget", "before": before, "after": after})
