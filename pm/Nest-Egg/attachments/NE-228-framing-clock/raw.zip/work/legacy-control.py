from pathlib import Path
import os,subprocess,hashlib,json
p=Path('ui/cinematic_framing.gd');final=p.read_bytes();before=Path('work/ne228-framing/before.gd').read_bytes();env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen';code=None
try:
 p.write_bytes(before)
 with Path('work/ne228-framing/native-before-wrapper.log').open('w') as log:
  code=subprocess.run(['python','/workspace/Nest-Egg/work/batch1020b/native.py','ne228-1022-framing-native-before-control','res://work/ne228-framing/native.tscn'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
finally:
 p.write_bytes(final)
 receipt={'before':hashlib.sha256(before).hexdigest(),'final':hashlib.sha256(final).hexdigest(),'restored':hashlib.sha256(p.read_bytes()).hexdigest(),'wrapper_exit':code,'scope':'original framing product source with same queued native legacy helper driver'}
 Path('work/ne228-framing/legacy-control.json').write_text(json.dumps(receipt,indent=2)+'\n')
 assert receipt['final']==receipt['restored']
 print(receipt,flush=True)
