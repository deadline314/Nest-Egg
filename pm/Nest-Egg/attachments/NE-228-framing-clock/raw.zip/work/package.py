from pathlib import Path
import hashlib,json,zipfile,subprocess,re,shutil
root=Path.cwd();work=root/'work/ne228-framing';native=Path('/workspace/Nest-Egg/work/batch1020b');out=root/'pm/Nest-Egg/attachments/NE-228-framing-clock';out.mkdir(parents=True,exist_ok=True)
base='b2d253c8862710841aaaf0c30301ce8144de7be0';sha=lambda b:hashlib.sha256(b).hexdigest()
frozen=json.loads((work/'frozen-source.json').read_text());assert all(sha((root/p).read_bytes())==v for p,v in frozen.items())
assert not subprocess.check_output(['git','diff','--name-only',base,'--','tests','tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/run_tests.sh','tools/select_tests.py','tools/test_filters.sh']).strip()
assert (work/'original-helper.gd').read_bytes()==subprocess.check_output(['git','show',base+':tests/helpers/contextual_ui_checks.gd'])
(work/'harness-unchanged.json').write_text(json.dumps({'base':base,'tests_and_original_harness_unchanged':True,'original_helper_sha256':sha((work/'original-helper.gd').read_bytes())},indent=2)+'\n')
log=(work/'changed.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures \(tests/known_failures.txt\): (\d+)\s*\(wall time (\d+) s\)',log);assert m and (m[2],m[3])==('0','0')
assert 'checks: 260, failures: 3' in (work/'before.log').read_text();assert 'checks: 260, failures: 0' in (work/'after.log').read_text()
native_checks=0
for case in ['720','1080','reduced']:
 name='ne228-1022-framing-main-'+case;t=(native/(name+'.log')).read_text();assert 'ERROR:' not in t and 'leaked' not in t and (native/(name+'.exit')).read_text().strip()=='0';d=json.loads((native/name/'result.json').read_text());assert d['completed'] and d['failures']==0
 native_checks+=sum(l.startswith('PASS ') for l in t.splitlines())
files={}
for p in work.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in part or part.startswith('data_') for part in p.relative_to(work).parts):files['work/'+str(p.relative_to(work))]=p.read_bytes()
for p in native.glob('ne228-1022-framing-*'):
 if p.is_dir() and not p.name.endswith('-profile'):
  for f in p.iterdir():
   if f.is_file():files['native/'+p.name+'/'+f.name]=f.read_bytes()
 elif p.is_file() and p.suffix in ['.log','.exit']:files['native/'+p.name]=p.read_bytes()
for p in ['ui/cinematic_framing.gd','tests/helpers/contextual_ui_checks.gd','ui/hud.gd','tools/quest_resume_probe.gd','tools/viewport_capture.gd','project.godot']:
 files['source/final/'+p]=(root/p).read_bytes();files['source/before/'+p]=subprocess.check_output(['git','show',base+':'+p])
files['tools/native.py']=(native/'native.py').read_bytes()
ref=root/'pm/Nest-Egg/attachments/NE-229-recovery-references'
for p in ref.iterdir():
 if p.is_file():files['references/'+p.name]=p.read_bytes()
validation={'base':base,'previous_ci':{'run':39748800959,'checks':95961,'new_failures':1,'seconds':625,'artifact':12413218239,'artifact_sha256':sha((work/'ci-artifact.zip').read_bytes())},'original_changed_groups':2,'checks':int(m[1]),'new_failures':0,'known_failures':0,'seconds':int(m[4]),'same_original_helper_jitter':{'before_checks':260,'before_failures':3,'after_checks':260,'after_failures':0,'headless_cleanup_warnings_retained':True},'native_formal_main_checks':native_checks,'native_formal_main_failures':0,'native_formal_main_engine_errors':0,'native_final_pngs_viewed':12,'renderer':'Forward+ HDR, Vulkan llvmpipe','native_legacy_helper':{'v1_assertion_failures':1,'v1_capture_name_error':True,'v2_assertion_failures':0,'v3_assertion_failures':0,'final_source_exit':250,'original_product_control_assertion_failures':0,'original_product_control_exit':250,'engine_errors':'11 CanvasShaderRD shaders not freed; decal atlas two textures not removed','engine_root_cause':'not established; changing queued teardown did not resolve; not treated as passing native exit'},'source':frozen,'scope':'actual formal Main Old K via public inputs; arranged routing/position; original .48s budget; not physical controller or human complete chapter'}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
manifest={'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for e in manifest['files']:assert sha(z.read(e['path']))==e['sha256']
manifest.update(archive_sha256=sha((out/'raw.zip').read_bytes()),archive_bytes=(out/'raw.zip').stat().st_size)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for src,name in [('720/person-dialogue.png','dialogue'),('720/dialogue-retreated.png','restored'),('1080/person-dialogue.png','dialogue-1080'),('1080/dialogue-retreated.png','restored-1080'),('reduced/dialogue-retreated.png','reduced')]:shutil.copy2(native/('ne228-1022-framing-main-'+src),root/'pm/Nest-Egg/images'/('NE-228-framing-'+name+'.png'))
print(json.dumps({'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256'],'validation':validation},indent=2))
