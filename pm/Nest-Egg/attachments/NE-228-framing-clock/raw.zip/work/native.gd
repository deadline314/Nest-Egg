extends "res://work/ne228-framing/repeat.gd"

var output := ""
var reading_captured := false
var captures: Array = []
var pending_capture := false

func _ready() -> void:
	pattern = PackedInt32Array([0])
	repeats = 1
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			output = arg.trim_prefix("--out=")
		elif arg == "--1080":
			get_window().size = Vector2i(1920, 1080)
			DisplayMode.ensure_scaling(get_window())
		elif arg == "--reduced":
			Settings.set_reduce_ui_motion(true)
	super._ready()

func _process(delta: float) -> void:
	super._process(delta)
	if reading_captured:
		return
	for node in get_tree().root.get_children():
		if node is Level and Story.is_cinematic_active() and Story._layer._reading_title == (preload("res://data/npcs/height_marks.tres") as NpcData).display_name:
			reading_captured = true
			pending_capture = true
			_capture("reading", node)

func _capture(name: String, level: Level) -> void:
	await RenderingServer.frame_post_draw
	var picture := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(picture.save_png(output.path_join(name + ".png")) == OK, "native capture " + name)
	captures.append({"name": name, "state": ContextualUiChecks._header_resume_state(level), "size": [picture.get_width(), picture.get_height()]})
	pending_capture = false

func _end_level(level: Level) -> void:
	while pending_capture:
		await get_tree().process_frame
	await _capture("resumed", level)
	for action in [&"move_right", &"shoot", &"jump", &"aim_right", &"aim_left", &"block"]:
		Input.action_release(action)
	# Capture resumes on frame_post_draw: defer destruction to the normal scene boundary.
	level.queue_free()
	get_tree().paused = false
	Engine.time_scale = 1.0
	await get_tree().process_frame
	await get_tree().process_frame

func run() -> void:
	var suite := UiScreensSuite.new(self)
	Story.auto_skip = true
	await ContextualUiChecks._radio_identity_after_authored_reading(suite)
	suite = null
	_check(reading_captured, "actual authored object reading was captured")
	Story.reset_active_presentation(&"leave")
	Sfx.stop_all()
	Music.stop(0)
	Ambience.stop_all(0)
	await AudioRelease.settle(get_tree())
	FileAccess.open(output.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify({"checks": checks, "failures": failures, "captures": captures, "scope": "unchanged original helper and exact .48-second assertion in authored legacy level_02; software Forward+; direct original object talk; not full human chapter"}, "\t"))
	print("checks: ", checks, ", failures: ", failures)
	get_tree().quit(0 if failures == 0 else 1)
