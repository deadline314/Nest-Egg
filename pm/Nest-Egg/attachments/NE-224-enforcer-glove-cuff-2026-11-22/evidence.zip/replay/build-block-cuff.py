from pathlib import Path
from PIL import Image
import numpy as np

e=Path(__file__).resolve().parent
source=np.asarray(Image.open("art/characters/enforcer/parts/hand.png").convert("RGBA"))
for variant, changes in {
    801: [(48,7,150),(49,8,195),(50,8,165),(50,9,185),(51,9,140)],
    802: [(47,7,155),(48,7,175),(48,8,196),(49,7,145),(49,8,214),(50,8,188),(50,9,212),(51,9,170),(52,9,145)],
    803: [(47,6,148),(48,7,188),(48,8,224),(49,7,176),(49,8,232),(50,7,153),(50,8,196),(50,9,225),(51,8,155),(51,9,205),(52,9,170),(53,9,136),(54,9,136)],
    }.items():
    result=source.copy()
    for y,x,alpha in changes:
        assert alpha>source[y,x,3]
        result[y,x,:3]=source[y,11,:3]
        result[y,x,3]=alpha
    Image.fromarray(result).save(e/f"wrist-band-{variant}.png")
    print(variant,len(changes))
s=(e/"wrist-matrix.gd").read_text(encoding="utf-8")
s=s.replace('const POSES := ["idle", "run", "aim_up", "crouch", "jump", "block", "stagger", "dead"]',
            'const POSES := ["block"]')
(e/"block-cuff.gd").write_text(s,encoding="utf-8")
s=(e/"wrist-matrix.tscn").read_text(encoding="utf-8").replace("/wrist-matrix.gd","/block-cuff.gd")
(e/"block-cuff.tscn").write_text(s,encoding="utf-8")
s=(e/"run-wrist-matrix.ps1").read_text(encoding="utf-8").replace("/wrist-matrix.tscn","/block-cuff.tscn")
(e/"run-block-cuff.ps1").write_text(s,encoding="utf-8")
