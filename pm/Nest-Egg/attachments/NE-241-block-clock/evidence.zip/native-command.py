import os,subprocess,pathlib,json,re
root=pathlib.Path.cwd();out=root/'work/block-clock';rows=[]
for label in ['before','after']:
 env=os.environ.copy();profile=str(out/('native-'+label+'-profile'));env.update(XDG_DATA_HOME=profile,APPDATA=profile,LOCALAPPDATA=profile)
 command=['python3','tools/comfyui/gpu_lock.py','--','xvfb-run','-a','-s','-screen 0 1280x720x24',env['GODOT'],'--path','.', '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',f'res://work/block-clock/native-{label}.tscn','--','--only=block','--fixture-fps=5']
 with (out/f'native-{label}.log').open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 text=(out/f'native-{label}.log').read_text(errors='replace');m=re.search(r'checks: (\d+), failures: (\d+)',text);rows.append({'label':label,'exit':r.returncode,'checks':int(m[1]) if m else 0,'failures':int(m[2]) if m else -1,'command':command});(out/'native.json').write_text(json.dumps(rows,indent=2));print(rows[-1],flush=True)
