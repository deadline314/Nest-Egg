from pathlib import Path
import subprocess,os,json,re,hashlib
from concurrent.futures import ThreadPoolExecutor
root=Path.cwd();out=root/'work/block-clock';engine=os.environ['GODOT'];label=os.environ.get('BLOCK_LABEL','final')
def run(fps):
 env=os.environ.copy();profile=str(out/f'{label}-profile-{fps}');env.update(XDG_DATA_HOME=profile,APPDATA=profile,LOCALAPPDATA=profile);command=[engine,'--headless','--audio-driver','Dummy','--path',str(root),'res://work/block-clock/after.tscn','--','--only=block',f'--fixture-fps={fps}']
 with (out/f'{label}-{fps}.log').open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 text=(out/f'{label}-{fps}.log').read_text(errors='replace');m=re.search(r'checks: (\d+), failures: (\d+)',text);diagnostics=[l for l in text.splitlines() if re.search(r'^ERROR:|SCRIPT ERROR|Parse Error|^FAIL:',l)]
 return {'fps':fps,'exit':r.returncode,'checks':int(m[1]) if m else 0,'failures':int(m[2]) if m else -1,'diagnostics':diagnostics}
results=list(ThreadPoolExecutor(max_workers=4).map(run,[0,5,10,20]));(out/f'{label}.json').write_text(json.dumps({'cases':results,'source_sha256':hashlib.sha256((root/'tests/smoke_test.gd').read_bytes()).hexdigest()},indent=2));print(results)
