extends "C:/Users/stanl/Github/Nest-Egg/work/ne97-campaign-route-20261119/combat-route.gd"

var _heard_sfx: Dictionary = {}
var _heard_tracks: Dictionary = {}
var _heard_beds: Dictionary = {}
var _loudest := -160.0
var _sample_left := 0.0


func _ready() -> void:
	if AudioServer.get_driver_name() != "WASAPI":
		get_tree().quit(3)
		return
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--audio-bank="):
			Sfx.bank().load_bank(arg.trim_prefix("--audio-bank="), true)
			Sfx._build_streams()
	Sfx.sound_played.connect(_observe_sfx)
	Music.track_started.connect(_observe_music)
	Ambience.layer_started.connect(_observe_bed)
	super._ready()


func _sound_location() -> StringName:
	if _main == null or _level() == null:
		return &"menu"
	return _level().data.id


func _observe_sfx(id: StringName) -> void:
	var key := "%s/%s" % [_sound_location(), id]
	if not _heard_sfx.has(key):
		_read_voice.call_deferred(key, id)


func _read_voice(key: String, id: StringName) -> void:
	if _heard_sfx.has(key):
		return
	for index in Sfx._players.size():
		var player: AudioStreamPlayer = Sfx._players[index]
		if player.playing and Sfx._voice_sound[index] == id and player.stream != null:
			_heard_sfx[key] = {"source": String(Sfx.source_of(id)), "file": player.stream.resource_path}
			return


func _observe_music(id: StringName) -> void:
	_heard_tracks["%s/%s" % [_sound_location(), Music.current_state()]] = Music.track_def(id).get("file", "")


func _observe_bed(id: StringName) -> void:
	_heard_beds["%s/%s" % [_sound_location(), id]] = true


func _process(delta: float) -> void:
	_sample_left -= delta
	if _sample_left > 0.0:
		return
	_sample_left = 0.1
	_loudest = maxf(_loudest, AudioServer.get_bus_peak_volume_left_db(0, 0))


func _exit_tree() -> void:
	if not _out.is_empty():
		var output := {"driver": AudioServer.get_driver_name(), "sfx": _heard_sfx, "music": _heard_tracks,
			"ambience": _heard_beds.keys(), "peak_db": _loudest}
		var file := FileAccess.open(_out.path_join("audio.json"), FileAccess.WRITE)
		if file != null:
			file.store_string(JSON.stringify(output, "\t"))
