extends Node


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() != 2:
		get_tree().quit(2)
		return
	get_window().content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	var lab := SoundLab.new()
	lab.stage_enabled = false
	add_child(lab)
	lab.tabs.current_tab = lab.tabs.get_tab_idx_from_control(lab.mixer_tab)
	var capture := preload("res://tools/viewport_capture.gd")
	for version: String in ["before", "after"]:
		if version == "before":
			Sfx.bank().load_bank(args[1], true)
			Sfx._build_streams()
		else:
			Sfx.reload_bank(true)
		var counts := Sfx.source_counts()
		if counts["failed"] != 0 or counts["synth"] != (4 if version == "before" else 0):
			get_tree().quit(1)
			return
		print("NE154_LAB ", version, " ", lab.mixer_tab.update_diagnostics())
		for tick in 12:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		if capture.image(get_viewport()).save_png(args[0].path_join(version + "-mixer.png")) != OK:
			get_tree().quit(1)
			return
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)
