extends Node

const SOUNDS := [&"reload_start", &"reload_mid", &"reload_done", &"empty"]


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	var paths := OS.get_cmdline_user_args()
	if paths.size() not in [1, 2]:
		get_tree().quit(2)
		return
	Engine.max_fps = 60
	var candidate := paths.size() == 2
	if candidate:
		Sfx.bank().load_bank(paths[1], true)
		Sfx._build_streams()
	var output := paths[0]
	DirAccess.make_dir_recursive_absolute(output)
	var effect := AudioEffectRecord.new()
	effect.format = AudioStreamWAV.FORMAT_16_BITS
	var effect_index := AudioServer.get_bus_effect_count(0)
	AudioServer.add_bus_effect(0, effect)
	var passed := AudioServer.get_driver_name() == "WASAPI"
	var entries: Array[Dictionary] = []
	for sound: StringName in SOUNDS:
		effect.set_recording_active(true)
		await get_tree().create_timer(0.10).timeout
		var played := Sfx._play_voice(sound, -4.0, 1.0, 1)
		var resources := Sfx.bank().files_of(sound)
		await get_tree().create_timer(maxf(0.32, Sfx.sound_length(sound) + 0.10)).timeout
		effect.set_recording_active(false)
		var wave := effect.get_recording()
		var status := wave.save_to_wav(output.path_join(String(sound) + ".wav"))
		var source := Sfx.source_of(sound)
		passed = passed and played and source == (&"file" if candidate else &"synth") and status == OK
		entries.append({"id":sound,"source":source,"duration":wave.get_length(),"files":resources,"played":played})
	var receipt := {"driver":AudioServer.get_driver_name(),"candidate":candidate,"entries":entries,"sources":Sfx.source_counts(),"passed":passed}
	FileAccess.open(output.path_join("receipt.json"), FileAccess.WRITE).store_string(JSON.stringify(receipt, "\t"))
	print(receipt)
	AudioServer.remove_bus_effect(0, effect_index)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if passed else 1)
