from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

base = Path(__file__).resolve().parent
shared = 'D:/NestEggVerification/ne218-baseline-20261117'
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
out = base / ('serial-' + (sys.argv[1] if len(sys.argv) > 1 else 'v1'))
out.mkdir()
native = 'native' in out.name
root = base.parents[1]
chain = ('street', 'blockade', 'warehouse', 'flood', 'raft', 'vault', 'handoff',
         'ch2-open', 'ch2-market', 'ch2-loading', 'ch2-yong', 'ch2-close')
prior = base / 'native-campaign-menu-prologue-v2/save/slot.json'
if len(sys.argv) > 3:
    prior = Path(sys.argv[2]).resolve()
    chain = chain[chain.index(sys.argv[3]):]
for mode in chain:
    stage = out / mode
    save = stage / 'save'
    save.mkdir(parents=True)
    path = save / 'slot.json'
    shutil.copyfile(prior, path)
    before = sha256(path.read_bytes()).hexdigest()
    env = os.environ.copy()
    for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
        env[key] = str(stage / 'profile' / key)
    graphics = (['--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--resolution', '1280x720']
                if native else ['--display-driver', 'headless', '--max-fps', '60'])
    lock = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--'] if native else []
    flags = ['--difficulty-audit'] if not native or mode in ('warehouse', 'vault', 'ch2-market', 'ch2-loading', 'ch2-yong') else []
    if mode == 'blockade':
        flags.append('--bypass-hardcore-blockade')
    if mode == 'warehouse':
        flags.append('--defensive-watchdog')
    command = [*lock, engine, '--path', shared, '--audio-driver', 'WASAPI', *graphics,
               '--fixed-fps', '60', '--quit-after', '16000',
               (base / 'campaign-audio.tscn').as_posix(), '--', '--from-save',
               *flags, '--' + mode, f'--out={stage.as_posix()}', f'--save-dir={save.as_posix()}']
    (stage / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
    print(f'{mode} starts from {prior}', flush=True)
    with (stage / 'raw.log').open('wb') as log:
        run = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=310)
    raw = (stage / 'raw.log').read_text(encoding='utf-8', errors='replace')
    passed = run.returncode == 0 and 'failures=0' in raw and 'SCRIPT ERROR:' not in raw
    after = sha256(path.read_bytes()).hexdigest()
    result = {'passed': passed, 'exit': run.returncode, 'before': before, 'after': after}
    (stage / 'chain.json').write_text(json.dumps(result, indent=2) + '\n')
    print(mode, result, flush=True)
    if not passed:
        sys.exit(1)
    prior = path
