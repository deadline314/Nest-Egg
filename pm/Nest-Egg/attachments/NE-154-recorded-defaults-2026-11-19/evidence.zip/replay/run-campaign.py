from pathlib import Path
import os
import shutil
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
source = root / 'work/ne97-campaign-route-20261119'
shared = 'D:/NestEggVerification/ne218-baseline-20261117'
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
cases = {
    'menu-prologue': ('fresh', None),
    'watchdog': ('warehouse', 'native-blockade-v3'),
    'market': ('ch2-market', 'native-ch2-open-v1'),
    'yong': ('ch2-yong', 'native-ch2-loading-v1'),
    'chapter-two-close': ('ch2-close', 'native-ch2-yong-v1'),
}
native = '--native' in sys.argv
revision = next((arg[10:] for arg in sys.argv if arg.startswith('--version=')), '')
selection = [label for label in sys.argv[1:] if not label.startswith('--')] or list(cases)
passed = True
for label in selection:
    mode, seed = cases[label]
    target = base / f'{"native-" if native else ""}campaign-{label}{revision}'
    target.mkdir()
    save = target / 'save'
    save.mkdir()
    if seed:
        shutil.copyfile(source / seed / 'save/slot.json', save / 'slot.json')
    env = os.environ.copy()
    for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
        env[key] = str(target / 'profile' / key)
    flags = ['--from-save', '--difficulty-audit'] if seed else ['--camera-audit', '--audio-route-audit']
    render = ['--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--resolution', '1280x720',
              '--fixed-fps', '60', '--quit-after', '18000'] if native else ['--display-driver', 'headless', '--max-fps', '60']
    prefix = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--'] if native else []
    command = [*prefix, engine, '--path', shared, '--audio-driver', 'WASAPI', *render,
               (base / 'campaign-audio.tscn').as_posix(), '--', *flags, '--' + mode, f'--out={target.as_posix()}',
               f'--save-dir={save.as_posix()}']
    print(label, flush=True)
    with (target / 'raw.log').open('wb') as log:
        run = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=320)
    print(label, run.returncode, (target / 'audio.json').is_file(), flush=True)
    passed = passed and run.returncode == 0 and (target / 'audio.json').is_file()
sys.exit(0 if passed else 1)
