from pathlib import Path
import os,subprocess,json,hashlib
out=Path('work/ne228-reverse');env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen';rows=[]
files=['ui/cinematic_framing.gd','tests/helpers/contextual_ui_checks.gd','tests/suite/test_npc.gd','work/ne228-framing/main.gd','work/ne228-framing/phone_base.gd']
(out/'frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')
for case,args in [('720',[]),('1080',['--1080']),('reduced',['--reduced'])]:
 name='ne228-1022-framing-realtime-'+case
 command=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/ne228-framing/main.tscn','--mode=write','--save-dir='+str((out/('main-'+case+'-save')).absolute()),*args]
 with (out/(name+'-wrapper.log')).open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=480)
 rows.append({'name':name,'command':command,'exit_code':r.returncode});(out/'matrix-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert r.returncode==0
