from pathlib import Path
import hashlib,json,zipfile,subprocess,re,shutil
root=Path.cwd();work=root/'work/ne228-reverse';native=Path('/workspace/Nest-Egg/work/batch1020b');out=root/'pm/Nest-Egg/attachments/NE-228-framing-realtime';out.mkdir(parents=True,exist_ok=True)
base='96f602e833037af5bc6d20c912d7c9924f722b74';sha=lambda b:hashlib.sha256(b).hexdigest()
frozen=json.loads((work/'frozen-source.json').read_text());assert all(sha((root/p).read_bytes())==v for p,v in frozen.items())
assert not subprocess.check_output(['git','diff','--name-only',base,'--','tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/run_tests.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']).strip()
npc=(root/'tests/suite/test_npc.gd').read_text();npc=npc.replace('\tawait _test_framing_real_time()\n','');a=npc.index('func _test_framing_real_time()');b=npc.index('func _test_cinematic_framing()',a);npc=npc[:a]+npc[b:]
assert npc.encode()==subprocess.check_output(['git','show',base+':tests/suite/test_npc.gd'])
helper=(root/'tests/helpers/contextual_ui_checks.gd').read_text();helper=''.join(l for l in helper.splitlines(keepends=True) if '"framing_animation_processing"' not in l)
assert helper.encode()==subprocess.check_output(['git','show',base+':tests/helpers/contextual_ui_checks.gd'])
(work/'original-assertions.json').write_text(json.dumps({'base':base,'original_assertions_and_waits_preserved':True,'npc_new_checks':2,'helper_only_change':'failure-only driver state','original_harness_unchanged':True},indent=2)+'\n')
assert 'checks: 1496, new failures: 0' in (work/'final-changed.log').read_text()
assert 'checks: 571, failures: 0' in (work/'final-prefix.log').read_text()
for f in ['final-120.log','after-jitter-v2.log']:assert 'checks: 260, failures: 0' in (work/f).read_text()
checks=0
for case in ['720','1080','reduced']:
 name='ne228-1022-framing-realtime-'+case;log=(native/(name+'.log')).read_text();d=json.loads((native/name/'result.json').read_text());assert d['completed'] and d['failures']==0 and 'ERROR:' not in log and 'leaked' not in log and (native/(name+'.exit')).read_text().strip()=='0'
 checks+=sum(l.startswith('PASS ') for l in log.splitlines())
files={}
for p in work.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in part or part.startswith('data_') for part in p.relative_to(work).parts):files['work/ne228-reverse/'+str(p.relative_to(work))]=p.read_bytes()
for f in ['main.gd','main.tscn','phone_base.gd','repeat.gd','repeat.tscn','ci-39753116995.log']:
 files['work/ne228-framing/'+f]=(root/'work/ne228-framing'/f).read_bytes()
for p in (root/'work/ne228-framing').glob('*artifact*.zip'):files['previous-ci/'+p.name]=p.read_bytes()
for case in ['720','1080','reduced']:
 name='ne228-1022-framing-realtime-'+case
 for p in (native/name).iterdir():
  if p.is_file():files['native/'+name+'/'+p.name]=p.read_bytes()
 for ext in ['.log','.exit']:files['native/'+name+ext]=(native/(name+ext)).read_bytes()
for p in ['ui/cinematic_framing.gd','tests/suite/test_npc.gd','tests/helpers/contextual_ui_checks.gd','ui/hud.gd','tools/quest_resume_probe.gd','tools/viewport_capture.gd','project.godot']:
 files['source/final/'+p]=(root/p).read_bytes();files['source/before/'+p]=subprocess.check_output(['git','show',base+':'+p])
files['tools/native.py']=(native/'native.py').read_bytes()
for p in (root/'pm/Nest-Egg/attachments/NE-229-recovery-references').iterdir():
 if p.is_file():files['references/'+p.name]=p.read_bytes()
validation={'base':base,'previous_ci':{'run':39753116995,'checks':95970,'new_failures':1,'seconds':489,'artifact':12414933322},'original_changed_groups':2,'checks':1496,'new_failures':0,'known_failures':0,'seconds':51,'original_ci_prefix_checks':571,'original_ci_prefix_failures':0,'original_helper_high_fps':{'before':[260,2],'trace_only_before':[260,4],'final':[260,0]},'original_helper_jitter':{'manual_clock_intermediate':[260,3],'final':[260,0]},'old_product_negative_slow_motion_failures':2,'native_checks':checks,'native_failures':0,'native_processes':3,'native_engine_errors':0,'final_pngs_individually_viewed':12,'source':frozen,'limitations':['headless replay cleanup warnings retained','legacy isolated scene exit250 remains unresolved','120fps is a configured cap, not measured constant native frame rate','arranged Main routing/position, no story flag injection; not full human chapter or physical hardware acceptance','large world speech bubble remains visible in these arranged shots; not a complete UI composition acceptance']}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
manifest={'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for e in manifest['files']:assert sha(z.read(e['path']))==e['sha256']
manifest.update(archive_sha256=sha((out/'raw.zip').read_bytes()),archive_bytes=(out/'raw.zip').stat().st_size)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for src,name in [('720/person-dialogue.png','dialogue'),('720/dialogue-retreated.png','restored'),('1080/person-dialogue.png','dialogue-1080'),('1080/dialogue-retreated.png','restored-1080'),('reduced/dialogue-retreated.png','reduced')]:shutil.copy2(native/('ne228-1022-framing-realtime-'+src),root/'pm/Nest-Egg/images'/('NE-228-realtime-'+name+'.png'))
print(json.dumps({'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256'],'native_checks':checks},indent=2))
