from pathlib import Path
import subprocess,os,json,hashlib
out=Path('work/ne228-reverse');env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6',LOG_DIR=str((out/'changed-shards').absolute()))
commands=[('changed.log',['tools/run_tests_changed.sh','96f602e8'],{}),('after-jitter.log',[env['GODOT'],'--headless','--path','.','res://work/ne228-framing/repeat.tscn','--','--repeat=20'],{'XDG_DATA_HOME':str((out/'after-jitter-profile').absolute())})];rows=[]
for name,command,extra in commands:
 child=env.copy();child.update(extra)
 with (out/name).open('w') as log:r=subprocess.run(command,env=child,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 rows.append({'log':name,'command':command,'exit_code':r.returncode});(out/'verification-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert r.returncode==0
