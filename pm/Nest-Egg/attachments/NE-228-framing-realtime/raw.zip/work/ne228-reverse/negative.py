from pathlib import Path
import os,subprocess,json,hashlib
p=Path('ui/cinematic_framing.gd');final=p.read_bytes();before=Path('work/ne228-reverse/before.gd').read_bytes();env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',XDG_DATA_HOME=str(Path('work/ne228-reverse/negative-profile').absolute()))
code=None
try:
 p.write_bytes(before)
 with Path('work/ne228-reverse/negative.log').open('w') as log:code=subprocess.run([env['GODOT'],'--headless','--path','.', 'res://tests/smoke_test.tscn','--','--only=NpcSuite'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
finally:
 p.write_bytes(final)
 receipt={'base':'96f602e833037af5bc6d20c912d7c9924f722b74','same_final_tests':True,'exit_code':code,'before_sha256':hashlib.sha256(before).hexdigest(),'final_sha256':hashlib.sha256(final).hexdigest(),'restored_sha256':hashlib.sha256(p.read_bytes()).hexdigest()};assert receipt['final_sha256']==receipt['restored_sha256'];Path('work/ne228-reverse/negative.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt,flush=True)
