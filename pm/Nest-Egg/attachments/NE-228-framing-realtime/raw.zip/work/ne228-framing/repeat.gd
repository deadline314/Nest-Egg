extends Node
var checks := 0
var failures := 0
var repeats := 20
var pattern := PackedInt32Array([0, 0, 0, 0, 150, 0, 0, 0, 0, 0, 250, 0])
var frame := 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--repeat="):
			repeats = int(arg.trim_prefix("--repeat="))
	run.call_deferred()

func _process(_delta: float) -> void:
	var stall := pattern[frame % pattern.size()]
	frame += 1
	if stall > 0:
		OS.delay_msec(stall)

func run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var suite := UiScreensSuite.new(self)
	for i in repeats:
		print("REPEAT ", i)
		await ContextualUiChecks._radio_identity_after_authored_reading(suite)
	Sfx.stop_all()
	Music.stop(0)
	Ambience.stop_all(0)
	await get_tree().create_timer(0.3, true, false, true).timeout
	print("checks: ", checks, ", failures: ", failures)
	get_tree().quit(0 if failures == 0 else 1)

func _check(ok: bool, message: String) -> void:
	checks += 1
	print("PASS: " if ok else "FAIL: ", message)
	if not ok:
		failures += 1

func _end_level(level: Level) -> void:
	for action in [&"move_right", &"shoot", &"jump", &"aim_right", &"aim_left", &"block"]:
		Input.action_release(action)
	if is_instance_valid(level):
		get_tree().root.remove_child(level)
		level.free()
	get_tree().paused = false
	Engine.time_scale = 1
	await get_tree().process_frame
	await get_tree().process_frame
