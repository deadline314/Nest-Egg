extends Node2D

class TrailVisual extends PlayerVisual:
	var sample: Dictionary
	func _ready() -> void:
		set_process(false)
		set_physics_process(false)
		LightKit.mark_emissive(self)
	func _draw() -> void:
		_draw_trail(sample)

const CAPTURE := preload("res://tools/viewport_capture.gd")
var out := ""
var pixels: Array[Dictionary] = []
var visuals: Array[TrailVisual] = []

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out=arg.trim_prefix("--out=")
	if not out.is_absolute_path() or DirAccess.make_dir_recursive_absolute(out) != OK:
		get_tree().quit(2)
		return
	_render.call_deferred()

func _render() -> void:
	Settings.use_storage("user://thrust_draw_audit.cfg")
	RenderingServer.set_default_clear_color(Color.BLACK)
	var weapon := load("res://data/weapons/melee/melee_glaive.tres") as WeaponData
	var trail: Dictionary = MeleeData.set_of(weapon).attack("thrust")["trail"]
	for item: Array in [[Vector2(120,120), 0.0],[Vector2(490,120),PI],
			[Vector2(120,260),-PI/4.0],[Vector2(490,250),3.0*PI/4.0]]:
		var visual := TrailVisual.new()
		var angle: float = item[1]
		var dir := Vector2.RIGHT.rotated(angle)
		var facing := -1 if dir.x < 0.0 else 1
		visual.sample = {"age":float(trail.life)*0.4, "trail":trail,"facing":facing,"base":angle}
		visual.position = item[0]
		visual.scale = Vector2.ONE * 2.4
		add_child(visual)
		visuals.append(visual)
		var center := Vector2(facing*8.0,-visual.body_center_height())
		var tail := visual.to_global(center + dir * float(trail.radius) * 0.45)
		var tip := visual.to_global(center + dir * float(trail.radius))
		pixels.append({"tail":[tail.x,tail.y],"tip":[tip.x,tip.y],"angle":angle})
	for mode in ["normal","reduced"]:
		Settings.set_reduce_flashes(mode=="reduced")
		for visual in visuals:
			visual.queue_redraw()
		for tick in 3:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var raw := get_viewport().get_texture().get_image()
		var buffer := FileAccess.open(out.path_join(mode+".bin"), FileAccess.WRITE)
		if buffer == null:
			get_tree().quit(2)
			return
		buffer.store_buffer(raw.get_data())
		buffer.close()
		if CAPTURE.image(get_viewport()).save_png(out.path_join(mode+".png")) != OK:
			get_tree().quit(2)
			return
	var receipt := {"view_width":get_viewport().get_visible_rect().size.x,
		"view_height":get_viewport().get_visible_rect().size.y,
		"adapter":RenderingServer.get_video_adapter_name(),"samples":pixels}
	var output := FileAccess.open(out.path_join("points.json"),FileAccess.WRITE)
	if output == null:
		get_tree().quit(2)
		return
	output.store_string(JSON.stringify(receipt,"  ")+"\n")
	output.close()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit()


