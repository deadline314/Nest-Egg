
from pathlib import Path
import json
import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent
def read(path):
    return json.loads(path.read_bytes())

old,new=(read(base/mode/'current-settings.json') for mode in ('stock','final'))
assert old==new and new['failures']==0 and len(new['weapons'])==5
for mode in ('stock','final'):
    assert 'ERROR:' not in (base/mode/'raw.log').read_text(encoding='utf-8-sig')
assert 'ERROR:' not in (base/'isolated-raw.log').read_text(encoding='utf-8-sig')
points=read(base/'isolated-raw/points.json')
assert '9070 XT' in points['adapter'] and len(points['samples'])==4
images=[np.asarray(Image.open(base/'isolated-raw'/f'{mode}.png').convert('RGB')) for mode in ('normal','reduced')]
height,width,_=images[0].shape
scale=np.array([width/points['view_width'],height/points['view_height']])
surfaces=[]
for mode in ('normal','reduced'):
    blob=(base/'isolated-raw'/f'{mode}.bin').read_bytes()
    assert len(blob) in (width*height*6,width*height*8,width*height*16)
    dtype='<f2' if len(blob) in (width*height*6,width*height*8) else '<f4'
    surfaces.append(np.frombuffer(blob,dtype=dtype).reshape(height,width,-1)[:,:,:3].astype(np.float32))
normal,reduced=surfaces
positions=np.argwhere(np.max(normal,axis=2)>0.01)
assert np.array_equal(np.max(normal,axis=2)>0.01,np.max(reduced,axis=2)>0.01)
samples=[]
for sample in points['samples']:
    tail,tip=np.asarray([sample['tail'],sample['tip']])*scale
    axis=tip-tail
    length=np.linalg.norm(axis)
    axis/=length
    offset=positions[:,::-1]+0.5-tail
    along=offset@axis
    across=offset@np.array([-axis[1],axis[0]])
    accepted=(along>=-1)&(along<=length+1)&(np.abs(across)<=20)
    weights=along[accepted]/length
    spans=across[accepted]
    def cross_section(a,b):
        values=spans[(weights>=a)&(weights<=b)]
        assert values.size>0
        return float(values.max()-values.min()+1)
    root,crown,end=(cross_section(a,b) for a,b in ((.06,.16),(.60,.69),(.87,.96)))
    y,x=positions[accepted].T
    normal_light=float(normal[y,x].mean())
    reduced_light=float(reduced[y,x].mean())
    ratio=reduced_light/normal_light
    assert crown>10 and root<crown*0.55 and end<crown*0.55
    assert .23<ratio<.27
    samples.append({'angle':sample['angle'],'widths':[root,crown,end],'linear_brightness_ratio':ratio,
                    'pixels':int(accepted.sum())})
crop=(647,358,871,380)
near_white={}
for version in ('stock','final'):
    with Image.open(base/version/'glaive-both.png') as page:
        detail=np.asarray(page.crop(crop).convert('RGB'))
        near_white[version]=int(np.count_nonzero(np.all(detail>=235,axis=2)))
assert near_white['stock']>1000 and near_white['final']<near_white['stock']*.3,near_white
out={'samples':samples,'near_white':near_white,'settings_cases_equal':20}
(base/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))


