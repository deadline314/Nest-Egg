from pathlib import Path
import json

base = Path(__file__).resolve().parent
pairs = {}
for lens, left, right in (("0.0", "ground-rifle-standard", "candidate-final-clearance"),
                          ("3.4", "ground-rifle-v2", "candidate-final-clearance")):
    for side in (-1, 1):
        name = f"kneel-{side}-{lens}"
        old, revised = [
            json.loads((base/label/name/"motion.json").read_bytes())["rows"] for label in (left,right)
        ]
        assert len(old) == len(revised) == 4
        rows = {}
        for a,b in zip(old,revised,strict=True):
            for key in ("label","root","direction","crouching","ground","spent","floor_y"):
                assert a[key] == b[key], (name, a["label"], key, a[key], b[key])
            assert a["muzzle"] == a["first"]["position"] and b["muzzle"] == b["first"]["position"]
            assert a["ground"] and b["ground"] and a["spent"] == b["spent"] == 1
            if a["label"] == "rifle_down":
                assert a["depth"] > 3.0 and b["depth"] < -2.0, (name, a["depth"], b["depth"])
                assert abs(a["muzzle"][0] - b["muzzle"][0]) < 0.001
                assert a["expired"] and b["expired"]
                assert a["expired"][0]["position"] == a["muzzle"]
                assert 1.8 < b["floor_y"] - b["expired"][0]["position"][1] < 2.3
            else:
                for key in ("muzzle","near_hand","far_hand","depth"):
                    assert a[key] == b[key], (name,b["label"],key,a[key],b[key])
            rows[b["label"]] = {
                "above_ground_before": -a["depth"], "above_ground_after": -b["depth"],
                "rounds_spent": b["spent"], "spawn_matches_muzzle": True,
                "impact_above_ground_before": [a["floor_y"]-value["position"][1] for value in a["expired"]],
                "impact_above_ground_after": [b["floor_y"]-value["position"][1] for value in b["expired"]],
            }
        pairs[name] = rows
result = {'comparisons': pairs, 'matched_live_shots':sum(map(len,pairs.values()))}
(base/"paired-results.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result),flush=True)
