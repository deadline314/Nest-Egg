from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

scope=Path(__file__).resolve().parent
fixture=scope.parent/'ne218-baseline-20261117'
experiment=scope/sys.argv[1]
native='native' in sys.argv[2:]
experiment.mkdir()
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','TEMP','TMP','TMPDIR'):
    folder=experiment/key
    folder.mkdir()
    env[key]=str(folder)
paths=['ui/inventory/card_list_page.gd','ui/inventory/detail_panel.gd',
       'ui/inventory/inventory_screen.gd','data/shops/ch1_pawn.tres','data/player/player_tuning.tres']
source={p:sha256((fixture/p).read_bytes()).hexdigest() for p in paths}
argv=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(fixture)]
if native:
    argv=[sys.executable,'-B',str(fixture/'tools/comfyui/gpu_lock.py'),'--',*argv,
          '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720']
else:
    argv+=['--headless']
argv+=['--max-fps','120','--quit-after','2400',str(scope/'observe.tscn'),'--','--out='+str(experiment)]
(experiment/'command.json').write_text(json.dumps({'argv':argv,'source':source},indent=2)+'\n')
with (experiment/'engine.log').open('wb') as f:
    proc=subprocess.run(argv,env=env,cwd=fixture,stdout=f,stderr=subprocess.STDOUT,timeout=100)
log=(experiment/'engine.log').read_text(encoding='utf-8')
if proc.returncode!=0 or re.search(r'^(?:SCRIPT )?ERROR:|^FAIL',log,re.M):
    print(log[-3000:])
    sys.exit(1)
assert source=={p:sha256((fixture/p).read_bytes()).hexdigest() for p in paths}
rows=json.loads((experiment/'hints.json').read_bytes())
assert [r['name'] for r in rows]==['insufficient','capacity','available']
for row in rows:
    print(row['name'],row['footer'],row['action_hint'],row['fits'])
