from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json
import re

root=Path.cwd()
base=Path(__file__).resolve().parent
def read(path):
    return json.loads((base/path).read_bytes())
def text(path):
    return (base/path).read_text(encoding='utf-8-sig')

stock=read('stock-native/hints.json')
fixed=read('candidate-native/hints.json')
for before,after in zip(stock,fixed,strict=True):
    assert before['name']==after['name'] and before['footer']==before['description']
    assert after['footer']==(after['description'] if after['action_enabled'] else after['action_hint'])
    assert before['fits'] and after['fits']
    assert {k:v for k,v in before.items() if k!='footer'}=={k:v for k,v in after.items() if k!='footer'}
assert text('focus-stock.log').count('FAIL:')==2
assert read('official-release/verification.json')=={'exit':0,'errors':[],'source_held':True}
official=text('official-release/raw.log')
suites=int(re.search(r'Running (\d+) groups',official)[1])
check=re.search(r'checks:\s*(\d+), new failures: 0, known failures [^:]*: 0.*wall time (\d+) s',official)
assert check and suites==11
checks,seconds=int(check[1]),int(check[2])
ticket=next((root/'pm/Nest-Egg').glob('[[]NE-228]*')).relative_to(root)
archive=Path('pm/Nest-Egg/attachments/NE-228-disabled-action-hints-2026-11-21/evidence.zip')
photos={'shop-insufficient-before':'stock-native/insufficient.png',
        'shop-insufficient-after':'candidate-native/insufficient.png',
        'shop-carry-limit':'candidate-native/capacity.png'}
images={key:Path(f'pm/Nest-Egg/images/NE-228-{key}-20261121.png') for key in photos}
prev=(root/ticket).read_text(encoding='utf-8')
assert '# Commit-53（' in prev and '# Commit-54（' not in prev
assert not (root/archive.parent).exists() and all(not (root/file).exists() for file in images.values())
raw=[base/path for path in ('adopt.py','bundle.py','observe.gd','observe.tscn','run.py','focus-stock.log',
                            'official-release/command.json','official-release/raw.log','official-release/verification.json')]
for folder in ('stock-native','candidate-native','official-release/shards'):
    raw.extend(file for file in sorted((base/folder).iterdir()) if file.is_file())
(root/archive).parent.mkdir()
with ZipFile(root/archive,'x',compression=ZIP_DEFLATED) as bundle:
    for file in raw:
        bundle.write(file,file.relative_to(base).as_posix())
with ZipFile(root/archive) as bundle:
    assert bundle.testzip() is None
for name,path in images.items():
    (root/path).write_bytes((base/photos[name]).read_bytes())
section=f'''
---

# Commit-54（選到無法操作的項目時顯示原因）

## 內文

補給、背包及改裝選到不能操作的項目時，底部直接顯示原按鈕的短說明，例如還差多少信用點或已達攜帶上限。可以操作的項目仍顯示用途，價格留在動作按鈕。

### 測試結果

- RX 9070 XT Forward+，1280×720、120% 文字。實際當舖介面比對信用點不足、醫療針拿滿、切換到可買的護盾電池。三種說明都放得下，原按鈕與 Hover 同步。
- 新回歸在舊程式重現兩種缺少提示的狀態。修後受影響回歸 {suites} 套、{checks:,} 項全過，{seconds} 秒。

[原生介面、提示內容與測試紀錄](attachments/NE-228-disabled-action-hints-2026-11-21/evidence.zip)

![原版信用點不足，只顯示醫療針用途](images/NE-228-shop-insufficient-before-20261121.png)
![目前選取即顯示還差 60 信用點](images/NE-228-shop-insufficient-after-20261121.png)
![已拿滿醫療針，顯示實際上限](images/NE-228-shop-carry-limit-20261121.png)
'''
(root/ticket).write_text(prev.rstrip()+'\n\n\n'+section.lstrip('\n'),encoding='utf-8')
paths=[*map(Path,read('runtime.json')),Path('design/20-campaign-experience/HUD_GUIDANCE.md'),
       ticket,archive,*images.values()]
(base/'delivery.json').write_text(json.dumps([path.as_posix() for path in paths],ensure_ascii=False,indent=2)+'\n',
                                  encoding='utf-8')
print(len(raw),(root/archive).stat().st_size)
