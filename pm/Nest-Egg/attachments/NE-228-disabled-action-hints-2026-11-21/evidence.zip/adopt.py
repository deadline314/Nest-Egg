from pathlib import Path
from hashlib import sha256
import json
import subprocess

base = Path(__file__).resolve().parent
root = Path.cwd()
previous = base.parent / 'evidence-20261121-st19-towel-contact'
game = base.parent / 'ne218-baseline-20261117'
manifest = json.loads((previous/'published-source.json').read_bytes())
parent = json.loads((previous/'publish/result.json').read_bytes())['commit']
git = lambda path,*args: subprocess.check_output(['git',*args],cwd=path)
sha = lambda path: sha256(path.read_bytes()).hexdigest()
paths = ['ui/inventory/card_list_page.gd','tests/suite/test_supply.gd']
assert git(root,'rev-parse','HEAD').decode().strip() == git(game,'rev-parse','HEAD').decode().strip() == parent
assert all(sha(game/path) == expected for path,expected in manifest.items() if path not in paths)
for path in paths:
    new = (root/path).read_bytes()
    digest = sha256(new).hexdigest()
    assert digest != manifest[path] and sha(game/path) in {manifest[path],digest}
    (game/path).write_bytes(new)
    manifest[path] = digest
assert all(sha(game/path) == expected for path,expected in manifest.items())
(base/'baseline.txt').write_text(parent+'\n',encoding='utf-8')
(base/'runtime.json').write_text(json.dumps(paths,indent=2)+'\n',encoding='utf-8')
(base/'source.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(len(manifest),'exact files',parent,flush=True)




