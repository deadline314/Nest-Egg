extends Node2D

const SHOP := preload("res://data/shops/ch1_pawn.tres")
const CAPTURE := preload("res://tools/viewport_capture.gd")

var output := ""
var records: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			output = arg.trim_prefix("--out=")
	if not output.is_absolute_path():
		get_tree().quit(2)
		return
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	process_mode = Node.PROCESS_MODE_ALWAYS
	_run.call_deferred()


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Settings.set_ui_text_scale(1.2)
	var player := Player.new()
	player.configure(preload("res://data/player/player_tuning.tres"),6,{})
	player.position = Vector2(500,260)
	add_child(player)
	player.set_physics_process(false)
	Progression.reset_run()
	var shop := ShopScreen.new()
	shop.configure_shop(player,SHOP)
	add_child(shop)
	shop.open()
	for _frame in 20:
		await get_tree().process_frame
	if not shop.is_open():
		print("FAIL shop did not open")
		get_tree().quit(1)
		return
	var page := shop._pages[0] as ShopPage
	await _capture(shop,page,"insufficient")
	Progression.add_credits(1000)
	page.refresh()
	var med := SHOP.stock[0]
	for _i in med.max_carry:
		player.consumables.add(med)
	page.refresh()
	await _capture(shop,page,"capacity")
	var down := InputEventAction.new()
	down.action = &"ui_down"
	down.pressed = true
	shop._input(down)
	await _capture(shop,page,"available")
	var file := FileAccess.open(output.path_join("hints.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(records,"  ") + "\n")
	file.close()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)


func _capture(shop: ShopScreen, page: ShopPage, name: String) -> void:
	for _frame in 5:
		await get_tree().process_frame
	var entry := page._entries[page._selected]
	var label := shop._hint_label
	records.append({"name":name,"id":str(entry.id),"description":entry.hint,
		"action_hint":entry.action_hint,"action_enabled":entry.action_enabled,"footer":label.text,
		"button":page._detail._action.text,"tooltip":page._detail._action.tooltip_text,
		"fits":label.get_theme_font("font").get_string_size(label.text,HORIZONTAL_ALIGNMENT_LEFT,-1,label.get_theme_font_size("font_size")).x <= label.size.x})
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		CAPTURE.image(get_viewport()).save_png(output.path_join(name+".png"))


