extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
const LANGUAGES := {
	"zh": ["消耗品", "醫療針", "護盾電池", "回復 2 格生命。", "護盾立即充滿", "使用", "生命已滿"],
	"ja": ["消耗品", "回復注射", "シールドセル", "ライフを2回復", "シールド全回復", "使う", "ライフは満タン"],
	"en": ["Supplies", "Med injector", "Shield cell", "Restores 2 health", "Refills shield", "Use", "Health is full"],
}
var _image_path := ""


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for option in OS.get_cmdline_user_args():
		if option.begins_with("--image="):
			_image_path = option.trim_prefix("--image=")
	Settings.use_storage("user://consumables_locale.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	for language: String in LANGUAGES:
		await _observe(language)
	await _finish()


func _observe(language: String) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	for scene in Story.scene_ids():
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	await _frames(12)
	var player := level.player
	var med := ConsumableBag.find(&"med_injector")
	var cell := ConsumableBag.find(&"shield_cell")
	_check(player.consumables.add(med) and player.consumables.add(cell), language + ": original inventory receives both resources")
	var expected: Array = LANGUAGES[language]
	_check(level.hud._items_label.text.contains(expected[1] + " ×1") and level.hud._items_label.text.contains(expected[2] + " ×1"),
		language + ": HUD uses localized names")
	_check(level.hud._items_label.tooltip_text.contains(InputBindings.primary_label(&"use_item")), language + ": HUD tooltip keeps the active binding")

	var inventory := level._inventory
	await _tap(&"inventory")
	_check(inventory.is_open(), language + ": the real inventory input opens the screen")
	inventory.select_tab(inventory.page_index(ConsumablesPage))
	var page := inventory._pages[inventory.page_index(ConsumablesPage)] as ConsumablesPage
	var med_row := page._entries[0]
	var cell_row := page._entries[1]
	_check(page.tab_title() == expected[0] and med_row.id == med.id and cell_row.id == cell.id, language + ": page title and item order")
	_check(med_row.title == expected[1] and cell_row.title == expected[2], language + ": actual cards use the same names as the HUD")
	_check(med_row.detail_body.contains(expected[3]) and cell_row.detail_body.contains(expected[4]), language + ": actual effects use the current language")
	_check(med_row.action_label == expected[5] and med_row.action_hint.contains(expected[1]), language + ": the confirmation and tooltip explain what will be used")
	_check(med_row.badge == InputBindings.primary_label(&"use_item"), language + ": the shortcut matches the HUD")
	page._select(0)
	await get_tree().process_frame
	await get_tree().process_frame
	var viewport := inventory._frame.get_global_rect()
	_check(inventory._tab_buttons.all(func(button: Button) -> bool: return viewport.grow(0.5).encloses(button.get_global_rect())),
		language + ": every tab fits at 120 percent text")
	if language == "en":
		var details := page._detail
		_check(details._scroll.get_global_rect().grow(1.0).encloses(details._body.get_global_rect()),
			language + ": the full translated effect fits without scrolling")

	if _image_path.is_absolute_path() and language == "en":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_image_path) == OK, "native inventory screenshot")

	# A normal confirmation must not consume a med when it cannot heal.
	page._select(0)
	await _tap(&"ui_accept")
	_check(inventory._hint_label.text.contains(expected[6]) and player.consumables.count(med.id) == 1, language + ": the full-health warning is localized and preserves the item")
	var damage := DamageInfo.create(3, Combat.Team.ENEMY, &"probe")
	damage.ignore_invulnerability = true
	player.health.take_damage(damage)
	var before := player.health.current
	await _tap(&"ui_accept")
	_check(player.health.current == before + med.heal_amount and player.consumables.count(med.id) == 0, language + ": confirmation still heals and consumes exactly one item")
	_check(not page._entries[0].action_enabled, language + ": exhausted item remains disabled")
	print("CONSUMABLE_LOCALE ", language, " | ", med_row.title, " | ", med_row.detail_body, " | ", med_row.action_hint)
	inventory.close()
	level.queue_free()
	for frames in 4:
		await get_tree().process_frame


func _tap(action: StringName) -> void:
	var press := InputEventAction.new()
	press.action = action
	press.pressed = true
	Input.parse_input_event(press)
	Input.flush_buffered_events()
	await get_tree().process_frame
	var release := press.duplicate() as InputEventAction
	release.pressed = false
	Input.parse_input_event(release)
	Input.flush_buffered_events()
	await get_tree().process_frame
