from pathlib import Path
from hashlib import sha256
import json, subprocess, sys

p = Path(__file__).resolve().parent
shared = p.parent / "ne218-baseline-20261117"
original = p / "route-seeded.py"
script = original.read_text(encoding="utf-8")
needle = "(p/'observer.gd').write_text(source,encoding='utf-8')"
script = script.replace(needle, ("""
marker = '\\t\\tvar camera := level.camera\\n'
assert source.count(marker)==1
capture = '\\t\\tif absi(frame - 846) <= 8 and player.global_position.distance_to(Vector2(810.7169, 783.9565)) < 0.02 and player.velocity.x < -120.0:\\n'
capture += '\\t\\t\\tRenderingServer.frame_post_draw.connect(_capture_takeoff, CONNECT_ONE_SHOT)\\n'
source = source.replace(marker, capture + marker)
source += '\\n\\nfunc _capture_takeoff() -> void:\\n'
source += '\\tvar image := preload("res://tools/viewport_capture.gd").image(_level.get_viewport())\\n'
source += '\\tvar path := str(route.get("_out")).path_join("warehouse-takeoff.png")\\n'
source += '\\tif image.save_png(path) != OK:\\n'
source += '\\t\\tpush_error("cannot write warehouse takeoff: " + path)\\n'
""" + needle))
assert script != original.read_text(encoding="utf-8")
guard = "assert result.returncode==0 and not errors"
assert script.count(guard)==1
script = script.replace(guard, "assert result.returncode==1 and len(errors)==1 and errors[0].startswith('FAIL NE97 defeated the authored Watchdog')")
(p/'route-frame.py').write_text(script,encoding='utf-8')

source=json.loads((p/'source.json').read_bytes())
paths=[path for path in json.loads((p/'runtime.json').read_bytes()) if not path.startswith('tests/')]
sha=lambda file:sha256(file.read_bytes()).hexdigest()
assert all(sha(shared/file)==digest for file,digest in source.items())
saved={file:(shared/file).read_bytes() for file in paths}
try:
    for name in ["original", "adjusted"]:
        for file in paths:
            changed = (p/('original-'+Path(file).name)).read_bytes() if name=="original" else saved[file]
            (shared/file).write_bytes(changed)
        subprocess.run([sys.executable,'-X','utf8',str(p/'route-frame.py'),'photo-full-'+name],check=True)
        out=p/('route-photo-full-'+name)
        assert (out/'warehouse-takeoff.png').is_file(), out
        actual=json.loads((out/'camera-observations.json').read_bytes())['landings']
        expected=json.loads((p/('route-seeded-'+name)/'camera-observations.json').read_bytes())['landings']
        assert len(actual)>=5, actual
        for key in ["from","landing","visible_before_takeoff"]:
            assert actual[4][key]==expected[4][key], (actual[4],expected[4])
        assert all(abs(a-b)<0.15 for a,b in zip(actual[4]["pixel_at_takeoff"],expected[4]["pixel_at_takeoff"]))
finally:
    for file in paths:
        (shared/file).write_bytes(saved[file])
    assert all(sha(shared/file)==digest for file,digest in source.items())
