from pathlib import Path
from hashlib import sha256
import json,os,subprocess,sys
p=Path(__file__).resolve().parent
root=p.parent/'ne218-baseline-20261117'
source=json.loads((p/'source.json').read_bytes())
paths=json.loads((p/'runtime.json').read_bytes())
sha=lambda path:sha256(path.read_bytes()).hexdigest()
assert all(sha(root/file)==digest for file,digest in source.items())
saved={file:(root/file).read_bytes() for file in paths}
script=(p/'route.py').read_text(encoding='utf-8')
marker="(p/'warehouse-route.gd').write_text"
assert script.count(marker)==1
script=script.replace(marker,"route=route.replace('func _run() -> void:\\n','func _run() -> void:\\n\\tseed(223256)\\n',1)\n"+marker)
script=script.replace("'--camera-projectile-audit','--camera-settle']","'--camera-projectile-audit','--camera-settle','--defensive-watchdog']")
(p/'route-seeded.py').write_text(script,encoding='utf-8')
results={}
try:
    for tag in ['original','adjusted']:
        for file in paths:
            data=(p/('original-'+Path(file).name)).read_bytes() if tag=='original' else saved[file]
            (root/file).write_bytes(data)
        r=subprocess.run([sys.executable,'-X','utf8',str(p/'route-seeded.py'),'seeded-'+tag])
        results[tag]=r.returncode
finally:
    for file in paths:
        (root/file).write_bytes(saved[file])
    assert all(sha(root/file)==digest for file,digest in source.items())
(p/'seeded-pair.json').write_text(json.dumps(results)+"\n")
print(results,flush=True)

