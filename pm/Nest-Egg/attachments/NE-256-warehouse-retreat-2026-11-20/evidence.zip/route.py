from pathlib import Path
from hashlib import sha256
from shutil import copyfile
import json,os,re,subprocess,sys
p=Path(__file__).resolve().parent
root=Path.cwd()
prior=root/'work/ne97-campaign-route-20261119'
shared=p.parent/'ne218-baseline-20261117'
baseline=prior/'native-blockade-v3'/'save'
expected='1908995cac2922a1480cef223532c4ed75cca394b78dce0fe6bbd5bc8105d89c'
assert sha256((baseline/'slot.json').read_bytes()).hexdigest()==expected
source=(root/'work/ne256-live-route-camera-20261119/observer.gd').read_text(encoding='utf-8')
a='"jump": _takeoff["jump"], "air_frames": frame - int(_takeoff["frame"])}'
assert source.count(a)==1
source=source.replace(a,'"jump": _takeoff["jump"], "air_frames": frame - int(_takeoff["frame"]), "camera_state": _takeoff["state"]}')
a='\t\t_last_ground = {"feet": player.global_position, "camera": transform, "frame": frame}'
assert source.count(a)==1
source=source.replace(a,'''		var camera := level.camera
		var view_left := (transform.affine_inverse() * Vector2(0,screen.size.y*0.5)).x
		var view_right := (transform.affine_inverse() * Vector2(screen.size.x,screen.size.y*0.5)).x
		var camera_state := {"rx": player.aim_dir.x,"facing":player.facing,"floor_velocity":player.velocity.x,
			"last_damage":str(player.health.current),"moving_left":Input.is_action_pressed(&"move_left"),
			"shooting":Input.is_action_pressed(&"shoot"),"center":str(camera.get_screen_center_position()),
			"target":str(camera.global_position),"kick":str(camera._kick),"offset":str(camera.offset),
			"view_x":[view_left,view_right],"offsets":[camera._look,camera._aim_look.x],"zoom":camera.zoom.x,
			"screen_rotation":camera.rotation,"frame":frame}
		_last_ground = {"feet": player.global_position, "camera": transform, "frame": frame, "state":camera_state}''')
(p/'observer.gd').write_text(source,encoding='utf-8')
route=(prior/'combat-route.gd').read_text(encoding='utf-8').replace(
    "C:/Users/stanl/Github/Nest-Egg/work/ne256-live-route-camera-20261119/observer.gd",(p/'observer.gd').as_posix())
(p/'warehouse-route.gd').write_text(route,encoding='utf-8')
scene=(prior/'combat-route.tscn').read_text(encoding='utf-8').replace(
    "C:/Users/stanl/Github/Nest-Egg/work/ne97-campaign-route-20261119/combat-route.gd",(p/'warehouse-route.gd').as_posix())
(p/'warehouse-route.tscn').write_text(scene,encoding='utf-8')
profile=sys.argv[1]
out=p/('route-'+profile)
out.mkdir()
save=out/'save'
save.mkdir()
for item in baseline.glob('slot.json*'): copyfile(item,save/item.name)
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    (out/key).mkdir()
    env[key]=str(out/key)
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
cmd=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',engine,'--path',str(shared),
     '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720',
     '--fixed-fps','60','--quit-after','18000',str(p/'warehouse-route.tscn'),'--','--from-save','--warehouse',
     '--out='+str(out),'--save-dir='+str(save),'--camera-audit','--camera-projectile-audit','--camera-settle']
if profile=='wide': cmd.append('--camera-wide')
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'engine.log').open('wb') as log:
    result=subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=250)
raw=(out/'engine.log').read_text(encoding='utf-8',errors='replace')
errors=[ln for ln in raw.splitlines() if re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|^FAIL |leaked at exit',ln)]
receipt={'source_save_sha256':expected,'exit':result.returncode,'errors':errors}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(profile,receipt,raw[-650:],flush=True)
assert result.returncode==0 and not errors

