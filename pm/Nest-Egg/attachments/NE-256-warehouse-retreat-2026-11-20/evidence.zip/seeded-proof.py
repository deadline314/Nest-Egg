from pathlib import Path
from hashlib import sha256
import json

p=Path(__file__).resolve().parent
def rows(case):
    return json.loads((p/f'route-{case}'/'camera-observations.json').read_bytes())

old, new = rows('seeded-original'), rows('seeded-adjusted')
def behavior(data):
    return [{k:r[k] for k in ['area','air_frames','jump','from','landing']} for r in data['landings']]
assert behavior(old)==behavior(new)
assert old['damage']==new['damage']
old_l,new_l=old['landings'],new['landings']
equivalent=[]
for i,(a,b) in enumerate(zip(old_l,new_l)):
    assert a['camera_state']['frame']==b['camera_state']['frame']
    equivalent.append({'i':i,'frame':a['camera_state']['frame'],'from':a['from'],'landing':a['landing'],
                       'old':a['pixel_at_takeoff'],'new':b['pixel_at_takeoff'],
                       'visible_old':a['visible_before_takeoff'],'visible_new':b['visible_before_takeoff']})
proof={'before_covered':sum(r['visible_old'] for r in equivalent),'after_covered':sum(r['visible_new'] for r in equivalent),
       'identical_damage':old['damage'],'landings':equivalent}
for line in equivalent:
    print(line)
print('identical damage:',len(old['damage']))
(p/'seeded-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
