import json
from pathlib import Path
import sys

import numpy as np
from PIL import Image
from scipy import ndimage

base=Path(__file__).resolve().parent
root=Path.cwd()
trace=base/sys.argv[1]
samples=json.loads((trace/'frames.json').read_bytes())
cache={}
rows=[]

def source_coordinates(part, point):
    matrix=np.asarray(part['to_cell'])
    dst=np.linalg.solve(matrix[:,:2],point-matrix[:,2])
    if 'rect_origin' in part:
        return dst-np.asarray(part['rect_origin'])
    vertices=np.asarray(part['vertices'])
    uvs=np.asarray(part['uv'])
    for t in part['triangles']:
        v=vertices[t]
        edge=(v[1:]-v[0]).T
        if abs(np.linalg.det(edge)) < 1e-10:
            continue
        a,b=np.linalg.solve(edge,dst-v[0])
        if min(a,b,1-a-b) >= -0.01:
            return uvs[t[0]] + a*(uvs[t[1]]-uvs[t[0]]) + b*(uvs[t[2]]-uvs[t[0]])
    return None

for group in samples:
    first=group['samples'][-1]
    frame=np.asarray(Image.open(trace/first['file']).convert('RGBA'))
    for cell in group['cells']:
        if cell['joint']!=sys.argv[2]:
            continue
        x,y,w,h=cell['rect']
        cx,cy=w//2,h//2
        radius=cell['radius']
        slab=frame[y+cy-radius:y+cy+radius,x+cx-radius:x+cx+radius,3]
        solid=slab>=128
        points=np.argwhere(ndimage.binary_fill_holes(solid,structure=np.ones((3,3)))&~solid)
        for yy,xx in points:
            pos=np.array((cx-radius+xx+0.5,cy-radius+yy+0.5))
            mapping={}
            for part in cell['geometry_sample']:
                uv=source_coordinates(part,pos)
                if uv is None:
                    continue
                name=part['texture'].removeprefix('res://')
                asset = root/name if name else (base/'torso-trial.png' if part['part']=='torso' else None)
                if asset is None:
                    continue
                if name not in cache:
                    cache[name]=np.asarray(Image.open(asset).convert('RGBA'))
                raw=cache[name]
                bx,by=np.floor(uv).astype(int)
                if 0<=bx<raw.shape[1] and 0<=by<raw.shape[0]:
                    alpha=int(raw[by,bx,3])
                else:
                    alpha=-1
                mapping[part['part']]=[float(uv[0]),float(uv[1]),alpha]
            rows.append({'pose':group['pose'],'zoom':group['zoom'],'facing':cell['facing'],
                         'cell':pos.tolist(),'render_alpha':int(slab[yy,xx]),'source':mapping})
(base/(sys.argv[1]+'-source.json')).write_text(json.dumps(rows,indent=2)+'\n')
for row in rows[:3]:
    print(row)
print('total first-frame mapped holes',len(rows))





