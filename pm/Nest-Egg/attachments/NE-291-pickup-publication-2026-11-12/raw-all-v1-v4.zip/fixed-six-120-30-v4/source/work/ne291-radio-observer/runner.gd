extends "res://tests/smoke_test.gd"
const Observed := preload("res://work/ne291-radio-observer/suite.gd")
var _observations: Array[Dictionary] = []
var _out := ""
var _physics_hz := 60
var _process_cap := 60
var _process_signals := 0
var _physics_signals := 0
var _freeze_feed_after_hide := false
var _saw_visible_radio := false
var _freeze_applied := false
var _test_variant := "original"
var _test_source_sha := ""

func _run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
		elif arg.begins_with("--physics-hz="): _physics_hz = int(arg.trim_prefix("--physics-hz="))
		elif arg.begins_with("--process-cap="): _process_cap = int(arg.trim_prefix("--process-cap="))
		elif arg == "--freeze-feed-after-hide": _freeze_feed_after_hide = true
		elif arg.begins_with("--test-variant="): _test_variant = arg.trim_prefix("--test-variant=")
	if not _out.is_absolute_path() or _physics_hz not in [60,120,240] or _process_cap not in [30,60,240]:
		get_tree().quit(2)
		return
	_test_source_sha = FileAccess.get_sha256("res://tests/suite/test_combat_hud.gd")
	var expected := {"original":"5beca0f6f99d4735805f7d8d34f56a6eabd2591fd415a75c8a14d74b7bc260ad",
		"restore-post-process":"da63de606a9615e337a01ca32eebace606309dc7936fa4177a8a0135f1d8bf2b"}
	if not expected.has(_test_variant) or _test_source_sha != expected[_test_variant]:
		printerr("RADIO_OBSERVER test variant/source hash mismatch")
		get_tree().quit(2)
		return
	Engine.physics_ticks_per_second = _physics_hz
	Engine.max_fps = _process_cap
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	get_tree().process_frame.connect(_on_process_signal)
	get_tree().physics_frame.connect(_on_physics_signal)
	EventBus.radio_visibility_changed.connect(_on_radio_visibility)
	var suite := Observed.new(self)
	await suite._test_banner_kinds()
	var file := FileAccess.open(_out.path_join("observations.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"scope":"inherited assertion routine from the recorded test source; passive check/event observation with optional explicitly marked feed-processing fault injection; no runtime product edits",
		"test_variant":_test_variant,"test_source_sha256":_test_source_sha,
		"restore_wait":"two physics frames" if _test_variant=="original" else "post-process SceneTree zero timer",
		"metadata_correction":"V3 incorrectly described its test wait as unaltered/original. V3 actually changed one restore wait boundary. Its original source, report and logs are preserved; this V4 header states and verifies the actual variant.",
		"physics_hz":_physics_hz,"process_cap":_process_cap,"checks":_checks,"failures":_failures,
		"negative_freeze_feed":_freeze_feed_after_hide,"freeze_applied":_freeze_applied,
		"observations":_observations},"\t")+"\n")
	get_tree().process_frame.disconnect(_on_process_signal)
	get_tree().physics_frame.disconnect(_on_physics_signal)
	EventBus.radio_visibility_changed.disconnect(_on_radio_visibility)
	await _finish() # Original smoke runner's reporting and cleanup.

func _on_process_signal() -> void:
	_process_signals += 1
	_observations.append(_snapshot("process_frame_signal"))

func _on_physics_signal() -> void:
	_physics_signals += 1

func _on_radio_visibility() -> void:
	_observations.append(_snapshot("radio_visibility_changed"))
	if DialogueLayer.radio_visible(): _saw_visible_radio = true
	elif _freeze_feed_after_hide and _saw_visible_radio and not _freeze_applied:
		for node in get_tree().root.get_children():
			if node is Level and not node.is_queued_for_deletion() and is_instance_valid(node.hud):
				node.hud.pickup_feed.set_process(false)
				_freeze_applied = true
				_observations.append(_snapshot("fault_feed_processing_disabled"))
				break

func observe_assertion(condition: bool, message: String) -> void:
	var row := _snapshot("assertion")
	row["message"] = message
	row["condition"] = condition
	_observations.append(row)
	print("RADIO_ASSERT_OBSERVER ",JSON.stringify(row))

func _snapshot(event: String) -> Dictionary:
	var result := {"event":event,"time_usec":Time.get_ticks_usec(),
		"physics_frame":Engine.get_physics_frames(),"process_frame":Engine.get_process_frames(),
		"process_signals":_process_signals,"physics_signals":_physics_signals,
		"tree_paused":get_tree().paused,"radio_visible":DialogueLayer.radio_visible(),
		"actual_radio_root_visible":Story._layer._radio_root.is_visible_in_tree()}
	for node in get_tree().root.get_children():
		if not node is Level or node.is_queued_for_deletion() or not is_instance_valid(node.hud): continue
		var feed := (node as Level).hud.pickup_feed
		var rows: Array[Dictionary] = []
		for child in feed.get_children():
			if child is PickupFeed._Row:
				rows.append({"visible":child.visible,"left":child.left,"age":child.age,"base_text":child.base_text})
		result.merge({"level_instance":node.get_instance_id(),"feed_visible":feed.visible,
			"feed_visible_in_tree":feed.is_visible_in_tree(),"feed_processing":feed.is_processing(),
			"feed_can_process":feed.can_process(),"feed_lines":feed.lines(),"rows":rows})
		break
	return result
