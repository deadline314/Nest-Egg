from pathlib import Path
import hashlib,json,os,shutil,subprocess,time

repo=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne228-ui-shadow-20261112')
source=repo/'work/ne228-scope-20261112';work=root/'work/ne291-radio-observer'
for name,target in [('radio-observer-suite.gd','suite.gd'),('radio-observer-runner.gd','runner.gd'),('radio-observer.tscn','probe.tscn')]:
    shutil.copyfile(source/name,work/target)
sha=lambda b:hashlib.sha256(b).hexdigest()
path='tests/suite/test_combat_hud.gd'
original=(root/path).read_bytes()
published=subprocess.check_output(['git','show','faa5e4e:'+path],cwd=repo)
assert original==published
old=b'\tStory._layer.cancel_radio()\n\tawait frames(2)\n\tcheck(feed.visible'
new=b'\tStory._layer.cancel_radio()\n\t# Feed visibility is published by _process; physics ticks can finish before any UI update.\n\tawait runner.get_tree().create_timer(0.0, true, false, true).timeout\n\tcheck(feed.visible'
assert original.count(old)==1
candidate=original.replace(old,new,1)
assert candidate.replace(new,old,1)==original
own=source/'ne291-candidate';own.mkdir(exist_ok=True)
(own/'test_combat_hud-before.gd').write_bytes(original)
(own/'test_combat_hud-candidate.gd').write_bytes(candidate)
(own/'manifest.json').write_bytes((json.dumps(dict(path=path,base='faa5e4e84155e72509e325967d22787e6c74097e',before_sha256=sha(original),candidate_sha256=sha(candidate),reconstruct_original_exact=True),indent=2)+'\n').encode())
ui=json.loads((source/'final-candidate/manifest.json').read_bytes())['paths']
for entry in ui: assert sha((root/entry['path']).read_bytes())==entry['candidate_sha256']
related=['tests/suite/test_suite.gd','tests/smoke_test.gd','ui/pickup_feed.gd','ui/dialogue_layer.gd','autoload/story.gd','ui/hud.gd','tests/suite/test_props.gd','autoload/event_bus.gd']
paths=[path]+related+[e['path'] for e in ui]+['work/ne291-radio-observer/suite.gd','work/ne291-radio-observer/runner.gd','work/ne291-radio-observer/probe.tscn']
def hashes():return {p:sha((root/p).read_bytes()) for p in paths}
results=[]
try:
    (root/path).write_bytes(candidate)
    for physics,process,negative in [(60,60,False),(240,30,False),(120,30,False),(240,30,True)]:
        tag=f'fixed-six-{physics}-{process}'+('-frozen-negative' if negative else '')+'-v4'
        out=work/tag;out.mkdir(exist_ok=False);(out/'.gdignore').touch();before=hashes()
        for p in paths:
            target=out/'source'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/p).read_bytes())
        (out/'source-before.json').write_bytes((json.dumps(before,indent=2)+'\n').encode())
        command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--headless','res://work/ne291-radio-observer/probe.tscn','--','--out='+str(out),f'--physics-hz={physics}',f'--process-cap={process}','--test-variant=restore-post-process']
        if negative: command.append('--freeze-feed-after-hide')
        profile=out/'profile';env=dict(os.environ,APPDATA=str(profile),LOCALAPPDATA=str(profile/'local'),XDG_DATA_HOME=str(profile/'data'),PYTHONIOENCODING='utf-8')
        (out/'command.json').write_bytes((json.dumps(dict(command=command,profile=str(profile),negative_control=negative),indent=2)+'\n').encode())
        start=time.monotonic()
        with (out/'run.log').open('wb') as log:
            child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
            try: code=child.wait(timeout=180)
            except subprocess.TimeoutExpired:
                subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True);code=124
        after=hashes();receipt=dict(exit=code,seconds=time.monotonic()-start,sources_unchanged=before==after,source_after=after)
        (out/'exit.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode());results.append(dict(tag=tag,**receipt))
        print(json.dumps({k:v for k,v in results[-1].items() if k!='source_after'}),flush=True)
        assert before==after
        text=(out/'run.log').read_text(encoding='utf8',errors='replace')
        assert 'SCRIPT ERROR' not in text
        assert code==(1 if negative else 0),'unexpected original assertion result; preserve and stop'
finally:
    (root/path).write_bytes(original)
    restored=(root/path).read_bytes()==original and all(sha((root/e['path']).read_bytes())==e['candidate_sha256'] for e in ui)
    (work/'batch-fixed-v4.json').write_bytes((json.dumps(dict(results=results,original_test_restored=restored),indent=2)+'\n').encode())
    assert restored
