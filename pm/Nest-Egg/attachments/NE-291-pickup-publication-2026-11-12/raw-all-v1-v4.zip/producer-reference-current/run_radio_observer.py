from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time

repo=Path('C:/Users/stanl/Github/Nest-Egg')
root=Path('D:/NestEggVerification/ne228-ui-shadow-20261112')
source=repo/'work/ne228-scope-20261112'
version=sys.argv[1] if len(sys.argv)>1 else 'v2'
work=root/'work/ne291-radio-observer';work.mkdir(exist_ok=True);(work/'.gdignore').touch()
for name,target in [('radio-observer-suite.gd','suite.gd'),('radio-observer-runner.gd','runner.gd'),('radio-observer.tscn','probe.tscn')]:
    shutil.copyfile(source/name,work/target)
candidate=json.loads((source/'final-candidate/manifest.json').read_bytes())
owned=[entry['path'] for entry in candidate['paths']]
original={p:(root/p).read_bytes() for p in owned}
sha=lambda b:hashlib.sha256(b).hexdigest()
for e in candidate['paths']: assert sha(original[e['path']])==e['candidate_sha256']
related=['tests/suite/test_combat_hud.gd','tests/suite/test_suite.gd','tests/smoke_test.gd',
         'ui/pickup_feed.gd','ui/dialogue_layer.gd','autoload/story.gd','ui/hud.gd',
         'tests/suite/test_props.gd','autoload/event_bus.gd']
eligibility=[]
for path in related:
    published=subprocess.check_output(['git','show','faa5e4e:'+path],cwd=repo)
    actual=(root/path).read_bytes()
    eligibility.append(dict(path=path,published_sha256=sha(published),shadow_sha256=sha(actual),same_bytes=published==actual))
assert all(e['same_bytes'] for e in eligibility),'related source differs from published FAA; stop before cases'
(work/'source-eligibility.json').write_bytes((json.dumps(eligibility,indent=2)+'\n').encode())
paths=owned+related+['project.godot','work/ne291-radio-observer/suite.gd','work/ne291-radio-observer/runner.gd','work/ne291-radio-observer/probe.tscn']
def hashes(): return {p:sha((root/p).read_bytes()) for p in paths}
results=[]
try:
    for phase in ['baseline','candidate']:
        for path in owned:
            (root/path).write_bytes((source/'final-candidate'/('base' if phase=='baseline' else 'candidate')/path).read_bytes())
        for physics,process in [(60,60),(240,30),(120,30)]:
            tag=f'{phase}-{physics}-{process}-{version}'
            out=work/tag;out.mkdir(exist_ok=False);(out/'.gdignore').touch()
            before=hashes()
            for path in paths:
                target=out/'source'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/path).read_bytes())
            (out/'source-before.json').write_bytes((json.dumps(before,indent=2)+'\n').encode())
            command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--headless',
                     'res://work/ne291-radio-observer/probe.tscn','--','--out='+str(out),f'--physics-hz={physics}',f'--process-cap={process}']
            profile=out/'profile'
            env=dict(os.environ,APPDATA=str(profile),LOCALAPPDATA=str(profile/'local'),XDG_DATA_HOME=str(profile/'data'),PYTHONIOENCODING='utf-8')
            (out/'command.json').write_bytes((json.dumps(dict(command=command,phase=phase,profile=str(profile),scope='headless functional observer; no GPU/performance claim'),indent=2)+'\n').encode())
            start=time.monotonic()
            with (out/'run.log').open('wb') as log:
                child=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
                try: code=child.wait(timeout=180)
                except subprocess.TimeoutExpired:
                    subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],capture_output=True);code=124
            after=hashes()
            receipt=dict(exit=code,seconds=time.monotonic()-start,source_after=after,sources_unchanged=before==after)
            (out/'exit.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
            results.append(dict(tag=tag,**receipt))
            print(json.dumps({k:v for k,v in results[-1].items() if k!='source_after'}),flush=True)
            assert before==after
            if code not in [0,1]: raise RuntimeError('unexpected engine result; preserve and stop')
            text=(out/'run.log').read_text(encoding='utf8',errors='replace')
            if 'SCRIPT ERROR' in text: raise RuntimeError('tool/script error; preserve and stop')
finally:
    for path,data in original.items(): (root/path).write_bytes(data)
    restored=all((root/path).read_bytes()==data for path,data in original.items())
    data=(json.dumps(dict(results=results,related_sources=eligibility,owned_six_restored=restored),indent=2)+'\n').encode()
    (work/('batch-'+version+'.json')).write_bytes(data)
    (work/'batch.json').write_bytes(data)
    assert restored
