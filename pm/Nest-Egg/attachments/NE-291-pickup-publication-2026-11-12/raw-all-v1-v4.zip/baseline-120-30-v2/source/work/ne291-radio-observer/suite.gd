extends "res://tests/suite/test_combat_hud.gd"
## Only observes the inherited assertions; inputs, waits and values stay original.

func check(condition: bool, message: String) -> void:
	runner.observe_assertion(condition, message)
	super.check(condition, message)
