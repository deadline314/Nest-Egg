extends "res://tools/quest_resume_probe.gd"

const BOOTH := "res://data/levels/ch1_booth_alley.tres"
var out := ""
var rows: Array = []

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	super._ready()

func _press(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await get_tree().process_frame
	await get_tree().process_frame
	event = InputEventAction.new()
	event.action = action
	Input.parse_input_event(event)
	await get_tree().process_frame

func _until(predicate: Callable, seconds := 20.0) -> bool:
	var limit := Time.get_ticks_msec() + int(seconds * 1000.0)
	while Time.get_ticks_msec() < limit:
		if predicate.call():
			return true
		await get_tree().process_frame
	return bool(predicate.call())

func _shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	if DisplayServer.get_name() != "headless":
		var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
		_check(image.save_png(out.path_join(name + ".png")) == OK, "native capture " + name)
	rows.append({"name": name, "flags": GameState.world_flags.duplicate(true), "deaths": GameState.deaths,
		"scene": String(Story._current_cinematic), "radio": Story._layer.is_radio_frozen(),
		"radio_queue": Story._layer._radio_queue.duplicate(true), "completed_scenes": Story._completed.keys(),
		"phone": _level().player.is_on_phone(), "objective": _objective()})

func _voice() -> NpcActor:
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and node.data != null and node.data.id == &"ch1_lamp_voice" and _level().is_ancestor_of(node):
			return node
	return null

func _read_until_choice() -> bool:
	for i in 100:
		if Story._player != null and Story._player.choice_active():
			return true
		await _press(&"ui_accept")
		await get_tree().create_timer(0.1).timeout
	return false

func _choice(id: String) -> void:
	var player := Story._player
	_check(player != null and player.choice_active(), "real choice panel is open for " + id)
	if player == null or not player.choice_active():
		return
	var index := player._choice_options.find_custom(func(o: Dictionary) -> bool: return o.get("id") == id)
	_check(index >= 0, "authored option exists: " + id)
	if index >= 0:
		(player._choice.get_child(index + 1) as Button).grab_focus()
		await get_tree().process_frame
		await _press(&"ui_accept")

func _read_to_end() -> void:
	for i in 100:
		if not Story.is_cinematic_active() and not Story._layer.is_radio_frozen():
			return
		await _press(&"ui_accept")
		await get_tree().create_timer(0.1).timeout
	_check(false, "presentation ended before budget")

func _talk_voice() -> void:
	var npc := _voice()
	_check(npc != null and npc.is_present(), "actual voice interaction is present")
	if npc == null:
		return
	_level().player.global_position = npc.global_position + Vector2(12, 0)
	_check(await _until(func() -> bool: return npc._player_in_range and npc._cooldown <= 0.0 and _level().player.state == Player.State.NORMAL and not get_tree().paused), "actual voice sensor and original cooldown are ready")
	await _press(&"interact")
	_check(await _until(func() -> bool: return Story.is_cinematic_active()), "public interact starts the voice prompt")
	_check(await _read_until_choice(), "voice prompt reaches real choices")

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	Settings.set_ui_text_scale(1.2)
	await _until(func() -> bool: return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested", GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE), "Main starts a real fresh run")
	await _skip_cinematics()
	await _enter(BOOTH)
	_check(not GameState.has_flag(&"ch1_recording_heard") and not GameState.has_flag(&"sq5_lamp_voice_noticed"), "new run does not fabricate recording or optional answer")
	var booth: Checkpoint
	for node in _level().find_children("*", "", true, false):
		if node is Checkpoint:
			booth = node
	_check(booth != null, "actual authored checkpoint found")
	if booth == null:
		return
	_level().player.global_position = booth.global_position + Vector2(-20, 0)
	await get_tree().create_timer(0.4).timeout
	_check(booth.can_dial() and not booth.activated, "standing nearby offers backup but does not activate it")
	await _press(&"interact")
	_check(await _until(func() -> bool: return Story._layer.is_radio_frozen()), "actual dial opens the authored recording")
	_check(not GameState.has_flag(&"ch1_recording_heard") and not Story._completed.has(&"ch1_t_booth_recording"), "unconfirmed recording does not publish heard flag or completed record")
	await _shot("recording-unconfirmed")
	await _read_to_end()
	_check(GameState.has_flag(&"ch1_recording_heard") and Story.was_seen(&"ch1_t_booth_recording"), "confirming actual recording publishes heard state")
	_check(not GameState.has_flag(&"ch1_voice_accepted") and not GameState.has_flag(&"sq5_lamp_voice_noticed"), "hearing does not accept or finish the optional quest")
	await get_tree().create_timer(0.6).timeout
	var npc := _voice()
	_check(npc != null and npc.is_present(), "hearing reveals actual headphone interaction")
	# x=436: phone at416 is nearer than voice at464; both authored sensors overlap.
	_level().player.global_position = booth.global_position + Vector2(20, 0)
	await get_tree().create_timer(0.4).timeout
	await _press(&"interact")
	await get_tree().process_frame
	_check(_level().player.is_on_phone() and booth.is_calling(), "overlap interact selects the nearer actual phone")
	_check(not Story.is_cinematic_active() and not npc._talking, "phone press does not also start optional voice dialogue")
	await _shot("overlap-nearer-phone")
	# Drain any presentation so the baseline can continue collecting independent evidence.
	if Story.is_cinematic_active():
		await _read_until_choice()
		await _choice("return")
		await _read_to_end()
	await _until(func() -> bool: return not _level().player.is_on_phone() and not booth.is_calling())
	await _talk_voice()
	await _shot("voice-return-choice")
	await _choice("return")
	await _read_to_end()
	_check(not GameState.has_flag(&"ch1_voice_accepted") and not GameState.has_flag(&"ch1_lamp_voice_asked") and not GameState.has_flag(&"sq5_lamp_voice_noticed"), "declining the optional prompt does not advance any voice result")
	await get_tree().create_timer(0.5).timeout
	await _talk_voice()
	await _choice("ask")
	_check(await _read_until_choice(), "first voluntary answer leads to the second question prompt")
	_check(GameState.has_flag(&"ch1_voice_accepted") and GameState.has_flag(&"ch1_lamp_voice_asked") and not GameState.has_flag(&"sq5_lamp_voice_noticed"), "first answer advances one step but does not complete the second")
	await _shot("voice-second-question-pending")
	await _choice("later")
	await _read_to_end()
	_check(not GameState.has_flag(&"sq5_lamp_voice_noticed"), "keeping the second question for later leaves the quest unfinished")
	await _journal(false, true)
	await get_tree().create_timer(0.3).timeout
	_check(_objective().contains("再問錄音是否是他"), "real HUD tracks only the unfinished second voluntary question")
	await _shot("voice-pending-hud")
	await get_tree().create_timer(0.5).timeout
	await _talk_voice()
	await _choice("ask")
	await _read_to_end()
	_check(GameState.has_flag(&"sq5_lamp_voice_noticed"), "only the real voluntary second answer completes the side quest")
	_check(GameState.deaths == 0, "the full recording and optional voice route needs no death")
	await _shot("voice-completed")
	await _journal(true, false)
	_completed = true
	_save_report()

func _continue() -> void:
	await _press_continue(BOOTH)
	_check(GameState.has_flag(&"ch1_recording_heard") and GameState.has_flag(&"ch1_lamp_voice_asked") and GameState.has_flag(&"sq5_lamp_voice_noticed"), "a new Main process restores only the completed real voice results")
	_check(not Story._layer.is_radio_frozen() and not _level().player.is_on_phone(), "continue leaves no phone or radio freeze")
	_check(GameState.deaths == 0, "continue retains the zero-death optional route")
	_check(QuestCatalog.status(_guidance().catalog.find("sq5_ch1_voice"), GameState.world_flags) == "completed", "continued journal truth retains the completed voice quest")
	_check(_guidance().state.pinned_id == "sq5_ch1_voice" and _guidance().state.target(_guidance().catalog, "ch1_kasa", GameState.world_flags).get("id") != "sq5_ch1_voice", "continue retains the real pin but completed side quest does not replace active guidance")
	await _shot("continued-voice-completed")
	await _journal(true, false)
	_completed = true
	_save_report()

func _click(root: Node, key: String) -> bool:
	for button: Button in root.find_children("*", "Button", true, false):
		if button.is_visible_in_tree() and (button.text == key or button.get_meta(&"nav_key", "") == key):
			button.grab_focus()
			await get_tree().process_frame
			await _press(&"ui_accept")
			return true
	return false

func _journal(completed: bool, pin: bool) -> void:
	await _press(&"pause")
	var pause := _level()._pause_menu
	_check(pause._root.visible and get_tree().paused, "public pause opens before the real journal")
	pause._quest_button.grab_focus()
	await get_tree().process_frame
	await _press(&"ui_accept")
	var screen: QuestMapScreen = pause._navigation
	_check(is_instance_valid(screen), "public confirmation opens the real journal")
	if screen == null:
		return
	if completed:
		_check(await _click(screen, "filter:completed"), "completed filter is keyboard accessible")
	_check(await _click(screen, "quest:sq5_ch1_voice"), "the real voice quest can be selected")
	_check(screen._selected == "sq5_ch1_voice", "journal details follow the selected real voice quest")
	var quest := screen.catalog.find("sq5_ch1_voice")
	_check(QuestCatalog.status(quest, GameState.world_flags) == ("completed" if completed else "active"), "journal status follows the actual completed answers")
	if not completed:
		_check(QuestCatalog.current_step(quest, GameState.world_flags).get("complete_flag") == "sq5_lamp_voice_noticed", "only the second voluntary question remains current")
	if pin:
		_check(await _click(screen, "釘選這項任務"), "public journal action pins the real voice quest")
		_check(screen.state.pinned_id == "sq5_ch1_voice", "the journal pin belongs to the actual run navigation")
	await _shot("journal-voice-completed" if completed else "journal-voice-second-question")
	await _press(&"ui_cancel")
	await _press(&"ui_cancel")
	_check(not get_tree().paused and not pause._root.visible, "back returns through pause to the same unpaused world")

func _save_report() -> void:
	var file := FileAccess.open(out.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures": _failures, "completed": _completed, "mode": _mode, "rows": rows,
		"scope": "actual Main, authored checkpoint and optional NPC, public input; arranged area/player position, no direct quest flags or completion emits; not human full-chapter acceptance"}, "\t"))
