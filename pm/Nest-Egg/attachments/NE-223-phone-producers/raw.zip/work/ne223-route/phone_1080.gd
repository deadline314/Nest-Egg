extends "res://work/ne223-route/phone.gd"

func _continue() -> void:
	get_window().size = Vector2i(1920, 1080)
	DisplayMode.ensure_scaling(get_window())
	await super._continue()
