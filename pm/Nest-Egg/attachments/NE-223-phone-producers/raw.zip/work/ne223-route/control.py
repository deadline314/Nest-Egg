from pathlib import Path
import subprocess,os,json,hashlib,re
root=Path('.');out=Path('work/ne223-route'); paths=['game/level/checkpoint.gd','game/npc/npc_actor.gd'];fixed={p:(root/p).read_bytes() for p in paths}
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt={'base':'8776dad7a563cd42fd883bc329e667dcdff60426','fixed_sha256':{p:sha(b) for p,b in fixed.items()}}
test=(root/'tests/suite/test_phone_booth.gd').read_text();start=test.index('## The real booth/NPC overlap');end=test.index('## 骨架動作逐格稽核',start)
old_test=test[:start]+test[end:];old_test=old_test.replace('\tawait _test_nearest_interaction()\n','')
original=subprocess.check_output(['git','show','8776dad7:tests/suite/test_phone_booth.gd'])
assert old_test.encode()==original,'original tests were altered'
receipt['original_assertions_byte_exact']=True
try:
 for p in paths:(root/p).write_bytes(subprocess.check_output(['git','show','8776dad7:'+p]))
 env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',XDG_DATA_HOME=str((out/'control-profile').resolve()))
 with (out/'headless-control.log').open('w') as log:
  cp=subprocess.run(['/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64','--headless','--path',str(root.resolve()),'res://tests/smoke_test.tscn','--','--only=PhoneBoothSuite'],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=300)
 receipt['exit']=cp.returncode;s=(out/'headless-control.log').read_text(); receipt['summary']=re.findall(r'checks:.*',s);receipt['failures']=[l for l in s.splitlines() if '[FAIL]' in l or l.startswith('FAIL')]; receipt['script_error']='SCRIPT ERROR:' in s
finally:
 for p,b in fixed.items():(root/p).write_bytes(b)
 receipt['restored_sha256']={p:sha((root/p).read_bytes()) for p in paths}
 (out/'headless-control-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False))
assert receipt.get('exit')!=0 and receipt.get('failures') and not receipt.get('script_error')
assert receipt['fixed_sha256']==receipt['restored_sha256']
