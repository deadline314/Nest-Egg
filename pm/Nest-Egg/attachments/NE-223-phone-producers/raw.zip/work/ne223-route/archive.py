from pathlib import Path
import hashlib,json,zipfile,subprocess
root=Path('.'); work=root/'work/ne223-route'; dst=root/'pm/Nest-Egg/attachments/NE-223-phone-producers'; entries=[]
for f in work.rglob('*'):
 if not f.is_file() or '__pycache__' in f.parts or any(part.endswith('-profile') for part in f.parts):continue
 entries.append((str(f),f.read_bytes()))
b=Path('/workspace/Nest-Egg/work/batch1020b')
for name in ['ne223-1022-phone-before','ne223-1022-phone-before-v2','ne223-1022-phone-after-v2','ne223-1022-phone-after-v3','ne223-1022-phone-continue-v3','ne223-1022-phone-after-v4','ne223-1022-phone-continue-v4','ne223-1022-phone-continue-1080']:
 for f in (b/name).rglob('*'):
  if f.is_file():entries.append(('native/'+name+'/'+f.name,f.read_bytes()))
 for suffix in ['.log','.exit','-xvfb.log']:
  f=b/(name+suffix)
  if f.exists():entries.append(('native/'+f.name,f.read_bytes()))
entries.append(('native/native.py',(b/'native.py').read_bytes()))
for path in ['game/level/checkpoint.gd','game/npc/npc_actor.gd','ui/quest_map_screen.gd']:
 entries.append(('base/'+path,subprocess.check_output(['git','show','8776dad7:'+path])))
for path in ['data/story/ch1_kasa.json','data/levels/ch1_booth_alley.tres','data/npcs/ch1_lamp_voice.tres','ui/cinematic_framing.gd','tools/quest_resume_probe.gd','tools/viewport_capture.gd']:
 entries.append(('frozen-dependencies/'+path,Path(path).read_bytes()))
manifest=[]
with zipfile.ZipFile(dst/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in sorted(entries):
  z.writestr(name,data);manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(dst/'raw.zip') as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(manifest)
 for e in manifest:
  data=z.read(e['path']);assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
f=dst/'raw.zip';m={'base':'8776dad7a563cd42fd883bc329e667dcdff60426','zip_bytes':f.stat().st_size,'zip_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'all_entries_read_back':True,'entries':manifest}
(dst/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print({k:v for k,v in m.items() if k!='entries'},'entries',len(manifest))
