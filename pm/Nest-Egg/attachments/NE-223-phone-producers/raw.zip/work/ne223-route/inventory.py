from pathlib import Path
import csv,re,urllib.parse,collections,json
rows={'unfinished':[],'review':[]}
for project,folder in [('NE','Nest-Egg'),('BG','Nest-Egg-BG'),('ST','ST')]:
 for p in Path('pm',folder).glob('*.md'):
  m=re.match(r'\[([A-Z]+)-(\d+)\]',p.name)
  if not m:continue
  text=p.read_text();status=re.search(r'^> 狀態：\s*(.+)',text,re.M)
  if not status:continue
  status=status[1].strip();kind='unfinished' if status.startswith('進行中') or status=='待辦' else 'review' if status=='審查中' else None
  if not kind:continue
  heading=re.search(r'^#\s*\[[^\]]+\]\s*(.+)',text,re.M)
  section=re.search(r'^### 驗收條件[^\n]*\n(.*?)(?=^### |\n---|\Z)',text,re.M|re.S)
  checks=re.findall(r'^- \[ \] (.+)',section[1],re.M) if section else []
  rows[kind].append({'ticket':m[0][1:-1],'project':project,'title':p.stem.split(']',1)[1],'status':status,'unchecked_criteria':'\n'.join(checks),'url':'https://github.com/deadline314/Nest-Egg/blob/main/'+urllib.parse.quote(str(p),safe='/')})
for kind,rs in rows.items():
 rs.sort(key=lambda r:(r['ticket'].split('-')[0],int(r['ticket'].split('-')[1])))
 dest=Path('pm',f'{kind}-tickets-2026-10-22-latest.csv')
 old=list(csv.DictReader(dest.open()))
 difference=[r['ticket'] for r in rs if next((o for o in old if o['ticket']==r['ticket']),{})!=r]
 print(kind,len(rs),'statuses',dict(collections.Counter(r['status'].split('（')[0] for r in rs)),'differences',difference)
 if '--write' in __import__('sys').argv:
  with dest.open('w',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=['ticket','project','title','status','unchecked_criteria','url']);writer.writeheader();writer.writerows(rs)
Path('work/ne223-route/inventory-readback.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
