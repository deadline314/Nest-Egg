from pathlib import Path
import json

folder = Path(__file__).resolve().parent
read = lambda path: json.loads((folder / path).read_bytes())
comparison = {}
for side, facing in (("left", -1), ("right", 1)):
    original, candidate = (read(f"{variant}-{side}/run.json") for variant in ("original-v2", "candidate"))
    assert original["input_save"] == candidate["input_save"]
    assert all(result["exit"] == result["resolution"]["failures"] == 0 and not result["errors"] for result in (original, candidate))
    before, after = (result["resolution"]["results"] for result in (original, candidate))
    assert before.keys() == after.keys() == {"no-rear-attack", "engaged", "telegraph", "calm-again"}
    for name, a in before.items():
        b = after[name]
        assert a["forward_visible"] and b["forward_visible"] and a["facing"] == b["facing"] == facing
        assert a["rear_state"] == b["rear_state"] and a["rear_room"] == b["rear_room"] and a["dimensions"] == b["dimensions"]
        if name in ("engaged", "telegraph"):
            assert a["rear_room"] == 178.0 and not a["rear_visible"] and b["rear_visible"] and b["rear_margin"] >= 28.0
        else:
            assert a["rear_room"] == 0.0 and not a["rear_visible"] and not b["rear_visible"]
            assert abs(a["forward_aim_offset"] - b["forward_aim_offset"]) < 0.05
            assert abs(a["forward_lead"] - b["forward_lead"]) < 0.4
    assert after["telegraph"]["rear_state"] == "aim"
    comparison[side] = {name: {"before": round(before[name]["rear_margin"], 3), "after": round(after[name]["rear_margin"], 3)}
                        for name in before}
(folder / "comparison.json").write_text(json.dumps(comparison, indent=2) + "\n", encoding="utf-8")
print(json.dumps(comparison, indent=2))
