extends "res://tools/ch1_flow_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
const START := Vector2(1528.0, 512.0)
var _store := ""
var _facing := 1
var _main: Node
var _rows := {}


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--face="):
			_facing = int(arg.trim_prefix("--face="))
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.player != null, "actual Main continues the street save")
	if _level == null or _level.player == null:
		_finish_rear()
		return
	var player := _level.player
	_level._next_story_trigger = _level._layout.story_triggers.size()
	player.health.grant_invulnerability(60.0)
	for node: Node in _level._entities.get_children():
		if node is EncounterZone:
			node.queue_free()
	for node: Node in get_tree().get_nodes_in_group(&"enemies"):
		node.queue_free()
	await _settle(5)
	player.global_position = START
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	var aim := &"aim_right" if _facing > 0 else &"aim_left"
	Input.action_press(aim)
	_level.camera.snap_to_target()
	await _settle(105)
	var near := _enemy_at(START + Vector2(-float(_facing) * 150.0, 0.0))
	var forward := _enemy_at(START + Vector2(float(_facing) * 110.0, 0.0))
	_check(player.facing == _facing and player.aim_dir == Vector2(_facing,0), "forward aim is stable on the original player")
	await _settle(25)
	await _observe("no-rear-attack",near,forward)
	near.raise_alert(player.global_position, 30.0)
	await _settle(150)
	_check(near.is_engaged() and _level.camera._rear_room > 170.0, "a real engaged enemy reaches the authored rear watch boundary")
	await _observe("engaged",near,forward)
	near.fsm.transition(&"aim")
	near._update_telegraph_light(1.0 / 60.0)
	near.queue_redraw()
	await _settle(12)
	_check(near.fsm.is_in(&"aim") and near.is_telegraphing(), "the original rear enemy begins the authored shot warning")
	await _observe("telegraph",near,forward)
	near.fsm.transition(&"patrol")
	near._alert_left = 0.0
	near._telegraph_left = 0.0
	near._update_telegraph_light(0.0)
	near.queue_redraw()
	await _settle(160)
	_check(is_zero_approx(_level.camera._rear_room), "the layout is calm again with no additional threats")
	await _observe("calm-again",near,forward)
	Input.action_release(aim)
	AimInput.set_virtual_gamepad(player,false)
	_finish_rear()


func _enemy_at(at: Vector2) -> Enemy:
	var definition := load("res://data/enemies/grunt.tres") as EnemyData
	var enemy := definition.behavior.new() as Enemy
	enemy.configure(definition)
	enemy.position = at
	_level._entities.add_child(enemy)
	enemy.set_physics_process(false)
	return enemy


func _observe(name: String, rear: Enemy, forward: Enemy) -> void:
	await RenderingServer.frame_post_draw
	var camera := _level.camera
	var to_canvas := get_viewport().get_canvas_transform()
	var screen := get_viewport().get_visible_rect()
	var a := to_canvas * (rear.global_position - Vector2(0,rear.data.body_size.y * .5))
	var b := to_canvas * (forward.global_position - Vector2(0,forward.data.body_size.y * .5))
	var from_edge := a.x - screen.position.x if _facing > 0 else screen.end.x - a.x
	_rows[name] = {"facing":_level.player.facing,"rear_visible":screen.has_point(a),"rear_margin":from_edge,"forward_visible":screen.has_point(b),
		"rear_state":str(rear.fsm.current),"camera_center":str(camera.get_screen_center_position()),"rear_room":camera._rear_room,
		"forward_aim_offset":camera._aim_look.x * _facing,"forward_lead":camera._look * _facing,"dimensions":str(screen.size)}
	_check(CAPTURE.image(get_viewport()).save_png(_out_dir.path_join(name+".png")) == OK,"capture "+name)


func _finish_rear() -> void:
	var f := FileAccess.open(_out_dir.path_join("rear.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"failures":_failures,"results":_rows},"  ")+"\n")
	f.close()
	_main.call("_quit",0 if _failures == 0 else 1)
