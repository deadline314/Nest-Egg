from pathlib import Path
import json

base = Path(__file__).resolve().parent
read = lambda name: json.loads((base / name / "run.json").read_bytes())

original = read("original-en")
old = original["resolution"]["samples"]
assert original["exit"] == 0 and not original["errors"] and original["resolution"]["failures"] == 0
assert old["default"]["text"] == old["remapped"]["text"] and "滾輪" in old["remapped"]["text"]
assert old["remapped"]["prev"] == "V" and old["remapped"]["next"] == "N"

records = {}
for locale, greeting in {"zh": "空欄位", "ja": "空き枠", "en": "Empty slot"}.items():
    receipt = read("candidate-" + locale)
    assert receipt["input_save"] == original["input_save"]
    data = receipt["resolution"]
    assert receipt["exit"] == 0 and not receipt["errors"] and data["failures"] == 0 and data["language"] == locale
    rows = data["samples"]
    assert rows.keys() == old.keys() and all(row["hovered"] and row["cursor_on_row"] for row in rows.values())
    assert rows["equipped"]["text"] == rows["equipped-after"]["text"] == old["equipped"]["text"]
    for name in ("default", "remapped"):
        assert rows[name]["text"].startswith(greeting)
        assert rows[name]["prev"] in rows[name]["text"] and rows[name]["next"] in rows[name]["text"]
    assert rows["remapped"]["prev"] == "V" and rows["remapped"]["next"] == "N" and "滾輪" not in rows["remapped"]["text"]
    records[locale] = rows
(base / "comparison.json").write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n", "utf-8")
print({locale: len(rows) for locale, rows in records.items()})
