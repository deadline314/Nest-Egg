# NE-228 武器空欄位提示

以 RX 9070 XT Forward+ 實際從主選單讀入第一章港街存檔。HUD 文字設成 120%，用實際滑鼠座標將游標移到已裝備的 P-9 與相鄰空欄。鍵鼠輸入對應由遊戲既有設定 API 改成上一把 V、下一把 N。探針沒有修改武器或彈量。

英語原版在改鍵前後都寫滾輪。修後三語的空欄語句都讀取目前按鍵，每種語言四個停留位置均正確收到 Hover，已裝備武器的原始說明一致。鍵名沿用現有輸入系統提供的名稱，預設滾輪名稱及武器原描述的獨立翻譯留在既有介面範圍。滑鼠 Hover 由 Godot 的 Control 直接詢問目前提示，不須在每次彈量變動時重寫文字。[Godot Control 提示 API](https://docs.godotengine.org/en/stable/classes/class_control.html#class-control-method-get-tooltip)

原生出圖來自相同存檔與語言設定，遊戲世界會持續推進，適合核對 UI 區域。開啟舊存檔時，既有的第二章缺旗標警告採安全預設並進入正常第一章。三語結果與原提示比較見 `comparison.json`。
