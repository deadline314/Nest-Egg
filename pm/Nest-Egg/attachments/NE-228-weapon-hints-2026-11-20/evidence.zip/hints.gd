extends "res://tools/ch1_flow_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
var _store := ""
var _locale := "en"
var _main: Node
var _rows := {}


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--locale="):
			_locale = arg.trim_prefix("--locale=")
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_check(Story.set_language(_locale), "uses the requested language")
	Settings.set_ui_text_scale(1.2)
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.player != null, "continues the original street save")
	if _level == null or _level.player == null:
		_finish_hints()
		return
	var loadout := _level.player.loadout
	var bar := _level.hud.weapon_bar
	var empty := bar.get_child(1) as Control
	var p9 := bar.get_child(0) as Control
	_check(loadout.weapon_in(1) == null and loadout.active_weapon() == loadout.weapon_in(0), "actual HUD shows a P-9 and an unused slot")
	await _visit("equipped", p9)
	await _visit("default", empty)
	_check(InputBindings.set_code(&"weapon_prev", 0, KEY_V) == &"" and InputBindings.set_code(&"weapon_next", 0, KEY_N) == &"", "remaps both weapon cycling actions")
	_check(InputBindings.get_code(&"weapon_prev", 0) == KEY_V and InputBindings.get_code(&"weapon_next", 0) == KEY_N, "both changes reached the input map")
	await _visit("remapped", empty)
	await _visit("equipped-after", p9)
	_finish_hints()


func _visit(name: String, control: Control) -> void:
	var at := control.get_global_transform_with_canvas() * (control.size * 0.5)
	var away := InputEventMouseMotion.new()
	away.position = Vector2(370, 168)
	away.global_position = away.position
	get_viewport().push_input(away, true)
	await _settle(3)
	var hovered := false
	for i in 55:
		if i == 0:
			Input.warp_mouse(get_viewport().get_final_transform() * at)
		var hover := InputEventMouseMotion.new()
		hover.position = at
		hover.global_position = at
		get_viewport().push_input(hover, true)
		hovered = hovered or get_viewport().gui_get_hovered_control() == control
		await _settle(1)
	await RenderingServer.frame_post_draw
	var local := control.size * 0.5
	_rows[name] = {"text":control.get_tooltip(local),"hovered":hovered,
		"cursor_on_row":get_viewport().gui_get_hovered_control()==control,
		"prev":InputBindings.primary_label(&"weapon_prev"),"next":InputBindings.primary_label(&"weapon_next")}
	_check(hovered and CAPTURE.image(get_viewport()).save_png(_out_dir.path_join(name+".png")) == OK, "capture "+name)


func _finish_hints() -> void:
	var file := FileAccess.open(_out_dir.path_join("hints.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures":_failures,"language":Story.language,"samples":_rows},"  ")+"\n")
	file.close()
	_main.call("_quit",0 if _failures==0 else 1)
