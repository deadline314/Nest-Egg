from pathlib import Path
import subprocess,os,json,hashlib
out=Path('work/ne228-choice');env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen'
files=['game/cutscene/cutscene_player.gd','work/ne228-choice/probe.gd','work/ne228-choice/phone_base.gd']
(out/'frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')
cases=[('720-120',[]),('720-100',['--100']),('1080-120',['--1080']),('1080-100',['--1080','--100'])]
results=[]
for case,args in cases:
 name='ne228-1022-choice-'+case
 command=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/ne228-choice/probe.tscn','--mode=write','--save-dir='+str((out/(case+'-save')).absolute()),*args]
 with (out/(name+'-wrapper.log')).open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 results.append({'name':name,'command':command,'exit_code':r.returncode});(out/'matrix-receipt.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert r.returncode==0
