extends "res://work/ne228-choice/phone_base.gd"

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	var scale := 1.2
	for arg in OS.get_cmdline_user_args():
		if arg == "--1080":
			get_window().size = Vector2i(1920, 1080)
			DisplayMode.ensure_scaling(get_window())
		if arg == "--100":
			scale = 1.0
	Settings.set_ui_text_scale(scale)
	await _until(func() -> bool: return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested", GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE), "Main starts fresh run")
	await _skip_cinematics()
	await _enter(BOOTH)
	var booth: Checkpoint
	for node in _level().find_children("*", "", true, false):
		if node is Checkpoint:
			booth = node
	_check(booth != null, "authored checkpoint exists")
	if booth == null:
		return
	_level().player.global_position = booth.global_position + Vector2(-20, 0)
	_check(await _until(booth.can_dial), "actual phone sensor is ready")
	await _press(&"interact")
	_check(await _until(func() -> bool: return Story._layer.is_radio_frozen()), "public dial starts actual recording")
	await _read_to_end()
	_check(GameState.has_flag(&"ch1_recording_heard"), "actual recording completes")
	await get_tree().create_timer(0.6).timeout
	await _press(&"interact")
	_check(await _until(func() -> bool: return booth.is_calling()), "public repeat dial starts backup")
	_check(await _until(func() -> bool: return not booth.is_calling() and not _level().player.is_on_phone()), "backup completes before voice interaction")
	await _talk_voice()
	var banner: UiBanner = _level().hud.toast_banner
	_check(banner.is_showing() and banner._label.text == "已備份，彈藥補滿", "actual backup toast is still present behind real choices")
	# Diagnostic only: freeze the actual banner's tween so the paired captures share its exact phase.
	var tween: Tween = banner._tween
	var was_running := tween != null and tween.is_running()
	if tween != null:
		tween.pause()
	var choice := Story._player._choice
	_check(choice.is_visible_in_tree() and choice.get_child_count() == 4, "prompt, two authored options and explanation share one panel")
	var initial_focus := get_viewport().gui_get_focus_owner()
	_check(initial_focus == choice.get_child(1), "first authored option receives original focus")
	await _shot("choice-with-toast")
	banner.hide()
	await get_tree().process_frame
	await _shot("choice-without-toast-control")
	banner.show()
	await get_tree().process_frame
	await _shot("choice-toast-restored")
	_check(get_viewport().gui_get_focus_owner() == initial_focus, "diagnostic visibility does not move choice focus")
	if tween != null and was_running:
		tween.play()
	await _press(&"ui_down")
	_check(get_viewport().gui_get_focus_owner() == choice.get_child(2), "public direction focuses return option")
	await _press(&"ui_accept")
	await _read_to_end()
	_check(not GameState.has_flag(&"ch1_voice_accepted") and not GameState.has_flag(&"ch1_lamp_voice_asked"), "public return leaves voluntary quest unaccepted")
	_check(await _until(func() -> bool: return not Story.is_cinematic_active() and not GameplayLock.is_locked() and not get_tree().paused), "choice completion releases the original gameplay lock")
	_check(await _until(func() -> bool: return not banner.is_showing(), 8.0), "original toast tween naturally finishes after diagnostic resume")
	await _shot("world-resumed")
	_completed = true
	_save_report()
