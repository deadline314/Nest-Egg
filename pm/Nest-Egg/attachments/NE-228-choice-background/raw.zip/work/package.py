from pathlib import Path
import subprocess,json,hashlib,zipfile,shutil,re
from PIL import Image,ImageChops
root=Path.cwd();scratch=root/'work/ne228-choice';native=Path('/workspace/Nest-Egg/work/batch1020b');out=root/'pm/Nest-Egg/attachments/NE-228-choice-background';out.mkdir(parents=True,exist_ok=True)
base='1a4fae5fce859d7b8e9bcb9817c8e7366afadbf7';sha=lambda b:hashlib.sha256(b).hexdigest()
frozen=json.loads((scratch/'frozen-source.json').read_text());assert all(sha((root/p).read_bytes())==h for p,h in frozen.items())
assert not subprocess.check_output(['git','diff','--name-only',base,'--','tests','tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/run_tests.sh','tools/select_tests.py','tools/test_filters.sh']).strip()
(scratch/'harness-unchanged.json').write_text(json.dumps({'base':base,'paths':'tests/ and original runners/selector/filters','unchanged':True},indent=2)+'\n')
log=(scratch/'changed.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures \(tests/known_failures.txt\): (\d+)\s*\(wall time (\d+) s\)',log);assert m and (m[2],m[3])==('0','0')
rows=[];checks=0
for case in ['before','720-120','720-100','1080-120','1080-100']:
 name='ne228-1022-choice-'+case;d=native/name
 t=(native/(name+'.log')).read_text();assert 'ERROR:' not in t and (native/(name+'.exit')).read_text().strip()=='0'
 assert json.loads((d/'result.json').read_text())['completed']
 count=sum(x.startswith('PASS ') for x in t.splitlines())
 if case!='before':checks+=count
 a=Image.open(d/'choice-with-toast.png').convert('RGB');b=Image.open(d/'choice-without-toast-control.png').convert('RGB');sx=a.width/1280;sy=a.height/720
 roi=tuple(round(v*(sx if i%2==0 else sy)) for i,v in enumerate((500,248,780,270)))
 diff=ImageChops.difference(a.crop(roi),b.crop(roi));different=sum(any(c for c in p) for p in diff.get_flattened_data())
 if case!='before':assert different==0
 rows.append({'case':case,'size':list(a.size),'text_scale':1.0 if case.endswith('100') else 1.2,'checks':count,'failures':0,'roi':roi,'different_pixels':different,'total_pixels':diff.width*diff.height})
assert rows[0]['different_pixels']>0
(scratch/'paired-roi-final.json').write_text(json.dumps({'scope':'paired same-process banner visibility control; rain continues; this text gap is inside the final opaque panel, not a whole-image comparison','rows':rows},indent=2)+'\n')
files={}
for p in scratch.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any(part.startswith('data_') or 'profile' in part for part in p.relative_to(scratch).parts):files['work/'+str(p.relative_to(scratch))]=p.read_bytes()
for case in ['before','720-120','720-100','1080-120','1080-100']:
 name='ne228-1022-choice-'+case
 for p in (native/name).iterdir():
  if p.is_file():files['native/'+name+'/'+p.name]=p.read_bytes()
 for suffix in ['.log','.exit','-xvfb.log']:files['native/'+name+suffix]=(native/(name+suffix)).read_bytes()
for p in ['game/cutscene/cutscene_player.gd','ui/kit/ui_banner.gd','ui/hud.gd','tools/quest_resume_probe.gd','tools/viewport_capture.gd','project.godot']:
 files['source/final/'+p]=(root/p).read_bytes();files['source/before/'+p]=subprocess.check_output(['git','show',base+':'+p])
files['tools/native.py']=(native/'native.py').read_bytes()
ref=root/'pm/Nest-Egg/attachments/NE-229-recovery-references'
for p in ref.iterdir():
 if p.is_file():files['references/'+p.name]=p.read_bytes()
validation={'base':base,'checks':int(m[1]),'new_failures':0,'known_failures':0,'seconds':int(m[4]),'native_final_checks':checks,'native_final_failures':0,'native_final_engine_errors':0,'renderer':'forward_plus','device':'llvmpipe','cases':rows,'source':frozen,'scope':'real Main and authored phone/NPC, arranged area/player position; public choice input; actual toast, diagnostic tween paused only for paired capture; not physical controller or human full-chapter acceptance'}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
manifest={'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for e in manifest['files']:assert sha(z.read(e['path']))==e['sha256']
manifest.update(archive_sha256=sha((out/'raw.zip').read_bytes()),archive_bytes=(out/'raw.zip').stat().st_size)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for src,dst in [('before/choice-with-toast.png','before'),('before/choice-without-toast-control.png','control'),('720-120/choice-with-toast.png','after'),('1080-120/choice-with-toast.png','1080'),('720-120/world-resumed.png','resumed')]:shutil.copy2(native/('ne228-1022-choice-'+src),root/'pm/Nest-Egg/images'/('NE-228-choice-'+dst+'.png'))
print(json.dumps({'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256'],'validation':validation},indent=2))
