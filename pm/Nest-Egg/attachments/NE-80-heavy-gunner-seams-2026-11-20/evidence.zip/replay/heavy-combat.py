from pathlib import Path
import json
import os
import subprocess
import sys

root=Path.cwd()
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=root/'work/ne80-heavy-neck-20261119'
label=sys.argv[1]
out=Path('D:/NestEggVerification/evidence-20261120-ne80-ne81')/label/'combat'
assert not out.exists()
profile=out.parent/'combat-profile'
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(profile/key)
fixture=root/'pm/Nest-Egg/attachments/NE-80-organic-combat'
probe=base/'organic-replay.gd'
original=(fixture/'replay.gd').read_text(encoding='utf-8')
for name in ('replay.gd','replay.tscn'):
    original=original.replace(f'res://pm/Nest-Egg/attachments/NE-80-organic-combat/{name}',(fixture/name).as_posix())
probe.write_text(original,encoding='utf-8',newline='\n')
scene=base/'organic-replay.tscn'
scene.write_text((fixture/'replay.tscn').read_text(encoding='utf-8').replace(
    'res://pm/Nest-Egg/attachments/NE-80-organic-combat/replay.gd',probe.as_posix()),encoding='utf-8',newline='\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=shared).decode().strip()
cmd=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
     'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(shared),'--rendering-method','forward_plus',
     '--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','--fixed-fps','60',
     '--quit-after','4000',scene.as_posix(),'--',f'--out={out.as_posix()}',f'--head={head}','--capture-images']
raw=out.parent/'combat.log'
with raw.open('wb') as log:
    process=subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
text=raw.read_text(encoding='utf-8')
print(text[-2400:],flush=True)
assert process.returncode==0 and 'ERROR:' not in text and '9070 XT' in text
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
