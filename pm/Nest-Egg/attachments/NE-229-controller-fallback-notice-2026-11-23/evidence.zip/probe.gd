extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const PAD := 420
var _out := ""
var _checks := 0
var _failures := 0


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://controller-fallback-probe.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	Story.set_language("en")
	Story.auto_skip = true
	var main: Node = load("res://game/main.gd").new()
	main.set("_run_store", RunSaveStore.new("user://fallback-new-player.json"))
	add_child(main)
	for frame in 100:
		if main.get("_screen") is MainMenu and not GameplayLock.is_locked():
			break
		await get_tree().process_frame
	var root := get_tree().root
	print("TITLE ", main.get("_screen"), " HUD listeners=", EventBus.toast_requested.get_connections().size())
	var prior := await _drop()
	_check(root.gui_get_focus_owner() == prior and not get_tree().paused and not InputBindings.using_gamepad, "title keeps focus and returns to keyboard")
	print("TITLE result label count=", _visible_message(root), " HUD listeners=", EventBus.toast_requested.get_connections().size())
	_check(_visible_message(root) == 1, "title shows exactly one visible device fallback message")
	await _picture("title.png")
	main.call("_on_start_requested", GameState.difficulties[1])
	var level: Level
	for frame in 360:
		var current := main.get("_screen") as Level
		if current != null and current.is_initialized() and not GameplayLock.is_locked() and not Story.is_cinematic_active():
			level = current
			break
		await get_tree().process_frame
	_check(level != null, "the real game can begin with the keyboard")
	if level != null:
		level._pause_menu.open()
		for frame in 6:
			await get_tree().process_frame
		prior = await _drop()
		_check(root.gui_get_focus_owner() == prior and get_tree().paused and not InputBindings.is_controller_interrupted(),
				"notices preserve the already-open pause and focus")
		var hud := level.hud
		print("PAUSE existing text=", hud.toast_banner._label.text, " HUD layer=", hud.layer, " Pause layer=", level._pause_menu.layer)
		_check(_visible_message(root) == 1, "pause shows one visible device fallback message")
		await _picture("pause.png")
		var banner := InputBindings.get("_disconnect_notice") as UiBanner
		var owner_id := banner.get_instance_id() if is_instance_valid(banner) else 0
		var obstacles_after_drop := PromptLayout._obstacles.size()
		await get_tree().create_timer(2.8, true).timeout
		_check(_visible_message(root) == 0 and not is_instance_id_valid(owner_id)
				and PromptLayout._obstacles.size() == obstacles_after_drop - int(owner_id != 0), "expired notice releases its presentation and obstacle")
		level._pause_menu.close()
	main.queue_free()
	for frame in 8:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _failures])
	get_tree().quit(1 if _failures else 0)


func _drop() -> Control:
	Input.joy_connection_changed.emit(PAD, true)
	InputBindings._set_device(true, PAD)
	for frame in 10:
		await get_tree().process_frame
	var focus := get_viewport().gui_get_focus_owner()
	print("DROP selected ", InputBindings.using_gamepad, " pad ", InputBindings.active_device, " focus ", focus)
	_check(InputBindings.using_gamepad and InputBindings.active_device == PAD and focus != null, "selected test device owns a focused menu")
	Input.joy_connection_changed.emit(PAD, false)
	for frame in 18:
		await get_tree().process_frame
	return focus


func _visible_message(node: Node) -> int:
	var count := 0
	for label: Label in node.find_children("*", "Label", true, false):
		if label.is_visible_in_tree() and label.text == "Controller disconnected. Use the keyboard.":
			count += 1
	return count


func _picture(name: String) -> void:
	await RenderingServer.frame_post_draw
	_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(passed: bool, note: String) -> void:
	_checks += 1
	_failures += int(not passed)
	if not passed:
		printerr("FAIL: ", note)
