extends SceneTree


func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() != 2:
		quit(2)
		return
	var source := Image.load_from_file(args[0])
	if source == null or source.get_size() != Vector2i(162, 122):
		quit(3)
		return
	var normal := NormalMapMaker.make(source)
	quit(0 if normal.save_png(args[1]) == OK else 4)
