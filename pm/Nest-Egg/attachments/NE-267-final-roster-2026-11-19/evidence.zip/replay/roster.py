from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
captures = base / sys.argv[1] if len(sys.argv) > 1 else base
captures.mkdir(exist_ok=True)
project = 'D:/NestEggVerification/ne218-baseline-20261117'
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
pages = [
    ('market', 'ch2_patroller,ch2_window_clerk,ch2_hawker,old_k'),
    ('transfer', 'ch2_medic,ch2_greycoat,guest_zheng,mei'),
    ('guests', 'guest_chen,guest_hong,ch2_medic/transport,ch2_greycoat/transport'),
]
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(base / 'profile' / key)

proof = {}
for page, actors in pages:
    for side in ('right', 'left'):
        stem = f'{page}-{side}'
        output = captures / f'{stem}.png'
        assert not output.exists()
        args = ['--left'] if side == 'left' else []
        command = [sys.executable, '-B', str(root/'tools/comfyui/gpu_lock.py'), '--', engine,
                   '--path', project, '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan',
                   '--audio-driver', 'Dummy', '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '1800',
                   'res://tools/rig_preview.tscn', '--', f'--out={output.as_posix()}', f'--chars={actors}',
                   '--closeup', '--bright', '--weapon=', *args]
        with (captures / f'{stem}.log').open('wb') as log:
            result = subprocess.run(command, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        raw = (captures / f'{stem}.log').read_text(encoding='utf-8', errors='replace')
        assert result.returncode == 0 and output.is_file() and 'RX 9070 XT' in raw and 'SCRIPT ERROR:' not in raw, stem
        proof[stem] = actors.split(',')
        print(stem, 'ok', flush=True)
(captures / 'native.json').write_text(json.dumps(proof, indent=2) + '\n')
