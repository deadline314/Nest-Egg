from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
import subprocess
import sys

from PIL import Image

root = Path.cwd()
base = Path(__file__).resolve().parent / 'v2'
base.mkdir()
sys.path.insert(0, str(root / 'tools/comfyui'))
from cut_layers import validate_final_override

assets = root / 'art_src/characters/ch2_window_clerk'
target = root / 'art/characters/ch2_window_clerk/parts/foot.png'
scratch = base / 'input'
scratch.mkdir()
refined = scratch / '07_refined'
refined.mkdir()
for source in (assets / '07_refined').glob('*.png'):
    copyfile(source, refined / source.name)
copyfile(assets / 'base_rgba.png', scratch / 'base_rgba.png')
overrides = scratch / 'overrides'
overrides.mkdir()
assert not (assets / 'overrides/foot.png').exists()
original = base / 'original'
candidate = base / 'candidate'


def cut(to):
    return subprocess.run(
        [sys.executable, '-B', str(root / 'tools/comfyui/cut_layers.py'),
         '--spec', 'tools/comfyui/specs/ch2_window_clerk_side.json', '--work', str(scratch),
         '--char', str(to / 'ch2_window_clerk'), '--rig', str(to / 'ch2_window_clerk.json')],
        cwd=root, check=True, text=True, encoding='utf-8', stdout=subprocess.PIPE).stdout


log = cut(original)
first = original / 'ch2_window_clerk/parts/foot.png'
source = Image.open(first).convert('RGBA')
live = Image.open(target).convert('RGBA')
assert source.size == (162,122) == live.size
assert source.tobytes() == live.tobytes()
result = source.copy()
last_toe = (128,130,131,132,133,134,134,135,136,137,138,139)
changed = 0
for y, last in enumerate(last_toe, 81):
    for x in range(last + 1, source.width):
        if result.getpixel((x,y))[3]:
            result.putpixel((x,y),(0,0,0,0))
            changed += 1
assert changed > 80, changed
override = overrides / 'foot.png'
result.save(override, optimize=True)
log += cut(candidate)
old_rig = original / 'ch2_window_clerk.json'
new_rig = candidate / 'ch2_window_clerk.json'
assert old_rig.read_bytes() == new_rig.read_bytes()
old_skin = original / 'ch2_window_clerk/character.json'
new_skin = candidate / 'ch2_window_clerk/character.json'
assert old_skin.read_bytes() == new_skin.read_bytes()
candidate_parts = candidate / 'ch2_window_clerk/parts'
validate_final_override(override, candidate_parts / 'foot.png')
copyfile(override, candidate_parts / 'foot.png')
assert (candidate_parts / 'foot.png').read_bytes() == override.read_bytes()
assert all((original / 'ch2_window_clerk/parts' / p.name).read_bytes() == p.read_bytes()
           for p in candidate_parts.glob('*.png') if p.name != 'foot.png')
(base / 'cut.log').write_text(log,encoding='utf-8')
receipt = {'removed_alpha_pixels':changed, 'canvas':source.size,
           'parent_sha256':sha256(target.read_bytes()).hexdigest(),
           'override_sha256':sha256(override.read_bytes()).hexdigest(),
           'other_parts_and_all_pivots_held':True}
(base / 'cut.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt)
