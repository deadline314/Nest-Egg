from pathlib import Path
from zipfile import ZipFile
from shutil import copytree
from subprocess import check_output
import json
import sys
import os
from collections import Counter
from PIL import Image
import numpy as np
from scipy import ndimage

root=Path.cwd()
base=Path(__file__).resolve().parent
baseline=base/'original-part-check'
baseline_dir=baseline/'art/characters/rin'
assert not baseline_dir.exists()
copytree(root/'art/characters/rin',baseline_dir,ignore=lambda path, names:[name for name in names if name.endswith(('.import','.uid'))])
for part in ('armor_jacket_far','armor_jacket'):
    for suffix in ('.png','_n.png'):
        name=f'art/characters/rin/parts/{part}{suffix}'
        (baseline/name).write_bytes(check_output(['git','show','HEAD:'+name],cwd=root))
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'tools/comfyui'))
import check_parts
fixed=check_parts.check_character('rin', normals=True)
check_parts.ROOT=baseline
before=check_parts.check_character('rin',normals=True)
assert before==fixed and len(before)==1 and 'armor_jacket_far: the pivot' in before[0]
(base/'parts-comparison.json').write_text(json.dumps({'baseline':before,'candidate':fixed},indent=2)+'\n')
print('same historical construction pivot:',before)

doc=json.loads((base/'same-location.json').read_bytes())
cases=doc['remaining']
new=Counter()
for row in cases:
    file=base/'final-whole'/row['file']
    x,y,w,h=row['rect'];r=row['radius']
    rect=np.array(Image.open(file).convert('RGBA'))[y+h//2-r:y+h//2+r,x+w//2-r:x+w//2+r,3]>=128
    px,py=row['point']
    closed=ndimage.binary_fill_holes(rect,structure=np.ones((3,3))) & ~rect
    new['covered' if rect[py,px] else 'enclosed' if closed[py,px] else 'open']+=1
assert sum(new.values())==len(cases)
print('exact original silhouette pixels',len(cases),new)
meta={'source_enclosed_pixels':len(cases),'candidate':dict(new)}
(base/'silhouette-pixel-comparison.json').write_text(json.dumps(meta,indent=2)+'\n')
