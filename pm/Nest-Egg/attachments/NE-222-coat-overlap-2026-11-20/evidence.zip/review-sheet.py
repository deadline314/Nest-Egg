from pathlib import Path
from collections import Counter
import json
import numpy as np
from scipy import ndimage
from PIL import Image, ImageDraw, ImageFont

base=Path(__file__).resolve().parent
def report(name):
    return json.loads((base/name/'report.json').read_bytes())
def cases(name):
    return {(row['pose'],row['facing'],row['frame']):row for row in report(name)['failures']
        if row['enclosed_pixels'] or row['loose_pieces'] or row['center_alpha']<128}
a=cases('whole')
b=cases('final-whole')
assert not set(b)-set(a)
pixel_increases=[key for key in set(a)&set(b) if b[key]['enclosed_pixels']>a[key]['enclosed_pixels']]
print('whole silhouette hard samples',len(a),'->',len(b),'new matched pixels on existing hard samples',len(pixel_increases))
assert not pixel_increases
path=base/'whole-comparison.json'
path.write_text(json.dumps({'old_hard':len(a),'new_hard':len(b),'new_samples':len(set(b)-set(a)), 'increased_pixels_existing_samples':len(pixel_increases)},indent=2)+'\n')
rows=[('idle',23,'遠側袖根'),('stagger',3,'外套內側')]
font_path=Path('C:/Windows/Fonts/msjh.ttc')
font=ImageFont.truetype(str(font_path),20)
title=ImageFont.truetype(str(font_path),24)
canvas=Image.new('RGB',(756,790),(31,30,39))
draw=ImageDraw.Draw(canvas)
draw.text((38,16),'修正前',font=title,fill=(255,246,248))
draw.text((410,16),'修正後',font=title,fill=(255,246,248))
for row,(pose,index,label) in enumerate(rows):
    names=('baseline-neighbors','final-neighbors')
    pos=row*370+52
    dot=None
    for col,name in enumerate(names):
        root=base/name
        data=json.loads((root/'frames.json').read_bytes())
        group=next(r for r in data if r['pose']==pose and r['zoom']==3.4)
        cell=next(c for c in group['cells'] if c['joint']=='coat_shoulder_back' and c['facing']==1)
        n=group['samples'][index]['file']
        x,y,w,h=cell['rect']
        r=cell['radius']; cx=x+w//2;cy=y+h//2
        image=Image.open(root/n).convert('RGBA').crop((cx-r,cy-r,cx+r,cy+r))
        alpha=np.asarray(image)[:,:,3]>=128
        holes=ndimage.binary_fill_holes(alpha,structure=np.ones((3,3))) & ~alpha
        if col==0:
            yy,xx=np.nonzero(holes)
            assert len(xx)==1
            dot=int(xx[0]),int(yy[0])
        else:
            assert alpha[dot[1],dot[0]] and not holes[dot[1],dot[0]]
        floor=Image.new('RGBA',image.size,(109,103,119,255))
        img=Image.alpha_composite(floor,image).convert('RGB').resize((320,320),Image.Resampling.NEAREST)
        mark=ImageDraw.Draw(img)
        dx,dy=dot[0]*5+2,dot[1]*5+2
        mark.rectangle((dx-8,dy-8,dx+8,dy+8),outline=(255,218,121),width=2)
        canvas.paste(img,(38+col*370,pos+18))
    draw.text((38,pos+341),label,font=font,fill=(251,239,249))
canvas.save(base/'coat-seams.png')
