from pathlib import Path
from hashlib import sha256
import json
import sys
from shutil import copyfile
import numpy as np
from PIL import Image

root=Path.cwd()
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'tools/comfyui'))
from cut_layers import part_transform, render_part
base=Path(__file__).resolve().parent
draft=base/'draft'
spec=json.loads((root/'tools/comfyui/specs/rin_side.json').read_bytes())
k=spec['tex_px_per_wp']/spec['illustration_px_per_wp']
joints={name:np.array(point)*k for name,point in spec['joints'].items()}
parts={'armor_jacket_far':'underlap-2.png','armor_jacket':'liner-2.png'}
assert k==1.0
report={}
runtime=[]
for name,pilot in parts.items():
    source_name=f'art_src/characters/rin_field/07_refined/{name}.png'
    override_name=f'art_src/characters/rin_field/overrides/refined/{name}.png'
    runtime_name=f'art/characters/rin/parts/{name}.png'
    runtime.extend((override_name,runtime_name))
    assert not (root/override_name).exists()
    source=Image.open(root/source_name).convert('RGBA')
    old=np.array(Image.open(root/runtime_name).convert('RGBA'))
    fixed=np.array(Image.open(base/pilot).convert('RGBA'))
    assert source.size==(1056,1536) and old.shape==fixed.shape
    config=spec['parts'][name]
    cut=part_transform(source,config,joints,k)
    old_cut=render_part(source,cut,k)
    assert np.array_equal(old_cut,old) and np.array_equal(cut[0][:,:2],np.eye(2))
    left,top=map(int,cut[0][:,2])
    h,w=old.shape[:2]
    pixels=np.array(source)
    changed=np.any(old!=fixed,axis=2)
    assert np.array_equal(old[old[:,:,3]>=128],fixed[old[:,:,3]>=128])
    source_pixels=np.asarray(source)
    assert np.array_equal(source_pixels[top:top+h,left:left+w,3],old[:,:,3])
    center, radius = (47,13) if name.endswith('_far') else (314,22)
    for y,x in zip(*np.where(changed)):
        distance=round(2*max(0,1-abs(int(y)-center)/radius))
        assert distance in (1,2)
        pixels[top+y,left+x]=source_pixels[top+y,left+x-distance]
    painted=Image.fromarray(pixels)
    recovered=part_transform(painted,config,joints,k)
    assert np.array_equal(cut[0],recovered[0]) and cut[1:3]==recovered[1:3] and np.array_equal(cut[3],recovered[3])
    assert np.array_equal(render_part(painted,recovered,k),fixed)
    override_path=draft/override_name
    override_path.parent.mkdir(parents=True,exist_ok=True)
    painted.save(override_path)
    solved=draft/runtime_name
    solved.parent.mkdir(parents=True,exist_ok=True)
    copyfile(base/pilot,solved)
    yy,xx=np.where(changed)
    report[name]={'original_refined_sha256':sha256((root/source_name).read_bytes()).hexdigest(),
                  'original_native_sha256':sha256((root/runtime_name).read_bytes()).hexdigest(),
                  'override_sha256':sha256(override_path.read_bytes()).hexdigest(),'native_rgba_sha256':sha256(fixed.tobytes()).hexdigest(),
                  'pivot':cut[3].tolist(),'size':[w,h],'changed_pixels':len(xx),
                  'changed_source_box':[left+int(xx.min()),top+int(yy.min()),left+int(xx.max())+1,top+int(yy.max())+1]}
(base/'material.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(base/'draft-paths.json').write_text(json.dumps(runtime,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
