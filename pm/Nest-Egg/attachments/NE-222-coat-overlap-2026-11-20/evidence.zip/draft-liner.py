from pathlib import Path
import numpy as np
from PIL import Image
base=Path(__file__).resolve().parent
source=Path('art/characters/rin/parts/armor_jacket.png')
art=np.array(Image.open(source).convert('RGBA'))
for offset in (0,2,4,6):
    result=art.copy()
    for y in range(293,337):
        steps=round(offset*max(0,1-abs(y-314)/22))
        if steps==0:
            continue
        for x in range(100,134):
            if art[y,x,3] < 128 and art[y,x-steps,3] > art[y,x,3]:
                result[y,x] = art[y,x-steps]
    count=int(np.count_nonzero((result!=art).any(axis=2)))
    assert np.array_equal(result[art[:,:,3]>=128],art[art[:,:,3]>=128])
    Image.fromarray(result).save(base/f'liner-{offset}.png')
    print(offset,count)
