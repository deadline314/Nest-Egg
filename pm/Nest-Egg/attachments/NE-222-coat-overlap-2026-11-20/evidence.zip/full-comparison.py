from pathlib import Path
from collections import Counter
import json

base=Path(__file__).resolve().parent
def index(label):
    report=json.loads((base/label/'report.json').read_bytes())
    assert report['samples']==26880
    rows={}
    for row in report['failures']:
        key=tuple(row[k] for k in ('joint','pose','zoom','facing','frame'))
        if row['enclosed_pixels'] or row['loose_pieces'] or row['center_alpha']<128:
            rows[key]=row
    return report, rows
before, old=index('baseline-neighbors')
after, new=index('final-neighbors')
gone=set(old)-set(new)
fresh=set(new)-set(old)
persist=set(old)&set(new)
changed={k:[old[k]['enclosed_pixels'],new[k]['enclosed_pixels']] for k in persist if old[k]['enclosed_pixels']!=new[k]['enclosed_pixels']}
print('total',before['samples'],'hard',len(old),'->',len(new),'fixed',len(gone),'new',len(fresh))
for name,m in [('before',old),('after',new),('fixed',gone),('new',fresh)]:
    print(name,Counter(key[0] for key in m))
print('new rows', sorted(fresh)[:25])
print('intersect pixel-area changes',Counter((k[0],v[1]-v[0]) for k,v in changed.items()))
(base/'comparison.json').write_text(json.dumps({'samples':before['samples'],'before':len(old),'after':len(new),
   'fixed':sorted(gone),'new':sorted(fresh),'shapes_same':all(set(old[k])==set(new[k]) for k in persist)},indent=2)+'\n',encoding='utf-8')
