extends Node

const SKINS := ["rin", "old_k", "egret", "janus", "enforcer", "ch2_escort", "slasher", "heavy_gunner"]

func _ready() -> void:
	var path := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--bytes="):
			path = arg.trim_prefix("--bytes=")
	var out := FileAccess.open(path, FileAccess.WRITE)
	if out == null:
		printerr("no rig trajectory destination")
		get_tree().quit(2)
		return
	var samples := 0
	for skin: String in SKINS:
		var rig := CharacterRig.new()
		add_child(rig)
		rig.setup(skin)
		rig.set_weapon("rifle")
		
		var input := RigInput.new()
		input.run_speed = 150.0
		for i in 540:
			var set := i / 60
			input.facing = 1 if i < 270 else -1
			input.on_floor = set not in [3, 4]
			input.crouching = set == 2
			input.dashing = set == 5
			input.blocking = set == 6
			input.velocity = Vector2(0.0 if set in [0, 2, 6, 7, 8] else 115.0 * input.facing, -110.0 if set == 3 else (96.0 if set == 4 else 0.0))
			input.aim_dir = Vector2.from_angle(float(i % 60) * 0.027 * input.facing)
			input.dead = set == 8
			rig.animate(1.0 / 60.0, input)
			for mesh: RigPartMesh in rig.limb_meshes():
				var glow := mesh._glow.polygon if mesh._glow != null else PackedVector2Array()
				out.store_var([skin, i, String(mesh.name), mesh.deformed_vertices(), mesh.width_ratio(), mesh.fold_count(), glow])
				samples += 1
		rig.free()
	out.close()
	print("RIG_TRAJECTORY ", samples, " deformed mesh samples")
	get_tree().quit(0)

