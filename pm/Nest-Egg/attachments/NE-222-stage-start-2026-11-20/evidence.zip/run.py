from pathlib import Path
import json, os, re, subprocess, sys

root=Path.cwd()
dir=Path(__file__).resolve().parent
project=Path(sys.argv[1]).resolve()
out=dir/sys.argv[2]
out.mkdir()
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
    (out/key).mkdir()
    env[key]=str(out/key)
command=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
    '--path',str(project),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
    '--resolution','1280x720','--fixed-fps','60','--quit-after','3400',str(dir/'stage-start.tscn'),'--','--out='+str(out)]
with (out/'engine.log').open('wb') as log:
    proc=subprocess.run(command,cwd=project,env=env,timeout=300,stdout=log,stderr=subprocess.STDOUT)
log=(out/'engine.log').read_text('utf-8',errors='replace')
errors=[line for line in log.splitlines() if re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|^FAIL |leaked at exit',line)]
receipt=out/'result.json'
assert receipt.is_file(),log[-2000:]
result=json.loads(receipt.read_bytes())
print({'exit':proc.returncode,'failures':result['failures'],'rows':len(result['rows']),'errors':errors},flush=True)
assert proc.returncode==0 and result['failures']==0 and not errors
