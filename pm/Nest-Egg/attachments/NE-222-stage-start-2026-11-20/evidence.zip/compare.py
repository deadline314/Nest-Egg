from pathlib import Path
from statistics import median
import json,sys
root=Path(__file__).resolve().parent

def read(mode):
    return json.loads((root/mode/'result.json').read_bytes())['rows']

entries={mode:read(mode) for mode in sys.argv[1:]}
tracks=('tick','actor','pose','x','y','floor','speed','where','body_scale','stage_scale','facing','phase','gait','gait_weight')
seq=list(entries.values())
for rows in seq[1:]:
    assert all(all(new[field]==old[field] for field in tracks) for old,new in zip(seq[0],rows,strict=True))
foot=('foot_front','foot_back')
summary={}
for mode,rows in entries.items():
    summary[mode]={}
    for name in ('rin','k'):
        walked=[r for r in rows if r['actor']==name and r['pose']=='walk' and abs(r['speed'])>2.0]
        values=[]
        for r in walked:
            sole=max(r[n][1]-r['floor'] for n in foot)
            ankle=max(r[n+'_ankle'][1]-r['floor'] for n in foot)
            gait=r['gait_weight']
            values.append((r['tick'],sole,ankle,gait))
        name_summary={}
        for tag, subset in (('all',values),('blend',[v for v in values if v[3]<1]),('steady',[v for v in values if v[3]>=1])):
            name_summary[tag]={'frames':len(subset),'sole_within_2px':sum(abs(v[1])<=2.0 for v in subset),
                'median_sole':median(v[1] for v in subset),'max_penetration':max(subset,key=lambda v:v[1]),
                'min_sole':min(subset,key=lambda v:v[1])}
        summary[mode][name]=name_summary
(root/'blend-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
for mode,row in summary.items(): print(mode,row)
