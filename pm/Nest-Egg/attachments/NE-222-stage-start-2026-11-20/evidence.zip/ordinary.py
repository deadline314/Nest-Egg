from pathlib import Path
from hashlib import sha256
import json,os,re,subprocess,sys

here=Path(__file__).resolve().parent
shared=here.parent/'ne218-baseline-20261117'
root=Path.cwd()
previous=json.loads((here.parent/'evidence-20261120-ne222-character-glow/published-source.json').read_bytes())
current=json.loads((here/'source.json').read_bytes())
rev=(here/'baseline.txt').read_text().strip()
changes=json.loads((here/'runtime.json').read_bytes())
sha=lambda data:sha256(data).hexdigest()
backups={p:(shared/p).read_bytes() for p in changes}
assert all(sha(data)==current[p] for p,data in backups.items())
scene=here.parent/'evidence-20261120-ne222-fast-row/geometry.tscn'
godot='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
results={}
for label in ('gameplay-before','gameplay-after'):
    out=here/label
    out.mkdir()
    try:
        if label=='gameplay-before':
            for p in changes:
                data=subprocess.check_output(['git','show',rev+':'+p],cwd=root)
                if sha(data)!=previous[p]:
                    data=data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
                assert sha(data)==previous[p],p
                (shared/p).write_bytes(data)
        env=os.environ.copy()
        for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','TEMP','TMP','TMPDIR'):
            (out/key).mkdir()
            env[key]=str(out/key)
        with (out/'probe.log').open('wb') as log:
            proc=subprocess.run([godot,'--headless','--path',str(shared),str(scene),'--','--bytes='+str(out/'frames.bin')],
                                cwd=shared, env=env, stdout=log,stderr=subprocess.STDOUT,timeout=120)
        log=(out/'probe.log').read_text('utf-8',errors='replace')
        assert proc.returncode==0 and 'RIG_TRAJECTORY 54540' in log and not re.search(r'^(?:SCRIPT )?ERROR:|leaked at exit',log,re.M),log[-1000:]
        results[label]=sha((out/'frames.bin').read_bytes())
    finally:
        if label=='gameplay-before':
            for p,data in backups.items():
                (shared/p).write_bytes(data)
    assert all(sha((shared/p).read_bytes())==current[p] for p in changes)
assert len(set(results.values()))==1,results
(here/'ordinary-geometry.json').write_text(json.dumps(results,indent=2)+'\n')
print(results,flush=True)
