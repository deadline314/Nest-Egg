extends "res://tools/cinematic_safe_area_capture.gd"

const HOME := &"ch1_c14_home"
var _rows: Array[Dictionary] = []
var _bottom_points: Dictionary = {}
var _photos: Dictionary = {}
var _failures := 0
var _render_tick := -1
var _render_holds: Array[Dictionary] = []


func _run() -> void:
	Story.auto_skip = false
	GameState.start_new_run(GameState.difficulties[1])
	for flag in [&"ch1_supper_done", &"ch1_handoff_done"]:
		GameState.set_flag(flag, true, false)
	var level := Level.new()
	level.configure(load(level_path) as LevelData)
	get_tree().root.add_child(level)
	await _frames(60)
	Story.reset_active_presentation(&"route")
	await _frames(18)
	_check(Story.play(HOME, false), "the actual return-home scene starts")
	for i in 240:
		if Story._current_cinematic == HOME and is_instance_valid(Story._player):
			break
		await _frames(1)
	RenderingServer.frame_post_draw.connect(_record_rendered_hold)
	var completed := false
	for tick in 3000:
		var player: CutscenePlayer = Story._player
		if not is_instance_valid(player) or player.scene_id != HOME or not player.is_running():
			completed = tick > 0
			break
		_render_tick = tick
		for actor_id: StringName in [&"k",&"rin"]:
			var actor: CutsceneActor = player._actors.get(actor_id)
			if is_instance_valid(actor) and actor.rig != null:
				_record(actor, tick, player._current_where, player._stage)
		if player._dialogue.visible and tick % 32 == 31:
			player._dialogue.complete()
			player._advance_requested = true
		await _frames(1)
	RenderingServer.frame_post_draw.disconnect(_record_rendered_hold)
	_check(completed and _rows.size() > 1000, "the actual scene ends after continuous movement observations")
	var file := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures":_failures,"rows":_rows,"photos":_photos,"render_holds":_render_holds},"  ")+"\n")
	file.close()
	Story.reset_active_presentation(&"route")
	AudioRelease.begin_shutdown()
	level.queue_free()
	await _frames(6)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures == 0 else 1)


func _record(actor: CutsceneActor, tick: int, where: String, stage: StageLibrary.Stage) -> void:
	var animator: HumanoidAnimator = actor.rig.animator
	var row := {"tick":tick,"actor":String(actor.actor_id),"pose":String(actor.pose),"x":actor.position.x,
		"y":actor.position.y,"floor":actor.ground_y,"where":where,"speed":actor._input.velocity.x,
		"phase":animator._phase,"gait":animator._gait_on,"gait_weight":animator._gait_w,"facing":actor.facing}
	for name: StringName in [&"foot_front",&"foot_back"]:
		var part := actor.rig.contact_part(name)
		if not is_instance_valid(part):
			_check(false, "could not find one visible current boot sprite: " + String(actor.actor_id)+"/"+String(name))
			return
		row[String(name)] = _floor_contact(part, actor.get_parent() as Node2D)
	if actor.actor_id == &"k" and is_instance_valid(stage):
		for hold: StagePropHold in stage._held:
			if hold.prop_id != "kettle" or hold._actor.get_ref() != actor:
				continue
			var pot := stage.prop_node("kettle") as StageLayers._Sprite
			var grip := stage.to_local(pot.to_global(pot.source_point(hold._source_point)))
			var palm := stage.to_local(actor.hand_contact_global(hold._hand))
			row["kettle_gap"] = grip.distance_to(palm)
	if actor.actor_id == &"k" and tick in [707, 712, 718, 1184, 1190, 1193]:
		var transition := preload("res://tools/viewport_capture.gd").image(get_viewport())
		if transition.save_png(_out.path_join("transition-%04d.png" % tick)) != OK:
			_failures += 1
	_rows.append(row)
	if actor.actor_id != &"k" or actor.pose != &"walk" or absf(actor._input.velocity.x) < 1.0:
		return
	var group := "%s-%d" % [where.get_slice("（",0).get_slice("步",0).strip_edges().get_slice(" ",3),actor.facing]
	var count := int(_photos.get(group,0))
	if count in [12,28,44,60]:
		var pic := "old-k-%s-%03d.png" % [group,count]
		var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
		if image.save_png(_out.path_join(pic)) != OK:
			_failures += 1
	_photos[group] = count + 1


func _record_rendered_hold() -> void:
	var player: CutscenePlayer = Story._player
	if _render_tick < 0 or not is_instance_valid(player) or player.scene_id != HOME:
		return
	var stage := player._stage
	if not is_instance_valid(stage):
		return
	for hold: StagePropHold in stage._held:
		var actor := hold._actor.get_ref() as CutsceneActor
		if hold.prop_id != "kettle" or not is_instance_valid(actor) or actor.actor_id != &"k":
			continue
		var pot := stage.prop_node("kettle") as StageLayers._Sprite
		var grip := stage.to_local(pot.to_global(pot.source_point(hold._source_point)))
		var palm := stage.to_local(actor.hand_contact_global(hold._hand))
		_render_holds.append({"tick":_render_tick,"pose":String(actor.pose),"facing":actor.facing,"gap":grip.distance_to(palm)})


func _floor_contact(part: Sprite2D, stage: Node2D) -> Array:
	var key := part.texture.get_instance_id()
	if not _bottom_points.has(key):
		var image := part.texture.get_image()
		var outline := PackedVector2Array()
		for x in image.get_width():
			for y in range(image.get_height()-1, -1, -1):
				if image.get_pixel(x,y).a >= 0.5:
					outline.append(Vector2(x+0.5,y+0.5))
					break
		_bottom_points[key] = Geometry2D.convex_hull(outline)
	var bottom := Vector2.ZERO
	var found := false
	for point: Vector2 in _bottom_points[key]:
		var local := CharacterRig.part_source_point(part, point)
		var location := stage.to_local(part.to_global(local))
		if not found or location.y > bottom.y:
			bottom = location
			found = true
	return [bottom.x,bottom.y,part.global_rotation] if found else []


func _check(ok: bool, what: String) -> void:
	print("%s %s" % ["PASS" if ok else "FAIL",what])
	if not ok:
		_failures += 1
