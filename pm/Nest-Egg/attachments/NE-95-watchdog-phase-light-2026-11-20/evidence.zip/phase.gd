extends "res://tools/ch1_flow_probe.gd"

const WAREHOUSE := preload("res://data/levels/ch1_warehouse.tres")
const SHOT := preload("res://data/projectiles/pistol_shot.tres")
var _dog: PatternBoss
var _back: Hurtbox
var _hit: Dictionary = {}
var _frames: Array[Dictionary] = []
var _changes_phase := true
var _reduced := false
var _low := false
var _direction := -1


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		match arg:
			"--no-transition": _changes_phase = false
			"--reduced": _reduced = true
			"--low": _low = true
			"--right-facing": _direction = 1
	Transition.instant = true
	add_child(LightKit.create_environment())
	super._ready()


func _run() -> void:
	seed(95254)
	Settings.use_storage("user://phase_transition_light.cfg")
	Settings.set_light_quality(LightQuality.Tier.LOW if _low else LightQuality.Tier.HIGH)
	Settings.set_reduce_flashes(_reduced)
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	_level = Level.new()
	_level.configure(WAREHOUSE)
	add_child(_level)
	_level._lighting._lightning_gap = 1.0e9
	await _settle(45)
	for node in _level._entities.get_children():
		if node is PatternBoss and node.data.id == &"watchdog":
			_dog = node
	for node in get_tree().get_nodes_in_group(&"enemies"):
		if node != _dog:
			node.queue_free()
	if _dog == null or not is_instance_valid(_level.player):
		_check(false, "the original warehouse did not create its watchdog and player")
		await _finish_phase()
		return
	for part: Hurtbox in _dog.hurtbox.parts:
		if part.part_id == &"back_power":
			_back = part
	if _back == null:
		_check(false, "the dog's back power port is missing")
		await _finish_phase()
		return
	var player := _level.player
	player.health.setup(999, 0.0)
	var wake := _dog.global_position
	player.global_position = wake + Vector2(-55 * _direction, 0.0)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	_dog.data = _dog.data.duplicate()
	_dog.data.attack_cooldown = 999.0
	_dog.data.move_speed = 0.0
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.limit_enabled = false
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * 2.0
	camera.global_position = (wake + player.global_position) * 0.5 + Vector2(0, -27)
	camera.reset_smoothing()
	camera.force_update_scroll()
	await _settle(190)
	_check(_dog.get("_awake"), "the moved player woke the real boss")
	_dog.facing = _direction
	_dog.health.current = floori(_dog.health.max_health * 0.30) + (1 if _changes_phase else 8)
	_dog.call(&"_apply_phase", 1, false)
	_dog.set("_stagger_override", 3.0)
	_dog.fsm.transition(&"yanked")
	_dog.health.damaged.connect(_record_hit)
	await _settle(24)
	_check(_dog.phase == 1 and _dog.is_part_open(&"back_power"), "pre-shot weak point is open in phase two")
	var hp := _dog.health.current
	var ammo := player.loadout.mag_in(player.loadout.active_slot)
	AimInput.restore_direction((_back.center() - player.aim_origin()).normalized())
	await _settle(6)
	var prior := get_viewport().get_canvas_transform() * _back.center()
	await _save_frame("before", prior)
	Input.action_press(&"shoot")
	await _settle(1)
	Input.action_release(&"shoot")
	for frame in 30:
		if not _hit.is_empty():
			break
		await _settle(1)
	_check(not _hit.is_empty() and _hit["part"] == "back_power" and _hit["weak"] and _hit["damage"] == int(SHOT.damage) * 2,
		"one real P-9 round hits the powered port for double damage")
	_check(player.loadout.mag_in(player.loadout.active_slot) == ammo - 1 and _dog.health.current == hp - int(SHOT.damage) * 2,
		"one round and the expected damage were consumed")
	_check(_dog.phase == (2 if _changes_phase else 1), "the real health change crossed only the intended threshold")
	if not _hit.is_empty():
		var projected := Vector2(_hit["pixel"][0], _hit["pixel"][1])
		for frame in 18:
			await _save_frame("%02d" % frame, projected)
			await _settle(1)
	await _finish_phase()


func _record_hit(info: DamageInfo) -> void:
	var point := get_viewport().get_canvas_transform() * _back.center()
	_hit = {"part": String(info.part), "weak": info.weak_hit, "damage": info.amount, "pixel": [point.x, point.y],
		"phase": _dog.phase, "health": _dog.health.current, "physics": Engine.get_physics_frames()}


func _save_frame(label: String, mark: Vector2) -> void:
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	var code := image.save_png(_out_dir.path_join(label + ".png"))
	if code != OK:
		_check(false, "could not save frame " + label)
	var lights: Array = []
	for light: PointLight2D in Fx._lights:
		if light.enabled:
			lights.append([light.global_position.x, light.global_position.y, light.energy, light.texture_scale])
	_frames.append({"key": label, "point": [mark.x, mark.y], "frame": Engine.get_physics_frames(),
		"phase": _dog.phase, "state": String(_dog.fsm.current), "lights": lights, "viewport": [get_viewport().size.x, get_viewport().size.y],
		"image": [image.get_width(), image.get_height()], "health": _dog.health.current})


func _finish_phase() -> void:
	var output := FileAccess.open(_out_dir.path_join("result.json"), FileAccess.WRITE)
	output.store_string(JSON.stringify({"failures": _failures, "hit": _hit, "frames": _frames,
		"reduced": _reduced, "low": _low, "threshold": _changes_phase, "dir": _direction,
		"adapter": RenderingServer.get_video_adapter_name(), "hdr": get_viewport().use_hdr_2d}, "  ") + "\n")
	output.close()
	AudioRelease.begin_shutdown()
	_level.queue_free()
	await _settle(6)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures == 0 else 1)
