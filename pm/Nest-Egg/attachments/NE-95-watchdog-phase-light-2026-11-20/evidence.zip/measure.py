from pathlib import Path
import json
import sys

import numpy as np
from PIL import Image

base = Path(__file__).resolve().parent
output = {}
for label in sys.argv[1:]:
    folder = base / label
    report = json.loads((folder / 'result.json').read_bytes())
    assert report['failures'] == 0 and len(report['frames']) == 19
    values = []
    for frame in report['frames']:
        with Image.open(folder / (frame['key'] + '.png')) as png:
            rgb = np.asarray(png.convert('RGB'))
        nearwhite = rgb.min(axis=2) >= 245
        x, y = (2.0 * val for val in frame['point'])
        yy, xx = np.ogrid[:rgb.shape[0], :rgb.shape[1]]
        areas = {
            'port': ((xx - x) / 54.0) ** 2 + ((yy - y) / 52.0) ** 2 <= 1.0,
            'armor': ((xx - (x + report['dir'] * 108.0)) / 66.0) ** 2 + ((yy - (y + 59.0)) / 54.0) ** 2 <= 1.0,
        }
        values.append({'frame': frame['key'], 'screen': int(nearwhite.sum()),
                       **{name: int((mask & nearwhite).sum()) for name, mask in areas.items()},
                       'lights': frame['lights']})
    numbers = {area: {'before': values[0][area], 'after_peak': max(r[area] for r in values[1:]),
                      'after_sum': sum(r[area] for r in values[1:])} for area in ('screen', 'port', 'armor')}
    output[label] = {'numbers': numbers, 'frames': values, 'hit': report['hit']}
    print(label, numbers)
(base / 'exposure.json').write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
