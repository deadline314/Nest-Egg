from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
root = Path.cwd()
output = base / sys.argv[1]
output.mkdir()
mode = sys.argv[2]
manifest = base / 'source.json' if mode == 'candidate' else base.parent / 'evidence-20261120-ne218-watchdog-native/published-source.json'
expected = json.loads(manifest.read_bytes())
path = 'game/enemies/boss/pattern_boss.gd'
script = root / path
stock = script.read_bytes()
assert sha256(stock).hexdigest() == expected[path]
edits = {
    'stock': None,
    'candidate': None,
    'no-phase-flash': ('Fx.flash_light(_center(), Palette.DANGER, 160.0, 2.0, 0.6)',
                       'pass # isolate only the temporary native phase light'),
    'no-marker': ('_draw_open_parts()', '_draw_open_parts() # bypass-pilot'),
}
assert mode in edits
changed = stock
if mode == 'no-marker':
    newline = b'\r\n' if b'\r\n' in stock else b'\n'
    marker = b'\t_draw_open_parts()' + newline
    assert changed.count(marker) == 1
    changed = changed.replace(marker, b'\tpass # isolate the open weak-point marker' + newline)
elif edits[mode] is not None:
    old, new = (entry.encode() for entry in edits[mode])
    assert changed.count(old) == 1
    changed = changed.replace(old, new)
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP', 'TMPDIR'):
    directory = output / key
    directory.mkdir()
    env[key] = str(directory)
godot = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
cmd = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--', godot, '--path', str(root),
       '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--fixed-fps', '60',
       '--audio-driver', 'Dummy', '--resolution', '1280x720', '--quit-after', '1200', str(base / 'phase.tscn'),
       '--', f'--out={output}', *sys.argv[3:]]
(output / 'source.json').write_text(json.dumps({'command': cmd, 'variant': mode, 'sha': sha256(changed).hexdigest(),
    'actor_sha': sha256((root / 'game/enemies/watchdog.gd').read_bytes()).hexdigest(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()}, indent=2), encoding='utf-8')
try:
    if changed != stock:
        script.write_bytes(changed)
    with (output / 'engine.log').open('wb') as log:
        proc = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120)
finally:
    if changed != stock:
        script.write_bytes(stock)
assert sha256(script.read_bytes()).hexdigest() == expected[path]
raw = (output / 'engine.log').read_text(encoding='utf-8', errors='replace')
print(raw[-4500:])
assert proc.returncode == 0 and not re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|leaked at exit', raw, re.M)
result = json.loads((output / 'result.json').read_bytes())
assert result['failures'] == 0 and len(result['frames']) == 19 and '9070' in result['adapter'] and result['hdr']
print(result['hit'])
