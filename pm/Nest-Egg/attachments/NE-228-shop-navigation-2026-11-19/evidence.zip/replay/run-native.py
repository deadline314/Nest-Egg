from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = root / 'work/ne228-shop-navigation-20261119'
variant = sys.argv[1]
assert variant in ('before', 'after')
for name in ('ui/inventory/shop_screen.gd', 'data/scripts/shop_data.gd'):
    assert (shared / name).read_bytes() == (base / variant / name).read_bytes()
out = base / f'native-{variant}'
out.mkdir()
probe = base / 'probe.gd'
scene = base / 'probe.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n'
                 '[node name="ShopNavigation" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')
env = os.environ.copy()
for name in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[name] = str(out / 'profile' / name)
command = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '2200',
           scene.as_posix(), '--', '--out=' + str(out)]
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (out / 'raw.log').open('wb') as log:
    result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=160)
raw = (out / 'raw.log').read_text(encoding='utf-8')
print(raw[-3500:], flush=True)
report = json.loads((out / 'report.json').read_text(encoding='utf-8'))
print(json.dumps(report, ensure_ascii=False), flush=True)
assert '9070 XT' in report['adapter'] and report['size'] == [1280, 720] and report['scale'] == 1.2
if variant == 'before':
    assert result.returncode == 1 and report['failures'] == 4 and 'SCRIPT ERROR' in raw
    assert 'Index p_index = 0 is out of bounds' in raw or 'out of bounds' in raw.lower()
else:
    assert result.returncode == 0 and report['failures'] == 0 and 'SCRIPT ERROR' not in raw
