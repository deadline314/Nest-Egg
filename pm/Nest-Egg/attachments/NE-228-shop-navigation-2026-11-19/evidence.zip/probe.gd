extends ScenarioBase

var _observed: Dictionary = {}


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	Settings.set_ui_text_scale(1.2)
	await open_arena("res://data/lighting/warehouse_interior.tres")
	Progression.add_credits(1000)
	var shelf := _open(load("res://data/shops/supply.tres") as ShopData)
	await _key(KEY_DOWN)
	await settle(45)
	await _check_legend("shelf-keyboard", shelf, false)
	await _button(JOY_BUTTON_DPAD_DOWN)
	await settle(45)
	await _check_legend("shelf-gamepad", shelf, false)
	_check(InputBindings.using_gamepad, "the gamepad event changes the displayed device")
	await _button(JOY_BUTTON_B)
	_check(not shelf.is_open() and not get_tree().paused, "gamepad cancel resumes play")
	await settle(45)

	var counter := _open(load("res://data/shops/ch1_pawn.tres") as ShopData)
	await _key(KEY_E)
	await settle(45)
	await _check_legend("counter-keyboard", counter, true)
	_check(counter._current == 1, "E opens the pawn page")
	await _button(JOY_BUTTON_RIGHT_SHOULDER)
	await settle(45)
	await _check_legend("counter-gamepad", counter, true)
	_check(counter._current == 2, "the right shoulder button opens the workbench")
	await _key(KEY_ESCAPE)
	_check(not counter.is_open() and not get_tree().paused, "keyboard cancel resumes play")
	await settle(45)

	var empty_data := ShopData.new()
	_observed["empty_prompt"] = empty_data.prompt_text()
	_check(empty_data.prompt_text() == "{interact} 補給點" and not empty_data.validate().is_empty(),
		"the empty data keeps its diagnostic and readable prompt")
	var empty := _open(empty_data)
	await settle(45)
	_check(empty.is_open() and empty._pages.size() == 1, "empty data opens one shelf")
	if empty._pages.size() == 1:
		var page := empty._pages[0] as ShopPage
		_check(page != null and page._detail._empty.visible and page._detail._empty.text == "這個補給點沒有商品。",
			"the empty shelf explains why it has no cards")
		await RenderingServer.frame_post_draw
		capture("empty-shelf")
		await _key(KEY_ENTER)
		_check(Progression.credits == 1000, "confirm cannot pay at an empty shelf")
		await _key(KEY_ESCAPE)
		_check(not empty.is_open() and not get_tree().paused, "the empty shelf can be dismissed")
	else:
		get_tree().paused = false
	var window_size := get_window().size
	var report := {"checks": _observed, "failures": failures, "scale": Settings.get_ui_text_scale(),
		"adapter": RenderingServer.get_video_adapter_name(), "size": [window_size.x, window_size.y]}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)


func _open(data: ShopData) -> ShopScreen:
	var screen := ShopScreen.new()
	screen.configure_shop(player, data)
	level.add_child(screen)
	screen.open()
	return screen


func _check_legend(label: String, screen: ShopScreen, has_tabs: bool) -> void:
	var legend := screen._legend_label
	_observed[label] = {"legend": legend.text, "tabs": screen._tabs.visible, "gamepad": InputBindings.using_gamepad}
	_check(legend.text.contains("分頁") == has_tabs and screen._tabs.visible == has_tabs, label + " reports the actual tabs")
	_check(legend.text.contains("確認") and legend.text.contains("返回" if InputBindings.using_gamepad else "離開"),
		label + " preserves confirm and exit hints")
	await RenderingServer.frame_post_draw
	capture(label)


func _key(code: int) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	await _press(event)


func _button(code: int) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = code
	await _press(event)


func _press(event: InputEvent) -> void:
	event.set("pressed", true)
	Input.parse_input_event(event)
	await settle(2)
	var release := event.duplicate() as InputEvent
	release.set("pressed", false)
	Input.parse_input_event(release)
	await settle(3)


func _check(condition: bool, label: String) -> void:
	_observed[label] = condition
	if not condition:
		failures += 1
		print("NE228 negative control: ", label)
