extends "res://tools/ch1_flow_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
var _store := ""
var _locale := "en"
var _main: Node
var _hud: Hud
var _observations := {}


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--locale="):
			_locale = arg.trim_prefix("--locale=")
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_check(Story.set_language(_locale), "uses the requested story language")
	Settings.set_ui_text_scale(1.2)
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.player != null, "loads the actual street save")
	if _level == null or _level.player == null:
		_finish_hints()
		return
	var player := _level.player
	_hud = _level.hud
	player.cyber.charge = CyberSystem.MAX_CHARGE
	player.cyber.debug_set_ability(Progression.find_ability(&"emp_pulse"))
	var bag := player.consumables
	bag.restore({})
	var med := ConsumableBag.find(&"med_injector")
	var shield := ConsumableBag.find(&"shield_cell")
	var added_med := bag.add(med)
	var added_shield := bag.add(shield)
	_check(added_med and added_shield and _hud.cyber_gauge.visible, "shows real consumables and cyber charge from Player signals")
	await _settle(10)
	var label := _hud._items_label
	var occupied := label.get_global_transform_with_canvas() * Vector2(3, label.size.y * 0.5)
	await _visit("full", label, occupied)
	await _visit("ability", _hud.cyber_gauge)
	var retarget := InputBindings.set_code(&"use_item", 0, KEY_N)
	var retarget_ability := InputBindings.set_code(&"ability", 0, KEY_B)
	_check(retarget == &"" and retarget_ability == &"" and InputBindings.get_code(&"use_item", 0) == KEY_N
		and InputBindings.get_code(&"ability", 0) == KEY_B, "normal direct remapping succeeds")
	await _settle(4)
	await _visit("full-rebound", label, occupied)
	await _visit("ability-rebound", _hud.cyber_gauge)
	_check(bag.take(&"shield_cell"), "removes one real item through the original bag")
	await _settle(6)
	await _visit("narrow", label, occupied)
	_check(bag.take(&"med_injector") and label.text.is_empty(), "the original bag depletes and clears the displayed counts")
	await _settle(5)
	await _visit("empty", label, occupied)
	await _visit("empty-edge", label, label.get_global_transform_with_canvas() * Vector2(0.5, label.size.y * 0.5))
	_check(bag.add(shield), "the real bag refills after being empty")
	await _settle(5)
	await _visit("refilled", label, occupied)
	_finish_hints()


func _visit(name: String, control: Control, target := Vector2.INF) -> void:
	var at := control.get_global_transform_with_canvas() * (control.get_minimum_size() * 0.5) if not target.is_finite() else target
	var hover := false
	var away := InputEventMouseMotion.new()
	away.position = Vector2(370, 168)
	away.global_position = away.position
	get_viewport().push_input(away, true)
	await _settle(4)
	for i in 50:
		if i == 0:
			Input.warp_mouse(get_viewport().get_final_transform() * at)
		var event := InputEventMouseMotion.new()
		event.position = at
		event.global_position = at
		get_viewport().push_input(event, true)
		hover = hover or get_viewport().gui_get_hovered_control() == control
		await _settle(1)
	await RenderingServer.frame_post_draw
	var hovered := get_viewport().gui_get_hovered_control()
	var label := control as Label
	_observations[name] = {"visible":control.is_visible_in_tree(),"hover":hovered==control,"hover_immediate":hover,
		"tooltip":control.tooltip_text,"text":label.text if label != null else "", "width":control.size.x,
		"minimum":control.get_minimum_size().x,"was_blocked":_hud.hover_guard.blocked,
		"item_key":InputBindings.primary_label(&"use_item"),"ability_key":InputBindings.primary_label(&"ability")}
	var path := _out_dir.path_join(name+".png")
	_check(CAPTURE.image(get_viewport()).save_png(path) == OK,"write "+name)


func _finish_hints() -> void:
	var f := FileAccess.open(_out_dir.path_join("hints.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"failures":_failures,"language":Story.language,"results":_observations},"  ")+"\n")
	f.close()
	_main.call("_quit",0 if _failures==0 else 1)