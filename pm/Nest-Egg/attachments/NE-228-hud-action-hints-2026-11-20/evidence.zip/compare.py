from pathlib import Path
import json

d=Path(__file__).resolve().parent
read=lambda path:json.loads((d/path/'run.json').read_bytes())
ref=read('original-edge-en')
old=ref['resolution']['results']
assert ref['exit']==0 and old['empty-edge']['visible'] and old['empty-edge']['hover'] and old['empty-edge']['width']==1
assert old['full']['tooltip']==old['refilled']['tooltip'] and '醫療針' in old['refilled']['tooltip']
assert '義體能力' in old['ability']['tooltip']
expect = {'zh':['快速道具','使用消耗品','擊敗敵人'],
          'ja':['クイックアイテム','消耗品','敵撃破'],
          'en':['quick item','consumables','defeating enemies']}
summary={}
for locale,(quick,bag,cyber) in expect.items():
    run=read(f'candidate-{locale}')
    assert run['exit']==0 and run['errors']==[] and run['input_save']==ref['input_save']
    assert run['resolution']['failures']==0 and run['resolution']['language']==locale
    rows=run['resolution']['results']
    assert all(not row['was_blocked'] for row in rows.values())
    for blank in ('empty','empty-edge'):
        row=rows[blank]
        assert not row['visible'] and not row['hover'] and row['text']==''
    for slot,key in (('full','Q'),('full-rebound','N'),('narrow','N')):
        row=rows[slot]
        assert row['visible'] and row['hover'] and quick in row['tooltip'] and key==row['item_key'] and key in row['tooltip']
        assert row['minimum']==row['width']
    row=rows['refilled']
    assert row['hover'] and row['visible'] and bag in row['tooltip'] and quick not in row['tooltip'] and 'Tab' in row['tooltip']
    for slot,key in (('ability','C'),('ability-rebound','B')):
        row=rows[slot]
        assert row['visible'] and row['hover'] and cyber in row['tooltip'] and key==row['ability_key'] and key in row['tooltip']
    summary[locale]={'occupied':rows['full']['tooltip'],'remapped':rows['full-rebound']['tooltip'],
                     'only_inventory':rows['refilled']['tooltip'],'ability':rows['ability-rebound']['tooltip'],
                     'hidden_when_empty':not rows['empty-edge']['hover']}
(d/'comparison.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(summary,ensure_ascii=False))