extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const AREA := "res://data/levels/ch2_ledger_front.tres"

var _checks := 0
var _fails := 0
var _out := ""
var _language := "en"


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--language="):
			_language = arg.trim_prefix("--language=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://checkpoint-language-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	if _language == "en":
		await _exercise("en", "Dial to set checkpoint", "Redial to refill ammo",
				"Try again, it's fine.", "Checkpoint set.", "Checkpoint set. Ammo refilled.")
	else:
		await _exercise("ja", "電話をかけて復帰地点を記録", "かけ直して弾薬を補充",
				"もう一度でいい。大丈夫。", "復帰地点を記録しました。", "復帰地点を記録し、弾薬を補充しました。")

	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(1 if _fails else 0)


func _exercise(language: String, first: String, again: String, voice: String, saved: String, refilled: String) -> void:
	Story.set_language(language)
	Story.auto_skip = true
	var main: Node = load("res://game/main.gd").new()
	main.set("_run_store", RunSaveStore.new("user://checkpoint-copy-" + language + ".json"))
	add_child(main)
	await _frames(8)
	main.call("_on_start_requested", GameState.difficulties[1])
	for frame in 360:
		var current := main.get("_screen") as Level
		if current != null and current.is_initialized() and not GameplayLock.is_locked() and not Story.is_cinematic_active():
			break
		await _frames(1)
	main.call("_on_area_requested", AREA)
	var level: Level
	for frame in 600:
		var current := main.get("_screen") as Level
		if current != null and current.data.resource_path == AREA and current.is_initialized() \
				and not GameplayLock.is_locked() and not Story.is_cinematic_active():
			level = current
			break
		await _frames(1)
	if level == null:
		_check(false, "the real main enters the original accounts anteroom")
		main.queue_free()
		await _frames(8)
		return
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		enemy.set_physics_process(false)
	var booth: Checkpoint
	for node: Node in level._entities.get_children():
		if node is Checkpoint:
			booth = node
			break
	_check(booth != null, "the original accounts anteroom contains its real checkpoint")
	if booth == null:
		main.queue_free()
		await _frames(8)
		return
	var player := level.player
	player.global_position = booth.global_position + Vector2(-23, 0)
	player.velocity = Vector2.ZERO
	level.camera.snap_to_target()
	InputBindings._set_device(false, -1)
	await _prompt(booth)
	print("FIRST ", language, " ", booth._prompt._display_text, " visible=", booth._prompt.is_showing())
	_check(booth.can_dial() and booth._prompt.is_showing() and booth._prompt._alpha >= 0.8
			and booth._prompt._display_text == InputBindings.primary_label(&"interact") + " " + first
			and not GameState.has_checkpoint, "first phone guidance matches the active keyboard and unchanged save state")
	await _picture("first-" + language + ".png")

	var notices: Array[String] = []
	var record := func(text: String) -> void: notices.append(text)
	EventBus.toast_requested.connect(record)
	var key := InputEventKey.new()
	key.keycode = KEY_E
	key.physical_keycode = KEY_E
	await _tap(key)
	_check(booth.is_calling(), "the announced keyboard key actually starts the call")
	await _complete(booth)
	print("SAVE ", language, " ", notices)
	_check(booth.activated and GameState.checkpoint_applies(AREA)
				and GameState.checkpoint_position.distance_to(booth.global_position) < 1.0,
				"the call owns the original checkpoint at the original map position")
	_check(notices.has(voice) and notices.has(saved),
			"the genuine call emits the localized spoken line and first completion")
	await _frames(18)
	await _picture("saved-" + language + ".png")
	await _tap(_joy(JOY_BUTTON_RIGHT_SHOULDER))
	# The first recording owns interaction until its actual two lines are acknowledged.
	var recording := false
	for frame in 120:
		if Story._layer._radio_active:
			recording = true
			await _tap(_joy(JOY_BUTTON_A))
		if not Story._layer._radio_active and not GameplayLock.is_locked() and frame > 1:
			break
		await _frames(1)
	print("RECORDING ", language, " seen=", recording, " settled=", GameState.has_flag(&"ch1_recording_heard"),
			" radio=", Story._layer._radio_active, " freeze=", Story._layer.is_radio_frozen())
	_check(not Story._layer.is_radio_frozen() and not get_tree().paused,
			"the booth returns control after the actual first call")
	# Reacquire the same booth in the view after the device changes the aim camera.
	var axis := InputEventJoypadMotion.new()
	axis.axis = JOY_AXIS_RIGHT_X
	axis.axis_value = -0.92
	Input.parse_input_event(axis)
	await _frames(16)
	axis = axis.duplicate()
	axis.axis_value = 0.0
	Input.parse_input_event(axis)
	level.camera.snap_to_target()
	await _prompt(booth)
	print("REDIAL ", language, " ", booth._prompt._display_text, " visible=", booth._prompt.is_showing())
	_check(booth.can_dial() and booth._prompt.is_showing() and booth._prompt._alpha >= 0.8
			and booth._prompt._display_text == InputBindings.primary_label(&"interact") + " " + again,
			"the active booth describes refilling and uses the changed device's key")
	await _picture("again-" + language + ".png")
	var slot := player.loadout.active_slot
	var magazine := player.loadout.mag_in(slot)
	player.loadout.consume_ammo()
	var low := player.loadout.mag_in(slot)
	notices.clear()
	await _tap(_joy(InputBindings.get_joy_button(&"interact") as JoyButton))
	_check(booth.is_calling() and low < magazine, "the announced pad button redials with spent ammunition")
	await _complete(booth)
	print("REFILL ", language, " ", notices, " at ", player.loadout.mag_in(slot))
	_check(player.loadout.mag_in(slot) == magazine and GameState.checkpoint_applies(AREA)
			and notices.has(voice) and notices.has(refilled), "the original redial refills and reports the localized results")
	EventBus.toast_requested.disconnect(record)
	main.queue_free()
	InputBindings.clear_held_inputs()
	await _frames(8)


func _prompt(booth: Checkpoint, limit := 160) -> void:
	for frame in limit:
		if booth._prompt.is_showing() and booth._prompt._alpha >= 0.8 and booth.can_dial():
			return
		await _frames(1)


func _complete(booth: Checkpoint) -> void:
	for frame in 140:
		if not booth.is_calling():
			return
		await _frames(1)


func _joy(button: JoyButton) -> InputEventJoypadButton:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	return event


func _tap(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	if not ok:
		printerr("FAIL: ", message)
