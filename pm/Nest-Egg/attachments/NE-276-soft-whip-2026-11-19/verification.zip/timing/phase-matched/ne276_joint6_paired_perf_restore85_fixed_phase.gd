extends "res://tools/melee_art_probe.gd"
const Original := preload("res://game/fx/soft_whip.gd")
const Candidate := preload("res://work/ne276_joint6_perf_kernel_restore85_fixed_phase.gd")
const PAIRS := 60

func median(values: Array) -> float:
	var sorted := values.duplicate()
	sorted.sort()
	return (float(sorted[sorted.size()/2-1])+float(sorted[sorted.size()/2]))*.5

func _run() -> void:
	Story.auto_skip=true
	await open_arena("res://data/lighting/warehouse_interior.tres",12.0)
	await clear_enemies()
	var camera := get_viewport().get_camera_2d()
	var weapon := load("res://data/weapons/melee/melee_whip.tres") as WeaponData
	await _arm(weapon,camera)
	AimInput.using_gamepad=true
	AimInput._last_stick_dir=Vector2.RIGHT
	player.facing=1
	player.aim_dir=Vector2.RIGHT
	await settle(60)
	var held := player._visual.melee_held()
	level._lighting._lightning_gap = 3600.0
	var old_vsync := DisplayServer.window_get_vsync_mode()
	var old_max := Engine.max_fps
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	Engine.max_fps=0
	var result := {"adapter":RenderingServer.get_video_adapter_name(),"renderer":RenderingServer.get_current_rendering_method(),"pairs_per_condition":PAIRS,"frames_per_sample":PERF_FRAMES,"protocol":"All predeclared pairs; alternating order; existing whole-game median frame sampler; warmed six physics frames after each substitution; same live arena; fixed 60 Hz simulation, measured wall time, physics steps recorded; same natural sustain phase after genuine input for every sample","conditions":{}}
	for condition in ["idle","natural-hold"]:
		var pairs: Array=[]
		var ratios: Array=[]
		var original_ms: Array=[]
		var candidate_ms: Array=[]
		var live_hold_samples := 0
		for round_index in PAIRS:
			var pair := {}
			for enabled in ([false,true] if round_index%2==0 else [true,false]):
				if condition == "natural-hold":
					Input.action_release(&"melee")
					await _arm(weapon, camera)
				var current := held.whip()
				var replacement: SoftWhip=(Candidate if enabled else Original).new()
				replacement._pos=current._pos.duplicate()
				replacement._prev=current._prev.duplicate()
				replacement._length=current._length
				replacement._laid=current._laid
				replacement.floor_y=current.floor_y
				held._whip=replacement
				await settle(6)
				var phase_start := -1.0
				if condition == "natural-hold":
					Input.action_press(&"melee")
					for i in 180:
						if player.melee.hold_mode == "sustain" and player.melee.is_active() and player.melee.time >= 0.3:
							break
						await get_tree().physics_frame
					phase_start = player.melee.time
				var first_tick := Engine.get_physics_frames()
				var elapsed := await _frame_ms()
				var physics_steps := Engine.get_physics_frames() - first_tick
				pair["candidate" if enabled else "before"]={"ms":elapsed,"hold_mode":player.melee.hold_mode,"phase":int(player._melee_phase),"static_memory":OS.get_static_memory_usage(),"physics_steps":physics_steps,"start_sustain_time":phase_start,"finish_sustain_time":player.melee.time}
				if condition=="natural-hold" and player.melee.hold_mode=="sustain":live_hold_samples+=1
			pairs.append(pair)
			original_ms.append(pair.before.ms)
			candidate_ms.append(pair.candidate.ms)
			ratios.append(pair.candidate.ms/maxf(.0001,pair.before.ms))
		var ratio := median(ratios)
		result.conditions[condition]={"pairs":pairs,"before_ms":median(original_ms),"candidate_ms":median(candidate_ms),"paired_ratio":ratio,"no_slower_by_paired_median":ratio<=1.0,"live_hold_samples":live_hold_samples}
		FileAccess.open(out_dir.path_join("performance.json"),FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
		print("NE276_PERF ",condition," ",ratio," live_hold_samples=",live_hold_samples)
	Input.action_release(&"melee")
	DisplayServer.window_set_vsync_mode(old_vsync)
	Engine.max_fps=old_max
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit()
