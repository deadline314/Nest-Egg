from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118')
agent = base / 'solver-repair-agent'
variant = sys.argv[1] if len(sys.argv) > 1 else ''
suffix = {'':'','optimized':'_opt','cached':'_cached','widths':'_widths','three':'_three','two':'_two','wave':'_wave','restore85':'_restore85'}[variant]
fixed_physics = '--fixed-physics' in sys.argv[2:]
phase_matched = '--phase-matched' in sys.argv[2:]
assert not phase_matched or fixed_physics
if fixed_physics:
    suffix += '_fixed'
if phase_matched:
    suffix += '_phase'
out = base / ('paired-perf-joint6' + suffix.replace('_','-'))
out.mkdir()
work = shared / 'work'
original_path = shared / 'game/fx/soft_whip.gd'
candidate = base / f'joint6-{variant}.gd' if variant else agent / 'joint6-frozen/soft_whip.gd'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
if not variant:
    assert sha(candidate) == json.loads((candidate.parent / 'guard.json').read_text())['raw_bytes_SHA256']
source = candidate.read_text(encoding='utf-8')
original = original_path.read_text(encoding='utf-8')
if variant!='widths':
    assert original[original.index('func draw('):] == source[source.index('func draw('):]
step = source[source.index('func step('):source.index('## 畫在 CanvasItem')]
step = step.replace('in ITERATIONS:', 'in BEND_ITERATIONS:')
extra = ''
if variant in ('cached','widths'):
    extra = 'var _prior_bend := PackedVector2Array()\n'
    if variant=='widths':
        extra += 'var _widths := PackedFloat64Array()\n'
    extra += '\nfunc _init() -> void:\n\tsuper._init()\n\t_prior_bend.resize(NODES)\n'
    if variant=='widths':
        extra += source[source.index('\t_widths.resize(NODES)'):source.index('\n\nfunc is_laid()')].rstrip()+'\n'
    extra += '\n'
draw = source[source.index('func draw('):source.index('## 第一次拿出來')] if variant=='widths' else ''
iterations = {'three':3,'two':2}.get(variant,4)
if variant in ('wave', 'restore85'):
    constants = '\n'.join(line for line in source.splitlines() if line.startswith(('const FREE_ITERATIONS', 'const PULLED_ITERATIONS', 'const BEND_HERTZ', 'const BEND_PROJECTION_DAMPING')))
    assert len(constants.splitlines()) == (4 if variant == 'restore85' else 3)
    if variant == 'restore85':
        extra = 'var _prediction := PackedVector2Array()\n\nfunc _init() -> void:\n\tsuper._init()\n\t_prediction.resize(NODES)\n\n'
else:
    assert f'const ITERATIONS := {iterations}' in source
    constants = f'const BEND_ITERATIONS := {iterations}\nconst BEND_HERTZ := 6.0'
override = f'extends SoftWhip\n\n{constants}\n\n' + extra + step.rstrip() + '\n\n' + draw
kernel = f'ne276_joint6_perf_kernel{suffix}.gd'
probe = f'ne276_joint6_paired_perf{suffix}'
script = (work / 'ne276_paired_perf_v2.gd').read_text(encoding='utf-8').replace('ne276_early_payout_cached_v2.gd', kernel)
if fixed_physics:
    assert script.count('var elapsed := await _frame_ms()') == 1
    script = script.replace('var elapsed := await _frame_ms()', 'var first_tick := Engine.get_physics_frames()\n\t\t\t\tvar elapsed := await _frame_ms()\n\t\t\t\tvar physics_steps := Engine.get_physics_frames() - first_tick')
    script = script.replace('"static_memory":OS.get_static_memory_usage()', '"static_memory":OS.get_static_memory_usage(),"physics_steps":physics_steps')
    script = script.replace('same live arena', 'same live arena; fixed 60 Hz simulation, measured wall time, physics steps recorded')
if phase_matched:
    initial_hold = '\t\tif condition=="natural-hold":\n\t\t\tInput.action_press(&"melee")\n\t\t\tawait settle(120)\n'
    assert script.count(initial_hold) == 1
    script = script.replace(initial_hold, '')
    script = script.replace('\tvar held := player._visual.melee_held()', '\tvar held := player._visual.melee_held()\n\tlevel._lighting._lightning_gap = 3600.0')
    script = script.replace('\t\t\t\tvar current := held.whip()', '\t\t\t\tif condition == "natural-hold":\n\t\t\t\t\tInput.action_release(&"melee")\n\t\t\t\t\tawait _arm(weapon, camera)\n\t\t\t\tvar current := held.whip()')
    script = script.replace('\t\t\t\tvar first_tick := Engine.get_physics_frames()', '''				var phase_start := -1.0
				if condition == "natural-hold":
					Input.action_press(&"melee")
					for i in 180:
						if player.melee.hold_mode == "sustain" and player.melee.is_active() and player.melee.time >= 0.3:
							break
						await get_tree().physics_frame
					phase_start = player.melee.time
				var first_tick := Engine.get_physics_frames()''')
    script = script.replace('"physics_steps":physics_steps', '"physics_steps":physics_steps,"start_sustain_time":phase_start,"finish_sustain_time":player.melee.time')
    script = script.replace('physics steps recorded', 'physics steps recorded; same natural sustain phase after genuine input for every sample')
scene = (work / 'ne276_paired_perf_v2.tscn').read_text(encoding='utf-8').replace('ne276_paired_perf_v2.gd', probe + '.gd')
for name, value in [(kernel, override), (probe+'.gd', script), (probe+'.tscn', scene)]:
    for folder in (work, out):
        with (folder / name).open('x', encoding='utf-8', newline='\n') as f:
            f.write(value)
paths = [original_path, candidate, work / kernel, work / (probe+'.gd'), shared / 'data/melee/mono_whip.json', shared / 'game/player/melee_held.gd']
source = {str(p): sha(p) for p in paths}
(out / 'source.json').write_text(json.dumps(source, indent=2) + '\n')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
cmd = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '1280x720', 'res://work/'+probe+'.tscn', '--', '--out=' + str(out)]
if fixed_physics:
    cmd[5:5] = ['--fixed-fps', '60']
(out / 'command.json').write_text(json.dumps(cmd, indent=2) + '\n')
with (out / 'raw.log').open('wb') as log:
    run = subprocess.run(cmd, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=900)
raw = (out / 'raw.log').read_bytes()
record = {'exit': run.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'errors': [line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line], 'source_held': all(sha(Path(p)) == h for p, h in source.items())}
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(record, raw.decode(errors='replace')[-1800:], flush=True)
assert record['exit'] == record['script_errors'] == 0 and not record['errors'] and record['source_held']
perf = json.loads((out / 'performance.json').read_text())
for condition, measures in perf['conditions'].items():
    assert len(measures['pairs']) == 60
    if fixed_physics:
        # Same-phase capture starts inside physics_frame, after that tick was counted.
        already_counted = int(phase_matched and condition == 'natural-hold')
        assert all(sample['physics_steps'] == perf['frames_per_sample'] - already_counted for pair in measures['pairs'] for sample in pair.values())
    if condition == 'natural-hold':
        assert measures['live_hold_samples'] == 120
        if phase_matched:
            assert all(abs(pair['before']['start_sustain_time'] - pair['candidate']['start_sustain_time']) < 0.00001 for pair in measures['pairs'])
            assert all(sample['phase'] == 2 and 0.3 <= sample['start_sustain_time'] < 0.34 and 1.0 < sample['finish_sustain_time'] < 1.11
                       for pair in measures['pairs'] for sample in pair.values())
    print(condition, {k: v for k, v in measures.items() if k != 'pairs'}, flush=True)
