from pathlib import Path
import hashlib
import json

base = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118')
previous = base / 'native-input-regression-source-v3'
fixture = Path('tests/fixtures/soft_whip_native_inputs.json')
data = json.loads((previous / fixture).read_text(encoding='utf-8'))
out = base / 'wave-regression-source'
out.mkdir()
for case in data['cases']:
    folder = base / f'native-{case["side"]}'
    raw = (folder / 'step-inputs.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == case['trace_sha256']
    states = json.loads(raw)
    observed = json.loads((folder / 'grip.json').read_text())['rows']
    key = lambda points: tuple(tuple(point) for point in points)
    mapping = {key(state['after']): index for index, state in enumerate(states)}
    windup = []
    for row in observed:
        if row['rope']['windup'] and row['pose'] in case['moves']:
            index = mapping[key(row['rope']['nodes'])]
            assert index in case['observed_indices']
            windup.append(index)
    assert windup and len(windup) == len(set(windup))
    case['windup_indices'] = sorted(windup)
data['description'] += ' Windup samples label the original motion and preserve its direction wave.'
for relative, text in [
    (fixture, json.dumps(data, ensure_ascii=False, separators=(',', ':')) + '\n'),
    (Path('tests/helpers/soft_whip_native_checks.gd'), Path('work/ne276-soft-whip-native-checks.gd').read_text(encoding='utf-8')),
]:
    destination = out / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding='utf-8', newline='\n')
