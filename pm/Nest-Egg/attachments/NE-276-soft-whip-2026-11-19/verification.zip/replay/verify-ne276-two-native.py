from pathlib import Path
import json
import math
import sys

base = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118')
candidate = sys.argv[1] if len(sys.argv) > 1 else 'two'
editions = {'before': base / 'joint6-native-ab-three/before', candidate: base / f'joint6-native-ab-{candidate}/{candidate}'}
moves = ('lash', 'return_lash', 'orbit')
reports = []
failed_moves = []
for edition, folder in editions.items():
    for side in (-1, 1):
        folder_side = folder / str(side)
        data = json.loads((folder_side / 'grip.json').read_text(encoding='utf-8'))
        receipt = json.loads((folder_side / 'result.json').read_text())
        assert receipt['source_held'] and not receipt['errors']
        assert receipt['observations'] == len(data['rows']) == 881
        assert len(data['shots']) == receipt['pngs'] == 109
        assert data['side'] == side
        cases = {name: [] for name in moves}
        overstraight = []
        max_ratio = 0.0
        for row in data['rows']:
            rope = row['rope']
            nodes = rope['nodes']
            assert len(nodes) == 20 and all(math.isfinite(v) for point in nodes for v in point)
            arc = sum(math.dist(a,b) for a,b in zip(nodes,nodes[1:]))
            assert arc > 0.0
            dx, dy = (b - a for a, b in zip(nodes[0], nodes[-1]))
            chord = math.hypot(dx, dy)
            ratio = chord / arc
            assert abs(rope['visible_ratio'] - ratio) < 0.000001
            assert max(point[1] for point in nodes) <= rope['floor'] + 0.01
            max_ratio = max(max_ratio, ratio)
            if ratio >= 0.99:
                overstraight.append((row['pose'], row['frame'], ratio))
            if row['pose'] in moves:
                bow = max(abs((x - nodes[0][0]) * dy - (y - nodes[0][1]) * dx) for x, y in nodes)
                wave = (nodes[4][0] - nodes[0][0]) * side > 2 and dx * side < -2
                cases[row['pose']].append((row, bow / (max(chord, 0.000001) * arc), wave))
        assert len(overstraight) == receipt['visible_failures']
        measures = {}
        for name, samples in cases.items():
            active = [(row, bow) for row, bow, _wave in samples if row['rope']['active']]
            assert active
            recovery = sum(row['pose'] == name + ':recovery' for row in data['rows'])
            assert recovery == 60
            min_bow = min(bow for _, bow in active)
            gap_ratio = min(math.dist(row['rope']['nodes'][-1], row['rope']['target']) / row['rope']['range'] for row, _bow in active)
            wave = any(wave for row, _bow, wave in samples if row['rope']['windup'])
            measures[name] = {'frames': len(samples), 'active': len(active), 'recovery': recovery, 'min_bow_over_arc': min_bow, 'nearest_tip_gap_over_range': gap_ratio, 'wave_seen': wave}
            if edition == candidate and (min_bow < 0.04 or gap_ratio > 0.15 or not wave):
                failed_moves.append((side, name, measures[name]))
        life = {entry['case']: entry for entry in data['lifecycle']}
        assert life['interrupted']['tip_below_palm'] > 4
        assert not life['switched-out']['laid'] and not life['switched-out']['visible']
        assert life['switched-back']['laid'] and life['switched-back']['tip_palm_gap'] < 50
        for shot, framed in zip(data['shots'], data['framing'], strict=True):
            assert shot['name'] == framed['name'] and framed['player_held']
            x, y, w, h = framed['screen_bounds']
            assert x >= -0.02 and y >= -0.02 and x+w <= 640.02 and y+h <= 360.02
        assert edition == 'before' or not overstraight
        reports.append({'edition': edition, 'side': side, 'max_ratio': max_ratio, 'overstraight': overstraight, 'moves': measures})
path = base / f'joint6-native-ab-{candidate}/independent.json'
with path.open('x', encoding='utf-8') as report:
    json.dump(reports, report, indent=2)
print(json.dumps(reports, ensure_ascii=False))
assert not failed_moves, failed_moves
