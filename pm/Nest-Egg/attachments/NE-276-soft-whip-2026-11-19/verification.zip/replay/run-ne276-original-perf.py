from pathlib import Path
import hashlib
import json
import subprocess
import sys

base = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118')
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
path = 'game/fx/soft_whip.gd'
solver = shared / path
before = (base / 'joint6-native-ab-three/before-solver.gd').read_bytes()
candidate = (base / 'joint6-wave.gd').read_bytes()
released = Path('D:/NestEggVerification/evidence-20261117/ne267-candidate-20261118/medic-transport-v1/root-s13-20261119/published-source.json')
assert hashlib.sha256(before).hexdigest() == json.loads(released.read_text())[path]
assert solver.read_bytes() == candidate and (Path.cwd() / path).read_bytes() == candidate
try:
    solver.write_bytes(before)
    modes = (['--fixed-physics', '--phase-matched'],) if '--phase-matched' in sys.argv else (['--fixed-physics'], [])
    for args in modes:
        assert solver.read_bytes() == before
        subprocess.run([sys.executable, '-B', '-X', 'utf8', 'work/run-ne276-joint6-perf.py', 'restore85', *args], check=True)
finally:
    assert solver.read_bytes() == before
    solver.write_bytes(candidate)
