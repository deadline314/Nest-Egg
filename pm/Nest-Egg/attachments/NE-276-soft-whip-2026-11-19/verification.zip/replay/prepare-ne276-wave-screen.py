from pathlib import Path
import json

base = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118')
agent = base / 'solver-repair-agent'
work = agent / 'runtime/work'
projection = '--projection' in __import__('sys').argv
version = 19 if projection else 14
out = base / f'wave-screen-v{version}'
prefix = f'whip_wave_v{version}'
out.mkdir()
baseline = base / 'joint6-native-ab-three/before'
candidate = base / 'joint6-native-ab-two/two'

for kind, folder in [('before', baseline), ('two', candidate)]:
    for side in (-1, 1):
        source = folder / str(side)
        rows = json.loads((source / 'step-inputs.json').read_text())
        poses = json.loads((source / 'grip.json').read_text())['rows']
        key = lambda points: tuple(tuple(point) for point in points)
        matches = {key(row['after']): index for index, row in enumerate(rows)}
        observations = []
        for row in poses:
            rope = row['rope']
            index = matches[key(rope['nodes'])]
            observations.append({'index': index, 'pose': row['pose'], 'frame': row['frame'], 'windup': rope['windup'], 'active': rope['active'], 'range': rope['range']})
        assert len(rows) == 1954 and len(observations) == len({row['index'] for row in observations}) == 881
        (out / f'{kind}-{side}-observations.json').write_text(json.dumps({'side': side, 'observations': observations}) + '\n')

def subclass(source):
    # Inherit the allocation and geometry methods. Only replace the live physics kernel.
    begin = source.index('func step(')
    stop = source.index('## 畫在 CanvasItem', begin)
    return 'extends SoftWhip\n\n' + source[begin:stop].replace('_solve_bend(', '_solve_wave_screen_bend(')

two = (base / 'joint6-two.gd').read_text(encoding='utf-8')
old = (baseline.parent / 'before-solver.gd').read_text(encoding='utf-8')
scripts = {'before': subclass(old).replace('in ITERATIONS:', 'in 8:'),
           'two': subclass(two).replace('in ITERATIONS:', 'in 2:').replace('BEND_HERTZ', '6.0')}
for active_iters, active_hz in ((4, 0), (6, 0), (8, 0), (3, 2), (4, 2), (4, 4), (2, 4)):
    name = f'a{active_iters}f{active_hz}'
    text = subclass(two).replace('in ITERATIONS:', f'in ({active_iters} if pull > 0.0 else 2):')
    if active_hz == 0:
        text = text.replace('if dt > 0.0:\n\t\t\t\t_solve_wave_screen_bend', 'if dt > 0.0 and pull <= 0.0:\n\t\t\t\t_solve_wave_screen_bend').replace('BEND_HERTZ', '6.0')
    else:
        text = text.replace('BEND_HERTZ', f'({float(active_hz)} if pull > 0.0 else 6.0)')
    scripts[name] = text
if projection:
    scripts = {name: scripts[name] for name in ('before', 'two', 'a4f0')}
    for name in ('restore35', 'restore85', 'restore100'):
        scripts[name] = (base / f'idle-screen-v18/whip_idle18_{name}.gd').read_text(encoding='utf-8')

for name, source in scripts.items():
    (work / f'{prefix}_{name}.gd').write_text(source, encoding='utf-8')
    (out / f'{prefix}_{name}.gd').write_text(source, encoding='utf-8')

probe = (work / 'repair_cpu_v12.gd').read_text(encoding='utf-8')
line = next(line for line in probe.splitlines() if 'var scripts :=' in line)
entries = ','.join(f'"{name}":preload("res://work/{prefix}_{name}.gd")' for name in scripts)
probe = probe.replace(line, '\tvar scripts := {' + entries + '}')
probe = probe.replace('var observations := {}', 'var side := int(mapped.side)\n\tvar observations := {}')
probe = probe.replace('"free_turn_peak":{},', '"free_turn_peak":{},"wave_seen":false,')
line = '\t\t\tvar ratio := chord.length()/maxf(.001,arc)'
assert line in probe
probe = probe.replace(line, '\t\t\tif bool(observation.windup) and (rope.node(4).x-rope.node(0).x)*side>2.0 and chord.x*side < -2.0: metric.wave_seen=true\n' + line)
scene = (work / 'repair_cpu_v12.tscn').read_text().replace('repair_cpu_v12.gd', prefix + '.gd')
(work / (prefix + '.gd')).write_text(probe, encoding='utf-8')
(work / (prefix + '.tscn')).write_text(scene, encoding='utf-8')
(out / (prefix + '.gd')).write_text(probe, encoding='utf-8')
