from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

base = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118')
version = 19 if '--projection' in sys.argv else 14
out = base / f'wave-screen-v{version}'
prefix = f'whip_wave_v{version}'
runtime = base / 'solver-repair-agent/runtime'
sources = sorted((runtime / 'work').glob(prefix + '*')) + [runtime / 'game/fx/soft_whip.gd', runtime / 'work/regression_factory.gd']
snapshot = lambda: {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources if path.is_file()}
guard = snapshot()
folders = {'before': base / 'joint6-native-ab-three/before', 'two': base / 'joint6-native-ab-two/two'}
moves = ('lash', 'return_lash', 'orbit')
aggregate = {}
for variant, folder in folders.items():
    for side in (-1, 1):
        output = out / f'{variant}-{side}'
        output.mkdir()
        env = os.environ.copy()
        for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
            env[key] = str(output / 'profile' / key)
        report = output / 'report.json'
        args = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', str(runtime),
                '--audio-driver', 'Dummy', '--quit-after', '600', f'res://work/{prefix}.tscn', '--',
                f'--trace={folder / str(side) / "step-inputs.json"}', f'--observations={out / f"{variant}-{side}-observations.json"}',
                f'--out={report}', f'--reference={variant}']
        (output / 'command.json').write_text(json.dumps(args, indent=2) + '\n')
        with (output / 'raw.log').open('wb') as log:
            run = subprocess.run(args, env=env, cwd=runtime, stdout=log, stderr=subprocess.STDOUT, timeout=300)
        raw = (output / 'raw.log').read_bytes()
        if run.returncode != 0 or b'ERROR:' in raw or snapshot() != guard:
            raise RuntimeError((variant, side, run.returncode, raw.decode(errors='replace')[-1800:]))
        data = json.loads(report.read_text())
        assert data[variant]['reference_parity'] == data[variant]['prev_parity'] == 0
        for name, row in data.items():
            values = aggregate.setdefault(name, {})
            missing = [move for move in moves if not row['poses'][move]['wave_seen']]
            values[f'{variant}/{side}'] = {'replay': row['regression_failures'], 'physics': row['dataset_failures'], 'missing_wave': missing}
        print(variant, side, [(name, v[f'{variant}/{side}']) for name, v in aggregate.items()], flush=True)
(out / 'aggregate.json').write_text(json.dumps(aggregate, indent=2) + '\n')
