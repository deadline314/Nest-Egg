from pathlib import Path
import hashlib
import json
import sys

from PIL import Image, ImageDraw, ImageFont

base = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118')
candidate = sys.argv[1] if len(sys.argv) > 1 else 'two'
out = base / f'joint6-native-ab-{candidate}/comparisons'
out.mkdir()
origins = (base / 'joint6-native-ab-three/before', base / f'joint6-native-ab-{candidate}/{candidate}')
font = ImageFont.truetype('C:/Windows/Fonts/consola.ttf', 15)
manifest = []
for side in (-1, 1):
    names = sorted(path.name for path in (origins[0] / str(side)).glob('*.png'))
    assert len(names) == 109 and names == sorted(path.name for path in (origins[1] / str(side)).glob('*.png'))
    for number, start in enumerate(range(0, len(names), 3), 1):
        subset = names[start : start + 3]
        canvas = Image.new('RGB', (1280, 384 * len(subset) + 24), (24, 24, 24))
        draw = ImageDraw.Draw(canvas)
        draw.text((8, 5), f'Facing {side:+d} | native 640x360 | Before (left), After (right)', font=font, fill='white')
        for row, name in enumerate(subset):
            for col, origin in enumerate(origins):
                with Image.open(origin / str(side) / name) as frame:
                    assert frame.size == (640, 360)
                    canvas.paste(frame, (col * 640, 48 + row * 384))
            draw.text((8, 26 + row * 384), name, font=font, fill=(245, 230, 180))
        file = out / f'{"left" if side == -1 else "right"}-{number:02}.png'
        canvas.save(file)
        manifest.append({'path': file.name, 'side': side, 'frames': subset, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
