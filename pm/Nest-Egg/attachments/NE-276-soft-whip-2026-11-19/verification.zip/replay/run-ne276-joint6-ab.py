from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118')
agent = base / 'solver-repair-agent'
runtime = agent / 'runtime'
variant=sys.argv[1] if len(sys.argv)>1 else 'optimized'
out = base / ('joint6-native-ab-'+variant)
out.mkdir()
solver = runtime / 'game/fx/soft_whip.gd'
probe = runtime / 'work/joint6_native.gd'
old_solver, old_probe = solver.read_bytes(), probe.read_bytes()
assert old_solver == (agent / 'joint6-frozen/soft_whip.gd').read_bytes()
fixed = base / f'joint6-{variant}.gd'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
editions=[('before',root/'game/fx/soft_whip.gd'),(variant,fixed)] if '--candidate-only' not in sys.argv else [(variant,fixed)]
for edition, source_path in editions:
    (out / (edition+'-solver.gd')).write_bytes(source_path.read_bytes())
try:
    for edition, _source in editions:
        solver.write_bytes((out / (edition+'-solver.gd')).read_bytes())
        label = '發佈主線基準' if edition == 'before' else '共同約束候選 '+variant
        probe.write_bytes(old_probe.decode().replace('私有6Hz共同約束候選', label).encode())
        for side in (-1, 1):
            dest = out / edition / str(side)
            dest.mkdir(parents=True)
            env = os.environ.copy()
            for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
                env[key] = str(dest / 'profile' / key)
            cmd = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-B',str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(runtime),'--audio-driver','Dummy','--rendering-method','forward_plus','--rendering-driver','vulkan','--resolution','640x360','--fixed-fps','60','--quit-after','7200','res://work/joint6_native.tscn','--','--out='+str(dest),'--facing='+str(side)]
            (dest/'command.json').write_text(json.dumps(cmd, indent=2)+'\n')
            names = ['game/fx/soft_whip.gd','game/player/melee_held.gd','work/joint6_native.gd','work/ne276_step_record.gd','data/melee/mono_whip.json']
            source = {n:sha(runtime/n) for n in names}
            with (dest/'raw.log').open('wb') as log:
                r = subprocess.run(cmd, cwd=runtime, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=600)
            raw = (dest/'raw.log').read_bytes()
            native = json.loads((dest/'ordering-summary.json').read_text(encoding='utf-8'))
            trace = json.loads((dest/'step-inputs.json').read_text(encoding='utf-8'))
            record = {'exit':r.returncode,'errors':[s.decode(errors='replace') for s in raw.splitlines() if b'ERROR:' in s],'source_held':all(sha(runtime/n)==h for n,h in source.items()),'sources':source,'observations':native['observed'],'visible_failures':native['visible_failures'],'inputs':len(trace),'pngs':len(list(dest.glob('*.png')))}
            if edition=='optimized':
                prior=json.loads((agent/'joint6-native'/str(side)/'step-inputs.json').read_text(encoding='utf-8'))
                record['frozen_trace_exact']=trace==prior
            (dest/'result.json').write_text(json.dumps(record,indent=2)+'\n')
            print(edition,side,{k:v for k,v in record.items() if k!='sources'},flush=True)
            assert r.returncode in (0,1) and not record['errors'] and record['source_held']
            assert record['observations']==881 and record['pngs']==109
            if edition!='before':
                assert r.returncode==0 and native['visible_failures']==0
            if edition=='optimized':
                assert record['frozen_trace_exact']
finally:
    solver.write_bytes(old_solver)
    probe.write_bytes(old_probe)
