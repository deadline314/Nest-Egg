from pathlib import Path
import json

base = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118')
variant = 'restore85'
replay = json.loads((base / 'wave-screen-v19/aggregate.json').read_text())[variant]
assert len(replay) == 4 and all(not errors for row in replay.values() for errors in row.values())
settle = json.loads((base / 'idle-screen-v18/report.json').read_text())[variant]
assert len(settle) == 3 and all(row['checks'] == 14 and not row['failures'] for row in settle)
source = (base / 'joint6-wave.gd').read_text(encoding='utf-8')
private = (base / f'idle-screen-v18/whip_idle18_{variant}.gd').read_text(encoding='utf-8')
step = private[private.index('func step('):]
step = step.replace('SCREEN_', '').replace('_solve_idle_screen_bend(', '_solve_bend(')
step = step.replace('else 0.02, dt', 'else KEEP_PER_SECOND_FREE, dt')
step = step.replace('for i in range(1,NODES):', 'for i in range(1, NODES):')
step = step.replace('\t\tif bend:\n\t\t\tfor i in range(1, NODES):',
                    '\t\t# 位置修正只少量回饋到速度，讓鬆弛的鞭身靜置後不再彈跳。\n\t\tif bend:\n\t\t\tfor i in range(1, NODES):')
step = step.replace(') * 0.85', ') * BEND_PROJECTION_DAMPING')
candidate = source[:source.index('func step(')] + step + source[source.index('## 畫在 CanvasItem'):]
candidate = candidate.replace('const BEND_HERTZ := 6.0', 'const BEND_HERTZ := 6.0\nconst BEND_PROJECTION_DAMPING := 0.85')
candidate = candidate.replace('var _prev := PackedVector2Array()', 'var _prev := PackedVector2Array()\nvar _prediction := PackedVector2Array()')
candidate = candidate.replace('\t_prev.resize(NODES)', '\t_prev.resize(NODES)\n\t_prediction.resize(NODES)')
assert candidate.count('_prediction[i]') == 2 and candidate.count('BEND_PROJECTION_DAMPING') == 2
assert candidate[candidate.index('func draw('):] == source[source.index('func draw('):]
with (base / f'joint6-{variant}.gd').open('x', encoding='utf-8', newline='\n') as target:
    target.write(candidate)
