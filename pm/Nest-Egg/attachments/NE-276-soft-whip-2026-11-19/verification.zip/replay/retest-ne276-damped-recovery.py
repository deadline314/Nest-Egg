from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/ne276-curvature-20261118')
prior = base / 'wave-integration'
out = base / 'restore85-integration'
out.mkdir()
reference = 'fdb67077526210eb319372e0d36ba62b6d89f704'
solver = 'game/fx/soft_whip.gd'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
snapshot = lambda project, names: {name: sha(project / name) for name in names}
guard = json.loads((prior / 'source.json').read_text())
paths = json.loads((prior / 'paths.json').read_text())
assert json.loads((prior / 'verification.json').read_text()) == {'exit':1,'errors':[],'source_held':True}
assert snapshot(shared, guard) == guard and snapshot(root, paths) == {name:guard[name] for name in paths}
assert all(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=project).decode().strip() == reference for project in (root, shared))
candidate = base / 'joint6-restore85.gd'
digest = sha(candidate)
for side in (-1, 1):
    native = json.loads((base / f'joint6-native-ab-restore85/restore85/{side}/result.json').read_text())
    assert native['exit'] == 0 and not native['errors'] and native['source_held'] and native['sources'][solver] == digest
proof = json.loads((base / 'paired-perf-joint6-restore85/performance.json').read_text())
assert all(case['no_slower_by_paired_median'] for case in proof['conditions'].values())
assert json.loads((base / 'paired-perf-joint6-restore85/source.json').read_text())[str(candidate)] == digest
for project in (shared, root):
    (project / solver).write_bytes(candidate.read_bytes())
guard[solver] = digest
(out / 'source.json').write_text(json.dumps(guard, indent=2) + '\n')
(out / 'paths.json').write_text(json.dumps(paths, indent=2) + '\n')

def run(name, command):
    evidence = out / name
    evidence.mkdir()
    env = os.environ.copy()
    env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', SHARDS='6', LOG_DIR=str(evidence / 'shards'))
    for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
        env[key] = str(evidence / 'profile' / key)
    (evidence / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
    with (evidence / 'raw.log').open('wb') as raw:
        process = subprocess.run(command, cwd=shared, env=env, stdout=raw, stderr=subprocess.STDOUT, timeout=2400)
    raw = (evidence / 'raw.log').read_bytes()
    receipt = {'exit': process.returncode, 'errors': [line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line],
               'source_held': snapshot(shared, guard) == guard and snapshot(root, paths) == {name:guard[name] for name in paths}}
    (evidence / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(name, receipt, raw.decode(errors='replace')[-1650:], flush=True)
    assert receipt == {'exit':0,'errors':[],'source_held':True}
    return receipt

godot = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
         'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared), '--headless', '--audio-driver', 'Dummy']
run('candidate', godot + ['--quit-after', '600', 'res://work/ne276_regression.tscn', '--', '--out=' + str(out / 'candidate/report.json')])
assert json.loads((out / 'candidate/report.json').read_text()) == {'checks':43,'failures':[]}
run('import', godot + ['--editor','--quit'])
official = run('official', ['C:/Program Files/Git/bin/bash.exe', '-c', f'python3() {{ python "$@"; }}; export -f python3; tools/run_tests_changed.sh {reference}'])
(out / 'verification.json').write_text(json.dumps(official, indent=2) + '\n')
