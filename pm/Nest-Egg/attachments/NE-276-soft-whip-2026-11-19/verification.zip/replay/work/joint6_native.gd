extends "res://work/ne276-native-rope-20261118.gd"
const Recorder := preload("res://work/ne276_step_record.gd")
var _visible_failures := 0
var _hold_active := 0

func observe(weapon_id: String, pose: String, frame: int) -> void:
	super.observe(weapon_id,pose,frame)
	rows[-1]["record_index"] = Recorder.captured.size() - 1
	var rope := player._visual.melee_held().whip()
	var arc := 0.0
	for i in range(1,SoftWhip.NODES): arc+=rope.node(i-1).distance_to(rope.node(i))
	var ratio := rope.node(0).distance_to(rope.tip())/maxf(.001,arc)
	rows[-1].rope["visible_ratio"] = ratio
	if ratio>=.99:
		_visible_failures+=1
		_failures+=1

func observe_lifecycle(camera: Camera2D) -> void:
	await super.observe_lifecycle(camera)
	var weapon := load("res://data/weapons/melee/melee_whip.tres") as WeaponData
	await arm_side(weapon,camera)
	Input.action_press(&"melee")
	for frame in 220:
		await step()
		observe("whip","natural-hold",frame)
		if player.melee.hold_mode=="sustain" and player._melee_phase==Player.MeleePhase.ACTIVE:
			_hold_active+=1
		if frame in [0,40,80,120,160,200,219]: await photo("whip-natural-hold-%03d" % frame,camera)
	Input.action_release(&"melee")
	for frame in 120:
		await step()
		observe("whip","natural-release",frame)
		if frame % 3 == 0: await photo("whip-release-%03d" % frame,camera)
	await photo("whip-natural-released",camera)
	if _hold_active<=100 or player._melee_phase!=Player.MeleePhase.NONE or player.melee.hold_mode!="":
		_failures+=1
	var result := {"source_mode":"私有6Hz共同約束候選；Recorder從首次new建立，呼叫super.step；真實640x360 PNG；非正式main","observed":rows.size(),"visible_failures":_visible_failures,"hold_active_frames":_hold_active,"input":"Synthetic Input.action_press and release; no physical-controller or human claim","initial_40_frames":"從首次建立即私有6Hz共同約束候選；從第一次step開始記錄，初始40格沒有照片"}
	FileAccess.open(out_dir.path_join("ordering-summary.json"),FileAccess.WRITE).store_string(JSON.stringify(result,"\t"))
	print("NE276_ORDERING ",JSON.stringify(result))

	var file := FileAccess.open(out_dir.path_join("step-inputs.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(Recorder.captured))
	file.close()


