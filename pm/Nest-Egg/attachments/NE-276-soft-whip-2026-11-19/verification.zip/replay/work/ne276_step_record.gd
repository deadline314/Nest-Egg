extends SoftWhip
## Private numerical observation only; calls the unchanged production step.
static var captured: Array[Dictionary] = []

func _vectors(points: PackedVector2Array) -> Array:
	var output := []
	for point in points: output.append([point.x, point.y])
	return output

func step(delta: float, root: Vector2, handle_dir: Vector2, length_target: float, tip_target: Vector2, pull: float) -> void:
	var before := {"pos": _vectors(_pos), "prev": _vectors(_prev), "length": _length, "laid": _laid}
	super.step(delta, root, handle_dir, length_target, tip_target, pull)
	var arc := 0.0
	for i in range(1, NODES): arc += _pos[i-1].distance_to(_pos[i])
	captured.append({"before":before, "delta":delta, "root":[root.x,root.y], "handle_dir":[handle_dir.x,handle_dir.y], "length_target":length_target, "tip_target":[tip_target.x,tip_target.y], "pull":pull, "floor":floor_y,
		"after":_vectors(_pos), "after_length":_length, "visible_ratio":_pos[0].distance_to(_pos[NODES-1])/maxf(.001,arc)})
