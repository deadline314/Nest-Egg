import json
from pathlib import Path
import sys
import subprocess
import re

root = Path.cwd()
base = Path(__file__).resolve().parent
overlay = base / "overlay"
chapters = ["ch1_kasa", "ch2_heron", "ch3_clearwater"]
sources = {chapter: f"tools/story/i18n/{chapter}.json" for chapter in chapters}
outputs = {chapter: f"data/story/{chapter}.json" for chapter in chapters}
read = lambda path: json.loads(path.read_bytes())
drafts = read(base / "drafts.json")
baseline = (base / "baseline.txt").read_text().strip()
def original(path):
    return subprocess.check_output(["git", "show", f"{baseline}:{path}"], cwd=root).decode("utf-8")

old_docs = {chapter: json.loads(original(path)) for chapter, path in outputs.items()}
old_tables = {chapter: original(path) for chapter, path in sources.items()}
tables = {chapter: json.loads(text) for chapter, text in old_tables.items()}
changes = {}

def write(path, data, indent=1):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=indent) + "\n", encoding="utf-8", newline="\n")

for row in read(base / "overflow.json") + read(base / "near-limit.json"):
    chapter, language, flag = (row[k] for k in ("chapter", "language", "complete_flag"))
    matches = [(i, j, step) for i, quest in enumerate(old_docs[chapter]["quests"]) if quest["id"] == row["quest"]
               for j, step in enumerate(quest["steps"]) if step["complete_flag"] == flag]
    assert len(matches) == 1, row
    qi, si, step = matches[0]
    field = f"title_{language}"
    before = row["text"].removeprefix("◎ ")
    after = drafts[language][flag]
    assert before == step[field] and before != after, row
    key = (chapter, "quests", qi, "steps", si, field)
    assert key not in changes and tables[chapter][step["title"]][language] == before, (row, step)
    tables[chapter][step["title"]][language] = after
    changes[key] = (before, after)
assert len(changes) == sum(map(len, drafts.values())) == 58

for chapter, path in sources.items():
    original_text = old_tables[chapter]
    for label, translations in json.loads(original_text).items():
        for language, old in translations.items():
            new = tables[chapter][label][language]
            if old == new:
                continue
            quoted_label, old_text, new_text, key = (json.dumps(item, ensure_ascii=False) for item in (label, old, new, language))
            entry = re.compile(rf'(?m)(^ +{re.escape(quoted_label)}: \{{\n(?: +[^\n]+\n){{0,2}}? +{key}: ){re.escape(old_text)}(?=,?$)')
            original_text, count = entry.subn(lambda m: m.group(1) + new_text, original_text)
            assert count == 1, (label, language)
    assert json.loads(original_text) == tables[chapter]
    (overlay / path).write_text(original_text, encoding="utf-8", newline="\n")

sys.dont_write_bytecode = True
sys.path.insert(0, str(root / "tools/story"))
import story_i18n
import ch1_runtime_backend
import build_ch2_story
import build_ch3_story
from chapter_compiler import write_chapter

def compile_docs(folder, table_dir):
    story_i18n.TABLE_DIR = table_dir
    ch1 = ch1_runtime_backend.compile_document()
    ch1["chapter"]["languages"] = ["zh", *story_i18n.LANGUAGES]
    story_i18n.apply(ch1, story_i18n.load_table(story_i18n.table_path("ch1_kasa")))
    write(folder / outputs["ch1_kasa"], ch1)
    for chapter, module in [("ch2_heron", build_ch2_story), ("ch3_clearwater", build_ch3_story)]:
        assert not write_chapter(module.spec(), folder / outputs[chapter])

def deltas(old, new, path):
    if old == new:
        return {}
    if isinstance(old, dict) and isinstance(new, dict) and old.keys() == new.keys():
        return {k: v for key in old for k, v in deltas(old[key], new[key], (*path, key)).items()}
    if isinstance(old, list) and isinstance(new, list) and len(old) == len(new):
        return {k: v for i, pair in enumerate(zip(old, new)) for k, v in deltas(*pair, (*path, i)).items()}
    return {path: (old, new)}

old_dir = base / "old-tables"
old_dir.mkdir(exist_ok=True)
for chapter, contents in old_tables.items():
    (old_dir / (chapter + ".json")).write_text(contents, encoding="utf-8")
compile_docs(base / "old-generated", old_dir)
compile_docs(base / "new-generated", overlay / "tools/story/i18n")
compiled_changes = {}
existing_drift = {}
for chapter, path in outputs.items():
    old_generated = read(base / "old-generated" / path)
    new_generated = read(base / "new-generated" / path)
    compiled_changes.update(deltas(old_generated, new_generated, (chapter,)))
    existing_drift[chapter] = len(deltas(old_docs[chapter], old_generated, (chapter,)))
assert compiled_changes == changes, (compiled_changes.keys() - changes.keys(), changes.keys() - compiled_changes.keys())
# Carry only these verified changes if a preexisting builder difference is unrelated.
for chapter, path in outputs.items():
    shipped = json.loads(original(path))
    for (owner, collection, qi, steps, si, field), (before, after) in changes.items():
        if owner == chapter:
            assert shipped[collection][qi][steps][si][field] == before
            shipped[collection][qi][steps][si][field] = after
    write(overlay / path, shipped)

proof = [{"path": key, "old": pair[0], "new": pair[1]} for key, pair in changes.items()]
write(base / "compile-proof.json", {"count": len(changes), "changes": proof, "prior_builder_differences": existing_drift}, 2)
print("Verified", len(changes), "localized quest steps. Prior builder differences:", existing_drift)
