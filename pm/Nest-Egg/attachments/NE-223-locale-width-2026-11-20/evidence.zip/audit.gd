extends Node

var _out := ""
var _measured: Array[Dictionary] = []

func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()

func _run() -> void:
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	var catalog := QuestCatalog.new()
	catalog.load_story_sources()
	if _out.is_empty() or catalog.quests.is_empty() or not catalog.issues.is_empty():
		push_error("quest source unavailable: "+str(catalog.issues))
		get_tree().quit(2)
		return
	var level := Level.new()
	level.configure(load("res://data/levels/ch2_rooftop.tres") as LevelData)
	add_child(level)
	await _frames(12)
	var label: Label = level.hud.quest_guidance._label
	if not is_instance_valid(label):
		push_error("original HUD label not available")
		get_tree().quit(2)
		return
	for language: String in ["zh","ja","en"]:
		Story.set_language(language)
		for style: String in ["pixel","smooth"]:
			Settings.set_ui_font(style)
			for factor: float in [1.0,1.2]:
				Settings.set_ui_text_scale(factor)
				await _frames(6)
				var font := label.get_theme_font(&"font")
				var font_size := label.get_theme_font_size(&"font_size")
				var available := label.size.x
				for quest: Dictionary in catalog.quests:
					for step: Dictionary in quest["steps"]:
						var text := "◎ " + QuestCatalog.display_text(step,"title")
						var needed := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
						_measured.append({"language":language,"font":style,"factor":factor,"quest":quest["id"],
							"chapter":quest["chapter"],"kind":quest["kind"],"complete_flag":step["complete_flag"],
							"available":available,"needed":needed,"text":text,"location":step["location"]})
	var f := FileAccess.open(_out.path_join("data.json"),FileAccess.WRITE)
	if f == null:
		get_tree().quit(2)
		return
	f.store_string(JSON.stringify(_measured,"\t"))
	f.close()
	print("QUEST_WIDTH ", _measured.size())
	Story.reset_active_presentation(&"route")
	AudioRelease.begin_shutdown()
	level.queue_free()
	await _frames(5)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)

func _frames(count: int) -> void:
	for i in count:
		await get_tree().process_frame

