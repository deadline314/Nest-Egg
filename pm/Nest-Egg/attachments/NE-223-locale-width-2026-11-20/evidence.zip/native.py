from pathlib import Path
from hashlib import sha256
import json, os, re, shutil, subprocess, sys

p = Path(__file__).resolve().parent
root = Path.cwd()
project = Path(sys.argv[2]).resolve()
mode = sys.argv[1]
out = p / ('native-' + mode)
out.mkdir()
source = root / 'work/ne97-campaign-route-20261119'
cases = [
    ('handoff', 'native-handoff-v1', 'ch1_handoff', 'ch1_disk_receipt_taken', 'en', '1280x720'),
    ('loading', 'native-ch2-loading-ground-v2', 'ch2_loading', 'ch2_evidence_collection', 'en', '1280x720'),
    ('lift', 'native-ch3-pump-v2', 'ch3_pump', 'ch3_freight_ready', 'ja', '1920x1080'),
]
results = {}
for name, directory, area, flag, locale, resolution in cases:
    case = out / name
    save = case / 'save'
    save.mkdir(parents=True)
    initial = source / directory / 'save' / 'slot.json'
    shutil.copyfile(initial, save / initial.name)
    env = os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        (case / key).mkdir()
        env[key] = str(case / key)
    args = [sys.executable, '-B', str(root/'tools/comfyui/gpu_lock.py'), '--',
            'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(project),
            '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
            '--resolution', resolution, '--fixed-fps', '60', '--quit-after', '600',
            str(p/'guidance.tscn'), '--', '--out='+str(case), '--save-dir='+str(save), '--area='+area,
            '--goal='+flag, '--language='+locale]
    if mode.startswith('after'):
        args.append('--candidate')
    with (case/'engine.log').open('wb') as log:
        run = subprocess.run(args, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=100)
    raw = (case/'engine.log').read_text(encoding='utf-8', errors='replace')
    faults = [line for line in raw.splitlines() if re.search(r'^(?:SCRIPT )?ERROR:|Parse Error|^FAIL |leaked at exit',line)]
    result = case / 'result.json'
    data = json.loads(result.read_bytes()) if result.is_file() else {}
    results[name] = {'source_save': directory, 'source_save_sha256': sha256(initial.read_bytes()).hexdigest(),
                     'exit': run.returncode, 'faults': faults, 'result': data}
    print(name, results[name], flush=True)
    (out/'receipt.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
