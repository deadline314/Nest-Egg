extends "res://tools/ch1_flow_probe.gd"

var _save := ""
var _area := ""
var _flag := ""
var _language := ""
var _candidate := false
var _main: Node


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_save = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--area="):
			_area = arg.trim_prefix("--area=")
		elif arg.begins_with("--goal="):
			_flag = arg.trim_prefix("--goal=")
		elif arg.begins_with("--language="):
			_language = arg.trim_prefix("--language=")
		elif arg == "--candidate":
			_candidate = true
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_save.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_check(Story.set_language(_language), "use the requested locale")
	Settings.set_ui_font("pixel")
	Settings.set_ui_text_scale(1.2)
	Settings.set_hud_auto_hide(false)
	_main.call("_on_continue_requested")
	await _settle(100)
	_level = _main.get("_screen") as Level
	_check(_level != null and str(_level.data.id) == _area, "continue the real area from the unchanged captured save")
	var sample: Dictionary = {}
	if _level != null:
		if _area == "ch1_handoff" or _area == "ch3_pump":
			var move := &"move_right" if _area == "ch1_handoff" else &"move_left"
			Input.action_press(move)
			await _settle(55)
			Input.action_release(move)
			await _settle(35)
		var guidance := _level.hud.quest_guidance
		var label := guidance._label
		_check(guidance._goal_key.begins_with(_flag), "the original active step owns the label: " + guidance._goal_key)
		var width := label.get_theme_font(&"font").get_string_size(label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, label.get_theme_font_size(&"font_size")).x
		_check(label.is_visible_in_tree() and guidance._row.modulate.a > 0.5 and width > 0.0, "the player's actual HUD shows the chosen objective")
		_check((width <= label.size.x) == _candidate, "the scenario's expected fit agrees with the real Label width")
		sample = {"area": str(_level.data.id), "goal": guidance._goal_key, "text": label.text, "width": width,
			"available": label.size.x, "language": Story.language, "resolution": str(get_window().size)}
		_capture("quest-objective")
	var file := FileAccess.open(_out_dir.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures": _failures, "sample": sample}, "  ") + "\n")
	file.close()
	_main.call("_quit", 0 if _failures == 0 else 1)
