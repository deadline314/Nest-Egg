extends Node
var rows: Array=[]
var failures:=0
func _ready() -> void: _run.call_deferred()
func _run() -> void:
	var output:=""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):output=arg.trim_prefix("--out=")
	var box:=Hurtbox.new()
	box.setup(Combat.Team.ENEMY,null,Vector2(2,2))
	add_child(box)
	var holder:=Node2D.new()
	add_child(holder)
	box._shape_node.reparent(holder,false)
	for size: Vector2 in [Vector2(INF,INF),Vector2(NAN,NAN)]:
		print("SIZE_BEFORE_SETTER requested=",size)
		box.resize(size,Vector2.ZERO)
		print("SIZE_AFTER_SETTER actual=",box._shape.size)
		print("SIZE_API_CALL")
		var point:=box.triangle_contact(Vector2(100,100),Vector2(101,100),Vector2(100,101))
		print("SIZE_API_RETURN point=",point)
		rows.append({"requested":str(size),"actual":str(box._shape.size),"stored_nonfinite":not box._shape.size.is_finite(),"finite_return":point.is_finite(),"point":str(point)})
		if point.is_finite():failures+=1
	box.resize(Vector2.ZERO,Vector2.ZERO)
	var zero_point:=box.triangle_contact(Vector2(-3,0),Vector2(3,0),Vector2(3,0.1))
	rows.append({"control":"zero-size original point-contact semantics","finite_return":zero_point.is_finite(),"point":str(zero_point)})
	if not zero_point.is_finite():failures+=1
	box.queue_free()
	holder.queue_free()
	await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	var file:=FileAccess.open(output,FileAccess.WRITE)
	file.store_string(JSON.stringify({"rows":rows,"failures":failures,"performance":false}))
	file.close()
	print("SIZE_API_DONE failures=",failures)
	get_tree().quit(1 if failures else 0)
