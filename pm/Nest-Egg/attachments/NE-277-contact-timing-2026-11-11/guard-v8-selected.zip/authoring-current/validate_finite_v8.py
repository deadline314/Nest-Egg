import json,os,subprocess,time
from run import ROOT,OUT,SHADOW,GODOT,sha,save,assert_sources,seal_generated_metadata
p=SHADOW/'manifest.json';raw=p.read_bytes();m=json.loads(raw);root=SHADOW/'candidate'
assert_sources(root,m['bundles']['candidate'])
v7=json.loads((OUT/'finite-proposal-manifest.json').read_bytes())['files']
v8=json.loads((OUT/'finite-proposal-v8-manifest.json').read_bytes())['files']
out=SHADOW/f'finite-v8-validation-{time.time_ns()}';out.mkdir();(out/'manifest-before.json').write_bytes(raw)
for name,record in v8.items():
 target=root/name;data=target.read_bytes();assert sha(data)==v7[name]['after']
 backup=out/'original-v7'/name;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(data)
 data=(ROOT/record['proposal']).read_bytes();assert sha(data)==record['after'];target.write_bytes(data);m['bundles']['candidate'][name]=sha(data)
m['pending_ne277_guard']={'version':8,'files':v8,'C_adopted':False};save(p,m)
for mode,scene in [('sizes','size'),('geometry','suite')]:
 folder=out/mode;folder.mkdir()
 command=[str(GODOT),'--headless','--quit-after','180','--path',str(root),f'res://work/ne277-finite-api/{scene}.tscn','--','--out='+str(folder/'result.json')]
 env=os.environ.copy();env['APPDATA']=str(folder/'appdata')
 with (folder/'engine.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 save(folder/'exit.json',dict(command=command,exit=result.returncode,performance=False))
 text=(folder/'engine.log').read_text(errors='replace')
 assert result.returncode==0 and 'ERROR:' not in text and 'SCRIPT ERROR' not in text
 assert ('SIZE_API_DONE failures=0' if mode=='sizes' else 'FINITE_PROPOSAL_DONE checks=113 failures=0') in text
 assert_sources(root,m['bundles']['candidate'])
seal_generated_metadata('candidate')
print(json.dumps(dict(output=str(out),version=8,geometry='113/0',size_controls='3/0',performance=False)))
