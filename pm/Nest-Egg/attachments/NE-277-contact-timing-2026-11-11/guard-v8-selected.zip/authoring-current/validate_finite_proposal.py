"""Explicit integration runner: private shadow only; never discovered as a Python unit test."""
import json,os,subprocess,time
from pathlib import Path
from run import ROOT,OUT,SHADOW,GODOT,sha,save,assert_sources,seal_generated_metadata
from prepare import main as prepare_sources
prepare_sources()
path=SHADOW/'manifest.json';raw=path.read_bytes();m=json.loads(raw);root=SHADOW/'candidate'
assert_sources(root,m['bundles']['candidate'])
out=SHADOW/f'finite-proposal-validation-{time.time_ns()}';out.mkdir();(out/'manifest-before.json').write_bytes(raw)
proposal=json.loads((OUT/'finite-proposal-manifest.json').read_bytes())
for name,record in proposal['files'].items():
 target=root/name;old=target.read_bytes();assert sha(old)==record['before']
 old_path=out/'original'/name;old_path.parent.mkdir(parents=True,exist_ok=True);old_path.write_bytes(old)
 data=(ROOT/record['proposal']).read_bytes();assert sha(data)==record['after']
 target.write_bytes(data);m['bundles']['candidate'][name]=sha(data)
for name in ['game/player/player.gd','game/player/player_visual.gd','game/player/melee_held.gd']:
 target=root/name;old_path=out/'original'/name;old_path.parent.mkdir(parents=True,exist_ok=True);old_path.write_bytes(target.read_bytes())
 data=(OUT/'candidate/instrumented'/name).read_bytes();target.write_bytes(data);m['bundles']['candidate'][name]=sha(data)
m['pending_ne277_guard']={'files':proposal['files'],'C_adopted':False,'original_26_manifest':'work/ne277-timing-isolated/candidate-v6.json'}
source='''extends Node
class Cases extends TestSuite:
	func run() -> void: pass
var checks:=0
var failures:=0
func _ready() -> void: _run.call_deferred()
func _check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:
		failures+=1
		push_error(label)
func _run() -> void:
	var suite:=Cases.new(self)
	await preload("res://tests/helpers/melee_contact_geometry_checks.gd").run(suite)
	suite=null
	await AudioRelease.settle(get_tree())
	print("FINITE_PROPOSAL_DONE checks=",checks," failures=",failures)
	get_tree().quit(1 if failures else 0)
'''
name='work/ne277-finite-api/suite.gd';data=source.encode();(root/name).write_bytes(data);m['bundles']['candidate'][name]=sha(data)
name='work/ne277-finite-api/suite.tscn';data=b'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/ne277-finite-api/suite.gd" id="1"]\n[node name="FiniteProposalSuite" type="Node"]\nscript = ExtResource("1")\n';(root/name).write_bytes(data);m['bundles']['candidate'][name]=sha(data);save(path,m)
command=[str(GODOT),'--headless','--quit-after','180','--path',str(root),'res://work/ne277-finite-api/suite.tscn']
env=os.environ.copy();env['APPDATA']=str(out/'appdata')
with (out/'engine.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
assert_sources(root,m['bundles']['candidate']);save(out/'exit.json',dict(command=command,exit=result.returncode,performance=False))
text=(out/'engine.log').read_text(errors='replace')
assert result.returncode==0 and 'failures=0' in text and 'FINITE_PROPOSAL_DONE' in text and 'SCRIPT ERROR' not in text and 'ERROR:' not in text
seal_generated_metadata('candidate')
print(json.dumps(dict(output=str(out),production_proposal=proposal['files'],performance=False)))
