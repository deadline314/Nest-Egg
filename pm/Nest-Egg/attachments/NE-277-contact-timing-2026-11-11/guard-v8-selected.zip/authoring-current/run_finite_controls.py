import json,os,subprocess,time
from pathlib import Path
from run import ROOT,OUT,SHADOW,GODOT,sha,save,assert_sources,seal_generated_metadata
p=SHADOW/'manifest.json';raw=p.read_bytes();m=json.loads(raw);root=SHADOW/'candidate'
assert_sources(root,m['bundles']['candidate'])
out=SHADOW/f'finite-controls-{time.time_ns()}';out.mkdir();(out/'manifest-before.json').write_bytes(raw)
for target_name,source_name in [('probe.gd','finite_probe.gd'),('guarded.gd','finite_guard.gd')]:
 name='work/ne277-finite-api/'+target_name;target=root/name
 if target.exists():(out/(target_name+'.original.txt')).write_bytes(target.read_bytes())
 data=(OUT/source_name).read_bytes();target.write_bytes(data);m['bundles']['candidate'][name]=sha(data)
save(p,m)
for mode in ['original','guarded']:
 folder=out/mode;folder.mkdir()
 command=[str(GODOT),'--headless','--quit-after','120','--path',str(root),'res://work/ne277-finite-api/probe.tscn','--','--out='+str(folder/'result.json')]+(['--guarded'] if mode=='guarded' else [])
 env=os.environ.copy();env['APPDATA']=str(folder/'appdata')
 with (folder/'engine.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 save(folder/'exit.json',dict(command=command,exit=result.returncode,performance=False))
 assert_sources(root,m['bundles']['candidate'])
 facts=json.loads((folder/'result.json').read_bytes());text=(folder/'engine.log').read_text(errors='replace')
 if mode=='original':assert result.returncode==1 and facts['failures']==3 and 'triangle_contact (res://core/components/hurtbox.gd:214)' in text
 else:assert result.returncode==0 and facts['failures']==0 and 'SCRIPT ERROR' not in text and 'ERROR:' not in text
seal_generated_metadata('candidate')
print(json.dumps(dict(output=str(out),original='3 real false-positive failures plus singular inverse API diagnostics',guarded='7/0 and 0 engine errors',performance=False)))
