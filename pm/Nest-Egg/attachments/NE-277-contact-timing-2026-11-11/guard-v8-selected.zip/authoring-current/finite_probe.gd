extends Node
var rows: Array = []
var failures := 0
func _ready() -> void:
	_run.call_deferred()
func _run() -> void:
	var out := ""
	var guarded := false
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
		elif arg == "--guarded":guarded=true
	var box: Hurtbox = preload("res://work/ne277-finite-api/guarded.gd").new() if guarded else Hurtbox.new()
	box.setup(Combat.Team.ENEMY,null,Vector2(2,2))
	add_child(box)
	_call(box,"identity-positive",Vector2(-3,0),Vector2(3,0),Vector2(3,0.1),true)
	_call(box,"nan-a",Vector2(NAN,0),Vector2.ZERO,Vector2(3,0.1),false)
	_call(box,"inf-b",Vector2.ZERO,Vector2(INF,0),Vector2(3,0.1),false)
	_call(box,"nan-c",Vector2.ZERO,Vector2(3,0),Vector2(3,NAN),false)
	# Isolate this pure geometry API from CollisionObject2D's own zero-transform setter errors.
	var holder := Node2D.new()
	add_child(holder)
	box._shape_node.reparent(holder,false)
	for xf: Transform2D in [Transform2D(Vector2.ZERO,Vector2.ZERO,Vector2(7,9)),Transform2D(Vector2(1,2),Vector2(2,4),Vector2(7,9))]:
		print("FINITE_CONFIG_TRANSFORM ",str(xf))
		box._shape_node.transform=xf
		print("FINITE_AFTER_SETTER determinant=",box._shape_node.global_transform.determinant())
		_call(box,"singular-"+str(rows.size()),Vector2(7,9),Vector2(10,9),Vector2(10,9.1),false)
	var reflected := Transform2D(Vector2(-2,0),Vector2(0,0.5),Vector2(12,-9))
	box._shape_node.transform=reflected
	_call(box,"reflected-positive",reflected*Vector2(-3,0),reflected*Vector2(3,0),reflected*Vector2(3,0.1),true)
	box.queue_free()
	holder.queue_free()
	await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	var file:=FileAccess.open(out,FileAccess.WRITE)
	file.store_string(JSON.stringify({"rows":rows,"failures":failures,"performance":false}))
	file.close()
	print("FINITE_API_DONE failures=",failures)
	get_tree().quit(1 if failures else 0)
func _call(box: Hurtbox,label: String,a: Vector2,b: Vector2,c: Vector2,expected: bool) -> void:
	print("FINITE_API_CALL ",label)
	var point:=box.triangle_contact(a,b,c)
	var finite:=point.is_finite()
	rows.append({"case":label,"input":[str(a),str(b),str(c)],"shape_transform":str(box._shape_node.global_transform),"return":str(point),"finite":finite,"expected_finite":expected})
	if finite!=expected:failures+=1
	print("FINITE_API_RETURN ",label," finite=",finite," expected=",expected," point=",point)
