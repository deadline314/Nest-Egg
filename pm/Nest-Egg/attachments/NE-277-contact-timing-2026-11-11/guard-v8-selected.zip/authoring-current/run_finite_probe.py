import json,os,subprocess,time
from pathlib import Path
from run import ROOT,OUT,SHADOW,GODOT,sha,save,assert_sources,seal_generated_metadata
p=SHADOW/'manifest.json';raw=p.read_bytes();m=json.loads(raw)
root=SHADOW/'candidate';assert_sources(root,m['bundles']['candidate'])
backup=SHADOW/f'finite-probe-{time.time_ns()}';backup.mkdir();(backup/'manifest-before.json').write_bytes(raw)
name='work/ne277-finite-api/probe.gd';data=(OUT/'finite_probe.gd').read_bytes();path=root/name
path.parent.mkdir(parents=True,exist_ok=True)
assert not path.exists();path.write_bytes(data);m['bundles']['candidate'][name]=sha(data)
name='work/ne277-finite-api/probe.tscn';data=b'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/ne277-finite-api/probe.gd" id="1"]\n[node name="FiniteProbe" type="Node"]\nscript = ExtResource("1")\n'
(root/name).write_bytes(data);m['bundles']['candidate'][name]=sha(data);save(p,m)
command=[str(GODOT),'--headless','--quit-after','120','--path',str(root),'res://work/ne277-finite-api/probe.tscn','--','--out='+str(backup/'result.json')]
env=os.environ.copy();env['APPDATA']=str(backup/'appdata')
with (backup/'engine.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
assert_sources(root,m['bundles']['candidate']);save(backup/'exit.json',dict(command=command,exit=result.returncode,performance=False))
seal_generated_metadata('candidate')
print(json.dumps(dict(output=str(backup),engine_exit=result.returncode,performance=False)))
