import json,os,subprocess,time
from run import ROOT,OUT,SHADOW,GODOT,sha,save,assert_sources,seal_generated_metadata
p=SHADOW/'manifest.json';raw=p.read_bytes();m=json.loads(raw);root=SHADOW/'candidate'
assert_sources(root,m['bundles']['candidate'])
out=SHADOW/f'size-probe-{time.time_ns()}';out.mkdir();(out/'manifest-before.json').write_bytes(raw)
name='work/ne277-finite-api/size.gd';data=(OUT/'size_probe.gd').read_bytes();assert not (root/name).exists();(root/name).write_bytes(data);m['bundles']['candidate'][name]=sha(data)
name='work/ne277-finite-api/size.tscn';data=b'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/ne277-finite-api/size.gd" id="1"]\n[node name="SizeProbe" type="Node"]\nscript = ExtResource("1")\n';(root/name).write_bytes(data);m['bundles']['candidate'][name]=sha(data);save(p,m)
command=[str(GODOT),'--headless','--quit-after','120','--path',str(root),'res://work/ne277-finite-api/size.tscn','--','--out='+str(out/'result.json')]
env=os.environ.copy();env['APPDATA']=str(out/'appdata')
with (out/'engine.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
assert_sources(root,m['bundles']['candidate']);save(out/'exit.json',dict(command=command,exit=result.returncode,performance=False))
seal_generated_metadata('candidate')
print(json.dumps(dict(output=str(out),engine_exit=result.returncode,performance=False)))
