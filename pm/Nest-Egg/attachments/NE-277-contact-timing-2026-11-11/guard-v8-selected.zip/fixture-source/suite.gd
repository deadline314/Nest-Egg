extends Node
class Cases extends TestSuite:
	func run() -> void: pass
var checks:=0
var failures:=0
func _ready() -> void: _run.call_deferred()
func _check(ok: bool,label: String) -> void:
	checks+=1
	if not ok:
		failures+=1
		push_error(label)
func _run() -> void:
	var suite:=Cases.new(self)
	await preload("res://tests/helpers/melee_contact_geometry_checks.gd").run(suite)
	suite=null
	await AudioRelease.settle(get_tree())
	print("FINITE_PROPOSAL_DONE checks=",checks," failures=",failures)
	get_tree().quit(1 if failures else 0)
