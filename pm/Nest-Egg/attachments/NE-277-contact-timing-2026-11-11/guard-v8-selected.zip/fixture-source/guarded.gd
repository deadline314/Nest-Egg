extends Hurtbox
## RAM-only guard proposal, not the measured production source. Valid calls delegate unchanged.
func triangle_contact(a: Vector2,b: Vector2,c: Vector2) -> Vector2:
	if _shape_node==null or _shape==null or not a.is_finite() or not b.is_finite() or not c.is_finite():
		return Vector2.INF
	var xf:=_shape_node.global_transform
	var determinant:=xf.determinant()
	if not xf.is_finite() or not is_finite(determinant) or determinant==0.0:
		return Vector2.INF
	var inverse:=xf.affine_inverse()
	if not inverse.is_finite() or not (inverse*a).is_finite() or not (inverse*b).is_finite() or not (inverse*c).is_finite():
		return Vector2.INF
	return super.triangle_contact(a,b,c)
