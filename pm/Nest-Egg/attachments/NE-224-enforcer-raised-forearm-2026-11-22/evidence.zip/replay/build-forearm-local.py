from pathlib import Path
from hashlib import sha256
import json
import numpy as np
from PIL import Image
import sys

e=Path(__file__).resolve().parent
root=Path.cwd()
sys.path.insert(0,str(root/"tools/comfyui"))
from cut_layers import part_transform, render_part

base=np.asarray(Image.open(e/"forearm-source-45.png").convert("RGBA"))
wide=np.asarray(Image.open(e/"forearm-source-691.png").convert("RGBA"))
stock=np.asarray(Image.open(root/"art_src/characters/enforcer/07_refined/armor_forearm.png").convert("RGBA"))
spec=json.loads((root/"tools/comfyui/specs/enforcer_side.json").read_bytes())
part=spec["parts"]["armor_forearm"]
phase=part["crop_phase"]
A=np.asarray(phase["affine"])
k=phase["k"]
J={name:np.asarray(point)*k for name,point in spec["joints"].items()}
yy,xx=np.indices(base.shape[:2])
uv=(np.stack([xx,yy],axis=-1)*k-A[:,2]) @ np.linalg.inv(A[:,:2]).T
x,y=uv[:,:,0],uv[:,:,1]
for tag,rx,ry,shoulder in ((701,3,4,4),(702,4,5,5),(703,2.5,4.5,4),(704,4,6,4.5)):
    local=((((x-76.2)/rx)**2 + ((y-246.4)/ry)**2 <=1) |
           (((x-80.5)/shoulder)**2 + ((y-249.8)/(ry+1))**2 <=1))
    mask=local & (wide[:,:,3]>base[:,:,3])
    out=base.copy()
    out[mask]=wide[mask]
    image=Image.fromarray(out)
    t=part_transform(image,part,J,k)
    assert np.array_equal(t[3],-np.asarray(phase["origin"])) and t[1]==173
    cut=render_part(image,t,k,crop_phase=phase)
    print(tag,t[1:3],np.count_nonzero(np.any(out!=stock,axis=2)),int(mask.sum()))
    image.save(e/f"forearm-source-{tag}.png")
    Image.fromarray(cut).save(e/f"forearm-end-{tag}.png")

