from pathlib import Path
from hashlib import sha256
import json
import numpy as np
from PIL import Image
import sys

e=Path(__file__).resolve().parent
root=Path.cwd()
sys.path.insert(0,str(root/"tools/comfyui"))
from cut_layers import part_transform, render_part

src=root/"art_src/characters/enforcer/07_refined/armor_forearm.png"
assert not (root/"art_src/characters/enforcer/overrides/refined/armor_forearm.png").exists()
stock=np.asarray(Image.open(root/"art/characters/enforcer/parts/armor_forearm.png").convert("RGBA"))
arr=np.asarray(Image.open(src).convert("RGBA"))
spec=json.loads((root/"tools/comfyui/specs/enforcer_side.json").read_bytes())
part=spec["parts"]["armor_forearm"]
k=spec["tex_px_per_wp"]/spec["illustration_px_per_wp"]
joints={name:np.asarray(point)*k for name,point in spec["joints"].items()}
A,width,height,pivot=part_transform(Image.fromarray(arr),part,joints,k)
assert np.array_equal(render_part(Image.fromarray(arr),(A,width,height,pivot),k),stock)
phase={"origin":(-pivot).tolist(),"size":[width,height],"affine":A.astype(float).tolist(),"k":k}
part["crop_phase"]=phase
(e/"forearm-crop-phase.json").write_text(json.dumps(phase,indent=2)+"\n",encoding="utf-8")
points=(np.asarray([[79,236],[79,262],[106,236],[106,262]]) @ A[:,:2].T + A[:,2])/k
print("source",src,sha256(src.read_bytes()).hexdigest(),"crop",phase,"region",points.tolist())
left,top=np.floor(points.min(axis=0)-2).astype(int)
right,bottom=np.ceil(points.max(axis=0)+2).astype(int)
y,x=np.mgrid[top:bottom,left:right]
coords=(np.stack([x,y],axis=-1)*k-A[:,2]) @ np.linalg.inv(A[:,:2]).T
local_x,local_y=coords[:,:,0],coords[:,:,1]
for reach in (4.5,5.,5.5,6.):
    taper=np.clip(np.minimum(np.minimum(local_x-79,106-local_x),reach),0,None)
    mask=(local_y>=239)&(local_y<=260)&(taper>0)
    mx,my=x[mask],y[mask]
    pick=np.rint(np.c_[mx,my]-taper[mask,None]*A[:,1]/k).astype(int)
    pixels=arr[pick[:,1],pick[:,0]]
    change=(pixels[:,3]>arr[my,mx,3])&(arr[my,mx,3]<235)
    src_changes=int(change.sum())
    mx,my=mx[change],my[change]
    pixels=pixels[change]
    out=arr.copy()
    out[my,mx,:3]=np.minimum(pixels[:,:3],[25,48,67])
    out[my,mx,3]=pixels[:,3]
    image=Image.fromarray(out)
    transform=part_transform(image,part,joints,k)
    cropped=render_part(image,transform,k,crop_phase=phase)
    kept=cropped[:height,:width]
    assert np.array_equal(pivot, transform[3]) and cropped.shape[1]==width
    solid=stock[:,:,3]>=235
    old_loss=int((solid&(kept[:,:,3]<235)).sum())
    rgba_delta=np.abs(kept[solid].astype(int)-stock[solid].astype(int))
    max_delta=int(rgba_delta.max())
    print("trial",reach,transform[1:3],src_changes,"opaque loss",old_loss,"delta",max_delta)
    key=round(10*reach)
    image.save(e/f"forearm-source-{key}.png")
    Image.fromarray(cropped).save(e/f"forearm-end-{key}.png")
    (e/f"forearm-height-{key}.txt").write_text(f"{transform[2]-height}\n",encoding="utf-8")

