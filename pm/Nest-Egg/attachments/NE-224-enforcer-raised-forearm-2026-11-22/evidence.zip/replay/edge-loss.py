from pathlib import Path
from PIL import Image
from scipy import ndimage
from functools import lru_cache
import json
import numpy as np
import sys

root=Path(__file__).resolve().parent
before=root/sys.argv[1]
after=root/sys.argv[2]
@lru_cache(maxsize=16)
def alpha(file):
    return np.asarray(Image.open(file).convert("RGBA"))[:,:,3]

def flags(folder):
    return {(x["pose"],x["zoom"],x["facing"],x["frame"],x["joint"]):x
            for x in json.loads((folder/"report.json").read_bytes())["failures"]}
a,b=flags(before),flags(after)
records=[]
for key in sorted(set(b)-set(a)):
    row=b[key]
    x,y,w,h=row["rect"]
    r=row["radius"]
    ox=x+w//2-r
    oy=y+h//2-r
    p=alpha(before/row["file"])[oy:oy+2*r,ox:ox+2*r]>=128
    q=alpha(after/row["file"])[oy:oy+2*r,ox:ox+2*r]>=128
    holes=ndimage.binary_fill_holes(q) & ~q
    row={
        "sample":key,"lost_opaque":int((p&~q).sum()),
        "diagonal_hole_pixels":int(holes.sum()),
        "new_flag_inside_old_opaque":int((holes&p).sum()),
        "existing_transparent":int((holes&~p).sum()),
        "open_with_diagonals":not bool((ndimage.binary_fill_holes(q,structure=np.ones((3,3))) & ~q).any()),
    }
    records.append(row)
print(after.name,"records",len(records),"alpha loss",sum(row["lost_opaque"] for row in records),
      "old transparent",sum(row["existing_transparent"] for row in records),
      "filled old current opaque",sum(row["new_flag_inside_old_opaque"] for row in records),
      "not open",sum(not row["open_with_diagonals"] for row in records))
(after/"new-edge-probe.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8")

