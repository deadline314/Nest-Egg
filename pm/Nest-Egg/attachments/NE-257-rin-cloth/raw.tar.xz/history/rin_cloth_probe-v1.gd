extends Node

const SEQUENCES := ["stop", "jump", "dash", "turn", "crouch", "hurt", "die_front", "die_back"]
var out := ""
var records: Array[Dictionary] = []
var rigs: Array[CharacterRig] = []
var inputs: Array[RigInput] = []
var viewport: SubViewport

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): out = arg.trim_prefix("--out=")
	_run.call_deferred()

func _run() -> void:
	if out.is_empty():
		get_tree().quit(2)
		return
	viewport = SubViewport.new()
	viewport.size = Vector2i(1280, 400)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(viewport)
	for sequence in SEQUENCES:
		for child in viewport.get_children():
			child.queue_free()
		await get_tree().process_frame
		rigs.clear()
		inputs.clear()
		for index in 4:
			var holder := Node2D.new()
			holder.position = Vector2(160 + index * 320, 330)
			holder.scale = Vector2.ONE * (1.0 if index % 2 == 0 else 3.4)
			viewport.add_child(holder)
			var rig := CharacterRig.new()
			holder.add_child(rig)
			if not rig.setup("rin"):
				get_tree().quit(3)
				return
			rig.use_level_lighting = false
			rig.set_weapon("rifle")
			rigs.append(rig)
			var input := RigInput.new()
			input.facing = 1 if index < 2 else -1
			input.aim_dir = Vector2(input.facing, 0)
			inputs.append(input)
		for tick in 60:
			for index in 4:
				inputs[index].velocity = Vector2(150 * inputs[index].facing if sequence in ["stop", "turn"] else 0, 0)
				rigs[index].animate(1.0 / 60, inputs[index])
		for tick in 121:
			var t := float(tick) / 60
			for index in 4:
				var input := inputs[index]
				input.jumped = false
				input.landed = 0
				input.dash_started = false
				input.hurt = false
				input.velocity = Vector2.ZERO
				match sequence:
					"stop": input.velocity.x = maxf(0, 150 - 2100 * t) * input.facing
					"jump":
						input.on_floor = tick >= 51
						input.velocity = Vector2(150 * input.facing if tick < 51 else 0, -420 + 1000 * t if tick < 51 else 0)
						input.jumped = tick == 0
						input.landed = 0.75 if tick == 51 else 0
					"dash":
						input.dashing = tick < 10
						input.velocity.x = (360 if tick < 10 else maxf(0, 360 - 2100 * (t - 0.17))) * input.facing
						input.dash_started = tick == 0
					"turn":
						input.facing = (-1 if index < 2 else 1)
						input.aim_dir = Vector2(input.facing, 0)
						input.velocity.x = 150 * input.facing if tick < 30 else 0
					"crouch":
						input.crouching = tick < 60
						input.aim_dir = Vector2(input.facing, -0.8).normalized()
					"hurt": input.hurt = tick == 0
					"die_front", "die_back":
						input.dead = true
						input.death_dir = 1 if sequence == "die_front" else -1
				rigs[index].animate(1.0 / 60, input)
			if tick not in [0, 3, 7, 12, 25, 51, 65, 120]: continue
			await RenderingServer.frame_post_draw
			var filename := "%s-%03d.png" % [sequence, tick]
			var image := viewport.get_texture().get_image()
			if image.save_png(out.path_join(filename)) != OK:
				get_tree().quit(4)
				return
			var angles: Array = []
			for rig in rigs: angles.append(rig.animator._spring_angle.duplicate())
			records.append({"image": filename, "sequence": sequence, "tick": tick, "time": t, "angles": angles})
	var data := {"renderer": RenderingServer.get_video_adapter_name(), "engine": Engine.get_version_info(), "source_sha": FileAccess.get_sha256("res://art/rigs/humanoid_tall.json"), "scope": "actual CharacterRig animation inputs in isolated software Forward+ viewport; not live gameplay", "cells": [{"x": 0, "facing": 1, "scale": 1.0}, {"x": 320, "facing": 1, "scale": 3.4}, {"x": 640, "facing": -1, "scale": 1.0}, {"x": 960, "facing": -1, "scale": 3.4}], "frames": records}
	var file := FileAccess.open(out.path_join("frames.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(data, "  "))
	print("RIN_CLOTH_CAPTURE frames=", records.size())
	get_tree().quit()
