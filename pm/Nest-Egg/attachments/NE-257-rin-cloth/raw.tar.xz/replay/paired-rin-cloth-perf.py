import subprocess,time,json,statistics,re,hashlib
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');p=b/'audio/art/rigs/humanoid_tall.json'
while 'baseline complete; final source restored' not in (b/'rin-cloth-baseline-queue.log').read_text():time.sleep(.5)
final=(b/'ne257-cloth-source/humanoid_tall-after.json').read_bytes();before=(b/'ne257-cloth-source/humanoid_tall-before.json').read_bytes()
assert p.read_bytes()==final
rows=[]
try:
 for pair in range(3):
  for mode,data in ([('before',before),('after',final)] if pair%2==0 else [('after',final),('before',before)]):
   p.write_bytes(data)
   r=subprocess.run([str(b/'godot472/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(b/'audio'),'--audio-driver','Dummy','res://tools/rig_perf_probe.tscn','--','--count=10','--frames=600','--skin=rin'],cwd=b/'audio',capture_output=True,text=True)
   raw=r.stdout+r.stderr;(b/f'rin-cloth-perf-{pair}-{mode}.log').write_text(raw)
   if r.returncode or 'ERROR:' in raw:raise RuntimeError(raw)
   m=re.search(r'剛體 ([\d.]+).*關節網格 ([\d.]+).*網格頂點 (\d+)',raw)
   assert m,raw
   rows.append({'pair':pair,'mode':mode,'rigid_us_per_10':float(m[1]),'mesh_us_per_10':float(m[2]),'vertices_per_rig':int(m[3])})
finally:p.write_bytes(final)
med={mode:statistics.median(x['mesh_us_per_10']/10 for x in rows if x['mode']==mode) for mode in ['before','after']}
result={'scope':'original headless script performance probe; sequential alternating pairs; no other native or test workload; not GPU draw time','rows':rows,'median_mesh_us_per_character':med,'added_us_per_character':med['after']-med['before'],'final_source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(b/'rin-cloth-paired-perf.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
