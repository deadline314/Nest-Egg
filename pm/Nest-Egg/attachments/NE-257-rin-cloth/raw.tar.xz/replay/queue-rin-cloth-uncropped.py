import subprocess,time,os
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');p=b/'audio/art/rigs/humanoid_tall.json'
while not (b/'rin-cloth-paired-perf.json').exists():time.sleep(.5)
final=(b/'ne257-cloth-source/humanoid_tall-after.json').read_bytes();assert p.read_bytes()==final
try:
 for mode,data in [('before',(b/'ne257-cloth-source/humanoid_tall-before.json').read_bytes()),('after',final)]:
  p.write_bytes(data)
  r=subprocess.run(['python',str(b/'native.py'),'rin-cloth-uncropped-'+mode,'res://work/rin_cloth_probe.tscn'],cwd=b/'audio',env=dict(os.environ,NE_NATIVE_PROJECT='audio'))
  if r.returncode:raise RuntimeError(mode+' failed')
finally:p.write_bytes(final)
print('uncropped complete; final source restored',flush=True)
