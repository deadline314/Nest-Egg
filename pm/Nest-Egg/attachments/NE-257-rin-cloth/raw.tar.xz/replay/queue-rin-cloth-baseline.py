import subprocess,time
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1020b');p=b/'audio/art/rigs/humanoid_tall.json'
while not (b/'rin-cloth-level.exit').exists():time.sleep(.5)
if (b/'rin-cloth-level.exit').read_text()!='0':raise RuntimeError('level capture failed; source not changed')
final=p.read_bytes();before=(b/'ne257-cloth-source/humanoid_tall-before.json').read_bytes()
(b/'ne257-cloth-source/humanoid_tall-after.json').write_bytes(final)
try:
 p.write_bytes(before)
 import os
 env=dict(os.environ,NE_NATIVE_PROJECT='audio')
 r=subprocess.run(['python',str(b/'native.py'),'rin-cloth-joints-before','res://tools/rig_joint_audit.tscn','--chars=rin','--joints=coat_shoulder_front,coat_shoulder_back,coat_cuff_front,coat_cuff_back','--frames=120'],cwd=b/'audio',env=env)
 if r.returncode:raise RuntimeError('baseline capture failed')
finally:p.write_bytes(final)
print('baseline complete; final source restored',flush=True)
