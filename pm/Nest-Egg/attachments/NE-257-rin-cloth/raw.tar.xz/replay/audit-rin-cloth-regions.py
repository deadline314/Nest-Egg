import json
from pathlib import Path
import numpy as np
from PIL import Image
b=Path('/workspace/Nest-Egg/work/batch1020b/rin-cloth-regions')
m=json.loads((b/'regions.json').read_text());control=np.array(Image.open(b/'control.png').convert('RGBA'));results=[]
for mode in ['run','minimum','maximum']:
 a=np.array(Image.open(b/(mode+'.png')).convert('RGBA'))
 for p in m['parts']:
  x,y=map(int,p['origin']);w,h=map(int,p['size']);root=int(p['warp']['from'][1]);d=np.any(a[y:y+h,x:x+w]!=control[y:y+h,x:x+w],axis=2)
  fixed=d[:root-2];free=d[root:]
  results.append({'mode':mode,'part':p['part'],'fixed_changed_pixels':int(fixed.sum()),'free_changed_pixels':int(free.sum()),'fixed_rows':[0,root-3]})
assert all(r['fixed_changed_pixels']==0 and r['free_changed_pixels']>0 for r in results),results
report={'scope':'actual source-resolution bound jacket Sprite2D nodes; fixed upper rows vs lower deformation; this does not prove body seams or art anatomy','negative_control':'maximum/minimum real visible bend must change free rows; unchanged upper source rows required exactly','results':results}
(b/'pixel-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(results))
