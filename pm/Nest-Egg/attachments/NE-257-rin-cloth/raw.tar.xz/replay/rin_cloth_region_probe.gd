extends Node
var out := ""
func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): out = arg.trim_prefix("--out=")
	_run.call_deferred()
func _run() -> void:
	var rig := CharacterRig.new()
	add_child(rig)
	rig.setup("rin")
	rig.use_level_lighting = false
	var input := RigInput.new()
	input.velocity = Vector2(220, 0)
	for tick in 60: rig.animate(1.0 / 60, input)
	var viewport := SubViewport.new()
	viewport.size = Vector2i(480, 420)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(viewport)
	var metadata: Array[Dictionary] = []
	var sources := {"coat_1": Vector2(30, 30), "coat_2": Vector2(330, 30)}
	var skin := RigLibrary.character("rin")
	for spring: Dictionary in rig.springs():
		if not spring.has("warp"): continue
		var id := StringName(str(spring["id"]))
		var target: Array = rig._sway_targets[id][0]
		var sprite := target[0] as Sprite2D
		var part_name := str(spring["warp"]["part"])
		var pivot := RigLibrary.vec2(skin["textures"][part_name]["pivot"])
		sprite.reparent(viewport, false)
		sprite.position = sources[str(id)] + pivot
		sprite.rotation = 0
		sprite.scale = Vector2.ONE
		metadata.append({"id": id, "part": part_name, "origin": [sources[str(id)].x, sources[str(id)].y], "size": skin["textures"][part_name]["size"], "warp": spring["warp"], "run_angle": rig.animator._spring_angle[id]})
	rig.visible = false
	for mode in ["control", "run", "minimum", "maximum"]:
		for spring: Dictionary in rig.springs():
			if not spring.has("warp"): continue
			var id := StringName(str(spring["id"]))
			var angle := 0.0
			if mode == "run": angle = float(rig.animator._spring_angle[id])
			elif mode == "minimum": angle = float(spring["min"])
			elif mode == "maximum": angle = float(spring["max"])
			rig.set_sway(id, angle)
		await RenderingServer.frame_post_draw
		viewport.get_texture().get_image().save_png(out.path_join(mode + ".png"))
	var file := FileAccess.open(out.path_join("regions.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"source_sha": FileAccess.get_sha256("res://art/rigs/humanoid_tall.json"), "scope": "actual bound Sprite2D nodes reparented for native 1:1 source-pixel isolation; no animation between control/extreme shots", "parts": metadata}, "  "))
	print("RIN_REGION_CAPTURE shots=4")
	get_tree().quit()
