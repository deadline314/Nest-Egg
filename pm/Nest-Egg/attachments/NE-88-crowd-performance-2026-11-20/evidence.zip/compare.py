from pathlib import Path
from statistics import mean
import json

base=Path(__file__).resolve().parent
profiles=('transfer','blackout','market')
names=('final-before-a','final-current-a','final-current-b','final-before-b')
results={}
for name in names:
    directory=base/name
    raw=(directory/'raw.log').read_text(encoding='utf-8')
    data=json.loads((directory/'report.json').read_bytes())
    expected=name.startswith('final-before')
    assert data['historical']==expected and data['failures']==0, name
    assert data['window']==[1280,720] and data['vsync']==0 and data['frame_window_seconds']==10.0
    assert 'RX 9070 XT' in data['adapter'] and 'Forward+' in raw and 'ERROR:' not in raw
    assert set(data['profiles'])==set(profiles)
    for lighting in profiles:
        row=data['profiles'][lighting]
        assert len(row['roles'])==row['visible_minimum']==11 and row['projectiles_peak']>0 and row['frames']>300
        assert all(role[1].startswith('ne88_before_')==expected for role in row['roles'])
    results[name]=data

fields=('fps','average_frame_ms','median_frame_ms','p99_ms','draw_calls','texture_bytes','video_bytes')
limits={'fps':-10.0,'median_frame_ms':10.0,'p99_ms':15.0}
summary={}
for lighting in profiles:
    rows={name:run['profiles'][lighting] for name,run in results.items()}
    old={key:mean(r[key] for n,r in rows.items() if 'before' in n) for key in fields}
    current={key:mean(r[key] for n,r in rows.items() if 'current' in n) for key in fields}
    changes={key:100*(current[key]/old[key]-1) for key in fields}
    accepted=all(changes[key] <= limit if key!='fps' else changes[key]>=limit for key,limit in limits.items())
    summary[lighting]={'before':old,'current':current,'relative_change_percent':changes,'performance_pass':accepted,
          'frames_by_run':{name:row['frames'] for name,row in rows.items()},
          'projectile_count_peaks':{name:row['projectiles_peak'] for name,row in rows.items()}}
record={'order':names,'samples_per_profile_mode':2,'conditions':limits,'profiles':summary,
        'performance_pass':all(row['performance_pass'] for row in summary.values())}
(base/'comparison.json').write_text(json.dumps(record,indent=2)+'\n')
for name,row in summary.items():
    print(name, row['performance_pass'], {k:round(v,2) for k,v in row['relative_change_percent'].items()},flush=True)
