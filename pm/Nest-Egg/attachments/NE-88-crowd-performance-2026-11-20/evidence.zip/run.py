from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys

base=Path(__file__).resolve().parent
root=Path.cwd()
worktree=Path('D:/NestEggVerification/st19-roof-checkcard-20261120')
run=base/sys.argv[1]
settings=sys.argv[2:]
run.mkdir()
original=json.loads((base/'isolated-original-imports.json').read_bytes())
assert all(sha256((worktree/path).read_bytes()).hexdigest()==value for path,value in original.items())
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_DATA_HOME'):
    env[key]=str(run/'profile'/key)
command=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
   'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(worktree),
   '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','WASAPI','--resolution','1280x720',
   str(base/'probe.tscn'),'--',f'--out={run}',*settings]
(run/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (run/'raw.log').open('wb') as log:
    result=subprocess.run(command,env=env,cwd=worktree,timeout=135,stdout=log,stderr=subprocess.STDOUT)
raw=(run/'raw.log').read_text(encoding='utf-8',errors='replace')
print(raw[-6500:],flush=True)
assert result.returncode == 0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw
