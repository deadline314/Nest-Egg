extends ScenarioBase

const ROLES := ["grunt", "elite_grunt", "mortar", "heavy_gunner", "flamer", "shield_rusher",
		"warden", "sniper", "elite_grunt", "grunt", "heavy_gunner"]
const ORIGINAL := {"grunt": "trooper", "elite_grunt": "trooper", "mortar": "grenadier", "heavy_gunner": "heavy_gunner",
		"flamer": "flamer", "shield_rusher": "enforcer", "warden": "warden", "sniper": "sniper"}
var _historical := false
var _measure_seconds := 10.0
var _rehearsal := false
var _results: Dictionary = {}


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
		elif argument == "--historical":
			_historical = true
		elif argument == "--rehearsal":
			_rehearsal = true
			_measure_seconds = 2.0
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	Engine.max_fps = 0
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Story.auto_skip = true
	for lighting: String in ["transfer", "blackout", "market"]:
		await _measure(lighting)
		if _rehearsal:
			break
	var size := get_window().size
	var report := {
		"historical": _historical, "adapter": RenderingServer.get_video_adapter_name(),
		"frame_window_seconds": _measure_seconds, "window": [size.x, size.y],
		"vsync": int(DisplayServer.window_get_vsync_mode()), "profiles": _results, "failures": failures,
	}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "  "))
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)


func _measure(lighting: String) -> void:
	seed(7923)
	await open_arena("res://data/lighting/%s.tres" % lighting, 22.0)
	player.health.grant_invulnerability(50.0)
	var camera := level.camera
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * 0.94
	camera.global_position = Vector2(326, FLOOR_Y - 111)
	camera.limit_left = -64
	camera.limit_right = 1120
	camera.force_update_scroll()
	var enemies: Array[Enemy] = []
	var render_paths: Array = []
	for index in ROLES.size():
		var id: String = ROLES[index]
		var path := "res://data/enemies/%s.tres" % id
		var original := load(path) as EnemyData
		var data := original
		if _historical:
			data = original.duplicate() as EnemyData
			data.rig_skin = "ne88_before_" + str(ORIGINAL[id])
			RigLibrary._json_cache["res://art/motion/%s.json" % data.rig_skin] = RigLibrary.load_json("res://art/motion/%s.json" % original.rig_skin)
		var enemy := level._create_enemy(data)
		if enemy == null:
			failures += 1
			continue
		var x := 178.0 + index * 34.8
		enemy.position = Vector2(x, FLOOR_Y)
		level._entities.add_child(enemy)
		enemies.append(enemy)
		if enemy.rig != null and enemy.rig.is_valid():
			render_paths.append([id, enemy.rig.skin_id])
		else:
			failures += 1
			push_error("The real enemy did not load its humanoid rig: %s / %s" % [id, data.rig_skin])
	await wait(0.6 if _rehearsal else 3.0)
	await RenderingServer.frame_post_draw
	capture(lighting + "-crowd")
	var stage := get_viewport().get_visible_rect().grow(-5)
	var frames := PackedFloat64Array()
	var scene_samples: Array = []
	var started := Time.get_ticks_usec()
	var previous := started
	var draw_total := 0.0
	var texture_peak := 0.0
	var video_peak := 0.0
	var min_visible := enemies.size()
	var active_projectile_peak := 0
	while (previous - started) < _measure_seconds * 1000000.0:
		await get_tree().process_frame
		var now := Time.get_ticks_usec()
		frames.append(float(now - previous) / 1000.0)
		previous = now
		if frames.size() % 16 != 1:
			continue
		var visible := 0
		var states: Array[String] = []
		for enemy: Enemy in enemies:
			if not is_instance_valid(enemy):
				continue
			var canvas := enemy.get_canvas_transform()
			var upper := enemy.global_position - Vector2(0.0, enemy.data.body_size.y)
			if enemy.visible and stage.has_point(canvas * upper) and stage.has_point(canvas * enemy.global_position):
				visible += 1
			states.append(str(enemy.fsm.current))
		min_visible = mini(min_visible, visible)
		active_projectile_peak = maxi(active_projectile_peak, ProjectilePool.active_count())
		draw_total += Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)
		texture_peak = maxf(texture_peak, Performance.get_monitor(Performance.RENDER_TEXTURE_MEM_USED))
		video_peak = maxf(video_peak, Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED))
		scene_samples.append([visible, states])
	var total_ms := float(previous - started) / 1000.0
	frames.sort()
	var record := {"frames": frames.size(), "average_frame_ms": total_ms / frames.size(),
		"median_frame_ms": frames[floori((frames.size() - 1) * 0.5)], "p99_ms": frames[floori((frames.size() - 1) * 0.99)],
		"fps": frames.size() * 1000.0 / total_ms, "draw_calls": draw_total / scene_samples.size(),
		"texture_bytes": texture_peak, "video_bytes": video_peak, "visible_minimum": min_visible,
		"projectiles_peak": active_projectile_peak, "samples": scene_samples, "roles": render_paths,
		"final_positions": enemies.filter(is_instance_valid).map(func(enemy: Enemy) -> String: return str(enemy.global_position)),
	}
	_results[lighting] = record
	print("CROWD ", JSON.stringify(record.duplicate().merged({"samples": []}, true)))
	if min_visible != ROLES.size() or active_projectile_peak == 0 or render_paths.size() != ROLES.size():
		failures += 1
		push_error("%s did not keep the complete fighting group active and visible" % lighting)
	await finish()

