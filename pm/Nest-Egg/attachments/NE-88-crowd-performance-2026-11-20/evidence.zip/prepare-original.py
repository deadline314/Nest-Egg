from hashlib import md5, sha256
from pathlib import Path
from shutil import copyfile
import json
import re
import subprocess
import tarfile

base = Path(__file__).resolve().parent
mini = base / 'asset-import'
mini.mkdir()
(mini/'project.godot').write_text('config_version=5\n[application]\nconfig/name="Historical Cast Import"\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n', encoding='utf-8')
revision = 'd906549a1739905baaf97562d9772a5355fde8de'
roles = ['trooper','enforcer','heavy_gunner','sniper','flamer','grenadier','warden']
prefix = 'ne88_before_'
original = base/'original-art.tar'
command = ['git','archive','--format=tar','--output='+str(original),revision,
           'art/rigs/humanoid.json',*[f'art/characters/{id}' for id in roles]]
subprocess.run(command,check=True)
records = {}
with tarfile.open(original,'r') as archive:
    for member in archive:
        if not member.isfile():
            continue
        old = member.name
        if old == 'art/rigs/humanoid.json':
            dest = 'art/rigs/ne88_before_humanoid.json'
        else:
            parent, character, tail = old.split('/',3)[1:]
            assert parent == 'characters' and character in roles
            dest = f'art/characters/{prefix}{character}/{tail}'
        if not dest.endswith(('.png','.png.import','.json')):
            continue
        raw=archive.extractfile(member).read()
        records[old] = {'sha256':sha256(raw).hexdigest(),'relative':dest}
        if dest.endswith('/character.json'):
            data=json.loads(raw)
            data['id']=prefix+character
            assert data['rig']=='res://art/rigs/humanoid.json'
            data['rig']='res://art/rigs/ne88_before_humanoid.json'
            raw=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
        elif dest.endswith('.png.import'):
            value=raw.decode()
            source=dest.removesuffix('.import')
            path=f'res://{source}'
            hashed=md5(path.encode()).hexdigest()
            original_hash=md5(f'res://{old.removesuffix(".import")}'.encode()).hexdigest()
            if original_hash not in value:
                raise ValueError(old)
            value=re.sub(r'^uid=.*\n','',value,flags=re.M)
            value=value.replace(original_hash,hashed).replace('res://'+old.removesuffix('.import'),path)
            raw=value.encode()
        target=mini/dest
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(raw)
(base/'asset-provenance.json').write_text(json.dumps({'revision':revision,'source':records},indent=2)+'\n')
print(f'extracted {len(records)} historical inputs at {revision}',flush=True)
