from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import subprocess

base=Path(__file__).resolve().parent
worktree=Path('D:/NestEggVerification/st19-roof-checkcard-20261120').resolve()
mini=base/'asset-import'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree).decode().strip()=='73a354fbdb44a2a7a931b2c6c2eb87a4529d3248'
files=list((mini/'art').rglob('*'))+list((mini/'.godot/imported').glob('*'))
manifest={}
for source in files:
    if not source.is_file():
        continue
    relative=source.relative_to(mini)
    target=worktree/relative
    assert not target.exists(), target
    target.parent.mkdir(parents=True,exist_ok=True)
    copyfile(source,target)
    manifest[relative.as_posix()]=sha256(target.read_bytes()).hexdigest()
(base/'isolated-original-imports.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('installed', len(manifest), 'original imported resources in the isolated worktree',flush=True)
