extends Node2D


func _ready() -> void:
	_calibrate.call_deferred()


func _calibrate() -> void:
	var path := "C:/Users/stanl/Github/Nest-Egg/work/ne242-lin-stamp-20261119/preview.json"
	var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
	var actor := CutsceneActor.new()
	add_child(actor)
	if not actor.setup(&"lin", "lin", "", 2.22, ""):
		get_tree().quit(2)
		return
	actor.face(-1)
	actor.ground_y = 285.0
	actor.set_process(false)
	var rig := actor.rig
	var offset := rig.hand_source_point(&"front", Vector2(86.5,19.5))
	var shoulder := rig.bone(&"arm_front_upper")
	var max_reach := rig.rest(&"arm_front_lower").length() + rig.rest(&"hand_front").length()
	for px: float in [349.,351.,353.,355.,357.,359.,361.,363.,365.]:
		actor.position = Vector2(px,285)
		var rejected := 0
		var margin := INF
		for frame in 60:
			actor._process(1.0/60.0)
			for key in ["rest", "hover", "press"]:
				var point := StageLayers.vec2_of(data[key])
				var inverse := rig._skeleton.global_transform.affine_inverse()
				var hand_angle := inverse.basis_xform(Vector2.from_angle(2.1)).angle()
				var wrist := inverse * point - offset.rotated(hand_angle)
				margin = minf(margin, max_reach - wrist.distance_to(inverse * shoulder.global_position))
				if not rig.place_hand(&"front", point, 2.1, 1.0, offset):
					rejected += 1
		print("NE242_STAMP_CALIBRATION ", JSON.stringify({"x": px, "failures": rejected, "margin": margin,
			"shoulder": str(shoulder.global_position), "reach": max_reach, "offset": str(offset)}))
	actor.free()
	get_tree().quit()
