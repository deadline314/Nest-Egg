extends "C:/Users/stanl/Github/Nest-Egg/work/ne97-campaign-route-20261119/combat-route.gd"

var _office_trace_seen: Dictionary = {}
var _office_last_step := ""
var _office_step_at := 0
var _office_probe_skipped := false
var _office_overlap_captured := false
var _office_exit_captured := false


func _trace_office_source() -> void:
	var player: CutscenePlayer = Story._player
	if is_instance_valid(player) and String(player.scene_id).begins_with("ch3_t_c20"):
		var step: String = player.get("_current_where")
		if player.scene_id == &"ch3_t_c20_rest":
			var cast: Dictionary = player.get("_actors")
			var old_k := cast.get(&"old_k") as CutsceneActor
			var rin := cast.get(&"rin") as CutsceneActor
			if old_k != null and rin != null and old_k.pose == &"walk":
				if not _office_overlap_captured and rin.pose == &"walk" and old_k.position.x > 276.0 and rin.position.x > 611.0:
					_office_overlap_captured = true
					print("NE97_OFFICE_TWO_PLANES old_k=", old_k.position, " floor=", old_k.ground_y, " rin=", rin.position, " floor=", rin.ground_y)
					_shot.call_deferred("ne97-office-two-planes")
				if not _office_exit_captured and step.begins_with("場景 ch3_t_c20_rest 第 34 步") and old_k.position.x < 290.0:
					_office_exit_captured = true
					print("NE97_OFFICE_RETURN_WALK old_k=", old_k.position, " floor=", old_k.ground_y)
					_shot.call_deferred("ne97-office-inside-return")
		if step != _office_last_step:
			_office_last_step = step
			_office_step_at = Engine.get_physics_frames()
			print("NE97_OFFICE_STEP ", step, " physics=", Engine.get_physics_frames(), " process=", Engine.get_process_frames())
		if step.begins_with("場景 ch3_t_c20_rest 第 29 步") and not _office_probe_skipped and Engine.get_physics_frames() - _office_step_at > 120:
			var actors: Dictionary = player.get("_actors")
			for id in [&"old_k", &"rin"]:
				var actor := actors.get(id) as CutsceneActor
				if actor != null:
					var motion := actor.rig.animator as NpcAnimator
					print("NE97_OFFICE_MOVE_GATE ", JSON.stringify({"actor": id, "pose": actor.pose, "y": actor.position.y,
						"ground": actor.ground_y, "ready": player.call(&"_standing_ready", actor), "can_process": actor.can_process(),
						"posture_active": motion.posture_active(), "stand_ready": motion.posture_ready(&"stand")}))
			_office_probe_skipped = true
			if "--office-step-skip" in OS.get_cmdline_user_args():
				Story.skip_cinematic()
	if Story._current_cinematic not in [&"ch3_t_c18_box", &"ch3_t_c19_watch"]:
		return
	var segment: StringName = Story._current_cinematic
	var request := Story.current_presentation_request()
	if _office_trace_seen.has(segment):
		return
	_office_trace_seen[segment] = true
	var context := Story.presentation_context_for_request(segment, request)
	var actor := _npc(&"ch3_petition_box")
	print("NE97_OFFICE_SOURCE ", JSON.stringify({"scene": segment, "context": context, "actor_key": actor.state_key(),
		"live_talking": actor.get("_talking"), "actor_index": actor.get("_presentation_index"), "entry": actor.data.talks[0].scene,
		"current_dispatch": Story.resolve_dispatch(actor.data.talks[0].scene), "entry_completed": Story._completed.has(&"ch3_t_c18_box"),
		"receipt_received": GameState.has_flag(&"ch3_petition_receipt_taken"), "admitted": Story.is_npc_presentation(actor.data, 0, segment)}))


func _route_from_save() -> void:
	if "--trace-office-source" in OS.get_cmdline_user_args():
		get_tree().process_frame.connect(_trace_office_source)
	if "--trace-clinic-slip" in OS.get_cmdline_user_args():
		get_tree().process_frame.connect(_trace_clinic_slip)
	if "--ch3-showroom-stamp" in OS.get_cmdline_user_args():
		get_tree().process_frame.connect(_trace_showroom_stamp)
		if "--showroom-stamp-preview" in OS.get_cmdline_user_args():
			var path := "C:/Users/stanl/Github/Nest-Egg/work/ne242-lin-stamp-20261119/preview.json"
			var proposal: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
			StageLibrary._cache[&"ch3_morning_window"] = proposal["stage"]
			Story._scenes["ch3_t_c15_posted"] = proposal["posted"]
			print("NE242_STAMP_PREVIEW scratch stage")
	if "--preview-clinic-slip" in OS.get_cmdline_user_args():
		var scratch := "C:/Users/stanl/Github/Nest-Egg/work/ne242-clinic-slip-20261119/"
		var stage: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(scratch + "ch3_clinic_counter.json"))
		var chapter: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(scratch + "ch3_clearwater.json"))
		StageLibrary._cache[&"ch3_clinic_counter"] = stage
		Story._scenes["ch3_t_c04_counter"] = chapter["scenes"]["ch3_t_c04_counter"]
		print("NE242_CLINIC_PREVIEW scratch stage and segment")
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_main.set("_run_store", RunSaveStore.new(_save_dir.path_join("slot.json")))
	add_child(_main)
	var menu: MainMenu
	for tick in 2400:
		menu = _main.get("_screen") as MainMenu
		if menu != null and menu.is_inside_tree() and not _main.call("_route_pending") and menu._continue_button != null and menu._continue_button.has_focus():
			break
		await _frames(1)
	if not _assert_route(menu != null and menu.is_visible_in_tree() and is_instance_valid(menu._continue_button), "the original Continue button is available"):
		_main.call("_quit", 2)
		return
	await _frames(24)
	menu._continue_button.pressed.emit()
	if "--ch3-ended" in OS.get_cmdline_user_args():
		await _chapter_three_cold_ending()
		_main.call("_quit", 1 if _failures > 0 else 0)
		return
	for tick in 2400:
		if _player() != null:
			break
		await _frames(1)
	if _assert_route(_player() != null, "continued the genuine campaign slot"):
		await _frames(30)
		if "--ch3-office-recovery" in OS.get_cmdline_user_args():
			await _chapter_three_office_recovery()
		elif "--ch3-office-first" in OS.get_cmdline_user_args():
			await _chapter_three_office_first()
		elif "--ch3-office-last" in OS.get_cmdline_user_args():
			await _chapter_three_office_last()
		elif "--ch3-ending" in OS.get_cmdline_user_args():
			await _chapter_three_ending()
		elif "--ch3-buy-upgrades" in OS.get_cmdline_user_args():
			await _chapter_three_buy_upgrades()
		elif "--ch3-upgrades-cold" in OS.get_cmdline_user_args():
			await _chapter_three_upgrades_cold()
		elif "--ch3-guard-stat-layout" in OS.get_cmdline_user_args():
			await _chapter_three_guard_stat_layout()
		elif "--ch3-morning-ruler" in OS.get_cmdline_user_args():
			await _chapter_three_morning_ruler()
		elif "--ch3-showroom-stamp" in OS.get_cmdline_user_args():
			await _chapter_three_showroom_stamp()
		elif "--ch3-showroom" in OS.get_cmdline_user_args():
			await _chapter_three_showroom()
		elif "--ch3-aftercare" in OS.get_cmdline_user_args():
			await _chapter_three_aftercare()
		elif "--ch3-janus-resume" in OS.get_cmdline_user_args():
			_check_janus_checkpoint()
		elif "--ch3-janus" in OS.get_cmdline_user_args():
			await _chapter_three_janus()
		elif "--ch3-clinic" in OS.get_cmdline_user_args():
			await _chapter_three_clinic()
		elif "--ch3-freight" in OS.get_cmdline_user_args():
			await _chapter_three_freight()
		elif "--ch3-pump" in OS.get_cmdline_user_args():
			await _chapter_three_pump()
		else:
			await _chapter_three_departure()
	print("NE97_CH3_ROUTE %s deaths=%d failures=%d" % [_visits, GameState.deaths, _failures])
	_main.call("_quit", 1 if _failures > 0 else 0)


func _chapter_three_buy_upgrades() -> void:
	var player := _player()
	var wallet := Progression.credits
	var pistol := player.loadout.weapon_in(player.loadout.active_slot)
	if not _assert_route(_level().data.id == &"ch3_pawnshop" and wallet == 1722 and pistol.id == &"pistol"
		and pistol.magazine_size == 12 and player.guard_max() == 100.0,
		"the genuine two-chapter budget starts at 1722 with the original magazine and shield"):
		return
	var inventory := _level()._inventory
	var index := inventory.page_index(UpgradesPage)
	inventory.open()
	inventory.select_tab(index)
	var upgrades := inventory._pages[index] as UpgradesPage
	var mag_index := upgrades._targets.find_custom(func(target: Dictionary) -> bool:
		return target["upgrade"].id == &"mag_boost" and target["weapon"].id == &"pistol")
	if not _assert_route(mag_index >= 0, "the upgrade screen offers the original P-9 magazine"):
		return
	upgrades._select(mag_index)
	await _frames(12)
	if not _assert_route(not upgrades._detail._action.disabled, "the magazine is affordable from earned credits"):
		return
	await _shot("ne231-magazine-offer")
	upgrades._detail._action.pressed.emit()
	await _frames(12)
	if not _assert_route(Progression.credits == wallet - 120 and player.loadout.weapon_in(player.loadout.active_slot).magazine_size == 18,
		"buying the 120-credit magazine changes the actual P-9 capacity 12 to 18"):
		return
	var cushion := Progression.find_arm_shield_part(&"cushion_pad")
	var cushion_index := upgrades._arm_targets.find(cushion)
	if not _assert_route(cushion_index >= 0, "the same screen offers the existing guard cushion"):
		return
	upgrades._select(upgrades._targets.size() + cushion_index)
	await _frames(12)
	if not _assert_route(not upgrades._detail._action.disabled, "the cushion is still affordable after choosing the magazine"):
		return
	await _shot("ne231-cushion-offer")
	upgrades._detail._action.pressed.emit()
	await _frames(12)
	if not _assert_route(Progression.credits == wallet - 280 and is_equal_approx(player.guard_max(), 130.0),
		"the second purchase is exactly 160 credits and increases the actual guard cap to 130"):
		return
	await _shot("ne231-cushion-installed")
	inventory.close()
	await _frames(40)


func _chapter_three_upgrades_cold() -> void:
	var player := _player()
	var slot := player.loadout.active_slot
	var pistol := player.loadout.weapon_in(slot)
	if not _assert_route(_level().data.id == &"ch3_pawnshop" and Progression.credits == 1442 and Progression.has_upgrade(pistol, &"mag_boost")
		and Progression.has_arm_shield_part(&"cushion_pad") and is_equal_approx(player.guard_max(), 130.0)
		and pistol.magazine_size == 18 and GameState.deaths == 1,
		"cold Continue restores the actual purchases and their 1442 remaining earned credits"):
		return
	print("NE231_COLD_MAGAZINE loaded=", player.loadout.mag_in(slot), " capacity=", pistol.magazine_size)
	_assert_route(player.loadout.mag_in(slot) == 18, "cold Continue preserves all 18 rounds already saved in the expanded magazine")
	if player.loadout.mag_in(slot) < 18:
		_send_action(&"reload")
		for tick in 180:
			if player.loadout.mag_in(slot) == 18:
				break
			await _frames(1)
		_assert_route(player.loadout.mag_in(slot) == 18, "a real reload fills all 18 purchased magazine places")
	await _shot("ne231-expanded-magazine-loaded")


func _chapter_three_guard_stat_layout() -> void:
	var inventory := _level()._inventory
	var index := inventory.page_index(UpgradesPage)
	var cushion := Progression.find_arm_shield_part(&"cushion_pad")
	var owned := Progression.has_arm_shield_part(cushion.id)
	for text_scale in [1.0, 1.2]:
		Settings.set_ui_text_scale(text_scale)
		inventory.open()
		inventory.select_tab(index)
		var upgrades := inventory._pages[index] as UpgradesPage
		upgrades._select(upgrades._targets.size() + upgrades._arm_targets.find(cushion))
		await _frames(20)
		var stat: Label
		for label: Label in upgrades._detail._stats.get_children():
			if label.text.contains("硬直"):
				stat = label
				break
		if not _assert_route(stat != null, "the real detail panel renders the break-stun value"):
			inventory.close()
			return
		var layout := preload("res://game/level/world_text_layout.gd").paragraph(stat.text, stat.get_theme_font(&"font"),
			stat.get_theme_font_size(&"font_size"), stat.size.x)
		var lines: PackedStringArray = []
		for i in layout.get_line_count():
			var span := layout.get_line_range(i)
			lines.append(stat.text.substr(span.x, span.y - span.x).strip_edges())
		print("NE228_UPGRADE_STAT ", JSON.stringify({"scale":text_scale,"owned":owned,"stat":stat.text,"lines":lines,"native_lines":stat.get_line_count(),"width":stat.size.x}))
		_assert_route(not lines.has("秒") and stat.text.contains("0.42"), "the break-stun number and unit read together at scale %.1f" % text_scale)
		await _shot("ne228-guard-stat-%d" % roundi(text_scale * 100.0))
		inventory.close()
		await _frames(6)


func _chapter_three_departure() -> void:
	if not _assert_route(_level().data.id == &"ch3_pawnshop" and GameState.has_flag(&"ch2_heron_closed")
			and StoryItems.holds(&"ch2_clinic_index") and GameState.get_flag(&"yong_link_choice") == "cut"
			and _player().health.current == 6 and GameState.deaths == 1,
			"Chapter 3 opens with the real clinic index, cut record, six health and one prior flood death"):
		return
	if not await _input_talk(&"ch3_old_k", ["ask", "go"], func() -> bool: return GameState.has_flag(&"ch3_departure_done")):
		return
	await _shot("ne97-ch3-breakfast-departure")
	if not await _route_portal(&"pawn_front"):
		return
	if not await _input_talk(&"ch3_control_box", [], func() -> bool: return GameState.has_flag(&"ch3_interlock_seen")):
		return
	if not _assert_route(not GameState.has_flag(&"ch3_freight_ready"), "the actual control box explains the water safety interlock before enabling the lift"):
		return
	await _shot("ne97-ch3-lift-interlock")
	if not await _route_portal(&"plaza_pump"):
		return
	_assert_route(_level().data.id == &"ch3_pump" and not GameState.has_flag(&"ch3_pump_low"), "entered the original pump room before draining the tank")


func _chapter_three_pump() -> void:
	if not _assert_route(_level().data.id == &"ch3_pump" and not GameState.has_flag(&"ch3_pump_low"),
			"resumed inside the actual flooded pump room"):
		return
	var kills: Array[StringName] = []
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: kills.append(id))
	await _walk_to(7.1 * 16.0, 3.0)
	await _fight_jump(9.3 * 16.0)
	if not _assert_route(absf(_player().global_position.y - 528.0) < 0.25 and _player().is_on_floor(), "first jump reaches the short entrance ledge"):
		return
	await _fight_jump(13.6 * 16.0)
	if not _assert_route(absf(_player().global_position.y - 464.0) < 0.25 and _player().is_on_floor(), "second jump reaches the dry upper walk without entering combat"):
		return
	var health_before := _player().health.current
	if not await _input_talk(&"ch3_drain_wheel", ["back", "drain"], func() -> bool: return GameState.has_flag(&"ch3_pump_low")):
		return
	if not _assert_route(kills.is_empty() and _player().health.current == health_before, "the real dry bridge reaches the wheel without kills or damage"):
		return
	await _shot("ne97-ch3-drained-bridge")
	await _walk_to(62.0 * 16.0, 5.0)
	Input.action_press(&"move_down")
	await _press(&"jump")
	Input.action_release(&"move_down")
	for tick in 130:
		if _player().is_on_floor() and absf(_player().global_position.y - 576.0) < 0.25:
			break
		await _frames(1)
	if not _assert_route(_player().is_on_floor() and _player().global_position.y > 570.0, "down plus jump drops through the actual upper platform to the panel floor"):
		return
	if not await _fight_step(63.8 * 16.0, 540):
		return
	if not await _input_talk(&"ch3_branch_panel", ["main", "branch", "power"], func() -> bool: return GameState.has_flag(&"ch3_lift_powered")):
		return
	if not _assert_route(GameState.has_flag(&"ch3_wet_branch_isolated") and GameState.has_flag(&"ch3_lift_powered"),
			"the wet branch and lift power are both confirmed after the recoverable wrong choice"):
		return
	await _shot("ne97-ch3-pump-panel-complete")


func _chapter_three_freight() -> void:
	if not _assert_route(_level().data.id == &"ch3_pump" and GameState.has_flag(&"ch3_pump_low")
			and GameState.has_flag(&"ch3_wet_branch_isolated") and GameState.has_flag(&"ch3_lift_powered"),
			"the drained and powered pump room is restored from a cold continuation"):
		return
	EventBus.enemy_killed.connect(func(id: StringName, _finished: bool) -> void: print("NE97_CH3_KILL ", id))
	for position in [840.0, 650.0, 430.0, 200.0, 83.0]:
		if not await _fight_step(position, 660):
			return
	if not await _route_portal(&"pump_plaza"):
		return
	if not await _input_talk(&"ch3_control_box", [], func() -> bool: return GameState.has_flag(&"ch3_freight_ready")):
		return
	if not await _input_talk(&"ch3_outer_ladder", [], func() -> bool: return GameState.has_flag(&"ch3_outer_ladder_down")):
		return
	if not await _route_portal(&"plaza_ladder"):
		return
	if not _assert_route(_level().data.id == &"ch3_pump" and absf(_player().global_position.y - 464.0) < 0.25,
			"the outdoor ladder drops directly onto the original dry upper bridge"):
		return
	var return_ladder: Portal = _level()._portals.get(&"pump_ladder")
	await _walk_to(return_ladder.global_position.x - 66.0, 4.0)
	if not _assert_route(return_ladder.is_armed(), "walking off the arrival ladder re-arms the round trip"):
		return
	if not await _route_portal(&"pump_ladder"):
		return
	if not await _route_portal(&"plaza_lift"):
		return
	await _walk_to(15.5 * 16.0, 5.0)
	for tick in 720:
		if GameState.has_flag(&"ch3_mezzanine_reached"):
			break
		await _frames(1)
	_assert_route(_level().data.id == &"ch3_mezzanine" and GameState.has_flag(&"ch3_mezzanine_reached"),
			"the original lift carries the player up to the mezzanine")


func _chapter_three_clinic() -> void:
	if not _assert_route(_level().data.id == &"ch3_mezzanine" and GameState.has_flag(&"ch3_mezzanine_reached")
			and GameState.has_flag(&"ch3_outer_ladder_down"), "resumed at the real mezzanine after the outdoor ladder round trip"):
		return
	if not await _input_talk(&"ch3_notice_terminal", [], func() -> bool: return true):
		return
	await _walk_to(37.0 * 16.0, 4.0)
	await _fight_jump(39.5 * 16.0)
	if not _assert_route(_player().is_on_floor() and absf(_player().global_position.y - 528.0) < 0.25, "jumped to the first ledge into the care walkway"):
		return
	await _fight_jump(46.5 * 16.0)
	if not _assert_route(_player().is_on_floor() and absf(_player().global_position.y - 480.0) < 0.25, "reached the upper care walkway above both inspectors"):
		return
	await _shot("ne97-ch3-care-walkway")
	await _walk_to(57.0 * 16.0, 6.0)
	await _fight_jump(64.5 * 16.0, true)
	await _walk_to(70.0 * 16.0, 6.0)
	if not await _route_portal(&"mezz_clinic"):
		return
	var receipt := &"ch3_review_slip"
	var initial_wallet := Progression.credits
	var skip := "--clinic-skip-handoff" in OS.get_cmdline_user_args()
	if not await _input_talk(&"ch3_zhi", [] if skip else ["disease"],
			func() -> bool: return GameState.has_flag(&"ch3_clinic_access") and StoryItems.holds(receipt)):
		return
	if not _assert_route(StoryItems.holds(&"ch2_clinic_index"), "the real public counter admits Rin while keeping the previous chapter's clinic index"):
		return
	if "--require-clinic-slip" in OS.get_cmdline_user_args():
		var expected := ["offer"] if skip else ["offer", "exchange", "received"]
		if not _assert_route(_clinic_samples.keys() == expected, "the real clinic delivers the expected visible handoff stages"):
			return
		if not _assert_route(StoryItems.snapshot()["held"].count(receipt) == 1 and initial_wallet == Progression.credits,
				"the real counter awards one no-fee reading slip after the scene"):
			return
		var revisit := &"ch3_t_c04_revisit"
		if not await _input_talk(&"ch3_zhi", [], func() -> bool: return revisit in Story.progress_snapshot()):
			return
		if not _assert_route(StoryItems.snapshot()["held"].count(receipt) == 1 and initial_wallet == Progression.credits,
				"revisiting the real counter does not repeat the handoff or change the balance"):
			return
	if not await _input_talk(&"ch3_public_report", ["save"], func() -> bool: return StoryItems.holds(&"ch3_report_p17")):
		return
	if not await _input_talk(&"ch3_nursing_board", ["twentytwo", "eleven"], func() -> bool: return StoryItems.holds(&"ch3_roster_n17")):
		return
	if not await _input_talk(&"ch3_register_cabinet", ["ask", "save"], func() -> bool: return StoryItems.holds(&"ch3_register_t17")):
		return
	if not await _input_talk(&"ch3_deposit_drawer", ["play", "lend"], func() -> bool: return StoryItems.holds(&"ch3_ahan_tape")):
		return
	var credits := Progression.credits
	if not await _input_talk(&"ch3_reading_desk", ["ninetytwo", "hundred", "three", "eleven", "cured", "tracked"],
			func() -> bool: return GameState.has_flag(&"ch3_report_reconciled") and StoryItems.holds(&"ch3_mezz_pass")):
		return
	if not _assert_route(Progression.credits == credits + 180, "the answered objection pays exactly 180 credits and grants the real pass"):
		return
	await _shot("ne97-ch3-clinic-reconciled")
	await _route_portal(&"clinic_gate")


func _chapter_three_janus() -> void:
	if not _assert_route(_level().data.id == &"ch3_gate_hall" and StoryItems.holds(&"ch3_mezz_pass")
			and not GameState.has_flag(&"ch3_janus_disabled"), "the authentic clinic pass opens the original gate hall before the encounter"):
		return
	if not await _input_talk(&"ch3_scanner_gate", [], func() -> bool: return GameState.has_flag(&"ch3_janus_intro_seen")):
		return
	var boss: JanusBoss
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		if enemy is JanusBoss:
			boss = enemy
			break
	if not _assert_route(boss != null and boss.health.current == boss.health.max_health,
			"the original gatekeeper still has full work-frame stability after his introduction"):
		return
	var before_deaths := GameState.deaths
	var hit_parts := {}
	for part in boss.hurtbox.parts:
		var id: StringName = part.part_id
		part.hit_received.connect(func(_info: DamageInfo) -> void: hit_parts[id] = int(hit_parts.get(id, 0)) + 1)
	var moves := {}
	var player := _player()
	var minimum := player.health.current
	var previous := &""
	var jump_used := false
	var jump_release_at := -1
	var shield_reported := false
	var rear_route := "--janus-rear-route" in OS.get_cmdline_user_args()
	var backup_seen := false
	var comm_reported := false
	var dash_ready_at := 0
	var scan_actions: Dictionary = {}
	player.health.damaged.connect(func(info: DamageInfo) -> void:
		print("NE271_PLAYER_HIT source=", info.source_id, " move=", boss.get("_move_id"), " hp=", player.health.current))
	_aim(Vector2.RIGHT)
	await _walk_to(boss.global_position.x - (230.0 if rear_route else 131.0), 6.0)
	_accept_radio = true
	for tick in 12000:
		if not is_instance_valid(boss) or boss.halted or not is_instance_valid(player) or player.is_dead() or _player() != player:
			break
		minimum = mini(minimum, player.health.current)
		var state := boss.fsm.current
		var move := StringName(str(boss.get("_move_id")))
		var active := state == &"windup" or state == &"act"
		if move != &"" and state == &"windup" and previous != &"windup":
			moves[move] = int(moves.get(move, 0)) + 1
			jump_used = false
			print("NE97_JANUS_WINDUP ", tick, " ", move, " hp=", boss.health.current, " player_hp=", player.health.current,
				" shield_misses=", boss.shield_misses, " gap=", player.global_position.x - boss.global_position.x)
			if rear_route and moves[move] == 1:
				await _shot("ne271-windup-%s" % move)
		previous = state
		var delta_x := boss.global_position.x - player.global_position.x
		var towards := signf(delta_x)
		var gap := absf(delta_x)
		var move_x := towards if gap > 141.0 else (-towards if gap < 119.0 else 0.0)
		if active and move == &"shield_bash" and gap < 133.0:
			move_x = -towards
		var front := towards == -float(boss.facing)
		if rear_route and not backup_seen and boss.call("_living_backups") > 0:
			backup_seen = true
			print("NE271_BACKUP actual=", boss.call("_living_backups"))
			await _shot("ne271-backup-arrived")
		if rear_route and not comm_reported and boss.comm_broken:
			comm_reported = true
			print("NE271_COMM_BROKEN valid_hits=", hit_parts.get(&"comm", 0))
			await _shot("ne271-comm-broken")
			if "--quit-after-comm" in OS.get_cmdline_user_args():
				Input.action_release(&"shoot")
				await _frames(24)
				_assert_route(GameState.has_flag(&"ch3_janus_comm_broken") and boss.health.current == 54 and player.health.current == 6,
					"the six rear hits save a broken communicator at 54 stability before the fight ends")
				return
		if rear_route and not backup_seen:
			move_x = towards if gap > 246.0 else (-towards if gap < 220.0 else 0.0)
		elif rear_route and not boss.comm_broken:
			if front:
				move_x = towards
				if gap < 69.0 and tick >= dash_ready_at:
					dash_ready_at = tick + 50
					_send_action(&"dash")
			else:
				move_x = towards if gap > 77.0 else (-towards if gap < 41.0 else 0.0)
		var scan := active and String(move).begins_with("scan_") and front
		var high := scan and String(move).ends_with("high")
		if high:
			Input.action_press(&"move_down")
			move_x = 0.0
		else:
			Input.action_release(&"move_down")
		if jump_release_at == tick:
			Input.action_release(&"jump")
		if scan and not high and not jump_used and player.is_on_floor() and (state == &"act" or float(boss.get("_telegraph_left")) < 0.04):
			Input.action_press(&"jump")
			jump_release_at = tick + 15
			jump_used = true
		if rear_route and scan and state == &"act" and not scan_actions.get(move, false) and float(boss.get("_scan_extent")) >= gap - 9.0:
			var avoided := player.is_crouching if high else not player.is_on_floor() and player.global_position.y < boss.global_position.y - 12.0
			if avoided or not scan_actions.has(move):
				scan_actions[move] = avoided
				print("NE271_SCAN_DODGE ", move, " correct_pose=", avoided, " player_y=", player.global_position.y, " player_hp=", player.health.current)
				await _shot("ne271-dodge-%s" % move)
		if player.health.current <= 4 and tick % 45 == 0 and player.consumables.count(&"med_injector") > 0:
			_send_action(&"use_item")
		if player.loadout.is_dry() and not player.loadout.is_reloading() and tick % 20 == 0:
			_send_action(&"reload")
		if boss.shield_cracked and not shield_reported:
			shield_reported = true
			await _shot("ne97-ch3-janus-cracked-shield")
		var target := Vector2.INF
		for enemy in get_tree().get_nodes_in_group(&"enemies"):
			if enemy is not Enemy or enemy == boss or enemy.is_dying():
				continue
			if enemy.global_position.distance_to(player.global_position) < 132.0:
				target = enemy.hurtbox.center()
				break
		if rear_route and not boss.comm_broken and not front and boss.is_part_open(&"comm"):
			target = boss.call(&"_part_point", &"comm")
		elif not target.is_finite() and boss.shield_cracked and (not rear_route or (boss.comm_broken and _janus_both_scans(scan_actions))):
			var part := &"shield_lock" if boss.is_part_open(&"shield_lock") else &"shield"
			target = boss.call(&"_part_point", part)
		if target.is_finite() and gap > 36.0:
			_aim((target - player.muzzle_position()).normalized())
			Input.action_press(&"shoot")
		else:
			_aim(Vector2(towards, 0.0))
			Input.action_release(&"shoot")
		if move_x != 0.0:
			Input.action_press(&"move_left" if move_x < 0 else &"move_right")
		await _frames(1)
		Input.action_release(&"move_left")
		Input.action_release(&"move_right")
	Input.action_release(&"shoot")
	Input.action_release(&"move_down")
	Input.action_release(&"jump")
	_accept_radio = false
	print("NE97_JANUS_RESULT ", JSON.stringify({"moves": moves, "hits": hit_parts, "shields_missed": boss.shield_misses,
		"stability": boss.health.current, "min_hp": minimum, "health": player.health.current, "retained_deaths": GameState.deaths}))
	if rear_route:
		_assert_route(backup_seen and boss.comm_broken and int(hit_parts.get(&"comm", 0)) >= 6,
			"the original reinforcement entered, then real rear hits broke the communicator")
		_assert_route(_janus_both_scans(scan_actions),
			"the original lower and higher scans reach a jumping and ducking player respectively")
	if not _assert_route(boss.halted and not boss.pin_pulled and boss.shield_cracked and GameState.deaths == before_deaths,
			"ordinary gunfire disabled the real frame after three avoided shield charges, leaving its original pin attached"):
		return
	await _shot("ne97-ch3-janus-frame-stopped")
	var pin: Vector2 = boss.global_position + (boss.call(&"_pin_local") as Vector2)
	await _walk_to(pin.x - boss.facing * 14.0, 5.0)
	if not _assert_route(boss.pin_reachable(), "walked within reach of the original rear pin"):
		return
	await _press(&"interact")
	for tick in 300:
		if GameState.has_flag(&"ch3_janus_disabled"):
			break
		await _frames(1)
	_assert_route(GameState.has_flag(&"ch3_janus_disabled") and not GameState.has_flag(&"ch3_janus_aftercare_done"),
			"the pin input commits the shutdown before the aftercare encounter")


func _janus_both_scans(scan_actions: Dictionary) -> bool:
	return (scan_actions.get(&"scan_low", false) or scan_actions.get(&"scan_wide_low", false)) \
		and (scan_actions.get(&"scan_high", false) or scan_actions.get(&"scan_wide_high", false))


func _check_janus_checkpoint() -> void:
	var boss: JanusBoss
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		if enemy is JanusBoss:
			boss = enemy
			break
	_assert_route(_level().data.id == &"ch3_gate_hall" and boss != null and boss.comm_broken and boss.health.current == 54
		and not boss.shield_cracked and not boss.halted and _player().health.current == 6
		and GameState.get_flag(&"ch3_janus_device_stability") == 90 and GameState.has_flag(&"ch3_janus_comm_broken"),
		"cold Continue retains the real broken communicator and 54 stability while the gatekeeper is active")


func _chapter_three_aftercare() -> void:
	if not _assert_route(_level().data.id == &"ch3_gate_hall" and GameState.has_flag(&"ch3_janus_disabled")
			and not GameState.has_flag(&"ch3_janus_aftercare_done") and GameState.get_flag(&"ch3_janus_device_stability") == 0,
			"the original pin result survives a cold start before aftercare"):
		return
	var credits := Progression.credits
	if not await _input_talk(&"ch3_gatekeeper", [], func() -> bool: return GameState.has_flag(&"ch3_janus_aftercare_done")):
		return
	var gatekeeper := _npc(&"ch3_gatekeeper")
	if not _assert_route(gatekeeper != null and gatekeeper._actor.pose == &"sit" and GameState.has_flag(&"ch3_care_passage_open")
			and Progression.credits == credits + 100, "aftercare seats the living gatekeeper, opens the shortcut and pays exactly 100 credits"):
		return
	await _shot("ne97-ch3-janus-seated")
	if not await _route_portal(&"gate_care"):
		return
	var care_return: Portal = _level()._portals.get(&"mezz_care")
	await _walk_to(care_return.global_position.x + 66.0, 5.0)
	if not await _route_portal(&"mezz_care"):
		return
	gatekeeper = _npc(&"ch3_gatekeeper")
	if not _assert_route(gatekeeper != null and gatekeeper._actor.pose == &"sit" and Progression.credits == credits + 100,
			"the care-passage round trip keeps the gatekeeper seated without paying again"):
		return
	if not await _route_portal(&"gate_lift"):
		return
	for tick in 720:
		if GameState.has_flag(&"ch3_sunlight_reached"):
			break
		await _frames(1)
	if not _assert_route(GameState.has_flag(&"ch3_sunlight_reached"), "the original lift and timed arrival reach the sunlight"):
		return
	if not await _input_talk(&"ch3_light_spot", [], func() -> bool: return true):
		return
	if not await _input_talk(&"ch3_telescope", [], func() -> bool: return true):
		return
	await _route_portal(&"edge_show")


var _clinic_samples := {}


func _trace_clinic_slip() -> void:
	var scene := Story._player
	if Story._current_cinematic != &"ch3_t_c04_counter" or scene == null or scene._stage == null:
		return
	var rin := scene._actors.get(&"rin") as CutsceneActor
	var zhi := scene._actors.get(&"zhi") as CutsceneActor
	if rin == null or zhi == null:
		return
	var paper := scene._stage.prop_node("clinic_review_slip") as StageLayers._Sprite
	if paper == null and not _clinic_samples.has("baseline") and scene._dialogue.is_complete() \
			and scene._dialogue._text.text.begins_with("公開報表在桌上"):
		_clinic_samples["baseline"] = true
		print("NE242_CLINIC_BEFORE ", JSON.stringify({"rin": str(rin.position), "zhi": str(zhi.position), "paper": false}))
		await _shot("ne242-clinic-slip-before")
	if paper == null or not paper.visible or scene._stage._held.is_empty():
		return
	var holder: StagePropHold = scene._stage._held[0]
	var right := paper.to_global(paper.source_point(Vector2(73,45)))
	var left := paper.to_global(paper.source_point(Vector2(19,45)))
	var scale := scene._stage.global_transform.x.length()
	var right_error := zhi.hand_contact_global(&"front").distance_to(right) / scale
	var left_error := rin.hand_contact_global(&"front").distance_to(left) / scale
	var pose := ""
	if holder.owns_actor(zhi) and zhi.hand_target_settled(&"front") and right_error < 0.15:
		if rin.hand_target_settled(&"front") and left_error < 0.15:
			pose = "exchange"
		elif scene._stage.to_local(right).x < 473.0:
			pose = "offer"
	elif holder.owns_actor(rin) and rin.hand_target_settled(&"front") and left_error < 0.15:
		if scene._stage.to_local(left).x < 450.0:
			pose = "received"
	if not pose.is_empty() and not _clinic_samples.has(pose):
		_clinic_samples[pose] = true
		print("NE242_CLINIC_CONTACT ", JSON.stringify({"pose": pose, "left_error": left_error, "right_error": right_error,
			"paper_left": str(scene._stage.to_local(left)), "floor_rin": rin.position.y, "floor_zhi": zhi.position.y,
			"holder": "rin" if holder.owns_actor(rin) else "zhi", "registered": StoryItems.holds(&"ch3_review_slip")}))
		if pose == "offer" and "--clinic-skip-handoff" in OS.get_cmdline_user_args():
			_send_action(&"ui_cancel")
			return
		await _shot("ne242-clinic-slip-%s" % pose)


func _chapter_three_morning_ruler() -> void:
	var before := "--ruler-before" in OS.get_cmdline_user_args()
	var skip := "--ruler-skip" in OS.get_cmdline_user_args()
	var credits := Progression.credits
	var flag := &"room_morning_measured"
	if not _assert_route(_level().data.id == &"ch3_showroom" and not GameState.has_flag(flag), "the genuine campaign is at the unmeasured showroom"):
		return
	if not await _input_talk(&"ch3_lin", ["post"], func() -> bool: return GameState.has_flag(&"ch3_clearwater_tour_started") and StoryItems.holds(&"ch3_tour_card")):
		return
	var npc := _npc(&"ch3_window_morning")
	await _walk_to(npc.global_position.x - 12.0, 5.0)
	await _press(&"interact")
	var contacts: Array[float] = []
	var prior_line := ""
	var lines: Array[String] = []
	var seated := false
	var stood := false
	var seat_ticks := 0
	var skipped := false
	for tick in 2400:
		if GameState.has_flag(flag) and not Story.is_cinematic_active():
			break
		var scene := Story._player
		if scene != null and scene.is_running() and Story._current_cinematic == &"ch3_t_c16_morning":
			var actor := scene._actors.get(&"rin") as CutsceneActor
			var ruler := scene._stage.prop_node("morning_paper_ruler")
			if actor != null and ruler != null and actor.hand_target_settled(&"front"):
				var hand := ruler.to_local(actor.hand_contact_global(&"front"))
				for x: float in [584.0, 600.0]:
					if x not in contacts and hand.distance_to(Vector2(x, 247.0)) < 1.5:
						contacts.append(x)
						print("NE242_RULER_CONTACT ", JSON.stringify({"target": x, "hand": [hand.x, hand.y], "feet": [actor.position.x, actor.position.y], "facing": actor.facing}))
						if x == 600.0 and skip and not skipped:
							skipped = true
							_send_action(&"ui_cancel")
			if not skipped and scene._dialogue.is_complete():
				var line: String = scene._dialogue._text.text
				if not line.is_empty() and line != prior_line:
					prior_line = line
					lines.append(line)
					if lines.size() == 2:
						await _shot("ne242-morning-ruler")
					elif lines.size() == 3:
						await _shot("ne242-morning-invitation")
				if tick % 8 == 0:
					_send_action(&"ui_accept")
			if skip and skipped and scene.choice_active() and tick % 8 == 0:
				_send_action(&"ui_accept")
			if actor != null and actor.pose == &"sit":
				seat_ticks += 1
				if seat_ticks == 38:
					seated = true
					await _shot("ne242-morning-seated")
			if seated and not stood and actor != null and actor.pose == &"idle" and is_equal_approx(actor.position.x, 508.0):
				stood = true
				await _shot("ne242-morning-stood")
		await _frames(1)
	print("NE242_RULER_RESULT ", JSON.stringify({"contacts": contacts, "lines": lines, "seated": seated, "stood": stood, "before": before, "skip": skip, "skip_requested": skipped, "measured": GameState.has_flag(flag), "wallet": Progression.credits}))
	_assert_route(contacts == ([] if before else [584.0, 600.0]), "ruler contact matches the expected build")
	_assert_route(GameState.has_flag(flag) and not Story.is_cinematic_active() and Progression.credits == credits and GameState.get_flag(&"room_choice") == "unset", "real measurement settles the old flag at no cost and leaves the proposal open")
	if skip:
		_assert_route(skipped and not seated, "Escape can still complete the measuring presentation before the chair trial")
	else:
		_assert_route(seated and stood and lines.size() == 3, "the original invitation has all three lines and Rin sits and stands")
	var revisit := &"ch3_t_c16_morning_revisit"
	if await _input_talk(&"ch3_window_morning", [], func() -> bool: return revisit in Story.progress_snapshot()):
		_assert_route(Progression.credits == credits, "the original short revisit retains the balance")
		await _shot("ne242-morning-revisit")


var _stamp_samples := {}


func _trace_showroom_stamp() -> void:
	var scene := Story._player
	if Story._current_cinematic != &"ch3_t_c15_posted" or scene == null:
		return
	var stage := scene._stage
	if stage == null:
		if not _stamp_samples.has("before") and scene._dialogue.is_complete() \
				and scene._dialogue._text.text.begins_with("公開查核件"):
			_stamp_samples["before"] = true
			await _shot("ne242-showroom-stamp-before")
		return
	var stamp := stage.prop_node("showroom_receipt_stamp") as StageLayers._Sprite
	var paper := stage.prop_node("showroom_posted_notice") as StageLayers._Sprite
	var ink := stage.prop_node("showroom_receipt_mark")
	var lin := scene._actors.get(&"lin") as CutsceneActor
	if stamp == null or paper == null or ink == null or lin == null:
		return
	var base := stage.to_local(stamp.to_global(stamp.source_point(Vector2(23.5,50.5))))
	var surface := stage.to_local(paper.to_global(paper.source_point(Vector2(48,43))))
	var target := stage.to_local(stamp.to_global(stamp.source_point(Vector2(23.5,12.5))))
	var hand := stage.to_local(lin.hand_contact_global(&"front"))
	var pose := ""
	if stage.prop_held("showroom_receipt_stamp") and ink.visible and base.distance_to(surface) < 0.15:
		pose = "press"
	elif _stamp_samples.has("press") and ink.visible and not stage.prop_held("showroom_receipt_stamp") and not lin.hand_targets_active():
		pose = "restored"
	if not pose.is_empty() and not _stamp_samples.has(pose):
		_stamp_samples[pose] = true
		print("NE242_SHOWROOM_STAMP ", JSON.stringify({"phase": pose,"hands": hand.distance_to(target),
			"ink": ink.visible,"contact": base.distance_to(surface),"base": [base.x,base.y],
			"surface": [surface.x,surface.y],"posted": GameState.has_flag(&"ch3_clearwater_tour_started")}))
		if pose == "press" and "--showroom-stamp-skip" in OS.get_cmdline_user_args():
			_send_action(&"ui_cancel")
			return
		await _shot("ne242-showroom-stamp-%s" % pose)


func _chapter_three_showroom_stamp() -> void:
	var before := "--showroom-stamp-before" in OS.get_cmdline_user_args()
	var skip := "--showroom-stamp-skip" in OS.get_cmdline_user_args()
	var later := "--showroom-stamp-later" in OS.get_cmdline_user_args()
	var credits := Progression.credits
	if not _assert_route(_level().data.id == &"ch3_showroom" and not GameState.has_flag(&"ch3_clearwater_tour_started"),
			"the genuine campaign is at the unchecked showroom reception"):
		return
	if later:
		var welcome := &"ch3_t_c15_welcome"
		if await _input_talk(&"ch3_lin", ["later"], func() -> bool: return welcome in Story.progress_snapshot()):
			_assert_route(_stamp_samples.is_empty() and Progression.credits == credits and not StoryItems.holds(&"ch3_tour_card")
					and not GameState.has_flag(&"ch3_clearwater_tour_started"), "waiting leaves the tour and stamp unopened without a charge")
			await _shot("ne242-showroom-stamp-later")
		return
	if not await _input_talk(&"ch3_lin", ["post"], func() -> bool:
			return GameState.has_flag(&"ch3_clearwater_tour_started") and StoryItems.holds(&"ch3_tour_card")):
		return
	var expected := ["before"] if before else (["press"] if skip else ["press", "restored"])
	_assert_route(_stamp_samples.keys() == expected, "the real posting is presented with the expected stamp phases")
	_assert_route(credits == Progression.credits and GameState.get_flag(&"room_choice") == "unset", "the actual desk opens the tour without a deposit or a proposal")
	if "--showroom-stamp-then-morning" in OS.get_cmdline_user_args():
		await _input_talk(&"ch3_window_morning", [], func() -> bool: return GameState.has_flag(&"room_morning_measured"))


func _chapter_three_showroom() -> void:
	if not _assert_route(_level().data.id == &"ch3_showroom" and GameState.has_flag(&"ch3_sunlight_reached"), "resumed inside the showroom after the actual sunlight route"):
		return
	var credits := Progression.credits
	if not await _input_talk(&"ch3_lin", ["post"], func() -> bool: return GameState.has_flag(&"ch3_clearwater_tour_started") and StoryItems.holds(&"ch3_tour_card")):
		return
	if not _assert_route(Progression.credits == credits and GameState.get_flag(&"room_choice") == "unset", "posting the objection starts the tour without collecting a deposit"):
		return
	for window in ["morning", "quiet", "late"]:
		var measured := StringName("room_%s_measured" % window)
		if not await _input_talk(StringName("ch3_window_%s" % window), [], func() -> bool: return GameState.has_flag(measured)):
			return
		await _shot("ne97-ch3-measured-%s" % window)
	if not await _input_talk(&"ch3_lin", ["propose", "quiet"], func() -> bool: return GameState.has_flag(&"sq3_room_proposal_done") and GameState.get_flag(&"room_choice") == "quiet"):
		return
	if not _assert_route(Progression.credits == credits + 20, "the first measured-room proposal pays exactly 20 credits"):
		return
	if not await _input_talk(&"ch3_lin", ["propose", "late"], func() -> bool: return GameState.get_flag(&"room_choice") == "late"):
		return
	if not _assert_route(Progression.credits == credits + 20, "changing the proposal updates the room without paying a second time"):
		return
	if not await _input_talk(&"ch3_lin", ["ask"], func() -> bool: return GameState.has_flag(&"ch3_lin_asked")):
		return
	if not await _input_talk(&"ch3_lin", ["finish"], func() -> bool: return GameState.has_flag(&"ch3_clearwater_tour_done")):
		return
	await _route_portal(&"show_hall")


func _chapter_three_office_first() -> void:
	var established := _level().data.id == &"ch3_office_hall" and GameState.has_flag(&"ch3_clearwater_tour_done")
	if not _assert_route(established and GameState.get_flag(&"room_choice") == "late", "reaching the original office preserves the showroom proposal"):
		return
	var credits := Progression.credits
	if not await _input_talk(&"ch3_petition_box", ["read", "listen", "leave"],
			func() -> bool: return GameState.has_flag(&"ch3_trade_half_heard") and GameState.has_flag(&"ch3_petition_receipt_taken")):
		return
	if not _assert_route(GameState.has_flag(&"sq7_ye_name_seen") and not GameState.has_flag(&"ch3_trade_listened")
			and not GameState.has_flag(&"ch3_trade_overheard") and Progression.credits == credits + 20,
			"the optional handwriting gives its one reward and leaving halfway records only the first half"):
		return
	await _shot("ne97-ch3-office-stepped-away")


func _chapter_three_office_last() -> void:
	var record_only := "--office-record-only" in OS.get_cmdline_user_args()
	var entry := &"ch3_t_c20_react" if record_only else &"ch3_t_c20_middle"
	if not _assert_route(_level().data.id == &"ch3_office_hall" and GameState.has_flag(&"ch3_trade_half_heard")
			and GameState.has_flag(&"ch3_trade_listened") == record_only and Story.resolve_dispatch(&"ch3_dispatch_bench") == entry,
			"a cold continuation resumes the original conversation at the waiting bench, halfway through"):
		return
	var middle_choice := "stay" if "--office-stay" in OS.get_cmdline_user_args() else "door"
	if not await _input_talk(&"ch3_waiting_bench", ["record"] if record_only else [middle_choice, "record"],
			func() -> bool: return GameState.has_flag(&"ch3_trade_overheard") and GameState.has_flag(&"ch3_l2_route_announced")):
		var player: CutscenePlayer = Story._player
		if is_instance_valid(player):
			print("NE97_OFFICE_HALTED ", player.scene_id, " step=", player.get("_current_where"), " process=", Engine.get_process_frames())
		return
	if not _assert_route(StoryItems.holds(&"ch3_trade_note") and StoryItems.holds(&"ch3_petition_receipt"), "the actual confirmation retains both the trade note and petition receipt"):
		return
	await _shot("ne97-ch3-office-recorded")
	for portal in [&"hall_edge", &"edge_lift", &"gate_care", &"mezz_lift", &"plaza_street"]:
		if not await _route_portal(portal):
			return
	_assert_route(_level().data.id == &"ch3_pawnshop" and GameState.has_flag(&"ch3_trade_overheard"), "the real home route returns to the evening pawnshop")


func _chapter_three_office_recovery() -> void:
	var actor := _npc(&"ch3_petition_box")
	if not _assert_route(_level().data.id == &"ch3_office_hall" and Story._current_cinematic == &"ch3_t_c19_watch"
			and actor != null and actor.get("_talking") and GameState.has_flag(&"ch3_petition_receipt_taken")
			and StoryItems.holds(&"ch3_intake_receipt") and not GameState.has_flag(&"ye_handwriting_seen"),
			"the original actor resumes the older blocked save after the receipt"):
		return
	var balance := Progression.credits
	var choices := ["read", "listen", "leave"]
	for tick in 4400:
		if choices.is_empty() and not Story.is_cinematic_active():
			break
		var cutscene: CutscenePlayer = Story._player
		if cutscene != null and cutscene.choice_active() and not choices.is_empty():
			var wanted: String = choices.front()
			var option := cutscene._choice_options.find_custom(func(current: Dictionary) -> bool: return str(current.get("id", "")) == wanted)
			if not _assert_route(option >= 0, "the recovered scene offers choice %s" % wanted):
				return
			choices.pop_front()
			cutscene.choose(option)
		elif tick % 8 == 0:
			_send_action(&"ui_accept")
		await _frames(1)
	if not _assert_route(choices.is_empty() and GameState.has_flag(&"ch3_trade_half_heard") and StoryItems.holds(&"ch3_intake_receipt")
			and GameState.has_flag(&"sq7_ye_name_seen") and Progression.credits == balance + 20,
			"the older save finishes the follow-up with the original receipt and exactly one name reward"):
		return
	await _shot("ne97-ch3-office-recovered")


func _chapter_three_ending() -> void:
	if not _assert_route(_level().data.id == &"ch3_pawnshop" and GameState.has_flag(&"ch3_trade_overheard")
			and not GameState.has_flag(&"ch3_shore_closed"), "cold continuation opens the evening pawnshop after the full return journey"):
		return
	if not await _input_talk(&"ch3_old_k_kitchen", ["note"], func() -> bool: return GameState.has_flag(&"ch3_home_supper_done")):
		return
	if not _assert_route(GameState.has_flag(&"ch3_umbrella_asked_twice"), "the kitchen conversation asks about the umbrella twice and puts the note away"):
		return
	if GameState.has_flag(&"m3_available"):
		if not await _input_talk(&"ch3_unsigned_record", [], func() -> bool: return GameState.has_flag(&"m3_seen")):
			return
	if not await _input_talk(&"ch3_shop_radio", ["tell", "agree"], func() -> bool: return GameState.has_flag(&"ch3_shore_closed")):
		return
	await _chapter_three_cold_ending()


func _chapter_three_cold_ending() -> void:
	for tick in 2400:
		if _main.get("_screen") is VictoryScreen and not _main.call("_route_pending"):
			break
		await _frames(1)
	var victory := _main.get("_screen") as VictoryScreen
	if not _assert_route(victory != null and victory.chapter == &"ch3_clearwater" and GameState.has_flag(&"ch3_shore_closed")
			and GameState.has_flag(&"ch3_told_egret_trade") and GameState.deaths == 1, "the genuine ending shows the third-chapter victory screen and preserves the single earlier flood death"):
		return
	var catalog := QuestCatalog.new()
	catalog.load_story_sources()
	var open_main := catalog.list_for("ch3_clearwater", "main", false, GameState.world_flags)
	_assert_route(catalog.issues.is_empty() and open_main.is_empty() and StoryItems.holds(&"ch3_trade_note")
			and GameState.get_flag(&"room_choice") == "late", "all Third Chapter main quests close and the trade note and proposal survive")
	await _shot("ne97-ch3-victory")
