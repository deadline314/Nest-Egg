extends "res://tests/smoke_test.gd"

class SlowRender extends Node:
	var delayed := 0

	func _process(_dt: float) -> void:
		for actor: Node in Fx._frozen:
			if actor is Player:
				delayed += 1
				print("HITSTOP_DELAY ", Engine.get_physics_frames(), " HP stage preserved")
				OS.delay_msec(120)
				return

func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	Engine.max_physics_steps_per_frame = 1
	var use_candidate := "--candidate" in OS.get_cmdline_user_args()
	var slow := SlowRender.new()
	slow.process_priority = -100
	slow.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(slow)
	var suite: MeleeSuite = preload("short-candidate.gd").new(self) if use_candidate else MeleeSuite.new(self)
	for i in 4:
		await suite._test_expired_early_command()
	print("DELAYED_REAL_HITS ", slow.delayed)
	_check(slow.delayed == 4, "the slow render observer sees every real local hitstop")
	await _finish()
