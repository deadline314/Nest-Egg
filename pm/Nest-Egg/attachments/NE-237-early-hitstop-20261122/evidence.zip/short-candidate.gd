extends MeleeSuite

func _test_expired_early_command() -> void:
	await open_level(10.0)
	var player := level.player
	# 用真長起手武器確保期限先到；快速頭招在正常速度下可能合法接續。
	player.loadout.reset(load("res://data/weapons/melee/melee_maul.tres") as WeaponData)
	var enemy := await _target_at(-16.0)
	check(player._try_melee() and player._try_melee(), "an early windup press queues one real command")
	var damage := int(player._melee_attack["damage"])
	check(float(player._melee_attack["windup"]) > MeleeData.buffer_time(), "the real long windup outlasts the command without changing timing data")
	var deadline := player._melee_commands._deadline_ms
	var observed_hitstop := [false]
	var capture_hitstop := func() -> void:
		observed_hitstop[0] = Fx.is_frozen(player) and Fx.is_frozen(enemy)
	# Observe the deferred Feel call in the same message flush, before the next frame can thaw it.
	var on_hit := func(_point: Vector2, _killed: bool) -> void: capture_hitstop.call_deferred()
	EventBus.hit_confirmed.connect(on_hit, CONNECT_DEFERRED | CONNECT_ONE_SHOT)
	var auto_chained := false
	var guard := 180
	while player._melee_phase != Player.MeleePhase.NONE and guard > 0:
		auto_chained = auto_chained or player._melee_index > 0
		await physics_frames(1)
		guard -= 1
	if EventBus.hit_confirmed.is_connected(on_hit):
		EventBus.hit_confirmed.disconnect(on_hit)
	check(guard > 0, "the expired-command swing naturally finishes within its physics guard")
	check(observed_hitstop[0] and enemy.health.current == 999 - damage, "the early-command regression includes one real hit and natural local hitstop")
	check(player._melee_commands.remaining() == 0.0 and player._melee_commands._deadline_ms == deadline, "the old command really expires without extending its deadline through hitstop")
	check(not auto_chained, "an early command that expires before cancellation cannot automatically advance the combo")
	_combo_trace("expired-early-command", player, enemy)
	await _frames_until(player, Player.MeleePhase.NONE)
	await physics_frames(3)
	await end_level(level)


