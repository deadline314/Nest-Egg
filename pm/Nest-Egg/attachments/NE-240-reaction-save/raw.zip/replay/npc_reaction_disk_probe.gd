extends "res://tools/run_save_probe.gd"
## Explicit optional-once fixture; no authored campaign reaction is changed.

func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	var data := NpcData.new()
	data.id = &"reaction_disk_fixture"
	var once := NpcReaction.new()
	once.gesture = &"greet"
	once.once = true
	data.reactions.append(once)
	var npc := NpcActor.new()
	npc.configure(data, Vector2i(1, 2))
	npc.awareness = NpcAwareness.new(null, data)
	var key := npc.state_key()
	var store := RunSaveStore.new(_directory.path_join("reaction.json"))
	store.validator = RunSnapshot.prepare
	if _mode == "write":
		_check(data.pick_reaction(0, Callable(), 0, Callable(), Callable(), {}) == 0, "explicit optional-once fixture is initially eligible")
		npc.awareness.restore([0])
		npc.talk_count = 3
		npc.claimed[1] = true
		var world := {key: npc.capture_state()}
		var captured := RunSnapshot.capture("res://data/levels/ch1_pawnshop.tres", {"position": [100, 160], "health": 4, "world": world, "area": {"consumed": {}, "damage": {}, "world": world}, "loadout": {}})
		captured["state"]["checkpoint_world"] = world.duplicate(true)
		captured["state"]["area_states"] = {"ch1_pawnshop": {"consumed": {}, "damage": {}, "world": world.duplicate(true)}}
		_check(store.write(captured, true), "first actual process writes all four whole-run world containers")
	else:
		var loaded := store.read()
		_check(not loaded.is_empty(), "second actual process reads the complete run from disk")
		if not loaded.is_empty():
			for item: Array in [["runtime", loaded["runtime"]["world"]], ["area", loaded["runtime"]["area"]["world"]], ["checkpoint", loaded["state"]["checkpoint_world"]], ["persistent", loaded["state"]["area_states"]["ch1_pawnshop"]["world"]]]:
				npc.restore_state(item[1].get(key))
				_check(npc.awareness.capture() == [0] and npc.talk_count == 3 and npc.claimed.has(1), "actual NPC owner restores reaction, talks and claims: " + item[0])
				_check(data.pick_reaction(0, Callable(), 0, Callable(), Callable(), npc.awareness.reacted) == -1, "restored optional-once reaction is ineligible: " + item[0])
	npc.free()
	await _finish()
