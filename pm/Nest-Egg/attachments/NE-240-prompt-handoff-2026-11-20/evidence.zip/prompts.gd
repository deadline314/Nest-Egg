extends "D:/NestEggVerification/evidence-20261120-ne240-prompts/reference/combat-route.gd"

var _gate: MechanismSwitch
var _pump: NpcActor
var _record := false
var _samples: Array[Dictionary] = []


func _chapter_one_flood() -> void:
	var args := OS.get_cmdline_user_args()
	_gamepad = "--gamepad" in args
	Settings.set_ui_text_scale(1.2 if "--large" in args else 1.0)
	Settings.set_reduce_ui_motion("--large" in args)
	if not _assert_route(_level().data.id == &"ch1_warehouse" and GameState.has_flag(&"watchdog_defeated"), "stored authored warehouse past Watchdog"):
		return
	print("CONNECTED_JOYPADS ", Input.get_connected_joypads())
	_accept_radio = true
	await _walk_to(77.5 * 16.0)
	await _press(&"interact")
	for tick in 750:
		if GameState.checkpoint_applies(_level().data.resource_path) and not _player().is_on_phone():
			break
		await _frames(1)
	_assert_route(GameState.checkpoint_applies(_level().data.resource_path), "normal telephone booth stores the checkpoint")
	for node in get_tree().get_nodes_in_group(WorldState.GROUP):
		if node is MechanismSwitch and node.data.id == &"ch1_switch_a":
			_gate = node
			break
	_pump = _npc(&"ch1_pump_service")
	if not _assert_route(is_instance_valid(_gate) and is_instance_valid(_pump), "original gate A and original shell are present"):
		return
	await _walk_to(_gate.global_position.x, 5.0)
	await _match_input_family()
	await _frames(20)
	var key_label := InputBindings.primary_label(&"interact")
	_assert_route(InputBindings.using_gamepad == _gamepad and _prompt_ready(_gate._prompt, key_label) and _pump._prompt._alpha == 0.0,
		"gate-only prompt uses the device's mapped key " + key_label)
	await _shot("gate-prompt")
	await _mapped_interaction()
	_assert_route(_gate.active and not Story.is_cinematic_active() and not GameplayLock.is_locked(),
		"one mapped interaction opens only the gate and preserves movement")
	_record = true
	await _walk_to(_pump.global_position.x, 5.0)
	await _frames(20)
	_record = false
	var settled := _samples.filter(func(sample: Dictionary) -> bool:
		return sample["gate"] > 0.1 and sample["pump"] > 0.1)
	var data := FileAccess.open(_out.path_join("samples.json"), FileAccess.WRITE)
	if data == null:
		_assert_route(false, "transition samples can be written")
		return
	data.store_string(JSON.stringify({"gamepad":_gamepad, "large":"--large" in args, "samples":_samples, "both_visible":settled}, "  "))
	data.close()
	print("NE240_PROMPTS exposed both for ", settled.size(), " frames of ", _samples.size())
	for sample: Dictionary in settled:
		if sample["gate"] > 0.35 and sample["pump"] > 0.35:
			print("NE240_PROMPTS both are readable ", sample)
			break
	_assert_route(_prompt_ready(_pump._prompt, key_label) and _gate._prompt._alpha == 0.0 and not Story.is_cinematic_active(),
		"pump-only prompt is readable with mapped key " + key_label)
	await _shot("pump-prompt")
	await _mapped_interaction()
	for tick in 240:
		if Story._current_cinematic == &"ch1_t_pump_check" and is_instance_valid(Story._player) and Story._player.choice_active():
			break
		if is_instance_valid(Story._player) and Story._player._dialogue.visible:
			Story._player._dialogue.complete()
			Story._player._advance_requested = true
		await _frames(1)
	_assert_route(Story._current_cinematic == &"ch1_t_pump_check" and not GameState.has_flag(&"ch1_pump_case_reset"),
		"separate mapped interaction opens authored repair choice without committing a repair")
	await _shot("pump-choice")


func _match_input_family() -> void:
	if _gamepad:
		await _touch_gamepad()
	else:
		var key := InputEventKey.new()
		key.physical_keycode = KEY_F13
		await _send_pressed(key)


func _mapped_interaction() -> void:
	for mapping: InputEvent in InputMap.action_get_events(&"interact"):
		if (_gamepad and mapping is InputEventJoypadButton) or (not _gamepad and mapping is InputEventKey):
			var key := mapping.duplicate() as InputEvent
			if key is InputEventJoypadButton:
				key.device = 0
			if key is InputEventKey:
				key.keycode = key.physical_keycode if key.physical_keycode != 0 else key.keycode
				key.physical_keycode = key.keycode
			print("NE240_BUTTON ", key.as_text(), " device=", key.device, " mapped=", key.is_action(&"interact"))
			await _send_pressed(key)
			return
	_assert_route(false, "the intended device has a mapped interaction")


func _send_pressed(key: InputEvent) -> void:
	key.set("pressed", true)
	Input.parse_input_event(key)
	Input.flush_buffered_events()
	print("NE240_BUTTON_STATE ", Input.is_action_pressed(&"interact"), " just=", Input.is_action_just_pressed(&"interact"))
	await _frames(2)
	var release := key.duplicate() as InputEvent
	release.set("pressed", false)
	Input.parse_input_event(release)
	Input.flush_buffered_events()
	await _frames(2)


func _prompt_ready(prompt: WorldPrompt, binding: String) -> bool:
	if not is_instance_valid(prompt) or not prompt.is_showing() or prompt._alpha < 0.9 or not prompt._display_text.contains(binding):
		return false
	var rect := _screen_rect(prompt)
	return get_viewport().get_visible_rect().encloses(rect)


func _screen_rect(prompt: WorldPrompt) -> Rect2:
	return prompt.get_global_transform_with_canvas() * Rect2(prompt._box.position + prompt._nudge, prompt._box.size)


func _frames(n: int) -> void:
	for i in n:
		await super._frames(1)
		if _record:
			var gate_rect := _screen_rect(_gate._prompt)
			var pump_rect := _screen_rect(_pump._prompt)
			_samples.append({"x": _player().global_position.x, "gate":_gate._prompt._alpha, "pump":_pump._prompt._alpha,
				"gate_target":Story.framing.is_interaction_prompt_target(_gate), "pump_target":Story.framing.is_interaction_prompt_target(_pump),
				"gate_range":_gate.interaction_available(), "pump_range":_pump.interaction_available(),
				"gate_screen_rect":str(gate_rect), "pump_screen_rect":str(pump_rect), "overlap":gate_rect.intersects(pump_rect)})
			if _gate._prompt._alpha > 0.35 and _pump._prompt._alpha > 0.35 and not FileAccess.file_exists(_out.path_join("transition.png")):
				await RenderingServer.frame_post_draw
				var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
				var code := image.save_png(_out.path_join("transition.png"))
				_assert_route(code == OK, "both prompts captured in the same native frame")
