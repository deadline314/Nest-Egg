extends "res://tests/smoke_test.gd"


func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = false
	var suite := Chapter1MapSuite.new(self)
	await preload("D:/NestEggVerification/evidence-20261120-ne240-prompts/maintenance-checks.gd")._switch_and_pump_select_one_target(suite)
	await _finish()
