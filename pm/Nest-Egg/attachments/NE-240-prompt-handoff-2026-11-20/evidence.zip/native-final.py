from pathlib import Path
from hashlib import sha256
from subprocess import run
from shutil import copyfile
import json
import os
import sys

base = Path(__file__).resolve().parent
shared = base.parent/'ne218-baseline-20261117'
root=Path.cwd()
python = Path(sys.executable)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def render(case, scene, args, fixed, resolution):
    out=base/case
    out.mkdir(exist_ok=False)
    (out/'save').mkdir()
    copyfile(base/'reference/fixture/slot.json',out/'save/slot.json')
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        var = out/'profile'/key
        var.mkdir(parents=True)
        env[key]=str(var)
    command = [str(python),str(shared/'tools/comfyui/gpu_lock.py'),'--',engine,
               '--path',str(shared),'--resolution',resolution,'--position','10,90',
               '--rendering-method','forward_plus','--rendering-driver','vulkan']
    if fixed:
        command.extend(('--fixed-fps','60'))
    command.append(str(scene))
    command.extend(('--',*[a.replace('{out}',out.as_posix()) for a in args]))
    (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=650)
    (out/'exit.txt').write_text(str(result.returncode)+'\n',encoding='utf-8')
    raw=(out/'raw.log').read_text(encoding='utf-8')
    print(case,result.returncode,len(raw),flush=True)
    assert result.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw
    return raw







for case, settings, resolution in (('keyboard',(), '1280x720'), ('gamepad',('--gamepad',), '1280x720'),
                                   ('keyboard-large',('--large',), '960x540'),
                                   ('gamepad-large',('--gamepad','--large'), '960x540')):
    text=render('fixed-'+case,base/'prompts-final.tscn',['--out={out}','--save-dir={out}/save','--from-save','--flood',*settings],True,resolution)
    assert 'FAIL ' not in text and 'NE240_PROMPTS exposed both for 0 frames' in text