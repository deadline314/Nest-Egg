from hashlib import sha256
from io import BytesIO
from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw
import sys

base=Path(__file__).resolve().parent
root=Path.cwd()
sys.path.insert(0,str(root/"tools/comfyui"))
from cut_layers import part_transform, render_part

role="egret"
spec=json.loads((root/f"tools/comfyui/specs/{role}_side.json").read_bytes())
scale=spec["tex_px_per_wp"]/spec["illustration_px_per_wp"]
joints={name:np.asarray(point,float)*scale for name,point in spec["joints"].items()}
candidate=base/f"{role}-patch-a"
materials={}
for piece in ("torso","arm_upper"):
    images=[Image.open(path).convert("RGBA") for path in (
        root/f"art_src/characters/{role}/07_refined/{piece}.png",candidate/f"source-{piece}.png")]
    rule=spec["parts"][piece]
    transforms=[part_transform(img,rule,joints,scale) for img in images]
    assert all(np.array_equal(old,new) for old,new in zip(*transforms))
    arrays=[np.asarray(img) for img in images]
    assert np.array_equal(arrays[0][arrays[0][:,:,3]>=128], arrays[1][arrays[0][:,:,3]>=128])
    for name,before,after in ((piece,base/f"preinstall/art/characters/{role}/parts/{piece}.png",candidate/f"{piece}.png"),
                              (piece+"_n",base/f"preinstall/art/characters/{role}/parts/{piece}_n.png",candidate/f"{piece}_n.png")):
        old,new=[np.asarray(Image.open(path).convert("RGBA")) for path in (before,after)]
        assert old.shape==new.shape
        if name==piece:
            for src, transform, texture in zip(images,transforms,(old,new)):
                assert np.array_equal(render_part(src,transform,scale,crop_phase=rule.get("crop_phase")),texture)
        materials[name]={"shape":list(new.shape), "changed":int(np.count_nonzero(np.any(old!=new,axis=2)))}
    materials[piece]["source_changed"]=int(np.count_nonzero(np.any(arrays[0]!=arrays[1],axis=2)))
    materials[piece]["approved_sha256"]=sha256((root/f"art_src/characters/{role}/07_refined/{piece}.png").read_bytes()).hexdigest()
    materials[piece]["affine"]=transforms[0][0].tolist()

before,after=[json.loads((base/f"egret-{stage}/run.json").read_bytes()) for stage in ("stock","preview-a")]
assert before["enclosed"]==8 and after["enclosed"]==0
assert after["samples"]==before["samples"]==16800 and before["loose"]==after["loose"]==0
edges=json.loads((base/"egret-preview-a-edges.json").read_bytes())
assert edges["with_alpha_loss"]==0
live_roots=[base/f"rooftop-{label}" for label in ("stock-b","preview-a")]
live=[json.loads((folder/"rooftop.json").read_bytes()) for folder in live_roots]
assert live[0]==live[1] and len(live[0]["rows"])==24 and live[0]["restored_pose"]=="lean"
assert live[0]["rendering_method"]=="forward_plus" and live[0]["hdr_2d"] and "9070 XT" in live[0]["adapter"]
assert all(row["visible"] and row["world"]==[872.0,800.0] for row in live[0]["rows"])
shoulder=live[0]["rows"][0]["shoulder"]
details=Image.new("RGB",(696,362),(32,36,45))
draw=ImageDraw.Draw(details)
for index,stage in enumerate(("stock","preview-a")):
    x=12+index*342
    draw.text((x,10),"Before" if index==0 else "After",fill=(233,236,240))
    atlas=base/f"egret-{stage}/frames/wave_3.4_018.png"
    with Image.open(atlas) as tile:
        tile=tile.convert("RGBA").crop((936,40,984,88)).resize((336,336),Image.Resampling.NEAREST)
    checker=Image.new("RGBA",tile.size)
    grid=ImageDraw.Draw(checker)
    for row in range(0,336,28):
        for col in range(0,336,28):
            grid.rectangle((col,row,col+27,row+27),fill=((160,114,155,255) if (row+col)//28%2 else (232,174,212,255)))
    checker.alpha_composite(tile)
    details.paste(checker.convert("RGB"),(x,25))
details.save(base/"egret-wave-detail.png")
result={"materials":materials, "audit":{"samples":after["samples"],"enclosed":[before["enclosed"],after["enclosed"]],
    "edge_only":[before["edge_notch_only"],after["edge_notch_only"]], "new_edge_flags":edges["new_edge_notch_flags"],
    "new_edge_flags_with_alpha_loss":edges["with_alpha_loss"],"loose":[before["loose"],after["loose"]]},
    "authored_rooftop":live[1]}
(base/"egret-delivery.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"materials":materials,"audit":result["audit"],"rooftop_matched_rows":len(live[1]["rows"])},indent=2))
