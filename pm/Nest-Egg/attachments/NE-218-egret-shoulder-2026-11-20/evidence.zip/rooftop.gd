extends Node

const Capture := preload("res://tools/viewport_capture.gd")

var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		_fail("Expected native rendering and an absolute output path")
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _fail(reason: String) -> void:
	printerr(reason)
	get_tree().quit(1)


func _run() -> void:
	Settings.use_storage("user://npc_contact_rooftop.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Settings.set_brightness(0.5)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(preload("res://data/levels/ch1_rooftop.tres"))
	add_child(level)
	var target: NpcActor
	for node in level._entities.get_children():
		if node is NpcActor and node.data.id == &"ch1_egret":
			target = node
			break
	if target == null or not target.is_present() or target.data.rig_id != "egret":
		_fail("The authored rooftop Egret is absent")
		return
	level._lighting._lightning_gap = 1.0e9
	for node in level.find_children("*", "", true, false):
		if node is ChapterCard:
			node.queue_free()
	target.set_physics_process(false)
	var actor: CutsceneActor = target._actor
	actor.set_process(false)
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.offset = Vector2.ZERO
	camera.global_position = target.global_position + Vector2(0, -37)
	camera.reset_smoothing()
	for zoom: float in [LevelCamera.base_zoom(), 3.4]:
		camera.zoom = Vector2.ONE * zoom
		camera.force_update_scroll()
		for direction: int in [-1, 1]:
			actor.face(direction)
			actor.set_loop(&"")
			actor.set_talking(false)
			actor.set_listening(false)
			if not target.present_pose(&"idle"):
				_fail("Could not set the controlled posture")
				return
			for frame in 180:
				actor._advance_stage_actor(1.0 / 60.0)
			target.present_pose(&"wave")
			for frame in 60:
				actor._advance_stage_actor(1.0 / 60.0)
				if frame not in [0, 18, 19, 20, 21, 46]:
					continue
				await get_tree().process_frame
				await RenderingServer.frame_post_draw
				var key := "%s_%d_%02d" % ["left" if direction < 0 else "right", roundi(100.0 * zoom), frame]
				var shoulder := camera.get_canvas_transform() * target.bone_global(&"arm_front_upper")
				if not shoulder.is_finite() or not get_viewport().get_visible_rect().has_point(shoulder):
					_fail("Front shoulder is outside the rooftop capture: " + str(shoulder))
					return
				if Capture.image(get_viewport()).save_png(_out.path_join(key + ".png")) != OK:
					_fail("Cannot save rooftop capture " + key)
					return
				var animator := actor.rig.animator as NpcAnimator
				if not animator._use_npc or animator._pose_now != &"stand" or animator._loop_name != &"" or not actor._input.waving:
					_fail("Unexpected live NPC animation state")
					return
				_rows.append({"key": key, "zoom": zoom, "facing": actor.facing, "frame": frame,
					"shoulder": [shoulder.x, shoulder.y], "world": [target.global_position.x, target.global_position.y],
					"actor": str(target.data.id), "pose": str(actor.pose), "visible": actor.rig.is_visible_in_tree()})
	target.refresh_pose()
	if actor.pose != target.data.pose:
		_fail("Authored pose failed to restore")
		return
	var file := FileAccess.open(_out.path_join("rooftop.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"adapter": RenderingServer.get_video_adapter_name(),
		"rendering_method": RenderingServer.get_current_rendering_method(), "hdr_2d": get_viewport().use_hdr_2d,
		"restored_pose": str(actor.pose), "rows": _rows}, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit()

