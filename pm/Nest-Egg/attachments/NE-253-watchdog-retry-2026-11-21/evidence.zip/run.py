from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
sha = lambda payload: sha256(payload).hexdigest()
name = sys.argv[1]
cold = "--cold-proof" in sys.argv
if cold:
    previous = base / sys.argv[sys.argv.index("--cold-proof") + 1]
    seed = previous / "death-primary.json"
    accept = json.loads((previous / "verified.json").read_bytes())
    payload = seed.read_bytes()
    assert sha(payload) == accept["captured_death_sha256"]
else:
    seed = root / "work/ne97-campaign-route-20261119/native-blockade-v3/save/slot.json"
    if not seed.exists() and (base / "original-warehouse.json").exists():
        seed = base / "original-warehouse.json"
    payload = seed.read_bytes()
    assert sha(payload) == "1908995cac2922a1480cef223532c4ed75cca394b78dce0fe6bbd5bc8105d89c"
out = base / name
out.mkdir()
if cold:
    (out / "before-death.json").write_bytes((previous / "before-death.json").read_bytes())
save = out / "save"
save.mkdir()
(save / "slot.json").write_bytes(payload)
(out / "original.json").write_bytes(payload)
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "XDG_DATA_HOME", "XDG_CONFIG_HOME", "TEMP", "TMP", "TMPDIR"):
    d = out / key
    d.mkdir()
    env[key] = str(d)
paths = ("game/enemies/watchdog.gd", "game/enemies/boss/pattern_boss.gd", "game/level/level.gd",
         "game/main.gd", "data/levels/ch1_warehouse.tres", "data/bosses/watchdog.json", "core/run_destination.gd")
source = {name: sha((game / name).read_bytes()) for name in paths}
argv = [sys.executable, "-B", str(game / "tools/comfyui/gpu_lock.py"), "--",
        "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(game),
        "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--audio-driver", "Dummy",
        "--fixed-fps", "60", "--resolution", "1280x720", "--quit-after", "21000", str(base / "retry.tscn"), "--",
        "--from-save", "--warehouse", "--defensive-watchdog", f"--out={out}", f"--save-dir={save}", *sys.argv[2:]]
(out / "command.json").write_text(json.dumps({"argv": argv, "source": source, "seed_sha256": sha(payload),
      "head": subprocess.check_output(["git","rev-parse","HEAD"],cwd=game).decode().strip()}, indent=2) + "\n")
with (out / "engine.log").open("wb") as log:
    process = subprocess.run(argv, cwd=game, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=360)
raw = (out / "engine.log").read_text(encoding="utf-8", errors="replace")
print(raw[-16000:], flush=True)
assert process.returncode == 0 and not re.search(r"^SCRIPT ERROR:|^ERROR:|^FAIL ", raw, re.M)
assert all(sha((game / name).read_bytes()) == digest for name, digest in source.items())
death = (out / "death-primary.json").read_bytes() if not cold else payload
decoded = lambda data: json.loads(json.loads(data)["payload"])
saved_dead = decoded(death)
assert saved_dead["runtime"]["dead"] and saved_dead["state"]["deaths"] == 1
assert not saved_dead["story"]["flags"].get("watchdog_defeated",False)
assert saved_dead["runtime"]["death_cause"].startswith("watchdog")
receipt={"captured_death_sha256":sha(death),"cold":cold,"source":source}
if "--death-primary-only" not in sys.argv:
    row = json.loads((out / "result.json").read_bytes())
    exit_primary = decoded((save / "slot.json").read_bytes())
    assert row["cold"] is cold and row["deaths"] == 1 and row["lost"] < row["max"] and not row["failures"]
    assert exit_primary["story"]["flags"].get("watchdog_defeated") is True
    assert exit_primary["state"]["deaths"] == 1
    receipt["victory_sha256"]=sha((save / "slot.json").read_bytes())
    receipt["reentered"]=row
(out / "verified.json").write_text(json.dumps(receipt,indent=2)+"\n")
