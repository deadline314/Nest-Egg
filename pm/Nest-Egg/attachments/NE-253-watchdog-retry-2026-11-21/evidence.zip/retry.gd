extends "D:/NestEggVerification/evidence-20261120-ne256-warehouse-landing/warehouse-route.gd"

var _retry_reentry := false
var _incoming: Array[Dictionary] = []


func _ready() -> void:
	if "--syntax-only" in OS.get_cmdline_user_args():
		get_tree().quit()
		return
	super._ready()


func _run() -> void:
	if "--cold-proof" not in OS.get_cmdline_user_args():
		await super._run()
		return
	seed(223256)
	var store := RunSaveStore.new(_save_dir.path_join("slot.json"))
	var initial := RunSaveCodec.decode(FileAccess.get_file_as_string(store.path)).get("data", {}) as Dictionary
	var expected: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(_out.path_join("before-death.json")))
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_main.set("_run_store",store)
	add_child(_main)
	for tick in 700:
		var menu := _main.get("_screen") as MainMenu
		if is_instance_valid(menu) and not _main.call("_route_pending") and is_instance_valid(menu._continue_button) \
				and menu._continue_button.has_focus():
			break
		await _frames(1)
	var launch := _main.get("_screen") as MainMenu
	if _assert_route(is_instance_valid(launch) and initial.get("runtime",{}).get("dead") == true,
			"genuine pending death is available through the actual Continue menu"):
		launch._continue_button.pressed.emit()
		for tick in 700:
			if is_instance_valid(_level()) and _level().is_initialized() and is_instance_valid(_player()):
				break
			await _frames(1)
		if _assert_route(is_instance_valid(_level()) and is_instance_valid(_player()) and _player().is_dead()
				and GameState.deaths == 1 and _level().data.id == &"ch1_warehouse",
				"cold Continue resumes death in the original warehouse without increasing the count"):
			var preserved := int(initial["state"]["area_states"]["ch1_warehouse"]["damage"][expected["key"]])
			await _shot("watchdog-cold-death")
			await _return_from_death(_level(), preserved, int(expected["health"]), str(expected["key"]),
					int(expected["credits"]), true)
	_main.call("_quit",int(_failures > 0))


func _watchdog_live(dog: PatternBoss) -> void:
	if _retry_reentry:
		await _shot("watchdog-restored-fight")
		await super._watchdog_live(dog)
		return
	var original := _player()
	var warehouse := _level()
	var deaths_before := GameState.deaths
	var store := _main.get("_run_store") as RunSaveStore
	var starting_credits := Progression.credits
	var durability := dog.health.max_health
	var damage_needed := 12
	var key := ""
	for name: String in warehouse._tracked:
		if warehouse._tracked[name] == dog:
			key = name
			break
	if not _assert_route(not key.is_empty() and GameState.difficulty.id == &"standard" and starting_credits >= 0,
			"uses the registered Watchdog in the actual standard warehouse"):
		return
	var script := load("C:/Users/stanl/Github/Nest-Egg/work/ne97-campaign-route-20261119/watchdog-driver.gd") as Script
	var driver: Node = script.new()
	add_child(driver)
	driver.use_current_fight(warehouse, dog)
	original.health.damaged.connect(_remember_damage)
	dog.health.damaged.connect(func(info: DamageInfo) -> void:
		print("WATCHDOG_RETRY_BOSS_DAMAGE ",JSON.stringify({"amount":info.amount,"source":String(info.source_id),
			"weak":info.weak_hit,"lost":dog.lost_health()})))
	for tick in 3600:
		if not is_instance_valid(original) or original.is_dead() or not is_instance_valid(dog) or dog.lost_health() >= damage_needed:
			break
		if original.loadout.is_dry() and not original.loadout.is_reloading() and tick % 20 == 0:
			_send_action(&"reload")
		driver.drive_frame()
		await _frames(1)
	driver.release_driver()
	driver.queue_free()
	if not _assert_route(is_instance_valid(original) and not original.is_dead() and is_instance_valid(dog)
			and dog.lost_health() >= damage_needed and not dog.is_dying(), "ordinary combat first takes actual Watchdog health"):
		return
	var lost := dog.lost_health()
	var fee := Progression.credits
	var expected_lost := roundi(float(lost) * (1.0 - warehouse.data.death_boss_recovery))
	var before := JSON.stringify({"health":durability,"lost":lost,"expected_lost":expected_lost,"credits":fee,"key":key})
	print("WATCHDOG_RETRY_START ", before)
	FileAccess.open(_out.path_join("before-death.json"), FileAccess.WRITE).store_string(before)
	_main.call("_save_run")
	FileAccess.open(_out.path_join("before-death-primary.json"), FileAccess.WRITE).store_buffer(FileAccess.get_file_as_bytes(store.path))
	await _shot("watchdog-before-loss")
	for tick in 3600:
		if not is_instance_valid(original) or original.is_dead() or _level() != warehouse:
			break
		if not GameplayLock.is_locked() and is_instance_valid(dog):
			var offset := dog.global_position.x - original.global_position.x
			_aim(Vector2(signf(offset),0))
			if absf(offset) > 44:
				Input.action_press(&"move_left" if offset < 0 else &"move_right")
		await _frames(1)
		Input.action_release(&"move_right")
		Input.action_release(&"move_left")
	if not _assert_route(GameState.deaths == deaths_before + 1 and is_instance_valid(original) and original.is_dead()
			and not _incoming.is_empty(), "real damage from the fight causes one ordinary player death"):
		return
	var lethal_source: String = _incoming.back()["source"]
	var latest_loss := dog.lost_health() if is_instance_valid(dog) else lost
	expected_lost = roundi(float(latest_loss) * (1.0 - warehouse.data.death_boss_recovery))
	_assert_route(lethal_source.begins_with("watchdog"), "recorded lethal damage source is the actual Watchdog attack")
	_assert_route(not GameState.has_flag(&"watchdog_defeated") and Progression.credits == fee,
			"first clinic death neither opens the gate nor charges a restoration fee")
	var primary_bytes := FileAccess.get_file_as_bytes(store.path)
	var accepted := RunSaveCodec.decode(primary_bytes.get_string_from_utf8()).get("data", {}) as Dictionary
	var lost_saved: int = accepted.get("state", {}).get("area_states", {}).get("ch1_warehouse", {}).get("damage", {}).get(key,-1)
	if not _assert_route(accepted.get("runtime", {}).get("dead") == true and lost_saved == expected_lost,
			"actual primary keeps the configured partial boss recovery and the genuine pending death"):
		return
	FileAccess.open(_out.path_join("death-primary.json"), FileAccess.WRITE).store_buffer(primary_bytes)
	FileAccess.open(_out.path_join("damage.json"), FileAccess.WRITE).store_string(JSON.stringify(_incoming,"\t"))
	await _shot("watchdog-lethal")
	if "--death-primary-only" in OS.get_cmdline_user_args():
		return
	await _return_from_death(warehouse, expected_lost, durability, key, fee, false)


func _return_from_death(previous: Level, saved_lost: int, durability: int, boss_key: String, credits: int, cold: bool) -> void:
	for tick in 2200:
		if _level() != null and _level() != previous and _player() != null and not _player().is_dead():
			break
		if Story.is_cinematic_active() and tick % 18 == 0:
			_send_action(&"ui_accept")
		await _frames(1)
	if not _assert_route(_level() != null and _level() != previous and _player() != null and not _player().is_dead()
			and GameState.deaths == 1 and GameState.has_flag(&"ch1_first_death_done"), "original clinic settles once and returns to the live checkpoint"):
		return
	_assert_route(_level().data.id == &"ch1_booth_alley" and Progression.credits == credits,
			"revival reaches the earlier booth and exact wallet")
	await _shot("watchdog-back-at-booth")
	_accept_radio = true
	if not await _route_portal(&"booth_street"):
		return
	await _chapter_one_street()
	if not _assert_route(_level().data.id == &"ch1_street" and not _player().is_dead(), "return crosses the actual street terraces"):
		return
	await _chapter_one_blockade()
	if not _assert_route(_level().data.id == &"ch1_warehouse" and not _player().is_dead(), "return enters the actual warehouse portal"):
		return
	var dog := _level()._tracked.get(boss_key) as PatternBoss
	if not _assert_route(is_instance_valid(dog) and dog.lost_health() == saved_lost
			and dog.health.max_health == durability and not GameState.has_flag(&"watchdog_defeated"),
			"ordinary travel reaches the original watchdog with its partially restored health"):
		return
	await _shot("watchdog-return")
	var store := _main.get("_run_store") as RunSaveStore
	_main.call("_save_run")
	FileAccess.open(_out.path_join("reentered-primary.json"),FileAccess.WRITE).store_buffer(FileAccess.get_file_as_bytes(store.path))
	var report := {"cold":cold,"health":dog.health.current,"lost":dog.lost_health(),"credits":Progression.credits,
		"deaths":GameState.deaths,"max":durability,"failures":_failures,"area":String(_level().data.id)}
	FileAccess.open(_out.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	_retry_reentry = true
	await _chapter_one_warehouse()


func _remember_damage(info: DamageInfo) -> void:
	_incoming.append({"source":String(info.source_id),"amount":info.amount,
		"remaining":_player().health.current if _player() != null else -1})