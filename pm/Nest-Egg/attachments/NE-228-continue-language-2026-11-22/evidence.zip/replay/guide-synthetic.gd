extends Node

var out := ""
var checks := 0
var failures := 0
var rows: Array[Dictionary] = []

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	_run.call_deferred()

func _run() -> void:
	var panel := DialogueLayer.new()
	add_child(panel)
	for language: String in ["zh", "ja", "en"]:
		Story.set_language(language)
		var verb: String = {"zh":"繼續", "ja":"続ける", "en":"Continue"}[language]
		var dialogue := Story.resolved_lines(&"ch1_p05_service_fall")
		var radio := Story.resolved_lines(&"ch1_p04_dash")
		if dialogue.is_empty() or radio.is_empty():
			push_error("Expected original localized sources")
			get_tree().quit(2)
			return
		await _send_device(false)
		panel.start_cinematic(&"p05_probe",dialogue)
		panel.advance()
		await _row(panel._continue, language, "dialogue", "key", verb)
		await _send_device(true)
		await _row(panel._continue, language, "dialogue", "pad", verb)
		panel.cancel_cinematic()

		await _send_device(false)
		panel.enqueue_radio(&"counter_radio_probe",radio,true)
		panel._radio_text.visible_ratio = 1.0
		await _row(panel._radio_continue, language, "frozen_radio", "key", verb)
		await _send_device(true)
		await _row(panel._radio_continue, language, "frozen_radio", "pad", verb)
		panel.cancel_radio()

		panel.enqueue_radio(&"counter_radio_probe",radio,false,true)
		await _row(panel._radio_continue, language, "skippable_radio", "pad", UiKit.cinematic_skip_hint(language,&"pause"), true)
		await _send_device(false)
		await _row(panel._radio_continue, language, "skippable_radio", "key", UiKit.cinematic_skip_hint(language,&"pause"), true)
		panel.cancel_radio()
	await _send_device(false)
	panel.queue_free()
	for tick in 6:
		await get_tree().process_frame
	var summary := {"checks":checks,"failures":failures,"rows":rows,"rendering":RenderingServer.get_current_rendering_method(),
		"adapter":RenderingServer.get_video_adapter_name(),"font_scale":Settings.get_ui_text_scale()}
	FileAccess.open(out.path_join("summary.json"),FileAccess.WRITE).store_string(JSON.stringify(summary,"  "))
	print("CONTINUE_LABELS ",checks," FAILURES ",failures)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures==0 else 1)

func _row(label: Label, language: String, presentation: String, device: String, verb: String, exact := false) -> void:
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var expected := verb if exact else InputBindings.primary_label(&"ui_accept")+" "+verb
	var captured := {"language":language,"type":presentation,"device":device,
		"text":label.text,"expected":expected,"visible":label.is_visible_in_tree(),
		"width":label.size.x,"min_width":label.get_minimum_size().x}
	rows.append(captured)
	_check(InputBindings.using_gamepad == (device == "pad"), "the synthetic device event was observed", captured)
	_check(label.is_visible_in_tree(), "the real prompt is visible", captured)
	_check(label.get_minimum_size().x<=label.size.x and label.get_line_count()==1, "the text fits at 120 percent", captured)
	_check(label.text == expected, "the action label uses the active locale and input", captured)
	if presentation!="skippable_radio":
		var file := "%s-%s-%s.png" % [language,presentation,device]
		preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(out.path_join(file))

func _check(ok: bool, note: String, details: Dictionary) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("FAIL ",note," ",JSON.stringify(details))


func _send_device(pad: bool) -> void:
	if pad:
		var motion := InputEventJoypadMotion.new()
		motion.device = 999
		motion.axis = JOY_AXIS_RIGHT_X
		motion.axis_value = 0.0
		Input.parse_input_event(motion)
		var move := motion.duplicate() as InputEventJoypadMotion
		move.axis_value = 0.9
		Input.parse_input_event(move)
	else:
		var key := InputEventKey.new()
		key.keycode = KEY_K
		key.physical_keycode = KEY_K
		key.pressed = true
		Input.parse_input_event(key)
		var release := key.duplicate() as InputEventKey
		release.pressed = false
		Input.parse_input_event(release)
	Input.flush_buffered_events()
	await get_tree().process_frame
