extends "res://tests/probes/prologue_completion.gd"

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	super._ready()

func _drive_dialogue() -> void:
	var host := Story._layer
	var lines := Story.resolved_lines(target)
	var want := 4 if phase == "call" else 5
	_check(lines.size() == want, "the real counter source has the expected authored line count")
	var seen := 0
	var content := []
	for tick in 1200:
		if not Story.is_cinematic_active() or _prompt() != null:
			break
		if host.is_cinematic_active() and host._text.visible_ratio >= 1.0:
			await RenderingServer.frame_post_draw
			var item := host._text
			_check(seen < lines.size() and item.text == lines[seen]["text"],
				"the rendered localized line matches the active counter source")
			_check(item.get_visible_line_count() == item.get_line_count() and item.get_line_count() >= 1,
				"the full localized dialogue fits at 120 percent text scale")
			var rect := item.get_global_rect()
			var panel := host._dialogue_panel.get_global_rect()
			_check(panel.grow(1.0).encloses(rect), "the full text rect stays inside the counter dialogue panel")
			_check(host._continue.visible and host._continue.text == InputBindings.format("{ui_accept} " + ({"ja":"続ける","en":"Continue"}[Story.language] as String)),
				"the live counter prompt is fully localized")
			await _capture("line-%d" % seen)
			content.append({"text":item.text,"visual_lines":item.get_line_count(),"panel":str(panel),"rect":str(rect)})
			seen += 1
			host.advance()
		await _frames(1)
	_check(seen == want and not Story.is_cinematic_active(), "the authored marks complete only after every localized line")
	FileAccess.open(out.path_join("text.json"),FileAccess.WRITE).store_string(JSON.stringify(
		{"language":Story.language,"target":String(target),"lines":content}, "  "))
