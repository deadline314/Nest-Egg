extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const PAD := 420
const LANGUAGES := ["zh", "ja", "en"]
var _out := ""
var _checks := 0
var _failures := 0


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://controller-fallback-layout.cfg")
	Settings.set_reduce_ui_motion(false)
	Settings.set_ui_text_scale(1.2)
	Story.set_language("en")
	Story.auto_skip = true
	var main: Node = load("res://game/main.gd").new()
	main.set("_run_store", RunSaveStore.new("user://fallback-layout/slot.json"))
	add_child(main)
	for frame in 160:
		if main.get("_screen") is MainMenu and not GameplayLock.is_locked():
			break
		await get_tree().process_frame
	main.call("_on_start_requested", GameState.difficulties[1])
	var level: Level
	for frame in 360:
		var current := main.get("_screen") as Level
		if current != null and current.is_initialized() and not GameplayLock.is_locked() and not Story.is_cinematic_active():
			level = current
			break
		await get_tree().process_frame
	_check(level != null, "the original prologue starts")
	if level != null:
		var pause := level._pause_menu
		pause.open()
		await _frames(16)
		for locale: String in LANGUAGES:
			Story.set_language(locale)
			for action: String in pause._actions:
				var button: Button = pause._actions[action]
				button.grab_focus()
				await _frames(4)
				Input.joy_connection_changed.emit(PAD, true)
				InputBindings._set_device(true, PAD)
				await _frames(4)
				Input.joy_connection_changed.emit(PAD, false)
				await _frames(18)
				var notice := InputBindings.get("_disconnect_notice") as UiBanner
				_check(notice != null and notice.is_showing() and pause._menu_hints.is_visible_in_tree()
						and get_viewport().gui_get_focus_owner() == button, locale + " " + action + " notice and focus")
				if notice == null:
					continue
				var hint_rect: Rect2 = pause._menu_hints.get_global_rect()
				var notice_rect := notice.get_global_rect()
				print(locale, "/", action, " hint=", hint_rect, " notice=", notice_rect)
				_check(not notice_rect.intersects(hint_rect)
						and get_viewport().get_visible_rect().encloses(notice_rect),
						locale + " " + action + " focus help and notice both fit")
				if action == "menu":
					await RenderingServer.frame_post_draw
					_check(Capture.image(get_viewport()).save_png(_out.path_join(locale + ".png")) == OK, locale + " snapshot")
		pause.close()
		await _frames(180)
	main.queue_free()
	await _frames(8)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _failures])
	get_tree().quit(1 if _failures else 0)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(passed: bool, note: String) -> void:
	_checks += 1
	_failures += int(not passed)
	if not passed:
		printerr("FAIL: ", note)
