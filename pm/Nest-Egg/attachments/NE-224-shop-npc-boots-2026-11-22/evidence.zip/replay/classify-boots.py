from collections import Counter
from functools import lru_cache
from pathlib import Path
from PIL import Image,ImageDraw
from scipy import ndimage
import json,numpy as np

base=Path(__file__).resolve().parent
stock=base/"whole"
read=lambda p:json.loads(p.read_bytes())
cases=[r for r in read(stock/"report.json")["failures"] if r["joint"].startswith("ankle_")
       and r["pose"] in {"stand","wave"} and (r["enclosed_pixels"] or r["loose_pieces"] or r["center_alpha"]<128)]
def key(row):
    return row["char"],row["pose"],row["joint"],row["zoom"],row["facing"],row["frame"]

@lru_cache(maxsize=6)
def pixels(folder,filename):
    return np.asarray(Image.open(folder/filename).convert("RGBA"))

def crop(row,data):
    x,y,w,h=row["rect"]
    r=row["radius"]
    return data[y+h//2-r:y+h//2+r,x+w//2-r:x+w//2+r]

def holes(opaque):
    return ndimage.binary_fill_holes(opaque,structure=np.ones((3,3),bool))&~opaque

legs={}
for pose in ("stand","wave"):
    directory=base/f"boots-{pose}"
    raw=(directory/"raw.log").read_text(encoding="utf-8-sig")
    assert "RX 9070 XT" in raw and "Forward+" in raw and "ERROR:" not in raw
    legs.update({key(r):r for r in read(directory/"report.json")["failures"] if r["joint"].startswith("ankle_")})
confirmations=[]
for row in sorted(cases,key=lambda r:r["file"]):
    name=key(row)
    both=legs.get(name)
    assert both is not None and row["rect"]==both["rect"] and row["radius"]==both["radius"]
    left=crop(row,pixels(stock,row["file"]))[:,:,3]
    right=crop(both,pixels(base/f"boots-{row['pose']}",both["file"]))[:,:,3]
    exact=bool(np.array_equal(holes(left>=128),holes(right>=128)))
    assert int(holes(left>=128).sum())==row["enclosed_pixels"]
    confirmations.append({"case":name,"enclosed":row["enclosed_pixels"],"exact":exact,"file":row["file"]})
different=[r for r in confirmations if not r["exact"]]
full={key(r) for r in cases}
uncovered={key(r) for r in legs.values() if r["enclosed_pixels"] and key(r) not in full}
stat={"whole":len(cases),"pixel_exact":len(cases)-len(different),"crossing_pixels":sum(r["enclosed"] for r in confirmations),
      "groups":dict(Counter(r["case"][0]+"/"+r["case"][1]+"/"+r["case"][2] for r in confirmations)),
      "stand_or_wave_legs_only":len(uncovered),"unmatched":different,"cases":confirmations}
(base/"boot-continuity.json").write_text(json.dumps(stat,indent=2)+"\n",encoding="utf-8")
print("BOOTS",stat["whole"],stat["pixel_exact"],stat["crossing_pixels"],stat["groups"],stat["stand_or_wave_legs_only"])
assert not different
for mode in ("dressed","isolated"):
    warnings={key(r) for r in read(base/mode/"report.json")["failures"] if
        r["enclosed_pixels"] or r["loose_pieces"] or r["center_alpha"]<128}
    assert not warnings&full

out=Image.new("RGB",(560,610),"#18253b")
draw=ImageDraw.Draw(out)
for y,actor in enumerate(("old_k","ah_po")):
    row=max((r for r in cases if r["char"]==actor),key=lambda r:r["enclosed_pixels"])
    for x,(directory,data,label) in enumerate(((stock,row,"FULL ACTOR"),
          (base/f"boots-{row['pose']}",legs[key(row)],"BOTH LEGS"))):
        rgba=crop(data,pixels(directory,data["file"]))
        matte=Image.new("RGBA",(rgba.shape[1],rgba.shape[0]),"#54546c")
        matte.alpha_composite(Image.fromarray(rgba))
        colored=np.array(matte)
        colored[holes(rgba[:,:,3]>=128)]=[226,112,154,255]
        out.paste(Image.fromarray(colored).convert("RGB").resize((280,280),Image.Resampling.NEAREST),(x*280,y*305+25))
        draw.text((x*280+8,y*305+7),f"{actor.upper()} | {label}",fill="#dce5ef")
out.save(base/"boot-continuity.png")
