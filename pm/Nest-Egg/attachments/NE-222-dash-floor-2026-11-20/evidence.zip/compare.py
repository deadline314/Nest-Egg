from pathlib import Path
import json
import math
import re
import sys

base=Path(__file__).resolve().parent
old=base/"stock"
new=base/sys.argv[1]
names=sorted(path.name for path in old.iterdir())
assert len(names)==8
def read(path):return json.loads(path.read_bytes())
def equal(a,b,eps=.00002):
    if isinstance(a,list):return len(a)==len(b) and all(equal(x,y,eps) for x,y in zip(a,b))
    if isinstance(a,dict):return a.keys()==b.keys() and all(equal(a[k],b[k],eps) for k in a)
    if isinstance(a,float):return math.isclose(a,b,abs_tol=eps,rel_tol=0)
    return a==b
protected=("root","velocity","facing","state","ground","dash_time","chest","hip","head","chest_rotation","hip_rotation",
           "muzzle","aim","rounds","weapon","zoom","camera_center","head_screen")
paired=0
results={}
for name in names:
    comparisons=[old/name,new/name]
    before,after=[read(x/"motion.json") for x in comparisons]
    assert before["checks_failed"]==after["checks_failed"]==0
    mode=before["mode"]
    assert mode==after["mode"] and before["side"]==after["side"]
    for folder in comparisons:
        log=(folder/"engine.log").read_text(encoding="utf-8")
        assert "Forward+ - Using Device #0: AMD - AMD Radeon RX 9070 XT" in log
        assert not re.search(r"^(?:SCRIPT )?ERROR:|^FAIL|Parse Error|leaked at exit",log,re.M)
    max_muzzle_change=0.0
    for a,b in zip(before["rows"],after["rows"],strict=True):
        paired+=1
        assert (a["action"],a["frame"])==(b["action"],b["frame"])
        for key in protected:
            assert equal(a[key],b[key]), (name,a["frame"],key,a[key],b[key])
        max_muzzle_change=max(max_muzzle_change,math.dist(a["muzzle"],b["muzzle"]))
        if mode!="dash":
            for key in ("foot","sole","foot_angles","knees"):
                assert equal(a[key],b[key]),(name,a["frame"],key,a[key],b[key])
    one={"samples":len(before["rows"]),"max_muzzle_change_world":max_muzzle_change}
    if mode=="dash":
        one["ground"]={}
        for label in ("forward","back"):
            old_rows,new_rows=[[x for x in v["rows"] if x["action"]==label] for v in (before,after)]
            assert len(old_rows)==len(new_rows)==36
            old_peak,new_peak=[max(max(r["sole"]) for r in q if r["state"]==1) for q in (old_rows,new_rows)]
            old_recovery,new_recovery=[max(max(r["sole"]) for r in q if 13<=r["frame"]<=26) for q in (old_rows,new_rows)]
            knee_change=max(abs(math.remainder(b-a,math.tau))
                 for a_values,b_values in zip(new_rows,new_rows[1:]) for a,b in zip(a_values["knees"],b_values["knees"]))
            one["ground"][label]={"lower_visible_sole_peak_world":[old_peak,new_peak],
                 "lower_visible_sole_recovery_world":[old_recovery,new_recovery],
                 "max_knee_radian_step":knee_change}
    results[name]=one
out={"samples":paired,"modes":results,"render":"RX 9070 XT Forward+ Vulkan 1280×720 fixed60",
     "visual_coordinates":"opaque boot alpha ≥0.5 transformed from current imported sprites into world positions relative to floor anchor",
     "controls":"actual Main Continue slot with seed and start fixed in authored Ch1 street. Horizontal aim arranged, jump and dash input simulated.",
     "lens":"default gameplay camera and diagnostic 3.4× tracking camera in current level"}
(base/"sole-evidence.json").write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
for name, case in results.items():
    print(name,case)
for mode in results.values():
    for direction in mode.get("ground",{}).values():
        assert direction["lower_visible_sole_peak_world"][1] < 0.65, direction
        assert direction["lower_visible_sole_recovery_world"][1] < 0.65, direction
        assert direction["max_knee_radian_step"] < 0.75, direction
