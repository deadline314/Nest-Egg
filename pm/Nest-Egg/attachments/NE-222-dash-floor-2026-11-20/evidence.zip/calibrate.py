from pathlib import Path
import json
import numpy as np

base=Path(__file__).resolve().parent
d=json.loads((base/"support-calibration/dash--1-0.0/motion.json").read_bytes())
points=np.unique(np.round(np.array(d["sole_local"]["foot_front"]),3),axis=0)
other=np.array(d["sole_local"]["foot_back"])
assert np.max(np.abs(other-np.array(d["sole_local"]["foot_front"]))) < .001
angles=np.linspace(-np.pi,np.pi,7201)
projections=points @ np.stack([np.sin(angles),np.cos(angles)],axis=0)
target=projections.max(axis=0)
chosen=[int(np.argmax(points[:,1]))]
while np.max(target-projections[chosen].max(axis=0))>.07:
    angle=int(np.argmax(target-projections[chosen].max(axis=0)))
    chosen.append(int(np.argmax(projections[:,angle])))
error=np.max(target-projections[chosen].max(axis=0))
selected=points[sorted(chosen)].tolist()
measure={"local_points":selected,"max_error_rig_units":float(error),"old_source_points":len(d["sole_local"]["foot_front"])-1,
         "angle_samples":len(angles),"standing_plane_offset":max(point[1] for point in selected)}
assert measure==json.loads((base/"sole-calibration.json").read_bytes())
print(json.dumps(measure))
