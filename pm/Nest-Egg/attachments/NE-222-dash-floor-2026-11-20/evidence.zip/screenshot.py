from pathlib import Path
from PIL import Image

base=Path(__file__).resolve().parent
crops={-1:(495,235,850,643),1:(424,235,779,643)}
width,height=355,408
sheet=Image.new("RGB",(2*width+4,2*height+4),"#222733")
for row,side in enumerate((-1,1)):
    for column,version in enumerate(("stock","candidate")):
        path=base/version/f"dash-{side}-3.4"/"back-012.png"
        with Image.open(path) as native:
            assert native.size==(1280,720)
            sheet.paste(native.crop(crops[side]),(column*(width+4),row*(height+4)))
sheet.save(base/"dash-floor-comparison.png")
