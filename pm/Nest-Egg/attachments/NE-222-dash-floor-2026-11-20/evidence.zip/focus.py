from pathlib import Path
import os
import re
import subprocess
import sys

base=Path(__file__).resolve().parent
root=Path.cwd()
mode=sys.argv[1]
project = root if mode.startswith("pilot") else Path("D:/NestEggVerification/ne218-baseline-20261117")
path=Path("tests/suite/test_protagonist_motion.gd")
actual=(project/path).read_bytes()
changed=(root/path).read_bytes()
if mode=="stock":
    assert actual==subprocess.check_output(["git","show",f"HEAD:{path.as_posix()}"],cwd=project)
    assert actual!=changed
else:
    assert actual==changed
folder=base/(mode+"-focus")
folder.mkdir()
env=os.environ.copy()
for key in ("APPDATA","LOCALAPPDATA","TEMP","TMP","TMPDIR","XDG_CONFIG_HOME","XDG_DATA_HOME"):
    place=folder/key
    place.mkdir()
    env[key]=str(place)
try:
    if mode=="stock":
        (project/path).write_bytes(changed)
    with (folder/"raw.log").open("wb") as log:
        result=subprocess.run(["C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(project),
              "--headless","res://tests/smoke_test.tscn","--","--only=ProtagonistMotionSuite"],cwd=project,
              env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
finally:
    if mode=="stock":
        (project/path).write_bytes(actual)
raw=(folder/"raw.log").read_text(encoding="utf-8")
print("\n".join(s for s in raw.splitlines() if re.search(r"^(?:SCRIPT )?ERROR:|^FAIL|checks:",s)))
assert result.returncode==int(mode=="stock") and not re.search(r"^(?:SCRIPT )?ERROR:",raw,re.M)

