extends "res://tests/smoke_test.gd"


func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = false
	var suite := Chapter1MapSuite.new(self)
	await preload("res://tests/helpers/ch1_world_maintenance_checks.gd")._switch_and_pump_select_one_target(suite)
	await _finish()
