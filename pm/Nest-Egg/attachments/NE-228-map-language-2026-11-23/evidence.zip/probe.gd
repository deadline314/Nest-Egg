extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const PAWN := "res://data/levels/ch1_pawnshop.tres"
const ROOF := "res://data/levels/ch1_rooftop.tres"

var _failed := 0
var _checks := 0
var _output := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_output = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://map-language-probe.cfg")
	Settings.set_ui_text_scale(1.2)
	Story.set_language("zh")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_prologue_exit", true, false)
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(load(PAWN) as LevelData)
	add_child(level)
	await _frames(25)
	var pause := level._pause_menu
	await _press(KEY_M)
	var screen: QuestMapScreen = pause._navigation
	_check(is_instance_valid(screen) and screen._page == "region", "actual map shortcut opens the Pawnshop map")
	if not is_instance_valid(screen):
		_finish()
		return
	var map_path := screen._map_path
	var zoom := screen._buttons[0]
	zoom.grab_focus()
	await _press(KEY_ENTER)
	_check(screen._canvas.zoom == 2.0, "the actual zoom control enlarges the view")
	screen._buttons[2].grab_focus()
	for locale: String in ["en", "ja", "zh"]:
		Story.set_language(locale)
		await _frames(7)
		var center := screen._buttons[2]
		var center_labels := {"zh": "回到所在區域", "ja": "現在地に戻る", "en": "Center on player"}
		var location_tips := {"zh": "主角目前在這裡。", "ja": "ここが現在地です。", "en": "Your current position."}
		_check(center.text == center_labels[locale], locale + " area map translates the recenter label")
		_check(center.has_focus() and screen._status.text == center.tooltip_text, locale + " restores the focus and matching tooltip without mouse")
		_check(screen._canvas.zoom == 2.0 and screen._map_path == map_path, locale + " retains area and zoom")
		var location := _marker(screen, "▲")
		_check(location != null and location.tooltip_text == location_tips[locale], locale + " localizes the current position tooltip")
		_check(screen._body.get_global_rect().end.y <= screen.size.y, locale + " area map fits the visible design viewport")
		if locale == "en":
			await _capture("area-en.png")
	Story.set_language("en")
	await _frames(6)
	await _press(KEY_E)
	_check(screen._page == "world", "the normal keyboard tab shortcut switches to the world map")
	var roof_name := (screen.maps.areas[ROOF]["data"] as LevelData).display_name
	var roof := _marker(screen, roof_name)
	_check(roof != null, "the world map keeps the authored rooftop name")
	if roof != null:
		roof.grab_focus()
		for locale: String in ["ja", "zh", "en"]:
			Story.set_language(locale)
			await _frames(7)
			roof = _marker(screen, roof_name)
			var openers := {"zh": "開啟", "ja": roof_name, "en": "Open the map for"}
			_check(roof != null and roof.tooltip_text.begins_with(openers[locale]), locale + " world marker explains its assigned area")
			_check(roof != null and roof.has_focus() and screen._status.text == roof.tooltip_text, locale + " focuses the same authored world marker")
			if locale == "ja":
				await _capture("world-ja.png")
		await _joy(JOY_BUTTON_A)
		_check(screen._page == "region" and screen._map_path == ROOF, "controller confirms the focused rooftop node")
		await _joy(JOY_BUTTON_B)
		roof = _marker(screen, roof_name)
		_check(screen._page == "world" and roof != null and roof.has_focus(), "controller return restores rooftop focus")
	_finish()


func _marker(screen: QuestMapScreen, label: String) -> Button:
	if is_instance_valid(screen._canvas):
		for marker in screen._canvas._markers:
			if marker.text.contains(label):
				return marker
	return null


func _press(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(2)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(6)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(2)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(6)


func _capture(filename: String) -> void:
	if DisplayServer.get_name() != "headless":
		_check(Capture.image(get_viewport()).save_png(_output.path_join(filename)) == OK, "captures " + filename)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(condition: bool, message: String) -> void:
	_checks += 1
	if not condition:
		_failed += 1
	print(("%s " % ("PASS" if condition else "FAIL")) + message)


func _finish() -> void:
	print("checks: %d, failures: %d" % [_checks, _failed])
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if _failed else 0)

