from pathlib import Path
import json, math
from PIL import Image

p=Path(__file__).resolve().parent
receipt={}
for facing in ('right','left'):
    paired=[]
    for tag in (facing,'candidate-'+facing):
        run=json.loads((p/tag/'run.json').read_bytes())
        assert run['exit']==0 and not run['errors'] and run['reload']['failures']==0
        paired.append(run['reload']['samples'])
    before,after=paired
    invariant=('label','reload','progress','direction','visible','weapon','mag','anchor')
    assert len(before)==len(after)==193 and all(all(a[k]==b[k] for k in invariant) for a,b in zip(before,after))
    def angle_diff(a,b):
        return math.degrees(abs(math.remainder(a-b, math.tau)))
    def metrics(rows,label):
        subset=[row for row in rows if row['label'].startswith(label+'-') and not row['label'].startswith(label+'-switch-')]
        assert subset[0]['label']==label+'-ready' and subset[-1]['label']==label+'-completed'
        peak=max(angle_diff(a['weapon_angle'],b['weapon_angle']) for a,b in zip(subset,subset[1:]))
        maximal=max(angle_diff(subset[0]['weapon_angle'],row['weapon_angle']) for row in subset)
        return {'rows':len(subset),'max_sampled_delta_degrees':peak,'max_lowering_degrees':maximal,
                'max_front_grip_gap':max(row['front_gap'] for row in subset),'max_back_grip_gap':max(row['back_gap'] for row in subset)}
    data={}
    for weapon in ('pistol','rifle'):
        first,last=[metrics(row,weapon) for row in paired]
        assert first['max_sampled_delta_degrees']>50 and last['max_sampled_delta_degrees']<13
        assert abs(first['max_lowering_degrees']-last['max_lowering_degrees'])<.01
        assert max(last['max_front_grip_gap'],last['max_back_grip_gap'])<.001
        data[weapon]={'before':first,'after':last}
    switch_label='rifle-switch-after-swap'
    switch_before,switch_after=(next(row for row in rows if row['label']==switch_label) for rows in paired)
    assert angle_diff(switch_before['weapon_angle'],switch_after['weapon_angle'])<0.001
    swap_peak=max(math.dist(switch_before[field],switch_after[field]) for field in ('front_world','back_world','grip','head'))
    assert swap_peak<.002
    data['swap_resume']={'observed':switch_after,'max_coordinate_delta':swap_peak}
    receipt[facing]=data
(p/'pose-comparison.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
for facing,measurements in receipt.items():
    for weapon in ('pistol','rifle'):
        print(facing,weapon,measurements[weapon])

# A 1:1 crop of the same native rifle pose at the first and last sampled phases.
box=(55,283,250,540)
canvas=Image.new('RGB',(390,514))
for row,file in enumerate(('rifle-phase0.png','rifle-phase2.png')):
    for col,directory in enumerate(('right','candidate-right')):
        img=Image.open(p/directory/file)
        assert img.size==(1280,720)
        canvas.paste(img.crop(box),(col*195,row*257))
canvas.save(p/'reload-comparison.png')
