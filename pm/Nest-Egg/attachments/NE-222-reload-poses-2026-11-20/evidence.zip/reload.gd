extends "res://tools/ch1_flow_probe.gd"

const CAPTURE := preload("res://tools/viewport_capture.gd")
var _store := ""
var _facing := 1
var _main: Node
var _player: Player
var _rig: CharacterRig
var _samples: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_store = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--facing="):
			_facing = int(arg.trim_prefix("--facing="))
	CampaignEdition.override_current(CampaignEdition.current().describe("demo-0.1"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_store.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.id == &"ch1_street", "the real street save continues into its original level")
	if _level == null or _level.player == null:
		_finish_reload()
		return
	_player = _level.player
	_rig = _player._visual.rig
	var original := _player.loadout.active_weapon()
	_check(original != null and original.has_magazine(), "the save's original magazine weapon is available")
	if original == null:
		_finish_reload()
		return
	var aim := &"aim_right" if _facing > 0 else &"aim_left"
	AimInput.set_virtual_gamepad(_player, true)
	Input.action_press(aim)
	await _settle(25)
	_check(_player.facing == _facing and _player.is_on_floor(), "normal aim takes the requested facing on the real floor")
	await _run_reload("pistol", false)
	var rifle := load("res://data/weapons/rifle.tres") as WeaponData
	var fixture_slot := _player.loadout.equip(rifle)
	_check(fixture_slot > 0, "fixture equips the released rifle in a secondary slot")
	await _settle(15)
	await _run_reload("rifle", false)
	await _run_reload("rifle-switch", true)
	Input.action_release(aim)
	AimInput.set_virtual_gamepad(_player, false)
	_finish_reload()


func _run_reload(label: String, interrupt: bool) -> void:
	var slot := _player.loadout.active_slot
	var weapon := _player.loadout.active_weapon()
	_check(weapon != null and weapon.id == (&"rifle" if label.begins_with("rifle") else &"pistol"), label + " records the intended real weapon")
	var before := _player.loadout.mag_in(slot)
	await _sample(label+"-ready", true)
	Input.action_press(&"shoot")
	for repeat in 15:
		await _settle(1)
		if _player.loadout.mag_in(slot) < before:
			break
	Input.action_release(&"shoot")
	var used := _player.loadout.mag_in(slot)
	_check(used < before and not _player.is_reloading(), label + " consumes a round through the normal fire input")
	await _settle(22)
	await _send(&"reload")
	_check(_player.is_reloading(), label + " the normal reload input starts loadout progress")
	var hits := 0
	var fractions := [0.12, 0.43, 0.78]
	for sample in 180:
		if not _player.is_reloading():
			break
		var progress := _player.loadout.reload_progress()
		var want_image: bool = hits < fractions.size() and progress >= float(fractions[hits])
		var segment := label + "-step%03d" % sample
		if want_image:
			segment = label + "-phase%d" % hits
		await _sample(segment, want_image)
		if want_image:
			hits += 1
		if interrupt and progress >= 0.48:
			await _send(&"weapon_next")
			break
	if interrupt:
		_check(not _player.is_reloading() and _player.loadout.active_slot != slot and _player.loadout.mag_in(slot) == used,
			"weapon switching cancels reload and leaves the previous magazine untouched")
		await _sample(label+"-after-swap", true)
	else:
		_check(not _player.is_reloading() and _player.loadout.mag_in(slot) > used and hits == 3, label + " records three phases and the original reload completion")
		await _sample(label+"-completed", true)
	await _settle(14)


func _send(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await _settle(1)
	var released := InputEventAction.new()
	released.action = action
	Input.parse_input_event(released)
	await _settle(1)


func _sample(label: String, shot: bool) -> void:
	await RenderingServer.frame_post_draw
	var weapon := _rig.weapon_def()
	var root := _rig.weapon_root()
	var grip := root.global_position
	var fore := (RigLibrary.vec2(weapon.get("foregrip")) - RigLibrary.vec2(weapon.get("grip"))) * _rig.weapon_scale()
	var muzzle := _rig.muzzle_global()
	var front := _rig.hand_contact_global(&"front")
	var back := _rig.hand_contact_global(&"back")
	var canvas := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	_samples.append({"label": label,"progress": _player.loadout.reload_progress(),"reload": _player.is_reloading(),
		"direction": _player.facing,"visible": root.is_visible_in_tree(),"weapon": String(_player.loadout.active_weapon().id),
		"weapon_angle": (muzzle - grip).angle(),"front_gap": front.distance_to(grip),
		"back_gap": back.distance_to(root.to_global(fore)),"front_world": _array(front),"back_world": _array(back),
		"grip": _array(canvas*grip),"head": _array(canvas*_rig.bone(&"head").global_position),
		"mag": _player.loadout.mag_in(_player.loadout.active_slot),"anchor": _array(_player.global_position)})
	if shot:
		_check(CAPTURE.image(get_viewport()).save_png(_out_dir.path_join(label+".png")) == OK, "save native "+label)


func _array(p: Vector2) -> Array:
	return [p.x,p.y]


func _finish_reload() -> void:
	var f := FileAccess.open(_out_dir.path_join("reload.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"failures":_failures,"samples":_samples},"  ")+"\n")
	f.close()
	_main.call("_quit",0 if _failures==0 else 1)
