extends Node

const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://key-binding-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.set_language("en")
	var menu := MainMenu.new()
	add_child(menu)
	await _frames(5)
	menu._open_settings()
	await _frames(6)
	var screen := menu._ui.get_child(menu._ui.get_child_count() - 1) as SettingsScreen
	_check(screen != null and screen._tabs.current_tab == 0, "the real title settings overlay opens")
	if screen == null:
		menu.queue_free()
		await _finish()
		return
	await _joy(JOY_BUTTON_RIGHT_SHOULDER)
	var page := screen._tabs.get_current_tab_control()
	_check(screen._tabs.current_tab == 1 and _has_text(page, "Key / Mouse 2")
			and _has_text(page, "Jump") and _has_text(page, "Crouch / Drop"), "settings grid uses English headings and actual action names")
	var map_secondary: Button = screen._binding_buttons["map:1"]
	map_secondary.grab_focus()
	await _frames(6)
	_check(map_secondary.tooltip_text.begins_with("Select and press a key")
			and screen._status.text == map_secondary.tooltip_text, "keyboard focus displays the same localized help as Hover")
	await _key(KEY_ENTER)
	await _key(KEY_R)
	var reload := InputEventKey.new()
	reload.physical_keycode = KEY_R
	_check(screen._capturing and map_secondary.has_focus() and screen._status.text.contains("Reload"),
			"conflict names the existing action, keeps focus and waits")
	_check(InputBindings.get_code(&"map", 1) == InputBindings.NONE and InputBindings.get_code(&"reload", 0) == KEY_R
			and InputMap.event_is_action(reload, &"reload") and not InputMap.event_is_action(reload, &"map"),
			"R still dispatches only Reload")
	await _picture("conflict-en.png")
	# Recover the stock state for the next independent operation.
	if screen._capturing:
		await _key(KEY_ESCAPE)
	InputBindings.reset_to_defaults()
	map_secondary.grab_focus()
	await _key(KEY_ENTER)
	await _key(KEY_M)
	_check(not screen._capturing and InputBindings.get_code(&"map", 0) == InputBindings.NONE
			and InputBindings.get_code(&"map", 1) == KEY_M
			and screen._status.text == "Map binding updated.", "moving the same key does not add a second mapping or claim a swap")
	InputBindings.reset_to_defaults()
	var jump: Button = screen._binding_buttons["jump:0"]
	jump.grab_focus()
	await _key(KEY_ENTER)
	await _key(KEY_2)
	_check(screen._capturing and screen._status.text.contains("reserved"), "reserved key explains why it is refused")
	await _key(KEY_J)
	_check(not screen._capturing and InputBindings.get_code(&"jump", 0) == KEY_J
			and InputBindings.get_code(&"shoot", 1) == KEY_SPACE
			and screen._status.text == "Jump binding updated. Swapped with Shoot.", "existing swaps still update both bindings and name the other action")
	await _key(KEY_ENTER)
	await _key(KEY_ESCAPE)
	_check(not screen._capturing and jump.has_focus() and screen._status.text == "Binding canceled.",
			"cancel keeps the focused key and shows a localized result")
	screen.close()
	InputBindings.reset_to_defaults()
	await _frames(8)
	Story.set_language("ja")
	menu._open_settings()
	await _frames(6)
	screen = menu._ui.get_child(menu._ui.get_child_count() - 1) as SettingsScreen
	await _joy(JOY_BUTTON_RIGHT_SHOULDER)
	page = screen._tabs.get_current_tab_control()
	_check(_has_text(page, "キー／マウス 2") and _has_text(page, "ジャンプ"), "Japanese grid uses Japanese headers and actions")
	var map_pad: Button = screen._binding_buttons["map:-1"]
	map_pad.grab_focus()
	await _joy(JOY_BUTTON_A)
	await _joy(JOY_BUTTON_A)
	_check(screen._capturing and map_pad.has_focus() and screen._status.text.contains("ジャンプ")
			and InputBindings.get_joy_button(&"map") == -1 and InputBindings.get_joy_button(&"jump") == JOY_BUTTON_A,
			"controller rejects taking Jump's only button and explains it in Japanese")
	await _picture("conflict-ja.png")
	screen.close()
	menu.queue_free()
	await _finish()



func _button(node: Node, caption: String) -> Button:
	for child in node.find_children("*", "Button", true, false):
		if (child as Button).text == caption:
			return child as Button
	return null


func _has_text(node: Node, caption: String) -> bool:
	if node is Label and (node as Label).text == caption:
		return true
	for child in node.get_children():
		if _has_text(child, caption):
			return true
	return false


func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _tap(event)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	await _tap(event)


func _tap(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish() -> void:
	await _frames(7)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))
