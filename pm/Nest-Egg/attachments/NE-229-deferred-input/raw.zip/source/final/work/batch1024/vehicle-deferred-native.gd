extends "res://work/batch1024/vehicle-deferred-native-base.gd"
var _output:=""
var _pending_photos:=0
func _run()->void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):_output=arg.trim_prefix("--out=")
	add_child(LightKit.create_environment())
	Enemy.activation_culling_enabled=false
	Story.auto_skip=true
	get_tree().physics_frame.connect(_note_physics)
	_round=0
	_injected=false
	await _test_gameplay()
	await _finish()
func _note_physics()->void:
	super._note_physics()
	if is_instance_valid(_observed) and is_instance_valid(_observed.player):
		for v in get_tree().get_nodes_in_group(&"vehicles"):
			if v.global_position.distance_to(_observed.player.global_position)<100.0:
				_observed.camera.snap_to_target()
func _check(condition:bool,message:String)->void:
	super._check(condition,message)
	if message in ["player mounts vehicle","player dismounts vehicle","pit damages and respawns"]:
		_pending_photos+=1
		_capture.call_deferred(message)
func _capture(label:String)->void:
	await RenderingServer.frame_post_draw
	print("CAPTURE_STATE ",JSON.stringify(_snapshot(label)))
	var path:=_output.path_join(label.replace(" ","-")+".png")
	_check(preload("res://work/batch1024/window_capture.gd").image(get_window()).save_png(path)==OK,"capture "+label)
	_pending_photos-=1
func _end_level(level:Level)->void:
	# All original gameplay checks already ran; hold their final state for readback.
	get_tree().paused=true
	for i in 8:
		if _pending_photos==0:break
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
	_check(_pending_photos==0,"all original gameplay states captured before teardown")
	await super._end_level(level)
	for i in 2:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
