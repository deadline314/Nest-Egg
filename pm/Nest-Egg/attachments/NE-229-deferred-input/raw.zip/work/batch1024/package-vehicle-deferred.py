from pathlib import Path
import hashlib,json,zipfile,subprocess,re,shutil
w=Path('work/batch1024');n=Path('work/batch1020b');out=Path('pm/Nest-Egg/attachments/NE-229-deferred-input');out.mkdir(exist_ok=True)
frozen=json.loads((w/'vehicle-deferred-final-source.json').read_text())
for p,h in frozen.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
s=Path('tests/suite/test_input_feel.gd').read_text().replace('\n\tawait preload("res://tests/helpers/vehicle_deferred_input_checks.gd").run(self)','')
assert s.encode()==subprocess.check_output(['git','show','f50882e9:tests/suite/test_input_feel.gd'])
for p in ['tests/smoke_test.gd','autoload/fx.gd','game/player/player.gd','game/vehicles/vehicle.gd','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']:
 assert Path(p).read_bytes()==subprocess.check_output(['git','show','f50882e9:'+p]),p
rows={}
for key,name in [('before','vehicle-deferred-before-v2-console.log'),('after','vehicle-deferred-after-final-console.log'),('original_main','vehicle-deferred-main-console.log')]:
 t=(w/name).read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',t);assert m,name
 rows[key]=dict(zip(['checks','new_failures','known_failures','seconds'],map(int,m.groups())))
assert rows['before']['checks']==rows['after']['checks']==130
assert rows['before']['new_failures']==2 and rows['after']['new_failures']==rows['original_main']['new_failures']==0
native={}
for phase in ['before','after']:
 name='ne229-1024-deferred-'+phase;t=(n/(name+'.log')).read_text();m=re.search(r'checks: (\d+), failures: (\d+)',t);assert m
 native[phase]={'checks':int(m[1]),'failures':int(m[2]),'exit':int((n/(name+'.exit')).read_text()),'engine_errors':t.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',t))}
 assert native[phase]['engine_errors']==native[phase]['leaks']==0
assert native['before']['failures']==1 and native['after']['failures']==0
ci=json.loads((w/'ci-f508-final.json').read_text());assert ci['conclusion']=='success'
receipt={'base':ci['head'],'prior_ci':ci,'headless':rows,'native':native,'frozen_sources':frozen,'original_tests_inputs_waits_reconstructed_identically':True,'limits':['Synchronous and deferred step stops are distinct controlled cases. The old CI frozen snapshot does not identify exact earlier callback ordering.','Pending input stays only within the original Godot input edge; original FX stop/deadline and actor rules remain.','Early fixture 130/3 includes an independent hold setup contaminated by the already failed exit. v2 establishes the hold case only after recording that failure; final before130/2 and after130/0 retain all assertions.','Actual original level_01, original gameplay inputs/waits/assertions. Explicit deferred80ms stop; captures are delayed and separately logged from assertions.','Software Vulkan Forward+, Dummy audio, synthetic input only. No physical controller/GPU, rig, human chapter or full-ticket acceptance.']}
(out/'validation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
files={}
def add(p,arc=None):p=Path(p);assert p.is_file(),p;files[arc or str(p)]=p.read_bytes()
for p in frozen:add(p,'source/final/'+p)
for p in ['game/player/vehicle_command_input.gd','tests/suite/test_input_feel.gd']:
 files['source/before/'+p]=subprocess.check_output(['git','show','f50882e9:'+p])
for pattern in ['vehicle-deferred-*','ci-f508*','package-vehicle-deferred.py']:
 for p in w.glob(pattern):
  if p.is_file():add(p)
  elif p.is_dir():
   for f in p.glob('*.log'):add(f)
for phase in ['before','after']:
 name='ne229-1024-deferred-'+phase
 for suffix in ['.log','.exit','-xvfb.log']:add(n/(name+suffix))
 for p in (n/name).glob('*.png'):add(p)
 shutil.copyfile(n/name/'player-mounts-vehicle.png',Path('pm/Nest-Egg/images')/('NE-229-deferred-'+phase+'.png'))
add(out/'validation.json');manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(out/'raw.zip') as z:
 for name,m in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==m['sha256'],name
h=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest();main=rows['original_main'];raw=(w/'vehicle-deferred-main'/'shard_0.log').read_text();errors=raw.count('ERROR:')
(out/'README.md').write_text(f'''# NE-229：延後停格保留原輸入邊緣

先讀User-guide與[既有同類作品研究](../../../../design/20-campaign-experience/VEHICLE_HITSTOP_INPUT.md)。同一步同步停格與物理步驟末尾延後停格須分開驗證。前一版f508已通過[完整CI40077537460](https://github.com/deadline314/Nest-Egg/actions/runs/40077537460)：96,404項／0新／已知失敗、530秒；完整job收於本包。補查發現另一條真缺口：短輪詢脈衝已放開，角色原本的引擎輸入邊緣卻仍有效，此時才延後停格仍可能漏鍵。沒有把前版綠燈說成全面涵蓋，也沒有把控制假稱原失敗CI唯一根因。

只保留那個尚未結束的原引擎邊緣，已接受、過期、進入Pause／GameplayLock即清除；不另加秒數窗口，不延長原頓幀或更改正常上下車規則。

| 同一控制 | 修前 | 修後 |
|---|---|---|
| 原隔離runner輸入套件＋7項 | 130項／2新失敗 | 130項／0新／已知失敗 |
| 原生原level_01完整玩法段 | 20項／1失敗 | 20項／0失敗 |

原選擇器f508只選InputFeelSuite，正式修後130／0、{rows['after']['seconds']}秒。額外原main完整核心流程{main['checks']}項／0新／已知失敗、{main['seconds']}秒。原InputFeel整份既有斷言／輸入／等待移除唯一新增呼叫後逐位元一致；原Smoke、玩家、載具、Fx及runner／selector／filters／known failures保持。原main有{errors}筆既有壞資料／物理查詢ERROR，由原filters辨識；輸入套件壞資料亦刻意印原InputFeel ERROR，沒有SCRIPT ERROR，不稱headless完全無ERROR。

新案例除了真正延後上下車，另驗正常上車後長按、隔一段時間才停格不會變成下車；範圍外按過的過期邊緣也不會在稍後停格／進範圍時重播。原暫停、保護時間、距離、獨立停用與公開事件案例全部保持。最早直接控制5／2；原runner先128／2，再129／2。增加獨立長按案例時130／3，其中第三項被先前已失敗的下車污染：原source／log保留。v2只在已記失敗後建立下一案例前提，仍保留同一七項判準，修前130／2、修後130／0，不將那個串連假失敗說成產品新缺口。

原生兩輪exit1／0，0引擎ERROR、0退出洩漏，六張1280×720真正視窗PNG逐張檢視並留SHA。仍是原level_01、真玩家／載具／敵人與原遊戲操作，僅明示加入延後80ms停格；沒有換正式章節避原關卡，也不在原流程停掉敵人。GAMEPLAY_DIAG是原斷言時刻，CAPTURE_STATE與照片讀回較晚，不能代稱同一物理格。軟體Vulkan Forward+／Dummy音訊與合成按鍵，不代稱實體手把、硬體GPU、人物關節或整票驗收。

[全部原檔](raw.zip)、[逐檔SHA](manifest.json)、[完整收據](validation.json)。原檔{len(files)}項、{(out/'raw.zip').stat().st_size:,} bytes，zip SHA `{h}`，逐項解出核對。
''')
p=Path('design/20-campaign-experience/VEHICLE_HITSTOP_INPUT.md');p.write_text(p.read_text()+'''\n## 2026-10-24：延後停格與原引擎輸入邊緣\n\nf508同步順序修正完整CI96404／0（530秒）後，另以原物理步驟末尾的deferred freeze補查，原runner130／2。短輪詢脈衝可能已釋放，但引擎原just-pressed物理邊緣尚未結束；只靠is_action_pressed的held latch仍會遺失。接收者可保留單一未結束邊緣，已接受、引擎邊緣結束、Pause／GameplayLock即清除。不得另加任意秒數或延長FX截止時間。正常上車後繼續按住，在較晚停格時也不能錯成下車；過期邊緣不能在稍後進搭乘範圍時重播。\n\n修前130／2→修後130／0，原生20／1→20／0。新增獨立長按案例的第一輪fixture被前一個已記失敗的退出污染，保留130／3原檔；v2只建立獨立前提，原斷言保持。原CI的真正停格快照與明示同步／延後控制分開，不推論唯一callback順序。[全部原檔與界線](../../pm/Nest-Egg/attachments/NE-229-deferred-input/README.md)。\n''')
p=Path('pm/Nest-Egg/[NE-229]補齊全流程手把操作.md');s=p.read_text();assert '# Commit-9' not in s;s+=f'''\n\n# Commit-9\n\n## 內文\n\n短按載具互動後才延後受到停格，原本仍可能沒有反應。現在原本有效的同一按鍵會接收一次，過期後不重播；正常上車後長按，也不會因稍後停格而意外下車。原停格時間、距離、上下車保護與暫停規則保持。\n\n前一版完整CI實際96,404項全過；補查新增不同停格順序，不以綠燈代稱所有時序已涵蓋。[原CI、負控制、中途fixture失敗、六張圖及完整界線](attachments/NE-229-deferred-input/README.md)。\n\n### 測試結果\n\n| 項目 | 結果 |\n|---|---|\n| 原runner輸入套件＋7項 | 130／2新失敗→130／0新／已知失敗 |\n| 原main完整核心流程 | {main['checks']}項／0新／已知失敗，{main['seconds']}秒 |\n| 原生同一原遊戲流程 | 20／1失敗→20／0；兩輪0引擎ERROR／退出洩漏 |\n\n### 前後圖\n\n| 修前未搭乘 | 修後機甲血條出現 |\n|---|---|\n| ![修前](images/NE-229-deferred-before.png) | ![修後](images/NE-229-deferred-after.png) |\n''';p.write_text(s)
p=Path('pm/user_guide.md');p.write_text('2026-10-24（NE-229）：同步與物理步驟末尾延後停格要分開驗。f508完整CI96,404／0、530秒後，補查仍130／2；只保留原引擎尚未結束的輸入邊緣，接受／過期／暫停即清，不另加秒數。正常上車後長按遇較晚停格不能意外下車，範圍外過期操作不能稍後重播。[130／0、原main、原生六圖與fixture污染原檔](Nest-Egg/attachments/NE-229-deferred-input/README.md)。\n\n'+p.read_text())
print('PACKAGED',len(files),h);print(json.dumps(rows))
