extends "res://tests/smoke_test.gd"

func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var suite = preload("res://work/batch1024/vehicle-deferred-step-suite.gd").new(self)
	await suite._test_vehicle_same_step_stop()
	await _finish()
