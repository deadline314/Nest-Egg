extends "res://tools/ch1_flow_probe.gd"

var _expected := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--expected="):
			_expected = arg.trim_prefix("--expected=")
	level_pattern = "res://data/levels/ch2_%s.tres"
	Transition.instant = true
	super._ready()


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch2_brief_done", true, false)
	Story.auto_skip = true
	await _enter("rooftop")
	_check(_level._training_stations.size() == 1, "run uses the actual rooftop practice station")
	if _level._training_stations.size() != 1:
		await _finish()
		return
	var station: TrainingStation = _level._training_stations.front()
	var prompt := station._prompt
	var player := _level.player
	var crosshair := _level.hud.crosshair
	player.global_position = station.global_position + Vector2(-24.0, 0.0)
	player.velocity = Vector2.ZERO
	player.facing = 1
	AimInput.set_virtual_gamepad(player, true)
	for size: float in [1.0, 1.1, 1.2]:
		Settings.set_ui_text_scale(size)
		AimInput.restore_direction(Vector2.RIGHT)
		await _settle(70)
		var frames_touching := 0
		for frame in 30:
			var rect := Rect2(prompt.base_rect().position + prompt._nudge, prompt.base_rect().size)
			var aim := crosshair.prompt_obstacle_rect()
			if prompt.is_showing() and aim.intersects(rect):
				frames_touching += 1
			await _settle(1)
		var reading := Rect2(prompt.base_rect().position + prompt._nudge, prompt.base_rect().size)
		var reticle := crosshair.prompt_obstacle_rect()
		_rows.append({"scale":size,"covered_frames":frames_touching,"visible":prompt.is_showing(),
			"true_point":str(player.aim_point),"reticle":str(reticle),"reading":str(reading),"inside_aim":reticle.has_point(player.aim_point)})
		_check(prompt.is_showing() and reticle.has_point(player.aim_point), "prompt and original true aim are visible at %.2f" % size)
		if _expected == "after":
			_check(frames_touching == 0, "actual crosshair stays clear for 30 frames at %.2f" % size)
		_capture("prompt-" + str(size))
	if _expected == "before":
		_check(_rows.any(func(record: Dictionary) -> bool: return record["covered_frames"] == 30),
			"the default actual aim reticle covers the original speech box in a reproducible case")
	if _expected == "after":
		await _sweep_aim(prompt, crosshair)
	await _finish()


func _sweep_aim(prompt: WorldPrompt, crosshair: Crosshair) -> void:
	for reduced: bool in [false, true]:
		Settings.set_reduce_ui_motion(reduced)
		var overlap := 0
		var visible_frames := 0
		for frame in 90:
			AimInput.restore_direction(Vector2.from_angle(sin(frame * TAU / 89.0) * 0.58))
			await RenderingServer.frame_post_draw
			if prompt.is_showing():
				visible_frames += 1
				var text := Rect2(prompt.base_rect().position + prompt._nudge, prompt.base_rect().size)
				overlap += 1 if crosshair.prompt_obstacle_rect().intersects(text) else 0
		_rows.append({"sweep": true, "reduced_motion": reduced, "covered_frames": overlap, "visible_frames": visible_frames})
		_check(overlap == 0 and visible_frames == 90, "moving real reticle keeps the prompt clear with reduced motion %s" % reduced)


func _finish() -> void:
	var data := FileAccess.open(_out_dir.path_join("result.json"),FileAccess.WRITE)
	data.store_string(JSON.stringify({"expected":_expected,"rows":_rows,"fails":_failures},"  ")+"\n")
	data.close()
	AudioRelease.begin_shutdown()
	if is_instance_valid(_level):
		_level.queue_free()
	await _settle(3)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures == 0 else 1)
