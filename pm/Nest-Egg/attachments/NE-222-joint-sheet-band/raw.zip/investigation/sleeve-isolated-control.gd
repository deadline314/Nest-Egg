extends Node
const PREVIEW := preload("res://tools/rig_preview.gd")
func _ready() -> void:
	_run.call_deferred()
func _run() -> void:
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	DirAccess.make_dir_recursive_absolute(out)
	var cases: Array[Dictionary] = [
		{"pose":"run", "zoom":3.4,"facing":1,"ticks":3,"bone":&"arm_back_upper","offsets":[Vector2i(9,16),Vector2i(9,17)]},
		{"pose":"run", "zoom":3.4,"facing":-1,"ticks":3,"bone":&"arm_back_upper","offsets":[Vector2i(-10,16),Vector2i(-10,17)]},
		{"pose":"stagger", "zoom":3.4,"facing":1,"ticks":4,"bone":&"arm_back_upper","offsets":[Vector2i(-1,28)]},
		{"pose":"stagger", "zoom":3.4,"facing":-1,"ticks":4,"bone":&"arm_back_upper","offsets":[Vector2i(0,28)]},
		{"pose":"dead", "zoom":1.0,"facing":-1,"ticks":2,"bone":&"hand_back","offsets":[Vector2i.ZERO]},
	]
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1280,400)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(viewport)
	var entries: Array[Dictionary] = []
	for index in cases.size():
		var c: Dictionary = cases[index]
		var holder := Node2D.new()
		holder.scale = Vector2.ONE * float(c.zoom)
		viewport.add_child(holder)
		var rig := CharacterRig.new()
		holder.add_child(rig)
		if not rig.setup("rin"):
			get_tree().quit(1)
			return
		rig.set_weapon(str(PREVIEW.SHEET_WEAPONS.get("rin","")))
		for part in rig._parts:
			var material := CanvasItemMaterial.new()
			material.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
			part.material = material
			for child in part.get_children():
				if child is CanvasItem:
					child.visible = false
		var keep := PackedStringArray(["armor_jacket", "armor_jacket_far", "torso", "jacket_sleeve_back_upper"] if c.pose != "dead" else ["jacket_sleeve_back_upper", "jacket_sleeve_back_lower", "arm_back_upper", "arm_back_lower", "hand_back"])
		var pair_bones: Array[Node] = []
		for part in rig._parts:
			if keep.has(str(part.name)) and not pair_bones.has(part.get_parent()):
				pair_bones.append(part.get_parent())
		for part in rig._parts:
			if str(part.name).begins_with("Pose_"):
				continue
			rig._set_base_part_visible(part, keep.has(str(part.name)) or (rig._base_part_is_visible(part) and pair_bones.has(part.get_parent())))
		var input := RigInput.new()
		input.facing = int(c.facing)
		input.aim_dir = Vector2(input.facing,0)
		input.on_floor = true
		input.velocity = Vector2(150.0*input.facing,0) if c.pose == "run" else Vector2.ZERO
		input.staggered = c.pose == "stagger"
		input.dead = c.pose == "dead"
		input.two_handed = true
		for tick in int(c.ticks):
			rig.animate(1.0/60.0,input)
		if rig.weapon_root() != null:
			rig.weapon_root().visible = false
		var center := Vector2(index*256+128,200 if c.pose == "dead" else 120)
		holder.position += center-rig.bone(c.bone).global_position
		var title := Label.new()
		title.position = Vector2(index*256+6,4)
		title.add_theme_font_size_override("font_size",12)
		title.text = "%s %.1fx side%d step%d\nISOLATED CONTROL / UNSHADED\nchild VFX and weapon hidden" % [c.pose,c.zoom,c.facing,c.ticks]
		viewport.add_child(title)
		var footer := Label.new()
		footer.position = Vector2(index*256+6,358)
		footer.add_theme_font_size_override("font_size",12)
		viewport.add_child(footer)
		entries.append({"case":c,"center":center,"footer":footer})
	await RenderingServer.frame_post_draw
	var picture := viewport.get_texture().get_image()
	var records: Array[Dictionary] = []
	for entry in entries:
		var values: Array[int] = []
		for offset: Vector2i in entry.case.offsets:
			values.append(roundi(picture.get_pixelv(Vector2i(entry.center)+offset).a*255.0))
		entry.footer.text = "audit-target alpha: " + str(values)
		records.append({"pose":entry.case.pose,"zoom":entry.case.zoom,"facing":entry.case.facing,"ticks":entry.case.ticks,"center":str(entry.center),"offsets":str(entry.case.offsets),"isolated_alpha":values})
	await RenderingServer.frame_post_draw
	picture = viewport.get_texture().get_image()
	for index in entries.size():
		var entry: Dictionary = entries[index]
		var values: Array[int] = []
		for offset: Vector2i in entry.case.offsets:
			values.append(roundi(picture.get_pixelv(Vector2i(entry.center)+offset).a*255.0))
		assert(values==records[index].isolated_alpha)
	picture.save_png(out.path_join("isolated-control.png"))
	var f := FileAccess.open(out.path_join("isolated-control.json"),FileAccess.WRITE)
	f.store_string(JSON.stringify(records,"\t"))
	print("ISOLATED_CONTEXT ",JSON.stringify(records))
	viewport.queue_free()
	await get_tree().process_frame
	get_tree().quit()
