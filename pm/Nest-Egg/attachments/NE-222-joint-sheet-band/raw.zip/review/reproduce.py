"""Run from the extracted packet: python3 review/reproduce.py."""
from pathlib import Path
import contextlib
import importlib.util
import io
import json
from PIL import Image
root=Path(__file__).resolve().parent.parent
pair=json.loads((root/'review/pair4-pinned.json').read_text())
worn=json.loads((root/'review/baseline4-pinned.json').read_text())
canvas=Image.new('RGB',(968,1936))
key=lambda f:(f['joint'],f['pose'],f['facing'],f['zoom'],f['frame'])
for col,name in enumerate(['before','after']):
 path=root/'source'/('joint_audit_both_before.py' if name=='before' else 'joint_audit_both.py')
 spec=importlib.util.spec_from_file_location(name,path)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 for row,f in enumerate(pair['failures']):
  p={'failures':[f]};b={'failures':[x for x in worn['failures'] if key(x)==key(f)]}
  out=root/'review'/f'{name}-{row}.png'
  with contextlib.redirect_stdout(io.StringIO()):
   module.class_sheet(root/'captures/pair4',p,root/'captures/baseline4',b,out,cols=1)
  with Image.open(out) as image:canvas.paste(image,(484*col,484*row))
canvas.save(root/'review/fixed-record-comparison.png')
