from pathlib import Path
import json,os,subprocess,sys

base=Path(__file__).resolve().parent
shared=base.with_name("ne218-baseline-20261117")
engine="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
for key,resolution in (("baseline","1280x720"),):
    out=base/key
    profile=out/"profile"
    profile.mkdir(parents=True,exist_ok=False)
    env=os.environ.copy()
    env.update(APPDATA=str(profile),LOCALAPPDATA=str(profile))
    command=[sys.executable,"-B",str(shared/"tools/comfyui/gpu_lock.py"),"--",engine,"--path",str(shared),
             "--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy","--resolution",resolution,
             "--fixed-fps","60","--quit-after","1500",str(base/"guide.tscn"),"--",f"--out={out}"]
    (out/"command.json").write_text(json.dumps(command,indent=2)+"\n")
    with (out/"raw.log").open("wb") as log:
        run=subprocess.run(command,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    (out/"exit.txt").write_text(str(run.returncode)+"\n")
    text=(out/"raw.log").read_text(encoding="utf-8")
    assert run.returncode==1 and "ERROR:" not in text and "leaked at exit" not in text,text
    value=json.loads((out/"summary.json").read_bytes())
    assert value["checks"]==84 and value["failures"]==6 and len(value["rows"])==18
    assert "RX 9070 XT" in value["adapter"] and value["rendering"]=="forward_plus"
    print(key,value["checks"],value["failures"],flush=True)
