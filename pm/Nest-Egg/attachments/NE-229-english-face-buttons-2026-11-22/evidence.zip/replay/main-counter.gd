extends "res://tests/probes/prologue_completion.gd"

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	super._ready()

func _drive_dialogue() -> void:
	var host := Story._layer
	var lines := Story.resolved_lines(target)
	var want := 4 if phase == "call" else 5
	var motion := InputEventJoypadMotion.new()
	motion.device = 999
	motion.axis = JOY_AXIS_RIGHT_X
	motion.axis_value = 0.9
	Input.parse_input_event(motion)
	Input.flush_buffered_events()
	await _frames(1)
	_check(InputBindings.using_gamepad and InputBindings.active_device == 999, "the actual English counter observed the synthetic pad event")
	_check(lines.size() == want, "the real counter source has the expected authored line count")
	var seen := 0
	var content := []
	for tick in 1200:
		if not Story.is_cinematic_active() or _prompt() != null:
			break
		if host.is_cinematic_active() and host._text.visible_ratio >= 1.0:
			await RenderingServer.frame_post_draw
			var item := host._text
			_check(seen < lines.size() and item.text == lines[seen]["text"],
				"the rendered localized line matches the active counter source")
			_check(item.get_visible_line_count() == item.get_line_count() and item.get_line_count() >= 1,
				"the full localized dialogue fits at 120 percent text scale")
			var rect := item.get_global_rect()
			var panel := host._dialogue_panel.get_global_rect()
			_check(panel.grow(1.0).encloses(rect), "the full text rect stays inside the counter dialogue panel")
			_check(host._continue.visible and host._continue.text == "A (bottom) Continue",
				"the English counter keeps the pad position beside the action")
			_check(host._dialogue_panel.get_global_rect().grow(1.0).encloses(host._continue.get_global_rect()),
				"the entire English controller prompt fits inside the dialogue panel")
			await _capture("line-%d" % seen)
			content.append({"text":item.text,"visual_lines":item.get_line_count(),"panel":str(panel),"rect":str(rect)})
			seen += 1
			host.advance()
		await _frames(1)
	_check(seen == want and not Story.is_cinematic_active(), "the authored marks complete only after every localized line")
	FileAccess.open(out.path_join("text.json"),FileAccess.WRITE).store_string(JSON.stringify(
		{"language":Story.language,"target":String(target),"lines":content}, "  "))
