extends "res://tests/smoke_test.gd"

var _out := ""


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://map_recenter_probe.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
	super._ready()


func _run() -> void:
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(load("res://data/levels/ch1_pawnshop.tres") as LevelData)
	add_child(level)
	await _frames(36)
	var menu := level._pause_menu
	await _send_key(KEY_M)
	await _frames(12)
	_check(is_instance_valid(menu._navigation) and menu._navigation._page == "region" and get_tree().paused, "real pawnshop map opens from M")
	var map := menu._navigation
	if not is_instance_valid(map):
		await _finish()
		return
	await _test_center(map, false)
	await _test_center(map, true)
	await _send_key(KEY_E)
	await _frames(5)
	_check(map._page == "world", "tab opens the authored world map")
	var destination: Button
	for marker in map._canvas._markers:
		if not marker.text.begins_with("▲ "):
			destination = marker
			break
	_check(destination != null, "the world map has a destination outside the pawnshop")
	if destination != null:
		destination.grab_focus()
		var title := destination.text
		await _send_button(JOY_BUTTON_A)
		await _frames(5)
		_check(map._page == "region" and map._map_path != map.player_path, "world-map destination opens its real area")
		await _test_center(map, true, "other-area")
		await _send_button(JOY_BUTTON_B)
		await _frames(5)
		var focus := get_viewport().gui_get_focus_owner() as Button
		_check(map._page == "world" and focus != null and focus.text == title, "Back restores the original world-map destination and its focus")
		await _send_button(JOY_BUTTON_B)
		await _frames(5)
	await _send_button(JOY_BUTTON_B)
	await _frames(6)
	_check(not is_instance_valid(menu._navigation) and menu._root.visible and get_tree().paused, "Back returns to the paused pawnshop menu")
	menu.close()
	await _frames(2)
	level.queue_free()
	await _frames(2)
	await _finish()


func _button(map: QuestMapScreen, text: String) -> Button:
	for control: Button in map.find_children("*", "Button", true, false):
		if control.text == text:
			return control
	return null


func _test_center(map: QuestMapScreen, controller: bool, suffix := "") -> void:
	var device := "controller" if controller else "keyboard"
	if not suffix.is_empty():
		device += "-" + suffix
	var initial := _button(map, "放大")
	if initial == null:
		_check(false, "the real regional map has a zoom control")
		return
	initial.grab_focus()
	if controller:
		await _send_button(JOY_BUTTON_A)
	else:
		await _send_key(KEY_ENTER)
	await _frames(3)
	_check(map._canvas.zoom == 2.0, device + " zooms the real map")
	var center := _button(map, "回到所在區域")
	if center == null:
		_check(false, "the real regional map has a center control")
		return
	center.grab_focus()
	if controller:
		await _send_button(JOY_BUTTON_A)
	else:
		await _send_key(KEY_ENTER)
	await _frames(5)
	center = _button(map, "回到所在區域")
	var owner := get_viewport().gui_get_focus_owner() as Button
	print("CENTER ", device, " focused=", owner.text if owner != null else "<none>", " zoom=", map._canvas.zoom, " status=", map._status.text)
	_check(map._map_path == map.player_path and map._canvas.zoom == 1.0, device + " resets regional zoom")
	_check(center != null and owner == center, device + " keeps focus on the activated center control")
	_check(center != null and map._status.text == center.tooltip_text, device + " keeps the center control hint")
	await _shot(device + "-center")


func _send_key(code: Key) -> void:
	var press := InputEventKey.new()
	press.keycode = code
	press.physical_keycode = code
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _send_button(button: JoyButton) -> void:
	var press := InputEventJoypadButton.new()
	press.button_index = button
	press.pressure = 1.0
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	release.pressure = 0.0
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _shot(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join(name + ".png")) == OK, "saved " + name)