extends "res://tools/ch3_flow_probe.gd"

const Capture := preload("res://tools/viewport_capture.gd")
var _captured := false


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	super._ready()


func _capture(_frame_name: String) -> void:
	pass


func _enter(area: String, near := Vector2.INF) -> void:
	if not _captured and GameState.has_flag(&"ch3_janus_aftercare_done") and is_instance_valid(_level) and str(_level.data.id) == "ch3_gate_hall":
		var actor := _object(&"ch3_gatekeeper")
		_check(is_instance_valid(actor) and actor._actor.pose == &"sit", "the authored hall keeps the seated gatekeeper")
		await _settle(3)
		await RenderingServer.frame_post_draw
		var target := _out_dir.path_join("gatekeeper-aftercare.png")
		_captured = Capture.image(get_viewport()).save_png(target) == OK
		_check(_captured, "native aftercare capture from the original gate hall")
	await super._enter(area, near)
