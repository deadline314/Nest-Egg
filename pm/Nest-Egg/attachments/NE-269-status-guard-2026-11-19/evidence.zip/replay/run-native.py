from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = root / 'work/ne269-status-guard-20261119'
variant = sys.argv[1]
assert variant in ('before', 'after')
name = 'ui/inventory/pages/status_page.gd'
assert (shared / name).read_bytes() == (base / variant / name).read_bytes()
out = base / f'native-{variant}'
out.mkdir()
probe = base / 'probe.gd'
scene = base / 'probe.tscn'
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n'
                 '[node name="GuardStatus" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[key] = str(out / 'profile' / key)
command = [sys.executable, '-B', str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
           '--resolution', '1280x720', '--fixed-fps', '60', '--quit-after', '1600',
           scene.as_posix(), '--', '--out=' + str(out)]
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (out / 'raw.log').open('wb') as log:
    result = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=160)
raw = (out / 'raw.log').read_text(encoding='utf-8')
print(raw[-2500:], flush=True)
report = json.loads((out / 'report.json').read_text(encoding='utf-8'))
print(json.dumps(report, ensure_ascii=False), flush=True)
assert '9070 XT' in report['adapter'] and report['size'] == [1280, 720] and report['scale'] == 1.2
assert 'SCRIPT ERROR' not in raw and 'ERROR:' not in raw
assert report['credits'] == 0
readings = report['readings']
assert readings['before-purchase']['guard'] == readings['after-purchase']['guard']
assert readings['before-purchase']['capacity'] < readings['after-purchase']['capacity']
if variant == 'before':
    assert result.returncode == 1 and report['failures'] == 2
    assert readings['after-purchase']['shown'] == '100%' and readings['half-guard']['shown'] == '65%'
else:
    assert result.returncode == 0 and report['failures'] == 0
    assert readings['after-purchase']['shown'] == '77%' and readings['half-guard']['shown'] == '50%'
