extends ScenarioBase

var _readings: Dictionary = {}


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	await open_arena("res://data/lighting/warehouse_interior.tres")
	player.health.setup(player._max_health, player.tuning.hurt_invulnerability)
	var part := Progression.find_arm_shield_part(&"cushion_pad")
	Progression.add_credits(part.cost)
	var inventory := level._inventory
	var status_index := inventory.page_index(StatusPage)
	var status := inventory._pages[status_index] as StatusPage
	inventory.open()
	inventory.select_tab(status_index)
	player.guard = player.guard_max()
	await _sample("before-purchase", status, "100%", 10)
	var upgrades_index := inventory.page_index(UpgradesPage)
	inventory.select_tab(upgrades_index)
	var upgrades := inventory._pages[upgrades_index] as UpgradesPage
	var part_index := upgrades._targets.size() + upgrades._arm_targets.find(part)
	upgrades._select(part_index)
	await settle(8)
	_check(upgrades._selected == part_index and not upgrades._detail._action.disabled, "the real workbench confirms the available cushion")
	await RenderingServer.frame_post_draw
	capture("workbench")
	var remaining := player.guard
	var max_before := player.guard_max()
	upgrades._detail._action.pressed.emit()
	_check(Progression.has_arm_shield_part(part.id) and Progression.credits == 0, "the workbench charges the exact price")
	_check(player.guard == remaining and is_equal_approx(player.guard_max(), max_before * (1.0 + part.amount)),
		"installing the cushion raises the cap without refilling guard")
	inventory.select_tab(status_index)
	await _sample("after-purchase", status, "77%", 8)
	player.guard = player.guard_max() * 0.5
	await _sample("half-guard", status, "50%", 5)
	player.guard = player.guard_max()
	await _sample("full-upgraded-guard", status, "100%", 10)
	inventory.close()
	_check(not get_tree().paused, "leaving the inventory resumes play")
	var size := get_window().size
	var report := {"readings": _readings, "failures": failures, "adapter": RenderingServer.get_video_adapter_name(),
		"size": [size.x, size.y], "scale": Settings.get_ui_text_scale(), "credits": Progression.credits}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)


func _sample(label: String, status: StatusPage, percent: String, segments: int) -> void:
	status.refresh()
	var shown := status._values[&"guard"].text
	var filled := status._guard_bar._filled
	_readings[label] = {"shown": shown, "segments": filled, "guard": player.guard, "capacity": player.guard_max()}
	_check(shown == percent and filled == segments, label + " shows the actual guard fraction")
	await settle(5)
	await RenderingServer.frame_post_draw
	capture(label)


func _check(condition: bool, label: String) -> void:
	if not condition:
		failures += 1
		print("NE269 guard probe: ", label)
