from collections import Counter
from hashlib import sha256
from pathlib import Path
import json

import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent
root=Path.cwd()
sha=lambda path: sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_bytes())
def key(f): return (f['char'],f['joint'],f['pose'],f['zoom'],f['facing'],f['frame'])
def gap(f): return f['center_alpha']<128 or f['enclosed_pixels'] or f['loose_pieces']

results={}
for scope,before,num in (('whole','extended-whole-long',3840),('torso-joints','stock-torso-joints',4608),
                         ('dressed','stock-dressed',1152),('isolated','stock-isolated',1152)):
    old=read(base/before/'report.json')
    new=read(base/f'final-{scope}'/'report.json')
    assert new['samples']==num
    current=[f for f in old['failures'] if num!=1152 or f['frame']<36]
    previous={key(f) for f in current if gap(f)}
    repaired={key(f) for f in new['failures'] if gap(f)}
    added=sorted(repaired-previous)
    results[scope]={'samples':num,'before':[len(current),len(previous)],'after':[new['failed_samples'],len(repaired)],
                    'new_gap_keys':added,'remaining_gaps_by_action':dict(Counter(k[2] for k in repaired))}
    assert not added,(scope,added)
    if scope in ('dressed','isolated'):
        assert {key(f) for f in current}=={key(f) for f in new['failures']},scope
        assert all(sha(p)==sha(base/before/p.name) for p in (base/f'final-{scope}').glob('*.png')),scope
assert results['whole']['before'][1] == 228
assert results['whole']['after'][1] <= 2 and not results['whole']['remaining_gaps_by_action'].get('crouch')
assert results['torso-joints']['before'][1] == 380 and results['torso-joints']['after'][1] <= 216

for suffix in ('final-dressed','final-isolated','final-whole','final-torso-joints','final-damage','normal','import'):
    assert 'ERROR:' not in (base/(suffix+'.log')).read_text(encoding='utf-8'),suffix
backup=root/'art_src/characters/warden/neck_overlap/torso-before.png'
new=root/'art_src/characters/warden/overrides/torso.png'
actual_diffuse=root/'art/characters/warden/parts/torso.png'
actual_normal=root/'art/characters/warden/parts/torso_n.png'
assert sha(new)==sha(actual_diffuse)==sha(base/'torso-trial.png')
assert sha(actual_normal)==sha(base/'normal-after.png')
assert sha(backup)==sha(base/'cut-check/warden/parts/torso.png')
assert sha(base/'normal-before.png')==sha(base/'normal-before-rebuilt.png')
old,patched,original_normal,baked=(np.asarray(Image.open(p).convert('RGBA')) for p in (backup,new,base/'normal-before.png',actual_normal))
changed=np.any(old!=patched,axis=2)
assert changed.sum()==246 and np.array_equal(patched[:,:,3],baked[:,:,3])
assert np.all(old[changed,3]<235) and np.all(old[changed,3]<patched[changed,3])
results['source']={'old':sha(backup),'diffuse':sha(actual_diffuse),'normal':sha(actual_normal),
                   'diffuse_pixels':int(changed.sum()),'normal_pixels':int(np.any(original_normal!=baked,axis=2).sum()),
                   'grid':[479,604]}
(base/'verification.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results))
