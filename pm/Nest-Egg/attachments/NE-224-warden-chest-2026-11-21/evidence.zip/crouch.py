from pathlib import Path
from PIL import Image,ImageDraw
import json
base=Path(__file__).resolve().parent
sheet=Image.new('RGB',(576,457),(33,37,48))
draw=ImageDraw.Draw(sheet)
for row,facing in enumerate((1,-1)):
    for col,scope in enumerate(('extended-whole-long','final-whole')):
        groups=json.loads((base/scope/'frames.json').read_bytes())
        group=next(g for g in groups if g['pose']=='crouch' and g['zoom']==3.4)
        x,y,w,h=next(c['rect'] for c in group['cells'] if c['facing']==facing)
        cx=(x+53 if facing==1 else x+75)
        with Image.open(base/scope/group['samples'][12]['file']) as frame:
            crop=frame.crop((cx-17,y+30,cx+17,y+54)).convert('RGBA')
        paper=Image.new('RGBA',crop.size,(140,151,170,255))
        paper.alpha_composite(crop)
        ox,oy=8+col*288,8+row*226
        sheet.paste(paper.resize((272,192),Image.Resampling.NEAREST).convert('RGB'),(ox,oy+19))
        draw.text((ox,oy),f'{"Before" if col==0 else "With overlap"}, facing {"right" if facing==1 else "left"}',
                  fill='#f9fafc')
sheet.save(base/'crouch-compare.png')
