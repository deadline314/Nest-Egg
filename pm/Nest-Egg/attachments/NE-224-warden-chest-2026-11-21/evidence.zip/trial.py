from pathlib import Path
import numpy as np
from PIL import Image
target=Path(__file__).resolve().parent/'torso-trial.png'
old=np.asarray(Image.open('art/characters/warden/parts/torso.png').convert('RGBA'))
new=old.copy()
for y in range(109,124):
    end=339-max(0,y-117)*2
    span=new[y,316:end]
    span[span[:,3]<235]=old[y,314]
assert np.array_equal(old[old[:,:,3]>=235],new[old[:,:,3]>=235])
print('updated', np.count_nonzero(np.any(old!=new,axis=2)))
Image.fromarray(new).save(target)
