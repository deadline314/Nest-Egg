from hashlib import sha256
from itertools import groupby
from pathlib import Path
import json
import re

root=Path.cwd()
levels=root/"data/levels"
output=Path(__file__).resolve().parent/"map-corridors.json"
catalog=json.loads((root/"data/combat/chapter_rosters.json").read_bytes())["chapters"]
selected=[level for chapter in ("ch1_kasa","ch2_heron") for level in catalog[chapter]["levels"]]
result={}
for name in [*selected,"level_01","level_02"]:
    level=levels/(name+".tres")
    raw=level.read_text(encoding="utf8")
    path=re.search(r'layout_path = "res://([^"]+)"',raw)[1]
    mapfile=root/path
    segments=json.loads(mapfile.read_bytes())["segments"]
    width=[max(map(len,segment)) for segment in segments]
    height=int(re.search(r"\nheight = (\d+)",raw)[1])
    tile=int(re.search(r"\ntile_size = (\d+)",raw)[1])
    rows=["".join((segment[r] if r<len(segment) else "").ljust(w,".") for w,segment in zip(width,segments)) for r in range(height)]
    groups={}
    for col in range(1,len(rows[0])-1):
        for floor in range(4,height):
            if rows[floor][col] not in "#=~" or rows[floor-1][col] in "#=~":
                continue
            for roof in range(floor-2,max(floor-8,-1),-1):
                if rows[roof][col]=="#":
                    headroom=(floor-roof-1)*tile
                    if 0<headroom<=80:
                        groups.setdefault((floor,headroom),[]).append(col)
                    break
    found=[]
    for (floor,headroom),cols in groups.items():
        for _,band in groupby(enumerate(cols),lambda pair: pair[1]-pair[0]):
            strip=[col for _,col in band]
            if len(strip)>1:
                found.append({"left":strip[0],"right":strip[-1],"floor":floor,"headroom":headroom,
                              "fits_unmodified_44_pixel_collider":headroom>=44})
    result[name]={"map":path,"sha256":sha256(mapfile.read_bytes()).hexdigest(),"lanes":found,"height":height,"tile":tile}
output.write_text(json.dumps({"method":"At least two adjacent columns with contiguous authored ground and a solid overhead ceiling. Heads, door states, props and platform path connectivity require runtime validation.","levels":result},indent=2)+"\n")
print("current areas",len(selected),"legacy areas",2)
print({name:record["lanes"] for name,record in result.items() if record["lanes"]})
