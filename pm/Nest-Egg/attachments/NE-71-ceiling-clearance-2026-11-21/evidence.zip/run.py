from pathlib import Path
from hashlib import sha256
import json
import os
import re
import subprocess
import sys

base=Path(__file__).resolve().parent
project=base.parent/"ne218-baseline-20261117"
folder=base/sys.argv[1]
requested=sys.argv[2:]
folder.mkdir()
env=os.environ.copy()
for key in ("APPDATA","LOCALAPPDATA","TEMP","TMP","TMPDIR","XDG_CONFIG_HOME","XDG_DATA_HOME"):
    isolated=folder/key
    isolated.mkdir()
    env[key]=str(isolated)
hashes=[f"data/levels/{name}{suffix}" for name in ("ch1_prologue","ch2_ledger_office","level_01","level_02")
        for suffix in (".tres","_map.json")]
hashes += ["game/player/player.gd","game/rig/character_rig.gd","game/rig/humanoid_animator.gd","art/characters/rin/character.json"]
sha=lambda path:sha256(path.read_bytes()).hexdigest()
source={name:sha(project/name) for name in hashes}
engine="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
command=[engine,"--path",str(project)]
if "headless" in requested:
    command.append("--headless")
else:
    command=[sys.executable,"-B",str(project/"tools/comfyui/gpu_lock.py"),"--"]+command
    command += ["--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy","--resolution","1280x720"]
command += ["--fixed-fps","60","--quit-after","9000",str(base/"observe.tscn"),"--","--out="+str(folder)]
command += [arg for arg in requested if arg.startswith("--case=")]
(folder/"command.json").write_text(json.dumps({"command":command,"source_sha256":source},indent=2)+"\n")
with (folder/"engine.log").open("wb") as f:
    proc=subprocess.run(command,cwd=project,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=210)
log=(folder/"engine.log").read_text(encoding="utf-8",errors="replace")
print(log[-3500:],flush=True)
assert proc.returncode==0 and not re.search(r"^(?:SCRIPT )?ERROR:|^FAIL ",log,re.M)
data=json.loads((folder/"corridors.json").read_bytes())
assert data["failures"] == 0 and data["runs"]
assert source=={name:sha(project/name) for name in hashes}
