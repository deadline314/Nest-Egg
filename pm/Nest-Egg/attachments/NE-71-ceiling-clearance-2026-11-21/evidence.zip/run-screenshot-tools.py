from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

base=Path(__file__).resolve().parent
project=base.parent/"ne218-baseline-20261117"
source=json.loads((base/"source.json").read_bytes())
root=base/"replacement-screenshot-tools-final"
root.mkdir()
expected={
    "rin_fit": {"rin_fit_"+name for name in ("stand","aim_up45","aim_up90","aim_down","crouch","run",
                                          "jump","block","tunnel_stand","tunnel_crouch")},
    "rin_light": {"rin_light_"+name for name in ("transfer","blackout","market")},
    "exposure": {"state_"+name for name in ("idle","hurt","hurt_late","fire","block")},
}
for scenario,names in expected.items():
    scope=root/scenario
    scope.mkdir()
    env=os.environ.copy()
    for key in ("APPDATA","LOCALAPPDATA","TEMP","TMP","TMPDIR","XDG_CONFIG_HOME","XDG_DATA_HOME"):
        profile=scope/key
        profile.mkdir()
        env[key]=str(profile)
    path="tools/screenshot.gd" if scenario=="exposure" else f"tools/scenarios/{scenario}_scenario.gd"
    source_code=(project/path).read_bytes()
    assert sha256(source_code).hexdigest()==source[path]
    if scenario!="exposure":
        assert b"Input.warp_mouse" not in source_code and b"AimInput.set_virtual_gamepad" in source_code
    selected="exposure_states@ch1_street@29" if scenario=="exposure" else scenario
    command=[sys.executable,"-B",str(project/"tools/comfyui/gpu_lock.py"),"--",
             "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(project),"--rendering-method","forward_plus",
             "--rendering-driver","vulkan","--audio-driver","Dummy","--fixed-fps","60","--resolution","1280x720",
             "--quit-after","3600",str(base/"screens.tscn"),"--",f"--out={scope}",f"--scenario={selected}"]
    (scope/"command.json").write_text(json.dumps({"command":command,"sha256":source[path]},indent=2)+"\n")
    with (scope/"engine.log").open("wb") as f:
        p=subprocess.run(command,cwd=project,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=280)
    log=(scope/"engine.log").read_text(encoding="utf8",errors="replace")
    assert p.returncode==0 and not re.search(r"^(?:SCRIPT )?ERROR:|^FAIL ",log,re.M),log[-5000:]
    assert {file.stem for file in scope.glob("*.png")}==names,(scenario,log[-4000:])
    assert all(png.read_bytes()[:8]==bytes.fromhex("89504e470d0a1a0a") for png in scope.glob("*.png"))
    print(scenario,len(names),flush=True)
