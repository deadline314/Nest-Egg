extends "res://tools/ch1_flow_probe.gd"


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip = true
	await _enter("pawnshop", Vector2(86 * 16, 19 * 16))
	var active := _level.player
	_check(is_instance_valid(active) and active.is_on_floor(), "real pawnshop player is ready on its floor")
	active.health.setup(100, 0.0)
	AimInput.set_virtual_gamepad(active, true)
	Input.action_press(&"aim_right")
	await _settle(45)
	_check(active.facing == 1 and active._visual.rig.contact_surface(&"armor_jacket") != null
		and active._visual.rig.contact_surface(&"armor_jacket_far") != null, "both gameplay coat panels are currently worn")
	await RenderingServer.frame_post_draw
	_capture("worn-idle")
	Input.action_press(&"move_down")
	await _settle(22)
	_check(active.is_crouching, "normal player input enters the crouch")
	await RenderingServer.frame_post_draw
	_capture("worn-crouch")
	Input.action_release(&"move_down")
	await _settle(28)
	var info := DamageInfo.create(1, Combat.Team.ENEMY, &"coat_probe")
	info.origin = active.global_position + Vector2(20, -10)
	active.health.take_damage(info)
	_check(active.health.current == 99, "the live player health lifecycle receives the controlled hit")
	for sample in 8:
		await RenderingServer.frame_post_draw
		_capture("worn-stagger-%02d" % sample)
	_check(active._visual.rig.contact_surface(&"armor_jacket") != null, "light hit keeps the tested outfit active")
	Input.action_release(&"aim_right")
	AimInput.set_virtual_gamepad(active, false)
	_level.queue_free()
	await _settle(3)
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if _failures else 0)
