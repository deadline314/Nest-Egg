from pathlib import Path
from collections import Counter
import json
import numpy as np
from PIL import Image
from scipy import ndimage

base=Path(__file__).resolve().parent
pilot=base.parent/'evidence-20261120-ne222-cuff'
prior=base.parent/'evidence-20261120-ne222-waist'

def read(folder):
    report=json.loads((folder/'report.json').read_bytes())
    failures={(r['joint'],r['pose'],r['zoom'],r['facing'],r['frame']):r
              for r in report['failures'] if r['enclosed_pixels'] or r['loose_pieces'] or r['center_alpha']<128}
    return report['samples'],failures

counts={}
for kind,before,after in (
    ('paired',prior/'release-paired',base/'candidate-paired'),
    ('whole',pilot/'whole',base/'candidate-whole'),
    ('pilot-one',pilot/'variant-0',pilot/'variant-1'),
    ('pilot-two',pilot/'variant-0',pilot/'variant-2'),
):
    count,old=read(before)
    new_count,new=read(after)
    assert count==new_count
    old_keys=set(old)
    new_keys=set(new)
    lost=old_keys-new_keys
    fresh=new_keys-old_keys
    inc=[k for k in (old_keys&new_keys) if new[k]['enclosed_pixels']>old[k]['enclosed_pixels']]
    counts[kind]={'samples':count,'baseline':len(old),'candidate':len(new),
                  'fixed_by_joint':dict(Counter(k[0] for k in lost)),
                  'fixed_by_pose':dict(Counter(k[1] for k in lost)),
                  'new':sorted(fresh),'increased':sorted(inc)}
    if kind in ('paired','whole'):
        assert not fresh and not inc, counts[kind]
whole=base/'candidate-whole'
indices={(g['pose'],g['zoom'],c['joint'],c['facing']):c
    for g in json.loads((whole/'frames.json').read_bytes()) for c in g['cells']}
locations=json.loads((pilot/'locations.json').read_bytes())
exact=Counter()
for row in locations:
    entry=indices[row['pose'],row['zoom'],row['joint'],row['facing']]
    x,y,w,h=entry['rect']
    r=32 if row['zoom']==3.4 else 10
    path=whole/f'{row["pose"]}_{row["zoom"]:.1f}_{row["frame"]:03}.png'
    area=(x+w//2-r,y+h//2-r,x+w//2+r,y+h//2+r)
    solid=np.asarray(Image.open(path).convert('RGBA').crop(area))[:,:,3]>=128
    xx,yy=row['point']
    closed=ndimage.binary_fill_holes(solid,structure=np.ones((3,3)))
    bucket='covered' if solid[yy,xx] else 'enclosed' if closed[yy,xx] else 'open'
    exact[(row['joint'],row['pose'],row['type'],bucket)]+=1
counts['locations']=[dict(joint=k[0],pose=k[1],before=k[2],after=k[3],pixels=n) for k,n in sorted(exact.items())]
print(json.dumps(counts,indent=2))
(base/'comparison.json').write_text(json.dumps(counts,indent=2)+'\n')
