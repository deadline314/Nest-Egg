from pathlib import Path
import json
import sys
from io import BytesIO
from subprocess import check_output
from hashlib import sha256
import numpy as np
from PIL import Image
root=Path.cwd()
base=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'tools/comfyui'))
from cut_layers import part_transform,render_part
name='armor_jacket_far'
rel_source=f'art_src/characters/rin_field/overrides/refined/{name}.png'
rel_dst=f'art/characters/rin/parts/{name}.png'
published=lambda path:check_output(["git","show",f"HEAD:{path}"])
p=Image.open(BytesIO(published(rel_source))).convert('RGBA')
s=json.loads((root/'tools/comfyui/specs/rin_side.json').read_bytes())
k=s['tex_px_per_wp']/s['illustration_px_per_wp']
joints={n:np.array(v)*k for n,v in s['joints'].items()}
cfg=s['parts'][name]
first=part_transform(p,cfg,joints,k)
old=render_part(p,first,k)
actual=np.asarray(Image.open(BytesIO(published(rel_dst))).convert('RGBA'))
assert np.array_equal(old,actual) and k==1.0
assert np.array_equal(first[0][:,:2],np.eye(2))
left,top=map(int,first[0][:,2])
candidate=np.asarray(Image.open(base.parent/'evidence-20261120-ne222-cuff/left.png').convert('RGBA'))
assert np.array_equal(candidate[old[:,:,3]>=128],old[old[:,:,3]>=128])
ys,xs=np.where(np.any(candidate!=old,axis=2))
assert len(xs)==17
img=np.array(p)
old_img=img.copy()
regions=([138,18,-1],)
for yy,xx in zip(ys,xs):
    y,x=int(yy),int(xx)
    step=next(d for c,r,d in regions if abs(y-c)<r/2)
    img[top+y,left+x]=old_img[top+y,left+x-step]
assert np.array_equal(img[old_img[:,:,3]>=128],old_img[old_img[:,:,3]>=128])
fixed=Image.fromarray(img)
second=part_transform(fixed,cfg,joints,k)
assert np.array_equal(first[0],second[0]) and first[1:3]==second[1:3] and np.array_equal(first[3],second[3])
output=render_part(fixed,second,k)
assert np.array_equal(candidate,output)
for file,image in ((rel_source,fixed),(rel_dst,Image.fromarray(output))):
    dst=base/'draft'/file
    dst.parent.mkdir(parents=True,exist_ok=True)
    image.save(dst)
sha=lambda name:sha256(published(name)).hexdigest()
reports={name:{'previous_refined_sha256':sha(rel_source),'previous_native_sha256':sha(rel_dst),
    'changed_pixels':len(xs),'pivot':second[3].tolist(),'size':list(second[1:3]),
    'boxes':[]}}
for c,r,d in regions:
    match=[(int(x),int(y)) for x,y in zip(xs,ys) if abs(y-c)<r/2]
    reports[name]['boxes'].append([left+min(x for x,y in match),top+min(y for x,y in match),
       left+max(x for x,y in match)+1,top+max(y for x,y in match)+1])
(base/'material.json').write_text(json.dumps(reports,indent=2)+'\n')
(base/'draft-paths.json').write_text(json.dumps([rel_source,rel_dst],indent=2)+'\n')
print(reports)
