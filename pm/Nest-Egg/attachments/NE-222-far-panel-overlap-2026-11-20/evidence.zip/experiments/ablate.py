from io import BytesIO
from collections import Counter
from pathlib import Path
from subprocess import check_output
import json
import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent
replay=(base/'baseline.py').read_text(encoding='utf-8').split("render('whole'")[0]
exec(replay)
old=check_output(['git','show','HEAD:art/characters/rin/parts/armor_jacket_far.png'])
original=np.asarray(Image.open(BytesIO(old)).convert('RGBA'))
both=np.asarray(Image.open(base/'edge-1.png').convert('RGBA'))
for key,lower,upper in [('left',120,157),('right',79,106)]:
    fix=original.copy()
    fix[lower:upper]=both[lower:upper]
    path=base/f'{key}.png'
    Image.fromarray(fix).save(path)
    print(key,'pixels',np.count_nonzero(np.any(original!=fix,axis=2)),flush=True)
    tag=f'only-{key}'
    scene=base.parent/'evidence-20261120-ne222-waist/armor-visibility.tscn'
    render(tag,scene,['--out={out}','--chars=rin','--joints=coat_shoulder_back,coat_cuff_back','--frames=120',
        '--zooms=1,3.4','--diagnostic-whole-rig',f'--diagnostic-part-texture=armor_jacket_far:{path.as_posix()}'],True)
    run([sys.executable,str(shared/'tools/check_joint_frames.py'),str(base/tag)],cwd=shared,check=False)
