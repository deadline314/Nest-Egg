from pathlib import Path
import json
from collections import Counter
import numpy as np
from PIL import Image

base=Path(__file__).resolve().parent
from subprocess import run
import sys
root=Path.cwd()
prefix=(base/'baseline.py').read_text(encoding='utf-8').split("render('whole'")[0]
exec(prefix)
cases=[
  ('coat_shoulder_back',3.4,18,'run',(32,60)),
  ('coat_shoulder_back',3.4,15,'block',(40,55)),
  ('coat_shoulder_back',3.4,43,'dead',(25,29)),
  ('coat_cuff_back',1.0,18,'dead',(10,10)),
]
f='res://tools/rig_joint_audit.tscn'
for idx,(joint,zoom,frame,pose,point) in enumerate(cases,1):
    render(f'trace-{idx}',f,['--out={out}','--chars=rin',f'--joints={joint}',f'--frames={frame+1}',
        f'--zooms={zoom}',f'--trace-joint={joint}',f'--trace-frame={frame}'],True)
    doc=json.loads((base/f'trace-{idx}/frames.json').read_bytes())
    cell=next(r['cells'][0] for r in doc if r['pose']==pose)
    pix=np.array(point,float)+.5+64-cell['radius']
    print(pose,frame,joint,flush=True)
    for entry in cell['geometry_sample']:
        part=entry['part']
        mat=np.array(entry['to_cell'])
        local=np.linalg.solve(mat[:,:2],pix-mat[:,2])
        if 'rect_origin' in entry:
            uv=local-np.array(entry['rect_origin'])
        else:
            poly=np.asarray(entry['vertices'])
            coords=np.asarray(entry['uv'])
            uv=None
            for tri in entry['triangles']:
                a,b,c=poly[tri[:3]]
                weights=np.linalg.solve(np.array((b-a,c-a)).T,local-a)
                if min(weights[0],weights[1],1-weights.sum())>=-.0001:
                    uv=coords[tri[0]]*(1-weights.sum())+coords[tri[1]]*weights[0]+coords[tri[2]]*weights[1]
                    break
        src=root/entry['texture'].removeprefix('res://')
        if uv is None or not src.is_file():
            continue
        alpha=np.array(Image.open(src).convert('RGBA'))[:,:,3]
        xy=np.round(uv-.5).astype(int)
        win=alpha[max(0,xy[1]-3):xy[1]+4,max(0,xy[0]-3):xy[0]+4] if min(xy)>=-3 else np.array([])
        if win.size:
            print(part,entry['texture'],'uv',np.round(uv,2).tolist(),'alpha',dict(sorted(Counter(win.flat).items())),flush=True)
