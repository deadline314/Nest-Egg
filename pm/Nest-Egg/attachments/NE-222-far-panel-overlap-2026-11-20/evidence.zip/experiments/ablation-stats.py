from pathlib import Path
from collections import Counter
import json

base=Path(__file__).resolve().parent
def failures(folder):
    data=json.loads((base/folder/'report.json').read_bytes())['failures']
    return {(r['joint'],r['pose'],r['zoom'],r['facing'],r['frame']):r for r in data
            if r['enclosed_pixels'] or r['loose_pieces'] or r['center_alpha']<128}

original=failures('whole')
result={}
for folder in ('candidate-whole','only-left','only-right'):
    if not (base/folder/'report.json').exists():
        continue
    variant=failures(folder)
    old=set(original)-set(variant)
    new=set(variant)-set(original)
    increased=[key for key in set(variant)&set(original) if variant[key]['enclosed_pixels']>original[key]['enclosed_pixels']]
    report={'baseline':len(original),'candidate':len(variant),'fixed':len(old),'new':len(new),'increased':len(increased),
        'fixed_by_pose':dict(Counter(key[1] for key in old)), 'new_by_pose':dict(Counter(key[1] for key in new)),
        'first_new':sorted(new)[:3]}
    result[folder]=report
(base/'ablation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
