from pathlib import Path
from hashlib import sha256
from subprocess import run
from shutil import copyfile
import json
import os
import sys

base = Path(__file__).resolve().parent
shared = base.parent/'ne218-baseline-20261117'
root=Path.cwd()
python = Path(sys.executable)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def render(case, scene, args, fixed):
    out=base/case
    out.mkdir(exist_ok=False)
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        var = out/'profile'/key
        var.mkdir(parents=True)
        env[key]=str(var)
    command = [str(python),str(shared/'tools/comfyui/gpu_lock.py'),'--',engine,
               '--path',str(shared),'--resolution','1280x720','--position','10,90',
               '--rendering-method','forward_plus','--rendering-driver','vulkan']
    if fixed:
        command.extend(('--fixed-fps','60'))
    command.append(str(scene))
    command.extend(('--',*[a.replace('{out}',out.as_posix()) for a in args]))
    (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=650)
    (out/'exit.txt').write_text(str(result.returncode)+'\n',encoding='utf-8')
    raw=(out/'raw.log').read_text(encoding='utf-8')
    print(case,result.returncode,len(raw),flush=True)
    assert result.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw
    return raw







import json
from PIL import Image
import numpy as np

picture=root/'art/characters/rin/parts/armor_jacket_far.png'
art=np.array(Image.open(picture).convert('RGBA'))
for count in (0,1,2):
    fixed=art.copy()
    for center,radius,span,direction in ((138,18,range(2,7),-1),(92,13,range(45,59),1)):
        for y in range(center-radius,center+radius+1):
            step=round(count * max(0,1-abs(y-center)/radius))*direction
            for x in span:
                if art[y,x,3]<128 and art[y,x-step,3]>art[y,x,3]:
                    fixed[y,x]=art[y,x-step]
    img=base/f'edge-{count}.png'
    Image.fromarray(fixed).save(img)
    print('variant',count,'pixels',np.count_nonzero(np.any(fixed!=art,axis=2)),flush=True)
    key=f'variant-{count}'
    render(key,'res://tools/rig_joint_audit.tscn',
        ['--out={out}','--chars=rin','--joints=coat_shoulder_back','--frames=80','--zooms=3.4',
        f'--diagnostic-part-texture=armor_jacket_far:{img.as_posix()}'],True)
    run([sys.executable,str(shared/'tools/check_joint_frames.py'),str(base/key)],cwd=shared,check=False)
