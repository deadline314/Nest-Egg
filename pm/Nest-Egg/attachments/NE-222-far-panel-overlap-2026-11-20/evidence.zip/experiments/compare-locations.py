from pathlib import Path
import json
import numpy as np
from PIL import Image
from scipy import ndimage
from collections import Counter

base=Path(__file__).resolve().parent
pri=base.parent/'evidence-20261120-ne222-waist'/'release-paired'
def get_frames(folder):
    return {(g['pose'],g['zoom'],c['joint'],c['facing']):c
            for g in json.loads((folder/'frames.json').read_bytes()) for c in g['cells']}
def band(path,entry,radius):
    x,y,w,h=entry['rect']
    box=(x+w//2-radius,y+h//2-radius,x+w//2+radius,y+h//2+radius)
    return np.array(Image.open(path).convert('RGBA').crop(box))[:,:,3]
def enclosed(solid):
    return ndimage.binary_fill_holes(solid,structure=np.ones((3,3))) & ~solid

whole=base/'whole'
indices=get_frames(whole)
doc=json.loads((pri/'report.json').read_bytes())
rows=[r for r in doc['failures'] if r['joint'] in ('coat_shoulder_back','coat_cuff_back')
    and (r['center_alpha']<128 or r['enclosed_pixels'] or r['loose_pieces'])]
cases=[]
for r in rows:
    config=indices[(r['pose'],r['zoom'],r['joint'],r['facing'])]
    radius=r['radius']
    orig=band(pri/r['file'],r,radius)
    after=band(whole/r['file'],config,radius)
    missing=enclosed(orig>=128)
    if orig[radius,radius]<128:
        missing[radius,radius]=True
    still=enclosed(after>=128)
    for y,x in zip(*np.nonzero(missing)):
        cases.append(dict(pose=r['pose'],joint=r['joint'],frame=r['frame'],zoom=r['zoom'],
                          point=[int(x),int(y)],facing=r['facing'],paired=int(orig[y,x]),
                          visible=int(after[y,x]),type='covered' if after[y,x]>=128 else 'enclosed' if still[y,x] else 'open'))
print(Counter((r['joint'],r['pose'],r['type']) for r in cases))
print(Counter((r['joint'],tuple(r['point']),r['type']) for r in cases))
(base/'locations.json').write_text(json.dumps(cases,indent=2)+'\n')
