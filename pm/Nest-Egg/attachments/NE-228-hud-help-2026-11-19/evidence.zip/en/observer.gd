extends Node

const CAPTURE := preload("res://tools/viewport_capture.gd")
const LEVEL := preload("res://data/levels/ch3_pump.tres")
var _out := ""
var _language := "zh"
var _scale_setting := 1.0
var _gamepad := false
var _fails: Array[String] = []
var _checks := 0

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--language="):
			_language = arg.trim_prefix("--language=")
		elif arg == "--large":
			_scale_setting = 1.2
		elif arg == "--gamepad":
			_gamepad = true
	_run.call_deferred()

func _assert(case: bool, name: String) -> void:
	_checks += 1
	if not case:
		_fails.append(name)

func _frames(count: int) -> void:
	for i in count:
		await get_tree().process_frame

func _mouse(pos: Vector2) -> void:
	var motion := InputEventMouseMotion.new()
	motion.position = pos
	motion.global_position = pos
	get_viewport().push_input(motion, true)

func _tooltip(control: Control) -> Window:
	for node in control.get_children(true):
		if node is Window and node.visible and not node.is_queued_for_deletion():
			return node
	return null

func _run() -> void:
	Story.set_language(_language)
	TranslationServer.set_locale(_language)
	Story.auto_skip = true
	Settings.set_ui_text_scale(_scale_setting)
	GameState.start_new_run(GameState.difficulties[2])
	GameState.set_flag(&"ch3_departure_done")
	GameState.set_flag(&"ch3_interlock_seen")
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(LEVEL)
	add_child(level)
	await _frames(12)
	var hud := level.hud
	InputBindings._set_device(_gamepad, -1)
	await _frames(3)
	var viewport := get_viewport().get_visible_rect()
	var lives := hud._lives_label
	var card := hud._controls_card
	var localized := {"zh": ["開啟操作說明", "殘機 ×3"], "ja": ["操作ガイド", "残機 ×3"], "en": ["Controls", "Lives ×3"]}
	_assert(lives.visible and lives.text == localized[_language][1], "the actual HUD shows localized remaining lives")
	_assert(card.visible and hud._controls.text == localized[_language][0], "the actual opening HUD card is localized")
	_assert(viewport.encloses(card.get_global_rect()) and viewport.encloses(lives.get_global_rect()) and not lives.get_global_rect().intersects(card.get_global_rect()), "the localized fields fit their screen")
	var cap := hud._hint_caps[0].get_child(0) as Label
	var keycap := cap.text
	_assert(keycap == InputBindings.primary_label(&"pause"), "the default card keeps the active control binding")
	await RenderingServer.frame_post_draw
	CAPTURE.image(get_viewport()).save_png(_out.path_join("hud-controls.png"))
	_mouse(Vector2(-40,-40))
	await _frames(3)
	_mouse(lives.get_global_rect().get_center())
	for i in 110:
		if _tooltip(lives) != null:
			break
		await _frames(1)
	_assert(_tooltip(lives) != null, "actual pointer input creates the lives tooltip")
	if _tooltip(lives) != null:
		await RenderingServer.frame_post_draw
		CAPTURE.image(get_viewport()).save_png(_out.path_join("hud-lives-hover.png"))
	var help_text := lives.tooltip_text
	level._pause_menu.open()
	await _frames(2)
	_assert(_tooltip(lives) == null and hud.hover_guard.blocked and not card.visible, "pause hides the background tooltip and card")
	level._pause_menu.close()
	await _frames(2)
	_assert(not hud.hover_guard.blocked and lives.tooltip_text == help_text, "resuming leaves the original tooltip usable")
	var output := {"locale": _language, "viewport": str(viewport), "scale": _scale_setting, "gamepad_labels": _gamepad,
		"adapter": RenderingServer.get_video_adapter_name(), "prompt": hud._controls.text, "lives": lives.text,
		"tooltip": help_text, "checks": _checks, "failures": _fails, "keycap": keycap}
	FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify(output, "\t"))
	print(output)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _fails.is_empty() else 1)
