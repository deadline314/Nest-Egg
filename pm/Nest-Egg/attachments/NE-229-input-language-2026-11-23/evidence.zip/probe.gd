extends Node

const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://input-language-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Story.set_language("en")
	var settings := SettingsScreen.new()
	add_child(settings)
	await _frames(9)
	settings._tabs.current_tab = 1
	await _frames(7)
	_check(settings._tabs.get_tab_title(1) == "Bindings" and settings._tabs.get_tab_title(0) == "Audio" and
		settings._tabs.get_tab_title(2) == "Display", "English uses the localized settings tab captions")
	_check(settings.find_children("*", "Label", true, false).any(func(label: Label) -> bool: return label.text == "Settings") and
		settings.find_children("*", "Button", true, false).any(func(button: Button) -> bool: return button.text == "Back"),
		"English Settings page has the localized heading and Back action")
	var jump := settings._binding_buttons["jump:0"] as Button
	jump.grab_focus()
	await _key(KEY_ENTER)
	_check(settings._capturing and settings._capture_action == &"jump", "Enter opens actual keyboard rebinding")
	await _key(KEY_K)
	_check(InputBindings.get_code(&"jump", 0) == KEY_K and jump.text == InputBindings.code_label(KEY_K), "pressing K updates the real rebound Jump key")
	_check(settings._hold_rule_labels.all(func(label: Label) -> bool: return label.text.begins_with("Hold K")),
		"both settings pages show the real rebound key in localized English")
	settings._tabs.current_tab = 3
	await _frames(7)
	await _button(JOY_BUTTON_DPAD_DOWN)
	_check(settings._tabs.get_tab_title(3) == "Controller" and settings._controller_invert.text == "Invert vertical aim",
		"controller options retain their real controls and English labels")
	_check(settings._hold_rule_labels[1].text.begins_with("Hold " + InputBindings.joy_label(&"jump")),
		"controller mode swaps the English hold guide to the current gamepad label")
	var strength := settings._controller_sliders["vibration_strength"] as HSlider
	strength.grab_focus()
	await _frames(5)
	_check(settings._status.text == strength.tooltip_text and strength.tooltip_text.begins_with("Adjust the rumble"),
		"the controller vibration focus hint matches the English tooltip")
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join("controller.png")) == OK, "rendered the actual controller settings")
	var scroll := settings._tabs.get_tab_control(3) as ScrollContainer
	var viewport_focus := get_viewport().gui_get_focus_owner()
	var before_scroll := scroll.scroll_vertical
	var stick := InputEventJoypadMotion.new()
	stick.axis = JOY_AXIS_RIGHT_Y
	stick.axis_value = 1.0
	Input.parse_input_event(stick)
	await _frames(5)
	stick = stick.duplicate()
	stick.axis_value = 0.0
	Input.parse_input_event(stick)
	await _frames(5)
	_check(scroll.scroll_vertical > before_scroll and get_viewport().gui_get_focus_owner() == viewport_focus,
		"right stick reads the rest of the controls without taking focus")
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join("rules.png")) == OK, "captured the remainder of the localized guide")
	await _key(KEY_PAGEUP)
	_check(scroll.scroll_vertical == before_scroll and get_viewport().gui_get_focus_owner() == viewport_focus,
		"Page Up returns to the controller controls with the same focus")
	settings._begin_capture(&"jump", SettingsScreen.JOY_SLOT)
	_check(settings._status.text.begins_with("Press a controller button.") and
		settings._status.text.contains(InputBindings.joy_label(&"ui_cancel")) and settings._status.text.contains("0.6"),
		"controller rebinding names the cancel binding and its hold time")
	await _key(KEY_ESCAPE)
	_check(not settings._capturing, "Escape cancels the original controller rebinding")
	settings.queue_free()
	await _frames(4)
	Story.set_language("ja")
	settings = SettingsScreen.new()
	add_child(settings)
	await _frames(8)
	_check(settings._tabs.get_tab_title(3) == "コントローラー" and settings._controller_invert.text == "上下の照準反転",
		"Japanese controller settings show their original actions in the selected language")
	_check(settings._hold_rule_labels[0].text.begins_with("K を長く"), "Japanese help reads the same rebound key")
	settings._begin_capture(&"jump", SettingsScreen.JOY_SLOT)
	_check(settings._status.text.begins_with("新しいボタン"), "Japanese rebind prompt is localized")
	await _key(KEY_ESCAPE)
	settings.queue_free()
	await _frames(5)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))


func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _press(event)


func _button(key: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = key
	await _press(event)


func _press(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(6)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)

