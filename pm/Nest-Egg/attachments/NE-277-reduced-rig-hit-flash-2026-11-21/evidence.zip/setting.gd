extends Node

func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	var output := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			output = arg.trim_prefix("--out=")
	if not output.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	Settings.use_storage("user://ne277_flash_hint.cfg")
	Settings.set_reduce_flashes(false)
	var screen := SettingsScreen.new()
	var canvas := CanvasLayer.new()
	add_child(canvas)
	canvas.add_child(screen)
	screen._tabs.current_tab = 2
	await get_tree().process_frame
	await get_tree().process_frame
	var toggle := screen._reduce_flashes
	var scroll := screen._tabs.get_current_tab_control() as ScrollContainer
	toggle.grab_focus()
	scroll.ensure_control_visible(toggle)
	var select := InputEventAction.new()
	select.action = &"ui_accept"
	select.pressed = true
	Input.parse_input_event(select)
	await get_tree().process_frame
	select = InputEventAction.new()
	select.action = &"ui_accept"
	Input.parse_input_event(select)
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var expected := "降低命中、爆炸與閃電的亮度。閃電只閃一次。"
	var clip := scroll.get_global_transform_with_canvas() * Rect2(Vector2.ZERO, scroll.size)
	var button := toggle.get_global_transform_with_canvas() * Rect2(Vector2.ZERO, toggle.size)
	var hint := screen._status.get_global_transform_with_canvas() * Rect2(Vector2.ZERO, screen._status.size)
	var checks := [toggle.has_focus(), toggle.is_visible_in_tree(), clip.encloses(button),
		get_viewport().get_visible_rect().encloses(hint), toggle.button_pressed,
		Settings.get_reduce_flashes(), toggle.tooltip_text == expected, screen._status.text == expected]
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	checks.append(image.save_png(output.path_join("flash-setting.png")) == OK)
	print("SETTINGS_FLASH ", JSON.stringify({"checks": checks, "hint": screen._status.text,
		"gpu": RenderingServer.get_video_adapter_name(), "hdr": get_viewport().use_hdr_2d}))
	screen.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(checks.has(false)))