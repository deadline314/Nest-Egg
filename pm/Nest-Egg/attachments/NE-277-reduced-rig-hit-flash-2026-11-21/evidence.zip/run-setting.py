from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
out = base / sys.argv[1]
out.mkdir()
env = os.environ.copy()
for name in ("APPDATA", "LOCALAPPDATA", "XDG_DATA_HOME", "XDG_CONFIG_HOME", "TEMP", "TMP", "TMPDIR"):
    path = out / "profile" / name
    path.mkdir(parents=True)
    env[name] = str(path)
paths = ["ui/settings_screen.gd", "autoload/settings.gd", "tools/viewport_capture.gd"]
source = {p: sha256((game/p).read_bytes()).hexdigest() for p in paths}
command = [sys.executable, "-B", str(game/"tools/comfyui/gpu_lock.py"), "--",
           "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(game),
           "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--audio-driver","Dummy",
           "--resolution", "1280x720", "--quit-after", "500", str(base/"setting.tscn"), "--", f"--out={out}"]
(out/"command.json").write_text(json.dumps({"argv": command, "source_sha256": source}, indent=2)+"\n",encoding="utf-8")
with (out/"engine.log").open("wb") as log:
    proc = subprocess.run(command,cwd=game,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
raw = (out/"engine.log").read_text(encoding="utf-8",errors="replace")
print(raw)
assert proc.returncode == 0 and not re.search(r"^(?:SCRIPT )?ERROR:|leaked at exit",raw,re.M)
line, = re.findall(r"^SETTINGS_FLASH (.*)$",raw,re.M)
row = json.loads(line)
assert len(row["checks"]) == 9 and all(row["checks"])
assert row["hdr"] and "9070 XT" in row["gpu"] and (out/"flash-setting.png").is_file()
assert all(sha256((game/path).read_bytes()).hexdigest() == value for path, value in source.items())
(out/"result.json").write_text(json.dumps(row,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")