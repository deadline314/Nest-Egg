from hashlib import sha256
from pathlib import Path
from PIL import Image
import json
import math

base = Path(__file__).resolve().parent
modes = ["normal", "reduced"]

def load(label):
    folder = base / label
    sheet = json.loads((folder / "contact-result.json").read_bytes())
    assert "9070 XT" in sheet["adapter"] and sheet["renderer"] == "forward_plus"
    assert sheet["failures"] == [] and sheet["checks"] == 297
    return folder, {row["name"]: row for row in sheet["rows"]}

def samples(row):
    frames = {s["tick"]: s for s in row["body_flash"]}
    return [frames[hit["tick"]] for hit in row["contact_hits"]]

def clip_pixels(folder, row, sample):
    with Image.open(folder / row["contact_first_image"]) as image:
        assert image.size == (1280, 720)
        x, y = (round(n * 2) for n in sample["torso"])
        return sum(min(r, g, b) >= 238 for r, g, b in image.crop((x - 22, y - 25, x + 23, y + 57)).convert("RGB").get_flattened_data())

report = {}
for mode in modes:
    old_folder, stock = load(f"stock-{mode}-hdr")
    new_folder, new = load(f"candidate-{mode}-hdr")
    assert stock.keys() == new.keys() and len(new) == 10
    reduced = mode == "reduced"
    compare = []
    for move, old in stock.items():
        row = new[move]
        assert old["reduced"] == row["reduced"] == reduced
        assert old["phases"] == row["phases"]
        assert len(old["contact_hits"]) == len(row["contact_hits"])
        hit_scalars = ("amount", "weak", "target_hp", "charged", "window", "visual_progress", "part", "phase")
        for before, after in zip(old["contact_hits"], row["contact_hits"], strict=True):
            assert all(before[k] == after[k] for k in hit_scalars), (move, before, after)
        prior = samples(old)
        actual = samples(row)
        for before, after in zip(prior, actual, strict=True):
            assert before["light"] in [1.20000004768372, 1.39999997615814], (move, before)
            scale = 0.25 if reduced else 1.0
            assert math.isclose(after["light"], 1 + (before["light"] - 1) * scale, abs_tol=1e-6), (move, before, after)
            assert before["rig_flash_left"] == after["rig_flash_left"]
        # Pose sampling is relative to each input case; absolute physics ticks can vary at startup.
        base_before = prior[0]["tick"]
        base_after = actual[0]["tick"]
        assert [p["tick"]-base_before for p in prior] == [p["tick"]-base_after for p in actual]
        assert any(sample["light"] == 1.0 for sample in old["body_flash"])
        assert any(sample["light"] == 1.0 for sample in row["body_flash"])
        assert old["freeze"][0]["rin"] and old["freeze"][0]["enemy"] and row["freeze"][0]["rin"] and row["freeze"][0]["enemy"]
        compare.append({"case": move, "body_modulation": [[p["light"], q["light"]] for p,q in zip(prior, actual, strict=True)],
                        "seconds": [[p["rig_flash_left"], q["rig_flash_left"]] for p,q in zip(prior, actual, strict=True)],
                        "near_white_first_body": [clip_pixels(old_folder,old,prior[0]),clip_pixels(new_folder,row,actual[0])]})
    using = [sha256((folder/"contact-result.json").read_bytes()).hexdigest() for folder in (old_folder,new_folder)]
    report[mode] = {"cases": compare,"source":using,"actual_hits":sum(len(row["body_modulation"]) for row in compare),
                    "total_body_near_white": [sum(row["near_white_first_body"][index] for row in compare) for index in range(2)]}
assert report["reduced"]["total_body_near_white"][1] < report["reduced"]["total_body_near_white"][0]
assert all(mode["actual_hits"] == 30 for mode in report.values())
(base/"body-comparison.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps({name:{k:v for k,v in values.items() if k!="cases"} for name,values in report.items()}))