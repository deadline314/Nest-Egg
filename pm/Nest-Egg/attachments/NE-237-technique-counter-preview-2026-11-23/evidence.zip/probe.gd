extends "res://tests/smoke_test.gd"

const PAWNSHOP := preload("res://data/levels/ch1_pawnshop.tres")
const WEAPONS := ["melee_dagger","melee_blade","melee_maul","melee_glaive","melee_whip"]
const Capture := preload("res://tools/viewport_capture.gd")
var _proof := ""


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	var args := OS.get_cmdline_user_args()
	if args.size() == 1:
		_proof = args[0]
	Settings.use_storage("user://technique_preview_proof.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	Story.set_language("zh")
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	Progression.add_credits(1000)
	for flag in [&"ch1_prologue_done", &"ch1_dinner_done", &"ch1_heard_brief"]:
		GameState.set_flag(flag)
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	var level := Level.new()
	level.configure(PAWNSHOP)
	add_child(level)
	await _frames(12)
	var station: ShopStation
	for child in level.find_children("*", "Area2D", true, false):
		if child is ShopStation:
			station = child
			break
	_check(station != null, "the actual Chapter 1 pawnshop opens its mods counter")
	if station != null:
		level.player.global_position = station.global_position
		await _frames(10)
		for id in WEAPONS:
			await _technique(level, station, id)
	level.queue_free()
	await _frames(5)
	await _finish()


func _technique(level: Level, station: ShopStation, id: String) -> void:
	var weapon := load("res://data/weapons/melee/%s.tres" % id) as WeaponData
	var moves := MeleeData.set_of(weapon)
	var base := moves.combo()
	var extra := moves.combo(true)
	var upgrade := Progression.find_upgrade(moves.extension_upgrade())
	_check(upgrade != null and extra.size() == base.size() + 1, id + " actor data has its real distinct paid tail")
	if upgrade == null:
		return
	level.player.loadout.reset(weapon)
	await _tap(KEY_E)
	var screen := station._screen
	_check(screen != null and screen.is_open(), id + " opens the real counter with E")
	if screen == null or not screen.is_open():
		return
	for attempt in 3:
		if screen._pages[screen._current] is UpgradesPage:
			break
		await _tap(KEY_E)
	var page := screen._pages[screen._current] as UpgradesPage
	_check(page != null and page._entries.size() > 1, id + " shows the mods page next to arm shield")
	if page == null or page._entries.is_empty():
		screen.close()
		return
	var item_id := StringName("%s:%s" % [id, upgrade.id])
	var index := page._entries.find_custom(func(item: InventoryEntry) -> bool: return item.id == item_id)
	if index < 0:
		_check(false, id + " is listed as its own purchasable tail")
		screen.close()
		return
	for step in page._entries.size():
		if page._selected == index:
			break
		await _tap(KEY_DOWN)
	var offer := page._entries[page._selected]
	_check(offer.action_enabled and offer.id == item_id, id + " navigation selects its purchasable tail")
	var dps := ["%.1f" % moves.damage_per_second(base),"%.1f" % moves.damage_per_second(extra)]
	var reach := [str(roundi(moves.max_range(base))),str(roundi(moves.max_range(extra)))]
	_check(_line(offer, 1).ends_with("%d → %d" % [base.size(),extra.size()]), id + " offer reveals the actual extra move")
	_check(_line(offer, 2).ends_with(_state(dps)), id + " offer shows actual before and after damage")
	_check(_line(offer, 3).ends_with(_state(reach)), id + " offer shows range without arrows for equal values")
	if id == "melee_blade" and _proof.is_absolute_path() and DisplayServer.get_name() != "headless":
		for i in 5:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_proof) == OK, "real mod screen capture")
	var money := Progression.credits
	await _tap(KEY_ENTER)
	_check(Progression.credits == money - upgrade.cost and Progression.has_upgrade(weapon,upgrade.id),
		id + " buys exactly one upgrade for the original price")
	var owned := page._entries[page._selected]
	_check(not owned.action_enabled and owned.dimmed, id + " installed entry stays disabled")
	_check(_line(owned, 1).ends_with(str(extra.size()))
		and _line(owned,2).ends_with(dps[1])
		and _line(owned,3).ends_with(reach[1])
		and not " ".join(owned.detail_stats).contains("→"), id + " installed panel shows the playable extended chain")
	await _tap(KEY_ESCAPE)
	_check(not screen.is_open() and not get_tree().paused, id + " normal cancel returns to gameplay")


func _line(entry: InventoryEntry, index: int) -> String:
	return entry.detail_stats[index] if entry.detail_stats.size() > index else ""


func _state(pair: Array) -> String:
	return pair[0] if pair[0] == pair[1] else "%s → %s" % pair


func _tap(code: int) -> void:
	var key := InputEventKey.new()
	key.keycode = code
	key.physical_keycode = code
	key.pressed = true
	Input.parse_input_event(key)
	Input.flush_buffered_events()
	await get_tree().process_frame
	await get_tree().physics_frame
	await get_tree().process_frame
	key.pressed = false
	Input.parse_input_event(key)
	Input.flush_buffered_events()
	await get_tree().process_frame

