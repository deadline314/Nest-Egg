from collections import Counter
from functools import lru_cache
from pathlib import Path
from PIL import Image
from scipy import ndimage
import json,numpy as np

base=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
stock=base/"whole"
range_poses={"sit","sit_listen","sit_talk"}
target={"neck","waist","hip_front","hip_back","knee_front","knee_back","elbow_front","elbow_back","wrist_front","wrist_back"}
cases=[r for r in read(stock/"report.json")["failures"] if r["char"]=="old_k" and r["pose"] in range_poses and
       r["joint"] in target and r["enclosed_pixels"]>0 and not r["loose_pieces"] and r["center_alpha"]>=128]
def key(r):
    return r["pose"],r["zoom"],r["frame"],r["joint"],r["facing"]

def cells(folder):
    return {(g["pose"],g["zoom"],c["joint"],c["facing"]):c for g in read(folder/"frames.json")
        for c in g["cells"] if c["char"]=="old_k"}

@lru_cache(maxsize=8)
def alpha(folder,file):
    return np.asarray(Image.open(folder/file).convert("RGBA"))[:,:,3]

def crop(data,row):
    x,y,w,h=row["rect"]
    radius=row["radius"]
    return data[y+h//2-radius:y+h//2+radius,x+w//2-radius:x+w//2+radius]

def closed(mask):
    return ndimage.binary_fill_holes(mask,structure=np.ones((3,3),bool))&~mask

current_cells={}
for pose in range_poses:
    folder=base/f"lap-{pose}"
    log=(folder/"raw.log").read_text(encoding="utf-8-sig")
    assert "Forward+" in log and "RX 9070 XT" in log and "ERROR:" not in log
    assert read(folder/"report.json")["samples"]==13440
    current_cells.update(cells(folder))
neighbor={mode:cells(base/mode) for mode in ("dressed","isolated")}
proof=[]
for row in sorted(cases,key=lambda r:r["file"]):
    timeline=(row["pose"],row["zoom"],row["joint"],row["facing"])
    both=current_cells[timeline]
    assert row["rect"]==both["rect"] and row["radius"]==both["radius"]
    before=crop(alpha(stock,row["file"]),row)
    control=crop(alpha(base/f"lap-{row['pose']}",row["file"]),both)
    solid=before>=128
    old_hole=closed(solid)
    open_now=not np.any(old_hole&((control>=128)|closed(control>=128)))
    open_neighbors={}
    for mode,geometry in neighbor.items():
        cell=geometry[timeline]
        pair=crop(alpha(base/mode,row["file"]),cell)>=128
        open_neighbors[mode]=not np.any(old_hole&(pair|closed(pair)))
    assert int(old_hole.sum())==row["enclosed_pixels"]
    proof.append({"case":key(row),"file":row["file"],"pixels":int(old_hole.sum()),
                  "opened_without_forearms_and_hands":open_now,"open_neighbors":open_neighbors})
match=[r for r in proof if r["opened_without_forearms_and_hands"] and all(r["open_neighbors"].values())]
failure=[r for r in proof if r not in match]
summary={"original_cases":len(proof),"matched":len(match),
    "counts":dict(Counter(r["case"][0]+"/"+r["case"][3] for r in match)),
    "pixels_opened":sum(r["pixels"] for r in match),"cases":proof}
(base/"old-k-lap-proof.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
print("OLD K LAP",summary["original_cases"],summary["matched"],summary["pixels_opened"],summary["counts"])
print("REMAINDER",dict(Counter(r["case"][0]+"/"+r["case"][3] for r in failure)))
