extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_pawnshop.tres")
var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://old_k_probe.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Settings.set_reduce_ui_motion(true)
	for direction: int in [-1, 1]:
		for zoom: float in [LevelCamera.base_zoom(), 3.4]:
			if not await _observe(direction, zoom):
				push_error("Original Old K interaction failed at %d / %.2f" % [direction, zoom])
				get_tree().quit(1)
				return
	var file := FileAccess.open(_out.path_join("street.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"adapter": RenderingServer.get_video_adapter_name(),
		"renderer": RenderingServer.get_current_rendering_method(), "rows": _rows}, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)


func _observe(direction: int, zoom: float) -> bool:
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = false
	for id in Story.scene_ids():
		if id != &"ch1_t_oldk_1":
			Story._seen[StringName(id)] = true
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	for tick in 8:
		await get_tree().physics_frame
	var npc: NpcActor
	for actor in level._entities.get_children():
		if actor is NpcActor and actor.data.id == &"ch1_old_k":
			npc = actor
		elif actor is Enemy:
			actor.process_mode = Node.PROCESS_MODE_DISABLED
	if npc == null or npc._actor == null or npc._actor.rig == null:
		return false
	var player := level.player
	player.global_position = npc.global_position + Vector2(34.0 * direction, 0.0)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	level._lighting._lightning_gap = 1.0e9
	for node in level.find_children("*", "", true, false):
		if node is ChapterCard:
			node.queue_free()
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.limit_left = -100000
	camera.limit_right = 100000
	camera.offset = Vector2.ZERO
	camera.zoom = Vector2.ONE * zoom
	camera.global_position = npc.global_position + Vector2(0, -31)
	camera.reset_smoothing()
	camera.force_update_scroll()
	var label := "%s_%d" % ["left" if direction < 0 else "right", roundi(zoom * 100)]
	for tick in 7:
		await get_tree().physics_frame
	if not await _capture(npc, camera, label + "_work"):
		return false
	var press := InputEventKey.new()
	press.keycode = KEY_E
	press.physical_keycode = KEY_E
	press.pressed = true
	Input.parse_input_event(press)
	Input.flush_buffered_events()
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	Input.parse_input_event(release)
	Input.flush_buffered_events()
	for tick in 220:
		if npc._talking and Story._layer._text.visible_ratio >= 1.0:
			break
		await get_tree().process_frame
	if not npc._talking or not Story.is_cinematic_active() or Story._layer._text.text.is_empty():
		return false
	if not await _capture(npc, camera, label + "_talk"):
		return false
	for tick in 340:
		if not Story.is_cinematic_active():
			break
		if Story._layer._text.visible_ratio >= 1.0:
			Story._layer.advance()
		await get_tree().process_frame
	if Story.is_cinematic_active():
		return false
	for tick in 8:
		await get_tree().process_frame
	if npc._talking or not await _capture(npc, camera, label + "_finished"):
		return false
	level.queue_free()
	for tick in 5:
		await get_tree().process_frame
	return true


func _capture(npc: NpcActor, camera: LevelCamera, name: String) -> bool:
	await RenderingServer.frame_post_draw
	var state := npc._actor.rig.animator as NpcAnimator
	var head := camera.get_canvas_transform() * npc._actor.rig.bone(&"head").global_position
	_rows.append({"key": name, "head": [head.x, head.y], "pose": str(state._pose_now),
		"loop": str(state._loop_name), "talking": npc._talking,
		"dialogue": Story._layer._text.text if npc._talking else "", "count": npc.talk_count})
	
	if name == "right_340_talk":
		return Capture.image(get_viewport()).save_png(_out.path_join("old-k-talk.png")) == OK
	return true
