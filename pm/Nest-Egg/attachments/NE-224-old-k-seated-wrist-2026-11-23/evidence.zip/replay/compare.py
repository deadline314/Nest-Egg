from hashlib import sha256
from pathlib import Path
from PIL import Image, ImageDraw
from zipfile import ZIP_DEFLATED, ZipFile
import json
import re
import shutil

root = Path.cwd()
base = Path(__file__).resolve().parent
audit = base.with_name("evidence-20261122-ne224-shop-npcs")
pm = root/"pm/Nest-Egg"

def read(file):
    return file.read_text(encoding="utf-8-sig")

def load(file):
    return json.loads(file.read_bytes())

def sha(file):
    return sha256(file.read_bytes()).hexdigest()

def key(row):
    return tuple(row[field] for field in ("pose","zoom","frame","joint","facing"))

def failures(report):
    return [row for row in report["failures"] if row["char"]=="old_k"]

def hard(rows):
    return {key(row) for row in rows if row["enclosed_pixels"] or row["loose_pieces"] or row["center_alpha"]<128}

scope = load(audit/"old-k-lap-proof.json")
matched={(r["case"][0], r["case"][1], r["case"][2], r["case"][3], r["case"][4])
         for r in scope["cases"] if r["opened_without_forearms_and_hands"] and all(r["open_neighbors"].values())}
assert len(matched)==4636 and scope["pixels_opened"]==95022
trace = load(base/"wrist-trace.json")
target={("sit_talk",3.4,row["frame"],"wrist_front",row["facing"]) for row in trace}
assert len(target)==44 and not (matched & target)

comparison = {}
natural_areas = {tuple(row["case"][:5]):row["pixels"] for row in scope["cases"] if tuple(row["case"][:5]) in matched}
natural_remaining = 0
for mode in ("whole","dressed","isolated"):
    installed = base/f"installed-{mode}"
    before = load(audit/mode/"report.json")
    after = load(installed/"report.json")
    assert before["samples"] == 67200 and after["samples"] == 33600
    log = read(installed/"raw.log")
    assert "Forward+" in log and "RX 9070 XT" in log and "ERROR:" not in log
    frame_data = load(installed/"frames.json")
    assert len(frame_data)==10 and all(len(group["samples"])==120 and len(group["cells"])==28 for group in frame_data)
    assert all(c["alpha_only_rgb"] and not c["diagnostic_part_texture"] for g in frame_data for c in g["cells"])
    a,b=hard(failures(before)),hard(failures(after))
    assert target <= a and not target & b
    assert b <= a, (mode, sorted(b-a)[:16])
    old_metrics = {key(row):row for row in failures(before)}
    for row in failures(after):
        old = old_metrics.get(key(row), {})
        assert row["enclosed_pixels"] <= old.get("enclosed_pixels",0)
        assert row["loose_pieces"] <= old.get("loose_pieces",0)
        assert row["center_alpha"] >= 128 or old.get("center_alpha",255) < 128
    if mode=="whole":
        assert matched <= a
        deposited = {key(row):row["enclosed_pixels"] for row in failures(after)}
        assert all(0 <= count-deposited.get(case,0) <= 2 for case,count in natural_areas.items())
        assert all(deposited.get(case,0)>0 for case,count in natural_areas.items() if count>1)
        natural_remaining = sum(deposited.get(case,0) for case in matched)
        assert natural_remaining == 94087
    before_rows = {key(row) for row in failures(before)}
    after_rows = {key(row) for row in failures(after)}
    comparison[mode] = {"samples":after["samples"],"hard_before":len(a),"hard_after":len(b),
                        "remaining_before_cases":len(a & b),"fixed_target":len(target),
                        "new_hard":len(b-a),"new_open_flags":len(after_rows-before_rows),
                        "old_hard_removed":sorted(a-b)}

before = load(base/"pawnshop-before/street.json")
after = load(base/"pawnshop-after/street.json")
assert before == after and len(after["rows"])==12 and "RX 9070 XT" in after["adapter"]
assert all(row["pose"]=="stand" and row["loop"]=="wipe_hands" for row in after["rows"])
assert sum(row["talking"] and row["count"]==0 and bool(row["dialogue"]) for row in after["rows"])==4
assert sum(row["count"]==1 and not row["talking"] for row in after["rows"])==4
assert "ERROR:" not in read(base/"pawnshop-after/raw.log")

official = base/"official"
assert load(official/"verification.json") == {"exit":0,"errors":[],"source_held":True}
counts = re.search(r"Running (\d+) groups in.*?checks: (\d+), new failures: 0, known failures .*?: 0  \(wall time (\d+) s\)",
                   read(official/"raw.log"),re.S)
assert counts and int(counts[1])==4

name = "NE-224-old-k-seated-wrist-2026-11-23"
attachment = pm/"attachments"/name
image = pm/"images/NE-224-old-k-seated-wrist-20261123.png"
ticket = next(pm.glob("[[]NE-224[]]*.md"))
doc = read(ticket)
assert "# Commit-29" in doc and "# Commit-30" not in doc
assert not image.exists()

# Use original rendered pixels with the wrist magnified so the one-pixel seam is visible.
with Image.open(audit/"old-k-lap-proof.png") as lap:
    display = Image.new("RGB",(lap.width,lap.height+128),(21,29,43))
    display.paste(lap, (0,0))
draw = ImageDraw.Draw(display)
capture_name = "sit_talk_3.4_014.png"
for index,(title,folder) in enumerate((("WRIST BEFORE","before-dressed"),("WRIST AFTER","tip-dressed"))):
    with Image.open(base/folder/capture_name) as wrist:
        source=wrist.convert("RGBA").crop((51,51,81,73)).resize((120,88),Image.Resampling.NEAREST)
        left = 36+index*(display.width//2)
        top = display.height-105
        display.paste(source,(left,top),source)
        draw.text((left,top-15),title,fill=(240,240,248))
        px,py = left+14*4,top+14*4
        draw.rectangle((px-2,py-2,px+6,py+6),outline=(255,111,164))
local_image = base/"seated-wrist-comparison.png"
display.save(local_image,optimize=True)

attachment.mkdir()
archive=attachment/"evidence.zip"
items = {
    "wrist-trace.json": base/"wrist-trace.json",
    "alpha-control.log": base/"tip-alpha-control/comparison.log",
    "benchmarks/raw.log": official/"raw.log",
    "benchmarks/verification.json": official/"verification.json",
    "pawnshop/before.json": base/"pawnshop-before/street.json",
    "pawnshop/after.json": base/"pawnshop-after/street.json",
    "sources/rebuild.log": base/"rebuild.log",
    "sources/spec.log": base/"spec.log",
    "sources/parts.log": base/"parts.log",
    "replay/arena.gd": base/"arena.gd",
    "replay/arena.tscn": base/"arena.tscn",
    "replay/classify-lap.py": audit/"classify-lap.py",
    "replay/compare.py": Path(__file__),
}
summary = {"parent":read(base/"baseline.txt").strip(),"natural_spaces":len(matched),
           "natural_pixels":scope["pixels_opened"],"natural_pixels_after":natural_remaining,"selected_wrist_frames":sorted(target),
           "modes":comparison,"official":[int(counts[i]) for i in (1,2,3)],
           "source_diffuse":sha(base/"arm-cuff-tip.png"),"source_normal":sha(base/"normal-tip.png"),
           "image":sha(local_image)}
with ZipFile(archive,"w",compression=ZIP_DEFLATED,compresslevel=9) as out:
    for label,file in items.items():
        out.write(file,label)
    out.writestr("result.json",json.dumps(summary,ensure_ascii=False,indent=2)+"\n")
with ZipFile(archive) as check:
    assert check.testzip() is None and all(sha256(check.read(label)).hexdigest()==sha(path) for label,path in items.items())
shutil.copyfile(local_image,image)
text = f"""

---

# Commit-30（老 K 坐姿手腕與外套輪廓）

## 內文

老 K 坐著說話時，近側手掌與袖口間偶爾露出一個像素的背景。補合手腕，保留外套、原手掌輪廓與動作。

### 驗收

- RX 9070 XT Forward+，用兩倍率、雙面向、五種原動作驗證安裝後材質。全身、著裝與相鄰零件各 33,600 項，原手腕 44 筆孔洞全部消失，三組都沒有新增封閉孔洞、鬆脫片或露出接點。
- 4,636 筆手臂與衣襬之間的畫面，隱藏前臂與手掌即可接通外緣。超過一像素的原空隙仍保留，每筆最多縮小兩像素。
- 在正式第一章當舖用互動鍵完成原對話，修正前後 12 筆量測一致，四次對話各記錄一次。受影響回歸 {counts[1]} 組、{int(counts[2]):,} 項全過，0 腳本錯誤。

[接點量測、當舖互動與回歸](attachments/{name}/evidence.zip)

![原外套空隙與修正前後的坐姿袖口](images/{image.name})
"""
ticket.write_text(doc.rstrip()+text.rstrip()+"\n",encoding="utf-8",newline="\n")
paths=[ticket,archive,image,root/"art_src/characters/old_k/overrides/arm_lower.png",
       root/"art/characters/old_k/parts/arm_lower.png",root/"art/characters/old_k/parts/arm_lower_n.png",
       root/"design/12-cast-redraw/RIG_QUALITY.md"]
(base/"delivery.json").write_text(json.dumps([p.relative_to(root).as_posix() for p in paths],ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print("OLD K RECEIPT",counts.groups(),archive.stat().st_size,image.stat().st_size,
      {key:(row["hard_before"],row["hard_after"],row["new_open_flags"]) for key,row in comparison.items()},flush=True)
