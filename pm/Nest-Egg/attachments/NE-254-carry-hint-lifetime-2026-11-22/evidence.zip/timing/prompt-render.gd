extends "res://tests/smoke_test.gd"

func _run() -> void:
	Story.auto_skip = true
	Enemy.activation_culling_enabled = false
	for iteration in 8:
		await preload("./prompt-render-suite.gd").new(self)._test_pickup_prompt_target()
	await _finish()
