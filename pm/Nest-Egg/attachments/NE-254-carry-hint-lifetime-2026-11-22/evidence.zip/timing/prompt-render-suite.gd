extends ThrowablesSuite

func _test_pickup_prompt_target() -> void:
	await open_level(10.0)
	var near := _place(CRATE, 10.7)
	var other := _place(PIPE, 9.0)
	var unsettled := _place(PIPE, 10.0, FLOOR_Y - 15.0)
	unsettled.set_physics_process(false)
	await physics_frames(4)
	check(near._prompt._player_near(), "the actual nearest pickup offers its interaction")
	check(not other._prompt._player_near(), "a second nearby pickup does not compete with the actual interaction target")
	check(not unsettled._prompt._player_near(), "an unsettled object never invites a pickup that the real handler rejects")
	place_player(9.0)
	await physics_frames(2)
	check(other._prompt._player_near() and not near._prompt._player_near(), "moving to the other object transfers the prompt to the actual pickup target")
	await _press(&"interact")
	check(level.player.carry.held == other and not near._prompt._player_near(), "the real interact key picks the advertised object and suppresses other pickup invitations")
	var frame := Engine.get_process_frames()
	var early := other._prompt._player_near()
	var from_cache := Story.framing._prompt_frame
	while Engine.get_process_frames() == frame:
		await runner.get_tree().process_frame
	var late := other._prompt._player_near()
	print("CARRY_SAMPLE process=", frame, " cache=", from_cache, " next=", Engine.get_process_frames(),
		" early=", early, " late=", late)
	check(late and other._prompt.text == "{interact} 放下", "the rendered held-object prompt offers the drop action")
	await end_level(level)

