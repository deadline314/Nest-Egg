extends "res://tests/smoke_test.gd"

var _out := ""
var _pad := false


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://vehicle_prompt_probe.cfg")
	for arg in OS.get_cmdline_user_args():
		if arg == "--pad":
			_pad = true
		if arg.begins_with("--text-scale="):
			Settings.set_ui_text_scale(float(arg.trim_prefix("--text-scale=")))
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	super._ready()


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(load("res://data/levels/level_01.tres") as LevelData)
	add_child(level)
	await _frames(45)
	for node in get_tree().get_nodes_in_group(&"enemies"):
		node.set_physics_process(false)
	var player := level.player
	var vehicle := get_tree().get_first_node_in_group(&"vehicles") as Vehicle
	_check(vehicle != null and vehicle.can_mount(), "the authored rain-night stage has its Bulwark")
	if vehicle == null:
		await _finish()
		return
	AimInput.set_virtual_gamepad(player, true)
	AimInput._last_stick_dir = Vector2.LEFT
	player.global_position = vehicle.global_position + Vector2(-38.0, 0)
	player.velocity = Vector2.ZERO
	await _frames(22)
	var mount_range := player.tuning.mount_range
	_check(player.global_position.distance_to(vehicle.global_position) > mount_range, "player is beyond the authored mount range")
	print("VEHICLE_OUT ", player.global_position.distance_to(vehicle.global_position), " display=", vehicle._prompt.is_showing())
	_check(not vehicle._prompt.is_showing(), "out of reach does not invite mounting")
	await _interact()
	await _frames(4)
	_check(player.state == Player.State.NORMAL and vehicle.driver == null, "out-of-range interact cannot mount")
	await _shot("outside-range")
	var crate := Throwable.new()
	crate.configure(load("res://data/throwables/crate_small.tres"))
	crate.position = level._entities.to_local(vehicle.global_position + Vector2(-80, 0))
	level._entities.add_child(crate)
	await _frames(20)
	player.global_position = crate.global_position + Vector2(-8, 0)
	player.velocity = Vector2.ZERO
	await _frames(23)
	await _interact()
	await _frames(35)
	_check(player.carry.is_holding() and player.carry.held == crate, "normal input lifts the authored crate staged nearby")
	player.global_position = vehicle.global_position + Vector2(-20, 0)
	player.velocity = Vector2.ZERO
	await _frames(28)
	_check(player.global_position.distance_to(vehicle.global_position) <= mount_range and player.carry.held == crate,
		"the carrying player is actually inside mount range")
	_check(crate._prompt.is_showing() and not vehicle._prompt.is_showing(), "holding offers only the current drop prompt")
	var banner := level.hud.toast_banner
	var pickup_hint := InputBindings.format("{shoot} 往準星丟出，{interact} 放下")
	_check(banner.is_showing() and banner._label.text == pickup_hint, "the first lift teaches the active throw and drop bindings")
	await _shot("hold-near-vehicle")
	await _interact()
	await _frames(9)
	print("VEHICLE_FIRST holding=", player.carry.is_holding(), " driver=", vehicle.driver != null)
	_check(not player.carry.is_holding() and vehicle.driver == null, "one interact puts the crate down without mounting")
	print("CARRY_HINT released=", not player.carry.is_holding(), " old_prompt=", banner._label.text == pickup_hint,
		" visible=", banner.is_showing(), " active_text=", banner._label.text)
	_check(banner._label.text != pickup_hint and not banner.is_showing(), "the pickup hint ends with the active hold")
	await _shot("first-press")
	if vehicle.driver != null:
		player.dismount_vehicle(false)
		await _frames(35)
	player.global_position = vehicle.global_position + Vector2(12, 0)
	player.velocity = Vector2.ZERO
	await _frames(25)
	var nearest := player.carry.nearest_pickable()
	var selected := Story.framing.interaction_prompt_target()
	print("VEHICLE_SECOND pos=",player.global_position, " vehicle=",vehicle.global_position, " crate=",crate.global_position,
		" nearest=", nearest, " target=", selected, " visible=",vehicle._prompt.is_showing(), " near=",vehicle._prompt._player_near(),
		" alpha=",vehicle._prompt._alpha, " layout=",vehicle._prompt._layout_allowed, " bounds=",vehicle._prompt._box)
	await _shot("second-prompt")
	_check(player.carry.nearest_pickable() == null and vehicle._prompt.is_showing(), "normal mount affordance works separately")
	await _interact()
	await _frames(25)
	_check(player.mounted_vehicle == vehicle and vehicle.driver == player, "a separate interact mounts the vehicle")
	await _shot("separate-mount")
	await _interact()
	await _frames(15)
	_check(player.state == Player.State.NORMAL and vehicle.driver == null, "interact dismounts after normal grace")
	level.queue_free()
	await _frames(5)
	await _finish()


func _interact() -> void:
	if _pad:
		var button := InputEventJoypadButton.new()
		button.button_index = InputBindings.get_joy_button(&"interact") as JoyButton
		button.pressed = true
		button.pressure = 1.0
		Input.parse_input_event(button)
		Input.flush_buffered_events()
		await _frames(3)
		var up := button.duplicate() as InputEventJoypadButton
		up.pressed = false
		up.pressure = 0.0
		Input.parse_input_event(up)
		Input.flush_buffered_events()
		return
	var press := InputEventKey.new()
	press.keycode = KEY_E
	press.physical_keycode = KEY_E
	press.pressed = true
	Input.parse_input_event(press)
	Input.flush_buffered_events()
	await _frames(3)
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	Input.parse_input_event(release)
	Input.flush_buffered_events()

func _send_key(code: Key) -> void:
	var press := InputEventKey.new()
	press.keycode = code
	press.physical_keycode = code
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _send_button(button: JoyButton) -> void:
	var press := InputEventJoypadButton.new()
	press.button_index = button
	press.pressure = 1.0
	press.pressed = true
	get_viewport().push_input(press, true)
	await get_tree().process_frame
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	release.pressure = 0.0
	get_viewport().push_input(release, true)
	await get_tree().process_frame


func _shot(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join(name + ".png")) == OK, "saved " + name)