extends Node

func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://hold-detached-probe.cfg")
	Story.set_language("en")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(load("res://data/levels/ch2_ledger_office.tres") as LevelData)
	add_child(level)
	for i in 30:
		await get_tree().process_frame
	var player := level.player
	var point := BossHoldPoint.new()
	point.setup(1.5, "")
	point.enabled = true
	level.add_child(point)
	point.global_position = player.global_position
	Input.action_press(&"interact")
	for i in 18:
		await get_tree().physics_frame
	var advanced := point.progress() > 0.1
	var notices: Array[String] = []
	var record := func(value: String) -> void:
		if value == "Operation interrupted.":
			notices.append(value)
	EventBus.toast_requested.connect(record)
	var hit := DamageInfo.create(1, Combat.Team.ENEMY, &"test")
	hit.ignore_invulnerability = true
	player.health.take_damage(hit)
	Input.action_release(&"interact")
	level.remove_child(point)
	for i in 3:
		await get_tree().process_frame
	EventBus.toast_requested.disconnect(record)
	point.free()
	print("active hold before detach: %s, stale interruption notices: %d" % [advanced, notices.size()])
	level.queue_free()
	for i in 4:
		await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(not advanced or not notices.is_empty()))
