extends "res://tests/smoke_test.gd"

const OFFICE := preload("res://data/levels/ch2_ledger_office.tres")
const Capture := preload("res://tools/viewport_capture.gd")
const WORDS := {
	"zh": ["高臺", "解除", "被打斷", "永久解除", "制伏進度", "儲能匣"],
	"ja": ["高台", "解除", "中断", "解除", "制圧進行", "電源セル"],
	"en": ["platform", "disconnect", "interrupted", "disconnected", "Subdue progress", "power cell"],
}


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://yong_guide_probe.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	Story.auto_skip = true
	Enemy.activation_culling_enabled = false
	add_child(LightKit.create_environment())
	var args := OS.get_cmdline_user_args()
	for language: String in WORDS:
		await _case(language, args[0] if args.size() == 1 else "-")
	await _finish()


func _case(language: String, screenshot: String) -> void:
	Story.set_language(language)
	InputBindings.reset_to_defaults()
	InputBindings.set_code(&"interact", 0, KEY_H)
	_key(KEY_F8, true)
	_key(KEY_F8, false)
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	var level := Level.new()
	level.configure(OFFICE)
	add_child(level)
	await _frames(30)
	var boss: PatternBoss
	for enemy: Node in get_tree().get_nodes_in_group(&"enemies"):
		if enemy is PatternBoss and enemy.data.id == &"yong":
			boss = enemy
			break
	_check(is_instance_valid(boss), "%s original office spawned its authored Yong" % language)
	if boss == null:
		level.queue_free()
		await _frames(4)
		return
	var player := level.player
	player.health.setup(70, 0.0)
	player.global_position = boss.global_position + Vector2(-106, 0)
	await _physics(12)
	var helper := Chapter2EnemiesSuite.new(self)
	await helper._damage_to(boss, 1)
	for i in 240:
		if boss.get("stage") == "cut_box":
			break
		await _physics(1)
	var box := boss.call(&"isolation_box") as BossHoldPoint
	var msg: Array = WORDS[language]
	var banner := level.hud.toast_banner
	_check(boss.get("stage") == "cut_box" and box != null and box.enabled and GameState.get_flag(&"yong_link_choice") == "cut",
		"%s original health gate offers the cut-route isolation box" % language)
	if box == null or not box.enabled:
		level.queue_free()
		await _frames(4)
		return
	var key_name := InputBindings.primary_label(&"interact")
	_check(banner._label.text.contains(msg[0]) and banner._label.text.contains(key_name), "%s the route guide names the box location and rebound key [%s]" % [language, banner._label.text])
	player.set_physics_process(false)
	boss.set_physics_process(false)
	player.global_position = box.global_position
	level.camera.snap_to_target()
	await _frames(3)
	_check(box._prompt._display_text.contains(msg[1]) and box._prompt._display_text.contains(key_name),
		"%s isolation-box prompt names the action and rebound key [%s]" % [language, box._prompt._display_text])
	_joy_axis(0.8)
	await _frames(2)
	var pad_name := InputBindings.primary_label(&"interact")
	_check(InputBindings.using_gamepad and pad_name != key_name and banner._label.text.contains(pad_name)
		and box._prompt._display_text.contains(pad_name), "%s both original guides follow the active controller binding" % language)
	_joy_axis(0.0)
	if language == "en" and screenshot.is_absolute_path():
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(screenshot) == OK, "original rendered isolation-box guide captured")
	_pad(true)
	await _physics(22)
	_check(box.progress() > 0.15 and not box.done, "%s real interact button advances the original hold" % language)
	var damage := DamageInfo.create(1, Combat.Team.ENEMY, &"test")
	damage.ignore_invulnerability = true
	player.health.take_damage(damage)
	_pad(false)
	await _physics(3)
	_check(is_zero_approx(box.progress()) and GameState.get_flag(&"yong_link_isolated") != true,
		"%s a real damage signal resets progress without committing the route" % language)
	_check(banner._label.text.contains(msg[2]), "%s the interruption is described in the selected language [%s]" % [language, banner._label.text])
	_pad(true)
	await _physics(100)
	_pad(false)
	await _physics(2)
	_check(boss.get("stage") == "subdue" and box.done and GameState.get_flag(&"yong_link_revoked") == true,
		"%s repeating the original hold enters subdue and records permanent isolation" % language)
	_check(banner._label.text.contains(msg[3]) and level.hud.boss_bar._name.contains(msg[4]),
		"%s original completion notice and subdue meter use selected language [%s / %s]" % [language, banner._label.text, level.hud.boss_bar._name])
	var cell := boss.call(&"power_cell") as BossHoldPoint
	_check(cell._prompt._display_text.contains(msg[5]) and cell._prompt._display_text.contains(pad_name),
		"%s the future power-cell prompt names the cell and active binding [%s]" % [language, cell._prompt._display_text])
	level.queue_free()
	await _frames(5)


func _key(code: Key, pressed: bool) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = pressed
	Input.parse_input_event(event)
	Input.flush_buffered_events()


func _joy_axis(value: float) -> void:
	var event := InputEventJoypadMotion.new()
	event.axis = JOY_AXIS_RIGHT_X
	event.axis_value = value
	Input.parse_input_event(event)
	Input.flush_buffered_events()


func _pad(pressed: bool) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = InputBindings.get_joy_button(&"interact") as JoyButton
	event.pressed = pressed
	event.pressure = float(pressed)
	Input.parse_input_event(event)
	Input.flush_buffered_events()


func _physics(count: int) -> void:
	for i in count:
		await get_tree().physics_frame
