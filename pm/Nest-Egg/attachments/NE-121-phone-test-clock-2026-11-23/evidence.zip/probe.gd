extends "res://tests/smoke_test.gd"

func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var candidate := "--candidate" in OS.get_cmdline_user_args()
	var suite: PhoneBoothSuite = preload("candidate.gd").new(self) if candidate else PhoneBoothSuite.new(self)
	await suite._test_dial_with_the_interact_key()
	await suite._test_nearest_interaction()
	print("CLOCK_TEST ", Engine.get_frames_per_second())
	await _finish()
