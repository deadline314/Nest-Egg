extends PhoneBoothSuite


func _test_dial_with_the_interact_key() -> void:
	await open_level(10.0)
	_clear_enemies()
	var booth := _booth(level)
	GameState.clear_checkpoint()
	place_player(BOOTH_TILE - 1.0)
	await physics_frames(20)
	await _press_interact()
	check(level.player.is_on_phone() and booth.is_calling(), "pressing the interact key starts the call")
	check(level.player.facing == 1, "the player faces the booth")
	await physics_frames(100)
	check(not level.player.is_on_phone() and not booth.is_calling() and booth.activated, "the call finishes by itself")
	await end_level(level)


func _press_interact() -> void:
	var tree := runner.get_tree()
	# The booth consumes the edge during _process, which can span several physics ticks.
	await tree.process_frame
	Input.action_press(&"interact")
	await tree.process_frame
	Input.action_release(&"interact")


func _test_nearest_interaction() -> void:
	await open_level(10.0)
	_clear_enemies()
	GameState.clear_checkpoint()
	var auto_skip := Story.auto_skip
	Story.auto_skip = false
	var scene := &"test_phone_nearest_source"
	Story._scenes[String(scene)] = {"mode": "dialogue", "lines": [{"speaker": "rin", "text": "互動來源測試。"}]}
	var booth := _booth(level, 18.0)
	var talk := NpcTalk.new()
	talk.scene = scene
	var data := NpcData.new()
	data.id = &"phone_neighbour"
	data.kind = NpcData.Kind.OBJECT
	data.rig_id = ""
	data.talks = [talk]
	var npc := NpcActor.new()
	npc.configure(data, Vector2i(21, 19))
	level._entities.add_child(npc)
	npc.global_position = booth.global_position + Vector2(48, 0)
	level.player.global_position = booth.global_position + Vector2(20, 0)
	await physics_frames(15)
	check(booth._player_in_range and npc._player_in_range, "both real interaction sensors overlap")
	check(booth.can_dial() and not Story.framing.is_interaction_target(npc), "the nearer phone owns interact before any action starts")
	level.player.global_position.x = booth.global_position.x + 25.0
	await physics_frames(5)
	check(not booth.can_dial() and Story.framing.is_interaction_target(npc), "the nearer NPC owns interact inside the same overlap")
	level.player.global_position.x = booth.global_position.x + 20.0
	await physics_frames(5)
	await _press_interact()
	check(level.player.is_on_phone() and booth.is_calling(), "a single overlap press begins the nearer booth call")
	check(not npc._talking and not Story.is_cinematic_active(), "that same press does not also begin NPC dialogue")
	Story.reset_active_presentation(&"test")
	await physics_frames(2)
	if not level.player.is_on_phone():
		check(booth.start_call(level.player), "phone precondition for the direct-dialogue guard")
	var done := [false, false]
	var begin_talk := func() -> void:
		done[1] = await npc._talk()
		done[0] = true
	begin_talk.call()
	await physics_frames(2)
	check(done[0] and not done[1] and not Story.is_cinematic_active(), "direct dialogue entry also refuses during the actual phone state")
	check(not npc._prompt_available(), "NPC hover guidance stays hidden during the call")
	Story.reset_active_presentation(&"test")
	Story.auto_skip = true
	await physics_frames(100)
	var token := GameplayLock.acquire(booth)
	check(not booth.start_call(level.player), "direct phone entry refuses an existing gameplay lock")
	GameplayLock.release(token)
	await physics_frames(100)
	Story.reset_active_presentation(&"test")
	await end_level(level)
	Story._scenes.erase(String(scene))
	Story._seen.erase(scene)
	Story._completed.erase(scene)
	Story.auto_skip = auto_skip
	GameState.clear_checkpoint()


## 骨架動作逐格稽核：把撥號動作整段播放，骨頭長度、手肘、驅幹、頭、角度跳動都要在限制內。
func _test_action_audit() -> void:
	var holder := Node2D.new()
	runner.get_tree().root.add_child(holder)
	var rig := CharacterRig.new()
	holder.add_child(rig)
	check(rig.setup("rin"), "rin builds")
	rig.set_weapon("handset")
	var report := AnimAudit.audit_actions(rig, ["rin.phone_call"])
	for check_name: String in ["bone_stretch", "elbow_hyper", "trunk_lean", "head_turn", "angle_pop"]:
		var entry: Dictionary = report.get(check_name, {"value": 0.0, "limit": AnimAudit.LIMITS[check_name], "where": "-"})
		check(float(entry["value"]) <= float(entry["limit"]), "phone call: %s within limit (%.2f > %.2f at %s)" % [check_name, float(entry["value"]), float(entry["limit"]), entry["where"]])
	holder.queue_free()
	await frames(1)

