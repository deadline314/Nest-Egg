"""Read-only published-five-hold supplement; original combo report is unchanged."""
import argparse, collections, copy, hashlib, importlib, json, pathlib, sys
import numpy as np

HERE=pathlib.Path(__file__).resolve().parent
WEAPONS={'blade':'thermal_blade','dagger':'mono_dagger','glaive':'ion_glaive','maul':'hydraulic_maul','whip':'mono_whip'}
VERSION='ne261-five-hold-reader-v1'

def check_content(j,inputs):
    assert j['schema']=='ne261-published-five-holds-v1' and j['failures']==0
    assert j['runtime']=={'adapter':'','audio_driver':'WASAPI','display':'headless','rendering_device_null':True}
    assert j['installer'][0]['equal'] and j['installer'][0]['installed_idle'] and j['installer'][-1]['uninstalled_idle']
    rows=j['hold_segments'];passes=j['passes'];clock=j['sample_clock'];count=clock['stop']['frames']
    assert len(rows)==34 and {(r['weapon'],r['part']) for r in rows}=={('ref',p) for p in ('silence','pistol','pistol_hit','walk')}|{(w,p) for w in WEAPONS for p in ('idle','entry_miss','hold_miss','entry_hit','hold_hit','holster')}
    assert [p['id'] for p in passes]==list(range(1,len(passes)+1))
    previous=0
    for ri,r in enumerate(rows):
        start,end=r['start_frames'],r['end_frames']
        assert set(start)==set(end)==set(count) and len(set(start.values()))==len(set(end.values()))==1
        assert all(type(start[n]) is int and type(end[n]) is int and previous<=start[n]<end[n]<=count[n] for n in count),'segment boundary outside true PCM'
        previous=end['SFX']
        ps=[passes[n-1] for n in r['pass_ids']]
        assert all(p['row']==ri and p['before']['phase']==p['after']['phase'] and p['before']['time']==p['after']['time'] for p in ps),'observer altered parent state'
        for p in ps:
            assert p['before']['phase']==2
            assert len(p['damage'])==len(p['confirmed'])
            assert all(e['source']=='melee' and e['window']==p['id'] and e['amount']>0 for e in p['damage'])
            ids=[e['id'] for e in p['sounds']]
            hit=[s for s in ids if s.startswith('melee_') and '_hit' in s]
            assert bool(p['damage'])==bool(hit) and ids.count('mat_armor')==len(p['damage']),'actual damage/material/hit layer mismatch'
            assert not (hit and any('_swing' in s for s in ids)),'same pass emitted hit and miss layers'
        part=r['part'];w=r['weapon']
        if part in ('pistol','entry_miss','hold_miss'):
            assert not r['start_state']['target'] and not r['damage'] and not r['confirmed']
            assert not any('_hit' in e['id'] or e['id']=='mat_armor' for e in r['sounds']),'hit sound in real miss'
        if part in ('pistol_hit','entry_hit','hold_hit'):
            a,b=r['start_state']['target'],r['end_state']['target']
            assert a['id']==b['id'] and a['can_process'] and a['body_space']!=0 and a['area_space']!=0 and a['material']=='armor'
            assert a['health']-b['health']==sum(e['amount'] for e in r['damage'])>0 and len(r['damage'])==len(r['confirmed'])
            assert all(e['source']==('player_pistol' if part=='pistol_hit' else 'melee') for e in r['damage'])
            if part=='pistol_hit':assert len(r['damage'])==3
        if part=='idle':assert r['end_state']['hum']=='melee_'+w+'_idle'
        if part=='holster':assert r['end_state']['hum']==''
        if part.startswith('hold_'):
            data=inputs[w];spec=data['hold'];attack=spec['attack'];definition=data['attacks'][attack]
            assert r['start_state']['attack']==attack and r['start_state']['hold_mode']==spec['mode'] and r['start_state']['input_pressed']
            assert r['end_state']['phase']==0 and not r['end_state']['input_pressed']
            preceding=rows[ri-1];assert preceding['part']=='entry_'+part.removeprefix('hold_') and preceding['weapon']==w
            pair=[j['inputs'][i] for i in preceding['input_indices']+r['input_indices']]
            assert [(e['pressed'],e['actual']) for e in pair]==[(True,True),(False,False)],'missing actual public hold/release'
            assert ps and all(p['before']['attack']==attack for p in ps)
            assert all(e['attack']==attack and e['hold_mode']==spec['mode'] for e in r['hold_starts'])
            if spec['mode']=='charge':assert all(p['before']['charged'] for p in ps),'not fully charged'
            elif spec['mode']=='repeat':
                assert len(r['hold_starts'])>=3 and set(p['before']['hit_window'] for p in ps)==set(range(len(definition['hits'])))
            else:assert max(p['before']['time'] for p in ps)>=float(spec['max']),'sustain did not reach actual max'
            feedback=definition.get('feedback',{});hit=feedback.get('high') or definition['sounds']['hit']
            expected_layers=[hit]+([feedback['low']] if feedback.get('low') else [])
            for p in ps:
                ids=[e['id'] for e in p['sounds']]
                if p['damage']:assert all(s in ids for s in expected_layers),'wrong published hold hit layers'
            swings=[e for e in r['sounds'] if e['id'].startswith('melee_'+w+'_swing')]
            assert all(not e['state']['landed'] for e in swings)
            if part=='hold_miss':assert swings,'miss has no actual swing event'
    return {'segments':len(rows),'measured_hold_segments':10,'hit_pass_calls':len(passes),'actual_hold_damage_events':sum(len(r['damage']) for r in rows if r['part']=='hold_hit'),'scope':'actual armor target only; no human hearing, physical controller, render, all-material or C26 claim'}

def evaluate(j,buses,rate,levels):
    sfx=np.frombuffer(buses['SFX']['pcm_s16'],dtype='<i2').reshape(-1,2).mean(axis=1,dtype=np.float32)/32768.0
    bed=np.zeros_like(sfx)
    for n in ('Music','Ambience'):
        x=np.frombuffer(buses[n]['raw_f32'],dtype='<f4').reshape(-1,2).mean(axis=1)
        x*=buses[n]['gain']/buses['SFX']['gain'];bed+=x
    rows=[]
    for r in j['hold_segments']:
        cut=slice(r['start_frames']['SFX'],r['end_frames']['SFX'])
        peak,loud,floor=levels(sfx[cut],rate)
        rows.append({'weapon':r['weapon'],'part':r['part'],'start_frame':cut.start,'end_frame':cut.stop,'peak':peak,'loud':loud,'floor':floor,'bed':levels(bed[cut],rate)[2]})
    problems=limits(rows)
    return rows,problems

def limits(rows):
    refs={r['part']:r for r in rows if r['weapon']=='ref'};problems=[]
    for r in rows:
        w,p=r['weapon'],r['part']
        if p in ('hold_miss','hold_hit') and r['loud']>refs['pistol_hit' if p=='hold_hit' else 'pistol']['loud']:problems.append({'weapon':w,'part':p,'rule':'hold loud <= pistol reference','actual':r['loud'],'limit':refs['pistol_hit' if p=='hold_hit' else 'pistol']['loud']})
        if p=='idle':
            for rule,limit in [('idle <= footsteps loud - 6dB',refs['walk']['loud']-6.0),('idle <= own actual bed - 10dB',r['bed']-10.0)]:
                if r['floor']>limit:problems.append({'weapon':w,'part':p,'rule':rule,'actual':r['floor'],'limit':limit})
            if r['floor'] < -75.0:problems.append({'weapon':w,'part':p,'rule':'idle >= -75dB','actual':r['floor'],'limit':-75.0})
        if p=='holster':
            idle=next(x for x in rows if x['weapon']==w and x['part']=='idle')
            if r['floor']>-70.0 and r['floor']>idle['floor']-10.0:problems.append({'weapon':w,'part':p,'rule':'holster <= -70dB or idle - 10dB','actual':r['floor']})
    return problems

def main():
    ap=argparse.ArgumentParser();ap.add_argument('run',type=pathlib.Path);ap.add_argument('--audio-tools',required=True,type=pathlib.Path);ap.add_argument('--out',type=pathlib.Path);args=ap.parse_args()
    sys.path.insert(0,str(args.audio_tools));pcm=importlib.import_module('melee_pcm_reader');report=importlib.import_module('melee_sound_report')
    run=args.run.resolve();receipt=json.loads((run/'exit.json').read_text());command=json.loads((run/'command.json').read_text());j=json.loads((run/'recording/hold-index.json').read_text())
    assert receipt['exit_code']==0 and not receipt['diagnostic_lines'] and not receipt['gpu_log_rejected'] and receipt['runtime_ok'] and receipt['source_unchanged']
    assert command['base']=='896d3e8a7fb1b0018df0aec47ed8c5a37bb881c0'
    inputs={w:json.loads((run/'published-inputs/data/melee'/f'{f}.json').read_text()) for w,f in WEAPONS.items()}
    for n,expected in command['source_before'].items():
        p=run/'published-inputs'/n
        if p.exists():assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,('frozen published input changed',n)
    content=check_content(j,inputs);rate,buses=pcm.load(run/'recording',j)
    rows,problems=evaluate(j,buses,rate,report.levels)
    result={'reader_version':VERSION,'accepted':not problems,'content':content,'mix_rate':rate,'frames':j['sample_clock']['stop']['frames'],'rows':rows,'problems':problems,'measurement_plane':'SFX before its actual bus gain; direct Music+Ambience captured after existing effects, actual stable gains normalized to SFX. Never Master minus SFX.'}
    text=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if args.out:args.out.write_text(text,encoding='utf8',newline='\n')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False,indent=2))
    return 0 if not problems else 1

if __name__=='__main__':raise SystemExit(main())
