# NE261 published five-hold audio supplement — RED

This independent leaf uses immutable published `896d3e8a7fb1b0018df0aec47ed8c5a37bb881c0` plus the accepted stage5 canonical seven files. It does not use the primary working tree's unpublished NE277 geometry. No product, sound bank, combat distance, damage, timing, volume or acceptance limit was changed. Canonical seven remain unchanged.

Both captures use headless DisplayServer, actual WASAPI, empty GPU adapter and null RenderingDevice. These are software-input audio/PCM checks, not Forward+ pictures, physical controller handling, performance or human hearing. 3,871 existing published/canonical/import-metadata files remain byte-identical before/after each process; each command/receipt retains that full source dictionary. Authored observation leaves have separate hashes and exact executed source ZIPs.

## Actual results

| Run | Result |
| --- | --- |
| `1794470800081490100-equivalence-original` / `1794470901349902000-equivalence-observer` | Same public press/release, original first blade hit 2 then fully charged dash-cut hit 7, same damage/material/weapon event sequences. Observer made 15 actual parent hit-pass calls, two damaging calls; no second query. Installer preserves original idle weapon ID and command latches. |
| `1794471276726598400-holds` | 70.404 s, engine exit 0, no diagnostics or GPU. Four buses each 2,489,344 actual PCM frames at 48 kHz. Content valid, loudness reader **exit 1**. |
| `1794472002092308000-holds` | Same public sequence with observation-only live audio metadata; 73.694 s, engine exit 0, no diagnostics or GPU. Four buses each 2,486,272 frames. Same content scope, loudness reader **exit 1**. |

Each full capture has 34 explicitly named rows: four references, five idle, ten normal entry/setup rows, ten actual hold rows, five holsters. Ten hold rows cover both miss and actual armor-target hit for `dash_cut`, `frenzy`, `guard_stance`, `quake`, and `orbit`. They contain 312 real hit-pass calls and 32 actual hold damage events (blade 1 / dagger 12 / glaive 9 / maul 1 / whip 9). Normal entries are disclosed separately and are not relabelled as holds or combos. Charge reaches the published full-charge condition; repeat covers three complete four-window cycles; sustain reaches its published maximum then naturally recovers. Each hit matches actual Health delta, melee source, hit-confirmed callback, armor material and source-defined immediate/delayed sound layers. Misses have swing events and no hit/damage/material calls. Sustained miss is not required to manufacture a new swing on every tick.

The original 50 ms RMS / 95th-percentile loudness rule is reused. All ten hold loudness values are below their original pistol miss/hit references. Five idle voices stop after holstering and meet the footstep-minus-6 dB and original inaudibility limits. **Maul idle fails the original bed-minus-10 dB rule in both runs:**

| Capture | Idle SFX floor | Actual direct Music+Ambience floor | Required idle maximum |
| --- | ---: | ---: | ---: |
| Original full holds | −43.440892 dB | −44.167589 dB | −54.167589 dB |
| Metadata replay | −43.717873 dB | −43.649280 dB | −53.649280 dB |

Measurement uses SFX before its bus gain and separate post-effect Music/Ambience captures, with the actual stable gains normalized to SFX's plane. It never subtracts SFX from limited Master. Independent bus counters, discarded frames, exact float-to-WAV samples and all row bounds are verified. This is a whole-bus measurement; event callbacks establish routing but do not separately measure the audibility of every mixed layer.

## Narrow cause evidence and limits

`idle-cause-pcm-v1.json` computes each bus from the original PCM, including adjacent rows. Ambience is exactly zero, Music gain is −3.098039 dB, SFX gain is 0 dB. The first maul idle spans actual SFX samples 31.3173–32.9173 s. Its preceding glaive holster Music floor is −29.556979 dB; following maul entry-miss Music floor is −28.078686 dB. The original capture recorded actual maul hum identity but not live track/fade/gain; those missing historical facts are not invented.

The second capture adds `audio_start`/`audio_end` in each row. Maul idle starts on `combat_dungeon`, neutral zone, active music voice at 0 dB. It ends during return to `calm_freight`, incoming voice −23.920029 dB and outgoing voice −36.079948 dB. Music filter remains open at 20,500 Hz, duck 0 dB. Both voices loop. This observes a real background dip during the source's simultaneous linear-in-dB fade; it does not isolate crossfade versus musical-content contributions to every original sample.

Actual maul hum is playing throughout: gain 0.458584→1, stream player −18.771622→−12 dB. Glaive hum was already stopped/gain 0 at previous holster end. The maul idle has no damage or one-shot SFX callbacks. Thus no evidence supports treating it as a mislabeled old hold sound. The first fade-in portion is retained in the original metric; it is not excluded to improve a number.

`ScenarioBase.open_arena("")` uses `NewEnemiesSuite.arena_data()` (`arena_test`, layout only), no lighting-zone override. LightingController announces `neutral`; the published Ambience default is empty. Thus this is the exact original probe's synthetic neutral arena, with a real default music route but no formal level ambience. The source defaults and actual metadata agree. This result does not prove every production soundscape fails, nor excuse the measured failure.

`MeleeHum` uses fixed `BASE_DB=-12`, loads `SoundBank.variants()` directly and does not apply `SoundBank.volume_db()`. Sfx and Ambience do apply that public bank gain. Changing just an idle bank entry therefore cannot be claimed to fix the hum. No such change has been made. Evidence supports first separating the synthetic no-ambience / music-transition case from a specified production soundscape, or reviewing the common music-crossfade/hum balance contract; it does not support blindly lowering all hums or raising the background to pass.

## Recompute

Use the stage5 exact `tools/audio` sources in the existing validation tree, or their source bundle:

```powershell
python verify_holds.py runs/1794471276726598400-holds --audio-tools <stage5-tools/audio> --out hold-result-v1.json
python verify_holds.py runs/1794472002092308000-holds --audio-tools <stage5-tools/audio> --out hold-result-v2-metadata.json
python verify_equivalence.py
python test_reader.py
```

The two hold reader commands must return **1** with precisely the actual maul idle bed problem. Content checks and 19 offline rejection controls are separate passing scopes, not a green loudness result. Synthetic positive metric fixtures only exercise unchanged limits; they are not captured audio.

Preserved failures include the original observer idle-state mismatch and its corrected state-preserving A/B; the initial reader's incorrect two-pass assumption (15 calls / two damages actually occurred); unresolved event alias and delayed-layer assumptions before the reader correctly resolved published event data. These are tool failures, not missing game layers, and no raw data were edited.

The first fresh extraction also correctly failed on default Windows cp950 because supplemental readers omitted explicit JSON UTF-8. Source bundle v1 and that real log are retained; v2 only adds explicit UTF-8 in those readers. No capture, runtime or threshold changed, and recomputation must work without an undocumented `-X utf8` prerequisite.

No new assets, downloads, licences or human listening are claimed. Historical user listening and old original24 retain their original scope. NE261 remains blocked from whole-ticket completion by this actual supplementary balance failure until its intended production/transition contract is resolved.
