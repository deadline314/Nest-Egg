import hashlib,json,pathlib,shutil,zipfile
HERE=pathlib.Path(__file__).resolve().parent
WT=pathlib.Path('C:/Users/stanl/.codex/worktrees/ne261-audio-validation-20261112/Nest-Egg')
OUT=HERE/'delivery';OUT.mkdir(exist_ok=True)
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def archive(path,items):
    assert not path.exists(),path
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for source,name in items:z.write(source,name)
    with zipfile.ZipFile(path) as z:assert z.testzip() is None
    return {'path':path.name,'bytes':path.stat().st_size,'sha256':sha(path)}
raw=[]
for run in sorted((HERE/'runs').iterdir()):
    if not run.is_dir():continue
    files=sorted(p for p in run.rglob('*') if p.is_file())
    path=OUT/(run.name+'-raw.zip')
    row=archive(path,[(p,p.relative_to(HERE).as_posix()) for p in files]);row['members']=len(files)
    receipt=json.loads((run/'exit.json').read_text())
    row['engine_exit']=receipt['exit_code'];row['expected_scope']='preserved observer-state RED' if receipt['exit_code'] else 'functional process only; full hold loudness RED if kind=holds'
    raw.append(row)
canonical=HERE/'canonical-audio-tools'
canonical.mkdir(exist_ok=True)
for name in ('melee_pcm_reader.py','melee_sound_report.py'):
    shutil.copyfile(WT/'tools/audio'/name,canonical/name)
names=['README.md','audit_melee.gd','probe.gd','probe-v1-original-hold-red.gd','probe.tscn','run.py','verify_holds.py','verify_holds-v0-unresolved-event-layers.py','verify_equivalence.py','verify_equivalence-v0-wrong-pass-count.py','test_reader.py','package.py','reader-controls.json','equivalence-result.json','hold-result-v1.json','hold-result-v2-metadata.json','hold-reader-original.log','hold-reader-metadata.log','idle-cause-pcm-v1.json','cause-source-manifest.json']
files=[HERE/n for n in names]+sorted(p for root in (HERE/'cause-source',canonical) for p in root.rglob('*') if p.is_file())
source=archive(OUT/'source-and-review.zip',[(p,p.relative_to(HERE).as_posix()) for p in files])
index={'schema':'ne261-hold-supplement-delivery-v1','accepted':False,'raw':raw,'source':source,'files':{p.relative_to(HERE).as_posix():sha(p) for p in files},'recompute':['Extract source-and-review.zip and each raw ZIP to the same folder.','python verify_equivalence.py (expect exit0)','python test_reader.py (expect19checks0failures)','python verify_holds.py runs/1794471276726598400-holds --audio-tools canonical-audio-tools (expect exit1: original maul idle-bed)','python verify_holds.py runs/1794472002092308000-holds --audio-tools canonical-audio-tools (expect exit1: metadata replay maul idle-bed)'],'scope':'All original epochs retained, immutable published896 plus canonical7, software input/headless WASAPI, actual PCM and action content. No C26, renderer, human hearing, physical controller or performance claim.'}
(OUT/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({k:index[k] for k in ('accepted','raw','source')},indent=2))
