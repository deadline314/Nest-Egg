import argparse,hashlib,json,os,pathlib,re,shutil,subprocess,sys,time,zipfile
HERE=pathlib.Path(__file__).resolve().parent
WT=pathlib.Path('C:/Users/stanl/.codex/worktrees/ne261-audio-validation-20261112/Nest-Egg')
LEAF=WT/'work/ne261-published-hold'
BASE='896d3e8a7fb1b0018df0aec47ed8c5a37bb881c0'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
def snapshot():
    names=json.loads((WT/'work/ne261-official-stage5/source-after.json').read_text())
    return {n:sha(WT/n) for n in names}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--kind',choices=['parse','equivalence-original','equivalence-observer','holds'],default='parse');args=ap.parse_args()
    assert subprocess.run(['git','rev-parse','HEAD'],cwd=WT,capture_output=True,check=True).stdout.decode().strip()==BASE
    before=snapshot();LEAF.mkdir(exist_ok=True)
    own={}
    for name in ['audit_melee.gd','probe.gd','probe.tscn']:
        shutil.copyfile(HERE/name,LEAF/name);own[name]=sha(HERE/name)
    out=HERE/'runs'/(str(time.time_ns())+'-'+args.kind);out.mkdir(parents=True)
    with zipfile.ZipFile(out/'executed-leaf.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for name in own:z.write(HERE/name,name)
        z.write(pathlib.Path(__file__),'run.py')
    selected=['game/melee/melee_module.gd','game/player/melee_command_input.gd','data/feel/sound_events.json','data/feel/materials.json']
    selected+=['data/melee/'+name+'.json' for name in ['thermal_blade','mono_dagger','ion_glaive','hydraulic_maul','mono_whip']]
    for name in selected:
        target=out/'published-inputs'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WT/name,target)
    env=os.environ.copy();env['APPDATA']=str(out/'appdata');env['LOCALAPPDATA']=str(out/'localappdata')
    command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(WT),'--display-driver','headless','--audio-driver','WASAPI','res://work/ne261-published-hold/probe.tscn','--','--out='+str(out/'recording'),'--kind='+args.kind]
    save(out/'command.json',{'argv':command,'cwd':str(WT),'kind':args.kind,'base':BASE,'source_before':before,'leaf_before':own,'instrumentation':'Published MeleeModule subclass logs only; exact once super.hit_pass(void) and start_hold(bool), no extra hit query or phase/data mutation. Public Input.action_press/release.','runner_sha256':sha(pathlib.Path(__file__))})
    t=time.monotonic()
    with (out/'engine.log').open('wb') as log:
        try:p=subprocess.run(command,cwd=WT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240 if args.kind=='holds' else 40)
        except subprocess.TimeoutExpired:save(out/'timeout.json',{'timed_out':True});raise
    text=(out/'engine.log').read_text(encoding='utf8',errors='replace').replace('\r','')
    after=snapshot();own_after={n:sha(LEAF/n) for n in own}
    diagnostics=[l for l in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|WARNING:',l)]
    runtime=[json.loads(l.split(' ',1)[1]) for l in text.splitlines() if l.startswith('NE261_HOLD_RUNTIME ')]
    runtime_ok=len(runtime)==1 and runtime[0]['audio_driver']=='WASAPI' and runtime[0]['display']=='headless' and runtime[0]['adapter']=='' and runtime[0]['rendering_device_null']
    gpu=bool(re.search(r'Vulkan.*(?:API|Device)|Using Device|OpenGL.*Renderer',text,re.I))
    result={'exit_code':p.returncode,'seconds':time.monotonic()-t,'source_unchanged':before==after and own==own_after,'source_after':after,'leaf_after':own_after,'diagnostic_lines':diagnostics,'gpu_log_rejected':gpu,'runtime_ok':runtime_ok,'runtime':runtime,'kind':args.kind,'scope':'Published896+final7 only; RAM observer explicitly instrumented; no C26/WIP, GPU/performance/human/gamepad claim.'}
    save(out/'exit.json',result)
    if (out/'recording').is_dir():save(out/'recording/exit.json',result)
    print(out);print(text);print(json.dumps({k:v for k,v in result.items() if k not in ('source_after','leaf_after')},indent=2))
    return 0 if p.returncode==0 and result['source_unchanged'] and not diagnostics and runtime_ok and not gpu else 1
if __name__=='__main__':raise SystemExit(main())
