import json,pathlib
HERE=pathlib.Path(__file__).resolve().parent
A=HERE/'runs/1794470800081490100-equivalence-original'
B=HERE/'runs/1794470901349902000-equivalence-observer'
def normalized(root):
    receipt=json.loads((root/'exit.json').read_text());command=json.loads((root/'command.json').read_text())
    assert receipt['exit_code']==0 and not receipt['diagnostic_lines'] and receipt['source_unchanged'] and receipt['runtime_ok'] and not receipt['gpu_log_rejected']
    assert command['source_before']==receipt['source_after']
    data=json.loads((root/'recording/equivalence.json').read_text());assert data['failures']==0
    result={'inputs':[(e['pressed'],e['actual']) for e in data['inputs']],'rows':[]}
    for row in data['rows']:
        result['rows'].append({'part':row['part'],'health_delta':row['start_state']['target']['health']-row['end_state']['target']['health'],
            'damage':[(e['source'],e['amount'],e['weak'],e['state']['attack'],e['state']['charged']) for e in row['damage']],
            'confirmed':len(row['confirmed']),
            'weapon_material_calls':[e['id'] for e in row['sounds'] if e['id'].startswith('melee_blade_') or e['id']=='mat_armor']})
    return result,data,command
a,_,ac=normalized(A);b,data,bc=normalized(B)
assert ac['leaf_before']==bc['leaf_before'],'controller/observer source not same epoch'
assert a==b,('published/observer actual behavior differs',a,b)
assert data['installer'][0]['equal'] and data['installer'][-1]['uninstalled_idle']
assert a['inputs']==[(True,True),(False,False)]
assert [r['health_delta'] for r in a['rows']]==[2,7]
assert len(data['passes'])==2 and all('after' in p for p in data['passes'])
result={'accepted':True,'same_source_epoch':True,'necessary_state_equal':True,'installed_uninstalled_idle':True,'actual_public_inputs_damage_material_weapon_events_equal':a,'not_audio_byte_equality':True,'scope':'Short original published module versus observation-only subclass, each one natural blade public hold/release. Not proof of five-weapon loudness.'}
(HERE/'equivalence-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(result,indent=2))
