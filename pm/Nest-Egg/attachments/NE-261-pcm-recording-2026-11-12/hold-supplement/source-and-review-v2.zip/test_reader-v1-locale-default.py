"""Bounded pure-CPU rejection controls; never edits raw recordings."""
import copy, importlib.util, json, pathlib, sys
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('hold_reader',HERE/'verify_holds.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
run=HERE/'runs/1794471276726598400-holds'
j=json.loads((run/'recording/hold-index.json').read_text())
inputs={w:json.loads((run/'published-inputs/data/melee'/f'{f}.json').read_text()) for w,f in v.WEAPONS.items()}
events=json.loads((run/'published-inputs/data/feel/sound_events.json').read_text())['events']
results=[]
def reject(label,change):
    x=copy.deepcopy(j);change(x)
    try:v.check_content(x,inputs,events)
    except (AssertionError,KeyError,IndexError) as e:results.append({'control':label,'rejected':True,'diagnostic':str(e)});return
    raise AssertionError('false acceptance: '+label)
v.check_content(j,inputs,events);results.append({'control':'actual34row10hold32damage content','accepted':True})
reject('no actual public release',lambda x:x['inputs'][13].update(actual=True))
reject('hold not entered',lambda x:x['hold_segments'][6]['start_state'].update(hold_mode=''))
reject('missing charge full',lambda x:x['passes'][7]['before'].update(charged=False))
reject('missing repeated cycles',lambda x:x['hold_segments'][12].update(hold_starts=[]))
reject('zero-space target',lambda x:x['hold_segments'][8]['start_state']['target'].update(area_space=0))
reject('wrong damage source',lambda x:x['hold_segments'][8]['damage'][0].update(source='test'))
reject('health delta does not match callback',lambda x:x['hold_segments'][8]['end_state']['target'].update(health=1))
reject('false hit in miss',lambda x:x['hold_segments'][6]['sounds'].append({'id':'melee_blade_hit'}))
reject('missing actual material layer',lambda x:x['passes'][22].update(sounds=[e for e in x['passes'][22]['sounds'] if e['id']!='mat_armor']))
reject('hold sample boundary exceeds real PCM',lambda x:x['hold_segments'][6]['end_frames'].update({n:99999999 for n in x['sample_clock']['buses']}))
reject('hum remains after holster',lambda x:x['hold_segments'][9]['end_state'].update(hum='melee_blade_idle'))
actual=json.loads((HERE/'hold-result-v1.json').read_text());assert len(actual['problems'])==1 and actual['problems'][0]['weapon']=='maul'
results.append({'control':'actual original full-hold maul idle bed failure','rejected':True,'diagnostic':actual['problems'][0]})
rows=copy.deepcopy(actual['rows'])
for r in rows:
    if r['weapon']=='ref':r['loud']=-20
    else:r.update(floor=-60,bed=-30,loud=-40)
    if r['part']=='holster':r['floor']=-120
assert not v.limits(rows);results.append({'control':'synthetic metric positive with original limits','accepted':True})
for label,part,fields in [('hold louder than pistol','hold_miss',{'loud':-19.999}),('hum less than6dB below steps','idle',{'floor':-25.999}),('hum less than10dB belowbed','idle',{'floor':-39.999}),('hum below original audibility bound','idle',{'floor':-75.001}),('holster remains audible','holster',{'floor':-30})]:
    x=copy.deepcopy(rows);next(r for r in x if r['weapon']=='blade' and r['part']==part).update(fields)
    assert v.limits(x),label
    results.append({'control':label,'rejected':True})
result={'checks':len(results),'failures':0,'scope':'Read-only index/content and original threshold rejection controls; actual loudness recording remains RED, no synthetic metric is presented as captured game audio.','results':results}
(HERE/'reader-controls.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(result,indent=2))
