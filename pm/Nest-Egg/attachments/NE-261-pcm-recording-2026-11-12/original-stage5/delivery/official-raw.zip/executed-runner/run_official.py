import hashlib,json,os,pathlib,shutil,subprocess,sys,time
HERE=pathlib.Path(__file__).resolve().parent
WT=pathlib.Path('C:/Users/stanl/.codex/worktrees/ne261-audio-validation-20261112/Nest-Egg')
OLD=WT/'work/ne261-official-v2/uid-context-followup';OUT=WT/'work/ne261-official-stage5'
assert not OUT.exists();OUT.mkdir()
BASE='896d3e8a7fb1b0018df0aec47ed8c5a37bb881c0'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
previous=json.loads((OLD/'source-after.json').read_text())
for name,digest in previous.items():assert sha(WT/name)==digest,('existing validation tree drift',name)
clock='tools/audio/melee_pcm_clock.gd'
shutil.copyfile(WT/clock,OUT/'previous-clock-original.bin');shutil.copyfile(HERE/clock,WT/clock)
manifest=json.loads((HERE/'canonical-7-manifest.json').read_text())
for name,row in (manifest['source_files']|manifest['metadata_files']).items():assert sha(WT/name)==row['sha256'],name
save(OUT/'candidate-7.json',manifest)
def snapshot():return {name:sha(WT/name) for name in previous}
before=snapshot();save(OUT/'source-before.json',before)
env=os.environ.copy();env.update({'GODOT':'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','SHARDS':'4','LOG_DIR':(OUT/'logs').as_posix(),'APPDATA':str(OUT/'user'),'LOCALAPPDATA':str(OUT/'user'),'PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
commands=[]
for label,argv in [('selector',[sys.executable,'tools/select_tests.py','--base',BASE]),('changed',['C:/Program Files/Git/bin/bash.exe','tools/run_tests_changed.sh',BASE])]:
    t=time.monotonic();p=subprocess.run(argv,cwd=WT,env=env,capture_output=True)
    (OUT/(label+'-stdout.log')).write_bytes(p.stdout);(OUT/(label+'-stderr.log')).write_bytes(p.stderr)
    commands.append({'label':label,'argv':argv,'cwd':str(WT),'exit':p.returncode,'seconds':time.monotonic()-t})
    assert p.returncode==0,(label,p.stderr)
after=snapshot();save(OUT/'source-after.json',after);assert before==after
assert (OUT/'selector-stdout.log').read_bytes().strip()==b''
assert not any('SCRIPT ERROR' in p.read_text(encoding='utf8',errors='replace') for p in OUT.glob('*.log'))
save(OUT/'result.json',{'base':BASE,'source_count':len(after),'source_unchanged':True,'only_overlay_from_previous':'tools/audio/melee_pcm_clock.gd','no_reimport':True,'actual_import_uid_metadata_reused':True,'selected_group_count':0,'suite_checks_not_run':True,'script_errors':0,'commands':commands,'scope':'Original changed script/selector unchanged, only final7 candidate on published896; no C WIP/BG4 overlay.'})
print((OUT/'result.json').read_text())
