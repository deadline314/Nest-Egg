"""Deploy only own new D leaf; actual project headless audio, never renderer."""
import argparse,hashlib,json,os,pathlib,queue,re,subprocess,threading,time,zipfile
HERE=pathlib.Path(__file__).resolve().parent
REVIEW=HERE.parent.parent
D=pathlib.Path('D:/NestEggVerification/bg42-published-8c788e7c-20261112')
LEAF=D/'work/ne261-stage5-producer'
GODOT=pathlib.Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
def sha(data):return hashlib.sha256(data).hexdigest()
def save(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
def context():
    names=list(json.loads((REVIEW/'stage3-context.json').read_text(encoding='utf8'))['files'])
    audio=json.loads((REVIEW/'source-index.json').read_text(encoding='utf8'))['files']['published']
    names+= [n for n in audio if n.startswith('audio/')]
    return {n:sha((D/n).read_bytes()) for n in sorted(set(names))}
def deploy():
    mappings={}
    files=list((HERE/'tools').rglob('*'))+[HERE/'fixture.gd',HERE/'fixture.tscn',HERE/'hit_control.gd',HERE/'hit_control.tscn']
    replacements={
      'res://tools/audio/melee_pcm_clock.gd':'res://work/ne261-stage5-producer/tools/audio/melee_pcm_clock.gd',
      'res://tools/audio/melee_sound_content.gd':'res://work/ne261-stage5-producer/tools/audio/melee_sound_content.gd',
      'res://tools/melee_sound_probe.gd':'res://work/ne261-stage5-producer/tools/melee_sound_probe.gd',
      'res://fixture.gd':'res://work/ne261-stage5-producer/fixture.gd',
      'res://hit_control.gd':'res://work/ne261-stage5-producer/hit_control.gd'}
    for source in files:
        if not source.is_file() or source.suffix not in ('.gd','.tscn','.py'):continue
        rel=source.relative_to(HERE);target=LEAF/rel
        assert target.resolve().is_relative_to(LEAF.resolve())
        raw=source.read_bytes();text=raw.decode('utf8');changes={}
        for old,new in replacements.items():
            count=text.count(old)
            if count:text=text.replace(old,new);changes[old]={'replacement':new,'count':count}
        actual=text.encode('utf8');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(actual)
        mappings[rel.as_posix()]={'canonical_sha256':sha(raw),'deployed_sha256':sha(actual),'target':str(target),'only_path_replacements':changes}
    return mappings
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['parser','normal','cancel-active','release-active','overflow','capture-file-fault','wav-file-fault','legacy-file-fault','index-file-fault','mkdir-fault','hit-culling-on','hit-culling-off','game'],default='parser');args=ap.parse_args()
    mappings=deploy();before=context()
    out=HERE/'runs'/str(time.time_ns());out.mkdir(parents=True)
    with zipfile.ZipFile(out/'executed-leaf-source.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,row in mappings.items():
            z.writestr('canonical/'+name,(HERE/name).read_bytes())
            z.writestr('deployed/'+name,pathlib.Path(row['target']).read_bytes())
        z.writestr('run.py',pathlib.Path(__file__).read_bytes())
    recording=out/'recording'
    if args.mode=='mkdir-fault':recording.write_text('intentional own-leaf file blocking directory',encoding='utf8')
    env=os.environ.copy();env['APPDATA']=str(out/'appdata');env['LOCALAPPDATA']=str(out/'localappdata')
    scene='tools/melee_sound_probe.tscn' if args.mode in ('parser','game','mkdir-fault') else 'fixture.tscn'
    if args.mode.startswith('hit-culling'):scene='hit_control.tscn'
    cmd=[str(GODOT),'--path',str(D),'--display-driver','headless','--audio-driver','WASAPI','res://work/ne261-stage5-producer/'+scene,'--','--out='+str(recording)]
    if args.mode=='parser':cmd.append('--parser-only')
    if args.mode not in ('parser','game'):cmd.append('--mode='+args.mode)
    save(out/'command.json',{'argv':cmd,'mode':args.mode,'APPDATA':env['APPDATA'],'LOCALAPPDATA':env['LOCALAPPDATA'],'mapping':mappings,'source_before':before,'runner_sha256':sha(pathlib.Path(__file__).read_bytes()),'runtime_epoch':'published8c788e7c plus owned stage5 tools only; explicit a4 differences in stage3-context.json'})
    proc=subprocess.Popen(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    q=queue.Queue()
    def read():
        for line in proc.stdout:q.put(line)
        q.put(None)
    threading.Thread(target=read,daemon=True).start();lines=[];gpu=False;deadline=time.monotonic()+(240 if args.mode=='game' else 45 if args.mode.startswith('hit-culling') else 25)
    timed_out=False
    while True:
        if time.monotonic()>deadline:proc.kill();timed_out=True;break
        try:line=q.get(timeout=.1)
        except queue.Empty:continue
        if line is None:break
        lines.append(line)
        if re.search(rb'(Vulkan.*(?:API|Device)|Using Device|OpenGL.*Renderer)',line,re.I):gpu=True;proc.kill()
    code=proc.wait(timeout=5);text=b''.join(lines).decode('utf8','replace')
    (out/'engine.log').write_bytes(b''.join(lines));after=context()
    stable=before==after and all(sha(pathlib.Path(v['target']).read_bytes())==v['deployed_sha256'] for v in mappings.values())
    runtime_rows=[]
    for line in text.splitlines():
        if line.startswith(('NE261_STAGE5_RUNTIME ','NE261_GAME_RUNTIME ')):runtime_rows.append(json.loads(line.split(' ',1)[1]))
    runtime_ok=len(runtime_rows)==1 and all(r['display']=='headless' and r['audio_driver']=='WASAPI' and r['adapter']=='' and r['rendering_device_null'] for r in runtime_rows)
    diagnostics=[l for l in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|WARNING:',l)]
    receipt={'exit_code':code,'gpu_log_rejected':gpu,'timed_out':timed_out,'source_unchanged':stable,'source_after':after,'diagnostic_lines':diagnostics,'runtime_ok':runtime_ok,'runtime':runtime_rows,'mode':args.mode}
    save(out/'exit.json',receipt)
    if recording.is_dir():save(recording/'exit.json',receipt)
    print(out);print(text);print(json.dumps({k:v for k,v in receipt.items() if k!='source_after'},indent=2))
    return 0 if code==0 and stable and runtime_ok and not diagnostics and not gpu and not timed_out else 1
if __name__=='__main__':raise SystemExit(main())
