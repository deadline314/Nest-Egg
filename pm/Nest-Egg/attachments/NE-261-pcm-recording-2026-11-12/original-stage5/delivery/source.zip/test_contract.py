import ast,importlib.util,json,pathlib,re,shutil,tempfile,unittest
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('capture_pcm_reader',HERE/'tools/audio/melee_pcm_reader.py');pcm=importlib.util.module_from_spec(spec);spec.loader.exec_module(pcm)
NORMAL=HERE.parent/'stage4/runs/1794463651899937100/recording'
GAME=HERE.parent/'stage4/runs/1794465467858097800/recording'

class Contract(unittest.TestCase):
    def data(self):return json.loads((NORMAL/'melee-index.json').read_text())
    def test_actual_capture_pcm(self):self.assertEqual(len(pcm.load(NORMAL,self.data())[1]),4)
    def reject(self,change):
        data=self.data();change(data)
        with self.assertRaises(AssertionError):pcm.load(NORMAL,data)
    def test_legacy_explained(self):
        with self.assertRaisesRegex(AssertionError,'Legacy/Record/wall-time'):pcm.load(NORMAL,{'segments':[]})
    def test_wrong_schema(self):self.reject(lambda d:d['sample_clock'].__setitem__('schema','Record-v0'))
    def test_oob(self):self.reject(lambda d:d['segments'][0]['bus_end_frames'].__setitem__('SFX',99999999))
    def test_noninteger(self):self.reject(lambda d:d['segments'][0]['bus_start_frames'].__setitem__('SFX',0.0))
    def test_wrong_bus_epoch(self):self.reject(lambda d:d['segments'][0]['bus_start_frames'].__setitem__('Music',512))
    def test_dropped(self):self.reject(lambda d:d['sample_clock']['buses']['SFX']['end'].__setitem__('discarded',512))
    def test_capture_not_stopped(self):self.reject(lambda d:d['sample_clock']['buses']['SFX']['after_save_counter'].__setitem__('pushed',999999))
    def test_gain_changed(self):self.reject(lambda d:d['sample_clock']['buses']['SFX']['gain_observations'][1].__setitem__('gain_db',-5))
    def test_no_per_process_allocations(self):
        for bus in self.data()['sample_clock']['buses'].values():
            self.assertEqual([x['kind'] for x in bus['gain_observations']],['first','last'])
            self.assertGreater(bus['gain_check_count'],2)
    def test_dummy_reject(self):self.reject(lambda d:d['runtime'].__setitem__('audio_driver','Dummy'))
    def test_empty_reject(self):self.reject(lambda d:d['runtime'].__setitem__('audio_driver',''))
    def test_cross_platform_metadata(self):
        # Reader portability only, not an actual Linux/ALSA playback claim.
        data=self.data();data['runtime']['audio_driver']='ALSA';self.assertEqual(len(pcm.load(NORMAL,data)[1]),4)
    def test_truncated_raw(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            target=pathlib.Path(temp)
            for source in NORMAL.iterdir():
                if source.is_file():shutil.copyfile(source,target/source.name)
            raw=target/'bus-SFX.f32';raw.write_bytes(raw.read_bytes()[:-8])
            with self.assertRaises(AssertionError):pcm.load(target,self.data())
    def test_plain_probe_without_wrapper_sidecar(self):
        with tempfile.TemporaryDirectory() as temp:
            target=pathlib.Path(temp)
            for source in NORMAL.iterdir():
                if source.is_file() and source.name!='exit.json':shutil.copyfile(source,target/source.name)
            self.assertEqual(len(pcm.load(target,self.data())[1]),4)
    def test_present_red_receipt_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            target=pathlib.Path(temp)
            for source in NORMAL.iterdir():
                if source.is_file():shutil.copyfile(source,target/source.name)
            receipt=json.loads((target/'exit.json').read_text());receipt['exit_code']=1
            (target/'exit.json').write_text(json.dumps(receipt),encoding='utf8')
            with self.assertRaises(AssertionError):pcm.load(target,self.data())
    def test_loudness_metric_ast(self):
        original=HERE.parents[1]/'source/published/tools/audio/melee_sound_report.py'
        a=ast.parse(original.read_text(encoding='utf8'));b=ast.parse((HERE/'tools/audio/melee_sound_report.py').read_text(encoding='utf8'))
        for name in ['db','levels','sheet']:
            x=next(n for n in a.body if isinstance(n,ast.FunctionDef) and n.name==name)
            y=next(n for n in b.body if isinstance(n,ast.FunctionDef) and n.name==name)
            self.assertEqual(ast.dump(x),ast.dump(y),name)
        for name in ['WINDOW','HUM_UNDER_STEPS_DB','HUM_UNDER_BED_DB']:
            get=lambda tree:next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
            self.assertEqual(ast.dump(get(a)),ast.dump(get(b)),name)
    def test_gameplay_methods_literal(self):
        original=(HERE.parents[1]/'source/published/tools/melee_sound_probe.gd').read_text(encoding='utf8')
        candidate=(HERE/'tools/melee_sound_probe.gd').read_text(encoding='utf8')
        def method(text,name):return re.search(r'(?ms)^func '+re.escape(name)+r'\(.*?(?=^func |\Z)',text).group().strip()
        for name in ['_combo','_target','_arm','_grant_extension','_heard','_seconds']:self.assertEqual(method(original,name),method(candidate,name),name)
        # Ordered actions/timers/inputs in the full scenario remain unchanged.
        pattern=r'(?m)^\s*(?:await )?(?:_arm|_combo|_target|_grant_extension|_seconds|settle|clear_enemies|Input\.action_press|Input\.action_release)\([^\n]*'
        self.assertEqual(re.findall(pattern,method(original,'_run')),re.findall(pattern,method(candidate,'_run')))

class ActionContract(unittest.TestCase):
    def data(self):return json.loads((GAME/'melee-index.json').read_text())
    def segment(self,data,weapon,part):return next(s for s in data['segments'] if (s['weapon'],s['part'])==(weapon,part))
    def reject(self,change):
        data=self.data();change(data)
        with self.assertRaises(AssertionError):pcm.verify_content(data)
    def test_true_actions(self):self.assertEqual(pcm.verify_content(self.data())['actual_damage_events'],18)
    def test_label_only_old_report_rejected(self):
        path=GAME.parent.parent/'1794463939585195400/recording/melee-index.json'
        with self.assertRaisesRegex(AssertionError,'labels alone'):pcm.verify_content(json.loads(path.read_text()))
    def test_zero_space(self):self.reject(lambda d:self.segment(d,'blade','combo_hit')['content']['targets_start'][0]['spaces'][0].__setitem__('space',0))
    def test_no_true_damage(self):self.reject(lambda d:self.segment(d,'blade','combo_hit')['content'].__setitem__('damage',[]))
    def test_wrong_source(self):self.reject(lambda d:self.segment(d,'ref','pistol_hit')['content']['damage'][0].__setitem__('source_id','synthetic'))
    def test_fake_maul_hit_layer(self):
        def mutate(data):
            calls=self.segment(data,'maul','combo_hit')['content']['audio_calls'];call=next(e for e in calls if e['id']=='melee_maul_swing_heavy');call['id']='melee_maul_hit_heavy'
        self.reject(mutate)
    def test_already_landed_swing(self):
        def mutate(data):
            calls=self.segment(data,'maul','combo_hit')['content']['audio_calls'];next(e for e in calls if e['id']=='melee_maul_swing_heavy')['pose']['landed']=True
        self.reject(mutate)
    def test_material_missing(self):self.reject(lambda d:self.segment(d,'glaive','combo_hit').__setitem__('sounds',[]))
    def test_holster_cross_next_arm(self):self.reject(lambda d:self.segment(d,'blade','holster')['content'].__setitem__('hum_end','melee_dagger_idle'))
    def test_miss_falsely_hit(self):self.reject(lambda d:self.segment(d,'blade','combo_miss')['content'].__setitem__('hit_confirmed',[{'fake':True}]))
    def test_stale_boundary(self):self.reject(lambda d:self.segment(d,'whip','holster')['content']['sample_end_frames'].__setitem__('SFX',999999999))

if __name__=='__main__':unittest.main()
