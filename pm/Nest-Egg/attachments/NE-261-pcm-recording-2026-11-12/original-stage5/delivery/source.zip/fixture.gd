extends Node
const Clock := preload("res://tools/audio/melee_pcm_clock.gd")
var clock
var out := ""
var mode := "normal"
var players: Array[AudioStreamPlayer] = []
var errors: Array[String] = []

func check(ok: bool, label: String) -> void:
	if not ok:errors.append(label);push_error("[NE261ClockRegression] " + label)

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
		if arg.begins_with("--mode="):mode=arg.trim_prefix("--mode=")
	_run.call_deferred()

func _run() -> void:
	var runtime := {"display":DisplayServer.get_name(),"audio_driver":AudioServer.get_driver_name(),"adapter":RenderingServer.get_video_adapter_name(),"rendering_device_null":RenderingServer.get_rendering_device()==null}
	print("NE261_STAGE5_RUNTIME " + JSON.stringify(runtime))
	check(runtime["display"]=="headless" and runtime["audio_driver"]=="WASAPI" and runtime["adapter"]=="" and runtime["rendering_device_null"],"local actual headless/WASAPI/dummy-rendering")
	if not errors.is_empty():get_tree().quit(2);return
	var mkdir := DirAccess.make_dir_recursive_absolute(out)
	if mkdir != OK:
		push_error("[NE261ClockRegression] mkdir path=%s error=%s" % [out,error_string(mkdir)])
		get_tree().quit(2);return
	AudioServer.set_bus_volume_db(0,-80.0)
	clock=Clock.new()
	add_child(clock)
	var baseline := {}
	for name in Clock.NAMES:
		var index := AudioServer.get_bus_index(name)
		check(index>=0,"existing game bus " + name)
		baseline[name]=[]
		for n in AudioServer.get_bus_effect_count(index):baseline[name].append(AudioServer.get_bus_effect(index,n).get_instance_id())
	for name in ["SFX","Music","Ambience"]:
		var rate := int(AudioServer.get_mix_rate())
		var bytes := PackedByteArray();bytes.resize(rate*4)
		for frame in rate:
			var value := int(sin(TAU*(330.0+players.size()*110.0)*frame/rate)*160.0)
			bytes.encode_s16(frame*4,value);bytes.encode_s16(frame*4+2,value)
		var stream := AudioStreamWAV.new()
		stream.format=AudioStreamWAV.FORMAT_16_BITS;stream.stereo=true;stream.mix_rate=rate;stream.data=bytes;stream.loop_mode=AudioStreamWAV.LOOP_FORWARD;stream.loop_end=rate
		var player := AudioStreamPlayer.new();player.stream=stream;player.bus=name;add_child(player);players.append(player);player.play()
	if mode=="overflow":clock.buffer_seconds=.02
	if not clock.attach():clock.cleanup();get_tree().quit(1);return
	# Same class as one owned effect, added after attach and before recording.
	var foreign := AudioEffectCapture.new()
	AudioServer.add_bus_effect(0,foreign,0)
	if not await clock.start():clock.cleanup();get_tree().quit(1);return
	if mode=="overflow":clock.set_process(false)
	var started := Time.get_ticks_usec()
	while Time.get_ticks_usec()-started<2000000:await get_tree().process_frame
	var stopped := {}
	if mode not in ["cancel-active","release-active"]:stopped=clock.stop()
	for player in players:player.stop()
	var result := {}
	if mode not in ["cancel-active","release-active"]:
		if mode=="capture-file-fault":DirAccess.make_dir_absolute(out.path_join("bus-SFX.f32"))
		if mode=="wav-file-fault":DirAccess.make_dir_absolute(out.path_join("bus-SFX.wav"))
		if mode=="legacy-file-fault":DirAccess.make_dir_absolute(out.path_join("melee-master.wav"))
		result=await clock.save(out,stopped)
	var clock_problems: Array = clock.problems.duplicate()
	var cleanup := {}
	if mode=="release-active":
		clock.free()
		cleanup={"released_active":true}
		check(not is_instance_valid(clock),"release active helper executes exit-tree cleanup")
	else:
		cleanup=clock.cleanup()
		check(not clock.active and cleanup["removed"]==4,"stop/remove exactly four owned effects")
		check(clock.cleanup()=={"already_cleaned":true,"removed":0},"cleanup is idempotent")
	var expected: Array = baseline["Master"].duplicate();expected.append(foreign.get_instance_id());expected.sort()
	var actual: Array=[]
	for n in AudioServer.get_bus_effect_count(0):actual.append(AudioServer.get_bus_effect(0,n).get_instance_id())
	actual.sort();check(expected==actual,"keep all original and newly inserted foreign effects by identity")
	for name in ["SFX","Music","Ambience"]:
		var got: Array=[];var index:=AudioServer.get_bus_index(name)
		for n in AudioServer.get_bus_effect_count(index):got.append(AudioServer.get_bus_effect(index,n).get_instance_id())
		check(got==baseline[name],"restore own effects only bus=" + name)
	var file_name := "control.json" if mode in ["cancel-active","release-active"] else "melee-index.json"
	if mode=="index-file-fault":DirAccess.make_dir_absolute(out.path_join(file_name))
	var writer := FileAccess.open(out.path_join(file_name),FileAccess.WRITE)
	if writer == null:
		push_error("[NE261ClockRegression] index open path=%s error=%s" % [out.path_join(file_name),error_string(FileAccess.get_open_error())])
		get_tree().quit(1);return
	result["cleanup"]=cleanup
	writer.store_string(JSON.stringify({"runtime":runtime,"sample_clock":result,"segments":[{"weapon":"synthetic","part":"two_seconds","bus_start_frames":{"Master":0,"SFX":0,"Music":0,"Ambience":0},"bus_end_frames":stopped.get("frames",{})}],"fixture_errors":errors,"mode":mode},"  "))
	writer.flush();var write_error:=writer.get_error();writer.close()
	check(write_error==OK,"index write path=" + out.path_join(file_name))
	print("NE261_STAGE5_DONE errors=%d clock_problems=%d" % [errors.size(),clock_problems.size()])
	get_tree().quit(0 if errors.is_empty() and clock_problems.is_empty() else 1)
