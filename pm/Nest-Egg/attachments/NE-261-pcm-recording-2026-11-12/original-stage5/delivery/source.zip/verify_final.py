"""Frozen stage5 only: legacy aliases, exact PCM/actions and old loudness rules."""
import hashlib,importlib.util,json,pathlib,subprocess,sys
HERE=pathlib.Path(__file__).resolve().parent
RUN=HERE/'runs/1794468251143191900';FAULT=HERE/'runs/1794468143021993100'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def aliases(folder):
    index=json.loads((folder/'melee-index.json').read_text())
    result={}
    for bus,name in [('Master','melee-master.wav'),('SFX','melee-sfx.wav')]:
        row=index['sample_clock']['buses'][bus]
        assert row['legacy_copy_attempted'] and row['legacy_file']==name and row['legacy_copy_error']==0,('legacy copy rejected',bus)
        assert (folder/name).is_file() and sha(folder/name)==sha(folder/('bus-'+bus+'.wav')),('legacy WAV not byte-exact',bus)
        result[name]={'sha256':sha(folder/name),'bytes':(folder/name).stat().st_size,'byte_exact':True}
    return result
positive=aliases(RUN/'recording')
fault=json.loads((FAULT/'exit.json').read_text());data=json.loads((FAULT/'recording/melee-index.json').read_text())
assert fault['exit_code']!=0 and fault['source_unchanged'] and not fault['gpu_log_rejected'] and not fault['timed_out']
assert (FAULT/'recording/melee-master.wav').is_dir() and data['sample_clock']['buses']['Master']['legacy_copy_error']!=0
assert any('legacy WAV copy failed' in line and 'source=' in line and 'target=' in line for line in fault['diagnostic_lines'])
try:aliases(FAULT/'recording')
except AssertionError:negative=True
else:raise AssertionError('legacy directory control accepted')
spec=importlib.util.spec_from_file_location('stage5_pcm',HERE/'tools/audio/melee_pcm_reader.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
receipt=json.loads((RUN/'exit.json').read_text());command=json.loads((RUN/'command.json').read_text())
assert receipt['exit_code']==0 and not receipt['diagnostic_lines'] and not receipt['timed_out'] and receipt['source_unchanged']
assert receipt['runtime_ok'] and command['source_before']==receipt['source_after']
rate,audio=reader.load(RUN/'recording',json.loads((RUN/'recording/melee-index.json').read_text()))
content=reader.verify_content(json.loads((RUN/'recording/melee-index.json').read_text()))
frames={n:len(row['raw_f32'])//8 for n,row in audio.items()};del audio
cmd=[sys.executable,'-X','utf8',str(HERE/'tools/audio/melee_sound_report.py'),str(RUN/'recording'),'--png',str(RUN/'waveforms.png')]
p=subprocess.run(cmd,capture_output=True);(RUN/'report-stdout.log').write_bytes(p.stdout);(RUN/'report-stderr.log').write_bytes(p.stderr)
result={'aliases':positive,'legacy_directory_negative_rejected':negative,'pcm_rate':rate,'pcm_frames':frames,'content':content,'report_argv':cmd,'report_exit':p.returncode,'reader_sha256':sha(HERE/'tools/audio/melee_pcm_reader.py'),'report_sha256':sha(HERE/'tools/audio/melee_sound_report.py'),'scope':'Single new actual published8c audio run; same four bus/clock/segments/metrics/limits. No C WIP, GPU, native-picture, performance or new listening claim.'}
(RUN/'validation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n')
print(p.stdout.decode('utf8','replace'));print(p.stderr.decode('utf8','replace'));print(json.dumps(result,indent=2))
raise SystemExit(p.returncode)
