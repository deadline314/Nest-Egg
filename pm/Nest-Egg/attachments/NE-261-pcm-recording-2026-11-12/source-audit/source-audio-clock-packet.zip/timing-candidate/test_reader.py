import json, pathlib, shutil, tempfile, unittest
from reader import verify, checked_slice

HERE=pathlib.Path(__file__).resolve().parent
NORMAL=HERE/'runs/1794461889919575400'

class Controls(unittest.TestCase):
    def test_real(self):self.assertEqual(len(verify(NORMAL)['buses']),2)
    def corrupt(self,change,file='result.json'):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            target=pathlib.Path(temp)
            for source in NORMAL.iterdir():
                if source.is_file():shutil.copyfile(source,target/source.name)
            data=json.loads((target/file).read_text());change(data)
            (target/file).write_text(json.dumps(data),encoding='utf8')
            with self.assertRaises(AssertionError):verify(target)
    def test_beyond_pcm(self):self.corrupt(lambda d:d['boundaries'][1]['buses']['Master'].__setitem__('pushed',10000000))
    def test_discarded(self):self.corrupt(lambda d:d['buses'][0]['end'].__setitem__('discarded',512))
    def test_bus_offset(self):self.corrupt(lambda d:d['boundaries'][1]['buses']['Master'].__setitem__('pushed',25088))
    def test_wrong_driver(self):self.corrupt(lambda d:d['runtime'].__setitem__('audio_driver','Dummy'))
    def test_end_after_save(self):self.corrupt(lambda d:d.__setitem__('record_stop_wall_usec',999999999))
    def test_truncated_pcm(self):
        with self.assertRaises(AssertionError):checked_slice(b'\x00'*12,0,4,3)
    def test_no_float_slice(self):
        with self.assertRaises(AssertionError):checked_slice(b'\x00'*12,0,2.5,3)

if __name__=='__main__':unittest.main()
