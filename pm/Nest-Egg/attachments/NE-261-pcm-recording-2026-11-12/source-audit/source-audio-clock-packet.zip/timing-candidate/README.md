# NE261 sample-clock candidate (isolated evidence, not product adoption)

Only this leaf is writable. No primary game/pm, protected D runtime, NE251,
NE262, NE27726 or private performance source was changed. All engines exited.
The real WASAPI output is intentionally quiet in these synthetic projects
(Master -80 dB); this is **not game-volume acceptance or human listening**.

## Executed stage 1

`python -X utf8 run.py` uses a private minimal project, isolated APPDATA and
`--display-driver headless --audio-driver WASAPI`. It never requests a GPU.
Runtime verifies display=headless, adapter empty, RenderingDevice=null and
actual AudioServer driver=WASAPI. The configured rendering-method string is
gl_compatibility; headless's actual rasterizer is dummy. Startup logs contain
no Vulkan/OpenGL-device initialization. Wrapper rejects GPU startup lines.

- Normal `runs/1794461889919575400`: producer 15/0, exit0, no diagnostics;
  Master and synthetic SFX each 95,744 frames at 48 kHz. Capture discarded0.
  Wall duration 2.000012 s; actual PCM duration 1.994666667 s. Do not use wall
  seconds as PCM slice coordinates.
- Per-sample independent reader converts each captured float exactly as
  Record's signed16 conversion and compares **every PCM byte**, then verifies
  all bus counter anchors and file bounds. Both buses exactly match.
- Tiny buffer `runs/1794461963648627400`: same project source, expected exit1,
  producer 15 checks/5 failures. Each Capture pushed delta0, discarded96,768,
  Capture PCM0; each independent Record contains96,768 frames. Thus overflow
  is real but **does not imply Record lost samples**. Reader rejects it.
  This buffer is smaller than a mixer block, so readiness also genuinely
  failed; that extra failure is retained, not relabelled as an ordinary run.
- `python -m unittest test_reader -v`: eight checks, including genuine bounds,
  wrong driver, per-bus offset, discarded frames and post-save end controls.

The source files' pre/post hashes are in each command/exit receipt. Original
normal/overflow receipts hashed project files, not the Python runner itself;
the delivered runner is the final snapshot (adds --helper project selection),
not falsely described as a pre-run hash of the earlier runner text.

## Narrow stage 2 candidate

`stage2/pcm_clock.gd` is a probe-only Node, without global class or autoload.
It records Master/SFX/Music/Ambience independently, drains actual Capture
buffers during process, stores pushed **and discarded** deltas, reads all
counter boundaries under AudioServer.lock and freezes final end before saves.
No audio sends, levels, limiter or game rules are modified. Constant gain and
direct-to-Master send observations are required; changed gain/send rejects.
Record length must equal pushed+discarded, and capture must have zero drops.
There is no padding/trim/fixed-delay flush claim. A process yield merely gives
the IO thread a scheduling opportunity; exact PCM/counter/sample equality
remains the acceptance test and missing Record tails remain red.

The exact helper was compiled/executed in a second **isolated two-second**
four-bus project, using three quiet synthetic loops:

- `runs/1794462282454514000`: counters/samples agreed, but six ObjectDB leaks
  at exit; wrapper rejected this run. It is retained as a genuine red.
- Corrected fixture stops its own three AudioStreamPlayers after frozen end.
  `runs/1794462301069536000`: exit0, no diagnostics, all four buses95,744
  frames; sample reader verifies every Record/Capture PCM byte. The helper
  source itself is byte-identical in both runs and stage2.
- `stage2/test_pcm.py`: ten tests pass, including exact four-bus data, genuine
  prior leak rejection, truncated float, nonaligned segment, drop, gain/send
  mutation, missing legacy metadata and preserved original metric formulas.

`build_stage2.py` mechanically derives `stage2/probe.gd` from the frozen
published original probe; `probe.diff` is the narrow review entry. It changes
the recorder/index source, not combat, target, reference or action sequencing.
`build_report.py` derives `stage2/report.py`; `report.diff` replaces wall-time
slices and invalid Master-minus-SFX subtraction. Existing db/levels/sheet
formulas and 6 dB/10 dB/-75 dB/-70 dB thresholds remain literally unchanged
(AST comparison test). The full game probe/report have **not been compiled or
executed/adopted**, so there is no new five-weapon loudness result.

Bed is measured directly from Music and Ambience after existing bus effects,
scaled by their stable observed gains into the SFX pre-gain measurement plane.
This is a **pre-Master balance measurement**; it is not a nonlinear
post-limiter contribution estimate. Master remains a separate listening mix.
The report requires independently recorded Music/Ambience, real per-bus sample
alignment and an accepted producer receipt. Absent/silent bed cannot be made
to pass by subtracting, padding, a noise floor or a different threshold.
Gain observations alone are not universal proof against an unobserved
sub-frame volume mutation; eventual game execution must keep settings fixed
and record relevant topology/source context. No generic bus framework added.

Next bounded step: on a Root-approved immutable published-only shadow, copy
only this leaf and run the full existing probe headless+WASAPI with a private
user directory and exact source/context receipts; first parse/readiness then
real 24 segments. No Forward/native visual/human claim, and no holds coverage
claim (the published probe still omits five newly added held modes). A true
action/bed/threshold red remains red and requires separate factual diagnosis.

## Engine basis (official, pinned to actual engine revision)

- [Record implementation](https://raw.githubusercontent.com/godotengine/godot/ed1daf0bf/servers/audio/effects/audio_effect_record.cpp): IO copying is asynchronous; stopping sets an active flag, with no public flush/count. This explains why exact observed equality is required.
- [Capture implementation](https://raw.githubusercontent.com/godotengine/godot/ed1daf0bf/servers/audio/effects/audio_effect_capture.cpp): successful writes increment pushed; full-buffer blocks increment discarded instead. clear_buffer does not reset either total.
- [Headless implementation](https://raw.githubusercontent.com/godotengine/godot/ed1daf0bf/servers/display/display_server_headless.cpp): installs RasterizerDummy.
- [AudioServer API](https://docs.godotengine.org/en/stable/classes/class_audioserver.html): actual driver, mixer locking and mix-rate API.

Root's original two-OGG decoding and strict bounds failure remain in its
separate review leaf; they were not regenerated or silently replaced here.
