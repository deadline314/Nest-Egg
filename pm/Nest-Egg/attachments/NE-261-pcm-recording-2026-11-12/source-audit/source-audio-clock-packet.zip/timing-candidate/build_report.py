"""Retain published metric/threshold code; replace untrusted slicing/subtraction."""
import difflib, pathlib
HERE=pathlib.Path(__file__).resolve().parent
original=(HERE.parent/'source/published/tools/audio/melee_sound_report.py').read_text(encoding='utf8')
text=original
def replace(old,new):
    global text
    assert text.count(old)==1,old
    text=text.replace(old,new)
replace('import numpy as np','from read_pcm import load as load_verified_pcm\nimport numpy as np')
replace('    sfx, rate = read(folder / "melee-sfx.wav")\n    master, master_rate = read(folder / "melee-master.wav")',
'''    rate, buses = load_verified_pcm(folder, index)
    # Keep the published SFX int16 metric and all original acceptance limits.
    sfx = np.frombuffer(buses["SFX"]["pcm_s16"], dtype="<i2").astype(np.float32).reshape(-1, 2).mean(axis=1) / 32768.0
    master = np.frombuffer(buses["Master"]["pcm_s16"], dtype="<i2").astype(np.float32).reshape(-1, 2).mean(axis=1) / 32768.0
    # Direct Music/Ambience captures after their existing effects, with actual
    # stable bus gains, normalized to SFX's pre-gain measurement plane. This is
    # a pre-Master balance measurement, never post-limiter Master minus SFX.
    bed = sum(np.frombuffer(buses[name]["raw_f32"], dtype="<f4").reshape(-1, 2).mean(axis=1)
              * buses[name]["gain"] / buses["SFX"]["gain"] for name in ("Music", "Ambience"))
    assert np.isfinite(bed).all(), "nonfinite independent bed"''')
replace('        cut = slice(int(segment["start"] * rate), int(segment["end"] * rate))',
        '        cut = slice(segment["bus_start_frames"]["SFX"], segment["bus_end_frames"]["SFX"])')
replace('        # Both recorders sit before their bus volume, so the master recording is the SFX bus plus everything else (ambience, music).\n        rest = master[cut][: sfx[cut].size] - sfx[cut][: master[cut].size]',
        '        rest = bed[cut]\n        assert rest.size == sfx[cut].size > 0, "empty/truncated bed/SFX segment"')
# Both numerical report slicing and plotted boundaries use the verified sample
# epoch. Preserve the original plot/levels/threshold formulas literally.
prefix='    rows = []\n    for segment in index["segments"]:'
replace(prefix,'    for segment in index["segments"]:\n        segment["start"] = segment["bus_start_frames"]["SFX"] / rate\n        segment["end"] = segment["bus_end_frames"]["SFX"] / rate\n'+prefix)
target=HERE/'stage2/report.py';target.write_text(text,encoding='utf8',newline='\n')
(HERE/'stage2/report.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='published/tools/audio/melee_sound_report.py',tofile='leaf/stage2/report.py')),encoding='utf8',newline='\n')
print('Own-leaf report generated; original thresholds unchanged; full game input not yet recorded.')
