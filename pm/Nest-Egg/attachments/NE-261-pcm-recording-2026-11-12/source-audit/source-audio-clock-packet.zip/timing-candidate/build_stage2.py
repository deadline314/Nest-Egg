"""Generate a reviewable narrow leaf diff, never write product files."""
import difflib, pathlib
HERE=pathlib.Path(__file__).resolve().parent
original=(HERE.parent/'source/published/tools/melee_sound_probe.gd').read_text(encoding='utf8')
text=original
def replace(old,new):
    global text
    assert text.count(old)==1,old
    text=text.replace(old,new)
replace('var _master := AudioEffectRecord.new()\nvar _sfx := AudioEffectRecord.new()',
        'var _clock := preload("res://work/ne261-audio-source-review-20261112/timing-candidate/stage2/pcm_clock.gd").new()')
replace('if not out_dir.is_absolute_path() or DisplayServer.get_name() == "headless":',
        'if not out_dir.is_absolute_path() or AudioServer.get_driver_name() != "WASAPI":')
replace('需要原生視窗與 --out=<絕對資料夾>', '需要真WASAPI與 --out=<絕對資料夾>（headless僅音訊，不是原生畫面驗收）')
replace('\tfor effect: AudioEffectRecord in [_master, _sfx]:\n\t\teffect.format = AudioStreamWAV.FORMAT_16_BITS\n\tAudioServer.add_bus_effect(0, _master)\n\tAudioServer.add_bus_effect(AudioServer.get_bus_index(Sfx.BUS), _sfx)',
        '\tadd_child(_clock)\n\t_clock.attach()')
replace('\t_master.set_recording_active(true)\n\t_sfx.set_recording_active(true)', '\tawait _clock.start()')
replace('\t_master.set_recording_active(false)\n\t_sfx.set_recording_active(false)\n\t_save(_master, "melee-master.wav")\n\t_save(_sfx, "melee-sfx.wav")',
        '\tvar sample_end: Dictionary = _clock.stop()\n\tvar pcm_index: Dictionary = await _clock.save(out_dir, sample_end)\n\t_failures += _clock.problems.size()')
replace('\tvar total := _now()\n\tfor index in _segments.size():\n\t\t_segments[index]["end"] = _segments[index + 1]["start"] if index + 1 < _segments.size() else total',
        '\tfor index in _segments.size():\n\t\tvar next: Dictionary = _segments[index + 1]["bus_start_frames"] if index + 1 < _segments.size() else sample_end["frames"]\n\t\t_segments[index]["bus_end_frames"] = next\n\t\t_segments[index]["start"] = float(_segments[index]["bus_start_frames"]["SFX"]) / pcm_index["mix_rate"]\n\t\t_segments[index]["end"] = float(next["SFX"]) / pcm_index["mix_rate"]')
replace('"master_db": AudioServer.get_bus_volume_db(0)', '"master_db": AudioServer.get_bus_volume_db(0), "sample_clock": pcm_index, "runtime": {"audio_driver":AudioServer.get_driver_name(),"display":DisplayServer.get_name()}, "scope": "Published weapon combo/extension recording; does not cover the five added hold modes or human listening. Headless recording is not native visual acceptance."')
replace('_segments.append({"weapon": weapon, "part": part, "start": _now(), "sounds": []})',
        '_segments.append({"weapon": weapon, "part": part, "wall_seconds_diagnostic_only": _now(), "bus_start_frames": _clock.mark(), "sounds": []})')
offset=text.index('\n\nfunc _save(')
text=text[:offset]+'\n'
out=HERE/'stage2';out.mkdir(exist_ok=True)
(out/'probe.gd').write_text(text,encoding='utf8',newline='\n')
(out/'probe.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='published/tools/melee_sound_probe.gd',tofile='leaf/stage2/probe.gd')),encoding='utf8',newline='\n')
(out/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://work/ne261-audio-source-review-20261112/timing-candidate/stage2/probe.gd" id="1"]\n\n[node name="NE261SampleClockCandidate" type="Node"]\nscript = ExtResource("1")\n',encoding='utf8',newline='\n')
print('Wrote own leaf candidate only; not compiled/run/adopted.')
