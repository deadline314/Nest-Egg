"""Read actual PCM and sample-counter anchors. No engine/network/source mutation."""
import argparse, json, pathlib, struct, wave

def verify(root):
    root=pathlib.Path(root);data=json.loads((root/'result.json').read_text())
    receipt=json.loads((root/'exit.json').read_text());command=json.loads((root/'command.json').read_text())
    assert receipt['source_unchanged'] and receipt['source_after']==command['source_before'],'producer source drift'
    assert receipt['exit_code']==0 and not receipt['gpu_log_rejected'] and not receipt['diagnostic_lines'],'producer rejected'
    assert data['failures']==[],'producer checks failed'
    runtime=data['runtime']
    assert runtime['display']=='headless' and runtime['rendering_device_null'] and runtime['adapter']=='','not dummy rasterizer'
    assert runtime['audio_driver']=='WASAPI','not actual WASAPI'
    outputs={};timelines={}
    for bus in data['buses']:
        name=bus['bus'];base=bus['base'];end=bus['end']
        pushed=end['pushed']-base['pushed'];discarded=end['discarded']-base['discarded']
        assert discarded==0,'Capture discarded audio'
        with wave.open(str(root/(name+'.wav')),'rb') as wav:
            assert (wav.getnchannels(),wav.getsampwidth(),wav.getframerate())==(2,2,bus['mix_rate']),'PCM format/rate'
            frames=wav.getnframes();pcm=wav.readframes(frames)
        capture=(root/(name+'.f32')).read_bytes()
        assert len(capture)%8==0 and len(capture)//8==pushed,'Capture bytes/pushed mismatch'
        assert frames==pushed+discarded==bus['processed_frames']==bus['record_frames']==bus['capture_frames'],'PCM/counter frame mismatch'
        # Exact conversion used by AudioEffectRecord, not an RMS/correlation fit.
        floats=struct.iter_unpack('<f',capture)
        expected=b''.join(struct.pack('<h',int(max(-32768,min(32767,sample[0]*32768)))) for sample in floats)
        assert pcm==expected,'Record PCM differs from corresponding Capture samples'
        assert any(pcm),'empty/silent prototype'
        assert bus['save_begin_usec']>=data['record_stop_wall_usec'] and bus['save_end_usec']>=bus['save_begin_usec'],'end contains file IO'
        anchors=[0]
        for boundary in data['boundaries']:
            current=boundary['buses'][name]
            assert current['discarded']==base['discarded'],'segment had discarded frames'
            frame=current['pushed']-base['pushed']+current['discarded']-base['discarded']
            assert isinstance(frame,int) and anchors[-1]<=frame<=frames,'segment outside PCM or nonmonotonic'
            anchors.append(frame)
        anchors.append(frames)
        # Expose sample-clock intervals; all report slicing must pass this gate.
        segments=[]
        for start,stop in zip(anchors,anchors[1:]):
            checked_slice(pcm,start,stop,frames)
            segments.append({'start_frame':start,'end_frame':stop,'start_seconds':start/bus['mix_rate'],'end_seconds':stop/bus['mix_rate']})
        timelines[name]=anchors
        outputs[name]={'frames':frames,'seconds':frames/bus['mix_rate'],'pushed':pushed,'discarded':discarded,'sample_equal':True,'segments':segments}
    assert len(outputs)==2 and len({tuple(a) for a in timelines.values()})==1,'per-bus sample anchors do not align'
    return {'buses':outputs,'wall_seconds':data['wall_elapsed_seconds'],'scope':'Two-second quiet synthetic audio clock prototype only; no gameplay mix, bed subtraction or human listening.'}

def checked_slice(pcm,start,end,frames):
    assert isinstance(start,int) and isinstance(end,int) and 0<=start<=end<=frames,'segment outside actual PCM'
    assert len(pcm)==frames*4,'stereo16 PCM size'
    return pcm[start*4:end*4]

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('root');args=ap.parse_args()
    print(json.dumps(verify(args.root),indent=2))
