"""Only this isolated headless/dummy-rendering project; no game or GPU run."""
import argparse, hashlib, json, os, pathlib, re, subprocess, time

HERE = pathlib.Path(__file__).resolve().parent
GODOT = pathlib.Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')

def sources(project):
    return {p.relative_to(HERE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in project.iterdir() if p.is_file() and p.suffix in ('.gd', '.tscn', '.godot')}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--overflow',action='store_true');ap.add_argument('--helper',action='store_true');args=ap.parse_args()
    out=HERE/'runs'/str(time.time_ns());out.mkdir(parents=True)
    project=HERE/('helper-project' if args.helper else 'project')
    before=sources(project)
    env=os.environ.copy();env['APPDATA']=str(out/'appdata');env['LOCALAPPDATA']=str(out/'localappdata')
    cmd=[str(GODOT),'--path',str(project),'--display-driver','headless','--audio-driver','WASAPI',
         '--','--out='+str(out),'--expected-driver=WASAPI']
    if args.overflow:cmd.append('--overflow')
    (out/'command.json').write_text(json.dumps({'argv':cmd,'APPDATA':env['APPDATA'],'LOCALAPPDATA':env['LOCALAPPDATA'],'source_before':before},indent=2)+'\n',encoding='utf8',newline='\n')
    proc=subprocess.Popen(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    lines=[];gpu_rejected=False
    try:
        # No GPU renderer is requested; additionally kill only our child if the
        # startup log contradicts headless/dummy preflight.
        import threading, queue
        q=queue.Queue()
        def read():
            for line in proc.stdout:q.put(line)
            q.put(None)
        threading.Thread(target=read,daemon=True).start()
        deadline=time.monotonic()+20
        while True:
            if time.monotonic()>deadline:proc.kill();raise TimeoutError('isolated prototype exceeded 20s')
            try:line=q.get(timeout=.1)
            except queue.Empty:continue
            if line is None:break
            lines.append(line)
            if re.search(rb'(Vulkan.*(?:API|Device)|Using Device|OpenGL.*Renderer)',line,re.I):
                gpu_rejected=True;proc.kill()
        code=proc.wait(timeout=3)
    except Exception as exc:
        if proc.poll() is None:proc.kill();proc.wait()
        lines.append(('WRAPPER_ERROR '+repr(exc)+'\n').encode());code=proc.returncode or 1
    (out/'engine.log').write_bytes(b''.join(lines))
    after=sources(project);text=b''.join(lines).decode('utf8','replace')
    receipt={'exit_code':code,'gpu_log_rejected':gpu_rejected,'source_after':after,'source_unchanged':before==after,
             'diagnostic_lines':[l for l in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|WARNING:',l)],'scope':'audio-only functional prototype, not performance/game loudness/human listening'}
    (out/'exit.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n')
    print(out);print(text);print(json.dumps(receipt,indent=2))
    return 0 if code==0 and before==after and not gpu_rejected and not receipt['diagnostic_lines'] else 1

if __name__=='__main__':raise SystemExit(main())
