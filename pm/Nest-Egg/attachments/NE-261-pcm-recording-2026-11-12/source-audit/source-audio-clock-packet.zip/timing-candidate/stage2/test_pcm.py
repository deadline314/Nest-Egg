import ast, json, pathlib, shutil, tempfile, unittest
from read_pcm import load

HERE=pathlib.Path(__file__).resolve().parent
NORMAL=HERE.parent/'runs/1794462301069536000'

class Controls(unittest.TestCase):
    def test_actual_four_bus(self):
        rate,audio=load(NORMAL,json.loads((NORMAL/'melee-index.json').read_text()))
        self.assertEqual(rate,48000);self.assertEqual(len(audio),4)
    def reject(self,change):
        index=json.loads((NORMAL/'melee-index.json').read_text());change(index)
        with self.assertRaises(AssertionError):load(NORMAL,index)
    def test_oob_end(self):self.reject(lambda d:d['segments'][0]['bus_end_frames'].__setitem__('SFX',9999999))
    def test_misaligned_bus(self):self.reject(lambda d:d['segments'][0]['bus_start_frames'].__setitem__('Music',512))
    def test_discard(self):self.reject(lambda d:d['sample_clock']['buses']['Music']['end'].__setitem__('discarded',512))
    def test_gain_change(self):self.reject(lambda d:d['sample_clock']['buses']['SFX']['gain_observations'][0].__setitem__('gain_db',-12))
    def test_route_change(self):self.reject(lambda d:d['sample_clock']['buses']['Music'].__setitem__('send','SFX'))
    def test_no_legacy_fallback(self):
        with self.assertRaises(KeyError):load(NORMAL,{'segments':[{'start':0,'end':99}]})
    def test_old_leak_run_rejected(self):
        root=NORMAL.parent/'1794462282454514000'
        with self.assertRaises(AssertionError):load(root,json.loads((root/'melee-index.json').read_text()))
    def test_truncated_float(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            target=pathlib.Path(temp)
            for source in NORMAL.iterdir():
                if source.is_file():shutil.copyfile(source,target/source.name)
            path=target/'bus-SFX.f32';path.write_bytes(path.read_bytes()[:-8])
            with self.assertRaises(AssertionError):load(target,json.loads((target/'melee-index.json').read_text()))
    def test_metric_formulas_unchanged(self):
        original=HERE.parent.parent/'source/published/tools/audio/melee_sound_report.py'
        a=ast.parse(original.read_text(encoding='utf8'));b=ast.parse((HERE/'report.py').read_text(encoding='utf8'))
        for name in ['db','levels','sheet']:
            x=next(n for n in a.body if isinstance(n,ast.FunctionDef) and n.name==name)
            y=next(n for n in b.body if isinstance(n,ast.FunctionDef) and n.name==name)
            self.assertEqual(ast.dump(x),ast.dump(y),name)
        for name in ['WINDOW','HUM_UNDER_STEPS_DB','HUM_UNDER_BED_DB']:
            x=next(n for n in a.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
            y=next(n for n in b.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
            self.assertEqual(ast.dump(x),ast.dump(y),name)

if __name__=='__main__':unittest.main()
