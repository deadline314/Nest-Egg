"""Fail-closed real per-bus PCM/sample-clock loader. No silent truncation."""
import json, math, pathlib, struct, wave

def load(folder,index):
    folder=pathlib.Path(folder);clock=index['sample_clock'];rate=clock['mix_rate']
    receipt=json.loads((folder/'exit.json').read_text(encoding='utf8'))
    assert receipt['exit_code']==0 and not receipt['diagnostic_lines'] and not receipt['gpu_log_rejected'] and receipt['source_unchanged'],'producer process rejected'
    assert index['runtime']['audio_driver']=='WASAPI','not actual WASAPI'
    assert type(rate) is int and rate>0 and clock['problems']==[], 'producer clock problems'
    assert set(clock['buses'])=={'Master','SFX','Music','Ambience'},'missing independent bus'
    audio={};lengths={}
    for name,bus in clock['buses'].items():
        base=bus['base'];end=bus['end']
        pushed=end['pushed']-base['pushed'];discarded=end['discarded']-base['discarded']
        assert discarded==0 and pushed>0,'Capture discard/empty bus'
        assert pushed==bus['pushed_delta']==bus['capture_frames']==bus['record_frames'],'bus frame count mismatch'
        assert bus['discarded_delta']==0 and bus['save_error']==0,'bus drop/save failure'
        raw=(folder/('bus-'+name+'.f32')).read_bytes()
        assert len(raw)==pushed*8,'float PCM size mismatch'
        floats=[x[0] for x in struct.iter_unpack('<f',raw)]
        assert all(math.isfinite(x) for x in floats),'nonfinite capture'
        with wave.open(str(folder/('bus-'+name+'.wav')),'rb') as wav:
            assert (wav.getnchannels(),wav.getsampwidth(),wav.getframerate(),wav.getnframes())==(2,2,rate,pushed),'Record format/size mismatch'
            pcm=wav.readframes(pushed)
        expected=b''.join(struct.pack('<h',int(max(-32768,min(32767,x*32768)))) for x in floats)
        assert pcm==expected,'Record/Capture sample mismatch'
        gain=bus['gain_db'];assert math.isfinite(gain),'invalid bus gain'
        assert bus['gain_observations'] and all(x['gain_db']==gain for x in bus['gain_observations']),'bus gain changed'
        if name!='Master':assert bus['send']=='Master','bed/SFX not direct Master children'
        assert clock['stop']['frames'][name]==pushed,'end not actual stop sample'
        lengths[name]=pushed;audio[name]={'raw_f32':raw,'pcm_s16':pcm,'gain':10**(gain/20)}
    assert len(set(lengths.values()))==1,'bus epoch lengths differ'
    previous=None
    for segment in index['segments']:
        starts=segment['bus_start_frames'];ends=segment['bus_end_frames']
        assert set(starts)==set(lengths) and set(ends)==set(lengths),'segment missing bus anchors'
        assert len(set(starts.values()))==len(set(ends.values()))==1,'bus segment epochs differ'
        for name,count in lengths.items():
            start,end=starts[name],ends[name]
            assert type(start) is int and type(end) is int and 0<=start<end<=count,'segment exceeds actual PCM'
            if previous is not None:assert start==previous[name],'segment discontinuity'
        previous=ends
    assert previous==clock['stop']['frames'],'last segment is not stop boundary'
    return rate,audio

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('folder');args=ap.parse_args()
    folder=pathlib.Path(args.folder);rate,audio=load(folder,json.loads((folder/'melee-index.json').read_text(encoding='utf8')))
    print(json.dumps({'mix_rate':rate,'bus_frames':{n:len(a['raw_f32'])//8 for n,a in audio.items()},'scope':'PCM/counter input contract only; no loudness or listening acceptance'},indent=2))
