extends Node
var out := ""
var clock := preload("res://pcm_clock.gd").new()

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
	_run.call_deferred()

func _run() -> void:
	var runtime := {"display":DisplayServer.get_name(),"audio_driver":AudioServer.get_driver_name(),"adapter":RenderingServer.get_video_adapter_name(),"rendering_device_null":RenderingServer.get_rendering_device()==null}
	print("NE261_AUDIO_RUNTIME " + JSON.stringify(runtime))
	if runtime["display"]!="headless" or runtime["audio_driver"]!="WASAPI" or runtime["adapter"]!="" or not runtime["rendering_device_null"]:
		get_tree().quit(2);return
	AudioServer.set_bus_volume_db(0,-80.0) # Isolated quiet functional tone only.
	for name in ["SFX","Music","Ambience"]:
		AudioServer.add_bus()
		var index := AudioServer.bus_count-1
		AudioServer.set_bus_name(index,name);AudioServer.set_bus_send(index,&"Master")
		var rate := int(AudioServer.get_mix_rate())
		var bytes := PackedByteArray();bytes.resize(rate*4)
		for frame in rate:
			var value := int(sin(TAU*(330.0+index*110.0)*frame/rate)*160.0)
			bytes.encode_s16(frame*4,value);bytes.encode_s16(frame*4+2,value)
		var stream := AudioStreamWAV.new()
		stream.format=AudioStreamWAV.FORMAT_16_BITS;stream.stereo=true;stream.mix_rate=rate;stream.data=bytes
		stream.loop_mode=AudioStreamWAV.LOOP_FORWARD;stream.loop_end=rate
		var player := AudioStreamPlayer.new();player.stream=stream;player.bus=name;add_child(player);player.play()
	add_child(clock);clock.attach();await clock.start()
	var started := Time.get_ticks_usec()
	while Time.get_ticks_usec()-started<2000000:await get_tree().process_frame
	var stopped: Dictionary = clock.stop()
	for child in get_children():
		if child is AudioStreamPlayer:child.stop()
	var result: Dictionary = await clock.save(out,stopped)
	var starts := {"Master":0,"SFX":0,"Music":0,"Ambience":0}
	var writer := FileAccess.open(out.path_join("melee-index.json"),FileAccess.WRITE)
	writer.store_string(JSON.stringify({"runtime":runtime,"sample_clock":result,"segments":[{"weapon":"synthetic","part":"two_seconds","bus_start_frames":starts,"bus_end_frames":stopped["frames"]}],"scope":"Copied candidate helper only; three synthetic quiet loops, not game audio or human listening."},"  "));writer.close()
	print("NE261_HELPER_DONE problems=" + JSON.stringify(clock.problems))
	get_tree().quit(0 if clock.problems.is_empty() else 1)
