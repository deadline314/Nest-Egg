extends Node
## Probe-only leaf. Counter epochs, not wall seconds, delimit every bus.
## No class_name; no game runtime or audio-routing change.
var buses: Array[Dictionary] = []
var problems: Array[String] = []
var active := false

func counters(capture: AudioEffectCapture) -> Dictionary:
	return {"pushed":capture.get_pushed_frames(), "discarded":capture.get_discarded_frames()}

func attach() -> void:
	for name in ["Master", "SFX", "Music", "Ambience"]:
		var index := AudioServer.get_bus_index(name)
		if index < 0:
			problems.append("missing bus: " + name)
			continue
		var record := AudioEffectRecord.new()
		record.format = AudioStreamWAV.FORMAT_16_BITS
		var capture := AudioEffectCapture.new()
		capture.buffer_length = 10.0
		AudioServer.add_bus_effect(index, record)
		AudioServer.add_bus_effect(index, capture)
		buses.append({"name":name, "index":index, "record":record, "capture":capture,
			"chunks":[], "gains":[], "gain_db":AudioServer.get_bus_volume_db(index),
			"send":String(AudioServer.get_bus_send(index))})

func start() -> void:
	# Call only after AudioServer has instantiated all effects. Not an arbitrary
	# number of frames: require actual audio-thread counter publication.
	var deadline := Time.get_ticks_usec() + 2000000
	while Time.get_ticks_usec() < deadline:
		var ready := buses.size() == 4
		for bus in buses:
			ready = ready and bus["capture"].get_pushed_frames() > 0
		if ready:break
		await get_tree().process_frame
	AudioServer.lock()
	for bus in buses:
		if bus["capture"].get_pushed_frames() <= 0:problems.append("audio thread not ready: " + bus["name"])
		bus["capture"].clear_buffer()
		bus["base"] = counters(bus["capture"])
		bus["record"].set_recording_active(true)
	active = true
	AudioServer.unlock()

func mark() -> Dictionary:
	var result := {}
	AudioServer.lock()
	for bus in buses:
		var current := counters(bus["capture"])
		result[bus["name"]] = current["pushed"] + current["discarded"] - bus["base"]["pushed"] - bus["base"]["discarded"]
	AudioServer.unlock()
	return result

func _drain(bus: Dictionary) -> void:
	var available: int = bus["capture"].get_frames_available()
	if available > 0:bus["chunks"].append(bus["capture"].get_buffer(available))
	var gain := AudioServer.get_bus_volume_db(bus["index"])
	bus["gains"].append({"counter":counters(bus["capture"]),"gain_db":gain})
	if gain != bus["gain_db"] and not problems.has("bus gain changed: " + bus["name"]):problems.append("bus gain changed: " + bus["name"])
	if String(AudioServer.get_bus_send(bus["index"])) != bus["send"]:problems.append("bus send changed: " + bus["name"])

func _process(_delta: float) -> void:
	if not active:return
	AudioServer.lock()
	for bus in buses:_drain(bus)
	AudioServer.unlock()

func stop() -> Dictionary:
	# Freeze all boundaries before any WAV/data file save or upgrade restoration.
	AudioServer.lock()
	var wall := Time.get_ticks_usec()
	var frames := {}
	for bus in buses:
		bus["end"] = counters(bus["capture"])
		frames[bus["name"]] = bus["end"]["pushed"] + bus["end"]["discarded"] - bus["base"]["pushed"] - bus["base"]["discarded"]
		bus["record"].set_recording_active(false)
		_drain(bus)
	active = false
	AudioServer.unlock()
	return {"wall_usec_diagnostic_only":wall,"frames":frames}

func save(out: String, end: Dictionary) -> Dictionary:
	# A scheduling yield is NOT a flush guarantee. PCM/counter/sample equality
	# remains mandatory in the offline reader; incomplete Record tails fail.
	await get_tree().process_frame
	var result := {"stop":end,"mix_rate":int(AudioServer.get_mix_rate()),"buses":{},"problems":problems}
	for bus in buses:
		var captured := PackedVector2Array()
		for chunk: PackedVector2Array in bus["chunks"]:captured.append_array(chunk)
		var wave: AudioStreamWAV = bus["record"].get_recording()
		var pushed: int = bus["end"]["pushed"] - bus["base"]["pushed"]
		var discarded: int = bus["end"]["discarded"] - bus["base"]["discarded"]
		var frames: int = wave.data.size() / 4 if wave != null else 0
		if discarded != 0 or pushed != captured.size() or frames != pushed + discarded:
			problems.append("PCM/counter/discard mismatch: " + bus["name"])
		var name: String = bus["name"]
		var capture_file := FileAccess.open(out.path_join("bus-" + name + ".f32"), FileAccess.WRITE)
		capture_file.store_buffer(captured.to_byte_array())
		capture_file.close()
		var saved: Error = wave.save_to_wav(out.path_join("bus-" + name + ".wav")) if wave != null else ERR_INVALID_DATA
		if saved != OK:problems.append("save failed: " + name)
		result["buses"][name] = {"base":bus["base"],"end":bus["end"],"pushed_delta":pushed,"discarded_delta":discarded,
			"record_frames":frames,"capture_frames":captured.size(),"gain_db":bus["gain_db"],"gain_observations":bus["gains"],"send":bus["send"],"save_error":saved}
	return result
