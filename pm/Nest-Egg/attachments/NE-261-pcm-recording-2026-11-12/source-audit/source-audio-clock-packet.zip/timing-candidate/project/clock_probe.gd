extends Node
## Stage1 only: actual Record PCM versus Capture processed-frame counters.
## Does not perform game loudness/bed reconstruction or human listening.
var out:=""
var overflow:=false
var expected_driver:="WASAPI"
var checks:=0
var failures:Array[String]=[]
var buses:Array=[]
var boundaries:Array=[]
var player:AudioStreamPlayer

func check(ok: bool, label: String) -> void:
	checks+=1
	if not ok:failures.append(label);printerr("CHECK_FAIL: "+label)

func counter(capture: AudioEffectCapture) -> Dictionary:
	return {"pushed":capture.get_pushed_frames(),"discarded":capture.get_discarded_frames(),"available":capture.get_frames_available()}

func mark(label: String) -> void:
	AudioServer.lock()
	var row:={"label":label,"wall_usec":Time.get_ticks_usec(),"buses":{}}
	for bus in buses:row["buses"][bus["name"]]=counter(bus["capture"])
	AudioServer.unlock()
	boundaries.append(row)

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):out=arg.trim_prefix("--out=")
		elif arg=="--overflow":overflow=true
		elif arg.begins_with("--expected-driver="):expected_driver=arg.trim_prefix("--expected-driver=")
	Engine.max_fps=120
	_run.call_deferred()

func _run() -> void:
	assert(out.is_absolute_path())
	var runtime:={"display":DisplayServer.get_name(),"render_method_configured":RenderingServer.get_current_rendering_method(),"adapter":RenderingServer.get_video_adapter_name(),"rendering_device_null":RenderingServer.get_rendering_device()==null,"audio_driver":AudioServer.get_driver_name(),"mix_rate":AudioServer.get_mix_rate(),"output_device":AudioServer.output_device,"engine":Engine.get_version_info()}
	print("NE261_AUDIO_RUNTIME "+JSON.stringify(runtime))
	check(runtime["display"]=="headless" and runtime["adapter"].is_empty() and runtime["rendering_device_null"],"headless dummy rasterizer preflight")
	check(runtime["audio_driver"]==expected_driver,"actual audio driver matches explicit request")
	if not failures.is_empty():_finish({"runtime":runtime});return
	AudioServer.add_bus();var sfx:=AudioServer.bus_count-1;AudioServer.set_bus_name(sfx,&"NE261_ClockSFX");AudioServer.set_bus_send(sfx,&"Master")
	# Quiet only this prototype's final physical output; effects record before
	# bus output gain. This is not a game mix-balance or audible-volume claim.
	AudioServer.set_bus_volume_db(0,-80.0)
	for index in [0,sfx]:
		var record:=AudioEffectRecord.new();record.format=AudioStreamWAV.FORMAT_16_BITS
		var capture:=AudioEffectCapture.new();capture.buffer_length=.01 if overflow else 10.0
		AudioServer.add_bus_effect(index,record);AudioServer.add_bus_effect(index,capture)
		buses.append({"index":index,"name":String(AudioServer.get_bus_name(index)),"record":record,"capture":capture})
	var rate:=int(AudioServer.get_mix_rate());var bytes:=PackedByteArray();bytes.resize(rate*4)
	for frame in rate:
		var value:=int(sin(TAU*440.0*frame/rate)*160.0)
		bytes.encode_s16(frame*4,value);bytes.encode_s16(frame*4+2,value)
	var stream:=AudioStreamWAV.new();stream.format=AudioStreamWAV.FORMAT_16_BITS;stream.stereo=true;stream.mix_rate=rate;stream.data=bytes;stream.loop_mode=AudioStreamWAV.LOOP_FORWARD;stream.loop_end=rate
	player=AudioStreamPlayer.new();player.stream=stream;player.bus=&"NE261_ClockSFX";add_child(player);player.play()
	var ready_deadline:=Time.get_ticks_usec()+2000000
	while buses[0]["capture"].get_pushed_frames()==0 and Time.get_ticks_usec()<ready_deadline:await get_tree().process_frame
	check(buses[0]["capture"].get_pushed_frames()>0,"capture instance actually receives audio frames")
	AudioServer.lock()
	var started:=Time.get_ticks_usec()
	for bus in buses:
		bus["capture"].clear_buffer()
		bus["base"]=counter(bus["capture"])
		bus["record"].set_recording_active(true)
	AudioServer.unlock()
	mark("start")
	var next_mark:=started+500000
	while Time.get_ticks_usec()-started<2000000:
		if Time.get_ticks_usec()>=next_mark:mark("segment");next_mark+=500000
		await get_tree().process_frame
	AudioServer.lock()
	var stopped:=Time.get_ticks_usec()
	for bus in buses:
		bus["end"]=counter(bus["capture"])
		bus["record"].set_recording_active(false)
		var available:int=bus["capture"].get_frames_available()
		bus["captured"]=bus["capture"].get_buffer(available) if available>0 else PackedVector2Array()
	AudioServer.unlock()
	player.stop()
	# A scheduling yield is not called a flush. Actual byte/frame equality below
	# is the acceptance gate; any missing Record tail remains an actual red.
	await get_tree().process_frame
	var rows:Array=[]
	for bus in buses:
		var wav:AudioStreamWAV=bus["record"].get_recording()
		var captured:PackedVector2Array=bus["captured"]
		var end:Dictionary=bus["end"];var base:Dictionary=bus["base"]
		var pushed:int=end["pushed"]-base["pushed"];var discarded:int=end["discarded"]-base["discarded"]
		var processed:=pushed+discarded
		var record_frames:=wav.data.size()/4 if wav!=null else 0
		check(wav!=null and wav.stereo and wav.mix_rate==rate,"real Record returns expected stereo16 PCM/rate")
		check(discarded==0,"no Capture buffer overflow/dropped frames")
		check(captured.size()==pushed,"Capture read frames match its actual successful pushed counter")
		check(record_frames==processed,"Record PCM frame length equals actual processed pushed+discarded delta")
		var nonzero:=false
		for sample in captured:
			if absf(sample.x)+absf(sample.y)>.00001:nonzero=true;break
		check(nonzero,"actual nonzero loop audio was captured")
		var name:=String(bus["name"])
		var capture_file:=FileAccess.open(out.path_join(name+".f32"),FileAccess.WRITE);capture_file.store_buffer(captured.to_byte_array());capture_file.close()
		var before_save:=Time.get_ticks_usec();var error:=wav.save_to_wav(out.path_join(name+".wav")) if wav!=null else ERR_INVALID_DATA;var after_save:=Time.get_ticks_usec()
		check(error==OK,"actual Record WAV save succeeded")
		rows.append({"bus":name,"base":base,"end":end,"processed_frames":processed,"capture_frames":captured.size(),"record_frames":record_frames,"mix_rate":rate,"channels":2,"format":"stereo_s16","f32_channels":2,"save_begin_usec":before_save,"save_end_usec":after_save,"save_error":error,"output_bus_db":AudioServer.get_bus_volume_db(bus["index"])})
	var effects:Array=[]
	for bus in buses:
		var list:Array=[]
		for n in AudioServer.get_bus_effect_count(bus["index"]):list.append(AudioServer.get_bus_effect(bus["index"],n).get_class())
		effects.append({"bus":bus["name"],"effects":list})
	_finish({"runtime":runtime,"boundaries":boundaries,"buses":rows,"effects":effects,"record_start_wall_usec":started,"record_stop_wall_usec":stopped,"wall_elapsed_seconds":float(stopped-started)/1000000.0,"overflow_control":overflow,"scope":"Isolated two-second actual audio clock only; per-bus PCM/counter anchors. No gameplay loudness, bed subtraction, rendering or human listening."})

func _finish(data: Dictionary) -> void:
	data["checks"]=checks;data["failures"]=failures
	var file:=FileAccess.open(out.path_join("result.json"),FileAccess.WRITE);file.store_string(JSON.stringify(data,"  "));file.close()
	print("NE261_AUDIO_DONE checks=%d failures=%d" % [checks,failures.size()])
	get_tree().quit(0 if failures.is_empty() else 1)
