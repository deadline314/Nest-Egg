"""Seal own evidence only. No Git writes or engine invocation."""
import hashlib, importlib.util, json, pathlib, subprocess, sys, zipfile

HERE=pathlib.Path(__file__).resolve().parent
def save(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
spec=importlib.util.spec_from_file_location('source_reader',HERE/'reader.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
save(HERE/'index.json',module.compare(HERE))
commands=[
    ([sys.executable,'-X','utf8','-m','unittest','test_reader','-v'],HERE,'source-tests'),
    ([sys.executable,'-X','utf8','-m','unittest','test_reader','-v'],HERE/'timing-candidate','clock-tests'),
    ([sys.executable,'-X','utf8','-m','unittest','test_pcm','-v'],HERE/'timing-candidate/stage2','four-bus-tests'),
    ([sys.executable,'-X','utf8','reader.py','runs/1794461889919575400'],HERE/'timing-candidate','clock-reader'),
    ([sys.executable,'-X','utf8','reader.py','runs/1794461963648627400'],HERE/'timing-candidate','overflow-rejected'),
    ([sys.executable,'-X','utf8','read_pcm.py','../runs/1794462301069536000'],HERE/'timing-candidate/stage2','four-bus-reader'),
    ([sys.executable,'-X','utf8','read_pcm.py','../runs/1794462282454514000'],HERE/'timing-candidate/stage2','leak-rejected')]
logs=HERE/'validation';logs.mkdir(exist_ok=True);receipts=[]
for command,cwd,label in commands:
    p=subprocess.run(command,cwd=cwd,capture_output=True)
    (logs/(label+'-stdout.log')).write_bytes(p.stdout);(logs/(label+'-stderr.log')).write_bytes(p.stderr)
    expected=1 if label.endswith('rejected') else 0
    receipts.append({'label':label,'argv':command,'cwd':str(cwd),'expected_exit':expected,'actual_exit':p.returncode})
    assert p.returncode==expected,(label,p.returncode,p.stderr.decode('utf8','replace'))
save(logs/'commands.json',receipts)
# New author text is LF; preserve original Git input, engine/PCM/receipt bytes.
for p in HERE.rglob('*'):
    if p.is_file() and p.suffix in ('.py','.md','.json','.gd','.tscn','.godot'):
        rel=p.relative_to(HERE)
        if rel.parts[0]=='source' or 'runs' in rel.parts or '.godot' in rel.parts or '__pycache__' in rel.parts:continue
        p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
files=[]
for p in HERE.rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(HERE)
    if any(part in ('.godot','__pycache__','appdata','localappdata') for part in rel.parts):continue
    if p.suffix in ('.pyc','.zip') or p.name=='packet-index.json':continue
    files.append(p)
members={}
archive=HERE/'source-audio-clock-packet.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files):
        data=p.read_bytes();name=p.relative_to(HERE).as_posix();z.writestr(name,data)
        members[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
save(HERE/'packet-index.json',{'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members,
    'scope':'Immutable original/published30-source audit plus isolated synthetic WASAPI clock prototypes and unexecuted full-game probe/report candidate; no C product/PM adoption or human listening.'})
print(json.dumps({'archive_bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(members),'validation_expected_exits':len(receipts)},indent=2))
