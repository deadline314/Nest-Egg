"""NE261 immutable Git source audit; no engine, decoding, network or product writes."""
from pathlib import Path
import hashlib,json,re,subprocess

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
COMMITS={'original':'bbe79e04e38edf0e8848cfb336840862442b51c6','published':'a4f2db7a'}
TICKET='pm/Nest-Egg/[NE-261]替每把近戰武器換上自己的聲音.md'
WEAPONS={'blade':'thermal_blade','dagger':'mono_dagger','glaive':'ion_glaive','maul':'hydraulic_maul','whip':'mono_whip'}
ROLES=['swing_a','swing_b','swing_heavy','hit','hit_heavy','idle']
DATA=['assets_src/audio/pipeline.json','assets_src/audio/LICENSES.json','assets_src/audio/manifest.json','assets_src/audio/build_cache.json','assets_src/audio/license_check.json','data/audio/sound_bank.json','data/feel/sound_events.json','data/feel/materials.json','data/audio/stage_scenes.json','data/audio/slots.json']
CODE=['game/player/melee_hum.gd','game/player/melee_set.gd','game/player/player_visual.gd','game/player/player.gd','autoload/sfx.gd','autoload/settings.gd','core/audio/sound_bank.gd','game/fx/hit_feedback.gd','core/components/hurtbox.gd','tools/sound_lab/stage_actions.gd','tools/melee_sound_probe.gd','tools/audio/melee_sound_report.py','tools/audio/build_audio.py','tools/audio/audio_lib.py','tests/suite/test_audio.gd','tests/suite/test_melee_weapons.gd']

def git(*args):return subprocess.run(['git','-c','core.quotepath=false',*args],cwd=ROOT,check=True,capture_output=True).stdout
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())

def main():
 commits={k:git('rev-parse',v).decode().strip() for k,v in COMMITS.items()}
 names=DATA+CODE+[TICKET]+['data/melee/'+value+'.json' for value in WEAPONS.values()]+['pm/Nest-Egg/attachments/NE-261/'+f for f in ['melee-index.json','melee-combos-master.ogg','melee-combos-sfx-only.ogg']]
 for weapon in WEAPONS:
  for role in ROLES:
   path=f'audio/sfx/melee_{weapon}_{role}_01.ogg';names.extend([path,path+'.import'])
 # The current module/move did not exist in the original pre-module version.
 optional=['game/melee/melee_module.gd','game/melee/melee_move.gd']
 result={}
 for label,commit in commits.items():
  result[label]={}
  tree=set(git('ls-tree','-r','--name-only',commit).decode().splitlines())
  for name in names+optional:
   if name not in tree:
    if name in optional:continue
    raise AssertionError(('required tracked input absent',commit,name))
   data=git('show',commit+':'+name);path=OUT/'source'/label/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
   result[label][name]={'sha256':sha(data),'bytes':len(data)}
 heard=[]
 for label in commits:
  text=(OUT/'source'/label/TICKET).read_text(encoding='utf-8')
  for number,line in enumerate(text.splitlines(),1):
   if '2026-10-12' in line or '使用者聽過' in line:heard.append({'version':label,'commit':commits[label],'path':TICKET,'line':number,'text':line})
 assert any('使用者聽過附件的錄音' in row['text'] and row['version']=='original' for row in heard)
 snapshots={'commits':commits,'files':result,'original_user_listening_ticket_record':heard,'engine_started':False,'decoded_audio':False,'network_used':False,'live_C_runtime_used':False,'scope':'Immutable original/published Git sources only. User listening is the historical ticket record, not new listening by this worker or Root.'}
 save(OUT/'source-index.json',snapshots)
 (OUT/'original-commit.txt').write_bytes(git('show','--format=fuller','--stat',commits['original']))
 (OUT/'commit2.diff').write_bytes(git('show','b2d0eb3d8c031d5f18ed6c369f658ec885dee4ba','--','tools/sound_lab/stage_actions.gd',TICKET))
 # Keep original stress-test claims as historical source, not invented raw.
 entries=git('ls-tree','-r','--name-only','b2d0eb3d8c031d5f18ed6c369f658ec885dee4ba','--','pm/Nest-Egg/attachments/NE-261').decode().splitlines()
 save(OUT/'commit2-evidence-scope.json',{'commit':'b2d0eb3d8c031d5f18ed6c369f658ec885dee4ba','tracked_attachment_entries':entries,'stress_28_runs_raw_found_in_this_attachment_tree':False,'standalone_1522_raw_found_in_this_attachment_tree':False,'limit':'Bounded original tracked attachment inspection, not a whole-disk absence claim. No stress test is executed or its original result reconstructed.'})
 print(json.dumps({'commits':commits,'files':{k:len(v) for k,v in result.items()},'source_index_sha256':sha((OUT/'source-index.json').read_bytes()),'engine_started':False}))

if __name__=='__main__':main()
