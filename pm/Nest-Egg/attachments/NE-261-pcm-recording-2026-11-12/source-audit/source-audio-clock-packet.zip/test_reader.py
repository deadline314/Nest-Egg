import json,unittest
from unittest.mock import patch
from reader import HERE,analyze,load

class SourceGuards(unittest.TestCase):
 def reject_changed(self,path,mutate):
  original=load(HERE/'source/published',path)
  mutate(original)
  def changed(folder,name):return original if name==path else load(folder,name)
  with patch('reader.load',side_effect=changed):
   with self.assertRaises(AssertionError):analyze(HERE/'source/published')
 def test_noncc0_record_refused(self):
  self.reject_changed('assets_src/audio/LICENSES.json',lambda d:d['oga_electricity-game-sound-pack'].__setitem__('license','CC-BY-4.0'))
 def test_missing_per_output_enrollment_refused(self):
  self.reject_changed('assets_src/audio/LICENSES.json',lambda d:d['oga_electricity-game-sound-pack']['outputs'].remove('res://audio/sfx/melee_glaive_swing_a_01.ogg'))
 def test_missing_nested_layer_source_refused(self):
  self.reject_changed('assets_src/audio/LICENSES.json',lambda d:d['oga_steam-release-sounds']['files_used'].remove('steam hisses - Marker #1.wav'))
 def test_bank_volume_mismatch_refused(self):
  self.reject_changed('data/audio/sound_bank.json',lambda d:d['sounds']['melee_blade_hit'].__setitem__('volume_db',999))
 def test_corrupt_cached_output_hash_refused(self):
  self.reject_changed('assets_src/audio/build_cache.json',lambda d:d['outputs']['audio/sfx/melee_blade_idle_01.ogg'].__setitem__('sha1','0'*40))
 def test_missing_idle_loop_refused(self):
  self.reject_changed('data/audio/sound_bank.json',lambda d:d['sounds']['melee_blade_idle'].__setitem__('loop',False))

if __name__=='__main__':unittest.main()
