"""Offline NE261 source reader. No Git, live runtime, audio decoding or network."""
from pathlib import Path
import hashlib,json

HERE=Path(__file__).resolve().parent
WEAPONS={'blade':'thermal_blade','dagger':'mono_dagger','glaive':'ion_glaive','maul':'hydraulic_maul','whip':'mono_whip'}
ROLES=['swing_a','swing_b','swing_heavy','hit','hit_heavy','idle']

def sha(data):return hashlib.sha256(data).hexdigest()
def load(folder,name):return json.loads((folder/name).read_bytes())
def components(node):
 result=[]
 if isinstance(node,dict):
  if 'pack' in node and 'file' in node:result.append({'pack':node['pack'],'file':node['file']})
  for key,value in node.items():
   if key not in ['pack','file']:result+=components(value)
 elif isinstance(node,list):
  for value in node:result+=components(value)
 return result

def analyze(folder):
 pipeline=load(folder,'assets_src/audio/pipeline.json');bank=load(folder,'data/audio/sound_bank.json')['sounds'];licenses=load(folder,'assets_src/audio/LICENSES.json');manifest={p['id']:p for p in load(folder,'assets_src/audio/manifest.json')['packs']};cache=load(folder,'assets_src/audio/build_cache.json')['outputs'];events=load(folder,'data/feel/sound_events.json')['events']
 outputs={};used_packs=set()
 for weapon,weapon_file in WEAPONS.items():
  for role in ROLES:
   id=f'melee_{weapon}_{role}';entry=bank[id];definition=pipeline['sfx'][id];files=entry['files']
   assert len(files)==1 and files[0]==f'res://audio/sfx/{id}_01.ogg',('unexpected output routing',id)
   path=files[0].removeprefix('res://');data=(folder/path).read_bytes();sources=components(definition['variants']);assert sources,('no actual recipe sources',id)
   packs={s['pack'] for s in sources};recorded=entry['pack'];recorded={recorded} if isinstance(recorded,str) else set(recorded)
   assert packs==recorded,('bank pack mismatch',id)
   assert entry.get('volume_db',0)==definition.get('volume_db',0),('pipeline/bank volume mismatch',id)
   enrollment=[]
   for source in sources:
    pack=source['pack'];file=source['file'];used_packs.add(pack)
    assert pack in manifest and pack in licenses,('missing recorded pack',id,pack)
    m=manifest[pack];l=licenses[pack]
    assert m['license']=='CC0-1.0' and l['license']=='CC0-1.0',('recorded non-CC0 license',id,pack)
    assert file in l['files_used'] and files[0] in l['outputs'],('missing per-file/output license enrollment',id,pack,file)
    assert m['page']==l['page'],('manifest/license page mismatch',id,pack)
    enrollment.append({'pack':pack,'file':file,'license':l['license'],'author':l.get('author'),'page':l['page'],'output_registered':True,'source_registered':True})
   assert hashlib.sha1(data).hexdigest()==cache[path]['sha1'],('shipped output/build cache mismatch',id)
   if role=='idle':assert entry.get('loop') is True and definition['variants'][0]['mode']=='loop',('idle loop metadata absent',id)
   outputs[id]={'path':path,'sha256':sha(data),'bytes':len(data),'bank':entry,'pipeline':definition,'components':sources,'license_enrollment':enrollment,'cache':cache[path],'import_sha256':sha((folder/(path+'.import')).read_bytes())}
 assert len(outputs)==30 and len({row['path'] for row in outputs.values()})==30
 routes={}
 for weapon,weapon_file in WEAPONS.items():
  definition=load(folder,'data/melee/'+weapon_file+'.json')
  assert definition['idle_sound']==f'melee_{weapon}_idle'
  attacks={}
  for name,attack in definition['attacks'].items():
   sounds=attack['sounds']
   assert set(sounds)=={'swing','hit'}
   for kind,id in sounds.items():
    assert id in bank or id in events,('unresolved move sound',weapon,name,kind,id)
    if id in events:
     assert all(sound in bank for layer in events[id]['layers'] for sound in layer['sounds'])
   attacks[name]=sounds
  routes[weapon]={'file':weapon_file,'idle_sound':definition['idle_sound'],'combo':definition['combo'],'extension':definition.get('extension'),'hold':definition.get('hold'),'attack_sounds':attacks}
 first={}
 for weapon in ['glaive','maul','whip']:
  id=f'melee_{weapon}_swing_first';definition=events[id]
  assert definition['layers'][0]['sounds']==[f'melee_{weapon}_swing_a',f'melee_{weapon}_swing_b']
  first[id]=definition
 return {'outputs':outputs,'packs':sorted(used_packs),'routes':routes,'first_events':first,'material_routing':load(folder,'data/feel/materials.json'),'selected_manifest_packs':{id:manifest[id] for id in sorted(used_packs)}}

def compare(root=HERE):
 source_index=load(root,'source-index.json')
 for version,files in source_index['files'].items():
  for name,row in files.items():
   data=(root/'source'/version/name).read_bytes();assert sha(data)==row['sha256'] and len(data)==row['bytes'],('frozen input drift',version,name)
 versions={version:analyze(root/'source'/version) for version in ['original','published']};a,b=versions.values()
 selected={}
 for id,row in a['outputs'].items():
  new=b['outputs'][id]
  selected[id]={field:row[field]==new[field] for field in ['sha256','bank','pipeline','components','license_enrollment','cache','import_sha256']}
 whole={name:source_index['files']['original'][name]['sha256']==source_index['files']['published'][name]['sha256'] for name in source_index['files']['original'] if name in source_index['files']['published'] and name.endswith(('.gd','.py','.json'))}
 old_moves={weapon:set(route['attack_sounds']) for weapon,route in a['routes'].items()}
 delta={weapon:{'old_attack_ids':sorted(old_moves[weapon]),'published_added_attack_ids':sorted(set(b['routes'][weapon]['attack_sounds'])-old_moves[weapon]),'old_attack_sounds_same':all(route['attack_sounds'][id]==b['routes'][weapon]['attack_sounds'].get(id) for id in old_moves[weapon]),'idle_same':route['idle_sound']==b['routes'][weapon]['idle_sound'],'combo_same':route['combo']==b['routes'][weapon]['combo'],'hold_original':route.get('hold'),'hold_published':b['routes'][weapon].get('hold')} for weapon,route in a['routes'].items()}
 return {'commits':source_index['commits'],'audio_decoded':False,'engine_started':False,'network_used':False,'whole_file_equal':whole,'selected30_comparison':selected,'original':a,'published':b,'move_scope_delta':delta,'user_listening':source_index['original_user_listening_ticket_record'],'scope':'Recorded licensing/source/data consistency; not a fresh online CC0 determination, audible comparison or runtime playback test.'}

def main():
 result=compare()
 print(json.dumps({'commits':result['commits'],'outputs':len(result['published']['outputs']),'packs':len(result['published']['packs']),'all_30_audio_bytes_same':all(x['sha256'] for x in result['selected30_comparison'].values()),'all_30_bank_selected_same':all(x['bank'] for x in result['selected30_comparison'].values()),'engine_started':False,'audio_decoded':False,'network_used':False},indent=2))

if __name__=='__main__':main()
