from pathlib import Path
from math import dist
import json

base = Path(__file__).resolve().parent
read = lambda file: json.loads(file.read_bytes())
comparisons = []
controls = 0
for mode in ('native','headless'):
    for folder in sorted((base/f'stock-{mode}').glob('kneel-*')):
        candidate = base/f'candidate-{mode}'/folder.name
        old_rows = read(folder/'motion.json')['rows']
        new_rows = read(candidate/'motion.json')['rows']
        assert len(old_rows) == len(new_rows) == 3
        for old,new in zip(old_rows,new_rows,strict=True):
            assert old['label'] == new['label'] and old['spent'] == new['spent'] == 1
            assert old['facing'] == new['facing'] and old['depth'] == new['depth']
            assert dist(old['first']['velocity'],new['first']['velocity']) < 0.0001
            assert dist(old['first_frame_aim'],new['first_frame_aim']) < 0.0001
            assert old['first']['live'] and new['first']['live'] and dist(old['first']['position'],old['muzzle']) < 0.001
            if new['label'].endswith('00_to_00'):
                assert dist(old['first']['position'],new['first']['position']) < 0.001
                controls += 1
            else:
                old_gap = dist(old['first']['position'],old['first_frame_pose'])
                new_gap = dist(new['first']['position'],new['first_frame_pose'])
                assert old_gap > 40.0 and new_gap < 6.0
                if new['label'].endswith('00_to_85'):
                    assert 3.0 < new['floor_y']-new['first']['position'][1] < 3.75
                    assert len(new['expired']) == 1
                else:
                    assert (new['first']['position'][0]-new['root'][0]) * new['facing'] > 30.0
                comparisons.append({'mode':mode,'case':new['label'],'facing':new['facing'],
                                    'old_gap_after_recoil':old_gap,'new_gap_after_recoil':new_gap})
assert len(comparisons) == 8 and controls == 4
prefire = read(next((base/'candidate-prefire-native').glob('kneel-*/motion.json')))['rows']
assert len(prefire) == 3 and all(dist(row['first']['position'],row['debit_muzzle']) < 0.001 for row in prefire)
result = {'paired_turn_shots':comparisons,'prefire_matches':len(prefire),'static_controls':controls}
(base/'audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(result)
