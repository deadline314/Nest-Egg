"""Register Ali's isolated seated trouser part on her unchanged source skeleton.

CPU-only source calibration. Original standing artwork and other parts are preserved.
Call before cut_layers through recipe.source_rebuilds. --publish adds only the new
pose texture and pose metadata to the existing character, without recutting other parts.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE = HERE / "01_design/isolated-trousers.png"
SOURCE_SHA = "3473fbe6a478d3ee5fcc69cd5daca045bcfbddfc2a1caa2f5a402bb78e90f4a0"
HIP = np.array([420.0, 520.0])
KNEE = np.array([1270.0, 535.0])
ACROSS = 0.38


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--publish", action="store_true")
    args = parser.parse_args()
    if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != SOURCE_SHA:
        raise ValueError(f"{SOURCE}: source changed; existing delivery retained")
    spec = json.loads((ROOT / "tools/comfyui/specs/ali_side.json").read_text())
    pixels = np.array(Image.open(SOURCE).convert("RGBA"))
    yy, xx = np.mgrid[:pixels.shape[0], :pixels.shape[1]]
    # Waist is already supplied by the original pelvis; the knee keeps a short
    # overlap for the existing shin. No copied far leg or invented fill pixels.
    source_axis = (KNEE - HIP) / np.linalg.norm(KNEE - HIP)
    forward = (xx - HIP[0]) * source_axis[0] + (yy - HIP[1]) * source_axis[1]
    keep = (yy >= 350) & (((xx < 1190) & (yy < 740)) | (np.hypot(xx - KNEE[0], yy - KNEE[1]) <= 155)) & (pixels[:, :, 3] >= 40)
    keep &= forward <= np.linalg.norm(KNEE - HIP) + 40.0  # original shin supplies the knee's forward/lower overlap
    standing = np.array(Image.open(ROOT / "art_src/characters/ali/07_refined/leg_upper.png").convert("RGBA"))
    wanted = standing[standing[:, :, 3] > 250, :3].astype(float)
    have = pixels[keep & (pixels[:, :, 3] > 250), :3].astype(float)
    gain = wanted.mean(axis=0) / have.mean(axis=0)
    pixels[keep, :3] = (pixels[keep, :3].astype(float) * gain).clip(0, 255).round().astype(np.uint8)
    pixels[~keep] = 0
    Image.fromarray((keep * 255).astype(np.uint8)).save(HERE / "source-mask.png")
    target_hip, target_knee = (np.array(spec["joints"][key], float) for key in ["hip", "knee"])
    source_axis = (KNEE - HIP) / np.linalg.norm(KNEE - HIP)
    target_axis = (target_knee - target_hip) / np.linalg.norm(target_knee - target_hip)
    along = np.linalg.norm(target_knee - target_hip) / np.linalg.norm(KNEE - HIP)
    source_basis = np.column_stack([source_axis, [-source_axis[1], source_axis[0]]])
    target_basis = np.column_stack([target_axis * along, np.array([-target_axis[1], target_axis[0]]) * ACROSS])
    linear = target_basis @ source_basis.T
    transform = np.column_stack([linear, target_hip - linear @ HIP])
    size = Image.open(ROOT / "art_src/characters/ali/base_rgba.png").size
    premultiplied = pixels.astype(np.float32)
    premultiplied[:, :, :3] *= premultiplied[:, :, 3:] / 255.0
    out = cv2.warpAffine(premultiplied, transform, size, flags=cv2.INTER_AREA)
    alpha = out[:, :, 3:]
    out[:, :, :3] = np.where(alpha > 0, out[:, :, :3] / np.maximum(alpha, 1e-3) * 255.0, 0)
    layer = Image.fromarray(out.clip(0, 255).round().astype(np.uint8))
    target = ROOT / "art_src/characters/ali/poses/sit/leg_upper.png"
    target.parent.mkdir(parents=True, exist_ok=True)
    layer.save(target)
    report = {"source": str(SOURCE.relative_to(ROOT)), "sha256": SOURCE_SHA,
              "source_hip": HIP.tolist(), "source_knee": KNEE.tolist(), "across": ACROSS,
              "target_hip": target_hip.tolist(), "target_knee": target_knee.tolist(),
              "along": float(along), "source_to_canvas": transform.tolist(), "color_gain": gain.tolist(), "forward_knee_overlap_source_pixels": 40,
              "canvas": list(size), "source_mask": "source-mask.png", "alpha_floor": 40,
              "sampling": "premultiplied affine INTER_AREA, then existing cut_layers density and warp; not a new HD illustration",
              "output_sha256": hashlib.sha256(target.read_bytes()).hexdigest()}
    (HERE / "calibration.json").write_text(json.dumps(report, indent=2) + "\n")
    if args.publish:
        sys.path.insert(0, str(ROOT / "tools/comfyui"))
        from cut_layers import part_transform, render_part, NOTE
        ratio = spec["tex_px_per_wp"] / spec["illustration_px_per_wp"]
        joints = {name: np.array(point, float) * ratio for name, point in spec["joints"].items()}
        part = {k: v for k, v in spec["parts"]["leg_upper"].items() if k != "y"}
        geometry = part_transform(layer, part, joints, ratio)
        if geometry is None:
            raise ValueError("Ali seated thigh is empty; delivery retained")
        _, width, height, pivot = geometry
        runtime = ROOT / "art/characters/ali"
        encoded = render_part(layer, geometry, ratio)
        name = "leg_upper_sit"
        character_file = runtime / "character.json"
        character = json.loads(character_file.read_text())
        Image.fromarray(encoded).save(runtime / "parts" / (name + ".png"))
        character["textures"][name] = {"file": "parts/" + name + ".png", "size": [width, height], "pivot": [round(float(v), 2) for v in pivot], "note": NOTE}
        depth = spec["pose_parts"]["sit"].get("slot_z", {})
        entries = [{"slot": use["name"], "texture": name, "bone": use["bone"], **({"z": depth[use["name"]]} if use["name"] in depth else {})} for use in part["uses"]]
        character.setdefault("pose_parts", {})["sit"] = {"parts": entries}
        character_file.write_text(json.dumps(character, ensure_ascii=False, indent=2) + "\n")
        print(f"Ali sit: {width}x{height}, pivot={pivot}, density ratio={ratio:.6f}; other textures and rig untouched")
    print("Ali seated source registered; no model loaded")


if __name__ == "__main__":
    main()
