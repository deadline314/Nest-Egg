extends Node

const CHAPTERS := ["res://data/story/ch1_kasa.json", "res://data/story/ch2_heron.json"]
const PORTRAIT_VIEW := preload("res://tools/viewport_capture.gd")
const NATIVE_SCENES := ["ch1_t_egret_1","ch1_c09_wake","ch1_c14_home",
	"ch2_t_s01_settle","ch2_t_s11_xiaowei","ch2_t_s18_introduce","ch2_t_s18_ticket"]

var output := ""
var native := false
var samples := {}
var only := ""
var counter_k := 0.0
var towel_start := 0.0
var contact: Array[Dictionary] = []
var failures: Array[String] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			output = arg.trim_prefix("--out=")
		elif arg.begins_with("--scene="):
			only = arg.trim_prefix("--scene=")
		elif arg.begins_with("--counter-k="):
			counter_k = float(arg.trim_prefix("--counter-k="))
		elif arg.begins_with("--towel-start="):
			towel_start = float(arg.trim_prefix("--towel-start="))
	if not output.is_absolute_path():
		get_tree().quit(2)
		return
	native = DisplayServer.get_name() != "headless"
	if native:
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	_run.call_deferred()


func _run() -> void:
	Story.set_language("zh")
	var active: Dictionary = Story.audit_data()["scenes"]
	for path: String in CHAPTERS:
		var authored: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
		for id: String in authored["scenes"]:
			var scene: Dictionary = active.get(id,{})
			if scene.get("mode","") != "animated" or scene.get("overlay",false) or (not only.is_empty() and only != id) or (native and only.is_empty() and id not in NATIVE_SCENES):
				continue
			await _observe(id,scene)
	var file := FileAccess.open(output.path_join("placements.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"failures":failures,"scenes":samples,"native":native,"counter_contact":contact},"  ") + "\n")
	file.close()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(not failures.is_empty()))


func _observe(id: String, scene: Dictionary) -> void:
	var timeline: Array = []
	var speakers: Dictionary = {}
	for step: Dictionary in scene["steps"]:
		if str(step.get("do","")) == "choice":
			break
		if step["do"] == "say":
			speakers[timeline.size()] = step["speaker"]
		if counter_k > 0.0 and id == "ch2_t_s01_settle" and step["do"] == "actor" and step["id"] == "k":
			var changed := step.duplicate()
			changed["pos"] = [counter_k, step["pos"][1]]
			timeline.append(changed)
		else:
			timeline.append(step)
	if speakers.is_empty():
		return
	var player := CutscenePlayer.new()
	add_child(player)
	player.speed = 1.0
	if native:
		# Keep the normal stage renderer while leaving the desktop pointer alone.
		player.scene_id = StringName(id)
		player._steps = timeline.duplicate(true)
		player._build_ui()
		player._framing_token = Story.framing.acquire(player)
		Story.framing.safe_rect_changed.connect(player._layout_safe_rect)
		player._layout_safe_rect(Story.framing.safe_rect())
		player._running = true
		player._run.call_deferred()
	else:
		var prefix := scene.duplicate()
		prefix["steps"] = timeline
		player.play(StringName(id),prefix)
	var rows: Array[Dictionary] = []
	var photographs := 0
	var start_moved := false
	var binding: StagePropBinding
	var push_frames := 0
	for cycle in 3900:
		await get_tree().process_frame
		if not is_instance_valid(player) or not player.is_running() or speakers.is_empty():
			break
		var index := player.steps_run
		if id == "ch2_t_s01_settle" and is_instance_valid(player._stage):
			var towel := player._stage.prop_node("towel")
			if towel != null:
				if not start_moved and towel_start > 0.0:
					towel.position.x = towel_start
					start_moved = true
				var old_k: CutsceneActor = player._actors.get(&"k")
				if old_k != null and index >= 3 and index <= 5:
					if binding == null:
						binding = StagePropBinding.new(towel,Vector2(80.0,30.0))
					var parent := old_k.get_parent() as Node2D
					var point := parent.to_global(binding.stage_point(parent))
					var distance := point.distance_to(old_k.hand_contact_global(&"front"))
					contact.append({"step":index,"x":towel.position.x,"distance":distance})
					if index == 4:
						push_frames += 1
						if native and push_frames in [11,28,36]:
							await RenderingServer.frame_post_draw
							if PORTRAIT_VIEW.image(get_viewport()).save_png(output.path_join("towel_push_%02d.png" % push_frames)) != OK:
								failures.append(id + ": cannot capture towel")
		if not speakers.has(index) or not player._dialogue._frame.visible:
			continue
		var speaker := str(speakers[index])
		if not player._dialogue.is_complete():
			continue
		var row := _snapshot(player,speaker,index)
		rows.append(row)
		speakers.erase(index)
		if native and photographs < 4 and not (row["speaking_actor"] as String).is_empty():
			await RenderingServer.frame_post_draw
			if PORTRAIT_VIEW.image(get_viewport()).save_png(output.path_join("%s_%02d.png" % [id,index])) != OK:
				failures.append(id + ": cannot write native capture")
			photographs += 1
		player._dialogue.complete()
		player._advance_requested = true
	if not speakers.is_empty():
		failures.append(id + ": " + str(speakers))
		print("FAIL",failures.back())
	samples[id] = rows
	if is_instance_valid(player) and player.is_running():
		player.cancel()
	for _settle in 3:
		await get_tree().process_frame


func _snapshot(player: CutscenePlayer, speaker: String, index: int) -> Dictionary:
	var safe := Story.framing.safe_rect()
	var mask := player._dialogue._frame.get_global_rect()
	var cast: Array[Dictionary] = []
	var speaking := ""
	for id: StringName in player._actors:
		var actor: CutsceneActor = player._actors[id]
		if actor.is_queued_for_deletion() or actor.rig == null or not actor.rig.is_valid():
			continue
		var head := actor.rig.bone(&"head")
		if head == null:
			continue
		var bounds := actor.rig.visual_bounds()
		var point := head.global_position
		if str(actor.speaker_id) == speaker or str(id) == speaker:
			speaking = str(id)
		cast.append({"id": str(id), "skin":actor.rig.skin_id, "speaker":str(actor.speaker_id),
			"position":[actor.position.x,actor.position.y], "scale":actor.scale.x,
			"head":[point.x,point.y], "head_in_safe":safe.has_point(point),
			"head_under_dialogue":mask.has_point(point), "alpha": actor.modulate.a,
			"bounds":[bounds.position.x,bounds.position.y,bounds.end.x,bounds.end.y],
			"safe_overlap":bounds.intersection(safe).get_area() / maxf(1.0,bounds.get_area())})
	return {"speaker":speaker,"speaking_actor":speaking,"step":index,"actors":cast,
		"camera":[player.cam_pos.x,player.cam_pos.y,player.cam_zoom],
		"safe":[safe.position.x,safe.position.y,safe.end.x,safe.end.y],
		"dialogue":[mask.position.x,mask.position.y,mask.end.x,mask.end.y]}




