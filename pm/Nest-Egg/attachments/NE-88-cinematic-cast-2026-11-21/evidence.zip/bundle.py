from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json
import re

root = Path.cwd()
base = Path(__file__).resolve().parent
def read(path):
    return json.loads((base/path).read_bytes())
def speaking_actors(report):
    for scene, rows in report['scenes'].items():
        for row in rows:
            for actor in row['actors']:
                if actor['id'] == row['speaking_actor'] and actor['skin'] != 'rin':
                    yield scene, row, actor

report = read('normal-all-headless/placements.json')
native = read('normal-native/placements.json')
booth = read('normal-booth-native/placements.json')
counts = Counter(actor['skin'] for _,_,actor in speaking_actors(report))
lines = sum(len(rows) for rows in report['scenes'].values())
assert len(report['scenes']) == 98 and lines == 297 and sum(counts.values()) == 161 and len(counts) == 14
assert len(native['scenes'])+len(booth['scenes']) == 7
for verify in (report,native,booth):
    assert not verify['failures']
    for scene,row,actor in speaking_actors(verify):
        assert actor['head_in_safe'] and not actor['head_under_dialogue'] and actor['safe_overlap'] >= 0.85, (scene,row,actor)
for folder in ('normal-all-headless','normal-native','normal-booth-native'):
    log = (base/folder/'engine.log').read_text(encoding='utf-8')
    assert not re.search(r'^(?:SCRIPT )?ERROR:|^FAIL',log,re.M)
assert 'k/front cannot reach' in (base/'normal-native/engine.log').read_text(encoding='utf-8')
assert read('official-release/verification.json') == {'exit':0,'errors':[],'source_held':True}

ticket = next((root/'pm/Nest-Egg').glob('[[]NE-88]*')).relative_to(root)
archive = Path('pm/Nest-Egg/attachments/NE-88-cinematic-cast-2026-11-21/evidence.zip')
photos = {
    'rooftop-dialogue':'normal-native/ch1_t_egret_1_03.png',
    'early-pawnshop':'normal-native/ch2_t_s01_settle_06.png',
    'phone-booth-return':'normal-booth-native/ch2_t_s14_return_45.png',
    'guest-book-zheng':'normal-native/ch2_t_s18_ticket_28.png',
}
images = {name:Path(f'pm/Nest-Egg/images/NE-88-{name}-20261121.png') for name in photos}
text = (root/ticket).read_text(encoding='utf-8')
assert '# Commit-10（' in text and '# Commit-11（' not in text
assert not (root/archive.parent).exists() and all(not (root/image).exists() for image in images.values())
raw = ['inspect_cinematics.gd','inspect_cinematics.tscn','run.py','bundle.py','official-release/raw.log','official-release/verification.json']
for scope in ('normal-all-headless','normal-native','normal-booth-native','headless','counter-contact-baseline'):
    raw.extend(f'{scope}/{name}' for name in ('command.json','engine.log','placements.json'))
    raw.extend(path.relative_to(base).as_posix() for path in sorted((base/scope).glob('*.png')))
(root/archive).parent.mkdir()
with ZipFile(root/archive,'x',compression=ZIP_DEFLATED) as bundle:
    for archive_name in raw:
        bundle.write(base/archive_name,archive_name)
with ZipFile(root/archive) as bundle:
    assert bundle.testzip() is None
for name,image in images.items():
    (root/image).write_bytes((base/photos[name]).read_bytes())
section = f'''
---

# Commit-11（前兩章的場上說話角色取景）

## 內文

用正式的過場舞台及正常動畫速度，檢查第一、二章 98 段有台詞的過場，從開場到各段第一個選擇之前，共 {lines} 句。其中場上 NPC 發言 161 句、14 種外觀，說話演員的頭部座標都在有效畫面內及對話框上方。另有凜發言 106 句、場外發言 30 句。

RX 9070 XT Forward+ 原生另播七段，含屋頂、第二章當舖、電話亭、帳房和客簿間。第二章當舖老 K 推毛巾的後段有兩次接觸診斷，仍需修正手臂與毛巾的距離。其他分支、角色完整動作、遮擋與照明仍待驗。受影響測試選擇器為文件證據交付，0 套。

[原生畫面、演員取景與毛巾的實際接觸紀錄](attachments/NE-88-cinematic-cast-2026-11-21/evidence.zip)

### 截圖

![第一章屋頂的鷺](images/NE-88-rooftop-dialogue-20261121.png)
![第二章清早的當舖](images/NE-88-early-pawnshop-20261121.png)
![第二章電話亭迎接鷺](images/NE-88-phone-booth-return-20261121.png)
![客簿間的鄭先生](images/NE-88-guest-book-zheng-20261121.png)
'''
(root/ticket).write_text(text.rstrip()+'\n\n\n'+section.lstrip('\n'),encoding='utf-8')
(base/'delivery.json').write_text(json.dumps([path.as_posix() for path in (ticket,archive,*images.values())],
                                            ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(raw),(root/archive).stat().st_size)
