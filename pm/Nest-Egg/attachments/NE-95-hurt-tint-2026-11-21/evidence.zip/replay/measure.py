
from pathlib import Path
from PIL import Image, ImageStat, ImageChops
import json
base=Path(__file__).resolve().parent
labels=('before','hit','decay','restored','normal-cue')
modes=('default-high','reduced-high','default-low','reduced-low')
sides=('stock-native','candidate-native')
regions={'center':(390,196,955,510),'left':(10,585,95,705),'right':(1160,585,1260,705)}
def red(image, box):
    r,g,b=ImageStat.Stat(image.crop(box)).mean
    return r-(g+b)/2
result={}
previous={}
for side in sides:
    folder=base/side
    data=json.loads((folder/'result.json').read_bytes())
    for mode in modes:
        rows={r['label']:r for r in data['rows'] if r['mode']==mode}
        with Image.open(folder/f'{mode}-before.png') as before, Image.open(folder/f'{mode}-hit.png') as hit:
            assert before.size==hit.size==(1280,720)
            b,h=before.convert('RGB'),hit.convert('RGB')
            result.setdefault(mode,{})[side]={key:round(red(h,box)-red(b,box),3) for key,box in regions.items()}
        for label in labels:
            row=rows[label]
            key=mode,label
            if side==sides[0]:
                previous[key]=row
                continue
            other=previous[key]
            for name in ('health','boss','sources','flash_count','reduced','mode','label'):
                assert row[name]==other[name],(key,name)
            assert abs(row['time']-other['time']) <= 1/60+1e-7,(key,row['time'],other['time'])
            assert abs(row['amount']-other['amount']) < 0.025,(key,row['amount'],other['amount'])
            assert row['edge']==(0 if label in ('before','normal-cue') else 0.8),(key,row['edge'])
        if side==sides[1]:
            for label in ('before','normal-cue','restored'):
                with Image.open(base/sides[0]/f'{mode}-{label}.png') as a, Image.open(folder/f'{mode}-{label}.png') as b:
                    delta=ImageStat.Stat(ImageChops.difference(a.convert('RGB').crop(regions['center']),b.convert('RGB').crop(regions['center']))).mean
                    result[mode].setdefault('unaffected_center_rgb_mae',{})[label]=round(sum(delta)/3,3)
for mode, stats in result.items():
    stock,after=(stats[side] for side in sides)
    assert 0<after['center']<stock['center']*0.65,stats
    for edge in ('left','right'):
        assert after[edge]>stock[edge]*0.72,stats
    stats['center_red_reduction_percent']=round(100*(1-after['center']/stock['center']),1)
(base/'measurement.json').write_text(json.dumps({'metric':'mean R - (G+B)/2 at hit minus before, in 8-bit screenshot pixels','regions':regions,'modes':result},indent=2)+'\n')
print(json.dumps(result))

