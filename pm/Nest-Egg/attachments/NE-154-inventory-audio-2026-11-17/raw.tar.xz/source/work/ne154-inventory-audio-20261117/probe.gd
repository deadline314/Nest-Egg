extends ScenarioBase
var variant := ""
var heard: Array[String] = []
var rows: Array[Dictionary] = []
var problems: Array[String] = []
var clock
var context: InventoryContext

func _ready() -> void:
	out_dir = OS.get_environment("NE154_OUT")
	variant = OS.get_environment("NE154_VARIANT")
	var profile := OS.get_environment("NE154_PROFILE").replace("\\", "/").to_lower()
	if variant not in ["original", "candidate"] or not out_dir.is_absolute_path() or not OS.get_user_data_dir().replace("\\", "/").to_lower().begins_with(profile + "/") or profile.is_empty():
		get_tree().quit(2)
		return
	DirAccess.make_dir_recursive_absolute(out_dir)
	_run.call_deferred()

func page(kind: String):
	var script: Script
	if variant == "original":
		var old := GDScript.new()
		old.source_code = FileAccess.get_file_as_string("res://work/ne154-inventory-audio-20261117/original-" + kind + ".gd.txt")
		old.source_code = "\n".join(old.source_code.split("\n").slice(1))
		if old.reload() != OK:
			problems.append("original compile failed: " + kind)
		script = old
	else:
		script = load("res://ui/inventory/pages/" + kind + "_page.gd")
	var result = script.new()
	result.bind(context)
	return result

func record(name: String, expected: String, action: Callable) -> void:
	await wait(0.35)
	heard.clear()
	var before := Progression.snapshot()
	var start: Dictionary = clock.mark()
	var value: bool = action.call()
	var events := heard.duplicate()
	await wait(0.65)
	var stop: Dictionary = clock.mark()
	var sources: Array[Dictionary] = []
	for event in events:
		sources.append({"id":event,"source":String(Sfx.source_of(StringName(event)))})
	var ok := events == [expected] and Sfx.source_of(StringName(expected)) == &"file"
	if not ok: problems.append(name + ": " + JSON.stringify(sources))
	rows.append({"name":name,"return":value,"expected":expected,"events":events,"sources":sources,"audio_ok":ok,"before":before,"after":Progression.snapshot(),"start_samples":start,"end_samples":stop})

func _run() -> void:
	GameState.story_autosave = false
	Story.auto_skip = true
	await open_arena("", 12.0)
	GameState.story_autosave = false
	player.process_mode = Node.PROCESS_MODE_DISABLED
	Music.stop(); Ambience.stop_all()
	await wait(0.8)
	context = InventoryContext.new(player)
	Sfx.sound_played.connect(func(id: StringName) -> void: heard.append(String(id)))
	clock = preload("res://tools/audio/melee_pcm_clock.gd").new()
	add_child(clock)
	if not clock.attach() or not await clock.start():
		get_tree().quit(2)
		return
	Progression.reset_run()
	var rifle := load("res://data/weapons/rifle.tres") as WeaponData
	player.loadout.equip(rifle)
	var upgrades = page("upgrades")
	upgrades._build_entries()
	var index := -1
	for i in upgrades._targets.size():
		if upgrades._targets[i]["weapon"].id == rifle.id and upgrades._targets[i]["upgrade"].id == &"mag_boost": index = i
	if index < 0: problems.append("missing rifle upgrade"); get_tree().quit(2); return
	await record("weapon-upgrade-refused", "ui_error", func(): return upgrades._activate_entry(index))
	Progression.add_credits(1000)
	await record("weapon-upgrade-bought", "ui_confirm", func(): return upgrades._activate_entry(index))
	Progression.reset_run()
	var part := Progression.arm_shield_catalog()[0]
	await record("arm-part-refused", "ui_error", func(): return upgrades._activate_arm(part))
	Progression.add_credits(1000)
	await record("arm-part-bought", "ui_confirm", func(): return upgrades._activate_arm(part))
	upgrades.free()
	Progression.reset_run()
	var item: ConsumableData = ConsumableBag.catalog()[0]
	var shop = page("shop")
	shop.shop = ShopData.new(); shop.shop.stock.append(item)
	await record("shop-refused", "ui_error", func(): return shop._activate_entry(0))
	shop.free()
	var pawn = page("pawn")
	Progression.add_credits(Progression.MAX_CREDITS)
	if Progression.pawn_block_reason(item).is_empty():
		problems.append("pawn refusal fixture did not reach a block reason"); get_tree().quit(2); return
	await record("pawn-refused", "ui_error", func(): return pawn._do_pawn(item))
	Progression.reset_run()
	await record("redeem-refused", "ui_error", func(): return pawn._do_redeem(item))
	pawn.free()
	var cyber = page("cyber")
	var ability := -1
	for i in Progression.ability_catalog().size():
		if not Progression.is_ability_unlocked(Progression.ability_catalog()[i].id): ability = i; break
	if ability < 0: problems.append("missing locked ability"); get_tree().quit(2); return
	await record("cyber-refused", "ui_error", func(): return cyber._activate_entry(ability))
	cyber.free()
	var weapons = page("weapons")
	player.loadout.equip(rifle)
	var slot := player.loadout.find_slot(&"pistol")
	await record("weapon-switch", "equip_ballistic", func(): return weapons._activate_entry(slot))
	weapons.free()
	var end: Dictionary = clock.stop()
	var pcm: Dictionary = clock.save(out_dir,end)
	var cleanup: Dictionary = clock.cleanup()
	var report := {"variant":variant,"driver":AudioServer.get_driver_name(),"display":DisplayServer.get_name(),"adapter":RenderingServer.get_video_adapter_name(),"cases":rows,"problems":problems,"pcm":pcm,"cleanup":cleanup,"notes":"Arranged isolated arena, actual page methods and player switch owner; not human play or full chapter audio acceptance."}
	var file := FileAccess.open(out_dir.path_join("report.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"\t"));file.close()
	print("NE154_UI_AUDIO ",variant," cases=",rows.size()," failed=",problems.size()," PCM=",pcm["problems"].size())
	level._inventory.open()
	await settle(3)
	if DisplayServer.get_name() != "headless": await capture("inventory-context")
	level._inventory.close()
	await finish()
	get_tree().quit(1 if not problems.is_empty() or not pcm["problems"].is_empty() else 0)
