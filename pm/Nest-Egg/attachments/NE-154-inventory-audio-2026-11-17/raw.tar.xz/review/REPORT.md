# NE-154：背包頁面音訊獨立驗證

本輪確認：五頁候選僅包含預期音效呼叫變更；9 個真頁面操作的回傳值與前後 `Progression.snapshot()`，原版／候選逐欄完全相同。既有 headless WASAPI v3 與本輪獨立原生 Forward+／WASAPI 都重現 **原版 9/9 語意音效失敗 → 候選 9/0**。四份錄音的 36 個實際 SFX sample windows 全部有非零峰值及能量，PCM 契約與讀取器負控制通過。這不是人耳驗收或整張 NE-154 結案。

## 範圍與來源

只新增本 `work/ne154-audio-independent-review/` 與自己的原生輸出。未改五頁產品、probe、音訊 clock／reader、票或設計。適用技能 `audio-pipeline`、`visual-verification` 已完整閱讀。

產品為 `ui/inventory/pages/{weapons,upgrades,shop,pawn,cyber}_page.gd`。重算腳本把既有 `original-*.gd.txt` 套用預期的音效字串替換／移除後，與候選全文比較，五頁全等：拒絕 `empty→ui_error`、兩個升級成功 `reload_done→ui_confirm`、武器頁移除額外 `reload_done`。未發現其他產品差異。

完全沿用 `work/ne154-inventory-audio-20261117/probe.gd/.tscn`。原版透過原始五頁文字建立記憶體 GDScript、只移除首行 `class_name` 避免名稱碰撞；候選載入正式頁面。兩者都綁定真正 `InventoryContext`／player，呼叫真頁面方法。**這是五頁的單因素執行中比較，並非整個 repo 的歷史 checkout，也不是滑鼠／鍵盤完整玩家流程。**

既有輸出：`C:/NE/evidence-20261117/ne154-inventory-audio/{original-v3,candidate-v3}`。這兩份是 headless display＋WASAPI，不能冒稱 Forward+ 截圖。

本輪獨立原生輸出：

- [原版 report](C:/NE/evidence-20261117/ne154-audio-independent-review/native-original/report.json)、[console](C:/NE/evidence-20261117/ne154-audio-independent-review/native-original/console.log)、[process receipt](C:/NE/evidence-20261117/ne154-audio-independent-review/native-original/process-receipt.json)、[背包情境 PNG](C:/NE/evidence-20261117/ne154-audio-independent-review/native-original/inventory-context.png)。
- [候選 report](C:/NE/evidence-20261117/ne154-audio-independent-review/native-candidate/report.json)、[console](C:/NE/evidence-20261117/ne154-audio-independent-review/native-candidate/console.log)、[process receipt](C:/NE/evidence-20261117/ne154-audio-independent-review/native-candidate/process-receipt.json)、[背包情境 PNG](C:/NE/evidence-20261117/ne154-audio-independent-review/native-candidate/inventory-context.png)。

兩張 PNG 已實際檢視，1280×720，顯示真正背包武器頁。probe 在音訊錄製結束後開啟正式背包拍照，故 PNG **只證明執行情境**，不是某個聲音正在播放的波形證據，也不是兩版舊／新頁面外觀差異圖。

## 原生命令、隔離與退出

`run_native.py` 每輪外包一次 `gpu_lock.py`；probe 本身沒有再拿鎖。與 fresh_character 協調後等共享鎖自然釋放，未重啟 GPU／ComfyUI。每輪在全新的 `native-{variant}/profile` 使用相同的 `APPDATA`、`LOCALAPPDATA`、`NE154_PROFILE` 值，兩輪 profile 彼此分離；`NE154_OUT` 為該輪絕對輸出，`NE154_VARIANT=original|candidate`。

實際命令完整 argv、環境覆寫、起訖時間、前後來源 SHA256 在上述 process receipts 與本目錄 `native-runs.json`。共同引擎命令如下（完整絕對 argv 以 receipt 為準）：

```text
python -B tools/comfyui/gpu_lock.py -- C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path C:/Users/stanl/Github/Nest-Egg --windowed --resolution 1280x720 --rendering-driver vulkan --rendering-method forward_plus --audio-driver WASAPI res://work/ne154-inventory-audio-20261117/probe.tscn
```

| 獨立原生 | 原版 | 候選 |
|---|---:|---:|
| 程序退出 | 1（預期負控制） | 0 |
| 音效語意錯誤 | 9 | 0 |
| PCM clock 問題 | 0 | 0 |
| ERROR／WARNING／洩漏日誌 | 0 | 0 |
| 五頁／probe／clock／reader 等來源前後 hash | 相同 | 相同 |
| 引擎／顯示／音訊 | Godot 4.7.2 / Windows / WASAPI | 同左 |
| 原生日誌 | Vulkan 1.4.359 / Forward+ / AMD Radeon RX 9070 XT | 同左 |

原版退出 1 是既定 9 個音效斷言失敗，沒有把它當作 PCM 損毀或引擎腳本錯誤。候選退出 0 且日誌沒有 ERROR／WARNING。`verification.json` 另保存所有輸入 report／PCM／WAV／PNG／日誌的 hash，以及審查時五頁、原始快照、probe、clock、reader、Sfx、sound bank、所涉實際音檔的 hash。

## 逐案例結果

| 案例 | 兩版回傳／狀態 | 原版事件 | 候選唯一事件 |
|---|---|---|---|
| weapon-upgrade-refused | false，不變 | empty（synth） | ui_error（file） |
| weapon-upgrade-bought | true，1000→880；rifle/mag_boost | reload_done（synth） | ui_confirm（file） |
| arm-part-refused | false，不變 | empty（synth） | ui_error（file） |
| arm-part-bought | true，1000→880；reaction_chip | reload_done（synth） | ui_confirm（file） |
| shop-refused | false，不變 | empty（synth） | ui_error（file） |
| pawn-refused | false，99999 不變 | empty（synth） | ui_error（file） |
| redeem-refused | false，不變 | empty（synth） | ui_error（file） |
| cyber-refused | false，不變 | empty（synth） | ui_error（file） |
| weapon-switch | true，Progression 不變 | equip_ballistic（file）＋reload_done（synth） | equip_ballistic（file） |

「兩版相同」是每個 case 的 `return`、完整 `before`、完整 `after` 三欄各自完全一致；不是說成功購買前後不變。兩個成功購買另獨立檢查扣款 120 與正確升級內容。原版並非沒有聲音，而是錯用了 synth，切槍另多播一個不屬於此頁的 reload_done。

## PCM 重算與負控制

執行 `python -B work/ne154-audio-independent-review/verify.py`，此次兩對錄音重算均 exit 0，結果見本目錄 `verification.json`。

沿用未修改的 `tools/audio/melee_pcm_reader.py`（`ne261-capture-reader-v2-chunked`），將本 probe 的 `pcm`、`cleanup`、driver 轉為原 reader 的輸入形狀，以唯一的 `[0,stop.frames]` 完整連續 segment 驗四條 bus。沒有放寬既有 Capture schema、audio driver 非 Dummy、零 discarded、pushed／capture／WAV frame 數一致、stop 邊界、raw 長度、finite、16-bit WAV 每樣本量化一致、gain／send 穩定、四 bus 同 epoch 及 cleanup=4 等條件。

probe 的各操作之間有 0.35 秒等待，故完整 capture 契約與實際操作窗分開檢查，沒有把操作窗假裝連續或填補缺口。實際 SFX 窗直接使用各 case 的 `start_samples.SFX` 與 `end_samples.SFX`，不使用 wall-time／假定秒數、不擴大區間、不截斷越界；嚴格要求 `0<=start<end<=capture_frames`、四 bus anchors 相同、操作窗順序不重疊。

每窗直接讀 `bus-SFX.f32` 的 stereo little-endian float32，計算 `peak=max(abs(samples))`、`energy=sum(samples²)`（雙聲道）與 `RMS=sqrt(energy/sample_count)`。既有 v3 及獨立原生，每版每個窗口都非零。獨立原生候選代表數字如下，完整 36 個窗口／雙版比較在 JSON：

| 案例 | 實際 sample window | peak | 雙聲道能量 |
|---|---|---:|---:|
| weapon-upgrade-refused | 16384..48128 | 0.06275284 | 7.491003 |
| weapon-upgrade-bought | 64512..95744 | 0.1894773 | 41.07027 |
| arm-part-bought | 161792..193024 | 0.1739485 | 68.60195 |
| weapon-switch | 402944..434176 | 0.09716275 | 8.678229 |

音檔變體、起音與音訊執行緒使不同輪次峰值／能量不逐位元相同；這些數字僅證實各實際操作窗確有可量測 PCM，不用於宣稱音量平衡、辨識品質或更好聽。

每份錄音跑 7 個拒絕負控制，共 28 個：原 reader 的空 segment、超出 stop segment 都報 `segment exceeds actual PCM`；空 raw 檔報 `float PCM size mismatch`；獨立窗讀取器的空窗、負起點、過尾、空 PCM 均拒絕。空 raw fixture 只存於本審查目錄 `negative-empty-raw/`，沒有破壞任何原始證據。原 reader 的 `verify_content` 是近戰 24 段真命中內容契約，與此九項 UI 操作無關；本輪只使用其 `load` PCM/clock 契約，未聲稱通過近戰內容驗收。

## 未驗項目

本輪沒有代勾人耳試聽、實體手把、全部 UI 操作、完整章節聲音覆蓋、音量平衡或整張票完成。錄音來自 AudioEffectCapture 的真 bus PCM，不是麥克風或喇叭實際聲學輸出。受影響範圍的正式產品測試由 root 另跑；本審查不代稱該結果。
