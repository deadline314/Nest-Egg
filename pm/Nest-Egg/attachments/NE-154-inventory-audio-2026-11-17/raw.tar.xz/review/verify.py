"""Independent page outcome and raw PCM verification using unchanged clock rules."""
import copy
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / "tools/audio"))
import melee_pcm_reader

NAMES = ["weapon-upgrade-refused", "weapon-upgrade-bought", "arm-part-refused",
         "arm-part-bought", "shop-refused", "pawn-refused", "redeem-refused",
         "cyber-refused", "weapon-switch"]
EXPECTED = ["ui_error", "ui_confirm", "ui_error", "ui_confirm", "ui_error",
            "ui_error", "ui_error", "ui_error", "equip_ballistic"]
RETURNS = [False, True, False, True, False, False, False, False, True]


def load_json(path):
    return json.loads(path.read_text(encoding="utf8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clock_index(report):
    clock = copy.deepcopy(report["pcm"])
    clock["cleanup"] = report["cleanup"]
    # The unchanged reader validates a continuous complete capture. Actual page
    # action windows are separate, gapped intervals checked below without padding.
    return {"sample_clock": clock, "runtime": {"audio_driver": report["driver"]},
            "segments": [{"bus_start_frames": {name: 0 for name in clock["buses"]},
                          "bus_end_frames": clock["stop"]["frames"].copy()}]}


def strict_window(samples, start, end):
    if type(start) is not int or type(end) is not int or not 0 <= start < end <= samples.shape[0]:
        raise ValueError("Empty, noninteger, negative or out-of-range sample window")
    window = samples[start:end]
    if window.shape != (end - start, 2) or not np.isfinite(window).all():
        raise ValueError("Incomplete or nonfinite actual PCM sample window")
    return window


def expect_reject(label, action):
    try:
        action()
    except (AssertionError, ValueError) as error:
        return {"name": label, "rejected": True, "reason": str(error)}
    raise AssertionError(f"Negative control was accepted: {label}")


def verify_recording(folder):
    report = load_json(folder / "report.json")
    index = clock_index(report)
    rate, audio = melee_pcm_reader.load(folder, index)
    samples = np.frombuffer(audio["SFX"]["raw_f32"], dtype="<f4").reshape(-1, 2)
    assert [case["name"] for case in report["cases"]] == NAMES
    rows = []
    previous_end = 0
    for case, expected, expected_return in zip(report["cases"], EXPECTED, RETURNS):
        starts, ends = case["start_samples"], case["end_samples"]
        assert set(starts) == set(ends) == {"Master", "SFX", "Music", "Ambience"}
        assert len(set(starts.values())) == len(set(ends.values())) == 1
        start, end = starts["SFX"], ends["SFX"]
        assert start >= previous_end, "Action sample windows overlap or run backwards"
        previous_end = end
        window = strict_window(samples, start, end)
        peak = float(np.max(np.abs(window)))
        energy = float(np.sum(np.square(window, dtype=np.float64)))
        rms = float(np.sqrt(energy / window.size))
        assert peak > 0 and energy > 0, f"Silent actual SFX window: {case['name']}"
        assert case["return"] is expected_return
        semantic_ok = case["events"] == [expected] and case["sources"] == [{"id": expected, "source": "file"}]
        assert bool(case["audio_ok"]) == semantic_ok
        if expected_return is False or case["name"] == "weapon-switch":
            assert case["before"] == case["after"], "Refused action/switch mutated Progression"
        else:
            assert case["before"]["credits"] == 1000 and case["after"]["credits"] == 880
            if case["name"] == "weapon-upgrade-bought":
                assert case["after"]["upgrades"] == {"rifle": ["mag_boost"]}
            else:
                assert case["after"]["arm_shield"] == ["reaction_chip"]
        rows.append({"name": case["name"], "return": case["return"],
                     "expected": expected, "events": case["events"], "sources": case["sources"],
                     "semantic_audio_ok": semantic_ok, "sample_start": start, "sample_end": end,
                     "frames": end - start, "seconds_diagnostic": (end - start) / rate,
                     "raw_f32_peak": peak, "raw_f32_energy_sum_both_channels": energy, "raw_f32_rms": rms,
                     "before": case["before"], "after": case["after"]})
    failures = sum(not row["semantic_audio_ok"] for row in rows)
    assert failures == (9 if report["variant"] == "original" else 0)
    assert len(report["problems"]) == failures
    assert report["pcm"]["problems"] == []
    empty = copy.deepcopy(index)
    for name in empty["sample_clock"]["buses"]:
        empty["segments"][0]["bus_end_frames"][name] = 0
    overflow = copy.deepcopy(index)
    for name in overflow["sample_clock"]["buses"]:
        overflow["segments"][0]["bus_end_frames"][name] += 1
    controls = [
        expect_reject("unchanged-reader-empty-window", lambda: melee_pcm_reader.load(folder, empty)),
        expect_reject("unchanged-reader-out-of-range-window", lambda: melee_pcm_reader.load(folder, overflow)),
        expect_reject("strict-window-empty", lambda: strict_window(samples, 0, 0)),
        expect_reject("strict-window-negative", lambda: strict_window(samples, -1, 1)),
        expect_reject("strict-window-past-end", lambda: strict_window(samples, 0, len(samples) + 1)),
        expect_reject("strict-window-empty-pcm", lambda: strict_window(np.empty((0, 2), dtype="<f4"), 0, 1)),
    ]
    invalid_folder = OUT / "negative-empty-raw" / folder.name
    invalid_folder.mkdir(parents=True, exist_ok=True)
    first_bus = next(iter(index["sample_clock"]["buses"]))
    (invalid_folder / f"bus-{first_bus}.f32").write_bytes(b"")
    controls.append(expect_reject("unchanged-reader-empty-raw-file", lambda: melee_pcm_reader.load(invalid_folder, index)))
    return {"folder": str(folder), "variant": report["variant"], "display": report["display"],
            "driver": report["driver"], "adapter": report["adapter"],
            "reader_version": melee_pcm_reader.READER_VERSION,
            "mix_rate": rate, "semantic_audio_failures": failures, "cases": rows,
            "negative_controls": controls,
            "evidence_sha256": {path.name: sha(path) for path in folder.iterdir()
                                 if path.is_file() and path.suffix in (".json", ".f32", ".wav", ".png", ".log")}}


def main():
    existing = Path("C:/NE/evidence-20261117/ne154-inventory-audio")
    independent = Path("C:/NE/evidence-20261117/ne154-audio-independent-review")
    pairs = [("provided-headless-v3", existing / "original-v3", existing / "candidate-v3")]
    if (independent / "native-candidate/report.json").exists():
        pairs.append(("independent-native", independent / "native-original", independent / "native-candidate"))
    output = {"scope": "Actual page outcomes and sample-clock PCM; not human listening acceptance", "pairs": []}
    for name, original_dir, candidate_dir in pairs:
        original, candidate = verify_recording(original_dir), verify_recording(candidate_dir)
        comparisons = []
        for old, new in zip(original["cases"], candidate["cases"]):
            assert old["name"] == new["name"]
            same = {field: old[field] == new[field] for field in ("return", "before", "after")}
            assert all(same.values()), (name, old["name"], same)
            comparisons.append({"name": old["name"], **same})
        output["pairs"].append({"name": name, "original": original, "candidate": candidate,
                                "progression_comparisons": comparisons})
        if name == "independent-native":
            for variant, folder in (("original", original_dir), ("candidate", candidate_dir)):
                receipt = load_json(folder / "process-receipt.json")
                assert receipt["exit_code"] == receipt["expected_exit_code"] == (1 if variant == "original" else 0)
                assert not receipt["diagnostic_lines"] and receipt["source_unchanged"]
                report = load_json(folder / "report.json")
                assert report["display"] == "Windows" and report["driver"] == "WASAPI"
                assert report["adapter"] == "AMD Radeon RX 9070 XT"
                text = (folder / "console.log").read_text(encoding="utf8")
                assert "Forward+" in text and "Vulkan" in text
                assert (folder / "inventory-context.png").is_file()
        print(f"{name}: 9/9 return/before/after equal; semantic audio 9 fail -> 0; all actual SFX windows nonzero; reader negative controls rejected")
    source_paths = ["tools/audio/melee_pcm_reader.py", "tools/audio/melee_pcm_clock.gd",
                    "work/ne154-inventory-audio-20261117/probe.gd", "work/ne154-inventory-audio-20261117/probe.tscn",
                    "autoload/sfx.gd", "data/audio/sound_bank.json", "project.godot"]
    source_paths += [f"ui/inventory/pages/{name}_page.gd" for name in ("weapons", "upgrades", "shop", "pawn", "cyber")]
    source_paths += [f"work/ne154-inventory-audio-20261117/original-{name}.gd.txt" for name in ("weapons", "upgrades", "shop", "pawn", "cyber")]
    bank = load_json(ROOT / "data/audio/sound_bank.json")["sounds"]
    for sound in ("ui_error", "ui_confirm", "equip_ballistic"):
        source_paths += [path.removeprefix("res://") for path in bank[sound]["files"]]
    audio_only = {}
    for name in ("weapons", "upgrades", "shop", "pawn", "cyber"):
        original = (ROOT / f"work/ne154-inventory-audio-20261117/original-{name}.gd.txt").read_text(encoding="utf8")
        candidate = (ROOT / f"ui/inventory/pages/{name}_page.gd").read_text(encoding="utf8")
        expected = original.replace('\tSfx.play(&"reload_done", -6.0)\n', '') if name == "weapons" else original.replace('&"empty"', '&"ui_error"').replace('&"reload_done"', '&"ui_confirm"')
        audio_only[name] = expected == candidate
        assert audio_only[name], f"Unexpected non-audio source change: {name}"
    output["candidate_exact_expected_audio_only_transform"] = audio_only
    output["review_time_source_sha256"] = {name: sha(ROOT / name) for name in source_paths}
    (OUT / "verification.json").write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf8")


if __name__ == "__main__":
    main()
