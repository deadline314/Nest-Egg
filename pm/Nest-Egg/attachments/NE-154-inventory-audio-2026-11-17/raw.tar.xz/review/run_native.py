"""Run the unchanged inventory probe once per variant under one GPU lock each."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
EVIDENCE = Path("C:/NE/evidence-20261117/ne154-audio-independent-review")
GODOT = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
SOURCES = ["work/ne154-inventory-audio-20261117/probe.gd",
           "work/ne154-inventory-audio-20261117/probe.tscn",
           "tools/audio/melee_pcm_clock.gd", "tools/audio/melee_pcm_reader.py",
           "tools/comfyui/gpu_lock.py"]
SOURCES += [f"ui/inventory/pages/{name}_page.gd" for name in ("weapons", "upgrades", "shop", "pawn", "cyber")]
SOURCES += [f"work/ne154-inventory-audio-20261117/original-{name}.gd.txt" for name in ("weapons", "upgrades", "shop", "pawn", "cyber")]


def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in SOURCES}


def main():
    receipts = []
    for variant in ("original", "candidate"):
        target = EVIDENCE / f"native-{variant}"
        if target.exists():
            raise FileExistsError(f"Refuse to overwrite evidence: {target}")
        target.mkdir(parents=True)
        profile = target / "profile"
        profile.mkdir()
        environment = os.environ.copy()
        overrides = {"APPDATA": str(profile), "LOCALAPPDATA": str(profile),
                     "NE154_PROFILE": str(profile), "NE154_OUT": str(target),
                     "NE154_VARIANT": variant}
        environment.update(overrides)
        command = [sys.executable, "-B", "tools/comfyui/gpu_lock.py", "--", GODOT,
                   "--path", str(ROOT), "--windowed", "--resolution", "1280x720",
                   "--rendering-driver", "vulkan", "--rendering-method", "forward_plus",
                   "--audio-driver", "WASAPI", "res://work/ne154-inventory-audio-20261117/probe.tscn"]
        before = hashes()
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (target / "console.log").open("wb") as log:
            process = subprocess.run(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT)
        after = hashes()
        text = (target / "console.log").read_text(encoding="utf8", errors="replace")
        diagnostics = [line for line in text.splitlines() if any(token in line for token in
                       ("SCRIPT ERROR", "ERROR:", "WARNING:", "Leaked", "leaked", "orphan"))]
        receipt = {"variant": variant, "started_utc": started,
                   "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   "command": command, "cwd": str(ROOT), "environment_overrides": overrides,
                   "exit_code": process.returncode, "expected_exit_code": 1 if variant == "original" else 0,
                   "diagnostic_lines": diagnostics, "source_before_sha256": before,
                   "source_after_sha256": after, "source_unchanged": before == after,
                   "output": str(target), "scope": "Native automated probe, not human listening acceptance"}
        (target / "process-receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf8")
        receipts.append(receipt)
        print(json.dumps({"variant": variant, "exit_code": process.returncode,
                          "diagnostics": diagnostics, "source_unchanged": before == after}), flush=True)
        if diagnostics or before != after or process.returncode != receipt["expected_exit_code"]:
            (OUT / "native-runs.json").write_text(json.dumps(receipts, indent=2), encoding="utf8")
            return 1
    (OUT / "native-runs.json").write_text(json.dumps(receipts, indent=2), encoding="utf8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
