from pathlib import Path
import hashlib,json,zipfile,subprocess,re,shutil
w=Path('work/batch1024'); n=Path('work/batch1020b'); out=Path('pm/Nest-Egg/attachments/NE-229-hitstop-order');out.mkdir(exist_ok=True)
frozen=json.loads((w/'vehicle-final-source.json').read_text())
for p,h in frozen.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
original=subprocess.check_output(['git','show','f5469ea3:tests/suite/test_input_feel.gd'])
current=Path('tests/suite/test_input_feel.gd').read_text(); rebuilt=current.split('\n\n## Combat can stop actors')[0].replace('\n\tawait _test_vehicle_same_step_stop()','')
assert rebuilt.encode()==original, 'Original InputFeel assertions/input/waits changed'
for p in ['tests/smoke_test.gd','autoload/fx.gd','game/player/player.gd','game/vehicles/vehicle.gd','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']:
 assert Path(p).read_bytes()==subprocess.check_output(['git','show','f5469ea3:'+p]),p
rows={}
for key,file in [('before_isolated','vehicle-before-isolated-console.log'),('after_changed','vehicle-changed-final-console.log'),('original_main','vehicle-original-main-console.log')]:
 t=(w/file).read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',t);assert m,file
 rows[key]=dict(zip(['checks','new_failures','known_failures','seconds'],map(int,m.groups())))
assert rows['before_isolated']['new_failures']==2
assert rows['after_changed']['new_failures']==rows['original_main']['new_failures']==0
native={}
for phase in ['before','after']:
 t=(n/('ne229-1024-step-'+phase+'.log')).read_text();m=re.search(r'checks: (\d+), failures: (\d+)',t);assert m
 native[phase]={'checks':int(m[1]),'failures':int(m[2]),'exit':int((n/('ne229-1024-step-'+phase+'.exit')).read_text()),'engine_errors':t.count('ERROR:'),'leak_diagnostics':len(re.findall('leaked|still in use at exit|PagedAllocator',t))}
 assert native[phase]['engine_errors']==native[phase]['leak_diagnostics']==0
assert native['before']['failures']==1 and native['after']['failures']==0
receipt={'base':'f5469ea3adb783405417714bbf8f7f133e32d612','failed_ci':{'run':40075701152,'job':120818443722,'checks':96395,'new_failures':3,'seconds':652},'original_assertions_input_waits_byte_identical':True,'frozen_sources':frozen,'headless':rows,'native':native,'limits':['CI snapshots prove frozen actors at the first failure, not exact earlier callback ordering. The explicit same-step control proves this additional ordering defect.','Nonisolated after-v1 has two controller menu failures; preserved, no proven root cause asserted. Original runner uses isolated profiles and passes.','Window captures are deferred after original assertions; CAPTURE_STATE is separate from GAMEPLAY_DIAG. No same-frame claim.','Software Vulkan Forward+, Dummy audio and synthetic input; no physical controller, hardware GPU, rig or full-ticket acceptance.']}
(out/'validation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
files={}
def add(p,arc=None):
 p=Path(p);assert p.is_file(),p;files[arc or str(p)]=p.read_bytes()
for p in frozen:add(p,'source/final/'+p)
for p in ['game/player/vehicle_command_input.gd','tests/suite/test_input_feel.gd']:
 files['source/before/'+p]=subprocess.check_output(['git','show','f5469ea3:'+p])
for pattern in ['vehicle-*.log','vehicle-*.json','vehicle-selector.txt','vehicle-command-original.gd','vehicle-command-final.gd','vehicle-ci-probe.gd','vehicle-ci-probe.tscn','package-vehicle-order.py','ci-f5469ea3-job120818443722.log','ci-f5469ea3-test-logs.zip']:
 for p in w.glob(pattern):add(p)
for directory in ['vehicle-before-isolated','vehicle-changed-final','vehicle-original-main','ci-f546-shards']:
 for p in (w/directory).glob('*.log'):add(p)
for phase in ['before','after']:
 for suffix in ['.log','.exit','-xvfb.log']:add(n/('ne229-1024-step-'+phase+suffix))
 for p in (n/('ne229-1024-step-'+phase)).glob('*.png'):add(p)
 shutil.copyfile(n/('ne229-1024-step-'+phase)/'player-mounts-vehicle.png',Path('pm/Nest-Egg/images')/('NE-229-step-'+phase+'.png'))
add('work/batch1024/native-large.py');add('work/batch1024/window_capture.gd');add(out/'validation.json')
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(out/'raw.zip') as z:
 for name,m in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==m['sha256'],name
h=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest();main=rows['original_main']
(out/'README.md').write_text(f'''# NE-229：同一步受擊停格不漏掉載具互動

先讀User-guide及[相近作品與既有輸入研究](../../../../design/20-campaign-experience/VEHICLE_HITSTOP_INPUT.md)。保留原停格、距離、空車、上下車保護、長按與暫停規則。互動接收者先輪詢、之後同一步戰鬥停用角色時，原本會先記住按住卻沒有真正執行；改在戰鬥與角色之後觀察同一步局部停格。

[完整收據](validation.json)、[逐檔SHA](manifest.json)、[全部原檔](raw.zip)。原InputFeel的所有既有斷言、輸入與等待逐位元重建一致；新增5項，原Smoke、Fx、玩家、載具與runner／selector／filters／known failures保持。

| 同一控制 | 修前 | 修後 |
|---|---|---|
| 原runner隔離輸入套件，80ms同一步停格 | 123項／2新失敗 | 123項／0新／已知失敗 |
| 原生舊level_01同一原遊戲流程 | 20項／1失敗 | 20項／0失敗 |

原選擇器基準f5469ea3只選InputFeelSuite，修後123／0，16秒。額外原main完整流程為{main['checks']}項／0新／已知失敗，{main['seconds']}秒；不是把核心流程排除在驗證外。最初未介入原遊戲流程六輪96／0；觀測用輸入列印僅在那六輪存在，正式產品沒有列印。另一次直接非隔離修後嘗試91／2（選單焦點、難度確認）原log保留，不補造根因；正式原runner隔離資料後123／0。兩輪原生皆0引擎ERROR、0退出洩漏診斷，exit1／0；六張真正1280×720視窗PNG逐張檢視，記錄SHA。Headless輸入壞資料案例會刻意印原有InputFeel ERROR及InputBindings警告，由原filters辨識，不稱完全無ERROR。

f5469ea3的完整[CI40075701152](https://github.com/deadline314/Nest-Egg/actions/runs/40075701152)實際96,395項／3新失敗、652秒。原artifact與job全log留存。第一個失敗時玩家健康5、NORMAL、無鎖／暫停，玩家及空載具皆被Fx停用；第二個原想下車的輸入卻成搭乘，第三個仍在載具。這次有真實停格狀態，但CI未記錄更早接收者的順序；80ms同一步介入證明額外真缺口，不宣稱已從原CI還原唯一callback順序。新提交完整CI須另核對，未以局部通過代稱完整綠燈。

照片在原斷言後延遲讀回，GAMEPLAY_DIAG與CAPTURE_STATE分開，不稱同一物理格。修後搭乘圖可見真正機甲血條；其餘圖可能已有自然戰鬥受擊／射擊，並非刻意清空敵人的擺拍。原生未停掉原遊戲流程的敵人。軟體Vulkan／Forward+／Dummy音訊、合成按鍵及明示80ms控制，不代稱硬體GPU、實體手把、人物接點或整票完成。真正停格owner與deadline保持，未靠提早解凍或加長原等待。

原檔{len(files)}項、{(out/'raw.zip').stat().st_size:,} bytes；zip SHA `{h}`，每項已解出核對。
''')
p=Path('design/20-campaign-experience/VEHICLE_HITSTOP_INPUT.md');p.write_text(p.read_text()+'''\n## 2026-10-24：同一步停格的接收順序\n\nNE-228 f5469ea3完整CI仍96395／3，取得失敗當刻真正狀態：首次搭乘時玩家NORMAL、生命5、無鎖／暫停，玩家及空載具同時Fx停用。這證明先前60ms修正不足；較早的接收者順序沒有CI快照，不補造唯一根因。\n\n原接收者以較早物理優先序輪詢，正常時也會記住已按住。如果同一步戰鬥在輪詢後、角色前停用角色，正常路徑沒執行且常駐路徑已記住按住。新增獨立80ms控制，在兩者之間停用真正玩家及原關卡載具，修前輸入套件123／2、修後123／0；原生20／1→20／0。把接收者移到戰鬥及角色之後，仍只處理Fx實際擁有的局部停頓。正常路徑、既有距離、空車、上下車保護、長按、Pause與GameplayLock保持，停格期限不動。原既有輸入／等待／斷言逐位元重建相同；原main另跑，不改原測試時序。\n\n[原CI、負控制、中途失敗、實際照片與範圍](../../pm/Nest-Egg/attachments/NE-229-hitstop-order/README.md)。照片延遲讀回，不能拿較晚畫面代稱斷言當格；合成操作及軟體GPU不代稱實體手把驗收。\n''')
p=Path('pm/Nest-Egg/[NE-229]補齊全流程手把操作.md');s=p.read_text();assert '# Commit-8' not in s
s+=f'''\n\n# Commit-8\n\n## 內文\n\n按下附近載具互動的同一步才受到短暫停格，原本仍可能沒有搭乘，後一個離開操作就錯成搭乘。現在這個交錯順序也能接收一次上下車，維持原停格時間、距離、空車、上下車保護、長按與暫停規則。\n\n接續f5469ea3完整CI的三項失敗，保存真正停格狀態；先前控制尚未涵蓋的同一步交錯，以同一原流程做前後對照。[成功、失敗、CI原檔、六圖與驗證界線](attachments/NE-229-hitstop-order/README.md)。原CI較早的操作順序沒有快照，不以控制替代唯一根因證明。\n\n### 測試結果\n\n| 項目 | 結果 |\n|---|---|\n| 原runner隔離輸入套件＋5項 | 修前123項／2新失敗；修後123項／0新／已知失敗 |\n| 原main完整核心流程 | {main['checks']}項／0新／已知失敗，{main['seconds']}秒 |\n| Forward+同一原遊戲流程 | 修前20項／1失敗；修後20項／0失敗，兩輪0引擎ERROR／退出洩漏診斷 |\n\n原斷言、輸入、等待與選擇器保持。合成輸入、明示短暫停格與軟體Vulkan分開記錄，整票條件維持真正證據要求。\n\n### 前後圖\n\n| 修前互動未搭乘 | 修後真正機甲血條出現 |\n|---|---|\n| ![修前](images/NE-229-step-before.png) | ![修後](images/NE-229-step-after.png) |\n''';p.write_text(s)
p=Path('pm/user_guide.md');p.write_text('2026-10-24（NE-229）：停格若在同一步較早輸入輪詢後才開始，也不能吞掉上下車；保留停格、長按、距離與保護。f546完整CI三項失敗的真停格狀態與較早callback順序證據分開，不補造唯一根因。[123項負控制、原main、原生六圖及中途失敗](Nest-Egg/attachments/NE-229-hitstop-order/README.md)。原生延遲讀回與原斷言時刻分開，仍不代稱實體手把。\n\n'+p.read_text())
print(json.dumps(receipt,ensure_ascii=False,indent=2));print('PACKAGED',len(files),h)
