extends "res://tests/smoke_test.gd"

func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	for round_index in 6:
		print("VEHICLE_CONTROL_ROUND ", round_index)
		await _test_gameplay()
	await _finish()
