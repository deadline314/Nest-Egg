extends Node

const Capture := preload("res://tools/viewport_capture.gd")
var _out := ""
var _checks := 0
var _failures := 0


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	GameState.story_autosave = false
	Story.auto_skip = true
	Enemy.activation_culling_enabled = false
	AimInput.using_gamepad = true
	AimInput._last_stick_dir = Vector2.RIGHT
	Settings.use_storage("user://melee-sweep-proof.cfg")
	Settings.set_reduce_ui_motion(true)
	add_child(LightKit.create_environment())
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(EnemySuiteBase.map_data())
	add_child(level)
	for frame in 14:
		await get_tree().physics_frame
	var player := level.player
	player.global_position = Vector2(160.0, EnemySuiteBase.FLOOR_Y)
	player.health.setup(999, 0.0)
	player.facing = 1
	player.aim_dir = Vector2.RIGHT
	player.loadout.reset(load("res://data/weapons/melee/melee_dagger.tres") as WeaponData)
	player._melee_cooldown_left = 0.0
	var enemy := level._create_enemy(load("res://data/enemies/grunt.tres") as EnemyData)
	enemy.position = player.global_position + Vector2(20.0, 0.0)
	level._entities.add_child(enemy)
	enemy.data = enemy.data.duplicate()
	enemy.data.detect_range = 0.0
	enemy.data.attack_range = 0.0
	enemy.data.move_speed = 0.0
	enemy.health.setup(999, 0.0)
	var hits: Array[Vector2] = []
	var listened := func(point: Vector2, _lethal: bool) -> void: hits.append(point)
	EventBus.hit_confirmed.connect(listened)
	level.camera.snap_to_target()
	for frame in 5:
		await get_tree().physics_frame
	Input.action_press(&"melee")
	await get_tree().physics_frame
	Input.action_release(&"melee")
	for frame in 180:
		if not hits.is_empty():
			break
		await get_tree().physics_frame
	_check(player.melee.is_active() and player.melee.landed, "the actual attack hits during the active window")
	_check(hits.size() == 1 and enemy.health.current == 998, "one real dagger damage lands in the original actor")
	_check(hits.size() == 1 and hits[0].is_finite() and enemy.hurtbox.contains_point(hits[0], 1.0), "rendered hit uses the original location on the opponent")
	print("DAGGER contact=", hits, " health=", enemy.health.current, " phase=", player.melee.phase)
	await RenderingServer.frame_post_draw
	_check(Capture.image(get_viewport()).save_png(_out.path_join("dagger-contact.png")) == OK, "captured the native visible contact")
	EventBus.hit_confirmed.disconnect(listened)
	Fx.thaw_all()
	level.queue_free()
	for frame in 8:
		await get_tree().physics_frame
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _failures])
	get_tree().quit(1 if _failures else 0)


func _check(success: bool, label: String) -> void:
	_checks += 1
	_failures += int(not success)
	if not success:
		printerr("FAIL: ", label)
