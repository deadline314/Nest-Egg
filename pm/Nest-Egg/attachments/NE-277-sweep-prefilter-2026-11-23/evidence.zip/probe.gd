extends Node

const Original := preload("./original_sweep.gd")
const Current := preload("res://core/melee_contact_sweep.gd")
const IDS := ["blade", "dagger", "glaive", "maul", "whip"]
const PATH := "res://data/weapons/melee/melee_%s.tres"

var _comparisons := 0
var _failures := 0


class CountedHurtbox extends Hurtbox:
	var calls := 0

	func triangle_contact(a: Vector2, b: Vector2, c: Vector2) -> Vector2:
		calls += 1
		return super(a, b, c)


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	var box := CountedHurtbox.new()
	add_child(box)
	box.setup(Combat.Team.ENEMY, null, Vector2(13.0, 25.0), Vector2(1.0, -4.0))
	var control := Original.new()
	var candidate := Current.new()
	var indexed := 0
	var hits := 0
	var misses := 0
	var before_calls := 0
	var after_calls := 0
	for id: String in IDS:
		var weapon := load(PATH % id) as WeaponData
		var pivot := Vector2(512.0, 234.0)
		_capture_pair(control, candidate, weapon, pivot)
		var default_size := control.current.size()
		for mirrored: bool in [false, true]:
			for angle: float in [0.0, 0.34, -0.72]:
				for shift: Vector2 in [Vector2.ZERO, Vector2(4000.0, -1500.0)]:
					_capture_pair(control, candidate, weapon, pivot + shift)
					box.transform = Transform2D(angle, Vector2(-1.2 if mirrored else 1.2, 0.7), 0.15, pivot + shift)
					for gx in range(-3, 15):
						for gy in range(-6, 8):
							box.position = pivot + shift + Vector2(gx * 4.0, gy * 4.0)
							for limits: Vector2 in [Vector2(0.0, 1.0), Vector2(0.31, 0.7), Vector2(0.5, 0.5)]:
								box.calls = 0
								var old_hit: Vector2 = control.contact(box, limits.x, limits.y)
								before_calls += box.calls
								box.calls = 0
								var new_hit: Vector2 = candidate.contact(box, limits.x, limits.y)
								after_calls += box.calls
								_check(old_hit == new_hit, "%s %s %s %s %s: %s versus %s" %
										[id, mirrored, angle, box.position, limits, old_hit, new_hit])
								hits += int(old_hit.is_finite())
								misses += int(not old_hit.is_finite())
		indexed += default_size / 3

	# A degenerate endpoint and exact tangent must still be checked.
	var edge := Vector2(4.0, 2.0)
	box.transform = Transform2D.IDENTITY
	box.resize(Vector2(8.0, 4.0), Vector2.ZERO)
	var geometry := PackedVector2Array([edge, edge, edge])
	for sweep in [control, candidate]:
		sweep.previous = geometry
		sweep.current = geometry
		sweep._valid = true
	_check(control.contact(box) == edge and candidate.contact(box) == edge, "inclusive point contact on an exact box corner")
	box.transform = Transform2D(Vector2(1.0, 0.0), Vector2(1.0, 0.00000001), Vector2.ZERO)
	_check(not box.contact_bounds().has_area(), "near-singular boxes use the original detailed query")
	_check(candidate.contact(box) == control.contact(box), "near-singular transforms retain the old answer")
	print("GEOMETRY triangles=", indexed, " hit=", hits, " miss=", misses, " old_triangle_calls=", before_calls, " new_triangle_calls=", after_calls)
	_check(hits > 100 and misses > 100 and after_calls < before_calls / 2, "prefilter materially reduces detailed work across real visible assets")
	print("checks: %d, failures: %d" % [_comparisons, _failures])
	get_tree().quit(1 if _failures else 0)


func _capture_pair(control: RefCounted, candidate: RefCounted, weapon: WeaponData, pivot: Vector2) -> void:
	for sweep in [control, candidate]:
		sweep.clear()
	var before := Transform2D(-0.4, pivot)
	var after := Transform2D(0.6, pivot + Vector2(5.0, 2.0))
	var rope: SoftWhip
	if weapon.melee_shape == "whip":
		rope = SoftWhip.new()
		rope.floor_y = pivot.y + 9.0
		for frame in 20:
			rope.step(1.0 / 60.0, pivot, Vector2.RIGHT, 55.0, pivot + Vector2(48.0, -20.0), 0.15)
	for sweep in [control, candidate]:
		sweep.capture(weapon, before, 1, rope, Transform2D.IDENTITY)
	if rope != null:
		rope.step(1.0 / 60.0, after.origin, Vector2(1.0, 0.2).normalized(), 55.0, pivot + Vector2(48.0, 4.0), 0.25)
	for sweep in [control, candidate]:
		sweep.capture(weapon, after, 1, rope, Transform2D.IDENTITY)


func _check(passed: bool, message: String) -> void:
	_comparisons += 1
	if not passed:
		_failures += 1
		if _failures < 30:
			printerr("FAIL: ", message)
