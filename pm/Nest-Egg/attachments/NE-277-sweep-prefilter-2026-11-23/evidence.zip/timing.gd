extends Node

const Original := preload("./original_sweep.gd")
const Current := preload("res://core/melee_contact_sweep.gd")
const IDS := ["blade", "dagger", "glaive", "maul", "whip"]
const PATH := "res://data/weapons/melee/melee_%s.tres"


func _ready() -> void:
	var previous_case := Transform2D(-0.4, Vector2(512.0, 234.0))
	var next_case := Transform2D(0.6, Vector2(517.0, 236.0))
	var baseline: Array[RefCounted] = []
	var candidates: Array[RefCounted] = []
	for id: String in IDS:
		var weapon := load(PATH % id) as WeaponData
		var control := Original.new()
		var candidate := Current.new()
		var rope: SoftWhip
		if id == "whip":
			rope = SoftWhip.new()
			rope.floor_y = 243.0
			for frame in 20:
				rope.step(1.0 / 60.0, previous_case.origin, Vector2.RIGHT, 55.0, Vector2(560, 214), 0.2)
		for sweep in [control, candidate]:
			sweep.capture(weapon, previous_case, 1, rope, Transform2D.IDENTITY)
		if rope != null:
			rope.step(1.0 / 60.0, next_case.origin, Vector2.RIGHT, 55.0, Vector2(560, 238), 0.25)
		for sweep in [control, candidate]:
			sweep.capture(weapon, next_case, 1, rope, Transform2D.IDENTITY)
		baseline.append(control)
		candidates.append(candidate)
	var targets: Array[Hurtbox] = []
	for x: float in [506.0, 520.0, 534.0, 540.0, 556.0, 573.0, 592.0]:
		for y: float in [222.0, 242.0, 265.0]:
			var box := Hurtbox.new()
			add_child(box)
			box.setup(Combat.Team.ENEMY, null, Vector2(13.0, 25.0), Vector2(1.0, -4.0))
			box.transform = Transform2D(0.34, Vector2(1.2, 0.7), 0.15, Vector2(x, y))
			targets.append(box)
	_measure(baseline, targets)
	_measure(candidates, targets)
	var ratios := PackedFloat64Array()
	var totals_match := true
	for pair in 9:
		var old: Vector2i
		var new: Vector2i
		if pair % 2 == 0:
			old = _measure(baseline, targets)
			new = _measure(candidates, targets)
		else:
			new = _measure(candidates, targets)
			old = _measure(baseline, targets)
		totals_match = totals_match and old.y == new.y and old.y > 0
		var ratio := float(new.x) / float(old.x)
		ratios.append(ratio)
		print("PAIR ", pair + 1, " old_us=", old.x, " new_us=", new.x, " matched_hits=", old.y, " ratio=", ratio)
	ratios.sort()
	print("Contact queries per sample: ", IDS.size() * targets.size() * 15, ", median ratio: ", ratios[4])
	var passed := totals_match and ratios[4] < 0.9
	print("checks: 2, failures: ", int(not totals_match) + int(ratios[4] >= 0.9))
	get_tree().quit(0 if passed else 1)


func _measure(sweeps: Array[RefCounted], targets: Array[Hurtbox]) -> Vector2i:
	var hits := 0
	var started := Time.get_ticks_usec()
	for sample in 15:
		for sweep in sweeps:
			for box in targets:
				var result: Vector2 = sweep.contact(box, 0.2, 0.85)
				hits += int(result.is_finite())
	return Vector2i(Time.get_ticks_usec() - started, hits)
