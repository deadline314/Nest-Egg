from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import sys

base=Path(__file__).resolve().parent
root=Path.cwd()
project=Path('D:/NestEggVerification/ne218-baseline-20261117')
revision='113b22ac9ade4fe5b11e4279a99a421ef63e3cc4'
paths=json.loads((base.parent/'evidence-20261120-ne88-crowd/published-source.json').read_bytes())
label=sys.argv[1]
if label!='before':
    paths.update(json.loads((base/'candidate.json').read_bytes()))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=project).decode().strip()==revision
held=lambda:all(sha256((project/path).read_bytes()).hexdigest()==digest for path,digest in paths.items())
assert held()
directory=base/label
directory.mkdir()
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_DATA_HOME'):
    env[key]=str(directory/'profile'/key)
cmd=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
     'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project),
     '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','WASAPI',
     '--resolution','1280x720','--fixed-fps','60',str(base/'probe.tscn'),'--','--out='+str(directory)]
(directory/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (directory/'raw.log').open('wb') as stdout:
    proc=subprocess.run(cmd,cwd=project,env=env,stdout=stdout,stderr=subprocess.STDOUT,timeout=135)
raw=(directory/'raw.log').read_text(encoding='utf-8',errors='replace')
receipt={'exit':proc.returncode,'source_held':held(),'issues':[line for line in raw.splitlines() if 'ERROR:' in line]}
(directory/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(raw[-2100:],receipt,flush=True)
assert receipt=={'exit':0,'source_held':True,'issues':[]} and 'NE275_BASE_REDRAW cases=7 failures=0' in raw and 'RX 9070 XT' in raw
