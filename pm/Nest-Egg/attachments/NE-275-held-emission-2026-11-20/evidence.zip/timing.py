from hashlib import sha256
from itertools import permutations
from pathlib import Path
from shutil import copyfile
from statistics import median
import json
import os
import subprocess
import sys

root=Path.cwd()
base=Path(__file__).resolve().parent
live=Path('D:/NestEggVerification/ne218-baseline-20261117')
history=Path('C:/NE/ne275-grip-20261119/before')
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
assert json.loads((base/'after/receipt.json').read_bytes())=={'exit':0,'source_held':True,'issues':[]}
revision=(history.parent/'before-commit.txt').read_text().strip()
assert revision.startswith('a42eaa524')
historical={}
for path in ('tools/melee_art_probe.gd','game/player/player_visual.gd','data/weapon_art/melee.json','project.godot'):
    source=subprocess.check_output(['git','show',f'{revision}:{path}'],cwd=root)
    assert (history/path).read_bytes()==source,path
    historical[path]=sha256(source).hexdigest()
rel='game/player/melee_held.gd'
variants={'current':base/'baseline-melee-held.gd','candidate':root/rel}
sha=lambda path:sha256(path.read_bytes()).hexdigest()
expected=json.loads((base/'candidate.json').read_bytes())[rel]
assert sha(variants['candidate'])==sha(live/rel)==expected
assert sha(variants['current'])!=expected
files=json.loads((base.parent/'evidence-20261120-ne88-crowd/published-source.json').read_bytes())
assert files[rel]==sha(variants['current'])
assert len(files)>10000

# Keep the original log's timings reproducible with fresh per-variant profiles.
for probe in ('settings','timing'):
    path=base/(probe+'.tscn')
    path.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{(base/(probe+".gd")).as_posix()}" id="1"]\n[node name="WeaponEvidence" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')


def start(label, project, probe, options, fixed=False):
    directory=base/label
    directory.mkdir()
    profile=base/(('historical' if project==history else label.split('-')[1])+'-profile')
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(profile/key)
    prefix=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',engine,'--path',str(project),
        '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720']
    if fixed:
        prefix.extend(('--fixed-fps','60'))
    cmd=[*prefix,'--quit-after','22000',str(base/(probe+'.tscn')),'--','--out='+str(directory),*options]
    (directory/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    with (directory/'raw.log').open('wb') as log:
        result=subprocess.run(cmd,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    raw=(directory/'raw.log').read_text(encoding='utf-8',errors='replace')
    assert result.returncode==0 and 'SCRIPT ERROR' not in raw and '9070 XT' in raw,(label,raw[-1800:])
    return directory,raw

settings,raw=start('visual-settings',live,'settings',[],fixed=True)
check=json.loads((settings/'current-settings.json').read_bytes())
assert 'NE275_CURRENT_SETTINGS tools failures=0' in raw and check['failures']==0 and len(check['weapons'])==5
assert all(len(modes)==4 for modes in check['weapons'].values())
print('20 native settings combinations passed',flush=True)


def run(variant, trial):
    project=history if variant=='historic' else live
    if project==live:
        copyfile(variants[variant],live/rel)
    tag=('before-' if variant=='historic' else 'after-')+variant+'-'+str(trial)
    directory,raw=start(tag,project,'timing',['--tag='+tag,'--quality=high','--perf'])
    assert f'NE275_HISTORIC_TIMING: {tag} weapons=5 failures=0' in raw
    data=json.loads((directory/'grip-timings.json').read_bytes())
    assert data['resolution']==[1280,720] and data['vsync']==data['max_fps']==data['failures']==0
    assert data['renderer']=='forward_plus' and '9070 XT' in data['gpu']
    assert not data['reduced_flashes'] and not data['reduced_ui_motion']
    records=data['records']
    assert set(records)=={'blade','dagger','glaive','maul','whip'}
    for item in records.values():
        assert item['drawn'] and item['dedicated_attachment']==(project==live) and len(item['samples_ms'])==600
        assert item['physics_steps']>=10 and item['scene_draw_calls']>0
    if project==live:
        assert sha(live/rel)==sha(variants[variant])
    values={id:median(item['samples_ms']) for id,item in records.items()}
    print(variant,trial,{key:round(value,3) for key,value in values.items()},flush=True)
    return values

order=('historic','current','candidate')
trials=[]
try:
    for label in order:
        run(label,'warm')
    for index, group in enumerate(permutations(order),1):
        trials.append({'order':group,'results':{label:run(label,index) for label in group}})
finally:
    copyfile(variants['candidate'],live/rel)
    assert sha(live/rel)==expected
assert all(sha(live/name)==(expected if name==rel else digest) for name,digest in files.items())
assert all(sha(history/name)==digest for name,digest in historical.items())
report={'historic_revision':revision,'historic_sha256':historical,'live_candidate':expected,'trials':trials}
for baseline in ('historic','current'):
    stats={}
    for id in ('blade','dagger','glaive','maul','whip'):
        older=[trial['results'][baseline][id] for trial in trials]
        newer=[trial['results']['candidate'][id] for trial in trials]
        ratios=[100*(a/b-1) for a,b in zip(newer,older)]
        stats[id]={'before_median_ms':median(older),'candidate_median_ms':median(newer),
            'paired_median_pct':median(ratios),'paired_min_pct':min(ratios),'paired_max_pct':max(ratios)}
    report[baseline]=stats
(base/'timings.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ('historic','current')},indent=2),flush=True)
