
from pathlib import Path
from collections import Counter
from math import atan2, degrees, dist, hypot
import json

base=Path(__file__).resolve().parent
variants={
    'ch2_loading--1-low': ('ch2_loading', -1, 'low'),
    'ch2_loading-1-high': ('ch2_loading', 1, 'high'),
    'ch2_market_gate--1-high': ('ch2_market_gate', -1, 'high'),
    'ch2_market_gate-1-low': ('ch2_market_gate', 1, 'low'),
}

def read(path):
    return json.loads(path.read_bytes())

def metrics(record):
    aim=record['phases']['locked']
    release=record['phases']['release']
    middle=record['fan'][2]
    x,y=middle['velocity']
    target=(aim['player'][0],aim['player'][1]-24)
    offset=(target[0]-middle['origin'][0], target[1]-middle['origin'][1])
    return {'locked_hand_gap':dist(aim['emitter'], (aim['hand'][0],aim['hand'][1]-1.5)),
            'last_grip_to_release':dist(record['last_windup_grip'],middle['origin']) if 'last_windup_grip' in record else None,
            'center_ray_to_target':abs(offset[0]*y-offset[1]*x)/hypot(x,y),
            'spread':sum(abs(degrees(atan2(x*vy-y*vx,x*vx+y*vy))) for vx,vy in (
                record['fan'][0]['velocity'],record['fan'][-1]['velocity'])), 'sheets':len(record['fan']),
            'frames':{name:frame['frame'] for name,frame in record['phases'].items()}}

summary={}
for case,scenario in variants.items():
    rows={}
    for version in ('stock','final','reviewed'):
        directory=base/f'{version}-{case}'
        trace=read(directory/'paper.json')
        assert (trace['map'],trace['side'],trace['tier'])==scenario
        assert '9070 XT' in trace['adapter'] and trace['skin']=='ch2_bill_thrower'
        assert trace['phases']['locked']['facing']==scenario[1]
        assert all(abs(shot['speed']-85)<0.001 and shot['damage']==1 for shot in trace['fan'])
        assert len({tuple(shot['origin']) for shot in trace['fan']})==1
        assert 'ERROR:' not in (directory/'raw.log').read_text(encoding='utf-8-sig')
        points=metrics(trace)
        assert abs(points['spread']-46)<0.001 and points['sheets']==5
        rows[version]=points
    old,trial,final=(rows[variant] for variant in ('stock','final','reviewed'))
    assert old['locked_hand_gap']>7.0 and trial['locked_hand_gap']<0.001 and final['locked_hand_gap']<0.001
    assert old['center_ray_to_target']<0.05 and trial['center_ray_to_target']>10.0 and final['center_ray_to_target']<0.05
    assert final['last_grip_to_release']<0.05
    assert old['frames']==final['frames']
    summary[case]=rows
(base/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))


