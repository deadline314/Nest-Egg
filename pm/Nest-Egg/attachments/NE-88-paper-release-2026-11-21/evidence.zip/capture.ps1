param([string]$Mode='stock')
$ErrorActionPreference='Stop'
$root='C:/Users/stanl/Github/Nest-Egg'
$ev=$PSScriptRoot.Replace('\','/')
$shared='D:/NestEggVerification/ne218-baseline-20261117'
$py='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
$godot='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$env:APPDATA="$ev/$Mode-profile/AppData"
$env:LOCALAPPDATA="$ev/$Mode-profile/Local"
$common=@('--path',$shared,'--rendering-method','forward_plus','--rendering-driver','vulkan','--resolution','1280x720','--max-fps','120','--quit-after','800')
foreach($spec in @(@('ch2_market_gate','-1','high'),@('ch2_market_gate','1','low'),@('ch2_loading','1','high'),@('ch2_loading','-1','low'))) {
    $map,$side,$quality=$spec
    $out="$ev/$Mode-$map-$side-$quality"
    New-Item -ItemType Directory -Force $out | Out-Null
    & $py -B "$root/tools/comfyui/gpu_lock.py" -- $godot @common "$ev/paper.tscn" -- "--out=$out" "--map=$map" "--side=$side" "--quality=$quality" *> "$out/raw.log"
    $engineExit=$LASTEXITCODE
    Get-Content -LiteralPath "$out/raw.log" -Tail 10
    Write-Output "$map $side $quality exit $engineExit"
    if ($engineExit -eq 0 -and (Test-Path "$out/paper.json") -and -not (Select-String -Pattern 'ERROR:' -Quiet -LiteralPath "$out/raw.log")) {
        Write-Output "Verified capture $out"
    }
}

