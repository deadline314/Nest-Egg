extends ScenarioBase

var map_id := "ch2_market_gate"
var side := -1
var tier := "high"
var actor: Enemy
var phases: Dictionary = {}
var fan: Array[Dictionary] = []
var last_windup_grip := Vector2.ZERO

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
		elif arg.begins_with("--map="):
			map_id = arg.trim_prefix("--map=")
		elif arg.begins_with("--side="):
			side = int(arg.trim_prefix("--side="))
		elif arg.begins_with("--quality="):
			tier = arg.trim_prefix("--quality=")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()

func _run() -> void:
	Settings.use_storage("user://paper_audit.cfg")
	Settings.set_light_quality(LightQuality.Tier.LOW if tier == "low" else LightQuality.Tier.HIGH)
	Settings.set_brightness(0.5)
	add_child(LightKit.create_environment())
	GameState.start_new_run(GameState.difficulties[1])
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	level = Level.new()
	level.configure(load("res://data/levels/%s.tres" % map_id) as LevelData)
	add_child(level)
	level._next_story_trigger = level._layout.story_triggers.size()
	player = level.player
	AimInput.set_virtual_gamepad(player, true)
	level._lighting._lightning_gap = 1.0e9
	for node in level._entities.get_children():
		if node is Enemy:
			if node.data.id == &"ch2_bill_thrower" and actor == null:
				actor = node
			else:
				node.set_physics_process(false)
				node.hurtbox.enabled = false
				for part: Hurtbox in node.hurtbox.parts:
					part.enabled = false
				if node.contact != null:
					node.contact.active = false
	if actor == null:
		push_error("Missing authored bill thrower: " + map_id)
		get_tree().quit(2)
		return
	var anchor := actor.global_position
	player.health.grant_invulnerability(10.0)
	for tick in 6:
		await get_tree().physics_frame
	var p := anchor + Vector2(88 * side, 0)
	var support := player.get_world_2d().direct_space_state.intersect_ray(
		PhysicsRayQueryParameters2D.create(p - Vector2(0, 8), p + Vector2(0, 34), Layers.SOLID))
	if support.is_empty():
		push_error("No floor at original bill thrower approach: " + str(p))
		get_tree().quit(2)
		return
	player.global_position = support["position"] - Vector2(0, 0.2)
	player.velocity = Vector2.ZERO
	var camera := level.camera
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * 3.4
	camera.offset = Vector2.ZERO
	camera.global_position = (player.global_position + actor.global_position) * 0.5 - Vector2(0, 26)
	camera.reset_smoothing()
	camera.force_update_scroll()
	for tick in 210:
		await get_tree().physics_frame
		var state := str(actor.fsm.current)
		if state == "windup":
			last_windup_grip = actor.anchor_node(&"hand_front").global_position + Vector2(0, -1.5)
			if not phases.has("tracking") and actor.fsm.time_in_state > 0.15:
				await _frame("tracking")
			if not phases.has("locked") and actor._telegraph_left <= 0.065 and actor._telegraph_left > 0.0:
				await _frame("locked")
		elif state == "recover":
			if not phases.has("release"):
				_measure_fan()
				await _frame("release")
			if not phases.has("restocked") and actor.fsm.time_in_state > 0.38:
				await _frame("restocked")
				break
	var file := FileAccess.open(out_dir.path_join("paper.json"), FileAccess.WRITE)
	if file == null:
		push_error("Could not save paper audit")
		get_tree().quit(2)
		return
	file.store_string(JSON.stringify({"map":map_id,"side":side,"tier":tier,"skin":actor.rig.skin_id,
		"adapter":RenderingServer.get_video_adapter_name(),"fan":fan,"phases":phases,"last_windup_grip":_v(last_windup_grip)}, "  ") + "\n")
	file.close()
	if phases.size() != 4 or fan.size() != 5:
		failures += 1
	await finish()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	get_tree().quit(1 if failures else 0)

func _frame(label: String) -> void:
	await RenderingServer.frame_post_draw
	var logical_hand := actor.anchor_node(&"hand_front").global_position
	phases[label] = {"state":str(actor.fsm.current),"frame":Engine.get_physics_frames(),"facing":actor.facing,
		"hand":_v(logical_hand),"emitter":_v(actor._muzzle()),"distance":logical_hand.distance_to(actor._muzzle()),
		"aim":_v(actor._aim),"feet":_v(actor.global_position),"player":_v(player.global_position),
		"hand_screen":_v(get_viewport().get_canvas_transform() * logical_hand),
		"emit_screen":_v(get_viewport().get_canvas_transform() * actor._muzzle())}
	capture(label)

func _measure_fan() -> void:
	for node: Node in ProjectilePool.container().get_children():
		var shot := node as Projectile
		if shot != null and shot.active and shot.team == Combat.Team.ENEMY and shot.spec.source_id == &"bill_paper":
			fan.append({"position":_v(shot.global_position),"velocity":_v(shot.velocity),
				"origin":_v(shot.global_position - shot.velocity * (shot.spec.lifetime - shot._life)),
				"damage":shot.spec.damage,"speed":shot.velocity.length()})

func _v(value: Vector2) -> Array[float]:
	return [value.x,value.y]


