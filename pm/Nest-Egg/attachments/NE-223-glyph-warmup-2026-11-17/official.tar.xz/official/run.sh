#!/usr/bin/env bash
set -uo pipefail
cd /d/NestEggVerification/camera-20261117
python3() { 'C:/Users/stanl/AppData/Local/Programs/Python/Python313/python.exe' "$@"; }
export -f python3
export GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
export SHARDS=2
export LOG_DIR='D:/NestEggVerification/evidence-20261117/ne223-glyph-official-56bb/shards'
mkdir -p "$LOG_DIR"
export PYTHONIOENCODING=utf-8
tools/run_tests_changed.sh 56bb233db929973adf380a4631066a4c8b79dc58
