"""Run the unmodified affected selector against 56bb with two workers and full immutable-source receipts."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path("D:/NestEggVerification/camera-20261117")
OUT = Path("D:/NestEggVerification/evidence-20261117/ne223-glyph-official-56bb")
BASE = "56bb233db929973adf380a4631066a4c8b79dc58"
assert (OUT / "preparation.json").exists() and not (OUT / "runner.log").exists()
names = subprocess.check_output(["git", "ls-files", "-co", "--exclude-standard", "-z"], cwd=ROOT).decode("utf8").split("\0")
exclude = ("pm/", "design/", "work/", ".agents/", ".claude/", ".github/", "docs/")
names = sorted({name for name in names if name and not name.startswith(exclude) and (ROOT / name).is_file()})
def hashes():
    return {name: {"sha256": hashlib.sha256((ROOT / name).read_bytes()).hexdigest(), "size": (ROOT / name).stat().st_size} for name in names}
before = hashes()
(OUT / "source-before.json").write_text(json.dumps(before, indent=2), encoding="utf8")
script = OUT / "run.sh"
script.write_text("#!/usr/bin/env bash\nset -uo pipefail\ncd /d/NestEggVerification/camera-20261117\n"
    "python3() { 'C:/Users/stanl/AppData/Local/Programs/Python/Python313/python.exe' \"$@\"; }\nexport -f python3\n"
    "export GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'\nexport SHARDS=2\n"
    "export LOG_DIR='D:/NestEggVerification/evidence-20261117/ne223-glyph-official-56bb/shards'\n"
    "mkdir -p \"$LOG_DIR\"\nexport PYTHONIOENCODING=utf-8\n"
    "tools/run_tests_changed.sh " + BASE + "\n", encoding="utf8", newline="\n")
command = ["C:/Program Files/Git/bin/bash.exe", "--noprofile", "--norc", str(script)]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUT / "runner.log").open("wb") as log:
    result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, env=os.environ.copy())
after = hashes()
(OUT / "source-after.json").write_text(json.dumps(after, indent=2), encoding="utf8")
receipt = {"command": command, "cwd": str(ROOT), "base": BASE, "shards": 2, "started_utc": started,
           "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exit_code": result.returncode,
           "source_files": len(before), "source_unchanged": before == after,
           "source_scope": "all tracked + nonignored untracked runtime/tool/test/binary-asset files, excluding pm/design/work/instruction/CI/docs trees"}
(OUT / "process-receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf8")
print(json.dumps(receipt))
raise SystemExit(result.returncode if before == after else 1)
