extends "res://tools/scenarios/gun_balance_scenario.gd"

func _ready() -> void:
	run.call_deferred()

func run() -> void:
	Story.auto_skip = true
	await open_arena("", PLAYER_TILE)
	Enemy.activation_culling_enabled = false
	AimInput.set_virtual_gamepad(player, true)
	var weapon := load("res://data/weapons/mech_cannon.tres") as WeaponData
	var row := await _sample(weapon, "grunt", 128.0)
	print("MOUNT_CONTROL ", JSON.stringify({"mounted": player.mounted_vehicle != null, "shot": row}))
	await finish()
	await get_tree().create_timer(0.5).timeout
	Sfx.stop_all()
	Music.stop(0.0)
	Ambience.stop_all(0.0)
	await get_tree().create_timer(0.2).timeout
	get_tree().quit(0 if not row.is_empty() else 1)
