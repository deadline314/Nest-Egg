extends "res://tests/smoke_test.gd"

const CANDIDATE := "D:/NestEggVerification/evidence-20261123-ne241-mounted-cannon-probe/candidate/tools/scenarios/gun_balance_scenario.gd"
const READY := preload("res://tools/viewport_capture.gd")
const CANNON := preload("res://data/weapons/mech_cannon.tres")
const PISTOL := preload("res://data/weapons/pistol.tres")


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Story.auto_skip = true
	Enemy.activation_culling_enabled = false
	Settings.use_storage("user://mounted_cannon_probe.cfg")
	var args := OS.get_cmdline_user_args()
	var arena: Variant
	if args.has("--candidate"):
		var script := GDScript.new()
		script.source_code = FileAccess.get_file_as_string(CANDIDATE).trim_prefix("class_name GunBalanceScenario\n")
		_check(script.reload() == OK, "mounted balance candidate compiles")
		if script.can_instantiate():
			arena = script.new()
	else:
		arena = GunBalanceScenario.new()
	if arena == null:
		await _finish()
		return
	add_child(arena)
	await arena.open_arena("", arena.PLAYER_TILE)
	AimInput.set_virtual_gamepad(arena.player, true)
	for target: String in arena.TARGETS:
		for range: float in arena.DISTANCES:
			var row: Dictionary = await arena._sample(CANNON, target, range)
			_check(_reports_mount(row), "%s %.0f px uses the mounted cannon and counts its accepted shots" % [target, range])
			_check(arena.player.mounted_vehicle == null, "isolated cannon sample cleans up its mounted vehicle")
	var sustained: Dictionary = await arena._sample(CANNON, "grunt", 128.0, 6.0)
	_check(_reports_mount(sustained) and sustained.get("sustain", false) and int(sustained.get("shots", 0)) >= 20,
		"mounted sustain uses the cannon's normal firing interval without inventory reloads")
	var handgun: Dictionary = await arena._sample(PISTOL, "grunt", 64.0)
	_check(not handgun.is_empty() and not handgun.get("mounted", true) and int(handgun.get("shots", 0)) > 0
		and int(handgun.get("damage", 0)) > 0, "the real handheld case still uses its inventory shot count")
	for arg: String in args:
		if arg.begins_with("--image="):
			await _capture_firing(arena, arg.trim_prefix("--image="))
	await arena.finish()
	arena.queue_free()
	await _finish()


func _reports_mount(row: Dictionary) -> bool:
	return not row.is_empty() and row.get("mounted", false) and int(row.get("shots", 0)) > 0 \
		and int(row.get("reloads", -1)) == 0


func _capture_firing(arena: Variant, image: String) -> void:
	var vehicle: Vehicle = await arena._mount_bulwark()
	_check(vehicle != null and vehicle.driver == arena.player, "capture uses the original Bulwark seat")
	if vehicle == null:
		return
	arena.snap_camera()
	for i in 10:
		await get_tree().physics_frame
	Input.action_press(&"aim_right")
	Input.action_press(&"shoot")
	for tick in 8:
		if vehicle._muzzle_flash > 0.0:
			break
		await get_tree().physics_frame
	Input.action_release(&"shoot")
	Input.action_release(&"aim_right")
	_check(vehicle._muzzle_flash > 0.0, "capture has a real mounted shot")
	await RenderingServer.frame_post_draw
	_check(READY.image(get_viewport()).save_png(image) == OK, "native firing capture saved")
	AimInput.set_virtual_gamepad(vehicle, false)
	arena.player.dismount_vehicle(false)
	vehicle.queue_free()

