from pathlib import Path
import os,subprocess,json
b=Path(__file__).parent
assert (b/'ne257-normal-control-complete').exists()
jobs=[]
for skin in ['ali','banyan','collector_brute','collector_gunner','egret','lin','vig','xiaowei','ye','zhi']:
 for face in ['right','left']:
  name=f'ne257-final-{skin}-{face}'
  args=['--chars='+skin,'--sway-extremes','--bright','--zoom=3.4','--out='+str(b/name/'frame.png')]
  if face=='left':args+=['--left']
  jobs.append((name,'fixtures','res://tools/rig_preview.tscn',args,True))
for q in ['high','low']:
 jobs.append((f'ne257-lights-ch1-{q}','fixtures','res://tools/harbor_readability_probe.tscn',['--quality='+q,'--detail'],False))
 jobs.append((f'ne257-lights-ch2-{q}','fixtures','res://tools/ch2_readability_check.tscn',['--quality='+q,'--detail'],False))
 jobs.append((f'ne257-lounge-cycle-{q}','fixtures','res://tools/readability_phase_probe.tscn',['--level=ch2_lounge_front','--tag='+q,'--quality='+q,'--player','--cycle-samples=16'],False))
 jobs.append((f'ne257-ledger-{q}','fixtures','res://tools/scene_tour.tscn',['--level=ch2_ledger_office','--tag='+q,'--quality='+q,'--player','--cells='+','.join(f'{c}:{r}' for r in [1,2] for c in range(4))],False))
jobs.append(('bg46-final-guest-native','guestbook','res://tools/ch2_flow_probe.tscn',['--guest-book-only'],True))
jobs.append(('bg46-final-stage-frames','guestbook','res://tools/stage_actor_capture.tscn',['--scene='+s for s in ['ch2_t_s17_book','ch2_t_s17_open','ch2_t_s18_wrong','ch2_t_s19_wrong_death','ch2_t_s20_wrong','ch2_t_s21_close']],True))
results=[]
for name,project,tool,args,required in jobs:
 if name=='ne257-final-lin-right' and (b/(name+'.exit')).read_text()=='0':
  rc=0
 else:
  env=os.environ.copy();env['NE_NATIVE_PROJECT']=project;print('START',name,flush=True)
  rc=subprocess.run(['python',str(b/'native.py'),name,tool,*args],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT).returncode
 results.append({'name':name,'project':project,'exit':rc,'args':args});(b/'ne257-native-final-results.json').write_text(json.dumps(results,indent=2)+'\n');print('DONE',name,rc,flush=True)
 if 'SCRIPT ERROR:' in (b/(name+'.log')).read_text(errors='replace') or (rc and required):raise SystemExit('STOP: inspect '+name)
(b/'ne257-native-final-complete').write_text('all jobs returned; inspect all threshold failures and engine errors before accepting\n')
