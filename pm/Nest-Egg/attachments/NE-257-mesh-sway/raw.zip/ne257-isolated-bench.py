from pathlib import Path
import subprocess,os,json
b=Path(__file__).parent
env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',GODOT=str(b/'godot472/Godot_v4.7.2-stable_linux.x86_64'),SHARDS='1')
results=[]
for project in ['audio','fixtures']:
 n='ne257-isolated-fx-'+project;env['LOG_DIR']=str(b/n)
 with (b/(n+'.log')).open('w') as log:r=subprocess.run(['tools/run_tests_parallel.sh','--only=FxMeleePickupsSuite','1'],cwd=b/project,env=env,stdout=log,stderr=subprocess.STDOUT)
 (b/(n+'.exit')).write_text(str(r.returncode));results.append({'name':n,'exit':r.returncode});print(n,r.returncode,flush=True)
for skin in ['ali','banyan','collector_brute','collector_gunner','egret','lin','vig','xiaowei','ye','zhi','rin']:
 for project in ['sway-baseline','fixtures']:
  n=f'ne257-perf-{skin}-{project}';log=b/(n+'.log')
  with log.open('w') as output:r=subprocess.run([env['GODOT'],'--headless','--path',str(b/project),'res://tools/rig_perf_probe.tscn','--','--skin='+skin,'--count=10','--frames=600'],cwd=b/project,env=env,stdout=output,stderr=subprocess.STDOUT)
  (b/(n+'.exit')).write_text(str(r.returncode));assert r.returncode==0 and 'SCRIPT ERROR:' not in log.read_text(),n
  print(n,log.read_text().splitlines()[-1],flush=True)
(b/'ne257-isolated-bench-results.json').write_text(json.dumps(results,indent=2)+'\n')
(b/'ne257-perf-complete').write_text('all 22 probes returned; interpret raw script timing, not GPU frame time\n')
