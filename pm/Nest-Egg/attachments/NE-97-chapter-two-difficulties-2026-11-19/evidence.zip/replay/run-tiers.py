from pathlib import Path
import subprocess
import sys

root = Path.cwd()
level = sys.argv[1]
assert level in ('assist', 'hardcore')
revision = sys.argv[2] if len(sys.argv) > 2 else 'v1'
prior = f'native-ne178-{level}-cold-v1'
runner = root / 'work/run-ne97-street-combat-20261119.py'
stages = ('ch2-open', 'ch2-market', 'ch2-loading', 'ch2-yong', 'ch2-close', 'ch3-cold')
for mode in stages:
    run = f'native-ne97-{level}-second-{mode}-{revision}'
    print(f'{level} enters {mode} from {prior}', flush=True)
    subprocess.run([sys.executable, '-B', str(runner), run, prior, mode, '--difficulty-audit'], cwd=root, check=True)
    prior = run
