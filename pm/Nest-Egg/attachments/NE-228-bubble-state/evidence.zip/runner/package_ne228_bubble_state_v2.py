from pathlib import Path
import json,hashlib,re,zipfile,shutil
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=Path('/workspace/Nest-Egg/work/batch1020b');d=r/'pm/Nest-Egg/attachments/NE-228-bubble-state'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
frozen=json.loads((w/'ne228-bubble-state-final-source-v2.json').read_text())
for f,h in frozen.items():assert sha(r/f)==h,f
probe=r/'work/ne228-bubble-state/probe.gd';assert sha(probe)==sha(r/'tests/probes/bubble_state.gd')=='4a39277c3adf8a21963da63510409906f6eafbba86200d2f329c9284322e4911'
assert (w/'ne228-bubble-state-affected-v2.exit').read_text().strip()=='0'
log=(w/'ne228-bubble-state-affected-v2.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',log);assert m and m[2]==m[3]=='0'
summary={}
for label in ['published','source','ali','voice','sunday','handoff','reception','supper','repeat']:
 root=w/('ne228-bubble-state-'+label+'-v2');receipt=json.loads((root/'receipt.json').read_text());cases=receipt['cases'];assert all(x['passed'] and x['exit']==0 for x in cases),label
 summary[label]={'processes':len(cases),'checks':sum(x['result']['checks'] for x in cases),'failures':0}
before=json.loads((w/'ne228-bubble-state-before-v1/receipt.json').read_text())['cases'][0];assert before['result']['checks']==52 and len(before['result']['failures'])==1
native=[]
for tag in ['ne228-bubble-state-before-native-v1','ne228-bubble-state-before-engine-safe-native-v1','ne228-bubble-state-after-original-native-v2','ne228-bubble-state-after-published-native-v2']:
 folder=n/tag;result=json.loads((folder/'result.json').read_text());state=json.loads((folder/'state.json').read_text());exit_code=int((n/(tag+'.exit')).read_text());raw=(n/(tag+'.log')).read_text()
 expected=1 if 'before' in tag else 0
 assert result['checks']==52 and len(result['failures'])==expected and exit_code==expected,(tag,result['failures'],exit_code)
 assert not any(x in raw for x in ['ERROR:','SCRIPT ERROR:','leaked at exit','were leaked','resources still in use','handle_crash:'])
 assert not state['scene_eligible'] and state['npc_present'] and state['talks']==1 and not state['completed']
 assert any(entry['id']=='ch1_b_stall' for entry in state['active']+state['queued'])==bool(expected)
 if expected:assert any(entry['id']=='ch1_b_stall' and entry['age']<entry['hold'] for entry in state['active'])
 native.append({'tag':tag,'checks':result['checks'],'failures':expected,'exit':exit_code,'same_frame':state['frame'],'png_sha256':sha(folder/'state.png'),'state_sha256':sha(folder/'state.json')})
safe=json.loads((w/'ne228-bubble-state-safe-control.json').read_text());assert safe['headless']['negative_control_valid'] and safe['native']['negative_control_valid'] and safe['engine_sha256']=='319aaea8c619fa1edc5d08a33158ab2bfd069e329a1bcd672db9654af53f35e2'
assert 'DUMMY_TEXTURE_EXIT_CHECK logs=4 diagnostics=0' in log
ci=json.loads((w/'bg51-ci-receipt.json').read_text());assert ci['commit']=='77d4e24181706f540b6f8d0b38a816ae785b96a2' and ci['conclusion']=='success' and ci['full_count_unavailable']
entries={}
def add(key,p):
 if p.is_file():entries[key]=p

def tree(prefix,root):
 for p in root.rglob('*'):
  if p.is_file() and not any(x.endswith('-profile') or x in ['.godot','__pycache__'] for x in p.relative_to(root).parts):add(prefix+'/'+str(p.relative_to(root)),p)
for f in frozen:add('source/final/'+f,r/f)
add('source/final/design/20-campaign-experience/BUBBLE_STATE_ELIGIBILITY.md',r/'design/20-campaign-experience/BUBBLE_STATE_ELIGIBILITY.md')
tree('source/before',w/'ne228-bubble-state-before-source-v1')
for p in w.glob('ne228-bubble-state-*'):
 if p.is_file() and p.suffix in ['.json','.log','.exit'] and 'package' not in p.name:add('records/'+p.name,p)
 elif p.is_dir():
  if p.name.endswith('-shards'):
   for f in p.glob('*.log'):add('tests/'+p.name+'/'+f.name,f)
  else:tree('runs/'+p.name,p)
for row in native:
 tag=row['tag'];tree('native/'+tag,n/tag)
 for suffix in ['.log','.exit','-xvfb.log']:add('native/'+tag+suffix,n/(tag+suffix))
for f in ['run_ne228_bubble_state_final.py','run_ne228_bubble_state_final_v2.py','run_ne228_bubble_state_safe_control.py','package_ne228_bubble_state.py','package_ne228_bubble_state_v2.py','st9-supper-ci-receipt.json','st9-supper-ci-evidence.zip','bg51-ci-receipt.json','bg51-ci-evidence.zip','bg51-original-failure-v1/note.json']:add('runner/'+f,w/f)
manifest={};archive=d/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for key,p in sorted(entries.items()):manifest[key]={'bytes':p.stat().st_size,'sha256':sha(p)};z.write(p,key)
with zipfile.ZipFile(archive) as z:
 for key,expected in manifest.items():
  with z.open(key) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==expected['sha256'],key
assert archive.stat().st_size<50*1024*1024
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
validation={'base':'77d4e24181706f540b6f8d0b38a816ae785b96a2','same_safe_engine_negative_control':safe,'fixed_engine_sha256':safe['engine_sha256'],'unsafe_engine_regression_failure_preserved':'ne228-bubble-state-supper-v1/host_none_read.log; independent BG51 fix and actual CI attached','source_sha256':frozen,'negative':{'checks':52,'before_failures':1,'after_failures':0,'identical_probe_sha256':sha(probe)},'affected':{'groups':int(re.search(r'Running (\d+) groups',log)[1]),'workers':4,'checks':int(m[1]),'new_failures':0,'known_failures':0,'seconds':int(m[4])},'native':native,'regressions':summary,'archive':{'bytes':archive.stat().st_size,'entries':len(manifest),'sha256':sha(archive)},'limits':['Same-frame original supper payment from exact produced evening primary, not a complete human chapter playthrough.','Software Forward+ HDR2D with Dummy audio; physical GPU/controller and human visual/style gates remain open.','State-driven withdrawal only; no font, layout style, HOLD/FADE, wording, choice, price or full-story policy changes.']}
(d/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
for name,tag in [('initial-before','ne228-bubble-state-before-native-v1'),('before','ne228-bubble-state-before-engine-safe-native-v1'),('after','ne228-bubble-state-after-original-native-v2'),('published','ne228-bubble-state-after-published-native-v2')]:
 shutil.copyfile(n/tag/'state.png',r/'pm/Nest-Egg/images'/('NE-228-bubble-state-'+name+'.png'));shutil.copyfile(n/tag/'state.json',d/(name+'-state.json'))
shutil.copyfile(w/'st9-supper-ci-receipt.json',d/'previous-supper-ci.json');shutil.copyfile(w/'st9-supper-ci-evidence.zip',d/'previous-supper-ci.zip')
shutil.copyfile(w/'bg51-ci-receipt.json',d/'previous-bg51-ci.json');shutil.copyfile(w/'bg51-ci-evidence.zip',d/'previous-bg51-ci.zip')
print(json.dumps({k:v for k,v in validation.items() if k!='source_sha256'},indent=2))
