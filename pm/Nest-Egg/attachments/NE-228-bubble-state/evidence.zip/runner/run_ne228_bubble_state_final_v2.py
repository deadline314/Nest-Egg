from pathlib import Path
import subprocess,json,hashlib,time
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';engine=w/'godot-texture-build/dist/godot'
files=['autoload/story.gd','game/level/map_bubbles.gd','tests/helpers/bubble_admission_checks.gd','tests/suite/test_map_bubbles.gd','tests/probes/bubble_state.gd','tests/probes/bubble_state.tscn','tools/run_bubble_state.py','.github/workflows/tests.yml']
frozen={f:hashlib.sha256((r/f).read_bytes()).hexdigest() for f in files};(w/'ne228-bubble-state-final-source-v2.json').write_text(json.dumps(frozen,indent=2)+'\n')
def unchanged():
 for f,h in frozen.items():assert hashlib.sha256((r/f).read_bytes()).hexdigest()==h,f
while not (w/'ne228-bubble-state-affected-v2.exit').exists():time.sleep(1)
assert (w/'ne228-bubble-state-affected-v2.exit').read_text().strip()=='0'
for tool,label in [('run_bubble_state.py','published'),('run_bubble_source.py','source'),('run_ali_completion.py','ali'),('run_voice_completion.py','voice'),('run_sunday_choice.py','sunday'),('run_handoff_completion.py','handoff'),('run_reception_completion.py','reception'),('run_supper_completion.py','supper'),('run_supper_repeat.py','repeat')]:
 unchanged();name='ne228-bubble-state-'+label+'-v2';print('START',name,flush=True)
 with (w/(name+'.log')).open('w') as log:code=subprocess.run(['python3',str(r/'tools'/tool),'--godot',str(engine),'--output',str(w/name)],cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
 (w/(name+'.exit')).write_text(str(code)+'\n');assert code==0,name;unchanged();print('PASS',name,flush=True)
for label,scene in [('original','res://work/ne228-bubble-state/probe.tscn'),('published','res://tests/probes/bubble_state.tscn')]:
 unchanged();tag='ne228-bubble-state-after-'+label+'-native-v2';env=__import__('os').environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(engine))
 print('START',tag,flush=True)
 with (w/(tag+'-wrapper.log')).open('w') as log:code=subprocess.run(['python3','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,scene,'--mode=pay','--save-dir='+str(w/(tag+'-slot'))],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 assert code==0,(tag,code);unchanged();print('PASS',tag,flush=True)
print('ALL ORIGINAL SOURCES AND NATIVE RUNS COMPLETE',flush=True)
