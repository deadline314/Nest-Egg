"""Original greeting negative control on pristine BG-51 main and the same safe engine."""
from pathlib import Path
import sys,subprocess,os,json,hashlib,shutil
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'dummy-texture-worktree';n=Path('/workspace/Nest-Egg/work/batch1020b');sys.path.insert(0,str(r/'tools'))
from runtime_probe import run_case,write_json
from run_supper_completion import coherent
engine=w/'godot-texture-build/dist/godot';out=w/'ne228-bubble-state-before-engine-safe-v1';out.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()=='77d4e24181706f540b6f8d0b38a816ae785b96a2'
probe=r/'work/ne228-bubble-state/probe.gd';assert hashlib.sha256(probe.read_bytes()).hexdigest()=='4a39277c3adf8a21963da63510409906f6eafbba86200d2f329c9284322e4911'
files=['autoload/story.gd','game/level/map_bubbles.gd','game/main.gd','data/story/ch1_kasa.json','tests/probes/supper_completion.gd','tests/helpers/supper_completion_base.gd','work/ne228-bubble-state/probe.gd','work/ne228-bubble-state/probe.tscn'];sources={}
for name in files:
 target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,target);sources[name]=hashlib.sha256(target.read_bytes()).hexdigest()
expected='ineligible original invitation has no active or queued original line'
case=run_case('pay',engine,out,240,project=r,scene='res://work/ne228-bubble-state/probe.tscn',slot=out/'slot')
assert case['exit']==1 and not case['timeout'] and case['result']['checks']==52 and case['result']['failures']==[expected]
assert case['diagnostics']==['FAIL '+expected] and coherent('pay',case['result']),case.get('diagnostics')
with engine.open('rb') as f:engine_hash=hashlib.file_digest(f,'sha256').hexdigest()
assert engine_hash=='319aaea8c619fa1edc5d08a33158ab2bfd069e329a1bcd672db9654af53f35e2'
write_json(out/'receipt.json',{'source_commit':'77d4e24181706f540b6f8d0b38a816ae785b96a2','source_sha256':sources,'engine_sha256':engine_hash,'negative_control_valid':True,'cases':[case]});print('SAFE_ENGINE_ORIGINAL_HEADLESS_NEGATIVE_VALID 52 checks / 1 intended failure',flush=True)
tag='ne228-bubble-state-before-engine-safe-native-v1';env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/dummy-texture-worktree',NE_NATIVE_GODOT=str(engine))
with (w/(tag+'-wrapper.log')).open('w') as log:code=subprocess.run(['python3','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://work/ne228-bubble-state/probe.tscn','--mode=pay','--save-dir='+str(w/(tag+'-slot'))],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
result=json.loads((n/tag/'result.json').read_text());state=json.loads((n/tag/'state.json').read_text());raw=(n/(tag+'.log')).read_text();assert code==1 and int((n/(tag+'.exit')).read_text())==1 and result['checks']==52 and result['failures']==[expected]
assert not any(text in raw for text in ['ERROR:','SCRIPT ERROR:','leaked at exit','resources still in use'])
assert not state['scene_eligible'] and state['npc_present'] and state['talks']==1 and not state['completed']
assert any(entry['id']=='ch1_b_stall' and entry['age']<entry['hold'] for entry in state['active'])
write_json(w/'ne228-bubble-state-safe-control.json',{'source_commit':'77d4e24181706f540b6f8d0b38a816ae785b96a2','engine_sha256':engine_hash,'probe_sha256':sources['work/ne228-bubble-state/probe.gd'],'headless':{'checks':52,'failures':1,'negative_control_valid':True},'native':{'tag':tag,'checks':52,'failures':1,'negative_control_valid':True,'png_sha256':hashlib.sha256((n/tag/'state.png').read_bytes()).hexdigest(),'state':{key:state[key] for key in ['scene_eligible','npc_present','talks','completed','active','frame']}}})
print('SAFE_ENGINE_ORIGINAL_NATIVE_NEGATIVE_VALID 52 checks / 1 intended failure',flush=True)
