extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
const COPY := "D:/NestEggVerification/evidence-20261123-ne228-weapon-inventory-language/weapon-copy.json"
const LOCALES := {
	"zh": ["近戰", "能量", "實彈", "連段", "彈匣", "彈藥", "目前手上武器", "空欄位", "詳情"],
	"ja": ["近接", "エネルギー", "実弾", "連撃", "弾倉", "弾薬", "装備中", "空き枠", "詳細"],
	"en": ["Melee", "Energy", "Ballistic", "Combo", "Magazine", "Ammo", "Equipped weapon", "Empty slot", "Details"],
}


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://weapon_labels_probe.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	Story.auto_skip = true
	var source := FileAccess.get_file_as_string(COPY)
	var translations: Dictionary = JSON.parse_string(source.trim_prefix("\ufeff"))
	var catalog := WeaponCatalog.load_all()
	_check(catalog.issues.is_empty() and catalog.weapons.size() == translations.size(), "every official weapon has a probe expectation")
	add_child(LightKit.create_environment())
	var out := "" if OS.get_cmdline_user_args().is_empty() else OS.get_cmdline_user_args()[0]
	for code: String in LOCALES:
		Story.set_language(code)
		GameState.start_new_run(GameState.difficulties[1])
		for scene in Story.scene_ids():
			Story._seen[StringName(scene)] = true
		var level := Level.new()
		level.configure(STREET)
		add_child(level)
		await _frames(8)
		var bag := level._inventory
		var page := bag._pages[bag.page_index(WeaponsPage)] as WeaponsPage
		var labels: Array = LOCALES[code]
		for weapon: WeaponData in catalog.weapons:
			level.player.loadout.reset(weapon)
			bag.open()
			await _frames(3)
			var card := page._entries[0]
			var values: Array = translations[str(weapon.id)]
			var name: String = weapon.display_name if code == "zh" else values[0 if code == "en" else 1]
			var description: String = weapon.description if code == "zh" else values[2 if code == "en" else 3]
			var kind: String = labels[0] if weapon.is_melee() else labels[1 if weapon.is_energy else 2]
			var stat: String = labels[3] if weapon.is_melee() else labels[4 if weapon.has_magazine() else 5]
			var scenario := "%s/%s" % [code, weapon.id]
			_check(card.title == name and page._detail._title.text == name, scenario + " official weapon name")
			_check(card.detail_body == description and card.hint == description, scenario + " full authored effect and hover")
			_check(card.detail_tag.begins_with(kind) and card.detail_stats[0].begins_with(stat)
					and page._detail._scroll_hint.text.ends_with(labels[8]), scenario + " type, stats and detail guidance")
			var empty := page._entries[1]
			var font := UiKit.font()
			var caption_width := font.get_string_size(empty.subtitle, HORIZONTAL_ALIGNMENT_LEFT, -1, UiKit.scaled_size(10)).x
			var available := ItemCard.CARD_SIZE.x - (10.0 + ItemCard.ICON_CELL.x + 6.0) - 8.0
			_check(card.action_label == labels[6] and empty.title.begins_with(labels[7]) and caption_width <= available,
					scenario + " equipped and empty states fit in the real card")
			var row := level.hud.weapon_bar._rows[0]
			_check(row._get_tooltip(Vector2.ZERO) == description, scenario + " HUD uses the same weapon tooltip")
			if code == "en" and weapon.id == &"melee_maul" and out.is_absolute_path():
				await RenderingServer.frame_post_draw
				_check(Capture.image(get_viewport()).save_png(out) == OK, "native localized melee details")
			bag.close()
		level.queue_free()
		await _frames(8)
	await _finish()
