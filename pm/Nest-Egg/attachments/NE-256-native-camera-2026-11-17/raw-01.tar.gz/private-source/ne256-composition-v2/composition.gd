extends "res://work/ne256-composition-v2/base.gd"
## Private validation only: prove the image belongs to an active independent stage.
func _capture_cutscene(level_id: String) -> void:
	await super._capture_cutscene(level_id)
	var host := Story._replay as CutscenePlayer
	var valid := Story.is_replaying() and is_instance_valid(host) and host.scene_id == _cutscene and host._stage != null and is_instance_valid(host._stage_holder) and not host._actors.is_empty()
	_failed = _failed or not valid
	var record: Dictionary = {"scene":String(_cutscene),"valid_active_stage":valid,"underlying_profile":String(_profile),"parent_probe_failed":_failed}
	var level_camera := get_viewport().get_camera_2d()
	if level_camera != null: record["underlying_level_zoom"] = level_camera.zoom.x
	if is_instance_valid(host):
		record["actual_scene_id"] = String(host.scene_id)
		record["stage_camera_position"] = [host.cam_pos.x,host.cam_pos.y]
		record["stage_camera_zoom"] = host.cam_zoom
		record["stage_layer"] = host.layer
		record["stage_follows_level_viewport"] = host.follow_viewport_enabled
		record["actors"] = host._actors.keys()
		if is_instance_valid(host._stage_holder):
			var xform := host._stage_holder.global_transform
			record["stage_holder_transform"] = [xform.x.x,xform.x.y,xform.y.x,xform.y.y,xform.origin.x,xform.origin.y]
	var file := FileAccess.open(_out_dir.path_join("composition-state.json"),FileAccess.WRITE)
	if file == null: _failed = true
	else: file.store_string(JSON.stringify(record,"  "))
	print("NE256_COMPOSITION ",JSON.stringify(record))
