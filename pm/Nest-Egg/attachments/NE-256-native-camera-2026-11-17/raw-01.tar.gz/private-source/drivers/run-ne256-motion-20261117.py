from pathlib import Path
import hashlib,json,os,subprocess,sys,time
import psutil
ROOT=Path('C:/Users/stanl/Github/Nest-Egg'); OUT=Path('D:/NestEggVerification/evidence-20261117/ne256')
PY='D:/ComfyUI/.venv-rocm/Scripts/python.exe'; GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
prior=json.loads((OUT/'framing-current-720/source-before.json').read_text(encoding='utf8'))
paths=set(prior)|{'data/feel/camera.json','tools/framing_probe.tscn','tools/viewport_capture.gd'}
for prefix in ('data/levels','data/layouts'):
 p=ROOT/prefix
 if p.exists(): paths.update(f.relative_to(ROOT).as_posix() for f in p.rglob('*') if f.is_file() and f.suffix in ('.tres','.json','.txt'))
def snap():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sorted(paths) if (ROOT/p).is_file()}
def write(p,d):p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
for resolution in ('1280x720',):
 for profile in ('current','level_wide'):
  out=OUT/('framing-motion-six-'+profile+'-'+resolution);out.mkdir(parents=True,exist_ok=False)
  env=os.environ.copy(); profile_dir=out/'private-profile'
  for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):env[key]=str(profile_dir/key)
  command=[PY,str(ROOT/'tools/comfyui/gpu_lock.py'),'--',GODOT,'--path',str(ROOT),'--rendering-driver','vulkan','--rendering-method','forward_plus','--resolution',resolution,'--fixed-fps','60','res://tools/framing_probe.tscn','--','--out='+str(out),'--motion','--trace']
  if profile!='current':command+=['--profile='+profile]
  before=snap();write(out/'source-before.json',before);write(out/'request.json',{'command':command,'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),'scope':'Existing unmodified public-input motion tool at fixed simulation60Hz across six configured sites. Not elapsed frame/GPU performance or natural whole-chapter play. Camera-clamped samples are excluded by the original tool. Private profile; frozen NE301 products present.'})
  start=time.monotonic()
  with (out/'native.log').open('wb') as log:
   proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
   try:code=proc.wait(timeout=300)
   except subprocess.TimeoutExpired:
    children=psutil.Process(proc.pid).children(recursive=True)
    for child in reversed(children):
     try:child.kill()
     except psutil.NoSuchProcess:pass
    proc.kill();proc.wait();code=124
  after=snap();write(out/'source-after.json',after);write(out/'result.json',{'natural_exit':code,'elapsed_s':time.monotonic()-start,'source_unchanged':before==after,'expected_exit':0})
  print(out.name,'exit',code,'held',before==after,flush=True)
  assert before==after,'Source epoch changed'
print('Both original six-site motion runs retained',flush=True)
