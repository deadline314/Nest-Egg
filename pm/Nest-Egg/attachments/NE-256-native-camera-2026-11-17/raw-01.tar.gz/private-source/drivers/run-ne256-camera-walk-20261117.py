from pathlib import Path
import hashlib,json,os,subprocess,time
import psutil
root=Path('C:/Users/stanl/Github/Nest-Egg');base=Path('D:/NestEggVerification/evidence-20261117/ne256')
paths=set(json.loads((base/'framing-six-current-1280x720/source-before.json').read_text(encoding='utf8')))|{'tools/camera_walk_probe.gd','tools/camera_walk_probe.tscn'}
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
def write(p,d):p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
for profile in ['current','level_wide']:
 out=base/('camera-walk-'+profile);out.mkdir(parents=True,exist_ok=False);env=os.environ.copy()
 for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
 command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--fixed-fps','60','--resolution','1280x720','--path',str(root),'res://tools/camera_walk_probe.tscn','--','--out='+str(out),'--tag='+profile]
 if profile!='current':command+=['--profile='+profile]
 before=snapshot();write(out/'source-before.json',before);write(out/'request.json',{'command':command,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'scope':'Existing original headless camera/map sampling; arranged standing/enemy samples, not natural chapter gameplay. Reader must reject missing levels/errors even when original tool exits0.'});start=time.monotonic()
 with (out/'native.log').open('wb') as log:
  process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:code=process.wait(timeout=600)
  except subprocess.TimeoutExpired:
   for child in reversed(psutil.Process(process.pid).children(recursive=True)):
    try:child.kill()
    except psutil.NoSuchProcess:pass
   process.kill();process.wait();code=124
 after=snapshot();write(out/'source-after.json',after);write(out/'result.json',{'natural_exit':code,'elapsed_s':time.monotonic()-start,'source_unchanged':before==after});print(profile,'exit',code,'held',before==after,flush=True)
 assert before==after,'Runtime/source drift'
print('Both original map camera walks retained',flush=True)
