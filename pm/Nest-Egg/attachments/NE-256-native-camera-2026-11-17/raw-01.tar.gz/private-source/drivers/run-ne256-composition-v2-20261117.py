from pathlib import Path
import hashlib,json,os,subprocess,sys,time
import psutil
ROOT=Path('D:/NestEggVerification/camera-20261117'); OUT=Path('D:/NestEggVerification/evidence-20261117/ne256')
PY='D:/ComfyUI/.venv-rocm/Scripts/python.exe'; GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
prior=json.loads((OUT/'framing-current-720/source-before.json').read_text(encoding='utf8'))
paths=set(prior)|{'work/ne256-composition-v2/base.gd','work/ne256-composition-v2/composition.gd','work/ne256-composition-v2/composition.tscn','data/story/ch1_kasa.json','game/cutscene/cutscene_player.gd'}|{'data/feel/camera.json','tools/framing_probe.tscn','tools/viewport_capture.gd'}
for prefix in ('data/levels','data/layouts'):
 p=ROOT/prefix
 if p.exists(): paths.update(f.relative_to(ROOT).as_posix() for f in p.rglob('*') if f.is_file() and f.suffix in ('.tres','.json','.txt'))
def snap():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sorted(paths) if (ROOT/p).is_file()}
def write(p,d):p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
for scene_id,profile in [(s,p) for s in ['ch1_t_egret_1','ch1_c09_wake','ch1_c14_home'] for p in ['current','level_wide']]+[('ch1_p_k_wait','current')]:
 resolution='1280x720'
 if True:
  out=OUT/('composition-v2-'+scene_id+'-'+profile);out.mkdir(parents=True,exist_ok=False)
  env=os.environ.copy(); profile_dir=out/'private-profile'
  for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):env[key]=str(profile_dir/key)
  command=[PY,str(ROOT/'tools/comfyui/gpu_lock.py'),'--',GODOT,'--path',str(ROOT),'--rendering-driver','vulkan','--rendering-method','forward_plus','--resolution',resolution,'res://work/ne256-composition-v2/composition.tscn','--','--out='+str(out),'--cutscene='+scene_id,'--level=ch1_pawnshop']
  if profile!='current':command+=['--profile='+profile]
  before=snap();write(out/'source-before.json',before);write(out/'request.json',{'command':command,'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),'scope':'Private frozen copy of candidate probe changes only stage invocation: explicitly arranged completion plus existing progress-free Story.replay API, checked return. Three authored stages over real pawnshop, current/wide control. This is isolated stage composition, NOT natural progression or proof of prerequisites. No-stage replay rejection is expected negative. v1 failed direct-play prerequisites remain unchanged.'})
  start=time.monotonic()
  with (out/'native.log').open('wb') as log:
   proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
   try:code=proc.wait(timeout=300)
   except subprocess.TimeoutExpired:
    children=psutil.Process(proc.pid).children(recursive=True)
    for child in reversed(children):
     try:child.kill()
     except psutil.NoSuchProcess:pass
    proc.kill();proc.wait();code=124
  after=snap();write(out/'source-after.json',after);write(out/'result.json',{'natural_exit':code,'elapsed_s':time.monotonic()-start,'source_unchanged':before==after,'expected_exit':1 if scene_id=='ch1_p_k_wait' else 0})
  print(out.name,'exit',code,'held',before==after,flush=True)
  assert before==after,'Source epoch changed'
print('Six real stage composition samples and no-stage negative retained',flush=True)
