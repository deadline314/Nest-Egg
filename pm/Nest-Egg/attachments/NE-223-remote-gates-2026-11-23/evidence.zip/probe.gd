extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const WAREHOUSE := "res://data/levels/ch1_warehouse.tres"
const PAWN := "res://data/levels/ch1_pawnshop.tres"

var _fails := 0
var _checks := 0
var _output := ""
var _level: Level


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_output = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://map-gate-probe.cfg")
	Settings.set_ui_text_scale(1.2)
	Story.set_language("en")
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch1_prologue_exit", true, false)
	add_child(LightKit.create_environment())
	await _enter(WAREHOUSE)
	var gate: Gate
	var control: MechanismSwitch
	for node in get_tree().get_nodes_in_group(WorldState.GROUP):
		if node is Gate and node.data.id == &"ch1_gate_a":
			gate = node
		elif node is MechanismSwitch and node.data.id == &"ch1_switch_a":
			control = node
	_check(is_instance_valid(gate) and is_instance_valid(control) and not gate.is_open, "original warehouse switch and closed Gate A are present")
	if not is_instance_valid(gate) or not is_instance_valid(control):
		await _finish()
		return
	var gate_key := gate.state_key()
	var gate_cell := gate.cell
	_level.player.global_position = control.global_position + Vector2(-4, -1)
	await _frames(20)
	_check(control.interaction_available(), "player is in reach of the original switch")
	await _key(KEY_E)
	_check(control.active and gate.is_open, "E activates the real switch and opens Gate A")
	_level._save_area_state(0.0)
	var saved: Dictionary = GameState.area_states.get("ch1_warehouse", {}).get("world", {})
	_check(saved.get(gate_key) == true, "the original warehouse snapshot records the open gate")
	await _enter(PAWN)
	_check(not WorldState.capture(get_tree()).has(gate_key), "the Pawnshop has no live gate with the warehouse tile key")
	var map_index := QuestMapIndex.for_chapter(&"ch1_kasa")
	var markers: Array[Dictionary] = map_index.areas[WAREHOUSE]["markers"]
	var index := markers.find_custom(func(entry: Dictionary) -> bool:
		return entry.get("kind") == "gate" and entry.get("cell") == gate_cell)
	_check(index >= 0, "the map marker comes from the original warehouse")
	QuestMapState.for_run().reveal(WAREHOUSE, [gate_cell])
	await _key(KEY_M)
	var map: QuestMapScreen = _level._pause_menu._navigation
	_check(is_instance_valid(map) and map._page == "region", "M opens the Pawnshop map")
	if not is_instance_valid(map):
		await _finish()
		return
	await _key(KEY_E)
	var warehouse := _map_button(map, "area:" + WAREHOUSE)
	_check(map._page == "world" and warehouse != null, "the real world map can select Warehouse")
	if warehouse != null:
		warehouse.grab_focus()
		await _joy(JOY_BUTTON_A)
		_check(map._page == "region" and map._map_path == WAREHOUSE, "controller A shows the remote warehouse")
		var gate_marker := _map_button(map, "marker:%d" % index)
		_check(gate_marker != null and gate_marker.text == QuestMapCanvas.SYMBOLS["exit"] and gate_marker.tooltip_text == "This gate is open.",
			"the remote gate shows its saved open state and the English tooltip")
		if gate_marker != null:
			gate_marker.grab_focus()
			await _frames(4)
			_check(map._status.text == gate_marker.tooltip_text, "controller focus speaks the same gate information as Hover")
		if DisplayServer.get_name() != "headless":
			await RenderingServer.frame_post_draw
			_check(Capture.image(get_viewport()).save_png(_output.path_join("gate.png")) == OK, "saved the actual remote gate view")
		await _joy(JOY_BUTTON_B)
		warehouse = _map_button(map, "area:" + WAREHOUSE)
		_check(map._page == "world" and warehouse != null and warehouse.has_focus(), "controller B restores the Warehouse world marker")
	_check(GameState.area_states.get("ch1_warehouse", {}).get("world", {}).get(gate_key) == true, "looking at the map preserves the authoritative gate state")
	await _finish()


func _enter(path: String) -> void:
	if is_instance_valid(_level):
		_level.queue_free()
		await _frames(6)
	_level = Level.new()
	_level.configure(load(path) as LevelData)
	add_child(_level)
	await _frames(32)


func _map_button(map: QuestMapScreen, key: String) -> Button:
	if is_instance_valid(map._canvas):
		for button in map._canvas._markers:
			if button.get_meta(&"nav_key", "") == key:
				return button
	return null


func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _press(event)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	await _press(event)


func _press(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(5)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(7)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish() -> void:
	if is_instance_valid(_level):
		_level.queue_free()
	await _frames(6)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))

