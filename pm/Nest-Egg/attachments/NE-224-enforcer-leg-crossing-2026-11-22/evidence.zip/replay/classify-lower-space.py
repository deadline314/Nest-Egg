from collections import Counter
from functools import lru_cache
from pathlib import Path
from PIL import Image
from scipy import ndimage
import json,numpy as np

base=Path(__file__).resolve().parent
load=lambda directory:json.loads((base/directory/"report.json").read_bytes())
whole="visor-shield-lower-after-whole"
dress="enforcer-lower-baseline-dressed"
pair="enforcer-lower-baseline-isolated"
leg="enforcer-lower-two-legs-whole"
def hard(rows):
    return [row for row in rows if row["enclosed_pixels"] or row["loose_pieces"] or row["center_alpha"]<128]
def key(row):
    return row["pose"],row["zoom"],row["facing"],row["frame"],row["joint"]

assert all(load(label)["samples"]==19200 for label in (whole,dress,pair,leg))
assert not hard(load(dress)["failures"]) and not hard(load(pair)["failures"])
isolated = {key(r):r for r in hard(load(leg)["failures"]) if r["joint"]!="waist"}
complete = {key(r):r for r in hard(load(whole)["failures"])}
assert len(complete)==318 and set(complete)==set(isolated)
assert all(r["joint"] in {"knee_front","knee_back","ankle_front","ankle_back"} for r in complete.values())

@lru_cache(maxsize=20)
def alpha(directory, file):
    return np.asarray(Image.open(base/directory/file).convert("RGBA"))[:,:,3]
kernel=np.ones((3,3),bool)
def pixels(directory,row):
    x,y,w,h=row["rect"]; size=row["radius"]
    left=x+w//2-size; top=y+h//2-size
    return alpha(directory,row["file"])[top:top+2*size,left:left+2*size]>=128
def holes(solid):
    return ndimage.binary_fill_holes(solid,structure=kernel)&~solid

checked=[]
for name,row in sorted(complete.items()):
    b=isolated[name]
    assert row["rect"]==b["rect"] and row["radius"]==b["radius"]
    full=holes(pixels(whole,row))
    both=holes(pixels(leg,b))
    assert np.array_equal(full,both) and int(full.sum())==row["enclosed_pixels"]
    for single in (dress,pair):
        mask=pixels(single,row)
        assert not (full & mask).any() and not (full & holes(mask)).any()
    checked.append({"sample":name,"pixels":int(full.sum()),"matches_both_legs":True,
                    "open_with_one_leg_dressed":True,"open_with_only_adjacent_parts":True})
summary={"checks":len(checked),"world_samples":19200,"dressed_samples":19200,"isolated_samples":19200,
         "two_leg_samples_excluding_waist":15360,
         "by_joint":dict(Counter(r["sample"][-1] for r in checked)),"cases":checked}
(base/"enforcer-lower-crossing-proof.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
print("EXACT TWO LEGS REPRODUCE ALL HOLES",len(checked),summary["by_joint"],sum(row["pixels"] for row in checked))
