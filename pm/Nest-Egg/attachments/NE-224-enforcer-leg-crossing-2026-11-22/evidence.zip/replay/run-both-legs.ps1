param([Parameter(Mandatory)][string]$Label,[ValidateSet('whole','dressed','isolated')][string]$Mode='whole',[int]$Frames=120,[switch]$UseCandidate,[int]$Depth=7,[string]$Joints="neck,hip_front,hip_back,shoulder_front,shoulder_back")
$ErrorActionPreference='Stop'
$e=$PSScriptRoot
$d='D:/NestEggVerification/ne218-baseline-20261117'
$out="$e/$Label-$Mode"
New-Item -ItemType Directory -Path "$out/profile" | Out-Null
$env:APPDATA="$out/profile"
$env:LOCALAPPDATA=$env:APPDATA
$py='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
$engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$extras=@()
if($Mode -eq 'whole') { $extras+='--diagnostic-whole-rig' }
if($Mode -eq 'isolated') { $extras+='--pair-only' }
if($UseCandidate) { $extras+="--diagnostic-part-texture=armor_forearm:$e/forearm-end-$Depth.png" }
& $py -B "$d/tools/comfyui/gpu_lock.py" -- $engine --path $d --rendering-method forward_plus --rendering-driver vulkan --resolution 1280x720 --max-fps 120 --audio-driver Dummy --quit-after 9000 "$e/both-legs-matrix.tscn" -- "--out=$out" --chars=enforcer "--joints=$Joints" "--frames=$Frames" @extras *> "$out/raw.log"
$code=$LASTEXITCODE
if($code -ne 0 -or (Select-String -LiteralPath "$out/raw.log" -Pattern 'ERROR:' -Quiet)) {
  Get-Content "$out/raw.log" -Tail 10
  exit 1
}
& $py -X utf8 -B tools/check_joint_frames.py $out *> "$out/check.log"
if($LASTEXITCODE -gt 1) { exit $LASTEXITCODE }
Get-Content "$out/check.log" -TotalCount 2
exit 0
