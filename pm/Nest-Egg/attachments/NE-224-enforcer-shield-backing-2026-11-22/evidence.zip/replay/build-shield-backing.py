from pathlib import Path
from PIL import Image
import numpy as np

e=Path(__file__).resolve().parent
stock=Path("art/characters/enforcer/parts/riot_shield.png")
owner=Path("art_src/characters/enforcer/carry/riot_shield.png")
pixels=lambda p:np.asarray(Image.open(p).convert("RGBA"))
src=pixels(owner)
def game_texture(rgba):
    return Image.fromarray(rgba).resize((200,440),Image.Resampling.LANCZOS)
assert np.array_equal(pixels(stock),np.asarray(game_texture(src))) and src.shape==(88,40,4)
for variant,peak in ((1,5),(2,6),(3,7),(4,8)):
    body=src.copy()
    for y in range(45,78):
        offset=(y-45)/(78-45)
        depth=round(peak*np.sin(np.pi*offset)**0.8)
        if depth<1:
            continue
        edge=int(np.flatnonzero(src[y,:,3]>=200)[0])
        target=edge-depth
        for x in range(target,edge):
            fill=150 if x==target else 239
            if fill<=src[y,x,3]:
                continue
            body[y,x,:3]=np.minimum(src[y,edge+2,:3],[25,34,44])
            body[y,x,3]=fill
    edited=np.any(body!=src,axis=2)
    assert np.any(edited) and np.all(body[:,:,3]>=src[:,:,3])
    assert not np.any((src[:,:,3]>=235)&edited)
    Image.fromarray(body).save(e/f"shield-backing-source-{variant}.png")
    game_texture(body).save(e/f"shield-backing-{variant}.png")
    print(variant,np.count_nonzero(edited),np.count_nonzero((src[:,:,3]<128)&(body[:,:,3]>=128)))
text=(e/"torso-elbow.gd").read_text(encoding="utf-8")
(e/"shield-backing.gd").write_text(text,encoding="utf-8")
text=(e/"torso-elbow.tscn").read_text(encoding="utf-8").replace("/torso-elbow.gd","/shield-backing.gd")
(e/"shield-backing.tscn").write_text(text,encoding="utf-8")
text=(e/"run-torso-elbow.ps1").read_text(encoding="utf-8").replace("torso:$e/torso-elbow-","riot_shield:$e/shield-backing-").replace("/torso-elbow.tscn","/shield-backing.tscn")
(e/"run-shield-backing.ps1").write_text(text,encoding="utf-8")
