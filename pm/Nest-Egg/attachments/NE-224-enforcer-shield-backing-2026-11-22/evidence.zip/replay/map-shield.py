from pathlib import Path
from PIL import Image
from scipy import ndimage
import json
import numpy as np
import sys

root=Path.cwd()
base=Path(__file__).resolve().parent
focus=base/sys.argv[1]
idx=int(sys.argv[2])

def project(part, point):
    matrix=np.asarray(part["to_cell"])
    local=np.linalg.solve(matrix[:,:2],point-matrix[:,2])
    if "rect_origin" in part:
        return local-np.asarray(part["rect_origin"])
    vertices=np.asarray(part["vertices"])
    tex=np.asarray(part["uv"])
    for triangle in part["triangles"]:
        corners=vertices[triangle]
        edges=(corners[1:]-corners[0]).T
        if abs(np.linalg.det(edges))<1e-10:
            continue
        a,b=np.linalg.solve(edges, local-corners[0])
        if min(a,b,1-a-b)>=-1e-3:
            return tex[triangle[0]] + a*(tex[triangle[1]]-tex[triangle[0]]) + b*(tex[triangle[2]]-tex[triangle[0]])
    return None

maps={}
rows=[]
for group in json.loads((focus/"frames.json").read_bytes()):
    file=group["samples"][idx]["file"]
    frame=np.asarray(Image.open(focus/file).convert("RGBA"))
    for cell in group["cells"]:
        x,y,w,h=cell["rect"]
        cx,cy=w//2,h//2
        rad=cell["radius"]
        slab=frame[y+cy-rad:y+cy+rad,x+cx-rad:x+cx+rad,3]
        solid=slab>=128
        holes=ndimage.binary_fill_holes(solid,structure=np.ones((3,3)))&~solid
        for yy,xx in np.argwhere(holes):
            point=np.array([cx-rad+xx+0.5,cy-rad+yy+0.5])
            materials={}
            for part in cell["geometry_sample"]:
                uv=project(part,point)
                if uv is None:
                    continue
                if part.get("texture","").startswith("res://"):
                    path=part["texture"].removeprefix("res://")
                elif len(sys.argv) > 3 and part["part"] == "riot_shield":
                    path=str(base/sys.argv[3])
                else:
                    continue
                if path not in maps:
                    maps[path]=np.asarray(Image.open(root/path).convert("RGBA"))
                raw=maps[path]
                bx,by=np.floor(uv).astype(int)
                if not (0<=bx<raw.shape[1] and 0<=by<raw.shape[0]):
                    materials[part["part"]]=[round(float(uv[0]),3),round(float(uv[1]),3),-1]
                if 0<=bx<raw.shape[1] and 0<=by<raw.shape[0]:
                    materials[part["part"]]=[round(float(uv[0]),3),round(float(uv[1]),3),int(raw[by,bx,3])]
            rows.append({"pose":group["pose"],"zoom":group["zoom"],"side":cell["facing"],"joint":cell["joint"],
                         "frame":idx,"point":point.tolist(),"alpha":int(slab[yy,xx]),"materials":materials})
(focus/"mapped.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8")
for row in rows:
    if row["side"] != 1:
        continue
    mats={key:value for key,value in row["materials"].items() if value[2]>0}
    print(row["pose"],row["zoom"],row["joint"],row["frame"],row["alpha"],mats)

