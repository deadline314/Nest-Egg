extends HeavyEnemiesSuite

func _test_watchdog_head_in_warehouse() -> void:
	level = await start_level(load("res://data/levels/ch1_warehouse.tres") as LevelData)
	level.player.health.setup(999, 0.0)
	var dog: Enemy = null
	for node in level._entities.get_children():
		if node is Enemy and (node as Enemy).data.id == &"watchdog":
			dog = node
	check(dog != null, "the warehouse places the watchdog")
	if dog == null:
		await end_level(level)
		return
	var player := level.player
	AimInput.set_virtual_gamepad(player, true)
	AimInput.restore_direction(Vector2(-0.6, -0.8))
	for side: int in [-1, 1]:
		# 站得很近：牠的習慣是抬頭吠叫；預兆中頭部感測器打開，真正的手槍瞄準畫面上的頭開一槍。
		player.global_position = dog.global_position + Vector2(side * 40.0, 0.0)
		player.velocity = Vector2.ZERO
		var settled := false
		for frame in 600:
			await physics_frames(1)
			player.global_position.x = dog.global_position.x + side * 40.0
			if dog.fsm.is_in(&"windup") and (dog as PatternBoss).current_move() == &"bark" and (dog as PatternBoss).is_part_open(&"head"):
				settled = true
				break
		# 預兆中退開一步再瞄頭（太近時子彈的路徑會先穿過有裝甲的軀幹）。
		player.global_position.x = dog.global_position.x + side * 90.0
		await _settle_player_aim(player, _head_center(dog))
		var hits: Array = []
		var record := func(info: DamageInfo) -> void: hits.append([info.part, info.weak_hit])
		dog.health.damaged.connect(record)
		var note := {
			"side": side, "settled": settled, "paused": player.get_tree().paused,
			"lock": GameplayLock.is_locked(), "state": int(player.state),
			"blocking": player.is_blocking, "melee_locked": player.is_melee_locked(),
			"melee_cooldown": player.melee.cooldown_left, "fire_cooldown": player._fire_cooldown_left,
			"reload": player.loadout.is_reloading(), "facing": player.facing,
			"muzzle": str(player.muzzle_position()), "direction": str(player.aim_dir),
			"position": str(player.global_position), "dog": str(dog.global_position),
			"phase": str(dog.fsm.is_in(&"windup")), "move": str((dog as PatternBoss).current_move()),
			"head": str(_head_center(dog)), "open": (dog as PatternBoss).is_part_open(&"head"),
			"head_moment": dog.fsm.time_in_state, "ammo": player.loadout.mag_in(player.loadout.active_slot)}
		player._try_fire()
		note["ammo_after"] = player.loadout.mag_in(player.loadout.active_slot)
		await physics_frames(12)
		note["final_head"] = str(_head_center(dog))
		note["hits"] = hits
		print("WATCHDOG_WAREHOUSE ", JSON.stringify(note))
		dog.health.damaged.disconnect(record)
		check(settled and hits.size() == 1 and hits[0][0] == &"head" and hits[0][1],
				"in the warehouse, the real pistol aimed at the barking watchdog's head scores a head hit (player side %d): %s" % [side, hits])
	await end_level(level)
