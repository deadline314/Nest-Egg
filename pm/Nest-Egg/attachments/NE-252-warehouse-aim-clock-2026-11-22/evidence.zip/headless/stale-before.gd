extends "res://tests/smoke_test.gd"

func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	for iteration in 3:
		var suite := preload("./stale-before-suite.gd").new(self)
		print("WATCHDOG_ITERATION ", iteration)
		await suite._test_watchdog_head_in_warehouse()
	await _finish()

