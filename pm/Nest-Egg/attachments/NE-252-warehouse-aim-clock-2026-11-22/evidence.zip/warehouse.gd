extends "res://tests/smoke_test.gd"

var _out := ""


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	super._ready()


func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var suite := preload("./warehouse-suite.gd").new(self)
	var runs := 3 if DisplayServer.get_name() == "headless" else 1
	for iteration in runs:
		await suite._test_watchdog_head_in_warehouse()
	await _finish()


func _capture(side: int) -> void:
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_check(image.save_png(_out.path_join("watchdog-side-%d.png" % side)) == OK, "captured the warehouse shot")
