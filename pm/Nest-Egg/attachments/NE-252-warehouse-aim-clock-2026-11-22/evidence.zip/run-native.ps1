param([Parameter(Mandatory)][string]$Label,[switch]$Before)
$ErrorActionPreference='Stop'
$e=$PSScriptRoot
$project='D:/NestEggVerification/ne218-baseline-20261117'
$scene="$e/warehouse.tscn"
if ($Before) { $scene="$e/warehouse-before.tscn" }
$out="$e/$Label"
New-Item -ItemType Directory -Path "$out/profile" | Out-Null
$env:APPDATA="$out/profile"
$env:LOCALAPPDATA=$env:APPDATA
$engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$py='D:/ComfyUI/.venv-rocm/Scripts/python.exe'
& $py -B "$project/tools/comfyui/gpu_lock.py" -- $engine --path $project --rendering-method forward_plus --rendering-driver vulkan --resolution 1280x720 --fixed-fps 24 --audio-driver Dummy --quit-after 1300 $scene -- "--out=$out" *> "$out/raw.log"
$code=$LASTEXITCODE
Set-Content -LiteralPath "$out/exit.txt" -Value $code
Get-Content "$out/raw.log" -Tail 12
exit $code
