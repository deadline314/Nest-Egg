from pathlib import Path
import subprocess,hashlib,json,zipfile,shutil
root=Path.cwd();work=root/'work/ne228-flood';out=root/'pm/Nest-Egg/attachments/NE-228-flood-prompt';out.mkdir(parents=True,exist_ok=True);native=Path('/workspace/Nest-Egg/work/batch1020b');sha=lambda b:hashlib.sha256(b).hexdigest();base='b09d21f2b4d30de1d807ec8be4ea4cda18406af8'
assert (work/'before.gd').read_bytes()==subprocess.check_output(['git','show',base+':game/props/flood_pit.gd'])
test=(root/'tests/suite/test_flood_pit.gd').read_text().replace('\tawait _test_prompt_reach()\n','');a=test.index('func _test_prompt_reach()');b=test.index('func _level_data(',a);test=test[:a]+test[b:];assert test.encode()==subprocess.check_output(['git','show',base+':tests/suite/test_flood_pit.gd'])
assert not subprocess.check_output(['git','diff','--name-only',base,'--','tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']).strip()
assert 'checks: 28, new failures: 0' in (work/'changed.log').read_text();assert 'checks: 28, new failures: 3' in (work/'negative.log').read_text()
for case,expected in [('before',2),('after',0)]:
 name='ne228-1022-flood-prompt-v3-'+case;d=json.loads((native/name/'result.json').read_text());log=(native/(name+'.log')).read_text();assert d['completed'] and d['failures']==expected and 'ERROR:' not in log and 'leaked' not in log
 assert (native/(name+'.exit')).read_text().strip()==('1' if case=='before' else '0')
 assert d['rows'][0]['distance']>1000 and d['rows'][0]['radio_queue']==[]
 assert d['rows'][0]['showing']==(case=='before')
files={}
for p in work.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in x or x.startswith('data_') for x in p.relative_to(work).parts):files['work/ne228-flood/'+str(p.relative_to(work))]=p.read_bytes()
for p in native.glob('ne228-1022-flood-prompt-*'):
 if p.is_dir() and not p.name.endswith('-profile'):
  for f in p.iterdir():
   if f.is_file():files['native/'+p.name+'/'+f.name]=f.read_bytes()
 elif p.is_file() and p.suffix in ['.log','.exit']:files['native/'+p.name]=p.read_bytes()
for p in ['game/props/flood_pit.gd','game/level/world_prompt.gd','tests/suite/test_flood_pit.gd','tools/quest_resume_probe.gd','tools/viewport_capture.gd','data/levels/ch1_warehouse.tres','project.godot']:
 files['source/final/'+p]=(root/p).read_bytes();files['source/before/'+p]=subprocess.check_output(['git','show',base+':'+p])
files['tools/native.py']=(native/'native.py').read_bytes()
for p in (root/'pm/Nest-Egg/attachments/NE-254-boundaries/research').iterdir():
 if p.is_file():files['references/'+p.name]=p.read_bytes()
validation={'base':base,'original_assertions_unchanged':True,'new_checks':5,'original_harness_unchanged':True,'old_product_negative':[28,3],'final_original_selector':[28,0],'seconds':14,'native_final_before':[15,2],'native_final_after':[15,0],'native_final_engine_errors':0,'native_final_pngs_viewed':6,'intermediate':'v1 radio masked near and far; v2 checked before deferred radio started and did not reproduce far bug; v3 waits destination sensors then actual radio completion; preserved','scope':'arranged formal Main warehouse and survival floor1, hold player physics for near/far, resume real gravity for plate; original enemies retained; not human chapter, physical controller or overall UI acceptance','final_product_sha256':sha((root/'game/props/flood_pit.gd').read_bytes())}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
manifest={'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for e in manifest['files']:assert sha(z.read(e['path']))==e['sha256']
manifest.update(archive_bytes=(out/'raw.zip').stat().st_size,archive_sha256=sha((out/'raw.zip').read_bytes()));(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for case,f,label in [('before','distant-combat','before'),('after','distant-combat','after'),('after','near-plate','near'),('after','plate-activated','activated')]:shutil.copy2(native/('ne228-1022-flood-prompt-v3-'+case)/(f+'.png'),root/'pm/Nest-Egg/images'/('NE-228-flood-'+label+'.png'))
print(json.dumps({'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256']},indent=2))
