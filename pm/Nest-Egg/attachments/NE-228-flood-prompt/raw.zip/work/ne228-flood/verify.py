from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();out=root/'work/ne228-flood';source=root/'game/props/flood_pit.gd';fixed=source.read_bytes();env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6');rows=[]
try:
 source.write_bytes((out/'before.gd').read_bytes())
 command=['tools/run_tests_parallel.sh','--only=FloodPitSuite'];child=env.copy();child['LOG_DIR']=str(out/'negative-shards')
 with (out/'negative.log').open('w') as log:r=subprocess.run(command,env=child,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 rows.append({'mode':'old-product-negative','command':command,'exit_code':r.returncode});print('negative',r.returncode,flush=True)
finally:
 source.write_bytes(fixed);assert source.read_bytes()==fixed
command=['tools/run_tests_changed.sh','b09d21f2'];child=env.copy();child['LOG_DIR']=str(out/'changed-shards')
with (out/'changed.log').open('w') as log:r=subprocess.run(command,env=child,stdout=log,stderr=subprocess.STDOUT,timeout=600)
rows.append({'mode':'final','command':command,'exit_code':r.returncode});print('final',r.returncode,flush=True)
(out/'verification.json').write_text(json.dumps({'runs':rows,'final_sha256':hashlib.sha256(fixed).hexdigest()},indent=2)+'\n');raise SystemExit(r.returncode)
