extends "res://work/ne228-flood/phone_base.gd"

func _save_report() -> void:
	FileAccess.open(out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify({"completed": _completed, "failures": _failures, "rows": rows, "scope": "formal Main warehouse, arranged routing/positions, player physics held only for near/far composition, original enemies retained and survival floor1; actual gravity activates plate; not combat balance or human play"}, "\t"))

func _capture(name: String, pit: FloodPit, prompt: WorldPrompt) -> void:
	await _shot(name)
	rows[-1]["distance"] = _level().player.global_position.distance_to(pit.global_position)
	rows[-1]["triggered"] = pit.triggered
	rows[-1]["enabled"] = prompt.enabled
	rows[-1]["showing"] = prompt.is_showing()
	rows[-1]["alpha"] = prompt._alpha
	_save_report()

func _settle_prompts() -> void:
	_check(await _until(func() -> bool: return not Story.is_cinematic_active() and not DialogueLayer.radio_visible() and Story._layer._radio_queue.is_empty() and not GameplayLock.is_locked() and not get_tree().paused, 60.0), "authored automatic radio finishes before prompt inspection")
	await get_tree().create_timer(0.3).timeout

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	Story.auto_skip = true
	await _until(func() -> bool: return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested", GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE), "formal Main starts the run")
	await _skip_cinematics()
	await _enter("res://data/levels/ch1_warehouse.tres")
	var pit: FloodPit
	for node in _level().find_children("*", "", true, false):
		if node is FloodPit:
			pit = node
	_check(pit != null, "authored warehouse flood pit exists")
	if pit == null:
		return
	var prompt: WorldPrompt
	for child in pit.get_children():
		if child is WorldPrompt:
			prompt = child
	_check(prompt != null, "authored plate invitation exists")
	if prompt == null:
		return
	var player := _level().player
	player.health.floor_health = 1
	player.set_physics_process(false)
	player.global_position = pit.global_position + Vector2(-1000, -96)
	_level().camera.snap_to_target()
	await _settle_prompts()
	_check(not pit.triggered, "distant combat position has not activated the plate")
	_check(not prompt.is_showing() and is_zero_approx(prompt._alpha), "plate invitation stays hidden at distant combat")
	await _capture("distant-combat", pit, prompt)
	player.global_position = pit.global_position + Vector2(30, -10)
	_level().camera.snap_to_target()
	await _settle_prompts()
	_check(not pit.triggered and prompt.is_showing(), "nearby dry plate retains its instruction")
	await _capture("near-plate", pit, prompt)
	player.global_position = pit.global_position + Vector2(0, -30)
	player.velocity = Vector2.ZERO
	player.set_physics_process(true)
	_check(await _until(func() -> bool: return pit.triggered, 3.0), "actual gravity lands on and activates the plate")
	await get_tree().create_timer(0.25).timeout
	_check(not prompt.enabled and not prompt.is_showing(), "activated plate retires the instruction")
	await _capture("plate-activated", pit, prompt)
	_completed = true
	_save_report()
