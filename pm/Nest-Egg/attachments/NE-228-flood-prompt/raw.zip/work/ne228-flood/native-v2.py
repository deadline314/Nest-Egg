from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd();out=root/'work/ne228-flood';source=root/'game/props/flood_pit.gd';final=source.read_bytes();env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen';rows=[]
try:
 for mode in ['before','after']:
  source.write_bytes((out/'before.gd').read_bytes() if mode=='before' else final)
  name='ne228-1022-flood-prompt-v2-'+mode
  command=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/ne228-flood/probe.tscn','--mode=write','--save-dir='+str(out/('v2-'+mode+'-save'))]
  with (out/(mode+'-wrapper.log')).open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1850)
  rows.append({'mode':mode,'command':command,'exit_code':r.returncode,'product_sha256':hashlib.sha256(source.read_bytes()).hexdigest()});(out/'native-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print(mode,r.returncode,flush=True)
  assert r.returncode==(1 if mode=='before' else 0)
finally:
 source.write_bytes(final);assert source.read_bytes()==final
