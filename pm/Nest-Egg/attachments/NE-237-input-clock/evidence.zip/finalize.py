from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
root=Path('work/melee-input-clock');console=(root/'required-runner.log').read_text()
m=re.search(r'checks: (\d+), new failures: 0, known failures .*: 0  \(wall time (\d+) s\)',console)
assert m,'required checks not passing/complete'
checks,seconds=map(int,m.groups())
assert 'checks: 8, failures: 0' in (root/'after.log').read_text()
assert (root/'paced-before.exit').read_text().strip()=='1'
assert (root/'paced-after.exit').read_text().strip()=='0'
assert (root/'native-focused-before.exit').read_text().strip()=='1'
assert (root/'native-focused-after.exit').read_text().strip()=='0'
assert 'diagnostics=0' in (root/'dummy-exit.log').read_text()
for mode in ['before','after']:
 log=(root/('native-focused-'+mode+'.log')).read_text()
 assert not re.search(r'^ERROR:|SCRIPT ERROR|Parse Error|leaked at exit|resources still in use',log,re.M),mode
folder=Path('pm/Nest-Egg/attachments/NE-237-input-clock');folder.mkdir(exist_ok=False)
source=root/'delivery-source';source.mkdir(exist_ok=False)
for name in ['game/player/melee_command_input.gd','tests/suite/test_melee.gd','tests/helpers/melee_physics_clock.gd','tests/helpers/melee_trigger_edge_checks.gd']:
 target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(name,target)
shutil.copyfile('/workspace/.nest-egg-env/ci-godot/dist/receipt.json',root/'engine-receipt.json')
initial=root/'discovery';initial.mkdir(exist_ok=False)
for name in ['required-runner.log','required/shard_0.log']:
 p=Path('work/ch2-gate-save')/name
 target=initial/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
for mode in ['before','after']:
 shutil.copyfile(root/('native-focused-'+mode+'.png'),Path('pm/Nest-Egg/images')/('NE-237-input-clock-'+mode+'.png'))
with zipfile.ZipFile(folder/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in {'.json','.log','.exit','.gd','.tscn','.py','.png','.txt'} and '__pycache__' not in p.parts:
   archive.write(p,str(p.relative_to(root)))
receipt={'base':'dba49a7b597476f2f0406712580c9bbb5f240b6c','discovery':{'groups':68,'checks':92203,'new_failures':1,'seconds':551},'controlled_headless':{'before_failures':1,'after_failures':0},'original_5fps_phases':{'checks':8,'failures':0},'fixed_clock_5fps_phases':{'checks':8,'failures':0},'controlled_native_software':{'steps_per_device':40,'before_failures':1,'after_failures':0},'required':{'groups':28,'checks':checks,'new_failures':0,'known_failures':0,'seconds':seconds},'archive_sha256':hashlib.sha256((folder/'evidence.zip').read_bytes()).hexdigest()}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(folder/'README.md').write_text(f'''# NE-237：裝置影格比對採一致時鐘

在巡帳員交付的受影響68組92,203項中，近戰熱刃early follow-up有1新失敗：鍵盤第24格接出第二段，另外三種輸入只有第一段。保留551秒完整結果與原MeleeSuite日誌，不把巡帳員交付當成通過。

正式命令刻意使用單調真實時間，避免局部hitstop或暫停延長命令。原parity測試以物理影格安排操作，卻用每輪不同的真實毫秒到期；補步時相同影格數不代表相同毫秒。不是發現手把的產品規則不同。

在乾淨dba49a7b保存原來源後才改動；控制使用原測試來源與同樣回傳Time的正式時鐘（查詢已集中到小型方法，並非宣稱整個控制是未修改main）。普通5fps八相位原本8項全過，不能假稱低FPS必然失敗。第一個只加400ms阻塞與64補步上限的控制也通過，完整保留。最終反例明示同一原影格腳本：鍵盤在第6格事件前阻塞400ms並允許64補步；其餘三種限制每畫面1步、60fps上限。這是不同渲染節拍的合成情境；原時鐘比較1項1失敗，與發現時相同的時間軸。修後相同控制1項0失敗。

`MeleeCommandInput._now_msec()`把既有Time.get_ticks_msec查詢集中，正式命令仍用原單調毫秒、原deadline與原資料。只有`MeleeSuite._timeline`替換為測試子類，以實際Engine物理步數換算毫秒。仍送原四種公開事件、跑真正Player物理步、原命令到期規則，原25條比較與200格腳本保持；沒有延長buffer或清掉失敗斷言。長起手、真命中停頓、已過期舊命令，以及扳機鎖存回歸仍用正式真實時鐘。

- 修後5fps八相位、32個原完整輸入重播：8項0失敗。
- 原必要選擇器28組{checks:,}項，0新／已知失敗、{seconds}秒。包含完整五武器×五操作×四輸入，以及真實過期／hitstop檢查。完整六份退出另驗DummyTexture0。
- 原生軟體Vulkan控制同樣1失敗→0失敗、無額外嚴格引擎診斷。最初200步原生診斷的說明與底部裁切，原圖保留；修正排版後用40步專注覆蓋同一第24格反例，舊／新各重新執行。這是合成輸入儀器畫面，不是自然戰鬥、實體GPU或實體手把驗收；完整200格覆蓋由上列原套件保留。
- 線上Godot Time文件讀取回403，沒有重試；改核對已驗SHA的同版本引擎來源中的Time.xml／Engine.xml。它們明示單調ticks與每渲染畫面補步上限，來源節錄及失敗嘗試記在research/sources.json，未宣稱線上文件已讀成功。

[evidence.zip](evidence.zip)含原發現、來源、所有通過／失敗控制、原生原圖及完整回歸。[receipt.json](receipt.json)記錄邊界及雜湊。實體手把條件維持未勾。
''')
p=Path('pm/Nest-Egg/[NE-237]擴充近戰連段與招式成長.md')
with p.open('a') as stream:
 stream.write(f'''

# Commit-9（穩定比較鍵鼠與手把的連段輸入）

## 內文

機器忙碌補跑物理步時，原連段比對會把不同真實時長的輸入當成同一串操作，偶爾錯報鍵盤和手把不一致。現在同一串影格操作能在一致的時間條件下比較；正式遊戲的命令仍按真實期限到期，命中停頓不延長接招。

控制案例1項1失敗→0失敗，低畫面更新率8組全過。原五把武器、五種操作、四種輸入的完整矩陣與真實命令到期檢查，包含在受影響28組{checks:,}項全過。原生軟體Vulkan另重現1失敗→0失敗；以下為合成輸入診斷，不代稱實體手把或完整戰鬥。

![舊時間條件造成錯報](images/NE-237-input-clock-before.png)
![一致時間條件的相同操作](images/NE-237-input-clock-after.png)

[原始發現、控制、裁切舊圖與全部原始結果](attachments/NE-237-input-clock/README.md)。
''')
print(json.dumps(receipt,indent=2))
