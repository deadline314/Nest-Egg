extends "res://tests/smoke_test.gd"
func _run() -> void:
 Story.auto_skip=true
 Enemy.activation_culling_enabled=false
 Engine.max_fps=5
 var suite:=MeleeSuite.new(self)
 var weapon:=load("res://data/weapons/melee/melee_blade.tres") as WeaponData
 for phase in 8:
  await suite.physics_frames(phase)
  var results: Dictionary={}
  for device: String in ["key_melee","pad_melee","mouse_shoot","pad_shoot"]:
   results[device]=await suite._timeline(weapon,[[0,3],[6,9]],device)
  print("PARITY_PHASE ",phase," ",results)
  _check(results.key_melee==results.pad_melee and results.key_melee==results.mouse_shoot and results.key_melee==results.pad_shoot,"original phase %d parity %s" % [phase,results])
 await _finish()
