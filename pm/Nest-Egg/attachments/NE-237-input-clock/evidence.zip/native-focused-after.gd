extends "res://tests/smoke_test.gd"
func _run() -> void:
 Story.auto_skip=true
 Enemy.activation_culling_enabled=false
 Engine.max_physics_steps_per_frame=64
 var suite=load("res://work/melee-input-clock/native-focused-after-suite.gd").new(self)
 var weapon:=load("res://data/weapons/melee/melee_blade.tres") as WeaponData
 var results: Dictionary={}
 for device: String in ["key_melee","pad_melee","mouse_shoot","pad_shoot"]:
  Engine.max_physics_steps_per_frame=64 if device=="key_melee" else 1
  Engine.max_fps=0 if device=="key_melee" else 60
  results[device]=await suite._timeline(weapon,[[0,3],[6,9]],device)
 print("STALL_PARITY ",results)
 _check(results.key_melee==results.pad_melee and results.key_melee==results.mouse_shoot and results.key_melee==results.pad_shoot,"same original frame-script parity after a declared renderer stall")
 var layer:=CanvasLayer.new()
 layer.layer=120
 add_child(layer)
 var bg:=ColorRect.new()
 bg.color=Color("101a26")
 bg.size=Vector2(1280,720)
 layer.add_child(bg)
 var text:=Label.new()
 text.position=Vector2(24,24)
 text.add_theme_font_size_override("font_size",14)
 text.text="INPUT CLOCK DIAGNOSTIC / AFTER\nSOFTWARE VULKAN / SYNTHETIC INPUT\nCONTROLLED PACING / 40 REAL PHYSICS STEPS\n\n"
 for device: String in results:text.text+=device+": "+str(results[device])+"\n"
 text.text+="\nPARITY CHECKS: "+str(_checks)+" / FAILURES: "+str(_failures.size())
 layer.add_child(text)
 await get_tree().process_frame
 await RenderingServer.frame_post_draw
 var image:=preload("res://tools/viewport_capture.gd").image(get_viewport())
 image.save_png("/workspace/Nest-Egg/work/melee-input-clock/native-focused-after.png")
 await _finish()
