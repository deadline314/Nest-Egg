extends "res://tests/smoke_test.gd"
func _run() -> void:
 Story.auto_skip=true
 Enemy.activation_culling_enabled=false
 Engine.max_physics_steps_per_frame=64
 var suite=load("res://work/melee-input-clock/stall-before-suite.gd").new(self)
 var weapon:=load("res://data/weapons/melee/melee_blade.tres") as WeaponData
 var results: Dictionary={}
 for device: String in ["key_melee","pad_melee","mouse_shoot","pad_shoot"]:
  Engine.max_physics_steps_per_frame=64 if device=="key_melee" else 1
  Engine.max_fps=0 if device=="key_melee" else 60
  results[device]=await suite._timeline(weapon,[[0,3],[6,9]],device)
 print("STALL_PARITY ",results)
 _check(results.key_melee==results.pad_melee and results.key_melee==results.mouse_shoot and results.key_melee==results.pad_shoot,"same original frame-script parity after a declared renderer stall")
 await _finish()
