from hashlib import sha256
from pathlib import Path
from shutil import copyfile
from tempfile import TemporaryDirectory
import json
import os
import re
import subprocess
import sys

root = Path.cwd()
project = Path(os.environ["NEST_EGG_PREVIEW_PROJECT"])
scratch = Path(__file__).resolve().parent
proof = scratch / sys.argv[1]
scene_prefix = "exact-" if sys.argv[1] == "native-final" else ""
proof.mkdir()
engine = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
lock = [sys.executable, "-B", str(project / "tools/comfyui/gpu_lock.py"), "--"]
paths = ("tools/scenery_stage_capture.gd", "tools/shock_ring_review.gd", "tools/weapon_balance_probe.gd")
before = {path: [line.strip() for line in (root / path).read_text(encoding="utf-8").splitlines()
                 if re.search(r'(?:res://pm/|user://verification/)', line)] for path in paths}
assert all(before[path] for path in paths)
(proof / "previous-or-current-defaults.json").write_text(json.dumps(before, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def state():
    return subprocess.run(["git", "status", "--porcelain=v1", "--untracked-files=all", "--", "pm"],
                          cwd=project, capture_output=True, check=True).stdout


before_pm = state()
receipts = []


def run_case(key, label, args, expected, *, native=False, artifact=None, error_message=None):
    actual = [engine, "--path", str(project), "--audio-driver", "Dummy"]
    if native:
        actual = lock + actual + ["--rendering-method", "forward_plus", "--rendering-driver", "vulkan",
                                  "--resolution", "640x360", "--max-fps", "120"]
    else:
        actual += ["--headless"]
    # The one real sample remains at 60 physics Hz, including the production wall-clock hitstop.
    actual += [str(scratch / f"{scene_prefix}{key}.tscn"), "--", *args]
    output = proof / f"{label}.log"
    with output.open("wb") as raw:
        result = subprocess.run(actual, cwd=project, env=environment, stdout=raw, stderr=subprocess.STDOUT, timeout=90)
    text = output.read_text(encoding="utf-8")
    assert "SCRIPT ERROR:" not in text, text[-3000:]
    assert result.returncode == expected, (label, result.returncode, text[-3000:])
    if expected == 0:
        assert not re.search(r"^ERROR:", text, re.M), (label, text[-3000:])
    if error_message is not None:
        assert error_message in text, (label, text[-2000:])
    if native:
        assert "RX 9070 XT" in text and "Forward+" in text, (label, text[:300])
    receipt = {"case": label, "exit": result.returncode}
    if artifact is not None:
        expected_path = artifact()
        assert expected_path.is_file(), (label, expected_path)
        capture = expected_path.read_bytes()
        assert str(expected_path).replace("\\", "/").casefold() in text.replace("\\", "/").casefold(), (label, str(expected_path), text[-600:])
        if key == "balance":
            doc = json.loads(capture)
            assert len(doc["samples"]) == 1 and doc["samples"][0]["damage"] > 0, doc["samples"]
        else:
            assert capture.startswith(b"\x89PNG\r\n\x1a\n")
        receipt.update(sha256=sha256(capture).hexdigest(), bytes=len(capture), file=expected_path.name)
        if label == "stage-default":
            copyfile(expected_path, proof / "stage-native.png")
    receipts.append(receipt)


def default(name):
    hits = list(profile.glob("**/verification/" + name))
    assert len(hits) == 1, hits
    return hits[0]


with TemporaryDirectory(prefix="nestegg-local-probe-profile-") as owned:
    profile = Path(owned)
    environment = dict(os.environ, APPDATA=owned, LOCALAPPDATA=owned, XDG_DATA_HOME=owned, XDG_CONFIG_HOME=owned)
    stage = "ch2_rooftop_tea"
    filename = f"BG-19-stage-{stage}.png"
    stage_override = profile / "explicit" / "scenes"
    ring_override = profile / "explicit" / "effects" / "ring.png"
    balance_override = profile / "explicit" / "measurements" / "balance.json"
    bad_file = profile / "file-not-directory"
    bad_file.write_text("Fixture that deliberately prevents creating a directory.\n", encoding="utf-8")
    run_case("stage", "stage-default", [f"--only={stage}"], 0, native=True,
             artifact=lambda: default(f"scenery-stages/{filename}"))
    run_case("stage", "stage-explicit", [f"--only={stage}", f"--out={stage_override}"], 0, native=True,
             artifact=lambda: stage_override / filename)
    run_case("stage", "stage-unknown", ["--only=invalid_stage_fixture"], 1, error_message="Unknown stage")
    run_case("ring", "ring-default", [], 0, native=True, artifact=lambda: default("shock-ring-review.png"))
    run_case("ring", "ring-explicit", [f"--out={ring_override}"], 0, native=True, artifact=lambda: ring_override)
    run_case("ring", "ring-blocked-parent", [f"--out={bad_file / 'ring.png'}"], 1, error_message="Cannot create")
    run_case("balance", "balance-default", [], 0, artifact=lambda: default("weapon-balance.json"))
    run_case("balance", "balance-explicit", [f"--out={balance_override}"], 0, artifact=lambda: balance_override)
    run_case("balance", "balance-blocked-parent", [f"--out={bad_file / 'balance.json'}"], 1, error_message="Cannot create")
    run_case("stage", "stage-blocked-parent", [f"--only={stage}", f"--out={bad_file / 'stage'}"], 1, error_message="Cannot create")
    run_case("stage", "stage-headless-viewport", [f"--only={stage}"], 1, error_message="A rendering viewport is required.")
    run_case("ring", "ring-headless-viewport", [], 1, error_message="A rendering viewport is required.")
    assert bad_file.read_text(encoding="utf-8").startswith("Fixture")

assert state() == before_pm, "probe modified the PM tree without an explicitly supplied PM path"
report = {"checks": len(receipts), "pm_status_preserved": True, "receipts": receipts}
(proof / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, ensure_ascii=False))
