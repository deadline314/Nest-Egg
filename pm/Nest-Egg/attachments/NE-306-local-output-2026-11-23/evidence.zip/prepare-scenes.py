from pathlib import Path
import sys

scratch = Path(__file__).resolve().parent
definitions = {
    "stage": "scenery_stage_capture",
    "ring": "shock_ring_review",
    "balance": "weapon_balance_probe",
}
prefix = "exact-" if "--exact" in sys.argv else ""
for key, file in definitions.items():
    target = "res://" if prefix else "./"
    template = f'''extends "{target}tools/{file}.gd"

func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	super._ready()
'''
    if key == "balance":
        template += '''
## The output test runs one real complete sample through the unmodified measurement method.
func _sample(index: int, target_id: String, difficulty: int, miss: bool) -> void:
	if samples.is_empty():
		await super._sample(index, target_id, difficulty, miss)
'''
    (scratch / f"{prefix}{key}.gd").write_bytes(template.encode("utf-8"))
    scene = f'''[gd_scene load_steps=2 format=3]

[ext_resource type="Script" path="./{prefix}{key}.gd" id="1"]

[node name="DiagnosticOutputProbe" type="Node"]
script = ExtResource("1")
'''
    (scratch / f"{prefix}{key}.tscn").write_bytes(scene.encode("utf-8"))
