from pathlib import Path
import hashlib,json,msvcrt,os,re,subprocess,sys,time,urllib.request,urllib.error
TREE=Path(__file__).resolve().parents[2];ROOT=Path('C:/Users/stanl/Github/Nest-Egg');OUT=TREE/'work/ne298-layout-proposal-v1'/sys.argv[1];MODE=sys.argv[2];OUT.mkdir(exist_ok=False)
BASE='92521d0cf3c18bd3dad4b13a316844e70bfaecd0';GODOT=Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe');GUARD=ROOT/'work/ne296-adoption-v1/c-native-context-v29.json'
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def snapshot():
 names=subprocess.check_output(['git','ls-files','-z'],cwd=TREE).decode().split('\0')+subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=TREE).decode().split('\0')
 roots={'art','audio','autoload','core','data','game','scenes','tests','tools','ui'}
 return {n:{'size':(TREE/n).stat().st_size,'sha256':sha(TREE/n)} for n in sorted(set(names)) if n and (TREE/n).is_file() and (n.split('/')[0] in roots or n=='project.godot')}
def queues():
 out=[];opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 for port in [8188,8189]:
  try:
   with opener.open(f'http://127.0.0.1:{port}/queue',timeout=3) as response:b=response.read()
   v=json.loads(b);assert isinstance(v['queue_running'],list) and isinstance(v['queue_pending'],list)
   out.append({'port':port,'state':'empty' if not v['queue_running'] and not v['queue_pending'] else 'busy','running':len(v['queue_running']),'pending':len(v['queue_pending']),'response_sha256':hashlib.sha256(b).hexdigest()})
  except urllib.error.URLError as e:
   code=getattr(e.reason,'winerror',None);out.append({'port':port,'state':'refused' if code==10061 else 'unknown','winerror':code})
  except Exception as e:out.append({'port':port,'state':'unknown','error':type(e).__name__})
 return out
def clear(q):return len(q)==2 and q[0]['state']=='empty' and q[1]['state'] in ('empty','refused')
assert MODE in ['import','focused'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=TREE).decode().strip()==BASE
assert sha(GUARD)=='a3df1f1a2c27952545453a3d1b8a422a42755deddcc86088a70c1dc62e1d81d0';guard=json.loads(GUARD.read_bytes())['files'];assert len(guard)==463;assert all(sha(ROOT/n)==v for n,v in guard.items())
expected=json.loads((TREE/'work/ne298-layout-proposal-v1/cpu-freeze-v6/source-manifest.json').read_bytes())['owned'];assert all(sha(TREE/n)==v['sha256'] for n,v in expected.items())
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes());before=snapshot();save('source-before.json',before);save('c-before.json',guard)
save('engine-source.json',{'path':str(GODOT),'sha256':sha(GODOT),'test_finish':'Original smoke_test._finish stop_all and real timers; no modified suite or audio adapter.'})
env=os.environ.copy();keys=['APPDATA','LOCALAPPDATA','USERPROFILE','TMP','TEMP']
for key in keys:env[key]=str(OUT/'userdata'/key);Path(env[key]).mkdir(parents=True,exist_ok=True)
argv=[str(GODOT),'--headless','--path',str(TREE)]+(['--editor','--import'] if MODE=='import' else ['res://tests/smoke_test.tscn','--','--only=SceneSanitySuite,Chapter1MapSuite'])
save('command.json',{'argv':argv,'cwd':str(TREE),'env':{k:env[k] for k in keys},'mode':MODE,'base':BASE,'scope':'Functional only, no performance/native/route acceptance'})
outer=queues();save('outer-queue-before.json',outer)
if not clear(outer):save('blocked.json',{'engine_started':False,'reason':'busy or unknown queue'});sys.exit(3)
sys.path.insert(0,str(ROOT/'tools/comfyui'));import comfy_guard
assert comfy_guard.LOCK_PATH==ROOT/'assets_src/work/comfy.lock';save('lock-source.json',{'path':str(comfy_guard.LOCK_PATH),'helper_sha256':sha(ROOT/'tools/comfyui/comfy_guard.py')})
lock=open(comfy_guard.LOCK_PATH,'a+b');held=False;process=None;error=None;code=None;after={};t=time.monotonic()
try:
 lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1);held=True
 inner=queues();save('inner-queue-before.json',inner);assert clear(inner)
 assert snapshot()==before and all(sha(ROOT/n)==v for n,v in guard.items())
 with (OUT/'engine.log').open('wb') as log:
  process=subprocess.Popen(argv,cwd=TREE,env=env,stdout=log,stderr=subprocess.STDOUT);save('process.json',{'pid':process.pid,'argv':argv})
  try:code=process.wait(timeout=900)
  except subprocess.TimeoutExpired:
   q=subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True);(OUT/'owned-timeout-cleanup.stdout').write_bytes(q.stdout);(OUT/'owned-timeout-cleanup.stderr').write_bytes(q.stderr);code=process.wait(timeout=30);raise
except Exception as e:error=repr(e)
finally:
 save('inner-queue-after.json',queues());after=snapshot();save('source-after.json',after);cafter={n:sha(ROOT/n) for n in guard};save('c-after.json',cafter)
 # Engine import cache inventory, distinct from the input source projection.
 cache={}
 for p in sorted((TREE/'.godot').rglob('*')):
  if p.is_file():cache[p.relative_to(TREE).as_posix()]={'size':p.stat().st_size,'sha256':sha(p)}
 save('import-products.json',cache)
 if held:lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
 lock.close();save('outer-queue-after.json',queues())
raw=(OUT/'engine.log').read_text(encoding='utf8',errors='replace') if process else ''
diag=[s for s in raw.splitlines() if re.search(r'ERROR:|SCRIPT ERROR|Parse Error|WARNING:|ObjectDB.*leak|RID allocations.*leaked|resources still in use at exit',s)]
added=sorted(set(after)-set(before));removed=sorted(set(before)-set(after));changed=sorted(n for n in before.keys()&after.keys() if before[n]!=after[n]);newuids=MODE=='import' and not changed and not removed and all(n.endswith('.gd.uid') or n.endswith('.gdshader.uid') for n in added)
result=re.findall(r'^checks: (\d+), failures: (\d+)$',raw,re.M);failures=[s for s in raw.splitlines() if s.startswith('FAIL:')];qok=all(clear(json.loads((OUT/n).read_bytes())) for n in ['outer-queue-before.json','inner-queue-before.json','inner-queue-after.json','outer-queue-after.json']) if process else False
filter_ok=True
if MODE=='focused' and process:
 filter_argv=['C:/Program Files/Git/bin/bash.exe','-c','source tools/test_filters.sh; if has_unexpected_errors "$1"; then exit 1; else exit 0; fi','ne298-original-filter',(OUT/'engine.log').as_posix()]
 classified=subprocess.run(filter_argv,cwd=TREE,capture_output=True)
 (OUT/'filter.stdout').write_bytes(classified.stdout);(OUT/'filter.stderr').write_bytes(classified.stderr)
 save('filter-command.json',{'argv':filter_argv,'exit':classified.returncode,'source_path':'tools/test_filters.sh','source_sha256':sha(TREE/'tools/test_filters.sh'),'scope':'Original unexpected-error predicate, unchanged; all WARNING/raw diagnostics remain stored.'})
 filter_ok=classified.returncode==0
 script_or_exit=any(re.search(r'SCRIPT ERROR|Parse Error|ObjectDB.*leak|RID allocations.*leaked|resources still in use at exit',x) for x in diag)
else:script_or_exit=bool(diag)
accepted=code==0 and error is None and (before==after or newuids) and cafter==guard and qok and filter_ok and not script_or_exit and (MODE=='import' or (result and int(result[-1][1])==0 and not failures))
receipt={'mode':MODE,'base':BASE,'exit':code,'seconds':round(time.monotonic()-t,3),'engine_started':process is not None,'owned_pid':process.pid if process else None,'error':error,'checks':result,'failures':failures,'diagnostics':diag,'original_filter_ok':filter_ok,'script_or_exit_diagnostics':script_or_exit,'source_before_count':len(before),'source_after_count':len(after),'changed':changed,'removed':removed,'added':added,'import_uid_additions':added if newuids else [],'c_unchanged':cafter==guard,'four_queue_gates':qok,'accepted':bool(accepted)}
save('receipt.json',receipt);print(json.dumps(receipt,ensure_ascii=False,indent=2),flush=True);sys.exit(0 if accepted else 1)