# NE298 v5窄修正候選

92521基底，21 owned LF來源；Player/2tuning為published依賴，不算自有產品。原cold-import-v1自然0/124.056s/0診斷，7新UID另列；focused-v1原2408/11、8原WARNING、0SCRIPT/ERROR、10177來源/C463前後同及四queueclear原件保留。沒有改寫這次紅。

v5移除8個實際已retired的arena_gate佈置；保resource檔與原cell遷移記錄、live wavezone/成員/增援。真lock_combat_area門不移除，原SceneAudit沒有skip。新門改street122,15及vault116,12，6個原紅入口配對真2D距離均>=原18格；新增同層/斜向近敵拒絕和垂直遠距永久控制。vault111..113開真落口接118,28秘密獎勵，沒有貼late標。

CPU22/0及完整生成exit0在../cpu/fixes-v5-*；新22/1測試紅原件也留存（街道channel位置誤當舊retired門resource，已改驗真可站地與author location）。原20/0與首輪11紅不混稱最終綠。v5尚未執行Godot；等待Root明確同2suite窗口。原44組已選測，尚未開長測。

Mapping仍246記錄；v4→v5所有原資源目的格不變，8退役gate標為不再放置。只有兩個新增portal移位。metadata/pack為CPU產生，不是引擎原件。所有真操作、火線安全、保存migration與Forward+畫面仍未完成。
