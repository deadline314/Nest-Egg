# NE298 v6

Base92521、21 owned LF source。v5原2399/1紅保留；唯一空格quest標記依真live ENCOUNTER/channel owner從street182,36改167,36，同改Binding/backend/generated quest，validator與所有GD source皆不變。相對published139 scenes/10quests，僅7個location scalar變更；raw原generator輸出及diff另保。geometry與mapping-actual-v5完全同，不加回retired gate。

CPU22/0、作者18/0、completion-policy9/0、chapter-policy6/0，具體原命令/log在../cpu/quest-owner-v6-*。原selectorowned21仍44組。此v6尚未engine測試，等同兩suite窗口；不稱44/保存/真Input/Forward+已驗。v4/v5 source/raw不覆寫。
