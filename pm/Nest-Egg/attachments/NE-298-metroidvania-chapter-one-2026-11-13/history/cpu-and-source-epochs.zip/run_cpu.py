from pathlib import Path
import subprocess,json,os,hashlib,sys,time
root=Path.cwd();out=root/'work/ne298-layout-proposal-v1/cpu';out.mkdir(exist_ok=True)
name=sys.argv[1];cmd=sys.argv[2:];assert not (out/(name+'.json')).exists()
paths=['tools/level/build_ch1.py','tools/level/level_kit.py','data/levels/ch1_layout_v2.json']
before={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in paths}
t=time.perf_counter();r=subprocess.run(cmd,capture_output=True,env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
(out/(name+'.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'elapsed':time.perf_counter()-t,'source_before':before,'source_after':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in paths}},indent=2)+'\n',encoding='utf8',newline='\n')
print(r.stdout.decode('utf8'));print(r.stderr.decode('utf8'));raise SystemExit(r.returncode)
