# NE298 v8

Base92521 exact21 LF candidate. Indoor warehouse/vault roof rows0..3 restored to preserve existing covered_columns/render/rain semantics. One drone destination90,3→90,6 avoids embedding; ID/encounter/source unchanged,246mapping rows preserved. CPU23/0 and full generator0. Geometry paths/late3-cell body unchanged otherwise. Prior v4/v5/v6 red/green and v7 native89/1 partial11 originals remain intact. v8 not yet engine/native tested.

Private producer now correct roof57,44→62,39 and includes actual ready-HUD flag transition/readback/hold witness plus guide image. Same original live-enemy rules;21 final images anticipated, not yet accepted. Original pixel precision verifier/1/255 threshold required separately. No savecore/primary/index/commit changes.
