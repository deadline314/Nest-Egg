# NE298 CPU候選 v4

基底92521d0c，21 owned來源均LF；source.zip逐檔與source-manifest.json相同。published Player與2個tuning另列context，不算本票產品。尚無Godot import/parser/headless/native；44組是原select_tests.py實際輸出，不是已執行。

CPU：完整build_ch1生成exit0；test_level_kit 20/0。此前作者18/0、completion policies9/0、chapter policy6/0保留原epoch；沒有合併說成一次檢查。舊pit地形紅與安全練習兩次紅都保留在../cpu/，不覆蓋。

映射：../mapping-actual-v4.json共246筆舊格；比v3唯一resource更動為vault drone舊52,9→60,44。四主要區offset[0,32]/height56；其餘identity。每個原resource目的格不合併。安全室腳20→12只CPU界線通過；活敵/實際輸入仍未驗。

故事JSON遞迴比較僅6個quest location.cell.y不同；source-manifest保具體path。generator原輸出鍵順序漂移另保../story-generated-original.json，正式候選保原鍵順序。

下一階段待Root排程：先獨立5env import；再原SceneSanitySuite/Chapter1MapSuite單程序。新SceneAudit保原普通5格/8格負控；late只有真ability/flag/目標，從P出發，不seed portal。12格是實際調校推得的寬鬆上界，不當真可玩證明。之後原changed.sh正式44組與Forward+真Input/安全練習另排。

原186畫面不是本圖驗收，未實作NE297保存核心。

選測範圍補充：原--base呼叫也看見本WT未追蹤的舊NE294/新NE298 work證據（原stderr列162檔）；這不是162個產品更動。另以exact21 owned --files獨立重算，44組字串與原--base逐byte相同，原文存selector-owned*。後續work附件增加不回填舊162數字。
