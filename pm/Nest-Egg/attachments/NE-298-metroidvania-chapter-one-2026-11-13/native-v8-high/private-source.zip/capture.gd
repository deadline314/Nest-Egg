extends Node
## NE298: public Input on actual geometry; arranged starts/progress, live enemies.
const Capture := preload("res://tools/viewport_capture.gd")
const ACTIONS: Array[StringName] = [&"jump", &"move_left", &"move_right", &"dash", &"shoot", &"melee", &"block", &"interact", &"move_down"]
var out := ""
var quality := "high"
var parse_only := false
var checks := 0
var failures := 0
var trace: Array[Dictionary] = []
var captures: Array[Dictionary] = []
var cases: Array[Dictionary] = []
var guide: Dictionary = {}
var level: Level
var measuring := false
var foreign_input := false
var previous_quality := -1
var fatal_io := false

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): out = arg.trim_prefix("--out=").replace("\\", "/")
		elif arg.begins_with("--quality="): quality = arg.trim_prefix("--quality=")
		elif arg == "--parse-only": parse_only = true
	_run.call_deferred()

func _input(event: InputEvent) -> void:
	if measuring and ((event is InputEventKey and event.pressed and not event.echo) or (event is InputEventMouseButton and event.pressed) or event is InputEventJoypadButton):
		foreign_input = true

func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("FAIL: ", label)

func _tick(count: int, tag := "") -> void:
	for i in count:
		await get_tree().physics_frame
		await get_tree().process_frame
		if not tag.is_empty() and is_instance_valid(level) and is_instance_valid(level.player):
			var p := level.player
			trace.append({"tag": tag, "physics_frame": Engine.get_physics_frames(), "process_frame": Engine.get_process_frames(), "position": [p.position.x,p.position.y], "velocity": [p.velocity.x,p.velocity.y], "on_floor": p.is_on_floor(), "can_process": p.can_process(), "air_used": p._air_jump_used, "health": p.health.current, "paused": get_tree().paused})

func _release() -> void:
	for action in [&"jump", &"move_left", &"move_right"]: Input.action_release(action)

func _neutral() -> bool:
	for action in ACTIONS:
		if Input.is_action_pressed(action): return false
	return true

func _enemy_state() -> Dictionary:
	var count := 0
	var active := 0
	var spaced := 0
	if is_instance_valid(level):
		for node in level._entities.get_children():
			if node is Enemy and is_instance_valid(node) and not node.is_queued_for_deletion():
				count += 1
				if node.can_process(): active += 1
				if PhysicsServer2D.body_get_space(node.get_rid()).is_valid(): spaced += 1
	return {"count": count, "active": active, "bodies_in_space": spaced, "activation_culling_changed": false}

func _begin(area: String, foot: Vector2i, earned: bool) -> bool:
	_release()
	check(_neutral(), "no outside action held at scenario entry")
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip = true
	GameState.set_flag(&"ledger_disk_obtained", earned, false)
	level = Level.new()
	level.configure(load("res://data/levels/ch1_" + area + ".tres"))
	add_child(level)
	var p := level.player
	AimInput.set_virtual_gamepad(p, true)
	AimInput.restore_direction(Vector2.RIGHT)
	# Only the initial pose is arranged. Subsequent movement uses normal physics.
	p.position = (Vector2(foot) + Vector2(0.5,1.0)) * 16.0
	p.velocity = Vector2.ZERO
	level.camera.snap_to_target()
	await _tick(4)
	Story.reset_active_presentation(&"capture_setup")
	await _tick(2)
	var ready := p.is_on_floor() and absf(p.position.y - float(foot.y + 1) * 16.0) <= 2.0 and not get_tree().paused and not p.is_dead()
	check(ready, "%s actual body settles on authored foot %s" % [area,foot])
	return ready

func _end() -> void:
	measuring = false
	_release()
	if is_instance_valid(level):
		AimInput.set_virtual_gamepad(level.player, false)
		level.queue_free()
	await get_tree().process_frame
	Story.reset_active_presentation(&"capture_end")
	await _tick(2)

func _snapshot(tag: String) -> void:
	await RenderingServer.frame_post_draw
	if not is_instance_valid(level) or not is_instance_valid(level.player):
		check(false, tag + " level/player remained live through readback")
		return
	var image := get_viewport().get_texture().get_image()
	var format := image.get_format()
	var bytes_per_pixel := 6 if format == Image.FORMAT_RGBH else (8 if format == Image.FORMAT_RGBAH else 0)
	check(image.get_size() == Vector2i(1280,720) and bytes_per_pixel > 0, "%s actual full HDR viewport" % tag)
	if bytes_per_pixel == 0 or image.get_size() != Vector2i(1280,720): return
	var data := image.get_data()
	var path := out.path_join(tag)
	var file := FileAccess.open(path + ".raw", FileAccess.WRITE)
	if file == null:
		check(false, "raw open: " + path)
		fatal_io = true
		return
	file.store_buffer(data)
	var write_error := file.get_error()
	var length := file.get_length()
	file.close()
	check(write_error == OK and length == 1280 * 720 * bytes_per_pixel, "raw exact length/write: " + path)
	var png_error := Capture.encode(image, true).save_png(path + ".png")
	check(png_error == OK, "PNG saved: " + path)
	fatal_io = fatal_io or write_error != OK or png_error != OK or length != 1280 * 720 * bytes_per_pixel
	var p := level.player
	var canvas := get_viewport().get_canvas_transform()
	var body := Rect2(p.global_position - Vector2(Player.BODY_SIZE.x * 0.5, Player.BODY_SIZE.y), Player.BODY_SIZE)
	var shown_body := canvas * body
	check(Rect2(Vector2.ZERO,Vector2(1280,720)).encloses(shown_body), tag + " actual physics body remains inside viewport")
	captures.append({"page":tag,"linear_raw":tag+".raw","encoded_png":tag+".png","size":[image.get_width(),image.get_height()],"format":format,"raw_bytes":length,"raw_sha256":FileAccess.get_sha256(path+".raw"),"png_sha256":FileAccess.get_sha256(path+".png"),"level":str(level.data.id),"player_position":[p.position.x,p.position.y],"on_floor":p.is_on_floor(),"health":p.health.current,"enemies":_enemy_state(),"physics_body_viewport_rect":[shown_body.position.x,shown_body.position.y,shown_body.size.x,shown_body.size.y],"canvas_transform":[canvas.x.x,canvas.x.y,canvas.y.x,canvas.y.y,canvas.origin.x,canvas.origin.y]})

func _air_pair(area: String, foot: Vector2i, target_row: int, earned: bool, safe_room: bool) -> void:
	var tag := area + ("-earned" if earned else "-locked")
	if not await _begin(area, foot, earned):
		await _end()
		return
	var p := level.player
	var hp := p.health.current
	var initial := _enemy_state()
	check(initial["count"] > 0 and initial["active"] > 0 and initial["bodies_in_space"] > 0, tag + " real enemies remain active in physics")
	foreign_input = false
	measuring = true
	var first_trace := trace.size()
	Input.action_press(&"jump")
	await _tick(20, tag)
	Input.action_release(&"jump")
	await _tick(2, tag)
	var before := p.velocity.y
	Input.action_press(&"jump")
	await _tick(2, tag)
	check(p._air_jump_used == earned and ((p.velocity.y < before) == earned), tag + " second press follows actual unlock")
	await _tick(12, tag)
	await _snapshot(tag + "-air")
	await _tick(12, tag)
	Input.action_release(&"jump")
	for i in 120:
		await _tick(1, tag)
		if p.is_on_floor() or p.is_dead(): break
	var min_y := INF
	for i in range(first_trace, trace.size()): min_y = minf(min_y, float(trace[i]["position"][1]))
	var expected_y := float(target_row + 1 if earned else foot.y + 1) * 16.0
	check(not p.is_dead() and p.is_on_floor() and absf(p.position.y - expected_y) <= 2.0, tag + " lands on high ledge or retry floor")
	if not earned: check(min_y > float(target_row + 1) * 16.0 + 2.0, tag + " cannot reach late ledge before unlock")
	if safe_room: check(p.health.current == hp, tag + " practice has no live-enemy damage")
	check(not foreign_input, tag + " no physical input interfered")
	await _snapshot(tag + "-landed")
	cases.append({"tag":tag,"start_foot_cell":[foot.x,foot.y],"target_foot_row":target_row,"arranged_progress":earned,"enemy_initial":initial,"enemy_final":_enemy_state(),"health_before":hp,"health_after":p.health.current,"minimum_foot_y":min_y,"final_foot_y":p.position.y,"safe_practice":safe_room,"foreign_input":foreign_input})
	await _end()

func _ordinary_step(area: String, foot: Vector2i, target: Vector2i) -> void:
	if not await _begin(area, foot, false):
		await _end()
		return
	var tag := area + "-ordinary-step"
	var p := level.player
	foreign_input = false
	measuring = true
	Input.action_press(&"move_right")
	Input.action_press(&"jump")
	for i in 150:
		await _tick(1, tag)
		if p.position.x >= (float(target.x)+0.5)*16.0: Input.action_release(&"move_right")
		if i > 4 and (p.is_on_floor() or p.is_dead()): break
	_release()
	check(not p.is_dead() and p.is_on_floor() and absf(p.position.y-float(target.y+1)*16.0)<=2.0 and absf(p.position.x-(float(target.x)+0.5)*16.0)<=24.0, tag + " actual ordinary jump climbs authored main-route step")
	check(not p._air_jump_used and not foreign_input, tag + " no earned ability or outside input")
	await _snapshot(tag)
	await _end()

func _hud_witness() -> Dictionary:
	var hud := level.hud
	var label: Label = hud._controls
	var card: PanelContainer = hud._controls_card
	return {"process_frame":Engine.get_process_frames(),"physics_frame":Engine.get_physics_frames(),"label_path":str(label.get_path()),"label_text":label.text,"label_visible":label.is_visible_in_tree(),"card_visible":card.is_visible_in_tree(),"card_alpha":card.modulate.a,"hold_clock":hud._controls_read_time,"owner_path":str(level.player.get_path()) if hud._hint_owner != null and hud._hint_owner.get_ref()==level.player else "","engaged_enemies":Music.engaged_enemies(),"toast_showing":hud.toast_banner.is_showing(),"paused":get_tree().paused,"cinematic":Story.is_cinematic_active()}

func _guide_capture() -> void:
	if not await _begin("vault",Vector2i(50,20),false):
		await _end()
		return
	var hp := level.player.health.current
	var before := _hud_witness()
	GameState.set_flag(&"ledger_disk_obtained",true,false)
	var published := _hud_witness()
	var samples: Array[Dictionary] = []
	var deadline := Time.get_ticks_msec()+8000
	var visible := false
	while Time.get_ticks_msec()<deadline:
		await _tick(1)
		var state := _hud_witness()
		samples.append(state)
		if state["label_visible"] and state["card_visible"] and state["card_alpha"]>=0.99 and str(state["label_text"]).contains("空中再躍已解鎖") and str(state["label_text"]).contains("跳躍"):
			visible = true
			break
	check(visible,"actual ability HUD label becomes visible after a ready-Level flag transition")
	await _snapshot("air-jump-guide")
	var after := _hud_witness()
	check(after["hold_clock"]>0.0 and after["hold_clock"]<published["hold_clock"],"actual visible guide consumes its own hold clock")
	check(not str(after["owner_path"]).is_empty() and level.player.health.current==hp,"guide remains owned by the live player in the safe practice room")
	guide={"before":before,"published":published,"samples":samples,"after":after,"health_before":hp,"health_after":level.player.health.current}
	await _end()

func _run() -> void:
	check(not out.is_empty() and quality in ["high","low"], "explicit output and existing quality tier")
	if out.is_empty():
		get_tree().quit(2)
		return
	check(DirAccess.make_dir_recursive_absolute(out) == OK, "output directory: " + out)
	if parse_only:
		await _finish()
		return
	check(DisplayServer.get_name() != "headless" and RenderingServer.get_current_rendering_method() == "forward_plus", "native Forward+ required")
	if failures > 0:
		await _finish()
		return
	previous_quality = Settings.get_light_quality()
	Settings.set_light_quality(LightQuality.Tier.HIGH if quality == "high" else LightQuality.Tier.LOW)
	get_viewport().use_hdr_2d = true
	add_child(LightKit.create_environment())
	for earned in [false,true]:
		await _air_pair("vault",Vector2i(46,20),12,earned,true)
		if failures > 0: break
	if failures == 0:
		for earned in [false,true]:
			await _air_pair("street",Vector2i(100,31),23,earned,false)
			if failures > 0: break
	if failures == 0:
		for row in [["street",Vector2i(47,47),Vector2i(51,43)],["warehouse",Vector2i(141,28),Vector2i(146,24)],["vault",Vector2i(13,44),Vector2i(17,40)],["rooftop",Vector2i(57,44),Vector2i(62,39)]]:
			await _ordinary_step(row[0],row[1],row[2])
			if failures > 0: break
	if failures == 0:
		for row in [["street",Vector2i(4,51)],["street",Vector2i(124,36)],["warehouse",Vector2i(77,48)],["warehouse",Vector2i(148,16)],["vault",Vector2i(43,28)],["vault",Vector2i(116,12)],["rooftop",Vector2i(48,49)],["rooftop",Vector2i(66,31)]]:
			if await _begin(row[0],row[1],true):
				await _tick(24)
				await _snapshot("view-"+row[0]+"-"+str(row[1].x)+"-"+str(row[1].y))
			await _end()
	if failures == 0: await _guide_capture()
	await _finish()

func _finish() -> void:
	_release()
	if is_instance_valid(level): await _end()
	if previous_quality >= 0: Settings.set_light_quality(previous_quality)
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	var result := {"checks":checks,"failures":failures,"fatal_io":fatal_io,"parse_only":parse_only,"quality":quality,"renderer":RenderingServer.get_current_rendering_method(),"hdr_2d":get_viewport().use_hdr_2d,"resolution":[1280,720],"captures":captures,"cases":cases,"trace":trace,"guide":guide,"scope":"Actual public Input/Player physics and live enemies. Initial positions/progress are arranged; setup cancels incidental presentation via existing API. Ordinary route segments and representative views, not a natural campaign/physical controller/performance proof."}
	var file := FileAccess.open(out.path_join("result.json"),FileAccess.WRITE)
	if file == null:
		push_error("[NE298] result open failed: " + out.path_join("result.json"))
		get_tree().quit(2)
		return
	file.store_string(JSON.stringify(result,"\t"))
	var error := file.get_error()
	file.close()
	print("NE298_CAPTURE ",checks," checks, ",failures," failures")
	get_tree().quit(0 if failures == 0 and not fatal_io and error == OK else 1)
