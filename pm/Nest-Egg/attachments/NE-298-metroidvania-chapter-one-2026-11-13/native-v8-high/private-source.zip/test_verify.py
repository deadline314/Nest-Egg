from pathlib import Path
import copy,hashlib,json,os,tempfile,unittest
from PIL import Image
from verify_capture_files import AIR,STEPS,PAGES,validate_ledger,verify

def fixture():
 result={'parse_only':False,'failures':0,'checks':120,'fatal_io':False,'renderer':'forward_plus','hdr_2d':True,'resolution':[1280,720],'cases':[],'trace':[],'captures':[]}
 for tag,(floor,target,earned,safe) in AIR.items():
  state={'count':2,'active':2,'bodies_in_space':2,'activation_culling_changed':False}
  result['cases'].append({'tag':tag,'arranged_progress':earned,'foreign_input':False,'final_foot_y':target if earned else floor,'minimum_foot_y':target-10 if earned else floor-70,'enemy_initial':state,'enemy_final':state,'health_before':3,'health_after':3})
  result['trace'] += [{'tag':tag,'position':[100,target-10 if earned else floor-70],'velocity':[0,0],'air_used':earned,'on_floor':False} for _ in range(24)]
 for tag,(x,y) in STEPS.items():result['trace'].append({'tag':tag,'position':[(x+.5)*16,(y+1)*16],'velocity':[0,0],'air_used':False,'on_floor':True})
 result['guide']={'before':{'label_text':'開啟操作說明','process_frame':10},'published':{'hold_clock':12},'after':{'label_visible':True,'card_visible':True,'card_alpha':1,'label_text':'空中再躍已解鎖，離地後再按一次跳躍','owner_path':'/root/Player','hold_clock':11.5,'process_frame':12},'health_before':6,'health_after':6,'samples':[{}]}
 for page in sorted(PAGES):result['captures'].append({'page':page,'size':[1280,720],'format':14,'raw_bytes':1280*720*6,'linear_raw':page+'.raw','encoded_png':page+'.png','physics_body_viewport_rect':[200,200,12,44]})
 return result

class Checks(unittest.TestCase):
 def test_ledger_positive(self):self.assertEqual(len(validate_ledger(fixture())),21)
 def test_missing_mismatched_and_false_scope_refused(self):
  for kind in ['missing','mismatched','parse','damage','no_enemies','no_impulse','guide_hidden','guide_clock']:
   r=fixture()
   if kind=='missing':r['captures'].pop()
   elif kind=='mismatched':r['captures'][0]['page']='other'
   elif kind=='parse':r['parse_only']=True
   elif kind=='damage':r['cases'][0]['health_after']=2
   elif kind=='no_enemies':r['cases'][0]['enemy_initial']={**r['cases'][0]['enemy_initial'],'active':0}
   elif kind=='no_impulse':
    for row in r['trace']:row['air_used']=False
   elif kind=='guide_hidden':r['guide']['after']['label_visible']=False
   else:r['guide']['after']['hold_clock']=12
   with self.subTest(kind=kind),self.assertRaises(AssertionError):validate_ledger(r)
 def test_files_positive_missing_truncated_and_mismatch(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp);raw=p/'original.raw';raw.write_bytes(bytes(1280*720*6));png=p/'original.png';Image.new('RGB',(1280,720)).save(png)
   rawsha=hashlib.sha256(raw.read_bytes()).hexdigest();pngsha=hashlib.sha256(png.read_bytes()).hexdigest();r=fixture()
   for c in r['captures']:
    os.link(raw,p/c['linear_raw']);os.link(png,p/c['encoded_png']);c.update(raw_sha256=rawsha,png_sha256=pngsha)
   report=p/'result.json';report.write_text(json.dumps(r));self.assertEqual(verify(p)['capture_files_verified'],21)
   c=r['captures'][0];target=p/c['linear_raw'];target.unlink()
   with self.assertRaises(AssertionError):verify(p)
   target.write_bytes(b'wrong');c['raw_sha256']=hashlib.sha256(b'wrong').hexdigest();report.write_text(json.dumps(r))
   with self.assertRaisesRegex(AssertionError,'truncated raw'):verify(p)
   target.unlink();os.link(raw,target);c['raw_sha256']=rawsha;c['raw_bytes']-=2;report.write_text(json.dumps(r))
   with self.assertRaises(AssertionError):verify(p)

if __name__=='__main__':unittest.main()