"""NE298 capture-file/ledger checks only; engine/source/queue receipt is separate."""
from pathlib import Path
import argparse,hashlib,json,math
from PIL import Image

AIR={'vault-locked':(21*16,13*16,False,True),'vault-earned':(21*16,13*16,True,True),'street-locked':(32*16,24*16,False,False),'street-earned':(32*16,24*16,True,False)}
STEPS={'street-ordinary-step':(51,43),'warehouse-ordinary-step':(146,24),'vault-ordinary-step':(17,40),'rooftop-ordinary-step':(62,39)}
VIEWS={'view-street-4-51','view-street-124-36','view-warehouse-77-48','view-warehouse-148-16','view-vault-43-28','view-vault-116-12','view-rooftop-48-49','view-rooftop-66-31'}
PAGES={n+s for n in AIR for s in ['-air','-landed']}|set(STEPS)|VIEWS|{'air-jump-guide'}

def validate_ledger(result):
 assert result['parse_only'] is False and result['failures']==0 and result['checks']>0 and result['fatal_io'] is False,'not a successful native ledger'
 assert result['renderer']=='forward_plus' and result['hdr_2d'] is True and result['resolution']==[1280,720]
 cases={c['tag']:c for c in result['cases']};assert len(result['cases'])==len(AIR) and set(cases)==set(AIR),'missing/mismatched air case'
 trace=result['trace'];assert trace,'missing actual frame ledger'
 for tag,(floor,target,earned,safe) in AIR.items():
  c=cases[tag];assert c['arranged_progress'] is earned and c['foreign_input'] is False
  assert abs(c['final_foot_y']-(target if earned else floor))<=2
  assert math.isfinite(c['minimum_foot_y'])
  for state in [c['enemy_initial'],c['enemy_final']]:assert state['count']>0 and state['activation_culling_changed'] is False
  assert c['enemy_initial']['active']>0 and c['enemy_initial']['bodies_in_space']>0
  if not earned:assert c['minimum_foot_y']>target+2
  else:assert c['minimum_foot_y']<target
  if safe:assert c['health_before']==c['health_after']
  rows=[r for r in trace if r['tag']==tag];assert len(rows)>=24 and all(math.isfinite(v) for r in rows for v in r['position']+r['velocity'])
  assert any(r['air_used'] for r in rows)==earned
 for tag,(x,y) in STEPS.items():
  rows=[r for r in trace if r['tag']==tag];assert rows and rows[-1]['on_floor']
  assert abs(rows[-1]['position'][1]-(y+1)*16)<=2 and abs(rows[-1]['position'][0]-(x+.5)*16)<=24
  assert not any(r['air_used'] for r in rows)
 guide=result['guide'];state=guide['after'];published=guide['published']
 assert '空中再躍' not in guide['before']['label_text']
 assert state['label_visible'] is True and state['card_visible'] is True and state['card_alpha']>=.99
 assert '空中再躍已解鎖' in state['label_text'] and '跳躍' in state['label_text'] and state['owner_path']
 assert 0<state['hold_clock']<published['hold_clock']<=12 and state['process_frame']>guide['before']['process_frame']
 assert guide['health_before']==guide['health_after'] and guide['samples']
 captures={c['page']:c for c in result['captures']};assert len(result['captures'])==len(PAGES) and set(captures)==PAGES,'missing/mismatched shot'
 return captures

def verify(folder):
 folder=Path(folder).resolve();result=json.loads((folder/'result.json').read_bytes());captures=validate_ledger(result)
 for page,c in captures.items():
  assert c['size']==[1280,720] and c['format'] in [14,15]
  channels=3 if c['format']==14 else 4
  assert c['raw_bytes']==1280*720*channels*2
  for key,ext in [('linear_raw','.raw'),('encoded_png','.png')]:
   assert c[key]==page+ext
   p=(folder/c[key]).resolve();assert p.parent==folder and p.is_file(),(page,'missing file')
   with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
   assert digest==c['raw_sha256' if ext=='.raw' else 'png_sha256'],(page,'SHA')
   if ext=='.raw':assert p.stat().st_size==c['raw_bytes'],(page,'truncated raw')
   else:
    with Image.open(p) as image:assert image.size==(1280,720);image.load()
  x,y,w,h=c['physics_body_viewport_rect'];assert all(math.isfinite(v) for v in [x,y,w,h]) and x>=0 and y>=0 and w>0 and h>0 and x+w<=1280 and y+h<=720
 return {'capture_files_verified':len(captures),'scope':'File and actual recorded ledger contract only. Separate engine/source/queue receipt and original verify_capture_precision pixel pass are required.'}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('folder',type=Path);print(json.dumps(verify(p.parse_args().folder),indent=2))