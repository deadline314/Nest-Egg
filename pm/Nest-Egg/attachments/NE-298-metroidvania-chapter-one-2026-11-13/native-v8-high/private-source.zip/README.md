# NE298 actual Input / representative native tool (CPU prepared, not parsed or run)

Original NE296 Input.action_press/release pattern, actual Player physics and live enemies. Initial floor cell and ledger_disk_obtained are arranged; this is not natural acquisition, full campaign or physical-controller acceptance. No enemy process/collision/health changes and no player invulnerability. Setup uses existing presentation cancellation once; no cancellation during measured input. Camera uses existing snap_to_target at initial arrangement.

Four actual ordinary main-route step clips; locked/earned vault practice and street reward at the same starts;8 representative views. Physics/frame/health/airjump ledgers retained. Practice must have no live-enemy damage; street combat remains active and any genuine input failure is kept. External key/button input while measuring is rejected.

Public existing Settings low/high; actual Forward+/HDR and1280x720. Raw lengths/SHA, PNG writes and physics-body viewport bounds are guarded; no full rendered-head alpha or exposure-threshold claim. These views are not whole-map coverage.

Prospective parser: original Godot --headless --path <D298> res://work/ne298-native-input-v1/capture.tscn -- --out=<own-output> --parse-only. Native: --resolution1280x720 --rendering-method forward_plus --rendering-driver vulkan same scene -- --out=<own-output> --quality=high (separate low). No engine launched here. Shared primary lock/4queues/new integrated source/context must precede runs. AudioRelease used on all normal finish paths.

Version2: correct rooftop start57,44→62,39; full original20 plus one actual visible HUD guide image. Guide samples store real label path/text/visible/alpha/hold clock/engagement/toast/pause and screenshot. Reader now requires21 exact pages and rejects event-only/hidden/nonadvancing-clock guide data. CPU3tests/11negative subcases only; parser/native pending.

Guide witness is at the real room entry50,20 on the same retry floor, outside the original encounter x22..46; the four measured jump cases still start46,20 unchanged. This chooses an actual safe-room position, never disables enemy AI/music/UI suppression. Published progress remains explicitly arranged.
