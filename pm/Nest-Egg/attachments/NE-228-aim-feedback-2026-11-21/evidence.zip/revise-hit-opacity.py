from pathlib import Path
from hashlib import sha256
import json

root = Path.cwd()
base = Path(__file__).resolve().parent
shared = base.parent / "ne218-baseline-20261117"
manifest_path = base / "source.json"
manifest = json.loads(manifest_path.read_bytes())
sha = lambda path: sha256(path.read_bytes()).hexdigest()
receipt = json.loads((base / "official-release/verification.json").read_bytes())
assert receipt["source_held"] is True
assert all(sha(shared / name) == digest for name, digest in manifest.items())
name = "ui/crosshair.gd"
code = root / name
before = "var mark_color := Color(LightKit.glow(Palette.WHITE, lerpf(1.0, 2.0, _flash_scale)), t)"
after = """# 白色在高光影下仍可能飽和，減閃光時也降低覆蓋強度。
		var mark_intensity := lerpf(1.0, 2.0, _flash_scale)
		var mark_alpha := t * lerpf(0.55, 1.0, _flash_scale)
		var mark_color := Color(LightKit.glow(Palette.WHITE, mark_intensity), mark_alpha)"""
text = code.read_text(encoding="utf-8")
assert text.count(before) == 1 and sha(code) == manifest[name]
previous = base / "source-before-hit-luminance.json"
assert not previous.exists()
previous.write_bytes(manifest_path.read_bytes())
code.write_text(text.replace(before, after), encoding="utf-8", newline="\n")
(shared / name).write_bytes(code.read_bytes())
manifest[name] = sha(code)
assert all(sha(shared / file) == digest for file, digest in manifest.items())
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")