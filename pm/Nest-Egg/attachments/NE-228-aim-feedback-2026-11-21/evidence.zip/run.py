from hashlib import sha256
from pathlib import Path
import json
import math
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
label = sys.argv[1]
out = base / label
if "--existing" in sys.argv:
    source=json.loads((out/"command.json").read_bytes())["source"]
    sha = lambda path: sha256(path.read_bytes()).hexdigest()
    from types import SimpleNamespace
    proc = SimpleNamespace(returncode=0)
else:
    out.mkdir()
    env = os.environ.copy()
    for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
        path = out / key
        path.mkdir()
        env[key] = str(path)
    paths = ["ui/crosshair.gd","ui/ammo_ring.gd","ui/settings_screen.gd","ui/hud.gd","autoload/settings.gd",
             "game/player/player.gd","data/levels/ch1_street.tres","game/player/loadout.gd","core/weapon_system.gd"]
    sha = lambda path: sha256(path.read_bytes()).hexdigest()
    source = {p:sha(game / p) for p in paths}
    argv = [sys.executable,"-B",str(game/"tools/comfyui/gpu_lock.py"),"--",
            "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(game),
            "--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy",
            "--fixed-fps","60","--resolution","1280x720","--quit-after","3300",str(base/"observe.tscn"),"--",f"--out={out}"]
    (out/"command.json").write_text(json.dumps({"argv":argv,"source":source},indent=2)+"\n",encoding="utf-8")
    with (out/"engine.log").open("wb") as log:
        proc = subprocess.run(argv,cwd=game,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=230)
raw=(out/"engine.log").read_text(encoding="utf-8",errors="replace")
print(raw[-8000:],flush=True)
report = json.loads((out/"result.json").read_bytes())
assert all(sha(game/p)==digest for p,digest in source.items())
assert proc.returncode==0 and not re.search(r"^SCRIPT ERROR:|^ERROR:",raw,re.M), (proc.returncode,report["failures"])
assert report["hdr"] and "9070 XT" in report["adapter"] and not report["failures"]

rows = {(r["mode"], r["label"]): r for r in report["rows"]}
assert len(rows) == 55 and len(list(out.glob("*.png"))) == 56
assert all(row["actual"] == row["ammo"] for row in rows.values())
for mode in ("normal", "motion", "flashes", "both", "toggle"):
    a, b = (rows[mode,f"dry-and-empty-{phase}"] for phase in "ab")
    assert 0 < b["empty"] < a["empty"] and a["bloom"] > 0
    assert rows[mode,"hit"]["hit"] > 0 and rows[mode,"weak"]["weak"] > 0
    assert rows[mode,"blocked"]["blocked"] > 0 and rows[mode,"kill"]["kill"] > 0
    assert rows[mode,"reload-b"]["progress"] > rows[mode,"reload-a"]["progress"] > 0
    assert rows[mode,"reloaded"]["actual"] == 12 and rows[mode,"reloaded"]["done"] > 0
    if label.startswith("stock") or mode not in ("both","motion"):
        assert a["center"] != a["aim"] and a["dry"] > 0
    else:
        assert a["center"] == a["aim"] and a["dry"] == 0
print(f"{len(rows)} rendered reticle and reload states accepted.", flush=True)

if label.startswith("stock"):
    assert report["hint"] == "選單直接顯示，關閉滑入與數字跳動；遊戲動作照常。"
else:
    assert report["hint"] == "關閉選單滑入、數字跳動與空槍時的準星晃動。"
