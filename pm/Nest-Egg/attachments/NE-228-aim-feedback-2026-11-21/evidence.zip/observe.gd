extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
var _out := ""
var _rows: Array[Dictionary] = []
var _failures: Array[String] = []


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://aim-feedback.cfg")
	Settings.set_brightness(0.5)
	Settings.set_hud_auto_hide(false)
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	for mode: String in ["normal", "motion", "flashes", "both", "toggle"]:
		await _observe(mode)
	var screen := SettingsScreen.new()
	add_child(screen)
	await _frames(3)
	screen._tabs.current_tab = 2
	await _frames(3)
	screen._reduce_ui_motion.grab_focus()
	await RenderingServer.frame_post_draw
	var hint := screen._reduce_ui_motion.tooltip_text
	var status := screen._status
	_check(status.text == hint and screen.get_viewport().gui_get_focus_owner() == screen._reduce_ui_motion,
		"display settings expose the exact hover explanation through keyboard focus")
	_check(status.get_theme_font("font").get_string_size(hint, HORIZONTAL_ALIGNMENT_LEFT, -1,
		status.get_theme_font_size("font_size")).x <= status.size.x, "the concise settings explanation fits the real row")
	_check(Capture.image(get_viewport()).save_png(_out.path_join("settings.png")) == OK, "settings evidence captured")
	screen.queue_free()
	await get_tree().process_frame
	var file := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"rows":_rows,"failures":_failures,"hint":hint,
		"adapter":RenderingServer.get_video_adapter_name(),"hdr":get_viewport().use_hdr_2d}, "  "))
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(not _failures.is_empty()))


func _observe(mode: String) -> void:
	seed(506228)
	Settings.set_reduce_ui_motion(mode in ["motion","both"])
	Settings.set_reduce_flashes(mode in ["flashes","both"])
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	for _frame in 120:
		if level.is_initialized():
			break
		await get_tree().process_frame
	var pile: CreditPickup
	for node in level._entities.get_children():
		if node is CreditPickup and pile == null and node._requires_flag == &"" and not node._elevated:
			pile = node
		elif node is Enemy:
			node.process_mode = Node.PROCESS_MODE_DISABLED
	if pile == null:
		_failures.append(mode + " missing authored position")
		level.queue_free()
		await get_tree().process_frame
		return
	for node in level.find_children("*","",true,false):
		if node is ChapterCard:
			node.queue_free()
	var player := level.player
	var reticle := level.hud.crosshair
	var ring := level.hud.ammo_ring
	player.global_position = pile.global_position + Vector2(-30,0)
	player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(player, true)
	level._lighting._lightning_gap = 1.0e9
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	camera.global_position = pile.global_position + Vector2(-42,-43)
	camera.reset_smoothing()
	camera.force_update_scroll()
	await _frames(24)
	await _record(mode, "steady", player, reticle, ring)
	var finite := player.loadout.equip(load("res://data/weapons/rifle.tres") as WeaponData)
	_check(finite > 0, mode + " equipped the authored finite weapon")
	player.loadout.set_ammo(finite, 0, 0)
	player._try_fire()
	_check(player.loadout.active_slot == 0 and player.aim_bloom > 0.0,
		mode + " actual empty trigger resolves to real primary and recoil")
	await _record(mode, "dry-and-empty-a", player, reticle, ring)
	await _frames(6)
	await _record(mode, "dry-and-empty-b", player, reticle, ring)
	if mode == "toggle":
		Settings.set_reduce_flashes(true)
		await _record(mode, "dry-flash-setting", player, reticle, ring)
		Settings.set_reduce_ui_motion(true)
		await _record(mode, "dry-motion-setting", player, reticle, ring)
		Settings.set_reduce_ui_motion(false)
		Settings.set_reduce_flashes(false)
		await _record(mode, "dry-restored", player, reticle, ring)
	await _frames(60)
	var impact := player.aim_point
	EventBus.hit_confirmed.emit(impact, false)
	await _record(mode, "hit", player, reticle, ring)
	await _frames(16)
	EventBus.hit_confirmed.emit(impact, false)
	EventBus.hit_marker.emit(&"weak")
	await _record(mode, "weak", player, reticle, ring)
	await _frames(16)
	EventBus.hit_marker.emit(&"blocked")
	await _record(mode, "blocked", player, reticle, ring)
	await _frames(16)
	EventBus.hit_confirmed.emit(impact, true)
	await _record(mode, "kill", player, reticle, ring)
	if mode == "toggle":
		Settings.set_reduce_ui_motion(true)
		await _record(mode, "kill-motion-setting", player, reticle, ring)
		Settings.set_reduce_ui_motion(false)
		await _record(mode, "kill-restored", player, reticle, ring)
	await _frames(24)
	player.loadout.set_ammo(0, 3, -1)
	_check(player.loadout.start_reload(),mode + " original reload should start")
	for frame in 50:
		if player.loadout.reload_progress() >= 0.25:
			break
		await get_tree().process_frame
	await _record(mode, "reload-a", player, reticle, ring)
	for frame in 50:
		if player.loadout.reload_progress() >= 0.65:
			break
		await get_tree().process_frame
	await _record(mode, "reload-b", player, reticle, ring)
	for frame in 90:
		await get_tree().process_frame
		if not player.loadout.is_reloading():
			break
	_check(player.loadout.mag_in(0) == 12,mode + " actual reload fills the pistol")
	await _record(mode, "reloaded", player, reticle, ring)
	level.queue_free()
	await get_tree().process_frame


func _record(mode: String, label: String, player: Player, reticle: Crosshair, ring: AmmoRing) -> void:
	await RenderingServer.frame_post_draw
	var picture := "%s-%s.png" % [mode,label]
	_check(Capture.image(get_viewport()).save_png(_out.path_join(picture))==OK, mode+" "+label+" captured")
	var center := reticle._draw_center()
	var aim := reticle._screen_point
	var ring_center := ring._point
	_rows.append({"mode":mode,"label":label,"file":picture,"actual":player.loadout.mag_in(player.loadout.active_slot),
		"ammo":ring.ammo,"reserve":ring.reserve,"bloom":player.aim_bloom,"draw_bloom":reticle._bloom,
		"aim":[aim.x,aim.y],"center":[center.x,center.y],"ring":[ring_center.x,ring_center.y],
		"gap":reticle._tick_gap(),"dry":reticle._dry_left,"hit":reticle._hit_left,"weak":reticle._weak_left,
		"blocked":reticle._blocked_left,"kill":reticle._kill_left,"done":ring._done_left,"empty":ring._empty_left,
		"alpha":ring.presence.alpha,"progress":ring._reload_progress,"time":ring._time,
		"motion":Settings.get_reduce_ui_motion(),"flashes":Settings.get_reduce_flashes()})


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _check(ok: bool, message: String) -> void:
	if not ok:
		_failures.append(message)
