extends "res://tests/smoke_test.gd"

const Capture := preload("res://tools/viewport_capture.gd")
const STREET := preload("res://data/levels/ch1_street.tres")
const TEXT := {
	"zh": ["電磁脈衝", "未解鎖", "耗電", "冷卻", "持有", "信用點不足", "頭目只消除彈幕", "已解鎖", "裝備中", "超頻", "已裝備"],
	"ja": ["EMP", "未解放", "消費電力", "クールダウン", "残高", "クレジット不足", "ボスは弾だけ消去", "解放した", "装備中", "オーバークロック", "装備した"],
	"en": ["EMP Pulse", "Locked", "Charge cost", "Cooldown", "Balance", "Not enough credits", "boss projectiles only", "Unlocked", "Equipped", "Overclock", "Equipped"],
}


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://cyberware_locale.cfg")
	Settings.set_reduce_ui_motion(true)
	Settings.set_ui_text_scale(1.2)
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	for scene in Story.scene_ids():
		Story._seen[StringName(scene)] = true
	for language: String in TEXT.keys():
		Story.set_language(language)
		await _run_language(language, TEXT[language])
	Story.set_language("zh")
	await _finish()


func _run_language(language: String, words: Array) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(STREET)
	add_child(level)
	await _frames(8)
	var bag := level._inventory
	var index := bag.page_index(CyberPage)
	var page := bag._pages[index] as CyberPage
	bag.select_tab(index)
	bag.open()
	await _frames(4)
	var emp := Progression.find_ability(&"emp_pulse")
	var boost := Progression.find_ability(&"overclock")
	var entry := page._entries[0]
	_check(bag.is_open() and page.is_visible_in_tree(), language + " opens the real first-street cyberware page")
	_check(entry.title == words[0] and page._detail._title.text == words[0], language + " real EMP name")
	_check(entry.subtitle.contains(words[1]) and entry.subtitle.contains(str(emp.unlock_cost)), language + " locked and price")
	_check(entry.detail_stats[0].contains(words[2]) and entry.detail_stats[0].contains(str(int(emp.charge_cost))), language + " power cost")
	_check(entry.detail_stats[1].contains(words[3]) and entry.detail_stats[1].contains(str(int(emp.cooldown))), language + " cooldown")
	_check(entry.detail_stats[2].contains(words[4]) and entry.detail_stats[2].contains("¥0"), language + " available credits")
	_check(page.current_hint().contains(words[5]) and page.current_hint().contains(str(emp.unlock_cost)), language + " locked focus explains precise shortage")
	_check(page._detail._body.text.contains(words[6]), language + " bosses retain the correct EMP exception")
	_check(page._detail._action.disabled and page._detail._action.tooltip_text == page.current_hint(), language + " disabled action shares the warning")
	await _action(&"ui_accept")
	_check(not Progression.is_ability_unlocked(emp.id) and Progression.credits == 0 and bag._hint_label.text.contains(words[5]), language + " keyboard confirm preserves balance and shows warning")
	bag.close()
	Progression.add_credits(650)
	bag.open()
	await _frames(4)
	_check(page._detail._action.tooltip_text.contains(str(emp.unlock_cost)), language + " affordable action explains price")
	await _action(&"ui_accept")
	_check(Progression.equipped_ability() == emp and Progression.credits == 650 - emp.unlock_cost, language + " first purchase charges once and equips")
	_check(page._entries[0].badge == words[8] and bag._hint_label.text.contains(words[7]), language + " badge and purchase confirmation")
	_check(bag._frame.get_global_rect().grow(1.0).encloses(page._detail._action.get_global_rect()), language + " 120 percent action stays in the panel")
	var caption := page._detail._action
	var caption_width := caption.get_theme_font("font").get_string_size(caption.text, HORIZONTAL_ALIGNMENT_LEFT, -1, caption.get_theme_font_size("font_size")).x
	_check(caption_width < caption.size.x, language + " 120 percent button fits the translation")
	await _action(&"ui_down")
	_check(page._detail._title.text == words[9], language + " keyboard focus reaches Overclock")
	await _action(&"ui_accept")
	_check(Progression.is_ability_unlocked(boost.id) and Progression.equipped_ability() == emp and Progression.credits == 650 - emp.unlock_cost - boost.unlock_cost, language + " second purchase does not replace the first")
	await _action(&"ui_accept")
	_check(Progression.equipped_ability() == boost and bag._hint_label.text.contains(words[10]), language + " selected ability equips with a clear confirmation")
	if language == "en" and OS.get_cmdline_user_args().size() == 1:
		var destination := OS.get_cmdline_user_args()[0]
		if destination.is_absolute_path():
			await RenderingServer.frame_post_draw
			_check(Capture.image(get_viewport()).save_png(destination) == OK, "native cyberware capture")
	bag.close()
	level.queue_free()
	await _frames(8)


func _action(id: StringName) -> void:
	var event := InputEventAction.new()
	event.action = id
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(2)
	event = InputEventAction.new()
	event.action = id
	Input.parse_input_event(event)
	await _frames(2)
