from pathlib import Path
from hashlib import sha256
import json

root = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: sha256(path.read_bytes()).hexdigest()

live = {}
native = "main-vault-left", "main-vault-right"
for name in native:
    data=read(root/name/"report.json")
    assert data["failure_count"] == 0 and data["level"] == "ch1_vault"
    assert data["max_health"] == 28 and data["original_armor"] == 4 and data["credit_value"] == 90
    assert [data["frames"][p]["state"] for p in ("telegraph","lunge","recovery")] == ["windup","leap","recover"]
    assert data["frames"]["first_hit"]["flash"] > 1 and data["frames"]["credits"]["flash"] == 1
    assert [data["frames"][f"armor_remaining_{i}"]["health"] for i in (3,2,1,0)] == [21,14,7,0]
    assert data["frames"]["debris_expired"]["live_debris"] == 0
    assert all(shot["source"] == "player_rifle" for shot in data["shots"])
    assert data["shots"][-1]["health"] == 0
    live[name] = {"hits":len(data["shots"]), "frames":len(data["frames"]),
                  "largest_live_debris_count":max(x["live_debris"] for x in data["shots"])}

damaged_save=read(root/"stock-damaged-save/report.json")
assert [damaged_save[k] for k in ("health","armor","credit")] == [14,2,368]
observations={}
for baseline, candidate, health, armor in (
    ("stock-legacy-cold","candidate-legacy-cold-headless-v2",15,3),
    ("stock-damaged-cold","candidate-damaged-cold-headless-v2",14,2),
    ("stock-damaged-cold-native-clear","candidate-damaged-cold-native-clear",14,2),
):
    x,y=[read(root/name/"report.json") for name in (baseline,candidate)]
    assert x["health"] == y["health"] == health and x["credit"] == y["credit"]
    assert x["armor"] == 4 and y["armor"] == armor and x["debris"] == y["debris"] == 0
    assert x["maximum"] == y["maximum"] == 28
    assert x["failure_count"] == y["failure_count"] == 0
    hashes=[read(root/name/"command.json")["seed_sha256"] for name in (baseline,candidate)]
    assert len(set(hashes)) == 1
    assert y["frames"]["cold_resume"]["armor"] == armor and y["frames"]["cold_resume"]["flash"] == 1.0
    observations[candidate] = {"input_sha256":hashes[0],"health":health,"credits":x["credit"],"old_armor":x["armor"],
                               "updated_armor":y["armor"],"replayed_debris":y["debris"]}

assert "Input.warp_mouse" not in (root/"observe_retry.gd").read_text(encoding="utf8")
result={"live_inspector_encounters":live,"actual_disk_save_restore_comparisons":observations}
(root/"paired-results.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
print(json.dumps(result),flush=True)
