from hashlib import sha256
from pathlib import Path
import json
import os
import re
from shutil import copy2
import subprocess
import sys

base=Path(__file__).resolve().parent
project=base.parent/"ne218-baseline-20261117"
prior=base.parent/"evidence-20261121-ne71-crouched-muzzle"
case=base/sys.argv[1]
lens=sys.argv[2]
approach=sys.argv[3]
case.mkdir()
seed=Path(sys.argv[4]).resolve()
slot=case/"slot.json"
copy2(seed,slot)
reference=base if case.name.startswith("candidate") else prior
source=json.loads((reference/"source.json").read_bytes())
paths=("data/levels/ch1_vault.tres","data/levels/ch1_vault_map.json","data/enemies/ch1_inspector.tres",
       "game/enemies/slasher.gd","game/enemies/enemy.gd","game/rig/character_rig.gd","game/rig/rig_debris.gd",
       "game/player/player_visual.gd","game/rig/humanoid_animator.gd","art/characters/enforcer/character.json",
       "tools/scenarios/scenario_base.gd","data/weapons/rifle.tres")
digest=lambda p: sha256(p.read_bytes()).hexdigest()
tracked={item:source[item] for item in paths}
assert all(digest(project/path)==expect for path,expect in tracked.items())
env=os.environ.copy()
for key in ("APPDATA","LOCALAPPDATA","TEMP","TMP","TMPDIR","XDG_CONFIG_HOME","XDG_DATA_HOME"):
    profile=case/key
    profile.mkdir()
    env[key]=str(profile)
headless = "--headless" in sys.argv[6:]
godot=["C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(project)]
if headless:
    command=godot+["--headless"]
else:
    command=[sys.executable,"-B",str(project/"tools/comfyui/gpu_lock.py"),"--"]+godot
    command+=["--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy","--resolution","1280x720"]
command += ["--fixed-fps","60","--quit-after","4200",str(base/"observe_retry.tscn"),"--",f"--out={case}",
            f"--lens={lens}",f"--approach={approach}",f"--slot={slot}",sys.argv[5]]
(case/"command.json").write_text(json.dumps({"argv":command,"source":tracked,"seed_sha256":digest(seed),
    "worktree_head_at_capture_start":subprocess.check_output(["git","rev-parse","HEAD"],cwd=project,text=True).strip()},indent=2)+"\n")
with (case/"engine.log").open("wb") as f:
    p=subprocess.run(command,cwd=project,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=295)
log=(case/"engine.log").read_text(encoding="utf-8",errors="replace")
print(log[-3500:],flush=True)
assert p.returncode==0 and not re.search(r"^(?:SCRIPT )?ERROR:|^FAIL ",log,re.M)
data=json.loads((case/"report.json").read_bytes())
assert data["failure_count"]==0 and len(data["frames"])
assert all(digest(project/path)==expect for path,expect in tracked.items())
print("health",data.get("health"),"armor",data.get("armor"),"real_hits",len(data.get("shots",[])),"captures",len(data["frames"]),flush=True)
