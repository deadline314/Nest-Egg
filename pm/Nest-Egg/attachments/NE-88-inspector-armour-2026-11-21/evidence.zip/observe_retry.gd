extends ScenarioBase

var inspector: Enemy
var shots: Array[Dictionary] = []
var snapshots: Dictionary = {}
var lens := 0.0
var approach := -1
var slot_path := ""
var app: Node
var target_health := 0
var cold := false


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
		elif arg.begins_with("--lens="):
			lens = float(arg.trim_prefix("--lens="))
		elif arg.begins_with("--approach="):
			approach = int(arg.trim_prefix("--approach="))
		elif arg.begins_with("--slot="):
			slot_path = arg.trim_prefix("--slot=")
		elif arg.begins_with("--stop-health="):
			target_health = int(arg.trim_prefix("--stop-health="))
		elif arg == "--cold":
			cold = true
	if not out_dir.is_absolute_path() or not slot_path.is_absolute_path():
		get_tree().quit(2)
		return
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	_run.call_deferred()


func _run() -> void:
	app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	app.set("_run_store", RunSaveStore.new(slot_path))
	add_child(app)
	for frame in 300:
		if app.get("_screen") is MainMenu and not bool(app.call("_route_pending")):
			break
		await get_tree().process_frame
	var menu := app.get("_screen") as MainMenu
	if menu == null:
		get_tree().quit(2)
		return
	await settle(8)
	menu._continue_button.pressed.emit()
	for frame in 300:
		var current := app.get("_screen") as Level
		if current != null and current.is_initialized() and current.data.id == &"ch1_vault" and not bool(app.call("_route_pending")):
			level = current
			break
		await get_tree().process_frame
	if level == null or level.player == null:
		get_tree().quit(2)
		return
	player = level.player
	AimInput.set_virtual_gamepad(player, true)
	for node in level._entities.get_children():
		if node is Enemy:
			if node.data.id == &"ch1_inspector":
				inspector = node
			else:
				node.set_physics_process(false)
				node.hurtbox.enabled = false
				for part: Hurtbox in node.hurtbox.parts:
					part.enabled = false
				if node.contact != null:
					node.contact.active = false
	if not _check(inspector != null and inspector.rig != null and inspector.rig.skin_id == "enforcer",
			"original vault Inspector with dedicated rig"):
		get_tree().quit(3)
		return
	var initial_kills := GameState.kills
	var initial_position := inspector.global_position
	var maximum := inspector.health.current
	var armor_total := inspector.rig._armor_visible
	if cold:
		if DisplayServer.get_name() != "headless":
			player.health.grant_invulnerability(1.0)
			await settle(4)
			_place_player(initial_position + Vector2(approach * 78.0, 0.0))
			for frame in 90:
				if not Transition.is_active():
					break
				await get_tree().process_frame
			_check(not Transition.is_active(), "the original game transition has fully cleared before capture")
			await settle(12)
		await _capture_state("cold_resume")
		_report({"scope":"original live Main Continue", "frames":snapshots, "failure_count":failures,
			"health":inspector.health.current, "maximum":inspector.health.max_health,
			"armor":inspector.rig._armor_visible,"debris":RigDebris._active, "credit":Progression.credits})
		app.call("_quit", int(failures > 0))
		return
	_check(maximum == inspector.data.max_health and armor_total > 0, "full ordinary Inspector health and visible armor")
	player.health.grant_invulnerability(65.0)
	await settle(4)
	_place_player(initial_position + Vector2(approach * 78.0, 0.0))
	_check(absf(player.global_position.y - initial_position.y) < 5.0, "actual initial approach has a registered platform")
	await settle(3)
	await _capture_state("full_armor")
	await _wait_state(&"windup", 105)
	await settle(18)
	await _capture_state("telegraph")
	_check(inspector.fsm.is_in(&"windup") and inspector.is_telegraphing(), "sustained live attack preview")
	await _wait_state(&"leap", 70)
	await settle(3)
	await _capture_state("lunge")
	await _wait_state(&"recover", 120)
	await _capture_state("recovery")
	var weapon := player.loadout.equip(preload("res://data/weapons/rifle.tres"))
	_check(weapon >= 0 and player.loadout.active_slot == weapon, "real inventory equips the standard K-7")
	inspector.health.damaged.connect(_record_damage)
	var last_armor := armor_total
	var first_flash := false
	for frame in 42:
		if inspector.is_dying():
			break
		var spot := inspector.global_position
		var separation := absf(spot.x - player.global_position.x)
		if separation < 44.0 or separation > 170.0 or player.global_position.y > spot.y + 14.0:
			_place_player(spot + Vector2(78.0 if spot.x < initial_position.x else -78.0, 0.0))
		_center()
		var hits := shots.size()
		_aim_at(inspector.hurtbox.center())
		await settle(2)
		Input.action_press(&"shoot")
		await settle(2)
		Input.action_release(&"shoot")
		for i in 20:
			if shots.size() > hits or inspector.is_dying():
				break
			await get_tree().physics_frame
		if shots.size() > hits and not first_flash:
			first_flash = true
			await _capture_state("first_hit")
		if inspector.rig._armor_visible < last_armor:
			last_armor = inspector.rig._armor_visible
			await _capture_state("armor_remaining_%d" % last_armor)
		if target_health > 0 and inspector.health.current <= target_health:
			_check(inspector.health.current == target_health and not inspector.is_dying(), "quit while the original Inspector is still wounded")
			await _capture_state("before_quit")
			_report({"scope":"original live Main close after real K-7 damage", "frames":snapshots, "failure_count":failures,
				"health":inspector.health.current, "maximum":inspector.health.max_health,"armor":inspector.rig._armor_visible,
				"debris":RigDebris._active, "credit":Progression.credits, "shots":shots})
			app.call("_quit", int(failures > 0))
			return
		await settle(6)
	_check(inspector.is_dying() and shots.size() >= 10, "the Inspector is defeated by real K-7 projectiles")
	_check(last_armor == 0, "armor count reaches zero on the real damage path")
	var eligible_credits := 0
	for node in level._entities.get_children():
		if node is CreditPickup and node.cell == Vector2i(-1, -1):
			eligible_credits += node.value
	_check(eligible_credits == inspector.data.credit_value and GameState.kills == initial_kills + 1, "one original Inspector kill yields its full credit pickup")
	_check(shots.all(func(row: Dictionary) -> bool: return row["source"] == "player_rifle"), "all damage came from the player firearm")
	await _capture_state("credits")
	for tick in 150:
		if RigDebris._active == 0:
			break
		await get_tree().physics_frame
	await _capture_state("debris_expired")
	_check(RigDebris._active == 0, "all removed armor leaves the live debris pool")
	var result := {"failure_count": failures, "level": String(level.data.id), "difficulty": "ordinary", "scope": "Main Continue from genuine earlier Vault save. Authored enemy with actual AI and damage, arranged player positions and temporary invulnerability.", "initial": _vector(initial_position), "max_health": maximum, "original_armor": armor_total, "credit_value": eligible_credits, "shots": shots, "frames":snapshots}
	var file := FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(result,"  ")+"\n")
	file.close()
	app.call("_quit", int(failures > 0))


func _report(value: Dictionary) -> void:
	var file := FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE)
	if file == null:
		failures += 1
		return
	file.store_string(JSON.stringify(value, "  ")+"\n")
	file.close()


func _place_player(estimate: Vector2) -> void:
	var query := PhysicsRayQueryParameters2D.create(estimate - Vector2(0, 10), estimate + Vector2(0, 44), Layers.SOLID)
	var support := player.get_world_2d().direct_space_state.intersect_ray(query)
	if not support.is_empty():
		player.global_position = support["position"] - Vector2(0, 0.2)
		player.velocity = Vector2.ZERO
	_center()


func _center() -> void:
	var camera := level.camera
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.zoom = Vector2.ONE * (lens if lens > 0.0 else LevelCamera.base_zoom())
	camera.offset = Vector2.ZERO
	camera.global_position = (inspector.global_position + player.global_position) * 0.5 - Vector2(0, 26)
	camera.reset_smoothing()
	camera.force_update_scroll()


func _wait_state(wanted: StringName, limit: int) -> void:
	for i in limit:
		if inspector.fsm.is_in(wanted):
			return
		await get_tree().physics_frame
	_check(false, "natural Inspector phase " + String(wanted))


func _aim_at(target: Vector2) -> void:
	AimInput.restore_direction(target - player.aim_origin())


func _record_damage(info: DamageInfo) -> void:
	shots.append({"source":String(info.source_id), "facing":inspector.facing,
		"health":inspector.health.current,"armor":inspector.rig._armor_visible,"live_debris":RigDebris._active,
		"state":String(inspector.fsm.current),"physics":Engine.get_physics_frames()})


func _capture_state(label: String) -> void:
	var draw := DisplayServer.get_name() != "headless"
	if draw:
		await RenderingServer.frame_post_draw
	var stats := {"live_debris":RigDebris._active,"player":_vector(player.global_position),"zoom":_vector(level.camera.zoom)}
	if is_instance_valid(inspector):
		stats.merge({"state":String(inspector.fsm.current),"actor":_vector(inspector.global_position),
			"health":inspector.health.current,"rig_fill":inspector.rig._fill,
			"armor":inspector.rig._armor_visible,"flash":inspector.rig._skeleton.modulate.r,
			"dying":inspector.is_dying()})
	snapshots[label] = stats
	if draw:
		capture(label)


func _vector(value: Vector2) -> Array:
	return [value.x,value.y]


func _check(value: bool, label: String) -> bool:
	print("PASS " + label if value else "FAIL " + label)
	if not value:
		failures += 1
	return value
