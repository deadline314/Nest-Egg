from pathlib import Path
import subprocess,json,hashlib
out=Path('work/ne246-combat');source=Path('tools/quest_resume_probe.gd');final=source.read_bytes();rows=[]
try:
 for name in ['negative-v4','preflight-v4']:
  source.write_bytes((out/'quest_resume_probe-before.gd').read_bytes() if name.startswith('negative') else final)
  command=['python',str(out/'headless.py'),name]
  with (out/(name+'-wrapper.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=420)
  rows.append({'name':name,'command':command,'exit_code':r.returncode,'observer_sha256':hashlib.sha256(source.read_bytes()).hexdigest()});(out/'observer-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
  assert r.returncode==(1 if name.startswith('negative') else 0)
finally:
 source.write_bytes(final);assert source.read_bytes()==final
