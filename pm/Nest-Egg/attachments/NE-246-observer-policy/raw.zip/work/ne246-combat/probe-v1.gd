extends "res://work/ne246-combat/combat_base.gd"

var readings: Array[Dictionary] = []
var confirmations: Array[Dictionary] = []
var pause_checked := false

func _world_snapshot() -> Dictionary:
	var enemies: Array = []
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		if enemy is Enemy and _level().is_ancestor_of(enemy):
			enemies.append({"instance": enemy.get_instance_id(), "data": String(enemy.data.id), "position": [enemy.global_position.x, enemy.global_position.y], "hp": enemy.health.current})
	var bullets: Array = []
	for node in ProjectilePool.container().get_children():
		if node is Projectile and node.visible:
			bullets.append({"instance": node.get_instance_id(), "position": [node.global_position.x, node.global_position.y]})
	var player := _level().player
	return {"player_instance": player.get_instance_id(), "position": [player.global_position.x, player.global_position.y], "hp": player.health.current, "enemies": enemies, "bullets": bullets, "clock": GameState.run_time, "hits": combat_events.size()}

func _source_ids() -> Array[String]:
	var result: Array[String] = []
	for entry in Story._layer._radio_queue:
		if not bool(entry.get("freeze", false)):
			continue
		var id := str(entry["id"])
		if not result.has(id):
			result.append(id)
	return result

func _save_report() -> void:
	super._save_report()
	var path := out.path_join("result.json")
	var report: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
	report["actual_readings"] = readings
	report["public_confirmations"] = confirmations
	report["pause_checked"] = pause_checked
	report["scope"] = "same real combat route as NE-223, actual authored radio sources, no direct Story.play or queue injection; arranged old-save prerequisites/positions and nonlethal floor1; public action input, not human chapter or physical controller"
	FileAccess.open(path, FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))

func _wait_full_line() -> bool:
	return await _until(func() -> bool: return not Story._layer.is_radio_frozen() or (Story._layer._radio_root.visible and Story._layer._radio_wait <= 0.0 and Story._layer._radio_text.visible_ratio >= 1.0), 20.0)

func _read_interrupt() -> bool:
	var layer := Story._layer
	if not layer.is_radio_frozen():
		return false
	_release()
	_check(await _wait_full_line(), "authored important radio really finishes typing before confirmation")
	var before := _world_snapshot()
	var ids := _source_ids()
	await get_tree().create_timer(0.35, true, false, true).timeout
	var after := _world_snapshot()
	_check(get_tree().paused and layer.is_radio_frozen() and before == after, "actual important reading keeps the same world identities, health, positions and clock")
	readings.append({"sources": ids, "before": before, "after": after, "source_queue": layer._radio_queue.duplicate(true), "text": layer._radio_text.text})
	await _shot("actual-radio-%02d" % readings.size())
	if not pause_checked:
		await _press(&"pause")
		_check(_level()._pause_menu._root.visible, "public pause opens during actual important reading")
		await get_tree().create_timer(0.2, true, false, true).timeout
		_check(before == _world_snapshot(), "public pause keeps the same real combat world frozen")
		await _shot("actual-radio-pause")
		await _press(&"ui_cancel")
		_check(not _level()._pause_menu._root.visible and layer.is_radio_frozen() and get_tree().paused, "public back leaves actual reading frozen until its final confirmation")
		pause_checked = true
	for i in 80:
		if not layer.is_radio_frozen():
			break
		_check(await _wait_full_line(), "the next actual line becomes fully readable")
		if not layer.is_radio_frozen():
			break
		var count := layer._radio_queue.size()
		var entry: Dictionary = layer._radio_queue.front().duplicate(true)
		await _press(&"ui_accept")
		var remaining := layer._radio_queue.size()
		_check(remaining == count - 1, "one public confirmation consumes exactly one fully displayed authored line")
		confirmations.append({"source": str(entry["id"]), "text": entry["line"]["text"], "last": entry["last"], "before_count": count, "after_count": remaining})
	_check(not layer.is_radio_frozen(), "actual authored queue finishes within the confirmation budget")
	_save_report()
	return true

func _write() -> void:
	Story.auto_skip = false
	await super._write()
	_check(not readings.is_empty() and pause_checked, "real combat route includes measured important reading and public pause")
	_check(readings.any(func(r: Dictionary) -> bool: return not r["before"]["bullets"].is_empty()), "at least one actual authored reading freezes a real in-flight projectile")
	_check(readings.any(func(r: Dictionary) -> bool: return r["before"]["enemies"].any(func(e: Dictionary) -> bool: return e["hp"] > 0)), "actual reading freezes living authored enemies")
	_check(readings.any(func(r: Dictionary) -> bool: return r["sources"].size() >= 2), "real source triggers queue back-to-back important scenes without injection")
	_save_report()
