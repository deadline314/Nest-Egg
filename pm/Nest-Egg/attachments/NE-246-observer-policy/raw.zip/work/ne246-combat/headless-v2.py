from pathlib import Path
import subprocess,os,json,time,hashlib
root=Path.cwd();out=root/'work/ne246-combat';name='preflight-v2';env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',XDG_DATA_HOME=str(out/(name+'-profile')))
command=['/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64','--headless','--path',str(root),'--fixed-fps','60','res://work/ne246-combat/probe.tscn','--','--mode=write','--out='+str(out/name),'--save-dir='+str(out/(name+'-save'))]
(out/name).mkdir(exist_ok=True);start=time.monotonic()
with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=400)
(out/(name+'-receipt.json')).write_text(json.dumps({'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start,'base':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'probe_sha256':hashlib.sha256((out/'probe.gd').read_bytes()).hexdigest()},indent=2)+'\n');print(r.returncode,flush=True);raise SystemExit(r.returncode)
