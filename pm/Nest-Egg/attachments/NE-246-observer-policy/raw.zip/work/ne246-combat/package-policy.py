from pathlib import Path
import subprocess,json,hashlib,zipfile
root=Path.cwd();work=root/'work/ne246-combat';out=root/'pm/Nest-Egg/attachments/NE-246-observer-policy';out.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();base='59c2642e48678da7461e2c903289d98cd9f0a644'
assert (work/'quest_resume_probe-before.gd').read_bytes()==subprocess.check_output(['git','show',base+':tools/quest_resume_probe.gd'])
reports={}
for name in ['negative-v4','preflight-v4']:
 d=json.loads((work/name/'result.json').read_text());assert d['completed'];reports[name]=d
fixed=reports['preflight-v4'];old=reports['negative-v4'];assert fixed['failures']==0 and old['failures']>0
assert all(r['main_process_mode']==1 and not r['main_can_process_while_paused'] and r['tree_paused'] and r['before']==r['after'] for r in fixed['actual_readings'])
assert all(r['main_process_mode']==0 and r['main_can_process_while_paused'] and r['tree_paused'] and r['before']!=r['after'] for r in old['actual_readings'])
assert any(r['before']['bullets'] for r in fixed['actual_readings']) and any(len(r['sources'])>1 for r in fixed['actual_readings'])
assert not subprocess.check_output(['git','diff','--name-only',base,'--','game','ui','core','autoload','tests','tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh']).strip()
files={}
for p in work.rglob('*'):
 if p.is_file() and p.name!='policy-package-receipt.json' and not any('profile' in x or x=='__pycache__' for x in p.relative_to(work).parts):files['work/ne246-combat/'+str(p.relative_to(work))]=p.read_bytes()
for p in ['tools/quest_resume_probe.gd','game/main.gd','scenes/main.tscn','ui/dialogue_layer.gd','data/story/ch1_kasa.json','game/level/level.gd','tools/viewport_capture.gd']:
 files['source/final/'+p]=(root/p).read_bytes()
files['source/before/tools/quest_resume_probe.gd']=(work/'quest_resume_probe-before.gd').read_bytes();files['work/.gdignore']=b''
for p in (root/'pm/Nest-Egg/attachments/NE-278-references').iterdir():
 if p.is_file():files['references/'+p.name]=p.read_bytes()
validation={'base':base,'old_failures':old['failures'],'fixed_failures':fixed['failures'],'old_checks':sum(l.startswith(('PASS ','FAIL ')) for l in (work/'negative-v4.log').read_text().splitlines()),'fixed_checks':sum(l.startswith(('PASS ','FAIL ')) for l in (work/'preflight-v4.log').read_text().splitlines()),'readings':len(fixed['actual_readings']),'old_runtime_policy':'INHERIT0, can_process true while tree paused','fixed_runtime_policy':'PAUSABLE1, can_process false while tree paused','production_main_scene_and_gameplay_unchanged':True,'native_verified':False,'old_selector_groups':0,'original_test_harness_unchanged':True,'scope':'headless actual combat route, authored radio triggers, public pause and confirmations, actual bullets and living enemies; declared position/prerequisite/survival arrangements, not native or human/hardware acceptance','history':'v1 old observer five freeze failures; v2 fixed observer zero; v3 same world freeze held but no live projectile, correctly rejected; v4 public firing across authored threshold makes live-flight case reproducible; old/fixed exact same v4 probe'}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n');manifest={'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for e in manifest['files']:assert sha(z.read(e['path']))==e['sha256']
manifest.update(archive_bytes=(out/'raw.zip').stat().st_size,archive_sha256=sha((out/'raw.zip').read_bytes()));(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256'],'validation':validation},indent=2))
