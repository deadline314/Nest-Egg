from pathlib import Path
import subprocess,os,json,sys,re,hashlib
from concurrent.futures import ThreadPoolExecutor
root=Path.cwd();label=sys.argv[1];out=root/'work/shield-frame-sample'/label;out.mkdir();(out/'.gitignore').write_text('*\n');(out/'.gdignore').touch()
def run(pair):
 fps,budget,phase=pair;name=f'{fps}-{budget}-{phase}';case=out/name;case.mkdir();env=os.environ.copy();profile=str(case/'profile');env.update(XDG_DATA_HOME=profile,APPDATA=profile,LOCALAPPDATA=profile)
 command=[env['GODOT'],'--headless','--verbose','--audio-driver','Dummy','--path',str(root),'res://work/shield-frame-sample/probe.tscn','--','--out='+str(case/'result'),f'--fixture-fps={fps}',f'--fixture-budget={budget}',f'--fixture-phase={phase}']
 with (case/'raw.log').open('w') as log:r=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 raw=(case/'raw.log').read_text(errors='replace');result=json.loads((case/'result/result.json').read_text()) if (case/'result/result.json').exists() else {};bad=[l for l in raw.splitlines() if re.search(r'^FAIL:|^ERROR:|SCRIPT ERROR|leaked at exit|resources still in use|Leaked instance:',l)];return {'fps':fps,'physics_budget':budget,'phase':phase,'exit':r.returncode,'diagnostics':bad,'result':result,'command':command}
pairs=[(5,8,i) for i in range(8)] if label.endswith('phases') else [(0,8,0),(5,1,0),(10,1,0),(20,8,0)]
rows=list(ThreadPoolExecutor(max_workers=4).map(run,pairs));
with Path(os.environ['GODOT']).resolve().open('rb') as stream: engine_sha=hashlib.file_digest(stream,'sha256').hexdigest()
receipt={'cases':rows,'engine_sha256':engine_sha,'source_sha256':hashlib.sha256((root/'tests/suite/test_fx_upgrades.gd').read_bytes()).hexdigest()};(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(rows)
