from pathlib import Path
import os,sys,subprocess,json,re
sys.path.insert(0,'tools');from runtime_probe import stop_owned
root=Path.cwd();out=root/'work/shield-frame-sample/native';out.mkdir();(out/'.gitignore').write_text('*\n');(out/'.gdignore').touch();env=os.environ.copy();profile=str(out/'profile');env.update(XDG_DATA_HOME=profile,APPDATA=profile,LOCALAPPDATA=profile)
command=['python3','tools/comfyui/gpu_lock.py','--','xvfb-run','-a','-s','-screen 0 1280x720x24',env['GODOT'],'--path','.', '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','res://work/shield-frame-sample/native.tscn','--','--out='+str(out/'result'),'--fixture-fps=5','--fixture-budget=8','--fixture-phase=3']
with (out/'raw.log').open('w') as log:
 p=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  stop_owned(p)
  try:code=p.wait(timeout=10)
  except subprocess.TimeoutExpired:stop_owned(p,force=True);code=p.wait(timeout=10)
raw=(out/'raw.log').read_text(errors='replace');bad=[l for l in raw.splitlines() if re.search(r'^FAIL:|^ERROR:|SCRIPT ERROR|leaked at exit|resources still in use',l)];result=json.loads((out/'result/result.json').read_text()) if (out/'result/result.json').exists() else {};receipt={'exit':code,'diagnostics':bad,'result':result,'command':command,'renderer':'Forward+ Vulkan llvmpipe'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(receipt)
