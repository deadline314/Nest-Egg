extends "res://tests/smoke_test.gd"
class OffsetSuite extends FxUpgradesSuite:
	var phase_steps := 0
	func open_level(player_tile := 10.0, difficulty_index := 1) -> Level:
		var fresh := await super.open_level(player_tile, difficulty_index)
		await physics_frames(phase_steps)
		return fresh

var _out := ""
var _phase := 0
func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
		if arg.begins_with("--fixture-fps="): Engine.max_fps = int(arg.trim_prefix("--fixture-fps="))
		if arg.begins_with("--fixture-phase="): _phase = int(arg.trim_prefix("--fixture-phase="))
		if arg.begins_with("--fixture-budget="): Engine.max_physics_steps_per_frame = int(arg.trim_prefix("--fixture-budget="))
	super._ready()
func _run() -> void:
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	var suite := OffsetSuite.new(self)
	suite.phase_steps = _phase
	await suite._test_shield_rules_unchanged()
	DirAccess.make_dir_recursive_absolute(_out)
	FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify({"checks": _checks, "failures": Array(_failures), "render_fps_cap": Engine.max_fps, "physics_step_budget": Engine.max_physics_steps_per_frame}, "  "))
	await _finish()
