extends Node

func _ready() -> void:
	print("CAPTURE_PLAYER_SETTINGS ", JSON.stringify({"path": Settings.storage_path(), "quality": Settings.get_light_quality(), "particles": Settings.get_feel_scale("particles"), "shake": Settings.get_feel_scale("shake"), "reduce_flashes": Settings.get_reduce_flashes()}))
	await AudioRelease.settle(get_tree())
	get_tree().quit()
