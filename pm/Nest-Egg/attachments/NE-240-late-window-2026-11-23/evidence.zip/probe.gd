extends "res://tools/ch3_flow_probe.gd"

const CHAIR := "late_window_chair"
const REST := 452.0
const SHADE := 479.0
const GRIP := Vector2(234.5, 30.5)
const FRONT_FOOT := Vector2(116.5, 239.5)
const BACK_FOOT := Vector2(243.5, 239.5)
const STAGE_FLOOR := 305.0

var _checks := 0
var _observing := false
var _moving_frames := 0
var _sounds := 0
var _max_position := REST
var _worst_gap := 0.0
var _floor_error := 0.0
var _calibrated := false
var _capture_queued := false
var _capture_done := false


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://late-window-probe.cfg")
	Story.set_language("en")
	Story.auto_skip = false
	add_child(LightKit.create_environment())
	Sfx.sound_played.connect(_record_sound)
	await _case(false)
	await _case(true)
	Sfx.sound_played.disconnect(_record_sound)
	if DisplayServer.get_name() != "headless":
		_check(_capture_done, "capture the real chair moving to shade")
	if is_instance_valid(_level):
		_level.queue_free()
	await _settle(6)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _failures])
	get_tree().quit(int(_failures != 0))


func _case(skip: bool) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Settings.set_skip_cutscenes(false)
	StoryItems.acquire(&"ch3_petition_receipt")
	var funds := Progression.credits
	await _enter("showroom")
	await _talk(&"ch3_window_late")
	_check(not GameState.has_flag(&"room_late_measured"), "the late window stays locked before the tour")
	await _talk(&"ch3_lin", ["post"])
	_check(StoryItems.holds(&"ch3_tour_card") and GameState.has_flag(&"ch3_clearwater_tour_started"), "the original posting opens the tour")
	Settings.set_skip_cutscenes(skip)
	_reset_motion()
	_observing = true
	await _talk(&"ch3_window_late")
	_observing = false
	if skip:
		_check(_moving_frames == 0 and _sounds == 0, "skipping omits the chair motion and contact audio")
	else:
		_check(_moving_frames > 10 and _max_position >= SHADE - 0.01, "the original interaction moves the chair 27 stage units")
		_check(_moving_frames > 10 and _worst_gap <= 1.0, "Rin's visible hand follows the chair back (max gap %.3f)" % _worst_gap)
		_check(_floor_error <= 0.20 and _sounds == 1, "the chair stays on the floor and makes one soft impact (max floor error %.3f, sounds %d)" % [_floor_error, _sounds])
	_check(GameState.has_flag(&"room_late_measured") and str(GameState.get_flag(&"room_choice")) == "unset" and Progression.credits == funds,
		"measuring the late window records the visit without an automatic proposal or charge")
	Settings.set_skip_cutscenes(false)
	_reset_motion()
	_observing = true
	await _talk(&"ch3_window_late")
	_observing = false
	_check(_moving_frames == 0 and _sounds == 0, "a return visit does not replay the chair move")
	await _talk(&"ch3_lin", ["propose", "late"])
	_check(str(GameState.get_flag(&"room_choice")) == "late" and Progression.credits == funds + 20,
		"the separately selected late-window proposal still pays the original reward")


func _reset_motion() -> void:
	_moving_frames = 0
	_sounds = 0
	_max_position = REST
	_worst_gap = 0
	_floor_error = 0


func _process(_delta: float) -> void:
	if _observing:
		_sample_motion.call_deferred()


func _sample_motion() -> void:
	var cut := Story._player
	if not _observing or not is_instance_valid(cut) or cut.scene_id != &"ch3_t_c16_late" or cut._stage == null:
		return
	var chair := cut._stage.prop_node(CHAIR) as StageLayers._Sprite
	var rin := cut._actors.get(&"rin") as CutsceneActor
	if chair == null or rin == null:
		return
	if not _calibrated and "--calibrate" in OS.get_cmdline_user_args():
		_calibrated = true
		_calibrate(rin, chair, cut._stage)
	var x := chair.position.x
	if x <= _max_position + 0.001:
		return
	_max_position = x
	_moving_frames += 1
	var contact := chair.to_global(chair.source_point(GRIP))
	var fist := rin.hand_contact_global(&"front")
	_worst_gap = maxf(_worst_gap, cut._stage.to_local(contact).distance_to(cut._stage.to_local(fist)))
	for foot: Vector2 in [FRONT_FOOT, BACK_FOOT]:
		var support := cut._stage.to_local(chair.to_global(chair.source_point(foot)))
		_floor_error = maxf(_floor_error, absf(support.y - STAGE_FLOOR))
	if x > REST + 13.5 and not _capture_queued and DisplayServer.get_name() != "headless":
		_capture_queued = true
		_capture_contact.call_deferred()


func _record_sound(id: StringName) -> void:
	if _observing and id == &"mat_wood" and Story._current_cinematic == &"ch3_t_c16_late":
		_sounds += 1


func _capture_contact() -> void:
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	_capture_done = image.save_png(_out_dir.path_join("late-window-contact.png")) == OK


func _check(ok: bool, what: String) -> void:
	_checks += 1
	super._check(ok, what)



func _calibrate(actor: CutsceneActor, chair: StageLayers._Sprite, stage: Node2D) -> void:
	var rig := actor.rig
	var parent := actor.get_parent() as Node2D
	var inverse := rig._skeleton.global_transform.affine_inverse()
	var shoulder := inverse * rig.bone(&"arm_front_upper").global_position
	var contact := rig.hand_source_point(&"front", Vector2(96.5, 37.5))
	var upper := rig.rest(&"arm_front_lower").length()
	var lower := rig.rest(&"hand_front").length()
	var original := stage.to_local(chair.to_global(chair.source_point(GRIP)))
	print("calibration ", shoulder, " contact ", contact, " reach ", upper + lower, " actor ", actor.position)
	for shift: int in range(-36, 25, 4):
		var best := INF
		var best_angle := 0.0
		for index in range(-34, 35):
			var angle := float(index) / 10.0
			var local_angle := inverse.basis_xform(parent.global_transform.basis_xform(Vector2.from_angle(angle))).angle()
			var worst := 0.0
			for offset in [0.0, 13.5, 27.0]:
				var target := original + Vector2(offset - shift, 0.0)
				var wrist := inverse * stage.to_global(target) - contact.rotated(local_angle)
				worst = maxf(worst, wrist.distance_to(shoulder))
			if worst < best:
				best = worst
				best_angle = angle
		print("calibration shift ", shift, " angle ", best_angle, " max ", best)
