from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

root=Path.cwd()
evidence=Path('D:/NestEggVerification/evidence-20261117')
project=evidence/'ne267-source-delivery-20261118/s19-runtime'
out=evidence/'ne267-source-delivery-20261118/s19-soup-v1/prior-stage-imports'
out.mkdir()
native_sources={
    's08':evidence/'ne267-combined-20261118/native-window',
    's22':evidence/'ne267-candidate-20261118/roof-watcher-v7/native-release',
}
scope=['data/story/ch2_heron.json','data/cutscene/stages/ch2_rent_window.json','data/cutscene/stages/ch2_rooftop_watcher.json',
       'game/cutscene/cutscene_player.gd','game/cutscene/stage_prop_hold.gd','game/cutscene/stage_library.gd']
for prefix in ('suo_boat/suo_boat__boat_umbrella','control_room/control_room__control_chair'):
    for ending in ('.png','_n.png'):
        path='art/environment/scene_props/'+prefix+ending
        scope += [path,path+'.import']
        assert b'process/size_limit=0' in (project/(path+'.import')).read_bytes()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
snapshot=lambda:{name:sha(project/name) for name in scope}
guard=snapshot()

for id,old in native_sources.items():
    unit=out/id
    unit.mkdir()
    capture=unit/'captures'
    capture.mkdir()
    observer=unit/'observer.gd'
    shutil.copyfile(old/'observer.gd',observer)
    scene=observer.with_suffix('.tscn')
    scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{observer.as_posix()}" id="1"]\n[node name="ImportedStage" type="Node2D"]\nscript = ExtResource("1")\n',encoding='utf-8')
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(unit/'profile'/key)
    command=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
             'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project),'--rendering-method','forward_plus',
             '--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360']
    if id=='s08':
        command += ['--fixed-fps','60']
    command += ['--quit-after','18000',scene.as_posix(),'--','--out='+str(capture)]
    (unit/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    with (unit/'raw.log').open('wb') as log:
        process=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    raw=(unit/'raw.log').read_text(encoding='utf-8')
    result={'exit':process.returncode,'errors':re.findall(r'^.*(?:ERROR:|WARNING:).*$',raw,re.M),
            'source_held':guard==snapshot(),'pngs':len(list(capture.glob('*.png'))),'source':guard}
    (unit/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(id,{key:value for key,value in result.items() if key!='source'},flush=True)
    assert result['exit']==0 and not result['errors'] and result['source_held'] and result['pngs']>=9
