from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

root = Path.cwd()
base = Path('D:/NestEggVerification/evidence-20261117/ne267-source-delivery-20261118')
project = base/'s19-runtime'
source = base/sys.argv[1]
out = source/'native'
out.mkdir()
assets = 'art/environment/scene_props/guest_book_contacts/'
textures = (assets+'chen_soup_props.png', assets+'chen_soup_props_n.png')
mapping = {name:Path(name).name for name in (*textures, 'data/story/ch2_heron.json',
           'data/cutscene/stages/ch2_guest_book_room.json', 'art/motion/guest_chen.json')}
known = ('art/rigs/guest_chen.json','art/rigs/ali.json','art/characters/guest_chen/character.json',
         'art/characters/ali/character.json','game/cutscene/cutscene_player.gd', 'game/cutscene/cutscene_actor.gd',
         'game/cutscene/stage_prop_hold.gd','game/rig/npc_animator.gd','game/cutscene/stage_library.gd')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
tracked = known + tuple(name for name in mapping if name not in textures)
assert all(sha(project/name)==sha(root/name) for name in tracked)
sidecars = tuple(name+'.import' for name in textures)
assert all(not (project/name).exists() for name in (*textures,*sidecars))
prior = {name:(project/name).read_bytes() for name in tracked if name in mapping}
probe_text = (base/'scene-adapter/ne267_chen_scene.gd').read_text(encoding='utf-8')
anchor = '\t\tif player.choice_active():'
assert probe_text.count(anchor)==1
probe_text = probe_text.replace(anchor, '''			if id == "ch2_t_s19_done":
				var stage: StageLibrary.Stage = player._stage
				var ali := player._actors.get(&"ali") as CutsceneActor
				var hood := stage.prop_node("chen_rainhood") as StageLayers._Sprite
				var bowl := stage.prop_node("chen_pear_soup") as StageLayers._Sprite
				if hood != null and hood.is_visible_in_tree() and ali.hand_target_settled(&"front") and not captured.has("hood-open"):
					var hold_x := stage.to_local(hood.to_global(hood.source_point(Vector2(96.5, 15.5))))
					var palm_x := stage.to_local(ali.hand_contact_global(&"front"))
					if absf(hood.rotation - .9) < .006:
						if hold_x.distance_to(palm_x) > StagePropHold.CONTACT_TOLERANCE:
							_failures.append("the hood was outside the fingers after the turn")
						captured["hood-open"] = true
						snapshots.append(await _snapshot(id, "hood-open", actor, stage))
					elif absf(hood.rotation) < .002 and not captured.has("hood-closed"):
						captured["hood-closed"] = true
						snapshots.append(await _snapshot(id, "hood-closed", actor, stage))
				if bowl != null and bowl.visible:
					var bowl_bottom := stage.to_local(bowl.to_global(bowl.source_point(Vector2(43.5, 91.5))))
					if stage.prop_held("chen_pear_soup"):
						var point := stage.to_local(bowl.to_global(bowl.source_point(Vector2(34.5, 77.5))))
						var palm := stage.to_local(ali.hand_contact_global(&"front"))
						var distance := point.distance_to(palm)
						held_contacts.append({"distance":distance,"bowl_bottom":bowl_bottom})
						if distance > StagePropHold.CONTACT_TOLERANCE:
							_failures.append("the bowl left the actual fingers while held")
						if bowl_bottom.y < 169.0 and not captured.has("serve-held"):
							captured["serve-held"] = true
							snapshots.append(await _snapshot(id, "serve-held", actor, stage))
					elif bowl.position.x >= 342.98 and not captured.has("serve-rest"):
						if absf(bowl_bottom.y - 180) > 1.0:
							_failures.append("the bowl did not land on the tabletop")
						captured["serve-rest"] = true
						snapshots.append(await _snapshot(id, "serve-rest", actor, stage))
		if player.choice_active():''')
anchor = '\tif not captured.has("sit"):'
assert probe_text.count(anchor)==1
probe_text = probe_text.replace(anchor, '''	if id == "ch2_t_s19_done":
		for phase in ["hood-closed", "hood-open", "serve-held", "serve-rest"]:
			if not captured.has(phase):
				_failures.append("missing native phase " + phase)
''' + anchor)
probe = out/'observer.gd'
probe.write_text(probe_text,encoding='utf-8')
scene=probe.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n[node name="GuestSoup" type="Node2D"]\nscript = ExtResource("1")\n',encoding='utf-8')
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(out/'profile'/key)
lock=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
      'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project)]

def run(name,command,timeout):
    (out/(name+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
    with (out/(name+'.log')).open('wb') as log:
        process=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    raw=(out/(name+'.log')).read_text(encoding='utf-8')
    return process.returncode,re.findall(r'^.*(?:ERROR:|WARNING:).*$',raw,re.M)

try:
    for name,filename in mapping.items():
        (project/name).write_bytes((source/filename).read_bytes())
    info, errors=run('policy',[sys.executable,'-B','-X','utf8','tools/assets/texture_import.py'],60)
    assert info==0 and not errors
    expected={name:sha(project/name) for name in (*known,*mapping)}
    for name in mapping:
        assert expected[name]==sha(source/mapping[name]),name
    code,errors=run('import',lock+['--headless','--editor','--import'],180)
    assert code==0 and not errors, (code,errors)
    for sidecar in sidecars:
        contents=(project/sidecar).read_bytes()
        assert b'mipmaps/generate=false' in contents
        (out/Path(sidecar).name).write_bytes(contents)
        expected[sidecar]=sha(project/sidecar)
    code,errors=run('raw',lock+['--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
                              '--resolution','1280x720','--fixed-fps','60','--quit-after','10000',scene.as_posix(),'--','--out='+str(out)],120)
    report=json.loads((out/'scenes.json').read_text(encoding='utf-8'))
    result={'exit':code,'errors':errors,'failures':report['failures'],
            'source_held':all(sha(project/name)==digest for name,digest in expected.items()),'source':expected}
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print({key:value for key,value in result.items() if key!='source'},flush=True)
finally:
    for name in (*textures,*sidecars):
        target=project/name
        assert target.resolve()==project.resolve()/name
        target.unlink(missing_ok=True)
    for name,content in prior.items():
        (project/name).write_bytes(content)
    assert all((project/name).read_bytes()==content for name,content in prior.items())
