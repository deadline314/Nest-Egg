from pathlib import Path
import hashlib
import json
import sys

root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/ne267-source-delivery-20261118')
candidate=base/sys.argv[1]
out=candidate/'author-files'
out.mkdir()


def replace(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new)


story_name='tools/story/ch2_source.py'
story=(root/story_name).read_text(encoding='utf-8')
story=replace(story,'import guest_letter_staging  # noqa: E402\n',
              'import guest_letter_staging  # noqa: E402\nimport guest_soup_staging  # noqa: E402\n')
story=replace(story,'"坐下和阿梨談今晚想要的那一碗湯。", 0.298),','"坐下和阿梨談今晚想要的那一碗湯。", 0.367),')
story=replace(story,'''        if segment.section == "S20":
            response = ident == "ch2_t_s20_done"''','''        if ident == "ch2_t_s19_done":
            cast[0]["props"] = guest_soup_staging.initial()
            dialogue = _with_cues(dialogue, ((0, guest_soup_staging.fulfill()),), ident)
        if segment.section == "S20":
            response = ident == "ch2_t_s20_done"''')
stages_name='tools/assets/stage_defs.py'
stages=(root/stages_name).read_text(encoding='utf-8')
stages=replace(stages,'import guest_letter_staging\n','import guest_letter_staging\nimport guest_soup_staging\n')
stages=replace(stages,'        *guest_letter_staging.layers(),\n','        *guest_letter_staging.layers(),\n        *guest_soup_staging.layers(),\n')

builder=(root/'work/build_chen_soup_props.py').read_text(encoding='utf-8')
builder=replace(builder,'import sys\n','')
builder=replace(builder,"sys.path.insert(0, str(Path.cwd() / 'tools/assets'))\n",'')
start=builder.index("image = Image.new")
end=builder.index('path = Path(sys.argv[1])')
builder=builder[:start]+'''OUTPUT = Path(__file__).resolve().parents[2] / "art/environment/scene_props/guest_book_contacts/chen_soup_props.png"


def build(path: Path) -> None:
'''+''.join('    '+line if line.strip() else line for line in builder[start:end].splitlines(keepends=True))+'''    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path)
    pixels = np.asarray(image, dtype=np.float32) / 255
    normals = depth_normal_map(pixels, profile="flat", relief=.2, detail=0.0)
    Image.fromarray(np.rint(normals * 255).astype(np.uint8)).save(path.with_stem(path.stem + "_n"))


if __name__ == "__main__":
    build(OUTPUT)
'''

test_name='tools/story/test_ch2_guest_cast.py'
test=(root/test_name).read_text(encoding='utf-8')
test=replace(test,'import guest_letter_staging\n','import guest_letter_staging\nimport guest_soup_staging\n')
test=replace(test,'\n\nif __name__ == "__main__":','''
    def test_chen_gets_the_coat_and_soup_only_after_the_accepted_choice(self):
        staging = guest_soup_staging
        for scene in self.framed.segments.values():
            if scene.section != "S19":
                continue
            with self.subTest(scene=scene.id):
                response = scene.id == "ch2_t_s19_done"
                stage = next(step for step in scene.steps if step["do"] == "scene")
                self.assertEqual(stage.get("props", {}).get(staging.COAT, {}).get("visible", False), response)
                holds = [(step["id"], step["actor"]) for step in scene.steps if step["do"] == "prop_hold"]
                self.assertEqual(holds, [(staging.COAT, "ali"), (staging.BOWL, "ali")] if response else [])


if __name__ == "__main__":''')

paths={story_name:story.encode(),stages_name:stages.encode(),test_name:test.encode(),
       'tools/story/guest_soup_staging.py':(root/'work/guest_soup_staging.py').read_bytes(),
       'tools/assets/build_chen_soup_props.py':builder.encode()}
for name in ('data/story/ch2_heron.json','data/cutscene/stages/ch2_guest_book_room.json','art/motion/guest_chen.json'):
    paths[name]=(candidate/Path(name).name).read_bytes()
prefix='art/environment/scene_props/'
for name in ('chen_soup_props.png','chen_soup_props_n.png'):
    paths[prefix+'guest_book_contacts/'+name]=(candidate/name).read_bytes()
    paths[prefix+'guest_book_contacts/'+name+'.import']=(candidate/'native'/(name+'.import')).read_bytes()
for name,limit in (('suo_boat/suo_boat__boat_umbrella',180),('control_room/control_room__control_chair',165)):
    for suffix in ('.png.import','_n.png.import'):
        path=prefix+name+suffix
        baseline=(root/path).read_text(encoding='utf-8')
        normalized=(base/'s19-runtime'/path).read_bytes()
        assert normalized.decode().replace('\r\n','\n') == replace(baseline,f'process/size_limit={limit}', 'process/size_limit=0')
        paths[path]=normalized
rows=[]
for name,payload in paths.items():
    output=out/name
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_bytes(payload)
    original=root/name
    rows.append({'path':name,'before':hashlib.sha256(original.read_bytes()).hexdigest() if original.is_file() else None,
                 'after':hashlib.sha256(payload).hexdigest()})
(out/'paths.json').write_text(json.dumps(rows,indent=2)+'\n')
