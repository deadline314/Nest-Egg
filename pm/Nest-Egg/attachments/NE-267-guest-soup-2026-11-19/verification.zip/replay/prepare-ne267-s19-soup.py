from dataclasses import replace
import hashlib
import json
from pathlib import Path
import sys

from PIL import Image

import guest_soup_staging as soup

root = Path.cwd()
out = Path('D:/NestEggVerification/evidence-20261117/ne267-source-delivery-20261118') / sys.argv[1]
sys.path.insert(0, str(root/'tools/story'))
from build_ch2_story import spec
from chapter_compiler import write_chapter

with Image.open(out/'chen_soup_props.png') as atlas:
    for layer in soup.layers():
        x,y,w,h = layer['region']
        assert atlas.width == layer['source_width'] and 0 <= x < x+w <= atlas.width and 0 <= y < y+h <= atlas.height
    for point in (soup.HOOD_GRIP, soup.BOWL_GRIP, [25.5,33.5], [43.5,91.5]):
        assert atlas.getpixel(tuple(map(int,point)))[3] >= 128
stage = json.loads((root/'data/cutscene/stages/ch2_guest_book_room.json').read_text(encoding='utf-8'))
stage['layers'][7:7] = soup.layers()
(out/'ch2_guest_book_room.json').write_text(json.dumps(stage,ensure_ascii=False,indent=1)+'\n',encoding='utf-8')
motion = (root/'art/motion/guest_chen.json').read_text(encoding='utf-8')
old = '"stand": {\n      "chest": 0.0,\n      "head": 0.0\n'
assert motion.count(old) == 1
(out/'guest_chen.json').write_bytes(motion.replace(old,old.rstrip('\n')+',\n      "foot_back": -0.12\n').encode())

chapter = spec()
ids = [ident for ident, segment in chapter.source.segments.items() if segment.section == 'S19']
assert len(ids) == 5
for ident in ids:
    segment = chapter.source.segments[ident]
    response = ident == 'ch2_t_s19_done'
    steps = []
    inserted = False
    for step in segment.steps:
        step = dict(step)
        if step['do'] == 'scene' and response:
            step['props'] = soup.initial()
        elif step['do'] == 'actor' and step['id'] == 'chen':
            step['seat_sag'] = .367
        elif step['do'] == 'say' and response and not inserted:
            steps.extend(soup.fulfill())
            inserted = True
        steps.append(step)
    chapter.source.segments[ident] = replace(segment,steps=tuple(steps))
new_path = out/'ch2_heron.json'
assert not write_chapter(chapter, new_path)
before, after = (json.loads(path.read_text(encoding='utf-8')) for path in (root/'data/story/ch2_heron.json', new_path))
assert [key for key in before if before[key] != after[key]] == ['scenes']
assert sorted(k for k in before['scenes'] if before['scenes'][k] != after['scenes'][k]) == sorted(ids)
for ident in ids:
    old, new = before['scenes'][ident], after['scenes'][ident]
    assert {k:v for k,v in old.items() if k != 'steps'} == {k:v for k,v in new.items() if k != 'steps'}
    assert [step for step in old['steps'] if step['do']=='say'] == [step for step in new['steps'] if step['do']=='say']
digest = {path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in out.iterdir() if path.is_file()}
(out/'prepared.json').write_text(json.dumps({'files':digest,'scenes':ids},indent=2)+'\n')
