extends Node2D
## 正式S08自然時間觀察；合成推進台詞，不代稱Story結果或真人驗收。
var _out := ""
var _failures: Array[String] = []
var _scenes: Array[Dictionary] = []
var _images: Array[Dictionary] = []
const STAMP := "rent_contract_stamp"
const PAPER := "rent_contract_copy"
const MARK := "rent_contract_mark"
const GRIP := Vector2(23.5, 12.5)
const BASE := Vector2(23.5, 50.5)
const PAPER_POINT := Vector2(48, 43)
const FLOOR_Y := 340.0
const SEAT_Y := 300.04
const COUNTER_Y := 286.2898701298701

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="): _out = argument.trim_prefix("--out=")
	if not _out.is_absolute_path() or DirAccess.make_dir_recursive_absolute(_out) != OK:
		get_tree().quit(2)
		return
	for id in ["ch2_t_s08_contract", "ch2_t_s08_contract_revisit"]:
		await _scene(id)
	for capture in _images:
		var source: Image = capture.image
		var raw_path: String = _out.path_join(capture.name + ".raw")
		var raw := FileAccess.open(raw_path, FileAccess.WRITE)
		raw.store_buffer(source.get_data())
		raw.close()
		capture.metadata["raw"] = {"file": raw_path.get_file(), "format": source.get_format(), "hdr": capture.hdr, "sha256": FileAccess.get_sha256(raw_path)}
		preload("res://tools/viewport_capture.gd").encode(source, capture.hdr).save_png(_out.path_join(capture.name))
	var result := {"classification": "正式S08資料、自然時間、合成台詞推進；不經Story結果owner", "adapter": RenderingServer.get_video_adapter_name(), "renderer": RenderingServer.get_current_rendering_method(), "scenes": _scenes, "failures": _failures}
	FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify(result, "  "))
	await AudioRelease.settle(get_tree())
	print("RENT_WINDOW failures=", _failures.size())
	get_tree().quit(0 if _failures.is_empty() else 1)

func _prop_point(stage: Node2D, sprite: StageLayers._Sprite, point: Vector2) -> Vector2:
	return stage.to_local(sprite.to_global(sprite.source_point(point)))

func _scene(id: String) -> void:
	var definition: Dictionary = Story._scenes.get(id, {})
	var errors := CutsceneChecker.validate(id, definition, Story._speakers)
	errors.append_array(CutsceneChecker.staging_problems(id, definition))
	if not errors.is_empty():
		_failures.append(id + ": " + str(errors))
		return
	var flags := GameState.world_flags.duplicate(true)
	var credits := Progression.credits
	var player := CutscenePlayer.new()
	add_child(player)
	player.play(StringName(id), definition)
	var start := Time.get_ticks_msec()
	var next_advance := start + 1800
	var captured := {}
	var contacts: Array[Dictionary] = []
	var snapshots: Array[Dictionary] = []
	var was_held := false
	var mark_seen := false
	while player.is_running() and Time.get_ticks_msec() - start < 30000:
		await get_tree().process_frame
		var actor := player._actors.get(&"window_clerk") as CutsceneActor
		if actor != null and actor.rig != null and player._stage != null:
			var stage := player._stage
			var stamp := stage.prop_node(STAMP) as StageLayers._Sprite
			var paper := stage.prop_node(PAPER) as StageLayers._Sprite
			var mark := stage.prop_node(MARK) as StageLayers._Sprite
			var held := stage.prop_held(STAMP)
			if player._dialogue.visible and not player._dialogue._text.text.is_empty():
				var line: String = player._dialogue._text.text
				var line_key := "line-" + line.sha256_text()
				if not captured.has(line_key):
					captured[line_key] = true
					player._dialogue.complete()
					var shot := await _snapshot(id, "dialogue-" + str(snapshots.size()), actor, stage)
					shot["dialogue_text"] = line
					snapshots.append(shot)
			if Time.get_ticks_msec() - start > 1300 and not captured.has("seated"):
				captured["seated"] = true
				snapshots.append(await _snapshot(id, "seated", actor, stage))
			if held and stamp != null:
				was_held = true
				var palm := stage.to_local(actor.hand_contact_global(&"front"))
				var grip := _prop_point(stage, stamp, GRIP)
				contacts.append({"milliseconds": Time.get_ticks_msec() - start, "palm": palm, "stamp_grip": grip, "distance": palm.distance_to(grip)})
				if palm.distance_to(grip) > StagePropHold.CONTACT_TOLERANCE:
					_failures.append(id + ": 真掌心/章柄接點超標")
				if not captured.has("held"):
					captured["held"] = true
					snapshots.append(await _snapshot(id, "held", actor, stage))
			if mark != null and mark.visible and not mark_seen:
				mark_seen = true
				var base := _prop_point(stage, stamp, BASE)
				var surface := _prop_point(stage, paper, PAPER_POINT)
				if not held or base.distance_to(surface) > StagePropHold.CONTACT_TOLERANCE:
					_failures.append(id + ": 印記出現時章底未接紙面，距離=" + str(base.distance_to(surface)))
				snapshots.append(await _snapshot(id, "press", actor, stage))
			if was_held and not held and actor.hand_target_complete(&"front") and not captured.has("returned"):
				captured["returned"] = true
				snapshots.append(await _snapshot(id, "returned", actor, stage))
		if Time.get_ticks_msec() >= next_advance:
			player._dialogue.complete()
			player._advance_requested = true
			next_advance = Time.get_ticks_msec() + 900
	if not captured.has("seated"):
		_failures.append(id + ": 沒有實際坐姿")
	if id == "ch2_t_s08_contract" and (not was_held or not mark_seen or not captured.has("returned")):
		_failures.append(id + ": 未完整觀察到持章、觸紙與收手")
	if id.ends_with("revisit") and (was_held or mark_seen):
		_failures.append(id + ": 回訪不應重蓋或重發副本")
	if GameState.world_flags != flags or Progression.credits != credits:
		_failures.append(id + ": 視覺播放不應私自安裝結果")
	_scenes.append({"id": id, "snapshots": snapshots, "held_contacts": contacts, "flags_and_credits_unchanged": GameState.world_flags == flags and Progression.credits == credits})
	player.skip()
	while player.is_running(): await get_tree().process_frame
	player.queue_free()
	await get_tree().process_frame

func _sprite_bottom(sprite: Sprite2D, stage: Node2D) -> float:
	var texture := sprite.texture
	if texture is CanvasTexture: texture = (texture as CanvasTexture).diffuse_texture
	var pixels := texture.get_image()
	var origin := sprite.get_rect().position
	var matrix := stage.global_transform.affine_inverse() * sprite.global_transform
	var bottom := -INF
	for y in pixels.get_height():
		for x in pixels.get_width():
			if pixels.get_pixel(x, y).a >= .5:
				bottom = maxf(bottom, (matrix * (origin + Vector2(x + .5, y + .5))).y)
	return bottom

func _snapshot(id: String, phase: String, actor: CutsceneActor, stage: StageLibrary.Stage) -> Dictionary:
	await RenderingServer.frame_post_draw
	var source := get_viewport().get_texture().get_image()
	var feet: Array[Dictionary] = []
	var seat := {}
	var bindings: Array[Dictionary] = []
	for part in actor.rig._parts:
		if not part.visible: continue
		var texture: Texture2D = (part as Sprite2D).texture if part is Sprite2D else (part as Polygon2D).texture
		if texture is CanvasTexture:
			var lit := texture as CanvasTexture
			bindings.append({"part": str(part.name), "diffuse": lit.diffuse_texture.resource_path, "diffuse_size": lit.diffuse_texture.get_size(), "normal": lit.normal_texture.resource_path if lit.normal_texture != null else "missing"})
			if lit.normal_texture == null: _failures.append(id + ": " + str(part.name) + " 法線缺少")
		if str(part.name) in ["foot_front", "foot_back"] and part is Sprite2D:
			var bottom := _sprite_bottom(part, stage)
			feet.append({"part": str(part.name), "material_bottom": bottom, "delta": bottom - FLOOR_Y})
			if absf(bottom - FLOOR_Y) > 1.0: _failures.append(id + ": 鞋底/地面超標 " + str(bottom - FLOOR_Y))
		if str(part.name) == "pelvis" and part is RigPartMesh:
			seat = _mesh_material_bottom(part, stage)
	if seat.is_empty() or absf(float(seat.get("delta", INF))) > 1.0: _failures.append(id + ": 臀底/座面超標 " + str(seat))
	var stamp := stage.prop_node(STAMP) as StageLayers._Sprite
	var paper := stage.prop_node(PAPER) as StageLayers._Sprite
	var chair := stage.prop_node("rent_clerk_chair") as StageLayers._Sprite
	var prop_bindings: Array[Dictionary] = []
	for prop_id in [STAMP, PAPER, MARK, "rent_clerk_chair"]:
		var prop := stage.prop_node(prop_id) as StageLayers._Sprite
		if prop == null or not prop.physical_surface() or not prop.texture is CanvasTexture:
			_failures.append(id + ": 實體道具沒有原生光照材質 " + prop_id)
			continue
		var lit := prop.texture as CanvasTexture
		prop_bindings.append({"id":prop_id,"diffuse":lit.diffuse_texture.resource_path,"diffuse_size":lit.diffuse_texture.get_size(),"normal":lit.normal_texture.resource_path if lit.normal_texture != null else "missing"})
		if lit.normal_texture == null: _failures.append(id + ": 實體道具法線缺少 " + prop_id)
	var metrics := {"stamp_base": _prop_point(stage, stamp, BASE), "paper_point": _prop_point(stage, paper, PAPER_POINT), "stamp_held": stage.prop_held(STAMP), "paper_visible": paper.visible, "paper_bottom": _sprite_bottom(paper, stage), "actual_chair_surface_reference": _prop_point(stage, chair, Vector2(158.5, 163.5))}
	if paper.visible and absf(float(metrics.paper_bottom) - COUNTER_Y) > 1.0: _failures.append(id + ": 紙張未落桌面")
	var name := id + "-" + phase + ".png"
	var metadata := {"phase": phase, "png": name, "feet": feet, "seat": seat, "props": metrics, "texture_bindings": bindings,"prop_texture_bindings":prop_bindings}
	_images.append({"name": name, "image": source, "hdr": get_viewport().use_hdr_2d, "metadata": metadata})
	return metadata


func _mesh_material_bottom(mesh: RigPartMesh, stage: Node2D) -> Dictionary:
	var texture := mesh.texture
	if texture is CanvasTexture:
		texture = (texture as CanvasTexture).diffuse_texture
	var pixels := texture.get_image()
	var uv := mesh.uv
	var vertices := mesh.deformed_vertices()
	var local_to_stage := stage.global_transform.affine_inverse() * mesh.global_transform
	var bottom := -INF
	for polygon: PackedInt32Array in mesh.polygons:
		assert(polygon.size() == 3)
		var a: int = polygon[0]
		var b: int = polygon[1]
		var c: int = polygon[2]
		var source_basis := Transform2D(uv[b] - uv[a], uv[c] - uv[a], uv[a])
		if absf(source_basis.determinant()) < 0.00001:
			continue
		var to_barycentric := source_basis.affine_inverse()
		var to_material := Transform2D(vertices[b] - vertices[a], vertices[c] - vertices[a], vertices[a])
		var low := uv[a].min(uv[b]).min(uv[c]).floor().max(Vector2.ZERO)
		var high := uv[a].max(uv[b]).max(uv[c]).ceil().min(Vector2(pixels.get_size()))
		for y in range(int(low.y), int(high.y)):
			for x in range(int(low.x), int(high.x)):
				if pixels.get_pixel(x, y).a < .5:
					continue
				var weights := to_barycentric * Vector2(x + .5, y + .5)
				if weights.x < 0.0 or weights.y < 0.0 or weights.x + weights.y > 1.0:
					continue
				var point := local_to_stage * (to_material * weights)
				if point.x >= 384.0 and point.x <= 419.0:
					bottom = maxf(bottom, point.y)
	return {"pelvis_material_bottom_over_chair": bottom, "seat_top_stage_y": 300.04, "delta": bottom - 300.04,
		"method": "opaque source pixel centres mapped through actual deformed UV triangles inside the formal right-chair x band"}
