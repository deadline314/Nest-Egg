extends Node

const Capture := preload("res://tools/viewport_capture.gd")

var _checks := 0
var _fails := 0
var _out := ""


func _ready() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://pickup-copy-native.cfg")
	Settings.set_ui_text_scale(1.2)
	Settings.set_reduce_ui_motion(true)
	Story.auto_skip = true
	await _exercise("en", "K-7 Assault Rifle: Fast, precise fire at any range.",
			"Picked up K-7 Assault Rifle", "Picked up Med injector (1/3)", "Med injector at carrying limit (3).")
	await _exercise("ja", "K-7 アサルトライフル：連射が速く正確。幅広い距離で使える。",
			"K-7 アサルトライフルを入手", "回復注射を入手（1/3）", "回復注射は所持上限です（3）。")
	await AudioRelease.settle(get_tree())
	await _finish()


func _exercise(language: String, prompt_text: String, weapon_text: String, item_text: String, full_text: String) -> void:
	Story.set_language(language)
	GameState.start_new_run(GameState.difficulties[1])
	InputBindings._set_device(false, -1)
	var map := load("res://data/levels/level_01.tres") as LevelData
	Story._seen[map.intro_scene] = true
	for scene: String in map.story_triggers:
		Story._seen[StringName(scene)] = true
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(map)
	add_child(level)
	await _frames(212)
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		enemy.set_physics_process(false)

	var rifle: WeaponPickup
	for child: Node in level._entities.get_children():
		if child is WeaponPickup and (child as WeaponPickup).weapon.id == &"rifle":
			rifle = child
			break
	_check(is_instance_valid(rifle), language + " loads the original K-7 pickup")
	if not is_instance_valid(rifle):
		level.queue_free()
		await _frames(6)
		return
	var player := level.player
	player.global_position = rifle.global_position + Vector2(-29.0, 0.0)
	player.velocity = Vector2.ZERO
	await _frames(80)
	var hint: WorldPrompt
	for child: Node in rifle.get_children():
		if child is WorldPrompt:
			hint = child
			break
	if is_instance_valid(hint):
		# Camera settling and a nearby actor can delay the first readable placement.
		for frame in 150:
			if hint.is_showing() and hint._alpha >= 0.8:
				break
			await _frames(1)
		print("PROMPT ", language, " visible=", hint.is_showing(), " alpha=", hint._alpha, " text=", hint._display_text)
	_check(is_instance_valid(hint) and hint.is_showing() and hint._alpha >= 0.8 and hint._display_text == prompt_text,
			language + " the real world prompt shows the localized name and weapon description")
	if language == "en":
		await _picture("inspect-en.png")

	var weapon_id := rifle.weapon.id
	await _walk(KEY_D, 19)
	await _frames(12)
	var hud := level.hud
	_check(not is_instance_valid(rifle) and player.loadout.find_slot(weapon_id) >= 0,
			language + " walking over the original pickup equips it")
	_check(hud.pickup_feed.lines().has(weapon_text) and hud.toast_banner._label.text != weapon_text,
			language + " weapon confirmation reaches the pickup feed")
	var med := load("res://data/consumables/med_injector.tres") as ConsumableData
	var med_pickup := _place_item(level, med, player.global_position)
	await _frames(12)
	_check(not is_instance_valid(med_pickup) and player.consumables.count(med.id) == 1,
			language + " real overlapping bodies grant the consumable once")
	_check(hud.pickup_feed.lines().has(item_text) and hud.toast_banner._label.text != item_text,
			language + " localized pickup feed shows the carried quantity")
	if language == "ja":
		await _picture("pickup-ja.png")
	for slot in range(player.consumables.count(med.id), med.max_carry):
		player.consumables.add(med)
	var full := _place_item(level, med, player.global_position)
	await _frames(15)
	_check(is_instance_valid(full) and not full.is_queued_for_deletion()
			and player.consumables.count(med.id) == med.max_carry,
			language + " the real full inventory leaves the pickup available")
	_check(hud.toast_banner._label.text == full_text and not hud.pickup_feed.lines().has(full_text),
			language + " the carrying limit stays a separate localized notice")
	if language == "en":
		await _picture("full-en.png")
	level.queue_free()
	InputBindings.clear_held_inputs()
	await _frames(8)


func _place_item(level: Level, item: ConsumableData, point: Vector2) -> ConsumablePickup:
	var pickup := ConsumablePickup.new()
	pickup.configure(item)
	pickup.position = level._entities.to_local(point)
	level._entities.add_child(pickup)
	return pickup


func _walk(key: Key, frames: int) -> void:
	var press := InputEventKey.new()
	press.keycode = key
	press.physical_keycode = key
	press.pressed = true
	Input.parse_input_event(press)
	await _frames(frames)
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	Input.parse_input_event(release)



func _key(key: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = key
	event.physical_keycode = key
	await _tap(event)


func _joy(button: JoyButton) -> void:
	var event := InputEventJoypadButton.new()
	event.button_index = button
	await _tap(event)


func _tap(event: InputEvent) -> void:
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(3)
	event = event.duplicate()
	event.pressed = false
	Input.parse_input_event(event)
	await _frames(5)


func _frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame


func _picture(name: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(Capture.image(get_viewport()).save_png(_out.path_join(name)) == OK, "captured " + name)


func _check(ok: bool, message: String) -> void:
	_checks += 1
	_fails += int(not ok)
	print(("%s " % ("PASS" if ok else "FAIL")) + message)


func _finish() -> void:
	await _frames(7)
	await AudioRelease.settle(get_tree())
	print("checks: %d, failures: %d" % [_checks, _fails])
	get_tree().quit(int(_fails != 0))
