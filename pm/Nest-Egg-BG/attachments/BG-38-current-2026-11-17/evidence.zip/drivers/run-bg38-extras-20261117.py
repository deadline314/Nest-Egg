from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg38-current');out=base/'extras';out.mkdir(exist_ok=False)
paths=json.loads((base/'native/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name,scene,args in [('context-current','res://work/bg38-current/observer.tscn',['--level=ch2_ali_home','--tag=after-context','--quality=high','--cells=1:1','--no-enemies']),('pack','res://tools/screenshot.tscn',['--scenario=scene_packs','--scene=ali_kitchen','--lighting=residential'])]:
    folder=out/name;folder.mkdir();env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60',scene,'--','--out='+str(folder)]+args
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
    raw=(folder/'raw.log').read_bytes();png=[p.relative_to(folder).as_posix() for p in folder.rglob('*.png')]
    row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'png':png}
    if name=='context-current':
        row['observations']=[json.loads(line.split(b'BG38_ENV ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG38_ENV ')]
        assert len(row['observations'])==1 and row['observations'][0]['environment'] and row['observations'][0]['count']==1 and row['observations'][0]['glow']
    else:assert b'props  8  OK' in raw and b'== 8 props in 1 scene(s)' in raw
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode('utf-8',errors='replace')[-1500:],flush=True)
    assert r.returncode==0 and row['script_errors']==0 and not row['engine_error'] and row['source_held'] and len(png)==1
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'passed':True,'source_held':before==snapshot()},indent=2)+'\n')
