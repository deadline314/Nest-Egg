from pathlib import Path
import hashlib,json,os,subprocess,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg38-current');out=base/(sys.argv[1] if len(sys.argv)>1 else 'environment-before');out.mkdir(exist_ok=False)
paths=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg29-current/checks/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy()
for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(out/'private-profile'/k)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg38-current/observer.tscn','--','--out='+str(out),'--level=ch2_ali_home','--tag=before-context','--quality=high','--cells=1:1','--no-enemies']
with (out/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
raw=(out/'raw.log').read_bytes();observations=[json.loads(line.split(b'BG38_ENV ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG38_ENV ')]
after=snapshot();result={'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==after,'observations':observations}
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True);print(raw.decode('utf-8',errors='replace')[-1800:],flush=True)
assert r.returncode==0 and result['script_errors']==0 and not result['engine_error'] and result['source_held'] and len(observations)==1
assert observations[0]['quality']==2 and observations[0]['hdr'] and not observations[0]['environment'] and observations[0]['count']==0
