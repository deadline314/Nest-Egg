from pathlib import Path
import hashlib,json,re,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg38-current');base.mkdir(exist_ok=True)
private=root/'work/bg38-current';private.mkdir(exist_ok=True)
assert not (base/'baseline-proof.json').exists()
parent=subprocess.check_output(['git','rev-parse','e6345829e^'],cwd=primary).decode().strip()
original_map=subprocess.check_output(['git','show',parent+':data/levels/ch2_ali_home_map.json'],cwd=primary)
original_theme=subprocess.check_output(['git','show',parent+':data/environment/themes/ch2_ali_home.tres'],cwd=primary)
current=json.loads((root/'data/levels/ch2_ali_home_map.json').read_text())
old=json.loads(original_map)
original_map_matches={k:v for k,v in old.items() if k!='props'}=={k:v for k,v in current.items() if k!='props'}
assert len(old['props'])==6 and len(current['props'])==8
baseline=dict(current);baseline['props']=old['props']
assert {k:v for k,v in baseline.items() if k!='props'}=={k:v for k,v in current.items() if k!='props'}
(private/'before-map.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
theme=(root/'data/environment/themes/ch2_ali_home.tres').read_text()
old_dirs=next(line for line in original_theme.decode().splitlines() if line.startswith('extra_prop_dirs = '))
theme=re.sub(r'^extra_prop_dirs = .*$',lambda _:old_dirs,theme,flags=re.M)
(private/'before-theme.tres').write_text(theme,encoding='utf-8',newline='\n')
data=(root/'data/levels/ch2_ali_home.tres').read_text()
data=data.replace('res://data/environment/themes/ch2_ali_home.tres','res://work/bg38-current/before-theme.tres')
data=data.replace('res://data/levels/ch2_ali_home_map.json','res://work/bg38-current/before-map.json')
assert not (root/'data/levels/bg38_before.tres').exists()
(private/'before-level.tres').write_text(data,encoding='utf-8',newline='\n')
(base/'original-map.json').write_bytes(original_map);(base/'original-theme.tres').write_bytes(original_theme)
(base/'baseline-proof.json').write_text(json.dumps({'before_parent':parent,'original_bg38_commit':'e6345829eac6a7360af41e66ebe2243536928c5e','current_base':'e3a8d31369ce402c0e1b2f6b974cb0f4a9c217f4',
    'same_nonprop_map_data':True,'historical_nonprop_matches_current':original_map_matches,'before_props':6,'after_props':8,'original_map_sha256':hashlib.sha256(original_map).hexdigest(),'original_theme_sha256':hashlib.sha256(original_theme).hexdigest(),
    'scope':'Original pre-BG38 map props and pack directories in current runtime/lighting/textures; current terrain/spawns/portals unchanged. Controlled scenery replacement comparison, not a complete historical checkout.'},indent=2)+'\n')
props=json.loads((root/'assets_src/pipeline/scene_props.json').read_text(encoding='utf-8'))
backgrounds=json.loads((root/'assets_src/pipeline/scene_bgs.json').read_text(encoding='utf-8'))
selected=[e for e in props['props'] if e.get('scene')=='ali_kitchen'];assert len(selected)==8
background=[e for entries in backgrounds.values() if isinstance(entries,list) for e in entries if isinstance(e,dict) and e.get('id')=='ali_kitchen'];assert len(background)==1
(base/'pipeline-extract.json').write_text(json.dumps({'styles':props['styles'],'defaults':props['defaults'],'props':selected,'background':background},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(private/'observer.gd').write_text('''extends "res://tools/scene_tour.gd"
func _ready() -> void:
    seed(38)
    if OS.get_cmdline_user_args().has("--preexisting-environment"):
        add_child(LightKit.create_environment())
    super._ready()
func _frame_interval_ms() -> float:
    var environment := get_viewport().find_world_3d().environment
    print("BG38_ENV ",JSON.stringify({"environment":environment!=null,"glow":environment!=null and environment.glow_enabled,
        "count":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),"quality":Settings.get_light_quality(),
        "hdr":get_viewport().use_hdr_2d,"size":[get_viewport().get_texture().get_width(),get_viewport().get_texture().get_height()]}))
    return await super._frame_interval_ms()
''',encoding='utf-8',newline='\n')
(private/'observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg38-current/observer.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
print((base/'baseline-proof.json').read_text(),flush=True)
