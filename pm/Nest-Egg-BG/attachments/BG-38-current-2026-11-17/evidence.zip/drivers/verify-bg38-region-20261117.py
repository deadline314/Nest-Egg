from pathlib import Path
import hashlib,json,math
root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg38-current/native')
before=json.loads((out/'source-before.json').read_text());after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in before}
assert before==after
private=root/'work/bg38-current';private_before=json.loads((out/'private-before.json').read_text())
assert all(hashlib.sha256((private/p).read_bytes()).hexdigest()==h for p,h in private_before.items())
runs=json.loads((out/'runs.json').read_text());assert len(runs)==8 and all(r['exit']==r['script_errors']==0 and not r['engine_error'] and r['source_held'] and r['private_held'] for r in runs)
results=[]
for q in ['low','high']:
    old=json.loads((out/('before-'+q+'-normal')/'bg38_before/tour-index.json').read_text())
    new=json.loads((out/('after-'+q+'-normal')/'ch2_ali_home/tour-index.json').read_text())
    before_rows=[r for r in old['shots'] if 'player_contrast' in r]
    after_rows=[r for r in new['shots'] if 'player_contrast' in r]
    assert len(before_rows)==len(after_rows)==6
    changes=[]
    for a,b in zip(before_rows,after_rows):
        assert a['world']==b['world'] and a['player_world']==b['player_world'] and a['fog_clock']==b['fog_clock']
        assert b['passed'] and b['cycle_passed'] and b['player_contrast']>=.6 and b['edge_contrast']>=1
        assert len(a['cycle_samples_raw'])==len(b['cycle_samples_raw'])==16
        changes.append({'cell':[a['column'],a['row']],'player_before':a['player_contrast'],'player_after':b['player_contrast'],
            'edge_before':a['edge_contrast'],'edge_after':b['edge_contrast'],'player_decreased':b['player_contrast']<a['player_contrast']})
    minima={}
    for key in ['player_contrast','edge_contrast','cycle_player_min','cycle_edge_min']:
        a=min(r[key] for r in before_rows);b=min(r[key] for r in after_rows)
        assert math.isfinite(a) and math.isfinite(b) and b>=a,(q,key,a,b)
        minima[key]={'before':a,'after':b}
    results.append({'quality':q,'minima':minima,'points':changes})
result={'passed':True,'contract':'Use the original BG38 ticket comparison columns: regional minimum over six visible sample cells, with original 0.6 player / 1.0 edge gates; enemy N/A in this safe room. Full point deltas retained; no claim that every individual point increased.',
    'original_driver_exit':1,'original_failure':'Extra pointwise monotonic comparison after all eight native producers completed exit 0; not a failure of the original regional-minimum contract. No runtime, data, sampling formulas, source images or thresholds changed for this recount.',
    'qualities':results,'source_held':True,'private_held':True}
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'private-after.json').write_text(json.dumps(private_before,indent=2)+'\n')
(out/'regional-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':True,'qualities':[{k:v for k,v in r.items() if k!='points'} for r in results],'individual_player_decreases':sum(p['player_decreased'] for r in results for p in r['points'])},indent=2),flush=True)
