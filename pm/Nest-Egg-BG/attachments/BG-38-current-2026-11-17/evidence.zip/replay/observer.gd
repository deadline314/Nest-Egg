extends "res://tools/scene_tour.gd"
func _ready() -> void:
    seed(38)
    if OS.get_cmdline_user_args().has("--preexisting-environment"):
        add_child(LightKit.create_environment())
    super._ready()
func _frame_interval_ms() -> float:
    var environment := get_viewport().find_world_3d().environment
    print("BG38_ENV ",JSON.stringify({"environment":environment!=null,"glow":environment!=null and environment.glow_enabled,
        "count":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),"quality":Settings.get_light_quality(),
        "hdr":get_viewport().use_hdr_2d,"size":[get_viewport().get_texture().get_width(),get_viewport().get_texture().get_height()]}))
    return await super._frame_interval_ms()
