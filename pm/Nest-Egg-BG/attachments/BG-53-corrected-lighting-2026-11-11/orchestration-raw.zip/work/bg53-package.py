from pathlib import Path
import hashlib,json,zipfile,re,shutil,sys
root=Path(__file__).resolve().parents[1]
base=root/sys.argv[1]
archives=[];summaries=[]
for case in sorted(base.iterdir()):
 if not case.is_dir() or not(case/'exit.json').exists():continue
 files=sorted(f for f in case.rglob('*')if f.is_file()and not f.name.endswith(('.import','.uid')))
 manifest={f.relative_to(case).as_posix():{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}for f in files}
 zpath=base/(case.name+'-raw.zip')
 if not zpath.exists():
  with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED)as z:
   for f in files:z.write(f,f.relative_to(case).as_posix())
   z.writestr('manifest-raw.json',(json.dumps(manifest,indent=2)+'\n').encode())
 with zipfile.ZipFile(zpath)as z:
  recorded=json.loads(z.read('manifest-raw.json'))
  assert recorded==manifest,('archive differs from raw case',case.name)
  for name,info in manifest.items():
   raw=z.read(name);assert len(raw)==info['bytes']and hashlib.sha256(raw).hexdigest()==info['sha256'],name
  before=json.loads(z.read('source-before.json'));after=json.loads(z.read('exit.json'))['source_after'];assert before==after,(case.name,'source changed during execution')
  for name,sha in before.items():assert hashlib.sha256(z.read('source/'+name)).hexdigest()==sha
 archives.append({'case':case.name,'zip':zpath.name,'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'bytes':zpath.stat().st_size,'raw_files':len(manifest)})
 log=(case/'run.log').read_bytes().decode('utf-8',errors='replace')
 entry={'case':case.name,**json.loads((case/'exit.json').read_bytes()),'engine_error_lines':[line for line in log.splitlines()if re.search(r'^(?:SCRIPT ERROR|ERROR):',line)],'photos':len(list(case.rglob('*.png'))),'levels':[]}
 for f in sorted(case.glob('*/*-index.json')):
  d=json.loads(f.read_bytes());v=[s for s in d['shots']if 'player_contrast'in s];e=[e for s in d['shots']for e in s.get('enemy_contrast',[])];cy=[s for s in v if 'cycle_player_min'in s]
  entry['levels'].append({'level':d['level'],'photos':len(d['shots']),'player_samples':len(v),'player_min':min((s['player_contrast']for s in v),default=None),'edge_min':min((s['edge_contrast']for s in v),default=None),'enemy_min':min(e)if e else None,'enemy_samples':len(e),'cycle_player_min':min((s['cycle_player_min']for s in cy),default=None),'cycle_edge_min':min((s['cycle_edge_min']for s in cy),default=None),'all_fixed_aim':all(s['facing']==1 and s['aim_dir']==[1,0] for s in d['shots']),'probe':d['probe']})
 if(case/'readability-report.json').exists():
  d=json.loads((case/'readability-report.json').read_bytes());ss=d['results'];harbor=[s for s in ss if s['spot']=='碼頭入口'];entry['chapter_spots']=len(ss);entry['invalid_spots']=[s for s in ss if not s['sampling_valid']];entry['failed_spots']=[s for s in ss if not s['passed']];entry['harbor']=harbor;entry['chapter_min']={k:min((s[k]for s in ss if s[k]is not None),default=None)for k in ['player_contrast','edge_contrast','enemy_contrast']}
 if(case/'report.json').exists():entry['known_answer_report']=json.loads((case/'report.json').read_bytes())
 summaries.append(entry)
(base/'archives.json').write_bytes((json.dumps(archives,indent=2)+'\n').encode())
(base/'summary.json').write_bytes((json.dumps(summaries,ensure_ascii=False,indent=2)+'\n').encode())
print('verified',len(archives),'archives',sum(a['raw_files']for a in archives),'raw files',sum(a['bytes']for a in archives),'zip bytes')
