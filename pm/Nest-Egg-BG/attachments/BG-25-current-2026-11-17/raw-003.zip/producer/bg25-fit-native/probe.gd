extends "res://tools/scene_motion_probe.gd"
var sample_level: Level
var pending := false
func _find_prop(level: Level) -> PropNode:
    var found := super._find_prop(level)
    if found!=null and sample_level==null:
        sample_level=level;pending=true
    return found
func _settle(frames: int) -> void:
    await super._settle(frames)
    if pending and frames==SETTLE_FRAMES and is_instance_valid(sample_level):
        pending=false
        var camera := get_viewport().get_camera_2d()
        var target := sample_level._lighting._target
        var prompts := 0
        for node in sample_level.find_children("*","",true,false):
            if node is WorldPrompt and node.is_visible_in_tree():prompts+=1
        var prop := super._find_prop(sample_level)
        var world_rect := get_viewport().get_canvas_transform().affine_inverse()*get_viewport().get_visible_rect()
        var fits := world_rect.encloses(Rect2(prop.global_position,prop.data.size))
        _check(fits,"entire authored prop rectangle including fixed ends is visible")
        print("BG25_FRAMING ",JSON.stringify({"prop_rect":[prop.global_position.x,prop.global_position.y,prop.data.size.x,prop.data.size.y],"world_rect":[world_rect.position.x,world_rect.position.y,world_rect.size.x,world_rect.size.y],"entire_prop_visible":fits,"zoom":camera.zoom.x}))
        var held := target==camera and is_equal_approx(target.global_position.x,camera.global_position.x)
        _check(held and prompts==0,"actual light observer follows camera and no hidden-player world prompts")
        print("BG25_OBSERVER ",JSON.stringify({"target_x":target.global_position.x,"camera_x":camera.global_position.x,"camera_zone":sample_level._lighting.zone_id_at(camera.global_position.x),"target_zone":sample_level._lighting.zone_id_at(target.global_position.x),"visible_prompts":prompts,"held":held}))

        if "--flat" in OS.get_cmdline_user_args():
            sample_level._lighting.process_mode=Node.PROCESS_MODE_DISABLED
            sample_level._lighting._modulate.color=Color.WHITE
            await super._settle(3)
            print("BG25_FLAT_DIAGNOSTIC only, not actual-light acceptance")
