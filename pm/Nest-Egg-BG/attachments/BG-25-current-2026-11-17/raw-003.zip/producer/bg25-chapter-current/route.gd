extends "res://tools/environment_motion_probe.gd"
func open_chapter(id: String, tile: int) -> void:
    await super.open_chapter(id,tile)
    var fits := level._layout.fits_body(player.global_position,Player.BODY_SIZE)
    print("BG25_PLACEMENT ",JSON.stringify({"level":id,"tile":tile,"feet":[player.global_position.x,player.global_position.y],"fits_body":fits}))
    assert(fits,"original chapter sample must fit actual body")
func capture(file_name: String) -> void:
    await super.capture(file_name)
    var environments := get_tree().root.find_children("*","WorldEnvironment",true,false)
    print("BG25_CAPTURE ",JSON.stringify({"file":file_name+".png","quality":Settings.get_light_quality(),"hdr":get_viewport().use_hdr_2d,"environments":environments.size(),"glow":environments[0].environment.glow_enabled if not environments.is_empty() else false}))
