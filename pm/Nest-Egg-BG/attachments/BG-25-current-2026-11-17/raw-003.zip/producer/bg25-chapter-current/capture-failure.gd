extends "res://tools/environment_motion_probe.gd"
func run() -> void:
    add_child(LightKit.create_environment())
    await capture("denied")
