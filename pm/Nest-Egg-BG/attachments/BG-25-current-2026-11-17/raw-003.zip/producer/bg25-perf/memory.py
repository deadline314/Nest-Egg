import ctypes,json,sys
from ctypes import wintypes
class Counters(ctypes.Structure):
    _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(n,ctypes.c_size_t) for n in ['PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage','PrivateUsage']]
kernel=ctypes.WinDLL('kernel32',use_last_error=True);psapi=ctypes.WinDLL('psapi',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.CloseHandle.argtypes=[wintypes.HANDLE];psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(Counters),wintypes.DWORD]
handle=kernel.OpenProcess(0x1000|0x10,False,int(sys.argv[1]));assert handle,ctypes.get_last_error()
try:
    c=Counters();c.cb=ctypes.sizeof(c);assert psapi.GetProcessMemoryInfo(handle,ctypes.byref(c),c.cb),ctypes.get_last_error()
    print(json.dumps({'pid':int(sys.argv[1]),'working_set_bytes':c.WorkingSetSize,'private_bytes':c.PrivateUsage,'peak_working_set_bytes':c.PeakWorkingSetSize}))
finally:kernel.CloseHandle(handle)
