extends "res://tools/scene_motion_probe.gd"
func _median(values: Array[float]) -> float:
    var stats := _stats()
    var output: Array = []
    var error := OS.execute("D:/ComfyUI/.venv-rocm/Scripts/python.exe",PackedStringArray(["-X","utf8","D:/NestEggVerification/ne218-baseline-20261117/work/bg25-perf/memory.py",str(OS.get_process_id())]),output,true)
    _check(error==0,"actual own Godot process memory read after frame timing")
    print("BG25_ACTIVE_STATS ",JSON.stringify(stats))
    print("BG25_WINDOWS_MEMORY ","".join(output))
    print("BG25_PERF_SAMPLES ",JSON.stringify(values))
    return super._median(values)
