extends "res://tools/scene_motion_probe.gd"
var shots: Array[Dictionary] = []
var damage_events := 0
func _shot(file: String, drip: LocalDrip) -> void:
    await RenderingServer.frame_post_draw
    _check(Capture.image(get_viewport()).save_png(_out.path_join(file+".png"))==OK,"save "+file)
    shots.append({"file":file+".png","clock":drip.clock,"stage":String(drip.stage()),"paused":get_tree().paused,"from":[drip._from.x,drip._from.y],"to":[drip._to.x,drip._to.y],"z":drip.get_parent().z_index})
func _until(drip: LocalDrip,at: float) -> bool:
    var deadline := Time.get_ticks_msec()+15000
    while drip.clock<at and Time.get_ticks_msec()<deadline:await get_tree().process_frame
    return _check(drip.clock>=at,"actual motion clock reaches "+str(at))
func _run() -> void:
    add_child(LightKit.create_environment())
    var previous := Settings.get_light_quality()
    Settings.set_light_quality(QUALITY[_quality])
    Story.auto_skip=true
    var level := await _open_level()
    var prop := _find_prop(level)
    if not _check(prop!=null,"actual placed bucket exists"):
        await _finish({},previous)
        return
    var drip := prop.get_node_or_null("LocalDrip") as LocalDrip
    if not _check(drip!=null,"original drip component exists"):
        await _finish({},previous)
        return
    var camera := get_viewport().get_camera_2d() as LevelCamera
    camera.set_physics_process(false)
    camera.offset=Vector2.ZERO
    camera.zoom=Vector2.ONE*LevelCamera.base_zoom()*2.0
    camera.global_position=prop.global_position+prop.data.size*.5
    camera.reset_smoothing();camera.force_update_scroll()
    await _settle(20)
    drip.clock=0.0
    await _shot("cycle-start",drip)
    for at in [.2,.48,1.0,1.64]:
        if not await _until(drip,at):
            await _finish({"shots":shots},previous)
            return
        await _shot("cycle-"+str(int(at*100)),drip)
    var before := drip.clock
    var deadline := Time.get_ticks_msec()+15000
    while drip.clock>=before and Time.get_ticks_msec()<deadline:await get_tree().process_frame
    _check(drip.clock<.2,"original fmod crosses into next falling cycle")
    await _shot("cycle-after-wrap",drip)
    await _until(drip,.48)
    await _shot("cycle-second-splash",drip)
    var player := level.player
    var feet := Vector2(prop.global_position.x-40,prop.global_position.y+prop.data.size.y-2)
    _check(level._layout.fits_body(feet,Player.BODY_SIZE),"arranged player fits actual ground")
    player.global_position=feet;player.velocity=Vector2.ZERO;player.show();player.process_mode=Node.PROCESS_MODE_INHERIT
    player.health.setup(999,0.0)
    for node in level.find_children("*","Node2D",true,false):
        if node is NpcActor and node.data.kind==NpcData.Kind.PERSON:node.hide()
    camera.zoom=Vector2.ONE*LevelCamera.base_zoom()
    camera.global_position=prop.global_position+prop.data.size*.5;camera.force_update_scroll()
    var enemy := level._create_enemy(load("res://data/enemies/grunt.tres"))
    enemy.position=Vector2(prop.global_position.x+65,feet.y)
    level._entities.add_child(enemy)
    _check(level._layout.fits_body(enemy.global_position,enemy.data.body_size),"arranged actual enemy fits actual ground")
    enemy.health.damaged.connect(func(_info: DamageInfo) -> void: damage_events+=1)
    await _settle(20)
    var transform := get_viewport().get_final_transform()*get_viewport().get_canvas_transform()
    Input.warp_mouse(transform*(enemy.global_position-Vector2(0,20)))
    Input.action_press(&"shoot")
    for i in 3:
        await get_tree().create_timer(.15).timeout
        await _shot("combat-"+str(i),drip)
    Input.action_release(&"shoot")
    _check(player.is_visible_in_tree() and not player.is_dead(),"actual player remains visible and alive")
    var live := is_instance_valid(enemy) and not enemy.is_queued_for_deletion()
    print("BG25_COMBAT ",JSON.stringify({"damage_events":damage_events,"enemy_still_valid":live,"player_visible":player.is_visible_in_tree(),"hp":player.health.current}))
    for node in get_tree().get_nodes_in_group(&"enemies"):node.queue_free()
    await _settle(5)
    var person: NpcActor
    for node in level.find_children("*","Node2D",true,false):
        if node is NpcActor and node.data.kind==NpcData.Kind.PERSON:
            person=node;break
    if _check(person!=null,"actual original Old K available"):
        person.global_position=Vector2(prop.global_position.x+40,feet.y)
        person.show()
        Story.auto_skip=false
        Story._layer.show()
        person._talk.call_deferred()
        await _settle(90)
        var active := Story.is_cinematic_active()
        _check(active,"actual NPC dialogue active")
        await _shot("dialogue",drip)
        print("BG25_DIALOGUE ",JSON.stringify({"active":active,"source_id":person.state_key(),"paused":get_tree().paused,"player_visible":player.is_visible_in_tree(),"person_visible":person.is_visible_in_tree()}))
        Story.reset_active_presentation(&"verification_end")
        await _settle(5)
    get_tree().paused=false
    level.queue_free();await _settle(8)
    await _finish({"shots":shots,"damage_events":damage_events,"scope":"Arranged actual player/enemy and original NPC around actual bucket; public shooting input and actual NPC talk. Starts at clock0 then natural wrap, no timer rescaling. Actor positions arranged and player999HP; not human chapter completion."},previous)
