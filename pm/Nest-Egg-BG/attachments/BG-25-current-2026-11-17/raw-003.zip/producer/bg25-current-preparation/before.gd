extends "res://work/bg25-current-preparation/scene-before.gd"
func _open_level() -> Level:
    var result := await super._open_level()
    var environments := get_tree().root.find_children("*", "WorldEnvironment", true, false)
    print("BG25_ENV ", JSON.stringify({"count":environments.size(),"hdr_2d":get_viewport().use_hdr_2d,"glow":environments[0].environment.glow_enabled if not environments.is_empty() else false}))
    return result
