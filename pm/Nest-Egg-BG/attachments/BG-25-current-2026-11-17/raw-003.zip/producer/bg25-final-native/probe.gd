extends "res://tools/scene_motion_probe.gd"
var sample_level: Level
var pending := false
func _find_prop(level: Level) -> PropNode:
    var found := super._find_prop(level)
    if found!=null and sample_level==null:
        sample_level=level;pending=true
    return found
func _settle(frames: int) -> void:
    await super._settle(frames)
    if pending and frames==SETTLE_FRAMES and is_instance_valid(sample_level):
        pending=false
        var camera := get_viewport().get_camera_2d()
        var target := sample_level._lighting._target
        var prompts := 0
        for node in sample_level.find_children("*","",true,false):
            if node is WorldPrompt and node.is_visible_in_tree():prompts+=1
        var held := target==camera and is_equal_approx(target.global_position.x,camera.global_position.x)
        _check(held and prompts==0,"actual light observer follows camera and no hidden-player world prompts")
        print("BG25_OBSERVER ",JSON.stringify({"target_x":target.global_position.x,"camera_x":camera.global_position.x,"camera_zone":sample_level._lighting.zone_id_at(camera.global_position.x),"target_zone":sample_level._lighting.zone_id_at(target.global_position.x),"visible_prompts":prompts,"held":held}))
