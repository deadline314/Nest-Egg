from pathlib import Path
import hashlib,json,os,subprocess

primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg25-current');out=base/'native';out.mkdir(exist_ok=False)
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
assert all((root/p).read_bytes().replace(b'\r\n',b'\n')==(primary/p).read_bytes().replace(b'\r\n',b'\n') for p in paths),'capture must match current primary'
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
cases=[('bucket','ch1_pawnshop','pawnshop_front__leak_bucket',10),('barrel','ch1_rooftop','rooftop__rain_collecting_barrel',10),('kettle','ch1_pawnshop','pawnshop_kitchen__kettle_stove',0),('pipe','ch1_booth_alley','anchor_phone_booth__gutter_downpipe',0),('chain','ch1_warehouse','dock_warehouse__hoist_chain',0),('paper-lamp','ch1_pawnshop','pawnshop_kitchen__paper_shade_lamp',0),('lantern','ch1_stall','dawn_noodle_stall__hanging_lantern',0),('plant','ch1_lounge','revival_lounge__corner_plant_string_lights',0),('antenna','ch1_rooftop','rooftop__antenna_forest',0),('wire','ch1_street','harbor_street__pole_wire_knot',0),('manhole','ch1_street','harbor_street__steam_manhole',0),('umbrella-tea','ch1_rooftop','rooftop__torn_umbrella_tea',0)]
for name,level,prop,reentries in cases:
    for quality in (['low','medium','high'] if name in ['bucket','barrel','kettle','pipe'] else ['high']):
        folder=out/(name+'-'+quality);folder.mkdir();env=os.environ.copy()
        for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
        times='0,0.12,0.24,0.38,0.54,0.7,1.7,1.82,2.08,2.4' if name=='bucket' else '0,0.2,0.4,0.8,1.2'
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://tools/scene_motion_probe.tscn','--','--out='+str(folder),'--level='+level,'--prop='+prop,'--quality='+quality,'--reentries='+str(reentries if quality=='high' else 0),'--times='+times,'--tag='+name]
        with (folder/'raw.log').open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        raw=(folder/'raw.log').read_bytes();row={'name':name,'quality':quality,'command':command,'exit':result.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'images':len(list(folder.glob('*.png')))};runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
        print(name,quality,row['exit'],row['script_errors'],row['images'],flush=True)
        assert row['exit']==row['script_errors']==0 and row['source_held'],row
        report=json.loads((folder/(name+'-report.json')).read_text());assert report['failures']==0 and len(report['shots'])==row['images'] and row['images']==len(times.split(','))
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'all_passed':True,'source_held':before==snapshot(),'runs':len(runs),'images':sum(r['images'] for r in runs)},indent=2)+'\n')
print('BG25_NATIVE complete',len(runs),sum(r['images'] for r in runs),flush=True)
