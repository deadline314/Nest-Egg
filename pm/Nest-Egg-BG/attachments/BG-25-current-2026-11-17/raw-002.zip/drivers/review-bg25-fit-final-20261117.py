from pathlib import Path
import hashlib,json
from PIL import Image,ImageDraw
base=Path('D:/NestEggVerification/evidence-20261117/bg25-current');assert json.loads((base/'native-fit-final/result.json').read_text())['all_passed']
out=base/'review-fit-final';out.mkdir(exist_ok=False);records=[]
groups=[]
for row in json.loads((base/'native-fit-final/runs.json').read_text()):
    folder=base/'native-fit-final'/(row['name']+'-'+row['quality']);report=json.loads((folder/(row['name']+'-report.json')).read_text());groups.append((row['name']+'-'+row['quality'],[(folder/s['file'],str(round(s['time'],2))+'s '+s['drip_stage']+' '+str({k:round(v,3) for k,v in s['clocks'].items()})) for s in report['shots']]))
for quality in ['low','medium','high']:
    folder=base/'contexts-final'/quality;report=json.loads((folder/'context-report.json').read_text());groups.append(('context-'+quality,[(folder/s['file'],s['file']+' clock='+str(round(s['clock'],3))) for s in report['shots']]))
for name in ['chain-flat','antenna-flat','wire-flat']:
    folder=base/'fixed-points'/name;groups.append((name,[(p,'FLAT DIAGNOSTIC '+p.name) for p in sorted(folder.glob('*.png'))]))
folder=base/'chapter/route';groups.append(('chapter',[(folder/c['file'],c['file']+' quality='+str(c['quality'])) for c in json.loads((base/'chapter/runs.json').read_text())[0]['captures']]))
for name,shots in groups:
    for start in range(0,len(shots),6):
        subset=shots[start:start+6];board=Image.new('RGB',(1280,3*384),(18,18,22));draw=ImageDraw.Draw(board);page=name+('-p%d'%(start//6+1) if len(shots)>6 else '')+'.png'
        for i,(p,label) in enumerate(subset):
            with Image.open(p) as im:
                assert im.size==(1280,720);x=(i%2)*640;y=(i//2)*384;board.paste(im.resize((640,360)),(x,y+24));draw.text((x+4,y+5),label,fill='white')
            records.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'review':page})
        board.save(out/page)
(out/'inputs.json').write_text(json.dumps(records,indent=2)+'\n');print('BG25_REVIEW_FINAL',len(records),'native inputs',len(list(out.glob('*.png'))),'pages',flush=True)
