from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile
base=Path('D:/NestEggVerification/evidence-20261117/bg25-current');out=base/'delivery-packet';out.mkdir(exist_ok=False)
assert json.loads((base/'native-fit-final/result.json').read_text())['all_passed']
assert json.loads((base/'perf/result.json').read_text())['source_held']
files={}
def tree(prefix,images=True):
    for parent,dirs,names in os.walk(base/prefix):
        dirs[:]=sorted(d for d in dirs if d.lower() not in ['private-profile','app_userdata','user','user-data'] and not d.startswith('data_'))
        for name in sorted(names):
            p=Path(parent)/name
            if images or p.suffix in ['.json','.log','.gd','.tscn','.py']:files[p.relative_to(base).as_posix()]=p
for prefix in ['native-fit-final','contexts-final','chapter-focused-final','chapter-final','chapter','directory-control','fixed-points','environment-controls','perf','affected-final','affected-complete','affected-focused-final','local-tests']:
    tree(prefix)
for prefix in ['native','native-final','contexts','affected']:
    tree(prefix,False)
for prefix,name in [('native/chain-high','chain-t0000.png'),('native/wire-high','wire-t0000.png'),('native/antenna-high','antenna-t0000.png')]:
    p=base/prefix/name;files[p.relative_to(base).as_posix()]=p
files['review/inputs.json']=base/'review-complete/inputs.json'
files['source-history/context_scene_motion_probe.gd']=base/'framing-preparation/before.gd'
paths=['tools/scene_motion_probe.gd','tools/environment_motion_probe.gd','design/19-world-item-art/ENVIRONMENT_MOTION.md']
for p in paths:files['source/'+p]=Path(p)
for p in Path('work').glob('*bg25*20261117.py'):files['drivers/'+p.name]=p
for folder in Path('D:/NestEggVerification/ne218-baseline-20261117/work').glob('bg25*'):
    for p in folder.rglob('*'):
        if p.is_file() and p.suffix in ['.gd','.tscn','.py']:files['producer/'+folder.name+'/'+p.relative_to(folder).as_posix()]=p
files=dict(sorted(files.items()));assert len(files)==len({n.casefold() for n in files})
archives=[];archive=None;record=None;total=0
def close():
    if archive:
        archive.close();p=out/record['file'];record.update(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest());archives.append(record)
for name,path in files.items():
    size=path.stat().st_size;assert size<45_000_000
    if archive is None or total+size>45_000_000:
        close();filename='raw-%03d.zip'%(len(archives)+1);archive=zipfile.ZipFile(out/filename,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6);record={'file':filename,'members':[]};total=0
    raw=path.read_bytes();archive.writestr(name,raw);record['members'].append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()});total+=size
close();(out/'archives.json').write_text(json.dumps({'archives':archives,'file_count':len(files)},indent=2)+'\n')
generic=Path('pm/Nest-Egg-BG/attachments/BG-20-current-2026-11-17/verify.py').read_text().split("before = data('final/source-before.json')",1)[0]
(out/'verify.py').write_text(generic+Path('work/bg25-reader-tail.py').read_text(),encoding='utf8',newline='\n')
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-X','utf8',str(out/'verify.py'),str(out)]
with (out/'verification.log').open('wb') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,(out/'verification.log').read_text()
negative=base/'reader-corrupt';negative.mkdir(exist_ok=False);first=archives[0]['file'];shutil.copyfile(out/first,negative/first);shutil.copyfile(out/'archives.json',negative/'archives.json')
with (negative/first).open('r+b') as stream:
    stream.seek(20);v=stream.read(1);stream.seek(20);stream.write(bytes([v[0]^1]))
r=subprocess.run(command[:-1]+[str(negative)],capture_output=True);(negative/'raw.log').write_bytes(r.stdout+r.stderr);assert r.returncode!=0 and b'archive bytes' in r.stderr
(out/'reader-control.json').write_text(json.dumps({'actual_zip_byte_flip_rejected':True,'exit':r.returncode},indent=2)+'\n')
print('BG25_PACKET',len(files),len(archives),sum(r['bytes'] for r in archives),'verified; corruption rejected',flush=True)
