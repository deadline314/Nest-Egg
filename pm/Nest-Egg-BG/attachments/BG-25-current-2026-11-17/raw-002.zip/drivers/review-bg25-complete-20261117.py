from pathlib import Path
import hashlib,json,shutil
from PIL import Image,ImageDraw
base=Path('D:/NestEggVerification/evidence-20261117/bg25-current');chapter=base/'chapter-focused-final';assert json.loads((chapter/'result.json').read_text())['all_passed']
old=base/'review-fit-final';out=base/'review-complete';out.mkdir(exist_ok=False)
records=[r for r in json.loads((old/'inputs.json').read_text()) if '/chapter/' not in r['file'].replace('\\','/')]
pages=[]
for p in old.glob('*.png'):
    if not p.name.startswith('chapter-'):
        shutil.copyfile(p,out/p.name);assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256((out/p.name).read_bytes()).digest();pages.append(p.name)
shots=json.loads((chapter/'runs.json').read_text())[0]['captures']
for start in range(0,len(shots),6):
    board=Image.new('RGB',(1280,1152),(18,18,22));draw=ImageDraw.Draw(board);page='chapter-p%d.png'%(start//6+1)
    for i,row in enumerate(shots[start:start+6]):
        p=chapter/'route'/row['file'];x=(i%2)*640;y=(i//2)*384
        with Image.open(p) as im:assert im.size==(1280,720);board.paste(im.resize((640,360)),(x,y+24))
        draw.text((x+4,y+5),row['file']+' quality='+str(row['quality']),fill='white');records.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'review':page})
    board.save(out/page)
assert len(records)==176 and len(pages)==32
(out/'inputs.json').write_text(json.dumps(records,indent=2)+'\n');(out/'unchanged-reviewed-pages.json').write_text(json.dumps({'exact_reused_pages':pages,'new_pages_to_view':['chapter-p1.png','chapter-p2.png','chapter-p3.png'],'scope':'Prior35pages were actually viewed; only13chapter originals are replaced after actual prop camera focus correction. Other32page bytes unchanged.'},indent=2)+'\n')
print('BG25_COMPLETE_REVIEW 32 exactly reused pages +3 new chapter pages',flush=True)
