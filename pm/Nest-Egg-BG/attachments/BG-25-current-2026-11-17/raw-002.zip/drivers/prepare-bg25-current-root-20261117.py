from pathlib import Path
import hashlib,json,subprocess

primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg25-preparation/align-root-011-candidate');out.mkdir(exist_ok=False)
def git(cwd,*args):
    result=subprocess.run(['git','-c','core.packedGitLimit=128m','-c','core.packedGitWindowSize=32m','-c','core.deltaBaseCacheLimit=64m','-c','pack.threads=1','-c','pack.window=0',*args],cwd=cwd,capture_output=True,check=True)
    with (out/'git.log').open('ab') as log:log.write(result.stdout+result.stderr)
    return result.stdout
assert git(root,'rev-parse','HEAD').decode().strip()=='fe1c1b9a5e044057e0a0d7ce046dd43b66a24e89'
dirty=git(root,'diff','--name-only','-z').decode().rstrip('\0').split('\0')
assert set(dirty)=={'game/props/fixture_art.gd','tests/suite/test_environment.gd'},dirty
for p in dirty:
    raw=(root/p).read_bytes();assert raw.replace(b'\r\n',b'\n')==git(primary,'show','011cfed6d81b74acc9c101d3d7a2e839c5373bd3:'+p).replace(b'\r\n',b'\n')
    backup=out/'published-before'/p;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(raw)
git(root,'restore','--source=HEAD','--',*dirty)
git(root,'checkout','011cfed6d81b74acc9c101d3d7a2e839c5373bd3')
paths=[p for p in git(primary,'ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot').decode().split('\0') if p and (primary/p).is_file()]+['data/lighting/legacy_reclaimer.tres']
candidate=set(json.loads((primary/'work/bg17-source-paths-final.json').read_text()));assert len(candidate)==24
changes=[]
for p in paths:
    actual=(root/p).read_bytes() if (root/p).exists() else None;want=(primary/p).read_bytes()
    if actual!=want:
        assert p in candidate or actual is not None and actual.replace(b'\r\n',b'\n')==want.replace(b'\r\n',b'\n'),p
        changes.append((p,actual,want))
for p,actual,want in changes:
    if actual is not None:
        backup=out/'before'/p;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(actual)
    target=root/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(want)
assert all((root/p).read_bytes()==(primary/p).read_bytes() for p in paths)
(out/'result.json').write_text(json.dumps({'head':git(root,'rev-parse','HEAD').decode().strip(),'source_count':len(paths),'all_primary_bytes_equal':True,'copied_paths':[p for p,a,w in changes],'candidate_paths':sorted(candidate),'import_required_before_any_native':True,'scope':'Offline preparation for next BG25 ticket only. Published BG21 two edits preserved before checkout; current24-path BG17 candidate aligned. Root and active BG17 native checkouts untouched. No engine/import/lock/queue/generation started; no claim cached textures are current yet.'},indent=2)+'\n')
print('BG25_CAPTURE_PREP',len(paths),'exact primary canonical files; proper import still required before native',flush=True)
