from pathlib import Path
import hashlib,json,os,statistics,subprocess
root=Path('D:/NestEggVerification/ne218-baseline-20261117');primary=Path('C:/Users/stanl/Github/Nest-Egg');out=Path('D:/NestEggVerification/evidence-20261117/bg25-current/perf');out.mkdir(exist_ok=False)
private=root/'work/bg25-perf';private.mkdir(exist_ok=False)
(private/'memory.py').write_text('''import ctypes,json,sys
from ctypes import wintypes
class Counters(ctypes.Structure):
    _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(n,ctypes.c_size_t) for n in ['PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage','PrivateUsage']]
kernel=ctypes.WinDLL('kernel32',use_last_error=True);psapi=ctypes.WinDLL('psapi',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
kernel.CloseHandle.argtypes=[wintypes.HANDLE];psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(Counters),wintypes.DWORD]
handle=kernel.OpenProcess(0x1000|0x10,False,int(sys.argv[1]));assert handle,ctypes.get_last_error()
try:
    c=Counters();c.cb=ctypes.sizeof(c);assert psapi.GetProcessMemoryInfo(handle,ctypes.byref(c),c.cb),ctypes.get_last_error()
    print(json.dumps({'pid':int(sys.argv[1]),'working_set_bytes':c.WorkingSetSize,'private_bytes':c.PrivateUsage,'peak_working_set_bytes':c.PeakWorkingSetSize}))
finally:kernel.CloseHandle(handle)
''',encoding='utf8')
(private/'probe.gd').write_text('''extends "res://tools/scene_motion_probe.gd"
func _median(values: Array[float]) -> float:
    var stats := _stats()
    var output: Array = []
    var error := OS.execute("D:/ComfyUI/.venv-rocm/Scripts/python.exe",PackedStringArray(["-X","utf8","D:/NestEggVerification/ne218-baseline-20261117/work/bg25-perf/memory.py",str(OS.get_process_id())]),output,true)
    _check(error==0,"actual own Godot process memory read after frame timing")
    print("BG25_ACTIVE_STATS ",JSON.stringify(stats))
    print("BG25_WINDOWS_MEMORY ","".join(output))
    print("BG25_PERF_SAMPLES ",JSON.stringify(values))
    return super._median(values)
''',encoding='utf8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg25-perf/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
assert all((root/p).read_bytes().replace(b'\r\n',b'\n')==(primary/p).read_bytes().replace(b'\r\n',b'\n') for p in paths)
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
def presence():
    raw=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -like '*Godot*' } | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"],text=True).strip()
    d=json.loads(raw) if raw else [];return d if isinstance(d,list) else [d]
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name,level,prop in [('bucket','ch1_pawnshop','pawnshop_front__leak_bucket'),('barrel','ch1_rooftop','rooftop__rain_collecting_barrel')]:
    for quality in ['low','high']:
        for order,mode in enumerate(['on','off','off','on'],1):
            folder=out/('%s-%s-%d-%s'%(name,quality,order,mode));folder.mkdir();env=os.environ.copy()
            for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
            workload=presence();assert not workload,'Other Godot presence: retain waiting state, do not start timing'
            command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg25-perf/probe.tscn','--','--out='+str(folder),'--level='+level,'--prop='+prop,'--quality='+quality,'--reentries=0','--times=0','--tag=perf']+(['--no-motion'] if mode=='off' else [])
            with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
            raw=(folder/'raw.log').read_bytes();fields={}
            for key in ['BG25_ACTIVE_STATS','BG25_WINDOWS_MEMORY','BG25_PERF_SAMPLES']:
                found=[json.loads(line.split((key+' ').encode(),1)[1]) for line in raw.splitlines() if line.startswith((key+' ').encode())];assert len(found)==1,(key,raw[-300:]);fields[key]=found[0]
            after_workload=presence();row={'name':name,'quality':quality,'order':order,'mode':mode,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'workload_before':workload,'workload_after':after_workload,**fields};runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(name,quality,order,mode,'median',statistics.median(fields['BG25_PERF_SAMPLES']),flush=True)
            report=json.loads((folder/'perf-report.json').read_text());assert row['exit']==row['script_errors']==0 and row['source_held'] and not after_workload and report['failures']==0 and len(fields['BG25_PERF_SAMPLES'])==180
summary=[]
for name in ['bucket','barrel']:
    for quality in ['low','high']:
        rows=[r for r in runs if r['name']==name and r['quality']==quality];groups={m:[r for r in rows if r['mode']==m] for m in ['on','off']};stat={m:{'frame_median_ms':statistics.mean(statistics.median(r['BG25_PERF_SAMPLES']) for r in rs),'windows_working_set_bytes':[r['BG25_WINDOWS_MEMORY']['working_set_bytes'] for r in rs],'windows_private_bytes':[r['BG25_WINDOWS_MEMORY']['private_bytes'] for r in rs],'renderer_texture_bytes':[r['BG25_ACTIVE_STATS']['texture_bytes'] for r in rs],'engine_static_bytes':[r['BG25_ACTIVE_STATS']['static_bytes'] for r in rs]} for m,rs in groups.items()};summary.append({'prop':name,'quality':quality,'ratio':stat['on']['frame_median_ms']/stat['off']['frame_median_ms'],'values':stat})
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'runs':len(runs),'summaries':summary,'scope':'Same current code, original no-motion option removes LocalDrip/LocalWaterFlow only; pre-existing ripples, sway, flicker, rain and other actors remain. ABBA on/off/off/on,180 actual intervals each, vsync off. Own Windows process working-set/private bytes read only AFTER timing while level alive, renderer texture accounting separately; neither dedicated VRAM nor all-animation-off. Godot presence audit, no claim OS background services absent.'},indent=2)+'\n')
print('BG25_PERF complete',flush=True)
