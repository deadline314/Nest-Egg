from pathlib import Path
import hashlib,json,os,subprocess
root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg25-current');out=base/'fixed-points';out.mkdir(exist_ok=False);private=root/'work/bg25-fit-native'
(private/'before.gd').write_bytes((base/'framing-preparation/before.gd').read_bytes())
observer=(private/'probe.gd').read_text().replace('extends "res://tools/scene_motion_probe.gd"','extends "res://work/bg25-fit-native/before.gd"')
(private/'before-observer.gd').write_text(observer,encoding='utf8',newline='\n');(private/'before-observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg25-fit-native/before-observer.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=root).decode().split('\0') if p and (root/p).is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name,level,prop,expected in [('old-wire-cropped','ch1_street','harbor_street__pole_wire_knot',1),('chain-flat','ch1_warehouse','dock_warehouse__hoist_chain',0),('antenna-flat','ch1_rooftop','rooftop__antenna_forest',0),('wire-flat','ch1_street','harbor_street__pole_wire_knot',0)]:
    folder=out/name;folder.mkdir();env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    scene='before-observer' if expected else 'probe'
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg25-fit-native/'+scene+'.tscn','--','--out='+str(folder),'--level='+level,'--prop='+prop,'--quality=high','--reentries=0','--times='+('0' if expected else '0,1.3,2.8,4.2,5.8'),'--tag=anchors']+([] if expected else ['--flat'])
    with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();framing=[json.loads(line.split(b'BG25_FRAMING ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG25_FRAMING ')]
    row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'framing':framing,'images':len(list(folder.glob('*.png'))),'scope':'Old fixed-zoom counter is actual light; positive full-object anchor views deliberately use flat diagnostic CanvasModulate, not actual-light or character-exposure acceptance.'};runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(name,r.returncode,row['images'],framing,flush=True)
    assert r.returncode==expected and row['script_errors']==0 and row['source_held'] and len(framing)==1 and framing[0]['entire_prop_visible']==(expected==0)
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':True,'all_expected_exits':True,'diagnostic_images':15,'actual_clipped_counter':1},indent=2)+'\n')
