from pathlib import Path
import json,os,subprocess
root=Path('D:/NestEggVerification/ne218-baseline-20261117');out=Path('D:/NestEggVerification/evidence-20261117/bg25-current/directory-control');out.mkdir(exist_ok=False)
block=out/'parent-file';block.write_text('owned mkdir negative control')
env=os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg25-chapter-current/capture-failure.tscn','--','--out='+str(block/'child')]
with (out/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
raw=(out/'raw.log').read_bytes();row={'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'specific_mkdir_error':b'[EnvironmentMotionProbe] Cannot create output' in raw,'actual_png_files':len([p for p in out.glob('*.png') if p.is_file()]),'scope':'Actual parent is a file, so recursive mkdir must fail. Earlier existing-output-file case was correctly rejected later by capture with exit1; driver incorrectly expected2 and counted a denied.png directory as an image. Successful thirteen-image route is retained without rerunning it.'};(out/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True);assert row['exit']==2 and row['script_errors']==0 and row['specific_mkdir_error']
chapter=out.parent/'chapter';before=json.loads((chapter/'source-before.json').read_text())
import hashlib
after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in before};assert before==after
(chapter/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
(chapter/'result.json').write_text(json.dumps({'source_held':True,'route_images':13,'actual_route_exit':0,'actual_script_errors':0,'capture_negative_exit':1,'existing_output_file_negative_exit':1,'recursive_mkdir_negative_exit':2,'earlier_driver_assertion_failed':True,'actual_successful_route_reused':True,'all_required_behaviors_passed':True},indent=2)+'\n')
