from pathlib import Path
import hashlib,json,os,subprocess
root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg25-preparation/import');out.mkdir(exist_ok=False)
assert json.loads((out.parent/'align-root-011-candidate/result.json').read_text())['all_primary_bytes_equal']
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=root).decode().split('\0') if p and (root/p).is_file()]+['data/lighting/legacy_reclaimer.tres']
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
sidecars={p:(root/p).read_bytes() for p in paths if p.endswith('.import')}
env=os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--headless','--editor','--import','--audio-driver','Dummy']
with (out/'raw.log').open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
editor=snapshot();changed=[p for p in paths if before[p]!=editor[p]];restored=[]
(out/'source-editor-after.json').write_text(json.dumps(editor,indent=2)+'\n')
for p in changed:
    raw=(root/p).read_bytes()
    assert p in sidecars and raw.replace(b'\r\n',b'\n')==sidecars[p].replace(b'\r\n',b'\n'),p
    backup=out/'editor-normalized'/p;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(raw)
    (root/p).write_bytes(sidecars[p]);restored.append(p)
after=snapshot();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
raw=(out/'raw.log').read_bytes();record={'command':command,'exit':result.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held_after_newline_restoration':before==after,'editor_newline_only_paths':restored,'source_count':len(paths),'scope':'Natural import of exact current root candidate in separate owned capture checkout; preserve all editor bytes and restore only proven newline changes before native runs. Private historical work preserved outside checkout; shared model server untouched.'}
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n');print(record,flush=True)
assert result.returncode==record['script_errors']==0 and record['source_held_after_newline_restoration']
