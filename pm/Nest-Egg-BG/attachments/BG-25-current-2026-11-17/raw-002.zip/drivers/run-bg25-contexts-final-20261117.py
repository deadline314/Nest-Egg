from pathlib import Path
import hashlib,json,os,subprocess
root=Path('D:/NestEggVerification/ne218-baseline-20261117');primary=Path('C:/Users/stanl/Github/Nest-Egg');out=Path('D:/NestEggVerification/evidence-20261117/bg25-current/contexts-final');out.mkdir(exist_ok=False)
private=root/'work/bg25-contexts-final';private.mkdir(exist_ok=False)
(private/'probe.gd').write_text('''extends "res://tools/scene_motion_probe.gd"
var shots: Array[Dictionary] = []
var damage_events := 0
func _shot(file: String, drip: LocalDrip) -> void:
    await RenderingServer.frame_post_draw
    _check(Capture.image(get_viewport()).save_png(_out.path_join(file+".png"))==OK,"save "+file)
    shots.append({"file":file+".png","clock":drip.clock,"stage":String(drip.stage()),"paused":get_tree().paused,"from":[drip._from.x,drip._from.y],"to":[drip._to.x,drip._to.y],"z":drip.get_parent().z_index})
func _until(drip: LocalDrip,at: float) -> bool:
    var deadline := Time.get_ticks_msec()+15000
    while drip.clock<at and Time.get_ticks_msec()<deadline:await get_tree().process_frame
    return _check(drip.clock>=at,"actual motion clock reaches "+str(at))
func _run() -> void:
    add_child(LightKit.create_environment())
    var previous := Settings.get_light_quality()
    Settings.set_light_quality(QUALITY[_quality])
    Story.auto_skip=true
    var level := await _open_level()
    var prop := _find_prop(level)
    if not _check(prop!=null,"actual placed bucket exists"):
        await _finish({},previous)
        return
    var drip := prop.get_node_or_null("LocalDrip") as LocalDrip
    if not _check(drip!=null,"original drip component exists"):
        await _finish({},previous)
        return
    var camera := get_viewport().get_camera_2d() as LevelCamera
    camera.set_physics_process(false)
    camera.offset=Vector2.ZERO
    camera.zoom=Vector2.ONE*LevelCamera.base_zoom()*2.0
    camera.global_position=prop.global_position+prop.data.size*.5
    camera.reset_smoothing();camera.force_update_scroll()
    level._lighting._target=camera
    await _settle(20)
    drip.clock=0.0
    await _shot("cycle-start",drip)
    for at in [.2,.48,1.0,1.64]:
        if not await _until(drip,at):
            await _finish({"shots":shots},previous)
            return
        await _shot("cycle-"+str(int(at*100)),drip)
    var before := drip.clock
    var deadline := Time.get_ticks_msec()+15000
    while drip.clock>=before and Time.get_ticks_msec()<deadline:await get_tree().process_frame
    _check(drip.clock<.2,"original fmod crosses into next falling cycle")
    await _shot("cycle-after-wrap",drip)
    await _until(drip,.48)
    await _shot("cycle-second-splash",drip)
    var player := level.player
    var feet := Vector2(prop.global_position.x-40,prop.global_position.y+prop.data.size.y-2)
    _check(level._layout.fits_body(feet,Player.BODY_SIZE),"arranged player fits actual ground")
    player.global_position=feet;player.velocity=Vector2.ZERO;player.show();player.process_mode=Node.PROCESS_MODE_INHERIT
    player.health.setup(999,0.0)
    for node in level.find_children("*","",true,false):
        if node is WorldPrompt:
            node.enabled=true;node.set_process(true)
    for node in level.find_children("*","Node2D",true,false):
        if node is NpcActor and node.data.kind==NpcData.Kind.PERSON:node.hide()
    camera.zoom=Vector2.ONE*LevelCamera.base_zoom()
    camera.global_position=prop.global_position+prop.data.size*.5;camera.force_update_scroll()
    var enemy := level._create_enemy(load("res://data/enemies/grunt.tres"))
    enemy.position=Vector2(prop.global_position.x+65,feet.y)
    level._entities.add_child(enemy)
    _check(level._layout.fits_body(enemy.global_position,enemy.data.body_size),"arranged actual enemy fits actual ground")
    enemy.health.damaged.connect(func(_info: DamageInfo) -> void: damage_events+=1)
    await _settle(20)
    var transform := get_viewport().get_final_transform()*get_viewport().get_canvas_transform()
    Input.warp_mouse(transform*(enemy.global_position-Vector2(0,20)))
    Input.action_press(&"shoot")
    for i in 3:
        await get_tree().create_timer(.15).timeout
        await _shot("combat-"+str(i),drip)
    Input.action_release(&"shoot")
    _check(player.is_visible_in_tree() and not player.is_dead(),"actual player remains visible and alive")
    var live := is_instance_valid(enemy) and not enemy.is_queued_for_deletion()
    print("BG25_COMBAT ",JSON.stringify({"damage_events":damage_events,"enemy_still_valid":live,"player_visible":player.is_visible_in_tree(),"hp":player.health.current}))
    for node in get_tree().get_nodes_in_group(&"enemies"):node.queue_free()
    await _settle(5)
    var person: NpcActor
    for node in level.find_children("*","Node2D",true,false):
        if node is NpcActor and node.data.kind==NpcData.Kind.PERSON:
            person=node;break
    if _check(person!=null,"actual original Old K available"):
        person.global_position=Vector2(prop.global_position.x+40,feet.y)
        person.show()
        Story.auto_skip=false
        Story._layer.show()
        person._talk.call_deferred()
        await _settle(90)
        var active := Story.is_cinematic_active()
        _check(active,"actual NPC dialogue active")
        await _shot("dialogue",drip)
        print("BG25_DIALOGUE ",JSON.stringify({"active":active,"source_id":person.state_key(),"paused":get_tree().paused,"player_visible":player.is_visible_in_tree(),"person_visible":person.is_visible_in_tree()}))
        Story.reset_active_presentation(&"verification_end")
        await _settle(5)
    get_tree().paused=false
    level.queue_free();await _settle(8)
    await _finish({"shots":shots,"damage_events":damage_events,"scope":"Arranged actual player/enemy and original NPC around actual bucket; public shooting input and actual NPC talk. Starts at clock0 then natural wrap, no timer rescaling. Actor positions arranged and player999HP; not human chapter completion."},previous)
''',encoding='utf8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg25-contexts-final/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for quality in ['low','medium','high']:
    folder=out/quality;folder.mkdir();env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','--quit-after','6000','res://work/bg25-contexts-final/probe.tscn','--','--out='+str(folder),'--level=ch1_pawnshop','--prop=pawnshop_front__leak_bucket','--quality='+quality,'--reentries=0','--tag=context']
    with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();row={'quality':quality,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'images':len([p for p in folder.glob('*.png') if p.is_file()])};runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(quality,row,flush=True)
    assert row['exit']==row['script_errors']==0 and row['source_held'] and (folder/'context-report.json').exists()
    report=json.loads((folder/'context-report.json').read_text());assert report['failures']==0 and len(report['shots'])==row['images']==11
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':True,'all_passed':True,'images':33},indent=2)+'\n')
