from pathlib import Path
import hashlib,json,os,subprocess
root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg25-current')
base.mkdir(exist_ok=False);out=base/'environment-controls';out.mkdir()
private=root/'work/bg25-current-preparation'
original=(root/'tools/scene_motion_probe.gd').read_text(encoding='utf8')
(private/'scene-before.gd').write_text(original,encoding='utf8',newline='\n')
for name,target in [('before','scene-before'),('fixed','scene_motion_probe'),('save-failure','scene_motion_probe')]:
    code='''extends "res://work/bg25-current-preparation/TARGET.gd"
func _open_level() -> Level:
    var result := await super._open_level()
    var environments := get_tree().root.find_children("*", "WorldEnvironment", true, false)
    print("BG25_ENV ", JSON.stringify({"count":environments.size(),"hdr_2d":get_viewport().use_hdr_2d,"glow":environments[0].environment.glow_enabled if not environments.is_empty() else false}))
    return result
'''.replace('TARGET',target)
    (private/(name+'.gd')).write_text(code,encoding='utf8',newline='\n')
    (private/(name+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg25-current-preparation/'+name+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','project.godot'],cwd=root).decode().split('\0') if p and (root/p).is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name,expected in [('before',0),('fixed',0),('save-failure',1)]:
    folder=out/name;folder.mkdir()
    if name=='save-failure':(folder/'probe-t0000.png').mkdir()
    env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg25-current-preparation/'+name+'.tscn','--','--out='+str(folder),'--level=ch1_pawnshop','--prop=pawnshop_front__leak_bucket','--quality=high','--reentries=0','--times=0','--tag=probe']
    with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();metadata=[json.loads(line.split(b'BG25_ENV ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG25_ENV ')]
    row={'case':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'environment':metadata};runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    print(name,row['exit'],row['script_errors'],metadata,flush=True)
    assert r.returncode==expected and row['script_errors']==0 and row['source_held'] and len(metadata)==1
    assert metadata[0]['hdr_2d'] and metadata[0]['count']==(0 if name=='before' else 1)
    if name!='before':assert metadata[0]['glow']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
print('BG25_ENVIRONMENT_CONTROLS complete',flush=True)
