from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');out=Path('D:/NestEggVerification/evidence-20261117/bg25-current/chapter-final');out.mkdir(exist_ok=False)
private=root/'work/bg25-chapter-final';private.mkdir(exist_ok=False)
(private/'route.gd').write_text('''extends "res://tools/environment_motion_probe.gd"
func open_chapter(id: String, tile: int) -> void:
    await super.open_chapter(id,tile)
    var fits := level._layout.fits_body(player.global_position,Player.BODY_SIZE)
    print("BG25_PLACEMENT ",JSON.stringify({"level":id,"tile":tile,"feet":[player.global_position.x,player.global_position.y],"fits_body":fits}))
    assert(fits,"original chapter sample must fit actual body")
func capture(file_name: String) -> void:
    await super.capture(file_name)
    var environments := get_tree().root.find_children("*","WorldEnvironment",true,false)
    print("BG25_CAPTURE ",JSON.stringify({"file":file_name+".png","quality":Settings.get_light_quality(),"hdr":get_viewport().use_hdr_2d,"environments":environments.size(),"glow":environments[0].environment.glow_enabled if not environments.is_empty() else false}))
''',encoding='utf8',newline='\n')
(private/'capture-failure.gd').write_text('''extends "res://tools/environment_motion_probe.gd"
func run() -> void:
    add_child(LightKit.create_environment())
    await capture("denied")
''',encoding='utf8',newline='\n')
for name in ['route','capture-failure']:
    (private/(name+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg25-chapter-final/'+name+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name,expected in [('route',0)]:
    folder=out/name;folder.mkdir();argument=folder
    if name=='capture-failure':(folder/'denied.png').mkdir()
    if name=='directory-failure':argument=folder/'not-a-directory';argument.write_text('owned output failure control')
    scene='capture-failure' if name=='directory-failure' else name
    env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg25-chapter-final/'+scene+'.tscn','--','--out='+str(argument)]
    with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();captures=[json.loads(line.split(b'BG25_CAPTURE ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG25_CAPTURE ')]
    row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'captures':captures,'images':len(list(folder.glob('*.png')))};runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(name,r.returncode,row['script_errors'],row['images'],flush=True)
    assert r.returncode==expected and row['script_errors']==0 and row['source_held']
    if name=='route':assert len(captures)==row['images']==13 and raw.count(b'BG25_SWITCH cycle=')==10 and all(c['hdr'] and c['environments']==1 for c in captures)
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':True,'route_images':13,'negative_exits':[1,2],'all_passed':True},indent=2)+'\n')

(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'all_passed':True,'actual_route_exit':0,'actual_script_errors':0,'route_images':13},indent=2)+'\n')
