from pathlib import Path
import hashlib,json,os,subprocess

primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg33-current');out=base/'before';out.mkdir(parents=True,exist_ok=False)
private=root/'work/bg33-before';private.mkdir(exist_ok=False)
(private/'observer.gd').write_text('''extends "res://tools/light_pool_probe.gd"
func _measure_lamp(image: Image,lamp: Lamp,walls: BackWallGeometry) -> Dictionary:
    var prompts := 0
    for node: Node in get_tree().root.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    print("BG33_OBSERVER ",JSON.stringify({"environments":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),
        "hdr":get_viewport().use_hdr_2d,"visible_prompts":prompts,"image_size":[image.get_width(),image.get_height()]}))
    return super._measure_lamp(image,lamp,walls)
''',encoding='utf8',newline='\n')
(private/'observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg33-before/observer.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
assert all((root/p).read_bytes().replace(b'\r\n',b'\n')==(primary/p).read_bytes().replace(b'\r\n',b'\n') for p in paths)
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name in ['normal','write-failure']:
    folder=out/name;folder.mkdir()
    if name=='write-failure':(folder/'pools-ch1_street-lamp00.png').mkdir()
    env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg33-before/observer.tscn','--','--out='+str(folder),'--level=ch1_street','--quality=high','--max=1']
    with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();observations=[json.loads(l.split(b'BG33_OBSERVER ',1)[1]) for l in raw.splitlines() if l.startswith(b'BG33_OBSERVER ')]
    row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'images':len([p for p in folder.glob('*.png') if p.is_file()]),'observations':observations,'engine_error':b'ERROR:' in raw}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert row['exit']==row['script_errors']==0 and row['source_held']
    assert observations and all(r['environments']==0 and r['hdr'] for r in observations)
    assert row['images']==(1 if name=='normal' else 0)
    if name=='write-failure':assert row['engine_error']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'missing_environment_reproduced':True,'write_false_success_reproduced':True},indent=2)+'\n')
