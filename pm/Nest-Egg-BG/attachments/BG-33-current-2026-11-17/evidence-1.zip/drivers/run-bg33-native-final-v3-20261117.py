from pathlib import Path
import hashlib,json,os,subprocess

primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg33-current');out=base/'native-final-v3';out.mkdir(exist_ok=False)
(root/'tools/light_pool_probe.gd').write_bytes((primary/'tools/light_pool_probe.gd').read_bytes())
private=root/'work/bg33-native-final-v3';private.mkdir(exist_ok=False)
(private/'observer.gd').write_text('''extends "res://tools/light_pool_probe.gd"
func _ready() -> void:
    for arg: String in OS.get_cmdline_user_args():
        if arg == "--maximum-brightness": Settings.set_brightness(1.0)
    super._ready()
func _measure_lamp(image: Image,lamp: Lamp,walls: BackWallGeometry) -> Dictionary:
    var prompts := 0
    for node: Node in get_tree().root.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    var environment := get_viewport().find_world_3d().environment
    var count := get_tree().root.find_children("*","WorldEnvironment",true,false).size()
    assert(environment != null and environment.glow_enabled and count == 1 and prompts == 0)
    print("BG33_OBSERVER ",JSON.stringify({"environments":count,"glow":environment.glow_enabled,"hdr":get_viewport().use_hdr_2d,
        "visible_prompts":prompts,"image_size":[image.get_width(),image.get_height()],"brightness":Settings.get_brightness(),"gamma":Settings.brightness_gamma(),
        "lamp":[lamp.global_position.x,lamp.global_position.y]}))
    return super._measure_lamp(image,lamp,walls)
''',encoding='utf8',newline='\n')
for name,script in [('observer','res://work/bg33-native-final-v3/observer.gd'),('inherited','res://tools/bg49_held_pool_probe.gd')]:
    (private/(name+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="'+script+'" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
assert all((root/p).read_bytes().replace(b'\r\n',b'\n')==(primary/p).read_bytes().replace(b'\r\n',b'\n') for p in paths)
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
levels=['ch1_street','ch1_warehouse','ch1_vault','ch1_rooftop','ch1_booth_alley','ch1_stall','ch1_pawnshop','ch1_lounge']
cases=[(q,'observer',q,levels,0) for q in ['low','medium','high']]+[('maximum-brightness','observer','high',['ch1_warehouse','ch1_vault'],0),('write-failure','observer','high',['ch1_street'],1)]
for name,scene,quality,selected,expected in cases:
    folder=out/name;folder.mkdir()
    if name=='write-failure':(folder/'pools-ch1_street-lamp00.png').mkdir()
    env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg33-native-final-v3/'+scene+'.tscn','--','--out='+str(folder),'--level='+','.join(selected),'--quality='+quality,'--max='+('1' if name in ['write-failure','maximum-brightness'] else '40')]
    if name=='maximum-brightness':command.append('--maximum-brightness')
    with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();observations=[json.loads(l.split(b'BG33_OBSERVER ',1)[1]) for l in raw.splitlines() if l.startswith(b'BG33_OBSERVER ')]
    row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'images':len([p for p in folder.glob('*.png') if p.is_file()]),'observations':observations,'engine_error':b'ERROR:' in raw}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k not in ['observations','command']}),flush=True)
    assert row['exit']==expected and row['script_errors']==0 and row['source_held'],row
    report=json.loads((folder/'pools-index.json').read_text());assert report['invalid_focus_samples']==0
    assert report['capture_failures']==(1 if name=='write-failure' else 0)
    if scene=='observer':
        assert observations and all(r['environments']==1 and r['glow'] and r['hdr'] and r['visible_prompts']==0 and r['image_size']==[1280,720] for r in observations)
        assert all(l['flags_unchanged'] for l in report['levels'].values())
    else:
        assert b'"bloom_valid": true' in raw or b'"bloom_valid":true' in raw,raw[-2000:]
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'all_passed':True,'source_held':before==snapshot(),'images':sum(r['images'] for r in runs)},indent=2)+'\n')
