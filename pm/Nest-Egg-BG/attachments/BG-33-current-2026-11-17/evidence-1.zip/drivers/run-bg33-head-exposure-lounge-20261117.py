from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg33-current/head-exposure-lounge');out.mkdir(exist_ok=False)
private=root/'work/bg33-head-exposure-lounge';private.mkdir(exist_ok=False)
(private/'probe.gd').write_text('''extends "res://tools/scene_motion_probe.gd"
func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(QUALITY[_quality])
    Lamp.flicker_hold = 1.0
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var blank := "--blank-head-mask" in OS.get_cmdline_user_args()
    var level := await _open_level()
    var player := level.player
    player.show()
    player.velocity = Vector2.ZERO
    var lamps: Array[Lamp] = []
    for node: Node in level.find_children("*","",true,false):
        if node is Lamp and node.fixture_id == &"neon_tube_bracket" and not node.dead: lamps.append(node)
        if node is Enemy or node is NpcActor:
            node.hide()
            node.process_mode = Node.PROCESS_MODE_DISABLED
            for child: Node in node.find_children("*","",true,false): child.process_mode = Node.PROCESS_MODE_DISABLED
    assert(lamps.size() == 1)
    var camera := get_viewport().get_camera_2d() as LevelCamera
    camera.set_physics_process(false)
    camera.offset = Vector2.ZERO
    camera.zoom = Vector2.ONE*LevelCamera.base_zoom()*1.7
    level._lighting._target = player
    var records := []
    var failures := 0
    for index in lamps.size():
        for gap: float in [12.0,40.0,80.0]:
            player.global_position = lamps[index].global_position+Vector2(0,58+gap)
            camera.global_position = player.global_position+Vector2(0,-40)
            camera.reset_smoothing()
            camera.force_update_scroll()
            await _settle(24)
            var label := "lamp"+str(index)+"-gap"+str(int(gap))
            var result := await preload("res://tools/weapon_head_probe.gd").capture(self,level,_out,label,blank)
            result["lamp"] = [lamps[index].global_position.x,lamps[index].global_position.y]
            result["feet"] = [player.global_position.x,player.global_position.y]
            result["feet_below_source"] = 58+gap
            result["fixture_energy"] = lamps[index].light_energy
            var valid: bool = result.get("bound_valid",false) and result.get("white_ratio_upper_bound",1.0) != null and float(result.get("white_ratio_upper_bound",1.0)) <= 0.02
            if not valid: failures += 1
            records.append(result)
            if blank: break
        if blank: break
    var writer := FileAccess.open(_out.path_join("head-results.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify({"quality":_quality,"blank":blank,"failures":failures,"records":records},"\\t"))
    writer.close()
    level.queue_free()
    await _settle(8)
    await AudioRelease.settle(get_tree())
    get_tree().quit(1 if failures > 0 else 0)
''',encoding='utf8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg33-head-exposure-lounge/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name,quality,blank in [('low','low',False),('high','high',False),('blank-mask','high',True)]:
    folder=out/name;folder.mkdir();env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg33-head-exposure-lounge/probe.tscn','--','--out='+str(folder),'--level=ch1_lounge','--prop=unused','--quality='+quality]
    if blank:command.append('--blank-head-mask')
    with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot()}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert row['exit']==int(blank) and row['script_errors']==0 and row['source_held'],row
    result=json.loads((folder/'head-results.json').read_text())
    if blank:assert result['failures']==1 and result['records'][0]['opaque_head_pixels']==0 and not result['records'][0]['bound_valid']
    else:assert result['failures']==0 and len(result['records'])==3
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'unobstructed_fixed_head_bound_passed':True,'blank_mask_rejected':True},indent=2)+'\n')
