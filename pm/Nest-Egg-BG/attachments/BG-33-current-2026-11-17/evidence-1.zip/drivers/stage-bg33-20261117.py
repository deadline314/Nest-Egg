from pathlib import Path
import hashlib,json,subprocess
root=Path('C:/Users/stanl/Github/Nest-Egg');paths=json.loads((root/'work/bg33-stage-paths.json').read_text())
def git(*args):return subprocess.check_output(['git','-c','core.packedGitLimit=128m','-c','core.packedGitWindowSize=32m','-c','core.deltaBaseCacheLimit=64m','-c','pack.threads=1','-c','pack.window=0',*args],cwd=root)
assert git('diff','--cached','--name-only')==b''
assert git('rev-parse','HEAD').decode().strip()=='bb895cb10169d19496ed90e7a2a42125ee4f8417'
git('add','--',*paths)
assert set(git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0'))==set(paths)
records=[]
for path in paths:
    working=(root/path).read_bytes();blob=git('show',':'+path)
    ordinary=not path.startswith('pm/Nest-Egg-BG/attachments/') and path.endswith(('.gd','.md','.json'))
    assert blob==working or (ordinary and blob==working.replace(b'\r\n',b'\n')),path
    records.append({'path':path,'working_sha256':hashlib.sha256(working).hexdigest(),'staged_sha256':hashlib.sha256(blob).hexdigest(),'mapping':'identity' if blob==working else 'ordinary CRLF-to-LF'})
git('diff','--cached','--check')
(root/'work/bg33-staged-verification.json').write_text(json.dumps({'paths':records,'diff_check_exit':0},indent=2)+'\n')
print('BG33 exact stage',len(paths),'paths; bytes verified; whitespace clean',flush=True)
