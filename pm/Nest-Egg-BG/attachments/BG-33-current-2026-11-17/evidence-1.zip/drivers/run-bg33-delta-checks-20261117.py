from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg33-current');out=base/'delta-checks';out.mkdir(exist_ok=False)
baseline=json.loads((base/'delta-baseline/result.json').read_text())['baseline_commit']
fixture='data/environment/lamp_fixtures.json'
old=json.loads((base/'delta-baseline/passed-sources'/fixture).read_text());old['fixtures']['bulkhead_wall']['energy']=1.0
assert old==json.loads((primary/fixture).read_text())
(root/fixture).write_bytes((primary/fixture).read_bytes())
paths=list(json.loads((base/'affected-final/source-after.json').read_text()))
assert all((root/p).read_bytes().replace(b'\r\n',b'\n')==(primary/p).read_bytes().replace(b'\r\n',b'\n') for p in paths)
prior=json.loads((base/'affected-final/source-after.json').read_text())
assert [p for p in paths if hashlib.sha256((primary/p).read_bytes()).hexdigest()!=prior[p]]==[fixture]
changed=[p for p in subprocess.check_output(['git','diff','--name-only','-z','HEAD'],cwd=root).decode().split('\0') if p]
assert changed==[fixture],changed
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==baseline
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy();env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='2',LOG_DIR=str(out/'shards'),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
command=['C:/Program Files/Git/bin/bash.exe','-c','python3() { python "$@"; }; export -f python3; tools/run_tests_changed.sh '+baseline]
with (out/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'command':command,'exit':r.returncode,'source_held':before==snapshot(),'changed_runtime_paths':changed,'baseline_commit':baseline,'prior_scope':'54 original affected groups / 58374 checks on exact preceding runtime; current only delta is the preflighted bulkhead scalar. Root HEAD/index unaffected; detached capture baseline is private, not another main delivery.'}
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
assert record['exit']==0 and record['source_held']
