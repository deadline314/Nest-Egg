from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg33-current');out=b/'exit-cleanup'
prior=json.loads((b/'native-final-v3/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in prior}
before=snapshot();assert [p for p in prior if prior[p]!=before[p]]==['tools/readability_check.gd']
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for scene,spot in [('readability_check','屋頂巷弄'),('ch2_readability_check','B1 電話亭'),('ch3_readability_check','排水輪')]:
    for q in ['low','high']:
        folder=out/(scene+'-'+q);folder.mkdir(exist_ok=False);env=os.environ.copy()
        for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','res://tools/'+scene+'.tscn','--','--quality='+q,'--spots='+spot,'--out='+str(folder)]
        with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
        raw=(folder/'raw.log').read_bytes();report=json.loads((folder/'readability-report.json').read_text())
        row={'scene':scene,'quality':q,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'resource_leak':b'leaked at exit' in raw,'spots':len(report['results']),'images':len(list(folder.glob('*.png')))}
        runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
        assert row['exit']==row['script_errors']==0 and not row['engine_error'] and not row['resource_leak'] and row['spots']==row['images']==1
        assert all(x['sampling_valid'] and x['passed'] for x in report['results'])
after=snapshot();assert before==after
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':True,'clean_native_exits':6,'scope':'Unchanged original samplers; only terminal AudioRelease after report. Representative original legacy/ch2/ch3 entrypoints at low/high; previous 188 metric rows and images reused because all sampling bytes and formulas unchanged.'},indent=2)+'\n')
