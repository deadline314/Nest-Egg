from pathlib import Path
import hashlib,json,os,subprocess,zipfile

primary=Path('C:/Users/stanl/Github/Nest-Egg');capture=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg33-current');out=base/'delta-baseline';out.mkdir(exist_ok=False)
passed=json.loads((base/'affected-final/result.json').read_text());assert passed['all_passed'] and passed['source_held']
for name,key in [('readability','all_original_thresholds_passed'),('head-exposure','unobstructed_fixed_head_bound_passed')]:
    assert json.loads((base/name/'result.json').read_text())[key]
sources=json.loads((base/'affected-final/source-after.json').read_text())
assert all(hashlib.sha256((primary/p).read_bytes()).hexdigest()==h for p,h in sources.items())
assert all((capture/p).read_bytes().replace(b'\r\n',b'\n')==(primary/p).read_bytes().replace(b'\r\n',b'\n') for p in sources)
before={p:hashlib.sha256((capture/p).read_bytes()).hexdigest() for p in sources}
(out/'capture-source-before.json').write_text(json.dumps(before,indent=2)+'\n')
runtime=['data/environment/lamp_fixtures.json','data/levels/ch1_warehouse_map.json','tests/suite/test_environment.gd','tools/light_pool_probe.gd']
def git(cwd,*args,env=None):
    r=subprocess.run(['git','-c','core.packedGitLimit=128m','-c','core.packedGitWindowSize=32m','-c','core.deltaBaseCacheLimit=64m','-c','pack.threads=1','-c','pack.window=0',*args],cwd=cwd,env=env,capture_output=True)
    with (out/'git.log').open('ab') as log:log.write(r.stdout+r.stderr)
    assert r.returncode==0,(args,r.stderr.decode(errors='replace'))
    return r.stdout
assert git(primary,'diff','--cached','--name-only')==b''
assert subprocess.run(['git','symbolic-ref','-q','HEAD'],cwd=capture,capture_output=True).returncode==1
tracked=set(git(capture,'ls-files','-z').decode().split('\0'))
modified=[p for p in git(capture,'diff','--name-only','-z').decode().split('\0') if p and (capture/p).is_file()]
preserve=set(modified)
for parent,dirs,names in os.walk(capture):
    dirs[:]=[d for d in dirs if d not in ['.git','.godot']]
    for name in names:
        p=Path(parent)/name;rel=p.relative_to(capture).as_posix()
        if rel not in tracked and rel!='.git':preserve.add(rel)
manifest={}
with zipfile.ZipFile(out/'preserved-working-files.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(preserve):
        data=(capture/p).read_bytes();z.writestr(p,data);manifest[p]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
with zipfile.ZipFile(out/'preserved-working-files.zip') as z:
    assert all(len(z.read(p))==v['bytes'] and hashlib.sha256(z.read(p)).hexdigest()==v['sha256'] for p,v in manifest.items())
(out/'preserved-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
env=os.environ.copy();env['GIT_INDEX_FILE']=str(out/'temporary-index')
env.update(GIT_AUTHOR_NAME='Stanley Li',GIT_AUTHOR_EMAIL='stanley890314@gmail.com',GIT_COMMITTER_NAME='Stanley Li',GIT_COMMITTER_EMAIL='stanley890314@gmail.com')
parent=git(primary,'rev-parse','HEAD').decode().strip();assert parent=='bb895cb10169d19496ed90e7a2a42125ee4f8417'
git(primary,'read-tree',parent,env=env)
git(primary,'add','--',*runtime,env=env)
tree=git(primary,'write-tree',env=env).decode().strip()
commit=git(primary,'commit-tree',tree,'-p',parent,'-m','test: record verified lighting source snapshot',env=env).decode().strip()
for p in runtime:
    raw=git(primary,'show',commit+':'+p)
    assert raw==(primary/p).read_bytes().replace(b'\r\n',b'\n')
    target=out/'passed-sources'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((primary/p).read_bytes())
(out/'tested-candidate.patch').write_bytes(git(primary,'diff',parent,commit,'--',*runtime))
git(capture,'reset','--mixed',commit)
git(capture,'sparse-checkout','reapply')
after={p:hashlib.sha256((capture/p).read_bytes()).hexdigest() for p in sources}
assert before==after
assert all((capture/p).is_file() and hashlib.sha256((capture/p).read_bytes()).hexdigest()==v['sha256'] for p,v in manifest.items())
assert git(primary,'diff','--cached','--name-only')==b''
assert git(primary,'rev-parse','HEAD').decode().strip()==parent
changed=git(capture,'diff','--name-only','-z').decode().split('\0')
assert not any(p in sources for p in changed)
(out/'capture-source-after.json').write_text(json.dumps(after,indent=2)+'\n')
result={'baseline_commit':commit,'parent':parent,'tree':tree,'runtime_paths':runtime,'source_count':len(sources),'capture_source_held':before==after,'preserved_files':len(manifest),'primary_head_and_index_unchanged':True,'scope':'Private unpublished snapshot of the actual 54-suite passing runtime, Stanley author and committer. Advance only the already owned detached verification checkout metadata; preserve every working byte and existing sparse patterns. No remote branch or extra main delivery. Next change must be only the preflighted bulkhead scalar, so the original changed entry in this checkout selects the actual new delta.'}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
