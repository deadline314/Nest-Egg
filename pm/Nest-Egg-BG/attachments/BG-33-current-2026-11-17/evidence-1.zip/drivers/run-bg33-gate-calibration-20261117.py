from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg33-current/gate-calibration');out.mkdir(exist_ok=False)
private=root/'work/bg33-gate-calibration';private.mkdir(exist_ok=False)
(private/'probe.gd').write_text('''extends "res://tools/scene_motion_probe.gd"
func _run() -> void:
    add_child(LightKit.create_environment())
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var level := await _open_level()
    var lamp: Lamp
    var occluders: Array[LightOccluder2D] = []
    for node: Node in level.find_children("*","Node2D",true,false):
        if node is Lamp and node.fixture_id == &"bulkhead_wall": lamp = node
        if node is Gate and not node.is_open and node.is_visible_in_tree():
            for child: Node in node.get_children():
                if child is LightOccluder2D and child.occluder != null: occluders.append(child)
    assert(lamp != null)
    var records := []
    for point: Vector2 in [Vector2(1448,594),lamp.global_position]:
        var hits := []
        for occluder in occluders:
            if Geometry2D.is_point_in_polygon(occluder.to_local(point),occluder.occluder.polygon):
                var polygon := []
                for vertex: Vector2 in occluder.occluder.polygon:
                    var world := occluder.global_transform*vertex
                    polygon.append([world.x,world.y])
                hits.append({"parent_class":occluder.get_parent().get_script().get_global_name(),"path":str(occluder.get_path()),"polygon":polygon})
        records.append({"point":[point.x,point.y],"hits":hits})
    var valid: bool = not lamp.dead and lamp.is_supported() and records[0].hits.size() == 1 and records[1].hits.is_empty()
    var writer := FileAccess.open(_out.path_join("calibration.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify({"valid":valid,"lamp_alive":not lamp.dead,"supported":lamp.is_supported(),"records":records},"\\t"))
    writer.close()
    level.queue_free()
    await _settle(8)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0 if valid else 1)
''',encoding='utf8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg33-gate-calibration/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=list(json.loads(Path('D:/NestEggVerification/evidence-20261117/bg33-current/delta-checks/source-after.json').read_text()))
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg33-gate-calibration/probe.tscn','--','--out='+str(out),'--level=ch1_warehouse','--prop=unused']
with (out/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
raw=(out/'raw.log').read_bytes();record={'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot()}
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
assert record['exit']==record['script_errors']==0 and record['source_held']
print((out/'calibration.json').read_text(),flush=True)
