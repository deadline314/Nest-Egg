from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import hashlib,json
b=Path('D:/NestEggVerification/evidence-20261117/bg33-current');data=b/'readability-regression'
assert json.loads((data/'result.json').read_text())['all_original_thresholds_passed']
mapping=json.loads((data/'screenshot-map.json').read_text());out=b/'review-regression';out.mkdir(exist_ok=False)
font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',13);pages=[];critical=[]
for scene,n in [('readability_check',16),('ch2_readability_check',22),('ch3_readability_check',20)]:
    reports={q:json.loads((data/(scene+'-'+q)/'readability-report.json').read_text()) for q in ['low','high']}
    for start in range(0,n,6):
        canvas=Image.new('RGB',(1280,612),(16,16,20));draw=ImageDraw.Draw(canvas);inputs=[]
        for offset,index in enumerate(range(start,min(start+6,n))):
            for col,q in enumerate(['low','high']):
                row=reports[q]['results'][index];item=next(m for m in mapping if m['scene']==scene and m['quality']==q and m['index']==index)
                p=data/item['screenshot'];assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
                x,y=(offset%2*2+col)*320,(offset//2)*204
                image=Image.open(p);assert image.size==(640,360);canvas.paste(image.resize((320,180)),(x,y+24))
                draw.text((x+3,y+3),f"{q} {row['level']} #{index}",font=font,fill='white');inputs.append(p.relative_to(b).as_posix())
        path=out/(scene+'-'+str(start//6+1)+'.png');canvas.save(path)
        pages.append({'page':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'inputs':inputs})
    for metric in ['player_contrast','edge_contrast','enemy_contrast']:
        rows=[(r[metric],q,i,r) for q in ['low','high'] for i,r in enumerate(reports[q]['results']) if r[metric] is not None]
        v,q,i,r=min(rows,key=lambda x:x[0]);m=next(m for m in mapping if m['scene']==scene and m['quality']==q and m['index']==i)
        critical.append({'metric':metric,'value':v,'scene':scene,'path':(data/m['screenshot']).as_posix()})
(out/'index.json').write_text(json.dumps(pages,indent=2)+'\n');(out/'critical.json').write_text(json.dumps(critical,indent=2)+'\n')
print(json.dumps({'pages':pages,'critical':critical}),flush=True)
