from pathlib import Path
import collections,hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');out=Path('D:/NestEggVerification/evidence-20261117/bg33-current/readability-regression')
before=json.loads((out/'source-before.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in before}
assert snapshot()==before
runs=json.loads((out/'runs-resumed.json').read_text());assert len(runs)==5
def run(scene,q,folder,extra,expected):
    folder.mkdir(exist_ok=False);env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','res://tools/'+scene+'.tscn','--','--quality='+q,'--detail','--out='+str(folder)]+extra
    with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();report=json.loads((folder/'readability-report.json').read_text())
    row={'scene':scene,'quality':q,'folder':folder.name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'spots':len(report['results']),'images':len(list(folder.glob('*.png')))}
    runs.append(row);(out/'runs-final.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert row['exit']==row['script_errors']==0 and row['source_held'] and row['spots']==expected
    assert row['images']==len({r['screenshot'] for r in report['results']})
    assert report['thresholds']=={'player':0.6,'edge':1.0,'enemy':0.45} and all(r['sampling_valid'] and r['passed'] for r in report['results'])
run('ch3_readability_check','high',out/'ch3_readability_check-high',[],20)
mapping=[];supplements=[]
for scene,n in [('readability_check',16),('ch2_readability_check',22),('ch3_readability_check',20)]:
    for q in ['low','high']:
        folder=out/(scene+'-'+q);report=json.loads((folder/'readability-report.json').read_text());assert len(report['results'])==n
        by_file=collections.defaultdict(list)
        for i,row in enumerate(report['results']):by_file[row['screenshot']].append(i)
        for index,row in enumerate(report['results']):
            shot=folder/row['screenshot']
            if index!=by_file[row['screenshot']][-1]:
                sub=out/(scene+'-'+q+'-supplement-'+str(index))
                run(scene,q,sub,['--spots='+row['spot']],1);shot=sub/row['screenshot']
                supplements.append({'folder':sub.name,'original_index':index,'spot':row['spot']})
            assert shot.is_file()
            mapping.append({'scene':scene,'quality':q,'index':index,'spot':row['spot'],'screenshot':shot.relative_to(out).as_posix(),'sha256':hashlib.sha256(shot.read_bytes()).hexdigest()})
assert len(mapping)==len(set(m['screenshot'] for m in mapping))==116 and len(supplements)==4
(out/'screenshot-map.json').write_text(json.dumps(mapping,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'all_original_thresholds_passed':True,'spots':116,'images':116,'supplemental_spots':4,'supplements':supplements,'filename_collision':'Existing sampler uses level+column; ch2 harbor col30 and ch3 pump col30 each have two elevations. Original --spots re-captures overwritten samples separately; no sampler edits.'},indent=2,ensure_ascii=False)+'\n',encoding='utf8')
