from pathlib import Path
import hashlib, json, os, subprocess

out = Path('D:/NestEggVerification/evidence-20261117/bg33-current/affected-final')
out.mkdir(exist_ok=False)
paths = [p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot']).decode().split('\0') if p and Path(p).is_file()]
def snapshot(): return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
runs = []
for name, script in [('changed','tools/run_tests_changed.sh bb895cb10169d19496ed90e7a2a42125ee4f8417')]:
    folder = out/name
    folder.mkdir()
    env = os.environ.copy()
    env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='4',LOG_DIR=str(folder/'shards'),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']: env[key]=str(folder/'private-profile'/key)
    command = ['C:/Program Files/Git/bin/bash.exe','-c','python3() { python "$@"; }; export -f python3; '+script]
    with (folder/'raw.log').open('wb') as log: run = subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
    row = {'name':name,'command':command,'exit':run.returncode,'source_held':before==snapshot()}
    runs.append(row)
    (out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert row['exit']==0 and row['source_held']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'all_passed':True,'source_held':before==snapshot()},indent=2)+'\n')
