from pathlib import Path
import hashlib,json,math
from PIL import Image,ImageDraw,ImageFont

base=Path('D:/NestEggVerification/evidence-20261117/bg33-current')
native=base/'native-final-v3'
runs=json.loads((native/'runs.json').read_text())
assert [r['name'] for r in runs[:4]]==['low','medium','high','maximum-brightness'] and all(r['exit']==r['script_errors']==0 and r['source_held'] for r in runs[:4])
for branch in ['readability-final','head-exposure-final','head-exposure-warehouse','head-exposure-lounge']:
    result=json.loads((base/branch/'result.json').read_text());assert result['source_held']
out=base/'review-main';out.mkdir(exist_ok=False)
font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',14)
pages=[]
def record(path,sources):
    pages.append({'page':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sources':[{'path':p.relative_to(base).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources]})
reports={q:json.loads((native/q/'pools-index.json').read_text()) for q in ['low','medium','high']}
for level,data in reports['high']['levels'].items():
    for start in range(0,len(data['records']),3):
        canvas=Image.new('RGB',(1152,720),(16,16,20));draw=ImageDraw.Draw(canvas);sources=[]
        for row,index in enumerate(range(start,min(start+3,len(data['records'])))):
            for col,quality in enumerate(['low','medium','high']):
                entry=reports[quality]['levels'][level]['records'][index]
                source=native/quality/entry['file'];sources.append(source)
                image=Image.open(source);assert image.size==(1280,720)
                canvas.paste(image.resize((384,216)),(col*384,row*240+24))
                ratio=f"{entry['ratio']:.3f}" if not entry.get('note') else 'N/A wall'
                draw.text((col*384+4,row*240+3),f'{quality} {level} #{index} {ratio}',font=font,fill='white')
        path=out/(level+'-'+str(start//3+1)+'.png');canvas.save(path);record(path,sources)
canvas=Image.new('RGB',(1280,768),(16,16,20));draw=ImageDraw.Draw(canvas);sources=[]
for row,level in enumerate(['ch1_warehouse','ch1_vault']):
    for col,mode in enumerate(['high','maximum-brightness']):
        source=native/mode/('pools-'+level+'-lamp00.png');sources.append(source)
        canvas.paste(Image.open(source).resize((640,360)),(col*640,row*384+24))
        draw.text((col*640+5,row*384+3),level+' '+('default' if mode=='high' else 'maximum brightness'),font=font,fill='white')
path=out/'brightness-default-maximum.png';canvas.save(path);record(path,sources)
for label,file in [('street','pools-ch1_street-lamp00.png'),('warehouse','pools-ch1_warehouse-lamp03.png')]:
    canvas=Image.new('RGB',(1280,384),(16,16,20));draw=ImageDraw.Draw(canvas);sources=[]
    for col,prefix in enumerate(['native/high','native-final-v3/high']):
        source=base/prefix/file;sources.append(source)
        canvas.paste(Image.open(source).resize((640,360)),(col*640,24))
        draw.text((col*640+5,3),label+(' earlier state' if col==0 else ' current state'),font=font,fill='white')
    path=out/(label+'-earlier-current.png');canvas.save(path);record(path,sources)
head_rows=[]
for branch,site in [('head-exposure-final','street'),('head-exposure-warehouse','warehouse'),('head-exposure-lounge','lounge')]:
    for quality in ['low','high']:
        folder=base/branch/quality;report=json.loads((folder/'head-results.json').read_text())
        for index,row in enumerate(report['records']):head_rows.append((site,quality,index,folder,row))
assert len(head_rows)==30
for start in range(0,len(head_rows),4):
    canvas=Image.new('RGB',(1024,600),(18,18,22));draw=ImageDraw.Draw(canvas);sources=[]
    for cell,(site,quality,index,folder,row) in enumerate(head_rows[start:start+4]):
        x,y=(cell%2)*512,(cell//2)*300
        world=folder/row['files']['world_png'];mask=folder/row['files']['mask_png'];sources += [world,mask]
        rect=row['sample_rect'];cx=rect[0]+rect[2]//2;cy=rect[1]+rect[3]//2;crop=(cx-64,cy-64,cx+64,cy+64)
        canvas.paste(Image.open(world).crop(crop).resize((256,256),Image.Resampling.NEAREST),(x,y+40))
        alpha=Image.open(mask).getchannel('A').crop(crop).resize((192,192),Image.Resampling.NEAREST).convert('RGB')
        canvas.paste(alpha,(x+280,y+68))
        draw.text((x+4,y+3),f'{site} {quality} #{index} crop x2 / alpha x1.5',font=font,fill='white')
        draw.text((x+4,y+21),f"H={row['opaque_head_pixels']} W={row['white_rectangle_pixels']} bound={row['white_ratio_upper_bound']*100:.3f}%",font=font,fill='white')
    path=out/('heads-'+str(start//4+1)+'.png');canvas.save(path);record(path,sources)
for condition in ['normal','dim']:
    low=base/'readability-final'/(condition+'-low');high=base/'readability-final'/(condition+'-high')
    reports=[json.loads((f/'readability-report.json').read_text()) for f in [low,high]]
    assert all(len(r['results'])==18 for r in reports)
    for start in range(0,18,6):
        canvas=Image.new('RGB',(1280,612),(18,18,22));draw=ImageDraw.Draw(canvas);sources=[]
        for offset,index in enumerate(range(start,min(start+6,18))):
            for q,folder in enumerate([low,high]):
                entry=reports[q]['results'][index];source=folder/entry['screenshot'];sources.append(source)
                x,y=(offset%2*2+q)*320,(offset//2)*204
                image=Image.open(source);assert image.size==(640,360)
                canvas.paste(image.resize((320,180)),(x,y+24))
                draw.text((x+4,y+3),f"{condition} {'low' if q==0 else 'high'} {entry['level']} {entry['column']}",font=font,fill='white')
        path=out/('readability-'+condition+'-'+str(start//6+1)+'.png');canvas.save(path);record(path,sources)
(out/'index.json').write_text(json.dumps(pages,indent=2)+'\n')
print(json.dumps({'pages':len(pages),'head_cases':len(head_rows),'names':[p['page'] for p in pages]}),flush=True)
