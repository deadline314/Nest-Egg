from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg33-current/readability-regression');out.mkdir(exist_ok=False)
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for scene,expected in [('readability_check',16),('ch2_readability_check',22),('ch3_readability_check',20)]:
    for quality in ['low','high']:
        folder=out/(scene+'-'+quality);folder.mkdir();env=os.environ.copy()
        for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','res://tools/'+scene+'.tscn','--','--quality='+quality,'--detail','--out='+str(folder)]
        with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        raw=(folder/'raw.log').read_bytes();report=json.loads((folder/'readability-report.json').read_text())
        row={'scene':scene,'quality':quality,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'spots':len(report['results']),'images':len(list(folder.glob('*.png')))}
        runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
        assert row['exit']==row['script_errors']==0 and row['source_held'] and row['spots']==row['images']==expected,row
        assert report['thresholds']=={'player':0.6,'edge':1.0,'enemy':0.45}
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'all_original_thresholds_passed':True,'spots':116,'images':116},indent=2)+'\n')
