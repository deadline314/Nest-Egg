from pathlib import Path
import hashlib,json,os,subprocess

primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg33-current');out=base/'diagnostics';out.mkdir(exist_ok=False)
private=root/'work/bg33-diagnostics';private.mkdir(exist_ok=False)
(private/'inherited.gd').write_text('''extends "res://tools/bg49_held_pool_probe.gd"
func _measure_level(_id: String,_source: LevelData) -> Dictionary:
    var active := get_viewport().find_world_3d().environment
    var count := get_tree().root.find_children("*","WorldEnvironment",true,false).size()
    var valid := active == _environment49.environment and active.glow_enabled and count == 1
    assert(valid,"base must preserve the inherited tool's original environment")
    print("BG33_INHERITED ",JSON.stringify({"valid":valid,"environments":count}))
    return {"inherited_environment_valid":valid,"environments":count}
''',encoding='utf8',newline='\n')
(private/'wall.gd').write_text('''extends "res://tools/light_pool_probe.gd"
var _done := false
func _measure_lamp(image: Image,lamp: Lamp,walls: BackWallGeometry) -> Dictionary:
    var result := super._measure_lamp(image,lamp,walls)
    if int(lamp.position.x/16) != 90 or _done: return result
    _done = true
    print("BG33_WALL_BASE ",JSON.stringify({"lamp":str(lamp.position),"world_to_screen":str(get_viewport().get_final_transform()*get_viewport().get_canvas_transform()),
        "radius":lamp.light_radius,"band_geometry":walls.covers(Rect2(lamp.position+Vector2(-26,33),Vector2(52,14))),"result":result}))
    _diagnose.call_deferred(lamp,walls)
    return result
func _diagnose(lamp: Lamp,walls: BackWallGeometry) -> void:
    var level := lamp.get_parent().get_parent() as Level
    assert(level != null)
    level.set_process_mode(Node.PROCESS_MODE_DISABLED)
    var lighting := level._lighting
    var original := lighting._modulate.color
    var shadow := lamp._light.shadow_enabled
    for mode: String in ["original","ambient-white","light-shadow-off","wall-shadows-off","foreground-off"]:
        lighting._modulate.color = Color.WHITE if mode == "ambient-white" else original
        lamp._light.shadow_enabled = false if mode == "light-shadow-off" else shadow
        for node: Node in level.find_children("*","",true,false):
            if node is WallShadows: node.visible = mode != "wall-shadows-off"
            if node is ForegroundLayer: node.visible = mode != "foreground-off"
        await get_tree().create_timer(1.2).timeout
        await RenderingServer.frame_post_draw
        var shot := Capture.image(get_viewport())
        assert(shot.save_png(_out.path_join("diagnostic-"+mode+".png")) == OK)
        print("BG33_WALL_DIAGNOSTIC ",JSON.stringify({"mode":mode,"metric":super._measure_lamp(shot,lamp,walls)}))
    get_tree().quit()
func _measure_level(level_id: String,data: LevelData) -> Dictionary:
    var result := await super._measure_level(level_id,data)
    if _done:
        await get_tree().create_timer(9.0).timeout
    return result
''',encoding='utf8',newline='\n')
for name in ['inherited','wall']:
    (private/(name+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg33-diagnostics/'+name+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name,level in [('inherited','ch1_street')]:
    folder=out/name;folder.mkdir()
    env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg33-diagnostics/'+name+'.tscn','--','--out='+str(folder),'--level='+level,'--quality=high','--max=40']
    with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot()}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert row['exit']==row['script_errors']==0 and row['source_held'],row
    assert b'"valid":true' in raw
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'inherited_original_environment_preserved':True},indent=2)+'\n')
