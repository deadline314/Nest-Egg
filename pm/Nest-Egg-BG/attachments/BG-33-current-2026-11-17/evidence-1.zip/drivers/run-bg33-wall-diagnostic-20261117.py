from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg33-current/wall-diagnostic');out.mkdir(exist_ok=False)
private=root/'work/bg33-wall-diagnostic';private.mkdir(exist_ok=False)
(private/'probe.gd').write_text('''extends "res://tools/scene_motion_probe.gd"
func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(LightQuality.Tier.HIGH)
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var level := await _open_level()
    var chosen: Lamp
    for node: Node in level.find_children("*","",true,false):
        if node is Lamp:
            node.use_flicker(LampFlicker.STABLE,0)
            node._flicker = 1.0
            if int(node.position.x/16) == 90: chosen = node
    assert(chosen != null)
    var focus := Node2D.new()
    level.add_child(focus)
    focus.global_position = Vector2(chosen.global_position.x,level.player.global_position.y)
    level._lighting._target = focus
    var camera := get_viewport().get_camera_2d() as LevelCamera
    camera.set_physics_process(false)
    camera.offset = Vector2.ZERO
    camera.zoom = Vector2.ONE*LevelCamera.base_zoom()*0.55
    camera.global_position = chosen.global_position+Vector2(0,60)
    camera.reset_smoothing()
    camera.force_update_scroll()
    await _settle(24)
    level._lighting.set_process(false)
    var tint := level._lighting._modulate.color
    var shadow := chosen._light.shadow_enabled
    var shadows := level.find_children("*","WallShadows",true,false)
    var foreground := level.find_children("*","ForegroundLayer",true,false)
    for node: Node in level.find_children("*","LightBudget",true,false): node.set_process(false)
    var snapshots := []
    for mode: String in ["original","ambient-white","light-shadow-off","wall-shadows-off","foreground-off"]:
        level._lighting._modulate.color = Color.WHITE if mode == "ambient-white" else tint
        chosen._light.shadow_enabled = false if mode == "light-shadow-off" else shadow
        for node in shadows: node.visible = mode != "wall-shadows-off"
        for node in foreground: node.visible = mode != "foreground-off"
        await get_tree().create_timer(1.2).timeout
        await RenderingServer.frame_post_draw
        var shot := Capture.image(get_viewport())
        assert(shot.save_png(_out.path_join(mode+".png")) == OK)
        snapshots.append({"mode":mode,"lamp":[chosen.position.x,chosen.position.y],"light_enabled":chosen._light.enabled,
            "light_visible":chosen._light.is_visible_in_tree(),"light_energy":chosen._light.energy,"shadows":shadows.size(),"foreground":foreground.size()})
    var writer := FileAccess.open(_out.path_join("observations.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify(snapshots,"\\t"))
    writer.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit()
''',encoding='utf8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg33-wall-diagnostic/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg33-wall-diagnostic/probe.tscn','--','--out='+str(out),'--level=ch1_warehouse','--prop=unused']
with (out/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
raw=(out/'raw.log').read_bytes();record={'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'images':len(list(out.glob('*.png')))}
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
assert record['exit']==record['script_errors']==0 and record['source_held'] and record['images']==5
