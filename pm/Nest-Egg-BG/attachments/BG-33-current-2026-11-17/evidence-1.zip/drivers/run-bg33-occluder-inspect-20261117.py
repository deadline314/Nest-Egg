from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg33-current/occluder-inspect');out.mkdir(exist_ok=False)
private=root/'work/bg33-occluder-inspect';private.mkdir(exist_ok=False)
source=(root/'work/bg33-wall-diagnostic/probe.gd').read_text().split('    for mode: String in ',1)[0]
source+='''    var records := []
    for node: Node in level.find_children("*","LightOccluder2D",true,false):
        if node.occluder == null: continue
        var polygon := PackedVector2Array()
        for point: Vector2 in node.occluder.polygon: polygon.append(node.global_transform*point)
        var inside := Geometry2D.is_point_in_polygon(chosen.global_position,polygon)
        if inside: records.append({"path":str(node.get_path()),"inside":inside,"mask":node.occluder_light_mask,"points":str(polygon)})
    print("BG33_OCCLUDERS ",JSON.stringify(records))
    var writer := FileAccess.open(_out.path_join("occluders.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify(records,"\\t"))
    writer.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit()
'''
(private/'probe.gd').write_text(source,encoding='utf8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg33-occluder-inspect/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
tool=root/'tools/light_pool_probe.gd';before=hashlib.sha256(tool.read_bytes()).hexdigest()
env=os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg33-occluder-inspect/probe.tscn','--','--out='+str(out),'--level=ch1_warehouse','--prop=unused']
with (out/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
raw=(out/'raw.log').read_bytes();record={'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'tool_source_held':before==hashlib.sha256(tool.read_bytes()).hexdigest()}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
assert record['exit']==record['script_errors']==0 and record['tool_source_held']
print((out/'occluders.json').read_text(),flush=True)
