from pathlib import Path
import hashlib,json,os,subprocess,zipfile
root=Path('C:/Users/stanl/Github/Nest-Egg');capture=Path('D:/NestEggVerification/ne218-baseline-20261117');out=Path('D:/NestEggVerification/evidence-20261117/bg33-current/advance-published');out.mkdir(exist_ok=False)
def git(cwd,*args):
    r=subprocess.run(['git','-c','core.packedGitLimit=128m','-c','core.packedGitWindowSize=32m','-c','core.deltaBaseCacheLimit=64m','-c','pack.threads=1','-c','pack.window=0',*args],cwd=cwd,capture_output=True)
    with (out/'git.log').open('ab') as f:f.write(r.stdout+r.stderr)
    assert r.returncode==0,(args,r.stderr.decode(errors='replace'))
    return r.stdout
target=git(root,'rev-parse','HEAD').decode().strip()
assert target==git(root,'rev-parse','main').decode().strip()==git(root,'rev-parse','origin/main').decode().strip()
assert target!='bb895cb10169d19496ed90e7a2a42125ee4f8417'
assert git(capture,'rev-parse','HEAD').decode().strip()=='d0941231aa11da8bbad833bea439bed645a6e506'
source=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg33-current/exit-cleanup/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((capture/p).read_bytes()).hexdigest() for p in source}
before=snapshot();assert before==source
tracked=set(git(capture,'ls-files','-z').decode().split('\0'))
preserve={p for p in git(capture,'diff','--name-only','-z').decode().split('\0') if p and (capture/p).is_file()}
for parent,dirs,names in os.walk(capture):
    dirs[:]=[d for d in dirs if d not in ['.git','.godot']]
    for name in names:
        p=Path(parent)/name;rel=p.relative_to(capture).as_posix()
        if rel not in tracked and rel!='.git':preserve.add(rel)
manifest={}
with zipfile.ZipFile(out/'preserved-working-files.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name in sorted(preserve):
        p=capture/name;z.write(p,name);manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(out/'preserved-working-files.zip') as z:assert all(hashlib.sha256(z.read(p)).hexdigest()==h for p,h in manifest.items())
git(capture,'reset','--mixed',target);git(capture,'sparse-checkout','reapply')
assert snapshot()==before
assert all((capture/p).is_file() and hashlib.sha256((capture/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
(out/'result.json').write_text(json.dumps({'published_commit':target,'source_held':True,'source_count':len(source),'preserved_private_files':len(manifest),'import_required':False,'scope':'Only advance owned detached verification metadata after published main; all runtime and private bytes preserved. Existing sparse pm/design/art_src exclusions retained.'},indent=2)+'\n')
print((out/'result.json').read_text(),flush=True)
