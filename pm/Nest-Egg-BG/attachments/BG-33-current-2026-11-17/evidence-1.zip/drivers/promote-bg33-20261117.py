from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('C:/Users/stanl/Github/Nest-Egg');b=Path('D:/NestEggVerification/evidence-20261117/bg33-current')
dest=root/'pm/Nest-Egg-BG/attachments/BG-33-current-2026-11-17';dest.mkdir(exist_ok=False)
for p in (b/'delivery-packet').iterdir():shutil.copy2(p,dest/p.name)
(dest/'.gitattributes').write_text('* -text -whitespace\n')
(dest/'RootReview.md').write_text('''# BG-33 當前光池與可讀性核對

RX 9070 XT、Godot 4.7.2、Forward+／Vulkan、HDR 2D。既有三級區域與光源清單維持；本次補齊 BG-36 燈具安裝後的一般／暗區逐盞光池。改動限於兩款燈具的能量係數、一盞倉庫燈的位置、光池攝影工具、可讀性取樣的退出清理與環境回歸檢查。

## 修正與校準

原攝影工具沒有正式 WorldEnvironment，雖然 viewport 是 HDR，仍缺少正式後製；23 個世界提示也在畫面上。現在沒有既有環境時才補正式環境，持續停用世界提示，並將 PNG 寫入失敗納入失敗退出。實際舊工具的同名目錄負控制自然 exit0、有寫入錯誤且無圖片；修後自然 exit1，索引捕捉失敗為 1。正式三品質每次均觀察到環境 1、glow 與 HDR 開啟、可見世界提示 0。真正繼承呼叫者既有的環境亦經測試保留，沒有疊加第二份環境。

原光池公式、取樣帶、距離、等待、分母下限 0.004 及門檻均保持。霓虹燈具能量係數 0.9→1.3；中間候選 1.1 實際只有 1.999515 倍，未取整冒充通過。艙壁燈具 0.85→1.0；街道第 201 欄在上一輪只有 1.821 倍，沒有降低分母或用中位數掩蓋，而是試算並回到正式三品質重測。

倉庫原第 90 欄的燈源 (1448,594) 在關閉閘門的遮光多邊形內。實際診斷只有關閉燈的陰影才恢復光池，關牆陰影或前景均無效；診斷時演員及自然相位未全部保持，僅作定位，不當成像素完全一致的對照。燈移到第 87 欄 (1400,594)，燈具、支撐與完整取樣帶都避開閘門。88、86 欄雖然移動舊實例時可亮，真正依擺位重新生成卻是故障種子，已拒絕。最終以真正載入的 87 欄活燈驗證。負控制重查實際 Gate 的遮光節點：舊點命中 1、新點命中 0；新環境檢查會拒絕活燈被關閉閘門包住。

## 當前原生畫面

第一章八區，低／中／高各 33 張，另有最高亮度 2 張，共 101 張真正 1280×720 原圖。一般／暗六區每品質 20 個可量背牆點，60／60 個別比值均 ≥2；各品質最低為 2.8086369857、2.3547734599、2.3151221685。街道第 150 欄沒有背牆，明列不可量測，不把零值當通過；當舖與復原館是亮區，不套夜間光池倍數門檻。所有觀察點跟隨燈的實際區域，保留原生雨霧與場景光；真玩家隱藏並留在出生點，以不碰撞的光影觀察點對準燈，不觸發故事。部分 NPC 仍可見，不宣稱自然通關或效能基準。

已實際查看涵蓋 99 張的三品質巡覽頁、預設／最高亮度、街道與倉庫前後圖，以及關鍵原尺寸圖片。前後獨立運行的天候相位與倉庫相機隨擺位不同，不是完全保持的單因素像素比較；原 Commit-1 的歷史三級調暗對照另行保留。

使用原可讀性工具與原 16 次取樣、0.6／1.0／0.45 門檻：第一章一般與燈最暗低／高共 72 點；舊兩關 32 點、第二章 44 點、第三章 40 點，共 188 點全過，實際圖皆 640×360。原第二章港街上下層與第三章泵室的兩層分別共用第 30 欄，工具原檔名只有關卡與欄號，22／20 筆資料分別只留下 21／19 張圖；外層數量檢查正確拒絕。用原有 --spots 篩選被覆寫的高度在獨立目錄補拍低／高，共四張與四筆補充取樣亦全過；screenshot-map 將原 116 筆跨章取樣對到 116 張獨立圖片，沒有更改原量測公式或覆寫上層。補圖是獨立重拍，不假稱原格相位。已查看全部回歸一覽及各區最低主角／地面／敵人對比的原圖。

兩款增亮燈具另驗主角頭部：街道兩盞霓虹與一盞艙壁燈、倉庫實際 87 欄艙壁燈、復原館霓虹，各距離 12／40／80、低／高，共 30 組。固定安排主角、停住其他演員、相機倍率為基準的 1.7 倍，實際轉換矩陣保留；畫面中的懸空是曝光測試安排，不稱自然站立、跳躍或戰鬥。由原工具複製真正頭部 drawable，取 alpha≥0.999 的不透明主頭部面積 H；原 HDR 頭部矩形內 RGB 各 >0.92 的白像素 W 包含背景，因此 W/H 是保守上限，不是全角色或髮尾的精確白色比例。原世界格式 14（RGBH，6 bytes／pixel）、遮罩格式 15（RGBAH，8 bytes／pixel）完整保存，由離線讀取器重算，30 組最高 1.304945% <2%。三個實際空白遮罩 H=0 均自然 exit1、比值 null。放大頁及原圖可看到主頭部與髮尾細節，鞋子原有發光保留；不代替全動作或全角色接縫驗收。

## 原測試與來源

原受影響入口以 bb895cb1 為基準跑 54 組、58,374 checks、新失敗 0、已知失敗 0，683 秒。之後只增加最後艙壁能量 0.85→1.0，因此將真正通過的四份候選來源建立私人未發佈快照 d0941231，在既有獨立驗證 checkout 由原 run_tests_changed.sh 對該基準重測，實際只選五組：Chapter2ExpansionSuite、DevMenuSuite、EnvironmentSuite、ReadabilityTargetsSuite、main；9,799 checks、新失敗 0、已知失敗 0，128 秒。沒有另造 main 交付或重跑不變的 54 組。

最後逐行讀 log 時，舊兩關與部分第二、三章取樣雖然 exit0／零 SCRIPT ERROR，仍有音訊資源未釋放的退出錯誤，未當成乾淨成功。共用取樣器只在全部報告寫完、設定還原後、退出前補上既有 AudioRelease 清理；取樣、像素、公式、檔名及門檻逐位元不變。舊兩關、第二章與第三章的原入口，各以低／高六次代表性取樣重新驗退出：全部 exit0、零 ERROR、無資源洩漏。這是共用退出路徑的驗證，不假稱重跑全部 188 點；先前數值與原圖以取樣程式相同的來源證明沿用。完整原受影響入口在這個最終來源又跑五組、9,799 checks、新失敗與已知失敗均 0。較早五組紀錄保留，不混稱來源完全相同。額外 verbose 診斷曾報系統既有 Epic Vulkan layer JSON 路徑失效，與正常原生六次無關，沒有修改外部安裝或把該診斷稱為乾淨成功。舊第二關第 492 欄的原取樣相機仍會裁到較低屋頂敵人的腳部，數值沿原工具範圍解讀，不宣稱該圖完整角色曝光；BG-17 的既有補充取景另存原票。

第一輪測試與私人基準的 10,085 份來源雜湊完全相同；最終只差燈具資料，JSON 深比對只差這一個能量值。第二輪、光池與頭部取樣的來源守衛一致；最後只多共用取樣器的退出清理一行，來源鏈與逐位元差異另列在附件。前 54 組加最終五組覆蓋本次全部變更。推送前一個 main（bb895cb1）的完整 CI 44062615255 已成功；本票推送後的完整測試另由 CI 執行。

保留的歷史失敗包括：未補環境的原工具、寫入假成功、88 欄新生故障燈、未加最後艙壁能量的 1.821 倍，以及原繼承探針找不到舊 harbor_approach 區域而 exit1。後者是該獨立 BG-49 探針的舊區域過濾，未在這張票修改，也未當作 BG-49 驗收通過；既有環境保留是另用真實繼承初始化的針對性測試驗證。

附件保存最終原圖、原始 HDR、逐點與逐格資料、來源守衛、原測試 log、已使用的私有觀察器及驅動、關鍵修前圖。較早被取代整批 PNG 不重複打包，歷史數據與錯誤保留；私人使用者目錄、匯入快取、備份 ZIP 與臨時 Git index 不公開。執行 `python verify.py` 可用純標準函式庫核對分卷 SHA、圖片尺寸、60 個光池、188 筆映射、原始 HDR W/H、來源鏈與所有負控制；真正翻轉 ZIP 位元也已被拒絕。
''',encoding='utf8',newline='\n')
images=root/'pm/Nest-Egg-BG/images/BG-33-20261117';images.mkdir(exist_ok=False)
names=['ch1_street-1.png','ch1_warehouse-2.png','ch1_vault-1.png','ch1_rooftop-1.png','ch1_booth_alley-1.png','ch1_stall-1.png','ch1_pawnshop-1.png','ch1_lounge-1.png','brightness-default-maximum.png','street-earlier-current.png','warehouse-earlier-current.png','heads-1.png','heads-5.png','heads-7.png']
for name in names:shutil.copy2(b/'review-main'/name,images/name)
ticket=next((root/'pm/Nest-Egg-BG').glob('[[]BG-33[]]*.md'));s=ticket.read_text(encoding='utf8')
assert '> 狀態：進行中' in s and '# Commit-2' not in s
s=s.replace('> 狀態：進行中','> 狀態：完成',1).replace('- [ ] 一般與暗的區域','- [x] 一般與暗的區域',1)
s+='''

# Commit-2

## 內文

場景燈具安裝後，霓虹與艙壁燈的部分光池不夠明顯，倉庫有一盞燈又被關閉閘門擋住。現在調整兩款燈的亮度並將倉庫該盞移開閘門，燈具與支撐保持完整。一般與暗的區域在三品質逐盞檢查，60 個可量背牆的光池全部超過原 2 倍門檻；亮區維持原先的喘息空間。

原攝影缺少正式後製且有提示覆蓋，現在與正式場景一致；圖片無法寫入時正確失敗退出。可讀性取樣完成後也會等待音訊釋放，六次代表性重跑均乾淨退出。第一章平常與最暗時，以及舊兩關、第二、三章的主角、平台與敵人可讀性全部通過。增亮燈旁的白髮亦放大核對，保留細節與鞋子發光。

### 測試結果

| 項目 | 結果 |
|---|---|
| 原生三品質、八區光池 | 99 張 1280×720；一般／暗區 60／60 ≥2 倍，各品質最低 2.809／2.355／2.315 倍 |
| 預設與最高亮度 | 倉庫與倉庫深處對照通過，另 2 張原圖 |
| 原可讀性門檻 | 第一章平常／最暗與三章回歸共 188 點全部通過；港街與泵室另補低／高共四張與四筆取樣 |
| 頭部近燈曝光 | 30 組保守上限最高 1.305% <2%；三個空白遮罩皆正確拒絕 |
| 原受影響測試 | 前 54 組 58,374 checks；最後單一亮度差異五組 9,799 checks；新失敗與已知失敗均 0 |
| 工具與回歸負控制 | 原寫入假成功已重現；修後失敗退出、既有環境保留、舊閘門擺位被拒絕均通過 |
| 原始資料離線重驗 | SHA、原圖尺寸、光池、可讀性、HDR、來源鏈全部通過；實際 ZIP 損壞被拒絕 |

[當前原圖、量測範圍與離線重驗](attachments/BG-33-current-2026-11-17/RootReview.md)。街道第 150 欄燈下沒有背牆，明列不可量測；亮區不套夜間倍數門檻。歷史三級調暗對照保留於前一段交付。

### 截圖

![街道光池修正前後](images/BG-33-20261117/street-earlier-current.png)

![倉庫燈移開閘門前後](images/BG-33-20261117/warehouse-earlier-current.png)

![倉庫三種光影品質逐盞對照](images/BG-33-20261117/ch1_warehouse-2.png)

![預設與最高亮度](images/BG-33-20261117/brightness-default-maximum.png)

![固定近燈曝光取樣，頭部與 alpha 放大](images/BG-33-20261117/heads-5.png)
'''
ticket.write_text(s,encoding='utf8',newline='\n')
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-X','utf8',str(dest/'verify.py'),str(dest)]
r=subprocess.run(command,capture_output=True);(b/'promoted-reader.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr.decode()
paths=['tools/readability_check.gd','tools/light_pool_probe.gd','tests/suite/test_environment.gd','data/environment/lamp_fixtures.json','data/levels/ch1_warehouse_map.json','design/08-lighting/LIGHT_SOURCES.md',ticket.relative_to(root).as_posix()]+[p.relative_to(root).as_posix() for p in sorted(dest.iterdir())]+[p.relative_to(root).as_posix() for p in sorted(images.iterdir())]
(root/'work/bg33-stage-paths.json').write_text(json.dumps(paths,indent=2)+'\n');print(json.dumps({'paths':len(paths),'public_reader_exit':0,'status':'complete'}),flush=True)
