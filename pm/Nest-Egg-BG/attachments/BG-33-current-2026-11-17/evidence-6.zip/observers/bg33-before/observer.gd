extends "res://tools/light_pool_probe.gd"
func _measure_lamp(image: Image,lamp: Lamp,walls: BackWallGeometry) -> Dictionary:
    var prompts := 0
    for node: Node in get_tree().root.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    print("BG33_OBSERVER ",JSON.stringify({"environments":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),
        "hdr":get_viewport().use_hdr_2d,"visible_prompts":prompts,"image_size":[image.get_width(),image.get_height()]}))
    return super._measure_lamp(image,lamp,walls)
