extends "res://tools/light_pool_probe.gd"
func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(LightQuality.Tier.HIGH)
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var observations := []
    for id: String in ["ch1_street","ch1_warehouse"]:
        GameState.start_new_run(GameState.difficulties[1])
        var level := Level.new()
        level.configure(load("res://data/levels/"+id+".tres"))
        add_child(level)
        await _settle(30)
        level.hud.hide()
        level.player.hide()
        level.player.process_mode = Node.PROCESS_MODE_DISABLED
        var chosen: Lamp
        for node: Node in level.find_children("*","",true,false):
            if node is ChapterCard: node.queue_free()
            if node is WorldPrompt:
                node.enabled = false
                node.set_process(false)
                node.hide()
            if node is Enemy or node is NpcActor:
                node.hide()
                node.process_mode = Node.PROCESS_MODE_DISABLED
                for child: Node in node.find_children("*","",true,false): child.process_mode = Node.PROCESS_MODE_DISABLED
            if node is Lamp:
                node.use_flicker(LampFlicker.STABLE,0)
                node._flicker = 1.0
                if int(node.position.x/16) == (11 if id == "ch1_street" else 90): chosen = node
        assert(chosen != null)
        var focus := Node2D.new()
        level.add_child(focus)
        focus.global_position = level.player.global_position
        level._lighting._target = focus
        level._lighting._lightning_gap = 1.0e9
        var camera := get_viewport().get_camera_2d() as LevelCamera
        camera.set_physics_process(false)
        camera.offset = Vector2.ZERO
        camera.zoom = Vector2.ONE*LevelCamera.base_zoom()*VIEW_ZOOM
        var candidates: Array = [0.9,1.1,1.3,1.5] if id == "ch1_street" else [90,88,86]
        for candidate in candidates:
            if id == "ch1_street": chosen.light_energy = chosen.energy*float(candidate)
            else: chosen.position.x = float(candidate)*16+8
            focus.global_position.x = chosen.global_position.x
            camera.global_position = chosen.global_position+Vector2(0,60)
            camera.reset_smoothing()
            camera.force_update_scroll()
            await _settle(24)
            await get_tree().create_timer(0.8).timeout
            await RenderingServer.frame_post_draw
            var image := Capture.image(get_viewport())
            var metric := _measure_lamp(image,chosen,level._scenery_walls)
            var stem := id+"-"+str(candidate)
            assert(image.save_png(_out.path_join(stem+".png")) == OK)
            var enclosed := 0
            for node: Node in level.find_children("*","LightOccluder2D",true,false):
                if node.occluder == null: continue
                var polygon := PackedVector2Array()
                for point: Vector2 in node.occluder.polygon: polygon.append(node.global_transform*point)
                if Geometry2D.is_point_in_polygon(chosen.global_position,polygon): enclosed += 1
            observations.append({"level":id,"candidate":candidate,"fixture":String(chosen.fixture_id),"position":[chosen.position.x,chosen.position.y],
                "energy":chosen.light_energy,"supported":chosen.is_supported(),"enclosing_occluders":enclosed,"metric":metric})
        level.queue_free()
        await _settle(8)
    var writer := FileAccess.open(_out.path_join("observations.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify(observations,"\t"))
    writer.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit()
