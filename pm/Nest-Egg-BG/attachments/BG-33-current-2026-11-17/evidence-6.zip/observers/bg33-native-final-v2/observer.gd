extends "res://tools/light_pool_probe.gd"
func _ready() -> void:
    for arg: String in OS.get_cmdline_user_args():
        if arg == "--maximum-brightness": Settings.set_brightness(1.0)
    super._ready()
func _measure_lamp(image: Image,lamp: Lamp,walls: BackWallGeometry) -> Dictionary:
    var prompts := 0
    for node: Node in get_tree().root.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    var environment := get_viewport().find_world_3d().environment
    var count := get_tree().root.find_children("*","WorldEnvironment",true,false).size()
    assert(environment != null and environment.glow_enabled and count == 1 and prompts == 0)
    print("BG33_OBSERVER ",JSON.stringify({"environments":count,"glow":environment.glow_enabled,"hdr":get_viewport().use_hdr_2d,
        "visible_prompts":prompts,"image_size":[image.get_width(),image.get_height()],"brightness":Settings.get_brightness(),"gamma":Settings.brightness_gamma(),
        "lamp":[lamp.global_position.x,lamp.global_position.y]}))
    return super._measure_lamp(image,lamp,walls)
