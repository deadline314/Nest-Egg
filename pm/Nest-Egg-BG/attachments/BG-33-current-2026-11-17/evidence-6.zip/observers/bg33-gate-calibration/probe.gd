extends "res://tools/scene_motion_probe.gd"
func _run() -> void:
    add_child(LightKit.create_environment())
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var level := await _open_level()
    var lamp: Lamp
    var occluders: Array[LightOccluder2D] = []
    for node: Node in level.find_children("*","Node2D",true,false):
        if node is Lamp and node.fixture_id == &"bulkhead_wall": lamp = node
        if node is Gate and not node.is_open and node.is_visible_in_tree():
            for child: Node in node.get_children():
                if child is LightOccluder2D and child.occluder != null: occluders.append(child)
    assert(lamp != null)
    var records := []
    for point: Vector2 in [Vector2(1448,594),lamp.global_position]:
        var hits := []
        for occluder in occluders:
            if Geometry2D.is_point_in_polygon(occluder.to_local(point),occluder.occluder.polygon):
                var polygon := []
                for vertex: Vector2 in occluder.occluder.polygon:
                    var world := occluder.global_transform*vertex
                    polygon.append([world.x,world.y])
                hits.append({"parent_class":occluder.get_parent().get_script().get_global_name(),"path":str(occluder.get_path()),"polygon":polygon})
        records.append({"point":[point.x,point.y],"hits":hits})
    var valid: bool = not lamp.dead and lamp.is_supported() and records[0].hits.size() == 1 and records[1].hits.is_empty()
    var writer := FileAccess.open(_out.path_join("calibration.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify({"valid":valid,"lamp_alive":not lamp.dead,"supported":lamp.is_supported(),"records":records},"\t"))
    writer.close()
    level.queue_free()
    await _settle(8)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0 if valid else 1)
