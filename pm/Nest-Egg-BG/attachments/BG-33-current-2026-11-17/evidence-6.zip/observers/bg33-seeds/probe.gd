extends Node
func _ready() -> void:
    var style := (load("res://data/lighting/warehouse_interior.tres") as LightingProfile).lamp_style
    for tile in [86,87,88,89,90]:
        var lamp := Lamp.new()
        lamp.position = Vector2(tile*16+8,594)
        lamp.floor_y = 784
        lamp.ceiling_y = 576
        lamp.wall_behind = true
        lamp.apply_style(style,hash(Vector2i(tile,594)),{&"ceiling":true,&"wall":true,&"pole":false,&"ground":false},3)
        print("BG33_SEED ",tile," dead=",lamp.dead," fixture=",lamp.fixture_id)
        lamp.free()
    get_tree().quit()
