extends "res://tools/bg49_held_pool_probe.gd"
func _measure_level(_id: String,_source: LevelData) -> Dictionary:
    var active := get_viewport().find_world_3d().environment
    var count := get_tree().root.find_children("*","WorldEnvironment",true,false).size()
    var valid := active == _environment49.environment and active.glow_enabled and count == 1
    assert(valid,"base must preserve the inherited tool's original environment")
    print("BG33_INHERITED ",JSON.stringify({"valid":valid,"environments":count}))
    return {"inherited_environment_valid":valid,"environments":count}
