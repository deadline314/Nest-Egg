extends "res://tools/scene_motion_probe.gd"
func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(LightQuality.Tier.HIGH)
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var level := await _open_level()
    var chosen: Lamp
    for node: Node in level.find_children("*","",true,false):
        if node is Lamp:
            node.use_flicker(LampFlicker.STABLE,0)
            node._flicker = 1.0
            if int(node.position.x/16) == 90: chosen = node
    assert(chosen != null)
    var focus := Node2D.new()
    level.add_child(focus)
    focus.global_position = Vector2(chosen.global_position.x,level.player.global_position.y)
    level._lighting._target = focus
    var camera := get_viewport().get_camera_2d() as LevelCamera
    camera.set_physics_process(false)
    camera.offset = Vector2.ZERO
    camera.zoom = Vector2.ONE*LevelCamera.base_zoom()*0.55
    camera.global_position = chosen.global_position+Vector2(0,60)
    camera.reset_smoothing()
    camera.force_update_scroll()
    await _settle(24)
    level._lighting.set_process(false)
    var tint := level._lighting._modulate.color
    var shadow := chosen._light.shadow_enabled
    var shadows := level.find_children("*","WallShadows",true,false)
    var foreground := level.find_children("*","ForegroundLayer",true,false)
    for node: Node in level.find_children("*","LightBudget",true,false): node.set_process(false)
    var snapshots := []
    var records := []
    for node: Node in level.find_children("*","LightOccluder2D",true,false):
        if node.occluder == null: continue
        var polygon := PackedVector2Array()
        for point: Vector2 in node.occluder.polygon: polygon.append(node.global_transform*point)
        var inside := Geometry2D.is_point_in_polygon(chosen.global_position,polygon)
        if inside: records.append({"path":str(node.get_path()),"inside":inside,"mask":node.occluder_light_mask,"points":str(polygon)})
    print("BG33_OCCLUDERS ",JSON.stringify(records))
    var writer := FileAccess.open(_out.path_join("occluders.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify(records,"\t"))
    writer.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit()
