extends "res://tools/scene_motion_probe.gd"
func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(QUALITY[_quality])
    Lamp.flicker_hold = 1.0
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var blank := "--blank-head-mask" in OS.get_cmdline_user_args()
    var level := await _open_level()
    var player := level.player
    player.show()
    player.velocity = Vector2.ZERO
    var lamps: Array[Lamp] = []
    for node: Node in level.find_children("*","",true,false):
        if node is Lamp and node.fixture_id == &"neon_tube_bracket" and not node.dead: lamps.append(node)
        if node is Enemy or node is NpcActor:
            node.hide()
            node.process_mode = Node.PROCESS_MODE_DISABLED
            for child: Node in node.find_children("*","",true,false): child.process_mode = Node.PROCESS_MODE_DISABLED
    assert(lamps.size() == 2)
    var camera := get_viewport().get_camera_2d() as LevelCamera
    camera.set_physics_process(false)
    camera.offset = Vector2.ZERO
    camera.zoom = Vector2.ONE*LevelCamera.base_zoom()*1.7
    level._lighting._target = player
    var records := []
    var failures := 0
    for index in lamps.size():
        for gap: float in [12.0,40.0,80.0]:
            player.global_position = lamps[index].global_position+Vector2(0,58+gap)
            camera.global_position = player.global_position+Vector2(0,-40)
            camera.reset_smoothing()
            camera.force_update_scroll()
            await _settle(24)
            var label := "lamp"+str(index)+"-gap"+str(int(gap))
            var result := await preload("res://tools/weapon_head_probe.gd").capture(self,level,_out,label,blank)
            result["lamp"] = [lamps[index].global_position.x,lamps[index].global_position.y]
            result["feet"] = [player.global_position.x,player.global_position.y]
            result["feet_below_source"] = 58+gap
            result["fixture_energy"] = lamps[index].light_energy
            var valid: bool = result.get("bound_valid",false) and result.get("white_ratio_upper_bound",1.0) != null and float(result.get("white_ratio_upper_bound",1.0)) <= 0.02
            if not valid: failures += 1
            records.append(result)
            if blank: break
        if blank: break
    var writer := FileAccess.open(_out.path_join("head-results.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify({"quality":_quality,"blank":blank,"failures":failures,"records":records},"\t"))
    writer.close()
    level.queue_free()
    await _settle(8)
    await AudioRelease.settle(get_tree())
    get_tree().quit(1 if failures > 0 else 0)
