extends "res://work/bg45-current/state-core.gd"
const Capture45 = preload("res://tools/viewport_capture.gd")
const Held45 = preload("res://tools/held_lighting_state.gd")
func drawable_geometry(item: CanvasItem) -> int:
    if item is Polygon2D:
        assert(item.get_bone_count()==0)
        return hash([item.polygon,item.uv,item.vertex_colors,item.polygons])
    assert(item is Sprite2D)
    return hash([item.get_rect(),item.flip_h,item.flip_v,item.region_rect,item.frame])

func pose(rig: CharacterRig) -> Array:
    var result: Array = []
    for part in rig._parts:
        result.append({"instance":part.get_instance_id(),"transform":Held45.transform_values(part.global_transform),"geometry":drawable_geometry(part),"visible":part.is_visible_in_tree()})
    return result

func save_image(image: Image, name: String) -> Dictionary:
    var path := _out.path_join(name+".bin")
    var file := FileAccess.open(path,FileAccess.WRITE)
    assert(file!=null)
    file.store_buffer(image.get_data())
    file.close()
    assert(Capture45.encode(image,true).save_png(_out.path_join(name+".png"))==OK)
    return {"raw":name+".bin","png":name+".png","sha256":FileAccess.get_sha256(path),"width":image.get_width(),"height":image.get_height(),"format":image.get_format(),"bytes":image.get_data().size()}

func mask(rig: CharacterRig) -> Dictionary:
    var viewport := get_viewport()
    var view := SubViewport.new()
    view.size = viewport.get_texture().get_image().get_size()
    view.world_2d = World2D.new()
    view.transparent_bg = true
    view.use_hdr_2d = true
    view.disable_3d = true
    view.canvas_item_default_texture_filter = viewport.canvas_item_default_texture_filter
    view.canvas_item_default_texture_repeat = viewport.canvas_item_default_texture_repeat
    view.msaa_2d = viewport.msaa_2d
    view.snap_2d_transforms_to_pixel = viewport.snap_2d_transforms_to_pixel
    view.snap_2d_vertices_to_pixel = viewport.snap_2d_vertices_to_pixel
    view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    add_child(view)
    var witnesses: Array = []
    for part in rig._parts:
        if not part.is_visible_in_tree(): continue
        assert(part is Sprite2D or part is Polygon2D)
        var ancestor: Node = part
        while ancestor is CanvasItem:
            assert(is_equal_approx(ancestor.modulate.a,1.0) and ancestor.clip_children==CanvasItem.CLIP_CHILDREN_DISABLED)
            ancestor = ancestor.get_parent()
        assert(is_equal_approx(part.self_modulate.a,1.0))
        var shader := part.material as ShaderMaterial
        assert(part.material==null or shader!=null and shader.shader==CharacterRig.LIGHT_SHADER)
        var geometry := drawable_geometry(part)
        var copy := part.duplicate(0) as Node2D
        for child in copy.get_children():
            copy.remove_child(child)
            child.free()
        copy.set_script(null)
        copy.process_mode = Node.PROCESS_MODE_DISABLED
        view.add_child(copy)
        copy.transform = viewport.get_final_transform()*part.get_global_transform_with_canvas()
        assert(geometry==drawable_geometry(copy))
        witnesses.append({"part":str(part.name),"source_geometry":geometry,"copy_geometry":drawable_geometry(copy),"source_transform":Held45.transform_values(viewport.get_final_transform()*part.get_global_transform_with_canvas()),"copy_transform":Held45.transform_values(copy.transform)})
    await settle(3)
    var result := save_image(view.get_texture().get_image(),"body-alpha")
    result["drawables"] = witnesses
    view.queue_free()
    await settle(2)
    return result

func _run() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(LightKit.create_environment())
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--quality="): Settings.set_light_quality(0 if arg.ends_with("low") else 2)
    Story.auto_skip = true
    GameState.start_new_run(GameState.difficulties[1])
    var level := await make_level("ch3_glass_edge")
    level.hud.visible = false
    await move(level,Vector2(328,318))
    var sun: PropNode
    for node in level._world.get_children():
        if node is PropNode and str(node.data.id)=="sun_patch": sun=node
    assert(sun!=null and sun._light!=null and sun._light.enabled and sun._light.is_visible_in_tree())
    var rect := Rect2(sun.global_position,sun.data.size)
    assert(rect.position.x<=level.player.global_position.x and level.player.global_position.x<=rect.end.x)
    assert(absf(rect.end.y-level.player.global_position.y)<0.02)
    Held45.preserve_physics_bodies(level)
    level.process_mode = Node.PROCESS_MODE_DISABLED
    for node in level.find_children("*","",true,false):
        if node is WorldPrompt: node.visible=false
    var clock := Engine.time_scale
    Engine.time_scale = 0.0
    var rig := level.player._visual.rig
    var initial := pose(rig)
    var alpha := await mask(rig)
    var records: Array = []
    for step in [[false,"off-0"],[true,"on-0"],[true,"on-1"],[false,"off-restore"],[true,"on-final"]]:
        sun._light.enabled = step[0]
        Held45.sync(level)
        await settle(3)
        assert(pose(rig)==initial and sun.visible and sun._glow_sprite.is_visible_in_tree())
        var row := save_image(get_viewport().get_texture().get_image(),step[1])
        row.merge({"label":step[1],"enabled":sun._light.enabled,"energy":sun._light.energy,"light_position":[sun._light.global_position.x,sun._light.global_position.y],"pose":pose(rig),"owners":Held45.snapshot(level),"camera":Held45.transform_values(get_viewport().get_final_transform()*get_viewport().get_canvas_transform())})
        records.append(row)
    assert(records[0].sha256==records[3].sha256 and records[1].sha256==records[2].sha256 and records[1].sha256==records[4].sha256)
    Engine.time_scale = clock
    level.process_mode = Node.PROCESS_MODE_INHERIT
    await move(level,Vector2(408,318))
    assert(level.player.global_position.x>rect.end.x)
    var outside := save_image(get_viewport().get_texture().get_image(),"outside-illustration")
    var f := FileAccess.open(_out.path_join("sun.json"),FileAccess.WRITE)
    assert(f!=null)
    f.store_string(JSON.stringify({"quality":Settings.get_light_quality(),"records":records,"alpha":alpha,"outside":outside,"sun_rect":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"scope":"Actual authored PropNode PointLight2D enabled/off/on in one frozen same-pose Level; glow artwork stays visible. Alpha-only static copies of the actual CPU drawables, no behavior; geometry/transforms checked. Outside frame is an illustration after restoring simulation, not a causal brightness comparison. No exposure/head-white/performance/full-chapter claim."},"  ")+"\n")
    f.close()
    level.queue_free()
    await settle(3)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0)
