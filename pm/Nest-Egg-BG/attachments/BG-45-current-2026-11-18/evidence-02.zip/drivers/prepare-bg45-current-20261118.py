from pathlib import Path
import hashlib,json,re,subprocess,sys
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');previous=Path('D:/NestEggVerification/evidence-20261117/bg44-current');early=previous.parent/'bg45-preflight';head='913c45f12c5c66a5e4f2afd8e4c7fc0a6b819304'
assert json.loads((previous/'publish/result.json').read_text())['commit']==head and json.loads((previous/'advance-published/result.json').read_text())['published_commit']==head
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p).decode().strip()==subprocess.check_output(['git','rev-parse','HEAD'],cwd=d).decode().strip()==head
for case in ['ch3_showroom-low','ch3_showroom-high','ch3_office_hall-low','ch3_office_hall-high']:assert json.loads((early/'tone-101'/case/'independent.json').read_text())['passed']
b=previous.parent/'bg45-current';b.mkdir(exist_ok=False);v=d/'work/bg45-current';v.mkdir(exist_ok=False);source=json.loads((previous/'checks-v2/source-after.json').read_text());assert len(source)==10092 and all(hashlib.sha256((d/r).read_bytes()).hexdigest()==h for r,h in source.items());(b/'source-base.json').write_text(json.dumps(source,indent=2)+'\n')
sys.dont_write_bytecode=True;sys.path.insert(0,str(p/'tools/level'));import build_ch3 as ch3
ch3.configure();parent='c80f5483fbb56f0f7f3feb15c782cb5625af0f5a';delta={};proof=[]
profiles={'clinic':'clinic_ward','glass_edge':'sunlit_edge','showroom':'sunny_day','office_hall':'tower_white'}
for ident,profile in profiles.items():
 rel='data/levels/ch3_'+ident+'_map.json';current=json.loads((d/rel).read_text());assert ch3.kit._map_extra(getattr(ch3,'build_'+ident)())['props']==current['props'];old=subprocess.check_output(['git','show',parent+':'+rel],cwd=p);old_data=json.loads(old);added=[x for x in current['props'] if x not in old_data['props']];removed=[x for x in old_data['props'] if x not in current['props']];delta['ch3_'+ident]={'added':added,'removed':removed};(b/(ident+'-original-map.json')).write_bytes(old);proof.append({'level':'ch3_'+ident,'added':added,'removed':removed,'original_map_sha256':hashlib.sha256(old).hexdigest(),'current_generator_props_match':True});(v/(profile+'-before.tres')).write_bytes((d/('data/lighting/'+profile+'.tres')).read_bytes())
(v/'prop-delta.json').write_text(json.dumps(delta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(b/'baseline-proof.json').write_text(json.dumps({'base':head,'original_bg45':'02015266ca88f23e0774620359d7045f460b8f6d','parent':parent,'rows':proof,'scope':'Four original BG45 area prop deltas on current runtime and geometry; these four areas do not use the tall-room mapping. No complete historical checkout.'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['probe.gd','probe.tscn','framed.gd']:(v/name).write_bytes((d/'work/bg45-preflight'/name).read_bytes().replace(b'bg45-preflight',b'bg45-current'))
cfg=json.loads((d/'assets_src/pipeline/scene_props.json').read_text());props=[x for x in cfg['props'] if x['id'] in {'clinic__reading_desk','sunlit_district__viewing_frame','tianqiong_corridor__petition_box'}];assert len(props)==3 and {x['seed'] for x in props}==set(range(7701,7704));(b/'pipeline-extract.json').write_text(json.dumps({'styles':cfg['styles'],'defaults':cfg['defaults'],'props':props},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Design decisions precede the product-data change.
doc=p/'design/20-campaign-experience/CH2_CH3_SCENE_GAPS.md'
with doc.open('a',encoding='utf-8') as f:f.write('\n## BG-45 的四區重驗（2026-11-18）\n\n沿用目前診所、玻璃邊緣、樣品房與接待廊的路線，只對照原票新增與移動的擺設；以真實NPC互動範圍及原始HDR檢查，不以舊表格取代重驗。樣品房與接待廊使用本區光影副本，僅將陰影／亮部同色RGB提高1%，主角補光、地形與單燈設定不變；環境音沿用原區，配樂維持原有區段未指定時的回退。日光以同一角色／姿態交替開關實際照明核對，另拍實際站進／站外及互動點擺放。\n')
ticket=next((p/'pm/Nest-Egg-BG').glob('[[]BG-45]*.md'));s=ticket.read_text();assert '> 狀態：審查中' in s;ticket.write_text(s.replace('> 狀態：審查中','> 狀態：進行中',1),encoding='utf-8')
mapping={'sunny_day':'showroom_day','tower_white':'reception_white'};changed=[]
for original,name in mapping.items():
 rel='data/lighting/'+name+'.tres';assert not (p/rel).exists();s=(p/('data/lighting/'+original+'.tres')).read_text();assert s.count('id = &"'+original+'"')==1;s=s.replace('id = &"'+original+'"','id = &"'+name+'"')
 for field in ['shadow_tint','highlight_tint']:
  pattern=r'^'+field+r' = Color\(([^)]+)\)';m=re.search(pattern,s,re.M);assert m;values=[float(x) for x in m[1].split(',')];assert len(values)==4;values[:3]=[x*1.01 for x in values[:3]];s=s[:m.start()]+field+' = Color('+', '.join(format(x,'.10g') for x in values)+')'+s[m.end():]
 (p/rel).write_text(s,encoding='utf-8',newline='\n');changed.append(rel)
 rel='data/levels/ch3_'+('showroom' if original=='sunny_day' else 'office_hall')+'.tres';s=(p/rel).read_text();needle='res://data/lighting/'+original+'.tres';assert s.count(needle)==1;(p/rel).write_text(s.replace(needle,'res://data/lighting/'+name+'.tres'),encoding='utf-8',newline='\n');changed.append(rel)
rel='tools/level/build_ch3.py';s=(p/rel).read_text()
for original,name in mapping.items():
 needle="a.zone(0, '"+original+"')";assert s.count(needle)==1;s=s.replace(needle,"a.zone(0, '"+name+"')")
(p/rel).write_text(s,encoding='utf-8',newline='\n');changed.append(rel)
rel='data/audio/ambience.json';s=(p/rel).read_text();before=json.loads(s)
for original,name in mapping.items():
 match=re.search(r'^  "'+original+r'": \[.*?^  \],',s,re.M|re.S);assert match;block=match[0];s=s[:match.end()]+'\n'+block.replace('"'+original+'":','"'+name+'":',1)+s[match.end():]
after=json.loads(s)
for original,name in mapping.items():assert after['profiles'].pop(name)==before['profiles'][original]
assert after==before;(p/rel).write_text(s,encoding='utf-8',newline='\n');changed.append(rel)
music=json.loads((p/'data/audio/music.json').read_text());assert all(name not in music['map']['zones'] for name in list(mapping)+list(mapping.values()))
for rel in changed:(d/rel).write_bytes((p/rel).read_bytes())
final={r:hashlib.sha256((d/r).read_bytes()).hexdigest() for r in set(source)|set(changed)};assert len(final)==10094;(b/'source-final.json').write_text(json.dumps(final,indent=2)+'\n');(b/'adoption.json').write_text(json.dumps({'product_paths':changed,'source_count':len(final),'tone_gain':1.01,'unchanged_music_fallback':True,'scope':'Only two local profile tone copies plus exact original ambience and level/generator references; no shared profile, material, actor, geometry, rule or light changes.'},indent=2)+'\n')
s=(v/'probe.gd').read_text();needle='var original := level._lighting.current.duplicate() as LightingProfile';assert s.count(needle)==1
s=s.replace(needle,'''var names := {"ch3_clinic":"clinic_ward","ch3_glass_edge":"sunlit_edge","ch3_showroom":"sunny_day","ch3_office_hall":"tower_white"}
	var original := (load("res://work/bg45-current/"+str(names[str(level.data.id)])+"-before.tres") as LightingProfile).duplicate() as LightingProfile''')
s=s.replace('var candidate := original','''var name := "showroom_day" if str(level.data.id)=="ch3_showroom" else "reception_white"
	var candidate := (load("res://data/lighting/"+name+".tres") as LightingProfile).duplicate() as LightingProfile if str(level.data.id) in ["ch3_showroom","ch3_office_hall"] else original.duplicate() as LightingProfile''')
s=s.replace('record["character_fill"] = LightKit.character_fill','''record["character_fill"] = LightKit.character_fill
		record["shadow_tint_values"] = [level._lighting.current.shadow_tint.r,level._lighting.current.shadow_tint.g,level._lighting.current.shadow_tint.b,level._lighting.current.shadow_tint.a]
		record["highlight_tint_values"] = [level._lighting.current.highlight_tint.r,level._lighting.current.highlight_tint.g,level._lighting.current.highlight_tint.b,level._lighting.current.highlight_tint.a]''')
(v/'final-base.gd').write_text(s,encoding='utf-8');s=(v/'framed.gd').read_text().replace('/probe.gd','/final-base.gd');(v/'final.gd').write_text(s,encoding='utf-8');(v/'final.tscn').write_bytes((v/'probe.tscn').read_bytes().replace(b'/probe.gd',b'/final.gd'))
s=(p/'work/run-bg45-preflight-20261118.py').read_text().replace('bg45-preflight','bg45-current').replace("out=base/'reproduction'","out=base/'formal-final'").replace('source-base.json','source-final.json').replace('/framed.tscn','/final.tscn');(p/'work/run-bg45-final-20261118.py').write_text(s,encoding='utf-8')
s=(p/'work/run-bg44-checks-v2-20261118.py').read_text().replace('bg44','bg45').replace('checks-v2','checks-final').replace('source-v2.json','source-final.json').replace('6d14fd587b1dc09aaf29190e01d2268334193d6f',head);(p/'work/run-bg45-checks-final-20261118.py').write_text(s,encoding='utf-8')
progress=p/'work/queue-20261117-progress.json';state=json.loads(progress.read_text());state['published']['BG44-complete']=head;state['BG44_completed']={'commit':head,'paths':47,'tests':'57groups63379checks0new0known735s +6generator unit tests;32maps+links+stage0error0warn;assetsOK','packet':json.loads((previous/'delivery-packet/result.json').read_text()),'reader':json.loads((previous/'delivery-packet/reader.log').read_text()),'advance':json.loads((previous/'advance-published/result.json').read_text()),'remaining_open':66,'scope':'Actual terminalfloor256->576 via existingdata override+meaningfulregression; pumpcreaturefloor.75/localleft20steelRGB1.7alpha1; no globalcodechanges. All16finalpagesviewed. Failed prototypes/sourceepoch1wrongnotice preserved; endpoint0.999999999999999 serialization correctedreaderonlyepsilon1e-12, notHDRthreshold.'};state.pop('BG44_active',None);state['branch']='codex/ticket-work-20261118-bg45';state['BG45_active']={'base':head,'source_count':10094,'state':'Selected privatecalibrationtone1.01 all4independentlyPASS; now adopted6productpaths2newlocalprofileclones +exactambience/level/generatorrefs. Originalmusicold/newzonenamesabsent, samefallback preserved. Final8nativejobs+changedBASE913c45 next; before source10092 after10094. Preflight diagnostic paths separate. Need flat/stateNPC+actualsunlight controls/artifact/commit/push.'};state['disk_relocation']='D:/NestEggVerification/relocated-owned-raw-20261118/receipt.json:1156files/2oldownedBG20-BG21+NE258folders SHAheld, originalCpaths retainedbyjunction; Cfree~2.12GB';progress.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'base':head,'changed':changed,'source_count':len(final),'remaining_open':66}),flush=True)
