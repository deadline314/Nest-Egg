from pathlib import Path
import json
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from verify_bg49_held import FORMATS
b=Path('D:/NestEggVerification/evidence-20261117/bg45-current');out=b/'review';out.mkdir(exist_ok=True);font=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc',14)
for phase,key in [('formal-v2','bg45'),('flat-v2','bg45_flat')]:
 for level in ['ch3_clinic','ch3_glass_edge','ch3_showroom','ch3_office_hall']:
  for q in ['low','high']:
   f=b/phase/(level+'-'+q)/level;index=f/'bg45-index.json'
   if not index.exists():continue
   data=json.loads(index.read_text());cols,rows=int(data['columns']),int(data['rows']);im=Image.new('RGB',(cols*320,36+rows*390),'#101722');draw=ImageDraw.Draw(im);draw.text((7,6),f'{phase}/{level}/{q}: BEFORE top, AFTER bottom; native640x360 shown320x180',font=font,fill='white')
   for shot in data['shots']:
    records=shot[key]['records'];after=records[-1] if phase=='formal-v2' else records[1];c,r=int(shot['column']),int(shot['row'])
    for i,(label,record) in enumerate([('before',records[0]),('after',after)]):
     x,y=c*320,36+r*390+i*195
     with Image.open(f/record['files']['png']) as image:
      assert image.size==(640,360);im.paste(image.convert('RGB').resize((320,180)),(x,y))
     draw.text((x+3,y+180),f'{label} c{c} r{r}',font=font,fill='white')
   im.save(out/f'{phase}-{level}-{q}.png')
for q in ['low','high']:
 f=b/'states-v3'/q;rows=json.loads((f/'states.json').read_text())['rows'];assert len(rows)==19
 for start in range(0,19,6):
  im=Image.new('RGB',(1280,1170),'#101722');draw=ImageDraw.Draw(im)
  for i,row in enumerate(rows[start:start+6]):
   x,y=i%2*640,i//2*390
   with Image.open(f/(row['name']+'.png')) as image:
    assert image.size==(640,360);im.paste(image,(x,y))
   draw.text((x+3,y+362),q+' / '+row['name'],font=font,fill='white')
  im.save(out/f'states-{q}-{start//6+1:02}.png')
for q in ['low','high']:
 f=b/'sun-v3'/q;s=json.loads((f/'sun.json').read_text());im=Image.new('RGB',(1280,780),'#101722');draw=ImageDraw.Draw(im)
 for i,(name,label) in enumerate([('off-0.png','actual point light OFF; original glow stays visible'),('on-0.png','actual point light ON; same frozen pose'),('body-alpha.png','actual drawable alpha union; geometry copied without behavior'),('outside-illustration.png','outside illustration; simulation restored, no numeric comparison')]):
  x,y=i%2*640,i//2*390
  with Image.open(f/name) as image:
   if name=='body-alpha.png':image=Image.merge('RGB',[image.getchannel('A')]*3)
   im.paste(image.convert('RGB'),(x,y))
  draw.text((x+3,y+362),q+' / '+label,font=font,fill='white')
 im.save(out/f'sun-{q}.png')
 a=s['alpha'];dtype,channels=FORMATS[a['format']];mask=np.frombuffer((f/a['raw']).read_bytes(),dtype=dtype).reshape(a['height'],a['width'],channels)[...,3]>=.99;yy,xx=np.where(mask);rect=(max(0,int(xx.min())-4),max(0,int(yy.min())-4),min(640,int(xx.max())+5),min(360,int(yy.max())+5));width,height=(rect[2]-rect[0])*4,(rect[3]-rect[1])*4
 im=Image.new('RGB',(max(900,width*2),height+36),'#101722');draw=ImageDraw.Draw(im)
 for i,name in enumerate(['off-0.png','on-0.png']):
  with Image.open(f/name) as image:im.paste(image.crop(rect).resize((width,height),Image.Resampling.NEAREST),(i*max(450,width),36))
  draw.text((i*max(450,width)+3,6),q+' / '+name+' / actual native pixels x4',font=font,fill='white')
 im.save(out/f'sun-detail-{q}.png')
print(json.dumps({'pages':[p.name for p in sorted(out.glob('*.png'))]}),flush=True)
