from pathlib import Path
import hashlib,json,re,subprocess,sys
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg45-current')
assert json.loads((b/'checks-final/result.json').read_text())['all_passed']
source=json.loads((b/'source-final.json').read_text());assert all(hashlib.sha256((d/r).read_bytes()).hexdigest()==h for r,h in source.items())
doc=p/'design/20-campaign-experience/CH2_CH3_SCENE_GAPS.md'
with doc.open('a',encoding='utf-8') as f:f.write('\n實際NPC驗證另外抓到A晨窗的方向筆記仍在第30欄，晨窗互動點在第32欄，水平相隔30.4像素。筆記移至晨窗同欄，不移動NPC、任務座標或窗戶；三扇窗以實際擺設寬度覆蓋各自互動點作回歸檢查。\n')
r='tools/level/build_ch3.py';s=(p/r).read_text();needle="a.prop('clearwater__sun_chart_notes', 30, y=13, support='wall')";assert s.count(needle)==1;s=s.replace(needle,needle.replace(', 30,',', 32,'));(p/r).write_text(s,encoding='utf-8',newline='\n')
r='data/levels/ch3_showroom_map.json';s=(p/r).read_text();needle='{"id": "clearwater__sun_chart_notes", "x": 30, "y": 13, "support": "wall"}';assert s.count(needle)==1;(p/r).write_text(s.replace(needle,needle.replace('"x": 30','"x": 32')),encoding='utf-8',newline='\n')
r='tools/level/test_ch3_layout.py';s=(p/r).read_text();assert 'import re\n' not in s;s=s.replace('import os\n','import os\nimport re\n');marker='    def test_quest_locations_point_at_real_content(self):';assert s.count(marker)==1
test='''    def test_showroom_window_props_cover_their_interaction_points(self):
        area = self.build('showroom')
        props = {p['id']: p for p in kit._map_extra(area)['props']}
        for glyph, ident in [('Ⓐ', 'clearwater__sun_chart_notes'), ('Ⓑ', 'clearwater__white_curtains'), ('Ⓤ', 'clearwater__sill_with_coin')]:
            with self.subTest(window=glyph):
                x = next(x for row in area.grid.rows() for x, char in enumerate(row) if char == glyph)
                entry = props[ident]
                path = os.path.join(kit.ROOT, 'data/environment/scene_props/clearwater', ident + '.tres')
                with open(path, encoding='utf-8') as resource:
                    width = float(re.search(r'^size = Vector2\\(([^,]+),', resource.read(), re.MULTILINE)[1])
                left = entry['x'] * kit.TILE + entry.get('dx', 0)
                self.assertLessEqual(left, (x + 0.5) * kit.TILE)
                self.assertGreaterEqual(left + width, (x + 0.5) * kit.TILE)

'''
s=s.replace(marker,test+marker);(p/r).write_text(s,encoding='utf-8',newline='\n')
changed=['tools/level/build_ch3.py','data/levels/ch3_showroom_map.json','tools/level/test_ch3_layout.py']
for r in changed:(d/r).write_bytes((p/r).read_bytes());source[r]=hashlib.sha256((d/r).read_bytes()).hexdigest()
(b/'source-v2.json').write_text(json.dumps(source,indent=2)+'\n')
sys.dont_write_bytecode=True;sys.path.insert(0,str(p/'tools/level'));import build_ch3 as ch3
ch3.configure();current=json.loads((p/'data/levels/ch3_showroom_map.json').read_text());assert ch3.kit._map_extra(ch3.build_showroom())['props']==current['props'];old=json.loads((b/'showroom-original-map.json').read_text());added=[x for x in current['props'] if x not in old['props']];removed=[x for x in old['props'] if x not in current['props']]
path=d/'work/bg45-current/prop-delta.json';delta=json.loads(path.read_text());delta['ch3_showroom']={'added':added,'removed':removed};path.write_text(json.dumps(delta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
proof=json.loads((b/'baseline-proof.json').read_text());(b/'baseline-proof-v1.json').write_text(json.dumps(proof,indent=2)+'\n');row=next(x for x in proof['rows'] if x['level']=='ch3_showroom');row['added']=added;row['removed']=removed;proof['window_correction']={'npc_column':32,'notes_before':30,'notes_after':32,'before_gap':30.4,'after_gap':0,'method':'Existing prop placement and unchanged NPC; all three window interaction centers lie within their primary prop width'};(b/'baseline-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
adoption=json.loads((b/'adoption.json').read_text());adoption['product_paths']+=['data/levels/ch3_showroom_map.json','tools/level/test_ch3_layout.py'];(b/'adoption.json').write_text(json.dumps(adoption,indent=2)+'\n')
for original,new in [('run-bg45-final-20261118.py','run-bg45-final-v2-20261118.py'),('run-bg45-flat-final-20261118.py','run-bg45-flat-v2-20261118.py'),('run-bg45-checks-final-20261118.py','run-bg45-checks-v2-20261118.py'),('run-bg45-state-v2-20261118.py','run-bg45-state-v3-20261118.py'),('run-bg45-sun-final-20261118.py','run-bg45-sun-v2-20261118.py')]:
 s=(p/'work'/original).read_text().replace('source-final.json','source-v2.json').replace("/'formal-final'","/'formal-v2'").replace("/'flat-final'","/'flat-v2'").replace('bg45-current/checks-final','bg45-current/checks-v2').replace("/'states-v2'","/'states-v3'").replace("/'sun-final'","/'sun-v2'");(p/'work'/new).write_text(s,encoding='utf-8')
print(json.dumps({'changed':changed,'source_count':len(source),'new_showroom_added':len(added),'new_showroom_removed':len(removed)}),flush=True)
