extends "res://work/bg45-current/state-core.gd"
var _choices: Array[String] = []
var _selected: Array[Dictionary] = []
var _alignments: Array[Dictionary] = []
func _process(delta: float) -> void:
    super._process(delta)
    var player: CutscenePlayer = Story._player if is_instance_valid(Story._player) else null
    if is_instance_valid(player) and player.choice_active():
        assert(not _choices.is_empty(),"Every selection must be explicitly authored by the driver")
        var choice: String = _choices.pop_front()
        var found := false
        for i in player._choice_options.size():
            if str(player._choice_options[i].get("id",""))==choice:
                _selected.append({"scene":str(Story._current_cinematic),"option":choice})
                assert(player.choose(i))
                found = true
                break
        assert(found,"Requested choice must exist in the actual menu")
    elif is_instance_valid(player) and player.is_running():
        player.speed = 20.0
        if player._dialogue.visible:
            player._dialogue.complete()
            player._advance_requested = true
    elif Story._layer.is_cinematic_active(): Story._layer.advance()

func prop(level: Level, id: String) -> PropNode:
    for node in level._world.get_children():
        if node is PropNode and str(node.data.id)==id: return node
    assert(false,id)
    return null

func alignment(level: Level, actor: NpcActor, id: String, grounded: bool, limit := 16.0) -> void:
    var node := prop(level,id)
    var rect := Rect2(node.global_position,node.data.size)
    var gap := maxf(0.0,maxf(rect.position.x-actor.global_position.x,actor.global_position.x-rect.end.x))
    assert(node.is_visible_in_tree() and gap<=limit)
    if grounded:
        assert(absf(rect.end.y-actor.global_position.y-ScenerySupport.ground_offset(node.data.id,node.data.size.y))<0.02)
    _alignments.append({"level":str(level.data.id),"npc":str(actor.data.id),"npc_world":[actor.global_position.x,actor.global_position.y],"prop":id,"rect":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"gap":gap,"limit":limit,"grounded":grounded,"ground_offset":ScenerySupport.ground_offset(node.data.id,node.data.size.y) if grounded else 0.0})

func talk(level: Level, id: StringName, name: String, choices: Array[String], prop_id := "", grounded := true, limit := 16.0) -> void:
    assert(_choices.is_empty())
    var actor := await check_npc(level,id,name)
    if not prop_id.is_empty(): alignment(level,actor,prop_id,grounded,limit)
    _choices.assign(choices)
    var count := actor.talk_count
    assert(await actor._talk())
    assert(_choices.is_empty() and actor.talk_count==count+1)

func _run() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(LightKit.create_environment())
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--quality=" ): Settings.set_light_quality(0 if arg.ends_with("low") else 2)
    Story.auto_skip = false
    Enemy.activation_culling_enabled = false
    GameState.start_new_run(GameState.difficulties[1])
    # Standalone fixture supplies only the earlier chapter's index, not this route's result flags.
    StoryItems.acquire(&"ch2_clinic_index")
    var level := await make_level("ch3_clinic")
    await talk(level,&"ch3_zhi","clinic-access",["go"])
    assert(GameState.has_flag(&"ch3_clinic_access") and StoryItems.holds(&"ch3_review_slip"))
    await talk(level,&"ch3_reading_desk","desk-missing",[],"clinic__reading_desk",true,32.0)
    assert(not GameState.has_flag(&"ch3_report_reconciled"))
    await talk(level,&"ch3_public_report","public-report",["save"],"clinic__reading_desk",true,32.0)
    await talk(level,&"ch3_nursing_board","nursing-board",["eleven"],"control_room__whiteboard_notes",false)
    await talk(level,&"ch3_register_cabinet","register-cabinet",["save"],"clinic__report_cabinet")
    var credits := Progression.credits
    await talk(level,&"ch3_reading_desk","desk-reconcile",["hundred","eleven","tracked"],"clinic__reading_desk",true,32.0)
    assert(GameState.has_flag(&"ch3_report_reconciled") and Progression.credits==credits+180 and StoryItems.holds(&"ch3_petition_receipt") and StoryItems.holds(&"ch3_mezz_pass"))
    await talk(level,&"ch3_deposit_drawer","deposit-drawer",["leave"],"nursing_ward__bedside_locker")
    assert(not StoryItems.holds(&"ch3_ahan_tape"))
    await shot(level,"clinic-results",{"reconciled":true,"earned":Progression.credits-credits,"borrowed_tape":false})
    level.queue_free()
    await settle(3)
    level = await make_level("ch3_glass_edge")
    await talk(level,&"ch3_light_spot","light-spot",[],"sun_patch")
    await talk(level,&"ch3_telescope","viewing-frame",[],"sunlit_district__viewing_frame")
    assert(GameState.has_flag(&"ch3_sunlight_pause_seen"))
    level.queue_free()
    await settle(3)
    level = await make_level("ch3_showroom")
    await talk(level,&"ch3_lin","showroom-post",["post"])
    assert(GameState.has_flag(&"ch3_clearwater_tour_started") and StoryItems.holds(&"ch3_tour_card"))
    await talk(level,&"ch3_window_morning","window-morning",[],"clearwater__sun_chart_notes",false)
    await talk(level,&"ch3_window_quiet","window-quiet",[],"clearwater__white_curtains",false)
    await talk(level,&"ch3_window_late","window-late",[],"clearwater__sill_with_coin")
    await talk(level,&"ch3_lin","showroom-finish",["finish"])
    assert(GameState.has_flag(&"ch3_clearwater_tour_done"))
    level.queue_free()
    await settle(3)
    level = await make_level("ch3_office_hall")
    await talk(level,&"ch3_petition_box","petition-before",["leave"],"tianqiong_corridor__petition_box")
    assert(GameState.has_flag(&"ch3_petition_receipt_taken") and StoryItems.holds(&"ch3_intake_receipt"))
    await shot(level,"petition-after",{"receipt_taken":true,"receipt_held":true})
    level.queue_free()
    await settle(3)
    level = await make_level("ch3_office_hall")
    await talk(level,&"ch3_petition_box","petition-reentry",[],"tianqiong_corridor__petition_box")
    await shot(level,"petition-repeat",{"receipt_taken":GameState.has_flag(&"ch3_petition_receipt_taken"),"receipt_held":StoryItems.holds(&"ch3_intake_receipt")})
    var f := FileAccess.open(_out.path_join("states.json"),FileAccess.WRITE)
    assert(f!=null)
    f.store_string(JSON.stringify({"rows":_rows,"alignments":_alignments,"selected":_selected,"actual_talks":true,"seeded_result_flags":false,"fixture":"Standalone authored Levels, real collision/prompts/NPC talks and explicit choices, dialogue speed20. Only previous-chapter clinic index supplied. Enemies removed, health999, scripted positioning. Same-run reentry, no Main/full campaign/manual input/cold-save claim. Shared desk deliberately between two interaction points; its 27px width cannot contain points64px apart, maxallowedgap32px and actualgaps preserved."},"  ")+"\n")
    f.close()
    level.queue_free()
    await settle(3)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0)
