from pathlib import Path
import os,time,subprocess,json
b=Path(__file__).parent
while not (b/'ne257-lifecycle-affected-final.exit').exists():time.sleep(3)
assert (b/'ne257-lifecycle-affected-final.exit').read_text()=='0'
env=os.environ.copy();env['NE_NATIVE_PROJECT']='fixtures';results=[]
for n,tool,q in [('bg49-pool-legacy-focus','res://work/light_pool_legacy.tscn','high'),('bg49-pool-local-high','res://tools/light_pool_probe.tscn','high'),('bg49-pool-local-low','res://tools/light_pool_probe.tscn','low')]:
 r=subprocess.run(['python',str(b/'native.py'),n,tool,'--level=ch1_street','--max=40','--quality='+q,'--tag='+q],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
 results.append({'name':n,'exit':r.returncode});(b/'bg49-pool-focus-results.json').write_text(json.dumps(results,indent=2)+'\n');print(n,r.returncode,flush=True)
 if 'SCRIPT ERROR:' in (b/(n+'.log')).read_text():raise SystemExit('SCRIPT ERROR in '+n)
 if n!='bg49-pool-legacy-focus' and r.returncode:raise SystemExit(r.returncode)
