extends SceneTree
var failures: Array[String] = []
var created := 0
var workers_count := 4

func _initialize() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--workers="):
			workers_count = int(arg.trim_prefix("--workers="))
	assert(workers_count in [1, 4])
	_run.call_deferred()

func _allocate(image: Image, count: int) -> Array[RID]:
	var rids: Array[RID] = []
	for i in count:
		rids.append(RenderingServer.texture_2d_create(image))
	return rids

func _run() -> void:
	for batch in 8:
		var workers: Array[Thread] = []
		for i in workers_count:
			var image := Image.create(2, 2, false, Image.FORMAT_RGBA8)
			image.fill(Color(float(i) / 4.0, 0.2, 0.5))
			var worker := Thread.new()
			worker.start(_allocate.bind(image, 1024 / workers_count))
			workers.append(worker)
		var all := {}
		for worker: Thread in workers:
			var rids: Array = worker.wait_to_finish()
			for rid: RID in rids:
				created += 1
				if not rid.is_valid() or all.has(rid):
					failures.append("invalid or duplicate RID in concurrent original public texture allocation")
				all[rid] = true
		await process_frame
		await process_frame
		for rid: RID in all:
			RenderingServer.free_rid(rid)
		await process_frame
		await process_frame
		print("BATCH ", batch, " unique ", all.size(), " failures ", failures.size())
		if not failures.is_empty():
			break
	print("DUMMY_TEXTURE_CONTROL created=", created, " failures=", failures.size())
	quit(0 if failures.is_empty() else 1)
