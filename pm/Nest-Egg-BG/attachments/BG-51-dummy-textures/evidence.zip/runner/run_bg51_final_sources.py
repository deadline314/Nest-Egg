from pathlib import Path
import subprocess,time,json,hashlib
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'dummy-texture-worktree';frozen=json.loads((w/'bg51-final-source-v2.json').read_text());engine=w/'godot-texture-build/dist/godot'
def unchanged():
 for f,h in frozen.items():assert hashlib.sha256((r/f).read_bytes()).hexdigest()==h,f
while not (w/'bg51-full-v2.exit').exists():time.sleep(1)
assert (w/'bg51-full-v2.exit').read_text().strip()=='0'
for tool,label in [('run_supper_completion.py','supper'),('run_sunday_choice.py','sunday')]:
 unchanged();name='bg51-original-'+label+'-v1';print('START',name,flush=True)
 with (w/(name+'.log')).open('w') as log:code=subprocess.run(['python3',str(r/'tools'/tool),'--godot',str(engine),'--output',str(w/name)],cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
 (w/(name+'.exit')).write_text(str(code)+'\n');assert code==0,name;unchanged();print('PASS',name,flush=True)
print('ALL ORIGINAL EXIT DIAGNOSTIC FLOWS VERIFIED',flush=True)
