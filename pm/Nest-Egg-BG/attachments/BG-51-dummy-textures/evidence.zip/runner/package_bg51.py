from pathlib import Path
import json,hashlib,re,zipfile,shutil,importlib.util
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'dummy-texture-worktree';n=Path('/workspace/Nest-Egg/work/batch1020b');d=r/'pm/Nest-Egg-BG/attachments/BG-51-dummy-textures'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
frozen=json.loads((w/'bg51-final-source-v4.json').read_text())
for f,h in frozen.items():assert sha(r/f)==h,f
before=json.loads((w/'bg51-published-before-v1/receipt.json').read_text());after=json.loads((w/'bg51-published-after-v1/receipt.json').read_text())
assert before['cases'][0]['passed'] and not before['cases'][1]['passed'] and all(c['passed'] for c in after['cases'])
assert before['source_sha256']==after['source_sha256'],'Public before/after sources must match exactly'
final=json.loads((w/'bg51-published-final-v1/receipt.json').read_text());assert all(c['passed'] for c in final['cases']) and sum(c['result']['checks'] for c in final['cases'])==32810
assert sha(w/'dummy-texture-thread-v3.gd')==sha(w/'dummy-texture-thread-control/probe.gd')
assert (w/'bg51-full-v2.exit').read_text().strip()=='0'
raw=(w/'bg51-full-v2.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',raw);assert m and m[2]==m[3]=='0'
regressions={}
for label in ['supper','sunday']:
 receipt=json.loads((w/('bg51-original-'+label+'-v1')/'receipt.json').read_text());assert all(c['passed'] and c['exit']==0 for c in receipt['cases']);regressions[label]={'processes':len(receipt['cases']),'checks':sum(c['result']['checks'] for c in receipt['cases']),'failures':0}
cold=json.loads((w/'bg51-original-cold-v1/receipt.json').read_text());assert len(cold['cases'])==3 and all(c['passed'] for c in cold['cases'])
visual=json.loads((w/'bg51-native-visual-review.json').read_text());assert visual['all_originals_viewed'] and visual['checks']==7 and visual['failures']==0
native=n/'bg51-supper-cold-native-v1';assert int((n/'bg51-supper-cold-native-v1.exit').read_text())==0
for name in ['bg51-build-tests-v3.log','bg51-selector-tests-v1.log']:
 text=(w/name).read_text();assert 'Ran 12 tests' in text and '\nOK\n' in text
assert (w/'bg51-audio-load-v1.exit').read_text().strip()=='0'
assert 'Ran 4 tests' in (w/'bg51-full-log-guard-tests-v1.log').read_text() and '\nOK\n' in (w/'bg51-full-log-guard-tests-v1.log').read_text()
assert 'logs=4 diagnostics=0' in (w/'bg51-full-log-guard-v1.log').read_text()
assert json.loads((w/'bg51-original-failure-log-guard-v1.json').read_text())['would_fail']
audio=json.loads((w/'bg51-audio-load-v1/results.json').read_text());assert len(audio['results'])==8 and all(c['exit']==0 and not any(c[k] for k in ['timeout','crashed','script_error','leaks','error']) and c['result']['audio_active'] and c['result']['shutdown_mixed'] and c['result']['audio_behavior'] for c in audio['results'])
engine=json.loads((w/'godot-texture-build/dist/receipt.json').read_text());assert sha(w/'godot-texture-build/dist/godot')==engine['binary_sha256'];assert sha(w/'godot-audio-build/dist/godot')=='dadf922b668b42d4484386749c9f5a2bf8587cd50c36215238f16776132de2ac'
spec=json.loads((r/'tools/godot_audio/manifest.json').read_text());assert engine['additional_patches']==spec['additional_patches']
loader=importlib.util.spec_from_file_location('fixed_engine_build',r/'tools/godot_audio/build.py');build=importlib.util.module_from_spec(loader);loader.loader.exec_module(build);assert build.verify_cached(w/'godot-texture-build',build.recipe()[2],spec)
entries={}
def add(key,p):
 if p.is_file():entries[key]=p

def tree(prefix,root):
 for p in root.rglob('*'):
  if p.is_file() and not any(x.endswith('-profile') or x.startswith('profile-') or x in ['.godot','__pycache__'] for x in p.relative_to(root).parts):add(prefix+'/'+str(p.relative_to(root)),p)
for f in frozen:add('source/final/'+f,r/f)
for f in ['design/20-campaign-experience/DUMMY_TEXTURE_CONCURRENCY.md','tools/godot_audio/README.md']:add('source/final/'+f,r/f)
for p in w.glob('bg51-*'):
 if p.is_file() and p.suffix in ['.json','.log','.exit'] and not p.name.startswith('bg51-package'):add('records/'+p.name,p)
 elif p.is_dir():
  if p.name.endswith('-shards'):
   for f in p.glob('*.log'):add('tests/'+p.name+'/'+f.name,f)
  else:tree('runs/'+p.name,p)
for p in w.glob('dummy-texture-thread-*'):
 if p.is_file():add('original/'+p.name,p)
add('original/project.godot',w/'dummy-texture-thread-control/project.godot');add('original/probe.gd',w/'dummy-texture-thread-control/probe.gd')
base='godot-ed1daf0bf001b61586d9930840f2f1394092c079'
for f in ['servers/rendering/dummy/storage/texture_storage.h','servers/rendering/rendering_server_default.h','servers/rendering/renderer_rd/storage_rd/texture_storage.h','core/templates/rid_owner.h']:
 for version,folder in [('before','godot-audio-build'),('after','godot-texture-build')]:add('engine/'+version+'/'+f,w/folder/base/f)
for f in ['receipt.json','LICENSE.txt','COPYRIGHT.txt']:add('engine/'+f,w/'godot-texture-build/dist'/f)
tree('native/bg51-supper-cold-native-v1',native)
for suffix in ['.log','.exit','-xvfb.log']:add('native/bg51-supper-cold-native-v1'+suffix,n/('bg51-supper-cold-native-v1'+suffix))
for f in ['run_bg51_final_sources.py','package_bg51.py','st9-supper-ci-receipt.json','st9-supper-ci-evidence.zip']:add('runner/'+f,w/f)
for p in (w/'ne280-full-v1-shards').glob('*.log'):
 if 'GodotArea2D' in p.read_text():add('prior-broad/'+p.name,p)
add('prior-sunday/exit-diagnostic.json',r/'pm/ST/attachments/ST-9-reception-results/exit-diagnostic.json');add('prior-sunday/observer_reset.log',w/'st9-reception-regression-sunday_choice-v1/observer_reset.log')
manifest={};archive=d/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for key,p in sorted(entries.items()):manifest[key]={'bytes':p.stat().st_size,'sha256':sha(p)};z.write(p,key)
with zipfile.ZipFile(archive) as z:
 for key,expected in manifest.items():
  with z.open(key) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==expected['sha256'],key
assert archive.stat().st_size<50*1024*1024
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
validation={'base':'97e07692d2260752e5c7131eb5629f0be54bcdb1','source_sha256':frozen,'engine':engine,'final_metadata_only_patch_context_normalization':{'same_cpp_after_sha256':'0cc7c447e017b6e9cf163da898a39f15da4592968889105ee613bcbe209c4be5','same_binary_sha256':'319aaea8c619fa1edc5d08a33158ab2bfd069e329a1bcd672db9654af53f35e2','final_published_checks':32810,'final_published_failures':0},'independent':{'original_each_allocations':8192,'original_before_single_errors':0,'original_before_four_errors':362,'original_before_four_leaked_rids':100,'identical_original_probe_sha256':sha(w/'dummy-texture-thread-v3.gd'),'published_before':[{k:c[k] for k in ['mode','exit','passed','diagnostic_count']} for c in before['cases']],'published_after':{'processes':2,'allocations':16384,'checks':sum(c['result']['checks'] for c in after['cases']),'failures':0,'same_sources':True}},'full':{'groups':int(re.search(r'Running (\d+) groups',raw)[1]),'workers':4,'checks':int(m[1]),'new_failures':0,'known_failures':0,'seconds':int(m[4])},'build_tests':12,'selector_tests':12,'full_log_guard':{'tests':4,'complete_logs':4,'dummy_diagnostics':0,'rejects_original_zero_exit_failure':True},'legacy_exit_diagnostics':'bg51-legacy-exit-diagnostics.json in archive records; no new ignore patterns','audio_processes':8,'cold':{'processes':3,'checks':21,'failures':0,'seed_sha256':cold['seed_sha256']},'native':visual,'regressions':regressions,'archive':{'bytes':archive.stat().st_size,'entries':len(manifest),'sha256':sha(archive)},'limits':['Independent matching-type worker race isolated; original single RID has no resource identity, so no claim of a uniquely identified prior Sunday object.','Software Forward+ and real Dummy-driver mixing; no physical GPU/controller/listening sign-off.','Original failures, parse/setup mistakes and the first no-selection run are retained. No known-failure or diagnostic-filter change.']}
(d/'validation.json').write_text(json.dumps(validation,indent=2)+'\n');shutil.copyfile(w/'godot-texture-build/dist/receipt.json',d/'engine-receipt.json');shutil.copyfile(w/'bg51-native-visual-review.json',d/'visual-review.json');shutil.copyfile(w/'st9-supper-ci-receipt.json',d/'previous-supper-ci.json')
(r/'pm/Nest-Egg-BG/images').mkdir(exist_ok=True);shutil.copyfile(native/'cold/frame.png',r/'pm/Nest-Egg-BG/images/BG-51-supper-cold.png')
print(json.dumps({k:v for k,v in validation.items() if k not in ['engine','source_sha256','native']},indent=2))
