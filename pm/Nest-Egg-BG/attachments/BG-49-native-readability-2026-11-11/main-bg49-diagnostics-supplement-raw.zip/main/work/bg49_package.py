"""Preserve all BG49 diagnostics/final cases without newline conversion."""
from pathlib import Path
import hashlib,json,zipfile

repo=Path(__file__).resolve().parents[1]
base=repo/'pm/Nest-Egg-BG/attachments/BG-49-native-readability-2026-11-11'
base.mkdir(exist_ok=True)
origins=[('main',repo/'work'),('native',Path('D:/NestEggVerification/native-ticket-batch-20261111/work'))]
cases=[(origin,p)for origin,folder in origins for p in sorted(folder.glob('bg49-*'))if p.is_dir()and(p/'command.json').exists()]
cases += [('cpu',p)for p in sorted(base.glob('cpu-*'))if p.is_dir()and(p/'command.json').exists()]
records=[]
for origin,case in cases:
 name=origin+'-'+case.name
 files=sorted(p for p in case.rglob('*')if p.is_file()and not p.name.endswith(('.uid','.import')))
 # Split before compression conservatively. One original file is never split;
 # all chunks carry a complete case manifest and their own member manifest.
 groups=[];group=[];total=0
 for p in files:
  size=p.stat().st_size
  if group and total+size>80000000:groups.append(group);group=[];total=0
  group.append(p);total+=size
 if group:groups.append(group)
 manifest={p.relative_to(case).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in files}
 chunks=[]
 for index,group in enumerate(groups):
  archive=base/(name+('-part%02d'%(index+1)if len(groups)>1 else'')+'-raw.zip')
  part={p.relative_to(case).as_posix():manifest[p.relative_to(case).as_posix()]for p in group}
  if not archive.exists():
   with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
    for p in group:z.write(p,p.relative_to(case).as_posix())
    z.writestr('manifest-part.json',(json.dumps(part,indent=2)+'\n').encode())
    z.writestr('manifest-case.json',(json.dumps(manifest,indent=2)+'\n').encode())
  with zipfile.ZipFile(archive)as z:
   assert json.loads(z.read('manifest-case.json'))==manifest,(name,'finished case was modified')
   assert json.loads(z.read('manifest-part.json'))==part
   for p,m in part.items():
    raw=z.read(p);assert len(raw)==m['bytes']and hashlib.sha256(raw).hexdigest()==m['sha256']
  assert archive.stat().st_size<95000000,(archive,'chunk exceeds delivery limit')
  chunks.append({'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(part)})
 exit_data=json.loads((case/'exit.json').read_bytes())if(case/'exit.json').exists()else None
 before=json.loads((case/'source-before.json').read_bytes())if(case/'source-before.json').exists()else{}
 after=exit_data.get('source_after',{})if exit_data else{}
 changes=[p for p,h in before.items()if after.get(p)!=h]if exit_data else[]
 errors=[line for line in(case/'run.log').read_bytes().decode('utf-8',errors='replace').splitlines()if'ERROR:'in line]if(case/'run.log').exists()else[]
 records.append({'case':name,'original_folder':str(case),'original_files':len(files),'chunks':chunks,'exit':exit_data,'changed_sources':changes,'engine_error_lines':errors,'complete_exit_receipt':exit_data is not None})
 print(name,len(files),len(chunks),'chunks',flush=True)
(base/'archives.json').write_bytes((json.dumps(records,ensure_ascii=False,indent=2)+'\n').encode())
(base/'.gitattributes').write_bytes(b'*.zip -text\n')
(base/'.gitignore').write_bytes(b'/cpu-*/\n/runs/\n/replay/\n*.import\n*.uid\n')
print('verified',sum(r['original_files']for r in records),'original files in',sum(len(r['chunks'])for r in records),'ZIP chunks')
