from pathlib import Path
import ast,json,re,subprocess,sys
repo=Path(__file__).resolve().parents[1]
root=Path("D:/NestEggVerification/native-ticket-batch-20261111")
points=ast.literal_eval(re.search(r"const PROBES := (\{.*?\n\})",(root/"tools/ch1_readability_check.gd").read_text(),re.S).group(1))
for quality in ["high","low"]:
 tag="held-complete-"+quality+"-v6"
 subprocess.run([sys.executable,"-X","utf8",str(repo/"work/bg49_run.py"),"held",tag,quality,"--level="+",".join(points)],check=True)
 case=root/"work"/("bg49-"+tag)
 subprocess.run([sys.executable,"-X","utf8",str(repo/"tools/verify_bg49_held.py"),str(case),"--kind=held","--expect-points=18","--out="+str(case.parent/(case.name+"-independent.json"))],check=True)
