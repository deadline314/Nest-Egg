from pathlib import Path
import ast,json,re,subprocess,sys

repo=Path(__file__).resolve().parents[1]
native=Path('D:/NestEggVerification/native-ticket-batch-20261111')
source=(native/'tools/ch1_readability_check.gd').read_text(encoding='utf-8')
points=ast.literal_eval(re.search(r'const PROBES := (\{.*?\n\})',source,re.S).group(1))
levels=','.join(points)
results=[]
for mode in ['world','held','pool']:
 for quality in ['high','low']:
  tag=mode+'-complete-'+quality+'-v5'
  argv=[sys.executable,'-X','utf8',str(repo/'work/bg49_run.py'),mode,tag,quality]
  if mode=='held':argv+=['--level='+levels]
  elif mode=='pool':argv+=['--level=ch1_street','--tag=bg49-pool-grounded']
  result=subprocess.run(argv,cwd=repo)
  results.append({'mode':mode,'quality':quality,'tag':tag,'runner_exit':result.returncode})
  (repo/'work/BG49-native-batch.json').write_bytes((json.dumps(results,indent=2)+'\n').encode())
  if result.returncode!=0:raise SystemExit(result.returncode)
print(json.dumps(results))
