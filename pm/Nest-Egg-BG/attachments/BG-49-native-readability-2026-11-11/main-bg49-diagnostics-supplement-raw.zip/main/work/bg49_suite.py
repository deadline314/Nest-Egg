from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path("D:/NestEggVerification/native-ticket-batch-20261111")
repo=Path(__file__).resolve().parents[1]
out=repo/"pm/Nest-Egg-BG/attachments/BG-49-native-readability-2026-11-11/cpu-suite-v1"
out.mkdir(parents=True,exist_ok=False)
paths=["tools/readability_check.gd","tools/ch1_readability_check.gd","tools/bg49_world_readability_probe.gd","tools/bg49_held_readability_probe.gd","tools/bg49_held_pool_probe.gd","tools/verify_bg49_held.py","tests/suite/test_readability_targets.gd","tests/smoke_test.gd","tests/smoke_test.tscn","project.godot"]
before={}
for path in paths:
 raw=(root/path).read_bytes();before[path]=hashlib.sha256(raw).hexdigest()
 dest=out/"source"/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
command=["C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--headless","--path",str(root),"res://tests/smoke_test.tscn","--","--only=ReadabilityTargetsSuite"]
(out/"command.json").write_bytes((json.dumps(command,indent=2)+"\n").encode())
(out/"source-before.json").write_bytes((json.dumps(before,indent=2)+"\n").encode())
(out/"runner.py").write_bytes(Path(__file__).read_bytes())
env=dict(os.environ,APPDATA=str(root/"work/bg49-suite-user"));started=time.monotonic()
with (out/"run.log").open("wb")as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
after={path:hashlib.sha256((root/path).read_bytes()).hexdigest()for path in paths};log=(out/"run.log").read_bytes()
receipt=dict(exit=result.returncode,source_after=after,sources_unchanged=before==after,seconds=time.monotonic()-started,strict_clean=result.returncode==0 and b"SCRIPT ERROR"not in log and b"ERROR:"not in log)
(out/"exit.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
print(log.decode("utf8"));print(json.dumps(receipt,indent=2));assert receipt["strict_clean"]and receipt["sources_unchanged"]
