from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path(os.environ.get('BG49_PROJECT','D:/NestEggVerification/native-ticket-batch-20261111')).resolve()
assert root.name=='native-ticket-batch-20261111' and (root/'project.godot').is_file(), 'BG49 must run in the isolated native project'
mode,tag,quality=sys.argv[1:4]
assert mode in {'held','pool','world','cpu'}
out=root/'work'/('bg49-'+tag);out.mkdir(parents=True,exist_ok=False);(out/'.gdignore').write_bytes(b'')
script={'held':'bg49_held_readability_probe','pool':'bg49_held_pool_probe','world':'bg49_world_readability_probe','cpu':'bg49_held_readability_probe'}[mode]
paths=set(['tools/held_lighting_state.gd','core/light_kit.gd','core/audio/audio_release.gd','game/level/lighting_controller.gd','game/player/player.gd','game/player/player_visual.gd','game/player/weapon_light.gd','game/rig/character_rig.gd','game/level/world_prompt.gd','game/level/environment/fog_layer.gd','data/combat/chapter_rosters.json','data/enemies/sweeper.tres','art/characters/sweeper/character.json'])
for name in ['bg49_held_readability_probe','bg49_held_pool_probe','bg49_world_readability_probe','bg55_enemy_readability_probe','readability_phase_probe','scene_tour','readability_check','ch1_readability_check','harbor_readability_probe','light_pool_probe']:
 for ext in ['.gd','.tscn']:
  if (root/'tools'/(name+ext)).exists():paths.add('tools/'+name+ext)
paths.update(['tools/viewport_capture.gd','tools/contrast_probe.gd'])
paths.update(p.relative_to(root).as_posix()for p in(root/'art/characters/sweeper').rglob('*')if p.is_file()and p.suffix in {'.png','.json','.tres'})
paths.update(['art/rigs/sweeper.json','art/shaders/character_light.gdshader','project.godot'])
for folder,glob in [('data/lighting','*.tres'),('data/levels','ch1_*.tres'),('data/levels','ch1_*.json')]:
 paths.update(p.relative_to(root).as_posix() for p in (root/folder).glob(glob))
for folder in ['game','core','autoload']:
 paths.update(p.relative_to(root).as_posix() for p in (root/folder).rglob('*') if p.is_file() and p.suffix in {'.gd','.gdshader'})
paths=sorted(paths)
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=hashes()
for path in paths:
 dest=out/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((root/path).read_bytes())
(out/'offline-verifier.py').write_bytes((root/'tools/verify_bg49_held.py').read_bytes())
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
(out/'source-before.json').write_text(json.dumps(before,indent=2),encoding='utf8')
command=[sys.executable,str(root/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe']
command+=['--headless','--quit-after','2']if mode=='cpu'else['--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan']
command+=['--path',str(root),'res://tools/'+script+'.tscn','--','--out='+str(out),'--quality='+quality]
if mode=='cpu':command+=['--validate-only']
if mode=='held':command+=['--player','--fixed-aim','--brightness=0.5','--lamps=full']
command+=sys.argv[4:]
(out/'command.json').write_text(json.dumps(command,ensure_ascii=False,indent=2),encoding='utf8')
env=dict(os.environ,APPDATA=str(root/'work'/('bg49-user-'+tag)),PYTHONIOENCODING='utf-8')
started=time.monotonic()
with (out/'run.log').open('wb') as log:
 process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:code=process.wait(timeout=900)
 except subprocess.TimeoutExpired:
  subprocess.run(["taskkill","/PID",str(process.pid),"/T","/F"],capture_output=True);code=124
after=hashes();log=(out/'run.log').read_bytes()
complete=False
if mode=='cpu':complete=b'BG49_DEFAULT_HOOK checks=2 failures=0'in log
elif mode=='world':
 report=out/'readability-report.json'
 if report.exists():
  data=json.loads(report.read_bytes());roi=out/'roi-samples.json'
  complete=bool(data.get('results'))and roi.exists()and len(json.loads(roi.read_bytes()).get('records',[]))==len(data['results'])*16
elif mode=='held':
 reports=list(out.glob('*/bg49-held.json'))
 complete=bool(reports) and all(json.loads(p.read_bytes()).get('results') for p in reports)
else:
 reports=list(out.glob('*-index.json'))
 complete=bool(reports) and all(data.get('levels') and all(level.get('observations') for level in data['levels'].values()) for data in [json.loads(p.read_bytes()) for p in reports])
clean=complete and code==0 and b'ERROR:' not in log and b'SCRIPT ERROR' not in log and b'ObjectDB instances were leaked' not in log
receipt={'exit':code,'completion_artifacts_present':complete,'seconds':time.monotonic()-started,'strict_clean':clean,'sources_unchanged':before==after,'source_after':after,'scope':'native rendering/metadata only; no performance claim; external GPU workloads not controlled'}
(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in receipt.items() if k!='source_after'}));print(log.decode('utf8')[-2800:])
sys.exit(0 if clean and before==after else 1)
