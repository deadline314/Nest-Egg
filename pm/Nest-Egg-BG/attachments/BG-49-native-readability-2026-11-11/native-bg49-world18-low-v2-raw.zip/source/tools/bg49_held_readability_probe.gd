extends "res://tools/bg55_enemy_readability_probe.gd"
## Original eighteen campaign points, pure-world held A/A/B/A comparisons.
## The reference restores freight only at the authored harbor-approach point;
## other points retain their exact authored profile, rather than changing zones.

const Campaign49 := preload("res://tools/ch1_readability_check.gd")
var _spot49 := ""
var _only49 := ""
var _reference49 := "res://data/lighting/freight.tres"
var _has_enemy49 := false


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--spots="):
			_only49 = argument.trim_prefix("--spots=")
	super._ready()
	_walk_player = true
	for node in get_children():
		if node is CanvasLayer:
			for child in node.get_children():
				if child is Label:
					child.text = "BG49 / ORIGINAL CAMPAIGN POINTS / HELD WORLD / SCRIPTED AIM"


func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
	# The original campaign checker includes its arranged foe at the viewport
	# edge. Cancel SceneTour's 24px grid-selection margin, keeping its original
	# body/ring geometry and clipping unchanged.
	var record := await super._capture55(level, world.grow(24.0), label)
	var probe := ContrastProbe.capture(get_viewport())
	if bytes_sha(probe._image.get_data()) != record.raw_sha256:
		printerr("[BG49] Capture changed before player/exposure observation")
		_contrast_failures += 1
	var player := level.player
	var parts := probe.character_parts(player.global_position, true)
	var body := probe._body_box(player.global_position, true)
	var edge := Rect2(player.global_position + Vector2(-24, 0), Vector2(48, 3))
	var below := Rect2(player.global_position + Vector2(-24, 8), Vector2(48, 6))
	record["player"] = {"feet": [player.global_position.x, player.global_position.y], "parts": parts, "contrast": maxf(parts.bright, parts.dark),
		"screen_rect": rect_values(probe._screen_rect(body)),
		"outer_screen_rect": rect_values(probe._screen_rect(body.grow(ContrastProbe.RING))),
		"edge_screen_rect": rect_values(probe._screen_rect(edge)),
		"below_screen_rect": rect_values(probe._screen_rect(below)),
		"edge_contrast": probe.edge_contrast(player.global_position)}
	var exposure: Array[Dictionary] = []
	for enemy in record.enemies:
		var actor := instance_from_id(int(enemy.instance)) as Enemy
		var bounds := probe._body_box(actor.global_position, false)
		if actor.rig != null:
			bounds = bounds.merge(actor.rig.visual_bounds())
			var weapon := actor.rig._weapon_sprite
			if weapon != null and weapon.texture != null and weapon.is_visible_in_tree():
				bounds = bounds.merge(weapon.global_transform * weapon.get_rect())
		var rect := probe._screen_rect(bounds.grow(1.0))
		var white := 0
		var peak := 0.0
		for y in range(rect.position.y, rect.end.y):
			for x in range(rect.position.x, rect.end.x):
				var color := probe._image.get_pixel(x, y)
				peak = maxf(peak, maxf(color.r, maxf(color.g, color.b)))
				if color.r > 0.92 and color.g > 0.92 and color.b > 0.92:
					white += 1
		exposure.append({"instance": enemy.instance, "id": enemy.id, "screen_rect": rect_values(rect),
			"world_bounds": [bounds.position.x, bounds.position.y, bounds.size.x, bounds.size.y],
			"white_pixels_including_background": white, "peak": peak,
			"enemy_white_ratio": 0.0 if white == 0 and rect.has_area() else null,
			"coverage": "merged legacy body, actual rig and weapon; zero proves zero; nonzero has no enemy-only denominator"})
	record["exposure"] = exposure
	var prompts: Array[String] = []
	for node in level.find_children("*", "", true, false):
		if node is WorldPrompt and node.is_visible_in_tree():
			prompts.append(str(node.get_path()))
	record["visible_world_prompts"] = prompts
	return record


func _measure(level: Level, world: Rect2) -> Dictionary:
	_reference55 = _reference49 if _spot49 == "碼頭入口" else ""
	var result := await super._measure(level, world)
	var records: Array = result.bg55.records
	var product: Dictionary = records[-1]
	if _has_enemy49 and (product.enemies.is_empty() or product.exposure.is_empty()):
		printerr("[BG49] Original arranged enemy is absent from the measurements")
		_contrast_failures += 1
	if product.player.contrast < ContrastProbe.MIN_PLAYER_CONTRAST or product.player.edge_contrast < ContrastProbe.MIN_EDGE_CONTRAST:
		printerr("[BG49] Player/edge below unchanged threshold at " + _spot49)
		_contrast_failures += 1
	for record in records:
		if not record.visible_world_prompts.is_empty():
			printerr("[BG49] World prompt contaminates " + _spot49)
			_contrast_failures += 1
		if _spot49 != "碼頭入口" and record.raw_sha256 != records[0].raw_sha256:
			printerr("[BG49] Unchanged point differs in held counterfactual: " + _spot49)
			_contrast_failures += 1
	if _spot49 == "碼頭入口":
		for exposure in product.exposure:
			if exposure.enemy_white_ratio == null:
				printerr("[BG49] Saturated rectangle requires an enemy-only bound")
				_contrast_failures += 1
	result["bg49"] = {"spot": _spot49, "kind": "same current geometry; original freight profile restored only at harbor; not historical checkout",
		"reference_profile": _reference55, "reference_sha256": FileAccess.get_sha256(_reference55) if not _reference55.is_empty() else "",
		"source_sha256": FileAccess.get_sha256("res://tools/bg49_held_readability_probe.gd")}
	return result


func _tour(level_id: String) -> bool:
	if not Campaign49.PROBES.has(level_id):
		printerr("[BG49] No original campaign points for " + level_id)
		return false
	var path := "res://data/levels/%s.tres" % level_id
	var source := load(path) as LevelData
	if source == null or DirAccess.make_dir_recursive_absolute(_out.path_join(level_id)) != OK:
		return false
	var failures_before := _contrast_failures
	var results: Array[Dictionary] = []
	for spot: Array in Campaign49.PROBES[level_id]:
		if not _only49.is_empty() and not _only49.split(",").has(str(spot[0])):
			continue
		_spot49 = str(spot[0])
		GameState.start_new_run(GameState.difficulties[1])
		var data := source.duplicate() as LevelData
		data.intro_scene = &""
		data.show_chapter_card = false
		var level := Level.new()
		level.configure(data)
		add_child(level)
		level._arena_triggered = true
		for node in level.find_children("*", "", true, false):
			if node is EncounterZone:
				node.restore_state(true)
			elif node is WorldPrompt:
				node.visible = false
				node.process_mode = Node.PROCESS_MODE_DISABLED
			elif node is ChapterCard:
				node.queue_free()
		for node in get_tree().get_nodes_in_group(&"enemies"):
			node.queue_free()
		level.hud.visible = false
		level.player.health.setup(999, 0.0)
		AimInput.set_virtual_gamepad(level.player, true)
		var tile := int(spot[1])
		var floor_y := float(spot[2]) * level._layout.tile_size
		var expected := Vector2(tile * level._layout.tile_size + 8.0, floor_y)
		level.player.global_position = expected - Vector2(0, 2)
		level.player.velocity = Vector2.ZERO
		var foe: Enemy
		var foe_expected := Vector2((tile + 6) * level._layout.tile_size + 8.0, floor_y)
		if level_id in ["ch1_street", "ch1_warehouse", "ch1_vault"]:
			foe = level._create_enemy(load("res://data/enemies/sweeper.tres"))
			foe.data = foe.data.duplicate()
			foe.data.detect_range = 0.0
			foe.data.attack_range = 0.0
			foe.data.move_speed = 0.0
			foe.position = foe_expected - Vector2(0, 2)
			foe.facing = -1
			level._entities.add_child(foe)
			foe.health.setup(999, 0.0)
		_has_enemy49 = foe != null
		await _settle(24)
		var camera := get_viewport().get_camera_2d() as LevelCamera
		camera.set_physics_process(false)
		camera.snap_to_target()
		camera.force_update_scroll()
		level._lighting.snap()
		_sync55(level)
		await _settle(4)
		var valid := level.player.global_position.distance_to(expected) <= 4.0
		if foe != null:
			valid = valid and foe.global_position.distance_to(foe_expected) <= 4.0
		if not valid:
			printerr("[BG49] Actors not on original sampling floors: " + _spot49)
			_contrast_failures += 1
		var transform := get_viewport().get_canvas_transform().affine_inverse()
		var world := transform * get_viewport().get_visible_rect()
		var result := await _measure(level, world)
		result["sampling_valid"] = valid
		result["expected_player_feet"] = str(expected)
		result["actual_player_feet"] = str(level.player.global_position)
		results.append(result)
		print("BG49_POINT ", level_id, " / ", _spot49, " / valid=", valid)
		Engine.time_scale = _time_scale55
		level.queue_free()
		for frame in 6:
			await get_tree().process_frame
		_held55 = null
	var writer := FileAccess.open(_out.path_join(level_id).path_join("bg49-held.json"), FileAccess.WRITE)
	if writer == null:
		return false
	writer.store_string(JSON.stringify({"level": level_id, "quality": Settings.get_light_quality(), "brightness": Settings.get_brightness(),
		"engine": Engine.get_version_info().string, "adapter": RenderingServer.get_video_adapter_name(),
		"renderer": RenderingServer.get_current_rendering_method(), "hdr": get_viewport().use_hdr_2d,
		"level_sha256": FileAccess.get_sha256(path), "results": results}, "\t"))
	if results.is_empty():
		printerr("[BG49] No original sampling point matches " + _only49)
		return false
	return failures_before == _contrast_failures
