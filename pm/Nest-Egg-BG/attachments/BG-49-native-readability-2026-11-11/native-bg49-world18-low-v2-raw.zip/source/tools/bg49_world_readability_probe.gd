extends "res://tools/harbor_readability_probe.gd"
## Original sixteen time samples at each of the eighteen campaign positions.
## Keep prompts disabled throughout the run: hiding once is undone by their owner.

var _prompts49 := {}
var _scan49 := true


func _ready() -> void:
	super._ready()
	Settings.set_brightness(0.5)
	for node in get_children():
		if node is CanvasLayer:
			for child in node.get_children():
				if child is Label:
					child.text = "BG49 / PURE WORLD / ORIGINAL 18 POINTS + 16 TIME SAMPLES / SCRIPTED AIM"


func _process(delta: float) -> void:
	super._process(delta)
	if not _scan49:
		return
	for node in find_children("*", "", true, false):
		if node is WorldPrompt:
			_prompts49[str(node.get_path())] = true
			node.visible = false
			node.process_mode = Node.PROCESS_MODE_DISABLED
	_scan49 = false


func _check_level(path: String, spots: Array, enemy_path := "res://data/enemies/grunt.tres") -> void:
	_scan49 = true
	await super._check_level(path, spots, enemy_path)


func _run() -> void:
	await super._run()
	if _out_dir.is_empty():
		return
	var path := _out_dir.path_join("readability-report.json")
	var report: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
	var environment := get_viewport().find_world_3d().environment
	var bloom_valid: bool = environment != null and environment.glow_enabled
	if not bloom_valid:
		printerr("[BG49World] Main-equivalent HDR bloom is not active")
		get_tree().quit(1)
	report["pure_world"] = {"world_prompt_process_disabled": true, "distinct_prompt_paths": _prompts49.keys(),
		"bloom_active": bloom_valid,
		"capture_size": [get_viewport().get_texture().get_width(), get_viewport().get_texture().get_height()],
		"adapter": RenderingServer.get_video_adapter_name(), "renderer": RenderingServer.get_current_rendering_method(),
		"hdr_2d": get_viewport().use_hdr_2d, "source_sha256": FileAccess.get_sha256("res://tools/bg49_world_readability_probe.gd"),
		"original_sampling_sha256": FileAccess.get_sha256("res://tools/readability_check.gd"),
		"original_points_sha256": FileAccess.get_sha256("res://tools/ch1_readability_check.gd"),
		"viewport_capture_sha256": FileAccess.get_sha256("res://tools/viewport_capture.gd"),
		"contrast_probe_sha256": FileAccess.get_sha256("res://tools/contrast_probe.gd")}
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		push_error("[BG49World] Cannot preserve final metadata: " + path)
		get_tree().quit(2)
		return
	file.store_string(JSON.stringify(report, "\t"))
