"""Independently recompute held BG-49 observations from original floating bytes."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

import numpy as np
from PIL import Image

FORMATS = {14: ("<f2", 3), 15: ("<f2", 4), 10: ("<f4", 3), 11: ("<f4", 4)}


def raster(world, record):
    x, y, w, h = world
    values = [float(v) for v in re.findall(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", record["canvas_transform"])]
    xx, xy, yx, yy, ox, oy = values
    points = np.array([[x, y], [x + w, y], [x, y + h], [x + w, y + h]])
    screen = (points @ [[xx, xy], [yx, yy]] + [ox, oy]) * record["density"]
    start = np.maximum(np.floor(screen.min(axis=0)), [0, 0]).astype(int)
    end = np.minimum(np.ceil(screen.max(axis=0)), [record["width"], record["height"]]).astype(int)
    return [*start.tolist(), *(np.maximum(0, end - start)).tolist()]


def section(pixels, rect):
    x, y, w, h = rect
    return pixels[y:y + h, x:x + w]


def contrast(rgb, body, outer):
    luma = rgb @ [0.2126, 0.7152, 0.0722]
    values = section(luma, body).reshape(-1)
    x, y, w, h = body
    ox, oy, ow, oh = outer
    yy, xx = np.mgrid[oy:oy + oh, ox:ox + ow]
    mask = ~((xx >= x) & (xx < x + w) & (yy >= y) & (yy < y + h))
    ring = section(luma, outer)[mask]
    assert values.size and ring.size, (body, outer)
    outside = float(ring.mean())
    inner = float(np.quantile(values, .9, method="lower"))
    dark = float(np.quantile(values, .25 if outside >= .12 else .5, method="lower"))
    return dict(inner=inner, body=dark, outer=outside, bright=(inner - outside) / (outside + .02), dark=(outside - dark) / (outside + .02))


def load_pixels(folder, record):
    raw = (folder / record["files"]["raw"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == record["raw_sha256"]
    dtype, channels = FORMATS[record["format"]]
    rgb = np.frombuffer(raw, dtype=dtype).reshape(record["height"], record["width"], channels)[..., :3].astype(np.float64)
    assert np.isfinite(rgb).all()
    image = np.asarray(Image.open(folder / record["files"]["png"]).convert("RGB"), dtype=np.float64) / 255
    expected = np.where(rgb <= .0031308, rgb * 12.92, 1.055 * np.maximum(rgb, 0) ** (1 / 2.4) - .055)
    assert np.max(np.abs(image - np.clip(expected, 0, 1))) <= 1 / 255 + .00001
    return rgb


def verify_held(folder):
    totals = dict(points=0, images=0, actor_observations=0)
    observations = []
    for path in sorted(folder.glob("*/bg49-held.json")):
        data = json.loads(path.read_bytes())
        assert data["hdr"] and data["renderer"] == "forward_plus"
        for result in data["results"]:
            assert result["sampling_valid"]
            group = result["bg55"]
            assert group["controls_valid"]
            records = group["records"]
            first = records[0]
            final = records[-1]
            spot = result["bg49"]["spot"]
            for record in records:
                rgb = load_pixels(path.parent, record)
                totals["images"] += 1
                assert record["held"] == first["held"]
                assert record["held"]["lighting_owners"]["valid"]
                assert record["visible_world_prompts"] == []
                assert record["world_environment"]["active"] and record["world_environment"]["glow_enabled"]
                assert record["player_visible"]
                assert record["weapon_light"]["origin_error"] <= .00001
                assert record["weapon_light"]["fade_level"] >= .999
                if record["label"] in ["A1", "restore-product"] or spot != "碼頭入口":
                    assert record["raw_sha256"] == first["raw_sha256"]
                if record["label"] == "product":
                    assert record["raw_sha256"] == final["raw_sha256"]
                actors = [(record["player"], True)] + [(enemy, False) for enemy in record["enemies"]]
                for actor, player in actors:
                    fx, fy = actor["feet"]
                    body = raster([fx - 9, fy - (58 if player else 44), 18, 54 if player else 40], record)
                    outer = raster([fx - 29, fy - (78 if player else 64), 58, 94 if player else 80], record)
                    assert body == actor["screen_rect"] and outer == actor["outer_screen_rect"]
                    values = contrast(rgb, body, outer)
                    for name, number in values.items():
                        assert abs(number - actor["parts"][name]) < .000002, (spot, name, number, actor["parts"][name])
                    assert abs(max(values["bright"], values["dark"]) - actor["contrast"]) < .000002
                    totals["actor_observations"] += 1
                player = record["player"]
                fx, fy = player["feet"]
                edge = raster([fx - 24, fy, 48, 3], record)
                below = raster([fx - 24, fy + 8, 48, 6], record)
                assert edge == player["edge_screen_rect"] and below == player["below_screen_rect"]
                luma = rgb @ [0.2126, 0.7152, 0.0722]
                edge_contrast = (section(luma, edge).mean() - section(luma, below).mean()) / (section(luma, below).mean() + .02)
                assert abs(edge_contrast - player["edge_contrast"]) < .000002
                for exposure in record["exposure"]:
                    world = exposure["world_bounds"]
                    grown = [world[0] - 1, world[1] - 1, world[2] + 2, world[3] + 2]
                    assert raster(grown, record) == exposure["screen_rect"]
                    area = section(rgb, exposure["screen_rect"])
                    white = int(np.all(area > .92, axis=-1).sum())
                    assert area.size > 0 and white == exposure["white_pixels_including_background"]
                    assert abs(float(area.max()) - exposure["peak"]) < .000002
                    assert exposure["enemy_white_ratio"] == (0.0 if white == 0 else None)
            assert final["player"]["contrast"] >= .6 and final["player"]["edge_contrast"] >= 1.0
            assert all(enemy["contrast"] >= .45 for enemy in final["enemies"])
            if spot == "碼頭入口":
                assert final["exposure"] and all(e["enemy_white_ratio"] == 0.0 for e in final["exposure"])
            totals["points"] += 1
            observations.append(dict(spot=spot, player=final["player"]["contrast"], edge=final["player"]["edge_contrast"],
                                     enemies=[e["contrast"] for e in final["enemies"]], controls_valid=True))
    assert totals["points"] > 0
    return dict(**totals, observations=observations)


def verify_pool(folder):
    observations = []
    for path in sorted(folder.glob("*-index.json")):
        index = json.loads(path.read_bytes())
        assert index["invalid_focus_samples"] == 0
        for level in index["levels"].values():
            assert level["hdr"]
            for lamp in level["observations"]:
                assert lamp["controls_valid"] and lamp["no_drop"]
                records = lamp["records"]
                assert len(records) == 5
                for record in records:
                    assert record["bloom_active"] and record["brightness"] == .5
                    assert record["state"] == records[0]["state"]
                    assert record["state"]["drawing_owners"]["valid"]
                    assert abs(record["target_x"] - record["lamp_x"]) < .001
                    synthetic = dict(record, files={"raw": record["raw"], "png": record["png"]})
                    load_pixels(folder, synthetic)
                    shown = np.asarray(Image.open(folder / record["png"]).convert("RGB"), dtype=np.float64) / 255
                    linear = np.where(shown <= .04045, shown / 12.92, ((shown + .055) / 1.055) ** 2.4)
                    luma = linear @ [.2126, .7152, .0722]
                    xx, xy, yx, yy, ox, oy = [float(v) for v in re.findall(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", record["world_to_screen"])]
                    assert abs(xy) < .00001 and abs(yx) < .00001 and xx > 0 and abs(xx - yy) < .00001
                    scale = xx
                    formula = record["formula"]
                    assert formula == dict(height=14.0, half_width=26.0, far_from=1.1, far_to=1.6, far_min=.004)
                    eligible = [band for band in record["bands"] if band["pool_wall_eligible"]]
                    assert eligible
                    band = eligible[0]
                    lx, ly = record["lamp_position"]
                    center_x, center_y = lx * xx + ox, (ly + band["drop"]) * yy + oy
                    rows = max(1, int(14 * scale))
                    top = int(center_y) - rows // 2

                    def sample(start, end):
                        left, right = max(0, int(start)), min(record["width"], int(end))
                        upper, lower = max(0, top), min(record["height"], top + rows)
                        assert left < right and upper < lower
                        return luma[upper:lower, left:right].mean(axis=0)

                    pool = sample(center_x - 26 * scale, center_x + 26 * scale)
                    far = []
                    for side, covered in zip([-1, 1], band["far_wall_eligible"]):
                        if covered:
                            start = center_x + side * record["lamp_radius"] * 1.1 * scale
                            end = center_x + side * record["lamp_radius"] * 1.6 * scale
                            far.extend(sample(min(start, end), max(start, end)))
                    assert far
                    pool_value = float(np.quantile(pool, .5, method="lower"))
                    far_value = float(np.quantile(far, .5, method="lower"))
                    ratio = pool_value / max(far_value, .004)
                    for name, value in [("pool", pool_value), ("far", far_value), ("ratio", ratio)]:
                        assert abs(value - record[name]) < .00002, (name, value, record[name])
                assert records[0]["raw_sha256"] == records[1]["raw_sha256"] == records[3]["raw_sha256"]
                assert records[2]["raw_sha256"] == records[4]["raw_sha256"]
                assert records[2]["ratio"] >= records[0]["ratio"] > 0
                observations.append(dict(lamp=lamp["lamp_tile"], before=records[0]["ratio"], after=records[2]["ratio"], controls_valid=True))
    assert observations
    return dict(lamps=len(observations), observations=observations)


def verify_world(folder):
    data = json.loads((folder / "readability-report.json").read_bytes())
    assert data["samples_per_spot"] == 16 and data["sample_interval"] == .2
    assert data["thresholds"] == dict(player=.6, edge=1.0, enemy=.45)
    assert data["brightness"] == .5
    assert data["pure_world"]["bloom_active"] and data["pure_world"]["world_prompt_process_disabled"]
    spots = data["results"]
    for spot in spots:
        assert spot["sampling_valid"] and spot["passed"]
        assert spot["player_contrast"] >= .6 and spot["edge_contrast"] >= 1
        assert spot["enemy_contrast"] is None or spot["enemy_contrast"] >= .45
        image = Image.open(folder / spot["screenshot"])
        assert list(image.size) == data["pure_world"]["capture_size"]
        assert image.width / data["viewport"][0] == image.height / data["viewport"][1] > 0
    assert spots
    assert len({(spot["level"], spot["column"]) for spot in spots}) == len(spots)
    return dict(points=len(spots), observations=[dict(spot=s["spot"], player=s["player_contrast"], enemy=s["enemy_contrast"], edge=s["edge_contrast"]) for s in spots])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", type=Path)
    parser.add_argument("--kind", choices=["held", "pool", "world"], default="held")
    args = parser.parse_args()
    result = {"held": verify_held, "pool": verify_pool, "world": verify_world}[args.kind](args.folder)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
