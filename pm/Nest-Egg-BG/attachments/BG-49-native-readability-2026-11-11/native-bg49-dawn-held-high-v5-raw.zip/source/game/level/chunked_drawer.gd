@abstract
class_name ChunkedDrawer
extends Node2D
## 分塊繪製框架：把大面積的靜態繪製切成多個區塊節點。
## 好處：畫面外的區塊自動被剔除；每個光源只需重繪「光照範圍內」的區塊，大幅降低光影成本。
## 子類別實作 _draw_chunk(canvas, rect)，在 rect（世界座標）範圍內呼叫 canvas.draw_*。

const CHUNK_WIDTH := 320.0

## true 時區塊用自發光材質（不受環境光壓暗），例如地形的亮邊。
var emissive := false
## 指定時所有區塊改用這份材質（例如會閃爍的窗光），優先於 emissive。
var chunk_material: Material = null

var _bounds := Rect2()


## 依範圍建立區塊。呼叫前請先設定子類別需要的資料。
func build_chunks(bounds: Rect2) -> void:
	_bounds = bounds
	for child in get_children():
		if child is _Chunk:
			child.queue_free()
	var x := bounds.position.x
	while x < bounds.end.x:
		var chunk := _Chunk.new()
		chunk.owner_drawer = self
		if chunk_material != null:
			chunk.material = chunk_material
		elif emissive:
			LightKit.mark_emissive(chunk)
		chunk.rect = Rect2(x, bounds.position.y, minf(CHUNK_WIDTH, bounds.end.x - x), bounds.size.y)
		add_child(chunk)
		x += CHUNK_WIDTH


## 子類別覆寫：只繪製落在 rect 內的內容（座標為本節點的區域座標）。
@abstract func _draw_chunk(canvas: CanvasItem, rect: Rect2) -> void


class _Chunk:
	extends Node2D

	var owner_drawer: ChunkedDrawer
	var rect := Rect2()

	func _init() -> void:
		# 材質用 draw_texture_rect_region 超出貼圖範圍的部分平鋪，需要開啟重複取樣。
		texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED

	func _draw() -> void:
		if owner_drawer != null:
			owner_drawer._draw_chunk(self, rect)
