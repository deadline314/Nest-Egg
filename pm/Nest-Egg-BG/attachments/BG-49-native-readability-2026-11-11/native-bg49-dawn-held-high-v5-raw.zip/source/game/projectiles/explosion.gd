class_name Explosion
extends Node2D
## 範圍爆炸：在第一個物理影格查詢範圍內的受擊框並造成傷害，視覺效果統一由 Fx 的既有圖集與環池播放。
## 請透過 Fx.explosion() 生成。

const DURATION := 0.3
const MAX_TARGETS := 32
## 爆炸的衝擊力（重擊，打得一般敵人硬直）。
const BLAST_IMPACT := 7.0

var radius := 24.0
var damage := 1
var team: Combat.Team = Combat.Team.ENEMY
var source_id: StringName = &""
var color := Palette.WARNING

var _age := 0.0
var _applied := false


func _physics_process(delta: float) -> void:
	if not _applied:
		_applied = true
		_apply_damage()
	_age += delta
	if _age >= DURATION:
		queue_free()
		return


func _apply_damage() -> void:
	if damage <= 0 or radius <= 0.0:
		return
	var shape := CircleShape2D.new()
	shape.radius = radius
	var params := PhysicsShapeQueryParameters2D.new()
	params.shape = shape
	params.transform = Transform2D(0.0, global_position)
	params.collision_mask = Combat.hurtbox_mask_against(team)
	params.collide_with_areas = true
	params.collide_with_bodies = false
	var seen: Dictionary = {}
	for hit in get_world_2d().direct_space_state.intersect_shape(params, MAX_TARGETS):
		var hurtbox := hit.get("collider") as Hurtbox
		hurtbox = hurtbox.root() if hurtbox != null else null  # 爆炸打整體，不分部位
		if hurtbox == null or seen.has(hurtbox):
			continue
		seen[hurtbox] = true
		var info := DamageInfo.create(damage, team, source_id)
		var away := hurtbox.global_position - global_position
		info.knockback = (away.normalized() if away.length_squared() > 1.0 else Vector2.UP) * 180.0 + Vector2(0, -80)
		info.origin = global_position
		info.bypass_guard = true
		info.impact = BLAST_IMPACT
		hurtbox.receive(info)
