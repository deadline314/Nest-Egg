from pathlib import Path
import hashlib, json, os, statistics, subprocess
import psutil

primary=Path('C:/Users/stanl/Github/Nest-Egg')
root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg36-current')
assert json.loads((base/'native/result.json').read_text())['all_passed']
assert json.loads((base/'checks/result.json').read_text())['all_passed']
out=base/'fixture-cost-v2'; out.mkdir(exist_ok=False)
private=root/'work/bg36-fixture-cost-v2';private.mkdir(exist_ok=False)
(private/'probe.gd').write_text('''extends "res://tools/scene_motion_probe.gd"
func _run() -> void:
    var white_block := "--white-block-control" in OS.get_cmdline_user_args()
    add_child(LightKit.create_environment())
    Settings.set_light_quality(QUALITY[_quality])
    Lamp.flicker_hold = 1.0
    DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
    Engine.max_fps = 0
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var results := []
    for id: String in ["ch1_street","ch1_warehouse","ch1_vault"]:
        _level_id = id
        var level := await _open_level()
        var lamps: Array[Lamp] = []
        for node: Node in level.find_children("*","Node2D",true,false):
            if node is Lamp:
                lamps.append(node)
                if white_block:
                    node._body.hide()
                    var card := Node2D.new()
                    LightKit.mark_emissive(card)
                    card.draw.connect(func() -> void:
                        card.draw_rect(Rect2(-6,-2,12,3),Palette.TERRAIN_TOP)
                        card.draw_rect(Rect2(-4,1,8,2),Color(node.color.darkened(0.7),0.5) if node.dead else LightKit.glow(node.color,2.5)))
                    node.add_child(card)
            if node is Enemy or node is NpcActor:
                node.hide()
                node.process_mode = Node.PROCESS_MODE_DISABLED
                for child: Node in node.find_children("*","",true,false): child.process_mode = Node.PROCESS_MODE_DISABLED
        lamps.sort_custom(func(a: Lamp,b: Lamp) -> bool: return a.position.x < b.position.x)
        var camera := get_viewport().get_camera_2d() as LevelCamera
        camera.set_physics_process(false)
        camera.offset = Vector2.ZERO
        camera.global_position = lamps[0].global_position + Vector2(0,50)
        camera.reset_smoothing()
        camera.force_update_scroll()
        level._lighting._target = camera
        await _settle(120)
        var contract := []
        var active_actors := 0
        for node: Node in level.find_children("*","",true,false):
            if (node is Enemy or node is NpcActor or node is CutsceneActor) and node.can_process(): active_actors += 1
        assert(active_actors == 0 and not level.player.can_process())
        for lamp in lamps:
            assert(lamp._body.visible != white_block)
            contract.append({"id":String(lamp.fixture_id),"position":[lamp.position.x,lamp.position.y],"radius":lamp.light_radius,
                "energy":lamp.light_energy,"dead":lamp.dead,"supported":lamp.is_supported(),"body_visible":lamp._body.visible})
        var samples: Array[float] = []
        var last := Time.get_ticks_usec()
        for frame in 180:
            await get_tree().process_frame
            var now := Time.get_ticks_usec()
            samples.append((now-last)/1000.0)
            last = now
        await RenderingServer.frame_post_draw
        var image := Capture.image(get_viewport())
        assert(image.save_png(_out.path_join(id+".png")) == OK)
        results.append({"level":id,"quality":_quality,"white_block_control":white_block,"samples_ms":samples,
            "active_actors":active_actors,"lamps":contract,"vsync":DisplayServer.window_get_vsync_mode(),
            "texture_reported_size":[get_viewport().get_texture().get_width(),get_viewport().get_texture().get_height()],
            "viewport":[image.get_width(),image.get_height()]})
        level.queue_free()
        await _settle(8)
    var writer := FileAccess.open(_out.path_join("samples.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify(results,"\\t"))
    writer.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit()
''',encoding='utf8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg36-fixture-cost-v2/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
def godots():
    result=[]
    for p in psutil.process_iter(['pid','name']):
        if 'godot' in (p.info['name'] or '').lower():result.append(p.info)
    return result
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
runs=[]
for quality in ['low','high']:
    for order,mode in enumerate(['fixtures','white-block','white-block','fixtures'],1):
        folder=out/(quality+'-'+str(order)+'-'+mode);folder.mkdir()
        env=os.environ.copy()
        for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg36-fixture-cost-v2/probe.tscn','--','--out='+str(folder),'--quality='+quality,'--level=ch1_street','--prop=unused']
        if mode=='white-block':command.append('--white-block-control')
        activity=godots();assert activity==[],activity
        with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        raw=(folder/'raw.log').read_bytes()
        row={'quality':quality,'mode':mode,'order':order,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'godot_before':activity,'godot_after':godots(),'source_held':before==snapshot()}
        runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
        assert row['exit']==row['script_errors']==0 and row['source_held'] and row['godot_after']==[],row
        rows=json.loads((folder/'samples.json').read_text());assert len(rows)==3
        assert all(len(a['samples_ms'])==180 and a['active_actors']==0 and a['vsync']==0 and a['viewport']==[1280,720] for a in rows)
ratios=[]
for quality in ['low','high']:
    for index,level in enumerate(['ch1_street','ch1_warehouse','ch1_vault']):
        groups={m:[] for m in ['fixtures','white-block']};contracts=[]
        for row in runs:
            if row['quality']!=quality:continue
            sample=json.loads((out/(quality+'-'+str(row['order'])+'-'+row['mode'])/'samples.json').read_text())[index]
            groups[row['mode']].append(statistics.median(sample['samples_ms']))
            contracts.append([{k:v for k,v in lamp.items() if k!='body_visible'} for lamp in sample['lamps']])
        assert all(a==contracts[0] for a in contracts)
        ratio=statistics.mean(groups['fixtures'])/statistics.mean(groups['white-block'])
        ratios.append({'quality':quality,'level':level,'medians_ms':groups,'ratio':ratio})
result={'scope':'Current-scene single-factor intervention. White rectangles replace only fixture art and supports; current light pools, shafts, positions, shadows and lamp processing remain. Lamp flicker held steady in both arms. Not a historical checkout or combat benchmark. All own native and test producers finished before timing.','source_held':before==snapshot(),'ratios':ratios,'within_105_percent':all(r['ratio']<=1.05 for r in ratios)}
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
