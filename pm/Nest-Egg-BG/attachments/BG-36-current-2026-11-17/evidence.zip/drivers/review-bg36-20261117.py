from pathlib import Path
import hashlib,json
from PIL import Image,ImageDraw

base=Path('D:/NestEggVerification/evidence-20261117/bg36-current')
out=base/'review-v2';out.mkdir(exist_ok=False)
assert json.loads((base/'native/result.json').read_text())['all_passed']
assert json.loads((base/'fixture-cost-v2/result.json').read_text())['within_105_percent']
records=[]
for level in ['ch1_street','ch1_warehouse','ch1_vault','ch1_rooftop','ch1_booth_alley','ch1_stall','ch1_pawnshop','ch1_lounge']:
    files=sorted((base/'native/tour-low').glob(level+'-*.png'))
    for start in range(0,len(files),3):
        canvas=Image.new('RGB',(1280,3*390),(18,18,22));draw=ImageDraw.Draw(canvas);sources=[]
        for row,file in enumerate(files[start:start+3]):
            for column,quality in enumerate(['low','high']):
                source=base/('native/tour-'+quality)/file.name
                im=Image.open(source);assert im.size==(1280,720)
                canvas.paste(im.resize((640,360)),(column*640,row*390+26))
                draw.text((column*640+6,row*390+6),quality+' '+file.stem,fill='white')
                sources.append({'path':str(source.relative_to(base)),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
        path=out/(level+'-'+str(start//3+1)+'.png');canvas.save(path)
        records.append({'page':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sources':sources})
for quality in ['low','medium']:
    source=base/('native/gallery-'+quality)/'lamps-unlit.png'
    assert Image.open(source).size==(2515,1415)
for mode in ['fixtures','white-block']:
    for level in ['ch1_street','ch1_warehouse','ch1_vault']:
        source=base/('fixture-cost-v2/high-'+('1' if mode=='fixtures' else '2')+'-'+mode)/(level+'.png')
        target=out/(mode+'-'+level+'.png');target.write_bytes(source.read_bytes())
        records.append({'page':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'sources':[{'path':str(source.relative_to(base)),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}]})
(out/'index.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'pages':len(records),'tour_images':sum(len(r['sources']) for r in records if r['page'].startswith('ch1_')),'names':[r['page'] for r in records]}),flush=True)
