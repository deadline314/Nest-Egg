from pathlib import Path
import hashlib, json, os, subprocess

primary = Path('C:/Users/stanl/Github/Nest-Egg')
root = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg36-current/gallery-before-write-control')
out.mkdir(parents=True, exist_ok=False)
paths = [p for p in subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'core', 'game', 'data', 'ui', 'art', 'tools', 'tests', 'project.godot'], cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
assert all((root/p).read_bytes().replace(b'\r\n', b'\n') == (primary/p).read_bytes().replace(b'\r\n', b'\n') for p in paths)
def snapshot(): return {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
(out/'source-before.json').write_text(json.dumps(before, indent=2)+'\n')
(out/'lamps-lit.png').mkdir()
env = os.environ.copy()
for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']: env[key] = str(out/'private-profile'/key)
command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', str(primary/'tools/comfyui/gpu_lock.py'), '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '2560x1440', 'res://tools/lamp_gallery.tscn', '--', '--out='+str(out)]
with (out/'raw.log').open('wb') as log: run = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
raw = (out/'raw.log').read_bytes()
record = {'command': command, 'exit': run.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'source_held': before == snapshot(), 'images': [p.name for p in out.glob('*.png') if p.is_file()], 'write_error': b'ERROR:' in raw}
(out/'source-after.json').write_text(json.dumps(snapshot(), indent=2)+'\n')
(out/'result.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record), flush=True)
assert record['source_held'] and record['script_errors'] == 0
assert run.returncode == 0 and record['images'] == ['lamps-unlit.png'] and record['write_error'], 'negative control did not reproduce false success'
