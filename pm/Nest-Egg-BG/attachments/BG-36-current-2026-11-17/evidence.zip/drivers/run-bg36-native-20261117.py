from pathlib import Path
import hashlib, json, os, subprocess

primary = Path('C:/Users/stanl/Github/Nest-Egg')
root = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg36-current/native')
out.mkdir(exist_ok=False)
(root/'tools/lamp_gallery.gd').write_bytes((primary/'tools/lamp_gallery.gd').read_bytes())
private = root/'work/bg36-native'
private.mkdir(exist_ok=False)
(private/'gallery.gd').write_text('''extends "res://tools/lamp_gallery.gd"
func _ready() -> void:
    for arg: String in OS.get_cmdline_user_args():
        if arg.begins_with("--quality="):
            Settings.set_light_quality({"low":0,"medium":1,"high":2}[arg.trim_prefix("--quality=")])
    super._ready()
func _settle(frames: int) -> void:
    await super._settle(frames)
    var rows := []
    for lamp in _lamps:
        var lit := LightKit.lamp_power > 0.0
        assert(lamp.is_supported() and lamp._art != null and lamp._glow != null)
        assert(lamp._body.z_index == WorldLayers.PROPS)
        assert(lamp._light.enabled == lit and lamp._glow.visible == lit)
        rows.append({"id":String(lamp.fixture_id),"mount":String(lamp.mount()),"supported":lamp.is_supported(),
            "light_enabled":lamp._light.enabled,"glow_visible":lamp._glow.visible,"art_tint":lamp._art.self_modulate.r,
            "light_radius":lamp.light_radius,"light_energy":lamp.light_energy,"light_color":str(lamp.light_color)})
    print("BG36_GALLERY ",JSON.stringify({"power":LightKit.lamp_power,"quality":Settings.get_light_quality(),
        "hdr":get_viewport().use_hdr_2d,"environments":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),"lamps":rows}))
''', encoding='utf8', newline='\n')
(private/'tour.gd').write_text('''extends "res://tools/scene_motion_probe.gd"
func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(QUALITY[_quality])
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var records := []
    for id: String in ["ch1_street","ch1_warehouse","ch1_vault","ch1_rooftop","ch1_booth_alley","ch1_stall","ch1_pawnshop","ch1_lounge"]:
        var first := []
        for entry in 2:
            _level_id = id
            var level := await _open_level()
            var lamps: Array[Lamp] = []
            for node: Node in level.find_children("*","Node2D",true,false):
                if node is Lamp: lamps.append(node)
                if node is Enemy or node is NpcActor: (node as Node2D).hide()
            lamps.sort_custom(func(a: Lamp,b: Lamp) -> bool: return a.position.x < b.position.x)
            var rows := []
            var kinds := {}
            for index in lamps.size():
                var lamp := lamps[index]
                assert(lamp.fixture_id != &"" and lamp.is_supported())
                assert(lamp._body.z_index == WorldLayers.PROPS)
                kinds[lamp.fixture_id] = true
                rows.append({"id":String(lamp.fixture_id),"position":[lamp.position.x,lamp.position.y],"mount":String(lamp.mount()),
                    "supported":lamp.is_supported(),"floor_y":lamp.support_floor_y if is_finite(lamp.support_floor_y) else null,
                    "ceiling_y":lamp.ceiling_y if is_finite(lamp.ceiling_y) else null,"dead":lamp.dead})
                if entry == 0:
                    var camera := get_viewport().get_camera_2d() as LevelCamera
                    camera.set_physics_process(false)
                    camera.offset = Vector2.ZERO
                    camera.global_position = lamp.global_position + Vector2(0,50)
                    camera.reset_smoothing()
                    camera.force_update_scroll()
                    level._lighting._target = camera
                    await _settle(8)
                    var file := _out.path_join(id+"-"+str(index)+".png")
                    assert(Capture.image(get_viewport()).save_png(file) == OK)
            assert(lamps.size() < 2 or kinds.size() >= 2)
            if entry == 0: first = rows
            else: assert(first == rows,"fixture choice and support must survive reentry")
            records.append({"level":id,"entry":entry,"lamps":rows,"kinds":kinds.size()})
            level.queue_free()
            await _settle(8)
    var writer := FileAccess.open(_out.path_join("audit.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify({"quality":_quality,"records":records},"\\t"))
    writer.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit()
''', encoding='utf8', newline='\n')
for name, kind in [('gallery','Node2D'),('tour','Node')]:
    (private/(name+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg36-native/'+name+'.gd" id="1"]\n[node name="Probe" type="'+kind+'"]\nscript = ExtResource("1")\n')
paths = [p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'],cwd=primary).decode().split('\0') if p and (primary/p).is_file()]
assert all((root/p).read_bytes().replace(b'\r\n',b'\n') == (primary/p).read_bytes().replace(b'\r\n',b'\n') for p in paths)
def snapshot(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
runs = []
cases = [('gallery-'+q,'gallery',q,0) for q in ['low','medium','high']] + [('gallery-write-failure','gallery','high',1),('gallery-unlit-write-failure','gallery','high',1)] + [('tour-'+q,'tour',q,0) for q in ['low','high']]
for name, scene, quality, expected in cases:
    folder = out/name
    folder.mkdir()
    if name == 'gallery-write-failure': (folder/'lamps-lit.png').mkdir()
    if name == 'gallery-unlit-write-failure': (folder/'lamps-unlit.png').mkdir()
    env = os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']: env[key] = str(folder/'private-profile'/key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','2560x1440' if scene=='gallery' else '1280x720','res://work/bg36-native/'+scene+'.tscn','--','--out='+str(folder),'--quality='+quality]
    if scene == 'tour': command += ['--level=ch1_street','--prop=unused']
    with (folder/'raw.log').open('wb') as log: run = subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw = (folder/'raw.log').read_bytes()
    row = {'name':name,'command':command,'exit':run.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'images':len([p for p in folder.glob('*.png') if p.is_file()])}
    runs.append(row)
    (out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert row['exit'] == expected and row['script_errors'] == 0 and row['source_held'],row
    if scene == 'gallery':
        records = [json.loads(line.split(b'BG36_GALLERY ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG36_GALLERY ')]
        assert len(records)==2 and all(r['hdr'] and r['environments']==1 and len(r['lamps'])==23 for r in records)
        assert row['images']==(2 if expected==0 else 1)
        (folder/'observations.json').write_text(json.dumps(records,indent=2)+'\n')
    else:
        audit=json.loads((folder/'audit.json').read_text())
        assert len(audit['records'])==16 and row['images']==sum(len(r['lamps']) for r in audit['records'] if r['entry']==0)
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'all_passed':True,'runs':len(runs),'source_held':before==snapshot(),'images':sum(r['images'] for r in runs)},indent=2)+'\n')
