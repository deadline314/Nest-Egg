extends "res://tools/scene_motion_probe.gd"
func _run() -> void:
    var white_block := "--white-block-control" in OS.get_cmdline_user_args()
    add_child(LightKit.create_environment())
    Settings.set_light_quality(QUALITY[_quality])
    Lamp.flicker_hold = 1.0
    DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
    Engine.max_fps = 0
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var results := []
    for id: String in ["ch1_street","ch1_warehouse","ch1_vault"]:
        _level_id = id
        var level := await _open_level()
        var lamps: Array[Lamp] = []
        for node: Node in level.find_children("*","Node2D",true,false):
            if node is Lamp:
                lamps.append(node)
                if white_block:
                    node._body.hide()
                    var card := Node2D.new()
                    LightKit.mark_emissive(card)
                    card.draw.connect(func() -> void:
                        card.draw_rect(Rect2(-6,-2,12,3),Palette.TERRAIN_TOP)
                        card.draw_rect(Rect2(-4,1,8,2),Color(node.color.darkened(0.7),0.5) if node.dead else LightKit.glow(node.color,2.5)))
                    node.add_child(card)
            if node is Enemy or node is NpcActor:
                node.hide()
                node.process_mode = Node.PROCESS_MODE_DISABLED
                for child: Node in node.find_children("*","",true,false): child.process_mode = Node.PROCESS_MODE_DISABLED
        lamps.sort_custom(func(a: Lamp,b: Lamp) -> bool: return a.position.x < b.position.x)
        var camera := get_viewport().get_camera_2d() as LevelCamera
        camera.set_physics_process(false)
        camera.offset = Vector2.ZERO
        camera.global_position = lamps[0].global_position + Vector2(0,50)
        camera.reset_smoothing()
        camera.force_update_scroll()
        level._lighting._target = camera
        await _settle(120)
        var contract := []
        var active_actors := 0
        for node: Node in level.find_children("*","",true,false):
            if (node is Enemy or node is NpcActor or node is CutsceneActor) and node.can_process(): active_actors += 1
        assert(active_actors == 0 and not level.player.can_process())
        for lamp in lamps:
            assert(lamp._body.visible != white_block)
            contract.append({"id":String(lamp.fixture_id),"position":[lamp.position.x,lamp.position.y],"radius":lamp.light_radius,
                "energy":lamp.light_energy,"dead":lamp.dead,"supported":lamp.is_supported(),"body_visible":lamp._body.visible})
        var samples: Array[float] = []
        var last := Time.get_ticks_usec()
        for frame in 180:
            await get_tree().process_frame
            var now := Time.get_ticks_usec()
            samples.append((now-last)/1000.0)
            last = now
        await RenderingServer.frame_post_draw
        var image := Capture.image(get_viewport())
        assert(image.save_png(_out.path_join(id+".png")) == OK)
        results.append({"level":id,"quality":_quality,"white_block_control":white_block,"samples_ms":samples,
            "active_actors":active_actors,"lamps":contract,"vsync":DisplayServer.window_get_vsync_mode(),
            "texture_reported_size":[get_viewport().get_texture().get_width(),get_viewport().get_texture().get_height()],
            "viewport":[image.get_width(),image.get_height()]})
        level.queue_free()
        await _settle(8)
    var writer := FileAccess.open(_out.path_join("samples.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify(results,"\t"))
    writer.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit()
