extends "res://tools/lamp_gallery.gd"
func _ready() -> void:
    for arg: String in OS.get_cmdline_user_args():
        if arg.begins_with("--quality="):
            Settings.set_light_quality({"low":0,"medium":1,"high":2}[arg.trim_prefix("--quality=")])
    super._ready()
func _settle(frames: int) -> void:
    await super._settle(frames)
    var rows := []
    for lamp in _lamps:
        var lit := LightKit.lamp_power > 0.0
        assert(lamp.is_supported() and lamp._art != null and lamp._glow != null)
        assert(lamp._body.z_index == WorldLayers.PROPS)
        assert(lamp._light.enabled == lit and lamp._glow.visible == lit)
        rows.append({"id":String(lamp.fixture_id),"mount":String(lamp.mount()),"supported":lamp.is_supported(),
            "light_enabled":lamp._light.enabled,"glow_visible":lamp._glow.visible,"art_tint":lamp._art.self_modulate.r,
            "light_radius":lamp.light_radius,"light_energy":lamp.light_energy,"light_color":str(lamp.light_color)})
    print("BG36_GALLERY ",JSON.stringify({"power":LightKit.lamp_power,"quality":Settings.get_light_quality(),
        "hdr":get_viewport().use_hdr_2d,"environments":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),"lamps":rows}))
