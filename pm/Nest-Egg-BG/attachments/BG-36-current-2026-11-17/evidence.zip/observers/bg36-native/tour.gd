extends "res://tools/scene_motion_probe.gd"
func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(QUALITY[_quality])
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var records := []
    for id: String in ["ch1_street","ch1_warehouse","ch1_vault","ch1_rooftop","ch1_booth_alley","ch1_stall","ch1_pawnshop","ch1_lounge"]:
        var first := []
        for entry in 2:
            _level_id = id
            var level := await _open_level()
            var lamps: Array[Lamp] = []
            for node: Node in level.find_children("*","Node2D",true,false):
                if node is Lamp: lamps.append(node)
                if node is Enemy or node is NpcActor: (node as Node2D).hide()
            lamps.sort_custom(func(a: Lamp,b: Lamp) -> bool: return a.position.x < b.position.x)
            var rows := []
            var kinds := {}
            for index in lamps.size():
                var lamp := lamps[index]
                assert(lamp.fixture_id != &"" and lamp.is_supported())
                assert(lamp._body.z_index == WorldLayers.PROPS)
                kinds[lamp.fixture_id] = true
                rows.append({"id":String(lamp.fixture_id),"position":[lamp.position.x,lamp.position.y],"mount":String(lamp.mount()),
                    "supported":lamp.is_supported(),"floor_y":lamp.support_floor_y if is_finite(lamp.support_floor_y) else null,
                    "ceiling_y":lamp.ceiling_y if is_finite(lamp.ceiling_y) else null,"dead":lamp.dead})
                if entry == 0:
                    var camera := get_viewport().get_camera_2d() as LevelCamera
                    camera.set_physics_process(false)
                    camera.offset = Vector2.ZERO
                    camera.global_position = lamp.global_position + Vector2(0,50)
                    camera.reset_smoothing()
                    camera.force_update_scroll()
                    level._lighting._target = camera
                    await _settle(8)
                    var file := _out.path_join(id+"-"+str(index)+".png")
                    assert(Capture.image(get_viewport()).save_png(file) == OK)
            assert(lamps.size() < 2 or kinds.size() >= 2)
            if entry == 0: first = rows
            else: assert(first == rows,"fixture choice and support must survive reentry")
            records.append({"level":id,"entry":entry,"lamps":rows,"kinds":kinds.size()})
            level.queue_free()
            await _settle(8)
    var writer := FileAccess.open(_out.path_join("audit.json"),FileAccess.WRITE)
    assert(writer != null)
    writer.store_string(JSON.stringify({"quality":_quality,"records":records},"\t"))
    writer.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit()
