from pathlib import Path
import hashlib
import json
import os
import subprocess
from PIL import Image

root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg28-aspect-final')
out.mkdir(parents=True,exist_ok=False)
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','project.godot'],cwd=root).decode('utf8').split('\0') if p and (root/p).is_file()]
def snapshot(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
reference=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg20-final-tour/high/ch1_rooftop/high-index.json').read_text())
runs=[]
for tag,size in [('ultrawide','1680x720'),('four-three','1024x768'),('sixteen-nine','1280x720')]:
    folder=out/tag;folder.mkdir()
    env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']: env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution',size,'res://tools/scene_tour.tscn','--','--out='+str(folder),'--level=ch1_rooftop','--tag='+tag,'--quality=high','--no-enemies']
    with (folder/'raw.log').open('wb') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes()
    index=json.loads((folder/'ch1_rooftop'/(tag+'-index.json')).read_text())
    world_equal=len(index['shots'])==len(reference['shots']) and all((a['column'],a['row'])==(b['column'],b['row']) and all(abs(x-y)<.001 for x,y in zip(a['world'],b['world'])) for a,b in zip(index['shots'],reference['shots']))
    dimensions=[]
    for path in sorted((folder/'ch1_rooftop').glob('*.png')):
        with Image.open(path) as image: dimensions.append(list(image.size))
    unexpected=[line.decode('utf8',errors='replace') for line in raw.splitlines() if line.startswith(b'ERROR:') and b'resources still in use at exit' not in line]
    window=list(map(int,size.split('x')))
    expected=[min(window[0],window[1]*16//9),min(window[1],window[0]*9//16)]
    assert index['window_size']==window and index['capture_size']==expected
    record={'window_size':window,'capture_size':expected,'tag':tag,'command':command,'exit':result.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'unexpected_errors':unexpected,'same_world_grid_as_1280x720':world_equal,'images':len(dimensions),'dimensions':dimensions,'source_held':before==snapshot(),'scope':'Complete static rooftop grid under actual window aspect ratios, camera-only geometry review; no actor-readability, gameplay or performance claim.'}
    runs.append(record)
    (out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    print(tag,result.returncode,len(dimensions),world_equal,flush=True)
    assert result.returncode==record['script_errors']==0 and not unexpected and world_equal and len(dimensions)==24 and all(d==expected for d in dimensions) and record['source_held']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'source-held.json').write_text(json.dumps({'source_held':before==snapshot(),'count':len(paths)},indent=2)+'\n')
