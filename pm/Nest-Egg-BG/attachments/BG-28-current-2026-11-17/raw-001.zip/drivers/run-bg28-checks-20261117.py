from pathlib import Path
import hashlib
import json
import os
import subprocess

out=Path('D:/NestEggVerification/evidence-20261117/bg28-checks')
out.mkdir(exist_ok=False)
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot']).decode('utf8').split('\0') if p and Path(p).is_file()]
def snapshot():return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
before=snapshot()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy()
env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='1',PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
records=[]
for name,script in [('affected','tools/run_tests_changed.sh 8949fac01ec6fb1afbc27ea982363985569c5bd3'),('scene-sanity','tools/run_tests_parallel.sh --only=SceneSanitySuite')]:
    folder=out/name;folder.mkdir()
    env['LOG_DIR']=str(folder/'shards')
    command=['C:/Program Files/Git/bin/bash.exe','-c','python3() { python "$@"; }; export -f python3; '+script]
    with (folder/'raw.log').open('wb') as log:result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
    record={'name':name,'command':command,'exit':result.returncode,'source_held':before==snapshot()}
    records.append(record)
    (out/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    assert result.returncode==0 and record['source_held']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
