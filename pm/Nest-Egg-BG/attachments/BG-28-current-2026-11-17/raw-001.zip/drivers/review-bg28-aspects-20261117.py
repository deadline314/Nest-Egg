from pathlib import Path
import hashlib
import json
from PIL import Image,ImageDraw

base=Path('D:/NestEggVerification/evidence-20261117/bg28-aspect-final')
out=base/'review';out.mkdir(exist_ok=False)
review=[]
for tag in ['ultrawide','four-three','sixteen-nine']:
    folder=base/tag/'ch1_rooftop'
    index=json.loads((folder/(tag+'-index.json')).read_text())
    assert len(index['shots'])==24
    sheet=Image.new('RGB',(1792,1656),'#222222');draw=ImageDraw.Draw(sheet)
    for n,shot in enumerate(index['shots']):
        path=folder/shot['file']
        with Image.open(path) as image:
            assert list(image.size)==index['capture_size']
            thumb=image.convert('RGB').resize((448,252),Image.Resampling.LANCZOS)
        x,y=shot['column']*448,shot['row']*276
        sheet.paste(thumb,(x,y+24))
        draw.text((x+4,y+5),'%s c%d r%d'%(tag,shot['column'],shot['row']),fill='white')
        review.append({'file':path.relative_to(base).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'world':shot['world'],'overview_cell':[x,y+24,448,252],'scope':'Downscaled overview; critical floor/gap frames separately inspected at native size.'})
    sheet.save(out/(tag+'.png'))
(out/'inputs.json').write_text(json.dumps(review,indent=2)+'\n')
print('BG28 full-grid overviews',len(review))
