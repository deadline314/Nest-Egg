from pathlib import Path
import hashlib,json,os,subprocess

root=Path('D:/NestEggVerification/bg17-full-resolution-8949')
out=Path('D:/NestEggVerification/evidence-20261117/bg17/legacy-pair-framing');out.mkdir(exist_ok=False)
private=root/'work/bg17-legacy-pair-framing';private.mkdir(exist_ok=False)
base=(root/'tools/readability_check.gd').read_text(encoding='utf8')
needle='\t\t\t_record_probe_sample(probe, level, spot, sample, foe, [player_contrast, edge_contrast, enemy_contrast])'
assert base.count(needle)==1
(private/'base.gd').write_text(base.replace(needle,needle.replace('_record_probe_sample','await _record_probe_sample')),encoding='utf8',newline='\n')
(private/'probe.gd').write_text('''extends "res://work/bg17-legacy-pair-framing/base.gd"
func _record_probe_sample(_probe: ContrastProbe, level: Level, spot: Array, sample: int, foe: Enemy, _sums: Array[float]) -> void:
    if sample != 15: return
    assert(spot[1] == 492 and is_instance_valid(foe))
    var feet := [level.player.global_position, foe.global_position]
    var mode := level.process_mode
    var camera := get_viewport().get_camera_2d() as LevelCamera
    var running := camera.is_physics_processing()
    var old_position := camera.global_position
    camera.set_physics_process(false)
    level.process_mode = Node.PROCESS_MODE_DISABLED
    var body := Rect2(feet[0] + Vector2(-20, -70), Vector2(40, 70)).merge(Rect2(feet[1] + Vector2(-20, -70), Vector2(40, 70)))
    camera.global_position.y = body.get_center().y
    camera.reset_smoothing()
    camera.force_update_scroll()
    await get_tree().process_frame
    await RenderingServer.frame_post_draw
    var image := get_viewport().get_texture().get_image()
    var transform := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
    var fully_visible := true
    for point in [body.position, Vector2(body.end.x, body.position.y), body.end, Vector2(body.position.x, body.end.y)]:
        fully_visible = fully_visible and Rect2(Vector2.ZERO, image.get_size()).has_point(transform * point)
    var result: Dictionary = await preload("res://tools/weapon_head_probe.gd").capture(self, level, _out_dir, "legacy-492-full-pair")
    var actors_held := level.player.global_position == feet[0] and foe.global_position == feet[1]
    print("LEGACY_PAIR ", JSON.stringify({"both_conservative_body_rects_fully_visible": fully_visible, "actors_held": actors_held, "feet": [[feet[0].x, feet[0].y], [feet[1].x, feet[1].y]], "old_camera": [old_position.x, old_position.y], "paired_camera": [camera.global_position.x, camera.global_position.y], "head": result, "scope": "Supplemental camera-only full-body framing after all16 original contrast samples, actors unchanged. Original contrast report retains its original partially clipped framing; this image is not substituted into the original metric."}))
    assert(fully_visible and actors_held and result.get("bound_valid", false))
    camera.global_position = old_position
    camera.reset_smoothing()
    camera.force_update_scroll()
    camera.set_physics_process(running)
    level.process_mode = mode
''',encoding='utf8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg17-legacy-pair-framing/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n',encoding='utf8')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','project.godot'],cwd=root).decode().split('\0') if p and (root/p).is_file()]+['data/lighting/legacy_reclaimer.tres']
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
runs=[]
for quality in ['low','high']:
    folder=out/quality;folder.mkdir()
    env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--quit-after','5000','res://work/bg17-legacy-pair-framing/probe.tscn','--','--level=level_02','--spots=回收員場地','--quality='+quality,'--out='+str(folder)]
    with (folder/'raw.log').open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();rows=[json.loads(line.split(b' ',1)[1]) for line in raw.splitlines() if line.startswith(b'LEGACY_PAIR ')]
    row={'quality':quality,'command':command,'exit':result.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'pair_checks':rows}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(row,flush=True)
    assert row['exit']==row['script_errors']==0 and row['source_held'] and len(rows)==1
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
