from pathlib import Path
import hashlib,json,os,subprocess
out=Path('D:/NestEggVerification/evidence-20261117/bg17/ambience-mapping/checks');out.mkdir(exist_ok=False)
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot']).decode().split('\0') if p and Path(p).is_file()]+['data/lighting/legacy_reclaimer.tres']
def snapshot():return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy();env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='1',LOG_DIR=str(out/'shards'),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
command=['C:/Program Files/Git/bin/bash.exe','-c','python3() { python "$@"; }; export -f python3; tools/run_tests_parallel.sh --only=AudioSuite,MusicSuite']
with (out/'raw.log').open('wb') as log:result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
after=snapshot();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
row={'command':command,'exit':result.returncode,'source_held':before==after,'source_count':len(paths)}
(out/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True)
assert result.returncode==0 and row['source_held']
