from pathlib import Path
import hashlib
import json
import os
import subprocess

roots = {'legacy': Path('D:/NestEggVerification/bg17-legacy-20261117'), 'current': Path('D:/NestEggVerification/bg17-current-20261117')}
out = Path('D:/NestEggVerification/evidence-20261117/bg17/active-nodes')
out.mkdir(exist_ok=False)
source = (roots['current'] / 'tools/environment_probe.gd').read_text()
anchor = '\t\tvar times: Array[float] = []'
assert source.count(anchor) == 1
diagnostic = '''		var active_nodes: Array[Dictionary] = []
		for node: Node in level.find_children("*", "", true, false):
			if node.can_process() and (node.is_processing() or node.is_physics_processing()):
				var script := node.get_script() as Script
				active_nodes.append({"path": str(level.get_path_to(node)), "script": script.resource_path if script != null else "", "class": String(script.get_global_name()) if script != null else node.get_class(), "process": node.is_processing(), "physics": node.is_physics_processing(), "mode": node.process_mode})
		var point := PhysicsPointQueryParameters2D.new()
		point.position = level.player.global_position + Vector2(0, -22)
		point.collide_with_areas = true
		var excluded_hits: Array[String] = []
		for hit in level.get_world_2d().direct_space_state.intersect_point(point, 128):
			var collider := hit.get("collider") as Node
			if collider != null and (collider == level.player or level.player.is_ancestor_of(collider)): excluded_hits.append(str(level.player.get_path_to(collider)))
		print("ACTIVE_NODES ", JSON.stringify({"nodes": active_nodes, "player_can_process": level.player.can_process(), "player_physics": level.player.is_physics_processing(), "player_mode": level.player.process_mode, "player_disable_mode": level.player.disable_mode, "excluded_player_hits": excluded_hits}))
'''
source = source.replace(anchor, diagnostic + anchor)
runs = []
for name, root in roots.items():
    private = root / 'work/bg17-active-nodes'
    private.mkdir(parents=True, exist_ok=False)
    (private / '.gdignore').write_bytes(b'')
    (private / 'probe.gd').write_text(source, encoding='utf8', newline='\n')
    (private / 'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg17-active-nodes/probe.gd" id="1"]\n[node name="ActiveNodesProbe" type="Node"]\nscript = ExtResource("1")\n')
    folder = out / name
    folder.mkdir()
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']: env[key] = str(folder / 'private-profile' / key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '320x180', '--quit-after', '10000', 'res://work/bg17-active-nodes/probe.tscn', '--', '--level=level_01', '--spots=30', '--quality=low', '--frames=180', '--no-characters']
    before = hashlib.sha256((private / 'probe.gd').read_bytes()).hexdigest()
    with (folder / 'raw.log').open('wb') as log: result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (folder / 'raw.log').read_bytes()
    rows = [json.loads(line.removeprefix(b'ACTIVE_NODES ')) for line in raw.splitlines() if line.startswith(b'ACTIVE_NODES ')]
    receipt = {'name': name, 'command': command, 'exit': result.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'source_held': hashlib.sha256((private / 'probe.gd').read_bytes()).hexdigest() == before, 'diagnostic': rows}
    runs.append(receipt)
    (out / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
    assert result.returncode == receipt['script_errors'] == 0 and receipt['source_held'] and len(rows) == 1
    print(name, len(rows[0]['nodes']), rows[0]['player_can_process'], rows[0]['excluded_player_hits'], flush=True)
