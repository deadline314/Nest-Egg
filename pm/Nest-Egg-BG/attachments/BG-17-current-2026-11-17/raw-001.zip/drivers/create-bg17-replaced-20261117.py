from pathlib import Path
import json
import shutil
import subprocess

workspace = Path('C:/Users/stanl/Github/Nest-Egg')
target = Path('D:/NestEggVerification/bg17-replaced-20261117')
assert target.resolve().parent == Path('D:/NestEggVerification').resolve() and not target.exists()
out = Path('D:/NestEggVerification/evidence-20261117/bg17/replaced-setup-v1')
out.mkdir(exist_ok=False)
git = ['git', '-c', 'core.packedGitLimit=128m', '-c', 'core.packedGitWindowSize=32m', '-c', 'core.deltaBaseCacheLimit=64m']
records = []
for name, command, cwd, data in [
    ('create', git + ['worktree', 'add', '--detach', '--no-checkout', str(target), '6f4805be6d0dfee76ace0baa644bf55b0b4aea44'], workspace, None),
    ('sparse', git + ['sparse-checkout', 'set', '--no-cone', '--stdin'], target, b'/*\n!/pm/\n!/design/\n!/art_src/\n'),
    ('populate', git + ['read-tree', '-mu', 'HEAD'], target, None),
]:
    process = subprocess.run(command, cwd=cwd, input=data, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out / (name + '.log')).write_bytes(process.stdout)
    records.append({'name': name, 'command': command, 'exit': process.returncode})
    print(name, process.returncode, flush=True)
    assert process.returncode == 0
assert (target / 'project.godot').is_file() and (target / 'game/rig/character_rig.gd').is_file()
shutil.copytree(workspace / '.godot/imported', target / '.godot/imported')
records.append({'name': 'import-cache-copy', 'scope': 'Ordinary file copies from unchanged main checkout, not symlinks or import acceptance. Engine import follows before measuring.'})
(out / 'runs.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf8')
print('Own sparse baseline checkout and import cache ready', flush=True)
