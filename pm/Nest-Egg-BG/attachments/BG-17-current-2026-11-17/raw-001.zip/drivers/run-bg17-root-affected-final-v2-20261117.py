from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

dependency=Path('D:/NestEggVerification/evidence-20261117/bg17/root-import-final/source-restored.json')
while not dependency.exists(): time.sleep(2)
ready=json.loads(dependency.read_text())
assert ready['import_exit']==0 and ready['source_restored'] and ready['script_errors']==0,ready
out = Path('D:/NestEggVerification/evidence-20261117/bg17/root-affected-final')
out.mkdir(parents=True,exist_ok=False)
source = Path('tools/environment_probe.gd')
paths = [p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot']).decode('utf8').split('\0') if p and Path(p).is_file()]
paths.append('data/lighting/legacy_reclaimer.tres')

def snapshot(): return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
all_before = snapshot()
(out/'source-before.json').write_text(json.dumps(all_before,indent=2)+'\n')
before = source.read_bytes()
env = os.environ.copy()
env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', SHARDS='2', LOG_DIR=str(out / 'shards'), PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']: env[key] = str(out / 'private-profile' / key)
command = ['C:/Program Files/Git/bin/bash.exe', '-c', 'python3() { python "$@"; }; export -f python3; tools/run_tests_changed.sh 011cfed6d81b74acc9c101d3d7a2e839c5373bd3']
with (out / 'raw.log').open('wb') as log: process = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
record = {'exit': process.returncode, 'command': command, 'source_held': all_before == snapshot(), 'source_sha256': hashlib.sha256(before).hexdigest()}
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
print(record, flush=True)
assert process.returncode == 0 and record['source_held']
