from pathlib import Path
import hashlib
import json
import os
import subprocess

root=Path('D:/NestEggVerification/bg17-current-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg17/readability-guarded-final')
out.mkdir(exist_ok=False)
assert json.loads(Path('D:/NestEggVerification/evidence-20261117/bg17/advance-8949/import/run.json').read_text())['source_held']
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','project.godot'],cwd=root).decode('utf8').split('\0') if p and (root/p).is_file()]
paths.append('data/lighting/legacy_reclaimer.tres')

def snapshot(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
records=[]
for scene,expected in [('readability_check',16),('ch1_readability_check',18),('ch2_readability_check',22),('ch3_readability_check',20)]:
    for quality in ['low','high']:
        folder=out/(scene+'-'+quality);folder.mkdir()
        env=os.environ.copy()
        for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']: env[key]=str(folder/'private-profile'/key)
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','res://tools/'+scene+'.tscn','--','--quality='+quality,'--detail','--out='+str(folder)]
        with (folder/'raw.log').open('wb') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        raw=(folder/'raw.log').read_bytes()
        report=folder/'readability-report.json'
        data=json.loads(report.read_text()) if report.is_file() else None
        record={'scene':scene,'quality':quality,'command':command,'exit':result.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'spots':len(data['results']) if data else 0,'expected_spots':expected,'source_held':before==snapshot(),'scope':'Original sampler formula/points/thresholds; corrected persistent prompt suppression and onlyPERSON NPC exclusion, latest011 runtime plus24-path BG17 candidate. Actual rendered actor sampling, software aim arrangement; .65 material edge alpha and legacy-only character_floor .7; no human gameplay or physical-controller claim.'}
        records.append(record)
        (out/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
        print(scene,quality,result.returncode,record['spots'],flush=True)
        assert record['script_errors']==0 and record['source_held'] and record['spots']==expected
after=snapshot()
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'source_held':before==after,'source_count':len(paths),'all_original_thresholds_passed':all(r['exit']==0 for r in records),'runs':records},indent=2)+'\n')
