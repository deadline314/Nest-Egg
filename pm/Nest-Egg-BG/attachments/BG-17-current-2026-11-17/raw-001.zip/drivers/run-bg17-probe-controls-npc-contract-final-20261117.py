from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('D:/NestEggVerification/bg17-current-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg17/probe-controls-npc-contract-final')
out.mkdir(exist_ok=False)
fixture = root / 'work/bg17-probe-controls'
assert fixture.is_dir() and (fixture / 'bad_map.tres').is_file() and (fixture / 'bad_level.tres').is_file()
assert hashlib.sha256((root / 'tools/environment_probe.gd').read_bytes()).hexdigest() == 'a3d7916a69bf1c488c62ea77a5859eadd6ce40396c4b3b5b577eb7eae564efd3'
paths = ['tools/environment_probe.gd', 'tools/environment_probe.tscn', 'work/bg17-probe-controls/bad_map.tres', 'work/bg17-probe-controls/bad_level.tres']
def snapshot():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
records = []
for name, level, spots, expected, marker in [('invalid-position', 'level_01', '-3', 2, b'invalid sample position'), ('save-failure', 'level_01', '30', 1, b'level_01_30_low.png'), ('invalid-migration', '../../work/bg17-probe-controls/bad_level', '30', 2, b'layout_revision')]:
    folder = out / name
    folder.mkdir()
    if name == 'save-failure':
        (folder / 'level_01_30_low.png').mkdir()
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
        env[key] = str(folder / 'private-profile' / key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '320x180', 'res://tools/environment_probe.tscn', '--', '--level=' + level, '--spots=' + spots, '--frames=30', '--no-characters', '--quality=low', '--out=' + str(folder)]
    with (folder / 'raw.log').open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (folder / 'raw.log').read_bytes()
    record = {'name': name, 'command': command, 'exit': process.returncode, 'expected_exit': expected, 'specific_error_present': marker in raw and b'[EnvironmentProbe]' in raw, 'script_errors': raw.count(b'SCRIPT ERROR:')}
    records.append(record)
    (out / 'results.json').write_text(json.dumps({'before': before, 'after': snapshot(), 'cases': records}, indent=2) + '\n', encoding='utf8')
    print(record['name'], record['exit'], record['specific_error_present'], flush=True)
    assert process.returncode == expected and record['specific_error_present'] and record['script_errors'] == 0 and snapshot() == before
