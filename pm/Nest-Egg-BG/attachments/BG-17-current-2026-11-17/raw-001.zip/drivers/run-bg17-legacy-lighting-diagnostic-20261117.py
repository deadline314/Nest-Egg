from pathlib import Path
import hashlib
import json
import os
import subprocess

root=Path('D:/NestEggVerification/bg17-full-resolution-8949')
out=Path('D:/NestEggVerification/evidence-20261117/bg17/legacy-lighting-diagnostic')
out.mkdir(exist_ok=False)
private=root/'work/bg17-legacy-lighting-diagnostic';private.mkdir(parents=True,exist_ok=False)
(private/'probe.gd').write_text('''extends "res://tools/readability_check.gd"
var _variant := "edge-only"
func _ready() -> void:
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--variant="): _variant = arg.trim_prefix("--variant=")
    super._ready()
func _prepare_probe_level(data: LevelData) -> void:
    var original_theme := data.environment
    var theme := original_theme.duplicate() as EnvironmentTheme
    theme.zones = []
    for original: EnvZone in original_theme.zones:
        var zone := original.duplicate() as EnvZone
        if original.material.id == &"hangar":
            zone.material = original.material.duplicate() as TerrainMaterialData
            zone.material.edge_color.a = 0.55
            assert(original.material.edge_color.a == 0.4)
        theme.zones.append(zone)
    data.environment = theme
    if _variant == "edge-and-fill" and data.id == &"level_02":
        var zones: Array[LightingZone] = []
        for original: LightingZone in data.lighting_zones:
            var zone := original.duplicate() as LightingZone
            if original.start_tile == 470:
                zone.profile = original.profile.duplicate() as LightingProfile
                zone.profile.character_floor = 0.8
                assert(original.profile.character_floor == 0.0)
            zones.append(zone)
        data.lighting_zones = zones
func _record_probe_sample(probe: ContrastProbe, level: Level, spot: Array, sample: int, _foe: Enemy, _sums: Array[float]) -> void:
    var box := Rect2(level.player.global_position + Vector2(-20, -90), Vector2(40, 90))
    var rect := probe._screen_rect(box)
    assert(rect.has_area() and probe._image.get_format() == Image.FORMAT_RGBH)
    var image := probe._image.get_region(rect)
    var white := 0
    for y in image.get_height():
        for x in image.get_width():
            var pixel := image.get_pixel(x, y)
            if pixel.r > 0.92 and pixel.g > 0.92 and pixel.b > 0.92: white += 1
    var name := "%s-%d-%02d.rgbh" % [level.data.id, spot[1], sample]
    var file := FileAccess.open(_out_dir.path_join(name), FileAccess.WRITE)
    assert(file != null)
    file.store_buffer(image.get_data())
    file.close()
    print("LEGACY_LIGHT_SAMPLE ", JSON.stringify({"level": str(level.data.id), "tile": spot[1], "sample": sample, "variant": _variant, "profile": str(level._lighting.current.id), "ambient": [level._lighting.current.ambient_color.r, level._lighting.current.ambient_color.g, level._lighting.current.ambient_color.b], "character_floor": level._lighting.current.character_floor, "character_fill": LightKit.character_fill, "enemy_fill": LightKit.enemy_fill, "player_light": LightKit.player_light_energy, "rect": [rect.position.x, rect.position.y, rect.size.x, rect.size.y], "raw": name, "raw_sha256": FileAccess.get_sha256(_out_dir.path_join(name)), "format": "RGBH", "white": white, "total": rect.get_area(), "scope": "Conservative body-and-background rectangle; zero bounds head white pixels, nonzero is not an exact head ratio."}))
''',encoding='utf8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg17-legacy-lighting-diagnostic/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n',encoding='utf8')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','project.godot'],cwd=root).decode('utf8').split('\0') if p and (root/p).is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
records=[]
for variant in ['edge-only','edge-and-fill']:
    for quality in ['low','high']:
        folder=out/(variant+'-'+quality);folder.mkdir()
        env=os.environ.copy()
        for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','res://work/bg17-legacy-lighting-diagnostic/probe.tscn','--','--quality='+quality,'--detail','--spots=頭目機庫,看守長場地,回收員場地','--variant='+variant,'--out='+str(folder)]
        with (folder/'raw.log').open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        raw=(folder/'raw.log').read_bytes()
        rows=[json.loads(line.removeprefix(b'LEGACY_LIGHT_SAMPLE ')) for line in raw.splitlines() if line.startswith(b'LEGACY_LIGHT_SAMPLE ')]
        record={'variant':variant,'quality':quality,'command':command,'exit':result.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'samples':rows,'source_held':before==snapshot(),'scope':'In-memory data-only diagnostic in full-resolution control checkout, original sampler/formulas/points/thresholds unchanged. Shared resources explicitly duplicated; no production change.'}
        records.append(record);(out/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
        print(variant,quality,result.returncode,len(rows),flush=True)
        assert record['script_errors']==0 and record['source_held'] and len(rows)==48
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
