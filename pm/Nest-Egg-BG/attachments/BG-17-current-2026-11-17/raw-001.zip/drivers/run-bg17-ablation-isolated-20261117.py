from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import psutil
import shutil

out = Path('D:/NestEggVerification/evidence-20261117/bg17/ablation-v2')
out.mkdir(exist_ok=False)
user_data = Path(os.environ['APPDATA']) / 'Godot/app_userdata/Nest Egg'
def user_snapshot():
    return {p.relative_to(user_data).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in user_data.rglob('*') if p.is_file()}
user_before = user_snapshot()
(out / 'user-before.json').write_text(json.dumps(user_before, indent=2) + '\n', encoding='utf8')
for relative in user_before:
    backup = out / 'user-before-copy' / relative
    backup.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(user_data / relative, backup)
roots = {'legacy': Path('D:/NestEggVerification/bg17-legacy-20261117'), 'current': Path('D:/NestEggVerification/bg17-current-20261117')}
paths = {}
for name, root in roots.items():
    paths[name] = [p for p in subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'core', 'game', 'data', 'ui', 'art', 'tools', 'project.godot'], cwd=root).decode('utf8').split('\0') if p and (root / p).is_file()]
def snapshot(name):
    return {p: hashlib.sha256((roots[name] / p).read_bytes()).hexdigest() for p in paths[name]}
before = {name: snapshot(name) for name in roots}
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
def workload():
    records = []
    for p in psutil.process_iter(['pid', 'name', 'memory_info']):
        try:
            if 'godot' in p.info['name'].lower():
                cpu = p.cpu_times()
                records.append({'pid': p.pid, 'name': p.info['name'], 'cwd': p.cwd(), 'cpu_s': cpu.user + cpu.system, 'rss_bytes': p.info['memory_info'].rss})
        except psutil.Error:
            pass
    return {'available_ram': psutil.virtual_memory().available, 'godot': records}
records = []
for hide in ['', 'Hud', 'RainLayer,FogLayer', 'PropNode', 'LevelBackground']:
    for name, root in roots.items():
        folder = out / (name + '-' + (hide.replace(',', '-') or 'baseline'))
        folder.mkdir()
        frames = 180 if not hide else 60
        command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--resolution', '320x180', 'res://tools/environment_probe.tscn', '--', '--level=level_01', '--quality=low', '--frames=' + str(frames), '--no-characters', '--out=' + str(folder)]
        if hide:
            command.append('--hide=' + hide)
        env = os.environ.copy()
        for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
            env[key] = str(folder / 'private-profile' / key)
        (folder / 'environment.json').write_text(json.dumps({key: env[key] for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']}, indent=2) + '\n', encoding='utf8')
        load_before = workload()
        start = time.monotonic()
        with (folder / 'raw.log').open('wb') as log:
            process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        elapsed = time.monotonic() - start
        raw = (folder / 'raw.log').read_bytes()
        rows = [json.loads(line.removeprefix(b'ENVIRONMENT_SAMPLES ')) for line in raw.splitlines() if line.startswith(b'ENVIRONMENT_SAMPLES ')]
        record = {'epoch': name, 'hide': hide, 'command': command, 'exit': process.returncode, 'elapsed_s': elapsed, 'workload_before': load_before, 'workload_after': workload(), 'script_errors': raw.count(b'SCRIPT ERROR:'), 'rows': rows, 'scope': 'Ablation diagnostic under disclosed background game-suite and other-project load, not quiet ABBA or 105% acceptance. Hidden classes never alter production source. Baseline saves three native PNGs; diagnostic hide intentionally suppresses PNG output.'}
        (folder / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
        records.append(record)
        print(name, hide or 'baseline', process.returncode, [round(sum(r['samples_ms']) / frames, 4) for r in rows], flush=True)
        assert process.returncode == 0 and record['script_errors'] == 0 and len(rows) == 3 and all(len(r['samples_ms']) == frames for r in rows)
after = {name: snapshot(name) for name in roots}
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
(out / 'results.json').write_text(json.dumps({'source_held': before == after, 'cases': records}, indent=2) + '\n', encoding='utf8')
user_after = user_snapshot()
(out / 'user-after.json').write_text(json.dumps(user_after, indent=2) + '\n', encoding='utf8')
assert before == after and user_before == user_after
