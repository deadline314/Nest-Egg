from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

out = Path('D:/NestEggVerification/evidence-20261117/bg17/forced-import-v1')
out.mkdir(exist_ok=False)
records = []
for name in ['legacy', 'replaced', 'current']:
    root = Path('D:/NestEggVerification/bg17-' + name + '-20261117')
    assert root.resolve().parent == Path('D:/NestEggVerification').resolve()
    folder = out / name
    folder.mkdir()
    paths = [p for p in subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode('utf8').split('\0') if p and (root / p).is_file()]
    def snapshot():
        return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}
    before = snapshot()
    (folder / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
    cache = (root / '.godot/imported').resolve()
    moved = []
    for sidecar in (root / 'art/environment').rglob('*.import'):
        for relative in re.findall(r'^path(?:\.[^=]+)?="res://(\.godot/imported/[^"\n]+)"', sidecar.read_text(encoding='utf8'), re.M):
            source = (root / relative).resolve()
            assert source.parent == cache and source.suffix == '.ctex'
            if source.is_file():
                destination = folder / 'previous-derived-cache' / source.name
                destination.parent.mkdir(exist_ok=True)
                assert not destination.exists()
                record = {'path': relative, 'old_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'bytes': source.stat().st_size}
                source.rename(destination)
                moved.append(record)
    assert moved
    (folder / 'moved-cache.json').write_text(json.dumps(moved, indent=2) + '\n', encoding='utf8')
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
        env[key] = str(folder / 'private-profile' / key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--headless', '--editor', '--import']
    with (folder / 'raw.log').open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    after = snapshot()
    (folder / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
    raw = (folder / 'raw.log').read_bytes()
    regenerated = all((root / r['path']).is_file() for r in moved)
    records.append({'epoch': name, 'command': command, 'exit': process.returncode, 'source_held': before == after, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'moved_cache_count': len(moved), 'all_previous_paths_regenerated': regenerated, 'scope': 'Only generated environment CTex files moved to a verified private backup, forcing actual missing-destination import. Original images, sidecars and code held. No shared model/server changes.'})
    (out / 'results.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf8')
    print(name, process.returncode, 'sourceheld', before == after, 'regenerated', regenerated, len(moved), flush=True)
    assert process.returncode == 0 and before == after and regenerated and records[-1]['script_errors'] == 0
