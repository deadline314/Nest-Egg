from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time
import psutil

OUT = Path('D:/NestEggVerification/evidence-20261117/bg17/replaced-comparison-v1')
OUT.mkdir(exist_ok=False)
CURRENT = Path('D:/NestEggVerification/bg17-current-20261117')
LEGACY = Path('D:/NestEggVerification/bg17-replaced-20261117')
shutil.copyfile(CURRENT / 'tools/environment_probe.gd', LEGACY / 'tools/environment_probe.gd')
results = []
for name, root in [('replaced', LEGACY), ('current', CURRENT)]:
    folder = OUT / name
    folder.mkdir()
    paths = [p for p in subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'core', 'game', 'data', 'ui', 'art', 'tools', 'project.godot'], cwd=root).decode('utf8').split('\0') if p and (root / p).is_file()]
    paths = sorted(set(paths + ['tools/environment_probe.gd', 'tools/environment_probe.tscn']))
    def snapshot():
        return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}
    before = snapshot()
    (folder / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
        env[key] = str(folder / 'private-profile' / key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '320x180', 'res://tools/environment_probe.tscn', '--', '--level=level_01', '--quality=low', '--frames=30', '--no-characters', '--out=' + str(folder)]
    request = {'command': command, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(), 'scope': 'Actual historical post-replacement 6f480 versus current loaded payload and native diagnostic only; not quiet ABBA or105% performance acceptance. Engine, GPU, tool, level and flags identical; all epoch sources guarded. Four other project headless Godot processes observed; team not exclusive. Same existing probe plus backwards-compatible optional prefetch lookup and read-only chronological sample log; no new CLI.'}
    (folder / 'request.json').write_text(json.dumps(request, indent=2) + '\n', encoding='utf8')
    start = time.monotonic()
    with (folder / 'raw.log').open('wb') as log:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        try:
            code = process.wait(timeout=600)
            natural = True
        except subprocess.TimeoutExpired:
            for child in reversed(psutil.Process(process.pid).children(recursive=True)):
                try:
                    child.kill()
                except psutil.NoSuchProcess:
                    pass
            process.kill()
            process.wait()
            code = 124
            natural = False
    after = snapshot()
    (folder / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
    raw = (folder / 'raw.log').read_bytes()
    rows = [json.loads(line.removeprefix(b'ENVIRONMENT_SAMPLES ')) for line in raw.splitlines() if line.startswith(b'ENVIRONMENT_SAMPLES ')]
    record = {'name': name, 'exit': code, 'natural': natural, 'elapsed_s': time.monotonic() - start, 'source_unchanged': before == after, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'sample_rows': len(rows), 'thirty_samples_each': len(rows) == 3 and all(len(row['samples_ms']) == 30 for row in rows)}
    (folder / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
    results.append(record)
    print('BG17_COMPAT', json.dumps(record), flush=True)
    if code or not natural or record['script_errors'] or not record['thirty_samples_each'] or not record['source_unchanged']:
        break
(OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf8')
