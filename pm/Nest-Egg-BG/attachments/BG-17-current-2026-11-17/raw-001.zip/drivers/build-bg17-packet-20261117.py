from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile

base=Path('D:/NestEggVerification/evidence-20261117/bg17')
out=base/'delivery-packet';out.mkdir(exist_ok=False)
files={}
def tree(prefix,images=True):
    for parent,dirs,names in os.walk(base/prefix):
        dirs[:]=sorted(d for d in dirs if d.lower() not in ['private-profile','app_userdata','user','user-data','review','editor-normalized'] and not d.startswith('data_'))
        for name in sorted(names):
            p=Path(parent)/name
            if not images and p.suffix.lower() not in ['.json','.log','.gd','.tscn','.patch','.py']:continue
            assert p.stat().st_size<45_000_000,p
            files[p.relative_to(base).as_posix()]=p
for prefix in ['root-affected-guarded-final','readability-guarded-final','readability-guarded-full-final','abba-root-final-v6','replaced-comparison-v2','legacy-lighting-diagnostic-v3','legacy-pair-framing-v2','prompt-npc-controls-v2','probe-controls-npc-contract-final','npc-contract-control/cases','root-python-final','resolution-control-v3']:
    tree(prefix)
for prefix in ['root-import-final','root-promotion-011','full-align-011-final','ambience-mapping','policy-red','policy-final-v3','root-affected-final','abba-final-v2','abba-npc-contract-v3','abba-root-final-v4','abba-root-final-v5','readability-8949','full-resolution-8949/readability','readability-local-data-final','readability-local-data-full-final','prompt-controls','legacy-lighting-diagnostic','legacy-lighting-diagnostic-v2','legacy-pair-framing']:
    tree(prefix,False)
for name in ['ready.json','full-resolution-only-paths.json','full-source-after-import.json','import.log','restricted-derived.json','same-code-restricted-source.json']:
    p=base/'full-resolution-8949'/name
    if p.exists():files[p.relative_to(base).as_posix()]=p
files['review/inputs.json']=base/'review-guarded-final/inputs.json'
paths=json.loads(Path('work/bg17-source-paths-final.json').read_text())+['design/20-campaign-experience/ENVIRONMENT_BENCHMARK.md']
for p in paths:files['source/'+p]=Path(p)
for p in Path('work').glob('*bg17*20261117.py'):files['drivers/'+p.name]=p
for root in ['D:/NestEggVerification/bg17-current-20261117/work','D:/NestEggVerification/bg17-full-resolution-8949/work']:
    for folder in Path(root).glob('bg17*'):
        if folder.is_dir():
            for p in folder.rglob('*'):
                if p.is_file() and p.suffix in ['.gd','.tscn','.tres']:
                    name='producers/'+Path(root).parent.name+'/'+p.relative_to(Path(root)).as_posix();files[name]=p
files=dict(sorted(files.items()));assert len(files)==len({n.casefold() for n in files})
archives=[];archive=None;record=None;total=0
def close():
    if archive:
        archive.close();p=out/record['file'];record.update(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest());archives.append(record)
for name,path in files.items():
    size=path.stat().st_size
    if archive is None or total+size>45_000_000:
        close();filename='raw-%03d.zip'%(len(archives)+1);archive=zipfile.ZipFile(out/filename,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6);record={'file':filename,'members':[]};total=0
    raw=path.read_bytes();archive.writestr(name,raw);record['members'].append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()});total+=size
close();(out/'archives.json').write_text(json.dumps({'archives':archives,'file_count':len(files)},indent=2)+'\n')
generic=Path('pm/Nest-Egg-BG/attachments/BG-20-current-2026-11-17/verify.py').read_text().split("before = data('final/source-before.json')",1)[0]
tail=Path('work/bg17-reader-tail.py').read_text()
(out/'verify.py').write_text(generic+tail,encoding='utf8',newline='\n')
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-X','utf8',str(out/'verify.py'),str(out)]
with (out/'verification.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,(out/'verification.log').read_text()
negative=base/'reader-corrupt';negative.mkdir(exist_ok=False)
first=archives[0]['file'];shutil.copyfile(out/first,negative/first);shutil.copyfile(out/'archives.json',negative/'archives.json')
with (negative/first).open('r+b') as stream:
    stream.seek(20);value=stream.read(1);stream.seek(20);stream.write(bytes([value[0]^1]))
result=subprocess.run(command[:-1]+[str(negative)],capture_output=True);(negative/'raw.log').write_bytes(result.stdout+result.stderr)
assert result.returncode!=0 and b'archive bytes' in result.stderr
(out/'reader-control.json').write_text(json.dumps({'actual_archive_byte_flip_rejected':True,'exit':result.returncode},indent=2)+'\n')
print('BG17_PACKET',len(files),len(archives),sum(r['bytes'] for r in archives),'verified; corruption rejected',flush=True)
