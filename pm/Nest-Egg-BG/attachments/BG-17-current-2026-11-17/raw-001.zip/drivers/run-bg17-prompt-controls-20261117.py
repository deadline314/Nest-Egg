from pathlib import Path
import hashlib,json,os,subprocess
root=Path('D:/NestEggVerification/bg17-current-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg17/prompt-controls');out.mkdir(exist_ok=False)
private=root/'work/bg17-prompt-controls';private.mkdir(exist_ok=False)
before=Path('D:/NestEggVerification/evidence-20261117/bg17/prompt-guard-preparation/bg17-current-20261117/tools/readability_check.gd').read_text(encoding='utf8')
(private/'before-base.gd').write_text(before,encoding='utf8',newline='\n')
child=(root/'tools/ch2_readability_check.gd').read_text(encoding='utf8')
needle='extends "res://tools/readability_check.gd"';assert child.count(needle)==1
(private/'before-child.gd').write_text(child.replace(needle,'extends "res://work/bg17-prompt-controls/before-base.gd"'),encoding='utf8',newline='\n')
observer='''extends "PARENT"
func _record_probe_sample(probe: ContrastProbe, level: Level, _spot: Array, sample: int, _foe: Enemy, _sums: Array[float]) -> void:
    var visible_count := 0
    var enabled_count := 0
    var processing_count := 0
    var showing_count := 0
    var overlaps: Array[String] = []
    var ring: Rect2 = probe._body_box(level.player.global_position, true).grow(ContrastProbe.RING)
    for node in level.find_children("*", "", true, false):
        var prompt := node as WorldPrompt
        if prompt == null: continue
        visible_count += int(prompt.is_visible_in_tree())
        enabled_count += int(prompt.enabled)
        processing_count += int(prompt.is_processing())
        showing_count += int(prompt.is_showing())
        var rect: Rect2 = prompt.base_rect()
        rect.position += prompt._nudge
        if prompt.is_showing() and prompt._alpha > 0.0 and rect.intersects(ring): overlaps.append(str(prompt.get_path()))
    var suppressed := visible_count == 0 and enabled_count == 0 and processing_count == 0 and showing_count == 0
    _failed = _failed or not suppressed
    print("PROMPT_GUARD ", JSON.stringify({"case": "CASE", "sample": sample, "visible": visible_count, "enabled": enabled_count, "processing": processing_count, "showing": showing_count, "body_ring_overlaps": overlaps, "suppressed": suppressed}))
'''
for name,parent in [('before','res://work/bg17-prompt-controls/before-child.gd'),('fixed','res://tools/ch2_readability_check.gd')]:
    (private/(name+'.gd')).write_text(observer.replace('PARENT',parent).replace('CASE',name),encoding='utf8',newline='\n')
    (private/(name+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg17-prompt-controls/'+name+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n',encoding='utf8')
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','project.godot'],cwd=root).decode().split('\0') if p and (root/p).is_file()]+['data/lighting/legacy_reclaimer.tres']
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
guard=snapshot();(out/'source-before.json').write_text(json.dumps(guard,indent=2)+'\n')
runs=[]
for name,expected in [('before',1),('fixed',0)]:
    folder=out/name;folder.mkdir();env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--quit-after','5000','res://work/bg17-prompt-controls/'+name+'.tscn','--','--level=ch2_pawnshop','--spots=櫃台','--quality=high','--out='+str(folder)]
    with (folder/'raw.log').open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();samples=[json.loads(line.split(b' ',1)[1]) for line in raw.splitlines() if line.startswith(b'PROMPT_GUARD ')]
    row={'case':name,'command':command,'exit':result.returncode,'expected':expected,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':guard==snapshot(),'samples':samples}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(name,result.returncode,len(samples),flush=True)
    assert result.returncode==expected and row['script_errors']==0 and row['source_held'] and len(samples)==16
    assert all(r['suppressed'] for r in samples) if name=='fixed' else any(not r['suppressed'] and r['showing']>0 for r in samples)
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
