from pathlib import Path
import hashlib,json
from PIL import Image,ImageDraw

base=Path('D:/NestEggVerification/evidence-20261117/bg17')
out=base/'review-guarded-final';out.mkdir(exist_ok=False)
sources=['readability-guarded-final','readability-guarded-full-final']
for name in sources:
    ready=json.loads((base/name/'result.json').read_text())
    assert ready['source_held'] and ready['all_original_thresholds_passed'] and len(ready['runs'])==8
records=[];selected=[]
for scene in ['readability_check','ch1_readability_check','ch2_readability_check','ch3_readability_check']:
    for quality in ['low','high']:
        reports=[json.loads((base/name/(scene+'-'+quality)/'readability-report.json').read_text()) for name in sources]
        for r in reports:
            assert r['thresholds']=={'player':.6,'edge':1.0,'enemy':.45}
            assert all(row['sampling_valid'] and row['passed'] for row in r['results'])
        keys=[[(r['level'],r['column'],r['spot']) for r in report['results']] for report in reports]
        assert keys[0]==keys[1] and len(keys[0])==len(set(keys[0]))
        chosen=set()
        for component in ['player_contrast','edge_contrast','enemy_contrast']:
            available=[r for r in reports[0]['results'] if r[component] is not None]
            if available:
                row=min(available,key=lambda r:r[component]);chosen.add((row['level'],row['column'],row['spot']))
        for row in reports[0]['results']:
            if (scene=='readability_check' and row['column'] in [330,400,492]) or row['level'] in ['ch2_loading','ch3_office_hall']:
                chosen.add((row['level'],row['column'],row['spot']))
        for left,right in zip(*[r['results'] for r in reports]):
            inputs=[]
            for name,row in zip(sources,[left,right]):
                path=base/name/(scene+'-'+quality)/row['screenshot']
                with Image.open(path) as im:assert im.size==(640,360)
                inputs.append({'file':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'metrics':{k:row[k] for k in ['player_contrast','edge_contrast','enemy_contrast']}})
            item={'scene':scene,'quality':quality,'level':left['level'],'column':left['column'],'spot':left['spot'],'sources':inputs,'selected_for_review':(left['level'],left['column'],left['spot']) in chosen}
            records.append(item)
            if item['selected_for_review']:selected.append(item)
assert len(records)==152 and sum(len(r['sources']) for r in records)==304
for start in range(0,len(selected),3):
    board=Image.new('RGB',(1024,3*316),(18,18,23));draw=ImageDraw.Draw(board)
    for i,row in enumerate(selected[start:start+3]):
        y=i*316
        for j,source in enumerate(row['sources']):
            with Image.open(source['file']) as im:board.paste(im.resize((512,288)),(j*512,y+28))
            label='%s %s %s@%d %s'%(row['scene'].removesuffix('_readability_check'),row['quality'],row['level'],row['column'],['restricted','full-resolution'][j])
            draw.text((j*512+5,y+6),label,fill='white')
    board.save(out/('page-%02d.png'%(start//3+1)))
(out/'inputs.json').write_text(json.dumps({'all_pairs':records,'selected_pairs':len(selected),'review_pages':(len(selected)+2)//3,'scope':'Original formula/points/thresholds; persistent UI suppression and PERSON NPC isolation. Both resolutions pass all76 points at both quality tiers. Overview selects actual minimum player/edge/enemy per group/quality plus all changed legacy330/400/492, allcurrentch2_loading and unchangedch3_office_hall. Different runs retain natural weather phases; no exact pixel-equivalence assertion.'},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('BG17_REVIEW',len(records),'pairs /304native;',len(selected),'selectedpairs;', (len(selected)+2)//3,'pages',flush=True)
