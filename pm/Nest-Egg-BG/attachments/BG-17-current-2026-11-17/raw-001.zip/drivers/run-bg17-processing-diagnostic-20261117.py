from pathlib import Path
import hashlib
import json
import os
import subprocess

out = Path('D:/NestEggVerification/evidence-20261117/bg17/processing-diagnostic-v2')
out.mkdir(exist_ok=False)
roots = {'legacy': Path('D:/NestEggVerification/bg17-legacy-20261117'), 'current': Path('D:/NestEggVerification/bg17-current-20261117')}
original = (roots['current'] / 'tools/environment_probe.gd').read_text()
anchor = '\t\tvar times: Array[float] = []'
assert original.count(anchor) == 1
addition = '''		if "--diagnostic-freeze-level" in OS.get_cmdline_user_args():
			for node: Node in level.find_children("*", "", true, false):
				node.process_mode = Node.PROCESS_MODE_DISABLED
			level.process_mode = Node.PROCESS_MODE_DISABLED
		if "--diagnostic-freeze-autoloads" in OS.get_cmdline_user_args():
			for node: Node in get_tree().root.get_children():
				if node == self: continue
				node.process_mode = Node.PROCESS_MODE_DISABLED
				for descendant: Node in node.find_children("*", "", true, false): descendant.process_mode = Node.PROCESS_MODE_DISABLED
		for settle_frame in 30: await get_tree().process_frame
		print("DIAGNOSTIC_COUNTERS ", JSON.stringify({"viewport": str(get_viewport().size), "texture_size": str(get_viewport().get_texture().get_size()), "nodes": get_tree().get_node_count(), "objects": Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME), "primitives": Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME), "draws": Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)}))
'''
source = original.replace(anchor, addition + anchor)
for root in roots.values():
    directory = root / 'work/bg17-processing-diagnostic'
    directory.mkdir(parents=True, exist_ok=False)
    (directory / '.gdignore').write_bytes(b'')
    (directory / 'probe.gd').write_text(source, encoding='utf8', newline='\n')
    (directory / 'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://work/bg17-processing-diagnostic/probe.gd" id="1"]\n\n[node name="ProcessingDiagnostic" type="Node"]\nscript = ExtResource("1")\n', encoding='utf8')
before = {name: hashlib.sha256((root / 'work/bg17-processing-diagnostic/probe.gd').read_bytes()).hexdigest() for name, root in roots.items()}
runs = []
for mode, extra in [('normal', []), ('frozen-level', ['--diagnostic-freeze-level']), ('frozen-all', ['--diagnostic-freeze-level', '--diagnostic-freeze-autoloads'])]:
    for epoch in ['legacy', 'current']:
        root = roots[epoch]
        folder = out / (mode + '-' + epoch)
        folder.mkdir()
        env = os.environ.copy()
        for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
            env[key] = str(folder / 'private-profile' / key)
        command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '320x180', '--quit-after', '10000', 'res://work/bg17-processing-diagnostic/probe.tscn', '--', '--level=level_01', '--spots=30', '--quality=low', '--frames=180', '--no-characters', '--out=' + str(folder), *extra]
        with (folder / 'raw.log').open('wb') as log:
            result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        raw = (folder / 'raw.log').read_bytes()
        row = {'mode': mode, 'epoch': epoch, 'command': command, 'exit': result.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'scope': 'Deliberately frozen scene and/or autoload diagnostic; not gameplay or 105% acceptance. Own headless affected suite and other-project load continue.'}
        runs.append(row)
        (out / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
        print(mode, epoch, result.returncode, flush=True)
        assert result.returncode == row['script_errors'] == 0
after = {name: hashlib.sha256((root / 'work/bg17-processing-diagnostic/probe.gd').read_bytes()).hexdigest() for name, root in roots.items()}
(out / 'source-held.json').write_text(json.dumps({'before': before, 'after': after, 'source_held': before == after}, indent=2) + '\n')
assert before == after
