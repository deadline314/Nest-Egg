from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('D:/NestEggVerification/bg17-current-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg17/npc-contract-control/cases')
out.mkdir(exist_ok=False)
probe = root / 'tools/environment_probe.gd'
before = probe.read_bytes()
assert hashlib.sha256(before).hexdigest() == 'a3d7916a69bf1c488c62ea77a5859eadd6ce40396c4b3b5b577eb7eae564efd3'
fixture = root / 'work/bg17-npc-contract-mutant'
fixture.mkdir(exist_ok=False)
line = b'\t\t\t\tfor child: Node in node.find_children("*", "", true, false): child.process_mode = Node.PROCESS_MODE_DISABLED\n'
assert before.count(line) == 1
(fixture / 'probe.gd').write_bytes(before.replace(line, b''))
(fixture / 'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://work/bg17-npc-contract-mutant/probe.gd" id="1"]\n\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n', encoding='utf8')
records = []
for name in ['environment-only', 'normal-mode', 'mutant-always-child']:
    folder = out / name
    folder.mkdir()
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
        env[key] = str(folder / 'private-profile' / key)
    scene = 'res://work/bg17-npc-contract-mutant/probe.tscn' if name.startswith('mutant') else 'res://tools/environment_probe.tscn'
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '320x180', scene, '--', '--level=level_01', '--spots=30', '--frames=30', '--quality=low', '--out=' + str(folder)]
    if name != 'normal-mode':
        command.append('--no-characters')
    with (folder / 'raw.log').open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (folder / 'raw.log').read_bytes()
    actors = [json.loads(line.removeprefix(b'ENVIRONMENT_ACTORS ')) for line in raw.splitlines() if line.startswith(b'ENVIRONMENT_ACTORS ')]
    record = {'name': name, 'command': command, 'exit': process.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'actors': actors}
    records.append(record)
    (out / 'results.json').write_text(json.dumps({'source_held': probe.read_bytes() == before, 'cases': records}, indent=2) + '\n', encoding='utf8')
    print(record, flush=True)
    assert len(actors) == 1 and record['script_errors'] == 0 and probe.read_bytes() == before
    a = actors[0]
    if name == 'environment-only':
        assert process.returncode == 0 and a['excluded_npcs'] == 2 and a['active_npcs'] == a['active_rigs'] == a['enemies'] == 0 and not a['player_can_process']
    elif name == 'normal-mode':
        assert process.returncode == 0 and a['excluded_npcs'] == 0 and a['active_npcs'] == a['active_rigs'] == 2 and a['enemies'] == 5 and a['player_can_process']
    else:
        assert process.returncode == 2 and a['active_rigs'] == 2 and b'characters still update in environment-only mode' in raw
