from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import psutil

out = Path('D:/NestEggVerification/evidence-20261117/bg17/abba-npc-contract-v3')
out.mkdir(exist_ok=False)
dependency = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/candidates/v11-ground-plane/performance-native-v5/source-held.json')
print('Waiting for own actor native V2 ABBA EOF', flush=True)
while not dependency.is_file():
    time.sleep(2)
assert json.loads(dependency.read_text())['source_held']
roots = {'legacy': Path('D:/NestEggVerification/bg17-legacy-20261117'), 'current': Path('D:/NestEggVerification/bg17-current-20261117')}
paths = {name: [p for p in subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'core', 'game', 'data', 'ui', 'art', 'tools', 'project.godot'], cwd=root).decode('utf8').split('\0') if p and (root / p).is_file()] for name, root in roots.items()}
def snapshot(name):
    return {p: hashlib.sha256((roots[name] / p).read_bytes()).hexdigest() for p in paths[name]}
def workload():
    result = []
    for p in psutil.process_iter(['pid', 'name']):
        try:
            if 'godot' in p.info['name'].lower():
                cpu = p.cpu_times()
                result.append({'pid': p.pid, 'name': p.info['name'], 'cwd': p.cwd(), 'cpu_s': cpu.user + cpu.system, 'rss_bytes': p.memory_info().rss})
        except psutil.Error:
            pass
    return result
before = {name: snapshot(name) for name in roots}
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
records = []
for index, name in enumerate(['legacy', 'current', 'current', 'legacy'], 1):
    root = roots[name]
    folder = out / (str(index) + '-' + name)
    folder.mkdir()
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
        env[key] = str(folder / 'private-profile' / key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '320x180', '--quit-after', '5000', 'res://tools/environment_probe.tscn', '--', '--level=level_01', '--quality=low', '--frames=180', '--no-characters', '--out=' + str(folder)]
    load_before = workload()
    with (folder / 'raw.log').open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (folder / 'raw.log').read_bytes()
    rows = [json.loads(s.removeprefix(b'ENVIRONMENT_SAMPLES ')) for s in raw.splitlines() if s.startswith(b'ENVIRONMENT_SAMPLES ')]
    actors = [json.loads(line.removeprefix(b'ENVIRONMENT_ACTORS ')) for line in raw.splitlines() if line.startswith(b'ENVIRONMENT_ACTORS ')]
    assert len(actors) == 3 and all(a['no_characters'] and a['excluded_npcs'] == 2 and a['active_npcs'] == a['active_rigs'] == a['enemies'] == 0 and not a['player_can_process'] for a in actors)
    record = {'actor_contracts': actors, 'order': index, 'epoch': name, 'command': command, 'exit': process.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'workload_before': load_before, 'workload_after': workload(), 'samples': rows}
    (folder / 'run.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
    records.append(record)
    assert process.returncode == 0 and record['script_errors'] == 0 and len(rows) == 3 and all(len(r['samples_ms']) == 180 for r in rows)
    print(index, name, [round(sum(r['samples_ms']) / 180.0, 4) for r in rows], flush=True)
after = {name: snapshot(name) for name in roots}
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
ratios = {}
for tile in [30, 115, 200]:
    values = {name: [sum(row['samples_ms']) / len(row['samples_ms']) for r in records if r['epoch'] == name for row in r['samples'] if row['tile'] == tile] for name in roots}
    ratios[str(tile)] = {'legacy_means': values['legacy'], 'current_means': values['current'], 'ratio': sum(values['current']) / sum(values['legacy'])}
foreign = [p for r in records for k in ['workload_before', 'workload_after'] for p in r[k] if 'NestEggVerification' not in p['cwd']]
receipt = {'source_held': before == after, 'numeric_105_percent_gate': all(r['ratio'] <= 1.05 for r in ratios.values()), 'machine_exclusive': not foreign, 'ratios': ratios, 'records': records, 'scope': 'Full 180-frame ABBA, identical corrected environment-only tool/renderer/audio/quality/points and forced per-epoch imports. Original mixed-NPC failures retained separately; contract confirms authored NPC and ALWAYS rig updates are excluded in both epochs. No game feature is disabled in production or normal probe mode. Own game suites finished. Other-project process load recorded; never claim machine exclusivity if present. Numeric gate is separate from protocol conditions.'}
(out / 'results.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print('BG17_ABBA', receipt['numeric_105_percent_gate'], 'machine_exclusive', receipt['machine_exclusive'], ratios, flush=True)
assert before == after
