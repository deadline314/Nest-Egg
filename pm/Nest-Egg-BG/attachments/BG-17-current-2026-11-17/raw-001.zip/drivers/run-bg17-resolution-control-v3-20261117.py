from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

root = Path('D:/NestEggVerification/bg17-current-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg17/resolution-control-v3')
out.mkdir(exist_ok=False)
dependency = Path('D:/NestEggVerification/evidence-20261117/bg17/abba-final-v2/results.json')
while not dependency.is_file(): time.sleep(2)
assert json.loads(dependency.read_text())['source_held']
sidecars = {p.relative_to(root).as_posix(): p.read_bytes() for p in (root / 'art/environment').rglob('*.import')}
paths = [p for p in subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'core', 'game', 'data', 'ui', 'art', 'tools', 'project.godot'], cwd=root).decode('utf8').split('\0') if p and (root / p).is_file()]
def snapshot():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
env = os.environ.copy()
for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
    env[key] = str(out / 'private-profile' / key)
godot = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root)]
records = []
def run(name, arguments):
    command = godot + arguments
    with (out / (name + '.log')).open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (out / (name + '.log')).read_bytes()
    record = {'name': name, 'command': command, 'exit': process.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:')}
    records.append(record)
    (out / 'runs.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf8')
    print(name, process.returncode, flush=True)
    assert process.returncode == 0 and record['script_errors'] == 0
def preserve_derived_cache(relatives, name):
    moved = []
    cache = (root / '.godot/imported').resolve()
    for relative in relatives:
        for generated in re.findall(r'^path(?:\.[^=]+)?="res://(\.godot/imported/[^"\n]+)"', (root / relative).read_text(encoding='utf8'), re.M):
            source = (root / generated).resolve()
            assert source.parent == cache and source.suffix == '.ctex'
            if source.is_file():
                backup = out / name / source.name
                backup.parent.mkdir(exist_ok=True)
                assert not backup.exists()
                source.rename(backup)
                moved.append(generated)
    assert moved
    (out / (name + '.json')).write_text(json.dumps(moved, indent=2) + '\n', encoding='utf8')
changed = []
try:
    for epoch in ['restricted', 'full-resolution']:
        if epoch == 'full-resolution':
            changed = []
            for relative, data in sidecars.items():
                full = re.sub(rb'(?m)^process/size_limit=[0-9]+(\r?)$', rb'process/size_limit=0\1', data)
                if full != data:
                    backup = out / 'import-before' / relative
                    backup.parent.mkdir(parents=True, exist_ok=True)
                    backup.write_bytes(data)
                    (root / relative).write_bytes(full)
                    changed.append(relative)
            (out / 'full-resolution-only-paths.json').write_text(json.dumps(changed, indent=2) + '\n', encoding='utf8')
            preserve_derived_cache(changed, 'restricted-derived-before-full')
            run('import-full-resolution', ['--headless', '--editor', '--import'])
        for level, spots in [('level_01', '30,115,200'), ('level_02', '30,175,350'), ('ch1_street', '30,130,180'), ('ch1_warehouse', '15,75,145')]:
            folder = out / epoch / level
            folder.mkdir(parents=True)
            run(epoch + '-' + level, ['--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '1280x720', '--fixed-fps', '60', 'res://tools/environment_probe.tscn', '--', '--level=' + level, '--spots=' + spots, '--quality=low', '--frames=30', '--no-characters', '--out=' + str(folder)])
            assert len(list(folder.glob('*.png'))) == 3
finally:
    for relative, data in sidecars.items():
        if (root / relative).read_bytes() != data:
            (root / relative).write_bytes(data)
    if changed:
        preserve_derived_cache(changed, 'full-derived-before-restore')
    run('import-restored-policy', ['--headless', '--editor', '--import'])
    line_endings = []
    for relative, data in sidecars.items():
        actual = (root / relative).read_bytes()
        if actual != data:
            assert actual.replace(b'\r\n', b'\n') == data.replace(b'\r\n', b'\n'), relative
            (root / relative).write_bytes(data)
            line_endings.append(relative)
    (out / 'sidecar-line-ending-restorations.json').write_text(json.dumps(line_endings, indent=2) + '\n', encoding='utf8')
    after = snapshot()
    (out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
    (out / 'restoration.json').write_text(json.dumps({'source_held': before == after, 'tracked_source_count': len(before), 'sidecar_count': len(sidecars), 'scope': 'Same code, only import size_limit temporarily set to zero. Fixed60 visual/payload control under background workload; not performance acceptance. Every original sidecar restored byte-for-byte and policy reimported.'}, indent=2) + '\n', encoding='utf8')
    assert before == after
