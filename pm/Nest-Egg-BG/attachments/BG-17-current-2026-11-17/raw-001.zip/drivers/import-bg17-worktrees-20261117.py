from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

OUT = Path('D:/NestEggVerification/evidence-20261117/bg17/imports-v1')
OUT.mkdir(exist_ok=False)
CURRENT = Path('D:/NestEggVerification/bg17-current-20261117')
LEGACY = Path('D:/NestEggVerification/bg17-legacy-20261117')
shutil.copyfile(CURRENT / 'tools/environment_probe.gd', LEGACY / 'tools/environment_probe.gd')
PYTHON = 'D:/ComfyUI/.venv-rocm/Scripts/python.exe'
LOCK = 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py'
GODOT = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
results = []
for name, root in [('legacy', LEGACY), ('current', CURRENT)]:
    folder = OUT / name
    folder.mkdir()
    paths = [p for p in subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'core', 'game', 'data', 'ui', 'art', 'tools', 'project.godot'], cwd=root).decode('utf8').split('\0') if p and (root / p).is_file()]
    paths = sorted(set(paths + ['tools/environment_probe.gd', 'tools/environment_probe.tscn']))
    def snapshot():
        return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}
    before = snapshot()
    (folder / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
        env[key] = str(folder / 'private-profile' / key)
    command = [PYTHON, LOCK, '--', GODOT, '--headless', '--path', str(root), '--editor', '--quit']
    request = {'command': command, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(), 'scope': 'Actual existing import cache copied as acceleration only. Editor must revalidate changed source/import settings. No native/performance acceptance from editor execution.'}
    (folder / 'request.json').write_text(json.dumps(request, indent=2) + '\n', encoding='utf8')
    start = time.monotonic()
    with (folder / 'raw.log').open('wb') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    after = snapshot()
    (folder / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
    changes = {p: {'before': before[p], 'after': after[p]} for p in before if before[p] != after[p]}
    raw = (folder / 'raw.log').read_bytes()
    record = {'name': name, 'natural_exit': result.returncode, 'elapsed_s': time.monotonic() - start, 'tracked_source_changes': changes, 'script_errors': raw.count(b'SCRIPT ERROR:')}
    (folder / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
    results.append(record)
    print('BG17_IMPORT', name, 'exit', result.returncode, 'script errors', record['script_errors'], 'tracked changes', len(changes), flush=True)
    if result.returncode or record['script_errors']:
        break
(OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf8')
