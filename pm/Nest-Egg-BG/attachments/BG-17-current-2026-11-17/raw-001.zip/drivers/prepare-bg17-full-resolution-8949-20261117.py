from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

source=Path('D:/NestEggVerification/bg17-current-20261117')
root=Path('D:/NestEggVerification/bg17-full-resolution-8949')
out=Path('D:/NestEggVerification/evidence-20261117/bg17/full-resolution-8949')
out.mkdir(exist_ok=False)
assert not root.exists()
cfg=['git','-c','core.packedGitLimit=128m','-c','core.packedGitWindowSize=32m','-c','core.deltaBaseCacheLimit=64m']
subprocess.run(cfg+['worktree','add','--detach','--no-checkout',str(root),'8949fac01ec6fb1afbc27ea982363985569c5bd3'],check=True)
subprocess.run(cfg+['sparse-checkout','set','--no-cone','/*','!/pm/','!/design/','!/art_src/','!/assets_src/'],cwd=root,check=True)
subprocess.run(cfg+['read-tree','-mu','HEAD'],cwd=root,check=True)
paths=[p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','project.godot'],cwd=source).decode('utf8').split('\0') if p and (source/p).is_file()]
for p in paths:
    assert (root/p).is_file(),p
    if (root/p).read_bytes() != (source/p).read_bytes(): shutil.copyfile(source/p,root/p)
same={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
assert same=={p:hashlib.sha256((source/p).read_bytes()).hexdigest() for p in paths}
(out/'same-code-restricted-source.json').write_text(json.dumps(same,indent=2)+'\n')
assert not (root/'.godot').exists()
(root/'.godot').mkdir()
shutil.copytree(source/'.godot/imported',root/'.godot/imported')
for name in ['global_script_class_cache.cfg','uid_cache.bin']:
    if (source/'.godot'/name).is_file(): shutil.copyfile(source/'.godot'/name,root/'.godot'/name)
changed=[]
cache=(root/'.godot/imported').resolve()
derived=[]
for p in sorted((root/'art/environment').rglob('*.import')):
    raw=p.read_bytes()
    full=re.sub(rb'(?m)^process/size_limit=[0-9]+(\r?)$',rb'process/size_limit=0\1',raw)
    if full==raw: continue
    relative=p.relative_to(root).as_posix()
    backup=out/'restricted-sidecars'/relative
    backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(raw)
    p.write_bytes(full);changed.append(relative)
    for generated in re.findall(r'^path(?:\.[^=]+)?="res://(\.godot/imported/[^"\n]+)"',raw.decode('utf8'),re.M):
        artifact=(root/generated).resolve()
        assert artifact.parent==cache and artifact.suffix=='.ctex'
        if artifact.is_file():
            target=out/'restricted-derived'/artifact.name
            target.parent.mkdir(exist_ok=True)
            assert not target.exists()
            artifact.rename(target);derived.append(generated)
(out/'full-resolution-only-paths.json').write_text(json.dumps(changed,indent=2)+'\n')
(out/'restricted-derived.json').write_text(json.dumps(derived,indent=2)+'\n')
env=os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(out/'private-profile'/key)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--headless','--editor','--import','--audio-driver','Dummy']
with (out/'import.log').open('wb') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
(out/'full-source-after-import.json').write_text(json.dumps(after,indent=2)+'\n')
differences=[p for p in paths if same[p]!=after[p]]
assert set(differences)==set(changed)
raw=(out/'import.log').read_bytes()
record={'command':command,'exit':result.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'same_runtime_before_import':True,'full_resolution_only_paths':changed,'source_count':len(paths),'derived_preserved':len(derived),'scope':'Separate owned checkout, identical current8949+BG17 runtime; only environment import size_limit set0. Existing current worktree and its running tests are never mutated. Forced derived-cache regeneration for each changed import; inherited cache alone is not accepted as full resolution.'}
(out/'ready.json').write_text(json.dumps(record,indent=2)+'\n')
print('BG17_FULL_RESOLUTION_READY',result.returncode,len(changed),len(paths),flush=True)
assert result.returncode==record['script_errors']==0 and changed and derived
