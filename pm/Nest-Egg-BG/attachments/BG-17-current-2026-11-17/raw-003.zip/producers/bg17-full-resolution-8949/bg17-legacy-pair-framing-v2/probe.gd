extends "res://work/bg17-legacy-pair-framing-v2/base.gd"
func _record_probe_sample(_probe: ContrastProbe, level: Level, spot: Array, sample: int, foe: Enemy, _sums: Array[float]) -> void:
    if sample != 15: return
    assert(spot[1] == 492 and is_instance_valid(foe))
    var feet: Array[Vector2] = [level.player.global_position, foe.global_position]
    var mode := level.process_mode
    var camera := get_viewport().get_camera_2d() as LevelCamera
    var running := camera.is_physics_processing()
    var old_position := camera.global_position
    camera.set_physics_process(false)
    level.process_mode = Node.PROCESS_MODE_DISABLED
    var body := Rect2(feet[0] + Vector2(-20, -70), Vector2(40, 70)).merge(Rect2(feet[1] + Vector2(-20, -70), Vector2(40, 70)))
    camera.global_position.y = body.get_center().y
    camera.reset_smoothing()
    camera.force_update_scroll()
    await get_tree().process_frame
    await RenderingServer.frame_post_draw
    var image := get_viewport().get_texture().get_image()
    var transform := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
    var fully_visible := true
    for point in [body.position, Vector2(body.end.x, body.position.y), body.end, Vector2(body.position.x, body.end.y)]:
        fully_visible = fully_visible and Rect2(Vector2.ZERO, image.get_size()).has_point(transform * point)
    var result: Dictionary = await preload("res://tools/weapon_head_probe.gd").capture(self, level, _out_dir, "legacy-492-full-pair")
    var actors_held: bool = level.player.global_position == feet[0] and foe.global_position == feet[1]
    print("LEGACY_PAIR ", JSON.stringify({"both_conservative_body_rects_fully_visible": fully_visible, "actors_held": actors_held, "feet": [[feet[0].x, feet[0].y], [feet[1].x, feet[1].y]], "old_camera": [old_position.x, old_position.y], "paired_camera": [camera.global_position.x, camera.global_position.y], "head": result, "scope": "Supplemental camera-only full-body framing after all16 original contrast samples, actors unchanged. Original contrast report retains its original partially clipped framing; this image is not substituted into the original metric."}))
    assert(fully_visible and actors_held and result.get("bound_valid", false))
    camera.global_position = old_position
    camera.reset_smoothing()
    camera.force_update_scroll()
    camera.set_physics_process(running)
    level.process_mode = mode
