extends "res://tools/readability_check.gd"
var _variant := "edge-only"
func _ready() -> void:
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--variant="): _variant = arg.trim_prefix("--variant=")
    super._ready()
func _prepare_probe_level(data: LevelData) -> void:
    var original_theme := data.environment
    var theme := original_theme.duplicate() as EnvironmentTheme
    theme.zones = []
    for original: EnvZone in original_theme.zones:
        var zone := original.duplicate() as EnvZone
        if original.material.id == &"hangar":
            zone.material = original.material.duplicate() as TerrainMaterialData
            zone.material.edge_color.a = 0.55
            assert(original.material.edge_color.a == 0.4)
        theme.zones.append(zone)
    data.environment = theme
    if _variant == "edge-and-fill" and data.id == &"level_02":
        var zones: Array[LightingZone] = []
        for original: LightingZone in data.lighting_zones:
            var zone := original.duplicate() as LightingZone
            if original.start_tile == 470:
                zone.profile = original.profile.duplicate() as LightingProfile
                zone.profile.character_floor = 0.8
                assert(original.profile.character_floor == 0.0)
            zones.append(zone)
        data.lighting_zones = zones
func _record_probe_sample(probe: ContrastProbe, level: Level, spot: Array, sample: int, _foe: Enemy, _sums: Array[float]) -> void:
    var box := Rect2(level.player.global_position + Vector2(-20, -90), Vector2(40, 90))
    var rect := probe._screen_rect(box)
    assert(rect.has_area() and probe._image.get_format() == Image.FORMAT_RGBH)
    var image := probe._image.get_region(rect)
    var white := 0
    for y in image.get_height():
        for x in image.get_width():
            var pixel := image.get_pixel(x, y)
            if pixel.r > 0.92 and pixel.g > 0.92 and pixel.b > 0.92: white += 1
    var name := "%s-%d-%02d.rgbh" % [level.data.id, spot[1], sample]
    var file := FileAccess.open(_out_dir.path_join(name), FileAccess.WRITE)
    assert(file != null)
    file.store_buffer(image.get_data())
    file.close()
    print("LEGACY_LIGHT_SAMPLE ", JSON.stringify({"level": str(level.data.id), "tile": spot[1], "sample": sample, "variant": _variant, "profile": str(level._lighting.current.id), "ambient": [level._lighting.current.ambient_color.r, level._lighting.current.ambient_color.g, level._lighting.current.ambient_color.b], "character_floor": level._lighting.current.character_floor, "character_fill": LightKit.character_fill, "enemy_fill": LightKit.enemy_fill, "player_light": LightKit.player_light_energy, "rect": [rect.position.x, rect.position.y, rect.size.x, rect.size.y], "raw": name, "raw_sha256": FileAccess.get_sha256(_out_dir.path_join(name)), "format": "RGBH", "white": white, "total": rect.get_area(), "scope": "Conservative body-and-background rectangle; zero bounds head white pixels, nonzero is not an exact head ratio."}))
