extends "res://tools/ch2_readability_check.gd"
func _record_probe_sample(probe: ContrastProbe, level: Level, _spot: Array, sample: int, _foe: Enemy, _sums: Array[float]) -> void:
    var visible_count := 0
    var enabled_count := 0
    var processing_count := 0
    var showing_count := 0
    var overlaps: Array[String] = []
    var ring: Rect2 = probe._body_box(level.player.global_position, true).grow(ContrastProbe.RING)
    for node in level.find_children("*", "", true, false):
        var prompt := node as WorldPrompt
        if prompt == null: continue
        visible_count += int(prompt.is_visible_in_tree())
        enabled_count += int(prompt.enabled)
        processing_count += int(prompt.is_processing())
        showing_count += int(prompt.is_showing())
        var rect: Rect2 = prompt.base_rect()
        rect.position += prompt._nudge
        if prompt.is_showing() and prompt._alpha > 0.0 and rect.intersects(ring): overlaps.append(str(prompt.get_path()))
    var suppressed := visible_count == 0 and enabled_count == 0 and processing_count == 0 and showing_count == 0
    _failed = _failed or not suppressed
    print("PROMPT_GUARD ", JSON.stringify({"case": "fixed", "sample": sample, "visible": visible_count, "enabled": enabled_count, "processing": processing_count, "showing": showing_count, "body_ring_overlaps": overlaps, "suppressed": suppressed}))
