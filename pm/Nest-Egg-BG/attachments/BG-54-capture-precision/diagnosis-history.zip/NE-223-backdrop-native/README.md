# NE-223 原生背景對照

起點：`61742fff`。本輪接續已推送的快取／操作交付，專門處理真正暫停與任務畫面底下無法辨認當舖的色塊。物理手把與孤立效能驗收不包含在本輪。

`baseline-receipt.json` 保存起點、背景產品來源與診斷工具的 SHA-256；`baseline-probe.gd.txt` 保存該版工具來源。探針會保留 Forward+、HDR 2D、燈、霧與正式場景繪製；世界在同一個程序凍結後依序擷取，沒有換場景來製造前後差異。

## 原工具的暫停安排錯誤

`first-copy-hypothesis.zip` 與 `moving-world-control.zip` 都使用錯誤的觀察者繼承安排：root 為 ALWAYS，Level 也繼承 ALWAYS，因此只設暫停旗標並沒有凍結玩家、鏡頭或遊玩時間。`moving-world-probe.gd.txt`／`moving-world-receipt.json` 保留第二次錯誤工具的來源與收據，原圖和原 log 全部保留。兩批不能作精確同影格對照；其中直接來源與世界差異 0.0846 包含鏡頭位移，不能據此指控取樣來源錯亂。

修正後明設真正 Level 為 PAUSABLE，觀察者保留 ALWAYS。兩支工具共用凍結取樣，逐次核對同一玩家／鏡頭身分與位置、鏡頭中心及畫布變換、遊玩時間與霧時間；不再把 `tree.paused` 當成世界凍結證據。新版收據與 baseline 工具對應這個修正。

## 已排除的第一個方向

`first-copy-hypothesis.zip` 保留第一次實驗的原始截圖、報告與 log。未暫停的當舖正常，真正暫停與任務頁出現色塊。將明確擷取插到背景前面，畫面沒有改善；純色場景中，較早後製顯示與隱藏的差異也為 0。因此這組實驗沒有證實「較早後製搶走取樣來源」，不能以官方文件的一般規則代替本次成因，也沒有依此加上產品重新擷取。

原問題也出現在單獨的暫停頁，與本輪地圖跨頁快取無關。第一次實驗的 0 問題只指純色來源的兩個斷言，**不表示背景畫面通過**。

## 可重跑的診斷

```powershell
python tools/comfyui/gpu_lock.py -- C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path . --rendering-driver vulkan --rendering-method forward_plus res://tools/scene_backdrop_probe.tscn -- --out=<絕對資料夾>
```

探針將直接取樣螢幕的原圖與世界 readback 比較；再分別改變模糊取樣間距、縮圖層級，保存背景本身與真正任務頁。`no-copy`、`LOD0`、`spacing` 是工具在執行期間明示的單因素介入，不代表歷史 checkout。原生實際結果、產品修正與接受的視覺版本分開記錄。
