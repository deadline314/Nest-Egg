extends Node
## 原生屏幕取樣回歸：先以後製後的純色遮蓋辨識讀取來源，再取真正當舖的世界／暫停／任務。
## 無人工、樣本任務或故事旗標；copy/no-copy、LOD0、post-hidden 為明示的單因素診斷。

var _out := ""
var _width := 1280
var _height := 720
var _issues: Array[String] = []
var _metrics := {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=").replace("\\", "/")
		elif arg.begins_with("--width="):
			_width = int(arg.trim_prefix("--width="))
		elif arg.begins_with("--height="):
			_height = int(arg.trim_prefix("--height="))
	if not _out.is_absolute_path() or DirAccess.make_dir_recursive_absolute(_out) != OK:
		push_error("[SceneBackdropProbe] --out 必須是可建立的絕對路徑。")
		get_tree().quit(2)
		return
	get_window().size = Vector2i(_width, _height)
	DisplayMode.ensure_scaling(get_window())
	_run.call_deferred()


func _run() -> void:
	var sources := preload("res://tools/world_pause_sample.gd").source_receipt(_out, ["res://tools/scene_backdrop_probe.gd", "res://tools/world_pause_sample.gd", "res://ui/kit/scene_backdrop.gd"])
	Settings.use_storage("user://ne223-backdrop-probe-settings.cfg")
	Settings.set_reduce_ui_motion(true)
	Story.auto_skip = true
	add_child(LightKit.create_environment())
	await _minimal()
	await _real()
	var report := {"renderer": RenderingServer.get_current_rendering_method(), "adapter": RenderingServer.get_video_adapter_name(), "resolution": [_width, _height], "sources": sources, "metrics": _metrics, "issues": _issues, "interventions": "minimal colored layers identify copy source; real scene copy-mode and LOD parameters are toggled only by this diagnostic tool"}
	var file := FileAccess.open(_out.path_join("backdrop-report.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "\t"))
	print("SCENE_BACKDROP_PROBE ", JSON.stringify(report))
	Sfx.stop_all()
	Music.stop(0.0)
	Ambience.stop_all(0.0)
	await get_tree().create_timer(0.3, true, false, true).timeout
	get_tree().quit(0 if _issues.is_empty() else 1)


func _minimal() -> void:
	var source := ColorRect.new()
	source.color = Color(0.8, 0.1, 0.1)
	UiKit.fill_parent(source)
	add_child(source)
	var early := PostProcess.new()
	add_child(early)
	# 這一整層在真正後製之後繪製，所以正確的背景只可能讀到綠色，與前一層無關。
	var later := CanvasLayer.new()
	later.layer = UiLayers.HUD
	add_child(later)
	var green := ColorRect.new()
	green.color = Color(0.1, 0.8, 0.2)
	UiKit.fill_parent(green)
	later.add_child(green)
	var top := CanvasLayer.new()
	top.layer = UiLayers.PAUSE
	add_child(top)
	var backdrop := SceneBackdrop.new()
	top.add_child(backdrop)
	await _settle()
	var production := await _capture("minimal-production")
	early.hide()
	var no_early := await _capture("minimal-no-earlier-reader")
	early.show()
	var copy := _copy_for(backdrop)
	copy.copy_mode = BackBufferCopy.COPY_MODE_VIEWPORT
	var explicit_copy := await _capture("minimal-explicit-copy")
	_metrics["production_vs_no_earlier_reader_mae"] = _mae(production, no_early)
	_metrics["explicit_copy_vs_no_earlier_reader_mae"] = _mae(explicit_copy, no_early)
	_expect(_metrics["production_vs_no_earlier_reader_mae"] < 0.003, "背景必須取到後製後的覆蓋層，不受較早讀螢幕的後製影響。")
	_expect(_metrics["explicit_copy_vs_no_earlier_reader_mae"] < 0.003, "明確擷取後，較早的螢幕讀取不應改變背景來源。")
	# 非均勻 sentinel：分別核對 LOD0／1／2，不能只由 LOD0 推論高層縮圖也正確。
	var sentinel_shader := Shader.new()
	sentinel_shader.code = "shader_type canvas_item; void fragment() { vec3 a = UV.x < 0.5 ? vec3(0.8, 0.1, 0.1) : vec3(0.1, 0.2, 0.8); COLOR = vec4(UV.y < 0.5 ? a : a.gbr, 1.0); }"
	var sentinel_material := ShaderMaterial.new()
	sentinel_material.shader = sentinel_shader
	green.material = sentinel_material
	copy.copy_mode = BackBufferCopy.COPY_MODE_DISABLED
	var direct := _direct_shader()
	(backdrop.material as ShaderMaterial).shader = direct
	for lod in [0.0, 1.0, 2.0]:
		(backdrop.material as ShaderMaterial).set_shader_parameter(&"source_lod", lod)
		early.show()
		var with_early := await _capture("sentinel-lod%d-with-earlier-reader" % int(lod))
		early.hide()
		var without_early := await _capture("sentinel-lod%d-without-earlier-reader" % int(lod))
		var error := _mae(with_early, without_early)
		_metrics["sentinel_lod%d_earlier_reader_mae" % int(lod)] = error
		_expect(error < 0.003, "LOD%d 的 sentinel 來源不能受較早後製影響。" % int(lod))
	for node in [source, early, later, top]:
		node.queue_free()
	await _settle()


func _real() -> void:
	GameState.start_new_run(GameState.difficulties[0])
	var level := Level.new()
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	level.configure(load("res://data/levels/ch1_pawnshop.tres") as LevelData)
	add_child(level)
	await get_tree().create_timer(2.0, true, false, true).timeout
	get_tree().paused = true
	var frozen := preload("res://tools/world_pause_sample.gd").snapshot(level)
	var world := await _capture("pawnshop-world")
	var sample_layer := CanvasLayer.new()
	sample_layer.layer = UiLayers.PAUSE
	add_child(sample_layer)
	var sample := SceneBackdrop.new()
	sample_layer.add_child(sample)
	await _capture("pawnshop-backdrop-only-production")
	var sample_material := sample.material as ShaderMaterial
	var original_shader := sample_material.shader
	var direct := _direct_shader()
	sample_material.shader = direct
	var raw_source := await _capture("pawnshop-direct-screen-source")
	_metrics["direct_screen_source_vs_world_mae"] = _mae(raw_source, world)
	_metrics["source_lod0_range"] = _range(raw_source)
	for lod in [1.0, 2.0]:
		sample_material.set_shader_parameter(&"source_lod", lod)
		var mip := await _capture("pawnshop-direct-screen-source-lod%d" % int(lod))
		_metrics["source_lod%d_range" % int(lod)] = _range(mip)
	var unclamped := Shader.new()
	unclamped.code = original_shader.code.replace("min(textureLod(screen_tex, uv + vec2(float(x), float(y)) * texel, blur_lod).rgb, vec3(1.2))", "textureLod(screen_tex, uv + vec2(float(x), float(y)) * texel, blur_lod).rgb")
	sample_material.shader = unclamped
	await _capture("pawnshop-backdrop-no-clamp")
	var raw_soft := Shader.new()
	raw_soft.code = original_shader.code.replace("COLOR = vec4(mix(scene, tint, dim), 1.0);", "COLOR = vec4(scene, 1.0);")
	sample_material.shader = raw_soft
	await _capture("pawnshop-backdrop-raw-soft")
	sample_material.shader = _single_shader(original_shader)
	await _capture("pawnshop-backdrop-single-sample")
	sample_material.shader = _spacing_shader(original_shader)
	sample_material.set_shader_parameter(&"sample_spacing", 1.0)
	sample_material.set_shader_parameter(&"blur_lod", 2.0)
	await _capture("pawnshop-backdrop-only-spacing1-lod2")
	sample_material.set_shader_parameter(&"blur_lod", 1.0)
	await _capture("pawnshop-backdrop-only-spacing1-lod1")
	sample_material.set_shader_parameter(&"blur_lod", 0.0)
	await _capture("pawnshop-backdrop-only-spacing1-lod0")
	sample_material.set_shader_parameter(&"sample_spacing", 2.0)
	await _capture("pawnshop-backdrop-only-spacing2-lod0")
	sample_layer.queue_free()
	await _settle()
	level._pause_menu.open()
	await _capture("pawnshop-pause-production")
	level._pause_menu._open_navigation("quests")
	await _capture("pawnshop-quests-production")
	var backdrop := level._pause_menu._navigation.get_child(0) as SceneBackdrop
	var quest_material := backdrop.material as ShaderMaterial
	var quest_original := quest_material.shader
	quest_material.shader = _single_shader(quest_original)
	await _capture("pawnshop-quests-single-sample")
	quest_material.shader = quest_original
	var copy := _copy_for(backdrop)
	copy.copy_mode = BackBufferCopy.COPY_MODE_DISABLED
	await _capture("pawnshop-quests-no-copy")
	(backdrop.material as ShaderMaterial).set_shader_parameter(&"blur_lod", 0.0)
	await _capture("pawnshop-quests-no-copy-lod0")
	(backdrop.material as ShaderMaterial).set_shader_parameter(&"blur_lod", 2.0)
	copy.copy_mode = BackBufferCopy.COPY_MODE_VIEWPORT
	await _capture("pawnshop-quests-explicit-copy")
	copy.copy_mode = BackBufferCopy.COPY_MODE_DISABLED
	(backdrop.material as ShaderMaterial).shader = _spacing_shader((backdrop.material as ShaderMaterial).shader)
	(backdrop.material as ShaderMaterial).set_shader_parameter(&"sample_spacing", 1.0)
	(backdrop.material as ShaderMaterial).set_shader_parameter(&"blur_lod", 2.0)
	await _capture("pawnshop-quests-spacing1-lod2")
	(backdrop.material as ShaderMaterial).set_shader_parameter(&"blur_lod", 1.0)
	await _capture("pawnshop-quests-spacing1-lod1")
	(backdrop.material as ShaderMaterial).set_shader_parameter(&"blur_lod", 0.0)
	await _capture("pawnshop-quests-spacing1-lod0")
	(backdrop.material as ShaderMaterial).set_shader_parameter(&"sample_spacing", 2.0)
	await _capture("pawnshop-quests-spacing2-lod0")
	(backdrop.material as ShaderMaterial).set_shader_parameter(&"sample_spacing", 6.0)
	(backdrop.material as ShaderMaterial).set_shader_parameter(&"blur_lod", 2.0)
	await _capture("pawnshop-quests-restored-original-kernel")
	var after := preload("res://tools/world_pause_sample.gd").snapshot(level)
	_metrics["world_freeze_before"] = frozen
	_metrics["world_freeze_after"] = after
	_metrics["world_frozen"] = frozen == after
	_expect(frozen == after and level.process_mode == Node.PROCESS_MODE_PAUSABLE, "同場景對照期間玩家、鏡頭、世界霧時間與遊玩時間必須真正凍結。")
	level._pause_menu.close()
	level.queue_free()
	get_tree().paused = false
	await _settle()


func _spacing_shader(original: Shader) -> Shader:
	var shader := Shader.new()
	shader.code = original.code
	if not shader.code.contains("uniform float sample_spacing"):
		shader.code = shader.code.replace("shader_type canvas_item;", "shader_type canvas_item;\nuniform float sample_spacing = 6.0;")
	shader.code = shader.code.replace("SCREEN_PIXEL_SIZE * 6.0", "SCREEN_PIXEL_SIZE * sample_spacing").replace("SCREEN_PIXEL_SIZE * 1.0", "SCREEN_PIXEL_SIZE * sample_spacing")
	return shader


func _direct_shader() -> Shader:
	var shader := Shader.new()
	shader.code = "shader_type canvas_item; uniform sampler2D screen_tex : hint_screen_texture, filter_linear_mipmap, repeat_disable; uniform float source_lod = 0.0; void fragment() { COLOR = vec4(textureLod(screen_tex, SCREEN_UV, source_lod).rgb, 1.0); }"
	return shader


func _single_shader(original: Shader) -> Shader:
	var shader := Shader.new()
	shader.code = original.code.replace("vec3 scene = soft(SCREEN_UV, SCREEN_PIXEL_SIZE * 6.0);", "vec3 scene = min(textureLod(screen_tex, SCREEN_UV, blur_lod).rgb, vec3(1.2));")
	return shader


func _copy_for(backdrop: SceneBackdrop) -> BackBufferCopy:
	for child in backdrop.get_children():
		if child is BackBufferCopy:
			return child
	var copy := BackBufferCopy.new()
	copy.name = "BackdropCopy"
	copy.show_behind_parent = true
	backdrop.add_child(copy)
	return copy


func _capture(name: String) -> Image:
	await _settle()
	await RenderingServer.frame_post_draw
	var raw := get_viewport().get_texture().get_image()
	var error := preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(_out.path_join("NE-223-backdrop-%s-%d.png" % [name, _width]))
	_expect(error == OK, "截圖應可儲存：" + name)
	return raw


func _settle() -> void:
	for i in 8:
		await get_tree().process_frame


func _mae(a: Image, b: Image) -> float:
	var total := 0.0
	var count := 0
	for y in range(24, a.get_height() - 24, 16):
		for x in range(24, a.get_width() - 24, 16):
			var ca := a.get_pixel(x, y)
			var cb := b.get_pixel(x, y)
			total += (absf(ca.r - cb.r) + absf(ca.g - cb.g) + absf(ca.b - cb.b)) / 3.0
			count += 1
	return total / maxi(1, count)


func _range(image: Image) -> Dictionary:
	var low := INF
	var high := -INF
	var above := 0
	var negative := 0
	var count := 0
	for y in range(8, image.get_height() - 8, 8):
		for x in range(8, image.get_width() - 8, 8):
			var color := image.get_pixel(x, y)
			low = minf(low, minf(color.r, minf(color.g, color.b)))
			high = maxf(high, maxf(color.r, maxf(color.g, color.b)))
			above += int(maxf(color.r, maxf(color.g, color.b)) > 1.2)
			negative += int(minf(color.r, minf(color.g, color.b)) < 0.0)
			count += 1
	return {"min": low, "max": high, "above_1_2": above, "negative": negative, "samples": count}


func _expect(condition: bool, issue: String) -> void:
	if not condition:
		_issues.append(issue)
		push_error("[SceneBackdropProbe] " + issue)
