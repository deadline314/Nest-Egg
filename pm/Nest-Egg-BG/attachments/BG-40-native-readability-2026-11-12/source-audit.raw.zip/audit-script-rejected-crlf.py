"""Read-only source reachability audit; preserve all C/D original bytes."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess,zipfile

root=Path('C:/Users/stanl/Github/Nest-Egg');native=Path('D:/NestEggVerification/native-ticket-batch-20261111');source=native/'work/bg40-all-high-v1/source'
folder=root/'pm/Nest-Egg-BG/attachments/BG-40-native-readability-2026-11-12'
compat=json.loads((folder/'source-compatibility.json').read_bytes())
head=subprocess.run(['git','rev-parse','HEAD'],cwd=root,capture_output=True,text=True,check=True).stdout.strip()
reasons={
'core/components/hurtbox.gd':('not invoked','Only adds triangle_contact(), called by visible melee collision. No enemy, attack, collision query or damage is initiated by this fixture; existing receive/shape code is unchanged.'),
'core/melee_art.gd':('not drawn','Extracts draw_transform()/texture_rect() and uses the same textured polygon algebra. MeleeHeld is hidden for the default pistol; the three LevelData legend resources contain no WeaponData pickup. No new draw call is introduced.'),
'data/scripts/terrain_material_data.gd':('active but byte-identical to published blob','Tested LF file is exactly the current published Git blob. Current C work file differs only by 39 CRLF line endings; all exports/defaults/normal_path/validate code is identical.'),
'game/cutscene/cutscene_actor.gd':('not invoked','Only adds hand_target_complete() getter. SceneTour marks all story scenes seen and uses auto_skip before constructing the level; no CutsceneActor performance is started.'),
'game/cutscene/cutscene_player.gd':('not invoked','Changes reach/move waiting, weak-reference actor lifetime checks and posture readiness. No reach/move/cutscene job executes in this held scene fixture.'),
'game/cutscene/cutscene_reach.gd':('not invoked','Tracks whether a requested hand pose was published and exposes complete(); only used for the absent cutscene reach path.'),
'game/enemies/janus_boss.gd':('not instantiated','Moves the same config defaults/cache into JanusConfig. Original native inventories contain zero Enemy instances in all three levels; none has a JANUS legend resource.'),
'game/melee/melee_module.gd':('called no-op after visual warmup; attack branches inactive','New after_visible_pose() checks false pending flags and phase NONE. Fixture only supplies aim_right, never melee/shoot; no start_attack, strike, recovery, visible contact or hit feedback executes. Existing idle pose_progress() remains -1.'),
'game/player/melee_held.gd':('hidden path only','New contact-sweep object is allocated, then its state is cleared in the not-shown early return. Default weapon is pistol, shows_melee_weapon() is false. New draw_transform/tip/contact capture calls occur only for a shown melee weapon.'),
'game/player/melee_set.gd':('new getter unused; validation only accepts optional field','Adds contact_span() and optional-field validation. No attack/weapon is selected or changed by the fixture. MeleeHeld never reaches contact capture while the pistol is active; existing resource values are not altered.'),
'game/player/player_visual.gd':('active warmup with no-op addition; then held disabled','Only adds player.melee.after_visible_pose() after all rig and held-weapon updates. With phase NONE and all pending flags false, this writes no rig/material/pose/lighting values. All existing rig and firearm drawing code is byte-identical after newline normalization.'),
'game/rig/npc_animator.gd':('animation may be active but changed getters are not','Only adds posture_active()/posture_ready() read-only getters, consumed by the cutscene move wait. No animation update, NPC data, posture blend or rendering method changes.'),
}
rows=[];payload={}
for old in compat['current_c_differences']:
    path=old['path'];a=(source/path).read_bytes();b=(root/path).read_bytes()
    assert hashlib.sha256(a).hexdigest()==old['tested_d_sha256']
    assert hashlib.sha256(b).hexdigest()==old['current_c_sha256']
    normalized=a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n')
    diff=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='tested-D/'+path,tofile='current-C/'+path)).encode()
    semantic=''.join(difflib.unified_diff(a.decode().splitlines(),b.decode().splitlines(),fromfile='tested-D/'+path,tofile='current-C/'+path,lineterm='\n')).encode()
    payload['tested-D/'+path]=a;payload['current-C/'+path]=b
    payload['exact-diff/'+path+'.diff']=diff;payload['content-diff/'+path+'.diff']=semantic
    status,reason=reasons[path]
    row=dict(**old,tested_bytes=len(a),current_bytes=len(b),tested_crlf=a.count(b'\r\n'),current_crlf=b.count(b'\r\n'),only_line_endings=normalized,active_path=status,rendering_assessment=reason,requires_native_retake=False)
    if path=='data/scripts/terrain_material_data.gd':
        blob=subprocess.run(['git','show',head+':'+path],cwd=root,capture_output=True,check=True).stdout
        assert blob==a and b.replace(b'\r\n',b'\n')==blob
        row.update(published_commit=head,published_sha256=hashlib.sha256(blob).hexdigest(),tested_exact_published_bytes=True)
        payload['published/'+path]=blob
    rows.append(row)

# Match concrete terrain material resources and their automatic normal paths.
materials=[]
for name in ['concrete','asphalt','facility_floor']:
    path='data/environment/materials/'+name+'.tres';a=(source/path).read_bytes();assert (root/path).read_bytes()==a
    assert (native/path).read_bytes()==a
    texture_rows=[]
    for field,path_value in re.findall(r'^(body|top|side) = "res://([^"]+)"',a.decode(),re.M):
        tex=Path(path_value)
        for candidate in [tex,tex.with_name(tex.stem+'_n'+tex.suffix)]:
            raw=(native/candidate).read_bytes();assert (root/candidate).read_bytes()==raw
            texture_rows.append(dict(field=field,path=candidate.as_posix(),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
    materials.append(dict(path=path,sha256=hashlib.sha256(a).hexdigest(),exact_tested_resource_matches_current=True,post_capture_body_top_side_and_normal_matches=texture_rows))
for path in ['game/level/terrain.gd','game/level/terrain_edges.gd','data/player/player_tuning.tres','data/weapons/pistol.tres']:
    a=(source/path).read_bytes() if (source/path).exists() else (native/path).read_bytes()
    assert a==(root/path).read_bytes()
    payload['active-same-source/'+path]=a

result=dict(scope='read-only exact source audit; original native reports/ZIPs unchanged; no C or D product writes',current_head=head,files=rows,terrain_materials=materials,conclusion='No rendering-relevant active change in the measured no-enemy/no-attack/no-cutscene fixture. TerrainMaterialData exactly equals published Git bytes; its apparent SHA mismatch was only C work-tree CRLF. No native retake is required for these twelve differences.',limitations='This is scoped reachability and source equivalence, not a claim that complete C/D runtimes are identical. Post-capture texture equality is explicitly separated from original capture receipts.')
payload['audit.json']=(json.dumps(result,indent=2)+'\n').encode()
payload['audit-script.py']=Path(__file__).read_bytes()
target=folder/'source-audit.raw.zip';assert not target.exists()
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,raw in sorted(payload.items()):z.writestr(name,raw)
index=dict(archive=target.name,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members={n:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for n,v in payload.items()})
with zipfile.ZipFile(target) as z:
    assert set(z.namelist())==set(payload)
    for name,row in index['members'].items():
        raw=z.read(name);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
(folder/'source-audit-index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
(folder/'source-audit.json').write_bytes(payload['audit.json'])
print(json.dumps(dict(files=len(rows),archive_bytes=target.stat().st_size,members=len(payload),conclusion=result['conclusion'])))
