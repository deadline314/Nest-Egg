from pathlib import Path
import hashlib,json,shutil
from PIL import Image
import numpy as np

root=Path('C:/Users/stanl/Github/Nest-Egg')
folder=root/'pm/Nest-Egg-BG/attachments/BG-40-native-readability-2026-11-12'
folder.mkdir(exist_ok=True)
(folder/'.gitattributes').write_bytes(b'* -text\n')
source=Path('D:/NestEggVerification/native-ticket-batch-20261111/work/bg40-office-smoke-high-v1')
index=next((source/'ch3_office_hall').glob('*-index.json'))
shutil.copyfile(index,folder/'office-smoke-original-index.json')
data=json.loads(index.read_bytes());records=data['shots'][0]['bg40']['records']
rows=[];images=[]
for label,record in [('original-props',records[0]),('current-props',records[-1])]:
    original=index.parent/record['files']['png']
    target=root/'pm/Nest-Egg-BG/images'/('BG-40-native-office-smoke-'+label+'.png')
    shutil.copyfile(original,target)
    image=Image.open(target);images.append(image)
    body=record['player']['outer_screen_rect'];x,y,w,h=body
    crop=image.crop((x,y,x+w,y+h))
    output=target.with_name(target.stem+'-canonical-outer.png');crop.save(output)
    assert np.array_equal(np.asarray(crop),np.asarray(image)[y:y+h,x:x+w])
    rows.append(dict(label=label,original_file=str(original),source_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),image=target.relative_to(root).as_posix(),crop=output.relative_to(root).as_posix(),canonical_player=record['player'],raw=record['files']['raw'],raw_sha256=record['raw_sha256'],density=record['density'],canvas_transform_values=record['canvas_transform_values']))
pair=Image.new('RGB',(images[0].width*2,images[0].height));pair.paste(images[0],(0,0));pair.paste(images[1],(images[0].width,0))
path=root/'pm/Nest-Egg-BG/images/BG-40-native-office-smoke-pair.png';pair.save(path)
pixels=np.asarray(pair)
assert np.array_equal(pixels[:,:images[0].width],np.asarray(images[0])) and np.array_equal(pixels[:,images[0].width:],np.asarray(images[1]))
(folder/'office-smoke-original-boxes.json').write_bytes((json.dumps(dict(scope='unscaled original PNG copies and exact canonical outer crop; no retouch; original props left/current props right',observations=rows),indent=2)+'\n').encode())
print(path)
