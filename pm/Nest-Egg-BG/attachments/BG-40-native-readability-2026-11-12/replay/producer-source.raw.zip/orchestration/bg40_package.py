from pathlib import Path
import hashlib,json,shutil,zipfile

repo=Path('C:/Users/stanl/Github/Nest-Egg')
native=Path('D:/NestEggVerification/native-ticket-batch-20261111/work')
folder=repo/'pm/Nest-Egg-BG/attachments/BG-40-native-readability-2026-11-12'
external=Path('D:/NestEggDeliveries/BG40-20261112')
external.mkdir(exist_ok=True,parents=True)
(folder/'raw').mkdir(exist_ok=True)
(folder/'replay').mkdir(exist_ok=True)
(folder/'.gitignore').write_bytes(b'/raw/*.raw.zip\n/replay/__pycache__/\n')
for name in ['verify_bg40_native.py','verify_bg49_held.py','bg40_reader_negative.py']:
    shutil.copyfile(repo/'work'/name,folder/'replay'/name)
shutil.copyfile(repo/'pm/Nest-Egg-BG/attachments/BG-56-street-contrast-2026-11-12/replay/verify_bg56_street_package.py',folder/'replay/verify_package.py')
for name in ['bg40-high-independent.json','bg40-low-independent.json','bg40-smoke-office-independent.json','bg40-negative-box.log','bg40-negative-owner.log']:
    shutil.copyfile(repo/'work'/name,folder/name)

sources=folder/'replay/producer-source.raw.zip'
assert not sources.exists()
with zipfile.ZipFile(sources,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in sorted((native/'bg40-producer').rglob('*')):
        if path.is_file(): archive.write(path,'producer/'+path.relative_to(native/'bg40-producer').as_posix())
    for name in ['bg40_run.py','bg40_select_smoke.py','bg40_select_smoke_rejected_channels.py','bg40_select_smoke_rejected_float_slice.py','bg40_package.py']:
        archive.write(repo/'work'/name,'orchestration/'+name)

def digest(path):
    sha=hashlib.sha256()
    with path.open('rb') as stream:
        while block:=stream.read(1024*1024):sha.update(block)
    return sha.hexdigest()
cases=[]
for name in ['bg40-cpu-validate-v1','bg40-pawn-smoke-high-v1','bg40-office-smoke-high-v1','bg40-all-high-v1','bg40-all-low-v1']:
    source=native/name;members=[];archives=[];archive=None;size=0;part=0
    def close():
        if archive is not None:archive.close()
        if part:
            path=external/filename
            assert path.stat().st_size<95_000_000
            archives.append(dict(file=filename,bytes=path.stat().st_size,sha256=digest(path)))
    for path in sorted(source.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:continue
        length=path.stat().st_size
        if archive is None or size+length>85_000_000:
            close();part+=1;size=0;filename=name+f'-{part:02d}.raw.zip'
            target=external/filename;assert not target.exists()
            archive=zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)
        member=name+'/'+path.relative_to(source).as_posix()
        archive.write(path,member)
        members.append(dict(member=member,archive=filename,bytes=length,sha256=digest(path)))
        size+=length
    close()
    manifest=dict(name=name,role='formal' if name.startswith('bg40-all-') else 'control',original_bytes_preserved=True,members=members)
    index=folder/'raw'/(name+'.members.json')
    index.write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
    shutil.copyfile(index,external/index.name)
    cases.append(dict(name=name,index=index.relative_to(folder).as_posix(),index_sha256=digest(index),members=len(members),archives=archives))
    print(name,len(members),len(archives),flush=True)
index=dict(maximum_zip_bytes=95_000_000,cases=cases,scope='original native evidence retained externally; no raw member rewritten')
(folder/'raw-index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
shutil.copyfile(folder/'raw-index.json',external/'raw-index.json')
print(json.dumps(dict(cases=len(cases),archives=sum(len(c['archives']) for c in cases),compressed_bytes=sum(a['bytes'] for c in cases for a in c['archives']),raw_root=str(external))))
