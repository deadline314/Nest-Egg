from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time

repo = Path('C:/Users/stanl/Github/Nest-Egg')
root = Path('D:/NestEggVerification/native-ticket-batch-20261111')
producer = root / 'work/bg40-producer'
(producer / '.gdignore').touch()
delta = {}
for level in ['ch2_pawnshop', 'ch2_lounge_front', 'ch3_office_hall']:
    versions = []
    for commit, label in [('3e9ddccd6^', 'before'), ('3e9ddccd6', 'after')]:
        name = 'data/levels/' + level + '_map.json'
        value = subprocess.run(['git', 'show', commit + ':' + name], cwd=repo, capture_output=True, check=True).stdout
        target = producer / 'reference' / label / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(value)
        versions.append(json.loads(value))
    old, new = versions
    assert {k:v for k,v in old.items() if k!='props'} == {k:v for k,v in new.items() if k!='props'}
    delta[level] = dict(added=[p for p in new['props'] if p not in old['props']], removed=[p for p in old['props'] if p not in new['props']], commit='3e9ddccd6', reference='same current geometry with only original BG40 prop delta; later unrelated props retained')
(producer / 'prop-delta.json').write_bytes((json.dumps(delta, indent=2) + '\n').encode())

tag, quality = sys.argv[1:3]
assert re.fullmatch(r'[A-Za-z0-9_-]+', tag) and quality in {'high','low','cpu'}
out = root / 'work' / ('bg40-' + tag)
out.mkdir(exist_ok=False)
(out / '.gdignore').touch()
paths = {'project.godot', 'tools/bg55_enemy_readability_probe.gd', 'tools/readability_phase_probe.gd', 'tools/scene_tour.gd', 'tools/held_lighting_state.gd', 'tools/viewport_capture.gd', 'tools/contrast_probe.gd'}
for directory in ['game','core','autoload','data/scripts','data/lighting','data/environment','data/levels']:
    paths.update(p.relative_to(root).as_posix() for p in (root/directory).rglob('*') if p.is_file() and p.suffix in {'.gd','.gdshader','.tres','.json'})
paths.update(p.relative_to(root).as_posix() for p in producer.rglob('*') if p.is_file())
def hashes(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(paths)}
before = hashes()
for path in paths:
    target = out / 'source' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((root/path).read_bytes())
(out/'source-before.json').write_bytes((json.dumps(before,indent=2)+'\n').encode())
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
engine = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root)]
if quality == 'cpu': engine += ['--headless']
else: engine += ['--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan']
engine += ['res://work/bg40-producer/probe.tscn','--']
if quality == 'cpu': engine += ['--validate-only']
else: engine += ['--out='+str(out),'--quality='+quality,'--player','--fixed-aim','--lamps=full','--brightness=0.5','--tag='+tag,*sys.argv[3:]]
command = [sys.executable,str(root/'tools/comfyui/gpu_lock.py'),'--',*engine]
(out/'command.json').write_bytes((json.dumps(command,indent=2)+'\n').encode())
env = dict(os.environ, PYTHONIOENCODING='utf-8', APPDATA=str(root/'work'/('bg40-user-'+tag)))
start=time.monotonic()
with (out/'run.log').open('wb') as log:
    process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    try: code=process.wait(timeout=500)
    except subprocess.TimeoutExpired:
        subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
        code=124
after=hashes()
log=(out/'run.log').read_bytes()
bad=[line for line in log.decode('utf8',errors='replace').splitlines() if re.search('ERROR:|SCRIPT ERROR|WARNING:|ObjectDB instances were leaked',line)]
reports=list(out.glob('*/*-index.json'))
receipt=dict(exit=code,wall_seconds=time.monotonic()-start,sources_unchanged=before==after,source_after=after,diagnostics=bad,report_count=len(reports),strict_clean=code==0 and not bad and before==after,scope='native held-scene/data control only; no performance claim')
(out/'exit.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in receipt.items() if k!='source_after'}),flush=True)
print(log.decode('utf8',errors='replace')[-3500:],flush=True)
sys.exit(0 if receipt['strict_clean'] else 1)
