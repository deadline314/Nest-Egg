extends Node2D
## BG57 owned gallery diagnostic. No gameplay results or historical checkout claim.
const Capture := preload("res://tools/viewport_capture.gd")
var _out := ""
var _world := Node2D.new()
var _stage: StageLibrary.Stage
var _stage_layer := CutscenePlayer.new()
var _world_light: PointLight2D
var _table: StageLayers._Sprite
var _bodies: Array[CanvasItem] = []
var _records: Array[Dictionary] = []
var _frames: Array[Dictionary] = []

class MissingHealth:
	extends HealthPickup
	func _draw_world_sprite(_key: String) -> bool:
		return false

func _ready() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=").replace("\\", "/")
	_run.call_deferred()

func _run() -> void:
	if "--parse-only" in OS.get_cmdline_user_args():
		await _finish(0)
		return
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		await _finish(2)
		return
	DirAccess.make_dir_recursive_absolute(_out)
	# Own fixture window only; never mutate the saved Settings display preference.
	var window := get_window()
	window.mode = Window.MODE_WINDOWED
	window.size = Vector2i(1280, 720)
	DisplayMode.ensure_scaling(window)
	await _settle(3)
	add_child(LightKit.create_environment())
	add_child(_world)
	var ambient := CanvasModulate.new()
	ambient.color = Color(0.2, 0.2, 0.2)
	_world.add_child(ambient)
	_world_light = LightKit.create_point_light(Color(1.0, 0.82, 0.62), 650, 0.35, false, false)
	_world.add_child(_world_light)
	_world_light.position = Vector2(100, 25)
	var original_quality := Settings.get_light_quality()
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	_build_world()
	_stage_layer._overlay_mode = true
	add_child(_stage_layer)
	_stage_layer._build_ui()
	_stage = StageLibrary.Stage.new()
	_stage.configure_lighting({"ambient": "#555555", "lights": [{"pos": [100, 190], "radius": 650, "energy": 0.35, "color": "#ffd29e"}]})
	_stage_layer._stage_holder.add_child(_stage)
	_build_stage()
	_stage_layer._dialogue.set_process(false)
	_stage_layer._dialogue.show_line(Story.speaker("rin"), "材質對照：介面保持清楚，場景物件依照光源受色。")
	_stage_layer._dialogue.complete()
	while _stage_layer._dialogue._slide_tween != null and _stage_layer._dialogue._slide_tween.is_valid() and _stage_layer._dialogue._slide_tween.is_running():
		await _settle(1)
	await _settle(4)
	# Same source and frozen draw state; one direction parameter owns one local light per canvas.
	for key: String in ["A1", "A2", "B", "A3"]:
		var x := 540.0 if key == "B" else 100.0
		_world_light.position.x = x
		_stage._local_lights[0].position.x = x
		await _settle(3)
		if not _capture(key):
			await _finish(1)
			return
	# Controlled legacy material negative, not a historical checkout: all physical
	# bodies use the old unshaded route together; emission stays frozen.
	var materials: Array[Material] = []
	for body: CanvasItem in _bodies:
		materials.append(body.material)
		body.material = LightKit.emissive_material()
	for key: String in ["old-A", "old-B"]:
		var x := 100.0 if key == "old-A" else 540.0
		_world_light.position.x = x
		_stage._local_lights[0].position.x = x
		await _settle(3)
		if not _capture(key):
			await _finish(1)
			return
	for i in _bodies.size():
		_bodies[i].material = materials[i]
	_world_light.position.x = 100.0
	_stage._local_lights[0].position.x = 100.0
	var text := _stage_layer._dialogue._text
	var ui_material := text.material
	text.material = null  # Explicit old UI route under the SAME dark stage canvas.
	await _settle(3)
	if not _capture("ui-old"):
		await _finish(1)
		return
	text.material = ui_material
	_stage._ambient.color = Color.WHITE
	_stage._local_lights[0].enabled = false
	for key: String in ["ui-white-new", "ui-white-old"]:
		text.material = ui_material if key == "ui-white-new" else null
		await _settle(3)
		if not _capture(key):
			await _finish(1)
			return
	text.material = ui_material
	# All original raw frames already persisted before PNG encoding begins.
	for row: Dictionary in _frames:
		var bytes := FileAccess.get_file_as_bytes(_out.path_join(row["raw"]))
		var image := Image.create_from_data(row["width"], row["height"], row["mipmaps"], row["format"], bytes)
		if Capture.encode(image, row["hdr2d"]).save_png(_out.path_join(row["png"])) != OK:
			await _finish(1)
			return
	Settings.set_light_quality(original_quality)
	await _finish(0)

func _build_world() -> void:
	for i in 2:
		var pickup: Pickup = HealthPickup.new() if i == 0 else MissingHealth.new()
		_world.add_child(pickup)
		pickup.position = Vector2(80 + i * 90, 115)
		pickup.set_process(false)
		pickup._time = 0.0
		pickup._glint_offset = 0.08
		pickup.monitoring = false
		_bodies.append(pickup)
		_record(pickup, "pickup" if i == 0 else "missing-pickup", Rect2(-12, -24, 24, 24) if i == 0 else Rect2(-5, -13, 10, 10))
	for i in 2:
		var prop := Throwable.new()
		prop.configure(load("res://data/throwables/pipe.tres" if i == 0 else "res://data/throwables/crate_small.tres") as ThrowableData)
		var previous: Variant = FixtureArt._cache.get(&"breakable_crate")
		var existed := FixtureArt._cache.has(&"breakable_crate")
		if i == 1:
			FixtureArt._cache[&"breakable_crate"] = null
		_world.add_child(prop)
		if i == 1:
			if existed:
				FixtureArt._cache[&"breakable_crate"] = previous
			else:
				FixtureArt._cache.erase(&"breakable_crate")
		prop.position = Vector2(270 + i * 90, 115)
		prop.set_physics_process(false)
		_bodies.append(prop)
		_record(prop, "pipe" if i == 0 else "missing-crate", Rect2(-prop.data.size.x * 0.5, -prop.data.size.y, prop.data.size.x, prop.data.size.y))
	var vehicle := Vehicle.new()
	vehicle.configure(load("res://data/vehicles/bulwark.tres") as VehicleData)
	_world.add_child(vehicle)
	vehicle.position = Vector2(490, 125)
	vehicle.set_physics_process(false)
	_bodies.append(vehicle)
	_record(vehicle, "legacy-vehicle", Rect2(-vehicle.data.body_size.x * 0.5, -vehicle.data.body_size.y, vehicle.data.body_size.x, vehicle.data.body_size.y))
	var chunk := Throwable.new()
	chunk.configure(load("res://data/throwables/concrete_chunk.tres") as ThrowableData)
	_world.add_child(chunk)
	chunk.position = Vector2(560, 115)
	chunk.set_physics_process(false)
	_bodies.append(chunk)
	_record(chunk, "concrete-chunk", Rect2(-chunk.data.size.x * 0.5, -chunk.data.size.y, chunk.data.size.x, chunk.data.size.y))
	# Independent prompts are intentionally hidden only in this static material gallery.
	for node: Node in _world.find_children("*", "WorldPrompt", true, false):
		(node as CanvasItem).hide()
		node.set_process(false)

func _build_stage() -> void:
	for stage_id: String in ["ch1_pawnshop_kitchen", "ch1_dawn_noodle_stall"]:
		for layer: Dictionary in StageLibrary.definition(StringName(stage_id))["layers"]:
			if layer.get("id") not in ["kettle", "noodle_table"]:
				continue
			var prop := StageLayers.create(layer, "BG57 original atlas descriptor") as StageLayers._Sprite
			_stage.add_layer(prop)
			prop.position = Vector2(240, 220) if layer["id"] == "kettle" else Vector2(400, 160)
			if layer["id"] == "noodle_table":
				_table = prop
			_bodies.append(prop)
			_record(prop, stage_id + "/" + layer["id"], prop.get_rect())

	var baked := StageLayers.create({"kind": "sprite", "path": "res://art/environment/scenes/pawnshop_kitchen_contacts.png", "source_width": 1672, "scale": 0.08, "pos": [20, 150], "glow": false}, "BG57 baked control") as Sprite2D
	_stage.add_layer(baked)
	_record(baked, "baked-control", baked.get_rect())

func _matrix(value: Transform2D) -> Array:
	return [value.x.x, value.x.y, value.y.x, value.y.y, value.origin.x, value.origin.y]


func _record(item: CanvasItem, id: String, local_rect: Rect2) -> void:
	var projection := item.get_viewport_transform() * item.get_global_transform()
	var physical := Rect2(projection * local_rect.position, Vector2.ZERO)
	for corner: Vector2 in [Vector2(local_rect.end.x, local_rect.position.y), local_rect.end, Vector2(local_rect.position.x, local_rect.end.y)]:
		physical = physical.expand(projection * corner)
	var texture: Texture2D = (item as Sprite2D).texture if item is Sprite2D else null
	var canvas := texture as CanvasTexture
	var emission := item.get_node_or_null("Emission") as CanvasItem
	_records.append({"id": id, "path": str(item.get_path()), "material_id": item.material.get_instance_id() if item.material != null else 0,
		"material_class": item.material.get_class() if item.material != null else "ordinary canvas", "light_mask": item.light_mask,
		"final_matrix": _matrix(get_viewport().get_final_transform()), "canvas_matrix": _matrix(item.get_canvas_transform()),
		"viewport_matrix": _matrix(item.get_viewport_transform()), "global_matrix": _matrix(item.get_global_transform()), "projection_matrix": _matrix(projection),
		"local_rect": [local_rect.position.x, local_rect.position.y, local_rect.size.x, local_rect.size.y],
		"canvas_layer": item.get_canvas_layer_node().layer if item.get_canvas_layer_node() != null else 0,
		"local_transform": var_to_str((item as Node2D).transform), "viewport_transform": var_to_str(item.get_viewport_transform()),
		"global_transform": var_to_str(item.get_global_transform()), "roi": [floori(physical.position.x), floori(physical.position.y), ceili(physical.end.x) - floori(physical.position.x), ceili(physical.end.y) - floori(physical.position.y)],
		"texture_class": texture.get_class() if texture != null else "procedural draw", "texture_size": [texture.get_width(), texture.get_height()] if texture != null else [],
		"normal_path": canvas.normal_texture.resource_path if canvas != null and canvas.normal_texture != null else "",
		"separate_emission_material": emission.material.get_instance_id() if emission != null and emission.material != null else null})

func _capture(key: String) -> bool:
	var viewport := get_viewport()
	var image := viewport.get_texture().get_image()
	if image == null or image.is_empty():
		return false
	var filename := key + ".raw"
	var bytes := image.get_data()
	var writer := FileAccess.open(_out.path_join(filename), FileAccess.WRITE)
	if writer == null:
		return false
	writer.store_buffer(bytes)
	writer.close()
	if FileAccess.get_file_as_bytes(_out.path_join(filename)) != bytes:
		return false
	var body_materials: Array[Dictionary] = []
	for body: CanvasItem in _bodies:
		var mode := (body.material as CanvasItemMaterial).light_mode if body.material is CanvasItemMaterial else -1
		body_materials.append({"path": str(body.get_path()), "material_id": body.material.get_instance_id() if body.material != null else 0, "light_mode": mode})
	var text := _stage_layer._dialogue._text
	var ui_projection := text.get_viewport_transform() * text.get_global_transform()
	var ui_rect := Rect2(ui_projection * Vector2.ZERO, Vector2.ZERO)
	for corner: Vector2 in [Vector2(text.size.x, 0), text.size, Vector2(0, text.size.y)]:
		ui_rect = ui_rect.expand(ui_projection * corner)
	var ui_mode := (text.material as CanvasItemMaterial).light_mode if text.material is CanvasItemMaterial else -1
	_frames.append({"window_mode": get_window().mode, "window_size": [get_window().size.x, get_window().size.y],
		"visible_rect": [viewport.get_visible_rect().position.x, viewport.get_visible_rect().position.y, viewport.get_visible_rect().size.x, viewport.get_visible_rect().size.y],
		"final_matrix": _matrix(viewport.get_final_transform()), "gameplay_canvas_matrix": _matrix(viewport.get_canvas_transform()), "UI_viewport_matrix": _matrix(text.get_viewport_transform()),
		"ui_text_mode": ui_mode, "ui_rect": [floori(ui_rect.position.x), floori(ui_rect.position.y), ceili(ui_rect.end.x) - floori(ui_rect.position.x), ceili(ui_rect.end.y) - floori(ui_rect.position.y)],
		"ui_text": text.text, "ui_complete": _stage_layer._dialogue.is_complete(), "ui_frame_alpha": _stage_layer._dialogue._frame.modulate.a,
		"stage_ambient": [_stage._ambient.color.r, _stage._ambient.color.g, _stage._ambient.color.b, _stage._ambient.color.a], "stage_light_enabled": _stage._local_lights[0].enabled, "body_materials": body_materials, "key": key, "raw": filename, "png": key + ".png", "width": image.get_width(), "height": image.get_height(),
		"draw_frame": Engine.get_frames_drawn(), "process_frame": Engine.get_process_frames(), "ticks_usec_metadata_only": Time.get_ticks_usec(),
		"readback_supported": image.get_format() in [10, 11, 14, 15] and viewport.use_hdr_2d and not image.has_mipmaps() and image.get_size() == Vector2i(1280, 720) and get_window().mode == Window.MODE_WINDOWED and get_window().size == Vector2i(1280, 720),
		"format": image.get_format(), "mipmaps": image.has_mipmaps(), "hdr2d": viewport.use_hdr_2d, "bytes": bytes.size(),
		"world_light": var_to_str(_world_light.position), "stage_light": var_to_str(_stage._local_lights[0].position)})
	var metadata := FileAccess.open(_out.path_join("capture.json"), FileAccess.WRITE)
	if metadata == null:
		return false
	metadata.store_string(JSON.stringify({"frames": _frames, "objects": _records, "renderer": RenderingServer.get_current_rendering_method(),
		"adapter": RenderingServer.get_video_adapter_name(), "display": DisplayServer.get_name(), "quality": Settings.get_light_quality(),
		"scope": "factory HIGH factory AABA + controlled old-unshaded negative + SAME-canvas UI dark/white controls only; no complete gameplay/stage/LOW acceptance",
		"world_light_range": [_world_light.range_layer_min, _world_light.range_layer_max], "stage_light_range": [_stage._local_lights[0].range_layer_min, _stage._local_lights[0].range_layer_max], "canvas_layer": _stage_layer.layer}, "\t"))
	metadata.close()
	return image.get_format() in [10, 11, 14, 15] and viewport.use_hdr_2d and not image.has_mipmaps() and image.get_size() == Vector2i(1280, 720) and get_window().mode == Window.MODE_WINDOWED and get_window().size == Vector2i(1280, 720)

func _settle(count: int) -> void:
	for i in count:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw

func _finish(code: int) -> void:
	AudioRelease.begin_shutdown()
	_world.free()
	_stage_layer.free()
	await AudioRelease.settle(get_tree())
	get_tree().quit(code)
