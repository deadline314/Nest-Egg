"""Read-only HIGH factory AABA diagnostic. CPU controls never imply native acceptance."""
from pathlib import Path
import argparse
import json
import numpy as np
from PIL import Image

FORMATS = {14: ("<f2", 3), 15: ("<f2", 4), 10: ("<f4", 3), 11: ("<f4", 4)}
KEYS = ["A1", "A2", "B", "A3", "old-A", "old-B"]

def decode(data, row):
    assert row["hdr2d"] is True and row["mipmaps"] is False, "HDR/ordinary readback required"
    dtype, channels = FORMATS[row["format"]]
    expected = row["width"] * row["height"] * channels * np.dtype(dtype).itemsize
    assert len(data) == row["bytes"] == expected, "exact raw byte count"
    pixels = np.frombuffer(data, dtype=dtype).reshape(row["height"], row["width"], channels).astype(np.float64)
    assert np.isfinite(pixels).all(), "finite original HDR required"
    return pixels

def png_reference(pixels):
    rgb = pixels[..., :3]
    shown = np.where(rgb <= 0.0031308, rgb * 12.92, 1.055 * np.maximum(rgb, 0) ** (1 / 2.4) - 0.055)
    alpha = np.clip(pixels[..., 3], 0, 1) if pixels.shape[2] == 4 else np.ones(rgb.shape[:2])
    return np.dstack((np.clip(shown, 0, 1), alpha))

def verify(directory):
    metadata = json.loads((directory / "capture.json").read_text())
    assert metadata["renderer"] == "forward_plus" and metadata["display"] != "headless", "native Forward+ required"
    assert "9070" in metadata["adapter"], "actual expected adapter witness required"
    assert metadata["quality"] == 2, "first gallery is HIGH only"
    assert metadata["world_light_range"] == [0, 0], "no widened world light layer"
    assert metadata["stage_light_range"] == [metadata["canvas_layer"]] * 2 and metadata["canvas_layer"] == 58, "actual independent stage canvas range"
    frames = metadata["frames"]
    assert [f["key"] for f in frames] == KEYS, "complete original six-frame order"
    arrays, originals, encoded = {}, {}, []
    for row in frames:
        assert [row["width"], row["height"]] == [1280, 720], "actual native size"
        raw = (directory / row["raw"]).read_bytes()
        pixels = decode(raw, row)
        image = Image.open(directory / row["png"])
        assert image.format == "PNG", "actual PNG format"
        shown = np.asarray(image.convert("RGBA"), dtype=np.float64) / 255
        assert shown.shape[:2] == pixels.shape[:2], "PNG native dimensions"
        error = float(np.max(np.abs(shown - png_reference(pixels))))
        assert error <= 1 / 255 + 0.00001, (row["key"], "canonical gamma before quantization", error)
        originals[row["key"]] = raw
        arrays[row["key"]] = pixels[..., :3]
        encoded.append({"key": row["key"], "max_png_error": error})
        assert len(row["body_materials"]) == 8, "all eight real physical factories"
        if row["key"].startswith("old-"):
            assert all(x["light_mode"] == 1 for x in row["body_materials"]), "legacy unshaded material control actually applied"
        else:
            assert all(x["material_id"] == 0 for x in row["body_materials"]), "ordinary reflective material actually applied"
    assert originals["A1"] == originals["A2"] == originals["A3"], "original and restored raw must match without relaxing ULP"
    assert originals["old-A"] == originals["old-B"], "legacy all-unshaded light-direction negative must remain constant"
    results = []
    objects = metadata["objects"]
    assert len(objects) == 9 and len({x["id"] for x in objects}) == 9, "all physical and baked controls recorded"
    for item in objects:
        x, y, width, height = item["roi"]
        assert all(isinstance(v, int) for v in item["roi"]), "integer physical ROI"
        assert width > 0 and height > 0 and x >= 0 and y >= 0 and x + width <= 1280 and y + height <= 720, "complete physical ROI inside native frame"
        a = arrays["A1"][y:y + height, x:x + width]
        b = arrays["B"][y:y + height, x:x + width]
        changed = int(np.count_nonzero(np.any(a != b, axis=2)))
        if item["id"] == "baked-control":
            assert changed == 0, "complete baked source must not be relit"
        else:
            assert changed > 0, (item["id"], "actual light response absent")
        if item["id"].startswith("ch1_"):
            assert item["texture_class"] == "CanvasTexture" and item["normal_path"].endswith("_n.png"), "HIGH physical stage retains its real normal"
        results.append({"id": item["id"], "roi": item["roi"], "changed_pixels": changed})
    return {"scope": "HIGH factory light-direction response only, not visual approval or complete ticket", "exact_raw_AABA": True, "legacy_negative_constant": True, "objects": results, "png": encoded}

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    print(json.dumps(verify(parser.parse_args().directory), indent=2))
