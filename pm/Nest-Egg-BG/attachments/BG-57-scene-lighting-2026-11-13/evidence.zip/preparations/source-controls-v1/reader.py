"""CPU source boundary controls; not runtime tests or rendering acceptance."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
FILES = {
    "game/pickups/pickup.gd": {"_ready", "_draw_world_sprite", "_draw", "_draw_glint"},
    **{f"game/pickups/{name}_pickup.gd": {"_draw_icon", "_draw_melee_icon"}
       for name in ["credit", "health", "weapon", "collectible", "consumable"]},
    "game/props/throwable.gd": {"_ready", "_draw"},
    "game/vehicles/vehicle.gd": {"_ready", "_draw"},
}

def functions(text):
    # Only top-level functions; nested draw classes are an explicitly new visual layer.
    text = text.replace("\r\n", "\n").split("\nclass _Emission:")[0]
    matches = list(re.finditer(r"^func (\w+)\([^\n]*", text, re.M))
    return {m.group(1): text[m.start(): matches[i + 1].start() if i + 1 < len(matches) else len(text)].rstrip()
            for i, m in enumerate(matches)}

def same_gameplay(before, after, allowed):
    problems = []
    old, new = functions(before), functions(after)
    for name in old:
        if name in allowed:
            continue
        value = new.get(name, "")
        # These are the only additions inside original update/damage functions.
        value = value.replace("\n\tif _emission != null:\n\t\t_emission.queue_redraw()", "")
        value = value.replace("\n\t_emission.queue_redraw()", "")
        if value != old[name]:
            problems.append(name)
    return problems, len(old.keys() - allowed)

if __name__ == "__main__":
    rows = []
    negatives = []
    for name, allowed in FILES.items():
        original = subprocess.run(["git", "show", "HEAD:" + name], cwd=ROOT,
                                  capture_output=True, check=True).stdout.decode("utf-8")
        actual = (ROOT / name).read_text(encoding="utf-8")
        problems, count = same_gameplay(original, actual, allowed)
        rows.append({"path": name, "unchanged_function_count": count, "unexpected": problems,
                     "candidate_sha256": hashlib.sha256((ROOT / name).read_bytes()).hexdigest()})
        if "func can_pick_up()" in actual:
            mutated = actual.replace("return state == State.REST", "return state != State.REST", 1)
            negatives.append({"name": "mutated pickup predicate", "rejected": "can_pick_up" in same_gameplay(original, mutated, allowed)[0]})
        if "func can_mount()" in actual:
            mutated = actual.replace("return not destroyed and driver == null", "return destroyed and driver == null", 1)
            negatives.append({"name": "mutated mount predicate", "rejected": "can_mount" in same_gameplay(original, mutated, allowed)[0]})
    report = {"kind": "CPU source-only boundary", "files": rows, "negative_controls": negatives,
              "pass": all(not row["unexpected"] for row in rows) and all(n["rejected"] for n in negatives)}
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["pass"] else 1)
