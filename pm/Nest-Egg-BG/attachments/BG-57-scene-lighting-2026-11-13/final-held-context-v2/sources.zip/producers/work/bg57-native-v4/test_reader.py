"""Synthetic 6x4 raw/PNG transfer controls only. No native observation."""
from pathlib import Path
import json
import numpy as np
from read_fixture import decode, png_reference, projection_control

checks = []
for fmt, dtype, channels in [(14, "<f2", 3), (15, "<f2", 4), (10, "<f4", 3), (11, "<f4", 4)]:
    raw = np.zeros((4, 6, channels), dtype=dtype)
    raw[..., :3] = np.linspace(0, 0.9, 24).reshape(4, 6, 1)
    if channels == 4:
        raw[..., 3] = 0.37
    row = {"format": fmt, "hdr2d": True, "mipmaps": False, "width": 6, "height": 4, "bytes": raw.nbytes}
    decoded = decode(raw.tobytes(), row)
    assert np.array_equal(decoded, raw.astype(np.float64))
    reference = png_reference(decoded)
    assert reference.shape == (4, 6, 4) and np.isfinite(reference).all()
    assert np.all(reference[..., 3] == (float(raw[0, 0, 3]) if channels == 4 else 1.0))
    checks.append({"control": f"format{fmt} true raw + alpha + transfer", "passed": True})
    for key, value in [("hdr2d", False), ("mipmaps", True), ("bytes", raw.nbytes - 1), ("format", 5)]:
        try:
            decode(raw.tobytes(), row | {key: value})
        except (AssertionError, KeyError):
            checks.append({"control": f"format{fmt} rejects {key}", "passed": True})
        else:
            raise AssertionError((fmt, key))
    bad = raw.copy()
    bad[1, 1, 0] = np.nan
    try:
        decode(bad.tobytes(), row)
    except AssertionError:
        checks.append({"control": f"format{fmt} rejects original NaN", "passed": True})
    else:
        raise AssertionError("NaN accepted")
item = {"final_matrix": [2,0,0,2,0,0], "canvas_matrix": [1,0,0,1,7,9], "viewport_matrix": [2,0,0,2,14,18], "global_matrix": [1,0,0,1,3,4], "projection_matrix": [2,0,0,2,20,26], "local_rect": [-2,-3,4,6], "roi": [16,20,8,12]}
projection_control(item)
checks.append({"control": "nonidentity independent stage canvas actual physical projection", "passed": True})
for key, value in [("canvas_matrix", [1,0,0,1,-100,-200]), ("projection_matrix", [2,0,0,2,6,8]), ("roi", [6,8,8,12])]:
    try:
        projection_control(item | {key: value})
    except AssertionError:
        checks.append({"control": "reject wrong projection " + key, "passed": True})
    else:
        raise AssertionError(key)
print(json.dumps({"scope": "CPU synthetic only; no engine, native or rendered material acceptance", "checks": checks, "count": len(checks)}, indent=2))
