extends "res://work/bg57-native-v4/capture.gd"
## Controlled real Stage/Actor/hold lighting, not a natural story route.
var _actor: CutsceneActor
var _kettle: StageLayers._Sprite
var _point := Vector2(350, 200) # Published kitchen_staging.KETTLE_GRIP.
var _quality_before := -1
var _original_material: Material
var _original_tint := Color.WHITE

func _run() -> void:
	if "--parse-only" in OS.get_cmdline_user_args():
		await _finish(0)
		return
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		await _finish(2)
		return
	DirAccess.make_dir_recursive_absolute(_out)
	get_window().mode = Window.MODE_WINDOWED
	get_window().size = Vector2i(1280, 720)
	DisplayMode.ensure_scaling(get_window())
	await _settle(3)
	add_child(LightKit.create_environment())
	add_child(_world)
	_world_light = LightKit.create_point_light(Color.WHITE, 650, 0.35, false, false)
	_world_light.enabled = false
	_world.add_child(_world_light)
	_quality_before = Settings.get_light_quality()
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	_stage_layer._overlay_mode = true
	add_child(_stage_layer)
	_stage_layer._build_ui()
	_stage = StageLibrary.Stage.new()
	_stage.configure_lighting({"ambient": "#555555", "lights": [{"pos": [100, 150], "radius": 650, "energy": 0.35, "color": "#ffd29e"}]})
	_stage_layer._stage_holder.add_child(_stage)
	_actor = CutsceneActor.new()
	_stage.actors.add_child(_actor)
	_actor.setup(&"fixture", "rin", "", 3.9, "")
	_actor.position = Vector2(320, 248)
	_actor.layer_slot = 1
	_actor.z_index = WorldLayers.stage_actor_z(1)
	_actor.face(1)
	_actor.set_process(false)
	for i in 120:
		_actor._process(1.0 / 60.0)
	for layer: Dictionary in StageLibrary.definition(&"ch1_pawnshop_kitchen")["layers"]:
		if layer.get("id") == "kettle":
			_kettle = StageLayers.create(layer, "BG57 original kitchen kettle") as StageLayers._Sprite
			_stage.add_layer(_kettle)
	if _actor.rig == null or _kettle == null:
		await _fail("live Rin rig and published physical kettle required")
		return
	_original_material = _kettle.material
	_original_tint = _kettle.self_modulate
	var palm := _stage.to_local(_actor.hand_contact_global(&"front"))
	_kettle.position = palm - _kettle.transform.basis_xform(_kettle.source_point(_point))
	var command := {"hand": "front", "space": "prop", "prop": "kettle", "to": [_point.x, _point.y], "contact": [73, 40], "angle": PI * 0.5, "time": 0.1}
	if not _actor.set_hand_target(command, StagePropBinding.new(_kettle, _point)):
		await _fail("published calibrated hand contact refused")
		return
	_actor._process(0.1)
	var issue := _stage.hold_prop("kettle", _actor, &"front", _point)
	if not issue.is_empty():
		await _fail(issue)
		return
	_freeze(_actor)
	_bodies.append(_kettle)
	_record(_kettle, "held-kettle", _kettle.get_rect())
	_stage_layer._dialogue.set_process(false)
	_stage_layer._dialogue.show_line(Story.speaker("rin"), "同一舞台：角色與手中水壺共用受光，放下後還原道具材質。")
	_stage_layer._dialogue.complete()
	while _stage_layer._dialogue._slide_tween != null and _stage_layer._dialogue._slide_tween.is_valid() and _stage_layer._dialogue._slide_tween.is_running():
		await _settle(1)
	await _settle(4)
	for key: String in ["held-A1", "held-A2", "held-B", "held-A3"]:
		_stage._local_lights[0].position.x = 540.0 if key == "held-B" else 100.0
		await _settle(3)
		if not _capture(key):
			await _finish(1)
			return
	if not _stage.release_prop("kettle"):
		await _fail("real release refused")
		return
	for key: String in ["released-HIGH", "released-LOW", "released-restored-HIGH"]:
		Settings.set_light_quality(LightQuality.Tier.LOW if key == "released-LOW" else LightQuality.Tier.HIGH)
		await _settle(3)
		if not _capture(key):
			await _finish(1)
			return
	for row: Dictionary in _frames:
		var bytes := FileAccess.get_file_as_bytes(_out.path_join(row["raw"]))
		var image := Image.create_from_data(row["width"], row["height"], row["mipmaps"], row["format"], bytes)
		if Capture.encode(image, row["hdr2d"]).save_png(_out.path_join(row["png"])) != OK:
			await _finish(1)
			return
	await _finish(0)

func _freeze(node: Node) -> void:
	node.set_process(false)
	node.set_physics_process(false)
	for child: Node in node.get_children():
		_freeze(child)

func _capture(key: String) -> bool:
	if not super._capture(key):
		return false
	var row: Dictionary = _frames[-1]
	var parts: Array[Dictionary] = []
	for part: CanvasItem in _actor.rig._parts:
		if not part.is_visible_in_tree():
			continue
		parts.append({"path": str(part.get_path()), "material_id": part.material.get_instance_id() if part.material != null else 0, "global_matrix": _matrix(part.get_global_transform()), "viewport_matrix": _matrix(part.get_viewport_transform()), "process": part.is_processing(), "physics": part.is_physics_processing()})
	var bounds := _actor.rig.visual_bounds()
	var projection := _actor.rig.get_viewport_transform()
	var physical := Rect2(projection * bounds.position, Vector2.ZERO)
	for corner: Vector2 in [Vector2(bounds.end.x, bounds.position.y), bounds.end, Vector2(bounds.position.x, bounds.end.y)]:
		physical = physical.expand(projection * corner)
	var canvas := _kettle.texture as CanvasTexture
	row["stage_hold"] = {"held": _stage.prop_held("kettle"), "bound_same_material": _kettle.material == _actor.rig._light_material,
		"restored_original_material": _kettle.material == _original_material, "restored_original_tint": _kettle.self_modulate == _original_tint,
		"actor_material_id": _actor.rig._light_material.get_instance_id(), "prop_material_id": _kettle.material.get_instance_id() if _kettle.material != null else 0,
		"fill": _actor.rig._fill, "cap": _actor.rig._light_cap, "uses_world_context": _actor.rig.use_level_lighting,
		"actor_canvas_layer": _actor.get_canvas_layer_node().layer, "prop_canvas_layer": _kettle.get_canvas_layer_node().layer,
		"palm": var_to_str(_actor.hand_contact_global(&"front")), "contact_error_world": _actor.hand_contact_global(&"front").distance_to(_kettle.to_global(_kettle.source_point(_point))),
		"prop_global_matrix": _matrix(_kettle.global_transform), "prop_texture_id": _kettle.texture.get_instance_id(), "prop_normal_path": canvas.normal_texture.resource_path if canvas != null and canvas.normal_texture != null else "",
		"actor_bounds": [bounds.position.x, bounds.position.y, bounds.size.x, bounds.size.y], "actor_roi": [floori(physical.position.x), floori(physical.position.y), ceili(physical.end.x) - floori(physical.position.x), ceili(physical.end.y) - floori(physical.position.y)],
		"actor_process": _actor.is_processing(), "actor_physics": _actor.is_physics_processing(), "parts": parts, "quality": Settings.get_light_quality()}
	var metadata: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(_out.path_join("capture.json")))
	metadata["frames"] = _frames
	metadata["scope"] = "controlled real Rin/physical kettle same Stage canvas: binding/light response/release and cached normal LOW/HIGH; not natural choreography or exposure/performance acceptance"
	var file := FileAccess.open(_out.path_join("capture.json"), FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(metadata, "\t"))
	file.close()
	return true

func _fail(message: String) -> void:
	var file := FileAccess.open(_out.path_join("fixture-failure.txt"), FileAccess.WRITE)
	if file != null:
		file.store_string(message)
		file.close()
	print("BG57 HELD FIXTURE REFUSED: ", message)
	await _finish(1)

func _finish(code: int) -> void:
	if _quality_before >= 0:
		Settings.set_light_quality(_quality_before)
	await super._finish(code)
