# BG-57 scene lighting candidate

Isolated linked worktree, actual base `9caed2a557511634aca4b83805c3dacf6ac843ca`.
Primary C product, PM and index are untouched. No Godot invocation is authorized
until the coordinator receives the manifest and commands and assigns a window.

S1/S2/S3 separate ordinary reflective canvas drawing from existing unshaded
outline, glint, fuse, cockpit, muzzle and hit-flash drawing. No physics, reward,
carry, throwing, fire, ownership or collision path is replaced. Procedural
missing-art bodies remain lit; their separate glint/status layer remains readable.

S4 classifies scene-prop/world-prop sprites as physical by their existing library,
with an optional explicit `lighting` role for other libraries. Complete baked
backgrounds remain unshaded. Every finite texture state loads the corresponding
normal through LitTextures without changing source geometry or contact points.
Explicit stage `ambient` (existing documented field) and at most eight local
`lights` are supported, with bounded energy and the actual independent canvas
layer. Decorative glow never implicitly becomes a light. No existing stage
lighting values have been changed yet; representative data requires native A/B.
Character-local cap and held attachment integration awaits the sibling's narrow
CharacterRig appearance interface. It must not modify global LightKit values.

S5 Settings synchronizes normal quality on load and change. LightingController
does not restore HIGH normals on Level exit. The cache's explicit test injection
API remains unchanged.

The permanent EnvironmentSuite helper exercises real factories, cached/new
texture quality, storage reload, diffuse/normal state swaps, baked isolation and
independent-canvas light range. These are structural controls, not GPU proof.
Native single-light direction/occlusion and restoration A/A/A/B/A, physical/glow
separation, LOW/HIGH, real held prop states and neon/exposure still need rendering.
