from pathlib import Path
r=Path.cwd()
def edit(path, fn):
 p=r/path;s=p.read_text(encoding='utf-8');n=fn(s);assert n!=s,path;p.write_text(n,encoding='utf-8',newline='\n')
# Settings owns normals even when no Level exists; _load covers startup and use_storage.
edit('autoload/settings.gd',lambda s:s.replace('\t\t_config = ConfigFile.new()\n\n\n#', '\t\t_config = ConfigFile.new()\n\tLitTextures.set_enabled(LightQuality.normal_maps())\n\n\n#',1).replace('\tdisplay_changed.emit()\n\n\n## 是否減少閃光', '\tLitTextures.set_enabled(LightQuality.normal_maps())\n\tdisplay_changed.emit()\n\n\n## 是否減少閃光',1))
edit('game/level/lighting_controller.gd',lambda s:s.replace('\tLitTextures.set_enabled(true)\n',''))
# Pickup base is shaded; existing cached contour/glow and glint draw on their own canvas.
def pickup(s):
 s=s.replace('var _collection_finished := false','var _collection_finished := false\nvar _emission: _Emission\nvar _world_sprite: Dictionary = {}')
 s=s.replace('\tLightKit.mark_emissive(self)\n','')
 mark='\t\tadd_child(prompt)\n'
 s=s.replace(mark,mark+'\t_emission = _Emission.new()\n\t_emission.pickup = self\n\tLightKit.mark_emissive(_emission)\n\tadd_child(_emission)\n',1)
 start=s.index('\tvar base: Texture2D = sprite["base"]',s.index('func _draw_world_sprite'))
 end=s.index('\treturn true',start)
 s=s[:start]+'''\t_world_sprite = sprite
\tdraw_texture_rect(sprite["base"], Rect2(Vector2(-12, -16), ItemIcons.WORLD_SIZE), false)
'''+s[end:]
 s=s.replace('\tqueue_redraw()\n','\tqueue_redraw()\n\tif _emission != null:\n\t\t_emission.queue_redraw()\n',1)
 s=s.replace('\t_draw_glint()\n','')
 start=s.index('## 圖示上偶爾閃過的四芒星')
 glint=s[start:]
 glint=glint.replace('func _draw_glint() -> void:', 'func _draw_glint() -> void:').replace('_time + _glint_offset','pickup._time + pickup._glint_offset')
 glint='\n'.join('\t'+line if line else '' for line in glint.splitlines())
 s=s[:start]+'''## Emission never includes the reflective item body.
class _Emission:
\textends Node2D
\tvar pickup: Pickup

\tfunc _draw() -> void:
\t\tdraw_set_transform(Vector2(0, -8 + sin(pickup._time * BOB_SPEED) * BOB_HEIGHT))
\t\tvar sprite := pickup._world_sprite
\t\tif not sprite.is_empty():
\t\t\tvar base: Texture2D = sprite["base"]
\t\t\tvar size := ItemIcons.WORLD_SIZE
\t\t\tvar origin := Vector2(-size.x * 0.5, -size.y * 0.5 - 4.0)
\t\t\tvar outline: Texture2D = sprite.get("outline")
\t\t\tif outline != null:
\t\t\t\tvar pad := Vector2(outline.get_size() - base.get_size()) * 0.5 * size / base.get_size()
\t\t\t\tdraw_texture_rect(outline, Rect2(origin - pad, size + pad * 2.0), false, Color(0.62, 0.85, 0.88, 0.65))
\t\t\tvar glow: Texture2D = sprite["glow"]
\t\t\tif glow != null:
\t\t\t\tdraw_texture_rect(glow, Rect2(origin, size), false, LightKit.glow(Color(1, 1, 1, 0.25), 1.1 + 0.1 * sin(pickup._time * 5.0)))
\t\t_draw_glint()

'''+glint+'\n'
 return s
edit('game/pickups/pickup.gd',pickup)
# Throwable emission child follows physics/state; procedural physical fallbacks stay on parent.
def throwable(s):
 s=s.replace('var _body_art: Sprite2D','var _emission: _Emission\nvar _body_art: Sprite2D')
 assert 'var _emission:' in s
 s=s.replace('\tLightKit.mark_emissive(self)\n','\t_emission = _Emission.new()\n\t_emission.prop = self\n\tLightKit.mark_emissive(_emission)\n\tadd_child(_emission)\n')
 s=s.replace('\tqueue_redraw()\n','\tqueue_redraw()\n\tif _emission != null:\n\t\t_emission.queue_redraw()\n')
 lamp='\t\t\t# 頂端警示燈：平常微亮，點燃引信後快速閃。\n\t\t\tdraw_rect(Rect2(Vector2(-1.5, rect.position.y - 2.0), Vector2(3, 2)), LightKit.glow(Palette.DANGER, fuse_light_energy()))\n'
 assert lamp in s;s=s.replace(lamp,'')
 start=s.index('\t# 可撿的提示：',s.index('func _draw()'))
 end=s.index('\n\n\n## Two smooth',start)
 emission=s[start:end]
 for old,new in [('state == State.REST','prop.state == State.REST'),('_flash >','prop._flash >'),('_fuse_left','prop._fuse_left'),('data.','prop.data.')]:emission=emission.replace(old,new)
 emission='\n'.join('\t\t'+line for line in emission.splitlines())
 # Body content was indented once already; normalize to nested func level.
 emission='\n'.join(line[1:] for line in emission.splitlines())
 s=s[:start]+s[end:]
 s+='''\n\n## Status light and warnings retain their own unshaded canvas, never the metal/wood body.
class _Emission:
\textends Node2D
\tvar prop: Throwable

\tfunc _draw() -> void:
\t\tif prop.data == null:
\t\t\treturn
\t\tvar rect := Rect2(Vector2(-prop.data.size.x * 0.5, -prop.data.size.y), prop.data.size)
\t\tif prop.data.look == ThrowableData.Look.BARREL:
\t\t\tdraw_rect(Rect2(Vector2(-1.5, rect.position.y - 2.0), Vector2(3, 2)), LightKit.glow(Palette.DANGER, prop.fuse_light_energy()))
'''+emission+'\n'
 return s
edit('game/props/throwable.gd',throwable)
# Vehicle physical body/cannon remain shaded; occupied cockpit, hit flash and muzzle stay emissive.
def vehicle(s):
 s=s.replace('var _prompt: WorldPrompt','var _prompt: WorldPrompt\nvar _emission: _Emission')
 s=s.replace('\tLightKit.mark_emissive(self)\n','')
 s=s.replace('\tadd_to_group(&"vehicles")','\t_emission = _Emission.new()\n\t_emission.vehicle = self\n\tLightKit.mark_emissive(_emission)\n\tadd_child(_emission)\n\tadd_to_group(&"vehicles")',1)
 s=s.replace('\tqueue_redraw()\n','\tqueue_redraw()\n\t_emission.queue_redraw()\n')
 s=s.replace('func _draw() -> void:\n','func _draw() -> void:\n\t_draw_body(self, false)\n\n\nfunc _draw_body(canvas: Node2D, flash: bool) -> void:\n',1)
 s=s.replace('\tif _flash_left > 0.0:\n\t\tbase = LightKit.glow(Palette.WHITE, 2.0)','\tif flash:\n\t\tbase = LightKit.glow(Palette.WHITE, 2.0)')
 start=s.index('\t# 駕駛艙',s.index('func _draw_body'))
 end=s.index('\t# 主砲',start)
 cockpit=s[start:end]
 # dark unoccupied cockpit is physical; active cockpit separately emissive.
 s=s[:start]+'''\tif driver == null or destroyed:
\t\tcanvas.draw_rect(Rect2(f * w * 0.05 - 4, -h * 0.8, 8, 6), Palette.CYAN_DIM.darkened(0.4))
'''+s[end:]
 start=s.index('\tif _muzzle_flash >',s.index('func _draw_body'))
 tail=s[start:];s=s[:start]
 start=s.index('func _draw_body')
 body=s[start:]
 for method in ['draw_line','draw_rect']:body=body.replace('\t'+method+'(', '\tcanvas.'+method+'(')
 # replacement includes branches' final tab; repeated canvas prefix not applied.
 s=s[:start]+body
 tail=tail.replace('_muzzle_flash','vehicle._muzzle_flash').replace('aim_dir','vehicle.aim_dir').replace('destroyed','vehicle.destroyed').replace('_anim_time','vehicle._anim_time')
 tail='\n'.join('\t'+line for line in tail.splitlines())
 s+='''\n\nclass _Emission:
\textends Node2D
\tvar vehicle: Vehicle

\tfunc _draw() -> void:
\t\tif vehicle.data == null:
\t\t\treturn
\t\tvar w := vehicle.data.body_size.x
\t\tvar h := vehicle.data.body_size.y
\t\tif vehicle._flash_left > 0.0:
\t\t\tvehicle._draw_body(self, true)
\t\tif vehicle.driver != null and not vehicle.destroyed:
\t\t\tdraw_rect(Rect2(float(vehicle.facing) * w * 0.05 - 4, -h * 0.8, 8, 6), LightKit.glow(Palette.CYAN, 2.0))
\t\tvar mount_point := Vector2(0, -h * 0.7)
'''+tail+'\n'
 return s
edit('game/vehicles/vehicle.gd',vehicle)
