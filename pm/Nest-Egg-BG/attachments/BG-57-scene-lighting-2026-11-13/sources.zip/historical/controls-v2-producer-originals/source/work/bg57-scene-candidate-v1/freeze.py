"""Explicit pre-engine runtime scope; no engine, service or source mutation."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
PREFIXES = ("art/", "audio/", "autoload/", "core/", "data/", "game/", "scenes/", "ui/", "tests/", "tools/")
ROOT_FILES = {"project.godot", "default_bus_layout.tres", "export_presets.cfg"}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    result = subprocess.run(["git", "ls-files", "-z"], cwd=ROOT, capture_output=True, check=True)
    names = {s.decode("utf-8") for s in result.stdout.split(b"\0") if s}
    names = {n for n in names if n.startswith(PREFIXES) or n in ROOT_FILES}
    for prefix in PREFIXES:
        for path in (ROOT / prefix).rglob("*.gd.uid"):
            names.add(path.relative_to(ROOT).as_posix())
    for path in (ROOT / "tests/helpers").glob("scene_lighting_checks.gd*"):
        names.add(path.relative_to(ROOT).as_posix())
    for path in OWN.iterdir():
        if path.is_file() and path.name != "manifest.json":
            names.add(path.relative_to(ROOT).as_posix())
    return {n: sha(ROOT / n) for n in sorted(names)}

if __name__ == "__main__":
    files = snapshot()
    tracked = subprocess.run(["git", "diff", "--name-only"], cwd=ROOT, capture_output=True, text=True, check=True).stdout.splitlines()
    manifest = {
        "head": subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip(),
        "runtime_scope": list(PREFIXES) + sorted(ROOT_FILES),
        "excluded": "PM/design/history evidence are not runtime consumers; immutable Git base records their source.",
        "changed": {n: files[n] for n in tracked if n in files},
        "count": len(files), "files": files,
        "prospective_uids": [n + ".uid" for n in files if n.endswith(".gd") and n + ".uid" not in files],
        "engine_started": False,
    }
    path = OWN / "manifest.json"
    path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"manifest": str(path), "head": manifest["head"], "count": len(files), "sha256": sha(path), "changed": manifest["changed"], "prospective_uids": manifest["prospective_uids"]}, ensure_ascii=False))
