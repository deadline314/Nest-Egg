extends RefCounted
## BG-57: real factories, texture states and quality lifecycle, without claiming GPU pixels.


static func run(suite: TestSuite) -> void:
	var pickup := HealthPickup.new()
	suite.runner.add_child(pickup)
	pickup.set_process(false)
	_check_surfaces(suite, pickup, "pickup")
	suite.check(pickup.get_child(1) is WorldPrompt, "pickup material split preserves the existing prompt child")
	pickup.free()
	for path: String in ["res://data/throwables/pipe.tres", "res://data/throwables/crate_small.tres", "res://data/throwables/fuel_barrel.tres"]:
		var prop := Throwable.new()
		prop.configure(load(path) as ThrowableData)
		suite.runner.add_child(prop)
		prop.set_physics_process(false)
		_check_surfaces(suite, prop, path)
		suite.check(prop.state == Throwable.State.REST and prop.health != null and prop.hurtbox != null, "throwable lighting preserves gameplay components: " + path)
		if prop._body_art != null:
			suite.check(prop._body_art.material == null and not prop._body_art.use_parent_material, "fixture art remains a separate lit body: " + path)
		prop.free()
	var vehicle := Vehicle.new()
	vehicle.configure(load("res://data/vehicles/bulwark.tres") as VehicleData)
	suite.runner.add_child(vehicle)
	vehicle.set_physics_process(false)
	_check_surfaces(suite, vehicle, "legacy vehicle")
	suite.check(vehicle.can_mount() and vehicle.health != null and vehicle.hurtbox != null, "legacy vehicle retains mounting, health and hurtbox")
	vehicle.free()
	_test_stage_textures(suite)
	await _test_quality(suite)
	await _test_stage_canvas(suite)


static func _check_surfaces(suite: TestSuite, body: Node2D, label: String) -> void:
	suite.check(body.material == null and not body.use_parent_material, label + " reflective body uses ordinary canvas lighting")
	var emission := body.get_node_or_null("Emission") as CanvasItem
	suite.check(emission != null and emission.material == LightKit.emissive_material() and not emission.use_parent_material, label + " warnings and glow use a distinct unshaded canvas")


static func _test_stage_textures(suite: TestSuite) -> void:
	var quality := Settings.get_light_quality()
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	var base := "res://art/environment/scene_props/dawn_noodle_stall/dawn_noodle_stall__noodle_bowls_table.png"
	var empty := "res://art/environment/scene_props/dawn_noodle_stall/dawn_noodle_stall__noodle_table_empty.png"
	var definition := {"kind": "sprite", "id": "table", "path": base, "pos": [0, 0], "source_width": 304, "scale": 0.5, "states": {"eaten": {"path": empty}}}
	var prop := StageLayers.create(definition, "BG57 table") as StageLayers._Sprite
	suite.check(prop != null and prop.texture is CanvasTexture and (prop.texture as CanvasTexture).normal_texture != null, "stage physical base loads the existing normal")
	if prop != null:
		var width := prop.texture.get_width() * prop.scale.x
		var changed := prop.set_prop_state("eaten")
		suite.check(changed and prop.texture is CanvasTexture and (prop.texture as CanvasTexture).normal_texture.resource_path == empty.get_basename() + "_n.png", "stage state swaps diffuse and its matching normal together")
		suite.check(is_equal_approx(prop.texture.get_width() * prop.scale.x, width) and prop.material == null, "stage state preserves source width and reflective material")
		prop.free()
	var backdrop := StageLayers.create({"kind": "sprite", "path": "res://art/environment/scenes/pawnshop_kitchen_contacts.png", "pos": [0, 0]}, "BG57 baked") as Sprite2D
	suite.check(backdrop != null and not backdrop.texture is CanvasTexture and backdrop.material == LightKit.emissive_material(), "complete baked backplate keeps its original appearance even when a normal file exists")
	if backdrop != null:
		backdrop.free()
	suite.check(not StageLayers.prop_state_problem({"kind": "sprite", "path": base, "lighting": "unknown"}).is_empty(), "unknown stage lighting role is rejected")
	suite.check(not StageLayers.prop_state_problem({"kind": "sprite", "path": base, "life": true}).is_empty(), "physical stage body cannot become an unshaded window-life layer")
	Settings.set_light_quality(quality)


static func _test_quality(suite: TestSuite) -> void:
	var previous := Settings.get_light_quality()
	var storage := Settings.storage_path()
	var path := "res://art/environment/scene_props/dawn_noodle_stall/dawn_noodle_stall__noodle_bowls_table.png"
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	var texture := LitTextures.load_texture(path) as CanvasTexture
	suite.check(texture != null and texture.normal_texture != null, "normal quality control starts with a real cached normal")
	Settings.set_light_quality(LightQuality.Tier.LOW)
	suite.check(not LitTextures.is_enabled() and texture != null and texture.normal_texture == null, "LOW applies to cached textures without any live Level")
	var controller := LightingController.new()
	controller._on_exiting()
	controller.free()
	suite.check(not LitTextures.is_enabled() and texture.normal_texture == null, "leaving LOW Level cannot silently restore HIGH normals")
	var cold := LitTextures.load_texture("res://art/environment/scene_props/pawnshop_kitchen_contacts/kettle_atlas.png") as CanvasTexture
	suite.check(cold != null and cold.normal_texture == null, "textures loaded after LOW Level exit stay LOW")
	var fixture := "user://bg57-light-quality.cfg"
	var config := ConfigFile.new()
	config.set_value("display", "light_quality", LightQuality.Tier.LOW)
	suite.check(config.save(fixture) == OK, "quality reload fixture is written")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Settings.use_storage(fixture)
	suite.check(Settings.get_light_quality() == LightQuality.Tier.LOW and not LitTextures.is_enabled() and texture.normal_texture == null, "loading stored LOW synchronizes normals before a Level is built")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	suite.check(LitTextures.load_texture(path) == texture and texture.normal_texture != null and cold.normal_texture != null, "HIGH restores the same cached textures and both normals")
	Settings.use_storage(storage)
	Settings.set_light_quality(previous)
	DirAccess.remove_absolute(fixture)
	await suite.frames(1)


static func _test_stage_canvas(suite: TestSuite) -> void:
	suite.check(not StageLibrary.lighting_problems({"lights": [{"pos": [0, 0], "color": "#ffffff", "radius": 100, "energy": 4.0}]}).is_empty(), "stage local light rejects an excessive energy")
	suite.check(not StageLibrary.lighting_problems({"ambient": 1.0}).is_empty(), "stage local lighting rejects a malformed ambient")
	var layer := CanvasLayer.new()
	layer.layer = UiLayers.CUTSCENE
	suite.runner.add_child(layer)
	var stage := StageLibrary.Stage.new()
	stage.configure_lighting({"ambient": "#cccccc", "lights": [{"pos": [50, 40], "radius": 100, "energy": 0.2, "color": "#ffe0bc"}]})
	layer.add_child(stage)
	await suite.frames(1)
	suite.check(stage._ambient != null and stage._ambient.color == Color("cccccc"), "stage uses its explicit local ambient")
	suite.check(stage._local_lights.size() == 1 and stage._local_lights[0].range_layer_min == UiLayers.CUTSCENE and stage._local_lights[0].range_layer_max == UiLayers.CUTSCENE, "stage point light is restricted to its actual independent canvas layer")
	suite.check(not stage._local_lights[0].is_in_group(LightKit.SCENE_LIGHTS), "stage light never joins the gameplay light budget")
	layer.free()
	var plain := StageLibrary.build(&"ch1_pawnshop_kitchen")
	suite.check(plain._local_lights.is_empty() and plain._ambient == null, "decorative stage glow does not silently become a light or change ambient")
	plain.free()
