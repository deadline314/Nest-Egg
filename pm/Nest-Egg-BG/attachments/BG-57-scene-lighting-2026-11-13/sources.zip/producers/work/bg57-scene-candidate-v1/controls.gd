extends Node

var checks := 0
var failures := 0

class Controls:
	extends TestSuite
	func run() -> void:
		await preload("res://tests/helpers/scene_lighting_checks.gd").run(self)
		await preload("res://tests/helpers/stage_prop_hold_checks.gd").run(self)

func _ready() -> void:
	_run.call_deferred()

func _run() -> void:
	var suite := Controls.new(self)
	await suite.run()
	suite = null
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	print("BG57 controls: %d checks / %d failures" % [checks, failures])
	get_tree().quit(0 if failures == 0 else 1)

func _check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
	print("%s %s" % ["PASS" if condition else "FAIL", message])

func _frames(count: int) -> void:
	for i in count:
		await get_tree().process_frame
