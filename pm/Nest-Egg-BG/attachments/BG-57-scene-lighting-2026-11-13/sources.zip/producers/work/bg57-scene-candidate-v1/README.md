# BG-57 scene lighting candidate

Isolated linked worktree, actual base `9caed2a557511634aca4b83805c3dacf6ac843ca`.
Primary C product, PM and index are untouched. Engine windows are assigned by
the coordinator; no additional engine invocation is implied by this preparation.

S1/S2/S3 separate ordinary reflective canvas drawing from existing unshaded
outline, glint, fuse, cockpit, muzzle and hit-flash drawing. No physics, reward,
carry, throwing, fire, ownership or collision path is replaced. Procedural
missing-art bodies remain lit; their separate glint/status layer remains readable.

S4 classifies scene-prop/world-prop sprites as physical by their existing library,
with an optional explicit `lighting` role for other libraries. Complete baked
backgrounds remain unshaded. Every finite texture state loads the corresponding
normal through LitTextures without changing source geometry or contact points.
Explicit stage `ambient` (existing documented field) and at most eight local
`lights` are supported, with bounded energy and the actual independent canvas
layer. Decorative glow never implicitly becomes a light. No existing stage
lighting values have been changed yet; representative data requires native A/B.
Character-local cap and held attachment integration now uses NE295's narrow
CharacterRig interface. Five source files and one actual editor-generated UID
are borrowed context, separately listed and excluded from BG57 owned delivery.
Stage entry handles rig setup before/after entry, without mutating global
LightKit. Release, owner loss and stage exit restore the held prop's appearance.

S5 Settings synchronizes normal quality on load and change. LightingController
does not restore HIGH normals on Level exit. The cache's explicit test injection
API remains unchanged.

The permanent EnvironmentSuite helper exercises real factories, cached/new
texture quality, storage reload, diffuse/normal state swaps, baked isolation and
independent-canvas light range. These are structural controls, not GPU proof.
Native single-light direction/occlusion and restoration A/A/A/B/A, physical/glow
separation, LOW/HIGH, real held prop states and neon/exposure still need rendering.

Observed epochs (raw in the external proof folder): cold import exit0/0diag;
initial control 36/1 (the new test incorrectly required destructible components
on the intentionally indestructible pipe); corrected 36/0, products unchanged;
stage-binding context 337/0, default fullautoload, strict0diag, C459/D10197 fixed,
all four queue boundaries clear. These are headless structural contracts only.
The next helper adds the actual concrete_chunk factory and seven UI-context
controls, expected 347 checks; these increments are not yet run. Pickup missing
art now also retains the cached empty dictionary instead of allocating one per
fallback draw. CutscenePlayer's two UI-build hooks isolate dialogue/title/choice
from the same canvas ambient, explicitly skipping the physical stage holder.
All 59 other original Player functions remain source-identical; a timer-mutation
negative is rejected by the CPU boundary reader. This is not rendered equality.

`D:/NestEggVerification/proofs/bg57-scene-lighting-20261113/` retains every epoch,
the test-only red/green delta, producer originals, and the separate stage owned
and borrowed manifests. Native fixture preparation is external/unparsed: one
HIGH gallery, six original raw frames, AABA plus controlled old-unshaded A/B.
Its 24 synthetic numeric controls verify raw/format/transfer rejection only.
