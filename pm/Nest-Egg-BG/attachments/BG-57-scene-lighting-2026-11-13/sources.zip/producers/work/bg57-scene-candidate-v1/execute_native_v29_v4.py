"""BG57 isolated scene-lighting import/control epochs; adapted from preserved NE251 runner."""
import argparse
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

P=Path(__file__).resolve().parent
D=P.parents[1]
C=Path('C:/Users/stanl/Github/Nest-Egg')
PROOF=Path('D:/NestEggVerification/proofs/bg57-scene-lighting-20261113')
GUARD=C/'work/ne296-adoption-v1/c-native-context-v29.json'
GODOT=Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
BASE='92521d0cf3c18bd3dad4b13a316844e70bfaecd0'
ENV=['APPDATA','LOCALAPPDATA','USERPROFILE','TMP','TEMP']
PREFIXES=['art/','audio/','autoload/','core/','data/','game/','scenes/','ui/','shaders/','addons/','config/','tools/','tests/','work/bg57-scene-candidate-v1/','work/bg57-native-v2/','work/bg57-native-v3/','work/bg57-native-v4/']
UID_INPUTS=[name+'.uid' for name in subprocess.check_output(['git','ls-files','-z'],cwd=D).decode().split('\0') if name.endswith('.gd') and not (D/(name+'.uid')).exists()]
UID_INPUTS += ['tests/helpers/scene_lighting_checks.gd.uid','work/bg57-scene-candidate-v1/controls.gd.uid']
UID_INPUTS += ['work/bg57-native-v4/capture.gd.uid']
EXTRA=set(UID_INPUTS)
EXPECTED_DIFF_SHA='432d8498f8edba7dbdd07aad11b3b0f3ad0f83f62332747fad2efafca4016c52'


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def save(out,name,value):
    target=out/name
    assert not target.exists(),target
    target.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')


def queues():
    values={}
    for port in [8188,8189]:
        try:
            with urllib.request.urlopen(f'http://127.0.0.1:{port}/queue',timeout=3) as response:data=json.load(response)
            assert isinstance(data['queue_running'],list) and isinstance(data['queue_pending'],list)
            values[str(port)]=dict(status='response',running=len(data['queue_running']),pending=len(data['queue_pending']))
        except urllib.error.URLError as error:
            code=getattr(error.reason,'winerror',None) or getattr(error.reason,'errno',None)
            values[str(port)]=dict(status='refused10061' if code==10061 else 'unknown',error=str(error))
        except (OSError,ValueError,KeyError,AssertionError) as error:values[str(port)]=dict(status='unknown',error=str(error))
    values['clear']=(values['8188'].get('status')=='response' and values['8188'].get('running')==values['8188'].get('pending')==0
                     and (values['8189'].get('status')=='refused10061' or (values['8189'].get('status')=='response' and values['8189'].get('running')==values['8189'].get('pending')==0)))
    return values


def processes():
    command=['powershell','-NoProfile','-NonInteractive','-Command',
             "Get-CimInstance Win32_Process | Where-Object { $_.Name -like '*Godot*' } | Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Compress"]
    result=subprocess.run(command,capture_output=True)
    assert result.returncode==0
    text=result.stdout.decode('utf8',errors='replace').strip()
    parsed=json.loads(text) if text else []
    return parsed if isinstance(parsed,list) else [parsed]


def snapshot():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=D,text=True).strip()==BASE
    tracked_diff=subprocess.check_output(['git','diff','--no-ext-diff','--name-only','HEAD'],cwd=D,text=True)
    assert hashlib.sha256(subprocess.check_output(['git','diff','--no-ext-diff','--binary'],cwd=D)).hexdigest()==EXPECTED_DIFF_SHA,'candidate tracked diff changed'
    guard=json.loads(GUARD.read_text(encoding='utf8'))
    assert guard['count']==len(guard['files'])==463
    assert sha(GUARD)=='a3df1f1a2c27952545453a3d1b8a422a42755deddcc86088a70c1dc62e1d81d0'
    primary={name:sha(C/name) for name in guard['files']}
    assert primary==guard['files'],'primary source epoch changed'
    files={}
    # Root approved this NEW scope after the complete first import: runtime
    # folders/tools/own, every root config, and the actual seven UID+GD pairs.
    # Historical PM/design ZIPs are not dynamic consumers and are excluded.
    for folder,dirs,names in os.walk(D):
        dirs[:]=[name for name in dirs if name not in ['.git','.godot','__pycache__']]
        for name in names:
            path=Path(folder)/name
            if path==D/'.git':continue
            relative=path.relative_to(D).as_posix()
            if path.parent==D or relative in EXTRA or any(relative.startswith(prefix) for prefix in PREFIXES):
                files[relative]=sha(path)
    return dict(base=BASE,primary_C=primary,primary_guard_sha256=sha(GUARD),d=files,
                own={f.name:sha(f) for f in P.iterdir() if f.is_file()},godot_sha256=sha(GODOT),
                excluded_mutable_caches=['.godot','__pycache__'],no_performance_claim=True,
                source_scope=dict(kind='runtime-prefix-v1, not full repository',prefixes=PREFIXES,extra=sorted(EXTRA),
                                  all_root_files_included=True,tracked_diff_before=tracked_diff,
                                  excluded='PM/design/art_src/assets_src historical source or evidence; no dynamic consumer in calibration',
                                  prospective_uid_origin='before source .gd without .uid, registered before engine', prospective_uids=UID_INPUTS))


def compare(before,after,phase):
    assert before['primary_C']==after['primary_C'] and before['godot_sha256']==after['godot_sha256']
    changed=[n for n,h in before['d'].items() if after['d'].get(n)!=h]
    added=sorted(set(after['d'])-set(before['d']))
    assert not changed,('changed/removed original D inputs',changed)
    if phase=='import':
        for name in added:
            assert name in UID_INPUTS and name.endswith('.gd.uid') and name.removesuffix('.uid') in before['d'],('unexpected import addition',name)
            assert re.fullmatch(rb'uid://[a-z0-9]+\r?\n?',(D/name).read_bytes()),name
    else:assert not added,('new source after freeze; retain and register prospectively',added)
    return dict(original_files_exact=True,added_uid_prospective=added,d_count_before=len(before['d']),d_count_after=len(after['d']),primary_count=463)


def engine(out,phase):
    env=os.environ.copy()
    for name in ENV:
        directory=out/'environment'/name
        directory.mkdir(parents=True)
        env[name]=str(directory)
    save(out,'environment.json',{name:env[name] for name in ENV})
    command=[str(GODOT),'--path',str(D),'--audio-driver','Dummy','--log-file',str(out/'godot.log')]
    command+=['--headless','res://work/bg57-native-v4/capture.tscn','--','--parse-only'] if phase=='parser' else ['--rendering-method','forward_plus','--rendering-driver','vulkan','--windowed','--resolution','1280x720','res://work/bg57-native-v4/capture.tscn','--','--out='+str(out/'captures')]
    save(out,'command.json',dict(command=command,cwd=str(D),phase=phase))
    started=time.monotonic()
    with (out/'process.log').open('xb') as log:
        process=subprocess.Popen(command,cwd=D,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
        save(out,'started.json',dict(cli_pid=process.pid))
        try:code=process.wait(timeout=300 if phase=='import' else 90)
        except subprocess.TimeoutExpired:
            observed=processes()
            save(out,'timeout-processes.json',observed)
            subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
            process.wait(timeout=15)
            code='timeout'
    text=(out/'process.log').read_text(encoding='utf8',errors='replace')
    diagnostics=[line for line in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|^WARNING:|Parse Error|ObjectDB.*leak|were leaked|resources still in use',line)]
    save(out,'process.json',dict(exit_code=code,seconds=time.monotonic()-started,diagnostics=diagnostics,log_sha256=sha(out/'process.log')))
    assert code==0 and not diagnostics,(code,diagnostics)
    if phase=='controls':assert re.search(r'BG57 controls: [1-9][0-9]* checks / 0 failures',text) is not None


def main(args):
    assert args.root_explicit_handoff,'Preparation is not authorization'
    out=PROOF/args.tag
    assert out.parent==PROOF and not out.exists()
    out.mkdir()
    before=snapshot()
    save(out,'before.json',before)
    save(out,'external-processes-before.json',processes())
    outside=queues()
    save(out,'queue-before-lock.json',outside)
    if not outside['clear']:
        print('WAITING queue, no engine/lock',flush=True)
        return 2
    sys.path.insert(0,str(C/'tools/comfyui'))
    import comfy_guard
    assert comfy_guard.LOCK_PATH.resolve()==(C/'assets_src/work/comfy.lock').resolve()
    started=False
    error=None
    with comfy_guard.LOCK_PATH.open('a+b') as lock:
        lock.seek(0)
        try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:
            print('WAITING primary lock, no engine',flush=True)
            return 2
        try:
            inside=queues()
            save(out,'queue-inside-before.json',inside)
            if not inside['clear']:return 2
            assert snapshot()==before
            print('START BG57 '+args.phase,flush=True)
            started=True
            try:engine(out,args.phase)
            except Exception as exception:error=repr(exception)
        finally:
            save(out,'queue-inside-after.json',queues())
            lock.seek(0)
            msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
    save(out,'queue-after-unlock.json',queues())
    after=snapshot()
    save(out,'after.json',after)
    gate=compare(before,after,args.phase)
    save(out,'source-gate.json',gate)
    save(out,'external-processes-after.json',processes())
    assert started
    clear=json.loads((out/'queue-inside-after.json').read_text())['clear'] and json.loads((out/'queue-after-unlock.json').read_text())['clear']
    save(out,'completion.json',dict(phase=args.phase,engine_exited=True,primary_lock_released=True,error=error,queue_gate_passed=clear,
                                   accepted=error is None and clear,source_gate=gate,scope='normal fullautoload parser or HIGH factory nine-frame layout/material diagnostic; no complete gameplay/LOW/performance claim'))
    print('DONE BG57 '+args.phase+': '+('accepted' if error is None and clear else 'rejected')+'; lock released',flush=True)
    if error:print(error,flush=True)
    return 0 if error is None and clear else 1


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=['parser','native'],required=True)
    parser.add_argument('--tag',required=True)
    parser.add_argument('--root-explicit-handoff',action='store_true')
    raise SystemExit(main(parser.parse_args()))
