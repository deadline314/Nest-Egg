extends "res://tools/stage_actor_capture.gd"
var observed: Array[Dictionary] = []
var shot_name := ""

func _ready() -> void:
    add_child(LightKit.create_environment())
    for arg: String in OS.get_cmdline_user_args():
        if arg.begins_with("--quality="):
            Settings.set_light_quality(int(arg.trim_prefix("--quality=")))
    await super._ready()

func _process(_delta: float) -> void:
    for node: Node in find_children("*","CutsceneActor",true,false):
        var actor := node as CutsceneActor
        if actor == null or is_nan(actor.ground_y): continue
        actor.face(-1 if shot_name.ends_with("left") else 1)
        var drop := (actor.ground_y-actor.position.y)/actor.scale.y
        var strength := pow(1.0-clampf(drop/ContactShadow.MAX_DROP,0.0,1.0),1.5)
        var half := CutsceneActor.STAGE_SHADOW_HALF_WIDTH*(CutsceneActor.STAGE_SHADOW_LYING if actor.pose==&"dead" else 1.0)*lerpf(1.0,ContactShadow.HEIGHT_SHRINK,clampf(drop/ContactShadow.MAX_DROP,0.0,1.0))
        var record := {"shot":shot_name,"pose":String(actor.pose),"facing":actor.facing,
            "position":[actor.position.x,actor.position.y],"ground_y":actor.ground_y,
            "scale":[actor.scale.x,actor.scale.y],"drop":drop,"strength":strength,"half_width":half,
            "quality":Settings.get_light_quality(),"rig_present":actor.rig!=null}
        if observed.is_empty() or observed[-1].shot != shot_name: observed.append(record)
        else: observed[-1]=record

func _capture(shot: String) -> bool:
    shot_name = shot.get_slice(":",0)
    var saved := await super._capture(shot)
    var file := FileAccess.open(_out.path_join("stage-observations.json"),FileAccess.WRITE)
    if file == null:
        push_error("BG29_STAGE cannot write observations")
        return false
    file.store_string(JSON.stringify(observed,"\t"));file.close()
    await AudioRelease.settle(get_tree())
    return saved and not observed.is_empty() and observed[-1].shot==shot_name
