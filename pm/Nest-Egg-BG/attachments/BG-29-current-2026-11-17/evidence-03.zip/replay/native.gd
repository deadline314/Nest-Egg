extends "res://tools/wall_shadow_probe.gd"
var rows: Array[Dictionary] = []

func check(value: bool, label: String) -> void:
    if not value:
        _failures += 1
        push_error("BG29_NATIVE " + label)

func rect_values(rect: Rect2) -> Array:
    return [rect.position.x,rect.position.y,rect.size.x,rect.size.y]

func take(level: Level, target: Node2D, label: String) -> void:
    var shadow := target.find_child("ContactShadow",false,false) as ContactShadow
    check(shadow != null,label+" actual attached shadow")
    if shadow == null: return
    var old_script: Script = load("res://work/bg29-current/before.gd")
    var old = old_script.new()
    old.half_width = shadow.half_width
    old.add_to_group(WallShadows.SKIPPED_GROUP)
    target.add_child(old)
    old.set_physics_process(false)
    shadow.set_physics_process(false)
    for item in [shadow,old]:
        for ray: RayCast2D in item._rays: ray.force_raycast_update()
        item._light_timer = 0.0
        item._physics_process(0.0)
    check(old.is_cast()==shadow.is_cast(),label+" cast unchanged")
    check(old.world_rect().is_equal_approx(shadow.world_rect()),label+" support unchanged")
    old.hide()
    HeldLighting.sync(level)
    await _settle(8)
    var on := Capture.image(get_viewport())
    shadow.hide();old.show()
    await _settle(8)
    var before := Capture.image(get_viewport())
    old.hide()
    await _settle(8)
    var off := Capture.image(get_viewport())
    check(on.get_data()==before.get_data(),label+" old/current pixels identical")
    var size := on.get_size()
    var pixels := get_viewport().get_final_transform()*get_viewport().get_canvas_transform()*shadow.world_rect()
    var onscreen := not shadow.is_cast() or Rect2(Vector2.ZERO,Vector2(size)).encloses(pixels)
    check(onscreen,label+" complete shadow in frame")
    for image_tag: Array in [["on",on],["before",before],["off",off]]:
        check(image_tag[1].save_png(_out.path_join(label+"-"+image_tag[0]+".png"))==OK,label+" save "+image_tag[0])
    var row := {"label":label,"quality":Settings.get_light_quality(),"target":str(target.get_path()),
        "feet":[target.global_position.x,target.global_position.y],"half_width":shadow.half_width,
        "cast":shadow.is_cast(),"bounds":rect_values(shadow.world_rect()),"pixel_bounds":rect_values(pixels),
        "strength":shadow._strength,"shift":shadow._shift,"same_pixels":on.get_data()==before.get_data(),
        "visible_change":on.get_data()!=off.get_data(),"in_view":onscreen,"size":[size.x,size.y]}
    rows.append(row)
    print("BG29_NATIVE ",JSON.stringify(row))
    shadow.show();old.queue_free()
    await _settle(4)

func pose_rig(rig: CharacterRig, pose: String, facing: int) -> void:
    var input := RigInput.new()
    input.facing = facing
    input.aim_dir = Vector2(facing,0)
    input.on_floor = pose != "jump"
    input.dead = pose == "dead"
    input.npc_pose = &"sit" if pose == "sit" else &"stand"
    input.two_handed = not (rig.animator is NpcAnimator)
    if pose == "jump": input.velocity = Vector2(0,-120)
    for i in 120: rig.animate(1.0/60.0,input)

func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(QUALITY[_quality])
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var data := load("res://data/levels/%s.tres" % _level) as LevelData
    var level := await _open(data)
    var feet := _stand(level)
    check(feet.is_finite(),"real floor selected")
    await _place_player(level,feet,Vector2.RIGHT)
    var player := level.player
    feet = player.global_position
    var camera := get_viewport().get_camera_2d() as LevelCamera
    camera.set_physics_process(false);camera.set_process(false)
    camera.position_smoothing_enabled = false
    camera.offset = Vector2.ZERO
    camera.global_position = feet+Vector2(0,-42)
    camera.force_update_scroll()
    HeldLighting.preserve_physics_bodies(level)
    level.process_mode = Node.PROCESS_MODE_DISABLED
    Engine.time_scale = 0.0
    get_tree().paused = true
    for facing: int in [-1,1]:
        player.facing = facing
        pose_rig(player._visual.rig,"idle",facing)
        await take(level,player,"player-stand-"+str(facing))
    player.global_position.y -= 40
    pose_rig(player._visual.rig,"jump",1)
    await take(level,player,"player-raised")
    player.global_position = feet
    pose_rig(player._visual.rig,"idle",1)
    await take(level,player,"player-landed")
    player.hide()
    for id: String in ["sweeper","collector_brute","watchdog","drone"]:
        var enemy_data := (load("res://data/enemies/%s.tres" % id) as EnemyData).duplicate() as EnemyData
        var enemy := level._create_enemy(enemy_data)
        enemy.position = feet
        level._entities.add_child(enemy)
        enemy.set_physics_process(false)
        if enemy.rig != null: pose_rig(enemy.rig,"idle",-1)
        if enemy.creature != null:
            enemy.creature.set_physics_process(false)
        if enemy_data.uses_gravity:
            await take(level,enemy,id)
        else:
            check(enemy.find_child("ContactShadow",false,false)==null,id+" airborne type has no foot shadow")
        enemy.queue_free()
        await _settle(4)
    var npc := NpcActor.new()
    npc.data=(load("res://data/npcs/ch1_old_k.tres") as NpcData).duplicate() as NpcData
    npc.data.loop = &""
    npc.position = feet
    level._entities.add_child(npc)
    for pose: String in ["idle","sit"]:
        npc._actor.set_pose(StringName(pose))
        pose_rig(npc._actor.rig,pose,-1)
        check((npc._actor.rig.animator as NpcAnimator).posture_ready(&"sit" if pose=="sit" else &"stand"),"NPC consumed "+pose+" posture")
        await take(level,npc,"npc-"+pose)
    npc.queue_free()
    player.show()
    var death := DamageInfo.new()
    player._on_died(death)
    pose_rig(player._visual.rig,"dead",1)
    await take(level,player,"player-dead")
    Engine.time_scale = 1.0
    get_tree().paused = false
    level.queue_free()
    await _settle(8)
    var file := FileAccess.open(_out.path_join("native-index.json"),FileAccess.WRITE)
    check(file != null,"report open")
    if file != null:
        file.store_string(JSON.stringify({"failures":_failures,"rows":rows,"adapter":RenderingServer.get_video_adapter_name(),
            "scope":"Arranged actual Player/NpcActor/Enemy on real level collision support; held world, direct existing rig pose inputs; not a motion or physical-input acceptance."},"\t"));file.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit(1 if _failures else 0)
