extends Node2D
const Capture := preload("res://tools/viewport_capture.gd")
var out := ""
var failures := 0

func check(value: bool, label: String) -> void:
    if not value:
        failures += 1
        push_error("BG29_REDRAW " + label)

func settle(frames: int) -> void:
    for i in frames: await get_tree().process_frame
    await RenderingServer.frame_post_draw

func _ready() -> void:
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--out="): out = arg.trim_prefix("--out=")
    check(out.is_absolute_path(), "absolute output")
    add_child(LightKit.create_environment())
    var body := StaticBody2D.new()
    body.collision_layer = Layers.WORLD
    body.collision_mask = 0
    var shape := CollisionShape2D.new()
    var rect := RectangleShape2D.new()
    rect.size = Vector2(440, 16)
    shape.shape = rect
    shape.position = Vector2(220, 258)
    body.add_child(shape)
    add_child(body)
    var floor_art := Polygon2D.new()
    floor_art.polygon = PackedVector2Array([Vector2(0,250),Vector2(440,250),Vector2(440,266),Vector2(0,266)])
    floor_art.color = Color(.6,.7,.8)
    add_child(floor_art)
    var results: Array[Dictionary] = []
    for version: String in ["before", "current"]:
        var owner := Node2D.new()
        owner.position = Vector2(220,250)
        add_child(owner)
        var script: Script = load("res://work/bg29-current/before.gd") if version == "before" else load("res://game/level/environment/contact_shadow.gd")
        var shadow = script.new()
        shadow.half_width = 12.0
        owner.add_child(shadow)
        var draws := [0]
        shadow.draw.connect(func(): draws[0] += 1)
        await settle(12)
        check(shadow.is_cast(), version+" ground casts")
        var grounded: Rect2 = shadow.world_rect()
        check(absf(grounded.position.y-248.0)<.5, version+" actual floor")
        owner.position = Vector2(580,250)
        await settle(12)
        check(not shadow.is_cast(), version+" pit hides")
        draws[0] = 0
        var physics_start := Engine.get_physics_frames()
        await get_tree().create_timer(.6).timeout
        await RenderingServer.frame_post_draw
        var row := {"version":version,"pit_draws":draws[0],"pit_physics_frames":Engine.get_physics_frames()-physics_start,
            "pit_cast":shadow.is_cast(),"surface":shadow._surface}
        check(row.pit_physics_frames >= 25, version+" real physics observations")
        if version == "before": check(draws[0]>=20,"counterfactual reproduces needless redraw")
        else: check(draws[0]==0,"unsupported shadow stays cached")
        owner.position = Vector2(220,250)
        await settle(12)
        row["reacquired"] = shadow.is_cast() and shadow.world_rect().is_equal_approx(grounded)
        check(row.reacquired,version+" reenter same floor")
        check(Capture.image(get_viewport()).save_png(out.path_join(version+"-ground.png"))==OK,version+" PNG save")
        results.append(row)
        owner.queue_free()
        await settle(4)
    var file := FileAccess.open(out.path_join("redraw.json"),FileAccess.WRITE)
    check(file != null,"report open")
    if file != null:
        file.store_string(JSON.stringify({"failures":failures,"rows":results,"adapter":RenderingServer.get_video_adapter_name()},"\t"))
        file.close()
    print("BG29_REDRAW ",JSON.stringify(results)," failures=",failures)
    await AudioRelease.settle(get_tree())
    get_tree().quit(1 if failures else 0)
