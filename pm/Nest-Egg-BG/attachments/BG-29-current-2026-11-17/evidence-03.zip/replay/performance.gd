extends "res://tools/wall_shadow_probe.gd"
var samples: Array[Dictionary] = []

func _spawn_foe(level: Level, position: Vector2) -> Enemy:
    var data := (load(ENEMY_PATH) as EnemyData).duplicate() as EnemyData
    data.detect_range = 0.0
    data.attack_range = 0.0
    data.move_speed = 0.0
    data.contact_damage = 0
    var enemy := level._create_enemy(data)
    enemy.position = position
    enemy.facing = -1
    level._entities.add_child(enemy)
    enemy.health.setup(999,0.0)
    return enemy

func _frame_ms() -> float:
    var level := get_tree().get_first_node_in_group(&"player").get_parent().get_parent().get_parent() as Level
    if level == null:
        push_error("BG29_PERF missing owning level")
        _failures += 1
        return 0.0
    var wall := level.find_child("WallShadows",true,false) as WallShadows
    var enabled := not wall.suspended
    wall.suspended = false
    var count := 0
    var rays := 0
    for node: Node in level.find_children("*","",true,false):
        if node is ContactShadow:
            count += 1
            rays += node.get_child_count()
            node.visible = enabled
            node.process_mode = Node.PROCESS_MODE_INHERIT if enabled else Node.PROCESS_MODE_DISABLED
    HeldLighting.sync_owners(level._light_budget,[wall])
    await _settle(8)
    var value := await super._frame_ms()
    samples.append({"enabled":enabled,"contacts":count,"rays":rays,"frames_ms":Array(_last_frame_samples),
        "wall_suspended":wall.suspended,"quality":Settings.get_light_quality()})
    wall.suspended = not enabled
    return value

func _perf(level: Level, shadows: WallShadows) -> Dictionary:
    var result := await super._perf(level,shadows)
    result["contact_samples"] = samples
    result["scope"] = "12 original sweeper actors with animations and physics; idle ranges/speed and contact damage 0; contact drawing + five ray updates toggled, nodes retained; wall projection held enabled. Not combat AI or byte allocation delta."
    return result
