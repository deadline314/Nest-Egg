extends "res://tools/wall_shadow_probe.gd"

func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(QUALITY[_quality])
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var data := load("res://data/levels/%s.tres" % _level) as LevelData
    var level := await _open(data)
    await _place_player(level,_stand(level),Vector2.RIGHT)
    var player := level.player
    var camera := get_viewport().get_camera_2d() as LevelCamera
    camera.set_physics_process(false);camera.set_process(false)
    camera.position_smoothing_enabled=false
    camera.offset=Vector2.ZERO
    camera.global_position=player.global_position+Vector2(0,-65)
    camera.force_update_scroll()
    Engine.max_fps=60
    DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
    var rows: Array[Dictionary]=[]
    var images: Array[Image]=[]
    var image_frames: Array[int]=[]
    var airborne := false
    var landed := false
    for frame in 240:
        if frame in [20,120]: Input.action_press(&"jump")
        if frame in [22,160]: Input.action_release(&"jump")
        if frame==90: _aim=Vector2.LEFT
        if frame==200: _aim=Vector2.RIGHT
        if frame==90: Input.action_press(&"move_left")
        if frame==92: Input.action_release(&"move_left")
        if frame==200: Input.action_press(&"move_right")
        if frame==202: Input.action_release(&"move_right")
        await get_tree().process_frame
        await RenderingServer.frame_post_draw
        var shadow := player._contact_shadow
        var box := shadow.world_rect()
        var ground := player.is_on_floor()
        if not ground and frame>20: airborne=true
        if airborne and ground: landed=true
        rows.append({"frame":frame,"physics_frame":Engine.get_physics_frames(),"feet":[player.global_position.x,player.global_position.y],
            "on_floor":ground,"velocity":[player.velocity.x,player.velocity.y],"cast":shadow.is_cast(),
            "bounds":[box.position.x,box.position.y,box.size.x,box.size.y],"strength":shadow._strength,"facing":player.facing,
            "jump_held":Input.is_action_pressed(&"jump")})
        if frame in [15,26,40,65,95,135,150,180,215]:
            images.append(get_viewport().get_texture().get_image())
            image_frames.append(frame)
    for action: StringName in [&"jump",&"move_left",&"move_right"]: Input.action_release(action)
    var all_saved := true
    for i in images.size():
        if Capture.encode(images[i],get_viewport().use_hdr_2d).save_png(_out.path_join("motion-%03d.png" % image_frames[i]))!=OK:
            all_saved=false
            push_error("BG29_MOTION PNG save failed frame "+str(image_frames[i]))
    var file := FileAccess.open(_out.path_join("motion-index.json"),FileAccess.WRITE)
    var passed := airborne and landed and all_saved and file!=null
    if not passed: push_error("BG29_MOTION missing jump, landing, image or report")
    if file!=null:
        file.store_string(JSON.stringify({"rows":rows,"image_frames":image_frames,"airborne":airborne,"landed":landed,
            "all_saved":all_saved,"quality":Settings.get_light_quality(),"adapter":RenderingServer.get_video_adapter_name(),
            "scope":"Software action input through actual player controller; floating frames held until sequence finishes, then encoded. Not physical keyboard/gamepad, video, or frame-budget benchmark."},"\t"));file.close()
    level.queue_free()
    await _settle(8)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0 if passed else 1)
