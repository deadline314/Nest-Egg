extends Node
const Capture := preload("res://tools/viewport_capture.gd")
var out := ""
var quality := 2
var failures := 0

func check(value: bool, label: String) -> void:
    if not value:
        failures += 1
        push_error("BG29_STAGE " + label)

func _ready() -> void:
    for arg: String in OS.get_cmdline_user_args():
        if arg.begins_with("--out="): out=arg.trim_prefix("--out=")
        if arg.begins_with("--quality="): quality=int(arg.trim_prefix("--quality="))
    add_child(LightKit.create_environment())
    Settings.set_light_quality(quality)
    _run.call_deferred()

func _run() -> void:
    var fixtures: Array=JSON.parse_string(FileAccess.get_file_as_string("res://work/bg29-current/stage-fixtures.json"))
    var records: Array[Dictionary]=[]
    for fixture: Dictionary in fixtures:
        var player := CutscenePlayer.new()
        add_child(player)
        player.play(StringName("bg29_"+fixture.name),fixture.scene)
        await get_tree().create_timer(2.4).timeout
        await RenderingServer.frame_post_draw
        var actors: Array[Dictionary]=[]
        for expected: Dictionary in fixture.scene.steps:
            if expected.get("do")!="actor": continue
            var actor := player._actors.get(StringName(expected.id)) as CutsceneActor
            check(actor!=null and actor.rig!=null,fixture.name+" actual actor/rig")
            if actor==null or actor.rig==null: continue
            check(actor.facing==int(expected.get("facing",1)) and actor.rig.facing==actor.facing,fixture.name+" rendered facing")
            var posture := actor.rig.animator as NpcAnimator
            var posed := posture.posture_ready(&"sit" if actor.pose==&"sit" else &"stand") if actor.pose in [&"sit",&"idle"] else true
            check(posed,fixture.name+" consumed posture")
            var world_to_canvas := actor.rig.get_global_transform_with_canvas()*actor.rig.global_transform.affine_inverse()
            var rect := get_viewport().get_final_transform()*world_to_canvas*actor.rig.visual_bounds()
            check(Rect2(Vector2.ZERO,Vector2(get_viewport().get_texture().get_size())).encloses(rect),fixture.name+" body inside viewport")
            actors.append({"id":String(actor.actor_id),"pose":String(actor.pose),"facing":actor.facing,"rig_facing":actor.rig.facing,
                "ground_y":actor.ground_y,"position":[actor.position.x,actor.position.y],"scale":actor.scale.x,
                "posture_ready":posed,"pixel_bounds":[rect.position.x,rect.position.y,rect.size.x,rect.size.y]})
        var saved := Capture.image(get_viewport()).save_png(out.path_join(fixture.name+".png"))==OK
        check(saved,fixture.name+" PNG save")
        records.append({"name":fixture.name,"quality":Settings.get_light_quality(),"actors":actors,"saved":saved})
        player.skip()
        while player.is_running(): await get_tree().process_frame
        player.queue_free()
        await get_tree().process_frame
    var file := FileAccess.open(out.path_join("stage-index.json"),FileAccess.WRITE)
    check(file!=null,"report open")
    if file!=null:
        file.store_string(JSON.stringify({"failures":failures,"records":records,"adapter":RenderingServer.get_video_adapter_name(),
            "scope":"Actual CutscenePlayer playback; arranged Rin poses use model scale 3.4 and diagnostic camera 0.72; Ali seat copies original scene/actor/seat_sag from ch2_t_s18_ticket. No Story results published."},"\t"));file.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit(1 if failures else 0)
