from pathlib import Path
import hashlib,json,os,subprocess,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg29-current')/(sys.argv[1] if len(sys.argv)>1 else 'stage')
out.mkdir(exist_ok=False);private=root/'work/bg29-current'
(private/'stage.gd').write_bytes((primary/'work/bg29-stage-observer.gd').read_bytes())
(private/'stage.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg29-current/stage.gd" id="1"]\n[node name="Probe" type="Node2D"]\nscript = ExtResource("1")\n')
paths=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg34-current/checks-restored/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for quality in ([1,2] if len(sys.argv)>2 and sys.argv[2]=='remaining' else [0,1,2]):
    folder=out/str(quality);folder.mkdir();env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg29-current/stage.tscn','--','--out='+str(folder),'--stage=ch1_pawnshop_front','--actor=rin','--scale=3.4','--quality='+str(quality)]
    for pose in ['idle','sit','dead','jump']:
        for facing in ['left','right']:command.append('--shot='+pose+'-'+facing+':320,300,1:320,'+('310' if pose=='jump' else '348')+':'+pose)
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    raw=(folder/'raw.log').read_bytes();row={'command':command,'exit':r.returncode,'source_held':before==snapshot(),'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode('utf8',errors='replace')[-1600:],flush=True)
    assert r.returncode==0 and row['script_errors']==0 and not row['engine_error'] and row['source_held']
    records=json.loads((folder/'stage-observations.json').read_text())
    assert len(records)==len(list(folder.glob('*.png')))==8
    assert all(x['quality']==quality and x['rig_present'] and x['ground_y']==348 and all(abs(s-3.4)<1e-6 for s in x['scale']) for x in records)
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'all_passed':True,'source_held':before==snapshot()},indent=2)+'\n')
