from pathlib import Path
import hashlib,json,os,subprocess,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg29-current')/(sys.argv[1] if len(sys.argv)>1 else 'native')
out.mkdir(exist_ok=False)
private=root/'work/bg29-current'
(private/'native.gd').write_bytes((primary/'work/bg29-native-probe.gd').read_bytes())
(private/'native.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg29-current/native.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg34-current/checks-restored/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for quality in ['low','medium','high']:
    for level,col in [('ch1_warehouse',70),('ch1_street',10)]:
        folder=out/(quality+'-'+level);folder.mkdir()
        env=os.environ.copy()
        for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg29-current/native.tscn','--','--out='+str(folder),'--level='+level,'--at='+str(col),'--quality='+quality]
        with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
        raw=(folder/'raw.log').read_bytes()
        row={'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot()}
        runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode('utf8',errors='replace')[-1800:],flush=True)
        assert r.returncode==0 and row['script_errors']==0 and not row['engine_error'] and row['source_held']
        report=json.loads((folder/'native-index.json').read_text())
        assert report['failures']==0 and len(report['rows'])==10
        assert all(x['same_pixels'] and x['in_view'] and x['quality']==['low','medium','high'].index(quality) for x in report['rows'])
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'all_passed':True,'source_held':before==snapshot()},indent=2)+'\n')
