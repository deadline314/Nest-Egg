from pathlib import Path
import hashlib,json,os,subprocess
root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg29-current/checks')
out.mkdir(exist_ok=False)
paths=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg34-current/checks-restored/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy();env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='4',LOG_DIR=str(out/'shards'),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(out/'private-profile'/k)
command=['C:/Program Files/Git/bin/bash.exe','-c','python3() { python "$@"; }; export -f python3; tools/run_tests_changed.sh 321d570afb0d776d7ab1cff39e91614ce70721ec']
with (out/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
raw=(out/'raw.log').read_bytes();after=snapshot()
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
report={'command':command,'exit':r.returncode,'source_held':before==after,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw}
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True);print(raw.decode('utf8',errors='replace')[-2400:],flush=True)
assert r.returncode==0 and report['source_held'] and report['script_errors']==0 and not report['engine_error']
