from pathlib import Path
import hashlib,json,os,subprocess,statistics,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg29-current')
def processes():
    raw=subprocess.check_output(['powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process -Filter \"Name LIKE 'Godot%'\" | Select-Object ProcessId,Name,CommandLine,KernelModeTime,UserModeTime) | ConvertTo-Json -Compress"]).decode('utf-8-sig').strip()
    rows=json.loads(raw) if raw else []
    if isinstance(rows,dict):rows=[rows]
    return [{'pid':r['ProcessId'],'name':r['Name'],'headless':'--headless' in (r['CommandLine'] or ''),'cpu_seconds':(int(r['KernelModeTime'])+int(r['UserModeTime']))/1e7} for r in rows]
shared_cpu=sys.argv[1:]==['--shared-cpu']
def acceptable(rows):return not rows or (shared_cpu and all(r['headless'] for r in rows))
assert acceptable(processes()),processes()
for phase in ['checks','native-final','stage-poses-final','motion-final']:assert (base/phase/'result.json').is_file(),phase
out=base/'performance';out.mkdir(exist_ok=False);private=root/'work/bg29-current'
(private/'performance.gd').write_bytes((primary/'work/bg29-performance-observer.gd').read_bytes())
(private/'performance.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg29-current/performance.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=json.loads((base/'checks/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for trial in range(2):
    idle=processes();assert acceptable(idle),idle
    folder=out/str(trial+1);folder.mkdir();env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg29-current/performance.tscn','--','--out='+str(folder),'--level=ch1_warehouse','--at=70','--quality=high','--mode='+('perf,reenter' if trial==0 else 'perf')]
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
    raw=(folder/'raw.log').read_bytes();report=json.loads((folder/'walls-index.json').read_text());perf=report['perf'];groups=perf['contact_samples']
    assert len(groups)==120 and all(len(g['frames_ms'])==45 and g['contacts']>=13 and g['rays']==g['contacts']*5 and not g['wall_suspended'] and g['quality']==2 for g in groups)
    ratios=[]
    for i in range(0,len(groups),2):
        pair={g['enabled']:statistics.median(g['frames_ms']) for g in groups[i:i+2]}
        ratios.append(pair[True]/pair[False])
    exact=statistics.median(ratios);assert abs(exact-perf['ratio_exact'])<1e-9
    idle_after=processes()
    row={'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'processes_before':idle,'processes_after':idle_after,'shared_cpu':shared_cpu,'quiet':not idle and not idle_after,'ratio_exact':exact,'raw_intervals':5400,'contacts':groups[0]['contacts'],'rays':groups[0]['rays'],'actors_before':perf['actors_before'],'actors_after':perf['actors_after']}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode('utf8',errors='replace')[-1400:],flush=True)
    assert r.returncode==0 and row['script_errors']==0 and not row['engine_error'] and row['source_held'] and acceptable(idle_after) and exact<=1.08
    assert row['actors_before']['valid'] and row['actors_after']['valid'] and report['failures']==0
    if trial==0:assert len(report['reenter']['nodes'])==10 and not report['reenter']['accumulates']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'all_passed':True,'source_held':before==snapshot()},indent=2)+'\n')
