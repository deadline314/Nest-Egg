from pathlib import Path
import hashlib, json, os, subprocess, sys

primary=Path('C:/Users/stanl/Github/Nest-Egg')
root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg29-current')
phase=sys.argv[1]
out=base/phase
out.mkdir(exist_ok=False)
private=root/'work/bg29-current'
(private/'redraw.gd').write_bytes((primary/'work/bg29-redraw-probe.gd').read_bytes())
(private/'redraw.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg29-current/redraw.gd" id="1"]\n[node name="Probe" type="Node2D"]\nscript = ExtResource("1")\n')
paths=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg34-current/checks-restored/source-after.json').read_text())
def snapshot(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy()
for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(out/'private-profile'/k)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg29-current/redraw.tscn','--','--out='+str(out)]
with (out/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
after=snapshot()
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
raw=(out/'raw.log').read_bytes()
report={'command':command,'exit':r.returncode,'source_held':before==after,'script_errors':raw.count(b'SCRIPT ERROR:')}
(out/'run.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
print(raw.decode('utf8',errors='replace')[-2200:],flush=True)
assert report['source_held'] and report['script_errors']==0
assert r.returncode==(1 if phase=='redraw-before' else 0)
