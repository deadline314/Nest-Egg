from pathlib import Path
import copy,hashlib,json,os,subprocess,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
out=Path('D:/NestEggVerification/evidence-20261117/bg29-current')/(sys.argv[1] if len(sys.argv)>1 else 'stage-poses');out.mkdir(exist_ok=False)
private=root/'work/bg29-current'
(private/'stage-poses.gd').write_bytes((primary/'work/bg29-stage-final.gd').read_bytes())
(private/'stage-poses.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg29-current/stage-poses.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
fixtures=[]
for pose in ['idle','sit','dead','jump']:
    for facing in [-1,1]:
        name=pose+('-left' if facing<0 else '-right')
        scene={'mode':'animated','steps':[{'do':'scene','id':'ch1_pawnshop_front','pos':[320,300],'zoom':.72,'fade':.25},
            {'do':'actor','id':'rin','kind':'rin','pos':[320,310 if pose=='jump' else 348],'facing':facing,'scale':3.4,'weapon':'','speaker':'rin','pose':pose},
            {'do':'say','speaker':'rin','text':'（接觸陰影檢查）'},{'do':'wait','time':60}]}
        fixtures.append({'name':name,'scene':scene})
author_path=root/'data/story/ch2_heron.json'
author=json.loads(author_path.read_text(encoding='utf-8'))['scenes']['ch2_t_s18_ticket']
stage=copy.deepcopy(next(x for x in author['steps'] if x.get('do')=='scene'))
actor=copy.deepcopy(next(x for x in author['steps'] if x.get('do')=='actor' and x.get('id')=='ali' and x.get('pose')=='sit'))
fixtures.append({'name':'ali-authored-seat','scene':{'mode':'animated','steps':[stage,actor,{'do':'say','speaker':'ali','text':'（接觸陰影檢查）'},{'do':'wait','time':60}]}})
(private/'stage-fixtures.json').write_text(json.dumps(fixtures,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(out/'stage-fixtures.json').write_bytes((private/'stage-fixtures.json').read_bytes())
(out/'authored-source.json').write_text(json.dumps({'path':'data/story/ch2_heron.json','sha256':hashlib.sha256(author_path.read_bytes()).hexdigest(),'scene':'ch2_t_s18_ticket','stage':stage,'actor':actor},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
paths=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg29-current/checks/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for q in [0,1,2]:
    folder=out/str(q);folder.mkdir();env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg29-current/stage-poses.tscn','--','--out='+str(folder),'--quality='+str(q)]
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    raw=(folder/'raw.log').read_bytes();row={'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot()}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode('utf8',errors='replace')[-1600:],flush=True)
    assert r.returncode==0 and row['script_errors']==0 and not row['engine_error'] and row['source_held']
    report=json.loads((folder/'stage-index.json').read_text());assert report['failures']==0 and len(report['records'])==len(list(folder.glob('*.png')))==9
    assert all(x['quality']==q and x['saved'] and len(x['actors'])==1 and x['actors'][0]['posture_ready'] and x['actors'][0]['facing']==x['actors'][0]['rig_facing'] for x in report['records'])
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'all_passed':True,'source_held':before==snapshot()},indent=2)+'\n')
