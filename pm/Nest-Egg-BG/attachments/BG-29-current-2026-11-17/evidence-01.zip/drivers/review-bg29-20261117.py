from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,hashlib,sys
base=Path('D:/NestEggVerification/evidence-20261117/bg29-current')
out=base/(sys.argv[1] if len(sys.argv)>1 else 'review');out.mkdir(exist_ok=False)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',18)
pages=[]
def page(name,items,columns=2,width=560):
    h=width*720//1280+30
    image=Image.new('RGB',(columns*width,((len(items)+columns-1)//columns)*h),(24,24,24))
    draw=ImageDraw.Draw(image)
    for i,(label,path) in enumerate(items):
        photo=Image.open(path).convert('RGB');assert photo.size==(1280,720)
        x=i%columns*width;y=i//columns*h
        image.paste(photo.resize((width,h-30)),(x,y+30));draw.text((x+5,y+5),label,font=font,fill='white')
    target=out/(name+'.png');image.save(target);pages.append(target.name)
for folder in sorted((base/'native-final').iterdir()):
    if not folder.is_dir():continue
    data=json.loads((folder/'native-index.json').read_text())
    assert len(data['rows'])==10 and data['failures']==0
    for half in range(2):
        items=[]
        for row in data['rows'][half*5:half*5+5]:
            label=row['label'];on=folder/(label+'-on.png');before=folder/(label+'-before.png')
            assert on.read_bytes()==before.read_bytes()
            for side in ['on','off']:items.append((label+' / '+side,folder/(label+'-'+side+'.png')))
        page(folder.name+'-'+str(half+1),items)
for q in [0,1,2]:
    folder=base/'stage-poses-final'/str(q)
    report=json.loads((folder/'stage-index.json').read_text())
    rows=report['records'];assert report['failures']==0 and len(rows)==9
    page('stage-'+str(q),[(row['name'],folder/(row['name']+'.png')) for row in rows],3,430)
for folder in sorted((base/'motion-final').iterdir()):
    if not folder.is_dir():continue
    report=json.loads((folder/'motion-index.json').read_text())
    assert report['airborne'] and report['landed'] and len(report['rows'])==240
    page('motion-'+folder.name,[(str(n),folder/('motion-%03d.png'%n)) for n in report['image_frames']],3,430)
    rows=report['rows']
    print(folder.name,'feetY',min(r['feet'][1] for r in rows),max(r['feet'][1] for r in rows),'facing',sorted(set(r['facing'] for r in rows)), 'casts',sum(r['cast'] for r in rows))
(out/'pages.json').write_text(json.dumps(pages,indent=2)+'\n')
print(json.dumps(pages),flush=True)
