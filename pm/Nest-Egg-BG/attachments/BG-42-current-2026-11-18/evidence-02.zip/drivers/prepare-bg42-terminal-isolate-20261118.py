from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
(root/'probe-terminal-isolate.gd').write_text('''extends "res://work/bg42-current/probe-boost.gd"
func _measure(level: Level, world: Rect2) -> Dictionary:
    _active_cell55 = _cell55
    _cell55 += 1
    var terminal: PropNode
    for node in _authored42:
        if node.data.id==&"revival_lounge__commission_terminal": terminal=node
    assert(terminal!=null)
    var records: Array[Dictionary] = []
    for mode in ["before","body-only","glow-only","full","nothing","restore"]:
        await _variant42(level,mode in ["before","restore"])
        terminal.visible = mode not in ["before","restore","nothing"]
        for sprite in terminal.get_children():
            if sprite is Sprite2D: sprite.visible = mode!="body-only" if sprite==terminal._glow_sprite else mode!="glow-only"
        await RenderingServer.frame_post_draw
        await RenderingServer.frame_post_draw
        var record := await _capture55(level,world,mode)
        records.append(record)
        print("BG42_ISOLATE ",JSON.stringify({"cell":_active_cell55,"mode":mode,"player":record.get("player",{})}))
    assert(records[0].raw_sha256==records[-1].raw_sha256)
    return {"bg42_isolate":{"records":records,"scope":"Individual body/glow visibility isolation; calibration only, not acceptance"},"passed":true}
''')
(root/'probe-terminal-isolate.tscn').write_bytes((root/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-terminal-isolate.gd'))
s=(p/'run-bg42-terminal-glow-20261118.py').read_text().replace("out=base/'terminal-glow-1'","out=base/'terminal-isolate'").replace('bg42-current/probe-terminal.tscn','bg42-current/probe-terminal-isolate.tscn').replace("'--tag=bg42'","'--tag=bg42','--cells=0:1,0:2'")
start=s.index('            index=json.loads(');end=s.index('    all_passed=True',start);s=s[:start]+s[end:]
(p/'run-bg42-terminal-isolate-20261118.py').write_text(s)
