from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
s=(root/'probe-lounge-vignette.gd').read_text().replace('candidate.vignette = 0.31','candidate.contrast = 1.05').replace('record["vignette"] = level._lighting.current.vignette','record["tone_contrast"] = level._lighting.current.contrast').replace('record["shader_vignette"] = level._post._material.get_shader_parameter(&"vignette")','record["shader_contrast"] = level._post._material.get_shader_parameter(&"contrast")')
(root/'probe-lounge-contrast.gd').write_text(s);(root/'probe-lounge-contrast.tscn').write_bytes((root/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-lounge-contrast.gd'))
driver=(p/'run-bg42-terminal-glow-20261118.py').read_text().replace("out=base/'terminal-glow-1'","out=base/'lounge-contrast-105'").replace('bg42-current/probe-terminal.tscn','bg42-current/probe-lounge-contrast.tscn')
(p/'run-bg42-lounge-contrast-20261118.py').write_text(driver)
print('Memory-only existing lounge tone contrast1.04->1.05. No vignette/fill/energy/cap/art/size/position/glow change. Exact HDR per-point original gates, actual shader uniform recorded.')
