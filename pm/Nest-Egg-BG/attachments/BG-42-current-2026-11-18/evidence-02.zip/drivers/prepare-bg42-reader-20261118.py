from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');s=(p/'verify_bg42_counterfactual_v2.py').read_text()
start=s.index(' receipt=json.loads(');end=s.index(' observations=[]',start)
s=s[:start]+''' receipts=json.loads((folder.parent/'runs.json').read_bytes())
 receipt=next(r for r in receipts if r['name']==folder.name)
 assert receipt['exit']==receipt['script_errors']==0 and not receipt['engine_error'] and receipt['source_held']
 assert 'gpu_lock.py' in receipt['command'][1] and '--rendering-method' in receipt['command']
 assert json.loads((folder.parent/'source-before.json').read_bytes())==json.loads((folder.parent/'source-after.json').read_bytes())
'''+s[end:]
old="assert abs(r['character_floor']-.5)<1e-6 and abs(r['enemy_fill_scale']-1)<1e-6";assert s.count(old)==1
s=s.replace(old,"assert abs(r['character_floor']-.5)<1e-6 and abs(r['enemy_fill_scale']-1.2)<1e-6")
s=s.replace('Current held geometry with original BG42 prop delta and only proposed local office profile; unchanged thresholds; no head exposure or performance acceptance','Current c38 geometry with original BG42 prop delta and office-only enemy gain1.0->1.2; strict exact HDR per-point nondecrease and original thresholds; no PNG-equivalence substitution')
(p/'verify_bg42_current_20261118.py').write_text(s)
