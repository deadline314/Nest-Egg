from pathlib import Path
import json
from verify_bg42_current_20261118 import verify
base=Path('D:/NestEggVerification/evidence-20261117/bg42-current/held-boost');summaries=[]
for folder in sorted(base.iterdir()):
    if not folder.is_dir():continue
    result=verify(folder);(folder/'independent.json').write_text(json.dumps(result,indent=2)+'\n')
    row={k:v for k,v in result.items() if k not in ['observations','decreases']};row.update(case=folder.name,decreases=len(result['decreases']));summaries.append(row);print(json.dumps(row),flush=True)
(base/'independent-summary.json').write_text(json.dumps({'passed':all(r['absolute_pass'] and r['no_worse'] for r in summaries),'cases':summaries},indent=2)+'\n')
