from pathlib import Path
import json
base=Path('D:/NestEggVerification/evidence-20261117/bg42-current')
for phase in ['held-reproduction','held-other','held-boost','terminal-glow-1']:
    for path in (base/phase).glob('*/*/bg42-index.json'):
        data=json.loads(path.read_text());negatives=[];enemies=[]
        for shot in data['shots']:
            a,b=shot['bg42']['records'][0],shot['bg42']['records'][-1]
            delta={k:b['player'][k]-a['player'][k] for k in ['contrast','edge_contrast']} if 'player' in a else {}
            if any(v<0 for v in delta.values()):negatives.append({'cell':[shot['column'],shot['row']],'deltas':delta})
            for left,right in zip(a['enemies'],b['enemies']):enemies.append({'cell':[shot['column'],shot['row']],'id':right['id'],'feet':right['feet'],'contrast':[left['contrast'],right['contrast']],'files':b['files'],'scale':b['enemy_fill_scale']})
        print(json.dumps({'case':path.parent.parent.name,'negative_cells':negatives,'enemies':enemies},ensure_ascii=False))
