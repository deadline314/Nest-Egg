from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');s=(p/'run-bg41-checks-20261118.py').read_text().replace('bg41-current/checks','bg42-current/checks').replace('bg41-current/fill-green/source-after.json','bg42-current/source-boost.json').replace('66b36fe092381d7ab8596cf3818021d87f00e162','c38a42e0fa2bf2a74ef1c1e67d618094a015d829')
assert 'bg41-current' not in s
(p/'run-bg42-checks-20261118.py').write_text(s)
