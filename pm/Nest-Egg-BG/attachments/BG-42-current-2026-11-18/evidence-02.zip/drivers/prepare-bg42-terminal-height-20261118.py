from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
s=(root/'probe-terminal.gd').read_text().replace('_terminal_reference.glow_intensity = 1.0','_terminal_reference.size = Vector2(22.0,57.0)').replace('"data":prop.data.glow_intensity','"size":[prop.data.size.x,prop.data.size.y],"data":prop.data.glow_intensity')
(root/'probe-terminal-height.gd').write_text(s);(root/'probe-terminal-height.tscn').write_bytes((root/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-terminal-height.gd'))
s=(p/'run-bg42-terminal-glow-20261118.py').read_text().replace("out=base/'terminal-glow-1'","out=base/'terminal-height-57'").replace('bg42-current/probe-terminal.tscn','bg42-current/probe-terminal-height.tscn')
(p/'run-bg42-terminal-height-20261118.py').write_text(s)
print('Memory-only uniform terminal size22x57 (1.9m), ground retained at320; original1.6HDR glow and x255, no production or recipe edits. Tests taller body/bloom origin, not metric threshold changes.')
