from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
s=(root/'probe-lounge-fill.gd').read_text().replace('candidate.character_floor = 0.625','candidate.shadow_tint = Color(original.shadow_tint*1.01,original.shadow_tint.a)\n\t\tcandidate.highlight_tint = Color(original.highlight_tint*1.01,original.highlight_tint.a)')
needle='\treturn record\n\n\nfunc _measure';assert s.count(needle)==1
s=s.replace(needle,'\trecord["tone_shadow"] = level._lighting.current.shadow_tint\n\trecord["tone_highlight"] = level._lighting.current.highlight_tint\n\trecord["shader_shadow"] = level._post._material.get_shader_parameter(&"shadow_tint")\n\trecord["shader_highlight"] = level._post._material.get_shader_parameter(&"highlight_tint")\n\trecord["player_light_energy"] = LightKit.player_light_energy\n\trecord["character_light_cap"] = LightKit.character_light_cap\n'+needle)
(root/'probe-lounge-tone-gain.gd').write_text(s);(root/'probe-lounge-tone-gain.tscn').write_bytes((root/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-lounge-tone-gain.gd'))
driver=(p/'run-bg42-terminal-glow-20261118.py').read_text().replace("out=base/'terminal-glow-1'","out=base/'lounge-tone-gain-101'").replace('bg42-current/probe-terminal.tscn','bg42-current/probe-lounge-tone-gain.tscn')
(p/'run-bg42-lounge-tone-gain-20261118.py').write_text(driver)
print('Memory-only existing lounge shadow/highlight RGB gain1.01, alpha preserved; same hues, original contrast1.04/vignette.30/fill/lights/terrain/terminal. Actual shader readback and strict HDR per-point gates; no product changes.')
