from pathlib import Path
import hashlib,json,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg42-current');base.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()=='c38a42e0fa2bf2a74ef1c1e67d618094a015d829'
private=root/'work/bg42-current';private.mkdir(exist_ok=False)
prior=primary/'pm/Nest-Egg-BG/attachments/BG-42-local-lighting-2026-11-12/native-producer'
for p in prior.iterdir():
    if p.suffix in ['.gd','.tscn','.tres','.json']:
        original=p.read_bytes();(base/('prior-'+p.name)).write_bytes(original)
        (private/p.name).write_bytes(original.replace(b'res://work/bg42-counterfactual-v2/',b'res://work/bg42-current/'))
for ident in ['ledger_front','ledger_office','lounge_front']:
    for suffix in ['.tres','_map.json']:
        rel='data/levels/ch2_'+ident+suffix
        (base/('current-ch2_'+ident+suffix)).write_bytes((root/rel).read_bytes())
source=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg41-current/checks/source-after.json').read_text());assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in source.items())
(base/'source-base.json').write_text(json.dumps(source,indent=2)+'\n')
progress=primary/'work/queue-20261117-progress.json';state=json.loads(progress.read_text(encoding='utf-8'))
state['branch']='codex/ticket-work-20261118-bg42';state['published']['BG41-complete']='c38a42e0fa2bf2a74ef1c1e67d618094a015d829'
state['BG41_completed']={'commit':'c38a42e0fa2bf2a74ef1c1e67d618094a015d829','paths':31,'tests':'39groups58083checks0new0known447s;32realmaps+portal+stage0error0warn;assetsOK','native':'622PNG/36processes;512tour42paired5medianregionalnondrop(7individualplayerdeclines);real5enemies13fixturepoints832original16cumrecords currentminlow.968302/high1.072109;other3marketconsumers12seededjobs40PNG640recordsALLgates;14stateNPCtalk/portalrequests/reentry +4guardwall','packet':'2ZIP61184888B1040logical781physical;independentreaderpass+actualbyte128flipreject;18publicpagesallviewed','limitations':'Preserve original fixtures-v2 outerfailed extra16meanplayeredge nondrop (marketlowtiny .000654decline); main5medianregionalcontractpasses. Unseededlegacycargo0.444outsidechangedzone retained;seed41001812reproduciblejobsallpass. InitialSceneTourAIre-enabled byVisibleOnScreenEnabler diagnosis fixedwithhouseflag/restoresbothpriorvalues. NOmainphysicalwholegame/head2%/performanceclaims.','git':'main/origin/HEADc38bothStanley,localbg41branchdeleted,newbranchbg42','verification':'Detachedadvanced66->c38source10088/private375 bytepreservedZIP,originalaudioPLACEMENTSdependencyrestored,noimport','remaining_open':69}
state['BG42_active']={'base':'c38a42e0fa2bf2a74ef1c1e67d618094a015d829','state':'Reusing committed 20261112 counterfactual nine-state A/A+B/restore producer against current source. Original BG42 strict per-point HDR nondrop including tiny negatives remains mandatory; do not substitute regional minimum or PNG equivalence. No production change yet.','prior':'Commit4 ba86d188d localofficealreadycharacterfloor.5 enemy1.0; original e676a2d96 art4. Prior5microHDRnegative1ULP actualPNGsame stillstrictfalse; preserved. Copied archive native producer into Dwork/bg42-current, path-literalonly replacement, deltaexactcurrentpropsvalidatenext.','next':'run two front low/high reproduction first with current heldscene,original9states/thresholds, actualHDR. Then fix minimal product if still needed, all3levels and fullbeforeafterflat normal screenshots/native interactionobjectQA. Need no identity/probes/culling/geometry weakening.'}
progress.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Published BG41 preserved; BG42 strict diagnostic uses committed house producer, current exact10088sources, no product change.')
