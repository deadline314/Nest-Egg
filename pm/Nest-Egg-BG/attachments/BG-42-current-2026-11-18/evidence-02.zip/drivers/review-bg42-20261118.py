from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
base=Path('D:/NestEggVerification/evidence-20261117/bg42-current');out=base/'review';out.mkdir(exist_ok=True);font=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc',14)
for phase,key in [('formal-final','bg42'),('flat-final','bg42_flat')]:
    for level in ['ch2_ledger_front','ch2_ledger_office','ch2_lounge_front']:
        for quality in ['low','high']:
            folder=base/phase/(level+'-'+quality)/level;path=folder/'bg42-index.json'
            if not path.exists():continue
            data=json.loads(path.read_text());columns=int(data['columns']);rows=int(data['rows'])
            sheet=Image.new('RGB',(columns*320,36+rows*390),'#101722');draw=ImageDraw.Draw(sheet)
            draw.text((7,6),f'{phase} / {level} / {quality} | each cell: BEFORE top, AFTER bottom | native640x360 shown320x180',font=font,fill='white')
            for shot in data['shots']:
                c=int(shot['column']);r=int(shot['row']);records=shot[key]['records']
                a=records[0];b=records[-1] if phase=='formal-final' else records[1]
                for si,(label,record) in enumerate([('before',a),('after',b)]):
                    image=Image.open(folder/record['files']['png']);assert image.size==(640,360)
                    x=c*320;y=36+r*390+si*195;sheet.paste(image.convert('RGB').resize((320,180)),(x,y))
                    draw.text((x+3,y+180),f'{label} c{c} r{r}',font=font,fill='white')
            sheet.save(out/(phase+'-'+level+'-'+quality+'.png'))
for quality in ['low','high']:
    folder=base/'states-final'/quality
    if not (folder/'states.json').exists():continue
    sheet=Image.new('RGB',(1280,800),'#101722');draw=ImageDraw.Draw(sheet)
    for i,row in enumerate(json.loads((folder/'states.json').read_text())['rows']):
        image=Image.open(folder/(row['name']+'.png'));assert image.size==(640,360)
        x=i%3*426;y=i//3*266;sheet.paste(image.resize((426,240)),(x,y));draw.text((x+4,y+242),quality+' / '+row['name'],font=font,fill='white')
    sheet.save(out/('states-'+quality+'.png'))
for level,cell in [('ch2_ledger_office',[2,2]),('ch2_lounge_front',[0,2])]:
    for quality in ['low','high']:
        folder=base/'formal-final'/(level+'-'+quality)/level
        if not (folder/'bg42-index.json').exists():continue
        data=json.loads((folder/'bg42-index.json').read_text());shot=next(s for s in data['shots'] if [s['column'],s['row']]==cell)
        records=shot['bg42']['records'];sheet=Image.new('RGB',(1280,780),'#101722');draw=ImageDraw.Draw(sheet)
        for i,label in enumerate(['A0','product-old','reference-new','authored-final']):
            record=next(r for r in records if r['label']==label);im=Image.open(folder/record['files']['png']);x=i%2*640;y=i//2*390;sheet.paste(im,(x,y));draw.text((x+4,y+362),quality+' / '+level+' / '+label,font=font,fill='white')
        sheet.save(out/('factors-'+level+'-'+quality+'.png'))
print(json.dumps({'pages':[p.name for p in sorted(out.glob('*.png'))]}))
