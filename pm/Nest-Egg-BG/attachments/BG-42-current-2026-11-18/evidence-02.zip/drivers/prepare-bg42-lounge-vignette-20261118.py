from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
s=(root/'probe-lounge-fill.gd').read_text().replace('candidate.character_floor = 0.625','candidate.vignette = 0.31')
needle='\treturn record\n\n\nfunc _measure'
assert s.count(needle)==1
s=s.replace(needle,'\trecord["vignette"] = level._lighting.current.vignette\n\trecord["shader_vignette"] = level._post._material.get_shader_parameter(&"vignette")\n\trecord["player_light_energy"] = LightKit.player_light_energy\n\trecord["character_light_cap"] = LightKit.character_light_cap\n'+needle)
(root/'probe-lounge-vignette.gd').write_text(s);(root/'probe-lounge-vignette.tscn').write_bytes((root/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-lounge-vignette.gd'))
driver=(p/'run-bg42-terminal-glow-20261118.py').read_text().replace("out=base/'terminal-glow-1'","out=base/'lounge-vignette-31-v2'").replace('bg42-current/probe-terminal.tscn','bg42-current/probe-lounge-vignette.tscn')
(p/'run-bg42-lounge-vignette-20261118.py').write_text(driver)
print('Memory-only existing lounge vignette.30->.31; physical rendered focus around playable center, no fill/energy/cap/art/size/position/glow changes. Original exact HDR per-point gates; actual value/readback stored.')
