from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');s=(p/'verify_bg42_current_20261118.py').read_text()
s=s.replace('raster,section,verify_owners','raster,section,verify_owners,transform_values')
needle="    for kind,visible in [('added',not REFERENCE[i]),('removed',REFERENCE[i])]:";assert s.count(needle)==1
extra='''    assert r['character_fill']==original['character_fill']
    assert r['player_light_energy']==original['player_light_energy'] and r['character_light_cap']==original['character_light_cap']
    for color_key,shader_key in [('tone_shadow','shader_shadow'),('tone_highlight','shader_highlight')]:
     base_color=transform_values(original[color_key]);actual_color=transform_values(r[color_key]);shader_color=transform_values(r[shader_key])
     gain=1.01 if CANDIDATE[i] and data['level']=='ch2_lounge_front' else 1.0
     assert len(base_color)==len(actual_color)==4 and len(shader_color) in [3,4]
     assert np.isfinite(base_color+actual_color+shader_color).all() and actual_color[3]==base_color[3]
     assert np.max(np.abs(np.array(actual_color[:3])-np.array(base_color[:3])*gain))<1e-6
     assert np.max(np.abs(np.array(actual_color[:3])-np.array(shader_color[:3])))<1e-6
'''
s=s.replace(needle,extra+needle).replace('office-only enemy gain1.0->1.2','office enemy gain1.0->1.2 and lounge tone RGB gain1.01, with unchanged player fill/light cap/energy')
(p/'verify_bg42_final_20261118.py').write_text(s)
