from pathlib import Path
import json
from verify_bg42_final_20261118 import verify
base=Path('D:/NestEggVerification/evidence-20261117/bg42-current/formal-final');rows=[]
for folder in sorted(base.iterdir()):
    if not folder.is_dir():continue
    result=verify(folder);(folder/'independent.json').write_text(json.dumps(result,indent=2)+'\n')
    minima={}
    for key in ['player','edge']:
        minima[key]=[min(o[side][key] for o in result['observations'] if key in o[side]) for side in ['baseline','final']]
    values=[[e['contrast'] for o in result['observations'] for e in o[side]['enemies']] for side in ['baseline','final']]
    if all(values):minima['enemy']=[min(a) for a in values]
    row={'name':folder.name,'absolute_pass':result['absolute_pass'],'strict_nondrop':result['no_worse'],'cells':result['cells'],'standable':result['standable'],'enemy_observations':result['enemy_observations'],'minima':minima};rows.append(row);print(json.dumps(row),flush=True)
assert len(rows)==6 and all(r['absolute_pass'] and r['strict_nondrop'] for r in rows)
(base/'independent-summary.json').write_text(json.dumps({'passed':True,'cells':sum(r['cells'] for r in rows),'standable':sum(r['standable'] for r in rows),'rows':rows},indent=2)+'\n')
