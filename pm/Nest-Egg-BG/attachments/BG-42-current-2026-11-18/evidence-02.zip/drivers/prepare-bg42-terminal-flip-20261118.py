from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
(root/'probe-terminal-flip.gd').write_text('''extends "res://work/bg42-current/probe-boost.gd"
func _ready() -> void:
    super._ready()
    _delta42["ch2_lounge_front"].added[0]["flip"] = true
func _settle(frames: int) -> void:
    await super._settle(frames)
    if is_instance_valid(_held55):
        for prop in _authored42:
            if prop.data.id==&"revival_lounge__commission_terminal":
                prop.flip = true
                for sprite in prop.get_children():
                    if sprite is Sprite2D: prop._apply_flip(sprite)
func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
    var record := await super._capture55(level,world,label)
    record["terminal_flip"] = []
    for prop in _authored42:
        if prop.data.id==&"revival_lounge__commission_terminal":
            var flags: Array[bool] = []
            for sprite in prop.get_children():
                if sprite is Sprite2D: flags.append(sprite.flip_h)
            record["terminal_flip"].append({"flip":prop.flip,"sprite_flip_h":flags,"size":[prop.data.size.x,prop.data.size.y],"world":[prop.position.x,prop.position.y]})
    return record
''')
(root/'probe-terminal-flip.tscn').write_bytes((root/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-terminal-flip.gd'))
s=(p/'run-bg42-terminal-glow-20261118.py').read_text().replace("out=base/'terminal-glow-1'","out=base/'terminal-flip'").replace('bg42-current/probe-terminal.tscn','bg42-current/probe-terminal-flip.tscn')
(p/'run-bg42-terminal-flip-20261118.py').write_text(s)
