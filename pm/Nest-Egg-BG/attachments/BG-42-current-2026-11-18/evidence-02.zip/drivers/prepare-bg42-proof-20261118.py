from pathlib import Path
import hashlib,json,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg42-current');delta=json.loads((root/'work/bg42-current/prop-delta.json').read_text())
origin='e676a2d96b78873860afad8a0d3aeada8f369eb0';parent=subprocess.check_output(['git','rev-parse',origin+'^'],cwd=primary).decode().strip();proof=[]
for level,change in delta.items():
    rel='data/levels/'+level+'_map.json';old=subprocess.check_output(['git','show',parent+':'+rel],cwd=primary);authored=subprocess.check_output(['git','show',origin+':'+rel],cwd=primary);now=(root/rel).read_bytes()
    before=json.loads(old);then=json.loads(authored);current=json.loads(now)
    assert all(p in before['props'] for p in change['removed']) and all(p in then['props'] for p in change['added']) and all(p in current['props'] for p in change['added'])
    (base/(level+'-historical-before-map.json')).write_bytes(old);(base/(level+'-original-authored-map.json')).write_bytes(authored)
    proof.append({'level':level,'origin':origin,'parent':parent,'removed':change['removed'],'added':change['added'],'current_non_ticket_props_preserved':True,'old_sha256':hashlib.sha256(old).hexdigest(),'original_authored_sha256':hashlib.sha256(authored).hexdigest(),'current_sha256':hashlib.sha256(now).hexdigest(),'scope':'Original ticket delta only, all subsequent unrelated props/current terrain/actors/camera preserved. Published c38 office/loungeroom lighting is baseline; whole historical checkout is not claimed.'})
(base/'baseline-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cfg=json.loads((root/'assets_src/pipeline/scene_props.json').read_text(encoding='utf-8'));ids={'yong_hideout__isolation_box','yong_hideout__isolation_diagram','yong_hideout__ledger_cabinet','revival_lounge__commission_terminal'};props=[p for p in cfg['props'] if p['id'] in ids]
assert len(props)==4 and {p['seed'] for p in props}=={7401,7412,7403,7404}
(base/'pipeline-extract.json').write_text(json.dumps({'styles':cfg['styles'],'defaults':cfg['defaults'],'props':props},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'levels':len(proof),'original_parent':parent,'props':len(props),'seeds':sorted(p['seed'] for p in props)}))
