from pathlib import Path
import hashlib,json
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg42-current');private=root/'work/bg42-current'
rel='data/lighting/lounge_front.tres';old=(root/rel).read_bytes();new=(primary/rel).read_bytes()
expected=old.replace(b'shadow_tint = Color(0.95,0.9,1.1,1)',b'shadow_tint = Color(0.9595,0.909,1.111,1)').replace(b'highlight_tint = Color(1.05,1.0,0.97,1)',b'highlight_tint = Color(1.0605,1.01,0.9797,1)')
assert new==expected and new!=old
(base/'lounge_front-before.tres').write_bytes(old);(private/'lounge_front-before.tres').write_bytes(old);(root/rel).write_bytes(new)
paths=json.loads((base/'source-base.json').read_text());current={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
assert set(p for p in paths if paths[p]!=current[p])=={rel,'data/lighting/ledger_office_interior.tres'}
for r in [rel,'data/lighting/ledger_office_interior.tres']:assert (root/r).read_bytes()==(primary/r).read_bytes()
(base/'source-final.json').write_text(json.dumps(current,indent=2)+'\n')
s=(private/'probe-boost.gd').read_text();needle='\tassert(candidate != null and candidate.validate().is_empty())';assert s.count(needle)==1
s=s.replace(needle,'\telif str(level.data.id) == "ch2_lounge_front":\n\t\toriginal = load("res://work/bg42-current/lounge_front-before.tres") as LightingProfile\n\t\tcandidate = load("res://data/lighting/lounge_front.tres") as LightingProfile\n'+needle)
needle='\treturn record\n\n\nfunc _measure';assert s.count(needle)==1
s=s.replace(needle,'\trecord["tone_shadow"] = level._lighting.current.shadow_tint\n\trecord["tone_highlight"] = level._lighting.current.highlight_tint\n\trecord["shader_shadow"] = level._post._material.get_shader_parameter(&"shadow_tint")\n\trecord["shader_highlight"] = level._post._material.get_shader_parameter(&"highlight_tint")\n\trecord["player_light_energy"] = LightKit.player_light_energy\n\trecord["character_light_cap"] = LightKit.character_light_cap\n'+needle)
s=s.replace('original BG42 prop delta and local office profile; current held geometry/runtime; no full historical checkout','original BG42 prop delta, office enemy gain and lounge tone gain; current held geometry/runtime; no full historical checkout')
(private/'probe-final.gd').write_text(s);(private/'probe-final.tscn').write_bytes((private/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-final.gd'))
driver=(primary/'work/run-bg42-held-boost-20261118.py').read_text().replace("out=base/'held-boost'","out=base/'formal-final'").replace("base/'source-boost.json'","base/'source-final.json'").replace('bg42-current/probe-boost.tscn','bg42-current/probe-final.tscn').replace('print(json.dumps(row),flush=True)','print(json.dumps({k:v for k,v in row.items() if k!="command"}),flush=True)')
needle='            print(json.dumps({\'name\':case,\'cells\':len(observations),\'strict_negative_cells\':[v for v in observations if not v[\'strict_nondrop\']]}),flush=True)';assert driver.count(needle)==1
driver=driver.replace(needle,needle+'\n            assert all(v["strict_nondrop"] for v in observations), "Original exact per-point HDR nondecrease failed"')
(primary/'work/run-bg42-final-20261118.py').write_text(driver)
for src,dst,old_out,new_out in [('run-bg42-flat-20261118.py','run-bg42-flat-final-20261118.py',"out=base/'flat'","out=base/'flat-final'"),('run-bg42-state-20261118.py','run-bg42-state-final-20261118.py',"out=base/'states'","out=base/'states-final'")]:
    source=(primary/'work'/src).read_text().replace(old_out,new_out).replace("base/'source-boost.json'","base/'source-final.json'").replace('print(json.dumps(row),flush=True)','print(json.dumps({k:v for k,v in row.items() if k!="command"}),flush=True)')
    (primary/'work'/dst).write_text(source)
source=(primary/'work/run-bg42-checks-20261118.py').read_text().replace('bg42-current/checks','bg42-current/checks-final').replace('bg42-current/source-boost.json','bg42-current/source-final.json')
(primary/'work/run-bg42-checks-final-20261118.py').write_text(source)
print('Selected final: exactly two existing lighting resources, three scalar/color fields total;10088 sources; no new material/audio/art/maps/framework. Formal driver enforces strict original per-point nondrop before success.')
