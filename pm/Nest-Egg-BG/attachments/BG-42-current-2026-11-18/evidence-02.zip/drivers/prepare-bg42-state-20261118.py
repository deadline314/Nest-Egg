from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117');private=root/'work/bg42-current'
(private/'state-core.gd').write_bytes((root/'work/bg41-current/state.gd').read_bytes())
s=(p/'run-bg41-state-20261118.py').read_text().replace('bg41-current','bg42-current').replace("out=base/'states-v3'","out=base/'states'").replace('work/bg41-state-20261118.gd','work/bg42-state-20261118.gd').replace("base/'fill-green/source-after.json'","base/'source-boost.json'").replace("len(states['rows'])==7","len(states['rows'])==5").replace("len(list(folder.glob('*.png')))==7","len(list(folder.glob('*.png')))==5").replace("assert states['actual_lever_talk'] and len(states['routes'])==2","assert states['actual_npc_talks'] and states['ledger_taken'] and states['ledger_owned'] and states['audit_submitted']")
(p/'run-bg42-state-20261118.py').write_text(s)
