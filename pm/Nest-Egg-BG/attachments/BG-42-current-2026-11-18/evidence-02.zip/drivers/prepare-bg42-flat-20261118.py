from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');private=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
(private/'flat.gd').write_bytes((p/'bg42-flat-20261118.gd').read_bytes());(private/'flat.tscn').write_bytes((private/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/flat.gd'))
s=(p/'run-bg42-held-boost-20261118.py').read_text().replace("out=base/'held-boost'","out=base/'flat'").replace('bg42-current/probe-boost.tscn','bg42-current/flat.tscn').replace("'--tag=bg42'","'--tag=bg42','--flat'")
start=s.index("            index=json.loads(");end=s.index("    all_passed=True",start)
s=s[:start]+s[end:];(p/'run-bg42-flat-20261118.py').write_text(s)
