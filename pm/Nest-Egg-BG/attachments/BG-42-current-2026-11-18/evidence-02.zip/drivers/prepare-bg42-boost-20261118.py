from pathlib import Path
import hashlib,json
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg42-current');private=root/'work/bg42-current'
rel='data/lighting/ledger_office_interior.tres';old=(root/rel).read_bytes();new=(primary/rel).read_bytes()
assert b'enemy_fill_scale = 1.0' in old and new==old.replace(b'enemy_fill_scale = 1.0',b'enemy_fill_scale = 1.2')
assert old==(private/'ledger_office_interior.tres').read_bytes()
(base/'ledger_office_interior-before.tres').write_bytes(old);(root/rel).write_bytes(new)
paths=json.loads((base/'source-base.json').read_text());current={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths};assert [p for p in paths if paths[p]!=current[p]]==[rel]
(base/'source-boost.json').write_text(json.dumps(current,indent=2)+'\n')
source=(private/'probe.gd').read_text();needle='candidate = load("res://work/bg42-current/ledger_office_interior.tres") as LightingProfile';assert source.count(needle)==1
source=source.replace(needle,'original = load("res://work/bg42-current/ledger_office_interior.tres") as LightingProfile\n\t\tcandidate = load("res://data/lighting/ledger_office_interior.tres") as LightingProfile')
(private/'probe-boost.gd').write_text(source);(private/'probe-boost.tscn').write_bytes((private/'probe.tscn').read_bytes().replace(b'bg42-current/probe.gd',b'bg42-current/probe-boost.gd'))
driver=(primary/'work/run-bg42-held-20261118.py').read_text().replace("out=base/'held-reproduction'","out=base/'held-boost'").replace("base/'source-base.json'","base/'source-boost.json'").replace("for level in ['ch2_ledger_front']:","for level in ['ch2_ledger_front','ch2_ledger_office','ch2_lounge_front']:").replace('bg42-current/probe.tscn','bg42-current/probe-boost.tscn')
(primary/'work/run-bg42-held-boost-20261118.py').write_text(driver)
print('Exactly one product field changed: office-only enemy fill1.0->1.2. Immutable previous .5/1.0 profile retained; nine-state baseline oldprops/oldgain versus newprops/currentgain, original strict thresholds.')
