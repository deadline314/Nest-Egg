from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
(root/'probe-terminal-height-shift.gd').write_text('''extends "res://work/bg42-current/probe-terminal-height.gd"
func _ready() -> void:
    super._ready()
    _delta42["ch2_lounge_front"].added[0]["dx"] = 12
func _settle(frames: int) -> void:
    await super._settle(frames)
    if is_instance_valid(_held55):
        for prop in _authored42:
            if prop.data.id==&"revival_lounge__commission_terminal": prop.position.x = 268.0
''')
(root/'probe-terminal-height-shift.tscn').write_bytes((root/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-terminal-height-shift.gd'))
s=(p/'run-bg42-terminal-glow-20261118.py').read_text().replace("out=base/'terminal-glow-1'","out=base/'terminal-height-shift'").replace('bg42-current/probe-terminal.tscn','bg42-current/probe-terminal-height-shift.tscn')
(p/'run-bg42-terminal-height-shift-20261118.py').write_text(s)
