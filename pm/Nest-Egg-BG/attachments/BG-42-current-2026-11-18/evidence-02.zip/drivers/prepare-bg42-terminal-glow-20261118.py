from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
source='''extends "res://work/bg42-current/probe-boost.gd"
var _terminal_reference: PropData
func _ready() -> void:
    _terminal_reference = load("res://data/environment/scene_props/revival_lounge/revival_lounge__commission_terminal.tres") as PropData
    _terminal_reference.glow_intensity = 1.0
    super._ready()
func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
    var record := await super._capture55(level,world,label)
    record["terminal_glow"] = []
    for prop in level._world.get_children():
        if prop is PropNode and prop.data.id==&"revival_lounge__commission_terminal":
            record["terminal_glow"].append({"data":prop.data.glow_intensity,"visible":prop.is_visible_in_tree(),"color":prop._glow_sprite.self_modulate.to_html()})
    return record
'''
(root/'probe-terminal.gd').write_text(source);(root/'probe-terminal.tscn').write_bytes((root/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-terminal.gd'))
s=(p/'run-bg42-held-boost-20261118.py').read_text().replace("out=base/'held-boost'","out=base/'terminal-glow-1'").replace("for level in ['ch2_ledger_front','ch2_ledger_office','ch2_lounge_front']:","for level in ['ch2_lounge_front']:").replace('bg42-current/probe-boost.tscn','bg42-current/probe-terminal.tscn').replace('print(json.dumps(row),flush=True)','print(json.dumps({k:v for k,v in row.items() if k!="command"}),flush=True)')
(p/'run-bg42-terminal-glow-20261118.py').write_text(s)
print('Memory-only terminal glow1.0 keeps self-lit screen; actual data/readback recorded. Product files unchanged.')
