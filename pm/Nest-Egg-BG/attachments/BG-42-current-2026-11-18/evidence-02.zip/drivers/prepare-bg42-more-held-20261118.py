from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');s=(p/'run-bg42-held-20261118.py').read_text();assert "out=base/'held-reproduction'" in s
s=s.replace("out=base/'held-reproduction'","out=base/'held-other'").replace("for level in ['ch2_ledger_front']:","for level in ['ch2_ledger_office','ch2_lounge_front']:")
(p/'run-bg42-held-other-20261118.py').write_text(s)
