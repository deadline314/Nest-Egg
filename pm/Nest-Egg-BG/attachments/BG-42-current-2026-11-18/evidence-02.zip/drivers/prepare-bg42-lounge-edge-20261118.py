from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
(root/'probe-lounge-edge.gd').write_text('''extends "res://work/bg42-current/probe-lounge-contrast.gd"
var _edge_reference: TerrainMaterialData
var _edge_original: Color
func _ready() -> void:
    _edge_reference = load("res://data/environment/materials/asphalt.tres") as TerrainMaterialData
    _edge_original = _edge_reference.edge_color
    super._ready()
func _apply55(level: Level, profile: LightingProfile) -> void:
    await super._apply55(level,profile)
    _edge_reference.edge_color = Color(_edge_original,0.6) if is_equal_approx(profile.contrast,1.05) else _edge_original
    var terrain := get_tree().get_first_node_in_group(&"terrain") as Terrain
    assert(terrain!=null and terrain._theme.zones[0].material==_edge_reference)
    var edges := terrain.get_node("Edges") as TerrainEdges
    for chunk in edges.get_children():
        if chunk is CanvasItem: chunk.queue_redraw()
    await RenderingServer.frame_post_draw
    await RenderingServer.frame_post_draw
func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
    var record := await super._capture55(level,world,label)
    record["terrain_edge_alpha"] = _edge_reference.edge_color.a
    return record
''')
(root/'probe-lounge-edge.tscn').write_bytes((root/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-lounge-edge.gd'))
s=(p/'run-bg42-terminal-glow-20261118.py').read_text().replace("out=base/'terminal-glow-1'","out=base/'lounge-contrast-edge'").replace('bg42-current/probe-terminal.tscn','bg42-current/probe-lounge-edge.tscn')
(p/'run-bg42-lounge-edge-20261118.py').write_text(s)
print('Memory-only contrast1.04->1.05 + existing asphalt edgealpha.55->.60. Same RGB/textures/geometry/physics/actors/lighting; redraw house TerrainEdges chunks only; original state restored per nine-state control. No product files changed.')
