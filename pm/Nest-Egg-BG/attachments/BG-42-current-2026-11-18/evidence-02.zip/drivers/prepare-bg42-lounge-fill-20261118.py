from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg42-current')
s=(root/'probe-boost.gd').read_text();needle='\tassert(candidate != null and candidate.validate().is_empty())';assert s.count(needle)==1
s=s.replace(needle,'\telif str(level.data.id) == "ch2_lounge_front":\n\t\tcandidate = original.duplicate() as LightingProfile\n\t\tcandidate.character_floor = 0.625\n'+needle)
(root/'probe-lounge-fill.gd').write_text(s);(root/'probe-lounge-fill.tscn').write_bytes((root/'probe-boost.tscn').read_bytes().replace(b'bg42-current/probe-boost.gd',b'bg42-current/probe-lounge-fill.gd'))
driver=(p/'run-bg42-terminal-glow-20261118.py').read_text().replace("out=base/'terminal-glow-1'","out=base/'lounge-fill-625'").replace('bg42-current/probe-terminal.tscn','bg42-current/probe-lounge-fill.tscn')
(p/'run-bg42-lounge-fill-20261118.py').write_text(driver)
print('Memory-only lounge own floor.62->.625 using existing exposure budget; terminal art/position/glow original. Same nine-state strict per-point controls, raw HDR retained. No product writes.')
