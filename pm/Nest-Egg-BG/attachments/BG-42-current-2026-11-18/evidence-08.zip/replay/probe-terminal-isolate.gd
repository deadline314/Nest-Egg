extends "res://work/bg42-current/probe-boost.gd"
func _measure(level: Level, world: Rect2) -> Dictionary:
    _active_cell55 = _cell55
    _cell55 += 1
    var terminal: PropNode
    for node in _authored42:
        if node.data.id==&"revival_lounge__commission_terminal": terminal=node
    assert(terminal!=null)
    var records: Array[Dictionary] = []
    for mode in ["before","body-only","glow-only","full","nothing","restore"]:
        await _variant42(level,mode in ["before","restore"])
        terminal.visible = mode not in ["before","restore","nothing"]
        for sprite in terminal.get_children():
            if sprite is Sprite2D: sprite.visible = mode!="body-only" if sprite==terminal._glow_sprite else mode!="glow-only"
        await RenderingServer.frame_post_draw
        await RenderingServer.frame_post_draw
        var record := await _capture55(level,world,mode)
        records.append(record)
        print("BG42_ISOLATE ",JSON.stringify({"cell":_active_cell55,"mode":mode,"player":record.get("player",{})}))
    assert(records[0].raw_sha256==records[-1].raw_sha256)
    return {"bg42_isolate":{"records":records,"scope":"Individual body/glow visibility isolation; calibration only, not acceptance"},"passed":true}
