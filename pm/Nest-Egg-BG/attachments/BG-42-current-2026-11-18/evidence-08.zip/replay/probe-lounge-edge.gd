extends "res://work/bg42-current/probe-lounge-contrast.gd"
var _edge_reference: TerrainMaterialData
var _edge_original: Color
func _ready() -> void:
    _edge_reference = load("res://data/environment/materials/asphalt.tres") as TerrainMaterialData
    _edge_original = _edge_reference.edge_color
    super._ready()
func _apply55(level: Level, profile: LightingProfile) -> void:
    await super._apply55(level,profile)
    _edge_reference.edge_color = Color(_edge_original,0.6) if is_equal_approx(profile.contrast,1.05) else _edge_original
    var terrain := get_tree().get_first_node_in_group(&"terrain") as Terrain
    assert(terrain!=null and terrain._theme.zones[0].material==_edge_reference)
    var edges := terrain.get_node("Edges") as TerrainEdges
    for chunk in edges.get_children():
        if chunk is CanvasItem: chunk.queue_redraw()
    await RenderingServer.frame_post_draw
    await RenderingServer.frame_post_draw
func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
    var record := await super._capture55(level,world,label)
    record["terrain_edge_alpha"] = _edge_reference.edge_color.a
    return record
