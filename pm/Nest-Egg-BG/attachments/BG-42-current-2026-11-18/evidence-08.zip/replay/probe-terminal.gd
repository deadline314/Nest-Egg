extends "res://work/bg42-current/probe-boost.gd"
var _terminal_reference: PropData
func _ready() -> void:
    _terminal_reference = load("res://data/environment/scene_props/revival_lounge/revival_lounge__commission_terminal.tres") as PropData
    _terminal_reference.glow_intensity = 1.0
    super._ready()
func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
    var record := await super._capture55(level,world,label)
    record["terminal_glow"] = []
    for prop in level._world.get_children():
        if prop is PropNode and prop.data.id==&"revival_lounge__commission_terminal":
            record["terminal_glow"].append({"data":prop.data.glow_intensity,"visible":prop.is_visible_in_tree(),"color":prop._glow_sprite.self_modulate.to_html()})
    return record
