extends "res://work/bg42-current/probe-boost.gd"
func _ready() -> void:
    super._ready()
    _delta42["ch2_lounge_front"].added[0]["flip"] = true
func _settle(frames: int) -> void:
    await super._settle(frames)
    if is_instance_valid(_held55):
        for prop in _authored42:
            if prop.data.id==&"revival_lounge__commission_terminal":
                prop.flip = true
                for sprite in prop.get_children():
                    if sprite is Sprite2D: prop._apply_flip(sprite)
func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
    var record := await super._capture55(level,world,label)
    record["terminal_flip"] = []
    for prop in _authored42:
        if prop.data.id==&"revival_lounge__commission_terminal":
            var flags: Array[bool] = []
            for sprite in prop.get_children():
                if sprite is Sprite2D: flags.append(sprite.flip_h)
            record["terminal_flip"].append({"flip":prop.flip,"sprite_flip_h":flags,"size":[prop.data.size.x,prop.data.size.y],"world":[prop.position.x,prop.position.y]})
    return record
