extends "res://work/bg42-current/probe-boost.gd"
func _ready() -> void:
    super._ready()
    _delta42["ch2_lounge_front"].added[0]["dx"] = 12
func _settle(frames: int) -> void:
    await super._settle(frames)
    if is_instance_valid(_held55):
        for prop in _authored42:
            if prop.data.id==&"revival_lounge__commission_terminal": prop.position.x = 268.0
