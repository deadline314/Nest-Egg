from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg35-current');out=b/'checks';out.mkdir(exist_ok=False)
private=root/'work/bg35-checks';private.mkdir(exist_ok=False)
(private/'selfcheck.gd').write_text('''extends Node
func _ready() -> void:
    var script := load("res://tools/lamp_flicker_probe.gd")
    var probe := script.new() as Node
    var image := Image.create(8,8,false,Image.FORMAT_RGBAH)
    for y in 8:
        for x in 8: image.set_pixel(x,y,Color(float(x)/3.0,float(y)/5.0,float(x+y)/8.0,0.5 if x%2==0 else 1.0))
    var rect := Rect2i(1,2,5,4)
    var full := preload("res://tools/viewport_capture.gd").encode(image,true).get_region(rect)
    var crop := preload("res://tools/viewport_capture.gd").encode(image.get_region(rect),true)
    assert(full.get_data() == crop.get_data())
    assert(probe._worst_second([])==0)
    assert(probe._worst_second([0.0,0.4,0.8,1.2])==3)
    assert(probe._worst_second([0.0,0.5,1.0])==3)
    assert(probe._worst_second([0.0,0.333,0.666,1.0])==4)
    var tracker := {"ref":0.0,"dir":0,"events":[],"low":9.0,"high":0.0}
    for i in 20: probe._track(tracker,float(i%2),float(i)/10.0)
    assert(probe._worst_second(tracker.events)>3)
    assert(LampFlicker.worst_window(LampFlicker._parse_pattern("amamamamamamamamamam"))>3)
    assert(LampFlicker.problems().is_empty())
    probe.free()
    print("BG35_SELFCHECK checks=8 failures=0; synthetic traces only, no visible flashing")
    await AudioRelease.settle(get_tree())
    get_tree().quit(0)
''',encoding='utf8',newline='\n')
(private/'selfcheck.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg35-checks/selfcheck.gd" id="1"]\n[node name="Check" type="Node"]\nscript = ExtResource("1")\n')
old=json.loads((b/'before/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in old}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
jobs=[('changed',['C:/Program Files/Git/bin/bash.exe','-c','python3() { python "$@"; }; export -f python3; tools/run_tests_changed.sh aaec09864dd164becb4c9ce05e292106826c0022']),('selfcheck',['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(root),'--audio-driver','Dummy','res://work/bg35-checks/selfcheck.tscn']),('patterns',['D:/ComfyUI/.venv-rocm/Scripts/python.exe','tools/assets/lamp_flicker_patterns.py','--show'])]
for name,command in jobs:
    folder=out/name;folder.mkdir();env=os.environ.copy();env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='2',LOG_DIR=str(folder/'shards'),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot()}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert row['exit']==row['script_errors']==0 and not row['engine_error'] and row['source_held']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'all_passed':True},indent=2)+'\n')
