from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg35-current');b.mkdir(exist_ok=False);out=b/'before';out.mkdir()
private=root/'work/bg35-before';private.mkdir(exist_ok=False)
(private/'observer.gd').write_text('''extends "res://tools/lamp_flicker_probe.gd"
func _burst(level_id: String, lamp: Lamp, camera: LevelCamera) -> String:
    var start := Time.get_ticks_usec()
    var result := await super._burst(level_id,lamp,camera)
    var level: Node = lamp
    while not level is Level: level = level.get_parent()
    var prompts := 0
    for node: Node in level.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    print("BG35_BEFORE ",JSON.stringify({"file":result,"burst_wall_seconds":float(Time.get_ticks_usec()-start)/1000000.0,
        "environments":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),"hdr":get_viewport().use_hdr_2d,
        "visible_prompts":prompts,"lamp":[lamp.global_position.x,lamp.global_position.y],"lighting_target_x":level._lighting._target.global_position.x,
        "camera":[camera.get_screen_center_position().x,camera.get_screen_center_position().y]}))
    return result
''',encoding='utf8',newline='\n')
(private/'observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg35-before/observer.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
source=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg33-current/exit-cleanup/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source}
before=snapshot();assert before==source
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name in ['normal','write-failure']:
    folder=out/name;folder.mkdir();env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[key]=str(folder/'private-profile'/key)
    if name=='write-failure':
        for state in ['loose','dying']:(folder/('flicker-ch1_warehouse-'+state+'.png')).mkdir()
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg35-before/observer.tscn','--','--out='+str(folder),'--level=ch1_warehouse','--seconds=2']
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();observations=[json.loads(l.split(b'BG35_BEFORE ',1)[1]) for l in raw.splitlines() if l.startswith(b'BG35_BEFORE ')]
    row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'images':len([p for p in folder.glob('*.png') if p.is_file()]),'observations':observations}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert row['exit']==row['script_errors']==0 and len(observations)==2 and all(r['environments']==0 for r in observations)
    assert row['images']==(2 if name=='normal' else 0)
    if name=='write-failure':assert row['engine_error']
after=snapshot();assert before==after
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':True,'missing_environment_reproduced':True,'write_false_success_reproduced':True},indent=2)+'\n')
