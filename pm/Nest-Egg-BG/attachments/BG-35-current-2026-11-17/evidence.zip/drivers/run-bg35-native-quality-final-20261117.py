from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg35-current');out=b/'native-quality-final';out.mkdir(exist_ok=False)
private=root/'work/bg35-native-quality-final';private.mkdir(exist_ok=False)
(private/'observer.gd').write_text('''extends "res://tools/lamp_flicker_probe.gd"
var _precreated: WorldEnvironment
func _ready() -> void:
    for arg: String in OS.get_cmdline_user_args():
        if arg.begins_with("--quality="): Settings.set_light_quality(LightQuality.Tier.LOW if arg.trim_prefix("--quality=")=="low" else LightQuality.Tier.HIGH)
    if OS.get_cmdline_user_args().has("--precreated-environment"):
        _precreated = LightKit.create_environment()
        add_child(_precreated)
    super._ready()
func _burst(level_id: String, lamp: Lamp, camera: LevelCamera) -> String:
    if OS.get_cmdline_user_args().has("--framing-control"): camera.zoom *= 4.0
    var result := await super._burst(level_id,lamp,camera)
    var level: Node = lamp
    while not level is Level: level = level.get_parent()
    var prompts := 0
    for node: Node in level.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    var environment := get_viewport().find_world_3d().environment
    var count := get_tree().root.find_children("*","WorldEnvironment",true,false).size()
    assert(environment != null and environment.glow_enabled and count == 1 and prompts == 0)
    assert(_precreated == null or environment == _precreated.environment)
    assert(level._lighting._target == _focus and _focus.global_position == lamp.global_position)
    print("BG35_OBSERVER ",JSON.stringify({"environments":count,"glow":environment.glow_enabled,"hdr":get_viewport().use_hdr_2d,
        "actual_quality":Settings.get_light_quality(),"normal_maps":LightQuality.normal_maps(),"visible_prompts":prompts,"lighting_target_x":_focus.global_position.x,"lamp_x":lamp.global_position.x,
        "original_player_x":level.player.global_position.x,"precreated_environment_preserved":_precreated != null}))
    return result
''',encoding='utf8',newline='\n')
(private/'observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg35-native-quality-final/observer.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
old=json.loads((b/'before/source-after.json').read_text());paths=list(old)+['audio/sfx/lamp_buzz_01.ogg','audio/sfx/lamp_buzz_01.ogg.import']
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert [p for p in old if before[p]!=old[p]]==['tools/lamp_flicker_probe.gd']
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
levels=['ch1_warehouse','ch1_vault','ch1_street','ch1_pawnshop','ch1_lounge']
cases=[(q+'-'+mode,q,mode,levels,10,0) for q in ['low','high'] for mode in ['normal','reduced']]
# The three negative controls already completed on identical production sources in native-final.
for name,q,mode,selected,seconds,expected in cases:
    folder=out/name;folder.mkdir(exist_ok=False);env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    if 'write-failure' in name:
        suffix='-context' if name=='context-write-failure' else ''
        for state in ['loose','dying']:(folder/('flicker-ch1_warehouse-'+state+suffix+'.png')).mkdir()
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg35-native-quality-final/observer.tscn','--','--out='+str(folder),'--level='+','.join(selected),'--seconds='+str(seconds),'--quality='+q]
    if mode=='reduced':command.append('--reduce-flashes')
    if name=='high-reduced':command.append('--precreated-environment')
    if name=='framing-control':command.append('--framing-control')
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();report=json.loads((folder/'flicker-index.json').read_text())
    row={'name':name,'quality':q,'mode':mode,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'images':len([p for p in folder.glob('*.png') if p.is_file()]),'observations':[json.loads(l.split(b'BG35_OBSERVER ',1)[1]) for l in raw.splitlines() if l.startswith(b'BG35_OBSERVER ')]}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k not in ['command','observations']}),flush=True)
    assert row['exit']==expected and row['script_errors']==0 and row['source_held']
    assert all(o['actual_quality']==(0 if q=='low' else 2) and o['normal_maps']==(q=='high') for o in row['observations'])
    assert report['capture_failures']==(0 if expected==0 else 2)
    if expected==0:
        assert not row['engine_error'] and len(report['captures'])==4 and row['images']==8
        for capture in report['captures']:
            times=[s['time'] for s in capture['samples']]
            assert len(times)==30 and all(a<b for a,b in zip(times,times[1:])) and times[-1]<=3.25
            assert capture['lamp']==capture['focus'] and capture['size']==[1280,720]
        for level,record in report['levels'].items():
            assert record['over_limit']==0 and record['observed_seconds']>=10 and record['buzz_far_gain']<=.02 and not record['buzz_far_sounding'] and (record['buzz_far_distance']==0 or record['buzz_far_distance']>=210)
            if level in ['ch1_warehouse','ch1_vault']:assert sum(v for k,v in record['states'].items() if k!='stable')>len(record['lamps'])/2
            else:assert set(record['states'])=={'stable'}
    else:assert row['engine_error']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'all_passed':True,'normal_runs':4,'negative_runs':0,'sheets':16,'contexts':16,'burst_frames':480},indent=2)+'\n')
