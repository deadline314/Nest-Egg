from pathlib import Path
import hashlib,json
from PIL import Image,ImageDraw,ImageFont
b=Path('D:/NestEggVerification/evidence-20261117/bg35-current');data=b/'native-quality-final';assert json.loads((data/'result.json').read_text())['all_passed']
out=b/'review';out.mkdir(exist_ok=False);font=ImageFont.truetype('C:/Windows/Fonts/consola.ttf',17);pages=[]
for level in ['ch1_warehouse','ch1_vault']:
    for state in ['loose','dying']:
        canvas=Image.new('RGB',(2000,830),(16,16,20));draw=ImageDraw.Draw(canvas);inputs=[]
        for row,mode in enumerate(['normal','reduced']):
            for col,q in enumerate(['low','high']):
                folder=data/(q+'-'+mode);report=json.loads((folder/'flicker-index.json').read_text());capture=next(c for c in report['captures'] if c['level']==level and c['state']==state)
                p=folder/capture['file'];image=Image.open(p);assert image.size==(2000,750)
                x,y=col*1000,row*415;canvas.paste(image.resize((1000,375)),(x,y+40));times=[s['time'] for s in capture['samples']]
                draw.text((x+4,y+3),f'{level} {state} {q} {mode}',font=font,fill='white')
                draw.text((x+4,y+21),f'actual {times[0]:.4f}..{times[-1]:.4f}s; max gap {max(b-a for a,b in zip(times,times[1:])):.4f}s',font=font,fill='white')
                inputs.append({'path':p.relative_to(b).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
        p=out/(level+'-'+state+'.png');canvas.save(p);pages.append({'page':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sources':inputs})
(out/'index.json').write_text(json.dumps(pages,indent=2)+'\n');print(json.dumps(pages),flush=True)
