from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg35-current');out=b/'smoke';out.mkdir(exist_ok=False)
env=os.environ.copy()
for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(out/'private-profile'/k)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://tools/lamp_flicker_probe.tscn','--','--out='+str(out),'--level=ch1_warehouse','--seconds=2']
source=hashlib.sha256((root/'tools/lamp_flicker_probe.gd').read_bytes()).hexdigest()
with (out/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
raw=(out/'raw.log').read_bytes();record={'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':source==hashlib.sha256((root/'tools/lamp_flicker_probe.gd').read_bytes()).hexdigest()}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);print(raw.decode(encoding='utf8',errors='replace')[-3500:],flush=True)
assert record['exit']==record['script_errors']==0 and not record['engine_error'] and record['source_held']
report=json.loads((out/'flicker-index.json').read_text());assert report['capture_failures']==0 and len(report['captures'])==2
for row in report['captures']:
    assert len(row['samples'])==30 and row['lamp']==row['focus']
    print(json.dumps({'state':row['state'],'times':[r['time'] for r in row['samples']],'size':row['size'],'crop':row['crop']}),flush=True)
