extends Node
func _ready() -> void:
    var script := load("res://tools/lamp_flicker_probe.gd")
    var probe := script.new() as Node
    var image := Image.create(8,8,false,Image.FORMAT_RGBAH)
    for y in 8:
        for x in 8: image.set_pixel(x,y,Color(float(x)/3.0,float(y)/5.0,float(x+y)/8.0,0.5 if x%2==0 else 1.0))
    var rect := Rect2i(1,2,5,4)
    var full := preload("res://tools/viewport_capture.gd").encode(image,true).get_region(rect)
    var crop := preload("res://tools/viewport_capture.gd").encode(image.get_region(rect),true)
    assert(full.get_data() == crop.get_data())
    assert(probe._worst_second([])==0)
    assert(probe._worst_second([0.0,0.4,0.8,1.2])==3)
    assert(probe._worst_second([0.0,0.5,1.0])==3)
    assert(probe._worst_second([0.0,0.333,0.666,1.0])==4)
    var tracker := {"ref":0.0,"dir":0,"events":[],"low":9.0,"high":0.0}
    for i in 20: probe._track(tracker,float(i%2),float(i)/10.0)
    assert(probe._worst_second(tracker.events)>3)
    assert(LampFlicker.worst_window(LampFlicker._parse_pattern("amamamamamamamamamam"))>3)
    assert(LampFlicker.problems().is_empty())
    probe.free()
    print("BG35_SELFCHECK checks=8 failures=0; synthetic traces only, no visible flashing")
    await AudioRelease.settle(get_tree())
    get_tree().quit(0)
