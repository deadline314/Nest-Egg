extends "res://tools/lamp_flicker_probe.gd"
func _burst(level_id: String, lamp: Lamp, camera: LevelCamera) -> String:
    var start := Time.get_ticks_usec()
    var result := await super._burst(level_id,lamp,camera)
    var level: Node = lamp
    while not level is Level: level = level.get_parent()
    var prompts := 0
    for node: Node in level.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    print("BG35_BEFORE ",JSON.stringify({"file":result,"burst_wall_seconds":float(Time.get_ticks_usec()-start)/1000000.0,
        "environments":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),"hdr":get_viewport().use_hdr_2d,
        "visible_prompts":prompts,"lamp":[lamp.global_position.x,lamp.global_position.y],"lighting_target_x":level._lighting._target.global_position.x,
        "camera":[camera.get_screen_center_position().x,camera.get_screen_center_position().y]}))
    return result
