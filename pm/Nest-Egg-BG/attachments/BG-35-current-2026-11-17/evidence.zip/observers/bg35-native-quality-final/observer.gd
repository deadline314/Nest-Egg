extends "res://tools/lamp_flicker_probe.gd"
var _precreated: WorldEnvironment
func _ready() -> void:
    for arg: String in OS.get_cmdline_user_args():
        if arg.begins_with("--quality="): Settings.set_light_quality(LightQuality.Tier.LOW if arg.trim_prefix("--quality=")=="low" else LightQuality.Tier.HIGH)
    if OS.get_cmdline_user_args().has("--precreated-environment"):
        _precreated = LightKit.create_environment()
        add_child(_precreated)
    super._ready()
func _burst(level_id: String, lamp: Lamp, camera: LevelCamera) -> String:
    if OS.get_cmdline_user_args().has("--framing-control"): camera.zoom *= 4.0
    var result := await super._burst(level_id,lamp,camera)
    var level: Node = lamp
    while not level is Level: level = level.get_parent()
    var prompts := 0
    for node: Node in level.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    var environment := get_viewport().find_world_3d().environment
    var count := get_tree().root.find_children("*","WorldEnvironment",true,false).size()
    assert(environment != null and environment.glow_enabled and count == 1 and prompts == 0)
    assert(_precreated == null or environment == _precreated.environment)
    assert(level._lighting._target == _focus and _focus.global_position == lamp.global_position)
    print("BG35_OBSERVER ",JSON.stringify({"environments":count,"glow":environment.glow_enabled,"hdr":get_viewport().use_hdr_2d,
        "actual_quality":Settings.get_light_quality(),"normal_maps":LightQuality.normal_maps(),"visible_prompts":prompts,"lighting_target_x":_focus.global_position.x,"lamp_x":lamp.global_position.x,
        "original_player_x":level.player.global_position.x,"precreated_environment_preserved":_precreated != null}))
    return result
