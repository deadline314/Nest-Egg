extends Node2D
const Capture := preload("res://tools/viewport_capture.gd")
var _out := ""
var _quality := 2
var _reduced := false
var _level: Level
var _rows: Array[Dictionary] = []

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out=arg.trim_prefix("--out=")
		elif arg=="--quality=low": _quality=0
		elif arg=="--reduced": _reduced=true
	assert(_out.is_absolute_path())
	DirAccess.make_dir_recursive_absolute(_out)
	Settings.use_storage("user://bg30-states.cfg")
	Settings.set_light_quality(_quality)
	Settings.set_brightness(0.5)
	Settings.set_reduce_flashes(_reduced)
	Settings.set_reduce_ui_motion(_reduced)
	Settings.set_feel_scale("shake",0.0 if _reduced else 1.0)
	add_child(LightKit.create_environment())
	_run.call_deferred()

func _settle(frames: int) -> void:
	for i in frames: await get_tree().physics_frame
	await RenderingServer.frame_post_draw

func _enter(id: String, tile: int, floor_row: int) -> void:
	if is_instance_valid(_level):
		Story.reset_active_presentation(&"route")
		_level.queue_free()
		await _settle(6)
	var data := load("res://data/levels/"+id+".tres") as LevelData
	var intro := data.intro_scene
	var card := data.show_chapter_card
	data.intro_scene=&""
	data.show_chapter_card=false
	_level=Level.new()
	_level.configure(data)
	add_child(_level)
	_level._arena_triggered=true
	await _settle(6)
	data.intro_scene=intro
	data.show_chapter_card=card
	for enemy in get_tree().get_nodes_in_group(&"enemies"): enemy.queue_free()
	Story._layer.hide()
	_level.player.health.setup(999,0.0)
	_level.player.position=Vector2(tile*16+8,floor_row*16-2)
	_level.player.velocity=Vector2.ZERO
	AimInput.set_virtual_gamepad(_level.player,true)
	Input.action_press(&"aim_right")
	await _settle(30)
	assert(_level.player.is_on_floor())
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.snap_to_target()
	camera.force_update_scroll()
	_level._lighting.snap()
	await _settle(12)

func _shot(name: String) -> void:
	for node in _level.find_children("*","",true,false):
		if node is WorldPrompt:
			node.enabled=false
			node.process_mode=Node.PROCESS_MODE_DISABLED
			node.hide()
	await RenderingServer.frame_post_draw
	var telegraphs: Array[Dictionary]=[]
	for node in _level._entities.get_children():
		if node is Enemy and node.is_telegraphing():
			assert(node.rig!=null)
			var view := get_viewport().get_visible_rect()
			var bounds: Rect2=get_viewport().get_canvas_transform()*node.rig.visual_bounds()
			assert(view.encloses(bounds))
			telegraphs.append({"id":str(node.data.id),"bounds":[bounds.position.x,bounds.position.y,bounds.size.x,bounds.size.y]})
	if name.ends_with("telegraph"): assert(telegraphs.size()==1)

	assert(Capture.image(get_viewport()).save_png(_out.path_join(name+".png"))==OK)
	var rain_count := 0
	var rain_surfaces: Array[float] = []
	for node in _level.find_children("*","",true,false):
		if node is RainLayer:
			rain_count+=1
			rain_surfaces.append(node._surface_at(_level.player.global_position.x))
	_rows.append({"name":name,"level":str(_level.data.id),"chapter":str(_level.data.chapter),
		"quality":Settings.get_light_quality(),"reduced_flashes":Settings.get_reduce_flashes(),"reduced_ui_motion":Settings.get_reduce_ui_motion(),
		"shake_scale":Settings.get_feel_scale("shake"),"rain_authored":_level.data.rain,"rain_nodes":rain_count,"rain_surfaces":rain_surfaces,
		"zone":str(_level._lighting.zone_id_at(_level.player.global_position.x)),"danger":_level._post.danger_level(),
		"flash":_level._lighting.flash_level(),"grain":_level._post.parameter(&"grain"),"telegraphs":telegraphs,"tooltip_suppressed_for_body_capture":true,"enemy_fill_scale":_level._lighting.current.enemy_fill_scale,
		"feet":[_level.player.global_position.x,_level.player.global_position.y],"on_floor":_level.player.is_on_floor()})
	assert(rain_count==(1 if _level.data.rain else 0))
	assert(Settings.get_light_quality()==_quality and Settings.get_reduce_flashes()==_reduced)

func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip=true
	await _enter("ch1_street",84,32)
	await _shot("street-calm")
	var foe := _level._create_enemy(load("res://data/enemies/sweeper.tres") as EnemyData)
	foe.data=foe.data.duplicate()
	foe.data.detect_range=0.0
	foe.data.attack_range=0.0
	foe.data.move_speed=0.0
	foe.position=Vector2(90*16+8,32*16-2)
	foe.facing=-1
	_level._entities.add_child(foe)
	await _settle(30)
	assert(foe.is_on_floor())
	foe._start_telegraph(2.0)
	await _settle(12)
	await _shot("enemy-telegraph")
	foe.queue_free()
	Fx.explosion(_level.player.global_position+Vector2(100,-10),44.0,0,Combat.Team.ENEMY,&"test")
	await _settle(4)
	await _shot("explosion")
	await _settle(60)
	_level._lighting._lightning_gap=0.0
	assert(_level._lighting.strike())
	await _settle(4)
	await _shot("lightning")
	await _settle(90)
	EventBus.player_health_changed.emit(1,6)
	await _settle(90)
	assert(_level._post.danger_level()>=0.99)
	await _shot("low-health")
	EventBus.player_health_changed.emit(6,6)
	await _settle(90)
	assert(_level._post.danger_level()<=0.01)
	await _shot("health-restored")
	await _enter("ch1_pawnshop",55,20)
	for node in _level.find_children("*","",true,false):
		if node is RainLayer:
			assert(node._surface_at(_level.player.global_position.x)<_level.player.global_position.y-60.0)
	await _shot("indoor")
	await _enter("ch1_warehouse",87,49)
	await _shot("warehouse-calm")
	foe=_level._create_enemy(load("res://data/enemies/collector_brute.tres") as EnemyData)
	foe.data=foe.data.duplicate()
	foe.data.detect_range=0.0
	foe.data.attack_range=0.0
	foe.data.move_speed=0.0
	foe.position=Vector2(94*16+8,49*16-2)
	foe.facing=-1
	_level._entities.add_child(foe)
	await _settle(30)
	assert(foe.is_on_floor())
	foe._start_telegraph(2.0)
	await _settle(12)
	await _shot("warehouse-telegraph")
	await _enter("ch1_street",84,32)
	await _shot("street-reentered")
	var file := FileAccess.open(_out.path_join("states.json"),FileAccess.WRITE)
	assert(file!=null and _rows.size()==10)
	file.store_string(JSON.stringify({"rows":_rows,"engine":Engine.get_version_info().string,"adapter":RenderingServer.get_video_adapter_name(),
		"renderer":RenderingServer.get_current_rendering_method(),"hdr":get_viewport().use_hdr_2d,
		"fixture":"scripted positioning, arranged stationary sweeper and direct telegraph/lightning/explosion/health signals; tooltips hidden only for body/effect capture; no natural combat or performance claim"},"\t")+"\n")
	Story.reset_active_presentation(&"route")
	_level.queue_free()
	await _settle(6)
	await AudioRelease.settle(get_tree())
	get_tree().quit()
