extends "res://tools/bg55_enemy_readability_probe.gd"

func _sync55(level: Level) -> void:
	super._sync55(level)
	for node in level._entities.get_children():
		if node is Enemy and node.creature!=null:
			node.creature.set_lighting(LightKit.creature_fill,LightKit.creature_light_cap)

func _capture55(level: Level,world: Rect2,label: String) -> Dictionary:
	var r := await super._capture55(level,world,label)
	r["creature_floor"]=level._lighting.current.creature_floor
	r["creature_fill"]=LightKit.creature_fill
	r["profile_id"]=str(level._lighting.current.id)
	var models: Array[Dictionary]=[]
	for node in level._entities.get_children():
		if not node is Enemy: continue
		var parts: Array[Dictionary]=[]
		if node.creature!=null:
			for part in node.creature._parts:
				parts.append({"transform":HeldLighting55.transform_values(part.sprite.global_transform),"visible":part.sprite.is_visible_in_tree(),"texture":part.sprite.texture.resource_path})
		models.append({"id":str(node.data.id),"instance":node.get_instance_id(),"skin":node.data.creature_skin,"feet":[node.global_position.x,node.global_position.y],"parts":parts,
			"fill":node.creature._lighting_fill if node.creature!=null else null,"cap":node.creature._lighting_cap if node.creature!=null else null})
	r["models"]=models
	return r

func _measure(level: Level,world: Rect2) -> Dictionary:
	var result := await super._measure(level,world)
	var baseline := level._lighting.current.duplicate() as LightingProfile
	var old: Dictionary=result.bg55.records[-1]
	var candidate := baseline.duplicate() as LightingProfile
	candidate.creature_floor=0.75
	await _apply55(level,candidate)
	var changed := await _capture55(level,world,"creature-floor075")
	await _apply55(level,baseline)
	var restored := await _capture55(level,world,"restore-creature-floor")
	var valid: bool=old.held==changed.held and old.held==restored.held and old.raw_sha256==restored.raw_sha256
	result["bg30_enemies"]={"diagnostic_only":true,"controls_valid":valid,"records":[old,changed,restored],"scope":"same frozen native actors and actual PartCreature lighting API; only temporary creature_floor0.75; original failed-threshold logs retained"}
	assert(valid)
	return result

func _frame_interval_ms() -> float:
	var start := Time.get_ticks_usec()
	await get_tree().process_frame
	return float(Time.get_ticks_usec()-start)/1000.0
