extends "res://work/bg30-current/enemies.gd"
var _observer30: Node2D

func _place_player(level: Level,center: Vector2,view: Vector2) -> void:
	super._place_player(level,center,view)
	if level.player.is_visible_in_tree():
		level._lighting._target=level.player
	else:
		if not is_instance_valid(_observer30) or _observer30.get_parent()!=level:
			_observer30=Node2D.new()
			level.add_child(_observer30)
		_observer30.global_position=center
		level._lighting._target=_observer30

func _capture55(level: Level,world: Rect2,label: String) -> Dictionary:
	var r := await super._capture55(level,world,label)
	var focus: Node2D=level._lighting._target
	r["focus"]={"position":[focus.global_position.x,focus.global_position.y],"is_player":focus==level.player,"zone":str(level._lighting.zone_id_at(focus.global_position.x))}
	var probe := ContrastProbe.capture(get_viewport())
	assert(bytes_sha(probe._image.get_data())==r.raw_sha256)
	var collisions: Array[Dictionary]=[]
	for e in r.enemies:
		var node := instance_from_id(int(e.instance)) as Enemy
		if node.creature==null: continue
		var bodies: Array[CollisionShape2D]=[]
		for child in node.get_children():
			if child is CollisionShape2D: bodies.append(child)
		assert(bodies.size()==1 and bodies[0].shape is RectangleShape2D)
		var body: CollisionShape2D=bodies[0]
		var size: Vector2=body.shape.size
		assert(size.is_equal_approx(node.data.body_size))
		var bounds: Rect2=body.global_transform*Rect2(-size*0.5,size)
		var parts := probe.contrast_parts(bounds,ContrastProbe.RING)
		collisions.append({"id":str(node.data.id),"instance":node.get_instance_id(),"data_path":node.data.resource_path,"data_size":[size.x,size.y],
			"shape_transform":HeldLighting55.transform_values(body.global_transform),"world_rect":[bounds.position.x,bounds.position.y,bounds.size.x,bounds.size.y],
			"screen_rect":rect_values(probe._screen_rect(bounds)),"outer_screen_rect":rect_values(probe._screen_rect(bounds.grow(ContrastProbe.RING))),
			"parts":parts,"contrast":maxf(parts.bright,parts.dark),"legacy_18x40":e.contrast,"uses_gravity":node.data.uses_gravity})
	r["collision_enemies"]=collisions
	return r
