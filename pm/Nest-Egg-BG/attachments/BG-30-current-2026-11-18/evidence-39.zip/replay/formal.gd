extends "res://work/bg30-current/enemies-focus.gd"

func _capture55(level: Level,world: Rect2,label: String) -> Dictionary:
	var r := await super._capture55(level,world,label)
	var probe := ContrastProbe.capture(get_viewport())
	assert(bytes_sha(probe._image.get_data())==r.raw_sha256)
	var camera := get_viewport().get_camera_2d()
	r["camera_world"]=[camera.global_position.x,camera.global_position.y]
	if level.player.is_visible_in_tree():
		var feet := level.player.global_position
		var body := probe._body_box(feet,true)
		var parts := probe.character_parts(feet,true)
		r["player"]={"feet":[feet.x,feet.y],"parts":parts,"contrast":maxf(parts.bright,parts.dark),
			"screen_rect":rect_values(probe._screen_rect(body)),"outer_screen_rect":rect_values(probe._screen_rect(body.grow(ContrastProbe.RING))),
			"edge_screen_rect":rect_values(probe._screen_rect(Rect2(feet+Vector2(-24,0),Vector2(48,3)))),
			"below_screen_rect":rect_values(probe._screen_rect(Rect2(feet+Vector2(-24,8),Vector2(48,6)))),"edge_contrast":probe.edge_contrast(feet)}
	for model in r.models:
		var node := instance_from_id(int(model.instance)) as Enemy
		if node.creature==null: continue
		model["creature_time"]=node.creature._time
		model["state_time"]=node.creature.state_time
		for i in node.creature._parts.size():
			var sprite: Sprite2D=node.creature._parts[i].sprite
			model.parts[i]["sprite_instance"]=sprite.get_instance_id()
			model.parts[i]["texture_instance"]=sprite.texture.get_instance_id()
			model.parts[i]["alpha"]=sprite.self_modulate.a
	return r

func _geometry30(record: Dictionary) -> Array:
	var models: Array=record.models.duplicate(true)
	for model in models:
		model.erase("fill")
		model.erase("cap")
	return models

func _measure(level: Level,world: Rect2) -> Dictionary:
	_active_cell55=_cell55
	_cell55+=1
	var authored := level._lighting.current.duplicate() as LightingProfile
	var baseline := authored.duplicate() as LightingProfile
	var zone := str(level._lighting.zone_id_at(level._lighting._target.global_position.x))
	if zone=="warehouse_interior":
		assert(level._lighting._zones.size()==1 and is_equal_approx(authored.creature_floor,0.6))
		baseline.creature_floor=0.0
	var records: Array[Dictionary]=[]
	for phase in ["before","before-repeat","after","restore","after-final"]:
		await _apply55(level,authored if phase in ["after","after-final"] else baseline)
		records.append(await _capture55(level,world,phase))
	var first: Dictionary=records[0]
	var final: Dictionary=records[-1]
	var valid: bool=first.held.lighting_owners.valid and first.raw_sha256==records[1].raw_sha256 and first.raw_sha256==records[3].raw_sha256 and records[2].raw_sha256==final.raw_sha256
	for r in records:
		valid=valid and r.held==first.held and _geometry30(r)==_geometry30(first) and r.focus==first.focus
		valid=valid and (r.focus.position==(r.player.feet if r.has("player") else r.camera_world))
		if zone!="warehouse_interior" or r.models.all(func(m: Dictionary) -> bool: return m.parts.is_empty()):
			valid=valid and r.raw_sha256==first.raw_sha256
	var passed: bool=valid
	if final.has("player"):
		passed=passed and final.player.contrast>=0.6 and final.player.edge_contrast>=1.0
	var legacy_below: Array[Dictionary]=[]
	for e in final.enemies:
		var matching: Array=final.collision_enemies.filter(func(c: Dictionary) -> bool: return c.instance==e.instance)
		if matching.is_empty(): passed=passed and e.contrast>=0.45
		else:
			assert(matching.size()==1)
			passed=passed and matching[0].contrast>=0.45
			if e.contrast<0.45: legacy_below.append({"id":e.id,"instance":e.instance,"legacy":e.contrast,"collision":matching[0].contrast})
	if not passed:
		_contrast_failures+=1
		printerr("[BG30] Final acceptance failed: ",level.data.id," cell=",_active_cell55," controls=",valid," player=",final.get("player",{})," creatures=",final.collision_enemies)
	return {"bg30":{"records":records,"controls_valid":valid,"zone":zone,"legacy_nonhumanoid_below":legacy_below,
		"scope":"correct live camera/player zone; unchanged original human0.6/enemy0.45/edge1 formula; actual physical collision rectangle supplementary for PartCreature, legacy18x40 retained; warehouse creature_floor0->0.6 only, not full historical BG30 checkout"},"passed":passed}
