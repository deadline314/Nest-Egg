extends "res://work/bg30-current/grounded.gd"

func _measure(level: Level,world: Rect2) -> Dictionary:
	if str(level.data.id)=="ch1_vault":
		var subject: Enemy
		for node in level._entities.get_children():
			if node is Enemy and node.data.id==&"collector_gunner" and world.grow(-24.0).has_point(node.global_position): subject=node
		assert(subject!=null and subject.rig!=null)
		var required: Rect2=subject.rig.visual_bounds().merge(Rect2(subject.global_position+Vector2(-9,-40),Vector2(18,40)).grow(ContrastProbe.RING))
		var camera := get_viewport().get_camera_2d()
		camera.global_position.y=required.get_center().y
		camera.reset_smoothing()
		camera.force_update_scroll()
		world.position.y=camera.global_position.y-world.size.y*0.5
		_place_player(level,world.get_center(),world.size)
		level._lighting._target=level.player if level.player.visible else camera
		await _settle(4)
	_active_cell55=_cell55
	_cell55+=1
	var before := level._lighting.current.duplicate() as LightingProfile
	var after := before.duplicate() as LightingProfile
	if str(level.data.id) in ["ch1_warehouse","ch1_vault"]: after.enemy_fill_scale=1.5
	var material: TerrainMaterialData
	var old_edge := Color.TRANSPARENT
	var terrain: Terrain
	if str(level.data.id)=="ch1_prologue":
		material=level.data.environment.zones[0].material
		old_edge=material.edge_color
		terrain=get_tree().get_first_node_in_group(&"terrain") as Terrain
		assert(terrain!=null)
	var records: Array[Dictionary]=[]
	for phase in ["before","fill15","fill18","fill20","restore"]:
		var chosen := before.duplicate() as LightingProfile
		if phase=="fill15": chosen.enemy_fill_scale=1.5
		if phase=="fill18": chosen.enemy_fill_scale=1.8
		if phase=="fill20": chosen.enemy_fill_scale=2.0
		await _apply55(level,chosen)
		if material!=null:
			material.edge_color=Color(old_edge.r,old_edge.g,old_edge.b,1.0) if phase=="after" else old_edge
			for owner in [terrain,terrain.get_node("Edges")]:
				for chunk in owner.get_children():
					if chunk is CanvasItem: chunk.queue_redraw()
			await RenderingServer.frame_post_draw
			await RenderingServer.frame_post_draw
		var r := await _capture55(level,world,phase)
		r["enemy_fill_scale"]=level._lighting.current.enemy_fill_scale
		r["edge_values"]=[material.edge_color.r,material.edge_color.g,material.edge_color.b,material.edge_color.a] if material!=null else []
		records.append(r)
	var valid: bool=true
	for record in records:
		valid=valid and records[0].held==record.held and _geometry30(records[0])==_geometry30(record)
	valid=valid and records[0].raw_sha256==records[-1].raw_sha256
	assert(valid)
	return {"bg30_calibration":{"diagnostic_only":true,"controls_valid":valid,"records":records,"scope":"held one-factor and combined bounded profile diagnostics; full-framed vault subject chosen from original cell by physical presence, camera vertical center from actual bounds, no pixel-based selection; no product changes"}}
