extends "res://work/bg30-current/formal.gd"
var _stand_search30: Array[Dictionary]=[]

func _place_player(level: Level,center: Vector2,view: Vector2) -> void:
	_stand_search30.clear()
	var player := level.player
	var shapes: Array[CollisionShape2D]=[]
	for child in player.get_children():
		if child is CollisionShape2D and not child.disabled: shapes.append(child)
	assert(shapes.size()==1)
	var body: CollisionShape2D=shapes[0]
	var column := clampi(int(center.x/level._layout.tile_size),0,level._layout.width-1)
	var world := Rect2(center-view*0.5,view)
	var checked := {}
	player.visible=false
	_contact55={"visible":false}
	for offset in [0,-1,1,-2,2,-3,3]:
		var at := clampi(column+int(offset),0,level._layout.width-1)
		if checked.has(at): continue
		checked[at]=true
		var x := float(at*level._layout.tile_size)+level._layout.tile_size*0.5
		if x<world.position.x+32.0 or x>world.end.x-32.0: continue
		var floor_y := visible_floor(level._layout,at,world)
		if not is_finite(floor_y):
			_stand_search30.append({"column":at,"reason":"no fully visible authored floor"})
			continue
		player.global_position=Vector2(x,floor_y-2.0)
		var query := PhysicsShapeQueryParameters2D.new()
		query.shape=body.shape
		query.transform=body.global_transform
		query.collision_mask=player.collision_mask|Layers.ENEMY
		query.exclude=[player.get_rid()]
		var overlaps := player.get_world_2d().direct_space_state.intersect_shape(query,1)
		if not overlaps.is_empty():
			_stand_search30.append({"column":at,"reason":"actual solid or enemy collision overlap"})
			continue
		var collision := player.move_and_collide(Vector2.DOWN*4.0,false,player.safe_margin)
		var support := ground_support(player)
		var valid: bool=collision!=null and bool(support.get("found",false)) and absf(float(support.get("gap",INF)))<=player.safe_margin+0.001
		valid=valid and collision.get_normal().dot(Vector2.UP)>0.99 if collision!=null else false
		_stand_search30.append({"column":at,"reason":"selected actual support" if valid else "actual solver failed","support":support})
		if not valid: continue
		player.visible=true
		support.merge({"visible":true,"layout_floor":floor_y,"safe_margin":player.safe_margin,"solver_contact":true,"solver_normal":[collision.get_normal().x,collision.get_normal().y],"valid":true})
		_contact55=support
		break

func _capture55(level: Level,world: Rect2,label: String) -> Dictionary:
	var r := await super._capture55(level,world,label)
	r["standing_search"]=_stand_search30.duplicate(true)
	r["standing_rule"]="first of center,-1,+1,-2,+2,-3,+3 columns with actual player-shape clearance from solids/enemies and original support solver; no pixel or contrast based choice; complete camera grid retained"
	return r
