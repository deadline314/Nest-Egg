extends "res://tools/scene_tour.gd"

func _ready() -> void:
	seed(30)
	Settings.use_storage("user://bg30-tour.cfg")
	Settings.set_reduce_flashes(false)
	Settings.set_reduce_ui_motion(false)
	super._ready()

func _frame_interval_ms() -> float:
	# Capture-only timing; one real interval is not a performance benchmark.
	var start := Time.get_ticks_usec()
	await get_tree().process_frame
	return float(Time.get_ticks_usec() - start) / 1000.0

func _tour(level_id: String) -> bool:
	var valid := await super._tour(level_id)
	var path := _out.path_join(level_id).path_join(_tag + "-index.json")
	if not valid or not FileAccess.file_exists(path):
		return false
	var index: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
	index["bg30"] = {"adapter": RenderingServer.get_video_adapter_name(), "engine": Engine.get_version_info().string,
		"renderer": RenderingServer.get_current_rendering_method(), "hdr": get_viewport().use_hdr_2d,
		"quality": Settings.get_light_quality(), "brightness": Settings.get_brightness(),
		"reduce_flashes": Settings.get_reduce_flashes(), "reduce_ui_motion": Settings.get_reduce_ui_motion(),
		"timing_scope": "single real process-frame interval per cell, capture only; no FPS or performance conclusions"}
	var file := FileAccess.open(path,FileAccess.WRITE)
	if file == null:
		push_error("[BG30] Cannot write tour metadata: " + path)
		return false
	file.store_string(JSON.stringify(index,"\t")+"\n")
	return true
