extends "res://work/bg30-current/grounded.gd"

func _full30(e: Dictionary) -> Rect2:
	var f: Array=e.feet
	var v: Array=e.visual_world_bounds_values
	return Rect2(v[0],v[1],v[2],v[3]).merge(Rect2(Vector2(f[0]-9.0,f[1]-44.0),Vector2(18,40)))

func _capture55(level: Level,world: Rect2,label: String) -> Dictionary:
	var r := await super._capture55(level,world,label)
	r["view_world"]=[world.position.x,world.position.y,world.size.x,world.size.y]
	var probe := ContrastProbe.capture(get_viewport())
	assert(bytes_sha(probe._image.get_data())==r.raw_sha256)
	for e in r.enemies:
		var full := _full30(e)
		e["fully_framed"]=world.encloses(full)
		var rect := probe._screen_rect(full.grow(1.0))
		var white := 0
		var peak := 0.0
		for y in range(rect.position.y,rect.end.y):
			for x in range(rect.position.x,rect.end.x):
				var color := probe._image.get_pixel(x,y)
				peak=maxf(peak,maxf(color.r,maxf(color.g,color.b)))
				if color.r>0.92 and color.g>0.92 and color.b>0.92: white+=1
		e["exposure"]={"screen_rect":rect_values(rect),"world_rect":[full.position.x,full.position.y,full.size.x,full.size.y],"white_pixels_including_background":white,"peak":peak,"zero_proves_actor_zero":white==0 and rect.has_area()}
	return r

func _pair30(level: Level,world: Rect2) -> Dictionary:
	_active_cell55=_cell55
	_cell55+=1
	var authored := level._lighting.current.duplicate() as LightingProfile
	var baseline := authored.duplicate() as LightingProfile
	var zone := str(level._lighting.zone_id_at(level._lighting._target.global_position.x))
	if zone=="warehouse_interior":
		assert(is_equal_approx(authored.creature_floor,0.6) and is_equal_approx(authored.enemy_fill_scale,2.0))
		baseline.creature_floor=0.0
		baseline.enemy_fill_scale=0.6
	var material: TerrainMaterialData
	var terrain: Terrain
	var edge := Color.TRANSPARENT
	if str(level.data.id)=="ch1_prologue":
		material=level.data.environment.zones[0].material
		assert(material.id==&"prologue_concrete")
		edge=material.edge_color
		terrain=get_tree().get_first_node_in_group(&"terrain") as Terrain
		assert(terrain!=null)
	var records: Array[Dictionary]=[]
	for phase in ["before","before-repeat","after","restore","after-final"]:
		var use_after: bool=phase in ["after","after-final"]
		await _apply55(level,authored if use_after else baseline)
		if material!=null:
			material.edge_color=edge if use_after else Color(edge.r,edge.g,edge.b,0.6)
			for owner in [terrain,terrain.get_node("Edges")]:
				for chunk in owner.get_children():
					if chunk is CanvasItem: chunk.queue_redraw()
			await RenderingServer.frame_post_draw
			await RenderingServer.frame_post_draw
		var r := await _capture55(level,world,phase)
		r["material_edge"]=[material.edge_color.r,material.edge_color.g,material.edge_color.b,material.edge_color.a] if material!=null else []
		records.append(r)
	var first: Dictionary=records[0]
	var final: Dictionary=records[-1]
	var valid: bool=first.held.lighting_owners.valid and first.raw_sha256==records[1].raw_sha256 and first.raw_sha256==records[3].raw_sha256 and records[2].raw_sha256==final.raw_sha256
	for r in records:
		valid=valid and r.held==first.held and _geometry30(r)==_geometry30(first) and r.focus==first.focus
		valid=valid and r.focus.position==(r.player.feet if r.has("player") else r.camera_world)
		if zone!="warehouse_interior" and material==null: valid=valid and r.raw_sha256==first.raw_sha256
	var passed: bool=valid
	if final.has("player"): passed=passed and final.player.contrast>=0.6 and final.player.edge_contrast>=1.0
	var cropped: Array[Dictionary]=[]
	var legacy_below: Array[Dictionary]=[]
	for e in final.enemies:
		var collision: Array=final.collision_enemies.filter(func(c: Dictionary) -> bool: return c.instance==e.instance)
		if not collision.is_empty():
			assert(collision.size()==1)
			passed=passed and collision[0].contrast>=0.45
			if e.contrast<0.45: legacy_below.append({"id":e.id,"instance":e.instance,"legacy":e.contrast,"collision":collision[0].contrast})
		elif e.fully_framed: passed=passed and e.contrast>=0.45
		else: cropped.append({"id":e.id,"instance":e.instance,"legacy":e.contrast})
	if not passed:
		_contrast_failures+=1
		printerr("[BG30] Native final failed ",level.data.id," pair=",_active_cell55," player=",final.get("player",{})," enemies=",final.enemies," creatures=",final.collision_enemies)
	return {"records":records,"controls_valid":valid,"zone":zone,"cropped_humanoids":cropped,"legacy_nonhumanoid_below":legacy_below,"passed":passed,"scope":"same live scene A/A/B/A/B; original human0.6/enemy0.45/edge1 formulas, clipped grid values preserved; supplementary collision rectangle for actual nonhuman shapes; full-framed extra views chosen by geometry only; baseline is current profile with only this ticket's adopted lighting/edge changes restored in memory, not historical checkout"}

func _measure(level: Level,world: Rect2) -> Dictionary:
	var group := await _pair30(level,world)
	var extra: Array[Dictionary]=[]
	var camera := get_viewport().get_camera_2d()
	var original_camera := camera.global_position
	var original_player := level.player.global_position
	var original_visible := level.player.visible
	var original_contact := _contact55.duplicate(true)
	var original_search := _stand_search30.duplicate(true)
	for cropped in group.cropped_humanoids:
		var enemy := instance_from_id(int(cropped.instance)) as Enemy
		assert(enemy!=null and enemy.rig!=null)
		var required := enemy.rig.visual_bounds().merge(Rect2(enemy.global_position+Vector2(-9,-44),Vector2(18,40))).grow(ContrastProbe.RING)
		var center := required.get_center()
		var size := level._layout.pixel_size()
		center.x=clampf(center.x,world.size.x*0.5,maxf(world.size.x*0.5,size.x-world.size.x*0.5))
		center.y=clampf(center.y,world.size.y*0.5,maxf(world.size.y*0.5,size.y-world.size.y*0.5))
		camera.global_position=center
		camera.reset_smoothing()
		camera.force_update_scroll()
		var full_world := Rect2(center-world.size*0.5,world.size)
		level.player.visible=false
		_contact55={"visible":false}
		_stand_search30=[]
		level._lighting._target=camera
		await _settle(4)
		var pair := await _pair30(level,full_world)
		var target: Array=pair.records[-1].enemies.filter(func(e: Dictionary) -> bool: return int(e.instance)==int(cropped.instance))
		var complete: bool=target.size()==1 and target[0].fully_framed and target[0].contrast>=0.45
		if not complete:
			_contrast_failures+=1
			printerr("[BG30] Full-framed actor failed ",level.data.id," ",cropped," target=",target)
		pair["target_instance"]=cropped.instance
		pair["target_complete"]=complete
		extra.append(pair)
	camera.global_position=original_camera
	camera.reset_smoothing()
	camera.force_update_scroll()
	level.player.global_position=original_player
	level.player.visible=original_visible
	_contact55=original_contact
	_stand_search30=original_search
	level._lighting._target=level.player if original_visible else camera
	await _settle(1)
	return {"bg30":group,"full_framed_views":extra,"passed":bool(group.passed) and extra.all(func(e: Dictionary) -> bool: return e.passed and e.target_complete)}
