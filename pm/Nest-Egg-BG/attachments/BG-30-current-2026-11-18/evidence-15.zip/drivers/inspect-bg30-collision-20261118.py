from pathlib import Path
import json,sys
sys.path.insert(0,str(Path.cwd()/'tools'))
from verify_bg49_held import load_pixels,contrast,raster
b=Path('D:/NestEggVerification/evidence-20261117/bg30-current/enemy-diagnostic');rows=[]
for path in b.glob('*/*/diagnostic-index.json'):
 for shot in json.loads(path.read_text())['shots']:
  for r in shot['bg30_enemies']['records'][:2]:
   rgb=load_pixels(path.parent,r)
   for e in r['enemies']:
    assert e['id']=='drone';x,y=e['feet'];box=[x-10,y-14,20,14];outer=[x-30,y-34,60,54];parts=contrast(rgb,raster(box,r),raster(outer,r));value=max(parts['bright'],parts['dark']);rows.append({'case':path.parent.parent.name,'label':r['label'],'instance':e['instance'],'feet':e['feet'],'original_18x40_legacy':e['contrast'],'actual_20x14_collision_diagnostic':value,'world_box':box,'world_outer':outer})
(b/'collision-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
