from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
b=Path('D:/NestEggVerification/evidence-20261117/bg30-current/calibration-v2');o=b/'review';o.mkdir(exist_ok=True);font=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc',14)
for p in b.glob('*/*/calibration-index.json'):
 shots=json.loads(p.read_text())['shots'];im=Image.new('RGB',(1280,len(shots)*390),'#101722');draw=ImageDraw.Draw(im)
 for i,s in enumerate(shots):
  for j,r in enumerate(s['bg30_calibration']['records'][:2]):
   with Image.open(p.parent/r['files']['png']) as pic:im.paste(pic,(j*640,i*390+30))
   draw.text((j*640+3,i*390+5),p.parent.parent.name+' '+r['label']+' cell'+str([s['column'],s['row']]),font=font,fill='white')
 im.save(o/(p.parent.parent.name+'.png'))
print('6pages prepared')
