from pathlib import Path
import hashlib,json,os,shutil,subprocess
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg30-current');o=b/'campaign-v2';o.mkdir(exist_ok=False);source=json.loads((b/'source-v2.json').read_text());snap=lambda:{n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in source};assert snap()==source;(o/'source-before.json').write_text(json.dumps(source,indent=2)+'\n');levels=['ch1_prologue','ch1_pawnshop','ch1_rooftop','ch1_street','ch1_booth_alley','ch1_warehouse','ch1_vault','ch1_handoff','ch1_lounge','ch1_stall','ch1_pawnshop_dawn'];runs=[]
for q in ['low','high']:
 f=o/q;f.mkdir();env=os.environ.copy()
 for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(f/'private-profile'/k)
 (f/'source/tools').mkdir(parents=True);shutil.copyfile(d/'tools/ch1_readability_check.gd',f/'source/tools/ch1_readability_check.gd')
 cmd=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(p/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(d),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://tools/bg49_held_readability_probe.tscn','--','--out='+str(f),'--level='+','.join(levels),'--quality='+q,'--brightness=0.5','--fixed-aim']
 with (f/'raw.log').open('wb') as log:r=subprocess.run(cmd,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
 raw=(f/'raw.log').read_bytes();row={'quality':q,'command':cmd,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':snap()==source};runs.append(row);(o/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
 reader=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-X','utf8',str(d/'tools/verify_bg49_held.py'),str(f),'--kind','held','--expect-points','18','--out',str(f/'independent.json')]
 with (f/'reader.log').open('wb') as log:r=subprocess.run(reader,cwd=d,stdout=log,stderr=subprocess.STDOUT)
 row['reader_exit']=r.returncode;(o/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({'quality':q,'reader_exit':r.returncode}),flush=True)
(o/'source-after.json').write_text(json.dumps(snap(),indent=2)+'\n');(o/'result.json').write_text(json.dumps({'passed':all(r['exit']==r['script_errors']==r['reader_exit']==0 and not r['engine_error'] and r['source_held'] for r in runs),'source_held':snap()==source,'completed_producers':len(runs)},indent=2)+'\n')
