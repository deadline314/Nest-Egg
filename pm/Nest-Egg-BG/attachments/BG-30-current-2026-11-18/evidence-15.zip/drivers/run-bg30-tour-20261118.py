from pathlib import Path
import hashlib,json,os,subprocess
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg30-current');o=b/'tour-current';o.mkdir(exist_ok=False);source=json.loads((b/'source-base.json').read_text());snap=lambda:{n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in source};assert snap()==source;(o/'source-before.json').write_text(json.dumps(source,indent=2)+'\n');levels=json.loads((d/'data/combat/chapter_rosters.json').read_text())['chapters']['ch1_kasa']['levels'];assert len(levels)==11;runs=[]
for q in ['low','high']:
 f=o/q;f.mkdir();env=os.environ.copy()
 for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(f/'private-profile'/k)
 cmd=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(p/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(d),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg30-current/tour.tscn','--','--out='+str(f),'--level='+','.join(levels),'--quality='+q,'--brightness=0.5','--player','--tag=current']
 with (f/'raw.log').open('wb') as log:r=subprocess.run(cmd,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
 raw=(f/'raw.log').read_bytes();row={'quality':q,'command':cmd,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':snap()==source};runs.append(row);(o/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
 assert row['exit']==row['script_errors']==0 and not row['engine_error'] and row['source_held']
 for level in levels:
  index=json.loads((f/level/'current-index.json').read_text());assert len(index['shots'])==index['columns']*index['rows'] and index['bg30']['adapter']=='AMD Radeon RX 9070 XT' and index['bg30']['quality']==(0 if q=='low' else 2) and index['bg30']['hdr']
(o/'source-after.json').write_text(json.dumps(snap(),indent=2)+'\n');(o/'result.json').write_text(json.dumps({'passed':True,'source_held':snap()==source,'completed_producers':len(runs),'performance_claim':False},indent=2)+'\n')
