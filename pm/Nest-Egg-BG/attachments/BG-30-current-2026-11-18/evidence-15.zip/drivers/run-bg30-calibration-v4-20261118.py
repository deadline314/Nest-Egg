from pathlib import Path
import hashlib,json,os,subprocess
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg30-current');o=b/'calibration-v4';o.mkdir(exist_ok=False);source=json.loads((b/'source-final.json').read_text());snap=lambda:{n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in source};assert snap()==source;runs=[]
for level,cells in [('ch1_warehouse','1:5,4:4,4:5'),('ch1_vault','4:1')]:
 for q in ['low','high']:
  f=o/(level+'-'+q);f.mkdir();env=os.environ.copy()
  for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(f/'private-profile'/k)
  cmd=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(p/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(d),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg30-current/calibration-v4.tscn','--','--out='+str(f),'--level='+level,'--cells='+cells,'--quality='+q,'--brightness=0.5','--player','--fixed-aim','--tag=calibration']
  with (f/'raw.log').open('wb') as log:r=subprocess.run(cmd,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
  raw=(f/'raw.log').read_bytes();row={'level':level,'quality':q,'command':cmd,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':snap()==source};runs.append(row);(o/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
  assert row['exit']==row['script_errors']==0 and not row['engine_error'] and row['source_held']
(o/'result.json').write_text(json.dumps({'completed_producers':len(runs),'source_held':snap()==source,'diagnostic_only':True},indent=2)+'\n')
