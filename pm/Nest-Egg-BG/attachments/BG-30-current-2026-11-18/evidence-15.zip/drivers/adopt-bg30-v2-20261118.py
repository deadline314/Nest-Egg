from pathlib import Path
import hashlib,json,subprocess
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg30-current');old=json.loads((b/'source-final.json').read_text());assert json.loads((b/'calibration-v6/result.json').read_text())['completed_producers']==2
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert all(sha(d/n)==h for n,h in old.items())
paths=['tools/scene_tour.gd','data/lighting/warehouse_interior.tres','data/scripts/lighting_profile.gd','tests/suite/test_exposure.gd','data/environment/themes/ch1_prologue.tres','data/audio/footsteps.json','data/environment/materials/prologue_concrete.tres']
for n in paths:
 if n in old:
  f=b/'original-source'/n
  if not f.exists():f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((d/n).read_bytes());assert sha(f)==json.loads((b/'source-base.json').read_text())[n]
def edit(n,a,z):
 f=p/n;raw=f.read_bytes();assert raw.count(a)==1,(n,a);f.write_bytes(raw.replace(a,z))
edit('data/lighting/warehouse_interior.tres',b'enemy_fill_scale = 0.6',b'enemy_fill_scale = 2.0')
edit('data/scripts/lighting_profile.gd',b'const MAX_ENEMY_FILL_SCALE := 1.5',b'const MAX_ENEMY_FILL_SCALE := 2.0')
n='tests/suite/test_exposure.gd'
edit(n,b'zone.profile = source.duplicate(true) as LightingProfile',b'zone.profile = source.duplicate(true) as LightingProfile'+b'\n\tzone.profile.enemy_fill_scale = 0.6')
edit(n,b'the warehouse interior asks for dimmer enemies and is valid data',b'the isolated dim-enemy fixture is valid lighting data')
edit(n,b'profile.enemy_fill_scale = 1.2',b'profile.enemy_fill_scale = LightingProfile.MAX_ENEMY_FILL_SCALE')
edit(n,b'baseline_fill * 1.2',b'baseline_fill * LightingProfile.MAX_ENEMY_FILL_SCALE')
edit(n,b'plain.enemy_fill_scale = 1.51',b'plain.enemy_fill_scale = 2.0'+b'\n\tcheck(plain.validate().is_empty(), "the bounded warehouse armor boost is valid")'+b'\n\tplain.enemy_fill_scale = 2.01')
new='data/environment/materials/prologue_concrete.tres';raw=(p/'data/environment/materials/concrete.tres').read_bytes();assert raw.count(b'id = &"concrete"')==1 and raw.count(b'0.9019608, 0.6)')==1
(p/new).write_bytes(raw.replace(b'id = &"concrete"',b'id = &"prologue_concrete"').replace(b'0.9019608, 0.6)',b'0.9019608, 1.0)'))
edit('data/environment/themes/ch1_prologue.tres',b'materials/concrete.tres',b'materials/prologue_concrete.tres')
n='data/audio/footsteps.json';raw=(p/n).read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n';needle=b'  "concrete": "concrete",'+nl;edit(n,needle,needle+b'  "prologue_concrete": "concrete",'+nl)
for n in paths:(d/n).write_bytes((p/n).read_bytes())
for folder in [p,d]:subprocess.run(['git','add','-N','--',new],cwd=folder,check=True)
source={n:sha(d/n) for n in list(old)+[new]};assert len(source)==10095
(b/'source-v2.json').write_text(json.dumps(source,indent=2)+'\n');(b/'adoption-v2.json').write_text(json.dumps({'base':'42bc3fb89675f1f46f27e6f2a3ee72b653c7b36d','product_paths':paths,'source_count':len(source),'scope':'Shared tour zone/frozen lighting correction; warehouse creature_floor0.6 and bounded enemy-only scale2.0 (global maximum2.0, runtime cap preserved); local prologue concrete edge alpha1 with exact footstep alias. Main character, ambient, fog, background, lamp, weather, textures, geometry, audio unchanged. Existing dim-fixture explicitly0.6; actual max rig/cap/flash plus finite validation boundary tested.'},indent=2)+'\n');print(json.dumps({'product_paths':paths,'source_count':len(source)}),flush=True)
