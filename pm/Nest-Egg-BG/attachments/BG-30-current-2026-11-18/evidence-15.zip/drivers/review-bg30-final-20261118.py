from pathlib import Path
import hashlib,json,math
from PIL import Image,ImageDraw,ImageFont
b=Path('D:/NestEggVerification/evidence-20261117/bg30-current');o=b/'review-v5';o.mkdir(exist_ok=True);font=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc',14);pages={}
def sheets(prefix,entries,cols=3,per=12):
 for page,start in enumerate(range(0,len(entries),per),1):
  items=entries[start:start+per];im=Image.new('RGB',(640*cols,384*math.ceil(len(items)/cols)),'#101722');dr=ImageDraw.Draw(im)
  for i,(p,label) in enumerate(items):
   x=i%cols*640;y=i//cols*384
   with Image.open(p) as pic:assert pic.size==(640,360);im.paste(pic,(x,y+24))
   dr.text((x+3,y+3),label,font=font,fill='white')
  name=f'{prefix}-{page:02}.png';im.save(o/name);pages[name]=hashlib.sha256((o/name).read_bytes()).hexdigest()
for q in ['low','high']:
 selected=[];extras=[]
 for p in sorted((b/'formal-v5'/q).glob('*/formal-index.json')):
  index=json.loads(p.read_text());entries=[]
  for s in index['shots']:
   r=s['bg30']['records'][-1];cell=f"c{int(s['column']):02}r{int(s['row']):02}";label=q+' '+index['level']+' '+cell
   entries.append((p.parent/r['files']['png'],label))
   if (index['level']=='ch1_prologue' and s['column']==1 and s['row'] in [1,2]) or (index['level']=='ch1_warehouse' and (s['column'],s['row']) in [(4,4),(4,5),(5,3)]):
    for r in [s['bg30']['records'][0],s['bg30']['records'][-1]]:selected.append((p.parent/r['files']['png'],label+' '+r['label']))
   for v in s['full_framed_views']:
    actor=next(e for e in v['records'][-1]['enemies'] if e['instance']==v['target_instance'])
    for r in [v['records'][0],v['records'][-1]]:extras.append((p.parent/r['files']['png'],label+' FULL '+actor['id']+' '+r['label']))
  sheets('grid-'+q+'-'+index['level'],entries)
 sheets('compare-'+q,selected,2,6);sheets('full-actors-'+q,extras,2,6)
 campaign=[]
 for p in sorted((b/'campaign-v2'/q).glob('*/bg49-held.json')):
  for result in json.loads(p.read_text())['results']:
   r=result['bg55']['records'][-1];campaign.append((p.parent/r['files']['png'],q+' ARRANGED '+p.parent.name+' '+result['bg49']['spot']))
 sheets('campaign-'+q,campaign,2,6)
 for mode in ['normal','reduced']:
  p=b/'states-v3'/(q+'-'+mode)/'states.json'
  if p.exists():sheets('states-'+q+'-'+mode,[(p.parent/(r['name']+'.png'),q+' '+mode+' '+r['name']) for r in json.loads(p.read_text())['rows']],2,10)
(o/'pages.json').write_text(json.dumps(pages,indent=2)+'\n');print(json.dumps({'pages':len(pages),'names':list(pages)},indent=2))
