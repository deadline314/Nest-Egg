from pathlib import Path
import hashlib,json
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg30-current');source=json.loads((b/'source-base.json').read_text());assert json.loads((b/'enemy-focus/result.json').read_text())['completed_producers']==8
paths=['tools/scene_tour.gd','data/lighting/warehouse_interior.tres'];old=b/'original-source';old.mkdir(exist_ok=False)
for n in paths:
 assert hashlib.sha256((d/n).read_bytes()).hexdigest()==source[n];f=old/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((d/n).read_bytes())
doc=p/'design/20-campaign-experience/SCENE_LIGHTING_REVIEW.md';text=doc.read_text();text+='''

### 巡覽與飛行器的受光

鏡格沒有可站主角時，巡覽改由相機所在位置選光影區段；有主角則仍依實際站位。凍結拍攝的敵人沿用正式CharacterRig／PartCreature受光介面同步，不推進動作。這避免鏡頭到了碼頭卻仍使用市集光影，亦不把拍攝工具的過暗誤認成正式遊戲。

倉庫與倉庫深處的飛行器在正確區段下仍過暗，warehouse_interior的非人形最低補光採0.6，與街道既有區段一致，保留原有上限、色調、霧、主角／人形敵人、燈具及聲音。共用此設定的第二章代收處門口沒有敵人，仍以同鏡頭驗證像素不變。飛行器正式碰撞框20×14與原18×40人形取樣框不同；保留原人形窗數字，另以真實碰撞框及相同公式／0.45門檻補查，不能宣稱兩種矩形相同。
''';doc.write_text(text,encoding='utf-8')
n='data/lighting/warehouse_interior.tres';raw=(p/n).read_bytes();assert raw==(d/n).read_bytes() and b'creature_floor' not in raw;newline=b'\r\n' if b'\r\n' in raw else b'\n';needle=b'enemy_fill_scale = 0.6'+newline;assert raw.count(needle)==1;(p/n).write_bytes(raw.replace(needle,needle+b'creature_floor = 0.6'+newline))
for n in paths:(d/n).write_bytes((p/n).read_bytes())
after={n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in source};assert sorted(n for n in source if source[n]!=after[n])==sorted(paths);(b/'source-final.json').write_text(json.dumps(after,indent=2)+'\n');(b/'adoption.json').write_text(json.dumps({'base':'42bc3fb89675f1f46f27e6f2a3ee72b653c7b36d','product_paths':paths,'source_count':len(after),'scope':'One existing warehouse profile creature_floor0->0.6 plus shared SceneTour camera-zone and frozen-enemy-light synchronization/metadata; no gameplay, texture, geometry, audio, actor/rig or threshold changes. Other consumer ch2_ledger_front has no enemies and requires exact controlled pixel comparison.'},indent=2)+'\n');print(json.dumps({'paths':paths,'source_count':len(after)}),flush=True)
