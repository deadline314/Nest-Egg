from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg46-current');base.mkdir(exist_ok=False)
source=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg45-current/source-v2.json').read_text());snapshot=lambda:{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source};assert snapshot()==source
(base/'source-before.json').write_text(json.dumps(source,indent=2)+'\n')
scenes=json.loads((root/'data/story/cutscenes_ch2.json').read_text())['scenes'];selected={k:v for k,v in scenes.items() if any(s.get('do')=='scene' and s.get('id')=='ch2_guest_book_room' for s in v.get('steps',[]))};assert len(selected)==18
(base/'scene-sources.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
runs=[];passed=False
try:
 for name,scene,args in [('stage-scenes','res://tools/stage_actor_capture.tscn',['--scene='+k for k in selected]),('real-flow','res://tools/ch2_flow_probe.tscn',['--guest-book-only'])]:
  folder=base/name;folder.mkdir();env=os.environ.copy()
  for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
  cmd=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','res://tools/stage_actor_capture.tscn' if name=='stage-scenes' else scene,'--','--out='+str(folder),*args]
  with (folder/'raw.log').open('wb') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
  raw=(folder/'raw.log').read_bytes();row={'name':name,'command':cmd,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':snapshot()==source};runs.append(row);(base/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
  assert r.returncode==0 and not row['script_errors'] and not row['engine_error'] and row['source_held']
  if name=='stage-scenes':
   assert len(list(folder.glob('*.png')))==18
   for ident in selected:
    m=json.loads((folder/(ident+'.json')).read_text());assert m['saved'] and m['flags_unchanged'] and not m['framing_problems'] and m['adapter']=='AMD Radeon RX 9070 XT' and m['godot'].startswith('4.7.2')
  else:
   result=json.loads((folder/'guest-book-result.json').read_text());assert result['failures']==0 and result['credit_delta']==100 and result['book_complete'] and not result['paused']
 passed=True
finally:
 (base/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(base/'result.json').write_text(json.dumps({'passed':passed,'source_held':snapshot()==source,'source_count':len(source),'completed_producers':len(runs)},indent=2)+'\n')
