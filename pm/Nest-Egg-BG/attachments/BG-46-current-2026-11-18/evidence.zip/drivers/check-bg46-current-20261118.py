from pathlib import Path
import hashlib,json,os,subprocess
p=Path.cwd();b=Path('D:/NestEggVerification/evidence-20261117/bg46-current');d=Path('D:/NestEggVerification/ne218-baseline-20261117');checks=b/'checks-v4';checks.mkdir(exist_ok=False);s=json.loads((b/'source-v4.json').read_text())
assert all(hashlib.sha256((p/n).read_bytes()).hexdigest()==h==hashlib.sha256((d/n).read_bytes()).hexdigest() for n,h in s.items())
env=os.environ.copy();env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='4',LOG_DIR=str(checks/'shards'),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(checks/'private-profile'/k)
cmd=['C:/Program Files/Git/bin/bash.exe','-c','python3() { python "$@"; }; export -f python3; tools/run_tests_changed.sh 6181ca48973c6c4651ede2bfd81c0880b64ad03a']
with (checks/'raw.log').open('wb') as f:r=subprocess.run(cmd,cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
raw=(checks/'raw.log').read_bytes();print(raw.decode('utf-8',errors='replace'));assert r.returncode==0 and b'SCRIPT ERROR:' not in raw and b'ERROR:' not in raw
(checks/'result.json').write_text(json.dumps({'exit':r.returncode,'command':cmd,'source_count':len(s),'root_matches_final_native_source':True,'only_probe_shutdown_changed':True,'prior_unchanged_source_checks':'BG45 checks-v2:56groups58567checks0new0known;32maps+portals+stages0errors0warnings;assets/importpolicyOK. Only tool exit timing changed; prior checks referenced, not rerun.'},indent=2)+'\n')
