from pathlib import Path
import hashlib,json,subprocess
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg46-current');s=json.loads((b/'native-v2/source-before.json').read_text());name='tools/ch2_flow_probe.gd'
for root in [p,d]:
 raw=(root/name).read_bytes();newline=b'\r\n' if b'\r\n' in raw else b'\n';needle=('\t# 獨立探針退出前留給排程中的演出清理收尾。\n\tawait get_tree().create_timer(0.5).timeout\n').encode().replace(b'\n',newline);assert raw.count(needle)==1;restored=raw.replace(needle,b'');variants=[restored,restored.replace(b'\r\n',b'\n')];matches=[v for v in variants if hashlib.sha256(v).hexdigest()==s[name]];assert matches;(root/name).write_bytes(matches[0])
assert all(hashlib.sha256((d/n).read_bytes()).hexdigest()==h for n,h in s.items());(b/'source-v3.json').write_text(json.dumps(s,indent=2)+'\n')
design=p/'design/20-campaign-experience/CH2_CH3_SCENE_GAPS.md';text=design.read_text();text+='''

後續正式工具重播仍出現同樣退出留存，0.5秒等待不成立，已精確撤回並核對來源雜湊回到原版。私有候選通過不能代表正式資源載入路徑通過；保留候選與失敗正式重播，進一步取得退出物件種類再決定修正。
''';design.write_text(text,encoding='utf-8');print('Rolled back ineffective exit delay; all10094sources identical to baseline')
