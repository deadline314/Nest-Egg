from pathlib import Path
import hashlib,json
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg46-current');assert not json.loads((b/'settle-diagnostic/result.json').read_text())['engine_error'];source=json.loads((b/'native-v2/source-before.json').read_text());name='tools/ch2_flow_probe.gd';old=(p/name).read_text();assert (p/name).read_bytes()==(d/name).read_bytes();assert hashlib.sha256((d/name).read_bytes()).hexdigest()==source[name]
design=p/'design/20-campaign-experience/CH2_CH3_SCENE_GAPS.md';s=design.read_text();s+='''

目前原生流程全部選項通過，但原工具在Level刪除後只等3個影格便退出，兩次一般輸出都出現12物件／3資源退出留存；詳細輸出重播沒有重現。只在客人簿獨立驗證工具最後給清理0.5秒，私有同流程對照無錯誤後採用，再重跑正式工具確認；不改遊戲、舞台、故事條件或來源。此為驗證工具退出時序處理，沒有定位或宣稱修復引擎內部洩漏根因。
''';design.write_text(s,encoding='utf-8')
needle='\t\tawait _settle(3)\n\tget_tree().quit(1 if _failures > 0 else 0)';assert old.count(needle)==1;new=old.replace(needle,'\t\tawait _settle(3)\n\t# 獨立探針退出前留給排程中的演出清理收尾。\n\tawait get_tree().create_timer(0.5).timeout\n\tget_tree().quit(1 if _failures > 0 else 0)')
for root in [p,d]:(root/name).write_text(new,encoding='utf-8')
after={n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in source};assert [n for n in source if source[n]!=after[n]]==[name];(b/'source-v2.json').write_text(json.dumps(after,indent=2)+'\n');(b/'adoption.json').write_text(json.dumps({'product_paths':[name],'only_probe_shutdown_changed':True,'source_count':len(after),'base':'6181ca48973c6c4651ede2bfd81c0880b64ad03a','first_epoch_images_unchanged_scope':'Only stage_actor_capture was used for 18 direct captures; it does not load ch2_flow_probe. Stage/scene/art/actors all byte-identical across source epochs.'},indent=2)+'\n');print('Adopted only probe exit settle; 10094 sources, one delta')
