from pathlib import Path
import hashlib,json
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg46-current');s=json.loads((b/'source-v3.json').read_text());name='tools/ch2_flow_probe.gd';assert hashlib.sha256((d/name).read_bytes()).hexdigest()==s[name];new=(p/name).read_bytes();assert new.count(b'await AudioRelease.settle(get_tree())')==2
design=p/'design/20-campaign-experience/CH2_CH3_SCENE_GAPS.md';text=design.read_text();text+='''

詳細輸出改用管線收集後重現退出錯誤，明確列出amb_rain_01、amb_city_night_01及safe_clinic的OggPacketSequence／AudioStreamPlaybackOggVorbis，共12物件3資源；不是角色或舞台資源。採現有AudioRelease.settle，只在第二章工具的兩個程序結束入口呼叫，停止音訊並等待混音端釋放（既有400ms上限），不用額外固定延遲、不修改共用音訊框架或正常遊戲聲音。完整保留失敗的0.5秒候選與撤回紀錄，最終只以正式工具原生重播為準。
''';design.write_text(text,encoding='utf-8');(d/name).write_bytes(new);after={n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in s};assert [n for n in s if s[n]!=after[n]]==[name];(b/'source-v4.json').write_text(json.dumps(after,indent=2)+'\n');(b/'audio-adoption.json').write_text(json.dumps({'product_paths':[name],'only_probe_audio_shutdown_changed':True,'source_count':len(after),'base':'6181ca48973c6c4651ede2bfd81c0880b64ad03a','old_sha256':s[name],'new_sha256':after[name]},indent=2)+'\n');print('Adopted existing AudioRelease at both terminal exits')
