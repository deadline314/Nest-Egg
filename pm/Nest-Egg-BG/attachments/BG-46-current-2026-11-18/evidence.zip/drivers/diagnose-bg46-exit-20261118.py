from pathlib import Path
import hashlib,json,os,subprocess
b=Path('D:/NestEggVerification/evidence-20261117/bg46-current');r=Path('D:/NestEggVerification/ne218-baseline-20261117');o=b/'exit-diagnostic';o.mkdir(exist_ok=False);s=json.loads((b/'native-v2/source-before.json').read_text());cmd=json.loads((b/'native-v2/runs.json').read_text())[1]['command'];cmd.insert(cmd.index('--path'),'--verbose');cmd=[('--out='+str(o)) if a.startswith('--out=') else a for a in cmd];env=os.environ.copy()
for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(o/'private-profile'/k)
with (o/'raw.log').open('wb') as f:p=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in s.items());(o/'result.json').write_text(json.dumps({'exit':p.returncode,'source_held':True,'diagnostic_only':True,'command':cmd},indent=2)+'\n');print((o/'raw.log').read_text()[-14000:])
