from pathlib import Path
import hashlib,json,os,subprocess
b=Path('D:/NestEggVerification/evidence-20261117/bg46-current');root=Path('D:/NestEggVerification/ne218-baseline-20261117');out=b/'flow-final-v4';out.mkdir(exist_ok=False);source=json.loads((b/'source-v4.json').read_text());runs=[];passed=False
try:
 for name in ['a','b']:
  f=out/name;f.mkdir();cmd=json.loads((b/'native-v2/runs.json').read_text())[1]['command'];cmd=[('--out='+str(f)) if a.startswith('--out=') else a for a in cmd];env=os.environ.copy()
  for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(f/'private-profile'/k)
  with (f/'raw.log').open('wb') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
  raw=(f/'raw.log').read_bytes();held=all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in source.items());row={'name':name,'command':cmd,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':held};runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
  assert r.returncode==0 and not row['script_errors'] and not row['engine_error'] and held
  s=json.loads((f/'guest-book-result.json').read_text());assert s['failures']==0 and s['credit_delta']==100 and s['book_complete'] and not s['paused']
 passed=True
finally:(out/'result.json').write_text(json.dumps({'passed':passed,'runs':len(runs),'only_probe_audio_shutdown_changed':True},indent=2)+'\n')
