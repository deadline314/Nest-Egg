extends RefCounted
## RAM-only floor intervention. Other profile fields and audio IDs are retained.


static func zones(original: Array[LightingZone]) -> Array[LightingZone]:
	var result: Array[LightingZone] = []
	var transition := LightingZone.new()
	transition.start_tile = 172
	transition.blend_tiles = 4
	transition.profile = original[0].profile.duplicate(false) as LightingProfile
	transition.profile.creature_floor = 0.6
	for i in original.size():
		result.append(original[i])
		if i == 0: result.append(transition)
	return result
