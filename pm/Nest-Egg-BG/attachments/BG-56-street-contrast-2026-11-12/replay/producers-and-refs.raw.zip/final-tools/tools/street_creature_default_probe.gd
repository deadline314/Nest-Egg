extends "res://tools/street_drone_contrast_probe.gd"
## Actual public component no-op, without resetting its materials in the fixture.
var _calls_default := 0


func _primitive_fill_prototype(fill: float) -> void:
	if fill != 0.0:
		_contrast_failures += 1
		printerr("[BG56 Default] This fixture only observes disabled lighting")
	for tick in 120:
		for node in _held55._entities.get_children():
			if node is Enemy and node.creature != null:
				node.creature.set_lighting(0.0, LightKit.creature_light_cap)
				_calls_default += 1


func _capture_street(level: Level, world: Rect2, label: String, color: Color) -> Dictionary:
	var result := await super._capture_street(level, world, label, color)
	var valid: bool = _calls_default > 0 and result.creature_profile_floor == 0.0 and result.creature_fill == 0.0
	for actor in result.enemy_inventory:
		var state: Variant = actor.creature_lighting
		if state == null: continue
		valid = valid and not state.cached_material_exists and state.fill == 0.0
		for binding in state.bindings:
			valid = valid and binding.source_material_restored and binding.self_modulate == binding.source_tint
	result["default_api"] = {"calls": _calls_default, "valid": valid,
		"scope": "real set_lighting(0) calls; no fixture material/tint resets; native RGB A/A with original-zone reference"}
	if not valid:
		_contrast_failures += 1
		printerr("[BG56 Default] Disabled API changed a source binding or allocated a material")
	return result
