extends Node
const Ramp := preload("res://tools/street_creature_ramp.gd")


func _ready() -> void:
	var data := load("res://tools/bg56_reference/ch1_street_initial_candidate.tres") as LevelData
	var before := LightingController.new()
	var after := LightingController.new()
	before._zones = data.lighting_zones
	after._zones = Ramp.zones(data.lighting_zones)
	before._tile = 16
	after._tile = 16
	var a := LightingProfile.new()
	var b := LightingProfile.new()
	var checks := 0
	var failures := 0
	for quarter_tile in range(208 * 4 + 1):
		var x := float(quarter_tile * 4)
		before.zone_state_at(x, a)
		after.zone_state_at(x, b)
		for field in LightingProfile.BLENDED:
			if field == &"creature_floor": continue
			checks += 1
			if a.get(field) != b.get(field): failures += 1
		var t := clampf((x - 2720.0) / 64.0, 0.0, 1.0)
		var expected := 0.6 * t * t * (3.0 - 2.0 * t)
		checks += 1
		if absf(b.creature_floor - expected) > 0.000001: failures += 1
	before.free()
	after.free()
	print("BG56_RAMP_CPU checks=", checks, " failures=", failures, " positions=833; all non-floor blended fields exactly unchanged")
	get_tree().quit(1 if failures else 0)
