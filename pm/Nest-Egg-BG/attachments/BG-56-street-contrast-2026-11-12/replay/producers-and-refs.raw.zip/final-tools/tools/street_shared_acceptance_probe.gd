extends "res://tools/street_shared_contrast_probe.gd"
## Authored street data versus the unchanged shared market/asphalt reference.
## The real controller evaluates both zone lists, including the dock blend.


func _sync55(level: Level) -> void:
	super._sync55(level)
	for node in level._entities.get_children():
		if node is Enemy and node.creature != null:
			node.creature.set_lighting(LightKit.creature_fill, LightKit.creature_light_cap)


func _measure(level: Level, world: Rect2) -> Dictionary:
	if not _fixed_aim or level.player.facing != 1 or not level.player.aim_dir.is_equal_approx(Vector2.RIGHT):
		printerr("[BG56 Acceptance] Fixed aim/facing changed")
		_contrast_failures += 1
	_active_cell55 = _cell55
	_cell55 += 1
	var terrain := level._world.get_node("Terrain") as Terrain
	var edges := terrain.get_node("Edges") as TerrainEdges
	var authored_theme := terrain._theme
	var baseline_theme := authored_theme
	var authored_zones := level._lighting._zones
	var baseline_zones: Array[LightingZone] = []
	if level.data.id == &"ch1_street":
		var before := load("res://tools/bg56_reference/ch1_street_before.tres") as LevelData
		baseline_theme = load("res://tools/bg56_reference/ch1_street_theme_before.tres") as EnvironmentTheme
		for zone in before.lighting_zones: baseline_zones.append(zone)
	else:
		for zone in authored_zones: baseline_zones.append(zone)
	var records: Array[Dictionary] = []
	var baseline_fill := 0.0
	var candidate_fill := 0.0
	for label: String in ["A0", "A1", "product", "restore-product", "authored-final"]:
		var altered := label in ["product", "authored-final"]
		terrain._theme = authored_theme if altered else baseline_theme
		edges._theme = terrain._theme
		for chunk in edges.get_children():
			if chunk is CanvasItem: chunk.queue_redraw()
		level._lighting._zones = authored_zones if altered else baseline_zones
		level._lighting.snap()
		# _apply55 only synchronizes owners and waits, using this actual snap.
		await _apply55(level, level._lighting.current.duplicate() as LightingProfile)
		var color := edges._theme.zone_at(int(level.player.global_position.x / 16.0)).material.edge_color
		var record := await _capture_street(level, world, label, color)
		record["zone_id"] = str(level._lighting.zone_id_at(level.player.global_position.x))
		record["zone_target_x"] = level._lighting._target.global_position.x
		record["profile_values"] = {}
		for field in LightingProfile.BLENDED:
			var value: Variant = level._lighting.current.get(field)
			record.profile_values[str(field)] = _color_values_street(value) if value is Color else value
		if altered: candidate_fill = level._lighting.current.enemy_fill_scale
		else: baseline_fill = level._lighting.current.enemy_fill_scale
		records.append(record)
	var valid := true
	for record in records:
		valid = valid and record.held == records[0].held
		valid = valid and is_equal_approx(float(record.zone_target_x), level.player.global_position.x)
	valid = valid and records[0].raw_sha256 == records[1].raw_sha256 and records[0].raw_sha256 == records[3].raw_sha256
	valid = valid and records[2].raw_sha256 == records[4].raw_sha256
	if not valid:
		_contrast_failures += 1
		printerr("[BG56 Acceptance] A/A, restoration, owner target, or held-state control failed")
	var final: Dictionary = records[-1]
	var passed := valid
	var enemy_values: Array[float] = []
	for enemy in final.enemies:
		enemy_values.append(enemy.contrast)
		passed = passed and bool(enemy.passed)
	var result := {"mean_luma": final.mean_luma, "passed": passed, "enemy_contrast": enemy_values,
		"player_world": [level.player.global_position.x, level.player.global_position.y],
		"facing": level.player.facing, "aim_dir": [level.player.aim_dir.x, level.player.aim_dir.y],
		"lighting_zone": str(level._lighting.zone_id_at(level.player.global_position.x)),
		"street_shared": {"factor": "authored-data", "diagnostic_only": false,
			"baseline_fill_scale": baseline_fill, "candidate_fill_scale": candidate_fill,
			"baseline_edge_color": records[0].street_edge_color, "candidate_edge_color": final.street_edge_color,
			"source_sha256": FileAccess.get_sha256("res://tools/street_shared_acceptance_probe.gd")},
		"bg55": {"diagnostic_only": false, "controls_valid": valid, "records": records,
			"scope": "current authored data and real zone blending; same held scene with unchanged shared market/asphalt reference, not a historical checkout"}}
	if final.player != null:
		result["player_contrast"] = final.player.contrast
		result["edge_contrast"] = final.player.edge_contrast
		result.passed = passed and float(final.player.contrast) >= ContrastProbe.MIN_PLAYER_CONTRAST and float(final.player.edge_contrast) >= ContrastProbe.MIN_EDGE_CONTRAST
	if not result.passed:
		_contrast_failures += 1
		printerr("[BG56 Acceptance] Authored threshold failure: ", result.player_world)
	# Restore actual authored owners before the camera moves to the next cell.
	terrain._theme = authored_theme
	edges._theme = authored_theme
	level._lighting._zones = authored_zones
	level._lighting.snap()
	_sync55(level)
	return result


func _clear_stance_street(level: Level, surface: Rect2) -> float:
	# Pick a real tile center without displacing an authored enemy.
	var candidates: Array[float] = [floorf(surface.get_center().x / 16.0) * 16.0 + 8.0]
	for x in range(int(surface.position.x / 16.0), int(surface.end.x / 16.0)):
		candidates.append(float(x * 16 + 8))
	for x in candidates:
		var clear := true
		for node in level._entities.get_children():
			if node is Enemy and absf(node.global_position.y - surface.position.y) < 58.0 and absf(node.global_position.x - x) < 32.0:
				clear = false
		if clear: return x
	return INF


func _put_on_surface_street(level: Level, x: float, floor_y: float) -> void:
	level.player.visible = true
	level.player.global_position = Vector2(x, floor_y - 2.0)
	var collision := level.player.move_and_collide(Vector2.DOWN * 4.0, false, level.player.safe_margin)
	_contact55 = ground_support(level.player)
	_contact55["visible"] = true
	_contact55["layout_floor"] = floor_y
	_contact55["solver_contact"] = collision != null
	_contact55["solver_normal"] = [collision.get_normal().x, collision.get_normal().y] if collision != null else []
	_contact55["valid"] = collision != null and bool(_contact55.found) and absf(_contact55.gap) <= level.player.safe_margin + 0.001
	if collision != null:
		_contact55.valid = _contact55.valid and collision.get_normal().dot(Vector2.UP) > 0.99
	if not _contact55.valid:
		_contrast_failures += 1
		printerr("[BG56 Acceptance] Supplementary real support failed: ", _contact55)


func _waypoint_street(level: Level, camera: LevelCamera, folder: String, point: Dictionary, view: Vector2) -> Dictionary:
	var center: Vector2 = point.center
	if point.has("surface"):
		_put_on_surface_street(level, point.stance_x, point.surface.position.y)
	elif point.kind == "enemy-coverage":
		var column := int(center.x / level._layout.tile_size)
		var floor_y := level._layout.floor_below(column, 0)
		if is_finite(floor_y):
			_put_on_surface_street(level, column * 16.0 + 8.0, floor_y)
		else:
			_contrast_failures += 1
			printerr("[BG56 Acceptance] Supplementary observer lacks real support")
		level.player.visible = false
		_contact55["visible"] = false
	else:
		_place_player(level, center, view)
	camera.global_position = center
	camera.reset_smoothing()
	camera.force_update_scroll()
	await _settle(SETTLE_FRAMES)
	if level.player.visible:
		_sync_player_light(level.player)
		await _settle(4)
	var inverse := (get_viewport().get_final_transform() * get_viewport().get_canvas_transform()).affine_inverse()
	var start := inverse * Vector2.ZERO
	var end := inverse * Vector2(get_viewport().get_window().size)
	var file := "%s-%s.png" % [_tag, point.key]
	if Capture.image(get_viewport()).save_png(folder.path_join(file)) != OK:
		_contrast_failures += 1
		printerr("[BG56 Acceptance] Cannot preserve native overview: ", file)
	var shot := {"file": file, "column": point.column, "row": point.row,
		"waypoint": point.key, "waypoint_kind": point.kind,
		"world": [start.x, start.y, end.x - start.x, end.y - start.y]}
	if point.has("platform_cells"):
		shot["authored_platform_cells"] = point.platform_cells
	if point.has("enemy_instance"):
		shot["coverage_enemy_instance"] = point.enemy_instance
	shot.merge(await _measure(level, Rect2(start, end - start)))
	return shot


func _tour(level_id: String) -> bool:
	var platform_only := ""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--only-platform="): platform_only = argument.trim_prefix("--only-platform=")
	# Keep the original camera grid exactly, then supplement actual coverage
	# gaps within this same live Level/instance ledger.
	var before := _contrast_failures
	var data := load("res://data/levels/%s.tres" % level_id) as LevelData
	if data == null:
		printerr("[BG56 Acceptance] Missing authored level: ", level_id)
		return false
	var folder := _out.path_join(level_id)
	DirAccess.make_dir_recursive_absolute(folder)
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(data)
	add_child(level)
	await _settle(SETTLE_FRAMES)
	level.hud.visible = false
	for child in level.get_children():
		if child is ChapterCard: child.queue_free()
	level.player.health.setup(999, level.player.tuning.hurt_invulnerability)
	level.player.process_mode = Node.PROCESS_MODE_DISABLED
	for node in level._entities.get_children():
		if node is Enemy: node.process_mode = Node.PROCESS_MODE_DISABLED
	for shadow in level.find_children("ContactShadow", "Node2D", true, false):
		shadow.process_mode = Node.PROCESS_MODE_ALWAYS
	level._lighting._lightning_gap = 1.0e9
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.offset = Vector2.ZERO
	camera.rotation = 0.0
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	var size := level._layout.pixel_size()
	var view := get_viewport().get_visible_rect().size / camera.zoom
	var step := view * (1.0 - OVERLAP)
	var columns := maxi(1, ceili((size.x - view.x) / step.x) + 1)
	var rows := maxi(1, ceili((size.y - view.y) / step.y) + 1)
	var shots: Array[Dictionary] = []
	for row in rows:
		for column in columns:
			if not platform_only.is_empty(): continue
			if not _cells.is_empty() and not _cells.has("%d:%d" % [column, row]): continue
			var center := Vector2(minf(view.x * 0.5 + step.x * column, maxf(view.x * 0.5, size.x - view.x * 0.5)),
				minf(view.y * 0.5 + step.y * row, maxf(view.y * 0.5, size.y - view.y * 0.5)))
			shots.append(await _waypoint_street(level, camera, folder,
				{"center": center, "column": column, "row": row, "kind": "original-grid", "key": "c%02d-r%02d" % [column, row]}, view))
	if _cells.is_empty() and level_id == "ch1_street":
		for cells in level._layout.platform_rects:
			if not platform_only.is_empty() and platform_only != "%d:%d" % [cells.position.x, cells.position.y]: continue
			var surface := level._layout.cells_to_pixels(cells)
			var covered := false
			for shot in shots:
				var support: Dictionary = shot.bg55.records[-1].held.player_support
				if support.get("valid", false) and absf(float(support.layout_floor) - surface.position.y) < 0.1:
					var feet: Array = shot.player_world
					covered = covered or (float(feet[0]) >= surface.position.x and float(feet[0]) < surface.end.x)
			if covered: continue
			var x := _clear_stance_street(level, surface)
			if not is_finite(x):
				_contrast_failures += 1
				printerr("[BG56 Acceptance] No clear stance on authored platform ", cells)
				continue
			shots.append(await _waypoint_street(level, camera, folder,
				{"center": Vector2(x, surface.position.y - 65.0), "column": -1, "row": -1,
				"kind": "platform-coverage", "key": "platform-%d-%d" % [cells.position.x, cells.position.y],
				"surface": surface, "stance_x": x,
				"platform_cells": [cells.position.x, cells.position.y, cells.size.x, cells.size.y]}, view))
		var seen: Dictionary = {}
		for shot in shots:
			var final: Dictionary = shot.bg55.records[-1]
			for actor in final.enemy_inventory:
				if actor.observed and actor.full_body_in_view: seen[int(actor.instance)] = true
		for node in level._entities.get_children():
			if not platform_only.is_empty(): break
			if not node is Enemy or node.health.current <= 0 or node._dying or not node.is_visible_in_tree() or seen.has(node.get_instance_id()): continue
			var center: Vector2 = node.global_position - Vector2(0, 30)
			center.x = clampf(center.x, view.x * 0.5, size.x - view.x * 0.5)
			center.y = clampf(center.y, view.y * 0.5, size.y - view.y * 0.5)
			# The enemy stays authored. A hidden player is explicit for this
			# additional enemy-only view; its owner target remains recorded.
			var point := {"center": center, "column": -2, "row": -2, "kind": "enemy-coverage",
				"key": "enemy-%d" % node.get_instance_id(), "enemy_instance": node.get_instance_id()}
			shots.append(await _waypoint_street(level, camera, folder, point, view))
	var result := {"level": level_id, "tag": _tag, "level_size": [size.x, size.y], "view": [view.x, view.y],
		"columns": columns, "rows": rows, "tile": level._layout.tile_size, "shots": shots,
		"probe": {"fixed_gamepad_aim": _fixed_aim},
		"scope": "original complete grid, followed by uncovered platform and actual live-enemy instance supplements; no performance measurement"}
	var writer := FileAccess.open(folder.path_join(_tag + "-index.json"), FileAccess.WRITE)
	writer.store_string(JSON.stringify(result, "\t") + "\n")
	writer.close()
	level.queue_free()
	await _settle(4)
	Engine.time_scale = _time_scale55
	_held55 = null
	print("STREET_ACCEPTANCE level=", level_id, " original_grid=", columns * rows, " records=", shots.size(), " failures=", _contrast_failures - before)
	return _contrast_failures == before
