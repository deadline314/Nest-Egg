extends Node
## Real data owners and geometry; no claim of native pixel acceptance.
var _checks := 0
var _failures := 0


func _ready() -> void:
	_run.call_deferred()


func _check(value: bool, message: String) -> void:
	_checks += 1
	if not value:
		_failures += 1
		printerr("[BG56 Data] FAIL ", message)


func _run() -> void:
	if OS.get_cmdline_user_args().has("--negative-missing-music"):
		Music._map.zones.erase("street_harbor")
	for pair: Array in [["street_market", "market", "enemy_fill_scale"], ["street_market_creature", "street_market", "creature_floor"], ["street_harbor", "harbor_approach", "creature_floor"]]:
		var local := load("res://data/lighting/%s.tres" % pair[0]) as LightingProfile
		var original := load("res://data/lighting/%s.tres" % pair[1]) as LightingProfile
		_check(local.id == StringName(pair[0]) and local.validate().is_empty(), "local profile validates: " + pair[0])
		for field in LightingProfile.BLENDED:
			var expected: Variant = (1.0 if pair[2] == "enemy_fill_scale" else 0.6) if str(field) == pair[2] else original.get(field)
			_check(local.get(field) == expected, "only declared field changes: %s/%s" % [pair[0], field])
		for property in original.lamp_style.get_property_list():
			if int(property.usage) & PROPERTY_USAGE_STORAGE:
				_check(local.lamp_style.get(property.name) == original.lamp_style.get(property.name), "lamp data stays exact: " + str(property.name))
		_check(Ambience.layers_for(StringName(pair[0])) == Ambience.layers_for(StringName(pair[1])), "real ambience owner preserves all layers and volumes")
		var layers: Array = Ambience._profiles[pair[0]]
		Ambience._profiles.erase(pair[0])
		_check(Ambience.layers_for(StringName(pair[0])) != Ambience.layers_for(StringName(pair[1])), "negative: missing ambience alias really loses ambience")
		Ambience._profiles[pair[0]] = layers
		var registered: bool = Music._map.zones.has(pair[0])
		_check(registered, "explicit local music route exists: " + pair[0])
		if not registered: continue
		for state in Music.STATES:
			_check(Music.resolve_cue(&"ch1_street", StringName(pair[0]), state) == Music.resolve_cue(&"ch1_street", StringName(pair[1]), state), "real street music owner preserves " + str(state))
			_check(Music.resolve_cue(&"", StringName(pair[0]), state) == Music.resolve_cue(&"", StringName(pair[1]), state), "zone-only music preserves " + str(state))
		var cue: Dictionary = Music._map.zones[pair[0]]
		Music._map.zones.erase(pair[0])
		_check(not Music._map.zones.has(pair[0]), "negative: missing music alias really removes explicit registration")
		var differs: bool = Music.resolve_cue(&"", StringName(pair[0]), &"calm") != Music.resolve_cue(&"", StringName(pair[1]), &"calm")
		_check(differs if pair[1] in ["market", "street_market"] else not differs, "actual fallback cue is different for market and already equal for harbor")
		Music._map.zones[pair[0]] = cue
	var before := load("res://tools/bg56_reference/ch1_street_theme_before.tres") as EnvironmentTheme
	var theme := load("res://data/environment/themes/ch1_street.tres") as EnvironmentTheme
	_check(theme.validate().is_empty(), "complete new theme validates")
	var asphalt := before.zone_at(0).material
	for x in 208:
		var local := theme.zone_at(x).material
		var pale := (x >= 76 and x < 82) or (x >= 98 and x < 104) or (x >= 122 and x < 126) or (x >= 164 and x < 170)
		var expected_id := &"street_asphalt_platform" if x >= 98 and x < 104 else &"street_asphalt" if pale else &"asphalt"
		_check(local.id == expected_id, "only four narrow material intervals: " + str(x))
		for field in ["body", "top", "side", "top_height", "side_width", "texture_scale"]:
			_check(local.get(field) == asphalt.get(field), "original wet material/normal geometry: %d/%s" % [x, field])
		_check(theme.zone_at(x).facades == before.zone_at(x).facades and theme.zone_at(x).hole_chance == before.zone_at(x).hole_chance, "facades and hole chance unchanged: " + str(x))
	var data := load("res://data/levels/ch1_street.tres") as LevelData
	var layout := LevelBuilder.parse(data)
	var old_wall := BackWallGeometry.new()
	old_wall.setup(layout, hash(data.id), before)
	var new_wall := BackWallGeometry.new()
	new_wall.setup(layout, hash(data.id), theme)
	for field in ["holes", "outdoor", "facade_top", "ground", "deep", "modules", "support_rects"]:
		_check(old_wall.get(field) == new_wall.get(field), "actual wall geometry identical: " + field)
	var terrain := Terrain.new()
	terrain._theme = theme
	_check(terrain.material_id_at(Vector2(2008, 256)) == &"street_asphalt", "real terrain material lookup uses local platform material")
	_check(terrain.material_id_at(Vector2(1624, 256)) == &"street_asphalt_platform", "only remaining platform uses stronger local edge")
	_check(Footsteps.surface_for_material(&"street_asphalt_platform") == Footsteps.surface_for_material(&"asphalt"), "second narrow edge keeps actual original wet footsteps")
	_check(Footsteps.surface_for_material(&"street_asphalt") == Footsteps.surface_for_material(&"asphalt"), "real footstep owner preserves wet surface")
	for kind in [&"step", &"land"]:
		_check(Footsteps.name_for(Footsteps.surface_for_material(&"street_asphalt"), kind) == Footsteps.name_for(Footsteps.surface_for_material(&"asphalt"), kind), "real original footstep/landing sound: " + str(kind))
	var surface: String = Footsteps._materials.street_asphalt
	Footsteps._materials.erase("street_asphalt")
	_check(Footsteps.surface_for_material(&"street_asphalt") != Footsteps.surface_for_material(&"asphalt"), "negative: absent material alias falls back to wrong surface")
	Footsteps._materials.street_asphalt = surface
	terrain.free()
	var previews: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/lighting_preview/scenes.json"))
	_check(previews.presets.street_market == ["harbor_street"] and previews.presets.street_market_creature == ["harbor_street"] and previews.presets.street_harbor == ["harbor_street"], "all local presets have real scene preview registrations")
	await AudioRelease.settle(get_tree())
	print("BG56_DATA checks=", _checks, " failures=", _failures, " (data owners/geometry only)")
	get_tree().quit(1 if _failures else 0)
