extends "res://tools/street_shared_masked_probe.gd"
## RAM single factor on the actual remaining low edge failure.

func _measure(level: Level, world: Rect2) -> Dictionary:
	if not _fixed_aim or level.player.facing != 1 or not level.player.aim_dir.is_equal_approx(Vector2.RIGHT):
		printerr("[BG56 Acceptance] Fixed aim/facing changed")
		_contrast_failures += 1
	_active_cell55 = _cell55
	_cell55 += 1
	var terrain := level._world.get_node("Terrain") as Terrain
	var edges := terrain.get_node("Edges") as TerrainEdges
	var authored_theme := terrain._theme
	var baseline_theme := authored_theme
	authored_theme = _copy_surface_street(authored_theme)
	authored_theme.zone_at(98).material.edge_color = Color(1.10, 1.14, 1.20, 1.0)
	var authored_zones := level._lighting._zones
	var baseline_zones: Array[LightingZone] = []
	for zone in authored_zones: baseline_zones.append(zone)
	var records: Array[Dictionary] = []
	var baseline_fill := 0.0
	var candidate_fill := 0.0
	for label: String in ["A0", "A1", "product", "restore-product", "authored-final"]:
		var altered := label in ["product", "authored-final"]
		terrain._theme = authored_theme if altered else baseline_theme
		edges._theme = terrain._theme
		for chunk in edges.get_children():
			if chunk is CanvasItem: chunk.queue_redraw()
		level._lighting._zones = authored_zones if altered else baseline_zones
		level._lighting.snap()
		# _apply55 only synchronizes owners and waits, using this actual snap.
		await _apply55(level, level._lighting.current.duplicate() as LightingProfile)
		var color := edges._theme.zone_at(int(level.player.global_position.x / 16.0)).material.edge_color
		var record := await _capture_street(level, world, label, color)
		record["zone_id"] = str(level._lighting.zone_id_at(level.player.global_position.x))
		record["zone_target_x"] = level._lighting._target.global_position.x
		record["profile_values"] = {}
		for field in LightingProfile.BLENDED:
			var value: Variant = level._lighting.current.get(field)
			record.profile_values[str(field)] = _color_values_street(value) if value is Color else value
		if altered: candidate_fill = level._lighting.current.enemy_fill_scale
		else: baseline_fill = level._lighting.current.enemy_fill_scale
		records.append(record)
	var valid := true
	for record in records:
		valid = valid and record.held == records[0].held
		valid = valid and is_equal_approx(float(record.zone_target_x), level.player.global_position.x)
	valid = valid and records[0].raw_sha256 == records[1].raw_sha256 and records[0].raw_sha256 == records[3].raw_sha256
	valid = valid and records[2].raw_sha256 == records[4].raw_sha256
	if not valid:
		_contrast_failures += 1
		printerr("[BG56 Acceptance] A/A, restoration, owner target, or held-state control failed")
	var final: Dictionary = records[-1]
	var passed := valid
	var enemy_values: Array[float] = []
	for enemy in final.enemies:
		enemy_values.append(enemy.contrast)
		passed = passed and bool(enemy.passed)
	var result := {"mean_luma": final.mean_luma, "passed": passed, "enemy_contrast": enemy_values,
		"player_world": [level.player.global_position.x, level.player.global_position.y],
		"facing": level.player.facing, "aim_dir": [level.player.aim_dir.x, level.player.aim_dir.y],
		"lighting_zone": str(level._lighting.zone_id_at(level.player.global_position.x)),
		"street_shared": {"factor": "edge-margin", "diagnostic_only": true,
			"baseline_fill_scale": baseline_fill, "candidate_fill_scale": candidate_fill,
			"baseline_edge_color": records[0].street_edge_color, "candidate_edge_color": final.street_edge_color,
			"source_sha256": FileAccess.get_sha256("res://tools/street_edge_margin_probe.gd")},
		"bg55": {"diagnostic_only": true, "controls_valid": valid, "records": records,
			"scope": "RAM single edge-strength intervention on platform98; no other authored field changes"}}
	if final.player != null:
		result["player_contrast"] = final.player.contrast
		result["edge_contrast"] = final.player.edge_contrast
		result.passed = passed and float(final.player.contrast) >= ContrastProbe.MIN_PLAYER_CONTRAST and float(final.player.edge_contrast) >= ContrastProbe.MIN_EDGE_CONTRAST
	if not result.passed:
		_contrast_failures += 1
		printerr("[BG56 Acceptance] Authored threshold failure: ", result.player_world)
	# Restore actual authored owners before the camera moves to the next cell.
	terrain._theme = authored_theme
	edges._theme = authored_theme
	level._lighting._zones = authored_zones
	level._lighting.snap()
	_sync55(level)
	return result

