extends Node
## Explicit public Hurtbox component lab on the authored drone. Not player input.
const Capture := preload("res://tools/viewport_capture.gd")
const Street := preload("res://tools/street_shared_contrast_probe.gd")
const Held := preload("res://tools/held_lighting_state.gd")
var _out := ""
var _quality := "high"
var _failures := 0
var _records: Array[Dictionary] = []


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
		elif arg.begins_with("--quality="): _quality = arg.trim_prefix("--quality=")
	if OS.get_cmdline_user_args().has("--validate-only"):
		print("STREET_DAMAGE_CPU compiled=true (not native validation)")
		get_tree().quit()
		return
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		push_error("[BG56 Damage] Native and absolute output required")
		get_tree().quit(2)
		return
	_run.call_deferred()


func _check(value: bool, message: String) -> void:
	if value: return
	_failures += 1
	printerr("[BG56 Damage] FAIL ", message)


func _capture(level: Level, target: Enemy, label: String) -> void:
	await RenderingServer.frame_post_draw
	if not is_instance_valid(target): return
	var probe := ContrastProbe.capture(get_viewport())
	var name := "%02d-%s" % [_records.size(), label]
	var raw := FileAccess.open(_out.path_join(name + ".bin"), FileAccess.WRITE)
	raw.store_buffer(probe._image.get_data())
	raw.close()
	_check(Capture.encode(probe._image, true).save_png(_out.path_join(name + ".png")) == OK, "PNG saved")
	_records.append({"label": label, "file": name + ".png", "raw": name + ".bin",
		"raw_sha256": FileAccess.get_sha256(_out.path_join(name + ".bin")),
		"format": probe._image.get_format(), "width": probe._image.get_width(), "height": probe._image.get_height(),
		"physics_frame": Engine.get_physics_frames(), "hp": target.health.current,
		"dying": target._dying, "actor_modulate": Street._color_values_street(target.modulate),
		"rotation": target.rotation, "feet": [target.global_position.x, target.global_position.y],
		"lighting": Street._creature_lighting_street(target),
		"viewport_final": Held.transform_values(get_viewport().get_final_transform()),
		"canvas_transform": Held.transform_values(probe._to_screen), "density": probe._scale,
		"floor": level._lighting.current.creature_floor, "fill": LightKit.creature_fill})
	if label == "hurt-flash":
		_check(target.creature._flash_left > 0.0, "first rendered hurt frame actually contains flash")


func _run() -> void:
	DirAccess.make_dir_recursive_absolute(_out)
	Settings.use_storage("user://bg56_damage.cfg")
	var previous_quality := Settings.get_light_quality()
	var previous_brightness := Settings.get_brightness()
	Settings.set_light_quality(LightQuality.Tier.LOW if _quality == "low" else LightQuality.Tier.HIGH)
	Settings.set_brightness(0.5)
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids(): Story._seen[StringName(id)] = true
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(load("res://data/levels/ch1_street.tres") as LevelData)
	add_child(level)
	var target: Enemy
	for node in level._entities.get_children():
		if node is Enemy:
			if node.data.id == &"drone" and is_equal_approx(node.global_position.x, 2984.0): target = node
			else:
				for child in node.get_children():
					if child is VisibleOnScreenEnabler2D: child.free()
				node.process_mode = Node.PROCESS_MODE_DISABLED
	_check(target != null, "original drone exists")
	if target == null:
		get_tree().quit(1)
		return
	var initial_hp := target.health.current
	var stats := target.data.duplicate() as EnemyData
	level.player.health.setup(999, level.player.tuning.hurt_invulnerability)
	level.player.global_position = Vector2(2984, 318)
	level.hud.visible = false
	level._lighting._lightning_gap = 1.0e9
	for node in level.find_children("*", "", true, false):
		if node is WorldPrompt:
			node.visible = false
			node.process_mode = Node.PROCESS_MODE_DISABLED
		elif node is ChapterCard: node.queue_free()
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.offset = Vector2.ZERO
	camera.zoom = Vector2.ONE * 1.5
	camera.global_position = Vector2(2984, 250)
	camera.reset_smoothing()
	camera.force_update_scroll()
	for frame in 24: await get_tree().physics_frame
	level._lighting.snap()
	await _capture(level, target, "before-public-damage")
	var material_id := target.creature._light_material.get_instance_id()
	var info := DamageInfo.create(1, Combat.Team.PLAYER, &"bg56_component_damage")
	info.origin = level.player.global_position
	info.contact_point = target.hurtbox.center()
	# The previous capture returned at frame_post_draw. Dispatch this public
	# hit at the next process-frame boundary, after physics and before draw,
	# so catch-up physics cannot expire the flash before its first PNG.
	await get_tree().process_frame
	var first_result := target.hurtbox.receive(info)
	_check(first_result == Hurtbox.Result.DAMAGED and target.health.current == initial_hp - 1, "public damage dispatch")
	await _capture(level, target, "hurt-flash")
	var started := Time.get_ticks_msec()
	while is_instance_valid(target) and (target.creature._flash_left > 0.0 or target.health.is_invulnerable()) and Time.get_ticks_msec() - started < 3000:
		await get_tree().physics_frame
	_check(is_instance_valid(target) and target.creature._flash_left == 0.0, "native flash recovers")
	await _capture(level, target, "recovered-wear")
	_check(target.creature._light_material.get_instance_id() == material_id, "same instance material after flash")
	_check(target.data.max_health == stats.max_health and target.data.contact_damage == stats.contact_damage and target.data.ability_speed == stats.ability_speed, "original combat stats retained")
	var fatal := DamageInfo.create(initial_hp - 1, Combat.Team.PLAYER, &"bg56_component_damage")
	fatal.origin = level.player.global_position
	fatal.contact_point = target.hurtbox.center()
	var fatal_result := target.hurtbox.receive(fatal)
	_check(fatal_result == Hurtbox.Result.DAMAGED and target.health.is_dead and target._dying, "public fatal damage starts original death")
	await _capture(level, target, "death-start")
	started = Time.get_ticks_msec()
	var faded := false
	var turned := false
	while is_instance_valid(target) and Time.get_ticks_msec() - started < 4000:
		for frame in 8: await get_tree().physics_frame
		if not is_instance_valid(target): break
		faded = faded or target.modulate.a < 0.95
		turned = turned or absf(target.rotation) > 0.1
		await _capture(level, target, "native-death")
	_check(not is_instance_valid(target) and faded and turned, "original spin/fall/fade/free remains active")
	level.queue_free()
	for frame in 4: await get_tree().process_frame
	Settings.set_light_quality(previous_quality)
	Settings.set_brightness(previous_brightness)
	var output := {"quality": _quality, "failures": _failures, "records": _records,
		"scope": "explicit Hurtbox.receive component lab; original authored health and death path, no direct HP/FSM/death writes; not shooting or human play"}
	var file := FileAccess.open(_out.path_join("damage.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(output, "\t") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	print("STREET_DAMAGE records=", _records.size(), " failures=", _failures)
	get_tree().quit(1 if _failures else 0)
