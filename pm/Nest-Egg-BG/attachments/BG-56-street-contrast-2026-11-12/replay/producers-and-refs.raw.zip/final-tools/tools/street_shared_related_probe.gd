extends "res://tools/bg49_held_readability_probe.gd"
## BG56 leaf only. Keep the published BG49 tools unchanged; compare the old
## harbor profile with the street-only clone at the same original dock point.


func _ready() -> void:
	_reference49 = "res://data/lighting/harbor_approach.tres"
	super._ready()


func _sync55(level: Level) -> void:
	super._sync55(level)
	for node in level._entities.get_children():
		if node is Enemy and node.creature != null:
			node.creature.set_lighting(LightKit.creature_fill, LightKit.creature_light_cap)
