extends "res://tools/street_shared_acceptance_probe.gd"
## Current-profile single factors on the originally missed authored drone.
## No product, creature texture, actor pose, health, AI or position is changed.

const BEE_FACTORS := ["identity", "enemy-fill1", "character-floor1", "contrast1", "contrast098", "fog1", "fog2", "rim1"]
var _primitive_states: Array[Dictionary] = []
var _primitive_material: ShaderMaterial


func _primitive_fill_prototype(fill: float) -> void:
	if fill > 0.0:
		_primitive_material = ShaderMaterial.new()
		_primitive_material.shader = CharacterRig.LIGHT_SHADER
		_primitive_material.set_shader_parameter("fill", fill)
		_primitive_material.set_shader_parameter("light_cap", LightKit.character_light_cap_for(LightKit.ambient_luma, fill) * LightKit.ENEMY_LIGHT_GAIN)
	for state in _primitive_states:
		var sprite: Sprite2D = state.sprite
		sprite.material = _primitive_material if fill > 0.0 else state.material
		var original: Color = state.self_modulate
		sprite.self_modulate = Color(original.r * fill, original.g * fill, original.b * fill, original.a) if fill > 0.0 else original


func _bee_materials(enemy: Enemy) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for node in enemy.find_children("*", "Sprite2D", true, false):
		var sprite := node as Sprite2D
		var shader := sprite.material as ShaderMaterial
		var texture := sprite.texture as CanvasTexture
		result.append({"path": str(enemy.get_path_to(sprite)), "material_class": sprite.material.get_class() if sprite.material != null else "null",
			"shader_path": shader.shader.resource_path if shader != null else "", "use_parent_material": sprite.use_parent_material,
			"shader_fill": shader.get_shader_parameter("fill") if shader != null else null,
			"shader_light_cap": shader.get_shader_parameter("light_cap") if shader != null else null,
			"light_mask": sprite.light_mask, "visible": sprite.is_visible_in_tree(),
			"modulate": _color_values_street(sprite.modulate), "self_modulate": _color_values_street(sprite.self_modulate),
			"diffuse": texture.diffuse_texture.resource_path if texture != null and texture.diffuse_texture != null else "",
			"normal": texture.normal_texture.resource_path if texture != null and texture.normal_texture != null else ""})
	return result


func _bee_measure(level: Level, world: Rect2, factor: String) -> Dictionary:
	_active_cell55 = _cell55
	_cell55 += 1
	var baseline := level._lighting.current.duplicate() as LightingProfile
	var candidate := baseline.duplicate() as LightingProfile
	match factor:
		"enemy-fill1": candidate.enemy_fill_scale = 1.0
		"character-floor1": candidate.character_floor = 1.0
		"contrast1": candidate.contrast = 1.0
		"contrast098": candidate.contrast = 0.98
		"fog1": candidate.fog_density = 1.0
		"fog2": candidate.fog_density = 2.0
		"rim1": candidate.rim_energy = 1.0
	var color := (load("res://data/environment/materials/asphalt.tres") as TerrainMaterialData).edge_color
	var records: Array[Dictionary] = []
	var prototype_fill := 0.0
	match factor:
		"creature-shader1": prototype_fill = 1.0
		"creature-fill24": prototype_fill = 2.4
		"creature-fill3": prototype_fill = 3.0
		"creature-fill4": prototype_fill = 4.0
	for label: String in ["A0", "A1", "product", "restore-product", "authored-final"]:
		var altered := label in ["product", "authored-final"]
		var profile := candidate if altered else baseline
		_primitive_fill_prototype(prototype_fill if altered else 0.0)
		await _apply55(level, profile)
		var record := await _capture_street(level, world, label, color)
		record["prototype_creature_fill"] = prototype_fill if altered else 0.0
		var all_restored := true
		for original in _primitive_states:
			all_restored = all_restored and original.sprite.material == original.material and original.sprite.self_modulate == original.self_modulate
		record["all_primitive_source_materials_restored"] = all_restored
		record["profile_values"] = {}
		for field in LightingProfile.BLENDED:
			var value: Variant = profile.get(field)
			record.profile_values[str(field)] = _color_values_street(value) if value is Color else value
		for node in level._entities.get_children():
			if node is Enemy and is_equal_approx(node.global_position.x, 2984.0):
				record["part_creature_materials"] = _bee_materials(node)
		records.append(record)
	var valid := true
	for record in records: valid = valid and record.held == records[0].held
	valid = valid and records[0].raw_sha256 == records[1].raw_sha256 and records[0].raw_sha256 == records[3].raw_sha256
	valid = valid and records[2].raw_sha256 == records[4].raw_sha256
	if not valid:
		_contrast_failures += 1
		printerr("[BG56 Bee] Single-factor held control failed: ", factor)
	var passed: bool = valid and not records[-1].enemies.is_empty()
	for enemy in records[-1].enemies: passed = passed and enemy.passed
	var result := {"column": -2, "row": -2, "waypoint": "bee-" + factor, "passed": passed,
		"player_world": [level.player.global_position.x, level.player.global_position.y], "facing": level.player.facing,
		"aim_dir": [level.player.aim_dir.x, level.player.aim_dir.y], "world": [world.position.x, world.position.y, world.size.x, world.size.y],
		"street_shared": {"factor": factor, "diagnostic_only": true,
			"baseline_fill_scale": baseline.enemy_fill_scale, "candidate_fill_scale": candidate.enemy_fill_scale,
			"baseline_edge_color": _color_values_street(color), "candidate_edge_color": _color_values_street(color),
			"source_sha256": FileAccess.get_sha256("res://tools/street_drone_contrast_probe.gd")},
		"bg55": {"diagnostic_only": true, "controls_valid": valid, "records": records,
			"scope": "single current-profile field on the same authored PartCreature/held scene, not product acceptance or a historical checkout"}}
	_primitive_fill_prototype(0.0)
	await _apply55(level, baseline)
	return result


func _tour(level_id: String) -> bool:
	var before := _contrast_failures
	var folder := _out.path_join(level_id)
	DirAccess.make_dir_recursive_absolute(folder)
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	# Keep the original zone reference after authored local data exists.
	# This is current runtime/geometry with declared reference data, not an old checkout.
	var reference := "res://tools/bg56_reference/ch1_street_before.tres"
	level.configure(load(reference if ResourceLoader.exists(reference) else "res://data/levels/ch1_street.tres") as LevelData)
	add_child(level)
	await _settle(SETTLE_FRAMES)
	_primitive_states.clear()
	for node in level._entities.get_children():
		if node is Enemy and node.creature != null:
			for child in node.find_children("*", "Sprite2D", true, false):
				var sprite := child as Sprite2D
				_primitive_states.append({"sprite": sprite, "material": sprite.material, "self_modulate": sprite.self_modulate})
	level.hud.visible = false
	level.player.health.setup(999, level.player.tuning.hurt_invulnerability)
	level.player.process_mode = Node.PROCESS_MODE_DISABLED
	for child in level.get_children():
		if child is ChapterCard: child.queue_free()
	_put_on_surface_street(level, 2984.0, 320.0)
	level.player.visible = false
	_contact55.visible = false
	level._lighting._lightning_gap = 1.0e9
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.offset = Vector2.ZERO
	camera.rotation = 0.0
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	camera.global_position = Vector2(2984, 162)
	camera.reset_smoothing()
	camera.force_update_scroll()
	await _settle(SETTLE_FRAMES)
	var inverse := (get_viewport().get_final_transform() * get_viewport().get_canvas_transform()).affine_inverse()
	var start := inverse * Vector2.ZERO
	var end := inverse * Vector2(get_viewport().get_window().size)
	var shots: Array[Dictionary] = []
	var factors: Array = ["identity", "creature-shader1", "creature-fill24", "creature-fill3", "creature-fill4"] if OS.get_cmdline_user_args().has("--bee-prototype-only") else BEE_FACTORS
	if OS.get_cmdline_user_args().has("--bee-default-api"): factors = ["identity"]
	for factor in factors:
		shots.append(await _bee_measure(level, Rect2(start, end - start), factor))
	var writer := FileAccess.open(folder.path_join(_tag + "-index.json"), FileAccess.WRITE)
	writer.store_string(JSON.stringify({"level": level_id, "shots": shots, "probe": {"fixed_gamepad_aim": _fixed_aim},
		"scope": "stationary PartCreature single-factor diagnostics; source positions and original canonical body kernel unchanged"}, "\t") + "\n")
	writer.close()
	_primitive_states.clear()
	_primitive_material = null
	level.queue_free()
	await _settle(4)
	Engine.time_scale = _time_scale55
	_held55 = null
	print("STREET_BEE factors=", shots.size(), " failures=", _contrast_failures - before)
	return before == _contrast_failures
