extends Node
## Headless state/ownership checks; native pixels are verified separately.

var _checks := 0
var _failures := 0


func _ready() -> void:
	_run.call_deferred()


func _check(value: bool, message: String) -> void:
	_checks += 1
	if not value:
		_failures += 1
		printerr("[BG56 Creature CPU] FAIL ", message)


func _run() -> void:
	var profile := LightingProfile.new()
	_check(profile.creature_floor == 0.0, "old profiles default to no material/tint ownership")
	_check(profile.validate().is_empty(), "default profile remains valid")
	profile.creature_floor = NAN
	_check(not profile.validate().is_empty(), "non-finite optional floor is rejected")
	profile.creature_floor = 1.1
	_check(not profile.validate().is_empty(), "floor above one is rejected")
	profile.creature_floor = -0.1
	_check(not profile.validate().is_empty(), "negative floor is rejected")
	profile.creature_floor = 0.6
	var zero := LightingProfile.new()
	var blended := LightingProfile.new()
	LightingProfile.blend_into(blended, zero, profile, 0.5)
	_check(is_equal_approx(blended.creature_floor, 0.3), "real zone interpolation includes optional floor")
	LightingProfile.copy_into(blended, profile)
	_check(is_equal_approx(blended.creature_floor, 0.6), "profile copy includes optional floor")
	var legacy := 0
	for file in DirAccess.get_files_at("res://data/lighting"):
		if file.ends_with(".tres") and not file.begins_with("street_"):
			var data := load("res://data/lighting/" + file) as LightingProfile
			_check(data.creature_floor == 0.0, "existing profile keeps default: " + file)
			legacy += 1
	var creature := PartCreature.new()
	add_child(creature)
	_check(creature.setup("drone"), "real authored creature loads")
	creature.animate(0.0, &"idle")
	var originals: Array[Dictionary] = []
	for part in creature._parts:
		var sprite: Sprite2D = part.sprite
		originals.append({"material": sprite.material, "tint": sprite.self_modulate,
			"texture": sprite.texture, "transform": sprite.global_transform})
	creature.set_lighting(0.0, 0.5)
	_check(creature._light_material == null, "disabled initial state allocates no material")
	for i in creature._parts.size():
		var sprite: Sprite2D = creature._parts[i].sprite
		_check(sprite.material == originals[i].material and sprite.self_modulate == originals[i].tint,
			"disabled default writes no appearance: " + str(i))
	creature.set_lighting(2.4, 0.608)
	var cached := creature._light_material
	_check(cached != null and cached.shader == PartCreature.LIGHT_SHADER, "enabled uses existing normal-aware/capped shader")
	_check(is_equal_approx(float(cached.get_shader_parameter("fill")), 2.4), "actual material receives requested fill")
	_check(is_equal_approx(float(cached.get_shader_parameter("light_cap")), 0.608), "actual material receives cap")
	for tick in 120: creature.set_lighting(2.4, 0.608)
	_check(creature._light_material == cached, "unchanged frames reuse the same instance material")
	for i in creature._parts.size():
		var sprite: Sprite2D = creature._parts[i].sprite
		var tint: Color = originals[i].tint
		_check(sprite.self_modulate.is_equal_approx(Color(tint.r * 2.4, tint.g * 2.4, tint.b * 2.4, tint.a)), "authored tint/alpha receives fill: " + str(i))
		_check(sprite.texture == originals[i].texture and sprite.global_transform == originals[i].transform,
			"normal/diffuse texture and pose remain unchanged: " + str(i))
	creature.flash()
	var flash := creature.modulate
	creature.set_lighting(2.4, 0.608)
	_check(creature.modulate == flash and creature._flash_left > 0.0, "lighting preserves real flash state and parent color")
	creature.set_wear(Color(0.8, 0.7, 0.6, 1))
	creature.animate(0.0, &"idle")
	var wear := creature.modulate
	creature.set_lighting(3.0, 0.4)
	_check(creature.modulate == wear, "lighting preserves parent wear and flash")
	var sprite: Sprite2D = creature._parts[0].sprite
	var foreign := ShaderMaterial.new()
	var shader := Shader.new()
	shader.code = "shader_type canvas_item; render_mode unshaded;"
	foreign.shader = shader
	sprite.material = foreign
	var effect_tint := Color(1, 0.2, 0.1, 0.6)
	sprite.self_modulate = effect_tint
	creature.set_lighting(4.0, 0.32)
	_check(sprite.material == foreign and sprite.self_modulate == effect_tint, "active external emission/dissolve shader and tint win")
	sprite.material = originals[0].material
	sprite.self_modulate = originals[0].tint
	creature.set_lighting(4.0, 0.32)
	_check(sprite.material == cached and sprite.self_modulate.r > effect_tint.r, "foreign effect release resumes area lighting without a fill change")
	var last_tint := sprite.self_modulate
	sprite.material = foreign
	creature.set_lighting(0.0, 0.5)
	_check(sprite.material == foreign and sprite.self_modulate == last_tint, "disabling does not overwrite an active external material")
	sprite.material = originals[0].material
	creature.set_lighting(0.0, 0.5)
	_check(not creature._lighting_pending, "deferred restoration finishes after effect release")
	for i in creature._parts.size():
		var part: Sprite2D = creature._parts[i].sprite
		_check(part.material == originals[i].material and part.self_modulate == originals[i].tint,
			"area exit restores exact original material/tint: " + str(i))
	# The disabled state must also leave pre-existing custom effects untouched.
	sprite.material = foreign
	sprite.self_modulate = effect_tint
	creature.set_lighting(0.0, 0.5)
	_check(sprite.material == foreign and sprite.self_modulate == effect_tint, "default zero preserves a pre-existing custom effect")
	creature.set_lighting(2.4, 0.608)
	_check(sprite.material == foreign and sprite.self_modulate == effect_tint, "enabling does not replace a pre-existing custom effect")
	creature.set_lighting(0.0, 0.5)
	creature.queue_free()
	for tick in 4: await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("BG56_CREATURE_CPU checks=", _checks, " failures=", _failures, " legacy_profiles=", legacy, " (state/ownership only, not native pixels)")
	get_tree().quit(1 if _failures else 0)
