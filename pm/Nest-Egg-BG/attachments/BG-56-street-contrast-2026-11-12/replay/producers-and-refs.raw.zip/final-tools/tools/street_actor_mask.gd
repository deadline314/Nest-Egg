extends RefCounted
## Tool-only physical coverage. Full native skeletons/UVs/bone weights are
## duplicated without scripts; all other characters retain black occlusion.
const LightShader := preload("res://art/shaders/character_light.gdshader")
const Capture := preload("res://tools/viewport_capture.gd")
const Held := preload("res://tools/held_lighting_state.gd")
const INSTANCE_DEFAULTS := {"sway_a": Vector4.ZERO, "sway_b": Vector4.ZERO,
	"sway_a_shape": Vector2.ZERO, "sway_b_shape": Vector2.ZERO,
	"sway_padding": 24.0, "sway_bounds": Vector2.ZERO}
var _owner: Node
var _out: String
var _view: SubViewport
var _key := ""
var _actors: Array[Dictionary] = []
var _proof: Dictionary = {}
var _images: Dictionary = {}
var _frames: Dictionary = {}
var _shaders: Dictionary = {}
var _blank := false
var _offset := 0.0
var _proof_file := ""
var _proof_sha := ""
var _known_answers: Dictionary = {}


func _init(owner: Node, out: String) -> void:
	_owner = owner
	_out = out
	_blank = OS.get_cmdline_user_args().has("--blank-actor-mask")
	_offset = 8.0 if OS.get_cmdline_user_args().has("--offset-actor-mask") else 0.0


static func _sha(data: PackedByteArray) -> String:
	var hash := HashingContext.new()
	hash.start(HashingContext.HASH_SHA256)
	hash.update(data)
	return hash.finish().hex_encode()


static func _numbers(rect: Rect2i) -> Array[int]:
	return [rect.position.x, rect.position.y, rect.size.x, rect.size.y]


static func _near(a: Transform2D, b: Transform2D) -> bool:
	var av := Held.transform_values(a)
	var bv := Held.transform_values(b)
	for i in 6:
		if absf(av[i] - bv[i]) > 0.0003: return false
	return true


static func _effective_z(item: CanvasItem) -> int:
	var z := item.z_index
	if item.z_as_relative and item.get_parent() is CanvasItem:
		z += _effective_z(item.get_parent() as CanvasItem)
	return z


static func _copy_at(root: Node, copy: Node, source: Node) -> CanvasItem:
	# duplicate sanitizes generated @Sprite2D names. Pair by native child
	# indices, then verify class/order/transforms; do not silently omit them.
	var indices: Array[int] = []
	var node := source
	while node != root:
		indices.push_front(node.get_index())
		node = node.get_parent()
		if node == null: return null
	var target := copy
	for index in indices:
		if index >= target.get_child_count(): return null
		target = target.get_child(index)
	return target as CanvasItem


func _shader(source: Shader) -> Shader:
	var key := source.resource_path if source != null else "plain"
	if _shaders.has(key): return _shaders[key]
	var code := "shader_type canvas_item; render_mode unshaded; uniform float mask_value = 0.0; uniform bool opaque_only = false; void fragment() { if (opaque_only && mask_value > 0.5 && COLOR.a < 0.999) { discard; } COLOR = vec4(vec3(mask_value), COLOR.a); }"
	if source != null:
		# Only this known shader is supported. Retain its actual sway/UV alpha
		# and native skeletal skinning; replace final RGB, never vertex/alpha.
		if source != LightShader: return null
		code = source.code
		var start := code.find("void fragment()")
		var opening := code.find("{", start)
		var depth := 1
		var end := opening + 1
		while end < code.length() and depth > 0:
			if code[end] == "{": depth += 1
			elif code[end] == "}": depth -= 1
			end += 1
		if start < 0 or opening < 0 or depth != 0: return null
		code = code.insert(end - 1, "\n if (opaque_only && mask_value > 0.5 && COLOR.a < 0.999) { discard; }\n COLOR.rgb = vec3(mask_value);\n")
		code = code.replace("shader_type canvas_item;", "shader_type canvas_item;\nrender_mode unshaded;\nuniform float mask_value = 0.0;\nuniform bool opaque_only = false;")
	var result := Shader.new()
	result.code = code
	_shaders[key] = result
	var path := _out.path_join("mask-shader-" + _sha(code.to_utf8_buffer()).substr(0, 16) + ".gdshader")
	var file := FileAccess.open(path, FileAccess.WRITE)
	file.store_buffer(code.to_utf8_buffer())
	file.close()
	return result


func validate_shader() -> void:
	# A coverage sum of two alpha=.99 sources can round to 1 in RGBAH.
	# The separate opaque pass must reject it, while retaining a genuine
	# opaque source below a semi layer of the same physical actor.
	var view := SubViewport.new()
	view.size = Vector2i(16, 16)
	view.transparent_bg = true
	view.use_hdr_2d = true
	view.disable_3d = true
	view.world_2d = World2D.new()
	view.world_3d = World3D.new()
	view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	_owner.add_child(view)
	var nodes: Array[Sprite2D] = []
	var materials: Array[ShaderMaterial] = []
	for i in 2:
		var sprite := Sprite2D.new()
		sprite.centered = false
		var material := ShaderMaterial.new()
		material.shader = _shader(null)
		sprite.material = material
		view.add_child(sprite)
		nodes.append(sprite)
		materials.append(material)
	var valid := true
	var rows: Array[Dictionary] = []
	for case: Array in [["semi-only", 0.99, 0.99, 1.0, 0.9999, 0.0],
		["opaque-under-own-semi", 1.0, 0.99, 1.0, 1.0, 1.0],
		["other-actor-semi-occludes", 1.0, 0.5, 0.0, 0.5, 0.5],
		["empty", 0.0, 0.0, 1.0, 0.0, 0.0]]:
		for i in 2:
			var image := Image.create(16, 16, false, Image.FORMAT_RGBAF)
			image.fill(Color(1, 1, 1, float(case[i + 1])))
			nodes[i].texture = ImageTexture.create_from_image(image)
			materials[i].set_shader_parameter("mask_value", 1.0 if i == 0 else float(case[3]))
		var values: Array[float] = []
		for opaque in [false, true]:
			for material in materials: material.set_shader_parameter("opaque_only", opaque)
			for frame in 2: await _owner.get_tree().process_frame
			await RenderingServer.frame_post_draw
			var image := view.get_texture().get_image()
			values.append(image.get_pixel(8, 8).r)
		var passed := absf(values[0] - float(case[4])) < 0.002 and absf(values[1] - float(case[5])) < 0.002
		valid = valid and passed
		rows.append({"case": case[0], "source_alphas": [case[1], case[2]], "front_selected": case[3],
			"coverage": values[0], "opaque": values[1], "expected": [case[4], case[5]], "passed": passed})
	_known_answers = {"valid": valid, "cases": rows, "scope": "same native shader, two uniform 16x16 RGBAF sources; no scene lighting/post"}
	view.queue_free()
	for frame in 2: await _owner.get_tree().process_frame


func _signature(level: Level, viewport: Viewport, size: Vector2i) -> String:
	var values: Array = [size, viewport.get_final_transform(), viewport.get_canvas_transform()]
	for actor in level._entities.get_children():
		if not WorldLayers.is_character(actor) or not actor.is_visible_in_tree(): continue
		values.append([actor.get_instance_id(), actor.global_transform, actor.modulate.a])
		for node in actor.find_children("*", "CanvasItem", true, false):
			values.append([str(actor.get_path_to(node)), node.is_visible_in_tree(), node.get_global_transform(), node.modulate.a, node.self_modulate.a])
			if node is Sprite2D: values.append([node.texture.get_instance_id() if node.texture != null else 0, node.get_rect(), node.flip_h, node.flip_v])
			elif node is Polygon2D: values.append([node.texture.get_instance_id() if node.texture != null else 0, node.polygon, node.uv, node.polygons, node.offset])
			if node is Bone2D: values.append(node.rest)
			for uniform in INSTANCE_DEFAULTS:
				var value: Variant = node.get_instance_shader_parameter(uniform) if node.material is ShaderMaterial and (node.material as ShaderMaterial).shader == LightShader else null
				values.append(value if value != null else INSTANCE_DEFAULTS[uniform])
	return _sha(var_to_bytes(values))


func _foreground_bounds(level: Level) -> Array[Rect2]:
	var result: Array[Rect2] = []
	if level._foreground == null or not level._foreground.is_visible_in_tree(): return result
	for node in level._foreground._static.find_children("*", "Sprite2D", true, false):
		if node.is_visible_in_tree():
			# Parallax repeat copies are renderer instances, not child nodes.
			# An unlimited horizontal envelope conservatively covers every copy.
			var bound: Rect2 = (node.global_transform * node.get_rect()).grow(ForegroundLayer.SWAY_AMPLITUDE + 1.0)
			bound.position.x = -1.0e9
			bound.size.x = 2.0e9
			result.append(bound)
	return result


func prepare(level: Level, viewport: Viewport, size: Vector2i) -> Dictionary:
	var key := _signature(level, viewport, size)
	if key == _key: return _proof
	if is_instance_valid(_view): _view.queue_free()
	_key = key
	_images.clear()
	_frames.clear()
	_actors.clear()
	var valid: bool = bool(_known_answers.get("valid", false))
	var rows: Array[Dictionary] = []
	var foreground := _foreground_bounds(level)
	_view = SubViewport.new()
	_view.size = size
	_view.transparent_bg = true
	_view.use_hdr_2d = true
	_view.disable_3d = true
	_view.world_2d = World2D.new()
	_view.world_3d = World3D.new()
	_view.canvas_item_default_texture_filter = viewport.canvas_item_default_texture_filter
	_view.canvas_item_default_texture_repeat = viewport.canvas_item_default_texture_repeat
	_view.msaa_2d = viewport.msaa_2d
	_view.snap_2d_transforms_to_pixel = viewport.snap_2d_transforms_to_pixel
	_view.snap_2d_vertices_to_pixel = viewport.snap_2d_vertices_to_pixel
	_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	_owner.add_child(_view)
	var matrix := viewport.get_final_transform() * viewport.get_canvas_transform()
	_view.canvas_transform = matrix
	_view.canvas_transform.origin += Vector2(_offset, 0)
	valid = valid and _near(_view.canvas_transform, matrix)
	for actor in level._entities.get_children():
		if not WorldLayers.is_character(actor) or not actor.is_visible_in_tree(): continue
		var root: Node2D
		var physical: Array[CanvasItem] = []
		if actor is Player:
			root = actor._visual.rig
			physical.assign(actor._visual.rig._parts)
			if actor._visual.rig._weapon_sprite != null: physical.append(actor._visual.rig._weapon_sprite)
		elif actor is Enemy:
			if actor.rig != null:
				root = actor.rig
				physical.assign(actor.rig._parts)
				if actor.rig._weapon_sprite != null: physical.append(actor.rig._weapon_sprite)
			elif actor.creature != null:
				root = actor.creature
				for part in actor.creature._parts: physical.append(part.sprite)
		if root == null:
			valid = false
			continue
		if not root.find_children("*", "RemoteTransform2D", true, false).is_empty() or not root.find_children("*", "CollisionObject2D", true, false).is_empty():
			valid = false
			continue
		var ancestor: Node = root
		while ancestor != null:
			if ancestor is CanvasItem and (not is_equal_approx(ancestor.modulate.a, 1.0) or ancestor.clip_children != CanvasItem.CLIP_CHILDREN_DISABLED): valid = false
			ancestor = ancestor.get_parent()
		var copy := root.duplicate(0) as Node2D
		copy.process_mode = Node.PROCESS_MODE_DISABLED
		_view.add_child(copy)
		copy.global_transform = root.global_transform
		copy.z_as_relative = false
		copy.z_index = _effective_z(root)
		copy.visible = root.visible and not _blank
		var materials: Array[ShaderMaterial] = []
		var allowed: Dictionary = {}
		var bounds := Rect2()
		var first := true
		for original in physical:
			allowed[str(root.get_path_to(original))] = true
		for original in root.find_children("*", "CanvasItem", true, false):
			var path := root.get_path_to(original)
			var target := _copy_at(root, copy, original)
			if target == null:
				valid = false
				continue
			var transforms_match := _near(original.get_global_transform(), target.get_global_transform())
			valid = valid and transforms_match and original.visible == target.visible
			valid = valid and original.get_class() == target.get_class() and original.get_index() == target.get_index() and _effective_z(original) == _effective_z(target)
			var row := {"actor": actor.get_instance_id(), "path": str(path), "native_type": original.get_class(),
				"copy_native_type": target.get_class(), "source_sibling_index": original.get_index(), "copy_sibling_index": target.get_index(),
				"source_z": _effective_z(original), "copy_z": _effective_z(target),
				"source_global": Held.transform_values(original.get_global_transform()),
				"copy_global": Held.transform_values(target.get_global_transform()), "same_visible": original.visible == target.visible,
				"source_alpha": original.modulate.a, "copy_alpha": target.modulate.a,
				"source_self_alpha": original.self_modulate.a, "copy_self_alpha": target.self_modulate.a}
			if original is Bone2D:
				row["source_rest"] = Held.transform_values(original.rest)
				row["copy_rest"] = Held.transform_values((target as Bone2D).rest)
				valid = valid and _near(original.rest, (target as Bone2D).rest)
			if original is Sprite2D or original is Polygon2D:
				if not allowed.has(str(path)):
					target.visible = false
					row["excluded_nonphysical_glow"] = true
				else:
					var source_shader := original.material as ShaderMaterial
					if original.use_parent_material or (original.material is CanvasItemMaterial and (original.material as CanvasItemMaterial).blend_mode != CanvasItemMaterial.BLEND_MODE_MIX): valid = false
					var shader := _shader(source_shader.shader if source_shader != null else null)
					if shader == null:
						valid = false
					else:
						var material := ShaderMaterial.new()
						material.shader = shader
						if source_shader != null:
							for uniform in source_shader.shader.get_shader_uniform_list():
								if not INSTANCE_DEFAULTS.has(uniform.name): material.set_shader_parameter(uniform.name, source_shader.get_shader_parameter(uniform.name))
						target.material = material
						materials.append(material)
						if source_shader != null:
							for uniform in INSTANCE_DEFAULTS:
								var value: Variant = original.get_instance_shader_parameter(uniform)
								target.set_instance_shader_parameter(uniform, value if value != null else INSTANCE_DEFAULTS[uniform])
					if original is Sprite2D:
						valid = valid and original.texture == (target as Sprite2D).texture and original.get_rect() == (target as Sprite2D).get_rect()
						var at: Rect2 = original.global_transform * original.get_rect()
						bounds = at if first else bounds.merge(at)
						first = false
					elif original is Polygon2D:
						var polygon := target as Polygon2D
						valid = valid and original.polygon == polygon.polygon and original.uv == polygon.uv and original.polygons == polygon.polygons and original.skeleton == polygon.skeleton
						row["source_polygon_sha256"] = _sha(var_to_bytes(original.polygon))
						row["copy_polygon_sha256"] = _sha(var_to_bytes(polygon.polygon))
						row["source_uv_sha256"] = _sha(var_to_bytes(original.uv))
						row["copy_uv_sha256"] = _sha(var_to_bytes(polygon.uv))
						row["bone_count"] = original.get_bone_count()
						var bones: Array[Dictionary] = []
						valid = valid and original.get_bone_count() == polygon.get_bone_count()
						for i in original.get_bone_count():
							var same: bool = original.get_bone_path(i) == polygon.get_bone_path(i) and original.get_bone_weights(i) == polygon.get_bone_weights(i)
							valid = valid and same
							bones.append({"path": str(original.get_bone_path(i)), "copy_path": str(polygon.get_bone_path(i)), "weights_unchanged": same,
								"source_weights_sha256": _sha(var_to_bytes(original.get_bone_weights(i))), "copy_weights_sha256": _sha(var_to_bytes(polygon.get_bone_weights(i)))})
						row["bone_bindings"] = bones
						if polygon.get_bone_count() > 0:
							var skeleton := polygon.get_node_or_null(polygon.skeleton) as Skeleton2D
							valid = valid and skeleton != null and copy.is_ancestor_of(skeleton)
							row["skeleton_relative_path"] = str(polygon.skeleton)
							row["skeleton_inside_copy"] = skeleton != null and copy.is_ancestor_of(skeleton)
			rows.append(row)
		# Rig bounds use the renderer's real deformed vertices; weapon bounds
		# above are merged without replacing that native mesh-aware envelope.
		if root is CharacterRig:
			var rig_bounds := (root as CharacterRig).visual_bounds()
			bounds = rig_bounds if first else bounds.merge(rig_bounds)
			first = false
		var foreground_clear := not first
		for foreground_bound in foreground:
			foreground_clear = foreground_clear and not bounds.intersects(foreground_bound)
		# Keep foreground intact in the main image. The independent H lower
		# bound excludes its entire repeated/sway envelope, even transparent
		# holes. W still includes all white pixels in this conservative region.
		valid = valid and not first
		_actors.append({"instance": actor.get_instance_id(), "materials": materials, "copy": copy,
			"source_actor_index": actor.get_index(), "copy_actor_index": copy.get_index(), "root_z": copy.z_index,
			"world_bounds": bounds, "foreground_clear": foreground_clear})
	_proof = {"valid": valid, "signature": key, "rows": rows, "actor_count": _actors.size(),
		"shader_known_answers": _known_answers,
		"main_matrix": Held.transform_values(matrix), "mask_matrix": Held.transform_values(_view.canvas_transform),
		"blank_negative": _blank, "offset_negative_pixels": _offset,
		"foreground_policy": "exclude entire projected envelope from opaque denominator; keep original main foreground unchanged",
		"scope": "complete native skeleton/weights/UVs, no scripts/normal lighting/post; black physical characters preserve draw order; static WorldLayers behind actors; projected foreground envelopes excluded from denominator"}
	_proof["foreground_bounds"] = []
	for bound in foreground:
		_proof.foreground_bounds.append([bound.position.x, bound.position.y, bound.size.x, bound.size.y])
	_proof["actor_draw_order"] = []
	for actor in _actors:
		_proof.actor_draw_order.append({"instance": actor.instance, "source_index": actor.source_actor_index,
			"copy_index": actor.copy_actor_index, "effective_root_z": actor.root_z, "foreground_clear": actor.foreground_clear,
			"physical_world_bounds": [actor.world_bounds.position.x, actor.world_bounds.position.y, actor.world_bounds.size.x, actor.world_bounds.size.y]})
	var proof_bytes := (JSON.stringify(_proof, "\t") + "\n").to_utf8_buffer()
	_proof_file = "mask-proof-" + key.substr(0, 20) + ".json"
	_proof_sha = _sha(proof_bytes)
	var proof_file := FileAccess.open(_out.path_join(_proof_file), FileAccess.WRITE)
	proof_file.store_buffer(proof_bytes)
	proof_file.close()
	return _proof


func capture(instance: int, directory: String, opaque_only: bool = false) -> Dictionary:
	var cache_key := str(instance) + ("-opaque" if opaque_only else "-coverage")
	if _images.has(cache_key): return _images[cache_key]
	var found := false
	var bounds := Rect2()
	for actor in _actors:
		var selected: bool = int(actor.instance) == instance
		if selected:
			found = true
			bounds = actor.world_bounds
		for material: ShaderMaterial in actor.materials:
			material.set_shader_parameter("mask_value", 1.0 if selected else 0.0)
			material.set_shader_parameter("opaque_only", opaque_only)
	for frame in 2: await _owner.get_tree().process_frame
	await RenderingServer.frame_post_draw
	var image := _view.get_texture().get_image()
	var valid: bool = found and _proof.valid and image.get_format() in [Image.FORMAT_RGBAH, Image.FORMAT_RGBAF]
	var matrix := _view.canvas_transform
	var projected := matrix * bounds.grow(24.0)
	var start := Vector2i(projected.position.floor()).max(Vector2i.ZERO)
	var end := Vector2i(projected.end.ceil()).min(image.get_size())
	var rect := Rect2i(start, end - start)
	var positive := 0
	var opaque := 0
	for y in range(rect.position.y, rect.end.y):
		for x in range(rect.position.x, rect.end.x):
			var pixel := image.get_pixel(x, y)
			if maxf(pixel.r, maxf(pixel.g, pixel.b)) > 0.0: positive += 1
			if minf(pixel.r, minf(pixel.g, pixel.b)) >= 0.999: opaque += 1
	valid = valid and positive > 0
	var raw := image.get_data()
	var sha := _sha(raw)
	var name := "actor-mask-" + sha.substr(0, 20)
	var file := FileAccess.open(directory.path_join(name + ".bin"), FileAccess.WRITE)
	file.store_buffer(raw)
	file.close()
	valid = valid and Capture.encode(image, true).save_png(directory.path_join(name + ".png")) == OK
	var result := {"valid": valid, "instance": instance, "width": image.get_width(), "height": image.get_height(),
		"format": image.get_format(), "raw_sha256": sha, "raw": name + ".bin", "png": name + ".png",
		"positive_pixels": positive, "opaque_pixels": opaque, "coverage_threshold": 0.999,
		"opaque_only": opaque_only, "source_alpha_cutoff": 0.999 if opaque_only else 0.0,
		"opaque_policy": "discard selected semi fragments; retain qualifying opaque sources below; other actors remain black with original alpha",
		"containing_rect": _numbers(rect), "pose_signature": _key,
		"proof_file": _proof_file, "proof_sha256": _proof_sha, "proof_valid": _proof.valid}
	_images[cache_key] = result
	_frames[cache_key] = image
	return result


func frame(instance: int) -> Image:
	return _frames.get(instance) as Image


func clear() -> void:
	if is_instance_valid(_view): _view.queue_free()
	_view = null
	_key = ""
	_actors.clear()
	_images.clear()
	_frames.clear()
