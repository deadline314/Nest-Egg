extends Node
## Real authored AI in its actual level. Only player test position/durability
## and non-target suspension are arranged; no enemy health/FSM/stat writes.
const Capture := preload("res://tools/viewport_capture.gd")
const Held := preload("res://tools/held_lighting_state.gd")
const Ramp := preload("res://tools/street_creature_ramp.gd")
const Street := preload("res://tools/street_shared_contrast_probe.gd")
var _out := ""
var _quality := "high"
var _failures := 0
var _records: Array[Dictionary] = []
var _environment: WorldEnvironment


func _ready() -> void:
	Settings.use_storage("user://street_action_settings.cfg")
	if OS.get_cmdline_user_args().has("--validate-only"):
		var level_data := load("res://data/levels/ch1_street.tres") as LevelData
		var brute := load("res://data/enemies/collector_brute.tres") as EnemyData
		var sweeper := load("res://data/enemies/sweeper.tres") as EnemyData
		var valid: bool = level_data != null and brute.rig_skin == "collector_brute" and sweeper.rig_skin == "sweeper"
		print("STREET_ACTION_CPU valid=", valid, " (loading/compile only; not native AI validation)")
		get_tree().quit(0 if valid else 1)
		return
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
		elif arg.begins_with("--quality="): _quality = arg.trim_prefix("--quality=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		push_error("[BG56 Action] Requires native rendering and absolute --out")
		get_tree().quit(2)
		return
	_environment = LightKit.create_environment()
	add_child(_environment)
	var overlay := CanvasLayer.new()
	add_child(overlay)
	var caption := Label.new()
	caption.position = Vector2(8, 340)
	caption.text = "BG56 / AI LAB"
	caption.add_theme_font_size_override("font_size", 11)
	overlay.add_child(caption)
	_run.call_deferred()


func _check(value: bool, message: String) -> void:
	if not value:
		_failures += 1
		printerr("[BG56 Action] FAIL ", message)


static func _stats(data: EnemyData) -> Dictionary:
	var result := {"id": str(data.id), "skin": data.rig_skin, "creature_skin": data.creature_skin, "weapon": data.rig_weapon,
		"behavior": data.behavior.resource_path, "projectile": data.projectile.resource_path if data.projectile != null else ""}
	for field in ["max_health", "move_speed", "contact_damage", "detect_range", "attack_range", "attack_cooldown", "telegraph_time", "ability_speed", "ability_time", "ability_radius", "ability_damage", "uses_gravity"]:
		result[field] = data.get(field)
	return result


func _run() -> void:
	DirAccess.make_dir_recursive_absolute(_out)
	var quality_before := Settings.get_light_quality()
	var brightness_before := Settings.get_brightness()
	Settings.set_light_quality(LightQuality.Tier.LOW if _quality == "low" else LightQuality.Tier.HIGH)
	Settings.set_brightness(0.5)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids(): Story._seen[StringName(id)] = true
	Input.action_press(&"aim_right")
	for id in ([&"drone"] if OS.get_cmdline_user_args().has("--ramp-only") else [&"collector_brute", &"sweeper", &"drone"]):
		await _observe(id)
	Input.action_release(&"aim_right")
	Settings.set_light_quality(quality_before)
	Settings.set_brightness(brightness_before)
	var result := {"scope": "Actual level and original enemy AI; test player placed 72 world pixels left on original ground (drone stays at authored air spawn), 999 HP with authored hurt invulnerability; other enemies remain drawn with AI/enablers suspended; lightning suppressed; no enemy FSM/health/stat/position writes; not human play",
		"engine": Engine.get_version_info().string, "adapter": RenderingServer.get_video_adapter_name(),
		"renderer": RenderingServer.get_current_rendering_method(), "hdr_2d": get_viewport().use_hdr_2d,
		"ram_anticipatory_floor": OS.get_cmdline_user_args().has("--ramp-only"), "quality": _quality, "brightness": 0.5, "simulation_time_scale": Engine.time_scale,
		"failures": _failures, "actors": _records}
	var file := FileAccess.open(_out.path_join("actions.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(result, "  ") + "\n")
	file.close()
	await AudioRelease.settle(get_tree())
	print("STREET_ACTION actors=%d failures=%d" % [_records.size(), _failures])
	get_tree().quit(1 if _failures else 0)


func _observe(id: StringName) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	var level_data := load("res://data/levels/ch1_street.tres") as LevelData
	if OS.get_cmdline_user_args().has("--ramp-only"):
		level_data = load("res://tools/bg56_reference/ch1_street_initial_candidate.tres") as LevelData
		level_data = level_data.duplicate(false) as LevelData
		level_data.lighting_zones = Ramp.zones(level_data.lighting_zones)
	level.configure(level_data)
	add_child(level)
	var target: Enemy
	var expected_x := 2136.0 if id == &"collector_brute" else 2984.0 if id == &"drone" else 1352.0
	for node in level._entities.get_children():
		if node is Enemy:
			if target == null and node.data.id == id and is_equal_approx(node.global_position.x, expected_x):
				target = node
			else:
				# Keep non-target sprites at their original positions, with their
				# AI suspended even when the camera activates their enabler.
				for enabler in node.get_children():
					if enabler is VisibleOnScreenEnabler2D: enabler.free()
				node.process_mode = Node.PROCESS_MODE_DISABLED
	_check(target != null, "authored target exists: " + str(id))
	if target == null:
		level.queue_free()
		await get_tree().process_frame
		return
	var enemy_start := target.global_position
	var original_hp := target.health.current
	var original_stats := _stats(target.data)
	var inventory_before: Array[Dictionary] = []
	for node in level._entities.get_children():
		if node is Enemy:
			inventory_before.append({"instance": node.get_instance_id(), "id": str(node.data.id),
				"feet": [node.global_position.x, node.global_position.y], "hp": node.health.current,
				"visible": node.is_visible_in_tree(), "target": node == target})
	level.player.health.setup(999, level.player.tuning.hurt_invulnerability)
	level.player.global_position = Vector2(target.global_position.x - 72.0, 318.0)
	level.player.velocity = Vector2.ZERO
	AimInput.set_virtual_gamepad(level.player, true)
	level.hud.visible = false
	level._lighting._lightning_gap = 1.0e9
	for node in level.find_children("*", "", true, false):
		if node is WorldPrompt:
			node.visible = false
			node.process_mode = Node.PROCESS_MODE_DISABLED
		elif node is ChapterCard: node.queue_free()
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.offset = Vector2.ZERO
	camera.zoom = Vector2.ONE * (1.5 if id == &"drone" else LevelCamera.base_zoom())
	camera.global_position = Vector2(enemy_start.x - 36.0, 250.0) if id == &"drone" else enemy_start + Vector2(-36, -50)
	camera.reset_smoothing()
	camera.force_update_scroll()
	# Moving the test player after Level._ready changes the owner target.
	# Synchronize the real area once before observing natural AI; keep all
	# subsequent live controller and creature updates on their normal paths.
	level._lighting.snap()
	for node in level._entities.get_children():
		if node is Enemy and node.creature != null:
			node.creature.set_lighting(LightKit.creature_fill, LightKit.creature_light_cap)
	# Let the actual visibility enabler, camera and collision solver run.
	# No enemy pose/state/HP is assigned for this preparation.
	for frame in 24: await get_tree().physics_frame
	_check(PhysicsServer2D.body_get_space(target.get_rid()).is_valid(), "target activation retains real physics space before observation")
	_check(PhysicsServer2D.body_get_space(level.player.get_rid()).is_valid(), "player physics space ready before observation")
	var started := Time.get_ticks_msec()
	var timeline: Array[Dictionary] = []
	var captures: Array[Dictionary] = []
	var states: Dictionary = {}
	var captured: Dictionary = {}
	var projectiles: Dictionary = {}
	while Time.get_ticks_msec() - started < 8000:
		await get_tree().physics_frame
		var state := str(target.fsm.current)
		states[state] = true
		var tick := {"physics_frame": Engine.get_physics_frames(), "milliseconds": Time.get_ticks_msec() - started,
			"state": state, "state_time": target.fsm.time_in_state, "action": str(target._rig_input.action),
			"action_t": target._rig_input.action_t, "enemy_feet": [target.global_position.x, target.global_position.y],
			"player_feet": [level.player.global_position.x, level.player.global_position.y],
			"enemy_hp": target.health.current, "player_hp": level.player.health.current,
			"enemy_ground_support": Street.ground_support(target),
			"player_ground_support": Street.ground_support(level.player),
			"enemy_body_space_valid": PhysicsServer2D.body_get_space(target.get_rid()).is_valid(),
			"player_body_space_valid": PhysicsServer2D.body_get_space(level.player.get_rid()).is_valid(),
			"enemy_frozen": Fx.is_frozen(target), "player_frozen": Fx.is_frozen(level.player),
			"enemy_process_mode": target.process_mode, "player_process_mode": level.player.process_mode,
			"rig_fill": target.rig._fill if target.rig != null else null, "light_cap": target.rig._light_cap if target.rig != null else null, "creature_lighting": Street._creature_lighting_street(target),
			"weapon_light_origin_error": level.player._weapon_light.global_position.distance_to(level.player.aim_origin().lerp(level.player.muzzle_position(), Player.WEAPON_LIGHT_ORIGIN))}
		timeline.append(tick)
		for bullet in ProjectilePool.container().get_children():
			if bullet is Projectile and bullet.active and bullet.team == Combat.Team.ENEMY:
				projectiles[str(bullet.get_instance_id())] = {"source": str(bullet.spec.source_id), "at": [bullet.global_position.x, bullet.global_position.y]}
		var phase := mini(2, int(target.fsm.time_in_state / 0.2))
		var key := "%s-%d" % [state, phase]
		if not captured.has(key) and captures.size() < 15:
			captured[key] = true
			await RenderingServer.frame_post_draw
			# The render can occur after a physics transition. Keep the trigger
			# separately and label the actual image with its post-draw state.
			var rendered_state := str(target.fsm.current)
			var probe := ContrastProbe.capture(get_viewport())
			var visual_bounds := Street._visual_bounds_street(target)
			var weapon: Sprite2D = target.rig._weapon_sprite if target.rig != null else null
			if weapon != null and weapon.texture != null and weapon.is_visible_in_tree():
				visual_bounds = visual_bounds.merge(weapon.global_transform * weapon.get_rect())
			var filename := "%s-%02d-%s" % [id, captures.size(), rendered_state]
			var raw := FileAccess.open(_out.path_join(filename + ".bin"), FileAccess.WRITE)
			raw.store_buffer(probe._image.get_data())
			raw.close()
			_check(Capture.encode(probe._image, get_viewport().use_hdr_2d).save_png(_out.path_join(filename + ".png")) == OK, "native action PNG saved")
			var parts := probe.character_parts(target.global_position, false)
			captures.append({"file": filename + ".png", "raw": filename + ".bin", "format": probe._image.get_format(),
				"raw_sha256": FileAccess.get_sha256(_out.path_join(filename + ".bin")),
				"size": [probe._image.get_width(), probe._image.get_height()], "state": rendered_state,
				"trigger_state": state, "physics_frame": Engine.get_physics_frames(), "milliseconds": Time.get_ticks_msec() - started,
				"state_time": target.fsm.time_in_state, "action": str(target._rig_input.action), "action_t": target._rig_input.action_t,
				"enemy_feet": [target.global_position.x, target.global_position.y],
				"player_feet": [level.player.global_position.x, level.player.global_position.y],
				"enemy_ground_support": Street.ground_support(target),
				"player_ground_support": Street.ground_support(level.player),
				"parts": parts, "contrast": maxf(parts.bright, parts.dark),
				"body_screen_rect": Street.rect_values(probe._screen_rect(probe._body_box(target.global_position, false))),
				"outer_screen_rect": Street.rect_values(probe._screen_rect(probe._body_box(target.global_position, false).grow(ContrastProbe.RING))),
				"rig_fill": target.rig._fill if target.rig != null else null, "light_cap": target.rig._light_cap if target.rig != null else null, "creature_lighting": Street._creature_lighting_street(target),
				"profile": str(level._lighting.zone_id_at(level.player.global_position.x)),
				"enemy_fill_scale": level._lighting.current.enemy_fill_scale,
				"world_environment_active": get_viewport().find_world_3d().environment == _environment.environment,
				"glow_enabled": _environment.environment.glow_enabled,
				"weapon_light_origin_error_post_draw": level.player._weapon_light.global_position.distance_to(level.player.aim_origin().lerp(level.player.muzzle_position(), Player.WEAPON_LIGHT_ORIGIN)),
				"visual_world_bounds": str(visual_bounds),
				"visual_world_bounds_values": [visual_bounds.position.x, visual_bounds.position.y, visual_bounds.size.x, visual_bounds.size.y],
				"viewport_final_transform_values": Held.transform_values(get_viewport().get_final_transform()),
				"canvas_transform": str(probe._to_screen), "canvas_transform_values": Held.transform_values(probe._to_screen), "density": probe._scale})
	_check((states.has("lock") and states.has("climb")) if id == &"drone" else states.has("windup" if id == &"collector_brute" else "aim") and states.has("recover"), "real AI completes telegraph and recovery: " + str(id))
	_check(states.has("leap") if id == &"collector_brute" else states.has("dive") if id == &"drone" else not projectiles.is_empty(), "real authored slash/projectiles observed: " + str(id))
	_check(target.health.current == original_hp, "enemy HP remains authored and unmodified")
	_check(_stats(target.data) == original_stats, "authored identity and combat stats remain unchanged")
	_check(is_equal_approx(level.player.health.invulnerability_time, level.player.tuning.hurt_invulnerability), "authored player hurt protection retained")
	_records.append({"id": str(id), "skin": target.data.rig_skin, "spawn_feet": [enemy_start.x, enemy_start.y],
		"stats_before": original_stats, "stats_after": _stats(target.data),
		"inventory_before": inventory_before,
		"enemy_data_sha256": FileAccess.get_sha256("res://data/enemies/%s.tres" % id), "states": states.keys(),
		"projectiles": projectiles, "timeline": timeline, "captures": captures})
	level.queue_free()
	for _frame in 4: await get_tree().process_frame
