extends "res://tools/street_shared_acceptance_probe.gd"
## Static authored acceptance plus native visible physical-actor masks.
const ActorMask := preload("res://tools/street_actor_mask.gd")
var _masks: ActorMask


func _capture_street(level: Level, world: Rect2, label: String, color: Color) -> Dictionary:
	var result := await super._capture_street(level, world, label, color)
	var directory := _out.path_join(str(level.data.id))
	if _masks == null:
		_masks = ActorMask.new(self, directory)
		await _masks.validate_shader()
	var proof: Dictionary = _masks.prepare(level, get_viewport(), Vector2i(result.width, result.height))
	var valid: bool = proof.valid
	var exposures: Array[Dictionary] = []
	for enemy in result.enemies:
		var mask: Dictionary = await _masks.capture(int(enemy.instance), directory)
		var opaque: Dictionary = await _masks.capture(int(enemy.instance), directory, true)
		valid = valid and bool(mask.valid) and bool(opaque.valid)
		exposures.append({"instance": enemy.instance, "id": enemy.id, "feet": enemy.feet, "physical_mask": mask, "opaque_mask": opaque,
			"white_threshold": 0.92, "limit": 0.02,
			"scope": "native physical coverage and opaque-pixel denominator lower bound; independent NP computes conservative white numerator, not a background-area ratio"})
	if bytes_sha(get_viewport().get_texture().get_image().get_data()) != result.raw_sha256:
		valid = false
		printerr("[BG56 Mask] Main HDR frame changed during read-only mask rendering")
	result["physical_exposure"] = {"controls_valid": valid, "observations": exposures,
		"mask_source": "full native skeleton/texture clones without scripts; original main rendering unchanged",
		"mask_source_sha256": FileAccess.get_sha256("res://tools/street_actor_mask.gd"),
		"acceptance_pending_independent_pixels": true}
	if not valid:
		_contrast_failures += 1
		printerr("[BG56 Mask] Invalid position/bone/draw-order/foreground or empty physical mask")
	return result


func _tour(level_id: String) -> bool:
	var result := await super._tour(level_id)
	if _masks != null:
		_masks.clear()
		_masks = null
		for frame in 2: await get_tree().process_frame
	return result
