extends "res://tools/street_shared_acceptance_probe.gd"
## Explicit RAM-only candidate, before authoring any product data.
## Four originally failing platform intervals; no enemy/geometry changes.

var _prepared_street: Level


func _settle(frames: int) -> void:
	await super._settle(frames)
	if is_instance_valid(_held55) and (not is_instance_valid(_prepared_street) or _prepared_street != _held55):
		_prepare_candidate_street(_held55)
		await RenderingServer.frame_post_draw


func _prepare_candidate_street(level: Level) -> void:
	var zones: Array[LightingZone] = []
	for original in level._lighting._zones:
		var zone := original.duplicate(false) as LightingZone
		if zone.profile.id == &"market":
			zone.profile = original.profile.duplicate(false) as LightingProfile
			zone.profile.id = &"street_market"
			zone.profile.enemy_fill_scale = 1.0
		zones.append(zone)
	level._lighting._zones = zones
	var terrain := level._world.get_node("Terrain") as Terrain
	var edges := terrain.get_node("Edges") as TerrainEdges
	var theme := _copy_surface_street(terrain._theme)
	var original := theme.zone_at(0)
	var surfaces: Array[EnvZone] = []
	# All unchanged fields (facades, hole chance, textures and normals) remain
	# exact copies. Only the four proven platform-column intervals are pale.
	for entry: Array in [[0, false], [76, true], [82, false], [98, true], [104, false],
		[122, true], [126, false], [164, true], [170, false]]:
		var zone := original.duplicate(false) as EnvZone
		zone.from_tile = int(entry[0])
		zone.material = original.material.duplicate(false) as TerrainMaterialData
		if bool(entry[1]):
			zone.material.id = &"street_asphalt"
			zone.material.edge_color = Color(0.94, 0.97, 1.0, 1.0)
		surfaces.append(zone)
	theme.zones = surfaces
	terrain._theme = theme
	edges._theme = theme
	for chunk in edges.get_children():
		if chunk is CanvasItem: chunk.queue_redraw()
	_prepared_street = level
	level._lighting.snap()
	_sync55(level)


func _measure(level: Level, world: Rect2) -> Dictionary:
	if not is_instance_valid(_prepared_street) or _prepared_street != level:
		_prepare_candidate_street(level)
	var result := await super._measure(level, world)
	result.street_shared.diagnostic_only = true
	result.street_shared.factor = "local-candidate"
	result.street_shared.source_sha256 = FileAccess.get_sha256("res://tools/street_shared_local_candidate_probe.gd")
	result.bg55.diagnostic_only = true
	result.bg55.scope = "RAM-only local fill=1 and four pale platform-column intervals; original shared market/asphalt A; not authored acceptance, not historical checkout"
	return result
