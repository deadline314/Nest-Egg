extends "res://tools/bg55_enemy_readability_probe.gd"
## Read-only product-source calibration. Each trial changes one current profile
## field or a copied terrain material, then restores the exact held scene.
## A diagnostic exit 0 proves controls only; observed threshold failures remain.

const FACTORS_STREET := ["identity", "fill-min", "fill-max", "edge-opaque", "edge-pale", "combined"]
var _factor_street := "identity"
var _caption_street: Label


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--street-factor="):
			_factor_street = argument.trim_prefix("--street-factor=")
	if not FACTORS_STREET.has(_factor_street):
		printerr("[StreetContrast] Unknown diagnostic factor: " + _factor_street)
		get_tree().quit(2)
		return
	if OS.get_cmdline_user_args().has("--validate-only"):
		var source := load("res://data/environment/themes/ch1_street.tres") as EnvironmentTheme
		var original_color := source.zones[0].material.edge_color
		var copied := _copy_surface_street(source)
		var negative := OS.get_cmdline_user_args().has("--negative-shared-material")
		if negative:
			copied.zones[0].material = source.zones[0].material
		copied.zones[0].material.edge_color = Color(0.1, 0.2, 0.3, 0.9)
		var checks: Array[bool] = [copied != source and copied.zones[0] != source.zones[0],
			copied.zones[0].material != source.zones[0].material,
			source.zones[0].material.edge_color == original_color]
		var profile := load("res://data/lighting/market.tres") as LightingProfile
		var variant := profile.duplicate(false) as LightingProfile
		variant.enemy_fill_scale = 1.0
		var profile_valid := true
		for field in LightingProfile.BLENDED:
			if field != &"enemy_fill_scale":
				profile_valid = profile_valid and variant.get(field) == profile.get(field)
		checks.append(profile_valid)
		var failures := 0
		for valid in checks:
			if not valid: failures += 1
		source.zones[0].material.edge_color = original_color
		print("STREET_COPY_CONTROL checks=", checks.size(), " failures=", failures,
			" negative_shared_material=", negative, " restored_original=", source.zones[0].material.edge_color == original_color,
			" (CPU resource isolation only)")
		get_tree().quit(0 if failures == 0 else 1)
		return
	super._ready()
	_diagnose55 = true
	for layer in get_children():
		if layer is CanvasLayer:
			for node in layer.get_children():
				if node is Label:
					if _caption_street == null:
						_caption_street = node as Label
						_caption_street.text = "BG56 / DIAG"
						_caption_street.add_theme_font_size_override("font_size", 11)
						_caption_street.size = _caption_street.get_combined_minimum_size()
					else:
						node.visible = false


static func _visual_bounds_street(enemy: Enemy) -> Rect2:
	# Preserve the rig's real GPU-skinning CPU mirror/active pose hull; an
	# enumeration of Sprite2D alone would omit RigPartMesh drawables.
	var bounds := enemy.rig.visual_bounds() if enemy.rig != null else Rect2()
	var found := enemy.rig != null and bounds.has_area()
	for node in enemy.find_children("*", "Sprite2D", true, false):
		var sprite := node as Sprite2D
		if sprite.texture == null or not sprite.is_visible_in_tree(): continue
		var rectangle := sprite.global_transform * sprite.get_rect()
		bounds = bounds.merge(rectangle) if found else rectangle
		found = true
	if not found: bounds = enemy.prompt_obstacle_rect()
	return bounds


static func _drawables_street(enemy: Enemy) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	if enemy.rig != null:
		for part in enemy.rig._parts:
			if not part is RigPartMesh or not part.is_visible_in_tree(): continue
			var points: Array = []
			for vertex in (part as RigPartMesh).deformed_vertices(): points.append([vertex.x, vertex.y])
			result.append({"path": str(enemy.get_path_to(part)), "kind": "deformed-rig-mesh", "vertices": points,
				"global_transform": HeldLighting55.transform_values(part.global_transform)})
		for geometry in enemy.rig.active_pose_mesh_geometries():
			var points: Array = []
			for vertex in geometry.vertices: points.append([vertex.x, vertex.y])
			result.append({"path": "active-pose-mesh", "kind": "active-pose-mesh", "vertices": points,
				"global_transform": HeldLighting55.transform_values(enemy.rig._skeleton.global_transform)})
	for node in enemy.find_children("*", "Sprite2D", true, false):
		var sprite := node as Sprite2D
		if sprite.texture == null or not sprite.is_visible_in_tree(): continue
		var rectangle := sprite.get_rect()
		result.append({"path": str(enemy.get_path_to(sprite)), "kind": "sprite", "texture": sprite.texture.resource_path,
			"local_rect": [rectangle.position.x, rectangle.position.y, rectangle.size.x, rectangle.size.y],
			"global_transform": HeldLighting55.transform_values(sprite.global_transform)})
	return result


static func _creature_lighting_street(enemy: Enemy) -> Variant:
	if enemy.creature == null: return null
	var creature := enemy.creature
	var bindings: Array[Dictionary] = []
	for i in creature._parts.size():
		var sprite: Sprite2D = creature._parts[i].sprite
		var shader := sprite.material as ShaderMaterial
		bindings.append({"path": str(enemy.get_path_to(sprite)),
			"material_class": sprite.material.get_class() if sprite.material != null else "null",
			"material_is_cached": creature._light_material != null and sprite.material == creature._light_material,
			"source_material_restored": sprite.material == creature._source_materials[i],
			"self_modulate": _color_values_street(sprite.self_modulate),
			"source_tint": _color_values_street(creature._source_tints[i]),
			"shader_fill": shader.get_shader_parameter("fill") if shader != null and shader.shader == PartCreature.LIGHT_SHADER else null,
			"shader_light_cap": shader.get_shader_parameter("light_cap") if shader != null and shader.shader == PartCreature.LIGHT_SHADER else null})
	return {"fill": creature._lighting_fill, "cap": creature._lighting_cap,
		"cached_material_exists": creature._light_material != null, "pending_foreign_owner": creature._lighting_pending,
		"parent_modulate": _color_values_street(creature.modulate), "wear": _color_values_street(creature._wear),
		"flash_left": creature._flash_left, "bindings": bindings}


func _pixel_rect_street(projected: Rect2, padding := 0) -> Rect2i:
	var start := Vector2i(projected.position.floor())
	var end := Vector2i(projected.end.ceil())
	var texture := get_viewport().get_texture()
	return Rect2i(start, end - start).grow(padding).intersection(Rect2i(0, 0, texture.get_width(), texture.get_height()))


func _caption_padding_street() -> int:
	var matrix := get_viewport().get_final_transform()
	return ceili(6.0 * maxf(matrix.x.length(), matrix.y.length()))


func _measurement_boxes_street() -> Array[Rect2i]:
	var boxes: Array[Rect2i] = []
	var matrix := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	var model := ContrastProbe.new()
	for player in get_tree().get_nodes_in_group(&"player"):
		if player is Player and player.is_visible_in_tree():
			boxes.append(_pixel_rect_street(matrix * model._body_box(player.global_position, true).grow(ContrastProbe.RING)))
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		if enemy is Enemy and enemy.is_visible_in_tree():
			boxes.append(_pixel_rect_street(matrix * model._body_box(enemy.global_position, false).grow(ContrastProbe.RING)))
			boxes.append(_pixel_rect_street(matrix * _visual_bounds_street(enemy as Enemy)))
	return boxes


func _caption_rect_street() -> Rect2i:
	return _pixel_rect_street(get_viewport().get_final_transform() * _caption_street.get_global_rect(), _caption_padding_street())


func _caption_clear_street() -> bool:
	var rectangle := _caption_rect_street()
	for measured in _measurement_boxes_street():
		if measured.has_area() and rectangle.intersects(measured):
			return false
	return true


func _position_caption_street() -> void:
	var size := get_viewport().get_visible_rect().size
	var right := size.x - _caption_street.size.x - 8.0
	var bottom := size.y - _caption_street.size.y - 4.0
	for position: Vector2 in [Vector2(8, bottom), Vector2(right, bottom), Vector2(8, 8), Vector2(right, 8)]:
		_caption_street.position = position
		if _caption_clear_street(): return
	printerr("[StreetContrast] No caption corner clear of character/ground measurements and actual visuals")
	_contrast_failures += 1


func _settle(frames: int) -> void:
	await super._settle(frames)
	if is_instance_valid(_caption_street):
		_position_caption_street()
		await RenderingServer.frame_post_draw


static func _color_values_street(color: Color) -> Array[float]:
	return [color.r, color.g, color.b, color.a]


static func _copy_surface_street(source: EnvironmentTheme) -> EnvironmentTheme:
	# Explicit copies avoid depending on how Resource.duplicate handles nested
	# Resources inside exported arrays in a particular engine release.
	var copied := source.duplicate(false) as EnvironmentTheme
	var zones: Array[EnvZone] = []
	for original_zone in source.zones:
		var zone := original_zone.duplicate(false) as EnvZone
		zone.material = original_zone.material.duplicate(false) as TerrainMaterialData
		zones.append(zone)
	copied.zones = zones
	return copied


func _surface_color_street(edges: TerrainEdges, color: Color) -> void:
	# Only this held Level's duplicate is touched. No global material, geometry,
	# collider or light is rebuilt, and the normal edge drawer performs drawing.
	for zone in edges._theme.zones:
		if zone.from_tile < 181:
			zone.material.edge_color = color
	for chunk in edges.get_children():
		if chunk is CanvasItem:
			chunk.queue_redraw()


func _capture_street(level: Level, world: Rect2, label: String, color: Color) -> Dictionary:
	var record := await super._capture55(level, world, label)
	var probe := ContrastProbe.capture(get_viewport())
	if bytes_sha(probe._image.get_data()) != record.raw_sha256:
		printerr("[StreetContrast] Float input changed during synchronous observations")
		_contrast_failures += 1
	var overlay_clear := _caption_clear_street()
	if not overlay_clear:
		printerr("[StreetContrast] Fixture caption overlaps a measurement or actual character visual")
		_contrast_failures += 1
	var logical := _caption_street.get_global_rect()
	record["fixture_labels"] = [{"text": _caption_street.text, "visible": _caption_street.is_visible_in_tree(),
		"logical_rect": [logical.position.x, logical.position.y, logical.size.x, logical.size.y],
		"pixel_rect_with_padding": rect_values(_caption_rect_street()), "padding_pixels": _caption_padding_street()}]
	record["fixture_overlay_clear"] = overlay_clear
	record["street_edge_color"] = _color_values_street(color)
	record["creature_fill"] = LightKit.creature_fill
	record["creature_light_cap"] = LightKit.creature_light_cap
	record["creature_profile_floor"] = level._lighting.current.creature_floor
	var observed: Dictionary = {}
	for enemy: Dictionary in record.enemies:
		observed[int(enemy.instance)] = true
	var inventory: Array[Dictionary] = []
	for node in level._entities.get_children():
		if not node is Enemy:
			continue
		var body := probe._body_box(node.global_position, false)
		var visual := _visual_bounds_street(node as Enemy)
		for measured: Dictionary in record.enemies:
			if int(measured.instance) == node.get_instance_id():
				measured["visual_world_bounds_values"] = [visual.position.x, visual.position.y, visual.size.x, visual.size.y]
				measured["visual_world_bounds"] = str(visual)
				measured["aux_full_visual_parts"] = probe.contrast_parts(visual, ContrastProbe.RING)
		inventory.append({"instance": node.get_instance_id(), "id": str(node.data.id), "skin": node.data.rig_skin,
			"feet": [node.global_position.x, node.global_position.y], "hp": node.health.current,
			"alive": node.health.current > 0 and not node._dying, "tree_visible": node.is_visible_in_tree(),
			"body_world": [body.position.x, body.position.y, body.size.x, body.size.y],
			"body_screen_rect": rect_values(probe._screen_rect(body)), "full_body_in_view": world.encloses(body),
			"visual_world": [visual.position.x, visual.position.y, visual.size.x, visual.size.y],
			"visible_drawables": _drawables_street(node as Enemy),
			"creature_lighting": _creature_lighting_street(node as Enemy),
			"full_visual_in_view": world.encloses(visual),
			"inside_original_24px_selection": world.grow(-24.0).has_point(node.global_position),
			"observed": observed.has(node.get_instance_id())})
	record["enemy_inventory"] = inventory
	record["player"] = null
	if level.player.visible:
		var feet := level.player.global_position
		var parts := probe.character_parts(feet, true)
		var body := probe._body_box(feet, true)
		var edge := Rect2(feet + Vector2(-24, 0), Vector2(48, 3))
		var below := Rect2(feet + Vector2(-24, 8), Vector2(48, 6))
		record["player"] = {"feet": [feet.x, feet.y], "parts": parts,
			"contrast": maxf(parts.bright, parts.dark), "edge_contrast": probe.edge_contrast(feet),
			"screen_rect": rect_values(probe._screen_rect(body)),
			"outer_screen_rect": rect_values(probe._screen_rect(body.grow(ContrastProbe.RING))),
			"edge_screen_rect": rect_values(probe._screen_rect(edge)),
			"below_screen_rect": rect_values(probe._screen_rect(below)),
			"edge_mean": probe.mean_luma(edge), "below_mean": probe.mean_luma(below)}
	record["mean_luma"] = probe.mean_luma(world)
	return record


func _measure(level: Level, world: Rect2) -> Dictionary:
	# Calibration is deliberately restricted to the existing market interior;
	# the later acceptance tool must use the real zone blend at its boundary.
	if not _fixed_aim or level.player.facing != 1 or not level.player.aim_dir.is_equal_approx(Vector2.RIGHT):
		printerr("[StreetContrast] Requires the original fixed rightward aim and facing")
		_contrast_failures += 1
		return {"passed": false}
	if level.data.id != &"ch1_street" or level._lighting.zone_id_at(level.player.global_position.x) != &"market":
		printerr("[StreetContrast] Diagnostic requires original ch1_street market cell")
		_contrast_failures += 1
		return {"passed": false}
	_active_cell55 = _cell55
	_cell55 += 1
	var terrain := level._world.get_node("Terrain") as Terrain
	var edges := terrain.get_node("Edges") as TerrainEdges
	var original_theme := terrain._theme
	var copied_theme := _copy_surface_street(original_theme)
	terrain._theme = copied_theme
	edges._theme = copied_theme
	var baseline_color := copied_theme.zone_at(0).material.edge_color
	var candidate_color := baseline_color
	var baseline := level._lighting.current.duplicate() as LightingProfile
	var candidate := baseline.duplicate() as LightingProfile
	match _factor_street:
		"fill-min": candidate.enemy_fill_scale = 0.5
		"fill-max", "combined": candidate.enemy_fill_scale = 1.0
	if _factor_street == "edge-opaque":
		candidate_color.a = 1.0
	elif _factor_street in ["edge-pale", "combined"]:
		candidate_color = Color(0.78, 0.86, 1.0, 1.0)
	var records: Array[Dictionary] = []
	for label: String in ["A0", "A1", "product", "restore-product", "authored-final"]:
		var altered := label in ["product", "authored-final"]
		var color := candidate_color if altered else baseline_color
		_surface_color_street(edges, color)
		await _apply55(level, candidate if altered else baseline)
		records.append(await _capture_street(level, world, label, color))
	var valid := true
	for record in records:
		valid = valid and record.held == records[0].held
	valid = valid and records[0].raw_sha256 == records[1].raw_sha256 and records[0].raw_sha256 == records[3].raw_sha256
	valid = valid and records[2].raw_sha256 == records[4].raw_sha256
	if _factor_street == "identity":
		valid = valid and records[0].raw_sha256 == records[2].raw_sha256
	if not valid:
		printerr("[StreetContrast] Diagnostic A/A, restoration or held-state control failed")
		_contrast_failures += 1
	var final: Dictionary = records[-1]
	var passed := valid
	var enemy_values: Array[float] = []
	for enemy in final.enemies:
		enemy_values.append(enemy.contrast)
		passed = passed and bool(enemy.passed)
	var result := {"mean_luma": final.mean_luma, "passed": passed, "enemy_contrast": enemy_values,
		"player_world": [level.player.global_position.x, level.player.global_position.y],
		"facing": level.player.facing, "aim_dir": [level.player.aim_dir.x, level.player.aim_dir.y],
		"lighting_zone": str(level._lighting.zone_id_at(level.player.global_position.x)),
		"street_shared": {"factor": _factor_street, "diagnostic_only": true,
			"baseline_fill_scale": baseline.enemy_fill_scale, "candidate_fill_scale": candidate.enemy_fill_scale,
			"baseline_edge_color": _color_values_street(baseline_color), "candidate_edge_color": _color_values_street(candidate_color),
			"source_sha256": FileAccess.get_sha256("res://tools/street_shared_contrast_probe.gd")},
		"bg55": {"diagnostic_only": true, "controls_valid": valid, "records": records,
			"scope": "calibration of a copied current profile/material; not product acceptance or a historical checkout"}}
	if final.player != null:
		result["player_contrast"] = final.player.contrast
		result["edge_contrast"] = final.player.edge_contrast
		result.passed = passed and float(final.player.contrast) >= ContrastProbe.MIN_PLAYER_CONTRAST and float(final.player.edge_contrast) >= ContrastProbe.MIN_EDGE_CONTRAST
	# Restore the unmodified resource references and current profile before
	# another grid cell uses them. The evidence records remain the altered B.
	terrain._theme = original_theme
	edges._theme = original_theme
	for chunk in edges.get_children():
		if chunk is CanvasItem:
			chunk.queue_redraw()
	await _apply55(level, baseline)
	return result
