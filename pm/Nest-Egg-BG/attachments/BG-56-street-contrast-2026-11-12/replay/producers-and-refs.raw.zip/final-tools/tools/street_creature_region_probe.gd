extends "res://tools/street_shared_acceptance_probe.gd"
## Real zone owner roundtrip, with hidden test player and unchanged authored enemies.

func _tour(level_id: String) -> bool:
	var before := _contrast_failures
	var folder := _out.path_join(level_id)
	DirAccess.make_dir_recursive_absolute(folder)
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	# Keep the original zone reference after authored local data exists.
	# This is current runtime/geometry with declared reference data, not an old checkout.
	level.configure(load("res://data/levels/ch1_street.tres") as LevelData)
	add_child(level)
	await _settle(SETTLE_FRAMES)
	level.hud.visible = false
	level.player.health.setup(999, level.player.tuning.hurt_invulnerability)
	level.player.process_mode = Node.PROCESS_MODE_DISABLED
	for child in level.get_children():
		if child is ChapterCard: child.queue_free()
	_put_on_surface_street(level, 2984.0, 320.0)
	level.player.visible = false
	_contact55.visible = false
	level._lighting._lightning_gap = 1.0e9
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.offset = Vector2.ZERO
	camera.rotation = 0.0
	camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
	camera.global_position = Vector2(2984, 162)
	camera.reset_smoothing()
	camera.force_update_scroll()
	await _settle(SETTLE_FRAMES)
	var inverse := (get_viewport().get_final_transform() * get_viewport().get_canvas_transform()).affine_inverse()
	var start := inverse * Vector2.ZERO
	var end := inverse * Vector2(get_viewport().get_window().size)
	var records: Array[Dictionary] = []
	for label: String in ["A0", "A1", "product", "restore-product", "authored-final"]:
		var inside := label in ["product", "authored-final"]
		_put_on_surface_street(level, 2984.0 if inside else 2680.0, 320.0)
		level.player.visible = false
		_contact55.visible = false
		level._lighting.snap()
		await _apply55(level, level._lighting.current.duplicate() as LightingProfile)
		var record := await _capture_street(level, Rect2(start, end - start), label, Color.WHITE)
		record["zone"] = str(level._lighting.zone_id_at(level.player.global_position.x))
		record["player_feet"] = [level.player.global_position.x, level.player.global_position.y]
		record["inside"] = inside
		record["api_states"] = []
		for enemy in level._entities.get_children():
			if enemy is Enemy and enemy.creature != null:
				record.api_states.append({"instance": enemy.get_instance_id(), "feet": [enemy.global_position.x, enemy.global_position.y], "state": _creature_lighting_street(enemy)})
		records.append(record)
	var valid: bool = records[0].raw_sha256 == records[1].raw_sha256 and records[0].raw_sha256 == records[3].raw_sha256 and records[2].raw_sha256 == records[4].raw_sha256
	for record in records:
		# x2984 is still inside the authored 14-tile blend; do not pretend
		# snap() replaces that spatial interpolation with the right endpoint.
		valid = valid and (record.creature_profile_floor > 0.0 and record.creature_profile_floor <= 0.6 if record.inside else record.creature_profile_floor == 0.0)
		for actor in record.api_states:
			for binding in actor.state.bindings:
				valid = valid and bool(binding.material_is_cached if record.inside else binding.source_material_restored)
	if not valid:
		_contrast_failures += 1
		printerr("[BG56 Region] Real owner roundtrip or pixel restoration failed")
	var writer := FileAccess.open(folder.path_join("street-region.json"), FileAccess.WRITE)
	writer.store_string(JSON.stringify({"records": records, "valid": valid, "scope": "actual authored zone owner with player collision-solved at x2680/2984; player hidden, camera fixed; no enemy position/health/AI writes"}, "\t") + "\n")
	writer.close()

	level.queue_free()
	await _settle(4)
	Engine.time_scale = _time_scale55
	_held55 = null
	print("STREET_REGION records=", records.size(), " failures=", _contrast_failures - before)
	return before == _contrast_failures
