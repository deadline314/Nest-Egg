"""Isolated, bounded street calibration; exit zero is a control result only."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
project=Path('D:/NestEggVerification/native-ticket-batch-20261111')
mode,tag,quality,factor=sys.argv[1:5]
assert re.fullmatch(r'[A-Za-z0-9_-]+',tag), 'case tag must be a simple name'
assert mode in {'cpu','native','fullcpu','fullnative','localcpu','localnative','beecpu','beenative','maskcpu','masknative'} and quality in {'high','low'}
is_cpu=mode.endswith('cpu')
is_local=mode.startswith('local')
is_bee=mode.startswith('bee')
is_mask=mode.startswith('mask')
is_full=mode.startswith('full') or is_local or is_mask
expected_readability_failure=is_full and ('--baseline-inventory' in sys.argv[5:] or '--candidate-diagnostic' in sys.argv[5:])
expected_mask_negative=is_mask and any(arg in sys.argv[5:] for arg in ['--blank-actor-mask','--offset-actor-mask'])
smoke=is_full and '--smoke' in sys.argv[5:]
bee_prototype=is_bee and '--bee-prototype-only' in sys.argv[5:]
bee_default=is_bee and '--bee-default-api' in sys.argv[5:]
platform_only=next((arg for arg in sys.argv[5:] if arg.startswith('--only-platform=')), '')
level_id=next((arg.split('=',1)[1] for arg in sys.argv[5:] if arg.startswith('--level=')), 'ch1_street')
assert re.fullmatch(r'ch[12]_[a-z_]+',level_id)
assert factor in {'identity','fill-min','fill-max','edge-opaque','edge-pale','combined'}
out=project/'work'/('street-shared-'+tag);out.mkdir(parents=True,exist_ok=False);(out/'.gdignore').write_bytes(b'')
paths={'project.godot','tools/street_shared_contrast_probe.gd','tools/street_shared_contrast_probe.tscn','tools/bg55_enemy_readability_probe.gd','tools/readability_phase_probe.gd','tools/scene_tour.gd','tools/held_lighting_state.gd','tools/contrast_probe.gd','tools/viewport_capture.gd','tools/level/build_ch1.py','data/audio/ambience.json','data/audio/music.json','data/audio/footsteps.json','data/lighting_preview/scenes.json','data/levels/ch1_street.tres','data/levels/ch1_street_map.json','data/environment/themes/ch1_street.tres'}
if is_full: paths.update({'tools/street_shared_acceptance_probe.gd','tools/street_shared_acceptance_probe.tscn'})
if is_local: paths.update({'tools/street_shared_local_candidate_probe.gd','tools/street_shared_local_candidate_probe.tscn'})
if is_bee: paths.update({'tools/street_drone_contrast_probe.gd','tools/street_drone_contrast_probe.tscn','tools/street_shared_acceptance_probe.gd'})
if bee_default: paths.update({'tools/street_creature_default_probe.gd','tools/street_creature_default_probe.tscn'})
if is_mask: paths.update({'tools/street_actor_mask.gd','tools/street_shared_masked_probe.gd','tools/street_shared_masked_probe.tscn'})
if (project/'tools/bg56_reference').exists():paths.update(p.relative_to(project).as_posix()for p in(project/'tools/bg56_reference').rglob('*')if p.is_file())
for folder in ['game','core','autoload','data/scripts']:
 paths.update(p.relative_to(project).as_posix()for p in(project/folder).rglob('*')if p.is_file()and p.suffix in {'.gd','.gdshader'})
for folder in ['data/lighting','data/environment/materials','data/enemies']:
 paths.update(p.relative_to(project).as_posix()for p in(project/folder).glob('*.tres'))
if level_id!='ch1_street':
 for folder in ['data/levels','data/environment/themes']:
  paths.update(p.relative_to(project).as_posix()for p in(project/folder).glob('*')if p.is_file()and p.suffix in {'.tres','.json'})
for actor in ['sweeper','collector_brute','collector_gunner']:
 for folder in ['art/characters/'+actor]:
  paths.update(p.relative_to(project).as_posix()for p in(project/folder).rglob('*')if p.is_file()and p.suffix in {'.png','.json'})
 for path in [project/'art/rigs'/(actor+'.json')]:
  if path.exists():paths.add(path.relative_to(project).as_posix())
paths.update(p.relative_to(project).as_posix()for p in(project/'art/creatures').rglob('*')if p.is_file()and p.suffix in {'.png','.json'})
paths.update(['art/shaders/character_light.gdshader','tools/verify_street_shared_contrast.py','tools/verify_bg55_readability.py','tools/verify_bg49_held.py'])
def git_read(*arguments):
 result=subprocess.run(['git','-c','core.quotepath=false',*arguments],cwd=project,capture_output=True,check=True)
 return result.stdout.decode('utf8').strip()
base_git={'head':git_read('rev-parse','HEAD'),'tree':git_read('rev-parse','HEAD^{tree}'),'scope':'published Git base plus exact listed runtime/overlay bytes; not an entire binary-resource checkout in each case'}
overlay=set(git_read('diff','--name-only','HEAD','--','game','core','autoload','data','art','project.godot').splitlines())
overlay.update(git_read('ls-files','--others','--exclude-standard','--','game','core','autoload','data','art').splitlines())
overlay={name for name in overlay if (project/name).is_file()}
base_git['overlay_paths']=sorted(overlay);paths.update(overlay);paths=sorted(paths)
(out/'base-git.json').write_bytes((json.dumps(base_git,indent=2)+'\n').encode())
def hashes():return {p:hashlib.sha256((project/p).read_bytes()).hexdigest()for p in paths}
before=hashes()
(out/'offline-verifier.py').write_bytes(Path('tools/verify_street_shared_contrast.py').read_bytes())
for p in paths:
 dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((project/p).read_bytes())
(out/'source-before.json').write_bytes((json.dumps(before,indent=2)+'\n').encode());(out/'runner.py').write_bytes(Path(__file__).read_bytes())
godot='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
command=[godot,'--headless','--quit-after','2']if is_cpu else[sys.executable,str(project/'tools/comfyui/gpu_lock.py'),'--',godot,'--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan']
scene='street_shared_masked_probe' if is_mask else 'street_creature_default_probe' if bee_default else 'street_drone_contrast_probe' if is_bee else 'street_shared_local_candidate_probe' if is_local else 'street_shared_acceptance_probe' if is_full else 'street_shared_contrast_probe'
command+=['--path',str(project),'res://tools/'+scene+'.tscn','--','--out='+str(out),'--street-factor='+factor]
if is_cpu:command+=['--validate-only',*sys.argv[5:]]
else:
 command+=['--player','--fixed-aim','--lamps=full','--brightness=0.5','--level='+level_id,'--quality='+quality,'--tag='+tag]
 if not is_full:command+=['--cells=4:1,6:1,4:2,6:2']
 elif smoke and not platform_only:command+=['--cells=6:1']
 if platform_only:command+=[platform_only]
 if bee_prototype:command+=['--bee-prototype-only']
 if bee_default:command+=['--bee-default-api']
 if is_mask:command += [arg for arg in sys.argv[5:] if arg in {'--blank-actor-mask','--offset-actor-mask'}]
(out/'command.json').write_bytes((json.dumps(command,indent=2)+'\n').encode())
env=dict(os.environ,APPDATA=str(project/'work'/('street-user-'+tag)),PYTHONIOENCODING='utf-8');started=time.monotonic()
with(out/'run.log').open('wb')as log:
 process=subprocess.Popen(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:code=process.wait(timeout=240 if is_full and not is_cpu else 120)
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True);code=124
after=hashes();raw_log=(out/'run.log').read_bytes();complete=b'STREET_COPY_CONTROL checks=4 failures='in raw_log if is_cpu else False
if not is_cpu:
 indices=list(out.glob('*/*-index.json'));complete=bool(indices)
 for path in indices:
  data=json.loads(path.read_bytes());shots=data.get('shots',[])
  complete=complete and (len(shots)==(1 if bee_default else 5 if bee_prototype else 8) if is_bee else len(shots)==1 if smoke else len(shots)>=data['columns']*data['rows'] if is_full else len(shots)==4) and all((is_bee or shot.get('street_shared',{}).get('factor')==('local-candidate' if is_local else 'authored-data' if is_full else factor)) and len(shot.get('bg55',{}).get('records',[]))==5 for shot in shots)
strict=code==0 and complete and before==after and b'ERROR:'not in raw_log and b'SCRIPT ERROR'not in raw_log and b'ObjectDB instances were leaked'not in raw_log
expected_failure_completed=(expected_readability_failure or expected_mask_negative) and code==1 and complete and before==after and b'ERROR:'not in raw_log and b'SCRIPT ERROR'not in raw_log and b'ObjectDB instances were leaked'not in raw_log
receipt=dict(exit=code,seconds=time.monotonic()-started,source_after=after,sources_unchanged=before==after,completion_artifacts_present=complete,strict_clean=strict,expected_readability_failure_completed=expected_failure_completed,scope='RAM-only local candidate diagnostic' if is_local else 'explicit baseline inventory' if expected_readability_failure else ('authored acceptance, threshold/coverage require independent verification' if is_full else 'diagnostic calibration only; zero exit proves controls, not readability thresholds; no performance claim'))
(out/'exit.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in receipt.items()if k!='source_after'}));print(raw_log.decode('utf8')[-2400:]);raise SystemExit(0 if strict or expected_failure_completed else 1)
