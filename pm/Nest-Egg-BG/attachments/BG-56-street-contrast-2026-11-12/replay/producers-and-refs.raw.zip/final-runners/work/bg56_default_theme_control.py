"""Compare real old/new writer bytes for every default theme, in isolation."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
from types import SimpleNamespace

root = Path('D:/NestEggVerification/native-ticket-batch-20261111')
out = root / 'work/bg56-default-theme-control-v1'
out.mkdir(exist_ok=False)
(out / '.gdignore').write_bytes(b'')
old_source = subprocess.run(['git', 'show', 'be43e4f5:tools/level/build_ch1.py'], cwd=root,
                            capture_output=True, check=True).stdout
new_source = (root / 'tools/level/build_ch1.py').read_bytes()
sys.path.insert(0, str(root / 'tools/level'))
modules = []
for name, source in [('old', old_source), ('new', new_source)]:
    path = out / (name + '.py')
    path.write_bytes(source)
    spec = importlib.util.spec_from_file_location('bg56_default_' + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    destination = out / name
    destination.mkdir()
    module.THEME_DIR = str(destination)
    modules.append(module)
assert modules[0].THEMES == modules[1].THEMES
rows = []
for theme in modules[0].THEMES:
    area = SimpleNamespace(id=theme, name='default control ' + theme, material_zones=[])
    for module in modules:
        module.write_theme(area, theme)
    old = (out / 'old' / ('ch1_' + theme + '.tres')).read_bytes()
    new = (out / 'new' / ('ch1_' + theme + '.tres')).read_bytes()
    assert old == new, theme
    rows.append(dict(theme=theme, bytes=len(old), sha256=hashlib.sha256(old).hexdigest(), byte_identical=True))
report = dict(valid=True, themes=len(rows), results=rows,
              old_source_sha256=hashlib.sha256(old_source).hexdigest(), new_source_sha256=hashlib.sha256(new_source).hexdigest(),
              scope='real published old and candidate new writer functions; every default theme output byte-identical, no production directories written')
(out / 'result.json').write_bytes((json.dumps(report, indent=2) + '\n').encode())
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k: v for k, v in report.items() if k != 'results'}))
