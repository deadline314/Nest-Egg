"""Review-only own changes; never modify C or stage any file."""
from pathlib import Path
import difflib
import hashlib
import json
import zipfile

root = Path('D:/NestEggVerification/native-ticket-batch-20261111')
current = Path('C:/Users/stanl/Github/Nest-Egg')
out = current / 'work/bg56-own-hunks-v1'
out.mkdir(exist_ok=False)
manifest = json.loads((current / 'work/BG56-product-candidate-sha256.json').read_bytes())
common = {'data/scripts/lighting_profile.gd', 'core/light_kit.gd', 'game/level/lighting_controller.gd',
          'game/creature/part_creature.gd', 'game/enemies/enemy.gd'}
rows = []
for row in manifest['files']:
    path = row['path']
    candidate = (root / path).read_bytes()
    assert hashlib.sha256(candidate).hexdigest() == row['candidate_sha256']
    c_bytes = (current / path).read_bytes() if (current / path).exists() else b''
    expected_c = hashlib.sha256(c_bytes).hexdigest() if c_bytes else None
    assert expected_c == row['current_c_sha256'], 'C changed since fixed manifest: ' + path
    base = (root / 'work/bg56-api-before' / path).read_bytes() if path in common else c_bytes
    for directory, data in [('base', base), ('candidate', candidate), ('current-c', c_bytes)]:
        target = out / directory / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    patch = ''.join(difflib.unified_diff(base.decode('utf8').replace('\r\n', '\n').splitlines(True),
                                       candidate.decode('utf8').splitlines(True),
                                       fromfile='a/' + path, tofile='b/' + path))
    target = out / 'patches' / (path + '.patch')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(patch.encode())
    policy = 'apply only own hunks to current C; preserve any other edits' if path in common or path == 'tests/suite/test_part_creature.gd' else 'full copy only if current C bytes still match current_c_sha256 (new files require absent destination)'
    rows.append(dict(row, own_base_sha256=hashlib.sha256(base).hexdigest() if base else None,
                     base_matches_current_c=base == c_bytes, integration=policy,
                     patch_sha256=hashlib.sha256(patch.encode()).hexdigest()))
result = dict(scope='18 exact owned candidates; review-only, no C product writes/staging; raw patch context remains inside ZIP',
              files=rows, runtime_refresh=manifest['runtime_refresh'])
(out / 'manifest.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
archive = current / 'work/BG56-own-hunks-v1.raw.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for path in sorted(out.rglob('*')):
        if path.is_file(): stream.write(path, path.relative_to(out).as_posix())
with zipfile.ZipFile(archive) as stream:
    assert stream.testzip() is None
    for info in stream.infolist():
        assert stream.read(info.filename) == (out / info.filename).read_bytes()
print(json.dumps(dict(files=len(rows), all_bases_match_current_c=all(r['base_matches_current_c'] for r in rows),
                      archive=str(archive), sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), bytes=archive.stat().st_size)))
