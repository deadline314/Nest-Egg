"""Preserve every closed BG56 case byte-for-byte in bounded ZIP files."""
from pathlib import Path
import hashlib
import json
import sys
import time
import zipfile

project = Path('D:/NestEggVerification/native-ticket-batch-20261111')
current = Path('C:/Users/stanl/Github/Nest-Egg')
destination = current / 'pm/Nest-Egg-BG/attachments/BG-56-street-contrast-2026-11-12'
destination.mkdir(parents=True, exist_ok=True)
(destination / '.gitattributes').write_bytes(b'* -text\n')
(destination / 'raw').mkdir(exist_ok=True)
maximum = 95_000_000
budget = 90_000_000


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024): value.update(block)
    return value.hexdigest()


def pack(name, files, role='history'):
    index_path = destination / 'raw' / (name + '.members.json')
    assert not index_path.exists(), 'never overwrite original package: ' + name
    files = sorted(files, key=lambda item: item[1])
    parts, members = [], []
    stream = None
    archive = None
    part = 0

    def close():
        if stream is None: return
        stream.close()
        assert archive.stat().st_size < maximum
        with zipfile.ZipFile(archive) as reader:
            for row in [m for m in members if m['archive'] == archive.name]:
                value = hashlib.sha256()
                length = 0
                with reader.open(row['member']) as handle:
                    while block := handle.read(1024 * 1024):
                        value.update(block)
                        length += len(block)
                assert length == row['bytes'] and value.hexdigest() == row['sha256'], row
        parts.append(dict(file=archive.name, bytes=archive.stat().st_size, sha256=sha(archive)))

    for source, member in files:
        size = source.stat().st_size
        assert size < budget
        # Deflate can expand incompressible input slightly. Reserve an entire
        # uncompressed entry plus overhead before opening the next member.
        bound = size + size // 1000 + len(member.encode('utf8')) * 2 + 4096
        if stream is None or stream.fp.tell() + bound > budget:
            close()
            part += 1
            archive = destination / 'raw' / (name + '-%02d.raw.zip' % part)
            assert not archive.exists()
            stream = zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6)
        digest = sha(source)
        stream.write(source, member)
        members.append(dict(member=member, archive=archive.name, bytes=size, sha256=digest))
    close()
    result = dict(name=name, role=role, original_bytes_preserved=True, members=members, archives=parts)
    index_path.write_bytes((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode())
    total = sum(p['bytes'] for p in parts)
    print('%s: %d members, %d ZIP, %.2f MB, readback SHA verified' % (name, len(members), len(parts), total / 1e6), flush=True)
    return dict(name=name, role=role, index='raw/' + index_path.name,
                index_sha256=sha(index_path), members=len(members), archives=parts)


final = {
 'street-shared-authored-edge98-final-high40-v1', 'street-shared-authored-edge98-final-low40-v1',
 'street-shared-default-api-high-v1', 'street-shared-default-api-low-v1',
 'bg56-lab-actions-final-high-v1', 'bg56-lab-actions-final-low-v1',
 'bg56-lab-damage-final-high-v2', 'bg56-lab-damage-final-low-v2',
 'bg56-lab-region-final-high-v1', 'bg56-lab-region-final-low-v1',
 'bg56-lab-related-dock-high-v2', 'bg56-lab-related-dock-low-v1',
 'bg56-lab-related-booth-high-v1', 'bg56-lab-related-booth-low-v1',
 'street-shared-related-gate-high-v1', 'street-shared-related-gate-low-v1',
 'bg56-cpu-api-final-v1', 'bg56-cpu-data-final-edge98-v1', 'bg56-cpu-permanent-suite-v1',
 'bg56-cpu-missing-alias-final-edge98-v1', 'bg56-cpu-ram-curve-final-v1',
 'bg56-default-theme-control-v1', 'street-shared-mask-final-blank-negative-v1',
 'street-shared-mask-final-offset-negative-v1'}
cases = []
started = time.monotonic()
for folder in sorted((project / 'work').iterdir()):
    if folder.is_dir() and (folder.name.startswith('street-shared-') or folder.name.startswith('bg56-')):
        files = [(path, folder.name + '/' + path.relative_to(folder).as_posix()) for path in folder.rglob('*') if path.is_file()]
        if files: cases.append(pack(folder.name, files, 'acceptance-or-explicit-negative' if folder.name in final else 'history-diagnostic'))

loose = [(p, 'loose/' + p.name) for p in (project / 'work').glob('bg56-*') if p.is_file()]
for path in (current / 'work').glob('street-*.json'):
    loose.append((path, 'loose-c/' + path.name))
for folder in ['bg56-offline-diagnostics', 'bg56-verifier-history']:
    base = current / 'work' / folder
    if base.exists(): loose += [(p, 'loose-c/' + folder + '/' + p.relative_to(base).as_posix()) for p in base.rglob('*') if p.is_file()]
if loose: cases.append(pack('development-loose-evidence', loose))

sources = []
for pattern in ['street_*.gd', 'street_*.gd.uid', 'street_*.tscn', 'test_street_*.gd', 'test_street_*.gd.uid', 'test_street_*.tscn']:
    sources += [(p, 'final-tools/' + p.relative_to(project).as_posix()) for p in (project / 'tools').glob(pattern)]
sources += [(p, 'final-tools/' + p.relative_to(project).as_posix()) for p in (project / 'tools/bg56_reference').rglob('*') if p.is_file()]
sources += [(p, 'final-tools/' + p.relative_to(current).as_posix()) for p in (current / 'tools').glob('verify_street_*.py')]
sources += [(p, 'final-runners/' + p.relative_to(current).as_posix()) for p in (current / 'work').glob('bg56_*.py')]
sources += [(current / 'work/street_shared_run.py', 'final-runners/work/street_shared_run.py'),
            (current / 'work/BG56-own-hunks-v1.raw.zip', 'integration/BG56-own-hunks-v1.raw.zip'),
            (current / 'work/BG56-product-candidate-sha256.json', 'integration/BG56-product-candidate-sha256.json')]
cases.append(pack('final-tools-and-integration', sources, 'exact-delivery-source'))
index = dict(scope='closed native/CPU cases, original failures and source versions preserved; semantic acceptance is stated separately in README',
             maximum_zip_bytes=maximum, cases=cases, seconds=time.monotonic()-started,
             all_members_readback_sha256_verified=True)
(destination / 'raw-index.json').write_bytes((json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode())
print('BG56 PACK COMPLETE %d cases %.1fs' % (len(cases), time.monotonic()-started), flush=True)
