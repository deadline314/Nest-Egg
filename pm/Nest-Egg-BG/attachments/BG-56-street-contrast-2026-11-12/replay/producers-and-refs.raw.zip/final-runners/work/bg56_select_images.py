"""Copy real original PNGs and exact, unscaled pixel crops for BG56 review."""
from pathlib import Path
import hashlib
import json
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path('tools').resolve()))
from verify_bg49_held import affine

root = Path('D:/NestEggVerification/native-ticket-batch-20261111/work')
images = Path('pm/Nest-Egg-BG/images')
out = Path('pm/Nest-Egg-BG/attachments/BG-56-street-contrast-2026-11-12')
images.mkdir(exist_ok=True)
rows = []
for quality in ['high', 'low']:
    folder = root / ('street-shared-authored-edge98-final-' + quality + '40-v1')
    index = next(folder.glob('*/*-index.json'))
    data = json.loads(index.read_bytes())
    points = [
      ('brute-platform', next(s for s in data['shots'] if s['column'] == 6 and s['row'] == 1), 'collector_brute', [2136, 320]),
      ('sweeper', next(s for s in data['shots'] if s['column'] == 4 and s['row'] == 2), 'sweeper', [1352, 320]),
      ('drone', next(s for s in data['shots'] if s['waypoint_kind'] == 'enemy-coverage'), 'drone', [2984, 192]),
      ('platform98', next(s for s in data['shots'] if s['waypoint'] == 'platform-98-16'), None, None),
      ('platform175', next(s for s in data['shots'] if s['waypoint'] == 'platform-175-15'), 'collector_gunner', [2840, 240]),
    ]
    for name, shot, actor_id, feet in points:
        records = shot['bg55']['records']
        final = records[-1]
        if actor_id:
            actor = next(a for a in final['enemy_inventory'] if a['id'] == actor_id and a['feet'] == feet)
            x, y, w, h = actor['visual_world']
            world = [x - 14, y - 12, w + 28, h + 26]
        else:
            x, y = shot['player_world']
            world = [x - 48, y - 64, 96, 86]
        matrix = affine(final['held']['lighting_owners']['viewport_final_transform_values']) @ affine(final['canvas_transform_values'])
        x, y, w, h = world
        vertices = np.array([[x,y,1],[x+w,y,1],[x,y+h,1],[x+w,y+h,1]]) @ matrix.T
        start = np.maximum(np.floor(vertices[:, :2].min(axis=0)).astype(int), [0, 0])
        end = np.minimum(np.ceil(vertices[:, :2].max(axis=0)).astype(int), [final['width'], final['height']])
        assert np.all(end > start)
        box = [int(start[0]), int(start[1]), int(end[0]), int(end[1])]
        for label, record in [('before', records[0]), ('after', final)]:
            original = index.parent / record['files']['png']
            filename = 'BG-56-%s-%s-%s.png' % (quality, name, label)
            target = images / filename
            assert not target.exists()
            target.write_bytes(original.read_bytes())
            crop_name = filename.replace('.png', '-crop.png')
            crop = images / crop_name
            full = Image.open(original).convert('RGBA')
            full.crop(tuple(box)).save(crop)
            expected = np.asarray(full)[box[1]:box[3], box[0]:box[2]]
            assert np.array_equal(expected, np.asarray(Image.open(crop)))
            rows.append(dict(quality=quality, point=name, waypoint=shot['waypoint'], label=label,
                             original_case=folder.name, original_png=record['files']['png'],
                             original_raw_sha256=record['raw_sha256'],
                             image=filename, image_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                             crop=crop_name, crop_sha256=hashlib.sha256(crop.read_bytes()).hexdigest(),
                             crop_box_pixels=box, unscaled_crop_pixels_verified=True,
                             player=record['player'],
                             enemies=[e for e in record['enemies'] if not actor_id or (e['id'] == actor_id and e['feet'] == feet)]))
(out / 'selected-images.json').write_bytes((json.dumps(dict(scope='original native PNG bytes plus exact unscaled crops; before is original profile/material in the same current runtime and geometry', images=rows), ensure_ascii=False, indent=2) + '\n').encode())
print('Copied %d original PNGs + %d exact unscaled crops; pixel equality verified' % (len(rows), len(rows)))
