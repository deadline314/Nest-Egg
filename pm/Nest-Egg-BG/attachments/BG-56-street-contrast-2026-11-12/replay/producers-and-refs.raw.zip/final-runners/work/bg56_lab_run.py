"""Strict D-only native behavior/region lab with exact runtime source receipts."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

root = Path('D:/NestEggVerification/native-ticket-batch-20261111')
mode, tag, quality = sys.argv[1:4]
assert mode in {'action', 'region', 'damage', 'ramp', 'ramp-action', 'edge', 'related'} and quality in {'high', 'low'}
assert re.fullmatch(r'[a-zA-Z0-9_-]+', tag)
out = root / 'work' / ('bg56-lab-' + tag)
out.mkdir(exist_ok=False)
(out / '.gdignore').write_bytes(b'')
paths = {'project.godot', 'art/shaders/character_light.gdshader'}
for directory in ['game', 'core', 'autoload', 'data/scripts']:
    paths.update(p.relative_to(root).as_posix() for p in (root / directory).rglob('*')
                 if p.is_file() and p.suffix in {'.gd', '.gdshader'})
for directory in ['data/lighting', 'data/environment/materials', 'data/enemies', 'tools/bg56_reference', 'data/levels', 'data/environment/themes']:
    paths.update(p.relative_to(root).as_posix() for p in (root / directory).rglob('*.tres'))
for pattern in ['street_*.gd', 'street_*.tscn']:
    paths.update(p.relative_to(root).as_posix() for p in (root / 'tools').glob(pattern))
paths.update(['tools/held_lighting_state.gd', 'tools/contrast_probe.gd', 'tools/viewport_capture.gd',
              'data/levels/ch1_street.tres', 'data/levels/ch1_street_map.json',
              'data/environment/themes/ch1_street.tres'])
paths.update(['tools/bg49_held_readability_probe.gd', 'tools/bg55_enemy_readability_probe.gd',
              'tools/readability_phase_probe.gd', 'tools/scene_tour.gd',
              'tools/ch1_readability_check.gd', 'tools/readability_check.gd'])
def git_read(*arguments):
    return subprocess.run(['git', '-c', 'core.quotepath=false', *arguments], cwd=root,
                          capture_output=True, check=True).stdout.decode('utf8').strip()
overlay = set(git_read('diff', '--name-only', 'HEAD', '--', 'game', 'core', 'autoload', 'data', 'art', 'project.godot').splitlines())
overlay.update(git_read('ls-files', '--others', '--exclude-standard', '--', 'game', 'core', 'autoload', 'data', 'art').splitlines())
overlay = {name for name in overlay if (root / name).is_file()}
paths.update(overlay)
(out / 'base-git.json').write_bytes((json.dumps(dict(head=git_read('rev-parse', 'HEAD'),
     tree=git_read('rev-parse', 'HEAD^{tree}'), overlay_paths=sorted(overlay),
     scope='Git base plus exact listed runtime overlays'), indent=2) + '\n').encode())
paths = sorted(paths)

def hashes():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}

before = hashes()
for path in paths:
    dest = out / 'source' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((root / path).read_bytes())
(out / 'source-before.json').write_bytes((json.dumps(before, indent=2) + '\n').encode())
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
scene = {'action': 'street_shared_action_probe', 'region': 'street_creature_region_probe',
         'damage': 'street_creature_damage_probe', 'ramp': 'street_creature_ramp_probe', 'ramp-action': 'street_shared_action_probe', 'edge': 'street_edge_margin_probe', 'related': 'street_shared_related_probe'}[mode]
command = [sys.executable, str(root / 'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root),
           '--resolution', '1280x720', '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan',
           'res://tools/' + scene + '.tscn', '--', '--out=' + str(out), '--quality=' + quality]
if mode in {'region', 'ramp', 'edge', 'related'}:
    command += ['--level=ch1_street', '--player', '--fixed-aim', '--lamps=full', '--brightness=0.5', '--tag=' + tag]
if mode == 'ramp-action': command += ['--ramp-only']
if mode == 'edge': command += ['--only-platform=98:16']
if mode == 'related':
    command = [arg for arg in command if arg != '--level=ch1_street']
    command += sys.argv[4:]
(out / 'command.json').write_bytes((json.dumps(command, indent=2) + '\n').encode())
started = time.monotonic()
with (out / 'run.log').open('wb') as stream:
    process = subprocess.Popen(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT,
                               env=dict(os.environ, APPDATA=str(out / 'user'), PYTHONIOENCODING='utf-8'))
    try:
        code = process.wait(timeout=120)
    except subprocess.TimeoutExpired:
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True)
        code = 124
after = hashes()
text = (out / 'run.log').read_text(encoding='utf8', errors='replace')
marker = {'action': 'STREET_ACTION actors=3 failures=', 'region': 'STREET_REGION records=',
          'damage': 'STREET_DAMAGE records=', 'ramp': 'STREET_RAMP records=', 'ramp-action': 'STREET_ACTION actors=1 failures=', 'edge': 'STREET_ACCEPTANCE level=ch1_street original_grid=33 records=1 failures=', 'related': 'BG49_POINT '}[mode]
complete = marker in text
clean = code == 0 and complete and before == after and 'ERROR:' not in text and 'SCRIPT ERROR' not in text and 'ObjectDB instances were leaked' not in text and 'resources still in use' not in text
receipt = dict(mode=mode, exit=code, seconds=time.monotonic()-started,
               completed=complete, strict_clean=clean, sources_unchanged=before == after, source_after=after,
               scope='native automated component/AI lab, not human play; independent pixels/behavior verification required')
(out / 'exit.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps({k: v for k, v in receipt.items() if k != 'source_after'}, indent=2))
print(text[-2200:])
raise SystemExit(0 if clean else 1)
