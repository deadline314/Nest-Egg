"""Author only the isolated street candidate; never regenerate a whole chapter."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import re

root = Path('D:/NestEggVerification/native-ticket-batch-20261111')
out = root / 'work/bg56-authored-candidate-v2'
out.mkdir(exist_ok=False)
(out / '.gdignore').write_bytes(b'')
reference = root / 'tools/bg56_reference'
reference.mkdir(exist_ok=True)
for path, name in [('data/levels/ch1_street.tres', 'ch1_street_before.tres'),
                   ('data/environment/themes/ch1_street.tres', 'ch1_street_theme_before.tres')]:
    destination = reference / name
    if destination.exists():
        assert destination.read_bytes() == (root / path).read_bytes()
    else:
        destination.write_bytes((root / path).read_bytes())

def author_copy(source, destination, replacements):
    data = (root / source).read_text(encoding='utf8')
    for old, new in replacements:
        assert data.count(old) == 1, (source, old)
        data = data.replace(old, new)
    path = root / destination
    if path.exists():
        assert path.read_bytes() == data.encode()
    else:
        path.write_bytes(data.encode())

author_copy('data/lighting/market.tres', 'data/lighting/street_market.tres',
            [('id = &"market"', 'id = &"street_market"'), ('enemy_fill_scale = 0.6', 'enemy_fill_scale = 1.0')])
author_copy('data/lighting/harbor_approach.tres', 'data/lighting/street_harbor.tres',
            [('id = &"harbor_approach"', 'id = &"street_harbor"'),
             ('enemy_fill_scale = 0.5\n', 'enemy_fill_scale = 0.5\ncreature_floor = 0.6\n')])
author_copy('data/environment/materials/asphalt.tres', 'data/environment/materials/street_asphalt.tres',
            [('id = &"asphalt"', 'id = &"street_asphalt"'),
             ('edge_color = Color(0.54901963, 0.6509804, 0.8509804, 0.55)', 'edge_color = Color(0.94, 0.97, 1.0, 1.0)')])

def add_alias(path, header, key, value, compact=False):
    target = root / path
    text = target.read_text(encoding='utf8')
    document = json.loads(text)
    route = document['map']['zones'] if header == 'zones' else document[header]
    if key in route:
        assert route[key] == value
        return
    match = re.search(r'(?m)^([ ]*)"' + re.escape(header) + r'": \{\n', text)
    assert match
    indentation = match[1] + ' '
    encoded = json.dumps(value, ensure_ascii=False) if compact else json.dumps(value, ensure_ascii=False, indent=1)
    encoded = encoded.replace('\n', '\n' + indentation)
    insertion = indentation + json.dumps(key) + ': ' + encoded + ',\n'
    changed = text[:match.end()] + insertion + text[match.end():]
    json.loads(changed)
    target.write_bytes(changed.encode())

for path in ['data/audio/ambience.json', 'data/audio/music.json', 'data/audio/footsteps.json', 'data/lighting_preview/scenes.json']:
    destination = out / 'before' / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((root / 'work/bg56-authored-candidate-v1/before' / path).read_bytes())
ambience = json.loads((root / 'data/audio/ambience.json').read_bytes())
music = json.loads((root / 'data/audio/music.json').read_bytes())
for local, original in [('street_market', 'market'), ('street_harbor', 'harbor_approach')]:
    add_alias('data/audio/ambience.json', 'profiles', local, copy.deepcopy(ambience['profiles'][original]))
    add_alias('data/audio/music.json', 'zones', local, copy.deepcopy(music['map']['zones'][original]))
    add_alias('data/lighting_preview/scenes.json', 'presets', local, ['harbor_street'], compact=True)
add_alias('data/audio/footsteps.json', 'materials', 'street_asphalt', 'wet', compact=True)

spec = importlib.util.spec_from_file_location('street_candidate_builder', root / 'tools/level/build_ch1.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
builder.ROOT = str(out / 'generated')
for name, folder in [('LEVEL_DIR', 'levels'), ('THEME_DIR', 'themes'), ('PROP_DIR', 'props'), ('ENCOUNTER_DIR', 'encounters')]:
    destination = out / 'generated' / folder
    destination.mkdir(parents=True)
    setattr(builder, name, str(destination))
area = builder.build_street()
extra = {'props': builder.prepare_props(area.props, area.id)}
if area.regions:
    extra['regions'] = area.regions
area.grid.write(area.id, (builder.LEVEL_DIR, 'ch1_street_map.json'), extra)
builder.write_level(area)
old_map = (root / 'data/levels/ch1_street_map.json').read_bytes()
new_map = (out / 'generated/levels/ch1_street_map.json').read_bytes().replace(b'\r\n', b'\n')
assert old_map == new_map, 'candidate must not change enemies, props, collision geometry or map bytes'
for source, destination in [('generated/levels/ch1_street.tres', 'data/levels/ch1_street.tres'),
                            ('generated/themes/ch1_street.tres', 'data/environment/themes/ch1_street.tres')]:
    (root / destination).write_bytes((out / source).read_bytes().replace(b'\r\n', b'\n'))

# Semantic AND byte-preserving additions: remove only the new aliases, and
# require every original dictionary/list/scalar to remain exactly the same.
for path, route, additions in [('data/audio/ambience.json', ['profiles'], ['street_market', 'street_harbor']),
                              ('data/audio/music.json', ['map', 'zones'], ['street_market', 'street_harbor']),
                              ('data/audio/footsteps.json', ['materials'], ['street_asphalt']),
                              ('data/lighting_preview/scenes.json', ['presets'], ['street_market', 'street_harbor'])]:
    old = json.loads((out / 'before' / path).read_bytes())
    changed = json.loads((root / path).read_bytes())
    at = changed
    for key in route:
        at = at[key]
    for key in additions:
        assert key in at
        del at[key]
    assert changed == old, path

files = ['data/lighting/street_market.tres', 'data/lighting/street_harbor.tres',
         'data/environment/materials/street_asphalt.tres', 'data/levels/ch1_street.tres',
         'data/environment/themes/ch1_street.tres', 'tools/level/build_ch1.py',
         'data/audio/ambience.json', 'data/audio/music.json', 'data/audio/footsteps.json',
         'data/lighting_preview/scenes.json']
receipt = dict(scope='D-only isolated authored candidate, no chapter-wide output adoption',
               map_bytes_unchanged=old_map == new_map,
               generator_sha256=hashlib.sha256((root / 'tools/level/build_ch1.py').read_bytes()).hexdigest(),
               files={name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files})
(out / 'receipt.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt, indent=2))
