"""Bounded strict D-only API/data/suite checks with real source receipts."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

root = Path('D:/NestEggVerification/native-ticket-batch-20261111')
mode, tag = sys.argv[1:3]
assert mode in {'api', 'data', 'suite', 'missing-alias', 'ramp'}
assert re.fullmatch(r'[a-zA-Z0-9_-]+', tag)
out = root / 'work' / ('bg56-cpu-' + tag)
out.mkdir(exist_ok=False)
(out / '.gdignore').write_bytes(b'')
paths = {'project.godot', 'tests/smoke_test.gd', 'tests/suite/test_part_creature.gd',
         'tests/suite/test_suite.gd', 'tools/test_filters.sh',
         'tools/level/build_ch1.py', 'data/levels/ch1_street.tres',
         'data/levels/ch1_street_map.json', 'data/environment/themes/ch1_street.tres',
         'data/audio/ambience.json', 'data/audio/music.json', 'data/audio/footsteps.json',
         'data/lighting_preview/scenes.json', 'art/shaders/character_light.gdshader'}
for directory in ['game', 'core', 'autoload', 'data/scripts']:
    paths.update(p.relative_to(root).as_posix() for p in (root / directory).rglob('*')
                 if p.is_file() and p.suffix in {'.gd', '.gdshader'})
for directory in ['data/lighting', 'data/environment/materials', 'tools/bg56_reference']:
    paths.update(p.relative_to(root).as_posix() for p in (root / directory).rglob('*.tres'))
for pattern in ['test_street_*.gd', 'test_street_*.tscn', 'street_*.gd', 'street_*.tscn']:
    paths.update(p.relative_to(root).as_posix() for p in (root / 'tools').glob(pattern))
paths = sorted(paths)
def hashes():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}
before = hashes()
for path in paths:
    dest = out / 'source' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((root / path).read_bytes())
(out / 'source-before.json').write_bytes((json.dumps(before, indent=2) + '\n').encode())
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
scene = 'tests/smoke_test' if mode == 'suite' else 'tools/test_street_creature_lighting' if mode == 'api' else 'tools/test_street_shared_data'
if mode == 'ramp': scene = 'tools/test_street_creature_ramp'
command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', str(root),
           'res://' + scene + '.tscn']
if mode == 'suite':
    command += ['--', '--only=PartCreatureSuite']
elif mode == 'missing-alias':
    command += ['--', '--negative-missing-music']
(out / 'command.json').write_bytes((json.dumps(command, indent=2) + '\n').encode())
started = time.monotonic()
with (out / 'run.log').open('wb') as stream:
    process = subprocess.Popen(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT,
                               env=dict(os.environ, APPDATA=str(out / 'user'), PYTHONIOENCODING='utf-8'))
    try:
        code = process.wait(timeout=90)
    except subprocess.TimeoutExpired:
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True)
        code = 124
after = hashes()
text = (out / 'run.log').read_text(encoding='utf8', errors='replace')
marker = 'checks: ' if mode == 'suite' else 'BG56_CREATURE_CPU checks=' if mode == 'api' else 'BG56_DATA checks='
if mode == 'ramp': marker = 'BG56_RAMP_CPU checks='
complete = marker in text and ('SUITE_TIME PartCreatureSuite' in text if mode == 'suite' else True)
errors = [line for line in text.splitlines() if line.startswith('ERROR:')]
expected = [line for line in errors if mode == 'suite' and 'no_such_creature' in line]
unexpected = [line for line in errors if line not in expected]
expected_code = 1 if mode == 'missing-alias' else 0
clean = code == expected_code and complete and before == after and not unexpected and 'SCRIPT ERROR' not in text and 'Parse Error' not in text and 'ObjectDB instances were leaked' not in text and 'resources still in use' not in text
receipt = dict(mode=mode, exit=code, seconds=time.monotonic()-started,
               expected_exit=expected_code, completed=complete, accepted=clean,
               sources_unchanged=before == after, source_after=after,
               expected_fixture_error_lines=expected, unexpected_error_lines=unexpected,
               scope='CPU state/data/suite only; missing-alias deliberately rejects explicit registration even where harbor fallback cue is equal')
(out / 'exit.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps({k: v for k, v in receipt.items() if k != 'source_after'}, indent=2))
print(text[-1800:])
raise SystemExit(0 if clean else 1)
