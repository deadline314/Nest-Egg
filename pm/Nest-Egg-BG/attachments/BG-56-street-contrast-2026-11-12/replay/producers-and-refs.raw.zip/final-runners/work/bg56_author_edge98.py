"""Adopt only the proven stronger edge on platform columns98..103 in D."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json

root = Path('D:/NestEggVerification/native-ticket-batch-20261111')
out = root / 'work/bg56-authored-edge98-v1'
out.mkdir(exist_ok=False)
(out / '.gdignore').write_bytes(b'')
paths = ['tools/level/build_ch1.py', 'data/environment/themes/ch1_street.tres', 'data/audio/footsteps.json']
for path in paths:
    target = out / 'before' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((root / path).read_bytes())
profile = (root / 'data/environment/materials/street_asphalt.tres').read_text(encoding='utf8')
assert profile.count('id = &"street_asphalt"') == 1 and profile.count('edge_color = Color(0.94, 0.97, 1.0, 1.0)') == 1
profile = profile.replace('id = &"street_asphalt"', 'id = &"street_asphalt_platform"').replace('edge_color = Color(0.94, 0.97, 1.0, 1.0)', 'edge_color = Color(1.10, 1.14, 1.20, 1.0)')
(root / 'data/environment/materials/street_asphalt_platform.tres').write_bytes(profile.encode())
builder_path = root / 'tools/level/build_ch1.py'
text = builder_path.read_text(encoding='utf8')
assert text.count("(98, 'street_asphalt')") == 1
builder_path.write_bytes(text.replace("(98, 'street_asphalt')", "(98, 'street_asphalt_platform')").encode())
tree = ast.parse(Path('work/bg56_author_candidate.py').read_text(encoding='utf8'))
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'add_alias')
namespace = dict(root=root, json=json, re=__import__('re'))
exec(compile(ast.Module(body=[node], type_ignores=[]), '<add_alias>', 'exec'), namespace)
namespace['add_alias']('data/audio/footsteps.json', 'materials', 'street_asphalt_platform', 'wet', compact=True)
before = json.loads((out / 'before/data/audio/footsteps.json').read_bytes())
after = json.loads((root / 'data/audio/footsteps.json').read_bytes())
del after['materials']['street_asphalt_platform']
assert before == after
spec = importlib.util.spec_from_file_location('bg56_edge_builder', builder_path)
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
builder.ROOT = str(out / 'generated')
for name, folder in [('LEVEL_DIR', 'levels'), ('THEME_DIR', 'themes'), ('PROP_DIR', 'props'), ('ENCOUNTER_DIR', 'encounters')]:
    target = out / 'generated' / folder
    target.mkdir(parents=True)
    setattr(builder, name, str(target))
area = builder.build_street()
extra = {'props': builder.prepare_props(area.props, area.id)}
if area.regions: extra['regions'] = area.regions
area.grid.write(area.id, (builder.LEVEL_DIR, 'ch1_street_map.json'), extra)
builder.write_level(area)
assert (out / 'generated/levels/ch1_street_map.json').read_bytes().replace(b'\r\n', b'\n') == (root / 'data/levels/ch1_street_map.json').read_bytes()
assert (out / 'generated/levels/ch1_street.tres').read_bytes().replace(b'\r\n', b'\n') == (root / 'data/levels/ch1_street.tres').read_bytes()
(root / 'data/environment/themes/ch1_street.tres').write_bytes((out / 'generated/themes/ch1_street.tres').read_bytes().replace(b'\r\n', b'\n'))
paths += ['data/environment/materials/street_asphalt_platform.tres']
receipt = dict(scope='D-only single platform edge; level/map geometry byte-identical',
               files={p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths})
(out / 'receipt.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt, indent=2))
