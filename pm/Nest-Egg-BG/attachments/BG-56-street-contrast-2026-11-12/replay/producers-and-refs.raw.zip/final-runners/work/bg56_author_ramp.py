"""Adopt the proven local floor ramp in D; preserve original map/theme bytes."""
from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json

root = Path('D:/NestEggVerification/native-ticket-batch-20261111')
out = root / 'work/bg56-authored-ramp-v1'
out.mkdir(exist_ok=False)
(out / '.gdignore').write_bytes(b'')
paths = ['tools/level/build_ch1.py', 'data/levels/ch1_street.tres',
         'data/levels/ch1_street_map.json', 'data/environment/themes/ch1_street.tres',
         'data/audio/ambience.json', 'data/audio/music.json', 'data/lighting_preview/scenes.json']
for path in paths:
    target = out / 'before' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((root / path).read_bytes())
reference = root / 'tools/bg56_reference/ch1_street_initial_candidate.tres'
assert not reference.exists()
reference.write_bytes((root / 'data/levels/ch1_street.tres').read_bytes())
profile = (root / 'data/lighting/street_market.tres').read_text(encoding='utf8')
assert profile.count('id = &"street_market"') == 1 and 'creature_floor' not in profile
profile = profile.replace('id = &"street_market"', 'id = &"street_market_creature"') + 'creature_floor = 0.6\n'
(root / 'data/lighting/street_market_creature.tres').write_bytes(profile.encode())
builder_path = root / 'tools/level/build_ch1.py'
builder_text = builder_path.read_text(encoding='utf8')
assert builder_text.count("    a.zone(0, 'street_market')") == 1
builder_text = builder_text.replace("    a.zone(0, 'street_market')", "    a.zone(0, 'street_market')\n    a.zone(172, 'street_market_creature', 4)")
builder_path.write_bytes(builder_text.encode())

# Reuse only the side-effect-free text insertion function; never run the
# earlier author script (it contains historical candidate assertions).
tree = ast.parse(Path('work/bg56_author_candidate.py').read_text(encoding='utf8'))
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'add_alias')
namespace = dict(root=root, json=json, re=__import__('re'))
exec(compile(ast.Module(body=[node], type_ignores=[]), '<add_alias>', 'exec'), namespace)
add = namespace['add_alias']
ambience = json.loads((root / 'data/audio/ambience.json').read_bytes())
music = json.loads((root / 'data/audio/music.json').read_bytes())
add('data/audio/ambience.json', 'profiles', 'street_market_creature', copy.deepcopy(ambience['profiles']['market']))
add('data/audio/music.json', 'zones', 'street_market_creature', copy.deepcopy(music['map']['zones']['market']))
add('data/lighting_preview/scenes.json', 'presets', 'street_market_creature', ['harbor_street'], compact=True)
for path, keys in [('data/audio/ambience.json', ['profiles']), ('data/audio/music.json', ['map', 'zones']),
                   ('data/lighting_preview/scenes.json', ['presets'])]:
    before = json.loads((out / 'before' / path).read_bytes())
    after = json.loads((root / path).read_bytes())
    at = after
    for key in keys:
        at = at[key]
    del at['street_market_creature']
    assert before == after, path

spec = importlib.util.spec_from_file_location('bg56_ramp_builder', builder_path)
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
builder.ROOT = str(out / 'generated')
for name, folder in [('LEVEL_DIR', 'levels'), ('THEME_DIR', 'themes'), ('PROP_DIR', 'props'), ('ENCOUNTER_DIR', 'encounters')]:
    target = out / 'generated' / folder
    target.mkdir(parents=True)
    setattr(builder, name, str(target))
area = builder.build_street()
extra = {'props': builder.prepare_props(area.props, area.id)}
if area.regions:
    extra['regions'] = area.regions
area.grid.write(area.id, (builder.LEVEL_DIR, 'ch1_street_map.json'), extra)
builder.write_level(area)
assert (out / 'generated/levels/ch1_street_map.json').read_bytes().replace(b'\r\n', b'\n') == (root / 'data/levels/ch1_street_map.json').read_bytes()
assert (out / 'generated/themes/ch1_street.tres').read_bytes().replace(b'\r\n', b'\n') == (root / 'data/environment/themes/ch1_street.tres').read_bytes()
(root / 'data/levels/ch1_street.tres').write_bytes((out / 'generated/levels/ch1_street.tres').read_bytes().replace(b'\r\n', b'\n'))
paths += ['data/lighting/street_market_creature.tres']
receipt = dict(scope='D-only proven early optional floor; original collision/map/theme unchanged',
               map_and_theme_byte_identical=True,
               files={path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths})
(out / 'receipt.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps(receipt, indent=2))
