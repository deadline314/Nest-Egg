class_name CharactersSuite
extends TestSuite
## 新增的角色骨架外觀（NE-44）：老 K、芽、航、回收員，以及狙擊手、火焰兵、重裝機槍手。
## 驗收重點：外觀定義與規格一致（尺寸、支點）、零件圖／發光層／法線都在且尺寸正確、
## 肢體確實畫到下一個關節（對位）、動畫與裝甲脫落正常、髮色與服裝和頭像一致。

const NEW_CHARACTERS: Array[String] = ["old_k", "mei", "wataru", "reclaimer", "sniper", "flamer", "heavy_gunner"]
## 會上場戰鬥的外觀：必須有可破壞裝甲。
const COMBATANTS: Array[String] = ["reclaimer", "sniper", "flamer", "heavy_gunner"]
## 衣物也會被打飛的角色（可操控的芽）：和戰鬥角色一樣檢查脫落與還原。
const BREAKABLE: Array[String] = ["reclaimer", "sniper", "flamer", "heavy_gunner", "mei"]
const NEW_WEAPONS: Array[String] = ["sniper", "flamethrower"]
## 規格基準（Q 版人形骨架的零件尺寸與支點）；凜已改用 7.5 頭身的專屬骨架，不再是基準。
## 零件依序在這幾個角色裡找規格：老 K 有基本零件與衣襬、回收員有裝甲、芽有後髮。
const REFERENCES: Array[String] = ["old_k", "reclaimer", "mei"]
const REQUIRED_PARTS: Array[String] = ["head", "torso", "pelvis", "arm_upper", "arm_lower", "hand", "leg_upper", "leg_lower", "foot"]
## 肢體零件要畫到下一個關節（規格書的「子關節」）：貼圖 → 從畫布左上角算起的位置。
const LIMB_ENDS := {
	"arm_upper": Vector2(12, 42), "arm_lower": Vector2(11, 37), "leg_upper": Vector2(14, 50), "leg_lower": Vector2(12, 48),
}
## 各角色預設的手持武器（空字串＝空手）。
const WEAPONS := {
	"old_k": "pistol", "mei": "smg", "wataru": "", "reclaimer": "rifle", "sniper": "sniper", "flamer": "flamethrower", "heavy_gunner": "minigun",
}
## 頭像取樣點（128×128）：{ 角色: [頭髮或頭盔處, 衣服處] }，與 painter_style 的 hair／armor 與 coat 比對。
const PORTRAIT_SAMPLES := {
	"old_k": [Vector2(60, 20), Vector2(60, 110)],
	"mei": [Vector2(50, 26), Vector2(60, 110)],
	"wataru": [Vector2(50, 26), Vector2(60, 110)],
	"reclaimer": [Vector2(70, 30), Vector2(60, 110)],
}
const HUE_TOLERANCE := 0.07
const VALUE_TOLERANCE := 0.3
const POSES: Array[String] = ["idle", "run", "aim", "crouch", "jump", "block", "stagger", "dead"]


func run() -> void:
	_test_definitions()
	_test_rin_density()
	_test_alignment()
	_test_portraits()
	_test_weapons()
	await _test_rigs()
	await _test_rin_hand_grips()
	_test_rin_hand_grip_density()


func _test_rin_hand_grips() -> void:
	var rig := CharacterRig.new()
	runner.get_tree().root.add_child(rig)
	check(rig.setup("rin"), "Rin independent hands build")
	check(is_equal_approx(rig.bone(&"hand_front").rotation, HumanoidAnimator.HAND_FOLLOWS_FOREARM) and is_equal_approx(rig.bone(&"hand_back").rotation, HumanoidAnimator.HAND_FOLLOWS_FOREARM), "freshly built hands use the forearm rest direction rather than turning ninety degrees on their first update")
	var hands := rig.find_children("hand_*", "Sprite2D", true, false)
	check(hands.size() == 2 and rig._hand_grips.size() == 2, "Rin has exactly two hand slots and two cached gripping attachments")
	var input := RigInput.new()
	input.on_floor = true
	var rest_textures := [hands[0].texture, hands[1].texture]
	for side in [1, -1]:
		input.facing = side
		for weapon in ["rifle", "pistol"]:
			rig.set_weapon(weapon)
			for angle in [-0.6, 0.0, 0.6]:
				input.aim_dir = Vector2(cos(angle) * side, sin(angle))
				input.two_handed = weapon == "rifle"
				for frame in 30:
					rig.animate(1.0 / 60.0, input)
				var palm := rig.bone(&"hand_front").global_transform * rig.hand_grip_offset(&"hand_front")
				check(palm.distance_to(rig.weapon_root().global_position) < 0.025, "Rin front palm holds the weapon without moving the wrist pivot: %s/%d/%.1f" % [weapon, side, angle])
				if input.two_handed:
					var def := rig.weapon_def()
					var point := (RigLibrary.vec2(def["foregrip"]) - RigLibrary.vec2(def["grip"])) * rig.weapon_scale()
					palm = rig.bone(&"hand_back").global_transform * rig.hand_grip_offset(&"hand_back")
					check(palm.distance_to(rig.weapon_root().global_transform * point) < 0.025, "Rin supporting palm holds the foregrip: %d/%.1f" % [side, angle])
				else:
					check(rig.hand_grip_offset(&"hand_back") == Vector2.ZERO, "single-handed weapon keeps the free left hand open")
		rig.set_weapon("")
		rig.animate(1.0 / 60.0, input)
		check(hands[0].texture == rest_textures[0] and hands[1].texture == rest_textures[1], "unarmed restores the same two resting hand textures")
		rig.set_weapon("rifle")
		input.dead = true
		rig.animate(1.0 / 60.0, input)
		check(rig.hand_grip_offset(&"hand_front") == Vector2.ZERO and rig.hand_grip_offset(&"hand_back") == Vector2.ZERO, "death releases both gripping attachments")
		input.dead = false
	input.two_handed = true
	input.action = &"rin.phone_call"
	input.action_t = 0.6
	rig.set_weapon("handset")
	for frame in 30: rig.animate(1.0 / 60.0, input)
	check(rig.hand_grip_offset(&"hand_back") == Vector2.ZERO, "phone action keeps the human supporting hand free")
	var phone_palm := rig.bone(&"hand_front").global_transform * rig.hand_grip_offset(&"hand_front")
	check(phone_palm.distance_to(rig.weapon_root().global_position) < 0.025, "phone action attaches the handset to the palm rather than the wrist")
	rig.get_parent().remove_child(rig)
	rig.free()
	var other := CharacterRig.new()
	runner.get_tree().root.add_child(other)
	check(other.setup("enforcer") and other._hand_grips.is_empty(), "unconfigured characters retain their original hands and zero grasp offsets")
	other.free()


func _test_rin_hand_grip_density() -> void:
	var cache_path := RigLibrary.CHARACTER_PATH % "rin"
	var original := RigLibrary.character("rin")
	for value: Variant in [&"missing", 0.018283541156251144, 0, -1.0, INF, NAN, "0.02", true, null]:
		var fixture := original.duplicate(true)
		var missing := typeof(value) == TYPE_STRING_NAME
		var valid: bool = missing or (typeof(value) == TYPE_FLOAT and is_finite(value) and float(value) > 0.0)
		if not missing:
			fixture["textures"]["hand_left_grip"]["texture_scale"] = value
		else:
			fixture["textures"]["hand_left_grip"].erase("texture_scale")
		RigLibrary._json_cache[cache_path] = fixture
		var rig := CharacterRig.new()
		runner.get_tree().root.add_child(rig)
		check(rig.setup("rin"), "grip density fixture builds: %s" % str(value))
		RigLibrary._json_cache[cache_path] = original
		var hand := rig.bone(&"hand_back").get_node_or_null("hand_back") as Sprite2D
		check(hand != null and hand.get_parent() == rig.bone(&"hand_back"), "invalid density preserves the attached resting hand: %s" % str(value))
		if hand == null:
			rig.free()
			continue
		var rest_scale := hand.scale
		var rest_texture := hand.texture
		var rest_offset := hand.offset
		var input := RigInput.new()
		input.two_handed = true
		input.on_floor = true
		rig.set_weapon("rifle")
		for side in [1, -1]:
			input.facing = side
			input.aim_dir = Vector2(side, -0.3)
			for frame in 30: rig.animate(1.0 / 60.0, input)
			var expected_scale := float(value) if valid and not missing else float(original["texture_scale"])
			check(hand.scale.is_equal_approx(Vector2.ONE * expected_scale), "native grip density applies without resampling: %s/%d" % [str(value), side])
			if valid:
				var foregrip := (RigLibrary.vec2(rig.weapon_def()["foregrip"]) - RigLibrary.vec2(rig.weapon_def()["grip"])) * rig.weapon_scale()
				var palm := rig.bone(&"hand_back").to_global(rig.hand_grip_offset(&"hand_back"))
				check(palm.distance_to(rig.weapon_root().to_global(foregrip)) < 0.025, "native grip density preserves the authored weapon attachment: %s/%d" % [str(value), side])
			else:
				check(hand.texture == rest_texture and hand.offset == rest_offset and rig.hand_grip_offset(&"hand_back") == Vector2.ZERO, "bad density rejects the grip safely: %s/%d" % [str(value), side])
		for state in [&"one_hand", &"shield", &"action", &"dead", &"unarmed"]:
			input.two_handed = state != &"one_hand"
			input.shield_forward = state == &"shield"
			input.action = &"rin.phone_call" if state == &"action" else &""
			input.dead = state == &"dead"
			rig.set_weapon("" if state == &"unarmed" else "rifle")
			rig.animate(1.0 / 60.0, input)
			check(hand.scale == rest_scale and hand.texture == rest_texture and hand.offset == rest_offset, "resting hand density and attachment restore: %s/%s" % [str(value), str(state)])
		rig.free()


func _test_rin_density() -> void:
	var spec: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://tools/comfyui/specs/rin_side.json"))
	var skin := RigLibrary.character("rin")
	check(is_equal_approx(float(spec["tex_px_per_wp"]), float(spec["illustration_px_per_wp"])), "Rin parts keep the approved source density without intermediate downsampling")
	check(absf(float(skin["texture_scale"]) * float(spec["tex_px_per_wp"]) - 1.0) < 0.0001, "Rin texture density and runtime world scale agree")
	for def: Dictionary in (skin["textures"] as Dictionary).values():
		var path := RigLibrary.character_dir("rin").path_join(str(def["file"]))
		var size := Vector2i(RigLibrary.vec2(def["size"]))
		for file in [path, path.get_basename() + "_n.png"]:
			var image := _texture_image(file)
			check(image != null and image.get_size() == size, "Rin loaded diffuse/normal keeps its declared native size: %s" % file)
	var portrait := _texture_image("res://art/portraits/rin.png")
	check(portrait != null and portrait.get_size() == Vector2i(256, 256), "Rin dialogue portrait is rendered from the 256-pixel source export")


## 零件 tex_name 的規格（尺寸與支點），在 REFERENCES 裡找到的第一個；沒有就回傳空字典。
func _reference_spec(tex_name: String) -> Dictionary:
	for id in REFERENCES:
		var def: Dictionary = RigLibrary.character(id).get("textures", {}).get(tex_name, {})
		if not def.is_empty():
			return def
	return {}


## 目前顯示中的裝甲零件數（名稱以 armor_ 開頭的零件，Sprite2D 或 RigPartMesh）。
func _visible_armor(rig: CharacterRig) -> int:
	var visible := 0
	for node in rig.find_children("armor_*", "CanvasItem", true, false):
		visible += 1 if (node as CanvasItem).visible else 0
	return visible


func _texture_image(path: String) -> Image:
	var tex := load(path) as Texture2D if ResourceLoader.exists(path) else null
	return tex.get_image() if tex != null else null


func _test_definitions() -> void:
	for id in NEW_CHARACTERS:
		var skin := RigLibrary.character(id)
		check(not skin.is_empty() and str(skin.get("id")) == id, "character definition loads and id matches its folder: %s" % id)
		check(not str(skin.get("display_name", "")).is_empty(), "character has a display name: %s" % id)
		var textures: Dictionary = skin.get("textures", {})
		var dir := RigLibrary.character_dir(id)
		for part_name in REQUIRED_PARTS:
			check(textures.has(part_name), "%s defines the required part %s" % [id, part_name])
		for tex_name: String in textures.keys():
			var def: Dictionary = textures[tex_name]
			if not RigLibrary.has_own_rig(id):  # 重畫過的角色有自己的骨架與零件尺寸，不比對 Q 版規格
				var spec := _reference_spec(tex_name)
				check(not spec.is_empty(), "%s.%s is a part the rig spec knows" % [id, tex_name])
				check(def.get("size") == spec.get("size") and def.get("pivot") == spec.get("pivot"), "%s.%s keeps the spec size and pivot" % [id, tex_name])
			var size := RigLibrary.vec2(def.get("size"))
			var file_path := dir.path_join(str(def.get("file")))
			var image := _texture_image(file_path)
			check(image != null and Vector2(image.get_size()) == size, "%s.%s image matches the declared canvas" % [id, tex_name])
			var normal := _texture_image(file_path.get_basename() + "_n.png")
			check(normal != null and Vector2(normal.get_size()) == size, "%s.%s has a normal map of the same size" % [id, tex_name])
			if def.has("glow"):
				var glow := _texture_image(dir.path_join(str(def["glow"])))
				check(glow != null and Vector2(glow.get_size()) == size, "%s.%s has a glow layer of the same size" % [id, tex_name])
		if RigLibrary.has_own_rig(id):
			check(float(skin.get("texture_scale", 0.0)) > 0.0 and RigLibrary.standing_height(id) > 30.0, "%s has a texture scale and a plausible standing height (%.0f)" % [id, RigLibrary.standing_height(id)])
		else:
			check(float(skin.get("texture_scale", 0.0)) == 0.25, "%s is drawn at 4x resolution" % id)
		var armor_orders: Array[int] = []
		for part: Dictionary in skin.get("parts", []):
			if int(part.get("armor_order", 0)) > 0:
				armor_orders.append(int(part["armor_order"]))
		if COMBATANTS.has(id):
			check(armor_orders.size() >= 4, "%s has breakable armor (%d pieces)" % [id, armor_orders.size()])
	check(RigLibrary.standing_height("wataru") <= 45.0, "wataru is drawn smaller (a child, %.0f)" % RigLibrary.standing_height("wataru"))
	for id in ["old_k", "mei", "reclaimer", "sniper"]:
		check(RigLibrary.standing_height(id) > RigLibrary.standing_height("wataru"), "%s is taller than wataru" % id)
	check(RigLibrary.standing_height("heavy_gunner") > RigLibrary.standing_height("enforcer"), "the heavy gunner is bigger than an enforcer")


## 對位檢查：肢體零件的支點與下一個關節都有畫到東西（沒畫到就會在關節處出現縫隙），主要零件不是空圖。
func _test_alignment() -> void:
	for id in NEW_CHARACTERS:
		var skin := RigLibrary.character(id)
		var dir := RigLibrary.character_dir(id)
		var textures: Dictionary = skin.get("textures", {})
		for tex_name: String in LIMB_ENDS.keys():
			if not textures.has(tex_name) or RigLibrary.has_own_rig(id):  # 肢體終點座標是 Q 版規格的數字
				continue
			var def: Dictionary = textures[tex_name]
			var image := _texture_image(dir.path_join(str(def["file"])))
			if image == null:
				check(false, "%s.%s image readable for the alignment check" % [id, tex_name])
				continue
			var pivot := RigLibrary.vec2(def.get("pivot"))
			var end: Vector2 = LIMB_ENDS[tex_name]
			check(image.get_pixelv(Vector2i(pivot)).a > 0.5, "%s.%s is painted at its pivot" % [id, tex_name])
			check(image.get_pixelv(Vector2i(end)).a > 0.5, "%s.%s reaches the next joint" % [id, tex_name])
		for tex_name in ["head", "torso", "pelvis", "foot", "hand"]:
			var image := _texture_image(dir.path_join(str(textures[tex_name]["file"])))
			var opaque := 0
			if image != null:
				for y in image.get_height():
					for x in image.get_width():
						if image.get_pixel(x, y).a > 0.5:
							opaque += 1
			var ratio := float(opaque) / maxf(1.0, float(image.get_width() * image.get_height())) if image != null else 0.0
			check(ratio > 0.12, "%s.%s is not an empty image (%.0f%% opaque)" % [id, tex_name, ratio * 100.0])


## 髮色與服裝以頭像為準：頭像取樣點的色相與亮度要和外觀的 painter_style 接近。
func _test_portraits() -> void:
	for id: String in PORTRAIT_SAMPLES.keys():
		var style: Dictionary = RigLibrary.character(id).get("painter_style", {})
		if style.is_empty():  # 重畫過的角色沒有程式繪製的設定，頭像由新立繪切出，不比對
			continue
		var portrait := _texture_image("res://art/portraits/%s.png" % id)
		check(portrait != null, "portrait exists for %s" % id)
		if portrait == null:
			continue
		var samples: Array = PORTRAIT_SAMPLES[id]
		var keys: Array[String] = ["hair" if style.has("hair") else "armor", "coat"]
		for i in 2:
			var from_portrait := portrait.get_pixelv(Vector2i(samples[i] as Vector2))
			var from_style := Color(str(style.get(keys[i], "#ff00ff")))
			var close := absf(from_portrait.v - from_style.v) <= VALUE_TOLERANCE
			if from_portrait.s > 0.2 and from_style.s > 0.2:
				var hue_gap := absf(from_portrait.h - from_style.h)
				close = close and minf(hue_gap, 1.0 - hue_gap) <= HUE_TOLERANCE
			check(close, "%s %s matches its portrait (portrait %s, style %s)" % [id, keys[i], from_portrait.to_html(false), from_style.to_html(false)])


func _test_weapons() -> void:
	var base_dir := RigLibrary.WEAPONS_PATH.get_base_dir()
	for id in NEW_WEAPONS:
		var def := RigLibrary.weapon(id)
		check(not def.is_empty(), "weapon visual exists: %s" % id)
		var size := RigLibrary.vec2(def.get("size"))
		for key in ["file", "glow"]:
			var image := _texture_image(base_dir.path_join(str(def.get(key, ""))))
			check(image != null and Vector2(image.get_size()) == size, "weapon %s %s image matches its canvas" % [id, key])
		var normal := _texture_image(base_dir.path_join(str(def.get("file", ""))).get_basename() + "_n.png")
		check(normal != null, "weapon %s has a normal map" % id)
		var muzzle := RigLibrary.vec2(def.get("muzzle"))
		check(Rect2(Vector2.ZERO, size).has_point(muzzle) and muzzle.x > size.x * 0.8, "weapon %s muzzle is inside the canvas, at the front" % id)


func _test_rigs() -> void:
	var holder := Node2D.new()
	runner.get_tree().root.add_child(holder)
	for id in NEW_CHARACTERS:
		var rig := CharacterRig.new()
		holder.add_child(rig)
		check(rig.setup(id) and rig.is_valid(), "rig builds: %s" % id)
		rig.set_weapon(str(WEAPONS[id]))
		var input := RigInput.new()
		for pose in POSES:
			input.facing = 1
			input.aim_dir = Vector2(1, -0.6).normalized() if pose == "aim" else Vector2.RIGHT
			input.on_floor = pose != "jump"
			input.velocity = Vector2(150, 0) if pose == "run" else (Vector2(80, -200) if pose == "jump" else Vector2.ZERO)
			input.crouching = pose == "crouch"
			input.blocking = pose == "block"
			input.staggered = pose == "stagger"
			input.dead = pose == "dead"
			for i in 20:
				rig.animate(1.0 / 60.0, input)
		input.dead = false
		input.staggered = false
		input.aim_dir = Vector2.RIGHT
		input.velocity = Vector2.ZERO
		for i in 30:
			rig.animate(1.0 / 60.0, input)
		await frames(1)
		if not str(WEAPONS[id]).is_empty():
			var hand := rig.bone(&"hand_front").global_position
			check(hand.distance_to(rig.weapon_root().global_position) < 2.0, "%s: front hand holds the weapon" % id)
			check(rig.muzzle_global().x > rig.global_position.x + 6.0, "%s: muzzle is in front of the character" % id)
		var armor := rig.armor_count()
		if BREAKABLE.has(id):
			var total := _visible_armor(rig)  # 一步可以有好幾片（前後側的同一種護甲），所以用零件數而不是步數比較
			rig.set_armor_ratio(0.0, false)
			check(_visible_armor(rig) == 0, "%s: all armor falls off at zero health" % id)
			rig.set_armor_ratio(1.0, false)
			check(_visible_armor(rig) == total and total >= armor, "%s: armor is restored at full health" % id)
		else:
			check(armor == 0, "%s: civilians have no breakable armor" % id)
		rig.queue_free()
	holder.queue_free()
	await frames(2)
