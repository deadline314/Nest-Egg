from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg41-current')
out=base/'shared-regression';out.mkdir(exist_ok=False)
paths=json.loads((base/'fill-green/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths;runs=[];passed=False
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
try:
    for name,level in [('legacy','level_01'),('ch1','ch1_handoff'),('ch3','ch3_plaza')]:
        for quality in ['low','high']:
            for side in ['before','after']:
                case=name+'-'+side+'-'+quality;folder=out/case;folder.mkdir();env=os.environ.copy()
                for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
                command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg41-current/shared-'+name+'-'+side+'.tscn','--','--out='+str(folder),'--level='+level,'--quality='+quality,'--detail']
                with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
                raw=(folder/'raw.log').read_bytes();report=json.loads((folder/'readability-report.json').read_text());samples=json.loads((folder/'frame-samples.json').read_text())
                row={'name':case,'level':level,'side':side,'quality':quality,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'spots':len(report['results']),'samples':len(samples),'all_passed':all(s['passed'] for s in report['results'])}
                runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
                assert row['script_errors']==0 and not row['engine_error'] and row['source_held'] and row['spots']>0 and row['samples']==row['spots']*16
                assert r.returncode==0 if side=='after' else r.returncode in [0,1]
                assert report['light_quality']==(0 if quality=='low' else 2) and report['thresholds']=={'player':.6,'edge':1.,'enemy':.45}
                assert all(s['sampling_valid'] for s in report['results'])
                if side=='after':assert row['all_passed']
    passed=True
finally:
    after=snapshot();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'result.json').write_text(json.dumps({'passed':passed,'source_held':before==after,'completed_producers':len(runs),'scope':'Original absolute gates at all other authored market-profile consumer probes; paired previous gain0.6 numbers retained. Chapter-two consumers are covered by the real-enemy fixture matrix.'},indent=2)+'\n')
