from pathlib import Path
import copy,hashlib,json,re,subprocess,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg41-current');base.mkdir(exist_ok=False)
private=root/'work/bg41-current';private.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=primary).decode().strip()=='66b36fe092381d7ab8596cf3818021d87f00e162'
sys.dont_write_bytecode=True;sys.path.insert(0,str(primary/'tools/level'))
import build_ch2 as ch2
ch2.configure();kit=ch2.kit
parent='f5869f249515112bbaaadb4c6bea5ec2513a5268'
proofs=[]
for ident in ['loading','market']:
    level='ch2_'+ident;folder=private/ident;folder.mkdir()
    current=json.loads((root/('data/levels/'+level+'_map.json')).read_text())
    assert current['legacy_layout']=={'revision':1,'cell_offset':[0,16],'cells':{}}
    assert kit._map_extra(getattr(ch2,'build_'+ident)())['props']==current['props']
    old_map=subprocess.check_output(['git','show',parent+':data/levels/'+level+'_map.json'],cwd=primary)
    old_theme=subprocess.check_output(['git','show',parent+':data/environment/themes/'+level+'.tres'],cwd=primary)
    old_level=subprocess.check_output(['git','show',parent+':data/levels/'+level+'.tres'],cwd=primary)
    old=json.loads(old_map);legacy=getattr(ch2,'_build_'+ident+'_v1')();legacy.props=copy.deepcopy(old['props'])
    mapped=kit._map_extra(kit._v2_area(legacy))['props']
    assert len(mapped)==len(old['props'])==(5 if ident=='loading' else 9)
    assert all(p.get('y')==35 and p.get('ground') is False for p in mapped)
    before=copy.deepcopy(current);before['props']=mapped
    assert {k:v for k,v in before.items() if k!='props'}=={k:v for k,v in current.items() if k!='props'}
    (folder/'before-map.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    theme=(root/('data/environment/themes/'+level+'.tres')).read_text()
    dirs=next(line for line in old_theme.decode().splitlines() if line.startswith('extra_prop_dirs = '))
    (folder/'before-theme.tres').write_text(re.sub(r'^extra_prop_dirs = .*$',lambda _:dirs,theme,flags=re.M),encoding='utf-8',newline='\n')
    data=(root/('data/levels/'+level+'.tres')).read_text()
    data=data.replace('res://data/environment/themes/'+level+'.tres','res://work/bg41-current/'+ident+'/before-theme.tres').replace('res://data/levels/'+level+'_map.json','res://work/bg41-current/'+ident+'/before-map.json')
    if ident=='loading':
        old_block=next(b for b in re.split(r'\n(?=\[)',old_level.decode()) if 'id = &"loading_sc1"' in b)
        block=next(b for b in re.split(r'\n(?=\[)',data) if 'id = &"loading_sc1"' in b)
        assert 'style = "door"' in old_block and 'style = "hidden"' in block
        data=data.replace(block,block.replace('style = "hidden"','style = "door"'))
    (folder/'before-level.tres').write_text(data,encoding='utf-8',newline='\n')
    for suffix,value in [('map.json',old_map),('theme.tres',old_theme),('level.tres',old_level)]:
        (base/(ident+'-original-'+suffix)).write_bytes(value)
    proofs.append({'level':level,'parent':parent,'before_props':len(mapped),'current_props':len(current['props']),'same_nonprops':True,'legacy_offset':[0,16],
        'current_generator_props_match':True,'baseline_mapper':'Existing build_ch2 -> _v2_area -> _map_extra, with only original pre-BG41 authored props substituted. All floor anchors explicitly mapped to row35, preserving current upper routes, NPCs, foes, portals and capabilities.',
        'portal_style':'Original door visual for loading_sc1 restored only in private before LevelData; current flag/positions/size and all other portal fields retained.' if ident=='loading' else 'unchanged',
        'original_sha256':{suffix:hashlib.sha256(value).hexdigest() for suffix,value in [('map.json',old_map),('theme.tres',old_theme),('level.tres',old_level)]}})
    tour=(root/'tools/scene_tour.gd').read_bytes();needle=b'var path := "res://data/levels/%s.tres" % level_id';assert tour.count(needle)==1
    (folder/'before-tour.gd').write_bytes(tour.replace(needle,('var path := "res://work/bg41-current/'+ident+'/before-level.tres"').encode()))
    phase=(root/'tools/readability_phase_probe.gd').read_bytes()
    (folder/'before-phase.gd').write_bytes(phase.replace(b'extends "res://tools/scene_tour.gd"',('extends "res://work/bg41-current/'+ident+'/before-tour.gd"').encode(),1))
    for side,parent_script in [('before','res://work/bg41-current/'+ident+'/before-phase.gd'),('after','res://tools/readability_phase_probe.gd')]:
        source='extends "'+parent_script+'"\n'+'''func _frame_interval_ms() -> float:
    var environment := get_viewport().find_world_3d().environment
    var enemies: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(&"enemies"):
        enemies.append({"kind":str(node.get_script().get_global_name()),"world":[node.global_position.x,node.global_position.y]})
    print("BG41_ENV ",JSON.stringify({"environment":environment!=null,"glow":environment!=null and environment.glow_enabled,"count":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),"hdr":get_viewport().use_hdr_2d,"quality":Settings.get_light_quality(),"size":[get_viewport().get_texture().get_width(),get_viewport().get_texture().get_height()],"enemies":enemies}))
    return await super._frame_interval_ms()
'''
        (folder/(side+'-observer.gd')).write_text(source,encoding='utf-8',newline='\n')
        (folder/(side+'-observer.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/'+ident+'/'+side+'-observer.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
(base/'baseline-proof.json').write_text(json.dumps(proofs,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cfg=json.loads((root/'assets_src/pipeline/scene_props.json').read_text(encoding='utf-8'))
ids={'neon_market__rent_window','dock_warehouse__collection_book_stand','dock_warehouse__drying_desk','dock_warehouse__bridge_lever','dock_warehouse__bridge_ladder_up','dock_warehouse__bridge_ladder_down'}
props=[p for p in cfg['props'] if p['id'] in ids];assert len(props)==6 and {p['seed'] for p in props}==set(range(7301,7307))
(base/'pipeline-extract.json').write_text(json.dumps({'styles':cfg['styles'],'defaults':cfg['defaults'],'props':props},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps([{'level':p['level'],'before_props':p['before_props'],'after_props':p['current_props'],'floor_row':35,'controlled_old_bridge_door':p['level']=='ch2_loading'} for p in proofs]),flush=True)
