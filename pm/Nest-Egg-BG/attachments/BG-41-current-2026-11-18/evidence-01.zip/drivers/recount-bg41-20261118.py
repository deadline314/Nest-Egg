from pathlib import Path
import json,math
base=Path('D:/NestEggVerification/evidence-20261117/bg41-current')
for phase in ['fixtures-v2','shared-regression']:
    for folder in sorted((base/phase).iterdir()):
        if not (folder/'readability-report.json').exists():continue
        data=json.loads((folder/'readability-report.json').read_text());samples=json.loads((folder/'frame-samples.json').read_text())
        for s in data['results']:
            records=[r for r in samples if r['level']==s['level'] and r['spot']==s['spot']]
            if not s['passed'] or phase=='shared-regression':
                print(json.dumps({'phase':phase,'case':folder.name,'spot':s['spot'],'player':s['player_contrast'],'edge':s['edge_contrast'],'enemy':s['enemy_contrast'],'scale':sorted(set(r['enemy_fill_scale'] for r in records)),'enemy_fill':sorted(set(r['enemy_fill'] for r in records)),'valid':s['sampling_valid']},ensure_ascii=False))
comparisons=[]
for quality in ['low','high']:
    sides=[json.loads((base/'fixtures-v2'/f'{side}-{quality}'/'readability-report.json').read_text())['results'] for side in ['before','after']]
    for level in ['ch2_market','ch2_loading']:
        groups=[[s for s in side if s['level']==level] for side in sides]
        row={'quality':quality,'level':level,'all_after_absolute_pass':all(s['passed'] for s in groups[1]),'minima':{}}
        for key in ['player_contrast','edge_contrast','enemy_contrast']:
            values=[[s[key] for s in g if s[key] is not None] for g in groups]
            if all(values):row['minima'][key]=[min(a) for a in values]
        assert row['all_after_absolute_pass']
        if level=='ch2_loading':assert row['minima']['enemy_contrast'][1]>=row['minima']['enemy_contrast'][0]
        comparisons.append(row)
(base/'fixture-recount.json').write_text(json.dumps({'scope':'Original 16-sample fixture absolute gates plus real-enemy regional nondrop. Extra fixture player/edge nondrop rejected in original outer driver; formal 5-median tour is primary scenery regional nondrop contract. No driver failure overwritten.','comparisons':comparisons},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(comparisons,ensure_ascii=False))
