from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');source=(p/'run-bg41-state-20261118.py').read_text()
source=source.replace("out=base/'states-v3'","out=base/'guard-wall'").replace("work/bg41-state-20261118.gd","work/bg41-guard-wall-20261118.gd").replace("private/'state.gd'","private/'guard.gd'").replace("private/'state.tscn'","private/'guard.tscn'").replace('bg41-current/state.gd','bg41-current/guard.gd').replace('bg41-current/state.tscn','bg41-current/guard.tscn').replace("len(states['rows'])==7","len(states['rows'])==2").replace("len(list(folder.glob('*.png')))==7","len(list(folder.glob('*.png')))==2").replace("assert states['actual_lever_talk'] and len(states['routes'])==2","assert states['wall_supported']")
(p/'run-bg41-guard-wall-20261118.py').write_text(source)
print('Existing rendered support geometry plus native normal/flat guard context; no new production wall or character.')
