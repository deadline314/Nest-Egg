from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg41-current')
out=base/'enemy-fill';out.mkdir(exist_ok=False);private=root/'work/bg41-current/loading'
(private/'enemy-fill.gd').write_text('''extends "res://work/bg41-current/loading/stationary-after.gd"
var _market: LightingProfile
func _ready() -> void:
    _market = load("res://data/lighting/market.tres") as LightingProfile
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--enemy-fill="):
            _market.enemy_fill_scale = float(argument.trim_prefix("--enemy-fill="))
    super._ready()
func _frame_interval_ms() -> float:
    for child in get_children():
        if child is Level:
            print("BG41_FILL ",JSON.stringify({"configured":_market.enemy_fill_scale,"actual":child._lighting.current.enemy_fill_scale,"enemy_fill":LightKit.enemy_fill,"character_fill":LightKit.character_fill}))
    return await super._frame_interval_ms()
func _measure(level: Level, world: Rect2) -> Dictionary:
    var result := await super._measure(level,world)
    var probe := ContrastProbe.capture(get_viewport())
    var parts: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(&"enemies"):
        if node is Enemy and node.is_visible_in_tree() and world.grow(-24).has_point(node.global_position):
            parts.append({"id":str(node.data.id),"feet":[node.global_position.x,node.global_position.y],"parts":probe.character_parts(node.global_position)})
    result["enemy_parts_diagnostic"] = parts
    return result
''',encoding='utf-8',newline='\n')
(private/'enemy-fill.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/loading/enemy-fill.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
paths=json.loads((base/'stationary-control/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths;runs=[]
try:
    for gain in [.6,.9]:
        for quality in ['low','high']:
            folder=out/(str(gain)+'-'+quality);folder.mkdir();env=os.environ.copy()
            for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
            command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg41-current/loading/enemy-fill.tscn','--','--out='+str(folder),'--level=ch2_loading','--tag=fill','--quality='+quality,'--cells=3:3','--player','--fixed-aim','--enemy-fill='+str(gain)]
            with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
            raw=(folder/'raw.log').read_bytes();report=json.loads((folder/'ch2_loading/fill-index.json').read_text());values=[v for shot in report['shots'] for v in shot.get('enemy_contrast',[])]
            observations=[json.loads(line.split(b'BG41_FILL ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG41_FILL ')]
            row={'gain':gain,'quality':quality,'command':command,'exit':r.returncode,'source_held':before==snapshot(),'enemy_contrast':values,'observations':observations}
            runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
            assert r.returncode==0 and b'ERROR:' not in raw and row['source_held'] and len(values)==2
            assert len(observations)==1 and abs(observations[0]['actual']-gain)<1e-6
finally:
    (out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
