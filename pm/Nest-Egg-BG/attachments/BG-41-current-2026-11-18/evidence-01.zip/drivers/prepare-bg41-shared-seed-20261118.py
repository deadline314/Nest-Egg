from pathlib import Path
root=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg41-current')
for name in ['legacy','ch1','ch3']:
    for side in ['before','after']:
        leaf='shared-seeded-'+name+'-'+side
        (root/(leaf+'.gd')).write_text('extends "res://work/bg41-current/shared-'+name+'-'+side+'.gd"\nfunc _prepare_probe_level(data: LevelData) -> void:\n    super._prepare_probe_level(data)\n    seed(410018)\n')
        (root/(leaf+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/'+leaf+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
source=Path('C:/Users/stanl/Github/Nest-Egg/work/run-bg41-shared-regression-20261118.py').read_text()
assert "out=base/'shared-regression'" in source and "res://work/bg41-current/shared-'" in source
source=source.replace("out=base/'shared-regression'","out=base/'shared-seeded'").replace("res://work/bg41-current/shared-'","res://work/bg41-current/shared-seeded-'")
Path('C:/Users/stanl/Github/Nest-Egg/work/run-bg41-shared-seeded-20261118.py').write_text(source)
print('Matched reproducible initial RNG seed410018; native flicker/lightning still active, original sample timings and thresholds unchanged. First unseeded cargo0.444 outside market zone retained as failure.')
