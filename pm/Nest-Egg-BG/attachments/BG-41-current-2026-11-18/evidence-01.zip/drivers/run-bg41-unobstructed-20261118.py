from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg41-current');out=base/'unobstructed';out.mkdir(exist_ok=False)
private=root/'work/bg41-current/loading'
for side in ['before','after']:
    source='extends "res://work/bg41-current/loading/'+side+'-observer.gd"\n'+'''func _place_player(level: Level, center: Vector2, view: Vector2) -> void:
    var separated := center
    separated.x = 904.0 if center.x<1000.0 else 984.0
    super._place_player(level,separated,view)
func _measure(level: Level, world: Rect2) -> Dictionary:
    var result := await super._measure(level,world)
    var probe := ContrastProbe.capture(get_viewport())
    var player_region := probe._body_box(level.player.global_position,true).grow(ContrastProbe.RING)
    var clear := true
    for node in get_tree().get_nodes_in_group(&"enemies"):
        if node is Node2D and node.is_visible_in_tree() and world.grow(-24.0).has_point(node.global_position):
            clear = clear and not player_region.intersects(probe._body_box(node.global_position,false).grow(ContrastProbe.RING))
    result["player_enemy_regions_disjoint"] = clear
    print("BG41_UNOBSTRUCTED ",JSON.stringify({"player_world":result.player_world,"regions_disjoint":clear,"enemies":result.get("enemy_contrast",[])}))
    return result
'''
    (private/('safe-'+side+'.gd')).write_text(source,encoding='utf-8',newline='\n')
    (private/('safe-'+side+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/loading/safe-'+side+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
paths=json.loads((base/'native/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
try:
    for quality in ['low','high']:
        for side,level in [('before','bg41_before_loading'),('after','ch2_loading')]:
            name=side+'-'+quality;folder=out/name;folder.mkdir();env=os.environ.copy()
            for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
            command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg41-current/loading/safe-'+side+'.tscn','--','--out='+str(folder),'--level='+level,'--tag=tour','--quality='+quality,'--cells=2:3,3:3','--player','--fixed-aim']
            with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
            raw=(folder/'raw.log').read_bytes();report=json.loads((folder/level/'tour-index.json').read_text())
            row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'shots':report['shots']}
            runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
            print(json.dumps({'name':name,'exit':r.returncode,'source_held':row['source_held'],'enemy_contrast':[s.get('enemy_contrast',[]) for s in report['shots']],'regions_disjoint':[s['player_enemy_regions_disjoint'] for s in report['shots']]}),flush=True)
            assert r.returncode==row['script_errors']==0 and not row['engine_error'] and row['source_held']
            assert all(s['player_enemy_regions_disjoint'] for s in report['shots'])
finally:
    (out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
