from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg41-current')
out=base/'cargo-lamp';out.mkdir(exist_ok=False);private=root/'work/bg41-current/loading'
layout=json.loads((root/'data/levels/ch2_loading_map.json').read_text());row=layout['segments'][1][31];assert row[20]=='.'
layout['segments'][1][31]=row[:20]+'*'+row[21:]
(private/'cargo-map.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
level=(root/'data/levels/ch2_loading.tres').read_text().replace('res://data/levels/ch2_loading_map.json','res://work/bg41-current/loading/cargo-map.json')
(private/'cargo-level.tres').write_text(level,encoding='utf-8',newline='\n')
tour=(root/'tools/scene_tour.gd').read_bytes();needle=b'var path := "res://data/levels/%s.tres" % level_id';assert tour.count(needle)==1
(private/'cargo-tour.gd').write_bytes(tour.replace(needle,b'var path := "res://work/bg41-current/loading/cargo-level.tres"'))
(private/'cargo-phase.gd').write_bytes((root/'tools/readability_phase_probe.gd').read_bytes().replace(b'extends "res://tools/scene_tour.gd"',b'extends "res://work/bg41-current/loading/cargo-tour.gd"',1))
observer=(private/'stationary-after.gd').read_text().replace('extends "res://tools/readability_phase_probe.gd"','extends "res://work/bg41-current/loading/cargo-phase.gd"',1)
(private/'cargo-observer.gd').write_text(observer,encoding='utf-8',newline='\n')
(private/'cargo-observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/loading/cargo-observer.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
paths=json.loads((base/'stationary-control/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths;runs=[]
try:
    for quality in ['low','high']:
        folder=out/quality;folder.mkdir();env=os.environ.copy()
        for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg41-current/loading/cargo-observer.tscn','--','--out='+str(folder),'--level=ch2_loading','--tag=lamp','--quality='+quality,'--cells=3:3','--player','--fixed-aim']
        with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
        raw=(folder/'raw.log').read_bytes();report=json.loads((folder/'ch2_loading/lamp-index.json').read_text());shot=report['shots'][0]
        row={'quality':quality,'command':command,'exit':r.returncode,'source_held':before==snapshot(),'player':shot['player_contrast'],'edge':shot['edge_contrast'],'enemy_contrast':shot.get('enemy_contrast',[]),'lamps':shot['lamps']}
        runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k not in ['command','lamps']}),flush=True)
        assert r.returncode==0 and b'ERROR:' not in raw and row['source_held'] and len(row['enemy_contrast'])==2
finally:
    (out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
