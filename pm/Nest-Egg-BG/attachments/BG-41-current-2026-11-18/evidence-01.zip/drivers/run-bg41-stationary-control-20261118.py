from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg41-current');out=base/'stationary-control';out.mkdir(exist_ok=False)
paths=json.loads((base/'native/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert [p for p in paths if paths[p]!=before[p]]==['tools/scene_tour.gd']
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
try:
    for quality in ['low','high']:
        for side,level in [('before','bg41_before_loading'),('after','ch2_loading')]:
            name=side+'-'+quality;folder=out/name;folder.mkdir();env=os.environ.copy()
            for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
            command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg41-current/loading/stationary-'+side+'.tscn','--','--out='+str(folder),'--level='+level,'--tag=tour','--quality='+quality,'--cells=2:3,3:3','--player','--fixed-aim']
            if name=='after-high':command.append('--preexisting-culling-disabled')
            with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
            raw=(folder/'raw.log').read_bytes();report=json.loads((folder/level/'tour-index.json').read_text())
            row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'shots':report['shots'],'freeze':[json.loads(line.split(b'BG41_FREEZE ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG41_FREEZE ')],'restore':[json.loads(line.split(b'BG41_CULLING_RESTORE ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG41_CULLING_RESTORE ')]}
            runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
            print(json.dumps({'name':name,'exit':r.returncode,'source_held':row['source_held'],'enemy_contrast':[s.get('enemy_contrast',[]) for s in report['shots']],'held':[s['held'] for s in row['freeze']],'restore':row['restore']}),flush=True)
            assert r.returncode==row['script_errors']==0 and not row['engine_error'] and row['source_held']
            assert len(row['freeze'])==2 and all(f['held'] and not f['culling'] and len(f['before'])==5 and all(a['mode']==4 and not a['can_process'] and a['enablers']==0 for a in f['before']) for f in row['freeze'])
            assert len(row['restore'])==1 and row['restore'][0]['restored']
finally:
    (out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
