from pathlib import Path
root=Path('D:/NestEggVerification/ne218-baseline-20261117')
for ident in ['loading','market']:
    folder=root/('work/bg41-current/'+ident)
    tour=(root/'tools/scene_tour.gd').read_bytes();needle=b'var path := "res://data/levels/%s.tres" % level_id';assert tour.count(needle)==1
    (folder/'stationary-before-tour.gd').write_bytes(tour.replace(needle,('var path := "res://work/bg41-current/'+ident+'/before-level.tres"').encode()))
    (folder/'stationary-before-phase.gd').write_bytes((root/'tools/readability_phase_probe.gd').read_bytes().replace(b'extends "res://tools/scene_tour.gd"',('extends "res://work/bg41-current/'+ident+'/stationary-before-tour.gd"').encode(),1))
    for side,parent in [('before','res://work/bg41-current/'+ident+'/stationary-before-phase.gd'),('after','res://tools/readability_phase_probe.gd')]:
        original=(folder/(side+'-observer.gd')).read_text();body=original.split('\n',1)[1]
        needle='    return await super._frame_interval_ms()'
        assert body.count(needle)==1
        body=body.replace(needle,'''    var before := _actors()
    var result := await super._frame_interval_ms()
    var after := _actors()
    print("BG41_FREEZE ",JSON.stringify({"before":before,"after":after,"held":before==after,"culling":Enemy.activation_culling_enabled}))
    return result''')
        prefix='''var _expected_culling := true
func _ready() -> void:
    if OS.get_cmdline_user_args().has("--preexisting-culling-disabled"):
        Enemy.activation_culling_enabled = false
    _expected_culling = Enemy.activation_culling_enabled
    super._ready()
func _actors() -> Array[Dictionary]:
    var result: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(&"enemies"):
        result.append({"instance":node.get_instance_id(),"data":str(node.data.id),"world":[node.global_position.x,node.global_position.y],"mode":node.process_mode,"can_process":node.can_process(),"enablers":node.find_children("*","VisibleOnScreenEnabler2D",true,false).size()})
    return result
func _exit_tree() -> void:
    print("BG41_CULLING_RESTORE ",JSON.stringify({"expected":_expected_culling,"actual":Enemy.activation_culling_enabled,"restored":_expected_culling==Enemy.activation_culling_enabled}))
    super._exit_tree()
'''
        source='extends "'+parent+'"\n'+prefix+body
        (folder/('stationary-'+side+'.gd')).write_text(source,encoding='utf-8',newline='\n')
        (folder/('stationary-'+side+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/'+ident+'/stationary-'+side+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
print('Stationary baseline copies regenerated from candidate; old rejected probe code retained.')
