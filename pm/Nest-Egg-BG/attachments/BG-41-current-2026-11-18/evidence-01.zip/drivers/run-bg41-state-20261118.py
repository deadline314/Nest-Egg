from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg41-current');out=base/'states-v3';out.mkdir(exist_ok=False)
private=root/'work/bg41-current';source=(primary/'work/bg41-state-20261118.gd').read_bytes();(private/'state.gd').write_bytes(source)
(private/'state.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/state.gd" id="1"]\n[node name="StateProbe" type="Node"]\nscript=ExtResource("1")\n')
paths=json.loads((base/'fill-green/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths;passed=False;runs=[]
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
try:
    for quality in ['low','high']:
        folder=out/quality;folder.mkdir();env=os.environ.copy()
        for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg41-current/state.tscn','--','--out='+str(folder),'--quality='+quality]
        with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
        raw=(folder/'raw.log').read_bytes();row={'quality':quality,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot()};runs.append(row);print(json.dumps(row),flush=True)
        (out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
        assert r.returncode==0 and not row['script_errors'] and not row['engine_error'] and row['source_held']
        states=json.loads((folder/'states.json').read_text());assert len(states['rows'])==7 and len(list(folder.glob('*.png')))==7
        assert all(s['quality']==(0 if quality=='low' else 2) for s in states['rows'])
        assert states['actual_lever_talk'] and len(states['routes'])==2
    passed=True
finally:
    after=snapshot();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'result.json').write_text(json.dumps({'passed':passed,'source_held':before==after,'completed_producers':len(runs)},indent=2)+'\n')
