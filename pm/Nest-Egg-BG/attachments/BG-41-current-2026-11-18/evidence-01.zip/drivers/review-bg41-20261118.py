from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json
base=Path('D:/NestEggVerification/evidence-20261117/bg41-current');out=base/'review';out.mkdir(exist_ok=True)
font=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc',14)
for ident in ['loading','market']:
    for quality in ['low','high']:
        for mode in ['normal','flat']:
            sheet=Image.new('RGB',(1280,896),'#101722');draw=ImageDraw.Draw(sheet)
            draw.text((10,5),f'{ident} / {quality} / {mode} | each row: historical props BEFORE, current AFTER | native 640x360 thumbnails 160x90',font=font,fill='white')
            for r in range(4):
                for si,side in enumerate(['before','after']):
                    folder=base/'formal-v2'/f'{ident}-{side}-{quality}-{mode}'/('bg41_before_'+ident if side=='before' else 'ch2_'+ident)
                    report=json.loads((folder/'tour-index.json').read_text())
                    for c in range(8):
                        shot=next(s for s in report['shots'] if s['column']==c and s['row']==r)
                        image=Image.open(folder/shot['file']).convert('RGB');assert image.size==(640,360)
                        x=c*160;y=32+(r*2+si)*108
                        sheet.paste(image.resize((160,90)),(x,y));draw.text((x+3,y+90),f'{side} c{c} r{r}',font=font,fill='white')
            sheet.save(out/f'{ident}-{quality}-{mode}.png')
def pages(phase,subdirs):
    for subdir in subdirs:
        folder=base/phase/subdir
        if not (folder/'readability-report.json').exists():continue
        report=json.loads((folder/'readability-report.json').read_text());rows=report['results']
        for start in range(0,len(rows),6):
            sheet=Image.new('RGB',(1280,640),'#101722');draw=ImageDraw.Draw(sheet)
            for i,row in enumerate(rows[start:start+6]):
                matches=list(folder.glob('*-'+row['level']+'-'+str(row['column'])+'.png'))
                assert len(matches)==1,(phase,subdir,row['spot'],[p.name for p in folder.glob('*.png')])
                im=Image.open(matches[0]);assert im.size==(640,360)
                x=(i%2)*640;y=(i//2)*212
                sheet.paste(im.resize((376,212)),(x,y))
                text=f"{phase}/{subdir}\n{row['level']}/{row['spot']}\nplayer {row['player_contrast']:.4f}\nedge {row['edge_contrast']:.4f}\nenemy {row['enemy_contrast']}\npass {row['passed']}"
                draw.multiline_text((x+378,y+5),text,font=font,fill='white')
            sheet.save(out/f'{phase}-{subdir}-{start//6+1:02}.png')
pages('fixtures-v2',['before-low','after-low','before-high','after-high'])
pages('shared-regression',[p.name for p in (base/'shared-regression').iterdir() if p.is_dir()])
pages('shared-seeded',[p.name for p in (base/'shared-seeded').iterdir() if p.is_dir()])
states=base/'states-v3'
for quality in ['low','high']:
    if not (states/quality/'states.json').exists():continue
    sheet=Image.new('RGB',(1280,800),'#101722');draw=ImageDraw.Draw(sheet)
    for i,p in enumerate(sorted((states/quality).glob('*.png'))):
        x=(i%3)*426;y=(i//3)*266
        sheet.paste(Image.open(p).resize((426,240)),(x,y));draw.text((x+4,y+242),quality+' / '+p.stem,font=font,fill='white')
    sheet.save(out/f'states-{quality}.png')
for quality in ['low','high']:
    sheet=Image.new('RGB',(1280,390),'#101722');draw=ImageDraw.Draw(sheet)
    for i,name in enumerate(['guard-context','guard-wall-flat']):
        sheet.paste(Image.open(base/'guard-wall'/quality/(name+'.png')),(i*640,0))
        draw.text((i*640+5,362),quality+' / '+name,font=font,fill='white')
    sheet.save(out/f'guard-wall-{quality}.png')
print(json.dumps({'pages':[p.name for p in sorted(out.glob('*.png'))]}))
