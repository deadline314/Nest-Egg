from pathlib import Path
import hashlib,json
root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg41-current')
assert json.loads((base/'fill-green/result.json').read_text())['exit']==0
assert b'enemy_fill_scale = 0.6' in (root/'work/bg41-current/market-before.tres').read_bytes()
for ident in ['loading','market']:
    folder=root/('work/bg41-current/'+ident)
    data=(folder/'before-level.tres').read_text();needle='res://data/lighting/market.tres';assert data.count(needle)==1
    (folder/'formal-before-level.tres').write_text(data.replace(needle,'res://work/bg41-current/market-before.tres'),encoding='utf-8',newline='\n')
    tour=(root/'tools/scene_tour.gd').read_bytes();needle=b'var path := "res://data/levels/%s.tres" % level_id';assert tour.count(needle)==1
    (folder/'formal-before-tour.gd').write_bytes(tour.replace(needle,('var path := "res://work/bg41-current/'+ident+'/formal-before-level.tres"').encode()))
    (folder/'formal-before-phase.gd').write_bytes((root/'tools/readability_phase_probe.gd').read_bytes().replace(b'extends "res://tools/scene_tour.gd"',('extends "res://work/bg41-current/'+ident+'/formal-before-tour.gd"').encode(),1))
    for side,parent in [('before','res://work/bg41-current/'+ident+'/formal-before-phase.gd'),('after','res://tools/readability_phase_probe.gd')]:
        source=(folder/('stationary-'+side+'.gd')).read_text().split('\n',1)[1]
        source='extends "'+parent+'"\n'+source+'''
func _measure(level: Level, world: Rect2) -> Dictionary:
    var result := await super._measure(level,world)
    result["enemy_fill_scale"] = level._lighting.current.enemy_fill_scale
    result["character_fill"] = LightKit.character_fill
    result["enemy_fill"] = LightKit.enemy_fill
    result["enemy_light_cap"] = LightKit.enemy_light_cap
    return result
'''
        (folder/('formal-'+side+'.gd')).write_text(source,encoding='utf-8',newline='\n')
        (folder/('formal-'+side+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/'+ident+'/formal-'+side+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
private=root/'work/bg41-current'
for side in ['before','after']:
    entries=[]
    for ident,spots,enemy in [('market',[["代收處",28,36],["租攤視窗",53,36],["公告屏",90,36],["雨棚上層",60,24]],''),
        ('loading',[["橋梯拉桿",92,29],["橋梯入口",100,36],["代收簿",112,36],["乾燥作業桌",128,36]],''),
        ('loading',[["票據投手30",24,36,30],["票據投手78",72,36,78]],'ch2_bill_thrower'),
        ('loading',[["押運手41",35,36,41],["押運手62",56,36,62],["押運手71",65,36,71]],'ch2_escort')]:
        path='res://work/bg41-current/'+ident+'/formal-before-level.tres' if side=='before' else 'res://data/levels/ch2_'+ident+'.tres'
        entries.append({'path':path,'spots':spots,'enemy_path':'res://data/enemies/'+enemy+'.tres' if enemy else ''})
    # Existing fixture engine handles real floor validation, separate actors and 16 HDR samples.
    source='extends "res://tools/readability_check.gd"\nfunc targets() -> Array[Dictionary]:\n    var entries: Array[Dictionary] = '+json.dumps(entries,ensure_ascii=False)+'\n    return entries\n'
    (private/('fixture-'+side+'.gd')).write_text(source,encoding='utf-8',newline='\n')
    (private/('fixture-'+side+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/fixture-'+side+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
print('Formal baseline keeps published enemy gain0.6, current data1.2; original helper 13 valid spots includes all five authored real enemy data/positions. No cycle-min gate added to original median tours.')
