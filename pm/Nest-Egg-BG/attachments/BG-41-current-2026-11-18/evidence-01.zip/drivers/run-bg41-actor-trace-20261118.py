from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg41-current')
out=base/'actor-trace';out.mkdir(exist_ok=False);private=root/'work/bg41-current/loading'
(private/'actor-trace.gd').write_text('''extends "res://work/bg41-current/loading/safe-before.gd"
func _trace(label: String) -> void:
    var actors: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(&"enemies"):
        actors.append({"instance":node.get_instance_id(),"data":str(node.data.id),"mode":node.process_mode,"can_process":node.can_process(),"parent":str(node.get_parent().name),"world":[node.global_position.x,node.global_position.y],"state":str(node.fsm.current),"velocity":[node.velocity.x,node.velocity.y]})
    print("BG41_ACTOR ",JSON.stringify({"label":label,"frame":Engine.get_physics_frames(),"actors":actors}))
func _frame_interval_ms() -> float:
    _trace("before_benchmark")
    var result := await super._frame_interval_ms()
    _trace("after_benchmark")
    return result
''',encoding='utf-8',newline='\n')
(private/'actor-trace.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/loading/actor-trace.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
paths=json.loads((base/'native/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths
env=os.environ.copy()
for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(out/'private-profile'/k)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg41-current/loading/actor-trace.tscn','--','--out='+str(out),'--level=bg41_before_loading','--tag=trace','--quality=low','--cells=2:3,3:3','--player','--fixed-aim']
with (out/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
raw=(out/'raw.log').read_bytes();observations=[json.loads(line.split(b'BG41_ACTOR ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG41_ACTOR ')]
(out/'result.json').write_text(json.dumps({'exit':r.returncode,'source_held':before==snapshot(),'observations':observations,'command':command},indent=2)+'\n')
print(json.dumps({'exit':r.returncode,'source_held':before==snapshot(),'observations':observations},indent=2),flush=True)
assert r.returncode==0 and b'ERROR:' not in raw and before==snapshot()
