from pathlib import Path
import hashlib,json,math,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg41-current');out=base/'native';out.mkdir(exist_ok=False)
private=root/'work/bg41-current'
paths=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg39-current/checks-final/source-after.json').read_text())
private_paths=[p for p in private.rglob('*') if p.is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
def private_snapshot():return {p.relative_to(private).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in private_paths}
before=snapshot();private_before=private_snapshot();assert before==paths
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');(out/'private-before.json').write_text(json.dumps(private_before,indent=2)+'\n')
runs=[];comparisons=[];passed=False
try:
    for ident in ['loading','market']:
        level='ch2_'+ident
        for flat in [False,True]:
            for quality in ['low','high']:
                reports=[]
                for side in ['before','after']:
                    tag=ident+'-'+side+'-'+quality+('-flat' if flat else '-normal');folder=out/tag;folder.mkdir()
                    level_arg='bg41_before_'+ident if side=='before' else level
                    env=os.environ.copy()
                    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
                    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg41-current/'+ident+'/'+side+'-observer.tscn','--','--out='+str(folder),'--level='+level_arg,'--tag=tour','--quality='+quality]
                    if flat:command.append('--flat')
                    else:command.extend(['--player','--fixed-aim','--cycle-samples=16'])
                    with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
                    raw=(folder/'raw.log').read_bytes();index=json.loads((folder/level_arg/'tour-index.json').read_text());reports.append(index)
                    observations=[json.loads(line.split(b'BG41_ENV ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG41_ENV ')]
                    row={'name':tag,'level_arg':level_arg,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'private_held':private_before==private_snapshot(),'shots':len(index['shots']),'observations':observations}
                    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
                    print(json.dumps({k:v for k,v in row.items() if k not in ['command','observations']}),flush=True)
                    assert row['script_errors']==0 and not row['engine_error'] and row['source_held'] and row['private_held']
                    assert row['shots']==index['columns']*index['rows']==len(observations)
                    assert all(o['environment'] and o['glow'] and o['hdr'] and o['count']==1 and o['quality']==(0 if quality=='low' else 2) and o['size']==[640,360] for o in observations)
                    assert r.returncode==0 if side=='after' or flat else r.returncode in [0,1]
                a,b=reports
                assert len(a['shots'])==len(b['shots'])
                for left,right in zip(a['shots'],b['shots']):
                    assert left['world']==right['world'] and left.get('player_world')==right.get('player_world')
                if flat:continue
                points=[]
                for left,right in zip(a['shots'],b['shots']):
                    if 'player_contrast' not in left:assert 'player_contrast' not in right;continue
                    assert left['fog_clock']==right['fog_clock'] and left['lamps']==right['lamps']
                    assert right['passed'] and right['cycle_passed'] and right['player_contrast']>=.6 and right['edge_contrast']>=1
                    assert len(left['cycle_samples_raw'])==len(right['cycle_samples_raw'])==16
                    points.append({'cell':[left['column'],left['row']],**{key:[left[key],right[key]] for key in ['player_contrast','edge_contrast','cycle_player_min','cycle_edge_min']}})
                assert points
                minima={key:[min(p[key][0] for p in points),min(p[key][1] for p in points)] for key in ['player_contrast','edge_contrast','cycle_player_min','cycle_edge_min']}
                enemies=[[v for s in report['shots'] for v in s.get('enemy_contrast',[])] for report in reports]
                assert all(enemies) and min(enemies[1])>=.45
                minima['enemy_contrast']=[min(values) for values in enemies]
                result={'level':level,'quality':quality,'points':points,'minima':minima,'passed':all(math.isfinite(x) and math.isfinite(y) and y>=x for x,y in minima.values())}
                comparisons.append(result);(out/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n')
                print(json.dumps({k:v for k,v in result.items() if k!='points'}),flush=True)
                assert result['passed'],(level,quality,minima)
    passed=True
finally:
    after=snapshot();private_after=private_snapshot()
    (out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'private-after.json').write_text(json.dumps(private_after,indent=2)+'\n')
    (out/'result.json').write_text(json.dumps({'passed':passed,'source_held':before==after,'private_held':private_before==private_after,'completed_producers':len(runs)},indent=2)+'\n')
