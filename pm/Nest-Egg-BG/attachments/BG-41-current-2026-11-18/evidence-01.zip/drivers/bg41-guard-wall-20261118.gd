extends "res://work/bg41-current/state.gd"
func _run() -> void:
    add_child(LightKit.create_environment())
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--quality="): Settings.set_light_quality(0 if arg.ends_with("low") else 2)
    Story.auto_skip = true
    Enemy.activation_culling_enabled = false
    GameState.start_new_run(GameState.difficulties[1])
    var level := await make_level("ch2_loading")
    var guard := await check_npc(level,&"ch2_guard","guard-context")
    var area := Rect2(guard.global_position+Vector2(-12,-56),Vector2(24,56))
    var supported := level._scenery_walls.covers(area)
    assert(supported, "Rendered back wall must cover the future guard's 24x56 support area")
    level._lighting.process_mode = Node.PROCESS_MODE_DISABLED
    level._lighting._modulate.color = Color.WHITE
    level._background.modulate = Color.WHITE
    level._post.visible = false
    await settle(10)
    await shot(level,"guard-wall-flat",{"wall_covers":supported,"support_area":[area.position.x,area.position.y,area.size.x,area.size.y],"npc_kind":guard.data.kind,"rig":guard.data.rig_id})
    var writer := FileAccess.open(_out.path_join("states.json"),FileAccess.WRITE)
    assert(writer!=null)
    writer.store_string(JSON.stringify({"rows":_rows,"wall_supported":supported,"scope":"Rendered existing back wall only; future guard still authored OBJECT placeholder with empty rig. No leaning character delivered by BG41."},"  ")+"\n")
    writer.close()
    level.queue_free()
    await settle(3)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0)
