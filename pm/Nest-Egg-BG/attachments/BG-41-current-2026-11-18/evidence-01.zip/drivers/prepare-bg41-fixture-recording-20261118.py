from pathlib import Path
root=Path('D:/NestEggVerification/ne218-baseline-20261117');private=root/'work/bg41-current'
record='''var _sample_records: Array[Dictionary] = []
func _record_probe_sample(_probe: ContrastProbe, level: Level, spot: Array, sample: int, foe: Enemy, sums: Array[float]) -> void:
    _sample_records.append({"level":str(level.data.id),"spot":str(spot[0]),"sample":sample,"sums":sums.duplicate(),"enemy":str(foe.data.id) if is_instance_valid(foe) else "","enemy_feet":[foe.global_position.x,foe.global_position.y] if is_instance_valid(foe) else [],"enemy_fill_scale":level._lighting.current.enemy_fill_scale,"character_fill":LightKit.character_fill,"enemy_fill":LightKit.enemy_fill,"enemy_light_cap":LightKit.enemy_light_cap})
func _exit_tree() -> void:
    var path := _out_dir.path_join("frame-samples.json")
    var writer := FileAccess.open(path,FileAccess.WRITE)
    if writer==null:
        push_error("[BG41] Cannot save fixture observations: %s (%s)" % [path,FileAccess.get_open_error()])
    else:
        writer.store_string(JSON.stringify(_sample_records,"  ")+"\\n")
'''
for side in ['before','after']:
    source='extends "res://work/bg41-current/fixture-'+side+'.gd"\n'+record
    (private/('fixture-record-'+side+'.gd')).write_text(source,encoding='utf-8',newline='\n')
    (private/('fixture-record-'+side+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/fixture-record-'+side+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
for name,parent in [('legacy','readability_check'),('ch1','ch1_readability_check'),('ch3','ch3_readability_check')]:
    for side in ['before','after']:
        source='extends "res://tools/'+parent+'.gd"\n'+record
        if side=='before':source+='''var _market_reference: LightingProfile
func _ready() -> void:
    _market_reference = load("res://data/lighting/market.tres") as LightingProfile
    _market_reference.enemy_fill_scale = 0.6
    super._ready()
'''
        (private/('shared-'+name+'-'+side+'.gd')).write_text(source,encoding='utf-8',newline='\n')
        (private/('shared-'+name+'-'+side+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg41-current/shared-'+name+'-'+side+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
print('Read-only sample hooks prepared for original fixture engine and all three other market-profile consumers; no pixels/formulas/timing changed.')
