from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg41-current')
out=base/'fixtures-v2';out.mkdir(exist_ok=False)
paths=json.loads((base/'fill-green/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths;runs=[];passed=False
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
try:
    for quality in ['low','high']:
        for side in ['before','after']:
            name=side+'-'+quality;folder=out/name;folder.mkdir();env=os.environ.copy()
            for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
            command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg41-current/fixture-record-'+side+'.tscn','--','--out='+str(folder),'--quality='+quality,'--detail']
            with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
            raw=(folder/'raw.log').read_bytes();report=json.loads((folder/'readability-report.json').read_text());samples=json.loads((folder/'frame-samples.json').read_text())
            row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'spots':len(report['results']),'samples':len(samples),'all_passed':all(s['passed'] for s in report['results'])}
            runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
            assert row['script_errors']==0 and not row['engine_error'] and row['source_held'] and row['spots']==13 and row['samples']==208
            assert r.returncode==0 if side=='after' else r.returncode in [0,1]
            assert report['light_quality']==(0 if quality=='low' else 2) and report['thresholds']=={'player':.6,'edge':1.,'enemy':.45}
            assert all(s['sampling_valid'] for s in report['results'])
            for spot in report['results']:
                records=[s for s in samples if s['level']==spot['level'] and s['spot']==spot['spot']]
                assert [s['sample'] for s in records]==list(range(16))
                assert all((records[-1]['sums'][i]==0 if spot[key] is None else abs(records[-1]['sums'][i]-spot[key])<1e-8) for i,key in enumerate(['player_contrast','edge_contrast','enemy_contrast']))
                if spot['enemy']:
                    assert records[0]['enemy'] in ['ch2_bill_thrower','ch2_escort']
                    assert all(abs(s['enemy_fill_scale']-(.6 if side=='before' else 1.2))<1e-6 for s in records)
                if side=='after':assert spot['passed']
    comparisons=[]
    for quality in ['low','high']:
        a=json.loads((out/('before-'+quality)/'readability-report.json').read_text())['results'];b=json.loads((out/('after-'+quality)/'readability-report.json').read_text())['results']
        for level in ['ch2_loading','ch2_market']:
            aa=[s for s in a if s['level']==level];bb=[s for s in b if s['level']==level];assert len(aa)==len(bb)
            for x,y in zip(aa,bb):assert x['spot']==y['spot'] and x['feet']==y['feet'] and x['expected_enemy_feet']==y['expected_enemy_feet']
            minima={}
            for key in ['player_contrast','edge_contrast']+(['enemy_contrast'] if level=='ch2_loading' else []):
                ar=[s for s in aa if key!='enemy_contrast' or s['enemy']];br=[s for s in bb if key!='enemy_contrast' or s['enemy']]
                minima[key]=[min(s[key] for s in ar),min(s[key] for s in br)]
            comparison={'quality':quality,'level':level,'minima':minima};comparisons.append(comparison);print(json.dumps(comparison),flush=True)
            assert all(y>=x for x,y in minima.values()),comparison
    (out/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n');passed=True
finally:
    after=snapshot();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'result.json').write_text(json.dumps({'passed':passed,'source_held':before==after,'completed_producers':len(runs)},indent=2)+'\n')
