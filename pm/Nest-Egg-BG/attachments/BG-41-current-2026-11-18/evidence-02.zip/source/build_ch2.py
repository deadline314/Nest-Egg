#!/usr/bin/env python3
"""第二章「鷺」的區域地圖產生器（ST-19）：輸出 data/levels/ch2_*.tres、ch2_*_map.json、環境主題與人物資料。

沿用第一章產生器的工具（區域格子、出入口、人物與主題的輸出、可通行檢查），只換章節前綴與本章的內容。
落地計畫見 design/13-story-v2/CH02_IMPLEMENTATION.md，劇本見 design/13-story-v2/SCRIPT_CH02.md。
敵人由戰鬥 Session 配置（NE-265、NE-266）：戰鬥區與成員都在 COMBAT_ZONES 一張表，整批調整只改這裡。
用法：python3 tools/level/build_ch2.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
sys.dont_write_bytecode = True
import build_ch1 as kit  # noqa: E402

kit.PREFIX = 'ch2'
kit.CHAPTER = 'ch2_heron'
AREA = kit.AREA
H = kit.H
Area = kit.Area

# ---------------------------------------------------------------------------
# 人物與可調查物件：字元 -> 資料檔（台詞由劇本的分派場景依進度挑選，見 tools/story/ch2_source.py）
# ---------------------------------------------------------------------------
NPC_CHARS = {
    'ⓞ': 'ch2_old_k', 'Ⓡ': 'ch2_radio', 'ⓔ': 'ch2_egret', 'Ⓖ': 'ch2_patroller', 'Ⓥ': 'ch2_vig', 'ⓐ': 'ch2_ali_market',
    'Ⓦ': 'ch2_rent_window', 'Ⓑ': 'ch2_banyan', 'Ⓝ': 'ch2_notice_screen', 'ⓗ': 'ch2_hawker', 'Ⓐ': 'ch2_ali_home',
    'ⓛ': 'ch2_collection_book', 'ⓧ': 'ch2_guard', 'ⓙ': 'ch2_sc1_lever', 'ⓓ': 'ch2_drying_desk', 'ⓘ': 'ch2_isolation_diagram',
    'ⓨ': 'ch2_ledger_door', 'ⓜ': 'ch2_ledger_cabinet', 'ⓟ': 'ch2_xiaowei', 'ⓣ': 'ch2_terminal', 'ⓢ': 'ch2_ali_lounge',
    'ⓠ': 'ch2_guest_entry',
    'Ⓔ': 'ch2_egret_booth',
}
# 人物（kind 0）有骨架外觀；物件（kind 1）只有互動提示。rig 用既有外觀；沒有專屬外觀的配角先借用，缺口列在 NE-267。
P, O = 0, 1
NPCS = {
    'ch2_old_k': dict(name='老 K', speaker='old_k', rig='old_k', loop='wipe_hands', facing=1, prompt='{interact} 和老 K 說話',
                      talks=[('ch2_dispatch_old_k', 0)]),
    'ch2_radio': dict(name='工作檯的收音機', speaker='label', kind=O, prompt='{interact} 看看工作檯的收音機', talks=[('ch2_dispatch_radio', 0)]),
    'ch2_egret': dict(name='鷺', speaker='egret', rig='egret', pose='lean', loop='yawn', facing=-1, prompt='{interact} 和鷺說話',
                      talks=[('ch2_dispatch_egret', 0)]),
    'ch2_patroller': dict(name='巡帳員', speaker='patroller', rig='ch2_patroller', loop='glance', facing=-1, prompt='{interact} 出示查核證',
                          talks=[('ch2_dispatch_patroller', 0)]),
    'ch2_vig': dict(name='利息', speaker='vig', rig='vig', loop='tablet', facing=-1, prompt='{interact} 和利息說話',
                    talks=[('ch2_dispatch_vig', 0)]),
    'ch2_ali_market': dict(name='阿梨', speaker='ali', rig='ali', loop='read_note', facing=1, prompt='{interact} 和阿梨說話',
                           talks=[('ch2_dispatch_ali_market', 0)], spawn_unless_flag='ch2_audit_submitted'),
    'ch2_rent_window': dict(name='租攤視窗', speaker='window_clerk', kind=O, prompt='{interact} 到租攤視窗查合約', talks=[('ch2_dispatch_rent_window', 0)]),
    'ch2_banyan': dict(name='榕伯', speaker='banyan', rig='banyan', loop='stir', facing=1, prompt='{interact} 和榕伯說話',
                       talks=[('ch2_dispatch_banyan', 0)]),
    'ch2_notice_screen': dict(name='公告屏', speaker='label', kind=O, prompt='{interact} 看公告屏', talks=[('ch2_dispatch_notice', 0)]),
    'ch2_hawker': dict(name='小販', speaker='hawker', rig='ch2_hawker', loop='sort_gear', facing=-1, prompt='{interact} 和小販說話',
                       talks=[('ch2_dispatch_hawker', 0)]),
    'ch2_ali_home': dict(name='阿梨', speaker='ali', rig='ali', loop='stir', facing=-1, prompt='{interact} 敲門找阿梨',
                         talks=[('ch2_dispatch_ali_home', 0)]),
    'ch2_collection_book': dict(name='代收簿', speaker='label', kind=O, prompt='{interact} 翻裝卸間的代收簿', talks=[('ch2_dispatch_collection_book', 0)]),
    'ch2_guard': dict(name='倚著牆的守衛', speaker='label', kind=O, prompt='{interact} 查看倚著牆的守衛', talks=[('ch2_dispatch_guard', 0)]),
    'ch2_sc1_lever': dict(name='橋梯拉桿', speaker='label', kind=O, prompt='{interact} 放下通往代收處的橋梯', talks=[('ch2_dispatch_sc1', 0)]),
    'ch2_drying_desk': dict(name='乾燥作業桌', speaker='label', kind=O, prompt='{interact} 在作業桌上對帳', talks=[('ch2_dispatch_reconcile', 0)]),
    'ch2_isolation_diagram': dict(name='隔離箱示意圖', speaker='label', kind=O, prompt='{interact} 看隔離箱示意圖', talks=[('ch2_dispatch_diagram', 0)]),
    'ch2_ledger_door': dict(name='帳房的門', speaker='label', kind=O, prompt='{interact} 進帳房找阿勇', talks=[('ch2_dispatch_ledger_door', 0)]),
    'ch2_ledger_cabinet': dict(name='帳櫃', speaker='label', kind=O, prompt='{interact} 打開帳櫃', talks=[('ch2_dispatch_cabinet', 0)]),
    'ch2_xiaowei': dict(name='小薇', speaker='xiaowei', rig='xiaowei', loop='glance', facing=1, prompt='{interact} 和小薇說話',
                        talks=[('ch2_dispatch_xiaowei', 0)], spawn_unless_flag='ch2_yong_subdued'),
    'ch2_terminal': dict(name='公用委託終端', speaker='terminal', kind=O, prompt='{interact} 在委託終端上傳證據', talks=[('ch2_dispatch_terminal', 0)]),
    'ch2_ali_lounge': dict(name='阿梨', speaker='ali', rig='ali', loop='wipe_hands', facing=-1, prompt='{interact} 和阿梨說話',
                           talks=[('ch2_dispatch_ali_lounge', 0)], spawn_requires_flag='ch2_audit_submitted'),
    'ch2_guest_entry': dict(name='客人簿', speaker='label', kind=O, prompt='{interact} 看阿梨今晚的工作', talks=[('ch2_dispatch_guest_entry', 0)],
                            spawn_requires_flag='ch2_audit_submitted'),
    'ch2_egret_booth': dict(name='鷺', speaker='egret', rig='egret', loop='yawn', facing=-1, prompt='{interact} 和鷺說話',
                            talks=[('ch2_dispatch_egret_booth', 0)], spawn_requires_flag='ch2_egret_transport_done', spawn_unless_flag='ch2_audit_submitted'),
}

# ---------------------------------------------------------------------------
# 出入口：字元 -> 設定（欄位同第一章）。目標區域留空＝鎖死的門。
# ---------------------------------------------------------------------------
PORTALS = {
    # 當舖（早上）
    'F': dict(id='pawn_front', to=AREA('harbor_street'), target='street_home', mode=0, prompt='{interact} 出門', style='door',
              requires='ch2_brief_done', locked='先上屋頂，鷺在茶座等你拿查核證。'),
    'S': dict(id='pawn_stairs', to=AREA('rooftop'), target='roof_stairs', mode=0, prompt='{interact} 上屋頂', style='ladder', w=20, h=152,
              requires='ch2_morning_settled', locked='先和老 K 把昨晚的報酬對完。'),
    'K': dict(id='pawn_basement', to='', target='', mode=0, prompt='{interact} 地下室', locked='地下室的門鎖著，老 K 說裡面在漏水。', style='hidden', w=32, h=48),
    # 屋頂
    'T': dict(id='roof_stairs', to=AREA('pawnshop'), target='pawn_stairs', mode=0, prompt='{interact} 下樓', style='hidden', w=24, h=44),
    # 港區街道（安全街段）
    'h': dict(id='street_home', to=AREA('pawnshop'), target='pawn_front', mode=0, prompt='{interact} 回當舖', style='door'),
    'm': dict(id='street_market', to=AREA('market_gate'), target='gate_street', mode=0, prompt='{interact} 往市集', style='road', w=28, h=44),
    # 市集入口
    'Ⅰ': dict(id='gate_street', to=AREA('harbor_street'), target='street_market', mode=0, prompt='{interact} 回港區街道', style='road', w=28, h=44),
    'Ⅱ': dict(id='gate_market', to=AREA('market'), target='market_gate', mode=0, prompt='{interact} 進公眾攤道', style='road', w=28, h=44,
              requires='ch2_brief_done', locked='公眾攤道要查核證，鷺在當舖屋頂等你。'),
    'Ⅲ': dict(id='gate_lounge', to=AREA('lounge_front'), target='lounge_gate', mode=0, prompt='{interact} 往復原館', style='road', w=28, h=44),
    'Ⅳ': dict(id='gate_family', to=AREA('ledger_office'), target='office_family', mode=0, prompt='{interact} 走家屬出口回帳房', style='door', w=28, h=56,
              requires='ch2_egret_transport_done', locked='家屬出口從帳房那一側鎖著。'),
    # 公眾攤道與代收處
    'Ⅴ': dict(id='market_gate', to=AREA('market_gate'), target='gate_market', mode=0, prompt='{interact} 回市集入口', style='road', w=28, h=44),
    'Ⅵ': dict(id='market_stairs', to=AREA('ali_home'), target='home_stairs', mode=0, prompt='{interact} 走後樓外梯', style='door'),
    'Ⅶ': dict(id='market_cargo', to=AREA('loading'), target='loading_market', mode=0, prompt='{interact} 往雨棚背面的貨道', style='road', w=28, h=44,
              requires='ch2_market_contact_done', locked='先到代收處問清楚這筆代收款，再去後面查帳。'),
    'Ⅷ': dict(id='market_sc1', to=AREA('loading'), target='loading_sc1', mode=0, prompt='{interact} 走橋梯捷徑到裝卸間', style='door',
              requires='ch2_sc1_open', locked='橋梯收在上面，要從裝卸間那一側放下來。'),
    # 阿梨的小廚房
    'Ⅸ': dict(id='home_stairs', to=AREA('market'), target='market_stairs', mode=0, prompt='{interact} 下後樓外梯', style='door', w=24, h=56),
    # 雨棚背面與裝卸間
    'Ⅹ': dict(id='loading_market', to=AREA('market'), target='market_cargo', mode=0, prompt='{interact} 回公眾攤道', style='road', w=28, h=44),
    'Ⅺ': dict(id='loading_sc1', to=AREA('market'), target='market_sc1', mode=0, prompt='{interact} 走橋梯回代收處', style='hidden', w=32, h=56,
              requires='ch2_sc1_open', locked='橋梯還收著，旁邊的拉桿可以放下來。'),
    'Ⅻ': dict(id='loading_ledger', to=AREA('ledger_front'), target='front_loading', mode=0, prompt='{interact} 進北棟貨門', style='door', w=28, h=56,
              requires='ch2_market_reconciled', locked='貨門要核對過的卸貨批號，先在作業桌把三張紙對完。'),
    # 帳房前室
    'ⅰ': dict(id='front_loading', to=AREA('loading'), target='loading_ledger', mode=0, prompt='{interact} 回裝卸間', style='door', w=28, h=56),
    'ⅱ': dict(id='front_office', to=AREA('ledger_office'), target='office_front', mode=0, prompt='{interact} 進二樓帳房', style='door', w=28, h=56,
              requires='ch2_yong_intro_seen', locked='先敲門，看阿勇要怎麼對這筆帳。'),
    # 二樓帳房
    'ⅲ': dict(id='office_front', to=AREA('ledger_front'), target='front_office', mode=0, prompt='{interact} 回前室', style='door', w=28, h=56),
    'ⅳ': dict(id='office_family', to=AREA('market_gate'), target='gate_family', mode=0, prompt='{interact} 走家屬出口到市集電話亭', style='door', w=28, h=56,
              requires='ch2_egret_transport_done', locked='先撐開家屬出口，讓人把鷺抬出去。'),
    # 阿梨小廚房的後窗（NE-299）：和公眾攤道雨棚上層的「market_roof」互通
    '⇥': dict(id='home_roof', to=AREA('market'), target='market_roof', mode=0, prompt='{interact} 從後窗爬到雨棚上', style='door', w=24, h=44),
    # 復原館外
    'ⅴ': dict(id='lounge_gate', to=AREA('market_gate'), target='gate_lounge', mode=0, prompt='{interact} 回市集入口', style='road', w=28, h=44),
}

THEMES = {
    # 區域 -> (地形材質, 立面清單, 室內牆面貼圖, 鏤空機率, 天空, 道具資料夾)
    'pawnshop': ('concrete', ['shopfront', 'brick_block'], 'brick', 0.0, 'sky_storm', ['pawnshop_front', 'pawnshop_kitchen', 'basement_door', 'harbor_street', 'radio_workbench']),
    'rooftop': ('rooftop', ['apartment', 'brick_block'], None, 0.22, 'sky_storm', ['rooftop']),
    'harbor_street': ('asphalt', ['shopfront', 'apartment', 'shutter_block'], None, 0.22, 'sky_storm', ['harbor_street', 'anchor_phone_booth']),
    'market_gate': ('asphalt', ['shopfront', 'shutter_block'], None, 0.22, 'sky_storm', ['neon_market', 'anchor_phone_booth', 'harbor_street']),
    'market': ('asphalt', ['shopfront', 'apartment'], None, 0.22, 'sky_storm', ['neon_market', 'harbor_street', 'accounting_lobby']),
    'ali_home': ('concrete', ['apartment'], 'brick', 0.0, 'sky_storm', ['ali_kitchen']),
    'loading': ('concrete', ['warehouse', 'shutter_block'], None, 0.22, 'sky_storm', ['dock_warehouse', 'neon_market', 'harbor_street']),
    'ledger_front': ('concrete', ['warehouse'], 'hangar_wall', 0.0, 'sky_storm', ['yong_hideout', 'accounting_lobby', 'anchor_phone_booth']),
    'ledger_office': ('concrete', ['warehouse'], 'hangar_wall', 0.0, 'sky_storm', ['yong_hideout']),
    'lounge_front': ('asphalt', ['facility_wall', 'shutter_block'], None, 0.22, 'sky_storm', ['clinic', 'revival_lounge', 'guest_book_room']),
}

# 劇情接點：進場劇情與機關頻道。
STORY = {
    'pawnshop': dict(intro='ch2_s01_morning'),
    # 阿勇頭目戰（NE-265）制伏時啟動這個頻道，關卡寫入制伏旗標；帳櫃與小薇的劇情讀這個旗標。
    'ledger_office': dict(durable=True, done={'ch2_yong_down': 'ch2_yong_subdued', 'ch2_yong_isolation': 'yong_link_isolated'},
                          done_extra={'ch2_yong_isolation': ['yong_link_revoked']}),
}

# 本章的敵人（NE-266）：字元 -> (資料檔, 設計資料裡的名稱)。押運手與票據投手是本章才有的收帳人身份；阿勇是頭目（NE-265）。
ENEMIES = {
    '♞': ('res://data/enemies/ch2_escort.tres', '押運手'),
    '♜': ('res://data/enemies/ch2_bill_thrower.tres', '票據投手'),
    '♚': ('res://data/enemies/yong.tres', '阿勇'),
}

# 戰鬥區與成員（戰鬥 Session 配置，NE-266）：區域 -> [(名稱, x0, x1, 用途, [(欄, 字元)])]。
# 每場同屏最多三名普通敵人；地面的敵人看不到上層的繞道（高度差超過他們的視線），照劇本可以繞過。
# 阿勇的兩名小弟由頭目戰第一階段從兩側門補進來（同時最多兩名，第二階段不再增援，見 data/bosses/yong.json）。
COMBAT_ZONES = {
    'market_gate': [('入口押運手', 30, 48, '短戰，可從上層公眾攤道繞過', [(36, '♞'), (44, '♞')]),
                    ('入口票據投手', 56, 74, '短戰，可從上層公眾攤道繞過', [(60, '♞'), (70, '♜')])],
    'loading': [('下層貨道一', 24, 44, '可從雨棚上層繞過', [(30, '♜'), (40, '♞')]),
                ('下層貨道二', 60, 80, '可從電線橋繞過', [(64, '♞'), (72, '♞'), (78, '♜')])],
    'ledger_office': [('阿勇與兩名小弟', 8, 58, '頭目戰（NE-265）；小薇的隔間不是戰區', [(40, '♚')])],
}


# ---------------------------------------------------------------------------
# 區域
# ---------------------------------------------------------------------------

def build_pawnshop():
    """H1 當舖，隔天早上：老 K 在櫃台結算（S01），工作檯的收音機可以修（S02），樓梯上屋頂找鷺。"""
    a = Area('pawnshop', '當舖（早上）', 112, 20, indoor=True)
    kit.pawnshop_shell(a)
    a.stand(40, 'P')
    a.stand(43, 'K')
    a.stand(50, 'ⓞ')
    a.stand(56, 'V')
    a.stand(61, 'Ⓡ')
    # 凜修的那台收音機（BG-40）：拆開的收音機放在自己的小檯上，緊挨著工作檯，互動點就在它旁邊；
    # 牆上是修東西用的工具板，前面一張坐著修的木凳。
    a.prop('radio_workbench__pegboard_tools', 56, y=14, support='wall')
    a.prop('radio_workbench__worn_stool', 57)
    a.prop('radio_workbench__radio_open_bench', 59)
    a.stand(74, 'F')
    a.stand(108, 'S')
    a.features = {'landmark': '櫃台與工作檯（x=50～61）：早上的結算與收音機都在這裡'}
    return a


def build_rooftop():
    """H7 屋頂茶座：鷺坐在破傘下（S03、S04、S22）。"""
    a = Area('rooftop', '屋頂茶座', 72, 18)
    kit.rooftop_shell(a)
    a.stand(3, 'T')
    a.stand(5, 'P')
    a.stand(40, 'ⓔ')
    a.features = {'landmark': '破傘下的茶座（x=38）：雨量屏在遠處亮著'}
    return a


def _build_harbor_street_v1():
    """H5 安全街段：當舖前門到市集入口，中間是 B1 電話亭。"""
    a = Area('harbor_street', '港區街道（白天）', 64, 20)
    a.stand(3, 'h')
    a.stand(6, 'P')
    a.stand(30, 'C')
    a.stand(61, 'm')
    a.prop('anchor_phone_booth__phone_booth', 30)
    a.prop('harbor_street__umbrella_vending', 9)
    a.prop('harbor_street__fish_cart', 18)
    a.prop('harbor_street__stacked_neon_signs', 24, y=8)
    a.prop('anchor_phone_booth__news_rack', 37)
    a.prop('harbor_street__parked_scooter', 46)
    a.prop('harbor_street__steam_manhole', 52)
    a.prop('harbor_street__restore_queue_sign', 57)
    # 戶外街燈約 4 公尺高（地面上 8 格，同第一章街道，BG-36）。
    a.lamp(14, 12)
    a.lamp(34, 12)
    a.lamp(54, 12)
    a.zone(0, 'alley_calm')
    a.features = {'landmark': 'B1 電話亭（x=30）'}
    return a


def _build_market_gate_v1():
    """H12a 市集入口：巡帳員看證（S05），地面兩個戰鬥區可從上層公眾攤道繞過；B3 電話亭；往復原館、家屬出口。"""
    a = Area('market_gate', '市集入口', 120, 20)
    a.combat = True
    a.stand(2, 'Ⅰ')
    a.stand(5, 'P')
    a.stand(18, 'Ⓖ')
    a.prop('neon_market__cut_lock_gate', 22)
    # 上層公眾攤道：x=26～80，第 15 列；兩端有階梯平台上下（跳 3～4 格）
    a.platform(24, 26, 17)
    a.platform(27, 80, 14)
    a.platform(81, 83, 17)
    a.prop('neon_market__tv_stack_stall', 35)
    a.prop('neon_market__produce_stall', 62)
    a.stand(50, 'c', row=13)
    a.trigger(88, 'ch2_b_booth_b3')
    a.stand(92, 'C')
    a.prop('anchor_phone_booth__phone_booth', 92)
    a.prop('anchor_phone_booth__restore_arrow_sign', 95)
    a.stand(96, 'Ⓔ')   # 鷺在 B3 電話亭醒來（S14），搬送完成後才出現
    a.stand(100, 'Ⅲ')
    a.stand(108, 'Ⅳ')
    a.stand(117, 'Ⅱ')
    a.prop('harbor_street__tide_gauge', 112)
    # 戶外街燈約 4 公尺高（BG-36）：地面上的燈在第 12 列，上層攤道（第 14 列）上的燈在第 9 列。
    for x in (12, 86, 104):
        a.lamp(x, 12)
    for x in (30, 48, 66):
        a.lamp(x, 9)
    # 巡帳員旁邊的台階下多一盞低燈，入口第一個戰區的敵人輪廓才不會沒進夜色。
    a.lamp(22, 15)
    a.zone(0, 'market_gate')
    a.features = {'loop': '上層公眾攤道（x=24～83，第 14 列）：可以完全繞過地面兩個戰鬥區',
                  'landmark': '市場的水位尺（x=112）', 'reward': '公眾攤道中段的信用點（x=50）',
                  'secret': '無', 'vertical': '地面與攤道兩層'}
    return a


def _build_market_v1():
    """H12b 公眾攤道：代收處（S06）、租攤視窗（證據 A）、榕伯涼茶攤、公告屏、小販；後樓外梯到阿梨家，往後面的貨道。"""
    a = Area('market', '公眾攤道', 140, 20)
    a.stand(2, 'Ⅴ')
    a.stand(5, 'P')
    # 代收處：利息在收款臺後、阿梨在臺前
    a.prop('neon_market__debt_desk', 28)
    a.stand(30, 'Ⓥ')
    a.stand(25, 'ⓐ')
    a.prop('neon_market__permit_board', 38)
    # 租攤視窗
    a.prop('neon_market__rent_window', 52, dx=5)   # 租攤視窗本身（BG-41）：半拉下的鐵捲窗、收據插、號碼牌
    a.stand(53, 'Ⓦ')
    a.prop('accounting_lobby__contract_stand', 56)
    # 榕伯的涼茶攤
    a.prop('neon_market__tea_urn', 70)
    a.stand(72, 'Ⓑ')
    a.prop('harbor_street__umbrella_stand', 75)
    # 公告屏與小販
    a.prop('neon_market__speech_screen', 90)
    a.stand(90, 'Ⓝ')
    a.stand(101, 'ⓗ')
    a.prop('neon_market__produce_stall', 104)
    # 後樓外梯（上到三樓小廚房）與橋梯捷徑（從裝卸間放下）
    a.prop('neon_market__ad_pillar', 112)
    a.stand(116, 'Ⅵ')
    a.stand(124, 'Ⅷ')
    a.stand(137, 'Ⅶ')
    for x in (14, 34, 54, 74, 94, 114, 132):
        a.lamp(x, 12)  # 戶外街燈約 4 公尺高（BG-36）
    a.zone(0, 'market')
    a.features = {'landmark': '公告屏（x=90）：沈望的週年演說', 'shortcut': '橋梯捷徑（x=124）：從裝卸間放下後直通'}
    return a


def build_ali_home():
    """H21 阿梨的三樓小廚房：一張桌、一口湯鍋、洗碗池（S07），零戰鬥。"""
    a = Area('ali_home', '阿梨的小廚房', 48, 20, indoor=True)
    a.ceiling(1, 46, 10)
    a.stand(3, 'Ⅸ')
    a.stand(6, 'P')
    # 這間廚房自己的東西（BG-38）：門口補過的油紙傘、洗碗池與晾碗架（凜在這裡洗碗）、一張小桌、
    # 湯鍋（阿梨站在爐子旁）、小冰箱；牆上是調味料架、晾著圍裙的窗與手寫食譜。
    # 洗碗池挨著湯爐（ST-19，2026-11-06）：凜在爐邊和阿梨說完，走幾步就到水槽洗碗，不用穿過整間廚房。
    a.prop('ali_kitchen__patched_umbrella', 9)
    a.prop('ali_kitchen__small_table', 14)
    a.prop('ali_kitchen__window_apron', 21, y=17, support='wall')
    a.prop('ali_kitchen__sink_drying_rack', 26)
    a.prop('ali_kitchen__spice_shelf', 27, y=15, support='wall')
    a.prop('ali_kitchen__soup_stove', 30)
    a.stand(32, 'Ⓐ')
    a.prop('ali_kitchen__small_fridge', 36)
    a.prop('ali_kitchen__recipe_notes', 40, y=16, support='wall')
    for x in (12, 26, 40):
        a.lamp(x, 11)
    a.stand(45, '⇥')   # 後窗：爬出去就是公眾攤道的雨棚上層（NE-299）
    a.zone(0, 'residential')
    a.features = {'landmark': '門口那把補過的油紙傘（x=9）', 'loop': '後窗通到公眾攤道的雨棚上層'}
    return a


def _build_loading_v1():
    """H12c 雨棚背面：下層貨道與雨棚上層成環，剪斷的電線橋（S09），裝卸間代收簿（證據 C），乾燥作業桌對帳（S10），北棟貨門。"""
    a = Area('loading', '雨棚背面與裝卸間', 150, 20)
    a.combat = True
    a.stand(2, 'Ⅹ')
    a.stand(5, 'P')
    # 雨棚上層：x=14～96，第 13 列；中段是剪斷電線的橋
    a.platform(10, 12, 17)
    a.platform(13, 96, 13)
    a.platform(97, 99, 17)
    a.prop('harbor_street__pole_wire_knot', 52)
    a.trigger(46, 'ch2_s09_wire')
    # 下層貨道（戰鬥區）
    a.prop('dock_warehouse__wrapped_pallets', 36)
    a.prop('dock_warehouse__float_drum_crate', 68)
    a.stand(84, 'ⓧ')
    # 橋梯拉桿（SC1）與捷徑口
    a.stand(92, 'ⓙ', row=12)
    # 拉桿箱立在雨棚上層、互動點旁；橋梯摺起來立在出入口，捷徑開通後換成放下的樣子（BG-41）。
    a.prop('dock_warehouse__bridge_lever', 93, y=12)
    a.prop('dock_warehouse__bridge_ladder_up', 100, react='bridge_ladder')
    a.stand(100, 'Ⅺ')
    # 裝卸間
    a.ceiling(104, 148, 10)
    a.block(104, 104, 10, 16)
    a.stand(112, 'ⓛ')
    a.prop('dock_warehouse__collection_book_stand', 112, dx=1)   # 代收簿攤開在簽收檯上（BG-41）
    a.prop('dock_warehouse__open_container', 120)
    a.stand(128, 'ⓓ')
    a.prop('dock_warehouse__drying_desk', 127, dx=1)             # 乾燥作業桌：線上晾著紙、上面一盞烘燈（BG-41）
    a.stand(134, 'c')
    a.stand(146, 'Ⅻ')
    # 雨棚上層的燈照棚頂，下層貨道另掛棚下燈（棚頂第 13 列擋住上方的光）。
    for x in (30, 70):
        a.lamp(x, 9)
    for x in (20, 40, 60, 80):
        a.lamp(x, 15)
    for x in (110, 124, 140):
        a.lamp(x, 11)
    # 雨棚背面沿用市集的燈色（貨運區的燈有三成是壞的，下層貨道會暗到看不見地面邊緣）；裝卸間用整排亮著的機庫燈。
    a.zone(0, 'market')
    a.zone(104, 'hangar', 6)
    a.features = {'loop': '下層貨道與雨棚上層（x=10～99）成環', 'shortcut': '橋梯捷徑 SC1（x=92 拉桿、x=100 梯口）回代收處',
                  'secret': '乾燥盒的信用點（x=134）', 'landmark': '剪斷電線的橋（x=46～52）', 'vertical': '地面與雨棚兩層'}
    return a


def build_ledger_front():
    """H13 前室：電話亭、隔離箱示意圖、帳房的門（S11 登場）。"""
    a = Area('ledger_front', '北棟二樓前室', 56, 20, indoor=True)
    a.ceiling(1, 54, 10)
    a.stand(3, 'ⅰ')
    a.stand(6, 'P')
    a.stand(16, 'C')
    a.prop('anchor_phone_booth__phone_booth', 16)
    # 示意圖貼在牆上，旁邊就是它畫的那個隔離箱（BG-42）。
    a.prop('yong_hideout__isolation_diagram', 27, y=17, dx=12, support='wall')
    a.stand(28, 'ⓘ')
    a.prop('yong_hideout__isolation_box', 31)
    a.prop('yong_hideout__money_sacks', 38)
    a.stand(46, 'ⓨ')
    a.stand(52, 'ⅱ')
    for x in (12, 30, 46):
        a.lamp(x, 11)
    a.zone(0, 'warehouse_interior')
    a.features = {'landmark': '隔離箱示意圖（x=28）：主箱永久解除、側箱只能暫停'}
    return a


def build_ledger_office():
    """H13 二樓帳房：戰區（兩層可繞鐵棍）、小薇在後方高臺的玻璃隔間、帳櫃、家屬出口。頭目戰由 NE-265 製作。"""
    a = Area('ledger_office', '二樓帳房', 72, 20, indoor=True)
    a.combat = True
    a.ceiling(1, 70, 6)
    a.stand(3, 'ⅲ')
    a.stand(6, 'P')
    # 兩層：中段平台可繞過鐵棍（第 15 列）
    a.platform(18, 30, 15)
    a.platform(40, 52, 15)
    # 小薇的玻璃隔間：後方高臺（第 10 列），玻璃與戰區分開；靠戰區那一側整面封住（第 57 欄），子彈與爆炸進不去（NE-265）
    a.block(58, 69, 11, 11)
    a.block(57, 57, 6, 10)
    a.stand(63, 'ⓟ', row=10)
    a.prop('yong_hideout__xiaowei_bed', 64, y=10)
    a.prop('yong_hideout__toy_corner', 60, y=10)
    a.prop('yong_hideout__banker_desk', 12)
    a.prop('yong_hideout__ledger_wall', 34, y=13, support='wall')
    a.prop('yong_hideout__teller_cage', 46)
    a.stand(54, 'ⓜ')
    a.prop('yong_hideout__ledger_cabinet', 53, dx=10)   # 帳櫃（BG-42）：玻璃門後一排排帳冊
    a.prop('yong_hideout__pendant_bulbs', 30, support='ceiling', ceiling_row=6)
    a.stand(68, 'ⅳ')
    for x in (14, 34, 50):
        a.lamp(x, 7)
    a.zone(0, 'ledger_office_interior')
    a.features = {'arena': '阿勇戰區（x=8～58），兩層平台繞鐵棍', 'landmark': '帳櫃（x=54）', 'vertical': '地面與中段平台兩層',
                  'loop': '家屬出口（x=68）搬送後通到市集電話亭', 'reward': '帳櫃裡的原帳與索引'}
    return a


def build_lounge_front():
    """H10 復原館外：公用委託終端（S15）、休息桌（S16）、客人簿入口（S17；客人簿是阿梨視角的演出，見劇本 S17～S21）。"""
    a = Area('lounge_front', '復原館外', 56, 20)
    a.stand(2, 'ⅴ')
    a.stand(5, 'P')
    a.ceiling(10, 54, 4)
    a.stand(16, 'ⓣ')
    a.prop('revival_lounge__commission_terminal', 16, dx=-1)   # 公用委託終端（BG-42）
    a.prop('revival_lounge__round_table_stools', 30)
    a.stand(33, 'ⓢ')
    a.stand(44, 'ⓠ')
    # 客人簿（BG-40）：攤開的客人簿放在矮桌上，旁邊一盞落地紙燈，互動點就在桌前。
    a.prop('guest_book_room__guest_book_table', 43)
    a.prop('guest_book_room__paper_floor_lamp', 47)
    a.prop('revival_lounge__booth_sofa', 48)
    a.lamp(16, 14)
    a.lamp(34, 14)
    a.zone(0, 'lounge_front')
    a.features = {'landmark': '委託終端（x=16）'}
    return a


# NE-299：港街、市集入口、公眾攤道與裝卸場改成上下層互通（data/levels/ch2_layout_v2.json）。
# 原內容整批下移 16 格，保留所有內容 ID 與舊檔格位映射；新的雨棚門只連接本來就能到的區域，
# 往貨道上層的門和原貨道一樣要先問過代收處（ch2_market_contact_done）。
def build_harbor_street():
    a = kit._v2_area(_build_harbor_street_v1())
    a.features.update(loop='雨棚上層連到市集入口的上層攤道', vertical='街面與雨棚兩層',
                      reward='雨棚上方第 15 列信用點：空中再躍')
    return a


def build_market_gate():
    a = kit._v2_area(_build_market_gate_v1())
    a.features.update(loop='上層攤道往左接回港區街道的雨棚', reward='上層攤道上方第 21 列信用點：空中再躍',
                      vertical='地面、上層攤道與高處三層')
    return a


def build_market():
    a = kit._v2_area(_build_market_v1())
    a.features.update(loop='雨棚上層連到阿梨家的後窗，也接到貨道上層（問過代收處後開放）',
                      reward='公告屏上方第 15 列信用點：空中再躍', vertical='攤道地面與雨棚兩層',
                      rest='阿梨的小廚房在回環上，零戰鬥')
    return a


def build_loading():
    a = kit._v2_area(_build_loading_v1())
    a.features.update(loop='下層貨道、雨棚上層與公眾攤道雨棚成環', reward='電線橋上方第 20 列信用點：空中再躍',
                      vertical='地面、雨棚與高處三層')
    return a


def route_checks(a):
    """各區的明確路線快照（只是格子近似，不代替真玩家輸入）。"""
    start = next(((x, y) for y in range(a.h) for x in range(a.w) if a.grid.at(x, y) == 'P'), None)
    normal = kit.RouteState('normal')
    late = kit.RouteState('air_jump_bound', jump_tiles=10)
    scenarios = {
        'harbor_street': [(normal, [('booth', (30, 35)), ('market', (61, 35)), ('upper', (61, 23))], [('reward', (27, 15))]),
                          (late, [('reward', (27, 15))], [])],
        'market_gate': [(normal, [('patroller', (18, 35)), ('upper', (3, 25)), ('booth', (92, 35)), ('market', (117, 35))],
                         [('reward', (47, 21))]),
                        (late, [('reward', (47, 21))], [])],
        'market': [(normal, [('vig', (30, 35)), ('roof', (116, 23)), ('canopy', (136, 23)), ('cargo', (137, 35))],
                    [('reward', (89, 15))]),
                   (late, [('reward', (89, 15))], [])],
        'loading': [(normal, [('canopy', (14, 28)), ('lever', (92, 28)), ('ledger', (146, 35))], [('reward', (61, 20))]),
                    (late, [('reward', (61, 20))], [])],
    }
    problems = []
    for state, goals, forbidden in scenarios.get(a.id, []):
        problems += kit.reachable(a, start, goals, state=state)
        for target in forbidden:
            if not kit.reachable(a, start, [target], state=state):
                problems.append(f'{a.id}/{state.name}: {target[0]} 不該用普通跳躍就到得了')
    return problems


# 和第一章共用空間的區域沿用第一章審過的擺設位置（scenery_placement.json 的 overrides）。
PLACEMENT_IDS = {'pawnshop': 'ch1_pawnshop', 'rooftop': 'ch1_rooftop'}

AREAS = (build_pawnshop, build_rooftop, build_harbor_street, build_market_gate, build_market, build_ali_home, build_loading,
         build_ledger_front, build_ledger_office, build_lounge_front)


def configure():
    """把第一章的工具切到第二章：人物、出入口、主題與劇情接點都換成本章的，字元不和第一章的資源衝突。"""
    clash = sorted(c for c in NPC_CHARS if c in kit.RES or c in PORTALS or c in kit.TRAINING)
    clash += sorted(c for c in PORTALS if c in kit.RES)
    clash += sorted(c for c in ENEMIES if c in kit.RES or c in NPC_CHARS or c in PORTALS)
    if clash:
        raise SystemExit(f'第二章的字元和既有資源衝突：{clash}')
    for char, ident in NPC_CHARS.items():
        kit.RES[char] = f'res://data/npcs/{ident}.tres'
    for char, (path, name) in ENEMIES.items():
        kit.RES[char] = path
        kit.ENEMY_NAMES[char] = name
    kit.PORTALS = PORTALS
    kit.NPCS = {ident: {**{'rig': '', 'loop': '', 'facing': 1}, **spec} for ident, spec in NPCS.items()}
    kit.THEMES = THEMES
    kit.STORY = STORY
    kit.placement_id = lambda ident: PLACEMENT_IDS.get(ident, f'ch2_{ident}')


def main():
    configure()
    areas = [build() for build in AREAS]
    for a in areas:
        for name, x0, x1, _use, members in COMBAT_ZONES.get(a.id, []):
            a.encounter(name, x0, x1, members)
    problems = []
    for a in areas:
        problems += a.check()
        start = next(((x, y) for y in range(a.h) for x in range(a.w) if a.grid.at(x, y) == 'P'), None)
        goals = [(a.grid.at(x, y), (x, y)) for y in range(a.h) for x in range(a.w)
                 if a.grid.at(x, y) in set(kit.RES) | set(PORTALS) | {'C'}]
        problems += route_checks(a) if hasattr(a, 'legacy_layout') else kit.reachable(a, start, goals)
    if problems:
        print('\n'.join(problems))
        sys.exit(1)
    kit.write_npc_files()
    kit.write_design(areas)
    for a in areas:
        extra = kit._map_extra(a)
        a.grid.write(a.id, (kit.LEVEL_DIR, f'ch2_{a.id}_map.json'), extra)
    by_id = {a.id: a for a in areas}
    kit.write_level(by_id['pawnshop'], show_card=True)
    for ident in ('rooftop', 'harbor_street', 'market_gate', 'market', 'ali_home', 'loading', 'ledger_front', 'ledger_office',
                  'lounge_front'):
        # 屋頂的章末接第三章的週日早上（當舖）。
        extra = {'complete_on_flag': '&"ch2_heron_closed"', 'next_level': '"res://data/levels/ch3_pawnshop.tres"'} if ident == 'rooftop' else {}
        kit.write_level(by_id[ident], **extra)


if __name__ == '__main__':
    main()
