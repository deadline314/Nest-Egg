extends "res://work/bg41-current/loading/formal-before-phase.gd"
var _expected_culling := true
func _ready() -> void:
    if OS.get_cmdline_user_args().has("--preexisting-culling-disabled"):
        Enemy.activation_culling_enabled = false
    _expected_culling = Enemy.activation_culling_enabled
    super._ready()
func _actors() -> Array[Dictionary]:
    var result: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(&"enemies"):
        result.append({"instance":node.get_instance_id(),"data":str(node.data.id),"world":[node.global_position.x,node.global_position.y],"mode":node.process_mode,"can_process":node.can_process(),"enablers":node.find_children("*","VisibleOnScreenEnabler2D",true,false).size()})
    return result
func _exit_tree() -> void:
    print("BG41_CULLING_RESTORE ",JSON.stringify({"expected":_expected_culling,"actual":Enemy.activation_culling_enabled,"restored":_expected_culling==Enemy.activation_culling_enabled}))
    super._exit_tree()
func _frame_interval_ms() -> float:
    var environment := get_viewport().find_world_3d().environment
    var enemies: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(&"enemies"):
        enemies.append({"kind":str(node.get_script().get_global_name()),"world":[node.global_position.x,node.global_position.y]})
    print("BG41_ENV ",JSON.stringify({"environment":environment!=null,"glow":environment!=null and environment.glow_enabled,"count":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),"hdr":get_viewport().use_hdr_2d,"quality":Settings.get_light_quality(),"size":[get_viewport().get_texture().get_width(),get_viewport().get_texture().get_height()],"enemies":enemies}))
    var before := _actors()
    var result := await super._frame_interval_ms()
    var after := _actors()
    print("BG41_FREEZE ",JSON.stringify({"before":before,"after":after,"held":before==after,"culling":Enemy.activation_culling_enabled}))
    return result

func _measure(level: Level, world: Rect2) -> Dictionary:
    var result := await super._measure(level,world)
    result["enemy_fill_scale"] = level._lighting.current.enemy_fill_scale
    result["character_fill"] = LightKit.character_fill
    result["enemy_fill"] = LightKit.enemy_fill
    result["enemy_light_cap"] = LightKit.enemy_light_cap
    return result
