extends "res://work/bg41-current/loading/safe-before.gd"
func _trace(label: String) -> void:
    var actors: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(&"enemies"):
        actors.append({"instance":node.get_instance_id(),"data":str(node.data.id),"mode":node.process_mode,"can_process":node.can_process(),"parent":str(node.get_parent().name),"world":[node.global_position.x,node.global_position.y],"state":str(node.fsm.current),"velocity":[node.velocity.x,node.velocity.y]})
    print("BG41_ACTOR ",JSON.stringify({"label":label,"frame":Engine.get_physics_frames(),"actors":actors}))
func _frame_interval_ms() -> float:
    _trace("before_benchmark")
    var result := await super._frame_interval_ms()
    _trace("after_benchmark")
    return result
