extends "res://work/bg41-current/loading/after-observer.gd"
func _place_player(level: Level, center: Vector2, view: Vector2) -> void:
    var separated := center
    separated.x = 904.0 if center.x<1000.0 else 984.0
    super._place_player(level,separated,view)
func _measure(level: Level, world: Rect2) -> Dictionary:
    var result := await super._measure(level,world)
    var probe := ContrastProbe.capture(get_viewport())
    var player_region := probe._body_box(level.player.global_position,true).grow(ContrastProbe.RING)
    var clear := true
    for node in get_tree().get_nodes_in_group(&"enemies"):
        if node is Node2D and node.is_visible_in_tree() and world.grow(-24.0).has_point(node.global_position):
            clear = clear and not player_region.intersects(probe._body_box(node.global_position,false).grow(ContrastProbe.RING))
    result["player_enemy_regions_disjoint"] = clear
    print("BG41_UNOBSTRUCTED ",JSON.stringify({"player_world":result.player_world,"regions_disjoint":clear,"enemies":result.get("enemy_contrast",[])}))
    return result
