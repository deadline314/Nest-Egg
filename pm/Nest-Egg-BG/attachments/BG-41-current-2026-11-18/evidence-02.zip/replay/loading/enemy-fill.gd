extends "res://work/bg41-current/loading/stationary-after.gd"
var _market: LightingProfile
func _ready() -> void:
    _market = load("res://data/lighting/market.tres") as LightingProfile
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--enemy-fill="):
            _market.enemy_fill_scale = float(argument.trim_prefix("--enemy-fill="))
    super._ready()
func _frame_interval_ms() -> float:
    for child in get_children():
        if child is Level:
            print("BG41_FILL ",JSON.stringify({"configured":_market.enemy_fill_scale,"actual":child._lighting.current.enemy_fill_scale,"enemy_fill":LightKit.enemy_fill,"character_fill":LightKit.character_fill}))
    return await super._frame_interval_ms()
func _measure(level: Level, world: Rect2) -> Dictionary:
    var result := await super._measure(level,world)
    var probe := ContrastProbe.capture(get_viewport())
    var parts: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(&"enemies"):
        if node is Enemy and node.is_visible_in_tree() and world.grow(-24).has_point(node.global_position):
            parts.append({"id":str(node.data.id),"feet":[node.global_position.x,node.global_position.y],"parts":probe.character_parts(node.global_position)})
    result["enemy_parts_diagnostic"] = parts
    return result
