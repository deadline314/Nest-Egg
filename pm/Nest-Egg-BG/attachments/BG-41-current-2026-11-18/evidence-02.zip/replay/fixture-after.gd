extends "res://tools/readability_check.gd"
func targets() -> Array[Dictionary]:
    var entries: Array[Dictionary] = [{"path": "res://data/levels/ch2_market.tres", "spots": [["代收處", 28, 36], ["租攤視窗", 53, 36], ["公告屏", 90, 36], ["雨棚上層", 60, 24]], "enemy_path": ""}, {"path": "res://data/levels/ch2_loading.tres", "spots": [["橋梯拉桿", 92, 29], ["橋梯入口", 100, 36], ["代收簿", 112, 36], ["乾燥作業桌", 128, 36]], "enemy_path": ""}, {"path": "res://data/levels/ch2_loading.tres", "spots": [["票據投手30", 24, 36, 30], ["票據投手78", 72, 36, 78]], "enemy_path": "res://data/enemies/ch2_bill_thrower.tres"}, {"path": "res://data/levels/ch2_loading.tres", "spots": [["押運手41", 35, 36, 41], ["押運手62", 56, 36, 62], ["押運手71", 65, 36, 71]], "enemy_path": "res://data/enemies/ch2_escort.tres"}]
    return entries
