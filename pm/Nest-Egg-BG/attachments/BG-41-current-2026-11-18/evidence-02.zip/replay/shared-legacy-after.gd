extends "res://tools/readability_check.gd"
var _sample_records: Array[Dictionary] = []
func _record_probe_sample(_probe: ContrastProbe, level: Level, spot: Array, sample: int, foe: Enemy, sums: Array[float]) -> void:
    _sample_records.append({"level":str(level.data.id),"spot":str(spot[0]),"sample":sample,"sums":sums.duplicate(),"enemy":str(foe.data.id) if is_instance_valid(foe) else "","enemy_feet":[foe.global_position.x,foe.global_position.y] if is_instance_valid(foe) else [],"enemy_fill_scale":level._lighting.current.enemy_fill_scale,"character_fill":LightKit.character_fill,"enemy_fill":LightKit.enemy_fill,"enemy_light_cap":LightKit.enemy_light_cap})
func _exit_tree() -> void:
    var path := _out_dir.path_join("frame-samples.json")
    var writer := FileAccess.open(path,FileAccess.WRITE)
    if writer==null:
        push_error("[BG41] Cannot save fixture observations: %s (%s)" % [path,FileAccess.get_open_error()])
    else:
        writer.store_string(JSON.stringify(_sample_records,"  ")+"\n")
