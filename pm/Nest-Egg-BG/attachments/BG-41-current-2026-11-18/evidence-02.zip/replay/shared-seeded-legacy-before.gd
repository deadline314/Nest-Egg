extends "res://work/bg41-current/shared-legacy-before.gd"
func _prepare_probe_level(data: LevelData) -> void:
    super._prepare_probe_level(data)
    seed(410018)
