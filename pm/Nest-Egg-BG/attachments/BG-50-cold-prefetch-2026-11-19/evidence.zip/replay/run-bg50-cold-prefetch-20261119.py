from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

import psutil

root=Path.cwd()
base=root/'work/bg50-cold-prefetch-20261119'
catalog=json.loads((base/'copies.json').read_bytes())
manifest=json.loads((base/'source.json').read_bytes())
source=Path('D:/NestEggVerification/ne218-baseline-20261117')
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=source/'tools/frame_time_probe.gd'
assert sha(original)==manifest['sha256']['tools/frame_time_probe.gd']
script=base/'observer.gd'
raw=original.read_text(encoding='utf-8')
raw=raw.replace('func _ready() -> void:\n', 'func _ready() -> void:\n\tSettings.set_fullscreen(true)\n', 1)
a='\tresult["warmup_max_ms"] = warmup["max_ms"]\n'
b='\t_player = null\n\tlevel.queue_free()'
c='\tget_tree().quit(0)\n'
assert raw.count(a)==raw.count(b)==raw.count(c)==1
raw=raw.replace(a,a+'\tresult["warmup_hitches"] = warmup["hitches"]\n\tresult["warmup_p99_ms"] = warmup["p99_ms"]\n')
raw=raw.replace(b,'''	var size := DisplayServer.window_get_size()
	result["window"] = [size.x, size.y]
	result["refresh_hz"] = DisplayServer.screen_get_refresh_rate()
	result["vsync_mode"] = DisplayServer.window_get_vsync_mode()
	result["light_quality"] = Settings.get_light_quality()
	result["adapter"] = RenderingServer.get_video_adapter_name()
	if not _tag.begins_with("shader-prime"):
		await RenderingServer.frame_post_draw
		var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
		var status := image.save_png(_out.path_join(level_id + ".png"))
		if status != OK:
			push_error("cold probe screenshot could not be saved")
'''+b)
raw=raw.replace(c,'\tAudioRelease.begin_shutdown()\n\tawait AudioRelease.settle(get_tree())\n'+c)
script.write_text(raw,encoding='utf-8',newline='\n')
scene=script.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{script.as_posix()}" id="1"]\n[node name="ColdPrefetch" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(base/'profile'/key)

def play(tag,project,level):
    folder=base/tag
    folder.mkdir()
    cpu=psutil.cpu_percent(interval=1)
    command=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',engine,
             '--path',str(project),'--rendering-method','forward_plus','--rendering-driver','vulkan',
             '--audio-driver','Dummy','--fullscreen','--resolution','2560x1440',scene.as_posix(),'--',
             '--level='+level,'--seconds=14','--tag='+tag,'--out='+str(folder)]
    (folder/'command.json').write_text(json.dumps({'command':command,'cpu_percent_before':cpu,'diagnostic_observer_sha256':sha(script)},indent=2)+'\n')
    with (folder/'raw.log').open('wb') as log:
        run=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=210)
    text=(folder/'raw.log').read_text(encoding='utf-8')
    print(tag,run.returncode,text[-1550:],flush=True)
    assert run.returncode==0 and 'SCRIPT ERROR' not in text and 'RX 9070 XT' in text and 'Forward+' in text
    errors=[line for line in text.splitlines() if 'ERROR:' in line]
    result=json.loads((folder/f'{tag}-frame-time.json').read_bytes())
    assert result['seconds']==14 and not result['idle']
    assert all(row['window']==[2560,1440] and row['prefetch']['loads']>0 and row['prefetch']['warmed_files']>0 for row in result['levels'])
    if not tag.startswith('shader-prime'):
        assert len(result['levels'])==1 and (folder/f'{level}.png').is_file()
    return {'tag':tag,'errors':errors,'cpu_percent_before':cpu,'levels':result['levels']}

if len(sys.argv)>1 and sys.argv[1]=='prime':
    result=play('shader-prime-fullscreen',source,'ch1_street,ch1_warehouse')
    (base/'shader-prime.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    exit()

assert (base/'shader-prime.json').exists()
values=[]
for key,config in catalog.items():
    project=Path(config['project'])
    assert all((project/name).is_file() for name in manifest['sha256'])
    values.append(play('first-'+key,project,config['region']))
    values.append(play('second-'+key,project,config['region']))
    for name in manifest['sha256']:
        if not name.startswith('.godot/'):
            assert sha(project/name)==manifest['sha256'][name],name
    for snapshot in config['independent_import_ids']:
        relative=Path('.godot/imported')/snapshot['file']
        assert sha(project/relative)==sha(source/relative)
assert all(sha(source/name)==digest for name,digest in manifest['sha256'].items() if not name.startswith('.godot/'))
(base/'results.json').write_text(json.dumps(values,indent=2)+'\n',encoding='utf-8')
