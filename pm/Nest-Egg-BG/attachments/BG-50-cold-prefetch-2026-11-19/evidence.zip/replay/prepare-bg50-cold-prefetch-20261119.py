from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

root=Path.cwd()
source=Path('D:/NestEggVerification/ne218-baseline-20261117')
work=root/'work/bg50-cold-prefetch-20261119'
target_root=Path('C:/NE/bg50-cold-prefetch-20261119')
guard_path=root/'work/ne228-save-notice-20261119/integration/publish/result.json'
assert json.loads(guard_path.read_bytes())['main_origin_head_equal']
head=json.loads(guard_path.read_bytes())['commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()==head
stages={'street':'ch1_street','warehouse':'ch1_warehouse'}
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
project_dirs=('art','audio','autoload','core','data','game','scenes','tests','tools','ui','.godot/imported')
source_paths=['project.godot','icon.png','icon.png.import','icon.ico',
              '.godot/global_script_class_cache.cfg','.godot/uid_cache.bin']
source_paths.extend(f'data/levels/{level}.tres' for level in stages.values())
source_paths.extend(('tools/frame_time_probe.gd','tools/frame_time_probe.tscn','core/asset_prefetch.gd'))
held={name:sha(source/name) for name in source_paths}
work.mkdir(exist_ok=True)
target_root.mkdir()
(work/'source.json').write_text(json.dumps({'head':head,'sha256':held},indent=2)+'\n')
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(work/'profile'/key)
commands={}
for tag,level in stages.items():
    new=target_root/tag
    new.mkdir()
    steps=[]
    for directory in project_dirs:
        src=source/directory
        dst=new/directory
        args=['robocopy.exe',str(src),str(dst),'/E','/J','/R:0','/W:0','/XJ','/COPY:DAT','/NFL','/NDL',
              '/NP','/NJS', '/XD','__pycache__']
        proc=subprocess.run(args,capture_output=True,timeout=240)
        (work/f'{tag}-{directory.replace("/","-")}-copy.log').write_bytes(proc.stdout+proc.stderr)
        assert proc.returncode<8,(tag,directory,proc.returncode)
        steps.append({'path':directory,'argv':args,'status':proc.returncode})
    for relative in source_paths[:6]:
        src=source/relative
        target=(new/relative).parent
        args=['robocopy.exe',str(src.parent),str(target),src.name,'/J','/R:0','/W:0','/XJ','/COPY:DAT','/NFL','/NDL','/NP']
        proc=subprocess.run(args,capture_output=True,timeout=60)
        assert proc.returncode<8,(relative,proc.returncode)
        steps.append({'path':relative,'argv':args,'status':proc.returncode})
    # Compare by metadata before first play. Hashing a staged texture here would warm it.
    files=[name for name in held if not name.startswith('.godot/')]
    assert all((new/name).stat().st_size==(source/name).stat().st_size for name in files)
    chosen=list(sorted((source/'.godot/imported').glob('*.ctex')))[:8]
    assert chosen
    ids=[]
    for existing in chosen:
        file=new/'.godot/imported'/existing.name
        assert file.stat().st_size==existing.stat().st_size
        before_id,after_id=existing.stat().st_ino,file.stat().st_ino
        assert before_id!=after_id
        ids.append({'file':existing.name,'source_id':before_id,'copy_id':after_id})
    commands[tag]={'project':str(new),'region':level,'steps':steps,'independent_import_ids':ids}
    print('ready',tag,len(steps),flush=True)
(work/'copies.json').write_text(json.dumps(commands,indent=2)+'\n')
print('unbuffered copy ready',head,flush=True)
