from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg34-current');out=b/'checks-restored';out.mkdir(exist_ok=False)
private=root/'work/bg34-checks-restored';private.mkdir(exist_ok=False)
(private/'before.gd').write_bytes(subprocess.check_output(['git','show','c6eaec5fb9edbd28ba0b6e022e1b787bd5226698:tools/wall_shadow_probe.gd'],cwd=primary))
(private/'selfcheck.gd').write_text('''extends Node
var failures := 0
var checks := 0
func check(value: bool, label: String) -> void:
    checks += 1
    if not value:
        failures += 1
        push_error("BG34_SELFCHECK " + label)
func _ready() -> void:
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    GameState.start_new_run(GameState.difficulties[1])
    var data := (load("res://data/levels/ch1_warehouse.tres") as LevelData).duplicate() as LevelData
    data.intro_scene = &""
    data.show_chapter_card = false
    data.complete_after_intro = false
    var level := Level.new()
    level.configure(data)
    add_child(level)
    for i in 20: await get_tree().process_frame
    var before := load("res://work/bg34-checks-restored/before.gd").new() as Node
    var current := load("res://tools/wall_shadow_probe.gd").new() as Node
    var original := level.player.global_position
    var found := false
    for col in range(10,level._layout.width-10):
        before._at = col
        current._at = col
        level.player.global_position = original
        var old_first: Vector2 = before._stand(level)
        var first: Vector2 = current._stand(level)
        level.player.global_position.y -= 128.0
        var old_second: Vector2 = before._stand(level)
        var second: Vector2 = current._stand(level)
        if old_first.is_finite() and old_second.is_finite() and old_first != old_second:
            check(old_first != old_second,"counterfactual old input changed floor")
            check(first==second,"fixed --at floor ignores previous fixture height")
            check(first==old_first,"initial floor selection preserved")
            print("BG34_FLOOR ",JSON.stringify({"column":col,"old_first":[old_first.x,old_first.y],"old_second":[old_second.x,old_second.y],"new":[first.x,first.y]}))
            found = true
            break
    check(found,"real multi-height fixture found")
    level.player.global_position = original
    var a := Image.create(6,6,false,Image.FORMAT_RGBA8)
    var c := Image.create(6,6,false,Image.FORMAT_RGBA8)
    a.fill(Color(.2,.2,.2));c.fill(Color(.8,.8,.8))
    check(current._shadowed_share(a,a)==0,"identical images have no shadow delta")
    check(current._shadowed_share(a,c)==1,"real darkening counted")
    check(current._shadowed_share(c,a)==-1,"reverse darkening subtracted")
    a.fill(Color.BLACK);c.fill(Color(1.0/255.0,1.0/255.0,1.0/255.0))
    check(current._shadowed_share(a,c)==0,"unchanged dark floor skips near black")
    before.free();current.free();level.queue_free()
    for i in 8: await get_tree().process_frame
    print("BG34_SELFCHECK checks=",checks," failures=",failures)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0 if failures==0 else 1)
''',encoding='utf8',newline='\n')
(private/'selfcheck.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg34-checks-restored/selfcheck.gd" id="1"]\n[node name="Check" type="Node"]\nscript = ExtResource("1")\n')
source=json.loads((b/'before/source-after.json').read_text())
source['design/16-audio/PLACEMENTS.md']=hashlib.sha256((root/'design/16-audio/PLACEMENTS.md').read_bytes()).hexdigest()
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name,command in [('changed',['C:/Program Files/Git/bin/bash.exe','-c','python3() { python "$@"; }; export -f python3; tools/run_tests_changed.sh c6eaec5fb9edbd28ba0b6e022e1b787bd5226698']),('selfcheck',['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(root),'--audio-driver','Dummy','res://work/bg34-checks-restored/selfcheck.tscn'])]:
    folder=out/name;folder.mkdir();env=os.environ.copy();env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='4',LOG_DIR=str(folder/'shards'),PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
    raw=(folder/'raw.log').read_bytes();row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot()}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);assert row['exit']==row['script_errors']==0 and not row['engine_error'] and row['source_held']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'all_passed':True},indent=2)+'\n')
