from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg34-current');out=b/'native-final-v3';out.mkdir(exist_ok=False)
private=root/'work/bg34-native-final-v3';private.mkdir(exist_ok=False)
(private/'observer.gd').write_text('''extends "res://tools/wall_shadow_probe.gd"
func _ready() -> void:
    if OS.get_cmdline_user_args().has("--preexisting-environment"):
        add_child(LightKit.create_environment())
    super._ready()
func _pair(shadows: WallShadows, name: String) -> Dictionary:
    var result := await super._pair(shadows,name)
    var prompts := 0
    for node: Node in get_tree().root.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    var environment := get_viewport().find_world_3d().environment
    var record := {"name":name,"environments":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),
        "hdr":get_viewport().use_hdr_2d,"glow":environment != null and environment.glow_enabled,
        "visible_prompts":prompts,"actual_quality":Settings.get_light_quality(),"restored_time_scale":Engine.time_scale}
    print("BG34_NATIVE ",JSON.stringify(record))
    return result
''',encoding='utf8',newline='\n')
def scene(name,script):
    (private/(name+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg34-native-final-v3/'+script+'" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
scene('observer','observer.gd')
canonical=(root/'tools/wall_shadow_probe.gd').read_bytes()
missing=canonical.replace(b'const ENEMY_PATH := "res://data/enemies/sweeper.tres"',b'const ENEMY_PATH := "res://data/enemies/bg34-deliberately-missing.tres"')
assert missing != canonical
(private/'missing.gd').write_bytes(missing);scene('missing','missing.gd')
source=json.loads((b/'checks-final/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source}
before=snapshot();assert before==source
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
cases=[]
for q in ['low','medium','high']:
    for level,col,mode,images in [('ch1_warehouse',70,'gun',3),('ch1_street',10,'lamp,gun',12)]:
        cases.append((q+'-'+level,q,level,col,mode,images,0,'observer'))
cases.extend([('write-failure','low','ch1_warehouse',70,'gun',1,1,'observer'),('partial-enemies','high','ch1_warehouse',14,'gun',3,1,'observer'),('missing-enemy','high','ch1_warehouse',70,'gun',3,1,'missing')])
for name,q,level,col,mode,images,expected,script in cases:
    folder=out/name;folder.mkdir(exist_ok=False);env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    if name=='write-failure':
        for side in ['on','off']:(folder/('walls-gun-'+side+'.png')).mkdir()
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg34-native-final-v3/'+script+'.tscn','--','--out='+str(folder),'--level='+level,'--mode='+mode,'--at='+str(col),'--quality='+q]
    if name=='high-ch1_pawnshop':command.append('--preexisting-environment')
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();observations=[json.loads(l.split(b'BG34_NATIVE ',1)[1]) for l in raw.splitlines() if l.startswith(b'BG34_NATIVE ')]
    report=json.loads((folder/'walls-index.json').read_text())
    row={'name':name,'command':command,'exit':r.returncode,'expected_exit':expected,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'images':len([p for p in folder.glob('*.png') if p.is_file()]),'observations':observations,'failures':report['failures']}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode('utf8',errors='replace')[-1200:],flush=True)
    assert row['exit']==expected and row['script_errors']==0 and row['source_held'] and row['images']==images
    if expected==0:
        assert not row['engine_error'] and report['failures']==0 and len(observations)==images//3
        for o in observations:assert o['environments']==1 and o['hdr'] and o['glow'] and o['visible_prompts']==0 and o['actual_quality']==['low','medium','high'].index(q) and o['restored_time_scale']==1
        pairs=list(report.get('lamp',{}).get('shots',{}).values())+([report['gun']] if 'gun' in report else [])
        for pair in pairs:
            assert pair['aa_identical'] and pair['size']==[1280,720]
            if q=='low':assert pair['lights']==0 and pair['shadowed_share']==0
            else:assert pair['lights']>0 and pair['silhouette_share']>0 and pair['shadowed_share']>=.001
        if 'gun' in report:assert report['gun']['enemies']==3 and report['gun']['actors']['valid']
    else:assert row['engine_error'] and report['failures']>0
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'all_passed':True},indent=2)+'\n')
