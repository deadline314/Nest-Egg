from pathlib import Path
import json,re,shutil,subprocess
root=Path('C:/Users/stanl/Github/Nest-Egg');b=Path('D:/NestEggVerification/evidence-20261117/bg34-current');dest=root/'pm/Nest-Egg-BG/attachments/BG-34-current-2026-11-17'
assert not dest.exists()
checks=(b/'checks-restored/changed/raw.log').read_text(encoding='utf8')
match=re.search(r'checks: (\d+), new failures: 0, known failures \(tests/known_failures.txt\): 0\s+\(wall time (\d+) s\)',checks);assert match
count,seconds=map(int,match.groups());perf=json.loads((b/'performance-capped/runs.json').read_text());ratios=[r['ratio_exact'] for r in perf]
assert len(ratios)==3 and all(v<=1.08 for v in ratios)
dest.mkdir()
for p in (b/'delivery-packet-v2').iterdir():shutil.copy2(p,dest/p.name)
(dest/'.gitattributes').write_text('* -text -whitespace\n')
manifest=json.loads((dest/'manifest.json').read_text());cadence=json.loads((b/'cadence/result.json').read_text())
text=f'''# BG-34 當前牆面投影驗收

Godot 4.7.2、RX 9070 XT、Forward+／Vulkan、HDR 2D、原生 1280×720。本次修正人物互動提示與指示線被一起投到牆上的缺陷，並限制超高 FPS 下的多餘輪廓重畫。保留原半解析度輪廓圖、光源數、著色器、背牆範圍與投影形狀；每三格檢查，距上次不足 8333 微秒時延後一輪。相機縮放改變及保持時間的攝影同步仍立即更新。

原程式的互動提示與指示線會進入身體輪廓。無頭紅控制確認兩者皆被標成投影層；修正後兩者皆不投影，身體仍投影。原生 NPC 對照刻意保留可見的「E 和老 K 說話」，提示不再留下巨大文字影子。人物直接畫在身體節點上的小對話泡泡，以及既有敵人頭上標記，仍屬原身體畫面；本次沒有重做這些世界圖示。

攝影沿用共用光影與接觸陰影同步，加入正式後製、持續停用提示、固定引擎時間、相同狀態 A/A 比對與寫檔結果檢查，保留實際雨景。原街道單靠 SceneTree 暫停時 A/A 不相同；最終 15 組正式開／關對照的 A/A 原圖皆逐位元相同。原公式的每三像素取樣、0.004 暗底、20% 明暗比較與 0.001 門檻完全保留。

最終展示為三種實際讀回的品質：倉庫槍燈照三名敵人，街道路燈左／正下方／右，以及街道槍燈照三名敵人，共 45 張完整原圖。低品質牆影關閉、開關原圖完全相同；中品質最多兩盞、高品質最多四盞。三名敵人均須實際落地且包含變形骨架與武器的範圍完整入鏡；範圍檢查不等於沒有前景遮擋，倉庫中間敵人仍被原場景的一部分前景物件遮住。

原瞄準鏡頭朝燈偏移，會把背光側投影推出畫面；路燈三個站位改用同一個以光源置中的原生鏡頭。早期倉庫與當舖高吊燈、街道右側舊鏡頭未達門檻的紀錄保留，沒有當成通過。最終三個站位採用街道距地 78 像素的實際路燈。天空採街道原圖最上方 1280×60 的可見天空區，三品質九組開關皆完全相同；另有空背牆支撐範圍的結構負控制，兩者分開解讀。

額外 15 組隔離對照使用真正的主角、NpcActor、塑膠椅 PropNode，以及 heavy_gunner 原 EnemyGlow：身體投影層逐個隔離，兩個受控點光源分別位於左右、同時亮或全關；投影方向與兩側輪廓可在原圖比較。敵人自帶光源的半徑、能量與頭部錨點保留原資料，改用 NPC 右側 40 像素的位置驗證；先前左側 52 像素配置的身體影子未被量到，失敗亦保留。光源全關及無背牆時開／關原圖完全相同。這些是刻意安排的原生測試場景，並非自然通關或整場戰鬥。

效能原量測為 110.608%，超過原 108% 上限。重複參數快取與背牆直條合併分別仍為 110.028%／110.123%，未見足夠收益，因此均移除。另用官方 RenderingServer 的 viewport CPU／GPU 計數定位輪廓重畫成本；計數只在 45 格組別之間讀取，該診斷不作正式效能結果。[官方計數範圍與限制](https://docs.godotengine.org/en/stable/classes/class_renderingserver.html#class-renderingserver-method-viewport-get-measured-render-time-cpu)。

最終三個獨立程序維持原 60 組成對交替、每側 45 格、關垂直同步與 FPS 上限；未取整的中位比值為 {ratios[0]:.12f}、{ratios[1]:.12f}、{ratios[2]:.12f}，全部小於 1.08。保留 16,200 個實際影格間隔，讀取器獨立重算。每輪前後確認 12 名敵人都在地面且完整入鏡，原生鏡頭倍率保持；敵人按原探針配置停止偵測、攻擊與行走，角色動畫、物理及接觸傷害仍運作，主角會被接觸擊退。這是同一現況開／關整個牆影功能的成本，不是歷史完整版本、12 名戰鬥 AI 或靜止整個遊戲的基準。量測前後無其他 Godot 程序，持有共用 GPU 鎖，與其他測試及截圖分開執行。

原十次進出檢查的節點皆為 97，貼圖記憶體監測皆為 182.82 MiB，沒有累積。這是引擎貼圖記憶體估計，並非實體 VRAM 或整個程序記憶體。

另以合成鍵盤動作在原生場景移動與跳躍，記錄四種 FPS 上限各 180 格、共 720 筆重畫時刻及位置，附四張原圖。60／144 上限實測約 59.69／129.22 FPS，重畫每三格；240 上限實測約 206.49 FPS，短暫突發時為三格或六格；無上限實測約 536.40 FPS，每六格。重畫實際間隔皆至少 8333 微秒。原讀取器錯把「240 上限」當成每一段都穩定 240 FPS，要求全程三格而拒絕；按實際時刻及原本就要限制突發的規則重新核對同一批原始資料，沒有改遊戲或效能門檻。這不是實體鍵盤／手把驗收，也沒有把四張照片當成逐格影片。

最終原 run_tests_changed.sh 以 c6eaec5f 為基準重跑 37 組、四個程序：{count} 項檢查，新失敗 0、已知失敗 0，{seconds} 秒；另八項地面站位與原影子公式自檢全過。第一次兩程序測試的 SoundStage 失敗，原因為稀疏驗證 checkout 漏帶原 design/16-audio/PLACEMENTS.md；確認後停止該無效批次的剩餘自有程序，補回與 c6 原提交一致的清單，再完整重跑。沒有為此改正式音效工具或加入已知失敗。最終來源守衛共 10,088 份，包含該實際執行依賴。

最終第一章正常／最暗、低／高的 72 點重新執行，附全部實際 640×360 圖，主角 0.6、地面 1.0、適用敵人 0.45 皆通過。沒有以優化前的 72 點代替。正式原生正常程序均自然 exit0、無 ERROR／SCRIPT ERROR；寫圖失敗、只有一名敵人與故意遺失敵人資料三個負控制均自然 exit1、無 SCRIPT ERROR，保留具體錯誤與成功寫出的診斷圖。遺失資料使用只替換一個路徑常數的私人副本，未破壞正式資料。

已實際查看最終 14 頁對照與可讀性、關鍵完整原圖、三張 12 名敵人效能場景及四張移動場景。早期失敗與被取代的量測 metadata／log 保留，整批舊 PNG 不重複公開；私人設定與匯入快取不打包。evidence.zip 共 {len(manifest['members'])} 成員、{manifest['bytes']:,} bytes。`verify.py` 使用 Python 3 與既有 Pillow，核對雜湊、實際 PNG 像素、15 組 A/A、原門檻、天空、15 組隔離對照、720 筆重畫時刻、16,200 格成本、重進資源與 72 點可讀性；實際翻轉 ZIP 位元亦被拒絕。
'''
(dest/'RootReview.md').write_text(text,encoding='utf8',newline='\n')
images=root/'pm/Nest-Egg-BG/images/BG-34-20261117';images.mkdir(exist_ok=False)
for p in sorted((b/'review-capped').glob('*.png')):shutil.copy2(p,images/p.name)
ticket=next((root/'pm/Nest-Egg-BG').glob('[[]BG-34[]]*.md'));s=ticket.read_text(encoding='utf8');assert '> 狀態：進行中' in s and '# Commit-2' not in s
s=s.replace('> 狀態：進行中','> 狀態：完成',1)
s+=f'''

# Commit-2

## 內文

人物互動提示與指示線原本會被一起投到背牆，現在保留提示顯示，也不會出現文字形狀的影子。超高幀率下減少重複重畫輪廓，維持投影解析度、光源、方向與原效能上限。

在 RX 9070 XT 重新驗收路燈左／正下方／右、槍燈照三名敵人、人物與地面擺設、敵人自帶光源、雙光源及熄燈。低品質保留腳下陰影、關閉牆影；天空沒有投影。攝影保持同一畫面，無法寫圖或敵人數量不足時都正確失敗退出。

### 測試結果

| 項目 | 結果 |
|---|---|
| 原受影響測試 | 37 組、{count:,} 項檢查，新失敗 0、已知失敗 0 |
| 原生三品質對照 | 15 組、45 張完整原圖；相同狀態連拍完全一致 |
| 身體與光源隔離對照 | 15 組，人物提示不投影，熄燈與無背牆負控制通過 |
| 十二名敵人每格成本 | 三輪 {ratios[0]*100:.2f}%／{ratios[1]*100:.2f}%／{ratios[2]*100:.2f}%，皆低於 108% |
| 十次進出 | 節點 97、貼圖監測 182.82 MiB，未累積 |
| 重畫節奏 | 四種幀率上限共 720 筆實際時刻，間隔與突發限制相符 |
| 正常／最暗可讀性 | 第一章低／高共 72 點重新執行，全部達標 |
| 負控制與資料核對 | 寫圖失敗、敵人不足與資料遺失皆正確失敗；實際 ZIP 損壞被拒絕 |

[原圖、逐格資料、測試與獨立核對](attachments/BG-34-current-2026-11-17/RootReview.md)。效能為十二名安排在畫面內的敵人，角色動畫與接觸仍運作，牆影開／關成對比較。

### 截圖

![高品質路燈與槍燈：關、開與差異](images/BG-34-20261117/native-3.png)

![中品質路燈與槍燈：關、開與差異](images/BG-34-20261117/native-2.png)

![人物、擺設與光源的隔離對照](images/BG-34-20261117/causality-3.png)
'''
ticket.write_text(s,encoding='utf8',newline='\n')
r=subprocess.run(['D:/ComfyUI/.venv-rocm/Scripts/python.exe','-X','utf8',str(dest/'verify.py'),str(dest)],capture_output=True);(b/'promoted-reader.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr.decode()
paths=['tools/wall_shadow_probe.gd','game/level/environment/wall_shadows.gd','tests/suite/test_environment.gd','design/08-lighting/LIGHT_SOURCES.md',ticket.relative_to(root).as_posix()]+[p.relative_to(root).as_posix() for p in sorted(dest.iterdir())]+[p.relative_to(root).as_posix() for p in sorted(images.iterdir())]
(root/'work/bg34-stage-paths.json').write_text(json.dumps(paths,indent=2)+'\n');print(json.dumps({'paths':len(paths),'public_reader_exit':0,'status':'complete'}),flush=True)
