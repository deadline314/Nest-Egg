from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg34-current');b.mkdir(exist_ok=True);out=b/'before-street';out.mkdir()
private=root/'work/bg34-before-street';private.mkdir(exist_ok=False)
(private/'observer.gd').write_text('''extends "res://tools/wall_shadow_probe.gd"
func _pair(shadows: WallShadows, name: String) -> Dictionary:
    var mode := shadows.process_mode
    shadows.process_mode = Node.PROCESS_MODE_ALWAYS
    get_tree().paused = true
    await _settle(8)
    var first := Capture.image(get_viewport())
    await _settle(8)
    var second := Capture.image(get_viewport())
    first.save_png(_out.path_join("diagnostic-aa-first.png"))
    second.save_png(_out.path_join("diagnostic-aa-second.png"))
    var aa := _shadowed_share(first,second)
    get_tree().paused = false
    shadows.process_mode = mode
    var prompts := 0
    for node: Node in get_tree().root.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    print("BG34_BEFORE ",JSON.stringify({"environments":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),
        "hdr":get_viewport().use_hdr_2d,"visible_prompts":prompts,"actual_quality":Settings.get_light_quality(),
        "aa_identical":first.get_data()==second.get_data(),"aa_shadowed_share":aa,"time_scale":Engine.time_scale,
        "image_size":[first.get_width(),first.get_height()]}))
    return await super._pair(shadows,name)
''',encoding='utf8',newline='\n')
(private/'observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg34-before-street/observer.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
source=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg35-current/native-quality-final/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source}
before=snapshot();assert before==source
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name,q in [('normal','high')]:
    folder=out/name;folder.mkdir(exist_ok=False);env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    if name=='write-failure':
        for mode in ['on','off']:(folder/('walls-gun-'+mode+'.png')).mkdir()
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg34-before-street/observer.tscn','--','--out='+str(folder),'--level=ch1_street','--mode=gun','--at=10','--quality='+q]
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();observations=[json.loads(l.split(b'BG34_BEFORE ',1)[1]) for l in raw.splitlines() if l.startswith(b'BG34_BEFORE ')]
    row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'main_images':len([p for p in folder.glob('walls-*.png') if p.is_file()]),'observations':observations}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert row['script_errors']==0 and row['source_held'] and observations and observations[0]['environments']==0
    if name=='write-failure':assert row['exit']==0 and row['engine_error'] and row['main_images']==0
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'missing_environment_reproduced':True,'scope':'street-only same-state A/A; separate before driver contains write-failure calibration'},indent=2)+'\n')
