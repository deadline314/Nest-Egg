from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg34-current');out=b/'causality-product-v2';out.mkdir(exist_ok=False)
private=root/'work/bg34-causality-product-v2';private.mkdir(exist_ok=False)
(private/'probe.gd').write_text('''extends "res://tools/wall_shadow_probe.gd"
var records: Array[Dictionary] = []
func check(value: bool, label: String) -> void:
    if not value:
        push_error("BG34_CAUSAL " + label)
        _failures += 1
func keep_only(target: CanvasItem) -> void:
    for owner: Node in get_tree().get_nodes_in_group(WallShadows.CASTER_GROUP):
        if owner == target: continue
        for node: Node in [owner] + owner.find_children("*","",true,false):
            if node is CanvasItem: (node as CanvasItem).visibility_layer &= ~WallShadows.CASTER_LAYER
func take(level: Level, wall: WallShadows, tag: String, expected_lights: int) -> void:
    wall.suspended = false
    HeldLighting.sync(level)
    await _settle(8)
    var aa := Capture.image(get_viewport())
    HeldLighting.sync(level)
    await _settle(8)
    var on := Capture.image(get_viewport())
    var count := wall.active_lights()
    var mask := wall.silhouette()
    if mask != null: check(mask.get_image().save_png(_out.path_join(tag+"-mask.png"))==OK,tag+" mask save")
    var snapshot := HeldLighting.snapshot(level)
    var prompt_records: Array[Dictionary] = []
    for node: Node in level.find_children("*","",true,false):
        if node is WorldPrompt:
            check((node.visibility_layer & WallShadows.CASTER_LAYER)==0,tag+" prompt layer")
            prompt_records.append({"visible":node.is_visible_in_tree(),"casts":(node.visibility_layer & WallShadows.CASTER_LAYER)!=0})
    snapshot["prompt_records"] = prompt_records
    wall.suspended = true
    HeldLighting.sync(level)
    await _settle(8)
    var off := Capture.image(get_viewport())
    for pair: Array in [[aa,"aa"],[on,"on"],[off,"off"]]:
        check((pair[0] as Image).save_png(_out.path_join(tag+"-"+pair[1]+".png"))==OK,tag+" image save")
    var delta := _shadowed_share(on,off)
    check(aa.get_data()==on.get_data(),tag+" A/A held")
    check(count==expected_lights,tag+" actual source count")
    check(on.get_data()==off.get_data() if expected_lights==0 else delta>0.0,tag+" shadow presence")
    records.append({"tag":tag,"lights":count,"aa_identical":aa.get_data()==on.get_data(),"on_off_identical":on.get_data()==off.get_data(),"shadowed_share":delta,"snapshot":snapshot})
    wall.suspended = false
func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(LightQuality.Tier.HIGH)
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    Story._layer.hide()
    var level := await _open(load("res://data/levels/ch1_warehouse.tres") as LevelData)
    _at = 70
    var feet := _stand(level)
    await _place_player(level,feet,Vector2.RIGHT)
    var npc := NpcActor.new()
    npc.configure(load("res://data/npcs/ch1_old_k.tres") as NpcData,Vector2i(70,49))
    npc.position = feet
    level._entities.add_child(npc)
    var prop_data := load("res://data/environment/scene_props/dawn_noodle_stall/dawn_noodle_stall__stool_stack.tres") as PropData
    var prop := PropNode.new()
    prop.setup(prop_data,feet-Vector2(prop_data.size.x*0.5,prop_data.size.y))
    level._entities.add_child(prop)
    var heavy_data := (load("res://data/enemies/heavy_gunner.tres") as EnemyData).duplicate() as EnemyData
    heavy_data.detect_range=0;heavy_data.attack_range=0;heavy_data.move_speed=0
    var heavy := level._create_enemy(heavy_data)
    heavy.data=heavy_data;heavy.position=feet+Vector2(40,-2)
    level._entities.add_child(heavy)
    var actors: Array[Enemy] = [heavy]
    await _wait_for_ground(actors,60)
    check(heavy.is_on_floor(),"heavy gunner actual floor")
    var wall := level.find_child("WallShadows",true,false) as WallShadows
    HeldLighting.preserve_physics_bodies(level)
    level.process_mode = Node.PROCESS_MODE_DISABLED
    Engine.time_scale = 0
    var camera := get_viewport().get_camera_2d()
    camera.position_smoothing_enabled=false;camera.offset=Vector2.ZERO
    camera.global_position=feet+Vector2(0,-38);camera.force_update_scroll()
    for node: Node in level.find_children("*","",true,false):
        if node is WorldPrompt: node.hide()
    for group: StringName in [LightKit.SCENE_LIGHTS,LightKit.AIMED_LIGHTS]:
        for light: Node in get_tree().get_nodes_in_group(group):
            if light is PointLight2D: light.enabled=false
    var left := LightKit.create_point_light(Color.WHITE,200,1.2,false)
    level.add_child(left);left.global_position=feet+Vector2(-56,-40)
    var right := LightKit.create_point_light(Color.WHITE,200,1.2,false)
    level.add_child(right);right.global_position=feet+Vector2(56,-40);right.enabled=false
    HeldLighting.sync(level)
    await _settle(8)
    var original_layers := {}
    for node: Node in level.find_children("*","CanvasItem",true,false): original_layers[node.get_instance_id()] = node.visibility_layer
    for target: CanvasItem in [level.player,npc,prop]:
        for id: int in original_layers:
            var node := instance_from_id(id) as CanvasItem
            node.visibility_layer=original_layers[id]
        level.player.visible=target==level.player;npc.visible=target==npc;prop.visible=target==prop
        heavy.hide()
        keep_only(target)
        var label := "player" if target==level.player else ("npc" if target==npc else "prop")
        left.enabled=true;right.enabled=false
        await take(level,wall,label+"-left",1)
        left.enabled=false;right.enabled=true
        await take(level,wall,label+"-right",1)
        left.enabled=true
        await take(level,wall,label+"-two",2)
        left.enabled=false;right.enabled=false
        await take(level,wall,label+"-off",0)
    # Actual EnemyGlow source and authored energy/radius/anchor; only target NPC casts.
    npc.show();prop.hide();heavy.show();level.player.hide()
    for id: int in original_layers:
        var node := instance_from_id(id) as CanvasItem
        node.visibility_layer=original_layers[id]
    keep_only(npc)
    var glow := heavy.find_child("EnemyGlow",true,false) as EnemyGlow
    check(glow != null,"authored EnemyGlow exists")
    glow.light().enabled=true
    await take(level,wall,"npc-enemy-light",1)
    glow.light().enabled=false
    await take(level,wall,"npc-enemy-off",0)
    left.enabled=true
    wall.setup([]);wall._apply_quality()
    await take(level,wall,"npc-no-backwall",0)
    Engine.time_scale=1
    level.queue_free()
    await _settle(8)
    var writer := FileAccess.open(_out.path_join("causal-index.json"),FileAccess.WRITE)
    check(writer != null,"index writable")
    if writer != null:
        writer.store_string(JSON.stringify({"failures":_failures,"records":records,"scope":"Arranged actual player/NpcActor/PropNode and actual heavy_gunner EnemyGlow; isolated caster layer, controlled two point lights; empty support rects are a no-backwall control."},"  "));writer.close()
    await AudioRelease.settle(get_tree())
    get_tree().quit(0 if _failures==0 else 1)
''',encoding='utf8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg34-causality-product-v2/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
source=json.loads((b/'checks-product/source-before.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source}
before=snapshot();assert before==source
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy()
for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(out/'private-profile'/k)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg34-causality-product-v2/probe.tscn','--','--out='+str(out)]
with (out/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
raw=(out/'raw.log').read_bytes();result={'exit':r.returncode,'command':command,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':snapshot()==before}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');print(json.dumps(result));print(raw.decode('utf8',errors='replace')[-4500:])
assert r.returncode==0 and not result['engine_error'] and result['source_held']
