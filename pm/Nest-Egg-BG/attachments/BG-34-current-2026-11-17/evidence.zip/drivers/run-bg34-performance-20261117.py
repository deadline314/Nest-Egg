from pathlib import Path
import hashlib,json,os,subprocess,statistics,time
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg34-current');out=b/'performance';out.mkdir(exist_ok=False)
source=json.loads((b/'checks-product/source-before.json').read_text())
source['design/16-audio/PLACEMENTS.md']=hashlib.sha256((root/'design/16-audio/PLACEMENTS.md').read_bytes()).hexdigest()
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source}
def processes():
    command=['powershell','-NoProfile','-Command',"@(Get-CimInstance Win32_Process -Filter \"Name LIKE 'Godot%'\" | Select-Object ProcessId,Name,CommandLine) | ConvertTo-Json -Compress"]
    raw=subprocess.check_output(command).decode('utf8-sig').strip()
    return json.loads(raw) if raw else []
before=snapshot();assert before==source
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for trial in range(3):
    folder=out/('high-'+str(trial+1));folder.mkdir(exist_ok=False)
    idle=processes();assert not idle,idle
    env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://tools/wall_shadow_probe.tscn','--','--out='+str(folder),'--level=ch1_warehouse','--mode='+('perf,reenter' if trial==0 else 'perf'),'--at=70','--quality=high']
    start=time.time()
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();report=json.loads((folder/'walls-index.json').read_text());after_idle=processes()
    perf=report['perf'];pairs={}
    for group in perf.get('groups',[]):
        assert len(group['frames_ms'])==45
        assert all(0<x<10000 for x in group['frames_ms'])
        pairs.setdefault(group['round'],{})[group['enabled']]=statistics.median(group['frames_ms'])
    ratios=[v[True]/v[False] for v in pairs.values()]
    exact=statistics.median(ratios) if ratios else None
    if exact is not None:assert abs(exact-perf['ratio_exact'])<1e-10
    row={'trial':trial+1,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'processes_before':idle,'processes_after':after_idle,'seconds':time.time()-start,'ratio_exact':exact,'frames':len(pairs)*90,'actor_valid':perf.get('actors_before',{}).get('valid',False) and perf.get('actors_after',{}).get('valid',False),'failures':report['failures']}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode('utf8',errors='replace')[-1200:],flush=True)
    assert row['exit']==row['script_errors']==0 and not row['engine_error'] and row['source_held'] and not after_idle and row['actor_valid'] and row['frames']==5400 and exact<=1.08
    if trial==0:
        re=report['reenter'];assert len(re['nodes'])==len(re['texture_mib'])==10 and not re['accumulates']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'all_passed':True},indent=2)+'\n')
