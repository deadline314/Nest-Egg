from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg34-current');out=b/'held-smoke';out.mkdir(exist_ok=False)
source=json.loads((b/'before/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source}
before=snapshot();assert [p for p in source if source[p]!=before[p]]==['tools/wall_shadow_probe.gd']
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for level,col in [('ch1_warehouse',70),('ch1_street',10)]:
    folder=out/level;folder.mkdir(exist_ok=False);env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://tools/wall_shadow_probe.tscn','--','--out='+str(folder),'--level='+level,'--mode=gun','--at='+str(col),'--quality=high']
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes();row={'level':level,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'images':len(list(folder.glob('*.png')))}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode(encoding='utf8',errors='replace')[-1500:],flush=True)
    assert row['exit']==row['script_errors']==0 and not row['engine_error'] and row['source_held'] and row['images']==3
    report=json.loads((folder/'walls-index.json').read_text());assert report['failures']==0 and report['gun']['enemies']==3 and report['gun']['aa_identical']
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'source_held':before==snapshot(),'all_passed':True},indent=2)+'\n')
