from pathlib import Path
import json,math
from PIL import Image,ImageChops,ImageEnhance,ImageDraw
b=Path('D:/NestEggVerification/evidence-20261117/bg34-current');out=b/'review-product';out.mkdir(exist_ok=True)
def pairs_page(pairs,prefix,per_page=5):
    for page in range(math.ceil(len(pairs)/per_page)):
        rows=pairs[page*per_page:(page+1)*per_page];sheet=Image.new('RGB',(1920,390*len(rows)),'#111111');draw=ImageDraw.Draw(sheet)
        for row,(label,on_path,off_path) in enumerate(rows):
            on=Image.open(on_path).convert('RGB');off=Image.open(off_path).convert('RGB')
            draw.text((8,row*390+5),label+' | shadow off / on / difference x4',fill='white')
            delta=ImageEnhance.Brightness(ImageChops.subtract(off,on)).enhance(4)
            for col,im in enumerate([off,on,delta]):sheet.paste(im.resize((640,360)),(col*640,row*390+25))
        sheet.save(out/(prefix+'-'+str(page+1)+'.png'))
if (b/'causality-product-v2/result.json').is_file():
    d=json.loads((b/'causality-product-v2/causal-index.json').read_text());assert d['failures']==0
    pairs_page([(r['tag']+f" delta={r['shadowed_share']}",b/'causality-product-v2'/(r['tag']+'-on.png'),b/'causality-product-v2'/(r['tag']+'-off.png')) for r in d['records']],'causality')
if (b/'native-product/result.json').is_file():
    pairs=[]
    for q in ['low','medium','high']:
        for level in ['ch1_warehouse','ch1_street']:
            folder=b/'native-product'/(q+'-'+level);d=json.loads((folder/'walls-index.json').read_text());assert d['failures']==0
            shots={**{'lamp-'+k:v for k,v in d.get('lamp',{}).get('shots',{}).items()},'gun':d['gun']}
            for tag,r in shots.items():pairs.append((q+' '+level+' '+tag+f" delta={r['shadowed_share']}",folder/('walls-'+tag+'-on.png'),folder/('walls-'+tag+'-off.png')))
    pairs_page(pairs,'native')
if (b/'readability-final/result.json').is_file():
    for case in ['normal-low','normal-high','dim-low','dim-high']:
        photos=sorted((b/'readability-final'/case).glob('*.png'));assert len(photos)==18
        for page in range(2):
            photos_page=photos[page*9:(page+1)*9];sheet=Image.new('RGB',(1920,385*3),'#111111');draw=ImageDraw.Draw(sheet)
            for i,p in enumerate(photos_page):
                x=(i%3)*640;y=(i//3)*385;draw.text((x+5,y+5),case+' '+p.name,fill='white');sheet.paste(Image.open(p).convert('RGB'),(x,y+25))
            sheet.save(out/('readability-'+case+'-'+str(page+1)+'.png'))
print(json.dumps({'review_pages':[p.name for p in out.glob('*.png')]}))
