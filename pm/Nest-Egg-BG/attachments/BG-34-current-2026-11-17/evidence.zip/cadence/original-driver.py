from pathlib import Path
import json,hashlib,os,subprocess,statistics
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg34-current');out=b/'cadence';out.mkdir(exist_ok=False);p=root/'work/bg34-cadence';p.mkdir(exist_ok=False)
(p/'probe.gd').write_text('''extends "res://tools/wall_shadow_probe.gd"
var moving := false
var motion_frame := 0
func _process(delta: float) -> void:
    super._process(delta)
    if not moving: return
    motion_frame += 1
    if motion_frame % 80 == 0:
        Input.action_release(&"move_left");Input.action_press(&"move_right")
    elif motion_frame % 80 == 40:
        Input.action_release(&"move_right");Input.action_press(&"move_left")
    if motion_frame % 160 == 0: Input.action_press(&"jump")
    elif motion_frame % 160 == 2: Input.action_release(&"jump")
func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(LightQuality.Tier.HIGH)
    Story.auto_skip=true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)]=true
    Story._layer.hide()
    var level := await _open(load("res://data/levels/ch1_warehouse.tres") as LevelData)
    _at=70
    var feet := _stand(level)
    await _place_player(level,feet,Vector2.RIGHT)
    var camera := get_viewport().get_camera_2d()
    camera.set_process(false);camera.set_physics_process(false);camera.position_smoothing_enabled=false;camera.offset=Vector2.ZERO
    camera.global_position=feet+Vector2(0,-45);camera.force_update_scroll()
    var wall := level.find_child("WallShadows",true,false) as WallShadows
    var old_fps := Engine.max_fps
    var old_vsync := DisplayServer.window_get_vsync_mode()
    DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
    var groups: Array[Dictionary] = []
    moving=true
    for cap: int in [60,144,240,0]:
        Engine.max_fps=cap
        await _settle(30)
        var frames: Array[Dictionary] = []
        for i in 180:
            await get_tree().process_frame
            frames.append({"now_usec":Time.get_ticks_usec(),"wall_frame":wall._frame,"draw_usec":wall._last_draw_usec,
                "player":[level.player.global_position.x,level.player.global_position.y],"on_floor":level.player.is_on_floor()})
        await RenderingServer.frame_post_draw
        if Capture.image(get_viewport()).save_png(_out.path_join("motion-"+str(cap)+".png")) != OK: _failures+=1
        groups.append({"cap":cap,"frames":frames})
    moving=false
    for action: StringName in [&"move_left",&"move_right",&"jump"]: Input.action_release(action)
    Engine.max_fps=old_fps
    DisplayServer.window_set_vsync_mode(old_vsync)
    level.queue_free()
    await _settle(8)
    var file := FileAccess.open(_out.path_join("cadence-index.json"),FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify({"groups":groups,"failures":_failures,"scope":"Native motion via synthetic keyboard actions; exact wall redraw stamps; fixed native camera. Not a physical keyboard or joypad acceptance."},"  "));file.close()
    else: _failures+=1
    await AudioRelease.settle(get_tree())
    get_tree().quit(0 if _failures==0 else 1)
''',encoding='utf8')
(p/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg34-cadence/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
source=json.loads((b/'capped-candidate-source.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source}
before=snapshot();assert before==source
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');env=os.environ.copy()
for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(out/'private-profile'/k)
command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720','res://work/bg34-cadence/probe.tscn','--','--out='+str(out)]
with (out/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
raw=(out/'raw.log').read_bytes();after=snapshot();result={'exit':r.returncode,'command':command,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==after,'cases':[]}
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert r.returncode==0 and b'ERROR:' not in raw and before==after
for group in json.loads((out/'cadence-index.json').read_text())['groups']:
    frames=group['frames'];draws=[(row['wall_frame'],row['draw_usec']) for i,row in enumerate(frames) if i and row['draw_usec']!=frames[i-1]['draw_usec']]
    gaps=[bb[0]-a[0] for a,bb in zip(draws,draws[1:])];intervals=[bb[1]-a[1] for a,bb in zip(draws,draws[1:])]
    fps=(len(frames)-1)*1e6/(frames[-1]['now_usec']-frames[0]['now_usec'])
    row={'cap':group['cap'],'observed_fps':fps,'redraw_frame_gaps':sorted(set(gaps)),'redraw_min_usec':min(intervals),'frames':len(frames),'motion_x_span':max(r['player'][0] for r in frames)-min(r['player'][0] for r in frames),'motion_y_span':max(r['player'][1] for r in frames)-min(r['player'][1] for r in frames)}
    result['cases'].append(row)
    assert min(intervals)>=8333 and all(g>=3 and g%3==0 for g in gaps)
    if group['cap']>0:assert group['cap']*.8<=fps<=group['cap']*1.1 and all(g==3 for g in gaps)
    else:assert fps>360 and any(g>3 for g in gaps)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
