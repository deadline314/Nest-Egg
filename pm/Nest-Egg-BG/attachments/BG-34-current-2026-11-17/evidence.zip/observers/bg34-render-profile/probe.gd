extends "res://tools/wall_shadow_probe.gd"
var observed_wall: WallShadows
func _open(data: LevelData) -> Level:
    var level := await super._open(data)
    observed_wall = level.find_child("WallShadows",true,false) as WallShadows
    RenderingServer.viewport_set_measure_render_time(get_viewport().get_viewport_rid(),true)
    RenderingServer.viewport_set_measure_render_time(observed_wall._viewport.get_viewport_rid(),true)
    print("BG34_DRAW_GEOMETRY ",JSON.stringify({"original":level._scenery_walls.support_rects.size(),"merged":observed_wall._rects.size()}))
    return level
func _frame_ms() -> float:
    var result := await super._frame_ms()
    var root_rid := get_viewport().get_viewport_rid()
    var mask_rid := observed_wall._viewport.get_viewport_rid()
    print("BG34_RENDER_PROFILE ",JSON.stringify({"enabled":not observed_wall.suspended,"frame_median":result,
        "main_cpu_ms":RenderingServer.viewport_get_measured_render_time_cpu(root_rid),"main_gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(root_rid),
        "mask_cpu_ms":RenderingServer.viewport_get_measured_render_time_cpu(mask_rid),"mask_gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(mask_rid),
        "main_calls":RenderingServer.viewport_get_render_info(root_rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_CANVAS,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME),
        "mask_calls":RenderingServer.viewport_get_render_info(mask_rid,RenderingServer.VIEWPORT_RENDER_INFO_TYPE_CANVAS,RenderingServer.VIEWPORT_RENDER_INFO_DRAW_CALLS_IN_FRAME)}))
    return result
