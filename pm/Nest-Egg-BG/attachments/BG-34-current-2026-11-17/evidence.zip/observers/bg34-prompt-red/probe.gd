extends Node
func _ready() -> void:
    var body := Node2D.new()
    var prompt := WorldPrompt.new()
    var leader := Node2D.new()
    prompt.add_child(leader);body.add_child(prompt)
    var wall := WallShadows.new()
    wall._flag_branch(body)
    var record := {"body_casts":(body.visibility_layer & WallShadows.CASTER_LAYER)!=0,"prompt_casts":(prompt.visibility_layer & WallShadows.CASTER_LAYER)!=0,"leader_casts":(leader.visibility_layer & WallShadows.CASTER_LAYER)!=0}
    print("BG34_PROMPT_CONTROL ",JSON.stringify(record))
    var okay: bool = record.body_casts and not record.prompt_casts and not record.leader_casts
    body.free();wall.free()
    get_tree().quit(0 if okay else 1)
