extends Node
var failures := 0
var checks := 0
func check(value: bool, label: String) -> void:
    checks += 1
    if not value:
        failures += 1
        push_error("BG34_SELFCHECK " + label)
func _ready() -> void:
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    GameState.start_new_run(GameState.difficulties[1])
    var data := (load("res://data/levels/ch1_warehouse.tres") as LevelData).duplicate() as LevelData
    data.intro_scene = &""
    data.show_chapter_card = false
    data.complete_after_intro = false
    var level := Level.new()
    level.configure(data)
    add_child(level)
    for i in 20: await get_tree().process_frame
    var before := load("res://work/bg34-checks-final/before.gd").new() as Node
    var current := load("res://tools/wall_shadow_probe.gd").new() as Node
    var original := level.player.global_position
    var found := false
    for col in range(10,level._layout.width-10):
        before._at = col
        current._at = col
        level.player.global_position = original
        var old_first: Vector2 = before._stand(level)
        var first: Vector2 = current._stand(level)
        level.player.global_position.y -= 128.0
        var old_second: Vector2 = before._stand(level)
        var second: Vector2 = current._stand(level)
        if old_first.is_finite() and old_second.is_finite() and old_first != old_second:
            check(old_first != old_second,"counterfactual old input changed floor")
            check(first==second,"fixed --at floor ignores previous fixture height")
            check(first==old_first,"initial floor selection preserved")
            print("BG34_FLOOR ",JSON.stringify({"column":col,"old_first":[old_first.x,old_first.y],"old_second":[old_second.x,old_second.y],"new":[first.x,first.y]}))
            found = true
            break
    check(found,"real multi-height fixture found")
    level.player.global_position = original
    var a := Image.create(6,6,false,Image.FORMAT_RGBA8)
    var c := Image.create(6,6,false,Image.FORMAT_RGBA8)
    a.fill(Color(.2,.2,.2));c.fill(Color(.8,.8,.8))
    check(current._shadowed_share(a,a)==0,"identical images have no shadow delta")
    check(current._shadowed_share(a,c)==1,"real darkening counted")
    check(current._shadowed_share(c,a)==-1,"reverse darkening subtracted")
    a.fill(Color.BLACK);c.fill(Color(1.0/255.0,1.0/255.0,1.0/255.0))
    check(current._shadowed_share(a,c)==0,"unchanged dark floor skips near black")
    before.free();current.free();level.queue_free()
    for i in 8: await get_tree().process_frame
    print("BG34_SELFCHECK checks=",checks," failures=",failures)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0 if failures==0 else 1)
