extends "res://tools/wall_shadow_probe.gd"
func _ready() -> void:
    if OS.get_cmdline_user_args().has("--preexisting-environment"):
        add_child(LightKit.create_environment())
    super._ready()
func _pair(shadows: WallShadows, name: String) -> Dictionary:
    var result := await super._pair(shadows,name)
    var prompts := 0
    for node: Node in get_tree().root.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    var environment := get_viewport().find_world_3d().environment
    var record := {"name":name,"environments":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),
        "hdr":get_viewport().use_hdr_2d,"glow":environment != null and environment.glow_enabled,
        "visible_prompts":prompts,"actual_quality":Settings.get_light_quality(),"restored_time_scale":Engine.time_scale}
    print("BG34_NATIVE ",JSON.stringify(record))
    return result
