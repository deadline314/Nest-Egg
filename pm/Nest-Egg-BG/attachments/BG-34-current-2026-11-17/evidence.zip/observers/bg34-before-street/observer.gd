extends "res://tools/wall_shadow_probe.gd"
func _pair(shadows: WallShadows, name: String) -> Dictionary:
    var mode := shadows.process_mode
    shadows.process_mode = Node.PROCESS_MODE_ALWAYS
    get_tree().paused = true
    await _settle(8)
    var first := Capture.image(get_viewport())
    await _settle(8)
    var second := Capture.image(get_viewport())
    first.save_png(_out.path_join("diagnostic-aa-first.png"))
    second.save_png(_out.path_join("diagnostic-aa-second.png"))
    var aa := _shadowed_share(first,second)
    get_tree().paused = false
    shadows.process_mode = mode
    var prompts := 0
    for node: Node in get_tree().root.find_children("*","",true,false):
        if node is WorldPrompt and node.is_visible_in_tree(): prompts += 1
    print("BG34_BEFORE ",JSON.stringify({"environments":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),
        "hdr":get_viewport().use_hdr_2d,"visible_prompts":prompts,"actual_quality":Settings.get_light_quality(),
        "aa_identical":first.get_data()==second.get_data(),"aa_shadowed_share":aa,"time_scale":Engine.time_scale,
        "image_size":[first.get_width(),first.get_height()]}))
    return await super._pair(shadows,name)
