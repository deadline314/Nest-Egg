extends "res://tools/wall_shadow_probe.gd"
func _ready() -> void:
    Story.auto_skip=true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)]=true
    for id: String in ["ch1_warehouse","ch1_street","ch1_pawnshop","ch1_lounge","ch1_vault","ch1_clinic"]:
        var level := await _open(load("res://data/levels/"+id+".tres") as LevelData)
        var lamps: Array[Dictionary] = []
        for node: Node in level.find_children("*","",true,false):
            if node is Lamp and not node.dead: lamps.append({"at":[node.position.x,node.position.y],"height":node.floor_y-node.position.y})
        print("BG34_SOURCES ",JSON.stringify({"level":id,"selected":_pick_source(level),"lamps":lamps}))
        level.queue_free()
        await _settle(4)
    await AudioRelease.settle(get_tree())
    get_tree().quit()

func _settle(frames: int) -> void:
    for i in frames: await get_tree().process_frame
