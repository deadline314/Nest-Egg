extends "res://tools/wall_shadow_probe.gd"
var moving := false
var motion_frame := 0
func _process(delta: float) -> void:
    super._process(delta)
    if not moving: return
    motion_frame += 1
    if motion_frame % 80 == 0:
        Input.action_release(&"move_left");Input.action_press(&"move_right")
    elif motion_frame % 80 == 40:
        Input.action_release(&"move_right");Input.action_press(&"move_left")
    if motion_frame % 160 == 0: Input.action_press(&"jump")
    elif motion_frame % 160 == 2: Input.action_release(&"jump")
func _run() -> void:
    add_child(LightKit.create_environment())
    Settings.set_light_quality(LightQuality.Tier.HIGH)
    Story.auto_skip=true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)]=true
    Story._layer.hide()
    var level := await _open(load("res://data/levels/ch1_warehouse.tres") as LevelData)
    _at=70
    var feet := _stand(level)
    await _place_player(level,feet,Vector2.RIGHT)
    var camera := get_viewport().get_camera_2d()
    camera.set_process(false);camera.set_physics_process(false);camera.position_smoothing_enabled=false;camera.offset=Vector2.ZERO
    camera.global_position=feet+Vector2(0,-45);camera.force_update_scroll()
    var wall := level.find_child("WallShadows",true,false) as WallShadows
    var old_fps := Engine.max_fps
    var old_vsync := DisplayServer.window_get_vsync_mode()
    DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
    var groups: Array[Dictionary] = []
    moving=true
    for cap: int in [60,144,240,0]:
        Engine.max_fps=cap
        await _settle(30)
        var frames: Array[Dictionary] = []
        for i in 180:
            await get_tree().process_frame
            frames.append({"now_usec":Time.get_ticks_usec(),"wall_frame":wall._frame,"draw_usec":wall._last_draw_usec,
                "player":[level.player.global_position.x,level.player.global_position.y],"on_floor":level.player.is_on_floor()})
        await RenderingServer.frame_post_draw
        if Capture.image(get_viewport()).save_png(_out.path_join("motion-"+str(cap)+".png")) != OK: _failures+=1
        groups.append({"cap":cap,"frames":frames})
    moving=false
    for action: StringName in [&"move_left",&"move_right",&"jump"]: Input.action_release(action)
    Engine.max_fps=old_fps
    DisplayServer.window_set_vsync_mode(old_vsync)
    level.queue_free()
    await _settle(8)
    var file := FileAccess.open(_out.path_join("cadence-index.json"),FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify({"groups":groups,"failures":_failures,"scope":"Native motion via synthetic keyboard actions; exact wall redraw stamps; fixed native camera. Not a physical keyboard or joypad acceptance."},"  "));file.close()
    else: _failures+=1
    await AudioRelease.settle(get_tree())
    get_tree().quit(0 if _failures==0 else 1)
