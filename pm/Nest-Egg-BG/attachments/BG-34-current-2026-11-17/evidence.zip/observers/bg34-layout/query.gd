extends Node
func _ready() -> void:
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    GameState.start_new_run(GameState.difficulties[1])
    var data := (load("res://data/levels/ch1_warehouse.tres") as LevelData).duplicate() as LevelData
    data.intro_scene = &""
    data.show_chapter_card = false
    data.complete_after_intro = false
    var level := Level.new()
    level.configure(data)
    add_child(level)
    for i in 20: await get_tree().process_frame
    var layout := level._layout
    var row := maxi(0,int(level.player.global_position.y/layout.tile_size)-3)
    var results := []
    for col in range(10,layout.width-10):
        var x := col*layout.tile_size+8.0
        var y := layout.floor_below(col,row)
        if y==INF: continue
        var valid := true
        for offset: float in [56,90,124,-12,24,-36,48,-60,72,-84,96,-108,120,-132,144]:
            valid = valid and is_equal_approx(layout.floor_below(int((x+offset)/layout.tile_size),int(y/layout.tile_size)-3),y)
        valid = valid and level._scenery_walls.covers(Rect2(x-156,y-74,322,74))
        if valid: results.append({"column":col,"feet":[x,y]})
    print("BG34_LAYOUT ",JSON.stringify({"spawn":[level.player.global_position.x,level.player.global_position.y],"candidates":results}))
    level.queue_free()
    for i in 8: await get_tree().process_frame
    await AudioRelease.settle(get_tree())
    get_tree().quit(0 if not results.is_empty() else 1)
