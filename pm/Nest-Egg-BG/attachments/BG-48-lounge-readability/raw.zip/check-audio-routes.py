from pathlib import Path
import subprocess,json
base=Path('/workspace/Nest-Egg/work/batch1020b');godot='/workspace/Nest-Egg/work/ne279/Godot_v4.7-stable_linux.x86_64'
for name,key in [('lighting','lounge_front'),('harbor','harbor_approach')]:
 root=base/name;paths=[root/'data/audio/ambience.json',root/'data/audio/music.json'];saved=[p.read_bytes() for p in paths];candidate=[]
 for i,raw in enumerate(saved):
  d=json.loads(raw);target=d['profiles'] if i==0 else d['map']['zones'];del target[key];candidate.append((json.dumps(d,ensure_ascii=False,indent=1)+'\n').encode())
 try:
  for p,raw in zip(paths,candidate):p.write_bytes(raw)
  with (base/(name+'-audio-negative-clean.log')).open('w') as log:
   r=subprocess.run([godot,'--headless','--path',str(root),'--script',str(base/'audio-route-probe.gd')],stdout=log,stderr=subprocess.STDOUT)
  print(name,'without route',r.returncode,flush=True)
 finally:
  for p,temporary,original in zip(paths,candidate,saved):
   assert p.read_bytes()==temporary,'Concurrent edit: refusing to overwrite '+str(p)
   p.write_bytes(original)
 with (base/(name+'-audio-final-clean.log')).open('w') as log:
  r=subprocess.run([godot,'--headless','--path',str(root),'--script',str(base/'audio-route-probe.gd')],stdout=log,stderr=subprocess.STDOUT)
 print(name,'with route',r.returncode,flush=True)
