extends SceneTree
func _initialize() -> void:
	_check.call_deferred()
func _check() -> void:
	var failures := 0
	var ambience := root.get_node("Ambience")
	var music := root.get_node("Music")
	for entry: Array in [["res://data/levels/ch2_lounge_front.tres", &"market"], ["res://data/levels/ch1_street.tres", &"freight"]]:
		var level: Resource = load(entry[0])
		var actual: StringName = level.lighting_zones.back().profile.id
		var expected: StringName = entry[1]
		var ambience_ok: bool = not ambience.layers_for(actual).is_empty() and ambience.layers_for(actual) == ambience.layers_for(expected)
		var music_ok: bool = music._scope(&"zones", actual) == music._scope(&"zones", expected)
		print("AUDIO_ROUTE ", actual, " ambience=", ambience_ok, " music=", music_ok)
		failures += int(not ambience_ok) + int(not music_ok)
	print("checks: 4, failures: ", failures)
	quit(1 if failures else 0)
