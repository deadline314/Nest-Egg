from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg20-final-tour')
out.mkdir(exist_ok=False)
dependency = Path('D:/NestEggVerification/evidence-20261117/ne218-brute-acceptance/candidates/v11-ground-plane/performance-native-v5/source-held.json')
while not dependency.is_file():
    time.sleep(2)
assert json.loads(dependency.read_text())['source_held']
paths = [p for p in subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'core', 'game', 'data', 'ui', 'art', 'tools', 'project.godot'], cwd=root).decode().split('\0') if p and (root / p).is_file()]
def snapshot():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
levels = ['ch1_pawnshop', 'ch1_pawnshop_dawn', 'ch1_street', 'ch1_booth_alley', 'ch1_warehouse', 'ch1_vault', 'ch1_lounge', 'ch1_rooftop', 'ch1_stall', 'ch1_prologue', 'ch1_handoff']
runs = []
for mode in ['low', 'high', 'flat']:
    folder = out / mode
    folder.mkdir()
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
        env[key] = str(out / 'private-profile' / mode / key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '1280x720', 'res://tools/scene_tour.tscn', '--', '--out=' + str(folder), '--level=' + ','.join(levels), '--tag=' + mode, '--quality=' + ('high' if mode == 'flat' else mode), '--no-enemies']
    if mode == 'flat': command.append('--flat')
    start = time.monotonic()
    with (folder / 'raw.log').open('wb') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (folder / 'raw.log').read_bytes()
    records = [json.loads((folder / level / (mode + '-index.json')).read_text()) for level in levels]
    row = {'mode': mode, 'command': command, 'exit': result.returncode, 'elapsed_s': time.monotonic() - start, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'images': sum(len(r['shots']) for r in records), 'levels': levels, 'scope': 'Original native scene tour, complete grids, frozen actors absent for decoration inspection; flat is geometry-only. Timing fields are diagnostics under recorded shared-machine load, not performance acceptance.'}
    runs.append(row)
    (out / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
    assert result.returncode == row['script_errors'] == 0 and all(r['shots'] for r in records)
    print('BG20_TOUR', mode, row['images'], result.returncode, flush=True)
after = snapshot()
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
(out / 'source-held.json').write_text(json.dumps({'source_held': before == after, 'count': len(before), 'baseline': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip()}, indent=2) + '\n')
assert before == after
