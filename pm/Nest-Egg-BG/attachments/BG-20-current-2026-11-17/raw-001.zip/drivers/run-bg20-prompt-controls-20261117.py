from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg20-prompt-controls')
out.mkdir(exist_ok=False)
source = root / 'tools/scene_tour.gd'
before = hashlib.sha256(source.read_bytes()).hexdigest()
assert before == '19f6b4b1835e885cd97d7076b9114c5d9c7dbe4f59afd71cc660f8e3da691acf'
runs = []
for mode, flags in [('static', []), ('shown-player', ['--show-player']), ('walking-player', ['--player'])]:
    folder = out / mode
    folder.mkdir()
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
        env[key] = str(folder / 'private-profile' / key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '1280x720', 'res://tools/scene_tour.tscn', '--', '--out=' + str(folder), '--level=ch1_warehouse', '--tag=control', '--cells=0:4', '--quality=low', *flags]
    with (folder / 'raw.log').open('wb') as log:
        process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (folder / 'raw.log').read_bytes()
    data = json.loads((folder / 'ch1_warehouse/control-index.json').read_text())
    row = {'mode': mode, 'command': command, 'exit': process.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'suppressed_player_prompts': data['suppressed_player_prompts'], 'images': len(data['shots'])}
    runs.append(row)
    (out / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
    assert process.returncode == row['script_errors'] == 0 and row['images'] == 1
    assert (row['suppressed_player_prompts'] > 0) if mode == 'static' else (row['suppressed_player_prompts'] == 0)
    assert hashlib.sha256(source.read_bytes()).hexdigest() == before
    print(mode, row['suppressed_player_prompts'], flush=True)
(out / 'source-held.json').write_text(json.dumps({'source_held': True, 'sha256': before}, indent=2) + '\n')
