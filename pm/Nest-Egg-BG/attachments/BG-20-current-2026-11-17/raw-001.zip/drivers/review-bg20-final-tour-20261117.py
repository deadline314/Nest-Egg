from pathlib import Path
import json
from PIL import Image, ImageDraw

base = Path('D:/NestEggVerification/evidence-20261117/bg20-final-tour')
out = base / 'review'
out.mkdir(exist_ok=True)
levels = json.loads((base / 'runs.json').read_text())[0]['levels']
for level in levels:
    index = json.loads((base / 'low' / level / 'low-index.json').read_text())
    width, height = index['columns'] * 192, index['rows'] * 120 + 24
    sheet = Image.new('RGB', (width, height * 3), '#333333')
    draw = ImageDraw.Draw(sheet)
    for mode_number, mode in enumerate(['low', 'high', 'flat']):
        current = json.loads((base / mode / level / (mode + '-index.json')).read_text())
        assert len(current['shots']) == len(index['shots'])
        draw.text((4, mode_number * height + 4), level + ' ' + mode + ' (all cells, no dark-cell filter)', fill='white')
        for shot in current['shots']:
            image = Image.open(base / mode / level / shot['file']).convert('RGB')
            x, y = shot['column'] * 192, mode_number * height + 24 + shot['row'] * 120
            sheet.paste(image.resize((192, 108), Image.Resampling.LANCZOS), (x, y))
            draw.text((x + 2, y + 108), f"c{shot['column']} r{shot['row']}", fill='white')
    sheet.save(out / (level + '-overview.png'))
print('ALL_CELL_OVERVIEWS', len(levels))
