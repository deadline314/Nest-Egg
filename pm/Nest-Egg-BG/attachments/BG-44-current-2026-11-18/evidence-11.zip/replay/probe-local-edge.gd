extends "res://work/bg44-current/probe-framed-v2.gd"
var _steel44: TerrainMaterialData
var _steel_color44: Color
var _theme44: EnvironmentTheme
var _zones_old44: Array[EnvZone] = []
var _zones_new44: Array[EnvZone] = []
var _zone_proof44: Dictionary = {}
func _ready() -> void:
    _steel44 = load("res://data/environment/materials/steel_plate.tres") as TerrainMaterialData
    _steel_color44 = _steel44.edge_color
    _theme44 = load("res://data/environment/themes/ch3_mezzanine.tres") as EnvironmentTheme
    assert(_theme44.zones.size()==1)
    _zones_old44.assign(_theme44.zones)
    var local := _zones_old44[0].duplicate() as EnvZone
    local.material = _steel44.duplicate() as TerrainMaterialData
    local.material.id = &"mezzanine_steel_plate"
    local.material.edge_color = Color(_steel_color44*1.7,1.0)
    var rest := _zones_old44[0].duplicate() as EnvZone
    rest.from_tile = 20
    _zones_new44.assign([local,rest])
    super._ready()
func _apply55(level: Level, profile: LightingProfile) -> void:
    await super._apply55(level,profile)
    if str(level.data.id)=="ch3_mezzanine":
        _theme44.zones = _zones_new44 if profile.has_meta(&"bg44_candidate") else _zones_old44
        var terrain := get_tree().get_first_node_in_group(&"terrain") as Terrain
        assert(terrain!=null and terrain._theme==_theme44)
        for owner in [terrain,terrain.get_node("Edges")]:
            for chunk in owner.get_children():
                if chunk is CanvasItem: chunk.queue_redraw()
        await RenderingServer.frame_post_draw
        await RenderingServer.frame_post_draw
func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
    var record := await super._capture55(level,world,label)
    record["character_floor"] = level._lighting.current.character_floor
    record["character_fill"] = LightKit.character_fill
    record["enemy_fill_scale"] = level._lighting.current.enemy_fill_scale
    var edge := _theme44.zones[0].material.edge_color if str(level.data.id)=="ch3_mezzanine" else Color.TRANSPARENT
    record["terrain_edge_color"] = [edge.r,edge.g,edge.b,edge.a]
    record["material_zones44"] = []
    if str(level.data.id)=="ch3_mezzanine":
        for zone in _theme44.zones:
            var color := zone.material.edge_color
            record.material_zones44.append({"from":zone.from_tile,"material":str(zone.material.id),"edge":[color.r,color.g,color.b,color.a]})
        record["zone_geometry44"] = _zone_proof44
    record["creature_floor"] = level._lighting.current.creature_floor
    record["creature_fill"] = LightKit.creature_fill
    record["creature_light_cap"] = LightKit.creature_light_cap
    var geometry: Array[Dictionary] = []
    var lighting: Array[Dictionary] = []
    for node in level._entities.get_children():
        if not node is Enemy or node.creature==null: continue
        var creature: PartCreature = node.creature
        var parts: Array[Dictionary] = []
        var tints: Array = []
        var active := 0
        for part in creature._parts:
            var sprite: Sprite2D = part.sprite
            parts.append({"instance":sprite.get_instance_id(),"transform":HeldLighting55.transform_values(sprite.global_transform),"visible":sprite.is_visible_in_tree(),"texture_instance":sprite.texture.get_instance_id() if sprite.texture!=null else 0})
            tints.append(sprite.self_modulate)
            if creature._light_material!=null and sprite.material==creature._light_material: active+=1
        geometry.append({"id":str(node.data.id),"skin":node.data.creature_skin,"instance":node.get_instance_id(),"creature_instance":creature.get_instance_id(),"feet":[node.global_position.x,node.global_position.y],"facing":node.facing,"time":creature._time,"state_time":creature.state_time,"parts":parts})
        lighting.append({"id":str(node.data.id),"fill":creature._lighting_fill,"cap":creature._lighting_cap,"active_parts":active,"shader_fill":creature._light_material.get_shader_parameter(&"fill") if creature._light_material!=null else null,"shader_cap":creature._light_material.get_shader_parameter(&"light_cap") if creature._light_material!=null else null,"tints":tints})
    record["creature_geometry44"] = geometry
    record["creature_lighting44"] = lighting
    return record

func _measure(level: Level, world: Rect2) -> Dictionary:
    _active_cell55 = _cell55
    _cell55 += 1
    var baseline_name := "power_room" if str(level.data.id)=="ch3_pump" else "transfer"
    var original := load("res://work/bg44-current/"+baseline_name+"-before.tres") as LightingProfile
    var candidate := original.duplicate() as LightingProfile
    candidate.set_meta(&"bg44_candidate",true)
    if str(level.data.id)=="ch3_pump": candidate.creature_floor=0.75
    assert(candidate != null and candidate.validate().is_empty())
    var sequence := [[true, false, "A0"], [true, false, "A1"], [false, false, "product-old"],
        [true, false, "restore-old"], [true, true, "reference-new"], [false, true, "product-new"],
        [true, true, "restore-new"], [true, false, "restore-original"], [false, true, "authored-final"]]
    var records: Array[Dictionary] = []
    for entry in sequence:
        await _apply55(level, candidate if entry[1] else original)
        await _variant44(level, entry[0])
        var record := await _capture55(level, world, entry[2])
        record["profile_candidate"] = entry[1]
        record["character_floor"] = level._lighting.current.character_floor
        record["enemy_fill_scale"] = level._lighting.current.enemy_fill_scale
        record["character_fill"] = LightKit.character_fill
        record["profile_valid"] = level._lighting.current.validate().is_empty()
        record["scope"] = "original BG44 added props; current held geometry/runtime; no full historical checkout"
        records.append(record)
    var valid: bool = records[0].raw_sha256 == records[1].raw_sha256 and records[0].raw_sha256 == records[3].raw_sha256 and records[0].raw_sha256 == records[7].raw_sha256
    valid = valid and records[4].raw_sha256 == records[6].raw_sha256 and records[5].raw_sha256 == records[8].raw_sha256
    for record in records:
        valid = valid and record.held.lighting_owners.valid and record.profile_valid
        if record.has("player"): valid = valid and bool(record.held.player_support.valid)
    if not valid:
        _contrast_failures += 1
        printerr("[BG44] Identity/restoration/owner/support control failed")
    var final: Dictionary = records[-1]
    var passed: bool = valid
    if final.has("player"):
        passed = passed and final.player.contrast >= 0.6 and final.player.edge_contrast >= 1.0
    for enemy in final.enemies: passed = passed and enemy.contrast >= 0.45
    if not passed:
        _contrast_failures += 1
        printerr("[BG44] Original threshold failure: ", level.data.id, " ", final.get("player", {}))
    return {"bg44": {"controls_valid": valid, "records": records, "prop_delta": _delta44[str(level.data.id)],
        "scope": "same current runtime/geometry; only original BG44 prop additions/removals ; later unrelated props retained"}, "passed": passed}

func _sync55(level: Level) -> void:
    super._sync55(level)
    # The real Enemy updates this owner in _drive_creature; hold its animation,
    # and synchronize only the same existing lighting API after a profile swap.
    for node in level._entities.get_children():
        if node is Enemy and node.creature!=null:
            node.creature.set_lighting(LightKit.creature_fill,LightKit.creature_light_cap)

func _settle(frames: int) -> void:
    await super._settle(frames)
    if not is_instance_valid(_held55) or str(_held55.data.id)!="ch3_mezzanine" or not _zone_proof44.is_empty(): return
    var hashes: Array[String] = []
    for zones in [_zones_old44,_zones_new44]:
        var theme := _theme44.duplicate() as EnvironmentTheme
        theme.zones = zones
        var geometry := BackWallGeometry.new()
        geometry.setup(_held55._layout,hash(_held55.data.id),theme)
        hashes.append(bytes_sha(var_to_bytes([geometry.holes,geometry.outdoor,geometry.facade_top,geometry.ground,geometry.deep,geometry.modules,geometry.support_rects])))
    assert(hashes[0]==hashes[1],"Local material zones must preserve all original facade/wall geometry")
    _zone_proof44 = {"old_sha256":hashes[0],"new_sha256":hashes[1],"same":true,"scope":"Same actual layout and ID seed; facade modules, wall holes, heights and collision support rectangles unchanged. Only left20tile edge material differs."}
