extends "res://work/bg44-current/probe-framed-v2.gd"
var _steel44: TerrainMaterialData
var _steel_color44: Color
func _ready() -> void:
    _steel44 = load("res://data/environment/materials/steel_plate.tres") as TerrainMaterialData
    _steel_color44 = _steel44.edge_color
    super._ready()
func _apply55(level: Level, profile: LightingProfile) -> void:
    await super._apply55(level,profile)
    if str(level.data.id)=="ch3_mezzanine":
        _steel44.edge_color = Color(_steel_color44*1.6,1.0) if profile.has_meta(&"bg44_candidate") else _steel_color44
        var terrain := get_tree().get_first_node_in_group(&"terrain") as Terrain
        assert(terrain!=null and terrain._theme.zones[0].material==_steel44)
        var edges := terrain.get_node("Edges") as TerrainEdges
        for chunk in edges.get_children():
            if chunk is CanvasItem: chunk.queue_redraw()
        await RenderingServer.frame_post_draw
        await RenderingServer.frame_post_draw
func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
    var record := await super._capture55(level,world,label)
    record["character_floor"] = level._lighting.current.character_floor
    record["character_fill"] = LightKit.character_fill
    record["enemy_fill_scale"] = level._lighting.current.enemy_fill_scale
    record["terrain_edge_color"] = _steel44.edge_color if str(level.data.id)=="ch3_mezzanine" else Color.TRANSPARENT
    return record

func _measure(level: Level, world: Rect2) -> Dictionary:
	_active_cell55 = _cell55
	_cell55 += 1
	var baseline_name := "power_room" if str(level.data.id)=="ch3_pump" else "transfer"
	var original := load("res://work/bg44-current/"+baseline_name+"-before.tres") as LightingProfile
	var candidate := original.duplicate() as LightingProfile
	candidate.set_meta(&"bg44_candidate",true)
	if str(level.data.id)=="ch3_pump": candidate.enemy_fill_scale=1.5
	else: candidate.character_floor=0.32
	assert(candidate != null and candidate.validate().is_empty())
	var sequence := [[true, false, "A0"], [true, false, "A1"], [false, false, "product-old"],
		[true, false, "restore-old"], [true, true, "reference-new"], [false, true, "product-new"],
		[true, true, "restore-new"], [true, false, "restore-original"], [false, true, "authored-final"]]
	var records: Array[Dictionary] = []
	for entry in sequence:
		await _apply55(level, candidate if entry[1] else original)
		await _variant44(level, entry[0])
		var record := await _capture55(level, world, entry[2])
		record["profile_candidate"] = entry[1]
		record["character_floor"] = level._lighting.current.character_floor
		record["enemy_fill_scale"] = level._lighting.current.enemy_fill_scale
		record["character_fill"] = LightKit.character_fill
		record["profile_valid"] = level._lighting.current.validate().is_empty()
		record["scope"] = "original BG44 added props; current held geometry/runtime; no full historical checkout"
		records.append(record)
	var valid: bool = records[0].raw_sha256 == records[1].raw_sha256 and records[0].raw_sha256 == records[3].raw_sha256 and records[0].raw_sha256 == records[7].raw_sha256
	valid = valid and records[4].raw_sha256 == records[6].raw_sha256 and records[5].raw_sha256 == records[8].raw_sha256
	for record in records:
		valid = valid and record.held.lighting_owners.valid and record.profile_valid
		if record.has("player"): valid = valid and bool(record.held.player_support.valid)
	if not valid:
		_contrast_failures += 1
		printerr("[BG44] Identity/restoration/owner/support control failed")
	var final: Dictionary = records[-1]
	var passed: bool = valid
	if final.has("player"):
		passed = passed and final.player.contrast >= 0.6 and final.player.edge_contrast >= 1.0
	for enemy in final.enemies: passed = passed and enemy.contrast >= 0.45
	if not passed:
		_contrast_failures += 1
		printerr("[BG44] Original threshold failure: ", level.data.id, " ", final.get("player", {}))
	return {"bg44": {"controls_valid": valid, "records": records, "prop_delta": _delta44[str(level.data.id)],
		"scope": "same current runtime/geometry; only original BG44 prop additions/removals ; later unrelated props retained"}, "passed": passed}
