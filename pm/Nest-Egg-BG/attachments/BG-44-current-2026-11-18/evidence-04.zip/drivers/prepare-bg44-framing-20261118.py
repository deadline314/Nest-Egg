from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');private=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg44-current')
(private/'probe-framed.gd').write_text('''extends "res://work/bg44-current/probe.gd"
func _settle(frames: int) -> void:
    await super._settle(frames)
    if not is_instance_valid(_held55) or not _held55.player.visible: return
    var viewport := get_viewport().get_visible_rect()
    var to_world := get_viewport().get_canvas_transform().affine_inverse()
    var bottom := (to_world * viewport.end).y
    # The original outer ring ends16px below feet; keep it and both edge ROIs intact.
    var required := _held55.player.global_position.y + 18.0
    if required > bottom:
        var camera := get_viewport().get_camera_2d()
        assert(camera != null)
        camera.global_position.y += required-bottom
        camera.force_update_scroll()
        _sync55(_held55)
        await RenderingServer.frame_post_draw
        await RenderingServer.frame_post_draw
func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
    var record := await super._capture55(level,world,label)
    if record.has("player"):
        assert(record.player.below_screen_rect[2]>0 and record.player.below_screen_rect[3]>0, "Original below-floor comparison ROI must be visible")
        var viewport := get_viewport().get_visible_rect()
        var to_world := get_viewport().get_canvas_transform().affine_inverse()
        record["framing44"] = {"player_feet":[level.player.global_position.x,level.player.global_position.y],"world_bottom":(to_world*viewport.end).y,"required_bottom":level.player.global_position.y+16.0,"scope":"Same grid cells and physical support; camera moves only when the original body/ring/edge comparison would be cropped. No sampler or threshold change."}
        assert(record.framing44.world_bottom>=record.framing44.required_bottom)
    return record
''',encoding='utf-8',newline='\n')
(private/'probe-framed.tscn').write_bytes((private/'probe.tscn').read_bytes().replace(b'/probe.gd',b'/probe-framed.gd'))
s=(p/'run-bg44-reproduction-20261118.py').read_text().replace("out=base/'reproduction'","out=base/'framed-baseline'").replace('/probe.tscn','/probe-framed.tscn')
(p/'run-bg44-framed-20261118.py').write_text(s,encoding='utf-8')
print('Private fixture camera frames full original ROI; same actor/world support and full80cell grid. Original invalid crop data retained. No product data or metric change.')
