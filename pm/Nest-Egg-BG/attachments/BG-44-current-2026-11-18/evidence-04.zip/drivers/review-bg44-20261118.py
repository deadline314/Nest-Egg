from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
b=Path('D:/NestEggVerification/evidence-20261117/bg44-current');out=b/'review';out.mkdir(exist_ok=True);font=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc',14)
for phase,key in [('formal-final','bg44'),('flat-final','bg44_flat')]:
 for level in ['ch3_pump','ch3_mezzanine']:
  for q in ['low','high']:
   f=b/phase/(level+'-'+q)/level;data=json.loads((f/'bg44-index.json').read_text());cols,rows=int(data['columns']),int(data['rows']);im=Image.new('RGB',(cols*320,36+rows*390),'#101722');draw=ImageDraw.Draw(im);draw.text((7,6),f'{phase}/{level}/{q}: BEFORE top, AFTER bottom; native640x360 shown320x180',font=font,fill='white')
   for shot in data['shots']:
    rec=shot[key]['records'];after=rec[-1] if phase=='formal-final' else rec[1];c,r=int(shot['column']),int(shot['row'])
    for i,(label,record) in enumerate([('before',rec[0]),('after',after)]):
     x,y=c*320,36+r*390+i*195
     with Image.open(f/record['files']['png']) as image:
      assert image.size==(640,360);im.paste(image.convert('RGB').resize((320,180)),(x,y))
     draw.text((x+3,y+180),f'{label} c{c} r{r}',font=font,fill='white')
   im.save(out/f'{phase}-{level}-{q}.png')
for q in ['low','high']:
 f=b/'states-v2'/q;rows=json.loads((f/'states.json').read_text())['rows'];assert len(rows)==10
 for start in range(0,10,6):
  im=Image.new('RGB',(1280,1170),'#101722');draw=ImageDraw.Draw(im)
  for i,row in enumerate(rows[start:start+6]):
   x,y=i%2*640,i//2*390
   with Image.open(f/(row['name']+'.png')) as image:
    assert image.size==(640,360);im.paste(image,(x,y))
   draw.text((x+3,y+362),q+' / '+row['name'],font=font,fill='white')
  im.save(out/f'states-{q}-{start//6+1:02}.png')
for level,cell in [('ch3_pump',(2,3)),('ch3_mezzanine',(0,2))]:
 for q in ['low','high']:
  f=b/'formal-final'/(level+'-'+q)/level;data=json.loads((f/'bg44-index.json').read_text());shot=next(s for s in data['shots'] if (s['column'],s['row'])==cell);records=shot['bg44']['records'];im=Image.new('RGB',(1280,780),'#101722');draw=ImageDraw.Draw(im)
  for i,label in enumerate(['A0','product-old','reference-new','authored-final']):
   rec=next(r for r in records if r['label']==label);x,y=i%2*640,i//2*390
   with Image.open(f/rec['files']['png']) as image:im.paste(image,(x,y))
   draw.text((x+3,y+362),f'{level}/{q}/{cell}/{label}',font=font,fill='white')
  im.save(out/f'factors-{level}-{q}.png')
print(json.dumps([p.name for p in sorted(out.glob('*.png'))]))
