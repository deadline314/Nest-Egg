from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');private=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg44-current')
s=(private/'probe-creatures-75.gd').read_text()
old='''    if str(level.data.id)=="ch3_pump": candidate.creature_floor=0.75
    else:
        candidate.character_floor=0.32
        candidate.creature_floor=0.75'''
assert s.count(old)==1;s=s.replace(old,'    if str(level.data.id)=="ch3_pump": candidate.creature_floor=0.75')
s=s.replace('func _ready() -> void:', '''var _theme44: EnvironmentTheme
var _zones_old44: Array[EnvZone] = []
var _zones_new44: Array[EnvZone] = []
var _zone_proof44: Dictionary = {}
func _ready() -> void:''',1)
needle='    super._ready()';assert s.count(needle)==1
s=s.replace(needle,'''    _theme44 = load("res://data/environment/themes/ch3_mezzanine.tres") as EnvironmentTheme
    assert(_theme44.zones.size()==1)
    _zones_old44.assign(_theme44.zones)
    var local := _zones_old44[0].duplicate() as EnvZone
    local.material = _steel44.duplicate() as TerrainMaterialData
    local.material.id = &"mezzanine_steel_plate"
    local.material.edge_color = Color(_steel_color44*1.7,1.0)
    var rest := _zones_old44[0].duplicate() as EnvZone
    rest.from_tile = 20
    _zones_new44.assign([local,rest])
'''+needle)
start=s.index('func _apply55(');end=s.index('func _capture55(',start)
s=s[:start]+'''func _apply55(level: Level, profile: LightingProfile) -> void:
    await super._apply55(level,profile)
    if str(level.data.id)=="ch3_mezzanine":
        _theme44.zones = _zones_new44 if profile.has_meta(&"bg44_candidate") else _zones_old44
        var terrain := get_tree().get_first_node_in_group(&"terrain") as Terrain
        assert(terrain!=null and terrain._theme==_theme44)
        for owner in [terrain,terrain.get_node("Edges")]:
            for chunk in owner.get_children():
                if chunk is CanvasItem: chunk.queue_redraw()
        await RenderingServer.frame_post_draw
        await RenderingServer.frame_post_draw
'''+s[end:]
needle='    record["terrain_edge_color"] = _steel44.edge_color if str(level.data.id)=="ch3_mezzanine" else Color.TRANSPARENT';assert s.count(needle)==1
s=s.replace(needle,'''    var edge := _theme44.zones[0].material.edge_color if str(level.data.id)=="ch3_mezzanine" else Color.TRANSPARENT
    record["terrain_edge_color"] = [edge.r,edge.g,edge.b,edge.a]
    record["material_zones44"] = []
    if str(level.data.id)=="ch3_mezzanine":
        for zone in _theme44.zones:
            var color := zone.material.edge_color
            record.material_zones44.append({"from":zone.from_tile,"material":str(zone.material.id),"edge":[color.r,color.g,color.b,color.a]})
        record["zone_geometry44"] = _zone_proof44''')
s+='''
func _settle(frames: int) -> void:
    await super._settle(frames)
    if not is_instance_valid(_held55) or str(_held55.data.id)!="ch3_mezzanine" or not _zone_proof44.is_empty(): return
    var hashes: Array[String] = []
    for zones in [_zones_old44,_zones_new44]:
        var theme := _theme44.duplicate() as EnvironmentTheme
        theme.zones = zones
        var geometry := BackWallGeometry.new()
        geometry.setup(_held55._layout,hash(_held55.data.id),theme)
        hashes.append(bytes_sha(var_to_bytes([geometry.holes,geometry.outdoor,geometry.facade_top,geometry.ground,geometry.deep,geometry.modules,geometry.support_rects])))
    assert(hashes[0]==hashes[1],"Local material zones must preserve all original facade/wall geometry")
    _zone_proof44 = {"old_sha256":hashes[0],"new_sha256":hashes[1],"same":true,"scope":"Same actual layout and ID seed; facade modules, wall holes, heights and collision support rectangles unchanged. Only left20tile edge material differs."}
'''
assert '\t' not in s
(private/'probe-local-edge.gd').write_text(s,encoding='utf-8',newline='\n');(private/'probe-local-edge.tscn').write_bytes((private/'probe.tscn').read_bytes().replace(b'/probe.gd',b'/probe-local-edge.gd'))
d=(p/'run-bg44-creatures-75-20261118.py').read_text().replace("out=base/'calibration-creature-floor-75'","out=base/'calibration-local-edge'").replace('/probe-creatures-75.tscn','/probe-local-edge.tscn')
d=d.replace("print(json.dumps({'name':case,'cells':len(observations),'strict_negative_cells':[v for v in observations if not v['strict_nondrop']]}),flush=True)","print(json.dumps({'name':case,'cells':len(observations),'strict_negative_cell_count':sum(not v['strict_nondrop'] for v in observations)}),flush=True)")
(p/'run-bg44-local-edge-20261118.py').write_text(d,encoding='utf-8')
print('Memory-only local candidate: pump creature floor.75; mezz original floor.3/creature0 preserved, only first20tiles gain1.7 alpha1 via existing EnvZone materials. Same old/new facade geometry asserted; terrain redraw retains original UV/full rectangles. No product mutations.')
