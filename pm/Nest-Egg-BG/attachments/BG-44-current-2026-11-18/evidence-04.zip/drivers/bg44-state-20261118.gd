extends "res://work/bg43-current/state-core.gd"
var _drive_choices := false
var _observed_level: Level
var _hand_captured := false
var _hand_pending := false
var _selected: Array[Dictionary] = []

func _process(delta: float) -> void:
    super._process(delta)
    if is_instance_valid(_observed_level) and not _hand_captured and not _hand_pending:
        var action: WorldPropAction = _observed_level.player._visual.interaction_action
        if action != null and action.phase == "turn" and action._elapsed > action._duration*0.35 and action._elapsed < action._duration*0.8 and action.contact_error <= 0.25:
            _hand_pending = true
            _capture_hand.call_deferred(action)
    if not _drive_choices: return
    var player: CutscenePlayer = Story._player if is_instance_valid(Story._player) else null
    if is_instance_valid(player) and player.choice_active():
        var found := false
        for i in player._choice_options.size():
            var option: Dictionary = player._choice_options[i]
            if str(option.get("id","")) in ["drain","branch","power"]:
                _selected.append({"scene":str(Story._current_cinematic),"option":str(option.id)})
                assert(player.choose(i))
                found = true
                break
        assert(found, "Only the authored drain/branch/power selections are allowed")
    elif is_instance_valid(player) and player.is_running():
        player.speed = 20.0
        if player._dialogue.visible:
            player._dialogue.complete()
            player._advance_requested = true
    elif Story._layer.is_cinematic_active():
        Story._layer.advance()

func react(level: Level, id: StringName) -> PropReaction:
    for node in level.find_children("*", "", true, false):
        if node is PropReaction and node.reaction_id == id: return node
    assert(false, str(id))
    return null

func _capture_hand(action: WorldPropAction) -> void:
    await shot(_observed_level,"wheel-hand-turn",{"phase":action.phase,"contact_error":action.contact_error,"elapsed":action._elapsed,"duration":action._duration,"contacts_completed":action.contacts_completed})
    _hand_captured = true

func wheel_state(level: Level, name: String, expected: String) -> void:
    var r := react(level,&"drain_wheel")
    assert(r._lamp_state.color=="#"+expected)
    var progress := r.dial_progress()
    await shot(level,name,{"progress":progress,"lamp":r._lamp_state.color,"prop":[r.get_parent().global_position.x,r.get_parent().global_position.y],"size":[r._size.x,r._size.y]})

func _run() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(LightKit.create_environment())
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--quality="): Settings.set_light_quality(0 if arg.ends_with("low") else 2)
    Story.auto_skip = false
    Enemy.activation_culling_enabled = false
    GameState.start_new_run(GameState.difficulties[1])
    var level := await make_level("ch3_pump")
    _observed_level = level
    var wheel := await check_npc(level,&"ch3_drain_wheel","wheel-prompt")
    assert(is_zero_approx(react(level,&"drain_wheel").dial_progress()))
    await wheel_state(level,"wheel-before","ff6a4a")
    _drive_choices = true
    assert(await wheel._talk())
    assert(GameState.has_flag(&"ch3_pump_low") and _hand_captured)
    await settle(30)
    var midway := react(level,&"drain_wheel").dial_progress()
    assert(midway>0.0 and midway<1.0)
    await wheel_state(level,"wheel-dial-mid","52d98c")
    await settle(100)
    assert(is_equal_approx(react(level,&"drain_wheel").dial_progress(),1.0))
    await wheel_state(level,"wheel-drained","52d98c")
    var panel := await check_npc(level,&"ch3_branch_panel","panel-before")
    var r := react(level,&"pump_branch_panel")
    assert(not r.is_swapped() and not r._swap_node.visible)
    var bottom: float = r.get_parent().global_position.y+r._size.y
    assert(await panel._talk())
    assert(GameState.has_flag(&"ch3_wet_branch_isolated") and GameState.has_flag(&"ch3_lift_powered"))
    assert(r.is_swapped() and r._swap_node.visible and r._lamp_state.color=="#52d98c")
    assert(absf(r._swap_node.global_position.y+r._swap_node.data.size.y-bottom)<0.01)
    await shot(level,"panel-open",{"swapped":true,"lamp":r._lamp_state.color,"closed_bottom":bottom,"open_bottom":r._swap_node.global_position.y+r._swap_node.data.size.y})
    assert(_selected.size()==3)
    _drive_choices = false
    _observed_level = null
    Story.auto_skip = true
    level.queue_free()
    await settle(3)
    level = await make_level("ch3_pump")
    var wheel_again := await check_npc(level,&"ch3_drain_wheel","pump-reentry")
    assert(wheel_again!=null and is_equal_approx(react(level,&"drain_wheel").dial_progress(),1.0))
    assert(react(level,&"pump_branch_panel").is_swapped())
    level.queue_free()
    await settle(3)
    level = await make_level("ch3_mezzanine")
    var notice := await check_npc(level,&"ch3_notice_terminal","notice-before")
    var terminal: PropNode
    for node in level.find_children("*", "", true, false):
        if node is PropNode and str(node.data.id)=="mezzanine__notice_terminal": terminal=node
    assert(terminal!=null and absf(terminal.global_position.y+terminal.data.size.y-notice.global_position.y)<0.01)
    assert(absf(terminal.global_position.x-notice.global_position.x)<16.0)
    await shot(level,"notice-aligned",{"prop":[terminal.global_position.x,terminal.global_position.y],"size":[terminal.data.size.x,terminal.data.size.y],"npc_position":[notice.global_position.x,notice.global_position.y]})
    assert(await notice._talk())
    assert(Story.was_seen(&"ch3_t_c03_notice_keep"))
    await shot(level,"notice-after",{"notice_seen":true,"scene":"ch3_t_c03_notice_keep"})
    var f := FileAccess.open(_out.path_join("states.json"),FileAccess.WRITE)
    assert(f!=null)
    f.store_string(JSON.stringify({"rows":_rows,"selected":_selected,"actual_talks":true,"hand_captured":_hand_captured,"fixture":"Standalone authored Level, real collision/prompts/NPC talk and WorldPropAction. Dialogue driven at speed20, enemies removed, health999. Reentry is live same-run flags, not cold-save. No Main/full-chapter/manual gameplay claim."},"  ")+"\n")
    f.close()
    level.queue_free()
    await settle(3)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0)
