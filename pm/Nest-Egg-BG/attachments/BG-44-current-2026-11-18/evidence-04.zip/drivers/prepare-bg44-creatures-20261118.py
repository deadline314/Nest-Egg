from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');private=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg44-current')
s=(private/'probe-calibration-v2.gd').read_text()
assert s.count('candidate.enemy_fill_scale=1.5')==1 and s.count('else: candidate.character_floor=0.32')==1
s=s.replace('candidate.enemy_fill_scale=1.5','candidate.creature_floor=0.35').replace('else: candidate.character_floor=0.32','else:\n        candidate.character_floor=0.32\n        candidate.creature_floor=0.35')
needle='    return record\n\nfunc _measure';assert s.count(needle)==1
extra='''    record["creature_floor"] = level._lighting.current.creature_floor
    record["creature_fill"] = LightKit.creature_fill
    record["creature_light_cap"] = LightKit.creature_light_cap
    var geometry: Array[Dictionary] = []
    var lighting: Array[Dictionary] = []
    for node in level._entities.get_children():
        if not node is Enemy or node.creature==null: continue
        var creature: PartCreature = node.creature
        var parts: Array[Dictionary] = []
        var tints: Array = []
        var active := 0
        for part in creature._parts:
            var sprite: Sprite2D = part.sprite
            parts.append({"instance":sprite.get_instance_id(),"transform":HeldLighting55.transform_values(sprite.global_transform),"visible":sprite.is_visible_in_tree(),"texture_instance":sprite.texture.get_instance_id() if sprite.texture!=null else 0})
            tints.append(sprite.self_modulate)
            if creature._light_material!=null and sprite.material==creature._light_material: active+=1
        geometry.append({"id":str(node.data.id),"skin":node.data.creature_skin,"instance":node.get_instance_id(),"creature_instance":creature.get_instance_id(),"feet":[node.global_position.x,node.global_position.y],"facing":node.facing,"time":creature._time,"state_time":creature.state_time,"parts":parts})
        lighting.append({"id":str(node.data.id),"fill":creature._lighting_fill,"cap":creature._lighting_cap,"active_parts":active,"shader_fill":creature._light_material.get_shader_parameter(&"fill") if creature._light_material!=null else null,"shader_cap":creature._light_material.get_shader_parameter(&"light_cap") if creature._light_material!=null else null,"tints":tints})
    record["creature_geometry44"] = geometry
    record["creature_lighting44"] = lighting
'''
s=s.replace(needle,extra+needle)
s+='''
func _sync55(level: Level) -> void:
    super._sync55(level)
    # The real Enemy updates this owner in _drive_creature; hold its animation,
    # and synchronize only the same existing lighting API after a profile swap.
    for node in level._entities.get_children():
        if node is Enemy and node.creature!=null:
            node.creature.set_lighting(LightKit.creature_fill,LightKit.creature_light_cap)
'''
assert '\t' not in s
(private/'probe-creatures.gd').write_text(s,encoding='utf-8',newline='\n');(private/'probe-creatures.tscn').write_bytes((private/'probe.tscn').read_bytes().replace(b'/probe.gd',b'/probe-creatures.gd'))
d=(p/'run-bg44-calibration-v2-20261118.py').read_text().replace("out=base/'calibration-fill-edge-v2'","out=base/'calibration-creature-floor'").replace('/probe-calibration-v2.tscn','/probe-creatures.tscn')
(p/'run-bg44-creatures-20261118.py').write_text(d,encoding='utf-8')
print('Memory-only candidate: both existing creature_floor.35; original enemy gain1.0 retained; mezz mainfloor.32/steel RGB1.6 alpha1. Same real PartCreature.set_lighting as game, no animation tick; all parts/material uniforms recorded. No product changes.')
