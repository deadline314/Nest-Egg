from pathlib import Path
import hashlib,json,re,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg44-current');private=root/'work/bg44-current'
for case in ['ch3_pump-low','ch3_pump-high','ch3_mezzanine-low','ch3_mezzanine-high']:assert json.loads((base/'calibration-local-edge'/case/'independent.json').read_text())['passed']
source=json.loads((base/'source-base.json').read_text());assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in source.items())
old_theme=(primary/'data/environment/themes/ch3_mezzanine.tres').read_bytes();(private/'mezzanine-before-theme.tres').write_bytes(old_theme)
profile=(primary/'data/lighting/power_room.tres').read_text();assert profile.count('id = &"power_room"')==1 and profile.count('character_floor = 0.36')==1
profile=profile.replace('id = &"power_room"','id = &"pump_room"').replace('character_floor = 0.36','character_floor = 0.36\ncreature_floor = 0.75')
(primary/'data/lighting/pump_room.tres').write_text(profile,encoding='utf-8',newline='\n')
material=(primary/'data/environment/materials/steel_plate.tres').read_text();needle='edge_color = Color(0.7019608, 0.8, 1, 0.6)';assert material.count(needle)==1
material=material.replace('id = &"steel_plate"','id = &"mezzanine_steel_plate"').replace('display_name = "鋼板"','display_name = "夾層左側鋼板"').replace(needle,'edge_color = Color(1.19333336, 1.36, 1.7, 1)')
(primary/'data/environment/materials/mezzanine_steel_plate.tres').write_text(material,encoding='utf-8',newline='\n')
for rel,pattern in [('data/audio/ambience.json',r'^  "power_room": \[.*?^  \],'),('data/audio/music.json',r'^   "power_room": \{.*?^   \},')]:
 p=primary/rel;s=p.read_text(encoding='utf-8');before=json.loads(s);match=re.search(pattern,s,re.M|re.S);assert match
 block=match[0];updated=s[:match.start()]+block+'\n'+block.replace('"power_room":','"pump_room":',1)+s[match.end():];after=json.loads(updated)
 a=after['profiles'] if 'ambience' in rel else after['map']['zones'];b=before['profiles'] if 'ambience' in rel else before['map']['zones'];assert a.pop('pump_room')==b['power_room'] and after==before
 p.write_text(updated,encoding='utf-8',newline='\n')
p=primary/'data/audio/footsteps.json';s=p.read_text(encoding='utf-8');needle='  "steel_plate": "metal"';assert s.count(needle)==1
updated=s.replace(needle,'  "mezzanine_steel_plate": "metal",\n'+needle);a,b=json.loads(updated),json.loads(s);assert a['materials'].pop('mezzanine_steel_plate')==b['materials']['steel_plate'] and a==b;p.write_text(updated,encoding='utf-8',newline='\n')
p=primary/'tools/level/build_ch3.py';s=p.read_text(encoding='utf-8')
start=s.index('def _build_pump_v1():');end=s.index('\ndef ',start+5);part=s[start:end];assert part.count("a.zone(0, 'power_room')")==1;s=s[:start]+part.replace("a.zone(0, 'power_room')","a.zone(0, 'pump_room')")+s[end:]
start=s.index('def _build_mezzanine_v1():');end=s.index('\ndef ',start+5);part=s[start:end];assert part.count("    a.zone(0, 'transfer')")==1
part=part.replace("    a.zone(0, 'transfer')","    a.material_zones = [(0, 'mezzanine_steel_plate'), (20, 'steel_plate')]\n    a.zone(0, 'transfer')");s=s[:start]+part+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
sys.dont_write_bytecode=True;sys.path.insert(0,str(primary/'tools/level'));import build_ch3 as ch3
ch3.configure();pump=ch3.build_pump();mezz=ch3.build_mezzanine()
pump_theme=primary/'data/environment/themes/ch3_pump.tres';original=pump_theme.read_bytes();ch3.kit.write_level(pump);generated=pump_theme.read_bytes();pump_theme.write_bytes(original)
assert generated.decode().replace('\r\n','\n')==original.decode().replace('\r\n','\n'),'Pump theme must remain unchanged'
ch3.kit.write_theme(mezz,'mezzanine')
changed=['data/lighting/pump_room.tres','data/environment/materials/mezzanine_steel_plate.tres','data/audio/ambience.json','data/audio/music.json','data/audio/footsteps.json','tools/level/build_ch3.py','data/levels/ch3_pump.tres','data/environment/themes/ch3_mezzanine.tres']
for rel in changed:(root/rel).write_bytes((primary/rel).read_bytes())
after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in set(source)|set(changed)}
assert len(after)==10092 and {p for p in source if source[p]!=after[p]}==set(changed)-{'data/lighting/pump_room.tres','data/environment/materials/mezzanine_steel_plate.tres'}
(base/'source-final.json').write_text(json.dumps(after,indent=2)+'\n')
s=(private/'probe-local-edge.gd').read_text()
start=s.index('    _theme44 = load(');end=s.index('    super._ready()',start)
s=s[:start]+'''    _theme44 = load("res://data/environment/themes/ch3_mezzanine.tres") as EnvironmentTheme
    var old_theme := load("res://work/bg44-current/mezzanine-before-theme.tres") as EnvironmentTheme
    assert(_theme44.zones.size()==2 and old_theme.zones.size()==1)
    _zones_old44.assign(old_theme.zones)
    _zones_new44.assign(_theme44.zones)
'''+s[end:]
start=s.index('    var candidate := original.duplicate() as LightingProfile');end=s.index('    assert(candidate != null',start)
s=s[:start]+'''    var candidate := (load("res://data/lighting/pump_room.tres") as LightingProfile).duplicate() as LightingProfile if str(level.data.id)=="ch3_pump" else original.duplicate() as LightingProfile
    candidate.set_meta(&"bg44_candidate",true)
'''+s[end:]
assert '\t' not in s
(private/'probe-final.gd').write_text(s,encoding='utf-8',newline='\n');(private/'probe-final.tscn').write_bytes((private/'probe.tscn').read_bytes().replace(b'/probe.gd',b'/probe-final.gd'))
d=(primary/'work/run-bg44-local-edge-20261118.py').read_text().replace("out=base/'calibration-local-edge'","out=base/'formal-final'").replace("base/'source-base.json'","base/'source-final.json'").replace('/probe-local-edge.tscn','/probe-final.tscn')
(primary/'work/run-bg44-final-20261118.py').write_text(d,encoding='utf-8')
checks=(primary/'work/run-bg43-checks-v2-20261118.py').read_text().replace('bg43','bg44').replace('checks-v2','checks-final').replace('source-v2.json','source-final.json').replace('eb40f91b7885faa65ac2a588fa79724fd8db4719','6d14fd587b1dc09aaf29190e01d2268334193d6f')
(primary/'work/run-bg44-checks-final-20261118.py').write_text(checks,encoding='utf-8')
with (primary/'design/20-campaign-experience/CH2_CH3_SCENE_GAPS.md').open('a',encoding='utf-8') as f:f.write('\n泵室採用本區專用的零件式生物最低補光 0.75，沿用原泵室音景與配樂；人形補光與主角設定保持原值。夾層只在左側二十格使用同一鋼板貼圖的強化亮邊，其餘鋼板與金屬腳步聲保持原樣；既有材質分段不改立面、洞口、支撐與地形碰撞。凍結取樣先保留完整身體／外圈及地面比較區，並用正式零件式生物受光介面同步材質，不推進動畫；不更改原取樣公式或門檻。\n')
(base/'adoption.json').write_text(json.dumps({'product_paths':changed,'source_count':len(after),'scope':'Two new data resources only; original humanoid/player lighting and all actor geometry/logic unchanged. Left20tile material zones use the existing writer; exact facade/wall geometry hash is independently checked in native runs.'},indent=2)+'\n')
print(json.dumps({'product_paths':changed,'source_count':len(after)}),flush=True)
