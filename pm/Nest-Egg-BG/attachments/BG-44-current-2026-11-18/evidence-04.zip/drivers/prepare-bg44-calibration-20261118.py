from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117');private=root/'work/bg44-current'
for name in ['power_room','transfer']:(private/(name+'-before.tres')).write_bytes((root/('data/lighting/'+name+'.tres')).read_bytes())
s=(private/'probe.gd').read_text()
s=s.replace('extends "res://tools/bg55_enemy_readability_probe.gd"','extends "res://work/bg44-current/probe-framed-v2.gd"',1)
# Keep the original scene setup and recorder only once; the framed parent already owns them.
start=s.index('func _measure(');end=s.index('\n\nfunc _frame_interval_ms',start)
measure=s[start:end]
measure=measure.replace('var original := level._lighting.current.duplicate() as LightingProfile\n\tvar candidate := original','''var baseline_name := "power_room" if str(level.data.id)=="ch3_pump" else "transfer"
\tvar original := load("res://work/bg44-current/"+baseline_name+"-before.tres") as LightingProfile
\tvar candidate := original.duplicate() as LightingProfile
\tcandidate.set_meta(&"bg44_candidate",true)
\tif str(level.data.id)=="ch3_pump": candidate.enemy_fill_scale=1.5
\telse: candidate.character_floor=0.32''')
leaf='''extends "res://work/bg44-current/probe-framed-v2.gd"
var _steel44: TerrainMaterialData
var _steel_color44: Color
func _ready() -> void:
    _steel44 = load("res://data/environment/materials/steel_plate.tres") as TerrainMaterialData
    _steel_color44 = _steel44.edge_color
    super._ready()
func _apply55(level: Level, profile: LightingProfile) -> void:
    await super._apply55(level,profile)
    if str(level.data.id)=="ch3_mezzanine":
        _steel44.edge_color = Color(_steel_color44*1.6,1.0) if profile.has_meta(&"bg44_candidate") else _steel_color44
        var terrain := get_tree().get_first_node_in_group(&"terrain") as Terrain
        assert(terrain!=null and terrain._theme.zones[0].material==_steel44)
        var edges := terrain.get_node("Edges") as TerrainEdges
        for chunk in edges.get_children():
            if chunk is CanvasItem: chunk.queue_redraw()
        await RenderingServer.frame_post_draw
        await RenderingServer.frame_post_draw
func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
    var record := await super._capture55(level,world,label)
    record["character_floor"] = level._lighting.current.character_floor
    record["character_fill"] = LightKit.character_fill
    record["enemy_fill_scale"] = level._lighting.current.enemy_fill_scale
    record["terrain_edge_color"] = _steel44.edge_color if str(level.data.id)=="ch3_mezzanine" else Color.TRANSPARENT
    return record
'''
(private/'probe-calibration.gd').write_text(leaf+'\n'+measure,encoding='utf-8',newline='\n')
(private/'probe-calibration.tscn').write_bytes((private/'probe.tscn').read_bytes().replace(b'/probe.gd',b'/probe-calibration.gd'))
driver=(p/'run-bg44-framed-v2-20261118.py').read_text().replace("out=base/'framed-baseline-v2'","out=base/'calibration-fill-edge'").replace('/probe-framed-v2.tscn','/probe-calibration.tscn')
(p/'run-bg44-calibration-20261118.py').write_text(driver,encoding='utf-8')
print('Memory-only candidate: pump enemy gain1->1.5; mezz player floor.3->.32 +steel edge RGB*1.6 alpha.6->1. Original profiles immutable, same framed physical cells; no product changes.')
