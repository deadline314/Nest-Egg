from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg44-current');out=base/'reproduction';out.mkdir(exist_ok=False)
paths=json.loads((base/'source-base.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths;runs=[];all_passed=False
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
try:
    for level in ['ch3_pump','ch3_mezzanine']:
        for quality in ['low','high']:
            case=level+'-'+quality;folder=out/case;folder.mkdir();env=os.environ.copy()
            for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
            command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg44-current/probe.tscn','--','--out='+str(folder),'--level='+level,'--quality='+quality,'--player','--fixed-aim','--brightness=0.5','--lamps=full','--tag=bg44']
            with (folder/'raw.log').open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
            raw=(folder/'raw.log').read_bytes();row={'name':case,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot()};runs.append(row);print(json.dumps({k:v for k,v in row.items() if k!="command"}),flush=True)
            (out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
            assert r.returncode in [0,1] and row['script_errors']==0 and not row['engine_error'] and row['source_held']
            index=json.loads((folder/level/'bg44-index.json').read_text());observations=[]
            for shot in index['shots']:
                group=shot['bg44'];assert group['controls_valid'];records=group['records'];a=records[0];b=records[-1]
                values={key:b['player'][key]-a['player'][key] for key in ['contrast','edge_contrast']} if 'player' in a else {}
                assert len(a['enemies'])==len(b['enemies']);enemy=[y['contrast']-x['contrast'] for x,y in zip(a['enemies'],b['enemies'])]
                observations.append({'cell':[shot['column'],shot['row']],'deltas':values,'enemy_deltas':enemy,'strict_nondrop':all(v>=0 for v in list(values.values())+enemy)})
            (folder/'strict-summary.json').write_text(json.dumps({'all_strict_nondrop':all(v['strict_nondrop'] for v in observations),'cells':len(observations),'observations':observations},indent=2)+'\n')
            print(json.dumps({'name':case,'cells':len(observations),'strict_negative_cells':[v for v in observations if not v['strict_nondrop']]}),flush=True)

    all_passed=all(r["exit"]==0 for r in runs)
finally:
    after=snapshot();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');(out/'result.json').write_text(json.dumps({'native_engine_gates_passed':all_passed,'source_held':before==after,'producers':len(runs),'scope':'Strict nondrop is separately recorded; this result is not a strict acceptance claim.'},indent=2)+'\n')
