from pathlib import Path
import hashlib,json,subprocess
p=Path.cwd();d=Path('D:/NestEggVerification/ne218-baseline-20261117');b=Path('D:/NestEggVerification/evidence-20261117/bg44-current')
assert json.loads((b/'checks-final/result.json').read_text())['all_passed']
assert json.loads((b/'states-v2/result.json').read_text())['passed']
source=json.loads((b/'source-final.json').read_text());assert all(hashlib.sha256((d/r).read_bytes()).hexdigest()==h for r,h in source.items())
r='data/levels/ch3_layout_v2.json';s=(p/r).read_text();marker='    "mezzanine": {\n      "height": 40,';assert s.count(marker)==1
s=s.replace(marker,marker+'\n      "prop_floors": {"mezzanine__notice_terminal:32": 36},');(p/r).write_text(s,encoding='utf-8',newline='\n')
r='data/levels/ch3_mezzanine_map.json';s=(p/r).read_text();data=json.loads(s);entry=next(x for x in data['props'] if x['id']=='mezzanine__notice_terminal');assert entry['y']==15;entry['y']=35
# Preserve every unrelated byte in the compact generated map.
old=json.dumps(dict(entry,y=15),ensure_ascii=False);new=json.dumps(entry,ensure_ascii=False);assert s.count(old)==1;s=s.replace(old,new);assert json.loads(s)==data;(p/r).write_text(s,encoding='utf-8',newline='\n')
r='tools/level/test_ch3_layout.py';s=(p/r).read_text();marker='    def test_shaft_doors_are_reciprocal_and_follow_the_freight_lift(self):';assert s.count(marker)==1
test='''    def test_notice_terminal_stands_at_its_interaction_floor(self):
        area = self.build('mezzanine')
        prop = next(p for p in kit._map_extra(area)['props'] if p['id'] == 'mezzanine__notice_terminal')
        npc = next((x, y) for y, row in enumerate(area.grid.rows()) for x, char in enumerate(row) if char == 'ⓝ')
        self.assertEqual((prop['x'], prop['y']), npc)
        self.assertFalse(prop['ground'])
        self.assertEqual(area.grid.at(npc[0], npc[1] + 1), '#')

'''
s=s.replace(marker,test+marker);(p/r).write_text(s,encoding='utf-8',newline='\n')
changed=['data/levels/ch3_layout_v2.json','data/levels/ch3_mezzanine_map.json','tools/level/test_ch3_layout.py']
for r in changed:(d/r).write_bytes((p/r).read_bytes());source[r]=hashlib.sha256((d/r).read_bytes()).hexdigest()
(b/'source-v2.json').write_text(json.dumps(source,indent=2)+'\n')
delta=d/'work/bg44-current/prop-delta.json';v=json.loads(delta.read_text());v['ch3_mezzanine']['added'][0]['y']=35;delta.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
proof=json.loads((b/'baseline-proof.json').read_text());(b/'baseline-proof-v1.json').write_text(json.dumps(proof,indent=2)+'\n');proof['rows'][1]['added'][0]['y']=35;proof['notice_floor_correction']={'before_bottom':256,'after_bottom':576,'actual_npc_floor':576,'method':'Existing prop_floors authored per-area override, no shared placement or geometry change'};(b/'baseline-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for old,new in [('run-bg44-final-20261118.py','run-bg44-final-v2-20261118.py'),('run-bg44-flat-final-20261118.py','run-bg44-flat-v2-20261118.py'),('run-bg44-checks-final-20261118.py','run-bg44-checks-v2-20261118.py')]:
 s=(p/'work'/old).read_text().replace('source-final.json','source-v2.json').replace("/'formal-final'","/'formal-v2'").replace("/'flat-final'","/'flat-v2'").replace("/'checks-final'","/'checks-v2'");(p/'work'/new).write_text(s,encoding='utf-8')
s=(p/'work/bg44-state-20261118.gd').read_text();needle='    assert(await notice._talk())';assert s.count(needle)==1
s=s.replace(needle,'''    var terminal: PropNode
    for node in level.find_children("*", "", true, false):
        if node is PropNode and str(node.data.id)=="mezzanine__notice_terminal": terminal=node
    assert(terminal!=null and absf(terminal.global_position.y+terminal.data.size.y-notice.global_position.y)<0.01)
    assert(absf(terminal.global_position.x-notice.global_position.x)<16.0)
    await shot(level,"notice-aligned",{"prop":[terminal.global_position.x,terminal.global_position.y],"size":[terminal.data.size.x,terminal.data.size.y],"npc_position":[notice.global_position.x,notice.global_position.y]})
'''+needle)
(p/'work/bg44-state-20261118.gd').write_text(s,encoding='utf-8')
s=(p/'work/run-bg44-state-v2-20261118.py').read_text().replace("/'states-v2'","/'states-v3'").replace('source-final.json','source-v2.json').replace('==10','==11');(p/'work/run-bg44-state-v3-20261118.py').write_text(s)
doc=p/'design/20-campaign-experience/CH2_CH3_SCENE_GAPS.md';s=doc.read_text().replace('夾層終端位於現行上層互動點。','原終端被首個上層地板吸到上層；正式NPC仍在下層。改用既有逐件地板指定，將終端放回第36列地面（576），與公共通知互動點一致。');doc.write_text(s,encoding='utf-8')
print(json.dumps({'changed':changed,'source_count':len(source),'notice_floor':576}),flush=True)
