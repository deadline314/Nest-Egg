from pathlib import Path
import copy,datetime,hashlib,json,subprocess,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');previous=Path('D:/NestEggVerification/evidence-20261117/bg43-current')
published=json.loads((previous/'publish/result.json').read_text());head=published['commit'];advance=json.loads((previous/'advance-published/result.json').read_text())
assert published['main_origin_head_equal'] and advance['source_held'] and advance['published_commit']==head
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==head
base=previous.parent/'bg44-current';base.mkdir(exist_ok=False);private=root/'work/bg44-current';private.mkdir(exist_ok=False)
source=json.loads((previous/'checks-v2/source-after.json').read_text());assert len(source)==10090 and all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in source.items())
(base/'source-base.json').write_text(json.dumps(source,indent=2)+'\n')
sys.dont_write_bytecode=True;sys.path.insert(0,str(primary/'tools/level'));import build_ch3 as ch3
ch3.configure();parent='245fa0d563336de8e351c41675843f053b0ed140';delta={};proof=[]
for ident in ['pump','mezzanine']:
 rel=f'data/levels/ch3_{ident}_map.json';current=json.loads((root/rel).read_text());assert ch3.kit._map_extra(getattr(ch3,'build_'+ident)())['props']==current['props']
 original=subprocess.check_output(['git','show',parent+':'+rel],cwd=primary);old=json.loads(original);legacy=getattr(ch3,'_build_'+ident+'_v1')();legacy.props=copy.deepcopy(old['props']);mapped=ch3.kit._map_extra(ch3.kit._v2_area(legacy))['props']
 added=[p for p in current['props'] if p not in mapped];removed=[p for p in mapped if p not in current['props']];assert len(added)==(2 if ident=='pump' else 1) and not removed
 delta['ch3_'+ident]={'added':added,'removed':removed,'baseline_parent':parent,'mapper':'Existing _v2_area/_map_extra; current upper geometry retained. No assumption that all props simply shift16 rows.'}
 (base/(ident+'-original-map.json')).write_bytes(original)
 proof.append({'level':'ch3_'+ident,'before_props':len(mapped),'current_props':len(current['props']),'added':added,'removed':removed,'original_map_sha256':hashlib.sha256(original).hexdigest(),'current_generator_props_match':True})
(private/'prop-delta.json').write_text(json.dumps(delta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(base/'baseline-proof.json').write_text(json.dumps({'base':head,'original_bg44':'c80f5483fbb56f0f7f3feb15c782cb5625af0f5a','parent':parent,'rows':proof,'scope':'Original BG44 added props varied on actual current geometry/runtime; all current later changes retained. No whole historical checkout or frame performance claim.'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
s=(root/'work/bg43-current/probe.gd').read_text().replace('BG43','BG44').replace('bg43','bg44').replace('43','44')
start=s.index('\t\t# Restore the original two door visuals');end=s.index('\t\tHeldLighting55.preserve_physics_bodies',start);s=s[:start]+s[end:]
s=s.replace('original BG44 props and original door visuals','original BG44 added props').replace('and original door visuals; later unrelated props retained','; later unrelated props retained')
(private/'probe.gd').write_text(s,encoding='utf-8',newline='\n');(private/'probe.tscn').write_bytes((root/'work/bg43-current/probe.tscn').read_bytes().replace(b'bg43',b'bg44'))
cfg=json.loads((root/'assets_src/pipeline/scene_props.json').read_text(encoding='utf-8'));props=[p for p in cfg['props'] if p['id'] in {'sluice_hall__drain_wheel','sluice_hall__branch_panel_closed','sluice_hall__branch_panel_open','mezzanine__notice_terminal'}];assert len(props)==4 and {p['seed'] for p in props}==set(range(7601,7605))
(base/'pipeline-extract.json').write_text(json.dumps({'styles':cfg['styles'],'defaults':cfg['defaults'],'props':props},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
driver=(primary/'work/run-bg43-reproduction-20261118.py').read_text().replace('bg43','bg44').replace("['ch3_plaza']","['ch3_pump','ch3_mezzanine']")
driver=driver.replace("assert r.returncode==0 and row['script_errors']==0 and not row['engine_error'] and row['source_held']","assert r.returncode in [0,1] and row['script_errors']==0 and not row['engine_error'] and row['source_held']")
driver=driver.replace('    all_passed=True','    all_passed=all(r["exit"]==0 for r in runs)')
(primary/'work/run-bg44-reproduction-20261118.py').write_text(driver,encoding='utf-8')
ticket=next((primary/'pm/Nest-Egg-BG').glob('[[]BG-44]*.md'));text=ticket.read_text(encoding='utf-8');assert '> 狀態：審查中' in text;ticket.write_text(text.replace('> 狀態：審查中','> 狀態：進行中',1),encoding='utf-8')
with (primary/'design/20-campaign-experience/CH2_CH3_SCENE_GAPS.md').open('a',encoding='utf-8') as f:f.write('\n## BG-44 的泵室與夾層重驗（2026-11-18）\n\n保留目前上下層路線，以原票提交之前的擺設經既有版面映射作對照，只切換排水輪、配電盤與通知終端三件擺設。映射使用現行產生器，不假設所有舊擺設都直接下移十六格；夾層終端位於現行上層互動點。重驗高低畫質原始 HDR、全亮擺放、排水輪角度／指針與配電盤狀態、正式通知對話。若需局部光影資料，環境音、腳步與配樂對應也一併保留。\n')
p=primary/'work/queue-20261117-progress.json';state=json.loads(p.read_text(encoding='utf-8'));state['updated']=datetime.datetime.now(datetime.timezone.utc).isoformat();state['branch']='codex/ticket-work-20261118-bg44';state['published']['BG43-complete']=head
packet=json.loads((previous/'delivery-packet/result.json').read_text());read=json.loads((previous/'delivery-packet/reader.log').read_text())
state['BG43_completed']={'commit':head,'packet':packet,'reader':read,'source_count':10090,'advance':advance,'remaining_open':67,'scope':'Original regional minimum contract,5pointmain declines/q disclosed. No enemy observations. Local profiletone1.1/materialedge.9 plus originalwet/ambience/music. 16reviewpagesviewed incl4identicalSHAfactors,44nativeinteractionPNG,all57changedgroupspassed. Failed first54groups/63158oneAmbienceerror preserved.'}
state.pop('BG43_active',None);state['BG44_active']={'base':head,'state':'House original delta prepared, pump2new/mezzanine1new, no removed borrowedprops. Current generator exactmatch, no newproduct change. Four native quality/level jobs next; standalone state may reuse actual source-identity corrected BG43 fixture.'};p.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'base':head,'proof':proof,'source_count':len(source),'remaining_open':67},ensure_ascii=False),flush=True)
