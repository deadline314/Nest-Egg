from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117');private=root/'work/bg44-current';base=Path('D:/NestEggVerification/evidence-20261117/bg44-current')
old=(private/'probe-framed.gd').read_bytes();(base/'framed-baseline/failed-probe.gd').write_bytes(old)
needle=b'        camera.force_update_scroll()';assert old.count(needle)==1
(private/'probe-framed-v2.gd').write_bytes(old.replace(needle,b'        camera.reset_smoothing()\n'+needle))
(private/'probe-framed-v2.tscn').write_bytes((private/'probe-framed.tscn').read_bytes().replace(b'/probe-framed.gd',b'/probe-framed-v2.gd'))
s=(p/'run-bg44-framed-20261118.py').read_text().replace("out=base/'framed-baseline'","out=base/'framed-baseline-v2'").replace('/probe-framed.tscn','/probe-framed-v2.tscn')
(p/'run-bg44-framed-v2-20261118.py').write_text(s,encoding='utf-8')
print('Use the existing tour reset_smoothing sequence before force_update_scroll; old failed crop guard+script retained. Original metrics/positions/coverage unchanged.')
