from pathlib import Path
import json, os, re, shutil, subprocess, sys, urllib.request

root=Path(__file__).resolve().parents[1]
out=root/'pm/Nest-Egg-BG/attachments/BG-52-rocm-runtime/lifecycle-v2'
out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools/comfyui'))
import comfy_guard
env=dict(os.environ,COMFYUI_DIR='D:/ComfyUI',COMFYUI_PYTHON='D:/ComfyUI/.venv-rocm/Scripts/python.exe')
base=['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(root/'tools/comfyui/start_comfyui.ps1'),'-Port','8189']
results=[]
with comfy_guard.server_lock():
 try:
  for name,flags in [('start',['-Safe','-TimeoutSec','120']),('reuse',['-Safe']),('restart',['-Restart','-Safe','-TimeoutSec','120'])]:
   with (out/(name+'.log')).open('wb') as log:
    result=subprocess.run([*base,*flags],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
   results.append({'case':name,'exit':result.returncode})
   if result.returncode: raise RuntimeError(f'{name} failed, see {name}.log')
   stats=json.load(urllib.request.urlopen('http://127.0.0.1:8189/system_stats',timeout=5))
   (out/(name+'-stats.json')).write_text(json.dumps(stats,indent=2),encoding='utf-8')
   if '9070 XT' not in stats['devices'][0]['name']:raise RuntimeError('Wrong GPU')
   if stats['system']['pytorch_version'] != '2.13.0+rocm10.0.0':raise RuntimeError('Wrong PyTorch environment')
   argv=stats['system']['argv']
   if '--database-url' not in argv or 'service-8189/user/comfyui.db' not in argv[argv.index('--database-url')+1]:raise RuntimeError('Database is not explicitly isolated')
   server_log=Path('D:/ComfyUI/nest_egg/comfy-8189.log')
   shutil.copy2(server_log,out/(name+'-server.log'))
   if re.search(rb'\[ERROR\]|Traceback|IMPORT FAILED',server_log.read_bytes()):raise RuntimeError(f'{name}: server diagnostics failed')
 finally:
  with (out/'stop.log').open('wb') as log:
   stopped=subprocess.run([*base,'-Stop'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=40)
  results.append({'case':'stop','exit':stopped.returncode})
  try:
   urllib.request.urlopen('http://127.0.0.1:8189/system_stats',timeout=2)
   results.append({'case':'stopped_endpoint_unreachable','passed':False})
  except OSError:
   results.append({'case':'stopped_endpoint_unreachable','passed':True})
  (out/'result.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(results),flush=True)
