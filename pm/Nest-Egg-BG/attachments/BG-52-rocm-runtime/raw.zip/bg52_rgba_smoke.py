"""One existing Qwen character workflow; a runtime sample, not an adopted character."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time

root=Path(__file__).resolve().parents[1]
out=root/'pm/Nest-Egg-BG/attachments/BG-52-rocm-runtime'
out.mkdir(parents=True,exist_ok=True)
(out/'.gdignore').touch()
reuse_service='--reuse-service' in sys.argv
port=8188 if reuse_service else 8189
os.environ.update(COMFY_HOST=f'http://127.0.0.1:{port}',COMFYUI_DIR='D:/ComfyUI',
                  COMFYUI_PYTHON='D:/ComfyUI/.venv-rocm/Scripts/python.exe',COMFY_MAX_RETRIES='0',
                  COMFY_STALL_S='900',COMFY_COLD_STALL_S='900',
                  COMFYUI_FLAGS='--disable-auto-launch --disable-smart-memory --reserve-vram 2.5',
                  OUT_DIR=str(out/'generated'))
if reuse_service: os.environ['COMFY_LOG']=str(out/'unowned-service-no-log.log')
sys.path.insert(0,str(root/'tools/comfyui'))
import comfy_api, comfy_guard
from field_design import STYLE,POSE,FINISH,RGBA
from PIL import Image
if reuse_service:
 def require_existing_server():
  if not comfy_guard.server_up(): raise RuntimeError('The shared service stopped; this client will not start or restart it')
 comfy_guard.ensure_server=require_existing_server

description=('An adult female harbour emergency medic, age 45, average build, short practical dark hair, '
             'a slightly crooked nose and tired eyes. A faded grey-green short work jacket ending at '
             'the waist, closed over a plain dark shirt, reinforced charcoal work trousers and '
             'scuffed ankle boots. One small plain first-aid patch on the upper sleeve. '
             'No weapon, no bag or loose accessories, no glowing trim.')
prompt=RGBA[0]+STYLE+POSE+description+FINISH+RGBA[1]
(out/'prompt.txt').write_text(prompt,encoding='utf-8')
original_run=comfy_api.run
def record_graph(graph,name,retries=None):
 (out/'graph.json').write_text(json.dumps(graph,indent=2,ensure_ascii=False),encoding='utf-8')
 return original_run(graph,name,retries=0)
comfy_api.run=record_graph
report={'seed':26711,'requested_size':[832,1216],'steps':25,'candidate_only':True,
        'python':sys.executable,'started_at':time.strftime('%Y-%m-%dT%H:%M:%S%z'),
        'shared_existing_service':reuse_service,'service_port':port}
started=time.monotonic()
try:
 # Startup has its own critical section. Do not wrap qwen() in this non-reentrant lock.
 with comfy_guard.server_lock():
  comfy_guard.ensure_server()
 report['server_stats_before']=json.loads(comfy_api._get('/system_stats').decode())
 paths=comfy_api.qwen(prompt,w=832,h=1216,steps=25,seed=26711,prefix='bg52_medic_rgba',
                      retries=1,reuse=False,cache_device='off')
 picture=paths[0]
 with Image.open(picture) as im:
  report.update(image=str(picture.relative_to(root)),mode=im.mode,size=list(im.size),
                sha256=hashlib.sha256(picture.read_bytes()).hexdigest())
  if im.mode!='RGBA': raise RuntimeError('Qwen output does not have native RGBA channels')
  histogram=im.getchannel('A').histogram()
  report['alpha_histogram']=histogram
  report['alpha_bbox']=im.getchannel('A').getbbox()
  if not histogram[0] or not sum(histogram[250:]):
   raise RuntimeError('Output lacks transparent background or an opaque subject')
  if im.size!=(832,1216): raise RuntimeError('Native output dimensions do not match the requested source')
 report['passed']=True
except Exception as error:
 report.update(passed=False,error=f'{type(error).__name__}: {error}')
finally:
 report['elapsed_seconds']=time.monotonic()-started
 (out/'generation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 if not reuse_service:
  log=Path('D:/ComfyUI/nest_egg/comfy-8189.log')
  if log.exists(): shutil.copyfile(log,out/'service-generation.log')
  subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',
                  str(root/'tools/comfyui/start_comfyui.ps1'),'-Port','8189','-Stop'],cwd=root)
print(json.dumps({k:v for k,v in report.items() if k!='alpha_histogram'},ensure_ascii=False),flush=True)
raise SystemExit(0 if report.get('passed') else 1)
