from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg39-current');out=base/'calibration-retained';out.mkdir(exist_ok=False)
paths=json.loads((base/'native/source-before.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths
(base/'native/source-after.json').write_text(json.dumps(before,indent=2)+'\n')
private=root/'work/bg39-current'
current=json.loads((root/'data/levels/ch3_gate_hall_map.json').read_text())
old=json.loads((base/'original-map.json').read_text())
camera=next(p for p in old['props'] if p['id']=='accounting_lobby__dome_camera')
assert camera not in current['props'];current['props'].append(camera)
(private/'retained-map.json').write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
theme=(root/'data/environment/themes/ch3_gate_hall.tres').read_text().replace('"res://data/environment/scene_props/gate_hall",','"res://data/environment/scene_props/gate_hall", "res://data/environment/scene_props/accounting_lobby",')
(private/'retained-theme.tres').write_text(theme)
level=(root/'data/levels/ch3_gate_hall.tres').read_text().replace('res://data/levels/ch3_gate_hall_map.json','res://work/bg39-current/retained-map.json').replace('res://data/environment/themes/ch3_gate_hall.tres','res://work/bg39-current/retained-theme.tres')
(private/'retained-level.tres').write_text(level)
tour=(root/'tools/scene_tour.gd').read_bytes().replace(b'var path := "res://data/levels/%s.tres" % level_id',b'var path := "res://work/bg39-current/retained-level.tres"')
(private/'retained-tour.gd').write_bytes(tour)
(private/'retained-phase.gd').write_bytes((root/'tools/readability_phase_probe.gd').read_bytes().replace(b'extends "res://tools/scene_tour.gd"',b'extends "res://work/bg39-current/retained-tour.gd"',1))
(private/'calibration.gd').write_text('''extends "res://work/bg39-current/retained-phase.gd"
func _ready() -> void:
    var data := PropLibrary.find(&"gate_hall__guard_booth", "res://data/environment/scene_props/gate_hall")
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--booth-radius="):
            data.light_radius = float(argument.trim_prefix("--booth-radius="))
    print("BG39_CALIBRATION radius=",data.light_radius)
    super._ready()
func _frame_interval_ms() -> float:
    for node in get_tree().get_nodes_in_group(PropNode.GROUP):
        if node.data.id == &"gate_hall__guard_booth":
            print("BG39_ACTUAL radius=",node.data.light_radius," texture_scale=",node._light.texture_scale," at=",node._light.global_position)
    return await super._frame_interval_ms()
''')
(private/'calibration.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg39-current/calibration.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
runs=[]
for radius in [48]:
    for quality in ['low','high']:
        folder=out/(str(radius)+'-'+quality);folder.mkdir();env=os.environ.copy()
        for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg39-current/calibration.tscn','--','--out='+str(folder),'--level=ch3_gate_hall','--tag=tour','--quality='+quality,'--cells=2:1','--player','--fixed-aim','--cycle-samples=16','--booth-radius='+str(radius)]
        with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
        raw=(folder/'raw.log').read_bytes();assert r.returncode==0 and b'ERROR:' not in raw and before==snapshot()
        shot=json.loads((folder/'ch3_gate_hall/tour-index.json').read_text())['shots'][0]
        row={'radius':radius,'quality':quality,'exit':r.returncode,'command':command,**{k:shot[k] for k in ['player_contrast','edge_contrast','cycle_player_min','cycle_edge_min']}}
        runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
