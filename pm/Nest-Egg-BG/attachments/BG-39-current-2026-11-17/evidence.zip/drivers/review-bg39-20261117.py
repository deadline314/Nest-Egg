from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,re
root=Path('C:/Users/stanl/Github/Nest-Egg');base=Path('D:/NestEggVerification/evidence-20261117/bg39-current')
out=base/'review';out.mkdir(exist_ok=False);font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',17)
pages=[]
for mode in ['normal','flat']:
    for quality in ['low','high']:
        for row in range(3):
            canvas=Image.new('RGB',(1280,416),(24,24,24));draw=ImageDraw.Draw(canvas)
            for side_index,(side,level) in enumerate([('before','bg39_before'),('after','ch3_gate_hall')]):
                folder=base/'native'/(side+'-'+quality+'-'+mode)/level
                report=json.loads((folder/'tour-index.json').read_text())
                shots=[s for s in report['shots'] if s['row']==row];assert len(shots)==4
                for column,shot in enumerate(shots):
                    image=Image.open(folder/shot['file']).convert('RGB');assert image.size==(640,360)
                    x=column*320;y=side_index*208
                    canvas.paste(image.resize((320,180)),(x,y+28));draw.text((x+4,y+4),side+' '+quality+' '+mode+' '+str(column)+':'+str(row),font=font,fill='white')
            name=quality+'-'+mode+'-row'+str(row)+'.png';canvas.save(out/name);pages.append(name)
cfg=json.loads((base/'pipeline-extract.json').read_text(encoding='utf-8'))
canvas=Image.new('RGB',(1000,1100),(30,33,40));draw=ImageDraw.Draw(canvas)
for i,entry in enumerate(cfg['props']):
    ident=entry['id'];data=(root/('data/environment/scene_props/gate_hall/'+ident+'.tres')).read_text(encoding='utf-8')
    match=re.search(r'^size = Vector2\(([^,]+),\s*([^)]+)\)',data,re.M);size=[float(match[1]),float(match[2])]
    image=Image.open(root/('art/environment/scene_props/gate_hall/'+ident+'.png')).convert('RGBA')
    x=i%4*250;y=i//4*520
    image=image.resize((max(1,round(size[0]*4)),max(1,round(size[1]*4))))
    canvas.paste(image,(x+(250-image.width)//2,y+300-image.height),image)
    draw.line((x+10,y+300,x+240,y+300),fill=(150,150,155),width=1)
    for line,text in enumerate([ident.removeprefix('gate_hall__'),str(entry['height_m'])+' m / '+str(size[1])+' world px','common scale: 4 px / world px','seed '+str(entry['seed'])]):
        draw.text((x+8,y+320+line*25),text,font=font,fill='white')
canvas.save(out/'props-common-scale.png');pages.append('props-common-scale.png')
(out/'pages.json').write_text(json.dumps(pages,indent=2)+'\n');print(json.dumps(pages),flush=True)
