from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg39-current');out=base/'extras';out.mkdir(exist_ok=False)
paths=json.loads((base/'native-final/source-after.json').read_text())
private=root/'work/bg39-current'
(private/'gate-observer.gd').write_text('extends "res://work/bg39-current/observer.gd"\nfunc _place_player(level: Level, center: Vector2, view: Vector2) -> void:\n    super._place_player(level,center,view)\n    level.player.visible = true\n    level.player.global_position = Vector2(280,318)\nfunc _frame_interval_ms() -> float:\n    for node in get_tree().get_nodes_in_group(NpcActor.GROUP):\n        if node.data.id==&"ch3_scanner_gate":\n            print("BG39_GATE ",JSON.stringify({"world":[node.global_position.x,node.global_position.y],"present":node.is_present(),"in_range":node._player_in_range,"prompt_visible":node._prompt.is_visible_in_tree(),"prompt":node.data.prompt}))\n    return await super._frame_interval_ms()\n')
(private/'gate-observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg39-current/gate-observer.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');runs=[]
for name,scene,args in [('gate-context','res://work/bg39-current/gate-observer.tscn',['--level=ch3_gate_hall','--tag=after-context','--quality=high','--cells=0:2','--player']),('pack','res://tools/screenshot.tscn',['--scenario=scene_packs','--scene=gate_hall','--lighting=facility'])]:
    folder=out/name;folder.mkdir();env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60',scene,'--','--out='+str(folder)]+args
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
    raw=(folder/'raw.log').read_bytes();png=[p.relative_to(folder).as_posix() for p in folder.rglob('*.png')]
    row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'png':png}
    if name=='gate-context':
        row['observations']=[json.loads(line.split(b'BG39_ENV ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG39_ENV ')]
        gate=[json.loads(line.split(b'BG39_GATE ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG39_GATE ')];row['gate']=gate
        assert len(gate)==1 and gate[0]['in_range'] and gate[0]['prompt_visible'] and gate[0]['present']
        assert len(row['observations'])==1 and row['observations'][0]['environment'] and row['observations'][0]['count']==1 and row['observations'][0]['glow']
    else:assert b'props  9  OK' in raw and b'== 9 props in 1 scene(s)' in raw
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode('utf-8',errors='replace')[-1500:],flush=True)
    assert r.returncode==0 and row['script_errors']==0 and not row['engine_error'] and row['source_held'] and len(png)==1
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'result.json').write_text(json.dumps({'passed':True,'source_held':before==snapshot()},indent=2)+'\n')
