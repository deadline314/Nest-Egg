from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg39-current');out=base/'aftercare';out.mkdir(exist_ok=False)
private=root/'work/bg39-current'
tour=(root/'tools/scene_tour.gd').read_bytes();needle=b'GameState.start_new_run(GameState.difficulties[1])';assert tour.count(needle)==1
(private/'aftercare-tour.gd').write_bytes(tour.replace(needle,needle+b'\n\tGameState.set_flag(&"ch3_janus_disabled", true, false)\n\tGameState.set_flag(&"ch3_janus_aftercare_done", true, false)'))
(private/'aftercare-observer.gd').write_text('''extends "res://work/bg39-current/aftercare-tour.gd"
func _ready() -> void:
    seed(481111)
    super._ready()
func _frame_interval_ms() -> float:
    var npcs: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
        npcs.append({"id":str(node.data.id),"present":node.is_present(),"world":[node.global_position.x,node.global_position.y],"pose":str(node._actor.pose) if node._actor!=null else "none","prompt":node.data.prompt})
    var props: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(PropNode.GROUP):
        if str(node.data.id).begins_with("gate_hall__") or node.data.id==&"clinic__gatekeeper_desk":
            props.append({"id":str(node.data.id),"world":[node.global_position.x,node.global_position.y],"size":[node.data.size.x,node.data.size.y],"layer":node.data.layer})
    var environment := get_viewport().find_world_3d().environment
    print("BG39_AFTERCARE ",JSON.stringify({"npcs":npcs,"props":props,"enemies":get_tree().get_nodes_in_group(&"enemies").size(),"environment":environment!=null,"glow":environment!=null and environment.glow_enabled,"hdr":get_viewport().use_hdr_2d,"quality":Settings.get_light_quality()}))
    return await super._frame_interval_ms()
''')
(private/'aftercare-observer.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg39-current/aftercare-observer.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
paths=json.loads((base/'native-final/source-after.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths
runs=[]
for quality in ['low','high']:
    folder=out/quality;folder.mkdir();env=os.environ.copy()
    for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
    command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg39-current/aftercare-observer.tscn','--','--out='+str(folder),'--level=ch3_gate_hall','--tag=aftercare','--quality='+quality,'--cells=0:2,1:2','--player']
    with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
    raw=(folder/'raw.log').read_bytes();observations=[json.loads(line.split(b'BG39_AFTERCARE ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG39_AFTERCARE ')]
    row={'quality':quality,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'observations':observations}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    assert r.returncode==0 and row['script_errors']==0 and not row['engine_error'] and row['source_held'] and len(observations)==2
    for item in observations:
        assert item['enemies']==0 and item['environment'] and item['glow'] and item['hdr']
        keeper=next(n for n in item['npcs'] if n['id']=='ch3_gatekeeper');assert keeper['present'] and keeper['pose']=='sit'
        desk=next(p for p in item['props'] if p['id']=='clinic__gatekeeper_desk')
        stool=next(p for p in item['props'] if p['id']=='gate_hall__desk_stool')
        assert abs(stool['world'][0]+stool['size'][0]/2-keeper['world'][0])<=8
        assert abs(stool['world'][1]+stool['size'][1]-keeper['world'][1])<=2
    print(quality,'actual aftercare NPC seated / existing desk and stool / 2 PNG',flush=True)
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'passed':True,'source_held':True},indent=2)+'\n')
