from pathlib import Path
import hashlib,json,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg39-current');out=base/'calibration';out.mkdir(exist_ok=False)
paths=json.loads((base/'native/source-before.json').read_text())
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot();assert before==paths
(base/'native/source-after.json').write_text(json.dumps(before,indent=2)+'\n')
private=root/'work/bg39-current'
(private/'calibration.gd').write_text('''extends "res://work/bg39-current/after-observer.gd"
func _ready() -> void:
    var data := load("res://data/environment/scene_props/gate_hall/gate_hall__guard_booth.tres") as PropData
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--booth-radius="):
            data.light_radius = float(argument.trim_prefix("--booth-radius="))
    print("BG39_CALIBRATION radius=",data.light_radius)
    super._ready()
''')
(private/'calibration.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg39-current/calibration.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
runs=[]
for radius in [70,110]:
    for quality in ['low','high']:
        folder=out/(str(radius)+'-'+quality);folder.mkdir();env=os.environ.copy()
        for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg39-current/calibration.tscn','--','--out='+str(folder),'--level=ch3_gate_hall','--tag=tour','--quality='+quality,'--cells=2:1','--player','--fixed-aim','--cycle-samples=16','--booth-radius='+str(radius)]
        with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
        raw=(folder/'raw.log').read_bytes();assert r.returncode==0 and b'ERROR:' not in raw and before==snapshot()
        shot=json.loads((folder/'ch3_gate_hall/tour-index.json').read_text())['shots'][0]
        row={'radius':radius,'quality':quality,'exit':r.returncode,'command':command,**{k:shot[k] for k in ['player_contrast','edge_contrast','cycle_player_min','cycle_edge_min']}}
        runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
