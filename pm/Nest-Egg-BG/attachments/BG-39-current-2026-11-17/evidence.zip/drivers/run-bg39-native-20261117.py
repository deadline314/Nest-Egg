from pathlib import Path
import hashlib,json,math,os,subprocess
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg39-current');out=base/'native';out.mkdir(exist_ok=False)
private=root/'work/bg39-current'
tour=(root/'tools/scene_tour.gd').read_bytes()
needle=b'var path := "res://data/levels/%s.tres" % level_id'
assert tour.count(needle)==1
(private/'before-tour.gd').write_bytes(tour.replace(needle,b'var path := "res://work/bg39-current/before-level.tres"'))
phase=(root/'tools/readability_phase_probe.gd').read_bytes()
assert phase.count(b'extends "res://tools/scene_tour.gd"')==1
(private/'before-phase.gd').write_bytes(phase.replace(b'extends "res://tools/scene_tour.gd"',b'extends "res://work/bg39-current/before-tour.gd"',1))
observer=(private/'observer.gd').read_bytes()
for name,parent in [('before-observer','res://work/bg39-current/before-phase.gd'),('after-observer','res://tools/readability_phase_probe.gd')]:
    source=observer.replace(b'extends "res://tools/scene_tour.gd"',('extends "'+parent+'"').encode(),1)
    (private/(name+'.gd')).write_bytes(source)
    (private/(name+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg39-current/'+name+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n')
paths=json.loads(Path('D:/NestEggVerification/evidence-20261117/bg38-current/checks/source-after.json').read_text())
private_paths=[p for p in private.glob('*') if p.is_file()]
def snapshot():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
def private_snapshot():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in private_paths}
before=snapshot();private_before=private_snapshot()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');(out/'private-before.json').write_text(json.dumps(private_before,indent=2)+'\n');runs=[]
for flat in [False,True]:
    for quality in ['low','high']:
        for side,level in [('before','bg39_before'),('after','ch3_gate_hall')]:
            name=side+'-'+quality+('-flat' if flat else '-normal');folder=out/name;folder.mkdir()
            env=os.environ.copy()
            for k in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']:env[k]=str(folder/'private-profile'/k)
            command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe',str(primary/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','640x360','--fixed-fps','60','res://work/bg39-current/'+side+'-observer.tscn','--','--out='+str(folder),'--level='+level,'--tag=tour','--quality='+quality]
            if flat:command.append('--flat')
            else:command.extend(['--player','--fixed-aim','--cycle-samples=16'])
            if name=='after-high-flat':command.append('--preexisting-environment')
            with (folder/'raw.log').open('wb') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
            raw=(folder/'raw.log').read_bytes();observations=[json.loads(line.split(b'BG39_ENV ',1)[1]) for line in raw.splitlines() if line.startswith(b'BG39_ENV ')]
            index=json.loads((folder/level/'tour-index.json').read_text())
            row={'name':name,'command':command,'exit':r.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'engine_error':b'ERROR:' in raw,'source_held':before==snapshot(),'private_held':private_before==private_snapshot(),'observations':observations,'shots':len(index['shots'])}
            runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode('utf-8',errors='replace')[-1200:],flush=True)
            assert row['script_errors']==0 and not row['engine_error'] and row['source_held'] and row['private_held'] and row['shots']==12
            assert len(observations)==12 and all(o['environment'] and o['glow'] and o['count']==1 and o['hdr'] and o['quality']==(0 if quality=='low' else 2) and o['size']==[640,360] for o in observations)
            if side=='after' or flat:assert r.returncode==0
            for shot in index['shots']:
                if 'player_contrast' in shot:
                    assert all(math.isfinite(shot[k]) for k in ['player_contrast','edge_contrast','cycle_player_min','cycle_edge_min'])
                    assert len(shot['cycle_samples_raw'])==16
for quality in ['low','high']:
    left=json.loads((out/('before-'+quality+'-normal')/'bg39_before/tour-index.json').read_text())['shots']
    right=json.loads((out/('after-'+quality+'-normal')/'ch3_gate_hall/tour-index.json').read_text())['shots']
    assert len(left)==len(right)==12
    for a,b in zip(left,right):
        assert a['world']==b['world'] and a.get('player_world')==b.get('player_world')
        if 'enemy_contrast' in b:assert min(b['enemy_contrast'])>=.45
    for key in ['player_contrast','edge_contrast']:
        old=min(x[key] for x in left if key in x);new=min(x[key] for x in right if key in x)
        assert new>=old,(quality,key,old,new)
    old_enemies=[v for x in left for v in x.get('enemy_contrast',[])]
    new_enemies=[v for x in right for v in x.get('enemy_contrast',[])]
    assert old_enemies and new_enemies
    assert min(new_enemies)>=min(old_enemies),(quality,'enemy',min(old_enemies),min(new_enemies))
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n');(out/'private-after.json').write_text(json.dumps(private_snapshot(),indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'all_passed':True,'source_held':before==snapshot(),'private_held':private_before==private_snapshot()},indent=2)+'\n')
