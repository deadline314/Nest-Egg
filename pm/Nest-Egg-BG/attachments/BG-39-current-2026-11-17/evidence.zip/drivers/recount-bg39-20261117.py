from pathlib import Path
import json,math
base=Path('D:/NestEggVerification/evidence-20261117/bg39-current');native=base/'native-final'
old=json.loads((base/'native/source-before.json').read_text());new=json.loads((native/'source-before.json').read_text())
changed=[p for p in old if old[p]!=new[p]]
assert sorted(changed)==['data/levels/ch3_gate_hall_map.json','tools/level/build_ch3.py']
assert new==json.loads((native/'source-after.json').read_text())
qualities=[]
for quality in ['low','high']:
    a=json.loads((native/('before-'+quality+'-normal')/'bg39_before/tour-index.json').read_text())['shots']
    b=json.loads((native/('after-'+quality+'-normal')/'ch3_gate_hall/tour-index.json').read_text())['shots']
    points=[]
    for left,right in zip(a,b):
        assert left['world']==right['world'] and left.get('player_world')==right.get('player_world')
        if 'player_contrast' not in left:continue
        assert left['fog_clock']==right['fog_clock'] and left['lamps']==right['lamps']
        assert right['passed'] and right['cycle_passed'] and right['player_contrast']>=.6 and right['edge_contrast']>=1
        points.append({'cell':[left['column'],left['row']],'world':left['player_world'],**{k:[left[k],right[k]] for k in ['player_contrast','edge_contrast','cycle_player_min','cycle_edge_min']},'player_decreased':right['player_contrast']<left['player_contrast']})
    assert len(points)==7
    minima={}
    for key in ['player_contrast','edge_contrast','cycle_player_min','cycle_edge_min']:
        left=min(p[key][0] for p in points);right=min(p[key][1] for p in points)
        assert math.isfinite(left) and math.isfinite(right) and right>=left
        minima[key]=[left,right]
    enemies=[[v for row in shots for v in row.get('enemy_contrast',[])] for shots in [a,b]]
    assert all(len(values)==2 for values in enemies) and min(enemies[1])>=max(.45,min(enemies[0]))
    minima['enemy_contrast']=[min(values) for values in enemies]
    qualities.append({'quality':quality,'minima':minima,'points':points})
result={'passed':True,'source_count':len(new),'changed_runtime_sources':changed,'qualities':qualities,'individual_player_decreases':sum(p['player_decreased'] for q in qualities for p in q['points']),'note':'Original regional minimum comparison; all point deltas retained. Native final driver completed exit0. Enemy medians cover one real boss in two overlapping views; cycles are player and edge only.'}
(base/'readability-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='qualities'},indent=2),flush=True)
