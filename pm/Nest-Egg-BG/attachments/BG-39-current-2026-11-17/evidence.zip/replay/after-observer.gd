extends "res://tools/readability_phase_probe.gd"
func _ready() -> void:
    seed(39)
    if OS.get_cmdline_user_args().has("--preexisting-environment"):
        add_child(LightKit.create_environment())
    super._ready()
func _frame_interval_ms() -> float:
    var environment := get_viewport().find_world_3d().environment
    var enemies: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(&"enemies"):
        enemies.append({"kind":str(node.get_script().get_global_name()),"world":[node.global_position.x,node.global_position.y]})
    print("BG39_ENV ",JSON.stringify({"enemies":enemies,"environment":environment!=null,"glow":environment!=null and environment.glow_enabled,
        "count":get_tree().root.find_children("*","WorldEnvironment",true,false).size(),"quality":Settings.get_light_quality(),
        "hdr":get_viewport().use_hdr_2d,"size":[get_viewport().get_texture().get_width(),get_viewport().get_texture().get_height()]}))
    return await super._frame_interval_ms()
