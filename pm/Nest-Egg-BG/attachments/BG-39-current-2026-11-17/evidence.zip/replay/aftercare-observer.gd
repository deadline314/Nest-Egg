extends "res://work/bg39-current/aftercare-tour.gd"
func _ready() -> void:
    seed(481111)
    super._ready()
func _frame_interval_ms() -> float:
    var npcs: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
        npcs.append({"id":str(node.data.id),"present":node.is_present(),"world":[node.global_position.x,node.global_position.y],"pose":str(node._actor.pose) if node._actor!=null else "none","prompt":node.data.prompt})
    var props: Array[Dictionary] = []
    for node in get_tree().get_nodes_in_group(PropNode.GROUP):
        if str(node.data.id).begins_with("gate_hall__") or node.data.id==&"clinic__gatekeeper_desk":
            props.append({"id":str(node.data.id),"world":[node.global_position.x,node.global_position.y],"size":[node.data.size.x,node.data.size.y],"layer":node.data.layer})
    var environment := get_viewport().find_world_3d().environment
    print("BG39_AFTERCARE ",JSON.stringify({"npcs":npcs,"props":props,"enemies":get_tree().get_nodes_in_group(&"enemies").size(),"environment":environment!=null,"glow":environment!=null and environment.glow_enabled,"hdr":get_viewport().use_hdr_2d,"quality":Settings.get_light_quality()}))
    return await super._frame_interval_ms()
