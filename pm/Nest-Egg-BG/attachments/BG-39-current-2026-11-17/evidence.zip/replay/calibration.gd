extends "res://work/bg39-current/after-observer.gd"
func _ready() -> void:
    var data := PropLibrary.find(&"gate_hall__guard_booth", "res://data/environment/scene_props/gate_hall")
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--booth-radius="):
            data.light_radius = float(argument.trim_prefix("--booth-radius="))
    print("BG39_CALIBRATION radius=",data.light_radius)
    super._ready()
func _frame_interval_ms() -> float:
    for node in get_tree().get_nodes_in_group(PropNode.GROUP):
        if node.data.id == &"gate_hall__guard_booth":
            print("BG39_ACTUAL radius=",node.data.light_radius," texture_scale=",node._light.texture_scale," at=",node._light.global_position)
    return await super._frame_interval_ms()
func _settle(frames: int) -> void:
    for node in get_tree().get_nodes_in_group(PropNode.GROUP):
        if node.data.id==&"gate_hall__guard_booth" and not node.has_meta(&"bg39_moved"):
            node.position.x += 96.0
            node.set_meta(&"bg39_moved",true)
    await super._settle(frames)
