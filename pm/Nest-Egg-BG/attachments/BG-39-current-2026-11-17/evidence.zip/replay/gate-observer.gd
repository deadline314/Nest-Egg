extends "res://work/bg39-current/observer.gd"
func _place_player(level: Level, center: Vector2, view: Vector2) -> void:
    super._place_player(level,center,view)
    level.player.disable_mode = CollisionObject2D.DISABLE_MODE_KEEP_ACTIVE
    level.player.visible = true
    level.player.global_position = Vector2(280,318)
func _frame_interval_ms() -> float:
    for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
        if node.data.id==&"ch3_scanner_gate":
            print("BG39_GATE ",JSON.stringify({"world":[node.global_position.x,node.global_position.y],"present":node.is_present(),"in_range":node._player_in_range,"prompt_visible":node._prompt.is_visible_in_tree(),"prompt":node.data.prompt}))
    return await super._frame_interval_ms()
