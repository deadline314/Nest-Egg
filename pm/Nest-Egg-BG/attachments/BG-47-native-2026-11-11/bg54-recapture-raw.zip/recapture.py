"""BG-47 recapture after BG-54. Run only after the shared GPU slot is released.

All stdout/stderr, source snapshots and generated evidence are preserved as bytes.
No product resources are moved or changed. Each Godot process uses isolated storage.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
GODOT = Path("C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe")
EXPECTED_HELPER_SHA256 = "390789818b405f341a6a0a24a880971353349c8c09dc907e9fd9d8538d98addd"
OUT = HERE / "bg54-recapture"
SOURCES = [
    "tools/viewport_capture.gd", "tools/bg47_native_probe.gd",
    "tools/bg47_native_probe.tscn", "tools/bg47_native_probe.gd.uid",
    "tools/fixture_states_probe.gd", "tools/screenshot.gd",
    "game/props/fixture_art.gd", "game/props/breakable.gd",
    "game/props/throwable.gd", "game/props/lift.gd",
    "game/props/mechanism_switch.gd", "game/props/power_switch.gd",
    "game/level/world_layers.gd", "core/light_kit.gd",
    "data/lighting/facility.tres", "data/lighting/warehouse_interior.tres",
    "data/levels/ch1_pawnshop.tres", "data/levels/ch1_warehouse.tres",
    "data/levels/ch1_pawnshop_map.json", "data/levels/ch1_warehouse_map.json",
    "tests/suite/test_props.gd", "tests/fixtures/props_map.json", "project.godot",
]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def snapshot(destination: Path) -> dict[str, str]:
    result = {}
    for relative in SOURCES:
        data = (ROOT / relative).read_bytes()
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        result[relative] = sha(data)
    for item in sorted((ROOT / "art/environment/fixtures").glob("*.png")):
        result[item.relative_to(ROOT).as_posix()] = sha(item.read_bytes())
    return result


def run(name: str, flags: list[str], prefix: str, expected_errors: int) -> dict:
    folder = OUT / name
    folder.mkdir(parents=True, exist_ok=True)
    before = snapshot(folder / "source-before")
    env = os.environ.copy()
    storage = folder / "_userdata"
    storage.mkdir(exist_ok=True)
    for variable in ("APPDATA", "LOCALAPPDATA", "XDG_DATA_HOME"):
        env[variable] = str(storage)
    command = [sys.executable, str(ROOT / "tools/comfyui/gpu_lock.py"), "--", str(GODOT),
               "--path", str(ROOT), "--rendering-driver", "vulkan",
               "--rendering-method", "forward_plus", "res://tools/bg47_native_probe.tscn",
               "--", *flags, f"--out={folder / 'images'}"]
    log = folder / "native.log"
    with log.open("wb") as stream:
        completed = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    raw = log.read_bytes()
    decode_error = None
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as error:
        decode_error = str(error)
        text = ""
    summary = re.search(rf"^{prefix} checks: (\d+), failures: (\d+)", text, re.MULTILINE)
    errors = re.findall(r"^(?:ERROR:|SCRIPT ERROR:).*", text, re.MULTILINE)
    loader_errors = [line for line in errors if line.startswith("ERROR: [FixtureArt] ")]
    unexpected = [line for line in errors if not line.startswith("ERROR: [FixtureArt] ")]
    diagnostics = re.findall(r"^.*(?:leaked at exit|resources still in use at exit|PagedAllocator).*$", text, re.MULTILINE)
    after = snapshot(folder / "source-after")
    probe_report_path = folder / "images/receipt.json"
    report = json.loads(probe_report_path.read_bytes()) if probe_report_path.is_file() else {}
    passed = (completed.returncode == 0 and summary is not None and int(summary[2]) == 0
              and len(loader_errors) == expected_errors
              and len(set(loader_errors)) == expected_errors and not unexpected and not diagnostics
              and before == after and decode_error is None
              and "Forward+ - Using Device #0: AMD - AMD Radeon RX 9070 XT" in text)
    result = {
        "name": name, "command": command, "exit_code": completed.returncode,
        "checks": int(summary[1]) if summary else None,
        "failures": int(summary[2]) if summary else None,
        "expected_loader_error_count": expected_errors,
        "loader_errors": loader_errors, "unexpected_errors": unexpected,
        "exit_diagnostics": diagnostics, "source_and_assets_unchanged": before == after,
        "source_sha256_before": before, "source_sha256_after": after,
        "log_sha256": sha(raw), "encoding": "raw process stdout/stderr bytes; strict UTF-8 audit",
        "decode_error": decode_error,
        "probe_receipt": report, "passed": passed,
        "images": [{"path": item.relative_to(OUT).as_posix(), "sha256": sha(item.read_bytes())}
                   for item in sorted((folder / "images").glob("*.png"))],
    }
    write_json(folder / "run.json", result)
    print(f"{name}: {result['checks']} checks, {result['failures']} failures, exit {completed.returncode}, audited={passed}", flush=True)
    return result


def main() -> int:
    if sha((ROOT / "tools/viewport_capture.gd").read_bytes()) != EXPECTED_HELPER_SHA256:
        raise RuntimeError("BG-54 capture helper fingerprint differs from the reviewed version")
    OUT.mkdir(exist_ok=True)
    results = [run("normal", [], "FIXTURE_STATES", 0),
               run("fallback", ["--fallback"], "BG47_FALLBACK", 15),
               run("warehouse", ["--campaign-barrel"], "BG47_WAREHOUSE", 0)]
    report = {
        "kind": "BG-47 fresh native captures after BG-54; no image re-encoding of old captures",
        "rendering": "Forward+ Vulkan / RX 9070 XT", "performance_measurement": False,
        "engine_sha256": {item.name: sha(item.read_bytes()) for item in
                          [GODOT, GODOT.with_name("Godot_v4.7.2-stable_win64.exe")]},
        "reviewed_helper_sha256": EXPECTED_HELPER_SHA256, "runs": results,
    }
    write_json(OUT / "manifest.json", report)
    # Preserve the runner and every fingerprinted source/log inside the immutable binary bundle.
    with zipfile.ZipFile(HERE / "bg54-recapture-raw.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        bundle.write(__file__, "recapture.py")
        for item in sorted(OUT.rglob("*")):
            if item.is_file() and "_userdata" not in item.relative_to(OUT).parts:
                bundle.write(item, item.relative_to(OUT).as_posix())
    return 0 if all(result["passed"] for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
