# BG-47 本機 Forward+ 驗收

2026-11-11，Godot `4.7.2.stable.official.ed1daf0bf`，日誌確認 `Vulkan 1.4.359 - Forward+ - AMD Radeon RX 9070 XT`。沒有更動遊戲物件、正式素材、LightKit 或全區光照；修改範圍是 BG-47 驗證工具與文件。指紋、程序結果及原圖 SHA-256 見 [receipt.json](receipt.json)，原始日誌、逐圖幾何帳本與完整原圖在 [raw.zip](raw.zip)。

每個程序的 `APPDATA`、`LOCALAPPDATA`、`XDG_DATA_HOME` 都隔離在本證據目錄；驗證設定另用自己的設定檔。原生程序以共享 GPU 鎖串行執行。其他專案亦有工作，本輪不量效能，不把截圖工具印的瞬時 FPS 當成遊戲效能。

| 路線 | 結果 |
|---|---|
| 正常 headless／native-final | 各 106 checks、0 failures；原生 17 圖，0 ERROR、0 退出洩漏 |
| fallback headless-final／native-fallback-final | 各 68 checks、0 failures；原生 5 圖，只有預期 15 條產品素材診斷，0 SCRIPT ERROR／其他 ERROR／退出洩漏 |
| control-final：保留正式素材，關閉故障注入 | 74 checks、19 個預期回退斷言失敗，exit 1；沒有引擎錯誤或退出洩漏。沒有把負控制當成產品失敗或通過 |
| warehouse-headless／warehouse-native | 各 4 checks、0 failures；原生 2 圖，0 ERROR／退出洩漏 |

正常路線沿既有真投射物破壞、升降與電源互動，新增原圖矩形和原碰撞相等、地面接觸差不超過 2px、非角色圖層在全部角色部件後面，以及玩家真正在移動平台接觸面上的檢查。導軌保持固定，平台承載面與寬度不變。正式當舖的兩個木箱由原關卡建立；為安排拍攝，故事入口標為已見，玩家提高耐久、移到拍攝位置並移除 AI，未宣稱自然通關。

倉庫路線讀取真正 `ch1_warehouse.tres`，選中原位 `(904,272)` 的正式燃料桶，保留地圖、原光照與所有燈光／天氣，只安排玩家與相機並抑制故事入口和 AI。真投射物令生命值 2→1，對應完整／破損 PNG，桶身位置不變；本體及貼圖 modulate 均為白色，沒有自訂材質。兩張正式原圖可看見桶身、危險標籤、破損斜裂與鋼圈缺口。無燈 facility 排列場中油桶細節確實偏暗，原圖完整保留；沒有調亮樣本去冒充正式修復，也沒有從該場地直接推論正式關卡缺陷。

回退路線先真的請求不存在的 `res://art/environment/fixtures/test_missing_prop_bg47_absent.png`，第二次請求沿用快取，產品只記一次路徑。另在獨立程序以 `Resource.take_over_path` 對十四個正式 PNG 路徑放入錯誤類型資源，讓真正的 `RigLibrary.optional_texture` 回傳 null，`FixtureArt.texture` 自行記錄路徑並走安全回退。沒有手動 push_error、沒有寫入 null 快取、沒有移動正式 PNG；資源覆寫只活在該程序，收尾撤回。十四個正式路徑加一個真缺檔路徑，各自恰有一次診斷；原始 PNG 前後 SHA-256 相同。

回退後三種可擊碎物仍保有原生命與實心碰撞，並可由真投射物破壞；平台和導軌使用原簡單畫法仍能載人，電源面板仍能以實際互動切電。不是以節點存在或引擎 exit 0 取代行為與退出診斷檢查。

本輪保留以下早期失敗：

- `fallback-headless-initial`／v2／verbose／v3／v4 使用舊 `chapter_01` 樣本，68／0 仍留下 940 ObjectDB、527 resources 等退出診斷。撤回路徑覆寫及 deferred quit 未解決；無覆寫對照亦有同類問題。v5 只改目前正式章節 `ch1_kasa` 後退出乾淨；最終 normal／fallback 再統一相同的正式章節與 facility 設定。這只是驗證樣本邊界，不代表舊章節或引擎缺陷已修復。
- 首輪原生 fallback 的 68 項中有 1 個取樣失敗：玩家腳底比平台高約 7.8px、`on_floor=false`。原等待只看平台相位，平台已在上升時會提早拍攝。最終等待真正接觸後才取樣，原 2px／on_floor 判準保持，正常與回退兩個程序同樣重跑成功。

上述失敗日誌與第一次原生原圖保留在 raw，不刪斷言、不加 known failure、不把正常程序的乾淨退出冒充早期失敗也乾淨。工具最終版本另加倉庫模式，原 normal／fallback 路線未因此調整；收據區分交付來源指紋與各次原始輸出。

無頭前置專項早於最後的搭台等待修正；修正後正常與回退兩個原生程序完整重跑，覆蓋最終取樣行為。沒有以較早的無頭結果冒稱每個歷史程序皆使用交付版相同位元組。

重跑（repo 根目錄，先設定自己的三個隔離使用者目錄環境變數；`$godot` 為 `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`）：

```powershell
& $godot --headless --path . res://tools/bg47_native_probe.tscn -- --out=<隔離輸出>
& $godot --headless --path . res://tools/bg47_native_probe.tscn -- --fallback --out=<隔離輸出>
& $godot --headless --path . res://tools/bg47_native_probe.tscn -- --fallback --no-override --out=<負控制輸出>
python tools/comfyui/gpu_lock.py -- $godot --path . --rendering-driver vulkan --rendering-method forward_plus res://tools/bg47_native_probe.tscn -- --out=<原生正常輸出>
python tools/comfyui/gpu_lock.py -- $godot --path . --rendering-driver vulkan --rendering-method forward_plus res://tools/bg47_native_probe.tscn -- --fallback --out=<原生回退輸出>
python tools/comfyui/gpu_lock.py -- $godot --path . --rendering-driver vulkan --rendering-method forward_plus res://tools/bg47_native_probe.tscn -- --campaign-barrel --out=<正式倉庫輸出>
```

原選擇器對這三個工具檔選出 0 個測試群組，以上直接工具專項全部另外執行，沒有把空選擇當通過。本票的正式外觀、支撐、遮擋與失敗回退已補齊；不代稱整章人工操作、實體手把、角色接縫或全遊戲暗部可讀性驗收。
