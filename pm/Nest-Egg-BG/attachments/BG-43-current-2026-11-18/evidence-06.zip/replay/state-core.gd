extends Node
var _out := ""
var _rows: Array[Dictionary] = []
var _routes: Array[String] = []
func _process(_delta: float) -> void:
    AimInput.using_gamepad = true
    AimInput._last_stick_dir = Vector2.RIGHT
func _ready() -> void:
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--out="): _out = arg.trim_prefix("--out=")
    assert(_out.is_absolute_path())
    get_tree().create_timer(180.0).timeout.connect(func(): get_tree().quit(3))
    _run.call_deferred()
func settle(frames := 40) -> void:
    for i in frames: await get_tree().process_frame
    await RenderingServer.frame_post_draw
func make_level(id: String) -> Level:
    var data := load("res://data/levels/"+id+".tres") as LevelData
    var authored_intro := data.intro_scene
    var authored_card := data.show_chapter_card
    data.intro_scene = &""
    data.show_chapter_card = false
    var level := Level.new()
    level.configure(data)
    add_child(level)
    level.area_requested.connect(func(path: String): _routes.append(path))
    level._arena_triggered = true
    for node in level.find_children("*", "", true, false):
        if node is EncounterZone: node.restore_state(true)
    for node in get_tree().get_nodes_in_group(&"enemies"): node.queue_free()
    level.player.health.setup(999, 0.0)
    await settle()
    level.player.disable_mode = CollisionObject2D.DISABLE_MODE_KEEP_ACTIVE
    level.player.process_mode = Node.PROCESS_MODE_DISABLED
    data.intro_scene = authored_intro
    data.show_chapter_card = authored_card
    assert(data.resource_path == "res://data/levels/"+id+".tres")
    return level
func move(level: Level, point: Vector2) -> void:
    level.player.process_mode = Node.PROCESS_MODE_INHERIT
    level.player.global_position = point
    level.player.velocity = Vector2.ZERO
    var camera := get_viewport().get_camera_2d() as LevelCamera
    if camera != null: camera.snap_to_target()
    await settle()
    assert(absf(level.player.global_position.y-point.y-2.0)<4.0, "Player must settle on the authored floor")
    level.player.process_mode = Node.PROCESS_MODE_DISABLED
    if camera != null: camera.snap_to_target()
    level.player._visual.rig._apply_fill(LightKit.character_fill)
    await settle(4)
func npc(level: Level, id: StringName) -> NpcActor:
    for node in level.find_children("*", "", true, false):
        if node is NpcActor and node.data.id == id: return node
    assert(false, str(id))
    return null
func reaction(level: Level) -> PropReaction:
    for node in level.find_children("*", "", true, false):
        if node is PropReaction and node.reaction_id == &"bridge_ladder": return node
    assert(false, "bridge_ladder")
    return null
func shot(level: Level, name: String, extra: Dictionary) -> void:
    await RenderingServer.frame_post_draw
    var image := get_viewport().get_texture().get_image()
    assert(image.save_png(_out.path_join(name+".png")) == OK)
    var row := {"name":name,"level":str(level.data.id),"quality":Settings.get_light_quality(),"flag":GameState.has_flag(&"ch2_sc1_open"),"player":[level.player.global_position.x,level.player.global_position.y]}
    var bounds := level.player._visual.rig.visual_bounds()
    row["visual_bounds"] = [bounds.position.x,bounds.position.y,bounds.size.x,bounds.size.y]
    row.merge(extra)
    _rows.append(row)
func check_npc(level: Level, id: StringName, name: String) -> NpcActor:
    var node := npc(level,id)
    await move(level,node.global_position+Vector2(-24,-2))
    assert(node.is_present() and node._player_in_range and node.interaction_available())
    assert(node._prompt.is_visible_in_tree())
    await shot(level,name,{"npc":str(id),"npc_world":[node.global_position.x,node.global_position.y],"in_range":node._player_in_range,"prompt_visible":node._prompt.is_visible_in_tree(),"prompt":node.data.prompt})
    return node
func bridge(level: Level, name: String, opened: bool) -> void:
    var r := reaction(level)
    var portal := level._portals[&"loading_sc1"] as Portal
    await move(level,portal.global_position+Vector2(-16,-2))
    assert(r.is_swapped()==opened and portal.is_open()==opened)
    assert(r._swap_node.visible==opened and r._light.color==Color("52d98c" if opened else "ff6a4a"))
    assert(absf(r._swap_node.global_position.y+r._swap_node.data.size.y-r.get_parent().global_position.y-r._size.y)<0.01)
    await shot(level,name,{"swapped":r.is_swapped(),"portal_open":portal.is_open(),"portal_available":portal.interaction_available(),"lamp":r._light.color.to_html(),"down_size":[r._swap_node.data.size.x,r._swap_node.data.size.y],"down_top":[r._swap_node.global_position.x,r._swap_node.global_position.y],"base_bottom":r.get_parent().global_position.y+r._size.y})
func _run() -> void:
    add_child(LightKit.create_environment())
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--quality="): Settings.set_light_quality(0 if arg.ends_with("low") else 2)
    Story.auto_skip = true
    Enemy.activation_culling_enabled = false
    GameState.start_new_run(GameState.difficulties[1])
    var level := await make_level("ch2_market")
    await check_npc(level,&"ch2_rent_window","rent-window")
    level.queue_free()
    await settle(3)
    level = await make_level("ch2_loading")
    await check_npc(level,&"ch2_collection_book","collection-book")
    await check_npc(level,&"ch2_drying_desk","drying-desk")
    await bridge(level,"bridge-closed",false)
    var locked := level._portals[&"loading_sc1"] as Portal
    assert(not locked.try_use() and _routes.is_empty())
    var lever := await check_npc(level,&"ch2_sc1_lever","bridge-lever")
    var talk_before := lever.talk_count
    assert(await lever._talk())
    assert(lever.talk_count==talk_before+1 and GameState.has_flag(&"ch2_sc1_open"))
    await bridge(level,"bridge-open",true)
    assert(locked.interaction_available() and locked.try_use())
    assert(_routes==["res://data/levels/ch2_market.tres"] and GameState.pending_portal==&"market_sc1")
    level.queue_free()
    await settle(3)
    level = await make_level("ch2_market")
    var back := level._portals[&"market_sc1"] as Portal
    await move(level,back.global_position+Vector2(-16,-2))
    assert(back.is_open())
    assert(back.try_use() and _routes.back()=="res://data/levels/ch2_loading.tres")
    level.queue_free()
    await settle(3)
    level = await make_level("ch2_loading")
    await bridge(level,"bridge-reentry",true)
    var writer := FileAccess.open(_out.path_join("states.json"),FileAccess.WRITE)
    assert(writer!=null)
    writer.store_string(JSON.stringify({"rows":_rows,"routes":_routes,"actual_lever_talk":true,"auto_skip":true,"fixture":"Level standalone; native collision monitoring, real NPC talk and Portal route requests; driver consumes route requests; enemies removed, invulnerable stationary player"},"  ")+"\n")
    writer.close()
    level.queue_free()
    await settle(3)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0)
