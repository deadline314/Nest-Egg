from pathlib import Path
import json
p=Path('C:/Users/stanl/Github/Nest-Egg/work');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg43-current');private=root/'work/bg43-current'
assert json.loads((base/'states-v2/result.json').read_text())['completed_producers']==1
(base/'states-v2/failed-probe.gd').write_bytes((private/'state.gd').read_bytes())
core=(root/'work/bg42-current/state-core.gd').read_text()
needle='var data := (load("res://data/levels/"+id+".tres") as LevelData).duplicate() as LevelData';assert core.count(needle)==1
core=core.replace(needle,'var data := load("res://data/levels/"+id+".tres") as LevelData\n    var authored_intro := data.intro_scene\n    var authored_card := data.show_chapter_card')
needle='    return level\nfunc move';assert core.count(needle)==1
core=core.replace(needle,'    data.intro_scene = authored_intro\n    data.show_chapter_card = authored_card\n    assert(data.resource_path == "res://data/levels/"+id+".tres")\n'+needle)
(private/'state-core.gd').write_text(core,encoding='utf-8',newline='\n')
s=(p/'run-bg43-state-v2-20261118.py').read_text().replace("out=base/'states-v2'","out=base/'states-v3'")
(p/'run-bg43-state-v3-20261118.py').write_text(s,encoding='utf-8')
print('Use actual authored LevelData resource path required by WorldPropAction; mask intro/card only during creation and restore original fields after settling. No cache takeover and no product edits.')
