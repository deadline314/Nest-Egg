from pathlib import Path
import copy,datetime,hashlib,json,re,subprocess,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/bg43-current');base.mkdir(exist_ok=False)
private=root/'work/bg43-current';private.mkdir(exist_ok=False)
head='eb40f91b7885faa65ac2a588fa79724fd8db4719'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==head
advance=json.loads((base.parent/'bg42-current/advance-published/result.json').read_text());assert advance['source_held'] and advance['source_count']==10088
paths=json.loads((base.parent/'bg42-current/checks-final/source-after.json').read_text());assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in paths.items())
(base/'source-base.json').write_text(json.dumps(paths,indent=2)+'\n')
parent='e676a2d96b78873860afad8a0d3aeada8f369eb0'
sys.dont_write_bytecode=True;sys.path.insert(0,str(primary/'tools/level'))
import build_ch3 as ch3
ch3.configure();kit=ch3.kit
current=json.loads((root/'data/levels/ch3_plaza_map.json').read_text())
assert kit._map_extra(ch3.build_plaza())['props']==current['props']
old_bytes=subprocess.check_output(['git','show',parent+':data/levels/ch3_plaza_map.json'],cwd=primary)
old=json.loads(old_bytes);legacy=ch3._build_plaza_v1();legacy.props=copy.deepcopy(old['props'])
mapped=kit._map_extra(kit._v2_area(legacy))['props']
removed=[p for p in mapped if p not in current['props']];added=[p for p in current['props'] if p not in mapped]
assert len(mapped)==5 and len(added)==3 and not removed
assert {p['react'] for p in added}=={'lift_control_box','freight_lift','plaza_outer_ladder'}
old_level=subprocess.check_output(['git','show',parent+':data/levels/ch3_plaza.tres'],cwd=primary)
data=(root/'data/levels/ch3_plaza.tres').read_text()
for ident in ['plaza_lift','plaza_ladder']:
    old_block=next(b for b in re.split(r'\n(?=\[)',old_level.decode()) if 'id = &"'+ident+'"' in b)
    block=next(b for b in re.split(r'\n(?=\[)',data) if 'id = &"'+ident+'"' in b)
    assert 'style = "door"' in old_block and 'style = "hidden"' in block
(base/'original-map.json').write_bytes(old_bytes);(base/'original-level.tres').write_bytes(old_level)
delta={'ch3_plaza':{'added':added,'removed':removed,'baseline_parent':parent,'legacy_offset':[0,16],'original_doors':['plaza_lift','plaza_ladder']}}
(private/'prop-delta.json').write_text(json.dumps(delta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
s=(root/'work/bg42-current/probe.gd').read_text().replace('BG42','BG43').replace('bg42','bg43').replace('42','43')
s=s.replace('var _original43: Array[PropNode] = []','var _original43: Array[CanvasItem] = []').replace('func _prop_visible43(node: PropNode, active: bool)','func _prop_visible43(node: CanvasItem, active: bool)')
needle='\t\tHeldLighting55.preserve_physics_bodies(_held55)'
assert s.count(needle)==1
doors='''\t\t# Restore the original two door visuals at today's actual portal anchors.
\t\t# The held parent disables areas/input; these copies never request travel.
\t\tfor entity in _held55._entities.get_children():
\t\t\tif not entity is Portal or str(entity.data.id) not in ["plaza_lift", "plaza_ladder"]: continue
\t\t\tassert(entity.data.style == "hidden")
\t\t\tvar original := Portal.new()
\t\t\tvar door := entity.data.duplicate() as PortalData
\t\t\tdoor.style = "door"
\t\t\toriginal.configure(door, entity.cell)
\t\t\toriginal.position = entity.position
\t\t\toriginal.z_index = entity.z_index
\t\t\t_held55._entities.add_child(original)
\t\t\toriginal._prompt.visible = false
\t\t\toriginal.visible = false
\t\t\t_original43.append(original)
'''
s=s.replace(needle,doors+needle)
start=s.index('\tif str(level.data.id) == "ch2_ledger_office":')
end=s.index('\tassert(candidate != null',start)
s=s[:start]+s[end:]
s=s.replace('original BG43 prop delta and local office profile','original BG43 props and original door visuals').replace('and local office profile; later unrelated props retained','and original door visuals; later unrelated props retained')
(private/'probe.gd').write_text(s,encoding='utf-8',newline='\n')
(private/'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg43-current/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript=ExtResource("1")\n')
proof={'base':head,'original_bg43':'245fa0d563336de8e351c41675843f053b0ed140','parent':parent,'old_props':len(mapped),'added':added,'removed':removed,'source_count':len(paths),'current_generator_props_match':True,'baseline':'Only original three prop additions and two original door visuals varied on current geometry/runtime. Same current market profile on both sides; later BG41 fill improvement retained. No historical whole-checkout claim.','ladder_geometry':{'up_bottom':33*16+3,'up_top':33*16+3-45,'down_bottom':33*16+3-45+90,'floor':36*16,'error':0},'original_sha256':{'map':hashlib.sha256(old_bytes).hexdigest(),'level':hashlib.sha256(old_level).hexdigest()}}
(base/'baseline-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
ticket=next((primary/'pm/Nest-Egg-BG').glob('[[]BG-43]*.md'));text=ticket.read_text(encoding='utf-8');assert '> 狀態：審查中' in text
ticket.write_text(text.replace('> 狀態：審查中','> 狀態：進行中',1),encoding='utf-8')
design=primary/'design/20-campaign-experience/CH2_CH3_SCENE_GAPS.md'
with design.open('a',encoding='utf-8') as f:f.write('\n## BG-43 的廣場重驗（2026-11-18）\n\n在目前的立體廣場保留原有路線與劇情條件，只對照貨梯、控制箱、外梯和原來兩扇出入口門的畫面。兩側均保留已交付的廣場補光；不把整份舊關卡當作現在的對照。外梯收起時上緣為 486、底邊為 531 世界像素；放下維持上緣，90 像素高的梯子底邊正好落在 576 的地面，無須改動位置。重新檢查紅／琥珀／綠燈、實際互動和往返出口，並在高低畫質保存原始 HDR 與修前修後巡覽。\n')
p=primary/'work/queue-20261117-progress.json';state=json.loads(p.read_text(encoding='utf-8'));state['updated']=datetime.datetime.now(datetime.timezone.utc).isoformat();state['branch']='codex/ticket-work-20261118-bg43';state['published']['BG42-complete']=head
state['BG42_completed']={'commit':head,'paths':38,'tests':'23 groups /45331 checks /0 new /0 known;32maps0error0warn;assets/importpolicyOK','product':'Office enemy fill1.0->1.2; lounge shadow/highlight RGB*1.01 only. Strict per-point original HDR nondrop passed all6 finalcases540observations, unchanged actor/edge sampler.','native':'formal6+flat6+state2 actualEOF0; all18publicreviewpagesviewed','packet':'8ZIP162454021B921logical731physical;portablepositive+actualbyte128flipnegative','verification_advance':advance,'remaining_open':68,'disk':'10oldownedBG42rawdirs SHA-manifest moved C->D,receipt preserved; Cfree~1.44GB. No foreign worktree deletion.'}
state.pop('BG42_active',None);state['BG43_active']={'base':head,'state':'Original parent mapped via house generator,3newprops/twooriginaldoors on current heldgeometry. No productchange yet; hypothesis of buried ladder disproved exactbottom576. Native high/low and actualNPCportalQA next.','evidence':str(base)}
p.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,ensure_ascii=False),flush=True)
