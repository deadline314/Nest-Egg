from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');private=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg43-current')
(private/'flat.gd').write_bytes((p/'bg43-flat-20261118.gd').read_bytes())
(private/'flat.tscn').write_bytes((private/'probe.tscn').read_bytes().replace(b'/probe.gd',b'/flat.gd'))
s=(p/'run-bg42-flat-final-20261118.py').read_text().replace('bg42','bg43').replace("['ch2_ledger_front','ch2_ledger_office','ch2_lounge_front']","['ch3_plaza']")
(p/'run-bg43-flat-final-20261118.py').write_text(s,encoding='utf-8')
print('House 3-state staging probe prepared; actual runtime source unchanged.')
