from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work')
phases={'formal-final':'formal-v2','flat-final':'flat-v2','states-v3':'states-v4','checks-final':'checks-v2','source-final.json':'source-v2.json'}
for filename in ['bg43-packet-reader-20261118.py','build-bg43-packet-20261118.py','promote-bg43-20261118.py','review-bg43-20261118.py']:
 s=(p/filename).read_text()
 for a,b in phases.items():s=s.replace(a,b)
 if filename=='bg43-packet-reader-20261118.py':
  s=s.replace("changes={'data/audio/footsteps.json'","changes={'data/audio/ambience.json','data/audio/music.json','data/audio/footsteps.json'")
  needle="assert data('source/data/audio/footsteps.json')['materials']['plaza_asphalt']=='wet'"
  assert s.count(needle)==1
  s=s.replace(needle,needle+"\n   assert data('source/data/audio/ambience.json')['profiles']['plaza']==data('source/data/audio/ambience.json')['profiles']['market']\n   assert data('source/data/audio/music.json')['map']['zones']['plaza']==data('source/data/audio/music.json')['map']['zones']['market']")
 if filename=='build-bg43-packet-20261118.py':
  s=s.replace("'states-final','states-v2']:","'states-final','states-v2','formal-final','flat-final','states-v3','checks-final']:")
  s=s.replace("for rel in ['data/audio/footsteps.json'","for rel in ['data/audio/ambience.json','data/audio/music.json','data/audio/footsteps.json'")
 if filename=='promote-bg43-20261118.py':
  s=s.replace("runtime=['data/audio/footsteps.json'","runtime=['data/audio/ambience.json','data/audio/music.json','data/audio/footsteps.json'")
  s=s.replace('其餘四份既有產品來源變動','其餘六份既有產品來源變動')
  s=s.replace('沒有改共用市場／柏油設定、','廣場的環境音及區段配樂另明確對應原市場完全相同的聲音／音量／曲目。沒有改共用市場／柏油設定、')
  s=s.replace('原受影響入口選54組、','首輪受影響入口54組、63158項抓到1個新失敗：廣場新光影名稱漏登環境音。另查區段配樂呼叫端，一併完整沿用原市場設定；不是只把驗證放寬。這輪失敗的分片與退出碼保留於diagnostics/checks-final。補齊後重新拍攝／重算正式光影、全亮與機關狀態，並重新執行原受影響入口54組、')
 (p/filename).write_text(s,encoding='utf-8')
print('Delivery tools now require epoch2 source-v2 for all final producers, six existing changes +two new resources, exact original market ambience/music mappings. Failed first checks and old capture epochs retained separately.')
