from pathlib import Path
import json
p=Path('C:/Users/stanl/Github/Nest-Egg/work');base=Path('D:/NestEggVerification/evidence-20261117/bg43-current');root=Path('D:/NestEggVerification/ne218-baseline-20261117')
cfg=json.loads((root/'assets_src/pipeline/scene_props.json').read_text(encoding='utf-8'))
props=[v for v in cfg['props'] if v['id'] in {'harbor_plaza__freight_lift','harbor_plaza__lift_control_box','harbor_plaza__outer_ladder_up','harbor_plaza__outer_ladder_down'}]
assert len(props)==4 and {v['seed'] for v in props}==set(range(7501,7505))
(base/'pipeline-extract.json').write_text(json.dumps({'styles':cfg['styles'],'defaults':cfg['defaults'],'props':props},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old=(p/'build-bg42-packet-20261118.py').read_text();tail=old[old.index("manifest={'base':"):].replace('c38a42e0fa2bf2a74ef1c1e67d618094a015d829','eb40f91b7885faa65ac2a588fa79724fd8db4719').replace('bg42','bg43').replace('verify_bg43_final_20261118.py','verify_bg43_current_20261118.py')
head='''from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg43-current');out=base/'delivery-packet';out.mkdir(exist_ok=False)
assert json.loads((base/'checks-final/result.json').read_text())['all_passed']
assert json.loads((base/'states-v3/result.json').read_text())['passed']
for q in ['low','high']:assert json.loads((base/'formal-final'/('ch3_plaza-'+q)/'independent.json').read_text())['passed']
files={}
def add(name,path):
    assert name not in files and Path(path).is_file(),name
    files[name]=Path(path)
for phase in ['formal-final','flat-final','states-v3','checks-final']:
    for path in (base/phase).rglob('*'):
        if path.is_file() and 'private-profile' not in path.parts and not any(v.startswith('data_') for v in path.parts) and path.suffix in ['.json','.png','.bin','.log']:add(phase+'/'+path.relative_to(base/phase).as_posix(),path)
for phase in ['reproduction','reproduction-high','edge-90','edge-90-tone-110','states-final','states-v2']:
    for path in (base/phase).rglob('*'):
        if path.is_file() and 'private-profile' not in path.parts and path.suffix in ['.json','.log','.gd']:add('diagnostics/'+phase+'/'+path.relative_to(base/phase).as_posix(),path)
for path in base.iterdir():
    if path.is_file():add(path.name,path)
for path in (root/'work/bg43-current').rglob('*'):
    if path.is_file() and path.suffix in ['.gd','.tscn','.tres','.json']:add('replay/'+path.relative_to(root/'work/bg43-current').as_posix(),path)
for path in (primary/'work').glob('*bg43*-20261118*'):
    if path.is_file() and path.name.startswith(('prepare-','run-','adopt-','review-','bg43-state','bg43-flat')):add('drivers/'+path.name,path)
for rel in ['data/audio/footsteps.json','tools/level/build_ch3.py','data/environment/themes/ch3_plaza.tres','data/levels/ch3_plaza.tres','data/lighting/plaza.tres','data/environment/materials/plaza_asphalt.tres','data/levels/ch3_plaza_map.json','tools/scene_tour.gd','tools/readability_phase_probe.gd','tools/bg55_enemy_readability_probe.gd','tools/held_lighting_state.gd','tools/viewport_capture.gd','tools/contrast_probe.gd','data/scripts/lighting_profile.gd','game/level/lighting_controller.gd','game/level/post_process.gd','game/level/post_process.gdshader','core/light_kit.gd','game/level/environment/prop_placement.gd','game/level/environment/prop_reaction.gd','data/environment/prop_reactions.json']:
    add('source/'+rel,root/rel)
for prop in json.loads((base/'pipeline-extract.json').read_text())['props']:
    ident=prop['id'];pack=ident.split('__')[0]
    add('assets/'+ident+'.tres',root/('data/environment/scene_props/'+pack+'/'+ident+'.tres'))
    for suffix in ['.png','_n.png','_glow.png']:
        path=root/('art/environment/scene_props/'+pack+'/'+ident+suffix)
        if path.exists():add('assets/'+ident+suffix,path)
'''
(p/'build-bg43-packet-20261118.py').write_text(head+tail,encoding='utf-8')
print('Packet builder and four original art seeds prepared; guards require actual final checks before assembly.')
