extends "res://work/bg43-current/probe-final.gd"
func _measure(level: Level, world: Rect2) -> Dictionary:
    _active_cell55 = _cell55
    _cell55 += 1
    level._lighting._modulate.color = Color.WHITE
    level._background.modulate = Color.WHITE
    level._post.visible = false
    var records: Array[Dictionary] = []
    for entry in [[true,"before-flat"],[false,"after-flat"],[true,"restore-flat"]]:
        await _variant43(level,entry[0])
        records.append(await _capture55(level,world,entry[1]))
    assert(records[0].raw_sha256==records[2].raw_sha256)
    return {"bg43_flat":{"records":records,"controls_valid":true,"scope":"Full-bright staging diagnostic; same authored terrain/profile on both sides, only original props and doors vary. No numeric exposure acceptance."},"passed":true}
