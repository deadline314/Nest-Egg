from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');private=Path('D:/NestEggVerification/ne218-baseline-20261117/work/bg43-current')
s=(private/'probe.gd').read_text().replace('var candidate := original','var candidate := original.duplicate() as LightingProfile\n\tcandidate.set_meta(&"bg43_candidate", true)')
needle='\treturn record\n\n\nfunc _measure';assert s.count(needle)==1
s=s.replace(needle,'\trecord["terrain_edge_color"] = (load("res://data/environment/materials/asphalt.tres") as TerrainMaterialData).edge_color\n'+needle)
s+='''
func _apply55(level: Level, profile: LightingProfile) -> void:
\tawait super._apply55(level,profile)
\tvar material := load("res://data/environment/materials/asphalt.tres") as TerrainMaterialData
\tmaterial.edge_color.a = 0.9 if profile.has_meta(&"bg43_candidate") else 0.55
\tvar terrain := get_tree().get_first_node_in_group(&"terrain") as Terrain
\tassert(terrain != null and terrain._theme.zones[0].material == material)
\tvar edges := terrain.get_node("Edges") as TerrainEdges
\tfor chunk in edges.get_children():
\t\tif chunk is CanvasItem: chunk.queue_redraw()
\tawait RenderingServer.frame_post_draw
\tawait RenderingServer.frame_post_draw
'''
(private/'probe-edge.gd').write_text(s,encoding='utf-8',newline='\n');(private/'probe-edge.tscn').write_bytes((private/'probe.tscn').read_bytes().replace(b'/probe.gd',b'/probe-edge.gd'))
driver=(p/'run-bg43-reproduction-20261118.py').read_text().replace("out=base/'reproduction'","out=base/'edge-90'").replace('/probe.tscn','/probe-edge.tscn')
(p/'run-bg43-edge-20261118.py').write_text(driver,encoding='utf-8')
print('Memory-only asphalt edgealpha.55->.9 on candidate profile marker; original profile remains identical. Per-cell decreases retained; original regional minima and absolute gates evaluated separately. No product mutation.')
