from pathlib import Path
p=Path('C:/Users/stanl/Github/Nest-Egg/work');s=(p/'publish-bg42-20261118.py').read_text()
s=s.replace('bg42-current','bg43-current').replace('bg42-stage-paths.json','bg43-stage-paths.json').replace('len(paths)==38',"len(paths)==len(set(paths)) and 30<=len(paths)<=50").replace("'paths':38","'paths':len(paths)").replace('c38a42e0fa2bf2a74ef1c1e67d618094a015d829','eb40f91b7885faa65ac2a588fa79724fd8db4719').replace('fix: preserve BG-42 readability with local lighting adjustments','fix: improve plaza readability and verify freight routes').replace('codex/ticket-work-20261118-bg43','codex/ticket-work-20261118-bg44').replace('codex/ticket-work-20261118-bg42','codex/ticket-work-20261118-bg43').replace('owned_bg42_branch_deleted','owned_bg43_branch_deleted')
assert 'bg42' not in s
(p/'publish-bg43-20261118.py').write_text(s,encoding='utf-8')
advance=(p/'advance-bg42-verification-20261118.py').read_text().replace('bg42-current','bg43-current').replace("=='c38a42e0fa2bf2a74ef1c1e67d618094a015d829'","=='eb40f91b7885faa65ac2a588fa79724fd8db4719'").replace('checks-final/source-after.json','checks-v2/source-after.json')
(p/'advance-bg43-verification-20261118.py').write_text(advance,encoding='utf-8')
print('Per-ticket publisher and byte-preserving detached metadata advance prepared. No commit/push performed yet.')
