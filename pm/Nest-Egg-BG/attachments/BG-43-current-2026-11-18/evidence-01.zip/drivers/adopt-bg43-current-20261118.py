from pathlib import Path
import hashlib,json,sys
primary=Path('C:/Users/stanl/Github/Nest-Egg');root=Path('D:/NestEggVerification/ne218-baseline-20261117');base=Path('D:/NestEggVerification/evidence-20261117/bg43-current');private=root/'work/bg43-current'
for q in ['low','high']:
 r=json.loads((base/'edge-90-tone-110'/('ch3_plaza-'+q)/'independent.json').read_text());assert r['passed']
profile=(primary/'data/lighting/market.tres').read_text();material=(primary/'data/environment/materials/asphalt.tres').read_text()
(private/'before-profile.tres').write_text(profile,encoding='utf-8',newline='\n')
new_profile=profile.replace('id = &"market"','id = &"plaza"').replace('shadow_tint = Color(0.95,0.9,1.1,1)','shadow_tint = Color(1.045,0.99,1.21,1)').replace('highlight_tint = Color(1.05,1.0,0.97,1)','highlight_tint = Color(1.155,1.1,1.067,1)')
assert new_profile!=profile
new_material=material.replace('id = &"asphalt"','id = &"plaza_asphalt"').replace('display_name = "濕柏油路"','display_name = "廣場濕柏油路"').replace('0.8509804, 0.55)','0.8509804, 0.9)')
assert new_material!=material
(primary/'data/lighting/plaza.tres').write_text(new_profile,encoding='utf-8',newline='\n')
(primary/'data/environment/materials/plaza_asphalt.tres').write_text(new_material,encoding='utf-8',newline='\n')
p=primary/'data/audio/footsteps.json';s=p.read_text(encoding='utf-8');assert s.count('  "asphalt": "wet",')==1;p.write_text(s.replace('  "asphalt": "wet",','  "asphalt": "wet",\n  "plaza_asphalt": "wet",'),encoding='utf-8',newline='\n')
p=primary/'tools/level/build_ch3.py';s=p.read_text(encoding='utf-8');assert s.count("'plaza': ('asphalt',")==1;s=s.replace("'plaza': ('asphalt',","'plaza': ('plaza_asphalt',")
start=s.index('def _build_plaza_v1():');end=s.index('\ndef ',start+5);part=s[start:end];assert part.count("a.zone(0, 'market')")==1;s=s[:start]+part.replace("a.zone(0, 'market')","a.zone(0, 'plaza')")+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
sys.dont_write_bytecode=True;sys.path.insert(0,str(primary/'tools/level'));import build_ch3 as ch3
ch3.configure();a=ch3.build_plaza();ch3.kit.write_level(a)
# The existing writer owns the theme and level references. Review its exact diff.
changed=['data/lighting/plaza.tres','data/environment/materials/plaza_asphalt.tres','data/audio/footsteps.json','tools/level/build_ch3.py','data/environment/themes/ch3_plaza.tres','data/levels/ch3_plaza.tres']
before=json.loads((base/'source-base.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in before.items())
for rel in changed:
 (root/rel).write_bytes((primary/rel).read_bytes())
after={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in set(before)|set(changed)}
assert {p for p in before if before[p]!=after[p]}==set(changed)-{'data/lighting/plaza.tres','data/environment/materials/plaza_asphalt.tres'}
(base/'source-final.json').write_text(json.dumps(after,indent=2)+'\n')
s=(private/'probe-edge-tone.gd').read_text()
start=s.index('\tvar original := level._lighting.current.duplicate() as LightingProfile');end=s.index('\tassert(candidate != null',start)
s=s[:start]+'''\tvar original := load("res://work/bg43-current/before-profile.tres") as LightingProfile
\tvar candidate := level._lighting.current.duplicate() as LightingProfile
\tcandidate.set_meta(&"bg43_candidate", true)
'''+s[end:]
s=s.replace('res://data/environment/materials/asphalt.tres','res://data/environment/materials/plaza_asphalt.tres')
needle='\treturn record\n\n\nfunc _measure';assert s.count(needle)==1
s=s.replace(needle,'\trecord["tone_shadow"] = level._lighting.current.shadow_tint\n\trecord["tone_highlight"] = level._lighting.current.highlight_tint\n\trecord["shader_shadow"] = level._post._material.get_shader_parameter(&"shadow_tint")\n\trecord["shader_highlight"] = level._post._material.get_shader_parameter(&"highlight_tint")\n'+needle)
(private/'probe-final.gd').write_text(s,encoding='utf-8',newline='\n');(private/'probe-final.tscn').write_bytes((private/'probe.tscn').read_bytes().replace(b'/probe.gd',b'/probe-final.gd'))
driver=(primary/'work/run-bg43-edge-tone-20261118.py').read_text().replace("out=base/'edge-90-tone-110'","out=base/'formal-final'").replace("base/'source-base.json'","base/'source-final.json'").replace('/probe-edge-tone.tscn','/probe-final.tscn')
(primary/'work/run-bg43-final-20261118.py').write_text(driver,encoding='utf-8')
(private/'state-core.gd').write_bytes((root/'work/bg42-current/state-core.gd').read_bytes())
state=(primary/'work/run-bg42-state-final-20261118.py').read_text().replace('bg42','bg43').replace("==5 and len(list(folder.glob('*.png')))==5","==22 and len(list(folder.glob('*.png')))==22").replace("states['actual_npc_talks'] and states['ledger_taken'] and states['ledger_owned'] and states['audit_submitted']","states['actual_npc_talks'] and not states['seeded_story_flags'] and len(states['routes'])==6")
(primary/'work/run-bg43-state-final-20261118.py').write_text(state,encoding='utf-8')
checks=(primary/'work/run-bg42-checks-final-20261118.py').read_text().replace('bg42','bg43').replace('c38a42e0fa2bf2a74ef1c1e67d618094a015d829','eb40f91b7885faa65ac2a588fa79724fd8db4719')
(primary/'work/run-bg43-checks-final-20261118.py').write_text(checks,encoding='utf-8')
design=primary/'design/20-campaign-experience/CH2_CH3_SCENE_GAPS.md'
with design.open('a',encoding='utf-8') as f:f.write('\n廣場沿用濕柏油貼圖及濕地腳步聲，只把本區亮邊不透明度從 0.55 調到 0.9，並用本區光影的陰影／亮部同色增益 1.1 保持角色與背景的辨識。共用市場光影與柏油資料保持原值。以原票的區域最低值判定「沒有變差」，另列逐點下降數；不宣稱每一個取樣點都不下降。\n')
print(json.dumps({'changed':changed,'source_count':len(after),'minimum_contract':'Original regional minimum, every point decline separately disclosed','private':'Old market profile copied byte-for-byte; native final reads actual product candidate and actual terrain resource.'}),flush=True)
