from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
base=Path('D:/NestEggVerification/evidence-20261117/bg43-current');out=base/'review-v2';out.mkdir(exist_ok=True);font=ImageFont.truetype('C:/Windows/Fonts/msjh.ttc',14)
for phase,key in [('formal-v2','bg43'),('flat-v2','bg43_flat')]:
 for quality in ['low','high']:
  folder=base/phase/('ch3_plaza-'+quality)/'ch3_plaza';p=folder/'bg43-index.json'
  if not p.exists():continue
  data=json.loads(p.read_text());cols,rows=int(data['columns']),int(data['rows'])
  sheet=Image.new('RGB',(cols*320,36+rows*390),'#101722');draw=ImageDraw.Draw(sheet)
  draw.text((7,6),f'{phase} / plaza / {quality} | BEFORE top, AFTER bottom | native640x360 shown320x180',font=font,fill='white')
  for shot in data['shots']:
   c,r=int(shot['column']),int(shot['row']);records=shot[key]['records'];b=records[-1] if phase=='formal-v2' else records[1]
   for i,(label,record) in enumerate([('before',records[0]),('after',b)]):
    with Image.open(folder/record['files']['png']) as im:
     assert im.size==(640,360);x,y=c*320,36+r*390+i*195;sheet.paste(im.convert('RGB').resize((320,180)),(x,y))
    draw.text((x+3,y+180),f'{label} c{c} r{r}',font=font,fill='white')
  sheet.save(out/(phase+'-'+quality+'.png'))
for quality in ['low','high']:
 folder=base/'states-v4'/quality;p=folder/'states.json'
 if not p.exists():continue
 rows=json.loads(p.read_text())['rows'];assert len(rows)==22
 for start in range(0,len(rows),6):
  sheet=Image.new('RGB',(1280,900),'#101722');draw=ImageDraw.Draw(sheet)
  for i,row in enumerate(rows[start:start+6]):
   with Image.open(folder/(row['name']+'.png')) as im:
    assert im.size==(640,360);x,y=i%2*640,i//2*300;sheet.paste(im.resize((480,270)),(x,y))
   draw.text((x+2,y+270),quality+' / '+row['name'],font=font,fill='white')
  sheet.save(out/f'states-{quality}-{start//6+1:02}.png')
for quality in ['low','high']:
 folder=base/'formal-v2'/('ch3_plaza-'+quality)/'ch3_plaza';data=json.loads((folder/'bg43-index.json').read_text())
 for cell in [(0,2),(2,3)]:
  shot=next(s for s in data['shots'] if [s['column'],s['row']]==list(cell));records=shot['bg43']['records']
  sheet=Image.new('RGB',(1280,780),'#101722');draw=ImageDraw.Draw(sheet)
  for i,label in enumerate(['A0','product-old','reference-new','authored-final']):
   rec=next(r for r in records if r['label']==label);x,y=i%2*640,i//2*390
   with Image.open(folder/rec['files']['png']) as im:sheet.paste(im,(x,y))
   draw.text((x+3,y+362),f'{quality} / cell{cell} / {label}',font=font,fill='white')
  sheet.save(out/f'factors-{quality}-{cell[0]}-{cell[1]}.png')
print(json.dumps({'pages':[p.name for p in sorted(out.glob('*.png'))]}),flush=True)
