extends "res://work/bg43-current/state-core.gd"

func react(level: Level, id: StringName) -> PropReaction:
    for node in level.find_children("*", "", true, false):
        if node is PropReaction and node.reaction_id == id: return node
    assert(false, str(id))
    return null

func status(level: Level, name: String, color: String, ready: bool, down: bool) -> void:
    var lift := level._portals[&"plaza_lift"] as Portal
    var ladder := level._portals[&"plaza_ladder"] as Portal
    var state: Array[Dictionary] = []
    for id in [&"lift_control_box", &"freight_lift", &"plaza_outer_ladder"]:
        var r := react(level,id)
        var expected := "52d98c" if down else "ff6a4a"
        if id != &"plaza_outer_ladder": expected = color
        assert(r._lamp_state.color == "#"+expected)
        var row := {"reaction":str(id),"state_color":r._lamp_state.color,"pulse":r._lamp_state.pulse,"top":[r.get_parent().global_position.x,r.get_parent().global_position.y],"size":[r._size.x,r._size.y]}
        if id == &"plaza_outer_ladder":
            assert(r.is_swapped()==down and r._swap_node.visible==down)
            assert(absf(r._swap_node.global_position.y-r.get_parent().global_position.y)<0.01)
            assert(absf(r._swap_node.global_position.y+r._swap_node.data.size.y-576.0)<0.01)
            row.merge({"swapped":down,"down_top":[r._swap_node.global_position.x,r._swap_node.global_position.y],"down_size":[r._swap_node.data.size.x,r._swap_node.data.size.y],"floor":576})
        state.append(row)
    assert(lift.is_open()==ready and ladder.is_open()==down)
    await move(level,lift.global_position+Vector2(-24,-2))
    await shot(level,name+"-lift",{"reactions":state,"lift_open":ready,"ladder_open":down})
    await move(level,ladder.global_position+Vector2(-24,-2))
    await shot(level,name+"-ladder",{"reactions":state,"lift_open":ready,"ladder_open":down})

func travel(level: Level, id: StringName, target: String, entry: StringName, name: String) -> Level:
    var portal := level._portals[id] as Portal
    await move(level,portal.global_position+Vector2(-40,-2))
    await move(level,portal.global_position+Vector2(-12,-2))
    assert(portal.interaction_available() and portal.is_open())
    var count := _routes.size()
    assert(portal.try_use())
    assert(_routes.size()==count+1 and _routes.back()=="res://data/levels/"+target+".tres" and GameState.pending_portal==entry)
    level.queue_free()
    await settle(3)
    var arrived := await make_level(target)
    assert(arrived._portals.has(entry))
    await shot(arrived,name,{"used":str(id),"entry":str(entry),"route":_routes.back()})
    return arrived

func _run() -> void:
    add_child(LightKit.create_environment())
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--quality="): Settings.set_light_quality(0 if arg.ends_with("low") else 2)
    Story.auto_skip = true
    Enemy.activation_culling_enabled = false
    GameState.start_new_run(GameState.difficulties[1])
    var level := await make_level("ch3_plaza")
    await status(level,"locked","ff6a4a",false,false)
    var box := await check_npc(level,&"ch3_control_box","control-box-locked")
    assert(await box._talk() and GameState.has_flag(&"ch3_interlock_seen"))
    var ladder_npc := await check_npc(level,&"ch3_outer_ladder","ladder-locked")
    assert(await ladder_npc._talk() and not GameState.has_flag(&"ch3_outer_ladder_down"))
    var count := _routes.size()
    assert(not (level._portals[&"plaza_lift"] as Portal).try_use())
    assert(not (level._portals[&"plaza_ladder"] as Portal).try_use() and _routes.size()==count)
    level = await travel(level,&"plaza_pump","ch3_pump",&"pump_plaza","pump-arrival")
    var wheel := await check_npc(level,&"ch3_drain_wheel","pump-wheel")
    assert(await wheel._talk())
    assert(GameState.has_flag(&"ch3_pump_low"))
    var panel := await check_npc(level,&"ch3_branch_panel","pump-panel")
    assert(await panel._talk())
    assert(GameState.has_flag(&"ch3_wet_branch_isolated") and GameState.has_flag(&"ch3_lift_powered"))
    level = await travel(level,&"pump_plaza","ch3_plaza",&"plaza_pump","plaza-powered-arrival")
    await status(level,"powered","ffb23f",false,false)
    box = await check_npc(level,&"ch3_control_box","control-box-powered")
    assert(await box._talk() and GameState.has_flag(&"ch3_freight_ready"))
    await status(level,"ready","52d98c",true,false)
    level = await travel(level,&"plaza_lift","ch3_mezzanine",&"mezz_lift","lift-arrival")
    level = await travel(level,&"mezz_lift","ch3_plaza",&"plaza_lift","lift-return")
    ladder_npc = await check_npc(level,&"ch3_outer_ladder","ladder-ready")
    assert(await ladder_npc._talk() and GameState.has_flag(&"ch3_outer_ladder_down"))
    await status(level,"lowered","52d98c",true,true)
    level = await travel(level,&"plaza_ladder","ch3_pump",&"pump_ladder","ladder-arrival")
    level = await travel(level,&"pump_ladder","ch3_plaza",&"plaza_ladder","ladder-return")
    await status(level,"reentry","52d98c",true,true)
    var writer := FileAccess.open(_out.path_join("states.json"),FileAccess.WRITE)
    assert(writer!=null)
    writer.store_string(JSON.stringify({"rows":_rows,"routes":_routes,"actual_npc_talks":true,"seeded_story_flags":[],"scope":"Standalone Level; real NPC talk, collision range, default authored choices and six Portal route requests consumed by driver. Story presentation auto-skipped, enemies removed/invulnerable player, scripted positioning; not Main/manual playthrough or visible wheel-action verification."},"  ")+"\n")
    writer.close()
    level.queue_free()
    await settle(3)
    await AudioRelease.settle(get_tree())
    get_tree().quit(0)
