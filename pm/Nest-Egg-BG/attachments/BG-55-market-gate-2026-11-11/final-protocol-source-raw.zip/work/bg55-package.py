from pathlib import Path
import json,hashlib,zipfile,re
root=Path(__file__).resolve().parents[1];base=root/'pm/Nest-Egg-BG/attachments/BG-55-market-gate-2026-11-11'
entries=[]
for case in sorted(base.iterdir()):
 if not case.is_dir()or not(case/'exit.json').exists():continue
 files=sorted(p for p in case.rglob('*')if p.is_file()and not p.name.endswith(('.import','.uid')))
 manifest={p.relative_to(case).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}for p in files}
 archive=base/(case.name+'-raw.zip')
 if not archive.exists():
  with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
   for p in files:z.write(p,p.relative_to(case).as_posix())
   z.writestr('manifest-raw.json',(json.dumps(manifest,indent=2)+'\n').encode())
 with zipfile.ZipFile(archive)as z:
  m=json.loads(z.read('manifest-raw.json'));assert m==manifest,(case.name,'case changed after archiving')
  for p,item in m.items():
   raw=z.read(p);assert hashlib.sha256(raw).hexdigest()==item['sha256']and len(raw)==item['bytes']
  before=json.loads(z.read('source-before.json'))if 'source-before.json'in z.namelist()else{}
  result=json.loads(z.read('exit.json'));after=result.get('source_after',{})
  changes=[p for p in before if before[p]!=after.get(p)]
  runtime_changes=[p for p in changes if p!='tools/verify_bg55_readability.py']
  assert not runtime_changes,(case.name,runtime_changes)
  for p,sha in before.items():assert hashlib.sha256(z.read('source/'+p)).hexdigest()==sha
  if changes:
   assert case.name=='accept-low-v1'and changes==['tools/verify_bg55_readability.py']
   assert hashlib.sha256(z.read('source-after/tools/verify_bg55_readability.py')).hexdigest()==after[changes[0]]
 text=(case/'run.log').read_bytes().decode('utf-8',errors='strict')
 complete=(case/'actions.json').exists()if case.name.startswith('actions-')else bool(list(case.glob('*/*-index.json')))if case.name.startswith(('accept-','diag-','regression-'))else True
 entries.append({'case':case.name,'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'raw_files':len(files),'engine_exit':result['exit'],'completion_artifact_present':complete,'engine_error_lines':[line for line in text.splitlines()if line.startswith(('ERROR:','SCRIPT ERROR:'))],'runtime_source_changes':runtime_changes,'offline_checker_changes':changes})
 print(case.name,len(files),round(archive.stat().st_size/1e6,2),'MB',flush=True)
 assert archive.stat().st_size<95000000,(case.name,'split this archive before GitHub delivery')
(base/'archives.json').write_bytes((json.dumps(entries,indent=2)+'\n').encode())
(base/'.gitattributes').write_bytes(b'*.zip -text\n')
(base/'.gitignore').write_bytes(b'/cpu-*/\n/diag-*/\n/accept-*/\n/actions-*/\n/regression-*/\n/product-before/\n/review/\n*.import\n*.uid\n')
print('verified',sum(e['raw_files']for e in entries),'original files across',len(entries),'archives')
