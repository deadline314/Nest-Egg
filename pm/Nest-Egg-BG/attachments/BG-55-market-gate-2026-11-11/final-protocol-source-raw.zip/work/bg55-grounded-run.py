from pathlib import Path
import os,subprocess,sys,json

root=Path(__file__).resolve().parents[1]
env=dict(os.environ,BG55_PROJECT='D:/NestEggVerification/native-ticket-batch-20261111')
results=[]
for level,profile,cells in [('ch2_market_gate','market',''),('ch2_market','market',''),('ch2_lounge_front','lounge_front',''),('ch1_street','market','4:1,6:1,4:2,6:2')]:
 for quality in ['high','low']:
  tag=('accept-'+quality+'-grounded-v2')if level=='ch2_market_gate'else('regression-grounded-'+level+'-'+quality+'-v2')
  command=[sys.executable,'-X','utf8',str(root/'work/bg55-run.py'),'native',tag,'--level='+level,'--quality='+quality,'--reference-profile=res://data/lighting/'+profile+'.tres']
  if cells:command.append('--cells='+cells)
  result=subprocess.run(command,cwd=root,env=env)
  results.append(dict(case=tag,runner_exit=result.returncode))
(root/'work/BG55-grounded-batch.json').write_bytes((json.dumps(results,indent=2)+'\n').encode())
print(json.dumps(results))
