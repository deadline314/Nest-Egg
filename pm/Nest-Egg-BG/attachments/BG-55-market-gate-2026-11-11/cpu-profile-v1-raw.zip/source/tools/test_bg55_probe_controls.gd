extends Node
## CPU checks for the fixture's real stale-rig failure and one-field interventions.
const Probe := preload("res://tools/bg55_enemy_readability_probe.gd")
var _checks := 0
var _failures := 0


func _ready() -> void:
	_run.call_deferred()


func _check(ok: bool, message: String) -> void:
	_checks += 1
	if not ok:
		_failures += 1
		printerr("[BG55 CPU] FAIL ", message)


func _run() -> void:
	var source := load("res://data/lighting/market.tres") as LightingProfile
	var original := var_to_bytes([source.fog_density, source.enemy_fill_scale, source.ambient_color,
		source.lamp_style.energy, source.rim_energy])
	for factor in ["source", "fill-min", "fill-max", "fog-half", "fog-quarter"]:
		var changed := Probe.variant_profile(source, factor)
		_check(changed != source, factor + " uses a distinct profile")
		_check(changed.ambient_color == source.ambient_color and changed.lamp_style == source.lamp_style
			and changed.rim_energy == source.rim_energy, factor + " preserves ambient, lamps and rim")
		_check(changed.enemy_fill_scale == source.enemy_fill_scale if factor.begins_with("fog-") else changed.fog_density == source.fog_density,
			factor + " changes only its declared factor")
	_check(Probe.variant_profile(source, "unknown") == null, "unknown intervention is rejected")
	_check(original == var_to_bytes([source.fog_density, source.enemy_fill_scale, source.ambient_color,
		source.lamp_style.energy, source.rim_energy]), "original cached market data is unchanged")
	if ResourceLoader.exists("res://data/lighting/market_gate.tres"):
		var local := load("res://data/lighting/market_gate.tres") as LightingProfile
		_check(local.validate().is_empty() and local.id == &"market_gate", "authored local profile validates")
		for name in LightingProfile.BLENDED:
			_check(is_equal_approx(local.enemy_fill_scale, 1.0) if name == &"enemy_fill_scale" else local.get(name) == source.get(name),
				"local profile changes only enemy fill: " + str(name))
		for property in source.lamp_style.get_property_list():
			if int(property.usage) & PROPERTY_USAGE_STORAGE:
				_check(local.lamp_style.get(property.name) == source.lamp_style.get(property.name), "lamp style unchanged: " + str(property.name))
		_check(Ambience.layers_for(&"market_gate") == Ambience.layers_for(&"market"), "real ambience owner preserves all layers and volumes")
		var audio_alias: Array = Ambience._profiles["market_gate"]
		Ambience._profiles.erase("market_gate")
		_check(Ambience.layers_for(&"market_gate") != Ambience.layers_for(&"market"), "negative control: missing ambience alias loses the soundscape")
		Ambience._profiles["market_gate"] = audio_alias
		var music_alias: Dictionary = Music._map["zones"]["market_gate"]
		for state in Music.STATES:
			_check(Music.resolve_cue(&"ch2_market_gate", &"market_gate", state) == Music.resolve_cue(&"ch2_market_gate", &"market", state), "real music owner preserves " + str(state))
		Music._map["zones"].erase("market_gate")
		_check(Music.resolve_cue(&"ch2_market_gate", &"market_gate", &"calm") != Music.resolve_cue(&"ch2_market_gate", &"market", &"calm"), "negative control: missing music alias changes cue")
		Music._map["zones"]["market_gate"] = music_alias
	_check(Probe.bytes_sha("abc".to_utf8_buffer()) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", "raw SHA has an independent known answer")
	var layout := LevelLayout.new()
	layout.width = 1
	layout.height = 24
	for row in 24: layout.rows.append("=" if row == 14 else ("#" if row >= 20 else "."))
	_check(is_equal_approx(layout.floor_below(0, 13), 224.0), "negative control: legacy search stops at an unusably high platform")
	_check(is_equal_approx(Probe.visible_floor(layout, 0, Rect2(0, 172.5, 333.333, 187.5)), 320.0), "continue to the visible ground below that platform")
	_check(not is_finite(Probe.visible_floor(layout, 0, Rect2(0, 0, 333.333, 187.5))), "sky-only view has no invented standable actor")
	var old_fill := LightKit.enemy_fill
	var old_cap := LightKit.enemy_light_cap
	var rig := CharacterRig.new()
	rig.use_enemy_fill = true
	add_child(rig)
	_check(rig.setup("collector_gunner"), "actual market enemy skin loads")
	LightKit.enemy_fill = 1.0
	LightKit.enemy_light_cap = 0.25
	Probe.sync_rig(rig)
	rig.process_mode = Node.PROCESS_MODE_DISABLED
	var pose: Array[String] = []
	for part in rig._parts: pose.append(str(part.global_transform))
	LightKit.enemy_fill = 2.0
	LightKit.enemy_light_cap = 0.6
	_check(is_equal_approx(rig._fill, 1.0) and is_equal_approx(rig._light_cap, 0.25), "negative control: frozen rig retains stale fill and cap")
	Probe.sync_rig(rig)
	_check(is_equal_approx(rig._fill, 2.0) and is_equal_approx(rig._light_cap, 0.6), "sync applies actual fill and cap to frozen rig")
	_check(is_equal_approx(float(rig._light_material.get_shader_parameter("fill")), 2.0), "actual lighting material receives fill")
	var after_pose: Array[String] = []
	for part in rig._parts: after_pose.append(str(part.global_transform))
	_check(pose == after_pose, "lighting sync preserves the actual drawable pose")
	var beam := WeaponLight.new()
	beam.top_level = true
	add_child(beam)
	beam.configure(load("res://data/weapons/pistol.tres") as WeaponData)
	beam.set_active(true)
	beam.aim(Vector2(40, 100), Vector2.RIGHT, 1.0, 1.0)
	_check(beam.is_lit(), "actual pistol weapon light is on")
	var moved_origin := Vector2(472, 290)
	_check(beam.global_position.distance_to(moved_origin) > 400.0, "negative control: top-level beam stays at the old origin")
	beam.aim(moved_origin, Vector2.RIGHT, 1.0, 0.0)
	_check(beam.global_position == moved_origin and is_equal_approx(beam._level, 1.0), "zero-time real owner aim synchronizes beam without advancing fade")
	beam.queue_free()
	LightKit.enemy_fill = old_fill
	LightKit.enemy_light_cap = old_cap
	rig.queue_free()
	await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	print("BG55_CPU checks=%d failures=%d" % [_checks, _failures])
	get_tree().quit(1 if _failures > 0 else 0)
