from pathlib import Path
import os,sys,subprocess,json,hashlib,time
root=Path(__file__).resolve().parents[1];base=root/'pm/Nest-Egg-BG/attachments/BG-55-market-gate-2026-11-11'
project=Path(os.environ.get('BG55_PROJECT',str(root)))
mode,tag=sys.argv[1:3];out=base/tag;out.mkdir(parents=True,exist_ok=False)
(out/'runner-source.py').write_bytes(Path(__file__).read_bytes())
paths=['tools/bg55_enemy_readability_probe.gd','tools/bg55_enemy_readability_probe.tscn','tools/test_bg55_probe_controls.gd','tools/test_bg55_probe_controls.tscn','tools/contrast_probe.gd','tools/readability_phase_probe.gd','tools/scene_tour.gd','tools/viewport_capture.gd','game/rig/character_rig.gd','game/level/lighting_controller.gd','game/level/environment/fog_layer.gd','data/lighting/market.tres','data/levels/ch2_market_gate.tres','data/audio/ambience.json','data/audio/music.json','data/lighting_preview/scenes.json','tools/level/build_ch2.py','game/player/weapon_light.gd','tools/bg55_enemy_action_probe.gd','tools/bg55_enemy_action_probe.tscn','game/enemies/escort_baton.gd','game/enemies/bill_thrower.gd','data/enemies/ch2_escort.tres','data/enemies/ch2_bill_thrower.tres','data/levels/ch2_market_gate_map.json','data/environment/themes/ch2_market_gate.tres','core/light_kit.gd','game/level/level.gd','game/level/environment/rain_layer.gd','game/level/post_process.gd','game/level/post_process.gdshader','game/rig/humanoid_animator.gd','data/scripts/lighting_profile.gd','game/player/player.gd','game/player/player_visual.gd','game/rig/rig_input.gd','game/projectiles/projectile.gd','data/projectiles/bill_paper.tres']
paths += ['tools/held_lighting_state.gd','game/level/light_budget.gd','game/level/environment/wall_shadows.gd','game/level/level_background.gd']
paths += ['data/levels/'+name+suffix for name in ['ch2_market','ch2_lounge_front','ch1_street']for suffix in ['.tres','_map.json']]
paths += ['data/lighting/lounge_front.tres','data/lighting/harbor_approach.tres','data/enemies/collector_brute.tres','data/enemies/collector_gunner.tres','art/shaders/character_light.gdshader','project.godot']
paths.extend(p.as_posix()for p in(project/'data/lighting').glob('market_gate*.tres'))
paths=sorted(set(p.replace(str(project).replace('\\','/')+'/','')for p in paths))
hashes={p:hashlib.sha256((project/p).read_bytes()).hexdigest()for p in paths}
for p in paths:
 dest=out/'source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((project/p).read_bytes())
(out/'source-before.json').write_bytes((json.dumps(hashes,indent=2)+'\n').encode())
godot='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
if mode=='import':command=[sys.executable,str(root/'tools/comfyui/gpu_lock.py'),'--',godot,'--headless','--path',str(project),'--editor','--import']
elif mode=='cpu':command=[godot,'--headless','--path',str(project),'res://tools/test_bg55_probe_controls.tscn']
elif mode=='cpu-action':command=[godot,'--headless','--path',str(project),'res://tools/bg55_enemy_action_probe.tscn','--','--validate-only']
else:command=[sys.executable,str(root/'tools/comfyui/gpu_lock.py'),'--',godot,'--path',str(project),'--rendering-method','forward_plus','--rendering-driver','vulkan',('res://tools/bg55_enemy_action_probe.tscn' if mode=='actions'else 'res://tools/bg55_enemy_readability_probe.tscn'),'--','--out='+str(out),'--player','--fixed-aim','--lamps=full','--brightness=0.5','--level=ch2_market_gate','--quality=high','--tag='+tag,*sys.argv[3:]]
(out/'command.json').write_bytes((json.dumps(command,indent=2)+'\n').encode())
env=dict(os.environ,PYTHONIOENCODING='utf-8',APPDATA=str(root/'work/bg55-user'));started=time.monotonic()
with(out/'run.log').open('wb')as f:
 p=subprocess.Popen(command,cwd=project,env=env,stdout=f,stderr=subprocess.STDOUT)
 try:code=p.wait(timeout=360)
 except subprocess.TimeoutExpired:subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],capture_output=True);code=124
(out/'exit.json').write_bytes((json.dumps({'exit':code,'seconds':time.monotonic()-started,'project':str(project),'source_after':{p:hashlib.sha256((project/p).read_bytes()).hexdigest()for p in paths}},indent=2)+'\n').encode())
print(tag,code,round(time.monotonic()-started,2));print((out/'run.log').read_bytes().decode('utf-8',errors='strict')[-2200:])

raw_log=(out/'run.log').read_bytes()
complete=(out/'actions.json').exists()if mode=='actions'else bool(list(out.glob('*/*-index.json')))if mode=='native'else True
strict_ok=code==0 and b'SCRIPT ERROR:' not in raw_log and b'ERROR:' not in raw_log and complete
(out/'execution-verdict.json').write_bytes((json.dumps({'engine_exit':code,'strict_clean':strict_ok,'completion_artifact_present':complete},indent=2)+'\n').encode())
sys.exit(0 if strict_ok else 1)
