extends "res://tools/readability_phase_probe.gd"
## Held-scene A/A and A/B/A. Product actors, scenery and drawing remain intact.
## --diagnose varies one profile field at a time in memory, never on disk.
## --reference-profile=res://... compares the original profile with authored data.

const Capture55 := preload("res://tools/viewport_capture.gd")
var _diagnose55 := false
var _reference55 := ""
var _held55: Level
var _cell55 := 0
var _files55: Dictionary = {}


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg == "--diagnose":
			_diagnose55 = true
		elif arg.begins_with("--reference-profile="):
			_reference55 = arg.trim_prefix("--reference-profile=")
	if not _reference55.is_empty() and not ResourceLoader.exists(_reference55):
		push_error("[BG55] Missing reference profile: %s" % _reference55)
		get_tree().quit(2)
		return
	super._ready()
	var overlay := CanvasLayer.new()
	add_child(overlay)
	var caption := Label.new()
	caption.position = Vector2(12, 33)
	caption.text = "BG55 / HELD SIMULATION / %s / SCRIPTED AIM" % ("DIAGNOSTIC FACTORS" if _diagnose55 else "AUTHORED ACCEPTANCE")
	caption.add_theme_font_size_override("font_size", 13)
	overlay.add_child(caption)


static func bytes_sha(bytes: PackedByteArray) -> String:
	var context := HashingContext.new()
	context.start(HashingContext.HASH_SHA256)
	context.update(bytes)
	return context.finish().hex_encode()


static func variant_profile(source: LightingProfile, factor: String) -> LightingProfile:
	var result := source.duplicate() as LightingProfile
	match factor:
		"source": pass
		"fill-min": result.enemy_fill_scale = 0.5
		"fill-max": result.enemy_fill_scale = 1.0
		"fog-half": result.fog_density *= 0.5
		"fog-quarter": result.fog_density *= 0.25
		_: return null
	return result


static func sync_rig(rig: CharacterRig) -> void:
	if rig != null:
		rig._apply_fill(LightKit.enemy_fill)
		rig._apply_light_cap(LightKit.enemy_light_cap)


func _settle(frames: int) -> void:
	# The first ordinary settling interval gives the authored actors their real
	# idle pose. All subsequent interventions share this exact live instance.
	for node in get_children():
		if node is Level and (not is_instance_valid(_held55) or node != _held55):
			await super._settle(frames)
			_held55 = node
			_held55.process_mode = Node.PROCESS_MODE_DISABLED
			for item in _held55.find_children("*", "", true, false):
				if item is WorldPrompt:
					item.visible = false
					item.process_mode = Node.PROCESS_MODE_DISABLED
				elif item is FogLayer or item is RainLayer or item is PostProcess:
					item.set_process(false)
			return
	if is_instance_valid(_held55):
		_held55._lighting.snap()
		_sync55(_held55)
	await super._settle(frames)


func _sync55(level: Level) -> void:
	_sync_player_light(level.player)
	for node in level._entities.get_children():
		if node is Enemy:
			sync_rig(node.rig)
	# Camera and player light can move between grid cells. Refresh actual tint
	# sources without advancing fog time or hiding any atmosphere layer.
	level._fog._tint_refresh = 0.0
	level._fog._process(0.0)
	level._fog.queue_redraw()


func _held_state55(level: Level) -> Dictionary:
	var actors: Array[Dictionary] = []
	for node in level._entities.get_children():
		if not node is Enemy:
			continue
		var parts: Array[String] = []
		if node.rig != null:
			for part in node.rig._parts:
				parts.append(str(part.global_transform))
		actors.append({"instance": node.get_instance_id(), "id": str(node.data.id),
			"feet": str(node.global_position), "facing": node.facing, "parts": parts})
	var rains: Array[Dictionary] = []
	for node in level.find_children("*", "", true, false):
		if node is RainLayer:
			rains.append({"time": node._time, "drift": node._drift,
				"visible": node.is_visible_in_tree(),
				"points_sha256": bytes_sha(var_to_bytes(node._points))})
	return {"actors": actors, "rain": rains, "fog_time": level._fog._time,
		"fog_visible": level._fog.is_visible_in_tree(), "camera": str(get_viewport().get_canvas_transform()),
		"player": str(level.player.global_position), "aim": str(level.player.aim_dir),
		"lamps": _lamp_observations(level)}


func _apply55(level: Level, profile: LightingProfile) -> void:
	LightingProfile.copy_into(level._lighting.current, profile)
	level._lighting._apply()
	_sync55(level)
	# Deliberately bypass this subclass's snap-to-authored _settle: the
	# intervention lives only in current, and must survive until capture.
	await super._settle(3)


func _capture55(level: Level, world: Rect2, label: String) -> Dictionary:
	await RenderingServer.frame_post_draw
	var probe := ContrastProbe.capture(get_viewport())
	var bytes := probe._image.get_data()
	var sha := bytes_sha(bytes)
	var directory := _out.path_join(str(level.data.id))
	var key := "%s:%s" % [level.data.id, sha]
	if not _files55.has(key):
		var name := "bg55-cell%03d-%s" % [_cell55, label]
		var raw_path := directory.path_join(name + ".bin")
		var file := FileAccess.open(raw_path, FileAccess.WRITE)
		if file == null:
			push_error("[BG55] Cannot preserve raw viewport: %s" % raw_path)
			_contrast_failures += 1
		else:
			file.store_buffer(bytes)
			file.close()
		var error := Capture55.encode(probe._image, get_viewport().use_hdr_2d).save_png(directory.path_join(name + ".png"))
		if error != OK:
			push_error("[BG55] Cannot preserve PNG: %s" % error_string(error))
			_contrast_failures += 1
		_files55[key] = {"raw": name + ".bin", "png": name + ".png"}
	var enemies: Array[Dictionary] = []
	for node in level._entities.get_children():
		if not node is Enemy or not node.is_visible_in_tree() or not world.grow(-24.0).has_point(node.global_position):
			continue
		var parts := probe.character_parts(node.global_position)
		var bounds := probe._body_box(node.global_position, false)
		var full_bounds: Rect2 = node.rig.visual_bounds() if node.rig != null else bounds
		enemies.append({"instance": node.get_instance_id(), "id": str(node.data.id), "skin": node.data.rig_skin,
			"feet": [node.global_position.x, node.global_position.y], "facing": node.facing,
			"fill": node.rig._fill if node.rig != null else null,
			"light_cap": node.rig._light_cap if node.rig != null else null,
			"parts": parts, "contrast": maxf(parts.bright, parts.dark),
			"screen_rect": str(probe._screen_rect(bounds)), "visual_world_bounds": str(full_bounds),
			"aux_full_visual_parts": probe.contrast_parts(full_bounds, ContrastProbe.RING),
			"passed": maxf(parts.bright, parts.dark) >= ContrastProbe.MIN_ENEMY_CONTRAST})
	return {"label": label, "raw_sha256": sha, "files": _files55[key],
		"width": probe._image.get_width(), "height": probe._image.get_height(), "format": probe._image.get_format(),
		"density": probe._scale, "canvas_transform": str(probe._to_screen),
		"fog_density": level._fog.density, "enemy_fill_scale": level._lighting.current.enemy_fill_scale,
		"enemy_fill": LightKit.enemy_fill, "ambient": str(level._lighting.current.ambient_color),
		"enemies": enemies, "held": _held_state55(level)}


func _measure(level: Level, world: Rect2) -> Dictionary:
	var result := await super._measure(level, world)
	var authored := level._lighting.current.duplicate() as LightingProfile
	var baseline := load(_reference55) as LightingProfile if not _reference55.is_empty() else authored
	await _apply55(level, baseline)
	var first := await _capture55(level, world, "A0")
	await _apply55(level, baseline)
	var repeat := await _capture55(level, world, "A1")
	var valid: bool = first.raw_sha256 == repeat.raw_sha256 and first.held == repeat.held
	var records: Array[Dictionary] = [first, repeat]
	var factors: Array[String] = ["fill-min", "fill-max", "fog-half", "fog-quarter"] if _diagnose55 else (["product"] if not _reference55.is_empty() else [])
	for factor in factors:
		var candidate := authored if factor == "product" else variant_profile(baseline, factor)
		await _apply55(level, candidate)
		var altered := await _capture55(level, world, factor)
		valid = valid and altered.held == first.held
		records.append(altered)
		await _apply55(level, baseline)
		var restored := await _capture55(level, world, "restore-" + factor)
		valid = valid and restored.raw_sha256 == first.raw_sha256 and restored.held == first.held
		records.append(restored)
	await _apply55(level, authored)
	var product := await _capture55(level, world, "authored-final")
	records.append(product)
	if not valid:
		printerr("[BG55] A/A, restoration, or held-state control failed in %s cell %d" % [level.data.id, _cell55])
		_contrast_failures += 1
	if not _diagnose55:
		for enemy in product.enemies:
			if not enemy.passed:
				printerr("[BG55] Enemy below unchanged threshold: %s %s %.6f" % [enemy.id, enemy.feet, enemy.contrast])
				_contrast_failures += 1
	result["bg55"] = {"kind": "single held live scene; diagnostic factors" if _diagnose55 else "authored profile acceptance",
		"diagnostic_only": _diagnose55, "controls_valid": valid, "records": records,
		"source_sha256": FileAccess.get_sha256("res://tools/bg55_enemy_readability_probe.gd"),
		"enemy_box_unchanged": true, "aux_full_visual_is_not_acceptance": true,
		"distinct_images_deduplicated_by_actual_raw_sha256": true}
	_cell55 += 1
	return result

