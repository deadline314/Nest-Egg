extends "res://work/bg21-current-native/states.gd"
var _reviewed: Dictionary = {}
func _run() -> void:
    add_child(LightKit.create_environment())
    Story.auto_skip = true
    for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
    for name: String in ["ch1_pawnshop", "ch1_rooftop", "ch1_warehouse", "ch1_vault"]:
        GameState.start_new_run(GameState.difficulties[1])
        for id: String in Story.scene_ids(): Story._seen[StringName(id)] = true
        var data := (load("res://data/levels/" + name + ".tres") as LevelData).duplicate()
        data.show_chapter_card = false
        data.intro_scene = &""
        var level := Level.new()
        level.configure(data)
        add_child(level)
        level._arena_triggered = true
        await _settle(20)
        for enemy in get_tree().get_nodes_in_group(&"enemies"): enemy.queue_free()
        level.player.health.setup(999, 0.0)
        level.hud.visible = false
        var camera := get_viewport().get_camera_2d() as LevelCamera
        camera.set_physics_process(false)
        camera.offset = Vector2.ZERO
        camera.zoom = Vector2.ONE * LevelCamera.base_zoom()
        for node in level.find_children("*", "", true, false):
            if not is_instance_valid(node): continue
            if node is Portal and node.data.style in ["door", "ladder"] and not _reviewed.has(node.data.style):
                _reviewed[node.data.style] = true
                _check(node._art != null, "actual " + node.data.style + " has formal art")
                var shape: CollisionShape2D
                for child in node.get_children():
                    if child is CollisionShape2D: shape = child
                _check(shape != null and shape.shape.size == Vector2(node.data.width, node.data.height), "portal trigger size retains authored width/height")
                await _view(level, node, node.data.style, float(node.data.height)*0.5)
                var target := load(node.data.target_level) as LevelData
                var pair_found := false
                for item in target.legend.values():
                    if item is PortalData and item.id == node.data.target_portal:
                        pair_found = item.target_level == "res://data/levels/" + name + ".tres" and item.target_portal == node.data.id
                _check(pair_found, "authored portal destination and return pair remain reciprocal")
            elif node is HintSign and not _reviewed.has("hint"):
                _reviewed["hint"] = true
                _check(node._art != null and node.get_child_count() >= 2, "actual hint retains its body and prompt")
                await _view(level, node, "hint-formal", 26)
                var original := FixtureArt.texture(&"hint_sign")
                FixtureArt._cache[&"hint_sign"] = null
                var fallback := HintSign.new()
                fallback.text = node.text
                fallback.position = node.position
                node.get_parent().add_child(fallback)
                node.hide()
                _check(fallback._art == null and fallback.get_child_count() == 1 and fallback.text == node.text, "loader refusal retains the original sign drawing and same prompt")
                await _view(level, fallback, "hint-loader-refusal", 26)
                fallback.queue_free()
                node.show()
                FixtureArt._cache[&"hint_sign"] = original
            elif node is ChannelSwitch and node.data.id == &"ch1_switch_a":
                _reviewed["switch"] = true
                var gate: Gate
                for sibling in level.find_children("*", "", true, false):
                    if sibling is Gate and sibling.data.id == &"ch1_gate_a": gate = sibling
                _check(gate != null and node._art_off != null and node._art_on != null and gate._art != null, "actual switch and linked gate use formal textures")
                var shape: Vector2 = gate._shape_node.shape.size
                await _view(level, node, "switch-off", 30)
                await _view(level, gate, "gate-closed-lower", 60)
                level.player.process_mode = Node.PROCESS_MODE_INHERIT
                level.player.global_position = node.global_position + Vector2(-12, -2)
                await _settle(4)
                _check(node._player_in_range, "actual player is inside interaction trigger")
                Input.action_press(&"interact")
                await get_tree().physics_frame
                Input.action_release(&"interact")
                await _settle(12)
                _check(node.active and node._art_on.visible and not node._art_off.visible and gate.is_open and gate._shape_node.disabled and gate._shape_node.shape.size == shape, "real interaction changes artwork and opens original collision without resizing it")
                await _view(level, node, "switch-on", 30)
                await _view(level, gate, "gate-open-upper", float(gate._size.y)-40)
            elif node is Breakable and node.data.look == BreakableData.Look.WALL and not _reviewed.has("wall"):
                _reviewed["wall"] = true
                _check(node._wall_art != null and node._shape_node.shape.size == node.size_px, "actual secret wall art matches original collision")
                var shape: Vector2 = node._shape_node.shape.size
                await _view(level, node, "wall-intact", node.size_px.y*0.5)
                await _shoot(node, level)
                await _wait(0.18)
                _check(not node.is_broken and node.health.current < node.data.max_health and not node._shape_node.disabled and node._shape_node.shape.size == shape, "real projectile damages wall while original collision remains")
                await _view(level, node, "wall-damaged", node.size_px.y*0.5)
                for shot in node.data.max_health + 2:
                    if node.is_broken: break
                    if not await _shoot(node, level): break
                await _settle(3)
                _check(node.is_broken and node._shape_node.disabled and not node.hurtbox.enabled, "real projectiles remove wall collision and hurtbox")
                await _view(level, node, "wall-broken", node.size_px.y*0.5)
        level.queue_free()
        await _settle(4)
    _check(_reviewed.size() == 5, "door, ladder, hint, switch and secret wall reviewed in actual campaign scenes")
    var report := {"checks": _checks, "failures": _failures, "reviewed": _reviewed, "quality": Settings.get_light_quality(), "adapter": RenderingServer.get_video_adapter_name(), "shots": _shots, "scope": "Arranged authored campaign objects/camera; story entrances suppressed, enemies removed, 999 player HP. Real projectiles and switch interaction; isolated injected loader-null sign. Not natural campaign play or physical controller."}
    var file := FileAccess.open(_out_dir.path_join("receipt.json"), FileAccess.WRITE)
    file.store_string(JSON.stringify(report, "  ")+"\n")
    file.close()
    await AudioRelease.settle(get_tree())
    print("BG21_CORE ", JSON.stringify(report))
    get_tree().quit(1 if _failures else 0)
func _view(level: Level, node: Node2D, name: String, above: float) -> void:
    level.player.process_mode = Node.PROCESS_MODE_DISABLED
    level.player.global_position = node.global_position + Vector2(-32, 0)
    var camera := get_viewport().get_camera_2d() as LevelCamera
    camera.global_position = node.global_position - Vector2(0, above)
    camera.reset_smoothing()
    camera.force_update_scroll()
    await _settle(8)
    await _photo("campaign-" + name, level)
