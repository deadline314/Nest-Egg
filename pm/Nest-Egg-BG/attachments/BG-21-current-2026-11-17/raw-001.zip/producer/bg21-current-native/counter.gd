extends Node
func _ready() -> void:
    var old := load("res://work/bg21-current-native/before.gd") as Script
    var holder := Node2D.new()
    add_child(holder)
    var id := &"test_missing_prop_fixture_bg21_counter"
    var path := FixtureArt.FOLDER + String(id) + ".png"
    assert(not ResourceLoader.exists(path))
    var placeholder := RigLibrary.texture(path)
    assert(placeholder != null)
    var count := holder.get_child_count()
    var broken: Sprite2D = old.attach(holder, id, Vector2.ZERO, Vector2(8, 8))
    assert(broken != null and broken.texture == placeholder)
    broken.free()
    var fixed := FixtureArt.attach(holder, id, Vector2.ZERO, Vector2(8, 8))
    assert(fixed == null and holder.get_child_count() == count)
    var held := FixtureArt.texture(id)
    assert(held == null)
    print("BG21_COUNTER ", JSON.stringify({"old_false_success": true, "current_null": true, "children_held": true, "repeated_missing_still_null": true}))
    holder.free()
    get_tree().quit()
