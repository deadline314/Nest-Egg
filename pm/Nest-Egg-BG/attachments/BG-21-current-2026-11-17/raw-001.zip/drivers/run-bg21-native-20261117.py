from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg21-current/native')
out.mkdir(exist_ok=False)
private = root / 'work/bg21-current-native'
private.mkdir(exist_ok=False)
old = subprocess.check_output(['git', 'show', 'HEAD:game/props/fixture_art.gd'], cwd=root).decode('utf8')
assert old.startswith('class_name FixtureArt\n')
(private/'before.gd').write_text(old.removeprefix('class_name FixtureArt\n'), encoding='utf8', newline='\n')
(private/'counter.gd').write_text('''extends Node
func _ready() -> void:
    var old := load("res://work/bg21-current-native/before.gd") as Script
    var holder := Node2D.new()
    add_child(holder)
    var id := &"test_missing_prop_fixture_bg21_counter"
    var path := FixtureArt.FOLDER + String(id) + ".png"
    assert(not ResourceLoader.exists(path))
    var placeholder := RigLibrary.texture(path)
    assert(placeholder != null)
    var count := holder.get_child_count()
    var broken: Sprite2D = old.attach(holder, id, Vector2.ZERO, Vector2(8, 8))
    assert(broken != null and broken.texture == placeholder)
    broken.free()
    var fixed := FixtureArt.attach(holder, id, Vector2.ZERO, Vector2(8, 8))
    assert(fixed == null and holder.get_child_count() == count)
    var held := FixtureArt.texture(id)
    assert(held == null)
    print("BG21_COUNTER ", JSON.stringify({"old_false_success": true, "current_null": true, "children_held": true, "repeated_missing_still_null": true}))
    holder.free()
    get_tree().quit()
''', encoding='utf8', newline='\n')
original = (root/'tools/fixture_states_probe.gd').read_text(encoding='utf8')
needle = '\tSettings.use_storage("user://fixture_states_settings.cfg")'
assert original.count(needle) == 1
instrumented = original.replace(needle, needle + '''
    for argument in OS.get_cmdline_user_args():
        if argument.begins_with("--quality="):
            Settings.set_light_quality({"low": LightQuality.Tier.LOW, "high": LightQuality.Tier.HIGH}[argument.trim_prefix("--quality=")])
    print("BG21_ACTUAL_QUALITY ", Settings.get_light_quality())
'''.replace('    ', '\t')).replace('SOFTWARE FORWARD+ / ', 'FORWARD+ / ')
(private/'states.gd').write_text(instrumented, encoding='utf8', newline='\n')
for name in ['counter', 'states']:
    (private/(name+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg21-current-native/'+name+'.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n', encoding='utf8')
paths = [p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','project.godot'],cwd=root).decode().split('\0') if p and (root/p).is_file()]
def snapshot(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
runs=[]
for name in ['counter','low','high']:
    folder=out/name;folder.mkdir()
    env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']: env[key]=str(folder/'private-profile'/key)
    command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--audio-driver','Dummy']
    if name=='counter': command+=['--headless','res://work/bg21-current-native/counter.tscn']
    else:
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--',*command,'--rendering-method','forward_plus','--rendering-driver','vulkan','--resolution','1280x720','res://work/bg21-current-native/states.tscn','--','--out='+str(folder),'--quality='+name]
    with (folder/'raw.log').open('wb') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes()
    row={'name':name,'command':command,'exit':result.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'images':len(list(folder.glob('*.png'))),'exit_diagnostics':[line.decode('utf8',errors='replace') for line in raw.splitlines() if b'resources still in use at exit' in line or b'were leaked at exit' in line]}
    runs.append(row);(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    print(name,row,flush=True)
    assert row['exit']==row['script_errors']==0 and row['source_held']
    if name=='counter':
        assert raw.count(b'BG21_COUNTER ')==1 and raw.count('[FixtureArt] 找不到固定物件貼圖'.encode())==1
    else:
        report=json.loads((folder/'receipt.json').read_text())
        assert report['failures']==0 and report['quality']=={'low':0,'high':2}[name] and len(report['shots'])==row['images'] and row['images']>=18,report
        assert not [line for line in raw.splitlines() if line.startswith(b'ERROR:') and b'resources still in use at exit' not in line]
(out/'source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
