from pathlib import Path
import hashlib,json,os,subprocess
root=Path("D:/NestEggVerification/ne218-baseline-20261117")
out=Path("D:/NestEggVerification/evidence-20261117/bg21-current/native")
paths = [p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','project.godot'],cwd=root).decode().split('\0') if p and (root/p).is_file()]
def snapshot(): return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=snapshot(); assert before == json.loads((out/'source-before.json').read_text())
(out/'high-source-before.json').write_text(json.dumps(before,indent=2)+'\n')
runs=[]
for name in ['high']:
    folder=out/name;folder.mkdir()
    env=os.environ.copy()
    for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']: env[key]=str(folder/'private-profile'/key)
    command=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--audio-driver','Dummy']
    if name=='counter': command+=['--headless','res://work/bg21-current-native/counter.tscn']
    else:
        command=['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--',*command,'--rendering-method','forward_plus','--rendering-driver','vulkan','--resolution','1280x720','res://work/bg21-current-native/states.tscn','--','--out='+str(folder),'--quality='+name]
    with (folder/'raw.log').open('wb') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(folder/'raw.log').read_bytes()
    row={'name':name,'command':command,'exit':result.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==snapshot(),'images':len(list(folder.glob('*.png'))),'exit_diagnostics':[line.decode('utf8',errors='replace') for line in raw.splitlines() if b'resources still in use at exit' in line or b'were leaked at exit' in line]}
    runs.append(row);(out/'high-run.json').write_text(json.dumps(runs,indent=2)+'\n')
    print(name,row,flush=True)
    assert row['exit']==row['script_errors']==0 and row['source_held']
    if name=='counter':
        assert raw.count(b'BG21_COUNTER ')==1 and raw.count('[FixtureArt] 找不到固定物件貼圖'.encode())==1
    else:
        report=json.loads((folder/'receipt.json').read_text())
        assert report['failures']==0 and report['quality']=={'low':0,'high':2}[name] and len(report['shots'])==row['images'] and row['images']==17,report
        assert not [line for line in raw.splitlines() if line.startswith(b'ERROR:') and b'resources still in use at exit' not in line]
(out/'high-source-after.json').write_text(json.dumps(snapshot(),indent=2)+'\n')
