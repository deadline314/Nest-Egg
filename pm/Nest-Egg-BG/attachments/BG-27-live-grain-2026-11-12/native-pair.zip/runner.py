from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time, urllib.error, urllib.request

ROOT = Path('C:/Users/stanl/Github/Nest-Egg')
context = json.loads((ROOT/'work/bg42-published-preparation-v1/published-context.json').read_bytes())
PROJECT = Path(context['project'])
OUT = ROOT/'work/bg27-native-pair-v1'
OUT.mkdir(exist_ok=False)
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf8', newline='\n')
def queues():
    result=[]
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for port in (8188,8189):
        try:
            with opener.open(f'http://127.0.0.1:{port}/queue',timeout=6) as response:
                raw=response.read()
            data=json.loads(raw)
            assert isinstance(data['queue_running'],list) and isinstance(data['queue_pending'],list)
            running,pending=len(data['queue_running']),len(data['queue_pending'])
            result.append(dict(port=port,state='empty' if running==pending==0 else 'busy',running=running,pending=pending,response_sha256=hashlib.sha256(raw).hexdigest()))
        except urllib.error.URLError as error:
            code=getattr(error.reason,'winerror',None)
            result.append(dict(port=port,state='refused' if code==10061 else 'unknown',winerror=code))
    return result
files=dict(context['files'])
for path in (PROJECT/'work/bg27-live-grain-v1').rglob('*'):
    if path.is_file() and path.suffix in ('.gd','.tscn','.txt'):
        files[path.relative_to(PROJECT).as_posix()]=sha(path)
for name,wanted in files.items():
    assert sha(PROJECT/name)==wanted,name
c_guard=json.loads((ROOT/'work/ne228-codex-final-official-v1/c-native-context-v15.json').read_bytes())['files']
assert all(sha(ROOT/name)==wanted for name,wanted in c_guard.items())
save(OUT/'source-before.json',files)
save(OUT/'c-before.json',c_guard)
save(OUT/'host-lock-before.json',{name:sha(ROOT/name) for name in ('tools/comfyui/gpu_lock.py','tools/comfyui/comfy_guard.py')})
(OUT/'runner.py').write_bytes(Path(__file__).read_bytes())
for candidate in (False,True):
    folder=OUT/('candidate' if candidate else 'baseline');folder.mkdir()
    before=queues();save(folder/'queue-before.json',before)
    assert all(item['state'] in ('empty','refused') for item in before),'busy or unknown; no engine started'
    command=[sys.executable,str(ROOT/'tools/comfyui/gpu_lock.py'),'--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(PROJECT),'--resolution','1280x720','--rendering-method','forward_plus','--rendering-driver','vulkan','res://work/bg27-live-grain-v1/native.tscn','--','--out='+str(folder)]
    if candidate:command.append('--candidate')
    save(folder/'command.json',command)
    env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
    for key,name in [('APPDATA','roaming'),('LOCALAPPDATA','local'),('XDG_DATA_HOME','data'),('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache')]:
        path=folder/'user'/name;path.mkdir(parents=True);env[key]=str(path)
    started=time.monotonic()
    with (folder/'run.log').open('xb') as log:
        process=subprocess.run(command,cwd=PROJECT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    seconds=time.monotonic()-started
    after=queues();save(folder/'queue-after.json',after)
    diagnostics=[line for line in (folder/'run.log').read_text(encoding='utf8',errors='replace').splitlines() if re.search(r'ERROR:|SCRIPT ERROR|WARNING:|ObjectDB.*leak|RID.*leak|resources still in use',line,re.I)]
    result=json.loads((folder/'result.json').read_bytes())
    expected=[] if candidate else ['live reduced flashes clears the actual rendered grain']
    receipt=dict(exit=process.returncode,seconds=seconds,diagnostics=diagnostics,expected_failures=expected,actual_failures=result['failures'],source_unchanged=all(sha(PROJECT/name)==wanted for name,wanted in files.items()),c_unchanged=all(sha(ROOT/name)==wanted for name,wanted in c_guard.items()),queue_clear=all(item['state'] in ('empty','refused') for item in after))
    save(folder/'exit.json',receipt)
    assert process.returncode==(0 if candidate else 1) and not diagnostics and result['failures']==expected and receipt['source_unchanged'] and receipt['c_unchanged'] and receipt['queue_clear'],receipt
    print(json.dumps(receipt),flush=True)
save(OUT/'source-after.json',{name:sha(PROJECT/name) for name in files})
save(OUT/'c-after.json',{name:sha(ROOT/name) for name in c_guard})
