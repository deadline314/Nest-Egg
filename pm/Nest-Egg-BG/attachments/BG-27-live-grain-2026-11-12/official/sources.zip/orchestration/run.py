"""Isolated published-896 BG27 original-selector validation; binary raw logs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

C = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
P = Path('C:/Users/stanl/.codex/worktrees/bg27-live-grain-validation-20261112/Nest-Egg')
BASE = '896d3e8a7fb1b0018df0aec47ed8c5a37bb881c0'
GODOT = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
BASH = 'C:/Program Files/Git/bin/bash.exe'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def save(name, data):
    path = OUT / name
    assert not path.exists(), str(path)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')

def call(command, name, env=None):
    start = time.monotonic()
    with (OUT / (name + '.log')).open('xb') as f:
        p = subprocess.run(command, cwd=P, env=env, stdout=f, stderr=subprocess.STDOUT)
    result = dict(command=command, cwd=str(P), exit_code=p.returncode,
                  seconds=time.monotonic()-start, utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save(name + '-process.json', result)
    print(name, result, flush=True)
    return p.returncode

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=P).decode().strip() == BASE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=P), 'New isolated tree must start clean'
manifest_path = C / 'work/bg27-live-grain-candidate-v1/manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf8'))
assert len(manifest['files']) == 3
for name, expected in manifest['files'].items():
    source = manifest_path.parent / 'candidate' / name
    assert sha(source) == expected
    target = P / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert sha(target) == expected
save('candidate.json', dict(official_base=BASE, canonical_manifest_sha256=sha(manifest_path),
                           canonical_manifest=manifest, files=manifest['files']))
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=P).decode('utf8').split('\0')
names = sorted(set(filter(None, tracked)) | set(manifest['files']))
before = {name:sha(P/name) for name in names}
save('source-before.json', before)
shutil.copyfile(P/'tools/test_filters.sh', OUT/'test_filters.sh.txt')
shutil.copyfile(P/'tests/known_failures.txt', OUT/'known_failures.txt')
save('entry-source.json', {name:sha(P/name) for name in ['tools/run_tests_changed.sh', 'tools/run_tests_parallel.sh', 'tools/select_tests.py', 'tools/test_filters.sh', 'tests/known_failures.txt']})
print('Frozen',len(before),'files; import starting under primary repository lock', flush=True)
rc = call(['python', str(C/'tools/comfyui/gpu_lock.py'), '--', GODOT, '--headless', '--editor', '--quit'], 'import')
text = (OUT/'import.log').read_text(encoding='utf8', errors='replace')
diagnostics = [line for line in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|Parse Error|ObjectDB.*leak|were leaked|resources still in use', line)]
save('import-diagnostics.json', diagnostics)
assert rc == 0 and not diagnostics, 'Import rejected; retain raw log'
uid = P/'tests/helpers/grain_accessibility_checks.gd.uid'
assert uid.is_file(), 'True import must generate the new helper UID'
shutil.copyfile(uid, OUT/uid.name)
after_import = {name:sha(P/name) for name in names}
assert before == after_import, 'Import changed a frozen source'
save('source-after-import.json', after_import)
save('generated-uid.json', dict(path=str(uid.relative_to(P)), sha256=sha(uid)))
print('Import DONE: primary lock released; original SHARDS=1 CPU entry starting', flush=True)
env = os.environ.copy()
env.update(GODOT=GODOT, SHARDS='1', LOG_DIR=str(OUT/'logs'), PYTHONIOENCODING='utf-8')
(OUT/'logs').mkdir()
rc = call([BASH, 'tools/run_tests_changed.sh', BASE], 'affected', env)
after = {name:sha(P/name) for name in names}
save('source-after.json', after)
save('source-status.json', dict(fixed=before == after, count=len(before), uid_fixed=sha(uid) == sha(OUT/uid.name),
                               isolated_status=subprocess.check_output(['git','status','--porcelain'],cwd=P).decode('utf8')))
assert before == after
lines=[]
for path in sorted((OUT/'logs').glob('shard_*.log')):
    raw=path.read_text(encoding='utf8',errors='replace')
    lines.extend(dict(file=path.name,line=i,text=line) for i,line in enumerate(raw.splitlines(),1)
                 if re.search(r'^FAIL:|^ERROR:|SCRIPT ERROR|Parse Error|ObjectDB.*leak|were leaked|resources still in use|^checks:',line))
save('raw-diagnostics-and-failures.json',lines)
print('FINAL original_entry_exit',rc,'source_fixed',before == after,flush=True)
raise SystemExit(rc)
