"""Sequential isolated users/processes; preserve original official epoch unchanged."""
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

OUT=Path(__file__).resolve().parent
SEALED=OUT.parent
P=Path('C:/Users/stanl/.codex/worktrees/bg27-live-grain-validation-20261112/Nest-Egg')
BASE='896d3e8a7fb1b0018df0aec47ed8c5a37bb881c0'
GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
expected=json.loads((SEALED/'source-after.json').read_text(encoding='utf8'))
candidate=json.loads((SEALED/'candidate.json').read_text(encoding='utf8'))['files']
paths=['game/cutscene/stage_layers.gd','tests/suite/test_cutscene.gd']
original={n:(P/n).read_bytes() for n in candidate}
uid=P/'tests/helpers/grain_accessibility_checks.gd.uid'
uid_original=uid.read_bytes()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def all_hashes():return {n:sha((P/n).read_bytes()) for n in expected}
def save(name,data):
    path=OUT/name
    assert not path.exists(),str(path)
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8',newline='\n')
assert all_hashes()==expected
assert all(sha(original[n])==h for n,h in candidate.items())
baseline={n:subprocess.check_output(['git','show',BASE+':'+n],cwd=P) for n in paths}
save('plan.json',dict(base=BASE,classification='Not performance. Two independent headless CutsceneSuite runs with separate users; original 26-group receipts unchanged',baseline_sha256={n:sha(v) for n,v in baseline.items()},candidate_sha256=candidate,uid_sha256=sha(uid_original)))
rows=[]
try:
    for condition in ['A_baseline','B_candidate']:
        for name in paths:(P/name).write_bytes(baseline[name] if condition=='A_baseline' else original[name])
        before=all_hashes()
        save(condition+'-before.json',before)
        expected_here=expected.copy()
        if condition=='A_baseline':expected_here.update({n:sha(v) for n,v in baseline.items()})
        assert before==expected_here
        user=OUT/('user-'+condition);user.mkdir()
        env=os.environ.copy();env.update(APPDATA=str(user),LOCALAPPDATA=str(user),XDG_DATA_HOME=str(user))
        command=[GODOT,'--headless','--path',str(P),'res://tests/smoke_test.tscn','--','--only=CutsceneSuite']
        start=time.monotonic()
        with (OUT/(condition+'.log')).open('xb') as log:
            result=subprocess.run(command,cwd=P,env=env,stdout=log,stderr=subprocess.STDOUT)
        raw=(OUT/(condition+'.log')).read_bytes()
        after=all_hashes()
        save(condition+'-after.json',after)
        text=raw.decode('utf8',errors='replace')
        lines=text.splitlines()
        diagnostics=[dict(line=i,text=l) for i,l in enumerate(lines,1) if re.search(r'SCRIPT ERROR|^ERROR:|Parse Error|ObjectDB.*leak|were leaked|resources still in use',l)]
        leaked=[d for d in diagnostics if re.search(r'ObjectDB.*leak|were leaked|resources still in use',d['text'])]
        summaries=re.findall(r'^checks: (\d+), failures: (\d+)',text,re.M)
        row=dict(condition=condition,command=command,user=str(user),exit_code=result.returncode,seconds=time.monotonic()-start,source_fixed=before==after,summary=summaries[-1] if summaries else None,diagnostics=diagnostics,exit_leaks=leaked,log_sha256=sha(raw),script_errors=sum('SCRIPT ERROR' in l for l in lines),failure_lines=[l for l in lines if l.startswith('FAIL:')])
        save(condition+'-process.json',row);rows.append(row)
        print(condition,row['summary'],'exit',result.returncode,'script_errors',row['script_errors'],'exit_leaks',len(leaked),'seconds',row['seconds'],flush=True)
        assert before==after and uid.read_bytes()==uid_original
        assert result.returncode==0 and row['summary'] and not row['failure_lines'] and not row['script_errors']
finally:
    for name,raw in original.items():(P/name).write_bytes(raw)
    restored=all_hashes()
    save('candidate-restored.json',dict(all_27674_exact=restored==expected,candidate={n:sha((P/n).read_bytes()) for n in candidate},uid_exact=uid.read_bytes()==uid_original))
    assert restored==expected and uid.read_bytes()==uid_original
if len(rows)==2:
    delta=int(rows[1]['summary'][0])-int(rows[0]['summary'][0])
    compare=dict(check_delta=delta,expected_new_checks=8,baseline_exit_leaks=rows[0]['exit_leaks'],candidate_exit_leaks=rows[1]['exit_leaks'],diagnostic_counts=[dict(condition=r['condition'],counts=dict(collections.Counter(d['text'] for d in r['diagnostics']))) for r in rows])
    save('comparison.json',compare)
    assert delta==8
    print('Candidate restored exact. Actual added checks:',delta,flush=True)
