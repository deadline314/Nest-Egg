from pathlib import Path
import os,subprocess,time,json
w=Path('work/bg50-prefetch-budget');path=Path('core/asset_prefetch.gd');final=path.read_bytes();env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1');rows=[]
def run(label):
 e=env.copy();e['LOG_DIR']=str((w/(label+'-shards')).resolve());cmd=['tools/run_tests_parallel.sh','--only=InputFeelSuite,CutsceneSuite,Chapter1MapSuite'];start=time.monotonic()
 with (w/(label+'.log')).open('w') as f:r=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 rows.append({'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start});(w/'focus-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);return r.returncode
try:
 path.write_bytes((w/'asset_prefetch-before.gd').read_bytes())
 assert run('negative-suite')==1
finally:path.write_bytes(final)
assert run('fixed-suite')==0
