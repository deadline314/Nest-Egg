from pathlib import Path
import os,json,subprocess,time,re,hashlib
w=Path('work/bg50-prefetch-budget');paths=['autoload/event_bus.gd','ui/dialogue_layer.gd','ui/kit/background_hover_guard.gd'];final={p:Path(p).read_bytes() for p in paths};rows=[]
for label,old,verbose in [('before-hover',True,True),('integrated-final',False,False)]:
 try:
  if old:
   for p in paths:Path(p).write_bytes(subprocess.check_output(['git','show','7a29f753:'+p]))
  env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/quests'
  if verbose:env['NE_NATIVE_GODOT']=str((w/'godot-verbose').resolve())
  name='bg50-1022-prefetch-exit-'+label;cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/bg50-prefetch-budget/native.tscn','--level=ch1_street,ch1_warehouse','--seconds=5','--tag=bg50'];start=time.monotonic()
  with (w/(label+'-wrapper.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
  b=Path('/workspace/Nest-Egg/work/batch1020b');log=(b/(name+'.log')).read_text();rec={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'engine_errors':log.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log)),'verbose':verbose,'before_hover_product':old};rows.append(rec);(w/'exit-comparison.json').write_text(json.dumps(rows,indent=2));print(label,rec,flush=True)
  if not old:
   (w/'integrated-first-native-receipt.json').write_bytes((w/'native-receipt.json').read_bytes())
   (w/'native-receipt.json').write_text(json.dumps(rec,indent=2));assert r.returncode==0 and rec['engine_errors']==0 and rec['leaks']==0
 finally:
  for p,v in final.items():Path(p).write_bytes(v)
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
print('EXIT_COMPARISON_COMPLETE',flush=True)
env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='2',LOG_DIR=str((w/'changed-shards').resolve()));cmd=['tools/run_tests_changed.sh',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()];start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
(w/'changed-receipt.json').write_text(json.dumps({'base':cmd[1],'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'shards':2},indent=2));assert r.returncode==0
print('BG50_INTEGRATED_PASS',flush=True)
