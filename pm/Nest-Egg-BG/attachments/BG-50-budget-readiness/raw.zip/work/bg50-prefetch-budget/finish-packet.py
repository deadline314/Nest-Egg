from pathlib import Path
import subprocess,time,json
w=Path('work/bg50-prefetch-budget');deadline=time.monotonic()+1500
while True:
 r=json.loads((w/'changed-receipt.json').read_text()) if (w/'changed-receipt.json').exists() else {}
 if r.get('base','').startswith('ad8c1cfe') and r.get('exit_code') is not None:break
 assert time.monotonic()<deadline
 time.sleep(2)
assert r['exit_code']==0,r
p=Path('design/20-campaign-experience/PREFETCH_BUDGET_READINESS.md');s=p.read_text().replace('預定修法：','修法：');summary=[x for x in (w/'changed.log').read_text().splitlines() if x.startswith('checks:')][-1];s+='\n2026-10-23最終整合：'+summary+'。接上獨立交付ad8同步守門後，原50組完整通過；先前中斷無終局收據，不當通過。首次原生退出留存尚未定位，前後診斷及最後原設定0ERROR／0退出洩漏全部保留，最新四圖逐張檢視。\n';p.write_text(s)
subprocess.run(['python',str(w/'package.py')],check=True)
subprocess.run(['python',str(w/'final-docs.py')],check=True)
subprocess.run(['git','diff','--check'],check=True)
print('BG50_PACKET_READY',flush=True)
