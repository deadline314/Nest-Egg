from pathlib import Path
import subprocess,os,json,time,hashlib,re,shutil
w=Path('work/bg50-prefetch-budget');base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert base.startswith('ad8c1cfe')
# Archive the complete second, unsuccessful run before replacing the active receipt.
archive=w/'second-hover-failure';archive.mkdir(exist_ok=True)
for name in ['changed.log','changed-receipt.json','changed-shards','native-receipt.json','viewed.json','verification-frozen-source.json']:
 p=w/name
 if p.is_dir():shutil.copytree(p,archive/name,dirs_exist_ok=True)
 else:shutil.copyfile(p,archive/name)
shutil.rmtree(w/'changed-shards')
files=['core/asset_prefetch.gd','tests/suite/test_ch1_map.gd','work/bg50-prefetch-budget/probe.gd','work/bg50-prefetch-budget/native.gd','tools/frame_time_probe.gd','tools/viewport_capture.gd','autoload/event_bus.gd','ui/dialogue_layer.gd','ui/kit/background_hover_guard.gd','tests/helpers/hud_background_hover_checks.gd']
(w/'verification-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2))
(w/'integration-base.json').write_text(json.dumps({'base':base,'first_run':'first-changed.log','second_run':'second-hover-failure/changed.log','reason':'Integrate separately delivered synchronous hover visibility, preserve both prior failures. SHARDS2 respects actual4CPUquota; original selection/predicates/input/waits/filters remain unchanged.'},indent=2))
env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/quests';name='bg50-1022-prefetch-world-'+base[:8];cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/bg50-prefetch-budget/native.tscn','--level=ch1_street,ch1_warehouse','--seconds=5','--tag=bg50'];start=time.monotonic()
with (w/'native-wrapper.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
b=Path('/workspace/Nest-Egg/work/batch1020b');log=(b/(name+'.log')).read_text();rec={'base':base,'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'engine_errors':log.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log))};(w/'native-receipt.json').write_text(json.dumps(rec,indent=2));assert r.returncode==0 and rec['engine_errors']==0 and rec['leaks']==0
report=json.loads((b/name/'bg50-frame-time.json').read_text());assert len(report['levels'])==2 and all(x['prefetch']['loads']>0 for x in report['levels']);assert log.count('error=0')==4 and len(list((b/name).glob('*.png')))==4
print('NATIVE_READY',name,flush=True)
env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='2',LOG_DIR=str((w/'changed-shards').resolve()));cmd=['tools/run_tests_changed.sh',base];start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
(w/'changed-receipt.json').write_text(json.dumps({'base':base,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'shards':2},indent=2));assert r.returncode==0
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
print('BG50_INTEGRATED_PASS',flush=True)
