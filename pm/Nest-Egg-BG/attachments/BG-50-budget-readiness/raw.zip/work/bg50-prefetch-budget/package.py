from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil,re
root=Path.cwd();w=root/'work/bg50-prefetch-budget';out=root/'pm/Nest-Egg-BG/attachments/BG-50-budget-readiness';native=Path('/workspace/Nest-Egg/work/batch1020b');base=json.loads((w/'integration-base.json').read_text())['base'];sha=lambda b:hashlib.sha256(b).hexdigest()
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
r=json.loads((w/'changed-receipt.json').read_text());assert r['exit_code']==0
t=(w/'changed.log').read_text();assert 'new failures: 0' in t and 'Detected script errors' not in t
assert json.loads((w/'original-test-reconstruction.json').read_text())['original_assertions_inputs_waits_byte_exact']
n=json.loads((w/'native-receipt.json').read_text());assert n['exit_code']==0 and n['engine_errors']==0 and n['leaks']==0
view=json.loads((w/'viewed.json').read_text());assert view['individually_viewed'] and len(view['files'])==4
harness=['tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']
for p in harness:assert (root/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p]),p
files={}
for p in w.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in x or x=='__pycache__' for x in p.relative_to(w).parts):files['work/bg50-prefetch-budget/'+str(p.relative_to(w))]=p.read_bytes()
for p in native.glob('bg50-1022-prefetch-*'):
 if 'profile' in p.name:continue
 if p.is_dir():
  for f in p.rglob('*'):
   if f.is_file():files['native/'+str(f.relative_to(native))]=f.read_bytes()
 elif p.is_file():files['native/'+p.name]=p.read_bytes()
refs=root/'../kitchen/work/ne228-hud-reading/references'
for name in ['598550-2.jpg','435530-2.jpg','sources.json']:files['references/'+name]=(refs/name).read_bytes()
paths=list(json.loads((w/'verification-frozen-source.json').read_text()))+harness+['design/20-campaign-experience/PREFETCH_BUDGET_READINESS.md']
for p in paths:files['source/final/'+p]=(root/p).read_bytes()
for p in ['core/asset_prefetch.gd','tests/suite/test_ch1_map.gd']:files['source/before/'+p]=subprocess.check_output(['git','show',base+':'+p])
report=json.loads((native/n['name']/'bg50-frame-time.json').read_text())
validation={'base':base,'additional_checks':5,'standalone_control':'real WorkerThreadPool reads actual imported pistol; explicit20ms mutex holder, original2ms soft budget; before5/2,after5/0','unit':'same original InputFeel/Cutscene/Chapter1Map group: before2368/2,after2368/0; unit uses declared200ms contention to ensure the original2ms branch admits on shared CI','affected':r,'affected_summary':[l for l in t.splitlines() if 'checks:' in l or re.search(r'Running \d+ groups',l)],'native':n,'viewed':view,'frame_report':report,'original_failure':'HUD integration on7a:7358 checks,1 warm-order failure,225s; no failure-time stats. Original check did not recur in negative focus, only2 new controlled failures. Demonstrated lost readiness gap is not called uniquely established root of original intermittent failure.','previous_ci':'7a29f753 run39789378374 job119861006251:96007/0 new/0 known,550s. Full raw job retained.','harness_unchanged':harness,'scope':'Forward+ HDR llvmpipe software Vulkan; original frame_time_probe bot and authored street/warehouse, production environment added. Original explicit invulnerability99999, virtual gamepad, auto skipped story and new run without route prerequisites remain; goal row stays prologue, not natural formal route. Initial v1 native medians179.18/210.78ms are historical; final timings are in frame_report. Neither software run passes hardware hitch criteria or proves cold cache. No physical controller/GPU or human acceptance.'}
out.mkdir(parents=True,exist_ok=True);(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
validation['first_affected_run']=json.loads((w/'first-changed-receipt.json').read_text())
validation['first_affected_failure']='55025 checks / 1 explosion budget failure (+12.64ms, original6ms). Original warming check passed; other49 groups passed.'
validation['paired_explosion_perf']=json.loads((w/'perf-comparison.json').read_text())
validation['engine_monitor_reference']=json.loads((w/'engine-monitor-reference.json').read_text())
validation['second_affected_run']=json.loads((w/'second-hover-failure/changed-receipt.json').read_text())
validation['second_affected_failure']='55025 checks / 2 original hover failures before ad8c1cfe. Separate hover synchrony delivery integrated; original failures lacked same-call snapshot, unique root not asserted.'
validation['integrated_first_native']=json.loads((w/'integrated-first-native-receipt.json').read_text())
validation['exit_comparison']=json.loads((w/'exit-comparison.json').read_text())
validation['exit_scope']='First integrated run exit0 but12 ObjectDB instances/3 resources reported; same-source verbose run, before-hover verbose control and original-settings final all0errors/leaks. No cleanup or timing changes; first issue remains unlocated, do not call it fixed.'
validation['interruption']='One ad8 full-selector run interrupted by environment pause; only partial logs, no terminal receipt. Archived interrupted-ad8-integration, including exact zombie process state. Last replay is the only final integrated receipt.'
validation['resource_scope']='4CPU quota;SHARDS2, original predicates/input/waits/harness/filters unchanged. Same original50 selected.'
(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for p,b in files.items():assert sha(z.read(p))==sha(b),p
m={'archive_bytes':(out/'raw.zip').stat().st_size,'archive_sha256':sha((out/'raw.zip').read_bytes()),'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for area in ['street','warehouse']:shutil.copyfile(native/n['name']/('ch1_'+area+'-running.png'),root/('pm/Nest-Egg-BG/images/BG-50-budget-'+area+'.png'))
for app,title in [('598550','huntdown'),('435530','finalstation')]:shutil.copyfile(refs/(app+'-2.jpg'),root/('pm/Nest-Egg-BG/images/BG-50-budget-ref-'+title+'.jpg'))
receipt={'entries':len(files),'bytes':m['archive_bytes'],'sha256':m['archive_sha256']};(w/'package-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
