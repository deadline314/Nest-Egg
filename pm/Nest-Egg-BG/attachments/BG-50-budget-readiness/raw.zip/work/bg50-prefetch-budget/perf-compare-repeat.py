from pathlib import Path
import subprocess,os,json,time,shutil,hashlib,re
w=Path('work/bg50-prefetch-budget');assert json.loads((w/'changed-receipt.json').read_text())['exit_code']==1
for name in ['changed.log','changed-receipt.json','verification-frozen-source.json']:
 shutil.copyfile(w/name,w/('first-'+name))
shutil.copytree(w/'changed-shards',w/'first-changed-shards',dirs_exist_ok=True)
paths=['core/asset_prefetch.gd','tests/suite/test_ch1_map.gd'];final={p:Path(p).read_bytes() for p in paths};rows=[]
env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1')
try:
 for label in ['baseline','current']:
  for p in paths:Path(p).write_bytes(subprocess.check_output(['git','show','7a29f753:'+p]) if label=='baseline' else final[p])
  command=['tools/run_tests_parallel.sh','--only=FxMeleePickupsSuite'];e=env.copy();e['LOG_DIR']=str((w/(label+'-perf-shards')).resolve());start=time.monotonic()
  with (w/(label+'-perf.log')).open('w') as f:r=subprocess.run(command,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=400)
  log=(w/(label+'-perf-shards')/'shard_0.log').read_text();row={'label':label,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start,'source_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths},'metrics':[l for l in log.splitlines() if 'FX_PERF' in l or l.startswith('checks:')]};rows.append(row);(w/'perf-comparison.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
finally:
 for p,b in final.items():Path(p).write_bytes(b)
assert len(rows)==2 and all(r['exit_code']==0 for r in rows),'paired perf comparison needs investigation'
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
env.update(SHARDS='6',LOG_DIR=str((w/'changed-shards').resolve()));command=['tools/run_tests_changed.sh','7a29f7535f60cef70cbb3c6deafb2790fb897975'];start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
(w/'changed-receipt.json').write_text(json.dumps({'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2));assert r.returncode==0
print('UNCHANGED_FULL_REPLAY_PASS',flush=True)
