from pathlib import Path
import subprocess,os,json,time,hashlib,re
w=Path('work/bg50-prefetch-budget');deadline=time.monotonic()+600
while True:
 rows=json.loads((w/'focus-receipt.json').read_text()) if (w/'focus-receipt.json').exists() else []
 if len(rows)==2:break
 assert time.monotonic()<deadline
 time.sleep(1)
assert rows[0]['exit_code']==1 and rows[1]['exit_code']==0
files=['core/asset_prefetch.gd','tests/suite/test_ch1_map.gd','work/bg50-prefetch-budget/probe.gd','work/bg50-prefetch-budget/native.gd','tools/frame_time_probe.gd','tools/viewport_capture.gd']
(w/'verification-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2))
env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/quests';name='bg50-1022-prefetch-world-v1';cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/bg50-prefetch-budget/native.tscn','--level=ch1_street,ch1_warehouse','--seconds=5','--tag=bg50'];start=time.monotonic()
with (w/'native-wrapper.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
b=Path('/workspace/Nest-Egg/work/batch1020b');log=(b/(name+'.log')).read_text();rec={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'engine_errors':log.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log))};(w/'native-receipt.json').write_text(json.dumps(rec,indent=2));assert r.returncode==0 and rec['engine_errors']==0 and rec['leaks']==0
report=json.loads((b/name/'bg50-frame-time.json').read_text());assert len(report['levels'])==2 and all(x['prefetch']['loads']>0 for x in report['levels'])
assert log.count('error=0')==4 and len(list((b/name).glob('*.png')))==4
env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6',LOG_DIR=str((w/'changed-shards').resolve()));cmd=['tools/run_tests_changed.sh','7a29f7535f60cef70cbb3c6deafb2790fb897975'];start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
(w/'changed-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2));assert r.returncode==0
print('BG50_VERIFIED',flush=True)
