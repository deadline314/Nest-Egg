from pathlib import Path
import json
w=Path('work/bg50-prefetch-budget');out=Path('pm/Nest-Egg-BG/attachments/BG-50-budget-readiness');r=json.loads((w/'changed-receipt.json').read_text());assert r['exit_code']==0
s=(w/'changed.log').read_text();summary=[x for x in s.splitlines() if x.startswith('checks:')][-1];assert 'new failures: 0' in summary
packet=json.loads((w/'package-receipt.json').read_text());n=json.loads((w/'native-receipt.json').read_text());report=json.loads((Path('/workspace/Nest-Egg/work/batch1020b')/n['name']/'bg50-frame-time.json').read_text());metrics='；'.join(f"{x['level']}中位數{x['median_ms']}ms，超33.3ms共{x['hitches']}格，實際預載{x['prefetch']['loads']}張／暖檔逾時{x['prefetch']['warm_timeouts']}次" for x in report['levels'])
(out/'README.md').write_text(f'''# BG-50：延後載入時保留背景完成標記

背景已讀完貼圖，主線因本格原2ms軟預算延後時，原版會先丟完成標記、同路徑又不重排，可能白等原3秒備援。現在真正開始載入才取件與計逾時。原每格一張、2ms／3秒、純背景IO與主線ResourceLoader、快取與scope規則保持。[設計](../../../../design/20-campaign-experience/PREFETCH_BUDGET_READINESS.md)、[收據](validation.json)、[全部原檔](raw.zip)、[SHA](manifest.json)。

正式pistol匯入檔由真WorkerThreadPool讀完；另一真工作明示持mutex20ms，原預算拒絕時ready舊版消失、新版保留，下一格真正cache增加。負控制5／2→5／0。原InputFeel／Cutscene／Chapter1Map只加五項，2368／2→2368／0；單元明示200ms競爭以確保原2ms分支准入。原所有斷言／輸入／等待逐位元保持，只另加失敗時唯讀狀態；runner／selector／filters／known_failures不變。

最後整合基準{r['base'][:8]}：{summary}，含準備{r['seconds']:.2f}秒。原50組全部跑完；四核心容器以兩程序保留引擎背景工作空間，沒有改判準。全部分片、固定來源SHA與真正指令收據保留。

環境暫停後，一次ad8整合測試僅完成部分套件便中斷，三個原程序已成zombie、沒有終局收據；完整部分log另存interrupted-ad8-integration。舊7a失敗收據不冒充那次結果，最後仍按原50組重新完整驗證。

前兩輪基準7a均保留：第一輪55,025項／1個爆炸效能超標（+12.64ms，原6ms）；未修改7a及本次來源隔離同Fx套件各44／0，原監測idle／burst為6.92／3.02及3.62／5.03ms，不稱性能改善或修好唯一根因。Godot4.7.2 main.cpp證實TIME_PROCESS每秒才寫process_max，原40格取樣不能當逐格平均；原檔／URL／SHA保留。第二輪55,025／2為原通訊守門失敗；唯讀十組觀察8774／0後找到另一個同呼叫同步缺口，已分票ad8c1cfe交付並整合，本票不混入Hover程式，也不補造舊失敗缺少的瞬間狀態。原暖檔檢查在這兩輪均通過。

第一次ad8整合原生exit0但退出有12個ObjectDB／3個資源留存，故當輪不通過。未改來源的verbose、改回Hover交付前的verbose對照、最後原設定整合程序均0引擎ERROR／0退出洩漏診斷；沒有增加清理等待、關效果或改原工具。這個首次留存未定位，不聲稱修好；成功與失敗完整log均保留。

最後正式街道／倉庫沿用原frame_time工具，僅增加正式環境與讀回：{metrics}。最新四圖已逐張檢視，原v1四圖也保留；其他診斷程序圖保留但不統稱逐張看過。軟體Vulkan llvmpipe不通過硬體停頓門檻，不當作冷快取或效能改善。

原工具明示生命99999、長無敵、虛擬手把及自動跳過；新輪沒有走正式前提，圖中目標仍序章。這是正式Level與預載管線，不冒充自然整章、全UI／角色接點、人手實玩或實體GPU。原硬體冷啟與使用者親手玩條件保持。HUNTDOWN與The Final Station官方研究原圖／URL／SHA收zip，只作畫面層級參考，不推論預載演算法。先讀User-guide與原生命週期研究；使用Godot背景載入規約，不回到RD背景ResourceLoader。

HUD起因7358項／1暖檔順序失敗原log保留，該輪缺失敗當刻計數；本次已證實的丟標記缺口不逕稱唯一根因。7a完整CI96,007／0／0、550秒原job也保留。

![HUNTDOWN官方參考，原權利屬Easy Trigger Games](../../images/BG-50-budget-ref-huntdown.jpg)
![The Final Station官方參考，原權利屬Do My Best Games](../../images/BG-50-budget-ref-finalstation.jpg)

原檔{packet['entries']}項、{packet['bytes']:,}bytes，zip SHA `{packet['sha256']}`，逐項解出核對完成。
''')
p=Path('pm/Nest-Egg-BG/[BG-50]修正進區後預載貼圖造成的戰鬥停頓.md');s=p.read_text();assert '# Commit-2' not in s
s+=f'''

# Commit-2

## 內文

貼圖已由背景讀完，若本格因時間預算延後，原本可能丟掉完成紀錄、無故等滿三秒。現在延後會保留已完成狀態，下格可以接著載；原每格一張、時間預算、備援及快取上限保持。

先讀User-guide與原量測研究，採真讀檔／真競爭負控制。兩輪不同失敗與首次退出留存都保留，不補造缺少的根因狀態。[設計與參照](../../design/20-campaign-experience/PREFETCH_BUDGET_READINESS.md)、[全部成功／失敗與原圖](attachments/BG-50-budget-readiness/README.md)。

### 測試結果

| 項目 | 結果 |
|---|---|
| 真讀檔／真鎖競爭，原2ms預算 | 修前5／2失敗，修後5／0 |
| 原三組前置流程＋5項 | 修前2368／2，修後2368／0；原斷言／輸入／等待保持 |
| 前兩輪原50組 | 55,025／1爆炸效能、55,025／2通訊守門；原暖檔檢查均通過 |
| 整合後原50組，基準{r['base'][:8]} | {summary} |
| 正式街道／倉庫原生 | 最後0引擎ERROR／0退出洩漏診斷，最新四圖逐張檢視；首次退出留存未定位，原log保留 |

軟體GPU整體幀時間不達硬體門檻，原冷啟與親手實玩條件維持。

### 本作原生圖

![街道真關卡與持續預載](images/BG-50-budget-street.png)
![倉庫真跑跳射擊；原工具的新輪目標仍序章](images/BG-50-budget-warehouse.png)
''';p.write_text(s)
p=Path('pm/user_guide.md');p.write_text('2026-10-23（BG-50）：因本格預算延後載入，不能先丟背景已讀完的標記。真競爭5／2→5／0，原三組2368／2→2368／0；[兩輪回歸失敗、整合結果、退出診斷與正式場景原圖](Nest-Egg-BG/attachments/BG-50-budget-readiness/README.md)。首次原生退出留存尚未定位；最後成功不抹除失敗。軟體GPU與安排路線不代勾硬體冷啟或親手實玩。\n\n'+p.read_text())
print(summary)
