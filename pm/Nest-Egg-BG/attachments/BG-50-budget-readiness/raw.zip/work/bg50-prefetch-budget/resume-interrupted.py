from pathlib import Path
import os,json,time,subprocess,hashlib,shutil
w=Path('work/bg50-prefetch-budget');other=Path('../person/work/st9-person-completion/native-receipt.json');deadline=time.monotonic()+1200
while True:
 rows=json.loads(other.read_text()) if other.exists() else []
 if len(rows)==10:break
 assert time.monotonic()<deadline,'native matrix did not finish'
 time.sleep(2)
assert all(x['exit_code']==0 and x['engine_errors']==0 and x['leaks']==0 for x in rows)
# No native renderer overlaps this replay. Prior interrupted shards are archived.
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
shutil.rmtree(w/'changed-shards',ignore_errors=True)
base=json.loads((w/'integration-base.json').read_text())['base'];cmd=['tools/run_tests_changed.sh',base];env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='2',LOG_DIR=str((w/'changed-shards').resolve()))
(w/'changed-receipt.json').write_text(json.dumps({'base':base,'command':cmd,'status':'running','exit_code':None,'shards':2},indent=2));cpu={'before':Path('/sys/fs/cgroup/cpu.stat').read_text(),'cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text()};start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
(w/'changed-receipt.json').write_text(json.dumps({'base':base,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'shards':2},indent=2));cpu['after']=Path('/sys/fs/cgroup/cpu.stat').read_text();(w/'integration-resource-envelope.json').write_text(json.dumps(cpu,indent=2))
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
assert r.returncode==0
print('BG50_INTEGRATED_PASS',flush=True)
