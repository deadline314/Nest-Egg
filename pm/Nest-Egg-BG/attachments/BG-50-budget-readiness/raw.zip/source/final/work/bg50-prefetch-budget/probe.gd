extends Node
var failures:=0
var checks:=0
func _ready()->void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	_run.call_deferred()
func _check(value:bool,label:String)->void:
	checks+=1
	if not value:
		failures+=1
	print("BUDGET_CHECK ",value," ",label)
func _run()->void:
	AssetPrefetch.clear()
	AssetPrefetch._strategy=AssetPrefetch.STRATEGY_MAIN_THREAD_RD_472
	AssetPrefetch._warm_override=1
	var path:="res://art/weapons/pistol.png"
	AssetPrefetch.request(PackedStringArray([path]))
	AssetPrefetch._install_pump()
	AssetPrefetch._pump.set_process(false)
	AssetPrefetch._warm_schedule()
	while not WorkerThreadPool.is_task_completed(AssetPrefetch._warm_task):
		await get_tree().process_frame
	AssetPrefetch._warm_join()
	_check(AssetPrefetch._warm_ready.has(path),"real worker read the actual imported pistol texture")
	var before:=AssetPrefetch.stats()
	var ready:=Semaphore.new()
	var mutex:=AssetPrefetch._warm_mutex
	var task:=WorkerThreadPool.add_task(func()->void:
		mutex.lock()
		ready.post()
		OS.delay_msec(20)
		mutex.unlock())
	ready.wait()
	var start:=Time.get_ticks_usec()
	AssetPrefetch._poll_main_thread()
	var duration:=Time.get_ticks_usec()-start
	WorkerThreadPool.wait_for_task_completion(task)
	print("BUDGET_DEFER ",JSON.stringify({"duration_us":duration,"before":before,"after":AssetPrefetch.stats(),"ready":AssetPrefetch._warm_ready.has(path),"sent":AssetPrefetch._warm_sent,"queued":AssetPrefetch._queued}))
	_check(duration>=AssetPrefetch.MAIN_SOFT_BUDGET_US and AssetPrefetch.stats().main_load_total==before.main_load_total,"actual mutex contention defers loading at the unchanged budget")
	_check(AssetPrefetch._warm_ready.has(path),"budget deferral retains the actual completed read proof")
	await get_tree().process_frame
	AssetPrefetch._poll_main_thread()
	_check(AssetPrefetch.stats().cached==1 and AssetPrefetch.stats().main_load_total==before.main_load_total+1,"next frame loads the already warm texture without waiting three seconds")
	_check(AssetPrefetch.stats().warm_timeouts_total==before.warm_timeouts_total,"a completed read never becomes a false timeout")
	AssetPrefetch.clear()
	AssetPrefetch._warm_override=-1
	AssetPrefetch._shutdown()
	print("checks: %d, failures: %d"%[checks,failures])
	get_tree().quit(1 if failures else 0)
