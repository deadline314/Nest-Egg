extends "res://tools/frame_time_probe.gd"
const Capture := preload("res://tools/viewport_capture.gd")
var _shots := {}
func _ready()->void:
	add_child(LightKit.create_environment())
	super._ready()
func _drive(level:Level,seconds:float,right_edge:float)->Dictionary:
	var label:=String(level.data.id)+("-start" if not _shots.has(level.data.id) else "-running")
	_shots[level.data.id]=true
	await RenderingServer.frame_post_draw
	var err:=Capture.image(get_viewport()).save_png(_out.path_join(label+".png"))
	print("BG50_NATIVE_CAPTURE ",label," error=",err," prefetch=",JSON.stringify(AssetPrefetch.stats()))
	return await super._drive(level,seconds,right_edge)
