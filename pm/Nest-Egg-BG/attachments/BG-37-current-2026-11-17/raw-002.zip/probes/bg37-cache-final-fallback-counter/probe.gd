extends Node
func _ready() -> void:
    var before := load("res://work/bg37-cache-final-fallback-counter/before.gd") as Script
    var holder := Node2D.new()
    add_child(holder)
    for id: StringName in [&"training_range__steel_target", &"training_range__striker_arm"]:
        var prop := PropLibrary.find(id, TrainingArt.DEFAULT_PACK)
        var path := prop.texture
        var count := holder.get_child_count()
        prop.texture = "res://art/environment/test_missing_prop_training_counter.png"
        var kind := "target" if id == &"training_range__steel_target" else "trainer"
        var old: Node2D = before.build(holder, kind)
        assert(old != null)
        old.free()
        var fixed := TrainingArt.build(holder, kind)
        prop.texture = path
        assert(fixed == null and holder.get_child_count() == count)
        print("FALLBACK_COUNTER ", JSON.stringify({"kind": kind, "old_partial_art": true, "current_original_drawing": fixed == null, "children_held": holder.get_child_count() == count}))
    holder.free()
    get_tree().quit()
