extends Node
func _ready() -> void:
    _run.call_deferred()
func _run() -> void:
    var out := ""
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--out="): out = arg.trim_prefix("--out=")
    assert(out.is_absolute_path())
    add_child(LightKit.create_environment())
    GameState.start_new_run(GameState.difficulties[1])
    var camera := Camera2D.new()
    camera.position = Vector2(0, -30)
    camera.zoom = Vector2.ONE * 3
    add_child(camera)
    for name: String in ["body", "arm"]:
        var id := &"training_range__steel_target" if name == "body" else &"training_range__striker_arm"
        var prop := PropLibrary.find(id, TrainingArt.DEFAULT_PACK)
        var original := prop.texture
        prop.texture = "res://art/environment/test_missing_prop_training_%s.png" % name
        RigLibrary.texture(prop.texture)
        var station := TrainingStation.new()
        station.configure(load("res://data/props/ch1_training_%s.tres" % ("target" if name == "body" else "trainer")).duplicate())
        station.data.requires_flag = &""
        add_child(station)
        prop.texture = original
        station.set_physics_process(false)
        assert(station._art == null and station.get_node_or_null("TrainingArt") == null)
        assert(station._prompt != null and (name == "arm" or station._hurtbox != null))
        for i in 6: await get_tree().process_frame
        await RenderingServer.frame_post_draw
        var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
        assert(image.save_png(out.path_join(name + ".png")) == OK)
        print("MISSING_TEXTURE ", JSON.stringify({"case": name, "original_drawing": station._art == null, "prompt_retained": station._prompt != null, "has_target_hurtbox": station._hurtbox != null}))
        station.queue_free()
        for i in 3: await get_tree().process_frame
    get_tree().quit()
