from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('D:/NestEggVerification/ne218-baseline-20261117')
base = Path('D:/NestEggVerification/evidence-20261117/bg37-release-final')
while not (base / 'native/source-held.json').is_file(): time.sleep(2)
assert json.loads((base / 'native/source-held.json').read_text())['source_held']
original = (root / 'tools/training_art_probe.gd').read_bytes()
driver = Path('work/run-bg37-lamp-guard-20261117.py').read_text()
driver = driver.replace("bg37-lamp-guard", "bg37-release-final/lamp-guard", 1)
driver = driver.replace("work/bg37-lamp-guard", "work/bg37-release-final-lamp-guard")
driver = driver.replace("out.mkdir(exist_ok=False)", "out.mkdir(parents=True, exist_ok=False)", 1)
driver = driver.replace("original = (root / 'tools/training_art_probe.gd').read_text()", "original = (root / 'tools/training_art_probe.gd').read_text()\noriginal = original.replace('var warn := await _capture(\"%s-warn\" % label)', 'var warn := await _capture(\"%s-warn\" % label)\\n\\t\\tprint(\"ARM_CAPTURE \", JSON.stringify({\"phase\": \"warn\", \"left\": station._art._arms[0].rotation, \"right\": station._art._arms[1].rotation}))')\noriginal = original.replace('await _capture(\"%s-strike\" % label)', 'await _capture(\"%s-strike\" % label)\\n\\t\\tprint(\"ARM_CAPTURE \", JSON.stringify({\"phase\": \"strike\", \"left\": station._art._arms[0].rotation, \"right\": station._art._arms[1].rotation}))')")
Path('work/run-bg37-release-final-lamp-guard-20261117.py').write_text(driver, encoding='utf8')
subprocess.run(['D:/ComfyUI/.venv-rocm/Scripts/python.exe', '-X', 'utf8', 'work/run-bg37-release-final-lamp-guard-20261117.py'], check=True)
out = base / 'empty-roi'
out.mkdir(exist_ok=False)
fixture = root / 'work/bg37-release-final-empty-roi'
fixture.mkdir(exist_ok=False)
s = original.decode('utf8')
start = s.index('func _screen_rect(')
end = s.index('\n\nfunc _lamp_white', start)
s = s[:start] + 'func _screen_rect(_world: Rect2, _image: Image) -> Rect2i:\n\treturn Rect2i()' + s[end:]
(fixture / 'probe.gd').write_text(s, encoding='utf8', newline='\n')
(fixture / 'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg37-release-final-empty-roi/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n', encoding='utf8')
env = os.environ.copy()
for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']: env[key] = str(out / 'private-profile' / key)
command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '1280x720', '--quit-after', '10000', 'res://work/bg37-release-final-empty-roi/probe.tscn', '--', '--out=' + str(out), '--tag=empty', '--quality=low']
with (out / 'raw.log').open('wb') as log: process = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
raw = (out / 'raw.log').read_bytes()
record = {'command': command, 'exit': process.returncode, 'specific_error': '狀態燈不在截圖內'.encode('utf8') in raw, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'source_held': original == (root / 'tools/training_art_probe.gd').read_bytes()}
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
print(record, flush=True)
assert process.returncode == 1 and record['specific_error'] and record['script_errors'] == 0 and record['source_held']
