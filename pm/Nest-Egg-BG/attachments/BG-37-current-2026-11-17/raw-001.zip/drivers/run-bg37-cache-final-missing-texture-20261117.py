from pathlib import Path
import json
import os
import subprocess

root = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg37-cache-final/missing-texture')
out.mkdir(exist_ok=False)
private = root / 'work/bg37-cache-final-missing-texture'
private.mkdir(exist_ok=False)
(private / 'probe.gd').write_text('''extends Node
func _ready() -> void:
    _run.call_deferred()
func _run() -> void:
    var out := ""
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--out="): out = arg.trim_prefix("--out=")
    assert(out.is_absolute_path())
    add_child(LightKit.create_environment())
    GameState.start_new_run(GameState.difficulties[1])
    var camera := Camera2D.new()
    camera.position = Vector2(0, -30)
    camera.zoom = Vector2.ONE * 3
    add_child(camera)
    for name: String in ["body", "arm"]:
        var id := &"training_range__steel_target" if name == "body" else &"training_range__striker_arm"
        var prop := PropLibrary.find(id, TrainingArt.DEFAULT_PACK)
        var original := prop.texture
        prop.texture = "res://art/environment/test_missing_prop_training_%s.png" % name
        RigLibrary.texture(prop.texture)
        var station := TrainingStation.new()
        station.configure(load("res://data/props/ch1_training_%s.tres" % ("target" if name == "body" else "trainer")).duplicate())
        station.data.requires_flag = &""
        add_child(station)
        prop.texture = original
        station.set_physics_process(false)
        assert(station._art == null and station.get_node_or_null("TrainingArt") == null)
        assert(station._prompt != null and (name == "arm" or station._hurtbox != null))
        for i in 6: await get_tree().process_frame
        await RenderingServer.frame_post_draw
        var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
        assert(image.save_png(out.path_join(name + ".png")) == OK)
        print("MISSING_TEXTURE ", JSON.stringify({"case": name, "original_drawing": station._art == null, "prompt_retained": station._prompt != null, "has_target_hurtbox": station._hurtbox != null}))
        station.queue_free()
        for i in 3: await get_tree().process_frame
    get_tree().quit()
''', encoding='utf8', newline='\n')
(private / 'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg37-cache-final-missing-texture/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n', encoding='utf8')
env = os.environ.copy()
for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']: env[key] = str(out / 'private-profile' / key)
command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '1280x720', '--quit-after', '1500', 'res://work/bg37-cache-final-missing-texture/probe.tscn', '--', '--out=' + str(out)]
with (out / 'raw.log').open('wb') as log: result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
raw = (out / 'raw.log').read_bytes()
rows = [json.loads(line.removeprefix(b'MISSING_TEXTURE ')) for line in raw.splitlines() if line.startswith(b'MISSING_TEXTURE ')]
record = {'command': command, 'exit': result.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'cases': rows, 'specific_paths_reported': all(('test_missing_prop_training_' + n + '.png').encode() in raw for n in ['body','arm']), 'scope': 'Arranged stations loaded from actual training data, missing texture paths injected in memory and restored, original drawing and input components checked. Not human gameplay.'}
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
print(record, flush=True)
assert result.returncode == record['script_errors'] == 0 and len(rows) == 2 and record['specific_paths_reported']
