from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg37-release-final/native')
out.mkdir(parents=True,exist_ok=False)
paths = [p for p in subprocess.check_output(['git', 'ls-files', '-z', 'autoload', 'core', 'game', 'data', 'ui', 'art', 'tools', 'project.godot'], cwd=root).decode().split('\0') if p and (root / p).is_file()]
def snapshot():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
runs = []
for name, scene, arguments in [('art-low', 'training_art_probe', ['--quality=low', '--tag=low']), ('art-high', 'training_art_probe', ['--quality=high', '--tag=high']), ('actual-input', 'prologue_play_probe', [])]:
    folder = out / name
    folder.mkdir()
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']:
        env[key] = str(folder / 'private-profile' / key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '1280x720', '--quit-after', '30000', 'res://tools/' + scene + '.tscn', '--', '--out=' + str(folder), *arguments]
    if name == 'actual-input': command.append('--save-dir=' + str(folder / 'private-profile' / 'save'))
    start = time.monotonic()
    with (folder / 'raw.log').open('wb') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (folder / 'raw.log').read_bytes()
    row = {'name': name, 'command': command, 'exit': result.returncode, 'elapsed_s': time.monotonic() - start, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'images': len(list(folder.glob('*.png'))), 'scope': 'Original tools, physical native GPU, Dummy audio. Art probe directly arranges visual states; actual-input case separately uses original Main movement/shooting/block/dash/interact script, not human play.'}
    runs.append(row)
    (out / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
    row['unexpected_errors'] = [line.decode('utf8',errors='replace') for line in raw.splitlines() if line.startswith(b'ERROR:') and b'resources still in use at exit' not in line]
    row['exit_diagnostics'] = [line.decode('utf8',errors='replace') for line in raw.splitlines() if b'resources still in use at exit' in line or b'were leaked at exit' in line]
    (out / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
    assert result.returncode == row['script_errors'] == 0 and row['images'] > 0 and not row['unexpected_errors']
    if name.startswith('art-'):
        report = json.loads((folder / (name[4:] + '-report.json')).read_text())
        assert len(report['stations']) == 5 and all(r['has_art'] for r in report['stations']), report
    print(name, result.returncode, row['images'], flush=True)
after = snapshot()
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
(out / 'source-held.json').write_text(json.dumps({'source_held': before == after, 'count': len(before), 'baseline': '361de2f78bff7dc47dec4df8524d03c8e0c07b95'}, indent=2) + '\n')
assert before == after
