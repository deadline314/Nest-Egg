from pathlib import Path
import json
import os
import subprocess

root = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg37-cache-final/fallback-counter')
out.mkdir(exist_ok=False)
private = root / 'work/bg37-cache-final-fallback-counter'
private.mkdir(exist_ok=False)
original = Path('D:/NestEggVerification/evidence-20261117/bg37-final/source-before-fallback/game/props/training_art.gd').read_text()
assert original.startswith('class_name TrainingArt\n')
(private / 'before.gd').write_text(original.removeprefix('class_name TrainingArt\n').replace(' -> TrainingArt:', ':').replace('var art := TrainingArt.new()', 'var art: Variant = (load("res://work/bg37-cache-final-fallback-counter/before.gd") as Script).new()'), encoding='utf8', newline='\n')
(private / 'probe.gd').write_text('''extends Node
func _ready() -> void:
    var before := load("res://work/bg37-cache-final-fallback-counter/before.gd") as Script
    var holder := Node2D.new()
    add_child(holder)
    for id: StringName in [&"training_range__steel_target", &"training_range__striker_arm"]:
        var prop := PropLibrary.find(id, TrainingArt.DEFAULT_PACK)
        var path := prop.texture
        var count := holder.get_child_count()
        prop.texture = "res://art/environment/test_missing_prop_training_counter.png"
        var kind := "target" if id == &"training_range__steel_target" else "trainer"
        var old: Node2D = before.build(holder, kind)
        assert(old != null)
        old.free()
        var fixed := TrainingArt.build(holder, kind)
        prop.texture = path
        assert(fixed == null and holder.get_child_count() == count)
        print("FALLBACK_COUNTER ", JSON.stringify({"kind": kind, "old_partial_art": true, "current_original_drawing": fixed == null, "children_held": holder.get_child_count() == count}))
    holder.free()
    get_tree().quit()
''', encoding='utf8', newline='\n')
(private / 'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg37-cache-final-fallback-counter/probe.gd" id="1"]\n[node name="Probe" type="Node"]\nscript = ExtResource("1")\n', encoding='utf8')
env = os.environ.copy()
for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']: env[key] = str(out / 'private-profile' / key)
command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--headless', '--audio-driver', 'Dummy', '--quit-after', '1000', 'res://work/bg37-cache-final-fallback-counter/probe.tscn']
with (out / 'raw.log').open('wb') as log: result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
raw = (out / 'raw.log').read_bytes()
rows = [json.loads(line.removeprefix(b'FALLBACK_COUNTER ')) for line in raw.splitlines() if line.startswith(b'FALLBACK_COUNTER ')]
record = {'command': command, 'exit': result.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'cases': rows, 'scope': 'Original builder and instance methods compared to current class under identical in-memory missing-path injection. Historical class name and return annotation removed; self-construction points to the copied historical script to avoid global class collision. Headless logical control, not image comparison.'}
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
print(record, flush=True)
assert result.returncode == record['script_errors'] == 0 and len(rows) == 2
