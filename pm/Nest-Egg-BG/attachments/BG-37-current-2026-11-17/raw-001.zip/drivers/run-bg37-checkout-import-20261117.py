from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('D:/NestEggVerification/ne218-baseline-20261117')
dependency = Path('D:/NestEggVerification/evidence-20261117/bg37-cache-final/empty-roi/run.json')
while not dependency.is_file(): time.sleep(2)
assert json.loads(dependency.read_text())['exit'] == 1
out = Path('D:/NestEggVerification/evidence-20261117/bg37-release-final/import')
out.mkdir(parents=True, exist_ok=False)
paths = [p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot'], cwd=root).decode('utf8').split('\0') if p and (root/p).is_file()]
def snapshot(): return {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
original_imports = {p: (root/p).read_bytes() for p in paths if p.endswith('.import')}
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env = os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']: env[key] = str(out/'private-profile'/key)
command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe','C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--headless','--editor','--import','--audio-driver','Dummy']
with (out/'raw.log').open('wb') as log: process = subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
after_engine = snapshot()
(out/'source-after-engine.json').write_text(json.dumps(after_engine,indent=2)+'\n')
normalized = []
for p, raw in original_imports.items():
    current = (root/p).read_bytes()
    if current != raw:
        assert current.replace(b'\r\n',b'\n') == raw.replace(b'\r\n',b'\n'),p
        normalized.append(p)
        backup = out/'engine-sidecars'/p
        backup.parent.mkdir(parents=True,exist_ok=True)
        backup.write_bytes(current)
        (root/p).write_bytes(raw)
after = snapshot()
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
raw = (out/'raw.log').read_bytes()
record = {'command':command,'exit':process.returncode,'script_errors':raw.count(b'SCRIPT ERROR:'),'source_held':before==after,'newline_only_restored':normalized,'generated_trim_caches':all((root/'.godot/imported'/p).is_file() for p in ['hip_trim.png-66239cf4a6d9e4ecb417741a1d1b3c9a.ctex','hip_trim_n.png-4b17d0e1e7c2d2134f073c758da8b240.ctex'])}
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print(record,flush=True)
assert process.returncode == record['script_errors'] == 0 and record['source_held'] and record['generated_trim_caches']
