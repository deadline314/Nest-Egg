from pathlib import Path
import hashlib
import json
import os
import subprocess

out = Path('D:/NestEggVerification/evidence-20261117/bg37-cache-final/root-import')
out.mkdir(exist_ok=False)
paths = [p for p in subprocess.check_output(['git','ls-files','-z','autoload','core','game','data','ui','art','tools','tests','project.godot']).decode('utf8').split('\0') if p and Path(p).is_file()]
def snapshot(): return {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
before = snapshot()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
env = os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME']: env[key] = str(out / 'private-profile' / key)
command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe','tools/comfyui/gpu_lock.py','--','C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(Path.cwd()),'--headless','--editor','--import','--audio-driver','Dummy']
with (out / 'raw.log').open('wb') as log: result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
after = snapshot()
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
raw = (out / 'raw.log').read_bytes()
record = {'command': command, 'exit': result.returncode, 'source_held': before == after, 'changed_paths': [p for p in paths if before[p] != after[p]], 'script_errors': raw.count(b'SCRIPT ERROR:')}
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf8')
print(record, flush=True)
assert result.returncode == record['script_errors'] == 0 and record['source_held']
