from pathlib import Path
import time
while not Path("D:/NestEggVerification/evidence-20261117/bg37-release-final/empty-roi/run.json").is_file(): time.sleep(2)
import hashlib
import json
from PIL import Image, ImageDraw

base = Path('D:/NestEggVerification/evidence-20261117/bg37-release-final/native')
out = base / 'review'
out.mkdir(exist_ok=True)
records = []
for quality in ['low', 'high']:
    images = sorted((base / ('art-' + quality)).glob('*.png'))
    assert len(images) == 36
    for page in range(6):
        sheet = Image.new('RGB', (1800, 928), '#333333')
        draw = ImageDraw.Draw(sheet)
        for i, path in enumerate(images[page * 6:(page + 1) * 6]):
            image = Image.open(path).convert('RGB')
            assert image.size == (1280,720)
            crop = (340,120,940,560)
            x,y = i % 3 * 600, i // 3 * 464
            sheet.paste(image.crop(crop), (x,y + 24))
            draw.text((x+4,y+4), path.name, fill='white')
            records.append({'file':str(path.relative_to(base)), 'sha256':hashlib.sha256(path.read_bytes()).hexdigest(), 'crop':crop})
        sheet.save(out / ('%s-%02d.png' % (quality,page+1)))
(out/'inputs.json').write_text(json.dumps(records,indent=2)+'\n')
guard = Path('D:/NestEggVerification/evidence-20261117/bg37-release-final/lamp-guard')
runs = json.loads((guard/'runs.json').read_text())
counts = []
def verify(row, path):
    x,y,w,h = row['rect']
    assert w>0 and h>0 and w*h==row['total']
    cx,cy = row['actual_center'];radius=row['physical_radius_px']
    assert x<=cx-radius and cx+radius<=x+w and y<=cy-radius and cy+radius<=y+h
    with Image.open(path) as image:
        assert list(image.size)==row['image_size']==[1280,720]
        assert x>=0 and y>=0 and x+w<=image.width and y+h<=image.height
        rgb=image.convert('RGB').crop((x,y,x+w,y+h))
        pixels=[rgb.getpixel((px,py)) for py in range(h) for px in range(w)]
    white=sum(all(c/255>row['threshold'] for c in pixel) for pixel in pixels)
    assert len(pixels)==row['total'] and white==row['white']==0
    return white
for run in runs:
    assert run['exit']==run['script_errors']==0 and len(run['measurements'])==16 and run['probe_source_held']
    for row in run['measurements']:
        counts.append(verify(row,guard/run['quality']/row['file']))
invalid=json.loads(json.dumps(runs[0]['measurements'][0]));invalid['rect']=[0,0,0,0];invalid['total']=0
rejected=False
try: verify(invalid,guard/runs[0]['quality']/invalid['file'])
except AssertionError: rejected=True
assert rejected and len(counts)==32
(guard/'independent-reader.json').write_text(json.dumps({'measurements':len(counts),'white_pixels':sum(counts),'empty_roi_rejected':rejected,'scope':'All physical lamps enclosed in positive-area rectangles containing zero white pixels; zero is an upper bound for lamp pixels, not a diluted nonzero ratio. Body-luma diagnostic includes background and is not an exact silhouette measurement.'},indent=2)+'\n')
print('BG37_REVIEW',len(records),'LAMP_RECALCULATIONS',len(counts),'EMPTY_ROI_REJECTED',rejected)
