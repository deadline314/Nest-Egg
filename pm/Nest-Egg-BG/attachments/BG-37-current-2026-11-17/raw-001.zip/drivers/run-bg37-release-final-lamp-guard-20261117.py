from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = Path('D:/NestEggVerification/evidence-20261117/bg37-release-final/lamp-guard')
out.mkdir(parents=True, exist_ok=False)
original = (root / 'tools/training_art_probe.gd').read_text()
original = original.replace('var warn := await _capture("%s-warn" % label)', 'var warn := await _capture("%s-warn" % label)\n\t\tprint("ARM_CAPTURE ", JSON.stringify({"phase": "warn", "left": station._art._arms[0].rotation, "right": station._art._arms[1].rotation}))')
original = original.replace('await _capture("%s-strike" % label)', 'await _capture("%s-strike" % label)\n\t\tprint("ARM_CAPTURE ", JSON.stringify({"phase": "strike", "left": station._art._arms[0].rotation, "right": station._art._arms[1].rotation}))')
source = original.replace('var _out := ""', 'var _last_capture := ""\nvar _out := ""', 1)
source = source.replace('func _capture(file_name: String) -> Image:\n', 'func _capture(file_name: String) -> Image:\n\t_last_capture = file_name\n', 1)
anchor = '\treturn float(white) / float(maxi(total, 1))'
assert source.count(anchor) == 1
source = source.replace(anchor, '''	var to_screen := get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	var actual_center := to_screen * (station.global_position + station._art.lamp_at.rotated(station._art.rotation))
	var radius := 5.0 * absf(to_screen.get_scale().x)
	assert(total > 0 and rect.has_point(Vector2i(actual_center)))
	assert(is_zero_approx(station._art.rotation))
	assert(Rect2(rect).encloses(Rect2(actual_center - Vector2.ONE * radius, Vector2.ONE * radius * 2.0)))
	print("LAMP_READBACK ", JSON.stringify({"file": "%s-%s.png" % [_tag, _last_capture], "station": str(station.data.id), "rect": [rect.position.x, rect.position.y, rect.size.x, rect.size.y], "actual_center": [actual_center.x, actual_center.y], "physical_radius_px": radius, "white": white, "total": total, "threshold": WHITE, "image_size": [image.get_width(), image.get_height()]}))
''' + anchor)
private = root / 'work/bg37-release-final-lamp-guard'
private.mkdir(exist_ok=False)
(private / '.gdignore').write_bytes(b'')
(private / 'probe.gd').write_text(source, encoding='utf8', newline='\n')
(private / 'probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/bg37-release-final-lamp-guard/probe.gd" id="1"]\n[node name="LampGuard" type="Node"]\nscript = ExtResource("1")\n')
before = hashlib.sha256((private / 'probe.gd').read_bytes()).hexdigest()
runs = []
for quality in ['low', 'high']:
    folder = out / quality
    folder.mkdir()
    env = os.environ.copy()
    for key in ['APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME']: env[key] = str(folder / 'private-profile' / key)
    command = ['D:/ComfyUI/.venv-rocm/Scripts/python.exe', 'C:/Users/stanl/Github/Nest-Egg/tools/comfyui/gpu_lock.py', '--', 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(root), '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy', '--resolution', '1280x720', '--quit-after', '10000', 'res://work/bg37-release-final-lamp-guard/probe.tscn', '--', '--out=' + str(folder), '--tag=' + quality, '--quality=' + quality]
    with (folder / 'raw.log').open('wb') as log: result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    raw = (folder / 'raw.log').read_bytes()
    rows = [json.loads(line.removeprefix(b'LAMP_READBACK ')) for line in raw.splitlines() if line.startswith(b'LAMP_READBACK ')]
    row = {'quality': quality, 'command': command, 'exit': result.returncode, 'script_errors': raw.count(b'SCRIPT ERROR:'), 'measurements': rows, 'probe_source_held': before == hashlib.sha256((private / 'probe.gd').read_bytes()).hexdigest()}
    runs.append(row)
    (out / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
    assert result.returncode == row['script_errors'] == 0 and row['probe_source_held'] and len(rows) == 16
    print('LAMP_GUARD', quality, len(rows), flush=True)
