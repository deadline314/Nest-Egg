extends "res://tools/harbor_readability_probe.gd"
## Fixed unoccluded harbor fixture only. A rendered opaque head subset supplies
## a lower bound on visible enemy pixels; full body rectangle white is an upper
## bound on its white pixels. Their quotient is conservative, not an exact ratio.

func _observe_exposure(reference: WeakRef, level_id: String, enemy_path: String) -> void:
	for sample in 3:
		await get_tree().create_timer(1.1).timeout
		var enemy := reference.get_ref() as Enemy
		if not is_instance_valid(enemy):
			return
		await RenderingServer.frame_post_draw
		var probe := ContrastProbe.capture(get_viewport())
		var world_bounds := probe._body_box(enemy.global_position, false)
		world_bounds = world_bounds.merge(enemy.rig.visual_bounds())
		var weapon := enemy.rig._weapon_sprite
		if weapon != null and weapon.texture != null and weapon.is_visible_in_tree():
			world_bounds = world_bounds.merge(weapon.global_transform * weapon.get_rect())
		var rect := probe._screen_rect(world_bounds.grow(1.0))
		var white := 0
		for y in range(rect.position.y, rect.end.y):
			for x in range(rect.position.x, rect.end.x):
				var color := probe._image.get_pixel(x, y)
				if color.r > 0.92 and color.g > 0.92 and color.b > 0.92:
					white += 1
		var before_mode := enemy.process_mode
		enemy.process_mode = Node.PROCESS_MODE_DISABLED
		var mask := await _opaque_head(enemy, probe, rect, sample)
		enemy.process_mode = before_mode
		var count: int = mask.get("opaque_head_pixels", 0)
		var upper: Variant = float(white) / count if count > 0 else null
		var valid: bool = count > 0 and bool(mask.get("source_held", false))
		if not valid or float(upper if upper != null else 1.0) > 0.02:
			_failed = true
		var raw_path := "sample%02d-hdr.bin" % sample
		var raw := FileAccess.open(_out_dir.path_join(raw_path), FileAccess.WRITE)
		raw.store_buffer(probe._image.get_data())
		raw.close()
		preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(_out_dir.path_join("sample%02d-scene.png" % sample))
		_exposure.append({"level": level_id, "enemy": enemy_path, "sample": sample, "quality": Settings.get_light_quality(),
			"screen_rect": [rect.position.x, rect.position.y, rect.size.x, rect.size.y],
			"white_pixels_including_background": white, "mask": mask, "valid": valid,
			"enemy_white_ratio_upper_bound": upper, "enemy_only_ratio": null,
			"raw_hdr": {"file": raw_path, "format": probe._image.get_format(), "width": probe._image.get_width(), "height": probe._image.get_height()}})
		var file := FileAccess.open(_out_dir.path_join("enemy-exposure.json"), FileAccess.WRITE)
		file.store_string(JSON.stringify({"encoding": "raw linear HDR", "fixture": "stationary, unoccluded sweeper at ch1_street harbor; rendered opaque head lower bound only", "observations": _exposure}, "  ") + "\n")
		file.close()
		print("HEAD_BOUND sample=", sample, " white=", white, " opaque_head=", count, " upper=", upper, " valid=", valid)

func _opaque_head(enemy: Enemy, probe: ContrastProbe, rect: Rect2i, sample: int) -> Dictionary:
	var head: CanvasItem
	for part: CanvasItem in enemy.rig._parts:
		if part.name == &"head" and part.is_visible_in_tree():
			head = part
	if head == null or not (head is Sprite2D or head is Polygon2D):
		return {"error": "no visible head drawable"}
	if head is Polygon2D and head.get_bone_count() > 0:
		return {"error": "GPU-skinned heads require a full skeleton copy; refused"}
	# No script or gameplay clone: copy the actual already-deformed native drawable.
	var before := head.global_transform
	var viewport := SubViewport.new()
	viewport.size = probe._image.get_size()
	viewport.world_2d = World2D.new()
	viewport.transparent_bg = true
	viewport.disable_3d = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.canvas_transform = get_viewport().get_final_transform() * get_viewport().get_canvas_transform()
	add_child(viewport)
	var copy := head.duplicate(0) as Node2D
	copy.process_mode = Node.PROCESS_MODE_DISABLED
	viewport.add_child(copy)
	copy.global_transform = before
	if OS.get_cmdline_user_args().has("--blank-mask"):
		copy.visible = false
	for i in 2:
		await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var pixels := viewport.get_texture().get_image()
	pixels.save_png(_out_dir.path_join("sample%02d-head-mask.png" % sample))
	var count := 0
	var outside := 0
	for y in pixels.get_height():
		for x in pixels.get_width():
			if pixels.get_pixel(x, y).a >= 0.999:
				if rect.has_point(Vector2i(x, y)):
					count += 1
				else:
					outside += 1
	var held := before == head.global_transform and copy.global_transform == before
	viewport.queue_free()
	return {"opaque_head_pixels": count, "outside_rectangle": outside, "source_held": held,
		"alpha_threshold": 0.999, "source_path": str(head.get_path()), "head_transform": [before.x.x, before.x.y, before.y.x, before.y.y, before.origin.x, before.origin.y]}
