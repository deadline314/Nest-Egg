from pathlib import Path
import subprocess,os,time,json
b=Path(__file__).parent
while not (b/'st9-result-shape-affected.exit').exists():time.sleep(2)
assert (b/'st9-result-shape-affected.exit').read_text()=='0'
env=os.environ.copy();env['NE_NATIVE_PROJECT']='fixtures';results=[]
for name,q,extra in [('bg49-head-bound-blank','low',['--blank-mask']),('bg49-head-bound-high','high',[]),('bg49-head-bound-low','low',[])]:
 r=subprocess.run(['python',str(b/'native.py'),name,'res://work/harbor_head_bound.tscn','--level=ch1_street','--spots=碼頭入口','--quality='+q,*extra],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit':r.returncode});(b/'bg49-head-bound-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if 'SCRIPT ERROR:' in (b/(name+'.log')).read_text():raise SystemExit('script error')
 if not extra and r.returncode:raise SystemExit(r.returncode)
