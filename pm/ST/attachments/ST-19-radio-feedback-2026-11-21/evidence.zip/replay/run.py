
from hashlib import sha256
from pathlib import Path
import json,os,re,subprocess,sys

base=Path(__file__).resolve().parent
game=base.parent/'ne218-baseline-20261117'
label=sys.argv[1]
mode=sys.argv[2]
out=base/label
out.mkdir()
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','TEMP','TMP','TMPDIR'):
    folder=out/key
    folder.mkdir()
    env[key]=str(folder)
paths=('data/story/ch2_heron.json','data/audio/sound_bank.json','autoload/sfx.gd','core/story_result_catalog.gd','data/story_contracts/migration-5a.json','audio/sfx/ch2_radio_static_01.ogg')
sha=lambda path:sha256(path.read_bytes()).hexdigest() if path.is_file() else None
source={path:sha(game/path) for path in paths}
argv=[sys.executable,'-B',str(game/'tools/comfyui/gpu_lock.py'),'--',
      'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(game),
      '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
      '--max-fps','60','--resolution','1280x720','--quit-after','6300',str(base/'observe.tscn'),'--',f'--out={out}',f'--mode={mode}']
if not label.startswith('stock'):
    argv.append('--expect-cue')
(out/'command.json').write_text(json.dumps({'argv':argv,'source':source},indent=2)+'\n')
with (out/'engine.log').open('wb') as log:
    proc=subprocess.run(argv,env=env,cwd=game,stdout=log,stderr=subprocess.STDOUT,timeout=165)
raw=(out/'engine.log').read_text(encoding='utf-8',errors='replace')
print(raw[-8500:],flush=True)
assert proc.returncode==0 and not re.search(r'^SCRIPT ERROR:|^ERROR:',raw,re.M),(proc.returncode,raw[-4000:])
report=json.loads((out/'result.json').read_bytes())
assert all(sha(game/path)==digest for path,digest in source.items())
assert report['failures']==0 and '9070 XT' in report['adapter']
assert len(report['cases'])==1 and len(list(out.glob('*.png')))==6

