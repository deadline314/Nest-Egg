
extends "res://tools/ch2_flow_probe.gd"

const CUE := &"ch2_radio_static"
const CLIP := "res://audio/sfx/ch2_radio_static_01.ogg"
const BAD := ["ch2_t_s02_power_wrong", "ch2_t_s02_antenna_wrong", "ch2_t_s02_speaker_wrong", "ch2_t_s02_tune_wrong"]
var _cases: Array[Dictionary] = []
var _voices: Array[Dictionary] = []
var _events: Array[String] = []
var _window_peak := 0.0
var _window_frames := 0
var _track := 0
var _bus_index := -1
var _audio_capture: AudioEffectCapture


func _run() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var expected := OS.get_cmdline_user_args().has("--expect-cue")
	_bus_index = AudioServer.get_bus_index(&"SFX")
	_check(_bus_index >= 0, "real SFX audio bus exists")
	if _bus_index >= 0:
		_audio_capture = AudioEffectCapture.new()
		AudioServer.add_bus_effect(_bus_index, _audio_capture)
	Sfx.sound_played.connect(_on_sound)
	var mode := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--mode="):
			mode = arg.trim_prefix("--mode=")
	if mode not in ["off", "save", "leave"]:
		get_tree().quit(2)
		return
	await _try_route(mode, expected)
	Sfx.sound_played.disconnect(_on_sound)
	if _bus_index >= 0:
		AudioServer.remove_bus_effect(_bus_index, AudioServer.get_bus_effect_count(_bus_index) - 1)
	var output := FileAccess.open(_out_dir.path_join("result.json"), FileAccess.WRITE)
	if output == null:
		get_tree().quit(2)
		return
	output.store_string(JSON.stringify({"audio_driver": AudioServer.get_driver_name(), "adapter":RenderingServer.get_video_adapter_name(), "failures":_failures,"cases":_cases}, "  "))
	output.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(_failures > 0))


func _try_route(mode: String, expected: bool) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip = false
	_carry_ch1_results()
	_shots = {"ch2_t_s02_power_wrong":"radio-power-" + mode,
		"ch2_t_s02_antenna_wrong":"radio-antenna-" + mode,
		"ch2_t_s02_speaker_wrong":"radio-speaker-" + mode,
		"ch2_t_s02_tune_wrong":"radio-tune-" + mode,
		"ch2_t_s02_broadcast:choice":"radio-broadcast-" + mode}
	await _enter("pawnshop")
	_level.process_mode = Node.PROCESS_MODE_PAUSABLE
	_voices.clear()
	_events.clear()
	var initial := Progression.credits
	await _talk(&"ch2_radio", ["antenna", "power", "speaker", "antenna", "power", "speaker", "edge", "middle", mode])
	await _settle(26)
	var flags := [GameState.has_flag(&"ch2_radio_repaired"), GameState.has_flag(&"sq4_broadcast_heard"), GameState.has_flag(&"sq4_clip_saved")]
	var clip := StoryItems.holds(&"ch2_radio_clip")
	var receipt := Story.outcomes.receipt_recorded(&"ch2.sq4_radio")
	var cash := Progression.credits - initial
	_check(flags == [mode != "leave", mode != "leave", mode == "save"], mode+" original flags match choice")
	_check(clip == (mode == "save"), mode+" original clip is only granted on save")
	_check(receipt == (mode != "leave") and cash == (0 if mode == "leave" else 20), mode+" original receipt and wallet match choice")
	if expected:
		_check(_events == BAD, mode+" one new cue at each original rejection")
		_check(_voices.size() == 4, mode+" four real mixer voices collected")
		for voice in _voices:
			_check(float(voice["length"]) > 0.265 and float(voice["length"]) < 0.30
				and float(voice["mix_peak"]) > 0.006 and int(voice["mix_samples"]) > 9000, mode+" original file produced a bounded mixed signal")
	else:
		_check(_events.is_empty() and _voices.is_empty(),mode+" original scenes have no radio static cue")
	await _settle(6)
	_capture("radio-result-" + mode)
	_cases.append({"mode": mode,"flags": flags,"clip":clip,"receipt":receipt,"credit_delta": cash, "events":_events.duplicate(), "voices":_voices.duplicate(true)})
	if is_instance_valid(_level):
		Story.reset_active_presentation(&"probe_cleanup")
		await _settle(3)
		_level.queue_free()
		await _settle(20)


func _on_sound(id: StringName) -> void:
	if id != CUE:
		return
	var scene := String(Story._current_cinematic)
	_events.append(scene)
	_window_peak = 0.0
	_window_frames = 0
	_track = 29
	if _audio_capture != null:
		_audio_capture.clear_buffer()
	_voice_started.call_deferred(scene)


func _voice_started(scene: String) -> void:
	# Capture the active pooled stream after play() returns.
	var found: AudioStreamPlayer
	for node in Sfx.get_children():
		if node is AudioStreamPlayer and node.playing and node.stream != null and node.stream.resource_path == CLIP:
			found = node
			break
	if found == null:
		_check(false, scene + " cue uses the imported stream")
		return
	_voices.append({"scene":scene,"path":found.stream.resource_path,"length":found.stream.get_length(),"volume":found.volume_db})


func _process(_delta: float) -> void:
	if _audio_capture == null:
		return
	var available := _audio_capture.get_frames_available()
	if available > 0:
		var frames := _audio_capture.get_buffer(available)
		if _track > 0:
			_window_frames += frames.size()
			for frame in frames:
				_window_peak = maxf(_window_peak, maxf(absf(frame.x), absf(frame.y)))
	if _track <= 0:
		return
	_track -= 1
	if _track == 0 and not _voices.is_empty():
		_voices.back()["mix_peak"] = _window_peak
		_voices.back()["mix_samples"] = _window_frames

