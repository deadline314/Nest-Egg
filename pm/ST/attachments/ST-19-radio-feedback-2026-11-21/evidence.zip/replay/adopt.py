
from pathlib import Path
from hashlib import sha256
from shutil import copyfile
import json,subprocess

root=Path.cwd()
base=Path(__file__).resolve().parent
previous=base.parent/'evidence-20261121-ne228-active-flash'
game=base.parent/'ne218-baseline-20261117'
paths=[
 'assets_src/audio/LICENSES.json','assets_src/audio/build_cache.json','assets_src/audio/pipeline.json',
 'audio/sfx/ch2_radio_static_01.ogg','audio/sfx/ch2_radio_static_01.ogg.import',
 'data/audio/slots.json','data/audio/sound_bank.json','data/audio/stage_scenes.json','data/story/ch2_heron.json',
 'tools/audio/slot_table.py','tools/story/ch2_source.py',
]
sha=lambda p:sha256(p.read_bytes()).hexdigest()
git=lambda repo,*args:subprocess.check_output(['git',*args],cwd=repo)
manifest=json.loads((previous/'published-source.json').read_bytes())
parent=json.loads((previous/'publish/result.json').read_bytes())['commit']
assert git(root,'rev-parse','HEAD').decode().strip()==git(game,'rev-parse','HEAD').decode().strip()==parent
assert all(sha(game/file)==digest for file,digest in manifest.items())
for file in paths:
    assert sha(root/file)!=manifest.get(file) and (game/file).is_file()==(file in manifest),file
for file in paths:
    copyfile(root/file,game/file)
    manifest[file]=sha(game/file)
cache=base/'import-cue/.godot/imported'
aud=list(cache.glob('ch2_radio_static_01.ogg-*'))
assert len(aud)==2
for file in aud:
    copyfile(file,game/'.godot/imported'/file.name)
assert all(sha(game/file)==digest for file,digest in manifest.items())
(base/'baseline.txt').write_text(parent+'\n')
(base/'runtime.json').write_text(json.dumps(paths,indent=2)+'\n')
(base/'source.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'{len(manifest)} verified exact files at {parent}, with the S02 feedback cue')

