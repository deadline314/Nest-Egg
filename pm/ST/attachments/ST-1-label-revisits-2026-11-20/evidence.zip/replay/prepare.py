from importlib import util
from pathlib import Path
import contextlib
import copy
import json
import sys

root=Path.cwd()
base=Path(__file__).resolve().parent
draft=base/'draft'
read=lambda p:json.loads(p.read_bytes())
story=Path('tools/story')
backend_file=root/story/'ch1_runtime_backend.py'
SCRIPT=story/'ch1_closure.py'
TABLE=story/'i18n/ch1_kasa.json'
OUT=Path('data/story/ch1_kasa.json')
old='這件我留著，主人來了才好找。'
new={
 'watch':('懷錶還在這格，送貨員回來我就拿給他喔。',
          '懐中時計はこの棚だよ。配達の人が戻ったら、すぐ渡せるからな。',
          "I keep the watch right here. If the delivery man comes back, I can hand it straight over."),
 'guitar':('那把吉他沒弦也得收好，木頭磕壞就難補了喔。',
           '弦がなくても、ギターはしまっとくよ。木を傷めたら直すのが面倒だからな。',
           "I'll keep the guitar safe, strings or no strings. The wood is a lot harder to fix."),
 'raincoat':('袖口還破著，等雨衣的主人回來再問怎麼補。',
             '袖口はまだ破れてる。持ち主が戻ったら、どう直したいか聞いてみるよ。',
             "The cuff's still torn. When the owner comes back, I'll ask how they want it mended."),
 'fare':('罐裡的船錢我另外留著，別把它算進今天的帳。',
         '缶の渡し賃は別に取ってある。今日の帳面には入れないでくれよ。',
         "I'm keeping the ferry money in the tin separate. Leave it out of today's books."),
}
def write(name,content):
    path=draft/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(content,encoding='utf-8',newline='\n')

source=(root/SCRIPT).read_text(encoding='utf-8')
for item,texts in new.items():
    start=source.index(f'        "{item}": ',source.index('    labels = {'))
    end=source.index(')),\n',start)
    source=source[:end]+'), "'+texts[0]+'"'+source[end+1:]
old_case='for name, (label, dialogue) in labels.items():'
assert source.count(old_case)==1
source=source.replace(old_case,'for name, (label, dialogue, revisit) in labels.items():')
last=f'("old_k", "{old}"))'
assert source.count(last)==1
write(SCRIPT,source.replace(last,'("old_k", revisit))'))
table=read(root/TABLE)
assert old in table
replacements={}
for zh,ja,en in new.values():
    assert zh not in table and len(zh)<=30 and min(len(en),len(ja))>10
    replacements[zh]={'ja':ja,'en':en}
table_source=(root/TABLE).read_text(encoding='utf-8')
prefix=' '+json.dumps(old,ensure_ascii=False)+': {'
assert table_source.count(prefix)==1
start=table_source.index(prefix)
end=table_source.index('\n },',start)+len('\n }')
new_block='\n'.join(json.dumps(replacements,ensure_ascii=False,indent=1).splitlines()[1:-1])
write(TABLE,table_source[:start]+new_block+table_source[end:])
expected={key:value for key,value in table.items() if key!=old}
expected.update(replacements)
assert read(draft/TABLE)==expected

sys.dont_write_bytecode=True
sys.path.insert(0,str(root/story))
spec=util.spec_from_file_location('ch1_closure',draft/SCRIPT)
module=util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
import ch1_runtime_backend as backend
backend.OUT=draft/OUT
backend.OUT.parent.mkdir(parents=True,exist_ok=True)
backend.legacy.STAGE_DIR=draft/'data/cutscene/stages'
original_table=backend.story_i18n.table_path
backend.story_i18n.table_path=lambda chapter: draft/TABLE if chapter=='ch1_kasa' else original_table(chapter)
with (base/'generator.log').open('w',encoding='utf-8') as log, contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
    assert backend.main()==0
before=read(root/OUT)
after=read(draft/OUT)
assert len(after['scenes'])==147 and len(after['quests'])==10
reset=copy.deepcopy(after)
rows={}
for item,translations in new.items():
    tag=f'ch1_t_label_{item}_revisit'
    prior=before['scenes'][tag]['steps'][1]
    final=after['scenes'][tag]['steps'][1]
    assert prior['speaker']==final['speaker']=='old_k' and prior['text']==old
    assert tuple(final[k] for k in ('text','ja','en'))==translations
    rows[tag]=[(prior[k],final[k]) for k in ('text','ja','en')]
    reset['scenes'][tag]['steps'][1]=prior
assert reset==before,'generator drift beyond four authored lines'
for file in (draft/'data/cutscene/stages').glob('*.json'):
    origin=root/'data/cutscene/stages'/file.name
    assert origin.is_file() and file.read_text(encoding='utf-8')==origin.read_text(encoding='utf-8'),file
(base/'changes.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Regenerated chapter. Only the four matched revisit lines differ across all three languages.')
