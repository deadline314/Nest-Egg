from pathlib import Path
from subprocess import run
from shutil import copyfile
import json
import os
import sys

base = Path(__file__).resolve().parent
shared = base.parent/'ne218-baseline-20261117'
root=Path.cwd()
python = Path(sys.executable)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def render(case, scene, args, fixed):
    out=base/case
    out.mkdir(exist_ok=False)
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        var = out/'profile'/key
        var.mkdir(parents=True)
        env[key]=str(var)
    command = [str(python),str(shared/'tools/comfyui/gpu_lock.py'),'--',engine,
               '--path',str(shared),'--resolution','1280x720','--position','10,90',
               '--rendering-method','forward_plus','--rendering-driver','vulkan']
    if fixed:
        command.extend(('--fixed-fps','60'))
    command.append(str(scene))
    command.extend(('--',*[a.replace('{out}',out.as_posix()) for a in args]))
    (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=650)
    (out/'exit.txt').write_text(str(result.returncode)+'\n',encoding='utf-8')
    raw=(out/'raw.log').read_text(encoding='utf-8')
    print(case,result.returncode,len(raw),flush=True)
    assert result.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw
    return raw







kind=sys.argv[1]
assert kind in ('before','after')
for tag in (('zh',) if kind=='before' else ('zh','ja','en')):
    log=render(f'labels-{kind}-{tag}',base/'labels.tscn',
               ['--out={out}',f'--story-language={tag}'],True)
    assert 'FAIL ' not in log and (base/f'labels-{kind}-{tag}'/'label-report.json').is_file()
