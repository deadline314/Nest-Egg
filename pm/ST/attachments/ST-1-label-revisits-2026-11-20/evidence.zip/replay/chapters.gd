extends Node

const CHAPTER := &"ch1_kasa"
const PATH := "res://data/story/ch1_kasa.json"


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	var source := load(PATH) as JSON
	if out.is_empty() or source == null or not source.data is Dictionary:
		get_tree().quit(2)
		return
	var missing := StoryLocale.audit(source.data)
	var records := {}
	var failed := not missing.is_empty()
	for code in StoryLocale.LANGUAGES:
		if not Story.set_language(code):
			push_error("Could not load active chapter language " + code)
			get_tree().quit(2)
			return
		var units := Story.text_units(CHAPTER)
		var problems := StoryLint.check_chapter(String(CHAPTER), units, Story._speakers, code)
		var validation := Story.validate()
		var line_count := 0
		var speakers := {}
		var modes := {}
		var longest := 0
		for unit: Dictionary in units:
			for line: Dictionary in unit["lines"]:
				if str(line.get("kind", "")) == "label":
					continue
				var text := str(line.get("text", ""))
				var role := str(line.get("speaker", ""))
				var mode := str(line.get("mode", "variant"))
				line_count += 1
				modes[mode] = int(modes.get(mode, 0)) + 1
				speakers[role] = int(speakers.get(role, 0)) + 1
				if code == StoryLocale.SOURCE_LANGUAGE:
					for sentence in StoryLint.split_sentences(text):
						longest = maxi(longest, StoryLint.sentence_length(sentence))
		records[code] = {"units": units.size(), "spoken_or_narrated_lines_and_choices": line_count,
			"speakers": speakers, "lines_by_mode": modes, "lint": problems,
			"validation": validation, "max_chinese_sentence": longest}
		failed = failed or units.is_empty() or line_count == 0 or not problems.is_empty() or not validation.is_empty()
		print("ST1_CHAPTER ", code, " units=", units.size(), " lines=", line_count, " lint=", problems.size(), " validate=", validation.size())
	var file := FileAccess.open(out, FileAccess.WRITE)
	if file == null:
		get_tree().quit(2)
		return
	file.store_string(JSON.stringify({"languages": records, "missing": missing}, "  "))
	get_tree().quit(1 if failed else 0)
