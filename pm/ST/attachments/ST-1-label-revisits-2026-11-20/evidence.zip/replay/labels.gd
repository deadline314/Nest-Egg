extends "res://tools/ch1_flow_probe.gd"

const LABELS := ["watch", "guitar", "raincoat", "fare"]
var _revisit := ""
var _expected := ""
var _captured := false
var _texts := {}
var _modes := {}


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip = false
	Story.scene_started.connect(func(id: StringName, mode: StringName) -> void:
		_played.append(String(id))
		_modes[String(id)] = String(mode))
	await _enter("pawnshop", Vector2(86 * 16, 19 * 16))
	for label: String in LABELS:
		await _talk(StringName("ch1_label_" + label))
		_check(GameState.has_flag(StringName("ch1_label_" + label + "_seen")), "first read records only the actual " + label)
	_check(GameState.has_flag(&"sq8_first_labels_done"), "the four real items complete the label side quest")
	var economy := Progression.snapshot()
	var items := StoryItems.snapshot()
	_played.clear()
	for label: String in LABELS:
		_revisit = "ch1_t_label_" + label + "_revisit"
		var scene: Dictionary = Story.audit_data()["scenes"][_revisit]
		_expected = String(scene["steps"][1]["text"])
		_captured = false
		await _talk(StringName("ch1_label_" + label))
		_check(_captured and Progression.snapshot() == economy and StoryItems.snapshot() == items,
			"the actual " + label + " revisit displays its line and gives no credit, item or receipt")
		_check(GameState.has_flag(StringName("ch1_label_" + label + "_seen")) and GameState.has_flag(&"sq8_first_labels_done"),
			"the revisit preserves the known item and quest flags")
	var expected: Array[String] = []
	for label: String in LABELS:
		expected.append("ch1_t_label_" + label + "_revisit")
	_check(_played == expected, "each real item uses exactly one short reprise in the original order")
	var file := FileAccess.open(_out_dir.path_join("label-report.json"), FileAccess.WRITE)
	if file == null:
		get_tree().quit(2)
		return
	file.store_string(JSON.stringify({"language": Story.language, "failures": _failures, "lines": _texts, "played": _played, "modes": _modes}, "  "))
	await _settle(4)
	get_tree().quit(1 if _failures > 0 else 0)


func _drive(_choices: Array, finished: Callable) -> void:
	for i in STEP_LIMIT:
		if finished.call():
			return
		var player: CutscenePlayer = Story._player
		if is_instance_valid(player) and player.is_running() and player._dialogue.visible:
			var dialogue: CutsceneDialogue = player._dialogue
			dialogue.complete()
			if not _captured and not _revisit.is_empty() and String(Story._current_cinematic) == _revisit and dialogue._text.text == _expected:
				_captured = true
				_texts[_revisit] = dialogue._text.text
				await _settle(2)
				if DisplayServer.get_name() != "headless":
					await RenderingServer.frame_post_draw
					_capture(_revisit)
			player._advance_requested = true
		elif Story.is_cinematic_active() and Story.scene_mode(Story._current_cinematic) != Story.MODE_ANIMATED:
			Story.skip_cinematic()
		await get_tree().physics_frame
	_check(false, "label dialogue finished before the probe limit")
