from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = base / sys.argv[1]
out.mkdir()
env = os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key] = str(out/'profile'/key)
env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8')
scene = sys.argv[2]
is_joint = scene == 'rig_joint_audit'
is_duel = scene in ('escort-duel','thrower-duel')
destination = out.as_posix() if is_joint or is_duel else (out/'preview.png').as_posix()
command = [sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(shared),
           *(['--verbose'] if out.name.endswith('-diagnostic') else []),
           '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
           '--resolution','1280x720','--fixed-fps','60','--quit-after','18000',
           (base/f'{scene}.tscn').as_posix() if is_duel else f'res://tools/{scene}.tscn','--',f'--out={destination}',*sys.argv[3:]]
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
    process = subprocess.run(command,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
raw = (out/'raw.log').read_text(encoding='utf-8',errors='replace')
print(raw[-3800:],flush=True)
assert process.returncode == 0 and 'ERROR:' not in raw
if is_duel:
    assert len(list(out.glob(scene.split('-')[0]+'-*.png'))) == (10 if scene == 'escort-duel' else 8)
else:
    assert (out/('frames.json' if is_joint else 'preview.png')).is_file()
