from pathlib import Path

from PIL import Image, ImageDraw

image = Image.new('RGBA', (96, 80))
draw = ImageDraw.Draw(image)


def paper(points, color):
    draw.polygon([(x * 4, y * 4) for x, y in points], fill=color)


paper([(1, 7), (17, 5), (23, 7), (22, 18), (5, 19), (1, 16)], '#52413b')
paper([(2, 9), (20, 7), (22, 8), (21, 17), (5, 18), (2, 16)], '#b7a68c')
paper([(0, 6), (16, 2), (22, 4), (22, 14), (5, 17), (1, 14)], '#625248')
paper([(1, 6), (16, 3), (21, 4), (21, 13), (5, 16), (2, 14)], '#e9d8b6')
paper([(4, 7), (14, 5), (17, 6), (7, 8)], '#9d7962')
paper([(5, 11), (12, 9.5), (14, 10), (6, 12)], '#a48c75')
paper([(16, 11.5), (18, 11), (19, 12.5), (16.5, 13)], '#a55c45')
image.resize((24, 20), Image.Resampling.LANCZOS).save(Path('art/weapons/ch2_bill_bundle.png'))
