extends Ch2MarketEnemiesScenario


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
	_begin.call_deferred()


func _begin() -> void:
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	Enemy.activation_culling_enabled = false
	for side in [-1, 1]:
		await _duel(side)
	Music.stop(0.0)
	Ambience.stop_all(0.0)
	Sfx.stop_all()
	var shutdown := Time.get_ticks_msec() + 600
	while Time.get_ticks_msec() < shutdown:
		await get_tree().process_frame
	get_tree().quit(failures)


func _duel(side: int) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	level = Level.new()
	level.configure(load(LEVEL) as LevelData)
	add_child(level)
	_migration = MapLayoutMigration.read(level.data)
	await settle(30)
	player = level.player
	level.hud.visible = false
	player.health.grant_invulnerability(30.0)
	player.set_physics_process(false)
	var thrower: Enemy
	for node in get_tree().get_nodes_in_group(&"enemies"):
		var enemy := node as Enemy
		if enemy.data.id == &"ch2_bill_thrower":
			thrower = enemy
			break
	if thrower == null or _migration.has("error"):
		failures += 1
		await finish()
		return
	_place(8.0, 20)
	await _frames(int(TITLE_CARD_TIME * 60))
	player.global_position = thrower.global_position + Vector2(side * 100.0, 0.0)
	_frame(player.global_position, thrower.global_position)
	var label := "left" if side < 0 else "right"
	if await _wait_for([thrower], &"windup", 720) == null:
		await finish()
		return
	await _frames(36)
	await RenderingServer.frame_post_draw
	assert(thrower.fsm.is_in(&"windup") and thrower.facing == side)
	capture("thrower-%s-windup" % label)
	var hand_raised := thrower.anchor_node(&"hand_front").global_position
	var aim: Vector2 = thrower.get("_aim")
	var muzzle: Vector2 = thrower.call(&"_muzzle")
	if await _wait_for([thrower], &"recover", 150) == null:
		await finish()
		return
	var hand_at_release := thrower.anchor_node(&"hand_front").global_position
	var angles: Array[float] = []
	var starts: Array[Vector2] = []
	for child in ProjectilePool.container().get_children():
		var projectile := child as Projectile
		if projectile == null or not projectile.active or projectile.spec.source_id != &"bill_paper":
			continue
		angles.append(rad_to_deg(aim.angle_to(projectile.velocity)))
		starts.append(projectile.global_position - muzzle)
	angles.sort()
	var expected := [-23.0, -11.5, 0.0, 11.5, 23.0]
	if angles.size() != expected.size():
		failures += 1
		push_error("[thrower duel] expected five actual paper projectiles")
	else:
		for index in angles.size():
			if absf(angles[index] - expected[index]) > 0.01:
				failures += 1
				push_error("[thrower duel] paper angles disagree with the authored fan")
	print("THROWER ", JSON.stringify({"side": side, "count": angles.size(), "angles": angles,
		"hand_raised": str(hand_raised), "hand_at_release": str(hand_at_release),
		"muzzle": str(muzzle), "release_grip_distance": hand_at_release.distance_to(muzzle), "first_observed_offsets": str(starts),
		"paper_texture_loaded": thrower.get("_paper_texture") is Texture2D}))
	await _frames(16)
	await RenderingServer.frame_post_draw
	capture("thrower-%s-flight" % label)
	await _frames(22)
	await RenderingServer.frame_post_draw
	capture("thrower-%s-recover" % label)
	var info := DamageInfo.create(5, Combat.Team.PLAYER, &"pistol", Vector2(-side * 100.0, 0.0))
	info.origin = player.global_position
	if thrower.hurtbox.receive(info) != Hurtbox.Result.DAMAGED or thrower.health.current != 0:
		failures += 1
		push_error("[thrower duel] defeat animation did not receive the lethal control hit")
	await _frames(34)
	await RenderingServer.frame_post_draw
	capture("thrower-%s-fall" % label)
	await _frames(260)
	await finish()
