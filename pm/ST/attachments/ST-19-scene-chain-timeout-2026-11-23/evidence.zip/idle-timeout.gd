extends "res://tools/ch1_flow_probe.gd"

func _run() -> void:
	var start := Engine.get_physics_frames()
	await _drive([], func() -> bool: return false)
	var elapsed := Engine.get_physics_frames() - start
	var exact := _failures == 1 and absi(elapsed - STEP_LIMIT) <= 2
	print("IDLE_TIMEOUT physics=", elapsed, " diagnosed=", exact)
	get_tree().quit(0 if exact else 1)
