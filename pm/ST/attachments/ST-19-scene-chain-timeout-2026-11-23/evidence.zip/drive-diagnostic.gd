extends "res://tools/ch2_flow_probe.gd"

func _drive(choices: Array, finished: Callable) -> void:
	var pending := choices.duplicate()
	var shown := {}
	for i in 7200:
		if finished.call():
			break
		var current := String(Story._current_cinematic)
		var player: CutscenePlayer = Story._player
		if i % 600 == 0 or i == STEP_LIMIT - 1:
			print("DRIVE_TIMELINE ", i, " scene=", current, " where=", player._current_where if is_instance_valid(player) else "<none>",
				" steps=", player.steps_run if is_instance_valid(player) else -1)
		if Story._layer.is_radio_frozen():
			# 重要通訊（NE-246）凍結世界等確認：像玩家一樣按確認讀完。
			await _settle(8)
			Story._layer.advance_radio()
		elif player != null and player.choice_active():
			var key := current + ":choice"
			if _shots.has(key) and not shown.has(key):
				shown[key] = true
				await _settle(20)
				_capture(_shots[key])
			var wanted: String = pending.pop_front() if not pending.is_empty() else str(player._choice_step.get("default", ""))
			var index := player._choice_options.find_custom(func(o: Dictionary) -> bool: return str(o.get("id", "")) == wanted)
			_check(index >= 0, "%s offers option %s" % [current, wanted])
			player.choose(maxi(index, 0))
		elif current != "" and _shots.has(current) and not shown.has(current):
			shown[current] = true
			await _settle(70)
			_capture(_shots[current])
		elif current != "" and Story.scene_mode(StringName(current)) != Story.MODE_ANIMATED:
			await _settle(8)
			Story.skip_cinematic()
		elif player != null and player.is_running() and player._dialogue.visible:
			player._dialogue.complete()
			player._advance_requested = true
		await get_tree().physics_frame
	_check(pending.is_empty(), "every planned choice was offered %s" % [choices])


