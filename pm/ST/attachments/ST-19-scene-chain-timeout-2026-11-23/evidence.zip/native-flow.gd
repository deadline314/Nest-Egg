extends "res://tools/ch2_flow_probe.gd"

const Capture := preload("res://tools/viewport_capture.gd")


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Story.scene_started.connect(_capture_transport)
	super._ready()


func _capture(_frame_name: String) -> void:
	pass


func _capture_transport(id: StringName, _mode: StringName) -> void:
	if id != &"ch2_t_s13_fall":
		return
	for i in 3800:
		await get_tree().physics_frame
		var player := Story._player
		if not is_instance_valid(player) or player.scene_id != id or player.steps_run < 85:
			continue
		if player.steps_run >= 95:
			break
		await RenderingServer.frame_post_draw
		var target := _out_dir.path_join("egret-transport.png")
		_check(Capture.image(get_viewport()).save_png(target) == OK, "native authored Egret transport frame")
		print("TRANSPORT_FRAME ", player.steps_run, " ", target)
		return
	_check(false, "original transport did not reach the final carrying sequence")
