extends "res://tests/probes/supper_completion.gd"

func _finish() -> void:
	if not finishing and faulted and _failures.is_empty() and _prompt() != null:
		await _capture("retry")
	await super._finish()

func _capture(name: String) -> void:
	if name == "pending":
		var deadline := Time.get_ticks_msec() + 4000
		while Time.get_ticks_msec() < deadline:
			var player: CutscenePlayer = Story._player if is_instance_valid(Story._player) else null
			if is_instance_valid(player):
				if player.choice_active():
					break
				if player._dialogue.visible:
					player._dialogue.complete()
					if Story.offers_choice(Story._scenes.get(String(Story._current_cinematic),{})):
						player._advance_requested = true
					else:
						await _frames(2)
						break
			await _frames(1)
	await super._capture(name)
