extends "res://tools/ch1_flow_probe.gd"

const ROOF := "res://data/levels/ch2_rooftop.tres"
const EGRET := &"ch2_egret"
var _main: Node
var _slot := ""
var _mode := "go"


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_slot = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_shots = {"ch2_t_s22_tea":"tea-opening", "ch2_t_s22_tea:choice":"tea-choice", "ch2_t_s22_decided":"tea-decided"}
	_main = load("res://game/main.gd").new()
	_main.set("_run_store",RunSaveStore.new(_slot.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(48)
	_check(GameState.has_flag(&"ch2_egret_returned"), "uses a real restored-Egret save")
	GameState.set_flag(&"ch2_audit_submitted")
	_main.call("_on_area_requested", ROOF)
	await _settle(60)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.resource_path == ROOF, "loaded the actual rooftop in Main")
	var npc := _object(EGRET)
	_check(npc != null, "the original Egret actor is present")
	if npc == null:
		_done({})
		return
	if not GameState.has_flag(&"ch2_brief_done"):
		_check(await _talk(EGRET), "the original first rooftop briefing completes")
		_check(GameState.has_flag(&"ch2_brief_done"), "the real briefing unlocks the later roof talk")
	var scenes: Array[String] = []
	Story.scene_started.connect(func(id: StringName, _type: StringName) -> void: scenes.append(String(id)))
	_check(Story.resolve_dispatch(npc.data.talks[npc.current_talk_index()].scene) == &"ch2_t_s22_tea", "dispatches the actual S22 talk")
	_check(await _talk(EGRET,[_mode]), "the original rooftop direction choice returns")
	await _settle(120)
	var expected := _mode == "go"
	_check(GameState.has_flag(&"ch2_heron_closed") == expected and GameState.has_flag(&"harbor_walk_ready") == expected,
			"only confirming closes the chapter and opens the original walking link")
	_capture("after-roof")
	print("ROOF_CASE ", JSON.stringify({"mode":_mode,"closed":GameState.has_flag(&"ch2_heron_closed"),
			"walk":GameState.has_flag(&"harbor_walk_ready"),"scenes":scenes}))
	_done({"mode":_mode,"closed":GameState.has_flag(&"ch2_heron_closed"),"walk":GameState.has_flag(&"harbor_walk_ready"),"scenes":scenes})


func _done(result: Dictionary) -> void:
	result["failures"] = _failures
	FileAccess.open(_out_dir.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
	get_tree().quit(0 if _failures == 0 else 1)
