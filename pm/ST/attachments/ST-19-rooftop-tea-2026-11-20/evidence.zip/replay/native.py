from pathlib import Path
from shutil import copyfile
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
prior = base.parent/'st19-booth-rain-20261120'
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
source = json.loads((prior/'integration/source.json').read_bytes())
files = ('data/story/ch2_heron.json','data/levels/ch2_rooftop.tres','data/cutscene/stages/ch1_rooftop.json','game/main.gd')
assert all(hashlib.sha256((shared/name).read_bytes()).hexdigest()==source[name] for name in files)
copyfile(base/'roof_probe.gd',shared/'work/st19_roof_probe.gd')
scene = '[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/st19_roof_probe.gd" id="1"]\n[node name="RoofTeaProbe" type="Node"]\nscript=ExtResource("1")\n'
(shared/'work/st19_roof_probe.tscn').write_text(scene, encoding='utf-8', newline='\n')
tag, *modes = sys.argv[1:]
for mode in modes:
    out = base/tag/mode
    (out/'slot').mkdir(parents=True)
    copyfile(prior/'after/normal/slot/slot.json', out/'slot/slot.json')
    env=os.environ.copy()
    for name in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[name] = str(out/'profile'/name)
    cmd=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
         'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(shared),'--audio-driver','WASAPI',
         '--rendering-method','forward_plus','--resolution','960x540','--position','32,32','--max-fps','60',
         'res://work/st19_roof_probe.tscn','--','--mode='+mode,'--save-dir='+str(out/'slot'),'--out='+str(out)]
    (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        process = subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    raw = (out/'raw.log').read_text(encoding='utf-8',errors='replace')
    record = {'exit':process.returncode,
              'source_held':all(hashlib.sha256((shared/name).read_bytes()).hexdigest()==source[name] for name in files),
              'errors':[line for line in raw.splitlines() if 'ERROR:' in line],
              'observed': [json.loads(line.removeprefix('ROOF_CASE ')) for line in raw.splitlines() if line.startswith('ROOF_CASE ')]}
    (out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(record,flush=True)
    assert not record['errors'] and record['source_held'] and record['exit']==0
