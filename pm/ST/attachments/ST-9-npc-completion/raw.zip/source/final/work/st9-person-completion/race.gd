extends "res://work/st9-person-completion/probe.gd"
class RaceStore extends RunSaveStore:
	var actor: NpcActor
	var armed := false
	var fired := false
	func _durable_phase(phase: DurablePhase, _absolute: String) -> void:
		if armed and phase == DurablePhase.PRIMARY_COMMITTED:
			armed = false
			fired = true
			actor.queue_free()

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	await _until(func()->bool:return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested",GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE),"race starts through actual Main new game")
	await _skip_cinematics()
	await _enter(PAWNSHOP)
	var actor := _actor()
	_check(actor != null,"race owns the actual authored watch label")
	if actor == null:return
	var scene:=StringName(TARGETS[target][0])
	var flag:=StringName(TARGETS[target][1])
	_main.call("_save_run")
	await _settle(8)
	var slot:=_save_dir.path_join("slot.json")
	var store:=RaceStore.new(slot)
	store.validator=RunSnapshot.prepare
	store.actor=actor
	_main.set("_run_store",store)
	_level().player.global_position=actor.global_position+Vector2(8,-2)
	_level().player.velocity=Vector2.ZERO
	_check(await _until(func()->bool:return actor._player_in_range and actor._cooldown<=0.0 and not get_tree().paused),"race has a real interaction sensor")
	store.armed=true
	await _press(&"interact")
	_check(await _until(func()->bool:return actor._talking and Story.is_cinematic_active()),"race starts actual label reading by public interaction")
	var owner:Node=_main.get("_result_completion")
	for i in 100:
		if is_instance_valid(owner.get("_prompt")):break
		await _press(&"ui_accept")
		await get_tree().create_timer(0.06,true,false,true).timeout
	_check(store.fired and is_instance_valid(owner.get("_prompt")) and owner.get("_recovery"),"actual durable rename retires the actor and requires loading the committed result")
	_check(not GameState.has_flag(flag) and not Story.progress_snapshot().has(scene),"stale source never publishes partially installed live results")
	var saved:=RunSaveCodec.decode(FileAccess.get_file_as_string(slot))
	_check(saved.has("data") and saved["data"]["story"]["flags"][String(flag)] and saved["data"]["story"]["seen"].has(String(scene)),"durable result remains committed despite source removal")
	for world:Dictionary in [saved["data"]["runtime"]["world"],saved["data"]["runtime"]["area"]["world"],saved["data"]["state"]["area_states"]["ch1_pawnshop"]["world"]]:
		_check(world["npc:ch1_label_watch@34,19"]["talks"]==1,"durable NPC count is one before any surviving waiter could settle")
	await _shot("committed-source-removed")
	var previous_level:=_level().get_instance_id()
	await _press(&"ui_accept")
	_check(await _wait_level(PAWNSHOP,previous_level),"public recovery reloads the actual committed Level")
	await _skip_cinematics()
	_check(await _until(func()->bool:return not get_tree().paused and not GameplayLock.is_locked()),"recovery releases its own pause and lock")
	_check(GameState.has_flag(flag) and Story.progress_snapshot().has(scene) and _actor()!=null and _actor().talk_count==1,"recovery restores matching objective/history/NPC count without a waiter")
	await _shot("committed-restored")
	_completed=true
	_save_report()
