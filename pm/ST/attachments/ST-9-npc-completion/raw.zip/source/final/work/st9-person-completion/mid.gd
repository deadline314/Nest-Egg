extends "res://work/st9-person-completion/probe.gd"
func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	await _until(func()->bool:return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested",GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE),"mid-read writer starts through actual Main")
	await _skip_cinematics()
	await _enter(PAWNSHOP)
	var actor:=_actor()
	_check(actor!=null,"mid-read writer owns authored watch label")
	if actor==null:return
	_level().player.global_position=_interaction_position(actor)
	_level().player.velocity=Vector2.ZERO
	_check(await _until(func()->bool:return actor._player_in_range and actor._cooldown<=0.0 and Story.framing.is_interaction_target(actor) and not get_tree().paused),"mid-read interaction sensor ready")
	await _press(&"interact")
	_check(await _until(_readable_first_line),"mid-read writer reaches actual full first line")
	_main.call("_save_run")
	var saved:=RunSaveCodec.decode(FileAccess.get_file_as_string(_save_dir.path_join("slot.json")))
	_check(saved.has("data") and saved["data"]["cinematic"]==TARGETS[target][0] and saved["data"]["cinematic_context"].get("source_id")==actor.state_key(),"mid-read save keeps exact real scene and actor context")
	_check(not GameState.has_flag(StringName(TARGETS[target][1])) and actor.talk_count==0 and not Story.progress_snapshot().has(StringName(TARGETS[target][0])),"mid-read save has no premature result or NPC settlement")
	await _shot("mid-reading")
	_completed=true
	_save_report()

func _continue() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	var expected:Dictionary=JSON.parse_string(FileAccess.get_file_as_string(_save_dir.path_join("expect.json")))
	_check(FileAccess.get_sha256(_save_dir.path_join("slot.json"))==expected["sha256"],"mid-read cold reader begins with exact frozen writer bytes")
	await _until(func()->bool:return not bool(_main.call("_route_pending")))
	_main.call("_on_continue_requested")
	_check(await _wait_level(PAWNSHOP),"mid-read cold Main restores authored pawnshop")
	var scene:=StringName(TARGETS[target][0])
	var flag:=StringName(TARGETS[target][1])
	_check(await _until(func()->bool:return Story._current_cinematic==scene),"mid-read cold continuation actually presents the saved scene")
	var actor:=_actor()
	_check(actor!=null and actor._talking,"cold continuation belongs to the actual NPC waiter, not an orphan fallback")
	if actor==null or not actor._talking:
		_completed=true
		_save_report()
		return
	_check(await _until(_readable_first_line),"resumed actual actor owns a full readable first line")
	_check(get_viewport().get_visible_rect().has_point(get_viewport().get_canvas_transform()*_level().player.global_position),"cold paused reading shows the actual player in the current rendered viewport")
	_check(not GameState.has_flag(flag) and actor.talk_count==0 and not Story.progress_snapshot().has(scene),"resumed reading starts without premature result")
	await _shot("resumed-reading")
	var slot:=_save_dir.path_join("slot.json")
	var before:=FileAccess.get_file_as_bytes(slot)
	_check(DirAccess.make_dir_absolute(slot+".tmp")==OK,"real IO obstruction applies to resumed completion")
	var owner:Node=_main.get("_result_completion")
	for i in 100:
		if is_instance_valid(owner.get("_prompt")):break
		await _press(&"ui_accept")
		await get_tree().create_timer(0.06,true,false,true).timeout
	_check(is_instance_valid(owner.get("_prompt")) and actor._talking and not GameState.has_flag(flag) and actor.talk_count==0,"resumed completion refuses atomically and retains its real waiter")
	_check(FileAccess.get_file_as_bytes(slot)==before,"resumed refusal preserves the exact pre-completion slot")
	await _shot("resumed-write-refused")
	DirAccess.remove_absolute(slot+".tmp")
	await _press(&"ui_accept")
	_check(await _until(func()->bool:return GameState.has_flag(flag) and actor.talk_count==1 and not actor._talking and not GameplayLock.is_locked() and not get_tree().paused),"public retry completes resumed reading exactly once")
	await _settle(8)
	var saved:=RunSaveCodec.decode(FileAccess.get_file_as_string(slot))
	_check(saved.has("data") and saved["data"]["cinematic"]=="" and saved["data"]["story"]["seen"].has(String(scene)) and saved["data"]["runtime"]["world"][actor.state_key()]["talks"]==1,"resumed success saves matching completed history and actor with no pending replay")
	await _shot("resumed-complete")
	_completed=true
	_save_report()
