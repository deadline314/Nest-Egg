from pathlib import Path
import os,subprocess,time,json,hashlib
w=Path('work/st9-person-completion');env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1',LOG_DIR=str((w/'durable-focus-shards').resolve()));cmd=['tools/run_tests_parallel.sh','--only=RunSaveSuite'];start=time.monotonic()
files=['game/npc/npc_actor.gd','game/story_result_completion.gd','data/story/ch1_kasa.json','tools/story/ch1_runtime_backend.py','tests/suite/test_npc.gd','tests/suite/test_run_save.gd','tests/helpers/npc_terminal_save_checks.gd']
(w/'verification-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2))
with (w/'focus.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
(w/'focus-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2));assert r.returncode==0
print('NPC_FOCUS_PASS',flush=True)
