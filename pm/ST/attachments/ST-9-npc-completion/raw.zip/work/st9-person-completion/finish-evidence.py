from pathlib import Path
import json, time, subprocess
w=Path('work/st9-person-completion')
while True:
    r=json.loads((w/'integration-receipt.json').read_text())
    if r.get('exit_code') is not None:
        assert r['exit_code']==0,r
        break
    time.sleep(15)
assert len(json.loads((w/'viewed-integrated.json').read_text())['files'])==30
subprocess.run(['python',str(w/'package.py')],check=True)
subprocess.run(['python',str(w/'final-docs.py')],check=True)
subprocess.run(['git','diff','--check'],check=True)
(w/'evidence-ready.json').write_text(json.dumps({'passed':True,'base':r['base'],'scope':'Final native246/0,all30individuallyviewed,original61 green,sourceSHA verified,archive entries SHA readback checked. No commit/push/cleanup performed by this script.'},indent=2)+'\n')
print('ST9_EVIDENCE_READY',flush=True)
