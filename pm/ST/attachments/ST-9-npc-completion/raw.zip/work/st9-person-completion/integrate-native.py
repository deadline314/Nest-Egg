from pathlib import Path
import subprocess,os,json,time,hashlib,re
w=Path('work/st9-person-completion');native=Path('/workspace/Nest-Egg/work/batch1020b');env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/person';rows=[];base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
files=['game/npc/npc_actor.gd','game/story_result_completion.gd','data/story/ch1_kasa.json','tools/story/ch1_runtime_backend.py','work/st9-person-completion/probe.gd','work/st9-person-completion/base.gd','tools/quest_resume_probe.gd','tools/viewport_capture.gd','core/asset_prefetch.gd','ui/hud.gd','ui/pickup_feed.gd','ui/quest_guidance.gd','work/st9-person-completion/race.gd','work/st9-person-completion/race.tscn','work/st9-person-completion/mid.gd','work/st9-person-completion/mid.tscn','game/level/level_camera.gd']
assert base!='ad8c1cfe05ede98e548ebd20dca8d8e6c228ee4e','Integrate BG50 and HUD main first'
(w/'integration-native-frozen-source.json').write_text(json.dumps({'base':base,'sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}},indent=2))
for target,dawn in [(x,False) for x in ['ch1_label_watch','ch1_label_guitar','ch1_label_raincoat','ch1_label_fare','ch1_egret']]+[('ch1_label_watch',True)]:
 label=target+('-dawn' if dawn else '');savedir=w/('integrated-camerafix-'+base[:8]+'-'+label+'-save');savedir.mkdir(exist_ok=True)
 for mode in ['write','continue']:
  name='st9-1023-npc-camerafix-'+base[:8]+'-'+label+'-'+mode;cmd=['python',str(native/'native.py'),name,'res://work/st9-person-completion/probe.tscn','--mode='+mode,'--npc='+target,'--save-dir='+str(savedir.resolve())]+(['--dawn'] if dawn else []);start=time.monotonic()
  with (w/(name+'-wrapper.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
  log=(native/(name+'.log')).read_text();report=json.loads((native/name/'result.json').read_text()) if (native/name/'result.json').exists() else {};rec={'name':name,'base':base,'target':target,'dawn':dawn,'mode':mode,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'engine_errors':log.count('ERROR:'),'script_errors':log.count('SCRIPT ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log)),'completed':report.get('completed'),'checks':report.get('checks'),'failures':report.get('failures')};rows.append(rec);(w/'integration-native-receipt.json').write_text(json.dumps(rows,indent=2));print(name,rec,flush=True)
  assert r.returncode==0 and rec['engine_errors']==0 and rec['script_errors']==0 and rec['leaks']==0 and rec['completed'] and rec['failures']==0
  if mode=='write':
   frozen=(savedir/'slot.json').read_bytes();(savedir/'frozen-writer.json').write_bytes(frozen);(savedir/'expect.json').write_text(json.dumps({'sha256':hashlib.sha256(frozen).hexdigest()}))
for p,h in json.loads((w/'integration-native-frozen-source.json').read_text())['sha256'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
print('NPC_INTEGRATED_NATIVE_PASS',flush=True)
