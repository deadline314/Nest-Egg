from pathlib import Path
import subprocess,os,json,time,hashlib
w=Path('work/st9-person-completion');path=Path('data/story/ch1_kasa.json');final=path.read_bytes();rows=[];env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1')
def run(label):
 e=env.copy();e['LOG_DIR']=str((w/(label+'-shards')).resolve());cmd=['tools/run_tests_parallel.sh','--only=RunSaveSuite'];start=time.monotonic()
 with (w/(label+'.log')).open('w') as f:r=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 rec={'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'scope':'activation-negative changes only the five generated policy annotations back to unmodified HEAD; current actor/owner code and all test predicates remain'};rows.append(rec);(w/'durable-control-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);return r.returncode
try:
 path.write_bytes(subprocess.check_output(['git','show','HEAD:data/story/ch1_kasa.json']))
 assert run('durable-negative')==1
finally:path.write_bytes(final)
assert run('durable-fixed')==0
files=['game/npc/npc_actor.gd','game/story_result_completion.gd','data/story/ch1_kasa.json','tools/story/ch1_runtime_backend.py','tests/suite/test_npc.gd','tests/suite/test_run_save.gd','tests/helpers/npc_terminal_save_checks.gd']
(w/'verification-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2))
print('DURABLE_CONTROL_PASS',flush=True)
