from pathlib import Path
import subprocess,os,json,time,hashlib,re
w=Path('work/st9-person-completion');native=Path('/workspace/Nest-Egg/work/batch1020b');env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/person';rows=[]
for target in ['ch1_label_watch','ch1_label_guitar','ch1_label_raincoat','ch1_label_fare','ch1_egret']:
 savedir=w/('native-'+target+'-save');savedir.mkdir(exist_ok=True)
 for mode in ['write','continue']:
  name='st9-1023-npc-'+target+'-'+mode;cmd=['python',str(native/'native.py'),name,'res://work/st9-person-completion/probe.tscn','--mode='+mode,'--npc='+target,'--save-dir='+str(savedir.resolve())];start=time.monotonic()
  with (w/(name+'-wrapper.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
  log=(native/(name+'.log')).read_text();report=json.loads((native/name/'result.json').read_text()) if (native/name/'result.json').exists() else {};rec={'name':name,'target':target,'mode':mode,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'engine_errors':log.count('ERROR:'),'script_errors':log.count('SCRIPT ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log)),'completed':report.get('completed'),'checks':report.get('checks'),'failures':report.get('failures')};rows.append(rec);(w/'native-receipt.json').write_text(json.dumps(rows,indent=2));print(name,rec,flush=True)
  assert r.returncode==0 and rec['engine_errors']==0 and rec['script_errors']==0 and rec['leaks']==0 and rec['completed'] and rec['failures']==0
  if mode=='write':
   frozen=(savedir/'slot.json').read_bytes();(savedir/'frozen-writer.json').write_bytes(frozen);(savedir/'expect.json').write_text(json.dumps({'sha256':hashlib.sha256(frozen).hexdigest()}))
  else:
   assert (savedir/'frozen-writer.json').read_bytes() != b''
print('NPC_NATIVE_MATRIX_PASS',flush=True)
