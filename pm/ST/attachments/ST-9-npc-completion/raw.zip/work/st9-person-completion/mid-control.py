from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
w=Path('work/st9-person-completion');env=os.environ.copy();rows=[];save=w/'mid-v2-writer-save';save.mkdir(exist_ok=True)
def run(label,mode,savedir):
 e=env.copy();e.update(XDG_DATA_HOME=str((w/(label+'-profile')).resolve()),LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu');cmd=['/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64','--headless','--path','.', 'res://work/st9-person-completion/mid.tscn','--','--mode='+mode,'--npc=ch1_label_watch','--out='+str((w/label).resolve()),'--save-dir='+str(savedir.resolve())];start=time.monotonic()
 with (w/(label+'.log')).open('w') as f:r=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 rec={'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start};rows.append(rec);(w/'mid-control-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);return r.returncode
assert run('mid-writer','write',save)==0
frozen=(save/'slot.json').read_bytes();(w/'mid-frozen-writer.json').write_bytes(frozen)
negative=w/'mid-v2-negative-save';negative.mkdir(exist_ok=True);(negative/'slot.json').write_bytes(frozen);(negative/'expect.json').write_text(json.dumps({'sha256':hashlib.sha256(frozen).hexdigest()}))
assert run('mid-negative','continue',negative)==1
print('MID_NEGATIVE_READY',flush=True)
