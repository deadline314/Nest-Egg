from pathlib import Path
import subprocess,os,json,time,hashlib
w=Path('work/st9-person-completion');path=Path('game/story_result_completion.gd');before=path.read_text();(w/'repair-before.gd').write_text(before);rows=[];env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1')
def run(label):
 e=env.copy();e['LOG_DIR']=str((w/(label+'-shards')).resolve());cmd=['tools/run_tests_parallel.sh','--only=RunSaveSuite'];start=time.monotonic()
 with (w/(label+'.log')).open('w') as f:r=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 rows.append({'label':label,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start});(w/'repair-control-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);return r.returncode
assert run('repair-negative')==1
old='''\t\t# Level's raw runtime shares its world dictionary with the live area.
\t\t# Build NPC changes only in the detached, normalized proposal.
\t\tcandidate = original["data"].duplicate(true)'''
new='''\t\t# Detach the raw capture from the live area, retaining actual owner facts.
\t\t# Copying the normalized original could silently introduce read-time repairs.
\t\tcandidate = candidate.duplicate(true)'''
assert old in before;path.write_text(before.replace(old,new));assert run('repair-fixed')==0
files=['game/npc/npc_actor.gd','game/story_result_completion.gd','data/story/ch1_kasa.json','tools/story/ch1_runtime_backend.py','tests/suite/test_npc.gd','tests/suite/test_run_save.gd','tests/helpers/npc_terminal_save_checks.gd','tests/helpers/npc_repair_boundary_checks.gd']
(w/'verification-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2));print('REPAIR_BOUNDARY_PASS',flush=True)
