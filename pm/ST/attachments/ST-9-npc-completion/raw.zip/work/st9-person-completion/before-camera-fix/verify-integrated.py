from pathlib import Path
import os,subprocess,time,json,hashlib,re
w=Path('work/st9-person-completion');base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert base!='ad8c1cfe05ede98e548ebd20dca8d8e6c228ee4e'
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
subprocess.run(['python',str(w/'integrate-native.py')],check=True)
env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/person';name='st9-1023-npc-'+base[:8]+'-source-removed';cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/st9-person-completion/race.tscn','--mode=write','--npc=ch1_label_watch','--save-dir='+str((w/('race-'+base[:8]+'-save')).resolve())];start=time.monotonic()
with (w/'integration-race-wrapper.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
native=Path('/workspace/Nest-Egg/work/batch1020b');log=(native/(name+'.log')).read_text();report=json.loads((native/name/'result.json').read_text()) if (native/name/'result.json').exists() else {};rec={'name':name,'base':base,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'engine_errors':log.count('ERROR:'),'script_errors':log.count('SCRIPT ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log)),'report':report};(w/'integration-race-receipt.json').write_text(json.dumps(rec,indent=2));assert r.returncode==0 and rec['engine_errors']==0 and rec['script_errors']==0 and rec['leaks']==0 and report['completed'] and report['failures']==0
mid_rows=[]
mid_save=w/('mid-'+base[:8]+'-save');mid_save.mkdir(exist_ok=True)
for mode in ['write','continue']:
 name='st9-1023-npc-'+base[:8]+'-mid-'+mode;cmd=['python',str(native/'native.py'),name,'res://work/st9-person-completion/mid.tscn','--mode='+mode,'--npc=ch1_label_watch','--save-dir='+str(mid_save.resolve())];start=time.monotonic()
 with (w/(name+'-wrapper.log')).open('w') as f:outcome=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
 log=(native/(name+'.log')).read_text();report=json.loads((native/name/'result.json').read_text()) if (native/name/'result.json').exists() else {};entry={'name':name,'base':base,'mode':mode,'command':cmd,'exit_code':outcome.returncode,'seconds':time.monotonic()-start,'engine_errors':log.count('ERROR:'),'script_errors':log.count('SCRIPT ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',log)),'report':report};mid_rows.append(entry);(w/'integration-mid-receipt.json').write_text(json.dumps(mid_rows,indent=2));print('MID_NATIVE',mode,entry['exit_code'],flush=True)
 assert outcome.returncode==0 and entry['engine_errors']==0 and entry['script_errors']==0 and entry['leaks']==0 and report['completed'] and report['failures']==0
 if mode=='write':
  frozen=(mid_save/'slot.json').read_bytes();(mid_save/'frozen-writer.json').write_bytes(frozen);(mid_save/'expect.json').write_text(json.dumps({'sha256':hashlib.sha256(frozen).hexdigest()}))
print('NPC_ALL_NATIVE_READY',flush=True)
env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='2',LOG_DIR=str((w/'integration-shards').resolve()));cmd=['tools/run_tests_changed.sh',base];start=time.monotonic()
(w/'integration-receipt.json').write_text(json.dumps({'base':base,'command':cmd,'exit_code':None,'status':'running','shards':2},indent=2))
with (w/'integration.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
(w/'integration-receipt.json').write_text(json.dumps({'base':base,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'shards':2},indent=2));assert r.returncode==0
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
for p,h in json.loads((w/'integration-native-frozen-source.json').read_text())['sha256'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
print('NPC_INTEGRATED_ALL_PASS',flush=True)
