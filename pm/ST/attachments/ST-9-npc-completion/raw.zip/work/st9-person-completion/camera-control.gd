extends "res://work/st9-person-completion/mid.gd"
func _geometry() -> Dictionary:
	var cam:=_level().camera
	var pixel:=get_viewport().get_canvas_transform()*_level().player.global_position
	return {"camera_global":cam.global_position,"camera_screen_center":cam.get_screen_center_position(),"canvas":get_viewport().get_canvas_transform(),"player_global":_level().player.global_position,"player_screen":pixel,"player_inside_view":get_viewport().get_visible_rect().has_point(pixel),"paused":get_tree().paused,"scene":String(Story._current_cinematic),"npc_talks":_actor().talk_count,"request":Story.current_presentation_request()}
func _shot(name: String) -> void:
	if name!="resumed-reading":
		await super._shot(name)
		return
	var before:=_geometry()
	await super._shot("resumed-before-force-scroll")
	_level().camera.force_update_scroll()
	await RenderingServer.frame_post_draw
	var after:=_geometry()
	await super._shot("resumed-after-force-scroll")
	var file:=FileAccess.open(out.path_join("camera-control.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"before":before,"after":after},"\t"))
	_check(before["player_inside_view"],"cold paused reading already places the real player in the actual rendered viewport")
	_check(after["player_inside_view"] and after["paused"] and before["request"]==after["request"] and after["npc_talks"]==0,"force-scroll-only control corrects camera without resuming gameplay or settling reading")
