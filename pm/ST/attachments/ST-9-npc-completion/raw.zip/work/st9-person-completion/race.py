from pathlib import Path
import os,subprocess,time,json
w=Path('work/st9-person-completion');env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',XDG_DATA_HOME=str((w/'race-v3-profile').resolve()));cmd=['/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64','--headless','--path','.', 'res://work/st9-person-completion/race.tscn','--','--mode=write','--npc=ch1_label_watch','--out='+str((w/'race-v3').resolve()),'--save-dir='+str((w/'race-v3-save').resolve())];start=time.monotonic()
with (w/'race.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
(w/'race-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'xdg':env['XDG_DATA_HOME']},indent=2));print(r.returncode)
