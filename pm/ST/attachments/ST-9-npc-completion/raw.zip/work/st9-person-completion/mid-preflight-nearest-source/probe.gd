extends "res://work/st9-person-completion/base.gd"
const TARGETS := {
	"ch1_label_watch": ["ch1_t_label_watch", "ch1_label_watch_seen", PAWNSHOP],
	"ch1_label_guitar": ["ch1_t_label_guitar", "ch1_label_guitar_seen", PAWNSHOP],
	"ch1_label_raincoat": ["ch1_t_label_raincoat", "ch1_label_raincoat_seen", PAWNSHOP],
	"ch1_label_fare": ["ch1_t_label_fare", "ch1_label_fare_seen", PAWNSHOP],
	"ch1_egret": ["ch1_t_egret_1", "ch1_heard_brief", "res://data/levels/ch1_rooftop.tres"],
}
var target := "ch1_label_watch"
var observations: Array = []
var checks := 0
var at_dawn := false
func _ready()->void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--npc="):target=arg.trim_prefix("--npc=")
		elif arg=="--dawn":at_dawn=true
	assert(TARGETS.has(target))
	super._ready()
func _check(value:bool,label:String)->void:
	checks+=1
	super._check(value,label)
	if _completed and not out.is_empty():_save_report()
func _actor()->NpcActor:
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and node.data!=null and String(node.data.id)==target and _level().is_ancestor_of(node):return node
	return null
func _write()->void:
	DirAccess.make_dir_recursive_absolute(out)
	await _until(func()->bool:return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested",GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE),"real Main new game starts in prologue")
	await _skip_cinematics()
	if target == "ch1_egret":
		# Declared preexisting dinner prerequisite; never inject this target result.
		GameState.set_flag(&"ch1_dinner_done")
	await _enter(_target_area())
	var actor:=_actor()
	_check(actor!=null and actor.is_present(),"actual authored NPC/object exists: "+target)
	if actor==null:return
	var scene:=StringName(TARGETS[target][0])
	var flag:=StringName(TARGETS[target][1])
	_check(not GameState.has_flag(flag) and not Story.progress_snapshot().has(scene),"target result is genuinely absent before reading")
	_main.call("_save_run")
	await _settle(8)
	var slot:=_save_dir.path_join("slot.json")
	var before:=FileAccess.get_file_as_bytes(slot)
	GameState.flag_changed.connect(func(id:StringName,value:Variant)->void:
		if id==flag:observations.append({"flag":String(id),"value":value,"disk_changed":FileAccess.get_file_as_bytes(slot)!=before,"completed":Story.progress_snapshot().has(scene),"actor_talks":actor.talk_count,"area_talks":_level()._area.get("world",{}).get(actor.state_key(),{}).get("talks",-1)}))
	_check(DirAccess.make_dir_absolute(_save_dir.path_join("slot.json.tmp"))==OK,"real temp-file directory blocks disk write")
	_level().player.global_position=actor.global_position+Vector2(36,-2)
	_level().player.velocity=Vector2.ZERO
	_check(await _until(func()->bool:return actor._player_in_range and actor._cooldown<=0.0 and _level().player.state==Player.State.NORMAL and not get_tree().paused),"actual interaction sensor is ready")
	await _press(&"interact")
	_check(await _until(func()->bool:return actor._talking and Story.is_cinematic_active()),"public interact begins the real authored reading")
	_check(await _until(_readable_first_line),"actual first line finishes with its real actors before reading capture")
	await _shot("reading")
	var owner:Node=_main.get("_result_completion")
	for i in 100:
		if not actor._talking or is_instance_valid(owner.get("_prompt")):break
		await _press(&"ui_accept")
		await get_tree().create_timer(0.06,true,false,true).timeout
	_check(not GameState.has_flag(flag),"failed save does not publish the NPC objective flag")
	_check(not Story.progress_snapshot().has(scene),"failed save does not complete the reading")
	_check(observations.is_empty(),"failed save emits no result notification")
	_check(actor.talk_count==0,"failed save does not settle the real NPC waiter")
	_check(_level()._area.get("world",{}).get(actor.state_key(),{}).get("talks",-1)==0,"failed proposal never mutates the live shared area world")
	_check(FileAccess.get_file_as_bytes(slot)==before,"failed save preserves original slot bytes")
	await _shot("write-refused")
	_check(is_instance_valid(owner.get("_prompt")) and get_tree().paused,"refusal leaves a persistent paused retry UI")
	if not is_instance_valid(owner.get("_prompt")):
		DirAccess.remove_absolute(_save_dir.path_join("slot.json.tmp"))
		_completed=true
		_save_report()
		return
	await _press(&"ui_accept")
	_check(not GameState.has_flag(flag) and observations.is_empty() and FileAccess.get_file_as_bytes(slot)==before,"public retry while blocked keeps every result unchanged")
	DirAccess.remove_absolute(_save_dir.path_join("slot.json.tmp"))
	await _press(&"ui_accept")
	_check(await _until(func()->bool:return GameState.has_flag(flag) and not actor._talking and not get_tree().paused and not GameplayLock.is_locked()),"public retry after IO recovery actually completes the original reading")
	_check(observations.size()==1 and observations[0]["disk_changed"] and observations[0]["completed"] and observations[0]["actor_talks"]==1 and observations[0]["area_talks"]==1,"exactly one observer sees matching durable and live completion")
	await _settle(8)
	var saved:=RunSaveCodec.decode(FileAccess.get_file_as_string(slot))
	_check(saved.has("data") and saved["data"]["story"]["flags"].get(String(flag))==true and saved["data"]["story"]["seen"].has(String(scene)),"real saved run contains the exact objective and reading history")
	_check(actor.talk_count==1,"the real NPC waiter settles exactly once")
	for world:Dictionary in [saved["data"]["runtime"]["world"],saved["data"]["runtime"]["area"]["world"],saved["data"]["state"]["area_states"][String(_level().data.id)]["world"]]:
		_check(world.get(actor.state_key(),{}).get("talks",-1)==1,"all durable NPC world projections agree before cold continuation")
	await _shot("write-accepted")
	_completed=true
	_save_report()
func _continue()->void:
	DirAccess.make_dir_recursive_absolute(out)
	var expected:Dictionary=JSON.parse_string(FileAccess.get_file_as_string(_save_dir.path_join("expect.json")))
	_check(FileAccess.get_sha256(_save_dir.path_join("slot.json"))==expected["sha256"],"cold reader starts with the exact frozen writer bytes")
	await _press_continue(_target_area())
	_check(await _until(func()->bool:return not get_tree().paused and not GameplayLock.is_locked() and not bool(_main.call("_route_pending"))),"cold continuation releases the actual transition")
	_check(GameState.has_flag(StringName(TARGETS[target][1])) and Story.progress_snapshot().has(StringName(TARGETS[target][0])),"cold Main restores the genuine completed objective and reading")
	_check(_actor()!=null and _actor().talk_count==1,"cold actual NPC retains exactly one settled conversation")
	await _shot("continued")
	_completed=true
	_save_report()
func _save_report()->void:
	var file:=FileAccess.open(out.path_join("result.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"completed":_completed,"checks":checks,"failures":_failures,"target":target,"observations":observations,"rows":rows,"scope":"real Main, actual authored NPC/object and public interact/confirmation; new game then explicit public area route and player positioning, no target flags/items/completion injection; not human full chapter"},"\t"))

func _readable_first_line() -> bool:
	if Story._current_cinematic!=StringName(TARGETS[target][0]):return false
	if target == "ch1_egret":
		return Story._player != null and Story._player._actors.has(&"rin") and Story._player._actors.has(&"egret") and Story._player._dialogue.visible and Story._player._dialogue.is_complete() and not Story._player._dialogue._text.text.is_empty()
	return Story._layer != null and Story._layer._cinematic_root.visible and Story._layer._text.get_total_character_count()>0 and (Story._layer._text.visible_characters<0 or Story._layer._text.visible_characters>=Story._layer._text.get_total_character_count())

func _target_area() -> String:
	return "res://data/levels/ch1_pawnshop_dawn.tres" if at_dawn and target!="ch1_egret" else TARGETS[target][2]
