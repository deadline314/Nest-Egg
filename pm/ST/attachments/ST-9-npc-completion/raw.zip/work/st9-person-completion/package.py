from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil,re
root=Path.cwd();w=root/'work/st9-person-completion';native=Path('/workspace/Nest-Egg/work/batch1020b');out=root/'pm/ST/attachments/ST-9-npc-completion';sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((w/'integration-receipt.json').read_text());assert r['exit_code']==0;base=r['base']
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
for p,h in json.loads((w/'integration-native-frozen-source.json').read_text())['sha256'].items():assert sha((root/p).read_bytes())==h,p
first=json.loads((w/'first-native-v1/native-receipt.json').read_text());rows=json.loads((w/'integration-native-receipt.json').read_text());race=json.loads((w/'integration-race-receipt.json').read_text());assert len(first)==10 and len(rows)==12
mid=json.loads((w/'integration-mid-receipt.json').read_text());assert len(mid)==2
for x in first+rows+[race]+mid:assert x['exit_code']==0 and x['engine_errors']==0 and x['leaks']==0,x['name']
view=json.loads((w/'viewed-integrated.json').read_text());assert view['individually_viewed'] and len(view['files'])==30
assert all('st9-1023-npc-camerafix-'+base[:8]+'-' in x['file'] for x in view['files'])
for x in view['files']:assert sha(Path(x['file']).read_bytes())==x['sha256']
assert json.loads((w/'compiler-scope.json').read_text())['only_five_policy_annotations_changed']
assert json.loads((w/'original-test-reconstruction.json').read_text())['run_save_original_byte_exact']
harness=['tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh','tests/known_failures.txt']
for p in harness:assert (root/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p]),p
files={}
for p in w.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in part or part=='__pycache__' for part in p.relative_to(w).parts):files['work/st9-person-completion/'+str(p.relative_to(w))]=p.read_bytes()
for p in native.glob('st9-1023-npc-*'):
 if 'profile' in p.name:continue
 if p.is_dir():
  for f in p.rglob('*'):
   if f.is_file():files['native/'+str(f.relative_to(native))]=f.read_bytes()
 elif p.is_file():files['native/'+p.name]=p.read_bytes()
refs=root/'pm/Nest-Egg/attachments/NE-278-references'
for name in ['ghost-song.webp','blasphemous2.jpg','sources.json']:files['references/'+name]=(refs/name).read_bytes()
paths=list(json.loads((w/'verification-frozen-source.json').read_text()))+list(json.loads((w/'integration-native-frozen-source.json').read_text())['sha256'])+harness+['design/20-campaign-experience/NPC_TERMINAL_COMPLETION.md']
for p in paths:files['source/final/'+p]=(root/p).read_bytes()
for p in ['game/npc/npc_actor.gd','game/story_result_completion.gd','data/story/ch1_kasa.json','tools/story/ch1_runtime_backend.py','tests/suite/test_npc.gd','tests/suite/test_run_save.gd','game/level/level_camera.gd']:files['source/before/'+p]=subprocess.check_output(['git','show',base+':'+p])
t=(w/'integration.log').read_text();summary=[x for x in t.splitlines() if x.startswith('checks:')][-1];assert 'new failures: 0' in summary
validation={'base':base,'camera_control':json.loads((w/'camera-control-receipt.json').read_text()),'camera_scope':'prior15 programs245/0 functional checks but native mid-reading viewport wrong; partial61 test stopped at197.97s, not a passed run.18/1->18/0 samefrozenfile, force-scroll-only diagnostic holds pause/request/count. Newcamera force_update_scroll at snap preserves all ordinary camera timing. Final native adds actual player inside viewport assertion; all15 programs replayed with fixedcamera before final61 replay.', 'affected':r,'summary':summary,'initial_original_negative':json.loads((w/'negative-receipt.json').read_text()),'negative_scope':'actual unmodified ad8 production:14checks/5failures,0engineERROR/0SCRIPTERROR after two invalid probe preflights retained','repair_control':json.loads((w/'repair-control-receipt.json').read_text()),'repair_scope':'611/3 ->611/0 actual unrelated required-item repair control; final adds one stricter UI assertion to offer original reload for uncommitted repair, total66 added checks', 'activation_control':json.loads((w/'durable-control-receipt.json').read_text()),'activation_scope':'disable only five generated annotations, keep current actor/owner and exact original tests.first578/8 ->594/0, final586/8 ->606/0 after additional resume admission checks; negative failed retry precondition skips invalid retry and success-only checks, not a predicate relaxation in positive path','additional_formal_checks':66,'original_test_reconstruction':json.loads((w/'original-test-reconstruction.json').read_text()),'first_native':first,'first_native_scope':'165/0;20PNG all viewed; egret reading was before actors and labels partly typing, no visual acceptance inferred','integrated_native':rows,'source_removed':race,'mid_read':json.loads((w/'integration-mid-receipt.json').read_text()),'mid_read_negative':json.loads((w/'mid-control-receipt.json').read_text()),'mid_read_fixed':json.loads((w/'mid-fixed-receipt.json').read_text()),'viewed':view,'harness_unchanged':harness,'scope':'Main/Level PAUSABLE; observer ALWAYS. Forward+ HDR llvmpipe software Vulkan, Dummy audio. New game then declared public area route and player position; dinner prerequisite alone injected for egret, never target flags/completion. Canonical actors, public inputs, actual temp-directory IO refusal and independent process cold readers with exact frozen-writer SHA. Source-removal case explicitly queues actual actor at real PRIMARY_COMMITTED hook. First five terminal sources only, no human/physical controller/GPU/full campaign, no general atomic_v1/choices/continuations/reward-bearing NPC acceptance.'}
out.mkdir(parents=True,exist_ok=True);(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for p,b in files.items():assert sha(z.read(p))==sha(b),p
m={'archive_bytes':(out/'raw.zip').stat().st_size,'archive_sha256':sha((out/'raw.zip').read_bytes()),'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
lookup={(x['target'],x['dawn'],x['mode']):x['name'] for x in rows}
for target,dawn,mode,frame,label in [('ch1_label_guitar',False,'write','reading','label'),('ch1_label_watch',False,'write','write-refused','retry'),('ch1_egret',False,'write','reading','brief'),('ch1_label_watch',True,'continue','continued','dawn')]:shutil.copyfile(native/lookup[(target,dawn,mode)]/(frame+'.png'),root/('pm/ST/images/ST-9-npc-'+label+'.png'))
shutil.copyfile(native/race['name']/'committed-source-removed.png',root/'pm/ST/images/ST-9-npc-committed-recovery.png')
for file in ['ghost-song.webp','blasphemous2.jpg']:shutil.copyfile(refs/file,root/('pm/ST/images/ST-9-npc-ref-'+file))
receipt={'entries':len(files),'bytes':m['archive_bytes'],'sha256':m['archive_sha256']};(w/'package-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
