import sys,os,json,subprocess,hashlib,shutil,re
from pathlib import Path
root=Path.cwd();out=root/'work/skip-save/captures-flushed';out.mkdir();cases=[]
for mode in ['skip','cancel','read']:
 slot=out/(mode+'-slot');slot.mkdir()
 seed=None
 if mode=='read':
  seed=(root/'work/skip-save/final-matrix/skip-slot/result-primary.json').read_bytes();(slot/'slot.json').write_bytes(seed)
 env=os.environ.copy();env.update(XDG_DATA_HOME=str(out/(mode+'-profile')),APPDATA=str(out/(mode+'-profile')),LOCALAPPDATA=str(out/(mode+'-profile')))
 command=[sys.executable,'tools/comfyui/gpu_lock.py','--','xvfb-run','-a','-s','-screen 0 1280x720x24',os.environ['GODOT'],'--path',str(root),'--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','res://work/skip-save/capture.tscn','--','--mode='+mode,'--save-dir='+str(slot),'--out='+str(out/mode)]
 with (out/(mode+'.log')).open('w') as log:
  process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=process.wait(timeout=180)
  except subprocess.TimeoutExpired:
   import signal;os.killpg(process.pid,signal.SIGTERM);code=process.wait(timeout=10)
 result=json.loads((out/mode/'result.json').read_text()) if (out/mode/'result.json').exists() else {}
 bad=[line for line in (out/(mode+'.log')).read_text().splitlines() if re.search(r'^ERROR:|SCRIPT ERROR|^FAIL|leaked at exit|resources still in use',line)]
 cases.append({'mode':mode,'exit':code,'result':result,'diagnostics':bad,'seed_sha256':hashlib.sha256(seed).hexdigest() if seed else None,'command':command})
 (out/'receipt.json').write_text(json.dumps({'cases':cases},indent=2))
 print(mode,code,result,flush=True)
 if code or bad:raise SystemExit(1)
