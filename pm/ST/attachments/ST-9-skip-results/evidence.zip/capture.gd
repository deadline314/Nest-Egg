extends "res://tests/probes/skip_completion.gd"

func _shot(name: String) -> void:
	if name == "skip-refused" and _prompt() != null:
		var language := Story.language
		var scale := Settings.get_ui_text_scale()
		Settings.set_ui_text_scale(1.2)
		for lang: String in ["zh", "ja", "en"]:
			Story.language = lang
			_prompt().set_recovery(false)
			await _frames(3)
			var prompt := _prompt()
			_check(prompt.cancel_button.visible and prompt.retry_button.focus_next == prompt.cancel_button.get_path(), "skip retry/cancel focus is usable: " + lang)
			_check(prompt._message.get_visible_line_count() == prompt._message.get_line_count() and prompt._message.get_minimum_size().y <= prompt._message.size.y, "skip explanation fits enlarged text: " + lang)
			await super._shot("skip-prompt-" + lang)
			prompt.cancel_button.grab_focus()
			prompt.set_recovery(true)
			await _frames(2)
			_check(not prompt.cancel_button.visible and prompt.retry_button.has_focus(), "committed skip recovery restores its safe reload focus: " + lang)
			prompt.set_original_recovery()
			await _frames(2)
			_check(prompt.cancel_button.visible and prompt._message.get_visible_line_count() == prompt._message.get_line_count(), "original skip backup recovery remains readable and cancellable: " + lang)
		Story.language = language
		Settings.set_ui_text_scale(scale)
		_prompt().set_recovery(false)
	await super._shot(name)
