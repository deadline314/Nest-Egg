extends "res://tests/probes/training_completion.gd"

func _run() -> void:
	_main = load("res://game/main.gd").new()
	var store := RunSaveStore.new(_save_dir.path_join("slot.json"))
	_main.set("_run_store", store)
	add_child(_main)
	await _frames(8)
	_main.call("_on_start_requested", GameState.difficulties[1])
	for i in 600:
		if _level() != null and _level().is_initialized(): break
		await _frames(1)
	_check(_level() != null, "real Main initializes original prologue")
	if _level() == null: await _done(); return
	await _frames(90)
	await _finish_story()
	await _frames(8)
	_main.call("_save_run")
	_before = FileAccess.get_file_as_bytes(store.path)
	FileAccess.open(_save_dir.path_join("original-primary.json"), FileAccess.WRITE).store_buffer(_before)
	_check(not _before.is_empty() and not GameState.has_flag(&"ch1_prologue_skipped"), "real original primary has no skip result")
	_check(DirAccess.make_dir_absolute(store.path + ".tmp") == OK, "real IO obstruction created")
	var source := _level()
	var pause := InputEventAction.new()
	pause.action = &"pause"
	pause.pressed = true
	Input.parse_input_event(pause)
	await _frames(2)
	pause = InputEventAction.new()
	pause.action = &"pause"
	Input.parse_input_event(pause)
	await _frames(2)
	_check(source._pause_menu._root.visible, "actual pause action opens its menu")
	source._pause_menu._skip_button.pressed.emit()
	await _frames(2)
	_check(source._pause_menu._skip_confirm != null, "original short press asks for skip confirmation")
	source._pause_menu._confirm_skip()
	await _frames(8)
	_check(not GameState.has_flag(&"ch1_prologue_skipped") and not GameState.has_flag(&"ch1_prologue_exit"), "refused skip cannot publish skipped or exit results")
	_check(FileAccess.get_file_as_bytes(store.path) == _before, "refused skip leaves exact original primary")
	_check(_level() == source, "refused skip stays in original area")
	await _shot("skip-refused")
	DirAccess.remove_absolute(store.path + ".tmp")
	await _done()
