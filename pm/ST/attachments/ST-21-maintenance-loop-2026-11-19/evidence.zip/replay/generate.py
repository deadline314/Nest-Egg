from pathlib import Path
from shutil import copyfile
import sys

root = Path.cwd()
out = Path(__file__).resolve().parent / 'generated'
sys.path.insert(0, str(root / 'tools/level'))
import build_ch3

kit = build_ch3.kit
for key, name in (('LEVEL_DIR', 'levels'), ('NPC_DIR', 'npcs'), ('THEME_DIR', 'themes'),
                  ('PROP_DIR', 'props'), ('ENCOUNTER_DIR', 'encounters')):
    path = out / name
    path.mkdir(parents=True, exist_ok=True)
    setattr(kit, key, str(path))
copyfile(root / 'data/levels/ch3_layout_v2.json', out / 'levels/ch3_layout_v2.json')
build_ch3.main()
for name in ('ch3_plaza.tres', 'ch3_plaza_map.json', 'ch3_pump.tres', 'ch3_pump_map.json'):
    source = out / 'levels' / name
    assert source.is_file(), source
    if sys.argv[1:] == ['--apply']:
        copyfile(source, root / 'data/levels' / name)
    print(name, source.stat().st_size)
