from hashlib import sha256
from pathlib import Path
import json
import os
from shutil import copyfile
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
ci = root / 'work/ne178-ci-icons-20261119'
expected = json.loads((ci / 'result.json').read_bytes())['commit']
previous = json.loads((root / 'work/ne178-pawn-umbrella-20261119/integration/published-source.json').read_bytes())
paths = ['data/levels/ch3_plaza.tres', 'data/levels/ch3_plaza_map.json', 'data/levels/ch3_pump.tres',
         'data/levels/ch3_pump_map.json', 'data/scripts/credit_pile_data.gd', 'game/pickups/credit_pickup.gd',
         'data/props/credits_maintenance.tres', 'tests/suite/test_collectibles.gd', 'tools/level/build_ch3.py',
         'data/environment/scene_props/sluice_hall/sluice_hall__maintenance_locker.tres']


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


assert all(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree).decode().strip() == expected
           for tree in (root, shared))
previous['.github/workflows/tests.yml'] = sha(root / '.github/workflows/tests.yml')
source = previous | {name: sha(root / name) for name in paths}
integration = base / 'integration'
stage = sys.argv[1:] in (['--stage'], ['--restage'])
if stage:
    before = json.loads((integration / 'source.json').read_bytes()) if sys.argv[1:] == ['--restage'] else previous
    assert all(sha(shared / name) == digest for name, digest in before.items())
    assert all(name in before or not (shared / name).exists() for name in paths)
    for name in paths:
        copyfile(root / name, shared / name)
assert all(sha(shared / name) == digest for name, digest in source.items())
assert all(sha(root / name) == source[name] for name in paths)
integration.mkdir(exist_ok=True)
for name, data in (('source', source), ('paths', paths)):
    (integration / f'{name}.json').write_text(json.dumps(data, indent=2) + '\n')
if stage:
    print(f'{len(paths)} candidate inputs with {len(source)} matching source hashes')
    sys.exit(0)
out = base / 'official-final'
out.mkdir()
env = os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key] = str(base / 'official-final-profile' / key)
env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8', GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
           LOG_DIR=str(out / 'shards'), SHARDS='6')
command = ['C:/Program Files/Git/bin/bash.exe', '-c',
           f'python3() {{ python "$@"; }}; export -f python3; tools/run_tests_changed.sh {expected}']
(out / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
with (out / 'raw.log').open('wb') as log:
    completed = subprocess.run(command, cwd=shared, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1500)
lines = (out / 'raw.log').read_text(encoding='utf-8').splitlines()
result = {'exit': completed.returncode, 'errors': [line for line in lines if 'ERROR:' in line],
          'source_held': all(sha(shared / name) == digest for name, digest in source.items())
          and all(sha(root / name) == source[name] for name in paths)}
(out / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(result, '\n' + '\n'.join(lines[-10:]), flush=True)
assert result == {'exit': 0, 'errors': [], 'source_held': True}
