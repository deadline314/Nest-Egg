from pathlib import Path
from shutil import copyfile
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
prior = base.parent/'st19-cinematic-music-20261119'
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
guard = {p: hashlib.sha256((shared/p).read_bytes()).hexdigest() for p in ('tools/story/ch2_source.py','data/story/ch2_heron.json','data/npcs/ch2_ali_home.tres','game/main.gd')}
copyfile(base/'ali_probe.gd',shared/'work/ali_probe.gd')
scene = '[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/ali_probe.gd" id="1"]\n[node name="AliSoupProbe" type="Node"]\nscript=ExtResource("1")\n'
(shared/'work/ali_probe.tscn').write_text(scene,encoding='utf-8',newline='\n')
tag, *modes = sys.argv[1:]
for mode in modes:
    out = base/tag/mode
    out.mkdir(parents=True)
    (out/'slot').mkdir()
    original = base/tag/'leave/slot/slot.json' if mode=='cold' else prior/'candidate/cut_play/slot/slot.json'
    copyfile(original,out/'slot/slot.json')
    env = os.environ.copy()
    for name in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[name] = str(out/'profile'/name)
    cmd = [sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
           '--path',str(shared),'--audio-driver','WASAPI','--rendering-method','forward_plus',
           '--resolution','960x540','--position','32,32','--max-fps','60',
           'res://work/ali_probe.tscn','--','--mode='+mode,'--save-dir='+str(out/'slot'),'--out='+str(out)]
    (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result = subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    raw = (out/'raw.log').read_text(encoding='utf-8',errors='replace')
    receipt = {'mode':mode,'exit':result.returncode, 'source_held':all(hashlib.sha256((shared/name).read_bytes()).hexdigest()==digest for name,digest in guard.items()),
               'observed':[json.loads(s.removeprefix('ALI_SOUP ')) for s in raw.splitlines() if s.startswith('ALI_SOUP ')],
               'errors':[s for s in raw.splitlines() if 'ERROR:' in s or 'WARNING: [Cutscene' in s],
               'save_sha':hashlib.sha256((out/'slot/slot.json').read_bytes()).hexdigest()}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(receipt,flush=True)
    assert result.returncode==0 and not receipt['errors'] and receipt['source_held']
