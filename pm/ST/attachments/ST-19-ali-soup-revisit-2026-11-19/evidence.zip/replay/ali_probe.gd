extends "res://tools/ch1_flow_probe.gd"
## Actual Main and original NPC. Entering the kitchen directly and setting the visible-quest prerequisite are declared fixtures.

const KITCHEN := "res://data/levels/ch2_ali_home.tres"
const ALI := &"ch2_ali_home"
var _main: Node
var _slot := ""
var _mode := "leave"


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_slot = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_shots = {
		"ch2_t_s07_bowls:choice":"soup-choice", "ch2_t_s07_wash:choice":"dry-rack-choice",
		"ch2_t_s07_soup":"tasting", "ch2_t_s07_revisit":"revisit",
	}
	_main = load("res://game/main.gd").new()
	_main.set("_run_store",RunSaveStore.new(_slot.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(48)
	if _mode != "cold":
		GameState.set_flag(&"ch2_market_contact_done")
		_main.call("_on_area_requested",KITCHEN)
		await _settle(60)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.resource_path == KITCHEN, "the real Main loaded the kitchen")
	if _level == null or _level.data.resource_path != KITCHEN:
		_done({})
		return
	var npc := _object(ALI)
	_check(npc != null, "the original Ali node is present")
	if npc == null:
		_done({})
		return
	var source_modes := []
	Story.scene_started.connect(func(id: StringName, _mode_tag: StringName) -> void:
		source_modes.append(String(id))
		var player := _level.player
		print("STANCE ", id, " ground=",player.is_on_floor()," velocity=",player.velocity,
			" active=",player.interaction.active," pos=",player.global_position,
			" phone=",player.is_on_phone()," carry=",player.carry.is_holding()))
	var before := _receipt(npc)
	if _mode == "leave":
		_check(await _talk(ALI,["address"]), "the original offer accepts address-only")
		_check(GameState.has_flag(&"knows_ali_address"), "the original address fact is learned")
	elif _mode == "taste":
		_level.player.health.current -= 2
		_level.player.health.health_changed.emit(_level.player.health.current,_level.player.health.max_health)
		await _settle(60)
		before = _receipt(npc)
		_check(before["health"] < _level.player.health.max_health, "damaged-player fixture can detect healing")
		_check(await _talk(ALI,["wash","left"]), "the original dry-rack choice accepts the bowl action")
		_check(GameState.has_flag(&"sq1_soup_practice_done"), "the original bowl route finishes the soup")
	else:
		_check(await _talk(ALI), "the original Ali interaction can be reopened")
	await _settle(12)
	var after := _receipt(npc)
	_main.call("_save_run")
	if _mode == "cold":
		_capture("ali-room-cold")
	print("ALI_SOUP ", JSON.stringify({"before":before,"after":after,"scenes":source_modes}))
	_done({"before":before,"after":after,"scenes":source_modes})


func _receipt(npc: NpcActor) -> Dictionary:
	var quest := {}
	var catalog := QuestCatalog.new()
	catalog.load_story_sources(["res://data/story/ch2_heron.json"])
	for record: Dictionary in catalog.quests:
		if record["id"] == "sq1_ali_soup":
			quest = record
	var flags := {}
	for name: String in ["knows_ali_address","ch2_market_contact_done","ch2_ali_home_visit","sq1_soup_practice_done"]:
		flags[name] = GameState.has_flag(StringName(name))
	return {"flags":flags,"dispatch":String(Story.resolve_dispatch(npc.data.talks[0].scene)),
		"health":_level.player.health.current,"credits":Progression.credits,
		"quest":QuestCatalog.status(quest,flags) if not quest.is_empty() else ""}


func _done(record: Dictionary) -> void:
	record["failures"]=_failures
	FileAccess.open(_out_dir.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify(record,"  "))
	get_tree().quit(0 if _failures==0 else 1)
