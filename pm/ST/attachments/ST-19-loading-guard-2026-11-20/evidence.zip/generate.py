from pathlib import Path
import json
import subprocess
import sys

project = Path.cwd()
scope = Path(__file__).resolve().parent
generated = scope / "generated"
sys.path.insert(0, str(project / "tools/level"))
import build_ch2 as chapter

kit = chapter.kit
for name, relative in (("LEVEL_DIR","data/levels"), ("NPC_DIR","data/npcs"), ("PROP_DIR","data/props"),
                       ("ENCOUNTER_DIR","data/props"), ("THEME_DIR","data/environment/themes")):
    target = generated / relative
    target.mkdir(parents=True, exist_ok=True)
    setattr(kit, name, str(target))
kit.write_design = lambda areas: None
chapter.main()
outputs = ("data/levels/ch2_loading_map.json", "data/npcs/ch2_guard.tres")
for name in outputs:
    current = (project/name).read_bytes()
    original = subprocess.check_output(["git","show",f"37579e19:{name}"],cwd=project)
    candidate = (generated/name).read_bytes()
    assert current.replace(b"\r\n",b"\n")==original.replace(b"\r\n",b"\n") or current==candidate, name
    assert original!=candidate
    if name.endswith(".json"):
        encoded = json.loads(candidate)
        known = json.loads(original)
        additions = [item for item in encoded["props"] if item not in known["props"]]
        assert len(additions)==1
        assert additions == [{"id":"dock_warehouse__wrapped_pallets", "x":81, "y":35, "dx":6.4}]
        encoded["props"].remove(additions[0])
        assert encoded==known
    else:
        shown = candidate.decode()
        assert 'kind = 1' in shown and 'pose = &"rest"' in shown and 'rig_id = "ch2_patroller"' in shown
    (project/name).write_bytes(candidate)

