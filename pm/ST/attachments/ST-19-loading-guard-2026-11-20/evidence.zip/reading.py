from pathlib import Path
import json, os, re, subprocess, sys
ROOT=Path.cwd()
HERE=Path(__file__).resolve().parent
mode=sys.argv[1]
short={'baseline':['accepted'],'baseline-d':['accepted'],'root-recovered':['accepted'],'final':['accepted','accepted_read','cancel','cancel_read']}
phases=short[mode]
out=HERE/mode
out.mkdir()
godot=r'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
receipts={}
for stage in phases:
    profile=out/(stage+'-profile')
    profile.mkdir()
    env=os.environ.copy()
    env.update(APPDATA=str(profile),LOCALAPPDATA=str(profile),XDG_DATA_HOME=str(profile),XDG_CONFIG_HOME=str(profile))
    shot=out/stage
    slot=out/('accepted-slot' if stage.startswith('accepted') else 'cancel-slot')
    command=[sys.executable,str(ROOT/'tools/comfyui/gpu_lock.py'),'--',godot,'--path',str(ROOT),
             '--fixed-fps','60','--rendering-method','forward_plus','--rendering-driver','vulkan','--resolution','1280x720','res://tests/probes/ch2_reading_completion.tscn','--',
             '--mode=guard--'+stage,'--out='+str(shot),'--save-dir='+str(slot)]
    with (out/(stage+'.log')).open('wb') as log:
        proc=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    raw=(out/(stage+'.log')).read_text(encoding='utf-8',errors='replace')
    bad=[line for line in raw.splitlines() if re.search('SCRIPT ERROR|Parse Error|^ERROR:|^FAIL |leaked at exit|resources still in use',line)]
    result=(shot/'result.json')
    data=json.loads(result.read_bytes()) if result.is_file() else {}
    success=proc.returncode==0 and not bad and data.get('failures')==[] and data.get('checks',0)>0
    receipts[stage]={'success':success,'exit':proc.returncode,'errors':bad,'result':data,'command':command}
    (out/'receipt.json').write_text(json.dumps(receipts,indent=2)+'\n')
    print(stage,'PASS' if success else 'FAIL',data.get('checks'),bad,flush=True)
    if not success:
        sys.exit(1)




