extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const LOADING := preload("res://data/levels/ch2_loading.tres")
const BACKREST := preload("res://data/environment/scene_props/dock_warehouse/dock_warehouse__wrapped_pallets.tres")
var _out := ""
var _records: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://guard_rest_fixture.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Settings.set_brightness(0.5)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	var poses: Dictionary = RigLibrary.load_json(NpcAnimator.DATA_PATH)["poses"]
	DirAccess.make_dir_recursive_absolute(_out)
	for variant: String in ["stock","low-a","low-b","sit-support"]:
		if not await _measure(variant, poses):
			printerr("Loading guard preview failed: ",variant)
			get_tree().quit(1)
			return
	FileAccess.open(_out.path_join("preview.json"),FileAccess.WRITE).store_string(JSON.stringify({"pictures":_records,
		"rendering":RenderingServer.get_current_rendering_method(),"gpu":RenderingServer.get_video_adapter_name()},"  "))
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)


func _measure(variant: String, poses: Dictionary) -> bool:
	seed(190820)
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(LOADING)
	add_child(level)
	var guard: NpcActor
	for actor in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if actor is NpcActor and (actor as NpcActor).data.id == &"ch2_guard":
			guard = actor
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		if enemy is Enemy:
			enemy.queue_free()
	if guard == null or guard._actor != null or guard.cell != Vector2i(84,35):
		return false
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.limit_enabled = false
	camera.zoom = Vector2.ONE * 3.4
	camera.global_position = guard.global_position + Vector2(-3,-26)
	camera.reset_smoothing()
	camera.force_update_scroll()
	level.player.global_position = guard.global_position + Vector2(38,0)
	level.player.velocity = Vector2.ZERO
	level._lighting._lightning_gap = 1.0e9
	for node in level.find_children("*", "", true, false):
		if node is ChapterCard:
			node.queue_free()
	var original: Dictionary = poses["crouch"]
	var backrest: PropNode
	if variant != "stock":
		var use_support := variant == "sit-support"
		guard.data = guard.data.duplicate() as NpcData
		guard.data.rig_id = "ch2_patroller"
		guard.data.pose = &"sit" if use_support else &"squat"
		guard._build_visual()
		if guard._actor == null or guard._actor.rig == null:
			return false
		guard.set_physics_process(false)
		guard._actor.face(1)
		if not use_support:
			poses["crouch"] = {"hip_x": -1.0, "hip_y": 0, "feet": {"x":[0.83, 0.36], "sag": 0.87 if variant == "low-a" else 0.96},
				"bones":{"chest":-0.26, "neck": 0.10, "head":0.34, "arm_front_upper":-0.55, "arm_front_lower":-0.38,
					"arm_back_upper":0.18, "arm_back_lower":-0.35}}
		var contact := guard.global_position + Vector2(-11.0, 0.0)
		backrest = level._place_prop(BACKREST, contact - BACKREST.size, false)
	for tick in 42:
		await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var rc := Capture.image(get_viewport()).save_png(_out.path_join(variant+".png"))
	var meta := {"variant":variant,"guard_cell":str(guard.cell),"guard":str(guard.global_position)}
	if guard._actor != null:
		var parts := {}
		for bone in [&"chest",&"pelvis",&"head",&"foot_front",&"foot_back",&"hand_front"]:
			var joint := guard._actor.rig.bone(bone)
			if joint != null:
				var offset := joint.global_position - guard.global_position
				parts[str(bone)] = [offset.x,offset.y]
		meta["relative_joints"] = parts
	_records.append(meta)
	poses["crouch"] = original
	level.queue_free()
	await get_tree().process_frame
	return rc == OK
