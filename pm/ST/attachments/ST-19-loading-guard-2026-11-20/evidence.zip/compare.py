from math import dist
from pathlib import Path
import json

base = Path(__file__).resolve().parent
raw = json.loads((base/"actual/living.json").read_bytes())
assert raw["renderer"]=="forward_plus" and raw["hdr"] and "9070 XT" in raw["gpu"]
assert raw["guard_cell"] == [84,35] and raw["guard_kind"] == 1
assert abs(raw["backrest"]["bottom_error"])<0.001 and abs(raw["backrest"]["right_to_origin"]-5.5)<0.01
rows=raw["rows"]
assert len(rows)==24 and sum(row["side"]<0 for row in rows)==12 and sum(row["side"]>0 for row in rows)==12
assert all(row["pose"]=="rest" and row["near"] and row["face"]==1 and not row["listening"] and not row["observed"] for row in rows)
chest=[row["chest_radians"] for row in rows]
assert max(chest)-min(chest) > 0.03
settled=[row for row in rows if row["frame"]>=40]
feet=settled[0]["feet"]
max_after=max(dist(point[:2], feet[i][:2]) for row in settled for i, point in enumerate(row["feet"]))
assert max_after < 0.005 and max(abs(point[2]) for row in settled for point in row["feet"])<1e-5
reading=json.loads((base/"final/receipt.json").read_bytes())
assert set(reading)=={"accepted","accepted_read","cancel","cancel_read"}
assert all(item["success"] and item["exit"]==0 and not item["errors"] and item["result"]["checks"]>0 for item in reading.values())
report = {"samples": len(rows), "settled_samples":len(settled), "ankle_motion_max":max_after,
          "breathing_angle_span_radians":max(chest)-min(chest), "scenario_checks":sum(item["result"]["checks"] for item in reading.values()),
          "guard_cell":raw["guard_cell"],"peak":max(chest),"trough":min(chest)}
(base/"visibility-checks.json").write_text(json.dumps(report,indent=2)+"\n")
print(report)
