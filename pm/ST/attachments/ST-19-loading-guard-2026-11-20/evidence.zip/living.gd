extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const LOADING := preload("res://data/levels/ch2_loading.tres")
var _out := ""
var _records: Array[Dictionary] = []


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	add_child(LightKit.create_environment())
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://live_loading_guard.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Settings.set_brightness(0.5)
	Settings.set_reduce_flashes(true)
	Story.auto_skip = true
	Story._layer.visible = false
	for id in Story.scene_ids():
		Story._seen[StringName(id)] = true
	DirAccess.make_dir_recursive_absolute(_out)
	seed(190820)
	GameState.start_new_run(GameState.difficulties[1])
	var level := Level.new()
	level.configure(LOADING)
	add_child(level)
	var guard: NpcActor
	for actor in level._entities.get_children():
		if actor is NpcActor and actor.data.id == &"ch2_guard":
			guard = actor
	if guard == null or guard._actor == null or guard._actor.rig == null:
		printerr("Missing authored loading-bay guard")
		get_tree().quit(1)
		return
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		if enemy is Enemy:
			enemy.queue_free()
	for node in level.find_children("*", "", true, false):
		if node is ChapterCard:
			node.queue_free()
	var contact := _backrest(level, guard)
	var camera := get_viewport().get_camera_2d() as LevelCamera
	camera.set_physics_process(false)
	camera.position_smoothing_enabled = false
	camera.limit_enabled = false
	camera.global_position = guard.global_position + Vector2(-3,-26)
	level._lighting._lightning_gap = 1.0e9
	for side: int in [-1, 1]:
		level.player.global_position = guard.global_position + Vector2(side * 35, 0)
		level.player.velocity = Vector2.ZERO
		AimInput.set_virtual_gamepad(level.player, true)
		camera.zoom = Vector2.ONE * (LevelCamera.base_zoom() if side < 0 else 3.4)
		camera.reset_smoothing()
		camera.force_update_scroll()
		for frame in 190:
			await get_tree().process_frame
			if frame % 15 == 10:
				_sample(guard, side, frame)
			if frame in [25, 85, 145]:
				await RenderingServer.frame_post_draw
				var image := Capture.image(get_viewport())
				image.save_png(_out.path_join("%d_%d.png" % [side,frame]))
		if guard._actor.facing != 1 or guard.awareness != null or guard._actor._input.listening or GameState.has_flag(&"ch2_guard_seen"):
			printerr("The real guard reacted or a visit finished the reading")
			get_tree().quit(1)
			return
	var receipt := {"gpu":RenderingServer.get_video_adapter_name(),"renderer":RenderingServer.get_current_rendering_method(),
		"hdr":get_viewport().use_hdr_2d, "guard_cell":[guard.cell.x,guard.cell.y],"guard_kind":guard.data.kind,
		"backrest":contact,"rows":_records}
	var file := FileAccess.open(_out.path_join("living.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(receipt,"  ") + "\n")
	file.close()
	level.queue_free()
	await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	get_tree().quit(0)


func _backrest(level: Level, guard: NpcActor) -> Dictionary:
	for node in level.find_children("*", "PropNode", true, false):
		var pallet := node as PropNode
		if pallet.data.id == &"dock_warehouse__wrapped_pallets" and absf(pallet.global_position.x - guard.global_position.x) < 52.0:
			var end := pallet.global_position + pallet.data.size
			return {"bottom_error":end.y-guard.global_position.y,"right_to_origin":guard.global_position.x-end.x,
				"width":pallet.data.size.x,"height":pallet.data.size.y}
	return {}


func _sample(guard: NpcActor, side: int, frame: int) -> void:
	var rig := guard._actor.rig
	var feet: Array[Array] = []
	for joint in [&"foot_front", &"foot_back"]:
		var foot := rig.bone(joint)
		var point := foot.global_position - guard.global_position
		feet.append([point.x,point.y,foot.global_rotation])
	var head := rig.bone(&"head").global_position - guard.global_position
	var hip := rig.bone(&"hip").global_position - guard.global_position
	_records.append({"side":side,"frame":frame,"pose":String(guard._actor.pose),"face":guard._actor.facing,
		"chest_radians":rig.bone(&"chest").rotation,"hip":[hip.x,hip.y],"head":[head.x,head.y],
		"feet":feet,"listening":guard._actor._input.listening,"near":guard._player_in_range,
		"observed":GameState.has_flag(&"ch2_guard_seen")})
