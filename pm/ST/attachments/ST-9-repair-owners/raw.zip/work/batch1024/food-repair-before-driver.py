from pathlib import Path
import subprocess,os,json,hashlib,re,signal,time
w=Path('work/batch1024');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
world=(w/'world-repair-before-headless.log').read_text();assert 'QUEST_RESUME mode=write failures=3' in world and 'SCRIPT ERROR:' not in world
sources=['game/world_item_completion.gd','game/story_result_completion.gd','work/batch1024/world-repair-probe.gd','work/batch1024/food-repair-probe.gd']
record=lambda name,t,code:{'name':name,'exit':code,'checks':len(re.findall('^PASS |^FAIL ',t,re.M)),'failures':len(re.findall('^FAIL ',t,re.M)),'engine_errors':t.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',t)),'source_sha256':{p:sha(p) for p in sources},'scope':'Headless actual Main/readers/buttons on b45+frozen5NE228WIP, not native GPU/window. No product changes for recovery cases.'}
(w/'world-repair-before-receipt.json').write_text(json.dumps(record('world',world,1),indent=2))
flag=w/'world-repair-headless-running';flag.write_text('Own food repair actual Main HEADLESS baseline; parent owns GPU lock. Finally removes marker after engine process exits.\n')
cmd=['python','tools/comfyui/gpu_lock.py','--',str(Path('work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64').resolve()),'--headless','--path',str(Path.cwd()),'res://work/batch1024/food-repair-probe.tscn','--','--mode=write','--save-dir='+str((w/'food-repair-before-save').resolve()),'--out='+str((w/'food-repair-before-out').resolve())];start=time.monotonic()
try:
 with (w/'food-repair-before-headless.log').open('w') as f:
  child=subprocess.Popen(cmd,env={**os.environ,'XDG_DATA_HOME':str((w/'food-repair-before-profile').resolve())},stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=240)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGTERM);code=child.wait(timeout=10)
 t=(w/'food-repair-before-headless.log').read_text();rec=record('food',t,code);rec.update(command=cmd,seconds=time.monotonic()-start);(w/'food-repair-before-receipt.json').write_text(json.dumps(rec,indent=2));print(json.dumps(rec),flush=True)
finally:flag.unlink(missing_ok=True)
