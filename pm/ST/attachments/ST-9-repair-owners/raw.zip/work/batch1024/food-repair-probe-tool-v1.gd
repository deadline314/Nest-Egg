extends "res://work/batch1024/world-pickup-historical-base.gd"
## Actual authored dinner bubble chain; unrelated malformed disk custody only.
const FOOD := &"ch1_b_dinner_food"
var _old_primary := PackedByteArray()
var _original_credits := 0

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	await _until(func() -> bool: return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested", GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE), "real Main starts the actual prologue")
	await _skip_cinematics()
	GameState.set_flag(&"ch1_prologue_exit") # Declared route arrangement only.
	await _enter(PAWNSHOP)
	_check(await _until(func() -> bool: return not (Story._passive_requests.get(FOOD, []) as Array).is_empty(), 90), "authored dinner chain reaches its actual food reader")
	_check(not GameState.has_flag(&"ch1_dinner_done") and not Story.progress_snapshot().has(FOOD), "dinner completion was never injected or precompleted")
	_main.call("_save_run")
	_main.call("_flush_save")
	_old_primary = FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json"))
	_original_credits = Progression.credits
	_check(not _old_primary.is_empty() and not StoryItems.holds(&"ch1_data_disk"), "actual original slot predates the unrelated corruption")
	GameState.world_flags[&"ledger_disk_obtained"] = true # Explicit unrelated owner corruption.
	var owner: Node = _main.get("_result_completion")
	_check(await _until(func() -> bool: return is_instance_valid(owner.get("_prompt")), 90), "real food reader completion opens the refused-write prompt")
	_check(not GameState.has_flag(&"ch1_dinner_done") and not Story.progress_snapshot().has(FOOD) and not StoryItems.holds(&"ch1_data_disk") and Progression.credits == _original_credits, "refusal publishes neither dinner nor unrelated inventory repair")
	_check(FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json")) == _old_primary, "nonNPC terminal refusal preserves the exact original slot")
	_check(bool(owner.get("_reload_original")) and not bool(owner.get("_recovery")), "uncommitted nonNPC terminal repair offers loading original progress")
	await _shot("food-repair-refused")
	_check(await _until(func() -> bool: return is_instance_valid(owner.get("_prompt")) and get_viewport().gui_get_focus_owner() == owner.get("_prompt").retry_button, 5), "real recovery button owns focus before public confirmation")
	var previous_level := _level().get_instance_id()
	await _press(&"ui_accept")
	var restored := await _until(func() -> bool: return _level() != null and _level().get_instance_id() != previous_level and not bool(_main.call("_route_pending")) and not get_tree().paused, 45)
	_check(restored and not GameState.has_flag(&"ledger_disk_obtained") and not StoryItems.holds(&"ch1_data_disk") and Progression.credits == _original_credits, "public original reload removes only the malformed live repair candidate")
	_check(restored and not GameplayLock.is_locked() and not Story.progress_snapshot().has(FOOD), "original reload releases the refusal lock and keeps dinner unread")
	await _shot("food-original-reloaded")
	_completed = true

func _shot(label: String) -> void:
	await _settle(2)
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		var captured := preload("res://work/batch1024/window_capture.gd").image(get_window())
		_check(captured != null and captured.save_png(out.path_join(label + ".png")) == OK, "actual native window capture " + label)
	var f := FileAccess.open(out.path_join("food-repair-result.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"failures": _failures, "label": label, "original_credits": _original_credits, "credits": Progression.credits, "dinner": GameState.has_flag(&"ch1_dinner_done"), "seen": Story.progress_snapshot().has(FOOD), "held_disk": StoryItems.holds(&"ch1_data_disk"), "ledger": GameState.has_flag(&"ledger_disk_obtained"), "scope": "ActualMainPAUSABLE observerALWAYS. Onlyprologueexit and entryroute arranged; actual authored bubblechain naturalreading timers. Only unrelated ledger flag malformed after old save; no dinner result/flag injection. Not human fullchapter/hardware."}, "  "))
