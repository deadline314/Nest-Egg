from pathlib import Path
import hashlib,json,zipfile,subprocess,re,shutil
w=Path('work/batch1024'); n=Path('work/batch1020b'); out=Path('pm/ST/attachments/ST-9-repair-owners');out.mkdir(exist_ok=True)
frozen=json.loads((w/'owners-final-source.json').read_text())
for p,h in frozen.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
base=json.loads((w/'owners-merged-base.json').read_text())['head']
original=subprocess.check_output(['git','show',base+':tests/suite/test_run_save.gd'])
rebuilt=Path('tests/suite/test_run_save.gd').read_text()
for name in ['world_item','terminal']:
 rebuilt=rebuilt.replace('\n\tawait preload("res://tests/helpers/'+name+'_repair_boundary_checks.gd").run(self, directory)','')
assert rebuilt.encode()==original,'Original RunSave suite changed'
console=(w/'owners-changed-merged-console.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',console);assert m
changed=dict(zip(['checks','new_failures','known_failures','seconds'],map(int,m.groups())));assert changed['new_failures']==changed['known_failures']==0
before=json.loads((w/'owners-native-before.json').read_text()); after=json.loads((w/'owners-native-after-merged.json').read_text())
assert len(before)==len(after)==2
for rows, failures, code in [(before,3,1),(after,0,0)]:
 for row in rows:assert row['completed'] and row['failures']==failures and row['exit']==code and row['engine_errors']==row['leaks']==0
ci=json.loads((w/'ci-4f164615-final.json').read_text());assert ci['conclusion']=='success'
receipt={'base':base,'formal_negative':{'checks':625,'failures':2},'formal_after':{'checks':625,'failures':0},'changed':changed,'native_before':before,'native_after':after,'original_run_save_assertions_inputs_waits_byte_identical':True,'source_sha256':frozen,'prior_ci':ci,'limits':['Only original whole-run reload routing added; no generic atomic coordinator enabled. Original unfinished ticket criteria preserved.','Before native used f5469ea3 owners; first after used f50882e9, merged after uses latest4f164615. Fourteen focused owner/probe sources remain byte-identical; actual merged native flows and seven suites rerun.','Actual authored pickup sensor and actual authored dinner trigger/reader chain; explicit route/player/nonlethal fixtures and unrelated malformed owner after valid original save. No target acquisition/completion injection.','Event/pickup refusal backgrounds intentionally opaque in original production UI; do not treat them as evidence of visible actor art.','Actual Main PAUSABLE under observerALWAYS; public ui_accept and real disk/reader restore. Native Chinese 1280x720 only, software Vulkan Forward+, Dummy audio. No human full-chapter or physical hardware claim.','Initial food trigger preflight did not reach source, preserved as tool failure rather than a product negative.']}
(out/'validation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
files={}
def add(p,arc=None):
 p=Path(p);assert p.is_file(),p;files[arc or str(p)]=p.read_bytes()
for p in frozen:add(p,'source/final/'+p)
for p in ['game/world_item_completion.gd','game/story_result_completion.gd','tests/suite/test_run_save.gd']:
 files['source/before/'+p]=subprocess.check_output(['git','show','f5469ea3:'+p])
for pattern in ['owners-*','world-repair-*','food-repair-*','world-pickup-historical-base.gd','window_capture.gd','native-large.py','package-owners.py','next-repair-proposed.json','ci-f508*','ci-4f164615*']:
 for p in w.glob(pattern):
  if p.is_file():add(p)
for p in (w/'owners-changed-merged').glob('*.log'):add(p)
for phase in ['before','after','after-merged']:
 for case in ['world','food']:
  name='st9-1024-owners-'+case+'-'+phase
  for suffix in ['.log','.exit','-xvfb.log']:add(n/(name+suffix))
  for p in (n/name).glob('*'):
   if p.is_file():add(p)
  for p in (w/(name+'-save')).glob('*'):
   if p.is_file():add(p)
  source='world-item-repair-refused' if case=='world' else 'food-repair-refused'
  if phase in ['before','after-merged']:
   shutil.copyfile(n/name/(source+'.png'),Path('pm/ST/images')/('ST-9-'+case+'-repair-'+('after' if phase=='after-merged' else phase)+'.png'))
for p in ['work/batch1020b/st9-1024-owners-world-after-merged/world-item-original-reloaded.png','work/batch1020b/st9-1024-owners-food-after-merged/food-original-reloaded.png']:
 name='ST-9-world-original-reloaded.png' if 'world-after-merged' in p else 'ST-9-food-original-reloaded.png'
 shutil.copyfile(p,Path('pm/ST/images')/name)
add(out/'validation.json')
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(out/'raw.zip') as z:
 for name,m in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==m['sha256'],name
h=hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest()
(out/'README.md').write_text(f'''# ST-9：拾取與非NPC事件修復拒寫後載入原進度

先讀User-guide，沿用[通訊修復的保存與同類作品參照](../ST-9-radio-repair/README.md)，重新核對Ghost Song／Hollow Knight等實圖的文字層次與返回原流程；圖片不證明保存時序或玩家民調。本次不改底板、字型、故事台詞或正常保存規則，只把真正無法直接重試的整輪修復拒寫導向原Main讀取流程。

[全部原檔](raw.zip)、[逐檔SHA](manifest.json)、[完整收據](validation.json)。新增12項，原RunSaveSuite所有原斷言、輸入、等待逐位元重建相同，原runner／selector／filters／known failures保持。

| 相同情境 | 修前 | 修後 |
|---|---|---|
| 真writer原RunSave＋12項 | 625項／2失敗 | 625項／0失敗 |
| 真Main正式保險箱資料盤，原生 | 15項／3失敗 | 15項／0失敗 |
| 真Main正式晚飯觸發與自然reader，原生 | 17項／3失敗 | 17項／0失敗 |

最終原選擇器，固定基準4f164615：七組{changed['checks']}項／0新／已知失敗，{changed['seconds']}秒。包含合入後的新載具順序控制與原存檔流程。原625／0在f546完成；同一來源雜湊在4f164615新main上重新跑七組及兩條原生恢復，沒有用舊結果代稱合併結果。前一票完整[CI{ci['run_id']}](https://github.com/deadline314/Nest-Egg/actions/runs/{ci['run_id']})實際{ci['checks']:,}項／0新／已知失敗，{ci['seconds']}秒；完整原job一併保存。本票推送後的新CI另行核對。

四輪原生exit1、1、0、0，全部0引擎ERROR、0退出洩漏診斷。修前四張與修後四張真正1280×720視窗PNG逐張檢視並留SHA。拒寫卡用原產品不透明event／pickup底板；不是空世界缺陷，也不能當人物或關節驗收。修後恢復圖則是真Main重新建立的保險箱區與當舖，原資料盤／晚飯尚未完成，原錢包與進度恢復，原鎖清除。

拾取控制明示路線前提、玩家位置、非致命floor1；取得資料盤的感應器與玩家是真正來源，沒有注入資料盤或取得旗標。先有有效原slot，再只把無關live錢包設為-1。晚飯控制只安排序章出口及玩家跨過真正地圖觸發位置；自然原對話鏈抵達food reader，保存有效原slot後只把無關ledger旗標設成缺少持盤的舊狀態，沒有預先完成晚飯。兩種拒寫都保留精確原磁碟與live狀態、不先發新結果；公開確認按鈕後由Main原reader還原整輪，不私自逐owner修補。writer單元測試與原生來源驗證分開。

第一個晚飯探針沒有跨過真觸發點，卡在工具前置，原source／log／tool_preflight_failed收據保留；不列為產品負控制。原本不透明底板觀察、原生前後、編輯器匯入、625項修前修後及最終七組全log均保留。Before以f546來源，首次after接上f508，最終after-merged接上4f164615的延後停頓修正並重跑32項原生與七組；兩個保存owner原始SHA及十四個最終關注來源逐一核對，沒有把三者說成完全同一checkout。

軟體Vulkan Forward+、Dummy音訊與合成輸入，不代稱實體GPU、手把、真人整章、其他語言原生驗收、通用atomic coordinator或整票完成。原三項整票條件保持未勾。

原檔{len(files)}項、{(out/'raw.zip').stat().st_size:,} bytes；zip SHA `{h}`，逐項解出核對SHA。
''')
p=Path('design/20-campaign-experience/WORLD_ITEM_COMPLETION.md');p.write_text(p.read_text()+'''\n## 2026-10-24：完整進度修復的恢復入口\n\n整輪正規化若發現與當前owner不同，仍須拒絕、保留原物件與live／disk bytes、不發布取得。這不是一般可直接重試的I/O失敗；未提交提示須提供載入原進度，經Main既有整輪reader恢復。兩處全輪修復拒絕採同一原進度政策，原放回／重新進範圍與已提交恢復政策保持。\n\n真正保險箱sensor控制只在有效原slot後製造無關錢包-1，資料盤與取得旗標不注入；修前原生15／3、修後15／0，公開確認後真Main重建Level、恢復原錢包，資料盤仍未取得且鎖釋放。[全部控制及界線](../../pm/ST/attachments/ST-9-repair-owners/README.md)。\n''')
p=Path('design/20-campaign-experience/NPC_TERMINAL_COMPLETION.md');p.write_text(p.read_text()+'''\n## 2026-10-24：非NPC結果的全輪修復拒寫\n\n需要全輪修復的非NPC末段結果也須載入原進度；不能因沒有NPC欄位就只留下不可能成功的重試。共用結果邊界保持不寫、不安裝、不發布，真正恢復仍由Main整輪reader負責。正常完成、NPC交談次數與已提交恢復不變。\n\n正式當舖地圖觸發自然晚飯鏈抵達真正food reader，先保存有效slot才製造無關缺盤旗標；沒有注入晚飯完成。原生17／3→17／0，公開按鈕後原slot重建關卡、清除舊鎖且晚飯未讀。[原檔與範圍](../../pm/ST/attachments/ST-9-repair-owners/README.md)。\n''')
p=Path('pm/ST/[ST-9]把第一章劇本接進遊戲.md');s=p.read_text();assert '# Commit-15' not in s;s+=f'''\n\n# Commit-15\n\n## 內文\n\n拾取物與沒有交談對象的劇情末段，在需要修復完整進度時，原本仍只提供無法成功的重試。現在可明確載入原進度；拒寫前後不先發物品、獎勵或完成旗標，恢復後保留原進度與未完成來源，解除暫停與舊提示。\n\n### 測試結果\n\n| 項目 | 結果 |\n|---|---|\n| 真磁碟writer原回歸＋12項 | 625／2失敗→625／0 |\n| 七組受影響回歸，最新main合併結果 | {changed['checks']}項／0新／已知失敗，{changed['seconds']}秒 |\n| 正式Main實際資料盤 | 原生15／3失敗→15／0 |\n| 正式Main自然晚飯鏈 | 原生17／3失敗→17／0 |\n\n四輪原生均0引擎錯誤及退出洩漏，八張圖逐張檢視。前置失敗、明示路線安排、非致命下限及舊狀態控制完整保存；不以局部通過代勾通用故事結果條件。[設計、同類作品、完整原檔與驗證界線](attachments/ST-9-repair-owners/README.md)。\n\n### 實際恢復提示\n\n| 實際資料盤 | 正式晚飯末段 |\n|---|---|\n| ![資料盤恢復](images/ST-9-world-repair-after.png) | ![晚飯恢復](images/ST-9-food-repair-after.png) |\n\n![載入原進度後回到當舖](images/ST-9-food-original-reloaded.png)\n''';p.write_text(s)
p=Path('pm/user_guide.md');p.write_text(f'2026-10-24（ST-9）：拾取與非NPC末段的整輪修復拒寫也要提供原進度，不能留不可能成功的重試。真sensor與自然晚飯鏈原生32／6→32／0、writer625／2→625／0；[八圖、前置失敗、合併複驗與完整原檔](ST/attachments/ST-9-repair-owners/README.md)。原event／pickup不透明底板是既有設計，不能為了展示世界而隱藏；沒有代勾整票。前一票4f164615完整CI{ci["run_id"]}實際{ci["checks"]:,}項全過，並非取消後假稱綠燈。\n\n'+p.read_text())
print('PACKAGED',len(files),h);print(json.dumps(changed))
