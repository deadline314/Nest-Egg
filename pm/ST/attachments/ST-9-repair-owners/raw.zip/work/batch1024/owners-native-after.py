from pathlib import Path
import subprocess,os,json,hashlib,re,time
w=Path('work/batch1024');n=Path('work/batch1020b');sources=['game/world_item_completion.gd','game/story_result_completion.gd'];frozen={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sources};rows=[]
for case in ['world','food']:
 name='st9-1024-owners-'+case+'-after';probe='res://work/batch1024/'+case+'-repair-probe.tscn';cmd=['python',str(w/'native-large.py'),name,probe,'--mode=write','--save-dir='+str((w/(name+'-save')).resolve())];start=time.monotonic()
 with (w/(name+'-driver.log')).open('w') as f:r=subprocess.run(cmd,env={**os.environ,'NE_NATIVE_PROJECT':'../..'},stdout=f,stderr=subprocess.STDOUT,timeout=800)
 t=(n/(name+'.log')).read_text();rec={'name':name,'case':case,'exit':r.returncode,'checks':len(re.findall('^PASS |^FAIL ',t,re.M)),'failures':len(re.findall('^FAIL ',t,re.M)),'engine_errors':t.count('ERROR:'),'leaks':len(re.findall('leaked|still in use at exit|PagedAllocator',t)),'completed':'PASS the write mode ran to the end' in t,'seconds':time.monotonic()-start,'command':cmd,'source_sha256':frozen};rows.append(rec);(w/'owners-native-after.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rec),flush=True)
 assert rec['exit']==0 and rec['failures']==0 and rec['engine_errors']==0 and rec['leaks']==0 and rec['completed'],rec
 for p,h in frozen.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
print('BOTH_VALID_NATIVE_AFTER_CONTROLS_DONE',flush=True)
