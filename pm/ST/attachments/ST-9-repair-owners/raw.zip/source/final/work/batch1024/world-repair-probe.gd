extends "res://work/batch1024/world-pickup-historical-base.gd"
## Arranged authored vault pickup; malformed wallet only, never acquisition flags.
const VAULT := "res://data/levels/ch1_vault.tres"
var _old_primary := PackedByteArray()
var _original_credits := 0
var _acquired := 0

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	await _until(func() -> bool: return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested", GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE), "real Main starts the actual prologue")
	await _skip_cinematics()
	for flag in [&"ch1_prologue_exit", &"ch1_dinner_done", &"ch1_heard_brief", &"ch1_street_route_open", &"watchdog_defeated", &"ch1_flood_gate_open"]:
		GameState.set_flag(flag)
	await _enter(VAULT)
	await _read_to_end()
	var pickup: CollectiblePickup
	for node in _level().find_children("*", "", true, false):
		if node is CollectiblePickup and node.item.id == &"ch1_data_disk":
			pickup = node
	_check(pickup != null, "authored vault retains its real disk pickup")
	if pickup == null:
		return
	_check(not StoryItems.owns(&"ch1_data_disk") and not GameState.has_flag(&"ledger_disk_obtained"), "target item and acquisition flag were never injected")
	_main.call("_save_run")
	_main.call("_flush_save")
	_old_primary = FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json"))
	_original_credits = Progression.credits
	_check(not _old_primary.is_empty() and _original_credits >= 0, "unchanged valid old whole-run slot exists before corruption")
	# Explicit unrelated live-owner corruption. Normal read owns whole-run repair.
	Progression.credits = -1
	StoryItems.acquired.connect(func(item: StoryItemData) -> void:
		if item.id == &"ch1_data_disk":
			_acquired += 1)
	_level().player.health.floor_health = 1
	_level().player.global_position = pickup.global_position
	_level().player.velocity = Vector2.ZERO
	var owner: Node = _main.get("_world_item_completion")
	_check(await _until(func() -> bool: return is_instance_valid(owner.get("_prompt")), 20), "actual pickup sensor opens the real refused-write prompt")
	_check(not StoryItems.owns(&"ch1_data_disk") and not GameState.has_flag(&"ledger_disk_obtained") and is_instance_valid(pickup) and _acquired == 0, "whole-run repair refusal neither grants nor consumes the actual item")
	_check(Progression.credits == -1 and FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json")) == _old_primary, "refusal leaves both malformed live owner and exact old primary unchanged")
	_check(bool(owner.get("_reload_original")) and not bool(owner.get("_recovery")), "uncommitted pickup repair offers original progress rather than impossible retry")
	await _shot("world-item-repair-refused")
	_check(await _until(func() -> bool: return is_instance_valid(owner.get("_prompt")) and get_viewport().gui_get_focus_owner() == owner.get("_prompt").retry_button, 5), "real recovery button owns focus before public confirmation")
	var previous_level := _level().get_instance_id()
	await _press(&"ui_accept")
	var restored := await _until(func() -> bool: return _level() != null and _level().get_instance_id() != previous_level and not bool(_main.call("_route_pending")) and not get_tree().paused, 45)
	_check(restored and Progression.credits == _original_credits and not StoryItems.owns(&"ch1_data_disk") and not GameState.has_flag(&"ledger_disk_obtained"), "public reload restores the original wallet and unread unacquired source")
	_check(restored and not GameplayLock.is_locked(), "original progress releases the old recovery lock")
	await _shot("world-item-original-reloaded")
	_completed = true

func _shot(label: String) -> void:
	await _settle(2)
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		var captured := preload("res://work/batch1024/window_capture.gd").image(get_window())
		_check(captured != null and captured.save_png(out.path_join(label + ".png")) == OK, "actual native window capture " + label)
	var f := FileAccess.open(out.path_join("world-repair-result.json"), FileAccess.WRITE)
	f.store_string(JSON.stringify({"failures": _failures, "label": label, "original_credits": _original_credits, "credits": Progression.credits, "owned": StoryItems.owns(&"ch1_data_disk"), "flag": GameState.has_flag(&"ledger_disk_obtained"), "acquired": _acquired, "scope": "ActualMainPAUSABLE observerALWAYS. Route prerequisites and playerposition arranged; nonlethal floor1; only unrelated wallet corrupted to -1 after original save. No disk acquisition flag or item injection. Not human fullchapter/hardware."}, "  "))
