extends RefCounted

static func image(window: Window) -> Image:
	var desktop := DisplayServer.screen_get_image(window.current_screen)
	if desktop == null or desktop.is_empty():
		push_error("native desktop capture is unavailable")
		return null
	var native_size := DisplayServer.window_get_size(window.get_window_id())
	if native_size != window.size:
		push_error("native window size differs from its scene property")
		return null
	var origin := DisplayServer.window_get_position(window.get_window_id()) - DisplayServer.screen_get_position(window.current_screen)
	var region := Rect2i(origin, native_size)
	if not Rect2i(Vector2i.ZERO, desktop.get_size()).encloses(region):
		push_error("native window extends outside the capture desktop")
		return null
	return desktop.get_region(region)
