import pathlib,subprocess,os,json,re,hashlib,shutil
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');n=pathlib.Path('/workspace/Nest-Egg/work/batch1020b');r=w/'st9-counters-worktree';engine=w/'godot-audio-build/dist/godot'
ci=json.loads((w/'st9-sunday-ci-style-v4/receipt.json').read_text());assert len(ci['cases'])==6 and all(x['passed'] for x in ci['cases'])
files=['autoload/story.gd','game/main.gd','game/story_result_completion.gd','game/cutscene/cutscene_player.gd','data/story/ch1_kasa.json','tools/story/ch1_runtime_backend.py','tests/probes/sunday_choice.gd','tests/probes/sunday_choice.tscn','tools/runtime_probe.py','tools/run_sunday_choice.py','tools/run_handoff_completion.py','.github/workflows/tests.yml'];frozen={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files};(w/'st9-sunday-final-source-v1.json').write_text(json.dumps(frozen,indent=2)+'\n')
env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(engine));rows=[]
for mode in ['write','read','pending_read','reset','return','skip']:
 tag='st9-sunday-final-'+mode+'-v1';slot=w/('st9-sunday-final-'+('write' if mode in ['write','read'] else mode)+'-v1-slot')
 if mode=='pending_read':
  slot.mkdir(exist_ok=False);payload=(w/'st9-sunday-final-write-v1-slot/pending-primary.json').read_bytes();(slot/'slot.json').write_bytes(payload);(w/'st9-sunday-pending-original-sha.json').write_text(json.dumps({'sha256':hashlib.sha256(payload).hexdigest(),'from':'first synchronous flag observer reads original raw primary','mutated':False})+'\n')
 command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://tests/probes/sunday_choice.tscn','--mode='+mode,'--save-dir='+str(slot)]
 print('START',tag,flush=True)
 with (w/(tag+'-console.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 data=json.loads((n/tag/'result.json').read_text());raw=(n/(tag+'.log')).read_text();exit_code=int((n/(tag+'.exit')).read_text());clean=not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use|^FAIL ',raw,re.M)
 row={'tag':tag,'mode':mode,'checks':data['checks'],'failures':data['failures'],'exit':code,'engine_exit':exit_code,'clean':clean};rows.append(row);(w/'st9-sunday-native-final-v1.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert code==0 and exit_code==0 and clean and not data['failures'],row
 for p,h in frozen.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
print('ALL NATIVE CASES VERIFIED',flush=True)
