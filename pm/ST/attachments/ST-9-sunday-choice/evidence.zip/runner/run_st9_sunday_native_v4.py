import pathlib,subprocess,os,json,re,hashlib,shutil,time
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');n=pathlib.Path('/workspace/Nest-Egg/work/batch1020b');r=w/'st9-counters-worktree';engine=w/'godot-audio-build/dist/godot'
deadline=time.monotonic()+1200
while not (w/'st9-sunday-affected-v1.exit').exists():
 assert time.monotonic()<deadline,'affected test deadline exceeded'
 time.sleep(1)
assert (w/'st9-sunday-affected-v1.exit').read_text().strip()=='0'
deadline=time.monotonic()+600
while True:
 try:
  pending_ci=json.loads((w/'st9-sunday-ci-style-v8/receipt.json').read_text())
  if pending_ci['cases']:assert pending_ci['cases'][-1]['passed'],'headless case failed'
  if len(pending_ci['cases'])==8:break
 except (FileNotFoundError,ValueError):pass
 assert time.monotonic()<deadline,'new probe deadline exceeded'
 time.sleep(1)
ci=json.loads((w/'st9-sunday-ci-style-v8/receipt.json').read_text());assert len(ci['cases'])==8 and all(x['passed'] for x in ci['cases'])
files=['autoload/story.gd','game/main.gd','game/story_result_completion.gd','game/cutscene/cutscene_player.gd','data/story/ch1_kasa.json','tools/story/ch1_runtime_backend.py','tests/probes/sunday_choice.gd','tests/probes/sunday_choice.tscn','tools/runtime_probe.py','tools/run_sunday_choice.py','tools/run_handoff_completion.py','.github/workflows/tests.yml','tools/test_runtime_probe.py','tests/probes/sunday_choice.gd.uid'];frozen={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files};(w/'st9-sunday-final-source-v4.json').write_text(json.dumps(frozen,indent=2)+'\n')
env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(engine));rows=[]
for mode in ['write','read','pending_read','reset','return','skip','observer_reset','accepted_read']:
 tag='st9-sunday-final-'+mode+'-v4';slot=w/('st9-sunday-final-'+('write' if mode in ['write','read'] else 'observer_reset' if mode=='accepted_read' else mode)+'-v4-slot')
 if mode=='pending_read':
  slot.mkdir(exist_ok=False);payload=(w/'st9-sunday-final-write-v4-slot/pending-primary.json').read_bytes();(slot/'slot.json').write_bytes(payload);(w/'st9-sunday-pending-original-sha.json').write_text(json.dumps({'sha256':hashlib.sha256(payload).hexdigest(),'from':'first synchronous flag observer reads original raw primary','mutated':False})+'\n')
 command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://tests/probes/sunday_choice.tscn','--mode='+mode,'--save-dir='+str(slot)]
 print('START',tag,flush=True)
 with (w/(tag+'-console.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 data=json.loads((n/tag/'result.json').read_text());raw=(n/(tag+'.log')).read_text();exit_code=int((n/(tag+'.exit')).read_text());clean=not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use|^FAIL ',raw,re.M)
 row={'tag':tag,'mode':mode,'checks':data['checks'],'failures':data['failures'],'exit':code,'engine_exit':exit_code,'clean':clean};rows.append(row);(w/'st9-sunday-native-final-v4.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert code==0 and exit_code==0 and clean and not data['failures'],row
 for p,h in frozen.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
print('ALL NATIVE CASES VERIFIED',flush=True)

for helper,output in [('run_handoff_completion.py','st9-sunday-handoff-ci-style-v2')]:
 print('START',output,flush=True)
 with (w/(output+'.log')).open('w') as log:
  code=subprocess.run(['python',str(r/'tools'/helper),'--godot',str(engine),'--output',str(w/output)],cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
 (w/(output+'.exit')).write_text(str(code)+'\n')
 assert code==0,output
 print('PASS',output,flush=True)
for p,h in frozen.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
print('ALL FINAL SOURCE AND SHARED RUNNERS VERIFIED',flush=True)
