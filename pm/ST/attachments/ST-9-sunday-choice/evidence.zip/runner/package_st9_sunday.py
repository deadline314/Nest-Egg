import hashlib,json,pathlib,re,shutil,zipfile
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=pathlib.Path('/workspace/Nest-Egg/work/batch1020b');d=r/'pm/ST/attachments/ST-9-sunday-choice'
assert (w/'st9-sunday-affected-v1.exit').read_text().strip()=='0'
assert (w/'st9-sunday-handoff-ci-style-v2.exit').read_text().strip()=='0'
assert (w/'st9-sunday-ci-style-v8.exit').read_text().strip()=='0'
frozen=json.loads((w/'st9-sunday-final-source-v6.json').read_text())
for p,h in frozen.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
native=json.loads((w/'st9-sunday-native-final-v4.json').read_text());assert len(native)==8 and all(x['clean'] and x['exit']==x['engine_exit']==0 and not x['failures'] for x in native)
headless=json.loads((w/'st9-sunday-ci-style-v8/receipt.json').read_text());handoff=json.loads((w/'st9-sunday-handoff-ci-style-v2/receipt.json').read_text());assert len(headless['cases'])==8 and all(x['passed'] for x in headless['cases']);assert len(handoff['cases'])==2 and all(x['passed'] for x in handoff['cases'])
assert 'Ran 7 tests' in (w/'st9-sunday-runner-unit-v2.log').read_text() and (w/'st9-sunday-runner-unit-v2.log').read_text().rstrip().endswith('OK')
before=json.loads((n/'st9-sunday-choice-before-v4/result.json').read_text());after=json.loads((n/'st9-sunday-choice-after-v4/result.json').read_text());assert before['checks']==17 and len(before['failures'])==6 and after['checks']==12 and not after['failures']
text=(w/'st9-sunday-affected-v1.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)\s+\(wall time (\d+) s\)',text);assert m and m[2]==m[3]=='0'
entries={}
def add(name,p):
 if p.is_file():entries[name]=p

def tree(prefix,p):
 for file in sorted(p.rglob('*')):
  if file.is_file() and not any(part.endswith('-profile') or part in ['.godot','__pycache__'] for part in file.relative_to(p).parts):add(prefix+'/'+str(file.relative_to(p)),file)
def digest(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
for p in frozen:add('source/final/'+p,r/p)
followup=json.loads((n/'st9-sunday-final-write-v6/result.json').read_text());followup_log=(n/'st9-sunday-final-write-v6.log').read_text();assert followup['checks']==49 and not followup['failures'] and (n/'st9-sunday-final-write-v6.exit').read_text().strip()=='0';assert not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use|^FAIL ',followup_log,re.M)
tree('source/before-v4',w/'st9-sunday-before-v4-source');tree('source/after-v4',w/'st9-sunday-frozen-v4');add('source/native-v1-probe.gd',w/'st9-sunday-native-v1-probe.gd');add('source/native-v2-probe.gd',w/'st9-sunday-native-v2-probe.gd');add('source/headless-v7-probe.gd',w/'st9-sunday-headless-v7-probe.gd');add('source/native-v4-probe.gd',w/'st9-sunday-native-v4-probe.gd');add('source/native-v5-probe.gd',w/'st9-sunday-native-v5-probe.gd')
for prefix in ['st9-sunday-choice-before-v','st9-sunday-choice-after-v','st9-sunday-choice-write-v','st9-sunday-final-']:
 for directory in sorted(n.glob(prefix+'*')):
  if directory.is_dir() and not directory.name.endswith('-profile'):
   tree('native/'+directory.name,directory)
   for suffix in ['.log','.exit','-xvfb.log']:add('native/'+directory.name+suffix,n/(directory.name+suffix))
for directory in sorted(w.glob('st9-sunday-*')):
 if directory.is_dir() and (directory.name.endswith('-slot') or directory.name.startswith('st9-sunday-ci-style-') or directory.name=='st9-sunday-handoff-ci-style-v2'):tree('runs/'+directory.name,directory)
for p in sorted(w.glob('st9-sunday-*')):
 if p.is_file() and p.suffix in ['.log','.exit','.json']:add('logs/'+p.name,p)
for p in sorted((w/'st9-sunday-affected-v1-shards').glob('*.log')):add('tests/affected/'+p.name,p)
for p in w.glob('run_st9_sunday*.py'):add('runner/'+p.name,p)
add('runner/package_st9_sunday.py',pathlib.Path(__file__))
add('research/ink-reading.json',w/'st9-ink-research.json')
manifest={};archive=d/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(entries.items()):manifest[name]={'bytes':p.stat().st_size,'sha256':digest(p)};z.write(p,name)
with zipfile.ZipFile(archive) as z:
 for name,expected in manifest.items():
  with z.open(name) as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected['sha256'],name
assert archive.stat().st_size<50*1024*1024
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
validation={'base':'598c2324b247c0b9a256f1697b4e37cef41da261','source_sha256':frozen,'engine_sha256':headless['engine_sha256'],'negative_v4':{'source_sha256':'57b1dfcfbbfcefebf89fed694b3ea2eaabf48e4b46f762213662e8287c6dda6b','before_checks':before['checks'],'before_failures':len(before['failures']),'after_checks':after['checks'],'after_failures':0,'different_counts_reason':'before wrongly publishes a flag and enters five observer assertions; corrected refusal emits no notification'},'affected':{'groups':int(re.search(r'Running (\d+) groups',text)[1]),'checks':int(m[1]),'new_failures':0,'known_failures':0,'seconds':int(m[4])},'native':{'processes':len(native),'checks':sum(x['checks'] for x in native),'failures':0,'cases':native},'headless':{'processes':8,'checks':sum(x['result']['checks'] for x in headless['cases']),'failures':0},'handoff_regression':{'processes':2,'checks':sum(x['result']['checks'] for x in handoff['cases']),'failures':0},'runner_unit':{'tests':7,'failures':0},'capture_followup':{'tag':'st9-sunday-final-write-v6','checks':49,'failures':0,'source_scope':json.loads((w/'st9-sunday-capture-only-followup.json').read_text()),'preview_mime':json.loads((w/'st9-sunday-preview-mime-verification.json').read_text())},'archive':{'file':'evidence.zip','bytes':archive.stat().st_size,'entries':len(manifest),'sha256':digest(archive)},'previous_handoff_ci':json.loads((d/'previous-handoff-ci.json').read_text()),'boundaries':['Arranged existing brief/dinner and unrelated credits/item; not a human chapter playthrough.','Software Forward+ HDR2D; physical hardware/input acceptance remains separate.','Only the finite authored rooftop Sunday choice and terminal reading are migrated; general atomic_v1 is not enabled.']}
(d/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
images={'question':n/'st9-sunday-final-write-v6/question.png','retry':n/'st9-sunday-final-write-v6/choice-refused.png','reading':n/'st9-sunday-final-write-v6/reading.png','leaf-retry':n/'st9-sunday-final-write-v6/leaf-refused.png','cold':n/'st9-sunday-final-pending_read-v4/cold.png'}
for name,p in images.items():shutil.copyfile(p,r/'pm/ST/images'/('ST-9-sunday-'+name+'.png'))
print(json.dumps({k:v for k,v in validation.items() if k not in ['source_sha256','previous_handoff_ci','boundaries']}))
