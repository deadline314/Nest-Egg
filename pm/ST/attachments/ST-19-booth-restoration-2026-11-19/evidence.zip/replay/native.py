from pathlib import Path
from shutil import copyfile
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
prior = base.parent/'st19-cinematic-music-20261119'
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
source = json.loads((base/'integration/source.json').read_bytes())
guard = {name: source[name] for name in json.loads((base/'integration/paths.json').read_bytes())}
probe = (prior/'s14_booth_trial.gd').read_text(encoding='utf-8')
start,end = probe.index('\tvar trial:'),probe.index('\t_main = ',probe.index('\tvar trial:'))
probe = probe[:start]+'''	var starts: Array[StringName] = []
	Story.scene_started.connect(func(id: StringName, _mode_tag: StringName) -> void: starts.append(id))
	var cues: Array[StringName] = []
	Sfx.sound_played.connect(func(id: StringName) -> void: cues.append(id))
	_check(StageLibrary.validate(&"ch2_phone_booth").is_empty(), "the original packaged booth validates")
	var stages: Dictionary = Story.audit_data()["scenes"]
	var booth_scenes := {String(RETURN): stages[String(RETURN)], String(QUIET): stages[String(QUIET)]}
	var issues := SceneAudit.audit_stages(booth_scenes, StageLibrary.definition)
	_check(issues.is_empty(), "the packaged stage passes proportion and support checks: " + str(issues))
	for id in [RETURN, QUIET]:
		var alerts := CutsceneChecker.validate(String(id), Story._scenes[String(id)], Story._speakers)
		_check(alerts.is_empty(), String(id) + ": " + str(alerts))
'''+probe[end:]
probe = probe.replace('\t_check(_level() != null and _level().data.resource_path == OFFICE,', '''	if _mode.begins_with("cold"):
		_check(_level() != null and _level().data.id == &"ch2_market_gate", "cold continue restores the actual booth area")
		_check(GameState.has_flag(&"ch2_egret_returned"), "cold Continue keeps Egret's returned flag")
		_check(int(GameState.get_flag(&"egret_restoration_count",213)) == 214, "cold Continue keeps the exact restoration 214")
		for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
			if node is NpcActor and node.data.id == &"ch2_egret_booth":
				_check(Story.resolve_dispatch(node.data.talks[0].scene) == &"ch2_t_s14_revisit", "cold actual Egret offers only the revisit")
		await _shot("cold-booth")
		await _done()
		return
	_check(_level() != null and _level().data.resource_path == OFFICE,''')
probe = probe.replace('\tvar seen: Dictionary[StringName, int] = {}','\tvar skipped := false\n\tvar seen: Dictionary[StringName, int] = {}')
probe = probe.replace('if player != null and player.is_running()', 'if is_instance_valid(player) and player.is_running()')
probe = probe.replace('if last_line != player.steps_run or last_scene != player.scene_id:', '''if _mode == "skip" and not skipped:
				skipped = true
				await _shot("skip-first-line")
				var event := InputEventKey.new()
				event.keycode = KEY_ESCAPE
				event.pressed = true
				Input.parse_input_event(event)
				await get_tree().process_frame
				event = InputEventKey.new()
				event.keycode = KEY_ESCAPE
				event.pressed = false
				Input.parse_input_event(event)
				continue
			if _mode == "skip":
				await get_tree().process_frame
				continue
			if last_line != player.steps_run or last_scene != player.scene_id:''')
probe = probe.replace('\t\t\tawait get_tree().process_frame\n\t_check(finished[1]', '\t\t\tawait get_tree().process_frame\n\t_check(finished[1]')
start = probe.index('\t_check(finished[1] and seen.get(RETURN)')
end = probe.index('\t_check(GameState.has_flag',start)
probe = probe[:start]+'''	if _mode == "skip":
		_check(skipped and finished[1] and seen.is_empty(), "one Escape skips both visuals")
		_check(starts.count(RETURN) == 1 and starts.count(QUIET) == 1, "one Escape still runs exactly the original result scene")
	else:
		_check(finished[1] and seen.get(RETURN) == 6 and seen.get(QUIET) == 3, "all nine original lines ran")
		_check(pose_changes == ["sit","idle","walk","idle","squat","idle"], "Egret sat, stood, stepped out and collected her bag")
		_check(cues.count(&"beep") >= 1, "the actual terminal cue used the registered SFX")
		for row: Dictionary in _samples:
			if row["scene"] == String(QUIET) or (row["scene"] == String(RETURN) and row["line"] >= 4):
				_check(row["held"]["egret_broken_umbrella"] and row["held"]["egret_equipment_bag"], "both objects held at " + str(row["scene"]) + "/" + str(row["line"]))
'''+probe[end:]
probe = probe.replace('\tawait _done()\n', '\tawait _done()\n')
probe = probe.replace('\tprint("POSE_TRANSITIONS ", pose_changes)', '''	await _frames(60)
	_sample("market_after")
	_check(not GameplayLock.is_locked(), "normal world controls recovered")
	_check(not FileAccess.get_file_as_bytes(store.path).is_empty(), "Main has a readable primary save")
	print("POSE_TRANSITIONS ", pose_changes)''')
(base/'st19_booth_native.gd').write_text(probe,encoding='utf-8',newline='\n')
scene = (prior/'s13_music_probe.tscn').read_text(encoding='utf-8').replace('s13_music_probe.gd','st19_booth_native.gd')
(base/'st19_booth_native.tscn').write_text(scene,encoding='utf-8',newline='\n')
for name in ('st19_booth_native.gd','st19_booth_native.tscn'):
    copyfile(base/name,shared/'work'/name)
assert all(hashlib.sha256((shared/name).read_bytes()).hexdigest()==digest for name,digest in guard.items())
tag, *modes = sys.argv[1:]
for mode in modes:
    out = base/tag/mode
    out.mkdir(parents=True)
    (out/'slot').mkdir()
    if mode.startswith('cold_'):
        original = base/tag/mode.removeprefix('cold_')/'slot/slot.json'
    else:
        route = 'cut_play' if mode=='normal' else 'keep_play'
        original = prior/f'candidate/{route}/slot/slot.json'
    copyfile(original,out/'slot/slot.json')
    env = os.environ.copy()
    for name in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[name] = str(out/'profile'/name)
    cmd = [sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
           '--path',str(shared),'--audio-driver','WASAPI','--rendering-method','forward_plus',
           '--resolution','960x540','--position','32,32','--max-fps','60',
           'res://work/st19_booth_native.tscn','--','--mode='+mode,'--save-dir='+str(out/'slot'),'--out='+str(out)]
    (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result = subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    raw = (out/'raw.log').read_text(encoding='utf-8',errors='replace')
    receipt = {'mode':mode,'exit':result.returncode, 'source_held':all(hashlib.sha256((shared/name).read_bytes()).hexdigest()==digest for name,digest in guard.items()),
               'sound':[json.loads(s.removeprefix('AUDIO_STATE ')) for s in raw.splitlines() if s.startswith('AUDIO_STATE ')],
               'errors':[s for s in raw.splitlines() if 'ERROR:' in s or 'WARNING: [Cutscene' in s],
               'save_sha':hashlib.sha256((out/'slot/slot.json').read_bytes()).hexdigest()}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(receipt,flush=True)
    assert result.returncode==0 and not receipt['errors'] and receipt['source_held']
