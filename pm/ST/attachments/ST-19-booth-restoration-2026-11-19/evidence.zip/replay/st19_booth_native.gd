extends "res://work/s13_music_probe.gd"

const RETURN := &"ch2_t_s14_return"
const QUIET := &"ch2_t_s14_quiet"
var _samples: Array[Dictionary] = []


func _run() -> void:
	var starts: Array[StringName] = []
	Story.scene_started.connect(func(id: StringName, _mode_tag: StringName) -> void: starts.append(id))
	var cues: Array[StringName] = []
	Sfx.sound_played.connect(func(id: StringName) -> void: cues.append(id))
	_check(StageLibrary.validate(&"ch2_phone_booth").is_empty(), "the original packaged booth validates")
	var stages: Dictionary = Story.audit_data()["scenes"]
	var booth_scenes := {String(RETURN): stages[String(RETURN)], String(QUIET): stages[String(QUIET)]}
	var issues := SceneAudit.audit_stages(booth_scenes, StageLibrary.definition)
	_check(issues.is_empty(), "the packaged stage passes proportion and support checks: " + str(issues))
	for id in [RETURN, QUIET]:
		var alerts := CutsceneChecker.validate(String(id), Story._scenes[String(id)], Story._speakers)
		_check(alerts.is_empty(), String(id) + ": " + str(alerts))
	_main = load("res://game/main.gd").new()
	var store := RunSaveStore.new(_save_dir.path_join("slot.json"))
	_main.set("_run_store", store)
	add_child(_main)
	await _frames(8)
	_main.call("_on_continue_requested")
	await _frames(30)
	if _mode.begins_with("cold"):
		_check(_level() != null and _level().data.id == &"ch2_market_gate", "cold continue restores the actual booth area")
		_check(GameState.has_flag(&"ch2_egret_returned"), "cold Continue keeps Egret's returned flag")
		_check(int(GameState.get_flag(&"egret_restoration_count",213)) == 214, "cold Continue keeps the exact restoration 214")
		for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
			if node is NpcActor and node.data.id == &"ch2_egret_booth":
				_check(Story.resolve_dispatch(node.data.talks[0].scene) == &"ch2_t_s14_revisit", "cold actual Egret offers only the revisit")
		await _shot("cold-booth")
		await _done()
		return
	_check(_level() != null and _level().data.resource_path == OFFICE, "opens the original S13 result in its real office")
	_check(GameState.has_flag(&"ch2_egret_transport_done"), "actual S13 completion opens the family route")
	_check(int(GameState.get_flag(&"egret_restoration_count", 213)) == 213, "Egret begins with 213 restorations")
	var portal: Portal = _level()._portals.get(&"office_family")
	_check(portal != null and portal.try_use(), "the original family door takes Rin to the market gate")
	await _frames(60)
	await _finish_story()
	await _wait_control()
	_check(_level() != null and _level().data.id == &"ch2_market_gate", "uses the actual portal target")
	if _level() == null or _level().data.id != &"ch2_market_gate":
		await _done()
		return
	var booth: NpcActor
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and node.data.id == &"ch2_egret_booth":
			booth = node
			break
	_check(booth != null and Story.resolve_dispatch(booth.data.talks[0].scene) == RETURN, "speaks to the original Egret NPC")
	if booth == null:
		await _done()
		return
	_player().global_position = booth.global_position + Vector2(-32, 0)
	_player().velocity = Vector2.ZERO
	_player().set_physics_process(false)
	var finished := [false, false]
	var talk := func() -> void:
		finished[1] = await booth._talk()
		finished[0] = true
	talk.call()
	var skipped := false
	var seen: Dictionary[StringName, int] = {}
	var pose_changes: Array = []
	var last_pose := &""
	var last_line := -1
	var last_scene: StringName
	for frame in 4200:
		if finished[0]:
			break
		var player := Story._player
		if is_instance_valid(player) and player.is_running() and player._actors.has(&"egret"):
			var egret := player._actors[&"egret"] as CutsceneActor
			if egret.pose != last_pose:
				last_pose = egret.pose
				pose_changes.append(String(last_pose))
		if is_instance_valid(player) and player.is_running() and player._dialogue.visible:
			if _mode == "skip" and not skipped:
				skipped = true
				await _shot("skip-first-line")
				var event := InputEventKey.new()
				event.keycode = KEY_ESCAPE
				event.pressed = true
				Input.parse_input_event(event)
				await get_tree().process_frame
				event = InputEventKey.new()
				event.keycode = KEY_ESCAPE
				event.pressed = false
				Input.parse_input_event(event)
				continue
			if _mode == "skip":
				await get_tree().process_frame
				continue
			if last_line != player.steps_run or last_scene != player.scene_id:
				last_line = player.steps_run
				last_scene = player.scene_id
				var index: int = seen.get(last_scene, 0)
				var name := String(last_scene) + "-" + str(index)
				await _shot(name)
				_sample(name)
				var poses := {}
				for id: StringName in player._actors:
					var actor: CutsceneActor = player._actors[id]
					poses[String(id)] = {"pose":String(actor.pose),"pos":str(actor.position)}
				var props := {}
				for id: String in ["egret_broken_umbrella","egret_equipment_bag"]:
					props[id] = player._stage.prop_held(id)
				_samples.append({"scene":String(last_scene),"line":index,"actors":poses,"held":props})
				seen[last_scene] = index + 1
			player._dialogue.complete()
			player._advance_requested = true
		await get_tree().process_frame
	if _mode == "skip":
		_check(skipped and finished[1] and seen.is_empty(), "one Escape skips both visuals")
		_check(starts.count(RETURN) == 1 and starts.count(QUIET) == 1, "one Escape still runs exactly the original result scene")
	else:
		_check(finished[1] and seen.get(RETURN) == 6 and seen.get(QUIET) == 3, "all nine original lines ran")
		_check(pose_changes == ["sit","idle","walk","idle","squat","idle"], "Egret sat, stood, stepped out and collected her bag")
		_check(cues.count(&"beep") >= 1, "the actual terminal cue used the registered SFX")
		for row: Dictionary in _samples:
			if row["scene"] == String(QUIET) or (row["scene"] == String(RETURN) and row["line"] >= 4):
				_check(row["held"]["egret_broken_umbrella"] and row["held"]["egret_equipment_bag"], "both objects held at " + str(row["scene"]) + "/" + str(row["line"]))
	_check(GameState.has_flag(&"ch2_egret_returned") and int(GameState.get_flag(&"egret_restoration_count", 213)) == 214, "the return publishes the original single restoration")
	_check(Story.resolve_dispatch(booth.data.talks[0].scene) == &"ch2_t_s14_revisit", "return visit does not repeat the restoration")
	await _frames(60)
	_sample("market_after")
	_check(not GameplayLock.is_locked(), "normal world controls recovered")
	_check(not FileAccess.get_file_as_bytes(store.path).is_empty(), "Main has a readable primary save")
	print("POSE_TRANSITIONS ", pose_changes)
	FileAccess.open(_out.path_join("lines.json"), FileAccess.WRITE).store_string(JSON.stringify(_samples, "  "))
	await _done()
