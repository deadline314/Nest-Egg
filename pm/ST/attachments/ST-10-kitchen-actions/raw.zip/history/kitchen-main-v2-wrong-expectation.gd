extends "res://tools/scenarios/scenario_base.gd"
const HOME := &"ch1_c14_home"
const LAST := "res://data/levels/ch1_pawnshop_dawn.tres"
var checks := 0
var failures := 0
var main: Node
var store: RunSaveStore
var mode := "natural"
var slot := ""
var phase_shots := {}
var sampler := preload("res://work/st10-kitchen/actions.gd").new()

func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--out="): out_dir = arg.trim_prefix("--out=")
  if arg.begins_with("--slot="): slot = arg.trim_prefix("--slot=")
  if arg.begins_with("--mode="): mode = arg.trim_prefix("--mode=")
 DirAccess.make_dir_recursive_absolute(out_dir)
 _run.call_deferred()

func check(ok: bool, message: String) -> void:
 checks += 1
 if not ok: failures += 1
 print("MAIN_KITCHEN_CHECK %s %s" % [ok, message])

func until(predicate: Callable, advance := false, seconds := 120) -> bool:
 var end := Time.get_ticks_msec() + seconds * 1000
 while Time.get_ticks_msec() < end:
  if predicate.call(): return true
  if is_instance_valid(Story._player):
   if Story._player._stage != null:
    sampler._sample(Story._player)
    if mode == "natural": _phase_shot(Story._player)
   if advance and is_instance_valid(Story._player._dialogue) and Story._player._dialogue.visible and Story._player._dialogue.is_complete():
    Story._player._advance_requested = true
  await RenderingServer.frame_post_draw
 return false

func movie() -> bool:
 return is_instance_valid(Story._player) and Story._current_cinematic == HOME and Story._player._stage != null and Story._player._actors.size() == 2 and Story._player._dialogue.visible and Story._player._dialogue.is_complete()

func filling() -> bool:
 return is_instance_valid(Story._player) and Story._player._stage != null and Story._player._stage.prop_node("tap_water").visible

func ending() -> bool:
 return is_instance_valid(Story._player) and Story._player._stage != null and Story._player.steps_run >= Story._player._steps.size() - 1

func victory() -> bool:
 var screen: Node = main.get("_screen")
 return screen is VictoryScreen and not main.call("_route_pending") and not screen._buttons.is_empty() and not screen._buttons[0].disabled

func _run() -> void:
 check(slot.is_absolute_path(), "probe uses an explicitly isolated whole-run slot")
 if not slot.is_absolute_path():
  get_tree().quit(2)
  return
 CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
 Transition.instant = true
 Settings.set_skip_cutscenes(false)
 Story.auto_skip = mode != "cold"
 main = preload("res://game/main.gd").new()
 main.process_mode = Node.PROCESS_MODE_PAUSABLE
 store = RunSaveStore.new(slot)
 main.set("_run_store", store)
 add_child(main)
 await settle(4)
 if mode == "cold":
  main.call("_on_continue_requested")
  check(await until(victory), "fresh Main continues the actual accepted chapter ending")
  check(GameState.has_flag(&"ch1_home_done") and GameState.has_flag(&"ch1_complete") and Story.progress_snapshot().has(HOME), "cold process restores both durable flags and completion")
  check(not GameplayLock.is_locked() and not get_tree().paused, "cold completed continuation has no stale stage lock")
  capture("cold-accepted")
  var p := CutscenePlayer.new()
  add_child(p)
  p.play(&"st10_cold_stage", {"steps": [{"do": "scene", "id": "ch1_pawnshop_kitchen", "pos": [320, 240], "zoom": .8, "fade": .3}, {"do": "wait", "time": 300.0}]})
  check(await until(func() -> bool: return p.steps_run >= 1), "completed continuation reconstructs the registered default stage")
  var stage := p._stage
  check(stage.prop_state("kettle") == "filled" and stage.prop_node("kettle").position.distance_to(_mat_support(stage)) < .001, "fresh default stage reconstructs filled kettle on the mat")
  check(not stage.prop_node("tap_water").visible and not stage.prop_node("stove_flame").visible and not stage.prop_node("stove_heat").visible and absf(stage.prop_node("kettle_lid").rotation) < .001, "fresh default stage is cold with lid and tap closed")
  await settle(3)
  await RenderingServer.frame_post_draw
  capture("cold-stage-default")
  p.cancel()
 else:
  main.call("_on_start_requested", GameState.difficulties[1])
  check(await until(func() -> bool: return main.get("_screen") is Level and main.get("_screen").is_initialized() and not main.call("_route_pending") and not Story.is_cinematic_active() and not GameplayLock.is_locked()), "real Main settles before arranged prerequisites")
  Story.reset_active_presentation(&"probe_setup")
  check(Story._apply_scene_results(&"ch1_t_handoff_summary")["ok"] and Story._apply_scene_results(&"ch1_t_supper_leave_none")["ok"], "canonical prerequisite operations retain real document custody")
  Story.auto_skip = false
  main.call("_on_area_requested", LAST)
  check(await until(movie), "actual final-room automatic intro starts the formal home movie")
  check(_initial_hot(), "formal home initial state is empty on stove with visible flame")
  capture("main-home-initial")
  check(await until(filling, true), "actual Main reaches physical open-lid filling")
  capture("main-home-filling")
  check(not GameState.has_flag(&"ch1_home_done") and not GameState.has_flag(&"ch1_complete"), "water animation cannot publish chapter completion early")
  if mode == "natural":
   var facts := var_to_bytes([GameState.world_flags, Progression.snapshot(), StoryItems.snapshot(), Story.progress_snapshot()])
   Story.reset_active_presentation(&"route")
   await settle(3)
   check(facts == var_to_bytes([GameState.world_flags, Progression.snapshot(), StoryItems.snapshot(), Story.progress_snapshot()]), "cancel during flow preserves all durable owners and history")
   main.call("_on_area_requested", LAST)
   check(await until(movie) and _initial_hot(), "reenter rebuilds original hot empty state without leftover held props or flow")
   check(await until(ending, true), "unmodified formal steps reach their natural final fade")
   if is_instance_valid(Story._player):
    check(Story._player._stage.prop_state("kettle") == "filled" and Story._player._stage.prop_node("kettle").position.distance_to(_mat_support(Story._player._stage)) < .08, "natural ending places the physically held full kettle on the mat")
    capture("main-home-final")
  else:
   var event := InputEventKey.new()
   event.keycode = KEY_ESCAPE
   event.pressed = true
   Input.parse_input_event(event)
   await settle(1)
   event = InputEventKey.new()
   event.keycode = KEY_ESCAPE
   event.pressed = false
   Input.parse_input_event(event)
  check(await until(victory, true), "formal completion reaches the actual chapter ending")
  var saved := store.read()
  check(saved.get("story", {}).get("flags", {}).get("ch1_home_done") == true and saved.get("story", {}).get("flags", {}).get("ch1_complete") == true and saved.get("chapter_complete") == true, "actual disk reader sees the existing durable chapter results")
  check(not GameplayLock.is_locked() and not get_tree().paused, "natural or skipped ending releases every gameplay lock")
  check(sampler.samples > 20 and sampler.worst_contact < .08 and sampler.worst_hold < .08, "actual Main sampled contacts and held prop remain physically aligned")
  capture("main-home-accepted")
 Story.reset_active_presentation(&"probe_cleanup")
 main.queue_free()
 var measurements := {"samples": sampler.samples, "worst_contact": sampler.worst_contact, "worst_hold": sampler.worst_hold}
 sampler.free()
 await settle(5)
 Sfx.stop_all()
 Music.stop(0.0)
 Ambience.stop_all(0.0)
 await get_tree().create_timer(1.1, true, false, true).timeout
 print("MAIN_KITCHEN_TOTAL ", JSON.stringify({"mode": mode, "checks": checks, "failures": failures, "measurements": measurements, "mechanical_images": phase_shots.keys()}))
 get_tree().quit(1 if failures else 0)

func _initial_hot() -> bool:
 if not is_instance_valid(Story._player) or Story._player._stage == null: return false
 var stage := Story._player._stage
 return stage.prop_state("kettle") == "default" and stage.prop_node("kettle").position.distance_to(Vector2(104.625, 174.625)) < .001 and stage.prop_node("stove_flame").visible and not stage.prop_node("tap_water").visible and not stage.prop_held("kettle")


func _mat_support(stage: StageLibrary.Stage) -> Vector2:
 var surface := (stage.prop_node("kettle_mat") as StageLayers._Rect)._rect
 return Vector2(surface.get_center().x, surface.position.y)


func _phase_shot(p: CutscenePlayer) -> void:
 if p.steps_run < 1: return
 var step: Dictionary = p._steps[p.steps_run - 1]
 var label := ""
 if step["do"] == "prop_hold": label = "pickup"
 if step["do"] == "prop_visible" and step["id"] == "stove_heat": label = "fire-off"
 if step["do"] == "move" and step["id"] == "k" and step["to"][0] == 365: label = "carry"
 if step["do"] == "prop_move" and step["id"] == "kettle_lid": label = "lid-open" if step["angle"] > 0 else "lid-closed"
 if step["do"] == "wait" and p._stage.prop_node("tap_water").visible: label = "water-on"
 if p._stage.prop_node("kettle_water").visible: label = "filled-mouth"
 if step["do"] == "prop_release": label = "placed"
 if not label.is_empty() and not phase_shots.has(label):
  phase_shots[label] = p.steps_run
  capture("main-mechanical-" + label)
