import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

B = Path('/workspace/Nest-Egg/work/batch1026')
ROOT = B / 'kitchen-worktree'
N = Path('/workspace/Nest-Egg/work/batch1020b')
env = os.environ.copy()
env['NE_NATIVE_PROJECT'] = '../batch1026/kitchen-worktree'
receipt = []

def native(name, mode, slot):
    command = ['python', '/workspace/Nest-Egg/work/batch1024/native-large.py', name, 'res://work/st10-kitchen/main.tscn', '--mode=' + mode, '--slot=' + str(slot)]
    with (B / (name + '-console.log')).open('w') as log:
        code = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
    text = (N / (name + '.log')).read_text()
    total = json.loads(re.findall(r'MAIN_KITCHEN_TOTAL (.+)', text)[-1])
    assert code == 0 and total['failures'] == 0 and not re.search(r'^ERROR:|SCRIPT ERROR:|were leaked|instances were leaked|cannot reach|CONTACT_MISS', text, re.M), name
    receipt.append({'name': name, 'returncode': code, 'result': total, 'log_sha256': hashlib.sha256(text.encode()).hexdigest()})
    (B / 'kitchen-final-sequence.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(name, total, flush=True)

assert (N / 'st10-kitchen-main-v3.exit').read_text() == '0'
native('st10-kitchen-cold-v3', 'cold', B / 'main-kitchen-v3-slot.json')
native('st10-kitchen-skip-v2', 'skip', B / 'main-kitchen-skip-v2-slot.json')
engine = str(N / 'godot472/Godot_v4.7.2-stable_linux.x86_64')
with (B / 'kitchen-final-import-v3.log').open('w') as log:
    subprocess.run([engine, '--headless', '--path', '.', '--editor', '--quit'], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
assert not re.search(r'^ERROR:|SCRIPT ERROR:', (B / 'kitchen-final-import-v3.log').read_text(), re.M)
env.update(GODOT=engine, SHARDS='8', LOG_DIR=str(B / 'kitchen-final-shards'))
with (B / 'kitchen-final-changed.log').open('w') as log:
    code = subprocess.run(['tools/run_tests_changed.sh'], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
(B / 'kitchen-final-changed.exit').write_text(str(code))
print('FINAL_SELECTOR_EXIT', code, flush=True)
raise SystemExit(code)
