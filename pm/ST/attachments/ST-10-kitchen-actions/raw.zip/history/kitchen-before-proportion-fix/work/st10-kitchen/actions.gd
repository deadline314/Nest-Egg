extends "res://tools/scenarios/scenario_base.gd"
var checks := 0
var failures := 0
var worst_contact := 0.0
var worst_hold := 0.0
var samples := 0

func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--out="): out_dir = arg.trim_prefix("--out=")
 DirAccess.make_dir_recursive_absolute(out_dir)
 _run.call_deferred()

func _check(ok: bool, message: String) -> void:
 checks += 1
 if not ok: failures += 1
 print("KITCHEN_CHECK %s %s" % [ok, message])

func _run() -> void:
 var facts := var_to_bytes([GameState.world_flags, StoryItems.snapshot(), Progression.snapshot(), Story.progress_snapshot()])
 var formal: Dictionary = Story._scenes["ch1_c14_home"]
 _check(CutsceneChecker.validate("ch1_c14_home", formal, Story._speakers).is_empty(), "formal home choreography validates")
 var steps: Array = []
 var captures := {}
 for original: Dictionary in formal["steps"]:
  var step := original.duplicate(true)
  if step["do"] == "say": step = {"do": "wait", "time": .05}
  if step["do"] == "fade": continue
  steps.append(step)
  var label := ""
  if step["do"] == "prop_visible" and step["id"] == "stove_heat": label = "fire-off-contact"
  if step["do"] == "prop_hold": label = "pickup-contact"
  if step["do"] == "move" and step["id"] == "k" and step["to"][0] == 375: label = "carry"
  if step["do"] == "prop_move" and step["id"] == "kettle_lid": label = "lid-open" if step["angle"] > 0 else "lid-closed"
  if step["do"] == "prop_visible" and step["id"] == "tap_water" and step["visible"]: label = "filling"
  if step["do"] == "prop_visible" and step["id"] == "kettle_water" and step["visible"]: label = "filled-mouth"
  if step["do"] == "prop_release": label = "placed-on-mat"
  if not label.is_empty():
   captures[steps.size()] = label
   steps.append({"do": "wait", "time": .5})
 steps.append({"do": "wait", "time": 300.0})
 var p := CutscenePlayer.new()
 add_child(p)
 p.play(&"st10_kitchen_actions", {"steps": steps, "pose_policy": "supported"})
 var end := Time.get_ticks_msec() + 180000
 while p.steps_run < steps.size() - 1 and Time.get_ticks_msec() < end:
  await RenderingServer.frame_post_draw
  if not is_instance_valid(p): break
  _sample(p)
  if captures.has(p.steps_run):
   var label: String = captures[p.steps_run]
   capture(label)
   captures.erase(p.steps_run)
 _check(captures.is_empty(), "every authored mechanical phase reached its rendered capture")
 _check(samples > 20 and worst_contact < .08, "actual post-render hand contacts remain on their physical targets")
 _check(worst_hold < .08, "held kettle remains on the actual palm through carry and squat")
 if is_instance_valid(p) and p._stage != null:
  var stage := p._stage
  _check(stage.prop_node("kettle").position.distance_to(Vector2(252, 183.2)) < .08, "final kettle base rests on the heat mat")
  _check(stage.prop_state("kettle") == "filled" and not stage.prop_node("tap_water").visible and not stage.prop_node("stove_flame").visible, "end state is filled with tap and stove off")
  _check(absf(stage.prop_node("kettle_lid").rotation) < .001, "lid physically closes before the return carry")
  capture("home-end")
  p.cancel()
 await settle(4)
 _check(facts == var_to_bytes([GameState.world_flags, StoryItems.snapshot(), Progression.snapshot(), Story.progress_snapshot()]), "diagnostic playback and cancel preserve actual story facts")
 print("KITCHEN_TOTAL ", JSON.stringify({"checks": checks, "failures": failures, "samples": samples, "worst_contact": worst_contact, "worst_hold": worst_hold}))
 get_tree().quit(1 if failures else 0)

func _sample(p: CutscenePlayer) -> void:
 if p._stage == null: return
 for id: StringName in p._actors:
  var actor: CutsceneActor = p._actors[id]
  for reach: CutsceneReach in actor._reaches:
   if not reach.settled() or not reach.active(): continue
   var point := reach.target + actor.position if reach._actor_space else reach.target
   var actual := p._stage.actors.to_local(actor.hand_contact_global(reach.hand))
   var error := actual.distance_to(point)
   worst_contact = maxf(worst_contact, error)
   samples += 1
   if error > .08: print("KITCHEN_CONTACT_MISS ", JSON.stringify({"step": p.steps_run, "actor": id, "hand": reach.hand, "error": error, "point": [point.x, point.y], "actual": [actual.x, actual.y]}))
 if p._stage.prop_held("kettle"):
  var kettle := p._stage.prop_node("kettle") as StageLayers._Sprite
  var actual := kettle.to_global(kettle.source_point(Vector2(350, 200)))
  var hand := p._actors[&"k"].hand_contact_global(&"front")
  worst_hold = maxf(worst_hold, actual.distance_to(hand) / .8)
