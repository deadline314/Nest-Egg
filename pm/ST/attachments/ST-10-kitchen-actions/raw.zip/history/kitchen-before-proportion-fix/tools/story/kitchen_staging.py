"""Kitchen source-space anchors shared by stage construction and choreography.

Atlas regions keep the urn body fixed and the kettle lid on a physical hinge.
Coordinates refer to the padded source canvas, before Godot import reduction.
"""
from math import pi

PROP_DIR = "res://art/environment/scene_props/pawnshop_kitchen_contacts/"
KETTLE_SCALE = 50.0 / 823.0
URN_SCALE = 192.0 / 1248.0
MAT = [252.0, 183.2]
STOVE = [91.0, 166.0]
KETTLE_GRIP = [350, 200]
LID_GRIP = [1380, 430]
LEVER_GRIP = [1091, 340]
LID_OPEN = 1.2
FILL_FOOT = [412.3 - (630 - 628) * KETTLE_SCALE, 252.0]


def layers():
    def sprite(id, atlas, region, pivot, pos, scale, **extra):
        return dict(kind="sprite", id=id, path=PROP_DIR + atlas + ".png",
                    region=region, pivot=pivot, pos=pos, scale=scale,
                    source_width=1700 if atlas == "kettle_atlas" else 1180,
                    filter="linear", **extra)
    return [
        {"kind": "rect", "rect": [222, 183.2, 58, 2.7], "color": "#343a31"},
        sprite("water_urn", "urn_atlas", [26, 18, 866, 1254], [474, 1251], [480, 304], URN_SCALE),
        sprite("urn_lever", "urn_atlas", [1048, 250, 84, 204], [43, 162], [0, 0], URN_SCALE,
               parent_prop="water_urn", anchor=[130, 582], angle=-pi / 2),
        sprite("kettle", "kettle_atlas", [36, 54, 1004, 828], [592, 825], MAT, KETTLE_SCALE,
               states={"filled": {"path": PROP_DIR + "kettle_atlas.png"}}, initial_state="filled"),
        sprite("kettle_lid", "kettle_atlas", [1122, 408, 560, 218], [535, 146], [0, 0], KETTLE_SCALE * .944,
               parent_prop="kettle", anchor=[900, 385]),
        {"kind": "dial", "id": "stove_dial", "pos": [88.8, 180.8], "radius": 5,
         "color": "#222a25", "pointer": "#d4ceb4", "angle": 1.2},
        {"kind": "rain", "id": "tap_water", "area": [411.99, 217.0, .6, 5.2],
         "speed": [24, 36], "length": [2, 3], "count": 8, "wind": 0,
         "opacity": .8, "visible": False},
        {"kind": "poly", "id": "kettle_water", "points": [[404, 225], [407, 223.7], [417, 223.7],
         [420, 225], [417, 226.2], [407, 226.2]], "color": "#829995", "visible": False},
        {"kind": "glow", "id": "stove_heat", "pos": [91, 166], "radius": 17,
         "color": "#e3b16c", "intensity": .5, "alpha": .25, "visible": False},
        {"kind": "poly", "id": "stove_flame", "points": [[70, 166], [73, 161], [76, 165],
         [81, 160], [85, 165], [91, 160], [95, 165], [101, 161], [105, 166]],
         "color": "#7ba6bd", "visible": False},
    ]


def reach(actor, hand, prop=None, point=None, **extra):
    result = dict(do="reach", id=actor, hand=hand, time=.35,
                  contact=([73, 40] if actor == "rin" else [64, 39]), angle=pi / 2)
    if prop:
        result.update(space="prop", prop=prop, to=point)
    return result | extra


def release(actor, hand):
    return dict(do="reach", id=actor, hand=hand, release=True, time=.25)


def close_stove():
    return [
        dict(do="move", id="k", to=[320, 304], time=1.5, wait=False, then="idle"),
        dict(do="move", id="rin", to=[105, 304], time=1.5, wait=True, then="idle"),
        reach("rin", "front", "stove_dial", [0, 0], follow_rotation=True),
        dict(do="prop_move", id="stove_dial", angle=1.2, time=.3),
        dict(do="sfx", id="switch", volume=-10),
        dict(do="prop_visible", id="stove_flame", visible=False),
        dict(do="prop_visible", id="stove_heat", visible=False),
        release("rin", "front"),
        dict(do="move", id="rin", to=[290, 304], time=1.8, wait=False, then="idle"),
    ]


def fill_kettle():
    # Source grip is on the left side of the black carrying handle. The other
    # hand is free to lift the lid and operate the tap; no hand swaps mid-carry.
    fill_grip = [FILL_FOOT[0] + (KETTLE_GRIP[0] - 628) * KETTLE_SCALE,
                 FILL_FOOT[1] + (KETTLE_GRIP[1] - 879) * KETTLE_SCALE]
    mat_grip = [MAT[0] + (KETTLE_GRIP[0] - 628) * KETTLE_SCALE,
                MAT[1] + (KETTLE_GRIP[1] - 879) * KETTLE_SCALE]
    return [
        dict(do="face", id="rin", dir=-1),
        dict(do="move", id="k", to=[110, 304], time=1.4, wait=True, then="idle"),
        dict(do="face", id="k", dir=-1),
        reach("k", "front", "kettle", KETTLE_GRIP),
        dict(do="prop_hold", id="kettle", actor="k", hand="front", point=KETTLE_GRIP),
        reach("k", "front", space="actor", to=[25, -170], time=.45),
        dict(do="face", id="k", dir=1),
        dict(do="move", id="k", to=[375, 304], time=1.8, wait=True, then="idle"),
        dict(do="face", id="rin", dir=1),
        dict(do="pose", id="k", pose="squat", pose_reason="蹲低以壺口對準水缸出水口", pose_support="雙腳仍在廚房地面304"),
        reach("k", "front", space="actor", to=[fill_grip[0] - 375, fill_grip[1] - 304], time=.5),
        reach("k", "back", "kettle_lid", LID_GRIP, angle=0),
        dict(do="prop_move", id="kettle_lid", angle=LID_OPEN, time=.4),
        release("k", "back"),
        reach("k", "back", "urn_lever", LEVER_GRIP, angle=0),
        dict(do="prop_move", id="urn_lever", angle=0, time=.3),
        dict(do="prop_visible", id="tap_water", visible=True),
        dict(do="wait", time=1.4),
        dict(do="prop_visible", id="kettle_water", visible=True),
        dict(do="prop", id="kettle", state="filled"),
        dict(do="prop_visible", id="tap_water", visible=False),
        dict(do="prop_move", id="urn_lever", angle=-pi / 2, time=.3),
        release("k", "back"),
        reach("k", "back", "kettle_lid", LID_GRIP, angle=0),
        dict(do="prop_move", id="kettle_lid", angle=0, time=.4),
        dict(do="prop_visible", id="kettle_water", visible=False),
        release("k", "back"),
        dict(do="pose", id="k", pose="idle"),
        reach("k", "front", space="actor", to=[25, -170], time=1.2),
        dict(do="face", id="k", dir=-1),
        dict(do="move", id="k", to=[200, 304], time=1.1, wait=True, then="idle"),
        dict(do="face", id="k", dir=1),
        reach("k", "front", space="stage", to=mat_grip, time=.4),
        dict(do="prop_release", id="kettle"),
        release("k", "front"),
        dict(do="move", id="k", to=[190, 304], time=.5, wait=True, then="idle"),
        dict(do="face", id="k", dir=1),
        dict(do="face", id="rin", dir=-1),
        dict(do="wait", time=3.0),
    ]
