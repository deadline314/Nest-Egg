from pathlib import Path

root = Path('/workspace/Nest-Egg/work/batch1026/kitchen-worktree')
p = root / 'tools/story/kitchen_staging.py'
s = p.read_text()
s = s.replace('MAT = [252.0, 183.2]\nSTOVE = [91.0, 166.0]', '''BACKGROUND = dict(path="pawnshop_kitchen_contacts.png", pos=[-313.75, -176], width=1672, scale=.75)


def background_point(x, y):
    return [BACKGROUND["pos"][0] + x * BACKGROUND["scale"],
            BACKGROUND["pos"][1] + y * BACKGROUND["scale"]]


# Baked surfaces measured in the immutable background source canvas.
FURNITURE = [
    dict(id="dining_table", kind="table", rect=background_point(685, 489) + [201 * .75, 146 * .75]),
    dict(id="dining_chair", kind="seat", rect=background_point(638.75, 552) + [75 * .75, 83 * .75]),
    dict(id="kitchen_door", kind="door", rect=background_point(1126.25, 283.75) + [100 * .75, 362.5 * .75]),
]
MAT = [252.0, background_point(685, 489)[1]]
STOVE = background_point(548.75, 467.5)
DIAL = background_point(546, 486)
URN_POS = [470, 304]
OUTLET = [URN_POS[0] + (60 - 500) * URN_SCALE, URN_POS[1] + (700 - 1269) * URN_SCALE]
FILL_ACTOR_X = 365''')
s = s.replace('FILL_FOOT = [412.3 - (630 - 628) * KETTLE_SCALE, 252.0]', 'FILL_FOOT = [OUTLET[0] - (630 - 628) * KETTLE_SCALE, OUTLET[1] + 8 + (879 - 430) * KETTLE_SCALE]')
s = s.replace('{"kind": "rect", "rect": [222, 183.2, 58, 2.7],', '{"kind": "rect", "id": "kettle_mat", "rect": [MAT[0] - 29, MAT[1], 58, 2.7],')
s = s.replace('[474, 1251], [480, 304], URN_SCALE)', '[474, 1251], URN_POS, URN_SCALE)')
s = s.replace('"pos": [88.8, 180.8]', '"pos": DIAL')
s = s.replace('"area": [411.99, 217.0, .6, 5.2]', '"area": [OUTLET[0] - .3, OUTLET[1] + .5, .6, 5.2]')
s = s.replace('"points": [[404, 225], [407, 223.7], [417, 223.7],\n         [420, 225], [417, 226.2], [407, 226.2]]', '"points": [[OUTLET[0] + x, OUTLET[1] + 8 + y] for x, y in [(-8, 0), (-5, -1.3), (5, -1.3), (8, 0), (5, 1.2), (-5, 1.2)]]')
s = s.replace('"pos": [91, 166]', '"pos": STOVE')
s = s.replace('"points": [[70, 166], [73, 161], [76, 165],\n         [81, 160], [85, 165], [91, 160], [95, 165], [101, 161], [105, 166]]', '"points": [[STOVE[0] + x, STOVE[1] + y] for x, y in [(-21, 0), (-18, -5), (-15, -1), (-10, -6), (-6, -1), (0, -6), (4, -1), (10, -5), (14, 0)]]')
s = s.replace('        reach("rin", "front", "stove_dial",', '        dict(do="pose", id="rin", pose="lean", pose_reason="前傾以手掌握住爐鈕", pose_support="雙腳仍在廚房地面304"),\n        dict(do="wait", time=.6),\n        reach("rin", "front", "stove_dial",')
s = s.replace('        release("rin", "front"),', '        release("rin", "front"),\n        dict(do="pose", id="rin", pose="idle"),')
s = s.replace('to=[375, 304]', 'to=[FILL_ACTOR_X, 304]').replace('fill_grip[0] - 375', 'fill_grip[0] - FILL_ACTOR_X')
p.write_text(s)

p = root / 'tools/story/build_ch1_story.py'
s = p.read_text()
s = s.replace('    from .ch1_closure import', '    from . import kitchen_staging\n    from .ch1_closure import', 1)
s = s.replace('    from ch1_closure import', '    import kitchen_staging\n    from ch1_closure import', 1)
a = s.index('    # 無烘入壺的新廚房立繪重新量測:') if '    # 無烘入壺的新廚房立繪重新量測:' in s else s.index('    # 無烘入壺的新廚房立繪重新量測：')
b = s.index('    # 復原館', a)
s = s[:a] + "    # 來源畫布中的實際家具表面；與廚房背景一起轉換。\n    'ch1_pawnshop_kitchen': kitchen_staging.FURNITURE,\n" + s[b:]
s = s.replace("dict(path='pawnshop_kitchen_contacts.png', pos=[-348, -208], width=1672, scale=.8)", 'kitchen_staging.BACKGROUND')
p.write_text(s)

for name in ['tests/helpers/kitchen_choreography_checks.gd', 'work/st10-kitchen/actions.gd', 'work/st10-kitchen/main.gd']:
    p = root / name
    s = p.read_text()
    s = s.replace('Vector2(252, 183.2)', '_mat_support(stage)')
    # The independent cold test refers to its separately reconstructed stage.
    if name.startswith('tests/'):
        s = s.replace('cold.prop_node("kettle").position.distance_to(_mat_support(stage))', 'cold.prop_node("kettle").position.distance_to(_mat_support(cold))')
    s = s.replace('Story._player._stage.prop_node("kettle").position.distance_to(_mat_support(stage))', 'Story._player._stage.prop_node("kettle").position.distance_to(_mat_support(Story._player._stage))')
    s = s.replace('Vector2(91, 166)', 'Vector2(104.625, 174.625)')
    s = s.replace('step["to"][0] == 375', 'step["to"][0] == 365')
    prefix = 'static ' if name.startswith('tests/') else ''
    s += '\n\n' + prefix + '''func _mat_support(stage: StageLibrary.Stage) -> Vector2:
 var surface := (stage.prop_node("kettle_mat") as StageLayers._Rect)._rect
 return Vector2(surface.get_center().x, surface.position.y)
'''
    if name.startswith('tests/'):
        s = s.replace('\n var surface :=', '\n\tvar surface :=').replace('\n return Vector2(surface', '\n\treturn Vector2(surface')
    p.write_text(s)
print('Kitchen background and props recalibrated against unchanged proportion limits')
