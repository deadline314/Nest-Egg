extends Node
class Fixture extends TestSuite:
 func run() -> void:
  await preload("res://tests/helpers/kitchen_choreography_checks.gd").run(self)
var checks := 0
var failures := 0
func _ready() -> void:
 if "--negative" in OS.get_cmdline_user_args():
  var steps: Array = Story._scenes["ch1_c14_home"]["steps"]
  for index in steps.size() - 1:
   if steps[index].get("do") == "pose" and steps[index].get("pose") == "idle" and steps[index + 1].get("do") == "reach":
    steps[index + 1]["time"] = .5
    print("NEGATIVE_MUTATION ", JSON.stringify({"step": index + 1, "time": .5, "original": 1.2}))
 await Fixture.new(self).run()
 print("CHOREO_TOTAL checks=%d failures=%d" % [checks, failures])
 get_tree().quit(1 if failures else 0)
func _check(ok: bool, message: String) -> void:
 checks += 1
 if not ok: failures += 1
 print("CHOREO_CHECK %s %s" % [ok, message])
