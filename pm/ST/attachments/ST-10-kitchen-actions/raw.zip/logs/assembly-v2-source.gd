extends "res://tools/scenarios/scenario_base.gd"

func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--out="): out_dir = arg.trim_prefix("--out=")
 DirAccess.make_dir_recursive_absolute(out_dir)
 _run.call_deferred()

func _run() -> void:
 var custom: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://work/st10-kitchen/assembly.json"))
 StageLibrary._cache[&"ch1_pawnshop_kitchen"] = custom
 print("ASSEMBLY_VALIDATE ", StageLibrary.validate(&"ch1_pawnshop_kitchen"))
 var p := CutscenePlayer.new()
 add_child(p)
 var formal: Dictionary = Story._scenes["ch1_c14_home"]
 var steps: Array = formal["steps"].slice(0, 3).duplicate(true)
 steps[0]["fade"] = .3
 steps[1]["pos"] = [110, 304]
 steps[2]["pos"] = [375, 304]
 steps[2]["facing"] = 1
 steps.append({"do": "wait", "time": 300.0})
 p.play(&"st10_assembly", {"steps": steps})
 while p.steps_run < 4: await get_tree().process_frame
 await settle(4)
 await RenderingServer.frame_post_draw
 capture("assembly-closed")
 var lid := p._stage.prop_node("kettle_lid")
 lid.rotation = 1.2
 await settle(2)
 await RenderingServer.frame_post_draw
 capture("assembly-open")
 p._stage.prop_node("kettle").position = Vector2(429.3, 252)
 p._actors[&"k"].set_pose(&"squat")
 p._stage.set_prop_visible("tap_water", true)
 await wait(.8)
 await RenderingServer.frame_post_draw
 capture("assembly-fill")
 p.cancel()
 await settle(3)
 print("ASSEMBLY_DONE")
 get_tree().quit()
