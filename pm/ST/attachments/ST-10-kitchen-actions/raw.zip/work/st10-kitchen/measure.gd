extends Node
func _ready() -> void:
 var parent := Node2D.new()
 add_child(parent)
 for kind in ["rin", "old_k"]:
  for facing in [-1, 1]:
   for pose in [&"idle", &"lean", &"squat"]:
    var actor := CutsceneActor.new()
    parent.add_child(actor)
    actor.setup(&"measure", kind, "", 3.9 if kind == "rin" else 4.0, "")
    actor.position = Vector2(0,304)
    actor.face(facing)
    actor.set_pose(pose)
    actor.set_process(false)
    for i in 120: actor._process(1.0/60.0)
    var hands := {}
    for hand in ["front", "back"]:
     var upper := StringName("arm_"+hand+"_upper")
     var lower := StringName("arm_"+hand+"_lower")
     var wrist := StringName("hand_"+hand)
     var shoulder := actor.rig.bone(upper).global_position
     var point := actor.rig.bone(wrist).global_position
     hands[hand] = {"shoulder":[shoulder.x,shoulder.y],"reach":(actor.rig.rest(lower).length()+actor.rig.rest(wrist).length())*absf(actor.scale.x)*actor.rig.body_scale(),"rest_wrist":[point.x,point.y]}
    print("KITCHEN_MEASURE "+JSON.stringify({"kind":kind,"facing":facing,"pose":pose,"hands":hands}))
    actor.free()
 parent.free()
 get_tree().quit()
