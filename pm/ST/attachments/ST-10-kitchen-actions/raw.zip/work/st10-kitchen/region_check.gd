extends Node
class RegionOnly extends TestSuite:
 func run() -> void:
  preload("res://tests/helpers/cutscene_prop_action_checks.gd").run(self)
  preload("res://tests/helpers/stage_sprite_geometry_checks.gd").run(self)
  preload("res://tests/helpers/stage_prop_binding_checks.gd").run(self)
  preload("res://tests/helpers/stage_prop_hold_checks.gd").run(self)
  preload("res://tests/helpers/stage_prop_parent_checks.gd").run(self)
var checks := 0
var failures := 0
func _ready() -> void:
 RegionOnly.new(self).run()
 print("REGION_RESULT checks=%d failures=%d" % [checks,failures])
 get_tree().quit(1 if failures else 0)
func _check(ok: bool, message: String) -> void:
 checks += 1
 if not ok: failures += 1
 print("REGION_CHECK %s %s" % [ok,message])
