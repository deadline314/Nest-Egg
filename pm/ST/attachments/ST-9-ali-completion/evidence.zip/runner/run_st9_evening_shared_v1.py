from pathlib import Path
import os,subprocess,time,json,hashlib
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';deadline=time.monotonic()+1200
while not (w/'st9-evening-affected-v1.exit').exists():
 assert time.monotonic()<deadline
 time.sleep(1)
assert (w/'st9-evening-affected-v1.exit').read_text().strip()=='0'
engine=str(w/'godot-audio-build/dist/godot');frozen=json.loads((w/'st9-evening-final-source-v1.json').read_text())
for tool,output in [('run_voice_completion.py','st9-evening-voice-regression-v1'),('run_sunday_choice.py','st9-evening-sunday-regression-v1'),('run_handoff_completion.py','st9-evening-handoff-regression-v1')]:
 print('START',output,flush=True)
 with (w/(output+'.log')).open('w') as log:code=subprocess.run(['python',str(r/'tools'/tool),'--godot',engine,'--output',str(w/output)],cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
 (w/(output+'.exit')).write_text(str(code)+'\n');assert code==0,output
 for name,expected in frozen.items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==expected,name
 print('PASS',output,flush=True)
print('ALL PREVIOUS DURABLE SOURCE FLOWS VERIFIED',flush=True)
