from pathlib import Path
import json,hashlib,os,subprocess,re,time
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=Path('/workspace/Nest-Egg/work/batch1020b');deadline=time.monotonic()+1200
while not (w/'st9-evening-affected-v1.exit').exists():
 assert time.monotonic()<deadline
 time.sleep(1)
assert (w/'st9-evening-affected-v1.exit').read_text().strip()=='0'
frozen=json.loads((w/'st9-evening-final-source-v1.json').read_text());env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(w/'godot-audio-build/dist/godot'));rows=[];primaries={}
for mode in ['name','name_read','evening_sit','evening_sit_read','evening_ordered','close_ordered','cancel','cancel_read']:
 tag='st9-evening-final-'+mode+'-v1';writer=mode.removesuffix('_read');slot=w/('st9-evening-final-'+writer+'-v1-slot')
 if mode=='evening_sit_read':
  payload=(slot/'pending-primary.json').read_bytes();slot=w/('st9-evening-final-'+mode+'-v1-slot');slot.mkdir(exist_ok=False);(slot/'slot.json').write_bytes(payload);primaries[mode]={'sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload),'source':'st9-evening-final-evening_sit-v1-slot/pending-primary.json'};(w/'st9-evening-native-original-primaries-v1.json').write_text(json.dumps(primaries,indent=2)+'\n')
 command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://tests/probes/ali_completion.tscn','--mode='+mode,'--save-dir='+str(slot)];print('START',tag,flush=True)
 with (w/(tag+'-console.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 data=json.loads((n/tag/'result.json').read_text());raw=(n/(tag+'.log')).read_text();row={'mode':mode,'tag':tag,'checks':data['checks'],'failures':data['failures'],'exit':code,'engine_exit':int((n/(tag+'.exit')).read_text()),'clean':not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use|^FAIL ',raw,re.M)};rows.append(row);(w/'st9-evening-native-final-v1.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);assert code==0 and row['engine_exit']==0 and row['clean'] and not row['failures'],row
 for name,expected in frozen.items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==expected,name
print('ALL EIGHT FINAL ORIGINAL ALI FLOWS VERIFIED',flush=True)
