from pathlib import Path
import os,subprocess,json,re,hashlib
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=Path('/workspace/Nest-Egg/work/batch1020b');frozen=json.loads((w/'st9-evening-after-v1-source.json').read_text());rows=[]
env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(w/'godot-audio-build/dist/godot'))
for mode in ['name','evening_sit','evening_ordered','close_sit','close_ordered']:
 tag='st9-evening-after-'+mode+'-v1'
 if True:
  command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://work/st9-evening-boundary/probe.tscn','--mode='+mode,'--save-dir='+str(w/(tag+'-slot'))];print('START',tag,flush=True)
  with (w/(tag+'-console.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 else:code=int((n/(tag+'.exit')).read_text())
 data=json.loads((n/tag/'result.json').read_text());raw=(n/(tag+'.log')).read_text();clean=not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use',raw,re.M);row={'mode':mode,'checks':data['checks'],'failures':data['failures'],'exit':code,'engine_exit':int((n/(tag+'.exit')).read_text()),'clean':clean};rows.append(row);(w/'st9-evening-after-v1.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert code==0 and clean and data['checks']>=14 and not data['failures'],row
 for name,expected in frozen.items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==expected,name
print('ALL FIVE AUTHORED BOUNDARIES HOLD RESULTS UNTIL SAVE',flush=True)
