from pathlib import Path
import json,hashlib,re,zipfile,shutil
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=Path('/workspace/Nest-Egg/work/batch1020b');d=r/'pm/ST/attachments/ST-9-ali-completion'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
frozen=json.loads((w/'st9-evening-final-source-v1.json').read_text())
for name,expected in frozen.items():assert digest(r/name)==expected,name
before=json.loads((w/'st9-evening-before-v1.json').read_text());after=json.loads((w/'st9-evening-after-v1.json').read_text());assert sum(row['checks'] for row in before)==sum(row['checks'] for row in after)==82 and sum(len(row['failures']) for row in before)==20 and all(not row['failures'] and row['clean'] and row['exit']==row['engine_exit']==0 for row in after)
old=json.loads((w/'st9-evening-after-v1-source.json').read_text())
for name,expected in old.items():assert digest(r/name)==expected,name
headless=json.loads((w/'st9-evening-ci-style-v1/receipt.json').read_text());assert len(headless['cases'])==12 and all(row['passed'] for row in headless['cases'])
native=json.loads((w/'st9-evening-native-final-v1.json').read_text());assert len(native)==8 and all(row['clean'] and not row['failures'] and row['exit']==row['engine_exit']==0 for row in native)
visual=[]
for key in ['name','ordered']:
 tag='st9-evening-visual-'+key+'-v1';data=json.loads((n/tag/'result.json').read_text());log=(n/(tag+'.log')).read_text();assert (n/(tag+'.exit')).read_text().strip()=='0' and not data['failures'] and not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use|^FAIL ',log,re.M);visual.append({'tag':tag,'checks':data['checks'],'failures':0})
summary=(w/'st9-evening-affected-v1.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)\s+\(wall time (\d+) s\)',summary);assert m and m[2]==m[3]=='0'
assert (w/'st9-evening-affected-v1.exit').read_text().strip()==(w/'st9-evening-policy-v1.exit').read_text().strip()=='0'
shared={}
for key in ['voice','sunday','handoff']:
 receipt=json.loads((w/('st9-evening-'+key+'-regression-v1')/'receipt.json').read_text());assert all(row['passed'] for row in receipt['cases']);shared[key]={'processes':len(receipt['cases']),'checks':sum(row['result']['checks'] for row in receipt['cases']),'failures':0}
entries={}
def add(name,p):
 if p.is_file():entries[name]=p

def tree(prefix,p):
 for file in sorted(p.rglob('*')):
  if file.is_file() and not any(part.endswith('-profile') or part in ['.godot','__pycache__'] for part in file.relative_to(p).parts):add(prefix+'/'+str(file.relative_to(p)),file)
for name in frozen:add('source/final/'+name,r/name)
add('source/final/design/20-campaign-experience/ALI_DIALOGUE_COMPLETION.md',r/'design/20-campaign-experience/ALI_DIALOGUE_COMPLETION.md')
for name in ['st9-evening-before-v1-source','st9-evening-positive-before-fixture-fix-v1-source','st9-evening-positive-name-v2-source']:tree('source/'+name,w/name)
tree('source/original-boundary',r/'work/st9-evening-boundary');tree('source/visual-probe',r/'work/st9-evening-visual')
for path in sorted(n.glob('st9-evening-*')):
 if path.is_dir() and not path.name.endswith('-profile'):
  tree('native/'+path.name,path)
  for suffix in ['.log','.exit','-xvfb.log']:add('native/'+path.name+suffix,n/(path.name+suffix))
for path in sorted(w.glob('st9-evening-*')):
 if path.is_file() and path.suffix in ['.log','.json','.exit']:add('logs/'+path.name,path)
 elif path.is_dir() and (path.name.endswith('-slot') or path.name.endswith('-shards') or path.name.startswith(('st9-evening-ci-style-','st9-evening-voice-regression-','st9-evening-sunday-regression-','st9-evening-handoff-regression-'))):
  if path.name.endswith('-shards'):
   for file in path.glob('*.log'):add('tests/'+path.name+'/'+file.name,file)
  else:tree('runs/'+path.name,path)
for path in w.glob('run_st9_evening*.py'):add('runner/'+path.name,path)
add('runner/package_st9_evening.py',Path(__file__))
archive=d/'evidence.zip';manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(entries.items()):manifest[name]={'bytes':path.stat().st_size,'sha256':digest(path)};z.write(path,name)
with zipfile.ZipFile(archive) as z:
 for name,expected in manifest.items():
  with z.open(name) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==expected['sha256'],name
assert archive.stat().st_size<50*1024*1024
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
validation={'base':'da6026e5e77622877a0dd0336144564952b619a0','source_sha256':frozen,'engine_sha256':headless['engine_sha256'],'negative':{'cases':5,'checks':82,'before_failures':20,'after_failures':0,'identical_probe_sha256':digest(r/'work/st9-evening-boundary/probe.gd')},'seed_provenance':headless['seed_provenance'],'affected':{'groups':int(re.search(r'Running (\d+) groups',summary)[1]),'workers':4,'checks':int(m[1]),'new_failures':0,'known_failures':0,'seconds':int(m[4])},'policy':{'checks':647,'failures':0},'headless':{'processes':12,'checks':sum(row['result']['checks'] for row in headless['cases']),'failures':0,'original_pending_primaries':headless['original_pending_primaries']},'native':{'processes':8,'checks':sum(row['checks'] for row in native),'failures':0,'cases':native},'visual':{'processes':2,'checks':sum(row['checks'] for row in visual),'failures':0,'cases':visual},'shared':shared,'archive':{'file':'evidence.zip','bytes':archive.stat().st_size,'entries':len(manifest),'sha256':digest(archive)},'limits':['Original produced handoff seed, arranged earlier disk/credits, actual lounge NPC and original decisions; not a human chapter playthrough.','Only four authored flag boundaries; existing order/payment/item results and whole-story acceptance remain separate.','Software Forward+ HDR2D; no physical GPU, controller, human-style or performance acceptance inferred.']}
(d/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
images={'reading':n/'st9-evening-visual-name-v1/reading/refused.png','evening-reading':n/'st9-evening-visual-ordered-v1/reading/refused.png','retry':n/'st9-evening-final-name-v1/refused.png','accepted':n/'st9-evening-final-evening_ordered-v1/accepted/refused.png','cold':n/'st9-evening-final-evening_sit_read-v1/cold/refused.png','cancel':n/'st9-evening-final-cancel-v1/cancelled/refused.png'}
for name,path in images.items():shutil.copyfile(path,r/'pm/ST/images'/('ST-9-ali-'+name+'.png'))
print(json.dumps({key:value for key,value in validation.items() if key not in ['source_sha256','native','seed_provenance','limits']},ensure_ascii=False))
