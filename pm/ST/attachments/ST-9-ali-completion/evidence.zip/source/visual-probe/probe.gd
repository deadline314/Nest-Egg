extends "res://tests/probes/ali_completion.gd"
## Read-only extra visual timing; all original result/refusal checks remain inherited.
func _drive() -> void:
	var deadline := Time.get_ticks_msec() + 90000
	var started_evening := false
	while Time.get_ticks_msec() < deadline:
		if faulted and (_prompt() != null or (skip_sent and Story._current_cinematic != target)):
			return
		var player: CutscenePlayer = Story._player if is_instance_valid(Story._player) else null
		if faulted and not skip_sent and is_instance_valid(player) and player.is_running():
			await _reading_picture()
			skip_sent = true
			Story.skip_cinematic()
		elif is_instance_valid(player) and player.choice_active():
			var wanted := "order" if ordered else "sit"
			if Story._current_cinematic == &"ch1_hub_ali_lounge":
				wanted = "evening"
			var index := player._choice_options.find_custom(func(option: Dictionary) -> bool: return option.get("id") == wanted)
			_check(index >= 0 and player.choose(index), "actual authored menu accepts " + wanted)
		elif is_instance_valid(player) and player.is_running() and player._dialogue.visible:
			player._dialogue.complete()
			player._advance_requested = true
		elif Story._layer.is_cinematic_active():
			Story._layer.advance()
		if not faulted and not _actor()._talking and GameState.has_flag(&"ch1_met_ali") and not started_evening:
			_check(_actor().talk_count == 1, "first genuine original meeting settles once before starting the evening encounter")
			_check(Progression.credits == 235, "original reception does not charge the unpaid 200 order")
			started_evening = true
			_actor()._talk()
		await _frames(1)
	_check(false, "authored encounter reaches its refused boundary within bounded time")


func _reading_picture() -> void:
	var deadline := Time.get_ticks_msec() + 60000
	while Time.get_ticks_msec() < deadline:
		var player: CutscenePlayer = Story._player if is_instance_valid(Story._player) else null
		if Story._current_cinematic == target and is_instance_valid(player) and player._dialogue.visible:
			player._dialogue.complete()
			await _capture("reading")
			return
		await _frames(1)
	_check(false, "actual authored reading becomes visible before its refused completion")
