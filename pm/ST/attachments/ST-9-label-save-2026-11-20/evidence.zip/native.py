from pathlib import Path
from hashlib import sha256
from subprocess import run
from shutil import copyfile
import json
import os
import sys

base = Path(__file__).resolve().parent
shared = base.parent/'ne218-baseline-20261117'
root=Path.cwd()
python = Path(sys.executable)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def render(case, scene, args, fixed):
    out=base/case
    out.mkdir(exist_ok=False)
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        var = out/'profile'/key
        var.mkdir(parents=True)
        env[key]=str(var)
    command = [str(python),str(shared/'tools/comfyui/gpu_lock.py'),'--',engine,
               '--path',str(shared),'--resolution','1280x720','--position','10,90',
               '--rendering-method','forward_plus','--rendering-driver','vulkan']
    if fixed:
        command.extend(('--fixed-fps','60'))
    command.append(str(scene))
    command.extend(('--',*[a.replace('{out}',out.as_posix()) for a in args]))
    (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=650)
    (out/'exit.txt').write_text(str(result.returncode)+'\n',encoding='utf-8')
    raw=(out/'raw.log').read_text(encoding='utf-8')
    print(case,result.returncode,len(raw),flush=True)
    assert result.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw
    return raw







seed=base.parent/'evidence-20261120-st16-pacing'/'ordinary-clean/save/slot.json'
slot=base/'slot.json'
assert seed.is_file() and not slot.exists()
copyfile(seed,slot)
record=lambda f:json.loads(f.read_bytes())
payload=lambda f:json.loads(record(f)['payload'])
original=payload(seed)
assert original['level']=='res://data/levels/ch1_pawnshop.tres' and not original['cinematic']
assert original['story']['flags']['ch1_prologue_done'] and not original['story']['flags']['ch1_prologue_skipped']
seed_hash=sha256(seed.read_bytes()).hexdigest()
(base/'seed-receipt.json').write_text(json.dumps({'path':str(seed),'sha256':seed_hash},indent=2)+'\n')
for phase in ('interrupt','finish','revisit'):
    text=render(phase,base/'cold-labels.tscn',['--out={out}',f'--phase={phase}',f'--slot={slot.as_posix()}'],True)
    assert 'FAIL ' not in text and sha256(seed.read_bytes()).hexdigest()==seed_hash
    assert record(base/phase/'round.json')['failures']==0
    game=payload(slot)
    flags=game['story']['flags']
    bits=[key for key in ('watch','guitar','raincoat','fare') if flags.get('ch1_label_'+key+'_seen')]
    assert bits==(['watch','guitar'] if phase=='interrupt' else ['watch','guitar','raincoat','fare'])
    assert game['progression']==original['progression'] and game['story']['items']==original['story']['items']
    (base/phase/'disk-receipt.json').write_text(json.dumps({'flags':bits,'cinematic':game['cinematic'],
          'slot_sha256':sha256(slot.read_bytes()).hexdigest(),'unchanged_progression':True,'unchanged_items':True},indent=2)+'\n')
