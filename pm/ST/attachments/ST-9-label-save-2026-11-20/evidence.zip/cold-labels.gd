extends "D:/NestEggVerification/evidence-20261120-st1-dialogue/labels.gd"

const RAINCOAT := &"ch1_t_label_raincoat"
const PAWNSHOP := "res://data/levels/ch1_pawnshop.tres"
var _main: Node
var _store: RunSaveStore
var _phase := ""


func _run() -> void:
	var filename := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--phase="):
			_phase = arg.trim_prefix("--phase=")
		elif arg.begins_with("--slot="):
			filename = arg.trim_prefix("--slot=")
	if _phase not in ["interrupt", "finish", "revisit"] or not filename.is_absolute_path():
		get_tree().quit(2)
		return
	_store = RunSaveStore.new(filename)
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_main.set("_run_store", _store)
	add_child(_main)
	Story.auto_skip = false
	Story.scene_started.connect(func(id: StringName, mode: StringName) -> void:
		_played.append(String(id))
		_modes[String(id)] = String(mode))
	for i in 2400:
		if _main.get("_screen") is MainMenu and not bool(_main.call("_route_pending")):
			break
		await get_tree().physics_frame
	_check(_main.get("_screen") is MainMenu and not _store.read().is_empty(), "real Main starts with the private existing save")
	_main.call("_on_continue_requested")
	for i in 2400:
		var current: Variant = _main.get("_screen")
		if current is Level and current.data.resource_path == PAWNSHOP and current.is_initialized() and not bool(_main.call("_route_pending")):
			_level = current
			break
		await get_tree().physics_frame
	_check(is_instance_valid(_level), "real Continue enters the original pawnshop")
	if not is_instance_valid(_level):
		_main.call("_quit", 1)
		return
	_check(GameState.has_flag(&"ch1_prologue_done") and not GameState.has_flag(&"ch1_prologue_skipped") and GameState.deaths==0,
		"the original completed prologue stays intact")
	var economy := Progression.snapshot()
	var items := StoryItems.snapshot()
	var marker := String(_store.read().get("cinematic", ""))
	match _phase:
		"interrupt":
			_check(_known() == [], "the actual seed has no label reads")
			await _talk(&"ch1_label_watch")
			await _talk(&"ch1_label_guitar")
			_check(_known() == ["watch", "guitar"] and _disk() == _known(),
				"both acknowledged visits have already reached the durable main slot")
			var raincoat := _object(&"ch1_label_raincoat")
			_check(is_instance_valid(raincoat), "the raincoat object exists")
			if is_instance_valid(raincoat):
				_level.player.global_position = raincoat.global_position + Vector2(-28, 0)
				_level.camera.snap_to_target()
				await _settle(12)
				raincoat._talk.call_deferred()
				for i in 600:
					if Story._current_cinematic == RAINCOAT and Story._layer.is_cinematic_active():
						Story._layer.advance()
						if DisplayServer.get_name() != "headless":
							await RenderingServer.frame_post_draw
							_capture("ST-9-raincoat-before-quit")
						break
					await get_tree().physics_frame
			_check(Story._current_cinematic == RAINCOAT and Story._layer.is_cinematic_active() and Story._layer._cinematic_index == 0
				and Story._layer._text.visible_ratio == 1.0 and _known() == ["watch", "guitar"] and _disk() == _known(),
				"normal exit starts with real unacknowledged raincoat prose and no early result")
		"finish":
			_check(_known() == ["watch", "guitar"] and _disk() == _known(),
				"cold Continue restores only the two acknowledged objects")
			_check(_object(&"ch1_label_watch").talk_count == 1 and _object(&"ch1_label_guitar").talk_count == 1,
				"restored first-read actor counts are exactly one")
			_check(not Story._completed.has(RAINCOAT), "the interrupted actor is still unread before confirmation")
			for i in 600:
				if Story._current_cinematic == RAINCOAT or bool(_level.get("_resumed_presentation_settled")):
					break
				await get_tree().physics_frame
			_check(Story._current_cinematic == RAINCOAT, "Continue replays the actual interrupted raincoat")
			if Story._current_cinematic == RAINCOAT:
				await _drive([], func() -> bool: return bool(_level.get("_resumed_presentation_settled")))
			_check(bool(_level.get("_resumed_presentation_completed")), "the replay completes through the original object owner")
			_check(_known() == ["watch", "guitar", "raincoat"] and _disk() == _known(), "the first genuinely finished raincoat visit is durable once")
			await _talk(&"ch1_label_fare")
			_check(_known() == ["watch", "guitar", "raincoat", "fare"] and _disk() == _known(),
				"the final different item completes the durable collection")
		"revisit":
			_check(_known() == ["watch", "guitar", "raincoat", "fare"] and _disk() == _known(),
				"second cold Continue keeps all four first-read state bits")
			_played.clear()
			for label: String in LABELS:
				var id := StringName("ch1_label_" + label)
				var actor := _object(id)
				_check(is_instance_valid(actor) and actor.talk_count == 1, label + " has exactly one saved original settlement")
				_revisit = "ch1_t_label_" + label + "_revisit"
				_expected = Story.audit_data()["scenes"][_revisit]["steps"][1]["text"]
				_captured = false
				await _talk(id)
				_check(_captured, "the actual short " + label + " variant displays after cold Continue")
			_check(_texts.size() == 4 and _known() == ["watch", "guitar", "raincoat", "fare"] and _disk() == _known(),
				"the four reprises keep the completed collection stable")
	_check(economy == Progression.snapshot() and items == StoryItems.snapshot(), "no label visit or restore emits a reward, receipt or transferable item")
	_check(GameState.has_flag(&"sq8_first_labels_done") == (_known().size() == LABELS.size()), "the overall objective follows exactly the four source flags")
	var file := FileAccess.open(_out_dir.path_join("round.json"), FileAccess.WRITE)
	if file == null:
		_main.call("_quit", 2)
		return
	file.store_string(JSON.stringify({"phase": _phase, "known": _known(), "disk": _disk(), "observed_entry_marker": marker,
		"failures": _failures, "rendered": _texts, "played": _played}, "  "))
	file.close()
	_main.call("_quit", 1 if _failures > 0 else 0)


func _known() -> Array[String]:
	var labels: Array[String] = []
	for label: String in LABELS:
		if GameState.has_flag(StringName("ch1_label_" + label + "_seen")):
			labels.append(label)
	return labels


func _disk() -> Array[String]:
	var flags: Dictionary = _store.read().get("story", {}).get("flags", {})
	var labels: Array[String] = []
	for label: String in LABELS:
		if bool(flags.get("ch1_label_" + label + "_seen", false)):
			labels.append(label)
	return labels


func _drive(choices: Array, finished: Callable) -> void:
	if Story._layer.is_cinematic_active():
		for i in STEP_LIMIT:
			if finished.call():
				return
			if Story._layer.is_cinematic_active():
				Story._layer.advance()
			await get_tree().physics_frame
		_check(false, "ordinary dialogue completes through its real confirm path")
	else:
		await super._drive(choices, finished)