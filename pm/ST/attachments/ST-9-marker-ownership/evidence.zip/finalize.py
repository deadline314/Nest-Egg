from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
root=Path('work/story-marker-save')
def cases(name):
 rows=json.loads((root/name/'receipt.json').read_text())['cases']
 assert rows and all(c['passed'] for c in rows), name
 return {'processes':len(rows),'checks':sum(c['result']['checks'] for c in rows),'failures':0}
results={name:cases(name) for name in ['after','matrix-final','handoff','sunday','clinic','native']}
assert results['matrix-final']['processes']==31
assert results['after']['processes']==4
assert results['native']['processes']==6
assert results['clinic']['processes']==4
before=json.loads((root/'before/receipt.json').read_text()); assert before['git_clean'] and before['base']=='92d62c08d711f6d2a5d13e8ecb6f240c269ebdc8'
negative={'processes':len(before['cases']),'checks':sum(c['result']['checks'] for c in before['cases']),'failures':sum(len(c['result']['failures']) for c in before['cases'])}
console=(root/'required-runner.log').read_text(); m=re.search(r'checks: (\d+), new failures: 0, known failures .*: 0  \(wall time (\d+) s\)',console); assert m
assert 'diagnostics=0' in (root/'dummy-exit.log').read_text()
assert not re.search(r'SCRIPT ERROR|Parse Error|Compile Error|^ERROR:',(root/'final-import.log').read_text(),re.M)
source=root/'delivery-source';source.mkdir(exist_ok=False)
for name in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines():
 p=Path(name)
 if p.is_file():
  target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
shutil.copyfile('/workspace/.nest-egg-env/ci-godot/dist/receipt.json',root/'engine-receipt.json')
folder=Path('pm/ST/attachments/ST-9-marker-ownership');folder.mkdir(exist_ok=False)
images={'native/label-missing/label-missing-refused.png':'refused','native/label-missing/label-missing-accepted.png':'label','native/gate-missing/gate-missing-accepted.png':'gate','native/item-missing/item-missing-accepted.png':'item'}
for name,label in images.items():shutil.copyfile(root/name,Path('pm/ST/images')/('ST-9-marker-'+label+'.png'))
with zipfile.ZipFile(folder/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in {'.json','.log','.exit','.gd','.tscn','.py','.png','.txt','.sh'} and '__pycache__' not in p.parts:
   archive.write(p,str(p.relative_to(root)))
receipt={'base':before['base'],'negative':negative,**results,'required':{'groups':7,'checks':int(m[1]),'seconds':int(m[2]),'new_failures':0,'known_failures':0},'archive_sha256':hashlib.sha256((folder/'evidence.zip').read_bytes()).hexdigest()}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
r=results['matrix-final'];n=results['native'];reg=sum(results[k]['checks'] for k in ['handoff','sunday','clinic'])
(folder/'README.md').write_text(f'''# ST-9：政策資料損壞時保留有限來源所有權

乾淨92d62c08的原當舖錶標籤、巡帳員與租契物件，在已保存原主檔後，明示刪除載入政策，再透過真正原NPC互動及閱讀鍵完成。另真的選擇一個植入的選項，證明政策一起遺失會繞過原未登記選項門。四程序{negative['checks']}項有{negative['failures']}失敗；不是資源載入錯誤或以測試直接設結果。相同四程序修後{results['after']['checks']}項全過；選項修前通知觀察產生的額外檢查會在修後沒有通知時消失，原比較保留。

結果控制先依獨立來源判定所有權，再嚴格檢查載入契約。九個原已支援終點補齊原模式／條件／結果，不改作者台詞、政策或玩法。政策缺失、錯型或換成其他合法owner均不能落入legacy。語義不符提供原整輪恢復；原IO拒寫仍保留原互動重試。未知未標記段落的舊行為保持。

正式矩陣{r['processes']}程序{r['checks']}項全過，其中獨立audit核對43個宣告來源及43份契約（86項），三個真原互動各驗缺失、換政策、錯型、缺失加未登記選項、正常IO拒寫，並各有另一程序冷讀。每份原結果通知檢查已安裝live旗標／歷史／物品與原人物次數，保留通知當下帶原checksum的主檔，三份raw world次數均為1。

初次正式fixture錯把Main正常對話入口存檔當成提交，並錯以為恢復後不會續播。保留matrix初次失敗，修正測試觀察點：真正開始對話並讓入口保存後才取基線；原進度恢復重新播放未讀對話，讀完後才要求釋放所有鎖。matrix-v2與最後加入audit的matrix-final保留完整過程。修復步驟明示還原測試破壞的載入字典，再按真正原進度恢復；沒有宣稱讀檔會自己修復壞掉的作者資源。

原交接櫃三次物品操作、週日追問、診間原取物／離開／待取冷讀共{reg}項全過。診間是明示挑選retry_take、normal_leave、write_take、read_take四項原案例；沒有改原runner或放寬門檻。原選擇器仍要求7組{int(m[1]):,}項，0新／已知失敗、{int(m[2])}秒，六份完整日誌另驗DummyTexture0；選擇器與已知失敗清單未改。最終editor import無腳本、編譯或ERROR診斷。

Forward+／軟體Vulkan三個實際互動的缺失政策、原進度恢復續讀與另程序冷讀共{n['processes']}程序{n['checks']}項全過，完整日誌無嚴格錯誤。四張交付原圖均看過，標籤／巡帳員／租契可看到原人物及原物件。恢復提示使用原既有覆層。位置、前置簡報／原檢查卡是明示安排，未直接設本次完成結果；不代稱自然整章通關。

引擎是與CI同來源／修補／選項的本機4.7.2建置（receipt有來源及SHA），編譯器不同，不聲稱二進位相同。軟體Vulkan不代稱硬體GPU、真人或實體手把驗收。[完整證據](evidence.zip)、[摘要](receipt.json)。
''')
p=Path('pm/ST/[ST-9]把第一章劇本接進遊戲.md')
with p.open('a') as stream:
 stream.write(f'''

# Commit-30（損壞標記不繞過原保存保護）

## 內文

原本事件的保存標記遺失時，閱讀標籤、查核或取得證據仍可能提前完成，甚至繞過未支援的選項限制。現在已納管的事件即使標記遺失、錯型或被替換，都保留原保存保護；無效內容提供恢復原進度，正常磁碟拒寫仍可重試。修復內容後恢復原未讀對話，真正完成並保存才一起公開結果與回訪次數。

原版4程序{negative['checks']}項有{negative['failures']}失敗，相同拒寫樣本修後全過。正式{r['processes']}程序{r['checks']}項、原交接／週日／診間{reg}項、受影響7組{int(m[1]):,}項全過。原生軟體Vulkan{n['processes']}程序{n['checks']}項全過；樣本明示安排原互動位置與前置條件。

![資料無效時恢復原進度](images/ST-9-marker-refused.png)
![原標籤恢復後讀完](images/ST-9-marker-label.png)
![原租契恢復後取得](images/ST-9-marker-item.png)

[原始失敗、測試假設修正、完整主檔及驗證](attachments/ST-9-marker-ownership/README.md)。
''')
print(json.dumps(receipt,indent=2))
