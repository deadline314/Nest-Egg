set -e
source /workspace/.nest-egg-env/activate.sh
engine=/workspace/.nest-egg-env/ci-godot/dist/godot
root=/workspace/Nest-Egg/work/story-marker-save/native
mkdir -p "$root"
for producer in label gate item; do
 for mode in missing missing_read; do
  XDG_DATA_HOME="$root/$producer-$mode-profile" python3 tools/comfyui/gpu_lock.py -- xvfb-run -a -s '-screen 0 1280x720x24' "$engine" --path . --rendering-method forward_plus --rendering-driver vulkan --audio-driver Dummy res://tests/probes/story_marker_completion.tscn -- --mode="$producer--$mode" --save-dir="$root/$producer-slot" --out="$root/$producer-$mode" > "$root/$producer-$mode.log" 2>&1
  echo "$producer $mode complete"
 done
done
