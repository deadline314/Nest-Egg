extends "res://tests/probes/channel_completion.gd"
const TARGET := &"ch2_t_s05_gate"
func _ready() -> void:
 super._ready()
 CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
func _run() -> void:
 _main=load("res://game/main.gd").new()
 var store:=RunSaveStore.new(_save_dir.path_join("slot.json"))
 _main.set("_run_store",store)
 add_child(_main)
 await _frames(8)
 _main.call("_on_start_requested",GameState.difficulties[1])
 await _frames(90)
 await _finish_story()
 await _wait_control()
 _main.call("_on_area_requested","res://data/levels/ch2_market_gate.tres")
 await _frames(12)
 await _finish_story()
 await _wait_control()
 # Explicit prior briefing/card and position fixture; not a chapter playthrough.
 GameState.set_flag(&"ch2_brief_done",true,false)
 StoryItems.acquire(&"ch2_check_card",false)
 var npc: NpcActor
 for node in _level()._entities.get_children():
  if node is NpcActor and node.data.id==&"ch2_patroller":npc=node
 _check(npc!=null,"real Main owns the original authored second-chapter patroller")
 if npc==null:await _done();return
 _player().global_position=npc.global_position+Vector2(-32,0)
 _player().velocity=Vector2.ZERO
 _player().set_physics_process(false)
 await _frames(4)
 _check(Story.resolve_dispatch(npc.data.talks[0].scene)==TARGET and not GameState.has_flag(&"ch2_gate_checked"),"declared prior briefing routes the original actor to its real uncompleted check")
 _main.call("_save_run")
 _before=FileAccess.get_file_as_bytes(store.path)
 _check(not _before.is_empty() and DirAccess.make_dir_absolute(store.path+".tmp")==OK,"owned refusal follows an ordinary complete original primary")
 var starts: Array[StringName]=[]
 Story.scene_started.connect(func(id: StringName, _mode: StringName)->void: starts.append(id))
 Story._scenes[String(TARGET)].erase("completion_policy") # Declared metadata corruption, never a result flag.
 var before_count:=npc.talk_count
 var done: Array[bool]=[false,false]
 var talk:=func()->void:
  done[1]=await npc._talk()
  done[0]=true
 talk.call()
 for i in 1800:
  if done[0] or _prompt()!=null:break
  var event:=InputEventAction.new()
  event.action=&"ui_accept"
  event.pressed=true
  Input.parse_input_event(event)
  Input.flush_buffered_events()
  event=event.duplicate()
  event.pressed=false
  Input.parse_input_event(event)
  Input.flush_buffered_events()
  await _frames(1)
 await _frames(4)
 _check(starts.has(TARGET),"actual original NPC interaction presents the authored gate check")
 _check(not GameState.has_flag(&"ch2_gate_checked"),"refused real patroller result cannot publish its gate flag")
 _check(not Story._completed.has(TARGET),"refused patroller reading cannot become completed history")
 _check(not done[0] and npc.talk_count==before_count,"refused patroller result retains its original waiter and count")
 _check(FileAccess.get_file_as_bytes(store.path)==_before,"refused patroller result preserves exact whole original primary bytes")
 _check(_prompt()!=null and get_tree().paused,"refused original check owns a retryable presentation")
 await _done()
func _prompt() -> Control:
 var owner: Node=_main.get("_result_completion")
 return owner.get("_prompt") as Control if is_instance_valid(owner) else null
