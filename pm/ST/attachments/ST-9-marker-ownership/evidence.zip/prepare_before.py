from pathlib import Path
root=Path('work/story-marker-save')
gate=Path('work/ch2-gate-save/probe.gd').read_text().replace(' var before_count:=npc.talk_count',' Story._scenes[String(TARGET)].erase("completion_policy") # Declared metadata corruption, never a result flag.\n var before_count:=npc.talk_count')
(root/'gate.gd').write_text(gate)
label=gate.replace('ch2_t_s05_gate','ch1_t_label_watch').replace('ch2_patroller','ch1_label_watch').replace('ch2_market_gate','ch1_pawnshop').replace('ch2_gate_checked','ch1_label_watch_seen').replace('through-ch2_heron','through-ch1_kasa').replace(' GameState.set_flag(&"ch2_brief_done",true,false)\n','').replace(' StoryItems.acquire(&"ch2_check_card",false)\n','')
label=label.replace('second-chapter patroller','first-chapter original watch label').replace('declared prior briefing routes','actual default state routes').replace('patroller','label')
(root/'label.gd').write_text(label)
item=Path('work/ch2-evidence-save/probe.gd').read_text().replace(' var count:=npc.talk_count',' Story._scenes[String(_definition.scene)].erase("completion_policy") # Declared metadata corruption.\n var count:=npc.talk_count')
(root/'item.gd').write_text(item)
choice=Path('tests/probes/patroller_completion.gd').read_text().replace('\t\tscene["mode"]="animated"','\t\tscene.erase("completion_policy") # Only the owned marker is missing.\n\t\tscene["mode"]="animated"')
(root/'choice.gd').write_text(choice)
for name in ['gate','label','item','choice']:
 (root/(name+'.tscn')).write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/story-marker-save/'+name+'.gd" id="1"]\n[node name="MarkerOwnershipProbe" type="Node"]\nscript = ExtResource("1")\n')
