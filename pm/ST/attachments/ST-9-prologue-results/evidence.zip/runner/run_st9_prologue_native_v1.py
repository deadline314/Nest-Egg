from pathlib import Path
import os,subprocess,json,shutil
w=Path('/workspace/Nest-Egg/work/batch1026');n=Path('/workspace/Nest-Egg/work/batch1020b');r=w/'dummy-texture-worktree';e=os.environ.copy();e.update(NE_NATIVE_PROJECT='../batch1026/dummy-texture-worktree',NE_NATIVE_GODOT=str(w/'godot-texture-build/dist/godot'))
rows=[]
for mode in ['fall_retry','fall_pending','call_pending','call_pending_read','clean_skip']:
 tag='st9-prologue-'+mode.replace('_','-')+'-native-v1';slot=w/(tag+'-slot');slot.mkdir()
 if mode=='call_pending_read':source=w/'st9-prologue-call-pending-native-v1-slot/pending-primary.json'
 else:source=r/'tests/fixtures/prologue_counter'/(mode.split('_')[0]+'.json')
 shutil.copyfile(source,slot/'slot.json')
 with (w/(tag+'-wrapper.log')).open('w') as out:
  x=subprocess.run(['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://tests/probes/prologue_completion.tscn','--mode='+mode,'--save-dir='+str(slot)],cwd='/workspace/Nest-Egg',env=e,stdout=out,stderr=subprocess.STDOUT)
 (w/(tag+'-wrapper.exit')).write_text(str(x.returncode)+'\n');v=json.loads((n/tag/'result.json').read_text());raw=(n/(tag+'.log')).read_text();passed=x.returncode==0 and not v['failures'] and not any(s in raw for s in ['ERROR:','SCRIPT ERROR:','leaked at exit','were leaked','resources still in use','handle_crash:']);rows.append({'tag':tag,'mode':mode,'checks':v['checks'],'passed':passed});(w/'st9-prologue-native-v1.json').write_text(json.dumps({'cases':rows},indent=2)+'\n');print(rows[-1],flush=True)
 if not passed:raise SystemExit(1)
