from pathlib import Path
import json,hashlib,re,zipfile,shutil,subprocess
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'dummy-texture-worktree';n=Path('/workspace/Nest-Egg/work/batch1020b');d=r/'pm/ST/attachments/ST-9-prologue-results'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
frozen=json.loads((w/'st9-prologue-final-source-v1.json').read_text())
for f,h in frozen.items():assert sha(r/f)==h,f
assert (w/'st9-prologue-final-v1.exit').read_text().strip()=='0'
clinic=json.loads((w/'st9-prologue-clinic-v1/receipt.json').read_text());assert len(clinic['cases'])==29 and all(x['passed'] for x in clinic['cases']);assert sum(x['result']['checks'] for x in clinic['cases'])==385
pub=json.loads((w/'st9-prologue-published-v1/receipt.json').read_text());assert len(pub['cases'])==27 and all(x['passed'] for x in pub['cases']);assert sum(x['result']['checks'] for x in pub['cases'])==337
for f,h in pub['source_sha256'].items():assert sha(r/f)==h,f
before=json.loads((w/'st9-prologue-before-summary-v1.json').read_text());assert before['checks']==58 and before['failures']==6
after=json.loads((w/'st9-prologue-original-after-v1/receipt.json').read_text());assert len(after['cases'])==3 and all(x['passed'] for x in after['cases']);assert sum(x['result']['checks'] for x in after['cases'])==58
assert sha(r/'tests/probes/prologue_original.gd')=='84d5cd005176843c2eb86be06771f0af48db412d75170f3ee53053bd53c4aa71'
fast_before=json.loads((w/'st9-prologue-fast-before-v1/receipt.json').read_text());fast_after=json.loads((w/'st9-prologue-fast-after-v1/receipt.json').read_text());assert all(len(x['result']['failures'])==2 for x in fast_before['cases']) and all(x['passed'] for x in fast_after['cases'])
log=(w/'st9-prologue-affected-v1.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',log);assert m and m[2]==m[3]=='0';assert 'DUMMY_TEXTURE_EXIT_CHECK logs=4 diagnostics=0' in log
native=json.loads((w/'st9-prologue-native-v1.json').read_text())['cases'];assert len(native)==5 and all(x['passed'] for x in native) and sum(x['checks'] for x in native)==60
visual=json.loads((w/'st9-prologue-visual-review-v1.json').read_text());assert visual['all_originals_viewed'] and len(visual['originals'])==6
for row in visual['originals']:assert sha(n/row['path'])==row['sha256']
entries={}
def add(key,p):
 if p.is_file():entries[key]=p

def tree(prefix,root):
 for p in root.rglob('*'):
  if p.is_file() and not any(x.endswith('-profile') or x in ['.godot','__pycache__'] for x in p.relative_to(root).parts):add(prefix+'/'+str(p.relative_to(root)),p)
for f in set(frozen)|set(pub['source_sha256']):add('source/final/'+f,r/f)
add('source/final/design/20-campaign-experience/PROLOGUE_COUNTER_RESULTS.md',r/'design/20-campaign-experience/PROLOGUE_COUNTER_RESULTS.md')
for p in (r/'work').glob('st9-prologue-*'):
 if p.is_dir():tree('source/private/'+p.name,p)
for p in w.glob('st9-prologue-*'):
 if p.is_file() and p.suffix in ['.json','.log','.exit','.md'] and not p.name.startswith('st9-prologue-package'):add('records/'+p.name,p)
 elif p.is_dir():
  if p.name.endswith('-shards'):
   for f in p.glob('*.log'):add('tests/'+p.name+'/'+f.name,f)
  else:tree('runs/'+p.name,p)
for row in native:
 tag=row['tag'];tree('native/'+tag,n/tag)
 for suffix in ['.log','.exit','-xvfb.log']:add('native/'+tag+suffix,n/(tag+suffix))
for p in w.glob('run_st9_prologue_*.py'):add('runner/'+p.name,p)
for f in ['package_st9_prologue_v1.py','st9-clinic-main-sync.json','st9-clinic-push-result.json','bg51-ci-receipt.json','bg51-ci-watch.log']:add('runner/'+f,w/f)
add('engine/receipt.json',w/'godot-texture-build/dist/receipt.json');tree('research',d/'research')
archive=d/'evidence.zip';manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for key,p in sorted(entries.items()):manifest[key]={'bytes':p.stat().st_size,'sha256':sha(p)};z.write(p,key)
with zipfile.ZipFile(archive) as z:
 for key,row in manifest.items():
  with z.open(key) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256'],key
assert archive.stat().st_size<50*1024*1024
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
validation={'base':'a4c4c93e407f4866ec5811a508d0bde00ee4b78d','source_sha256':frozen,'engine_sha256':pub['engine_sha256'],'original_negative':{'processes':3,'checks':58,'before_failures':6,'after_failures':0,'identical_probe_sha256':sha(r/'tests/probes/prologue_original.gd')},'fast_seed_control':{'processes':3,'checks':sum(x['result']['checks'] for x in fast_after['cases']),'before_failures':6,'after_failures':0},'published':{'processes':27,'checks':337,'failures':0,'seconds':pub['wall_seconds']},'affected':{'groups':int(re.search(r'Running (\d+) groups',log)[1]),'workers':4,'checks':int(m[1]),'new_failures':0,'known_failures':0,'seconds':int(m[4]),'dummy_exit_diagnostics':0},'previous_clinic_regression':{'processes':29,'checks':385,'failures':0},'compiler':json.loads((w/'st9-prologue-compiler-v1.json').read_text()),'policy_compiler_tests':{'tests':6,'failures':0},'native':native,'archive':{'bytes':archive.stat().st_size,'entries':len(manifest),'sha256':sha(archive)},'limits':['Exact actual-training Main primaries; fast source cases move player into same counter interaction range. Separate full-input controls walk through original actual training.','Software Forward+ HDR2D with Dummy audio; physical GPU/controller and human tutorial timing/style gates remain open.','Policy declaration audit does not certify every world-event flag or automatic item producer. Mother ticket is not automatically closed.','GitHub detailed CI query previously returned HTTP401; no retry or bypass. Local checks do not certify this commit remote CI.']}
(d/'validation.json').write_text(json.dumps(validation,indent=2)+'\n');shutil.copyfile(w/'st9-prologue-visual-review-v1.json',d/'visual-review.json')
for tag,source,label in [('fall-retry','refused','refused'),('fall-retry','complete','saved'),('fall-pending','pending','service'),('call-pending','pending','call'),('call-pending-read','complete','cold'),('clean-skip','complete','skip')]:
 src=n/('st9-prologue-'+tag+'-native-v1')/(source+'.png');dest=r/'pm/ST/images'/('ST-9-prologue-results-'+label+'.png');assert not subprocess.check_output(['git','ls-files','--',str(dest.relative_to(r))],cwd=r,text=True),'Existing tracked image must be preserved';assert not dest.exists() or dest.read_bytes()==src.read_bytes();shutil.copyfile(src,dest)
print(json.dumps({k:v for k,v in validation.items() if k not in ['source_sha256','compiler']},indent=2))
