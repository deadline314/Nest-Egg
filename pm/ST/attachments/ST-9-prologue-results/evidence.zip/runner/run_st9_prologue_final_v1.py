from pathlib import Path
import subprocess,json,hashlib,os
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'dummy-texture-worktree';engine=w/'godot-texture-build/dist/godot';frozen=json.loads((w/'st9-prologue-final-source-v1.json').read_text())
def unchanged():
 for f,h in frozen.items():assert hashlib.sha256((r/f).read_bytes()).hexdigest()==h,f
assert (w/'st9-prologue-published-v1.exit').read_text().strip()=='0';assert (w/'st9-prologue-native-v1.exit').read_text().strip()=='0';unchanged()
name='st9-prologue-affected-v1';e=os.environ.copy();e.update(GODOT=str(engine),SHARDS='4',LOG_DIR=str(w/(name+'-shards')));print('START affected',flush=True)
with (w/(name+'.log')).open('w') as out:code=subprocess.run(['bash','tools/run_tests_changed.sh','origin/main'],cwd=r,env=e,stdout=out,stderr=subprocess.STDOUT).returncode
(w/(name+'.exit')).write_text(str(code)+'\n');assert code==0,name
with (w/(name+'.log')).open('a') as out:subprocess.run(['python3','tools/check_dummy_texture_exit.py',str(w/(name+'-shards'))],cwd=r,stdout=out,stderr=subprocess.STDOUT,check=True)
unchanged();print('PASS affected',flush=True)
name='st9-prologue-clinic-v1';print('START delivered clinic source',flush=True)
with (w/(name+'.log')).open('w') as out:code=subprocess.run(['python3','tools/run_clinic_completion.py','--godot',str(engine),'--output',str(w/name)],cwd=r,stdout=out,stderr=subprocess.STDOUT).returncode
(w/(name+'.exit')).write_text(str(code)+'\n');assert code==0,name;unchanged();print('ALL FINAL CHECKS PASS',flush=True)
