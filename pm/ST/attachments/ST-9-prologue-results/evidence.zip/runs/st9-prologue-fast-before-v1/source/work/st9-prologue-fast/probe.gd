extends "res://tests/helpers/ali_completion_base.gd"
## Original exact training-produced Main primary; actual counter actor and dialogue.
const TARGETS := {"fall":&"ch1_p05_service_fall","clean":&"ch1_p05_service_clean","call":&"ch1_p06_call"}

func _run() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
	Transition.instant = true
	Story.auto_skip = false
	target = TARGETS[_mode]
	_main = MainScript.new()
	store = RunSaveStore.new(_directory.path_join("slot.json"))
	_main.set("_run_store",store)
	add_child(_main)
	await _frames(5)
	_main.call("_on_continue_requested")
	await _until(func() -> bool: return _main.get("_screen") is Level and (_main.get("_screen") as Level).is_initialized() and not _main.call("_route_pending"))
	await _frames(8)
	await _until(func() -> bool: return _actor() != null and _actor().is_present() and not Story.is_cinematic_active() and not GameplayLock.is_locked())
	_check(GameState.has_flag(&"ch1_prologue_dash_done") and GameState.deaths == 0 and not GameState.has_flag(&"ch1_first_death_done"),"exact original primary retains actual completed training and no genuine death")
	_check(GameState.has_flag(&"ch1_prologue_fall_shown") == (_mode != "clean"),"exact original primary retains its genuine training-fall variant")
	_check(not GameState.has_flag(&"ch1_prologue_done") and GameState.has_flag(&"ch1_prologue_service_heard") == (_mode == "call"),"no result is arranged beyond the exact original producer primary")
	var actor := _actor()
	(_main.get("_screen") as Level).player.global_position = actor.global_position + Vector2(14,0)
	await _frames(4)
	Story.scene_started.connect(_inject)
	actor._talk()
	var deadline := Time.get_ticks_msec()+30000
	while Story.is_cinematic_active() and _prompt() == null and Time.get_ticks_msec() < deadline:
		if Story._layer.is_cinematic_active():
			Story._layer.advance()
		await _frames(1)
	await _frames(4)
	_check(faulted,"same real counter and original dispatcher reach the actual selected result")
	_check(_facts() == facts_before,"actual write refusal preserves all services and original counter completion")
	_check(FileAccess.get_file_as_bytes(store.path) == original,"actual refusal retains exact previous primary bytes")
	_check(_prompt() != null and Story._current_cinematic == target and actor._talking and actor.talk_count == before_count and get_tree().paused,"actual refusal retains same counter waiter and its real retry modal")
	await _shot()
	_check(DirAccess.remove_absolute(store.path+".tmp") == OK,"remove only owned empty IO obstruction")
	await _finish()

func _actor() -> NpcActor:
	if not is_instance_valid(_main) or not _main.get("_screen") is Level:
		return null
	for node: Node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and node.data.id == &"ch1_old_k_counter" and (_main.get("_screen") as Level).is_ancestor_of(node):
			return node
	return null

func _facts() -> PackedByteArray:
	return var_to_bytes([super._facts(),_actor().talk_count])

func _inject(id: StringName, kind: StringName) -> void:
	super._inject(id,kind)
	if faulted and id == target:
		FileAccess.open(_directory.path_join("refused-primary.json"),FileAccess.WRITE).store_buffer(original)
		FileAccess.open(_directory.path_join("facts-before.bin"),FileAccess.WRITE).store_buffer(facts_before)

func _shot() -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	DirAccess.make_dir_recursive_absolute(out)
	preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(out.path_join("refused.png"))

func _finish() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	FileAccess.open(out.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify({"mode":_mode,"checks":_checks,"failures":Array(_failures),"target":String(target),"before_count":before_count,"talks":_actor().talk_count,"flags":GameState.world_flags,"current":String(Story._current_cinematic),"deaths":GameState.deaths},"  "))
	_main.call("_quit",0 if _failures.is_empty() else 1)
