import hashlib,json,os,pathlib,re,shutil,subprocess
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=pathlib.Path('/workspace/Nest-Egg/work/batch1020b');env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(w/'godot-audio-build/dist/godot'))
jobs=[('accept',w/'handoff-mid-primary-before-v2.json'),('receipt',w/'handoff-mid-receipt-v3-save-slot.json-pending.json')]
records=[]
for part,original in jobs:
 tag='st9-counter-old-pending-'+part+'-v1';slot=w/(tag+'-save');slot.mkdir(exist_ok=False);shutil.copyfile(original,slot/'slot.json');digest=hashlib.sha256(original.read_bytes()).hexdigest();assert hashlib.sha256((slot/'slot.json').read_bytes()).hexdigest()==digest
 command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://work/st10-handoff/mid.tscn','--mode=mid_'+part+'_read','--save-dir='+str(slot)]
 with (w/(tag+'-console.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 data=json.loads((n/tag/'result.json').read_text());log=(n/(tag+'.log')).read_text();engine_exit=int((n/(tag+'.exit')).read_text());clean=not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use|^FAIL ',log,re.M)
 record={'tag':tag,'primary_source':original.name,'primary_sha256':digest,'checks':data['checks'],'failures':data['failures'],'exit':code,'engine_exit':engine_exit,'clean':clean};records.append(record);(w/'st9-counter-old-pending-v1.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 assert code==0 and engine_exit==0 and clean and not data['failures'],record
print('BOTH UNCHANGED ORIGINAL PENDING SLOTS PASSED',flush=True)
