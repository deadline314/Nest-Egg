import hashlib,json,pathlib,re,shutil,zipfile
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=pathlib.Path('/workspace/Nest-Egg/work/batch1020b');d=r/'pm/ST/attachments/ST-9-handoff-counters'
assert (w/'st9-counter-merged-v1.exit').read_text().strip()=='0'
assert (w/'st9-counter-ci-style-v4.exit').read_text().strip()=='0'
frozen=json.loads((w/'st9-counter-frozen-source-v2.json').read_text())
for name,h in frozen['files'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==h,name
before=json.loads((w/'st9-counter-before-v1-receipt.json').read_text());after=json.loads((w/'st9-counter-after-v1-receipt.json').read_text());assert before['checks']==after['checks']==103 and before['failures']==15 and after['failures']==0 and after['same_probe_as_before']
ci=json.loads((w/'st9-counter-ci-style-v4/receipt.json').read_text());assert len(ci['cases'])==2 and all(case['passed'] for case in ci['cases'])
legacy=json.loads((w/'st9-counter-legacy-v1.json').read_text());pending=json.loads((w/'st9-counter-old-pending-v1.json').read_text());assert len(legacy)==8 and len(pending)==2
assert all(row['exit']==0 and row['engine_exit']==0 and row['clean'] and not row['failures'] for row in legacy+pending)
text=(w/'st9-counter-merged-v1.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)\s+\(wall time (\d+) s\)',text);assert m and m[2]=='0' and m[3]=='0'
d.mkdir(parents=True,exist_ok=True);(d/'.gdignore').touch();entries={}
def add(name,path):
 if path.is_file():entries[name]=path

def tree(prefix,path):
 for p in sorted(path.rglob('*')):
  if p.is_file() and not any(part.endswith('-profile') or part=='.godot' for part in p.relative_to(path).parts):add(prefix+'/'+str(p.relative_to(path)),p)

def digest_file(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

for name in frozen['files']:add('source/after/'+name,r/name)
tree('source/before',w/'st9-counter-source-before-v1')
for name in ['work/st9-person-completion/base.gd','work/st9-person-completion/probe.gd','work/st9-person-completion/probe.tscn','tools/quest_resume_probe.gd']:add('legacy-source/'+name,r/name)
tags=['st9-handoff-counters-before-v1','st9-handoff-counters-after-v1']+[row['tag'] for row in legacy+pending]
for tag in tags:
 tree('native/'+tag,n/tag)
 for suffix in ['.log','.exit','-xvfb.log']:add('native/'+tag+suffix,n/(tag+suffix))
for version in [1,2,3,4]:tree('headless/ci-style-v'+str(version),w/('st9-counter-ci-style-v'+str(version)))
for name in ['st9-counter-before-v1-save','st9-counter-after-v1-save']+[row['tag']+'-save' for row in pending]:tree('slots/'+name,w/name)
for directory in sorted(w.glob('st9-counter-legacy-*-v1-save')):tree('slots/'+directory.name,directory)
for p in sorted(w.glob('st9-counter-*')):
 if p.is_file() and p.suffix in ['.log','.exit','.json','.py','.txt']:add('logs/'+p.name,p)
for prefix in ['st9-counter-affected-v1-shards','st9-counter-merged-v1-shards']:
 for p in (w/prefix).glob('*.log'):add('tests/'+prefix+'/'+p.name,p)
for p in w.glob('run_st9_counter_*.py'):add('runner/'+p.name,p)
for name in ['handoff-mid-primary-before-v2.json','handoff-mid-receipt-v3-save-slot.json-pending.json']:add('original-pending/'+name,w/name)
add('runner/package_st9_counters.py',pathlib.Path(__file__))
add('research/ink-reading.json',w/'st9-ink-research.json')
archive=d/'evidence.zip';manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,path in sorted(entries.items()):
  h=digest_file(path);manifest[name]={'bytes':path.stat().st_size,'sha256':h};z.write(path,name)
with zipfile.ZipFile(archive) as z:
 for name,expected in manifest.items():
  with z.open(name) as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected['sha256'],name
assert archive.stat().st_size<50*1024*1024
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
validation={'source':frozen,'engine_sha256':ci['engine_sha256'],'before':before,'after':after,'headless':{'processes':len(ci['cases']),'checks':sum(case['result']['checks'] for case in ci['cases']),'failures':0},'affected':{'groups':int(re.search(r'Running (\d+) groups',text)[1]),'checks':int(m[1]),'new_failures':0,'known_failures':0,'seconds':int(m[4])},'legacy':{'processes':len(legacy),'checks':sum(row['checks'] for row in legacy),'failures':0,'cases':legacy},'original_pending':{'processes':len(pending),'checks':sum(row['checks'] for row in pending),'failures':0,'cases':pending},'archive':{'file':archive.name,'entries':len(entries),'bytes':archive.stat().st_size,'sha256':digest_file(archive)},'boundaries':['Actual Main with arranged disk and explicit NPC choices; not a human chapter playthrough.','Software Vulkan Forward+, HDR2D, Dummy mixing; physical devices and hardware GPU are separate.','Only existing reward-free terminal producers are handled; general story results, continuations and other source kinds retain their original requirements.']}
(d/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
images={'accepted':n/'st9-handoff-counters-after-v1/ch1_t_handoff_summary-accepted.png','retry':n/'st9-handoff-counters-after-v1/ch1_t_handoff_receipt-refused.png','legacy-reading':n/'st9-counter-legacy-ch1_egret-write-v1/reading.png','legacy-cold':n/'st9-counter-legacy-ch1_label_watch-dawn-continue-v1/continued.png'}
(r/'pm/ST/images').mkdir(exist_ok=True)
for name,path in images.items():shutil.copyfile(path,r/'pm/ST/images'/('ST-9-handoff-counters-'+name+'.png'))
print(json.dumps({'archive':validation['archive'],'affected':validation['affected'],'headless':validation['headless'],'legacy_checks':validation['legacy']['checks'],'pending_checks':validation['original_pending']['checks']}))
