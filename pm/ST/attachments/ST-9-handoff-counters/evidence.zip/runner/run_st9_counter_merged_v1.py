import os,pathlib,subprocess,hashlib,json
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';env=os.environ.copy();env.update(GODOT=str(w/'godot-audio-build/dist/godot'),SHARDS='8',LOG_DIR=str(w/'st9-counter-merged-v1-shards'))
frozen=json.loads((w/'st9-counter-frozen-source-v1.json').read_text())
def verify():
 for name,h in frozen['files'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==h,name
for tag,command in [('st9-counter-merged-v1',['bash','tools/run_tests_changed.sh']),('st9-counter-ci-style-v3',['python','tools/run_handoff_completion.py','--godot',env['GODOT'],'--output',str(w/'st9-counter-ci-style-v3')])]:
 verify()
 with (w/(tag+'.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 (w/(tag+'.exit')).write_text(str(code)+'\n');verify();print(tag,code,flush=True);assert code==0,(tag,code)
print('MERGED ST9 CHECKS COMPLETE',flush=True)
