from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
root=Path('work/home-owner-save')
def metric(name, expected):
 r=json.loads((root/name/'receipt.json').read_text());rows=r['cases'];assert len(rows)==expected and all(c['passed'] for c in rows),name
 return {'processes':len(rows),'checks':sum(c['result']['checks'] for c in rows),'failures':0}
results={name:metric(name,count) for name,count in [('after',3),('matrix-final',16),('prior-markers',31),('native',6),('native-reading',2)]}
before=json.loads((root/'before/receipt.json').read_text());assert before['git_clean'] and before['base']=='01f65d9e7f28f95e599fe010c8e063a07f329325'
negative={'processes':len(before['cases']),'checks':sum(c['result']['checks'] for c in before['cases']),'failures':sum(len(c['result']['failures']) for c in before['cases'])}
for name in ['matrix-final','prior-markers']:
 receipt=json.loads((root/name/'receipt.json').read_text())
 for filename,sha in receipt['source_sha256'].items():assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==sha,filename
m=re.search(r'checks: (\d+), new failures: 0, known failures .*: 0  \(wall time (\d+) s\)',(root/'required-runner.log').read_text());assert m
assert 'diagnostics=0' in (root/'dummy-exit.log').read_text()
assert not re.search(r'SCRIPT ERROR|Parse Error|Compile Error|^ERROR:',(root/'final-import.log').read_text(),re.M)
source=root/'delivery-source';source.mkdir(exist_ok=False)
for name in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines():
 p=Path(name)
 if p.is_file():
  target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
shutil.copyfile('/workspace/.nest-egg-env/ci-godot/dist/receipt.json',root/'engine-receipt.json')
folder=Path('pm/ST/attachments/ST-9-home-ownership');folder.mkdir(exist_ok=False)
images={'native-reading/intact/home-original-dialogue.png':'reading','native/missing-write/home-missing-refused.png':'refused','native/foreign-write/home-foreign-accepted.png':'accepted'}
for name,label in images.items():shutil.copyfile(root/name,Path('pm/ST/images')/('ST-9-home-owner-'+label+'.png'))
with zipfile.ZipFile(folder/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in {'.json','.log','.exit','.gd','.tscn','.py','.png','.txt','.sh'} and '__pycache__' not in p.parts:
   archive.write(p,str(p.relative_to(root)))
receipt={'base':before['base'],'negative':negative,**results,'required':{'groups':7,'checks':int(m[1]),'seconds':int(m[2]),'new_failures':0,'known_failures':0},'archive_sha256':hashlib.sha256((folder/'evidence.zip').read_bytes()).hexdigest()}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(folder/'README.md').write_text(f'''# ST-9：返家結算保留原旗標來源

乾淨01f65d9e，真Main進原晨間當舖，在原返家intro前只安排已吃宵夜／交盤，不設定本次返家、結章或已讀。明示刪政策、替換成另一個已宣告旗標、植入真選項，{negative['processes']}程序{negative['checks']}項有{negative['failures']}失敗。缺政策／選項另以自己的.tmp目錄控制真正拒寫；替換旗標使用正常可寫目的地，原版仍公開錯的旗標並保存。不是假檔案錯誤或直接設完成結果。相同三程序修後{results['after']['checks']}項全過。

新增有限返家原來源：原劇本檔、原晨間關卡、原模式、完整前置條件與兩個原結果。旗標owner依獨立ID先承接，再驗政策與內容；錯政策不能移到另一結果owner。真正選項門將原返家中的未登記選項交回旗標owner拒絕，保留原恢復介面，不先套選項結果。正常原台詞、65步演出、聲音、道具與章節路由不改，未知舊來源與既有重要通訊維持原行為。

正式8種安排各有另一程序冷讀，共16程序{results['matrix-final']['checks']}項全過：正常IO拒寫／原請求重試，以及缺政策、另一合法政策、錯型、另一宣告結果、真選項、錯劇本來源、刪前置條件。語義損壞測試明示還原載入字典／來源，再按原進度恢復，不能假稱reader會修復壞掉的作者資源。恢復原未讀intro後再完成，兩個通知內均檢查兩原結果及歷史已在原checksum主檔且cinematic清空。此時章末卡尚未結束，另等真原章末卡與正式結算畫面，檢查chapter_complete，最後跨程序繼續到真結算。entry、refused、每個publication及最終主檔均保留原bytes。

原43種結果來源與返家共同audit現在44份宣告／44份契約，88項；加上先前NPC損壞／復原矩陣，共31程序{results['prior-markers']['checks']}項全過。原選擇器仍是7組{int(m[1]):,}項、0新／已知失敗、{int(m[2])}秒，六份完整退出另驗DummyTexture0。最終editor import無腳本、編譯或ERROR診斷；選擇器／已知失敗未改。初次正式矩陣誤取成功decode沒有的issues欄位，嚴格runner確實拒絕；保留matrix初次錯誤，改用既有可選診斷欄位後完整重跑16程序。

原生Forward+／軟體Vulkan初次6程序{results['native']['checks']}項與補拍原對話／冷讀2程序{results['native-reading']['checks']}項全過、0嚴格診斷。正常IO案例用ui_accept閱讀鍵完整跑原演出，不呼叫skip；其他損壞來源案例明示用原略過路徑。最初在scene_started取圖只見舞台載入前的原關卡，保留原圖，補拍等待真正對話可見，原凜、老K、壺與舞台可見。預設冷讀截圖尚在結算UI入場動畫中，保留但不作完整視覺證明；交付結算圖選已完成入場的真正接受畫面。三張交付原圖已逐張看過。

圖中主線目標及極短通關時間來自明示進區測試，不作自然整章通關／人工玩法證據；未修改計時、場景或演員外觀來拍照。本次原生演出只驗保存整合，既有角色造型／道具比例與全動作美術驗收各留原票條件。引擎同CI來源／修補／選項的本機4.7.2建置，編譯器不同，不聲稱二進位等同；軟體Vulkan不代稱實體GPU、真人通關或實體手把。

[完整證據](evidence.zip)、[摘要](receipt.json)。
''')
p=Path('pm/ST/[ST-9]把第一章劇本接進遊戲.md')
with p.open('a') as stream:
 stream.write(f'''

# Commit-31（返家結算保留原保存保護）

## 內文

返家事件的保存標記遺失，或內容被換成其他已知結果時，原本可能在保存成功前公開返家與結章進度。現在原返家事件依自身來源保留保存保護，政策、結果、前置條件或選項不符就提供原進度復原；正常磁碟拒寫可保留原演出重試。

原版3程序{negative['checks']}項有{negative['failures']}失敗，相同案例修後全過。正式拒寫、復原、結算與冷讀16程序{results['matrix-final']['checks']}項，既有故事矩陣31程序{results['prior-markers']['checks']}項，受影響7組{int(m[1]):,}項全過。原生軟體Vulkan8程序114項全過，其中正常返家以閱讀鍵跑完原演出，恢復後確實到原結算，另程序可續玩。

![閱讀原返家對話](images/ST-9-home-owner-reading.png)
![無效內容提供原進度復原](images/ST-9-home-owner-refused.png)
![真正保存後的原結算](images/ST-9-home-owner-accepted.png)

[原始失敗、完整主檔、演出與驗證](attachments/ST-9-home-ownership/README.md)。樣本明示安排進區與前置條件，不代稱自然整章通關。
''')
print(json.dumps(receipt,indent=2))
