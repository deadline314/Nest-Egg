set -e
source /workspace/.nest-egg-env/activate.sh
engine=/workspace/.nest-egg-env/ci-godot/dist/godot
root=/workspace/Nest-Egg/work/home-owner-save/native-reading
mkdir -p "$root"
for mode in intact intact_read; do
 set +e
 XDG_DATA_HOME="$root/$mode-profile" python3 tools/comfyui/gpu_lock.py -- xvfb-run -a -s '-screen 0 1280x720x24' "$engine" --path . --rendering-method forward_plus --rendering-driver vulkan --audio-driver Dummy res://work/home-owner-save/normal.tscn -- --mode="$mode" --save-dir="$root/slot" --out="$root/$mode" > "$root/$mode.log" 2>&1
 result=$?
 set -e
 echo "$result" > "$root/$mode.exit"
 if [ "$result" != 0 ]; then exit "$result"; fi
 echo "$mode complete"
done
