set -e
source /workspace/.nest-egg-env/activate.sh
engine=/workspace/.nest-egg-env/ci-godot/dist/godot
root=/workspace/Nest-Egg/work/home-owner-save/native
mkdir -p "$root"
for fixture in normal missing foreign; do
 scene=res://tests/probes/home_completion.tscn
 action=$fixture
 if [ "$fixture" = normal ]; then
  scene=res://work/home-owner-save/normal.tscn
  action=intact
 fi
 for phase in write read; do
  mode=$action
  if [ "$phase" = read ]; then mode=${action}_read; fi
  set +e
  XDG_DATA_HOME="$root/$fixture-$phase-profile" python3 tools/comfyui/gpu_lock.py -- xvfb-run -a -s '-screen 0 1280x720x24' "$engine" --path . --rendering-method forward_plus --rendering-driver vulkan --audio-driver Dummy "$scene" -- --mode="$mode" --save-dir="$root/$fixture-slot" --out="$root/$fixture-$phase" > "$root/$fixture-$phase.log" 2>&1
  result=$?
  set -e
  echo "$result" > "$root/$fixture-$phase.exit"
  if [ "$result" != 0 ]; then exit "$result"; fi
  echo "$fixture $phase complete"
 done
done
