extends "res://tests/probes/channel_completion.gd"
const HOME := &"ch1_c14_home"
const AREA := "res://data/levels/ch1_pawnshop_dawn.tres"
var _store: RunSaveStore
var _notices := 0
var _started := false
var _selected := false
func _run() -> void:
 _main=load("res://game/main.gd").new()
 _store=RunSaveStore.new(_save_dir.path_join("slot.json"))
 _main.set("_run_store",_store)
 add_child(_main)
 await _frames(8)
 _main.call("_on_start_requested",GameState.difficulties[1])
 await _frames(90)
 await _finish_story()
 await _wait_control()
 GameState.set_flag(&"ch1_supper_done",true,false)
 GameState.set_flag(&"ch1_handoff_done",true,false)
 _check(not GameState.has_flag(&"ch1_home_done") and not GameState.has_flag(&"ch1_complete") and not Story._completed.has(HOME),"original home result is absent before actual original ending intro")
 var scene: Dictionary=Story._scenes[String(HOME)]
 if _mode in ["missing","choice"]:scene.erase("completion_policy")
 if _mode=="foreign":scene.results[0].id="ch1_label_guitar_seen"
 if _mode=="choice":
  scene.steps=[{"do":"choice","text":"Explicit unregistered ending choice fixture","default":"inject","options":[{"id":"inject","text":"Try an unregistered result","set_flags":{"ch1_home_done":true}},{"id":"leave","text":"Leave"}]}]
 Story.scene_started.connect(func(id: StringName,_kind: StringName)->void:
  if id!=HOME:return
  _started=true
  if _mode!="foreign":_check(DirAccess.make_dir_absolute(_store.path+".tmp")==OK,"owned IO refusal starts only after actual original home intro is requested")
 )
 GameState.flag_changed.connect(func(flag: StringName,_value: Variant)->void:
  if flag in [&"ch1_home_done",&"ch1_complete",&"ch1_label_guitar_seen"]:_notices+=1
 )
 _main.call("_on_area_requested",AREA)
 await _frames(12)
 _check(_started and _level()!=null and _level().data.resource_path==AREA,"actual original dawn area requests its original ending intro")
 _before=FileAccess.get_file_as_bytes(_store.path)
 FileAccess.open(_out.path_join("entry-primary.json"),FileAccess.WRITE).store_buffer(_before)
 for i in 180:
  if _prompt()!=null:break
  if is_instance_valid(Story._player) and Story._player.choice_active():
   _selected=true
   Story._player.choose(0)
  elif Story.is_cinematic_active():Story.skip_cinematic()
  else:break
  await _frames(1)
 await _frames(6)
 _check(not GameState.has_flag(&"ch1_home_done") and not GameState.has_flag(&"ch1_complete") and not GameState.has_flag(&"ch1_label_guitar_seen"),"invalid original ending metadata cannot publish its real or another declared result")
 _check(not Story._completed.has(HOME),"unaccepted original ending cannot become completed history")
 _check(_notices==0,"invalid original ending has no premature flag publications")
 _check(FileAccess.get_file_as_bytes(_store.path)==_before,"invalid original ending preserves the complete actual entry primary bytes")
 _check(_prompt()!=null and get_tree().paused,"invalid original ending retains its real owner recovery prompt")
 if _mode=="choice":_check(_selected,"fixture selects the actual injected choice through the original CutscenePlayer")
 FileAccess.open(_out.path_join("observed-primary.json"),FileAccess.WRITE).store_buffer(FileAccess.get_file_as_bytes(_store.path))
 await _shot("home-"+_mode+"-refused")
 await _done()
func _prompt() -> Control:
 var owner: Node=_main.get("_story_completion")
 return owner.get("_prompt") as Control if is_instance_valid(owner) else null
