extends "res://tests/probes/home_completion.gd"
## Native control reads the original full intro with real reading events; no skip.
var _pictured := false
func _on_home_started(id: StringName, kind: StringName) -> void:
 super._on_home_started(id,kind)
 if id==HOME:await _shot("home-original-intro")
func _drive_home() -> void:
 for frame in 7200:
  if _prompt()!=null or _main.get("_screen") is VictoryScreen:return
  if _started and not Story.is_cinematic_active():return
  if not _pictured and is_instance_valid(Story._player):
   var dialogue: Control=Story._player.get("_dialogue")
   if dialogue!=null and dialogue.visible:
    _pictured=true
    await _shot("home-original-dialogue")
  var event:=InputEventAction.new()
  event.action=&"ui_accept"
  event.pressed=true
  Input.parse_input_event(event)
  Input.flush_buffered_events()
  event=event.duplicate()
  event.pressed=false
  Input.parse_input_event(event)
  Input.flush_buffered_events()
  await _frames(1)
 _check(false,"native original home reading finishes within its full-animation frame guard")
