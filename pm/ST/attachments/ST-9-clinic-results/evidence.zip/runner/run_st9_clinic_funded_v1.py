from pathlib import Path
import time,sys,json,shutil,hashlib
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'dummy-texture-worktree';sys.path.insert(0,str(r/'tools'));from runtime_probe import run_case
while not (w/'st9-clinic-affected-v1.exit').exists():time.sleep(1)
assert (w/'st9-clinic-affected-v1.exit').read_text().strip()=='0'
out=w/'st9-clinic-funded-v1';out.mkdir()
for f in ['work/st9-clinic-funded/probe.gd','work/st9-clinic-funded/probe.tscn','tests/probes/clinic_completion.gd']:
 p=out/'source'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/f,p)
x=run_case('normal_take',w/'godot-texture-build/dist/godot',out,150,project=r,scene='res://work/st9-clinic-funded/probe.tscn',slot=out/'slot');(out/'receipt.json').write_text(json.dumps(x,indent=2)+'\n');print({k:x[k] for k in ['passed','diagnostics','exit']},flush=True);raise SystemExit(0 if x['passed'] else 1)
