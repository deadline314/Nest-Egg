from pathlib import Path
import os,subprocess,json,shutil
w=Path('/workspace/Nest-Egg/work/batch1026');n=Path('/workspace/Nest-Egg/work/batch1020b');r=w/'dummy-texture-worktree';e=os.environ.copy();e.update(NE_NATIVE_PROJECT='../batch1026/dummy-texture-worktree',NE_NATIVE_GODOT=str(w/'godot-texture-build/dist/godot'))
rows=[]
for mode in ['write_tray','write_decide','retry_take','read_tray','skip_look']:
 tag='st9-clinic-'+mode.replace('_','-')+'-native-v2';slot=w/(tag+'-slot');slot.mkdir()
 if mode=='read_tray':shutil.copyfile(r/'tests/fixtures/clinic_tray_pending.json',slot/'slot.json')
 with (w/(tag+'-wrapper.log')).open('w') as out:
  x=subprocess.run(['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://work/st9-clinic-native/probe.tscn','--mode='+mode,'--save-dir='+str(slot)],cwd='/workspace/Nest-Egg',env=e,stdout=out,stderr=subprocess.STDOUT)
 (w/(tag+'-wrapper.exit')).write_text(str(x.returncode)+'\n');v=json.loads((n/tag/'result.json').read_text());raw=(n/(tag+'.log')).read_text();passed=x.returncode==0 and not v['failures'] and not any(s in raw for s in ['ERROR:','SCRIPT ERROR:','leaked at exit','were leaked','resources still in use','handle_crash:']);rows.append({'tag':tag,'mode':mode,'checks':v['checks'],'passed':passed});(w/'st9-clinic-native-v2.json').write_text(json.dumps({'cases':rows},indent=2)+'\n');print(rows[-1],flush=True)
 if not passed:raise SystemExit(1)
