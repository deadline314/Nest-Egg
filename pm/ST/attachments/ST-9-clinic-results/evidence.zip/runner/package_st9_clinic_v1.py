from pathlib import Path
import json,hashlib,re,zipfile,shutil
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'dummy-texture-worktree';n=Path('/workspace/Nest-Egg/work/batch1020b');d=r/'pm/ST/attachments/ST-9-clinic-results'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
frozen=json.loads((w/'st9-clinic-final-source-v1.json').read_text())
for f,h in frozen.items():assert sha(r/f)==h,f
assert (w/'st9-clinic-final-v1.exit').read_text().strip()=='0'
assert (w/'st9-clinic-funded-v1.exit').read_text().strip()=='0'
funded=json.loads((w/'st9-clinic-funded-v1/receipt.json').read_text());assert funded['passed'] and funded['result']['checks']==17
clinic=json.loads((w/'st9-clinic-positive-v2/receipt.json').read_text());assert len(clinic['cases'])==29 and all(x['passed'] for x in clinic['cases']);assert sum(x['result']['checks'] for x in clinic['cases'])==385
original=json.loads((w/'st9-clinic-before-v2/receipt.json').read_text());material=original['cases'][:3];assert sum(x['result']['checks'] for x in material)==42 and sum(len(x['result']['failures']) for x in material)==6
before=json.loads((w/'st9-clinic-cold-before-v3/receipt.json').read_text());after=json.loads((w/'st9-clinic-cold-after-v3/receipt.json').read_text());assert before['result']['checks']==after['result']['checks']==5 and len(before['result']['failures'])==1 and after['passed'];assert sha(w/'st9-clinic-cold-before-v3/source/work/st9-clinic-cold-v3/probe.gd')==sha(r/'tests/probes/clinic_original.gd')
log=(w/'st9-clinic-affected-v1.log').read_text();m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',log);assert m and m[2]==m[3]=='0';assert 'DUMMY_TEXTURE_EXIT_CHECK logs=4 diagnostics=0' in log
reg={}
for label in ['bubble-state','bubble-source','ali','voice','sunday','handoff','reception','supper','repeat']:
 receipt=json.loads((w/('st9-clinic-'+label+'-v1/receipt.json')).read_text());cases=receipt['cases'];assert all(x['passed'] and x['exit']==0 for x in cases),label;reg[label]={'processes':len(cases),'checks':sum(x['result']['checks'] for x in cases),'failures':0}
native=json.loads((w/'st9-clinic-native-v2.json').read_text())['cases'];assert len(native)==5 and all(x['passed'] for x in native) and sum(x['checks'] for x in native)==71
visual=json.loads((w/'st9-clinic-visual-review-v2.json').read_text());assert visual['all_originals_viewed'] and len(visual['originals'])==7
for row in visual['originals']:assert sha(n/row['path'])==row['sha256']
entries={}
def add(key,p):
 if p.is_file():entries[key]=p

def tree(prefix,root):
 for p in root.rglob('*'):
  if p.is_file() and not any(x.endswith('-profile') or x in ['.godot','__pycache__'] for x in p.relative_to(root).parts):add(prefix+'/'+str(p.relative_to(root)),p)
for f in frozen:add('source/final/'+f,r/f)
add('source/final/design/20-campaign-experience/FIRST_CLINIC_RESULTS.md',r/'design/20-campaign-experience/FIRST_CLINIC_RESULTS.md')
for p in (r/'work').glob('st9-clinic-*'):
 if p.is_dir():tree('source/private/'+p.name,p)
for p in w.glob('st9-clinic-*'):
 if p.is_file() and p.suffix in ['.json','.log','.exit','.gd'] and not p.name.startswith('st9-clinic-package'):add('records/'+p.name,p)
 elif p.is_dir():
  if p.name.endswith('-shards'):
   for f in p.glob('*.log'):add('tests/'+p.name+'/'+f.name,f)
  else:tree('runs/'+p.name,p)
for tag in ['st9-clinic-tray-native-v1']+[x['tag'] for x in native]:
 tree('native/'+tag,n/tag)
 for suffix in ['.log','.exit','-xvfb.log']:add('native/'+tag+suffix,n/(tag+suffix))
for p in w.glob('run_st9_clinic_*.py'):add('runner/'+p.name,p)
for f in ['package_st9_clinic_v1.py','bg51-ci-watch.log','bg51-ci-receipt.json','bg51-ci-evidence.zip','ne228-main-sync.json','ne228-push-result.json','ne228-cleanup.json']:add('runner/'+f,w/f)
add('engine/receipt.json',w/'godot-texture-build/dist/receipt.json');tree('research',d/'research')
archive=d/'evidence.zip';manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for key,p in sorted(entries.items()):manifest[key]={'bytes':p.stat().st_size,'sha256':sha(p)};z.write(p,key)
with zipfile.ZipFile(archive) as z:
 for key,row in manifest.items():
  with z.open(key) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256'],key
assert archive.stat().st_size<50*1024*1024
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
validation={'base':'a276c2cb69ef762c4a91c0d344aee43dd445d090','source_sha256':frozen,'engine_sha256':clinic['engine_sha256'],'compiler':json.loads((w/'st9-clinic-compiler-v1.json').read_text()),'material_negative':{'same_immutable_v2_checks':42,'before_failures':6,'after_failures':0},'cold_negative':{'same_v3_checks':5,'before_failures':1,'after_failures':0,'original_v2_early_menu_assertion_failure_retained':True},'clinic':{'processes':29,'checks':385,'failures':0,'seconds':clinic['wall_seconds']},'funded_original_pickup':{'checks':funded['result']['checks'],'failures':0,'real_physics_pickup_before_first_death':True},'affected':{'groups':int(re.search(r'Running (\d+) groups',log)[1]),'workers':4,'checks':int(m[1]),'new_failures':0,'known_failures':0,'seconds':int(m[4]),'dummy_exit_diagnostics':0},'regressions':reg,'native':native,'archive':{'bytes':archive.stat().st_size,'entries':len(manifest),'sha256':sha(archive)},'limits':['Direct original Main route into booth alley, not a full human chapter playthrough.','Software Forward+ HDR2D with Dummy audio; physical GPU/controller, full character art and human visual acceptance remain open.','Cloth/cup prop animation is not implemented or accepted by this persistence change.','GitHub detailed CI queries returned HTTP 401; no retry/bypass. New commit CI is not certified by local checks.','Original zero-wallet route supplemented by a distinct actual physics credit-pile collection; existing DeathFlowSuite retains original 1000-credit free/paid controls.']}
(d/'validation.json').write_text(json.dumps(validation,indent=2)+'\n');shutil.copyfile(w/'st9-clinic-visual-review-v2.json',d/'visual-review.json')
for tag,source,label in [('write-tray','pending','tray'),('write-decide','pending','decide'),('retry-take','refused','refused'),('retry-take','complete','recovered'),('read-tray','complete','cold'),('skip-look','complete','skip')]:shutil.copyfile(n/('st9-clinic-'+tag+'-native-v2')/(source+'.png'),r/'pm/ST/images'/('ST-9-clinic-results-'+label+'.png'))
print(json.dumps({k:v for k,v in validation.items() if k!='source_sha256'},indent=2))
