from pathlib import Path
import subprocess,json,hashlib,time,os
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'dummy-texture-worktree';engine=w/'godot-texture-build/dist/godot'
files=['autoload/story.gd','core/story_outcomes.gd','game/level/level.gd','game/main.gd','game/story_result_clinic.gd','game/story_result_completion.gd','game/story_result_sources.gd','tools/story/ch1_runtime_backend.py','data/story/ch1_kasa.json','tests/helpers/clinic_source_checks.gd','tests/suite/test_run_save.gd','tests/probes/clinic_original.gd','tests/probes/clinic_original.tscn','tests/probes/clinic_completion.gd','tests/probes/clinic_completion.tscn','tests/fixtures/clinic_tray_pending.json','tests/fixtures/clinic_tray_pending.provenance.json','tools/run_clinic_completion.py','tools/runtime_probe.py','.github/workflows/tests.yml']
frozen={f:hashlib.sha256((r/f).read_bytes()).hexdigest() for f in files};(w/'st9-clinic-final-source-v1.json').write_text(json.dumps(frozen,indent=2)+'\n')
def unchanged():
 for f,h in frozen.items():assert hashlib.sha256((r/f).read_bytes()).hexdigest()==h,f
while not (w/'st9-clinic-native-v2.exit').exists():time.sleep(1)
assert (w/'st9-clinic-native-v2.exit').read_text().strip()=='0'
unchanged();env=os.environ.copy();env.update(GODOT=str(engine),SHARDS='4',LOG_DIR=str(w/'st9-clinic-affected-v1-shards'));name='st9-clinic-affected-v1';print('START affected',flush=True)
with (w/(name+'.log')).open('w') as out:code=subprocess.run(['bash','tools/run_tests_changed.sh','origin/main'],cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
(w/(name+'.exit')).write_text(str(code)+'\n');assert code==0,name
with (w/(name+'.log')).open('a') as out:subprocess.run(['python3','tools/check_dummy_texture_exit.py',str(w/'st9-clinic-affected-v1-shards')],cwd=r,stdout=out,stderr=subprocess.STDOUT,check=True)
unchanged();print('PASS affected',flush=True)
for tool,label in [('run_bubble_state.py','bubble-state'),('run_bubble_source.py','bubble-source'),('run_ali_completion.py','ali'),('run_voice_completion.py','voice'),('run_sunday_choice.py','sunday'),('run_handoff_completion.py','handoff'),('run_reception_completion.py','reception'),('run_supper_completion.py','supper'),('run_supper_repeat.py','repeat')]:
 unchanged();name='st9-clinic-'+label+'-v1';print('START',name,flush=True)
 with (w/(name+'.log')).open('w') as out:code=subprocess.run(['python3',str(r/'tools'/tool),'--godot',str(engine),'--output',str(w/name)],cwd=r,stdout=out,stderr=subprocess.STDOUT).returncode
 (w/(name+'.exit')).write_text(str(code)+'\n');assert code==0,name;unchanged();print('PASS',name,flush=True)
print('ALL AFFECTED AND ORIGINAL SOURCES COMPLETE',flush=True)
