from pathlib import Path
import sys,json,shutil,hashlib,argparse
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'dummy-texture-worktree';sys.path.insert(0,str(r/'tools'));from runtime_probe import run_case
pa=argparse.ArgumentParser();pa.add_argument('tag');a=pa.parse_args();out=w/a.tag;out.mkdir(exist_ok=False)
assert hashlib.sha256((r/'work/st9-clinic-boundary/probe.gd').read_bytes()).hexdigest()=='de34ea0aab5ef2f170d0a55872ee8b72c9f2cc7a1d01aec5ea6dd07f1d4dfaa1'
rows=[]
for mode in ['wake','look','take','pending_write','pending_read']:
 slot=out/(mode+'-slot');slot.mkdir()
 if mode=='pending_read':shutil.copyfile(w/'st9-clinic-before-v2/pending_write-slot/pending-primary.json',slot/'slot.json')
 x=run_case(mode,w/'godot-texture-build/dist/godot',out,150,project=r,scene='res://work/st9-clinic-boundary/probe.tscn',slot=slot);rows.append(x)
 (out/'receipt.json').write_text(json.dumps({'cases':rows},indent=2)+'\n');print(mode,x['passed'],x.get('result',{}).get('checks'),x.get('diagnostics'),flush=True)
 if not x['passed']:sys.exit(1)
print('PASS checks',sum(x['result']['checks'] for x in rows),flush=True)
