extends "res://tests/probes/clinic_completion.gd"
## Supplement the zero-wallet original route by physically touching one actual
## authored credit pile, without setting currency or invoking its grant method.
var pile: CreditPickup
var moved := false
var observed := false
var original_position := Vector2.ZERO

func _idle() -> bool:
	if not super._idle():
		return false
	if observed or _level().data.resource_path != AREA or GameState.deaths != 0:
		return true
	if not moved:
		for node: Node in get_tree().get_nodes_in_group(WorldState.GROUP):
			if node is CreditPickup and _level().is_ancestor_of(node) and not node.collected:
				pile = node
				original_position = _level().player.global_position
				_level().player.global_position = pile.global_position
				moved = true
				break
	if is_instance_valid(pile) and pile.collected:
		observed = true
		_check(Progression.credits > 0 and pile.value > 0,"real authored pile was collected by physics before the first death; wallet is nonzero")
		_level().player.global_position = original_position
		return true
	return false

func _finish() -> void:
	_check(observed and wallet_before > 0,"nonzero original pickup wallet supplements the separate zero-wallet original route")
	await super._finish()
