extends "res://tests/probes/clinic_completion.gd"
## Original controls only: finish the spoken line and open its actual menu.
## No product changes, crop, overlay, time adjustment or frame reconstruction.
func _capture(label: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	if label == "pending" and phase in ["tray","decide"]:
		var deadline := Time.get_ticks_msec()+30000
		while _movie() != null and not _movie().choice_active() and Time.get_ticks_msec() < deadline:
			if _movie()._dialogue.visible:
				_movie()._dialogue.complete()
				_movie()._advance_requested = true
			await _frames(1)
		_check(_movie() != null and _movie().choice_active(),"original pending clinic screenshot shows its genuine readable menu")
	elif _movie() != null and _movie()._dialogue.visible:
		_movie()._dialogue.complete()
	await _frames(3)
	await super._capture(label)
