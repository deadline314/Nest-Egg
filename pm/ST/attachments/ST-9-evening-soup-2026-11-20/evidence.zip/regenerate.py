from pathlib import Path
from shutil import copy2
import json, sys

root=Path.cwd()
scope=Path(__file__).resolve().parent
sys.path.insert(0,str(root/"tools/story"))
import ch1_runtime_backend as backend
out=scope/sys.argv[1]
out.mkdir(exist_ok=False)
backend.OUT=str(out/"ch1_kasa.json")
backend.legacy.STAGE_DIR=str(out)
assert backend.main()==0
selected="ch1_t_ali_2_ordered"
path=root/"data/story/ch1_kasa.json"
before=json.loads(path.read_bytes())
after=json.loads((out/"ch1_kasa.json").read_bytes())
left=before["scenes"].pop(selected)
right=after["scenes"].pop(selected)
assert before==after
steps1=left.pop("steps")
steps2=right.pop("steps")
assert left==right and [step for step in steps1 if step["do"]=="say"]==[step for step in steps2 if step["do"]=="say"]
copy2(out/"ch1_kasa.json",path)
copy2(out/"ch1_revival_lounge.json",root/"data/cutscene/stages/ch1_revival_lounge.json")
print("Generated stage and story match every other authored scene")
