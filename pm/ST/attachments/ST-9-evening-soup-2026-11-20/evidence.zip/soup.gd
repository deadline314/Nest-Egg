extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const PROP := "ali_lounge_soup_bowl"
const SIT := &"ch1_t_ali_2_sit"
const ORDERED := &"ch1_t_ali_2_ordered"
const POINT := Vector2(14, 73)
var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	var facts := [GameState.world_flags.duplicate(true), Progression.credits, StoryItems.snapshot()]
	if not await _observe(SIT, "normal") or not await _observe(ORDERED, "normal") 			or not await _observe(ORDERED, "skip") or not await _observe(ORDERED, "cancel"):
		printerr("A stage case failed")
		get_tree().quit(1)
		return
	if facts != [GameState.world_flags, Progression.credits, StoryItems.snapshot()]:
		printerr("Direct presentation changed story facts")
		get_tree().quit(1)
		return
	var out := FileAccess.open(_out.path_join("soup.json"), FileAccess.WRITE)
	out.store_string(JSON.stringify({"adapter":RenderingServer.get_video_adapter_name(),
		"renderer":RenderingServer.get_current_rendering_method(), "hdr_2d":get_viewport().use_hdr_2d,
		"facts_unchanged":true, "cases":_rows}, "  ") + "\n")
	out.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit()


func _observe(id: StringName, mode: String) -> bool:
	var scene: Dictionary = Story._scenes.get(id, {})
	var problems := CutsceneChecker.validate(str(id), scene, Story._speakers)
	problems.append_array(CutsceneChecker.staging_problems(str(id), scene))
	if not problems.is_empty():
		printerr(problems)
		return false
	var player := CutscenePlayer.new()
	add_child(player)
	player.play(id, scene)
	var rows: Array[Array] = []
	var held := false
	var shot := false
	var finished := false
	var start := Vector2.INF
	var initial_y := INF
	var highest := INF
	var last := Vector2.INF
	var maximum_error := 0.0
	for frame in 240:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		if player._stage == null:
			continue
		var bowl := player._stage.prop_node(PROP) as StageLayers._Sprite
		var rin: CutsceneActor = player._actors.get(&"rin")
		if bowl == null or not is_instance_valid(rin):
			continue
		if id == SIT:
			if bowl.visible or player._stage.prop_held(PROP):
				printerr("The no-order route showed a bowl")
				return false
			if player._dialogue.is_complete() and player._dialogue.visible:
				finished = true
				break
			continue
		if not bowl.visible:
			return false
		last = player._stage.to_local(bowl.global_position)
		var grip := player._stage.to_local(bowl.to_global(bowl.source_point(POINT)))
		var hand := player._stage.to_local(rin.hand_contact_global(&"front"))
		var head := player._stage.to_local(rin.rig.bone(&"head").global_position)
		var now_held := player._stage.prop_held(PROP)
		if not start.is_finite():
			start = last
			initial_y = last.y
		rows.append([frame,last.x,last.y,grip.x,grip.y,hand.x,hand.y,head.x,head.y,now_held,player._dialogue.visible])
		if now_held:
			held = true
			highest = minf(highest,last.y)
			maximum_error = maxf(maximum_error,grip.distance_to(hand))
			if mode != "normal" and initial_y - last.y >= 3.0:
				if mode == "skip":
					player.skip()
				else:
					player.cancel()
				break
			if not shot and initial_y - last.y >= 6.0 and rin.hand_target_settled(&"front"):
				shot = Capture.image(get_viewport()).save_png(_out.path_join("ali-soup-lift.png")) == OK
		if mode == "normal" and held and not now_held and player._dialogue.visible and player._dialogue.is_complete():
			finished = Capture.image(get_viewport()).save_png(_out.path_join("ali-soup-return.png")) == OK
			break
	if mode == "normal" and not finished:
		printerr("No first dialogue: ", id, " held=", held, " lift=", initial_y-highest, " shot=", shot)
		return false
	if id == ORDERED and (not held or maximum_error > 0.04 or (mode == "normal"
			and (initial_y - highest < 6.0 or not shot or last.distance_to(start) > 0.06))):
		printerr("Soup contact or counter pose is incorrect: ", maximum_error, " / ", initial_y-highest, " / ", start.distance_to(last))
		return false
	if player.is_running() and mode != "cancel":
		player.skip()
	for frame in 120:
		if not player.is_running():
			break
		await get_tree().process_frame
	var settled := not player.is_running()
	player.queue_free()
	await get_tree().process_frame
	_rows.append({"scene":str(id), "mode":mode, "finished":finished, "held":held, "settled":settled, "rows":rows,
		"max_contact_error":maximum_error,"peak_lift":initial_y-highest if held else 0.0,
		"return_distance":start.distance_to(last) if start.is_finite() else 0.0,
		"steps_sha256":JSON.stringify(scene["steps"]).sha256_text()})
	return settled
