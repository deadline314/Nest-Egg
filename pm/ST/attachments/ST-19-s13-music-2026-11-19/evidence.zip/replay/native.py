from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
tag, *modes = sys.argv[1:]
for mode in modes:
    out = base/tag/mode
    out.mkdir(parents=True)
    profile = out/'profile'
    env = os.environ.copy()
    for name in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[name] = str(profile/name)
    cmd = [sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
           '--path',str(shared),'--audio-driver','WASAPI','--rendering-method','forward_plus',
           '--resolution','960x540','--position','32,32','--max-fps','60',
           'res://work/s13_music_probe.tscn','--','--mode='+mode,'--save-dir='+str(out/'slot'),'--out='+str(out)]
    (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result = subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=360)
    raw = (out/'raw.log').read_text(encoding='utf-8',errors='replace')
    receipt = {'mode':mode,'exit':result.returncode,'sound':[json.loads(s.removeprefix('AUDIO_STATE ')) for s in raw.splitlines() if s.startswith('AUDIO_STATE ')],
               'errors':[s for s in raw.splitlines() if 'ERROR:' in s], 'WASAPI': '--audio-driver=WASAPI' in raw or 'WASAPI' in cmd}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(receipt,flush=True)
    assert result.returncode == 0 and not receipt['errors'] and len(receipt['sound'])>=3
