extends "res://tests/probes/channel_completion.gd"
## Arrange the existing boss outcome, then use the real cabinet and reload the actual save.

const OFFICE := "res://data/levels/ch2_ledger_office.tres"
const LEDGER_ITEMS := [&"ch2_original_ledger", &"ch2_ali_page", &"ch2_clinic_index"]


func _ready() -> void:
	super._ready()
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))


func _run() -> void:
	var route := _mode.get_slice("_", 0)
	var first := StringName("ch2_t_s13_" + route)
	_main = load("res://game/main.gd").new()
	var store := RunSaveStore.new(_save_dir.path_join("slot.json"))
	_main.set("_run_store", store)
	add_child(_main)
	await _frames(8)
	if _mode.ends_with("_read"):
		_main.call("_on_continue_requested")
		await _frames(30)
		_check(_level() != null and _level().data.resource_path == OFFICE, "cold primary restored the exact cabinet area")
		_check(str(GameState.get_flag(&"yong_link_choice")) == route, "cold primary retained the selected branch")
		_check(_complete(first), "cold primary retained the three scenes, result flags and all ledger items")
		await _verify_revisit()
		await _done()
		return

	_main.call("_on_start_requested", GameState.difficulties[1])
	await _frames(90)
	await _finish_story()
	await _wait_control()
	_main.call("_on_area_requested", OFFICE)
	await _frames(30)
	await _finish_story()
	await _wait_control()
	var cabinet := _cabinet()
	_check(cabinet != null, "main has the original cabinet")
	if cabinet == null:
		await _done()
		return
	_check(Story.resolve_dispatch(cabinet.data.talks[0].scene) == &"ch2_t_s13_locked", "unsubdued cabinet stays locked")
	GameState.set_flag(&"yong_link_choice", route)
	GameState.set_flag(&"yong_link_isolated")
	if route == "cut":
		GameState.set_flag(&"yong_link_revoked")
	GameState.set_flag(&"ch2_yong_subdued")
	_check(Story.resolve_dispatch(cabinet.data.talks[0].scene) == first, "real dispatcher selects the arranged boss result")
	_check(not GameState.has_flag(&"ch2_egret_transport_done") and not StoryItems.holds(LEDGER_ITEMS[0]), "no transport or items before the cabinet interaction")
	Story.scene_started.connect(func(id: StringName, _kind: StringName) -> void: _starts.append(id))
	var credits := Progression.credits
	await _frames(96)
	_sample("office_before")
	_check(await _talk_cabinet(cabinet), "real cabinet interaction completes")
	_check(_starts == [first, &"ch2_t_s13_cabinet", &"ch2_t_s13_fall"], "original cabinet scene order remained exact: %s" % str(_starts))
	_check(_complete(first) and Progression.credits == credits + 120, "real completion grants all three items, the transport flag and exactly 120 credits")
	await _frames(96)
	_sample("office_after")
	_main.call("_save_run")
	_check(not FileAccess.get_file_as_bytes(store.path).is_empty(), "actual Main wrote a complete primary")
	await _verify_revisit()
	await _done()


func _complete(first: StringName) -> bool:
	if not GameState.has_flag(&"ch2_original_ledger_taken") or not GameState.has_flag(&"ch2_egret_transport_done"):
		return false
	for scene in [first, &"ch2_t_s13_cabinet", &"ch2_t_s13_fall"]:
		if not Story._completed.has(scene):
			return false
	for id in LEDGER_ITEMS:
		if not StoryItems.holds(id):
			return false
	return true


func _cabinet() -> NpcActor:
	for node: Node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and node.data.id == &"ch2_ledger_cabinet":
			return node
	return null


func _verify_revisit() -> void:
	var cabinet := _cabinet()
	var credits := Progression.credits
	_check(cabinet != null and Story.resolve_dispatch(cabinet.data.talks[0].scene) == &"ch2_t_s13_revisit", "finished cabinet offers only its original revisit")
	if cabinet != null:
		_check(await _talk_cabinet(cabinet) and Progression.credits == credits, "revisit completes without a repeated payment")


func _talk_cabinet(cabinet: NpcActor) -> bool:
	_player().global_position = cabinet.global_position + Vector2(-32, 0)
	_player().velocity = Vector2.ZERO
	_player().set_physics_process(false)
	var finished := [false, false]
	var talk := func() -> void:
		finished[1] = await cabinet._talk()
		finished[0] = true
	talk.call()
	for frame in 6000:
		if finished[0]:
			return finished[1]
		var player := Story._player
		if player != null and player.is_running() and player.scene_id == &"ch2_t_s13_fall" and not _fall_sampled:
			_fall_sampled = true
			await _frames(84)
			await _shot("office-fall")
			_sample("office_fall")
		if player != null and player.is_running() and player._dialogue.visible:
			player._dialogue.complete()
			player._advance_requested = true
		await get_tree().process_frame
	return false

var _fall_sampled := false


func _sample(tag: String) -> void:
	var music := AudioServer.get_bus_index(&"Music")
	var ambience := AudioServer.get_bus_index(&"Ambience")
	print("AUDIO_STATE ", JSON.stringify({
		"tag": tag,
		"cue": String(Music.current_cue()),
		"playing": Music.is_playing(),
		"pos": Music.player().playback_position(),
		"music_db": AudioServer.get_bus_peak_volume_left_db(music, 0),
		"ambience_db": AudioServer.get_bus_peak_volume_left_db(ambience, 0),
		"filters": Music.filter_state(),
		"music_settings": Settings.get_volume(&"Music"),
		"scene": String(Story._player.scene_id) if Story._player else "",
	}))
