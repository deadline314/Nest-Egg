import os,sys,pathlib,json,subprocess,time,shutil,re
sys.path.insert(0,'tools')
from runtime_probe import stop_owned,write_json
root=pathlib.Path.cwd();out=root/os.environ.get('CHANNEL_NATIVE_OUT','work/channel-save/native');out.mkdir();(out/'.gdignore').touch();(out/'.gitignore').write_text('*\n');cases=[]
for mode in ['flood','boss','boss_read','overlap','overlap_read']:
 slot=out/(mode+'-slot');slot.mkdir()
 if mode.endswith('_read'):shutil.copyfile(out/(mode.removesuffix('_read')+'-slot')/'result-primary.json',slot/'slot.json')
 env=os.environ.copy();profile=out/(mode+'-profile');env.update(XDG_DATA_HOME=str(profile),APPDATA=str(profile),LOCALAPPDATA=str(profile))
 command=['python3','tools/comfyui/gpu_lock.py','--','xvfb-run','-a','-s','-screen 0 1280x720x24',env['GODOT'],'--path','.', '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','res://tests/probes/channel_completion.tscn','--','--mode='+mode,'--save-dir='+str(slot),'--out='+str(out/mode)]
 with (out/(mode+'.log')).open('w') as log:
  process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);write_json(out/(mode+'-process.json'),{'pid':process.pid,'command':command})
  try:code=process.wait(timeout=600)
  except subprocess.TimeoutExpired:
   stop_owned(process);code=process.wait(timeout=10)
 text=(out/(mode+'.log')).read_text(errors='replace');diagnostics=[line for line in text.splitlines() if re.search(r'^ERROR:|SCRIPT ERROR|Parse Error|^FAIL |leaked at exit|resources still in use',line)]
 result=json.loads((out/mode/'result.json').read_text()) if (out/mode/'result.json').exists() else {}
 cases.append({'mode':mode,'exit':code,'diagnostics':diagnostics,'result':result});write_json(out/'receipt.json',{'cases':cases,'renderer':'Forward+ Vulkan llvmpipe','resolution':[1280,720]});print(mode,code,result,diagnostics,flush=True)
 if code or diagnostics or result.get('failures')!=[]:sys.exit(1)
