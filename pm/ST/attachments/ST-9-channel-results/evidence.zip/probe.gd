extends "res://tests/probes/training_completion.gd"
## Explicit warehouse-entry/pressure-plate position fixture; not a chapter playthrough.
func _run() -> void:
	_main = load("res://game/main.gd").new()
	var store := RunSaveStore.new(_save_dir.path_join("slot.json"))
	_main.set("_run_store", store)
	add_child(_main)
	await _frames(8)
	_main.call("_on_start_requested", GameState.difficulties[1])
	await _frames(90)
	await _finish_story()
	await _frames(8)
	_main.call("_on_area_requested", "res://data/levels/ch1_warehouse.tres")
	await _frames(30)
	await _finish_story()
	Story.reset_active_presentation(&"probe")
	await _frames(2)
	for i in 1800:
		if not GameplayLock.is_locked() and not Story.is_cinematic_active(): break
		await _finish_story()
		await _frames(1)
	_check(not GameplayLock.is_locked(), "fixture waits for original chapter-card/control handoff")
	_check(_level() != null and _level().data.resource_path == "res://data/levels/ch1_warehouse.tres", "explicit original warehouse entry fixture is live under Main")
	var pit: FloodPit
	for node in _level()._entities.get_children():
		if node is FloodPit: pit = node; break
	_check(pit != null and not pit.triggered and not GameState.has_flag(&"ch1_flood_gate_open"), "fixture starts with original untriggered pressure plate and no result")
	if pit == null: await _done(); return
	print("FIXTURE: place original player above original pressure plate; advance actual physics contact, no result flag arrangement")
	_player().global_position = pit.global_position + Vector2(0, -16)
	_player().velocity = Vector2.ZERO
	_player().set_physics_process(false)
	await _frames(4)
	for i in 1800:
		if Story._layer._radio_active:
			var confirm := InputEventAction.new()
			confirm.action = &"ui_accept"
			confirm.pressed = true
			Input.parse_input_event(confirm)
			Input.flush_buffered_events()
			confirm = confirm.duplicate()
			confirm.pressed = false
			Input.parse_input_event(confirm)
			Input.flush_buffered_events()
		elif not GameplayLock.is_locked() and not _main.call("_story_save_blocked"): break
		await _frames(1)
	_check(not GameplayLock.is_locked(), "fixture reads original nearby radio before obstructing its own plate save")
	_player().set_physics_process(true)
	_main.call("_save_run")
	_before = FileAccess.get_file_as_bytes(store.path)
	FileAccess.open(_save_dir.path_join("original-primary.json"), FileAccess.WRITE).store_buffer(_before)
	_check(DirAccess.make_dir_absolute(store.path + ".tmp") == OK, "create owned real IO obstruction before actual plate contact")
	for i in 180:
		if pit.triggered: break
		await _frames(1)
	await _frames(4)
	print("PLATE_STATE ", JSON.stringify({"pit":[pit.global_position.x,pit.global_position.y],"player":[_player().global_position.x,_player().global_position.y],"paused":get_tree().paused,"locks":GameplayLock.is_locked(),"floor":_player().is_on_floor(),"scene":String(Story._current_cinematic),"lock_owners":GameplayLock._locks.values().map(func(entry:Dictionary)->String: return str(entry["owner"].get_ref().get_path()) if is_instance_valid(entry["owner"].get_ref()) else "gone")}))
	_check(pit.triggered, "actual original player physics contact triggers original pressure plate")
	_check(not GameState.has_flag(&"ch1_flood_gate_open"), "refused channel result cannot publish its story flag")
	_check(FileAccess.get_file_as_bytes(store.path) == _before, "refused channel result leaves exact original primary")
	await _shot("channel-refused")
	DirAccess.remove_absolute(store.path + ".tmp")
	await _done()
