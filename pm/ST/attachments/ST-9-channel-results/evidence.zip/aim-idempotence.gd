extends Node
func _ready() -> void:
 GameState.start_new_run(GameState.difficulties[1])
 var old = load("res://work/channel-save/aim-old.gd")
 var valid = RunSnapshot.capture("res://data/levels/ch1_pawnshop.tres", {"position":[100,160],"health":4,"world":{},"loadout":{}})
 var results = {}
 var directions = [Vector2(0.9972785115242,0.0737261027097702),Vector2(3,7),Vector2(-4,0),Vector2.ZERO]
 for index in 64: directions.append(Vector2.from_angle(index * TAU / 64.0) * 3.0)
 for pair in [["before",old],["after",RunSnapshot]]:
  var failures = []
  var checks = 0
  for direction in directions:
   var data = valid.duplicate(true)
   data["runtime"]["aim_dir"] = [direction.x,direction.y]
   var once = pair[1].prepare(data)["data"]
   var twice = pair[1].prepare(RunSaveCodec.decode(RunSaveCodec.encode(once))["data"])["data"]
   checks += 2
   if JSON.parse_string(JSON.stringify(once)) != JSON.parse_string(JSON.stringify(twice)): failures.append("not idempotent: " + str(direction))
   if not is_equal_approx(RunSaveCodec.vector(once["runtime"]["aim_dir"]).length_squared(),1.0): failures.append("not unit: " + str(direction))
  results[pair[0]] = {"checks":checks,"failures":failures}
 print(JSON.stringify(results))
 FileAccess.open("res://work/channel-save/aim-idempotence.json",FileAccess.WRITE).store_string(JSON.stringify(results,"  "))
 get_tree().quit(0 if results["after"]["failures"].is_empty() and not results["before"]["failures"].is_empty() else 1)
