from pathlib import Path
import json,re,zipfile,hashlib,shutil,subprocess
r=Path.cwd();w=r/'work/janus-save';d=r/'pm/ST/attachments/ST-21-pin-save';d.mkdir(parents=True,exist_ok=True)
a=json.loads((w/'public-final/receipt.json').read_text());b=json.loads((w/'yong-final/receipt.json').read_text());assert len(a['cases'])==len(b['cases'])==7 and all(c['passed'] for c in a['cases']+b['cases'])
c=(w/'affected-console.log').read_text();g=int(re.search(r'Running (\d+) groups',c)[1]);checks,new,known,seconds=map(int,re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',c).groups());assert new==known==0
native=[json.loads((w/f/'receipt.json').read_text()) for f in ('native-final','native-cold')];assert all(x['exit']==0 and not x['diagnostics'] and x['result']['failures']==[] for x in native)
n=sum(x['result']['checks'] for x in a['cases']);old=sum(x['result']['checks'] for x in b['cases']);baseline=json.loads((w/'before/receipt.json').read_text());assert baseline['git_clean'] and not baseline['passed']
for dest,src in [('refused','native-final/result/janus-refused.png'),('accepted','native-final/result/janus-accepted.png'),('cold','native-cold/result/janus-cold.png')]:shutil.copyfile(w/src,r/f'pm/ST/images/ST-21-pin-{dest}.png')
extra=['tools/story/ch3_source.py','tools/story/build_ch3_story.py','tools/story/chapter_compiler.py','data/story/ch3_clearwater.json','.github/workflows/tests.yml','design/13-story-v2/CH03_IMPLEMENTATION.md']
source={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in extra}
readme=f'''# ST-21：原維修插銷的持久停機結果

乾淨基準 `{baseline['baseline']}` 的原負控制7項有1失敗：真正原插銷已拔下，即使主檔不能寫入，仍提前公開停機旗標，原主檔bytes未變。工作架穩定度耗盡與玩家位置是明示末段樣本，隨後使用真正互動按鍵拔原插銷；不是完整自然戰鬥，也不直接寫停機旗標。

門禁大廳與產生來源逐區啟用持久結果。原工作架必須halted且pin_pulled才提供完成通道；人物未死。重試沿用原關卡、原生成資源／節點、完成狀態與整輪主檔驗證。已排入刪除的守門人也不再嘗試醒來或播敗北提示。

第一次遷移的public-initial原始失敗保留：部分案例四個physics訊號內尚未執行idle保存，工具過早檢查提示；改成最多等120個process訊號取得真提示。真正重試則揭露穩定度數字跨JSON後沒有宣告型別，嚴格批次安裝正確拒絕。作者來源及產生JSON補上穩定度100、撲空次數0、通訊器false、敗北false四項預設。沒有放寬型別檢查或濾掉錯誤。當時未完成回歸以記錄的自有程序群終止，原輸出保留，不當通過。

- 最後原插銷7程序{n}項全過：拒絕／兩次重試、退出、死亡、換來源、假通道、接受／取消的原整份主檔冷讀。
- 阿勇同執行器7程序{old}項全過，防止新增選項破壞原預設路徑。
- 原必要選擇器{g}組、{checks:,}項、0新增／已知失敗、{seconds}秒；未改選擇器或已知失敗。
- 原生Forward+／軟體Vulkan互動及原主檔冷讀共{sum(x['result']['checks'] for x in native)}項全過、0嚴格診斷。三張原圖逐張看過；拒絕是原保存提示，接受含原回饋效果，冷讀無退場血條。相機與目標列保留原樣，接受圖玩家在邊緣、目標仍是直接進區前的序章目標，不作完整構圖、故事流程或角色美術驗收。
- 三章原29個區域建構輸出（不含天亮當舖共圖變體）的持久化設定核對通過；第三章故事由實際作者來源／編譯器產出，JSON僅新增四個型別預設。

保存通知當下讀回磁碟原整輪，核對停機旗標及原工作架／插銷狀態；通知內切主選單被阻擋。拒絕／取消保持原整份主檔，死亡或來源被換只能回原整輪。新增程序納入CI。

[evidence.zip](evidence.zip)含原版負控制、初次失敗、最後全部程序／來源／主檔、原生原圖與受影響原始輸出。引擎與CI相同固定來源／修補／選項、本機編譯器，雜湊見engine-receipt；不宣稱二進位相同。沒有代勾整章人工、實體手把或完整自然戰鬥驗收。
'''
(d/'README.md').write_text(readme)
with zipfile.ZipFile(d/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in w.rglob('*'):
  if not p.is_file() or any('profile' in part or part.startswith('data_') or part in ('__pycache__','.godot') for part in p.relative_to(w).parts) or p.name in ('.gitignore','.gdignore'):continue
  z.write(p,str(p.relative_to(w)))
 for name in extra:z.write(r/name,'source-final/'+name)
 for name in ['game/enemies/janus_boss.gd','data/story/ch3_clearwater.json','tools/story/ch3_source.py']:
  z.writestr('source-before/'+name,subprocess.check_output(['git','show','c2bea219:'+name]))
 z.write('/workspace/.nest-egg-env/ci-godot/dist/receipt.json','engine-receipt.json')
a.update(affected={'groups':g,'checks':checks,'failures':0,'seconds':seconds},yong_checks=old,native=native,supplemental_source_sha256=source,archive_sha256=hashlib.sha256((d/'evidence.zip').read_bytes()).hexdigest())
(d/'receipt.json').write_text(json.dumps(a,indent=2,ensure_ascii=False)+'\n')
p=r/'pm/ST/[ST-21]完成第三章故事與關卡.md';assert '# Commit-5' not in p.read_text()
with p.open('a') as f:f.write(f'''\n\n# Commit-5（拔插銷先保存，再公開停機結果）

## 內文

守門人的插銷原本在存檔失敗時仍公開停機進度。現在原插銷完成後先保存原整輪與停機結果，成功才通知；失敗保持原現場，可重試。退出不接受結果，死亡或原來源被換則回原整輪。工作架停機仍不代表人物死亡，續玩也不會重新開退場頭目的血條或敗北提示。

原插銷的末段樣本7程序{n}項全過，包含拒絕、重試、退出、死亡、來源替換、假訊號與原整份主檔冷讀；阿勇7程序{old}項及受影響{g}組{checks:,}項亦全過。原生軟體Vulkan互動與冷讀{sum(x['result']['checks'] for x in native)}項全過。樣本不代稱自然完整戰鬥或整章人工通關。

![原插銷結果的保存拒絕](images/ST-21-pin-refused.png)
![原主檔冷續玩](images/ST-21-pin-cold.png)

[原版負控制、初次失敗、原主檔、原生原圖與完整紀錄](attachments/ST-21-pin-save/README.md)。
''')
print(g,checks,n,old)
