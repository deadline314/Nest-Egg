extends "res://tools/run_save_probe.gd"
## Arranged prior evening facts; real Main, authored stall, Ali and choices.
var _out := ""
var _record: Array = []
var _captured := {}
var _seen_finished: Dictionary = {}
var _cancelled_once := false
var _restarted := false
var _skipped_once := false
var _phase := {}
var _palm_samples := 0
var _mouth_samples := 0
var _palm_error := 0.0
var _hold_error := 0.0
var _mouth_error := 0.0

func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	super._ready()

func _run() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
	Transition.instant = true
	Settings.set_skip_cutscenes(false)
	Story.auto_skip = _mode != "read"
	_main = MainScript.new()
	_main.set("_run_store", RunSaveStore.new(_directory.path_join("slot.json")))
	add_child(_main)
	await _frames(5)
	Story.scene_finished.connect(_finished_scene)
	if _mode == "read":
		_main.call("_on_continue_requested")
		await _room()
		await _drive([false, false])
		await _finish()
		return
	_main.call("_on_start_requested", GameState.difficulties[1])
	await _room()
	Story.reset_active_presentation(&"probe_setup")
	_check(Story._apply_scene_results(&"ch1_t_ali_evening_close")["ok"], "arrange prior evening through formal result operation; not a campaign playthrough")
	_main.call("_on_area_requested", "res://data/levels/ch1_stall.tres")
	await _room()
	await _frames(5)
	Story.auto_skip = false
	var npc := _ali()
	_check(npc != null and npc.is_present(), "authored stall contains actual present Ali")
	if npc != null:
		(_main.get("_screen") as Level).player.global_position = npc.global_position + Vector2(-80, 0)
		var done := [false, false]
		_start_talk(npc, done)
		await _drive(done)
	await _finish()

func _start_talk(npc: NpcActor, done: Array) -> void:
	done[1] = await npc._talk()
	done[0] = true

func _drive(done: Array) -> void:
	var deadline := Time.get_ticks_msec() + 180000
	while Time.get_ticks_msec() < deadline:
		if _mode == "read" and _captured.has("address") and not Story.is_cinematic_active():
			break
		var current := String(Story._current_cinematic)
		var player: CutscenePlayer = Story._player
		if current == "ch1_t_supper_stay_meal" and is_instance_valid(player) and player._stage != null and player._actors.has(&"rin"):
			_sample(player)
			if _mode == "cancel" and not _cancelled_once and player._stage.prop_held("meal_chopsticks"):
				_cancelled_once = true
				var facts := var_to_bytes([GameState.world_flags, Progression.snapshot(), StoryItems.snapshot(), Story.progress_snapshot()])
				Story.reset_active_presentation(&"route")
				_check(facts == var_to_bytes([GameState.world_flags, Progression.snapshot(), StoryItems.snapshot(), Story.progress_snapshot()]), "cancel while physically holding food leaves all result owners untouched")
				continue
			if _mode == "skip" and not _skipped_once and _mouth_samples > 0:
				_skipped_once = true
				Story.skip_cinematic()
				continue
		if done[0] and not Story.is_cinematic_active():
			if _mode == "cancel" and _cancelled_once and not _restarted:
				_restarted = true
				_check(not GameState.has_flag(&"ch1_supper_meal_done"), "cancelled meal does not complete or inherit visual state")
				done = [false, false]
				_start_talk(_ali(), done)
			elif _mode == "skip" and _skipped_once and not _restarted:
				_restarted = true
				_check(GameState.has_flag(&"ch1_supper_meal_done") and not GameState.has_flag(&"knows_ali_address"), "skipped chosen meal completes once without granting the unplayed address")
				done = [false, false]
				_start_talk(_ali(), done)
			else:
				break
		if is_instance_valid(player) and player.choice_active():
			var desired := "stay" if current == "ch1_t_supper_choice_none" else "accept"
			var index := player._choice_options.find_custom(func(o: Dictionary) -> bool: return o.get("id") == desired)
			_check(index >= 0, "real Ali offers explicit " + desired)
			player.choose(maxi(0, index))
		elif is_instance_valid(player) and player.is_running() and player._dialogue.visible:
			var meal := current == "ch1_t_supper_stay_meal"
			var address := current == "ch1_t_supper_stay_address"
			var state: String = player._stage.prop_state("noodle_table") if player._stage != null and player._stage.has_method("prop_state") else "unavailable"
			if meal and not _captured.has("meal-full"):
				_captured["meal-full"] = true
				_check(state == "default", "actual chosen meal starts with full Rin bowl")
				await _shot("meal-full", player)
			if meal and state == "eaten" and not _captured.has("meal-empty"):
				_captured["meal-empty"] = true
				_check(not GameState.has_flag(&"ch1_supper_meal_done"), "visible after-eating state itself does not grant segment completion")
				await _shot("meal-empty", player)
			if meal and _restarted and _mode == "cancel" and not _captured.has("restarted"):
				_captured["restarted"] = true
				_check(state == "default", "re-entering actual cancelled meal creates a fresh full-bowl stage")
				await _shot("meal-restarted", player)
			if address and not _captured.has("address"):
				_captured["address"] = true
				_check(state == "eaten", "new address stage already reconstructs eaten bowl at its first dialogue")
				_check(GameState.has_flag(&"ch1_supper_meal_done") and not GameState.has_flag(&"knows_ali_address"), "meal and address retain separate actual outcomes")
				await _shot("address", player)
				if _mode == "write":
					await _frames(3)
					var saved: Dictionary = _main.get("_run_store").read()
					_check(saved.get("cinematic") == current and saved.get("story", {}).get("flags", {}).get("ch1_supper_meal_done") == true, "actual disk saves completed meal with still-pending address entry")
					return
			if player._dialogue.is_complete():
				player._advance_requested = true
		await RenderingServer.frame_post_draw
	_check(GameState.has_flag(&"ch1_supper_done") and GameState.has_flag(&"knows_ali_address"), "real Ali interaction completes authored meal and address chain")
	_check(_seen_finished.get("ch1_t_supper_stay_meal", 0) <= 1 and _seen_finished.get("ch1_t_supper_stay_address", 0) == 1, "each actual segment completes once despite stage replacement")
	_check(Progression.credits == 0 and Story.outcomes.account_state(&"ch1_lounge") == "none", "visual state and unbilled invitation grant no credits or meal receipt")
	if _mode not in ["skip", "read"]:
		_check(_captured.has("meal-empty"), "normal formal meal actually reaches after-eating state")

func _room() -> void:
	var deadline := Time.get_ticks_msec() + 120000
	while Time.get_ticks_msec() < deadline:
		var level := _main.get("_screen") as Level
		if level != null and level.is_initialized() and not _main.call("_route_pending"):
			return
		await _frames(1)
	_check(false, "Main creates current authored room within time budget")

func _ali() -> NpcActor:
	for node: Node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and node.data.id == &"ch1_ali_stall":
			return node
	return null

func _finished_scene(id: StringName) -> void:
	_seen_finished[String(id)] = int(_seen_finished.get(String(id), 0)) + 1

func _shot(name: String, player: CutscenePlayer) -> void:
	_record.append({"name": name, "scene": String(Story._current_cinematic), "state": player._stage.prop_state("noodle_table") if player._stage.has_method("prop_state") else "unavailable", "actor_positions": {"rin": player._actors[&"rin"].position, "ali": player._actors[&"ali"].position}})
	if _out.is_empty() or DisplayServer.get_name() == "headless":
		return
	DirAccess.make_dir_recursive_absolute(_out)
	player._dialogue.complete()
	var canvas := CanvasLayer.new()
	canvas.layer = 120
	add_child(canvas)
	var note := Label.new()
	note.text = "SOFTWARE FORWARD+ / ARRANGED EVENING + REAL ALI CHOICES / ACTUAL UTENSIL / LIP CONTACT"
	note.position = Vector2(10, 10)
	note.add_theme_font_size_override("font_size", 12)
	canvas.add_child(note)
	var captured: Image
	var rendered := false
	for attempt in 45:
		await _frames(1)
		await RenderingServer.frame_post_draw
		captured = preload("res://tools/viewport_capture.gd").image(get_viewport())
		var white := 0
		for y in range(26, 48, 2):
			for x in range(20, 1060, 2):
				var color := captured.get_pixel(x, y)
				if minf(color.r, minf(color.g, color.b)) > 0.8:
					white += 1
		if white >= 64:
			rendered = true
			break
	_check(rendered, "actual diagnostic caption has rendered: " + name)
	captured.save_png(_out.path_join(name + ".png"))
	canvas.queue_free()

func _sample(p: CutscenePlayer) -> void:
	var actor: CutsceneActor = p._actors[&"rin"]
	var reach := actor._reaches[0]
	var stage := p._stage
	if reach.active() and reach.weight >= .999:
		_palm_samples += 1
		var target := reach.target + actor.position if reach._actor_space else reach.target
		_palm_error = maxf(_palm_error, stage.actors.to_local(actor.hand_contact_global(&"front")).distance_to(target))
	if not stage.prop_held("meal_chopsticks"): return
	var sticks := stage.prop_node("meal_chopsticks") as StageLayers._Sprite
	_hold_error = maxf(_hold_error, stage.to_local(sticks.to_global(sticks.source_point(Vector2(310, 481)))).distance_to(stage.to_local(actor.hand_contact_global(&"front"))))
	var step: Dictionary = p._steps[mini(p.steps_run, p._steps.size() - 1)]
	if step.get("do") == "reach" and step.get("space") == "part": _phase_shot("lift")
	elif step.get("do") == "reach" and not step.has("space"): _phase_shot("pickup")
	if reach.settled() and reach._binding != null and stage.prop_node("meal_noodles").visible:
		var head := actor.rig.contact_part(&"head")
		var lip := stage.to_local(head.to_global(CharacterRig.part_source_point(head, Vector2(152, 145))))
		var tip := stage.to_local(sticks.to_global(sticks.source_point(Vector2(1110, 503))))
		_mouth_samples += 1
		_mouth_error = maxf(_mouth_error, tip.distance_to(lip))
		_phase_shot("mouth")

func _phase_shot(name: String) -> void:
	if _phase.has(name): return
	_phase[name] = true
	if not _out.is_empty(): preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(_out.path_join("mechanical-" + name + ".png"))

func _finish() -> void:
	var level := _main.get("_screen") as Level
	var table := level.find_child("dawn_noodle_stall__noodle_bowls_table", true, false) as PropNode if level != null else null
	var reaction: PropReaction
	if table != null:
		for child in table.get_children():
			if child is PropReaction: reaction = child
	_check(reaction != null and reaction.is_swapped() and reaction._swap_node.visible, "actual accepted meal also reconstructs the eaten table on the real map")
	_check(reaction != null and reaction._swap_node.data.size.is_equal_approx(table.data.size), "real map replacement keeps its table footprint and support")
	if _mode != "read":
		_check(_palm_samples > 5 and _palm_error < .08, "real Main palm contact stays reachable throughout eating (%.6f)" % _palm_error)
		_check(_hold_error < .08, "real Main keeps same actual utensil on palm (%.6f)" % _hold_error)
		_check(_mouth_samples > 0 and _mouth_error < .08, "real Main food reaches visible lips before disappearance (%.6f)" % _mouth_error)
	if not _out.is_empty():
		DirAccess.make_dir_recursive_absolute(_out)
		var file := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
		file.store_string(JSON.stringify({"mode": _mode, "checks": _checks, "failures": Array(_failures), "captures": _record, "finished": _seen_finished, "samples": {"palm": _palm_samples, "mouth": _mouth_samples, "palm_error": _palm_error, "hold_error": _hold_error, "mouth_error": _mouth_error}, "probe_sha256": FileAccess.get_sha256("res://work/st10-meal/meal_prop_probe.gd")}, "  "))
		file.close()
	await super._finish()
