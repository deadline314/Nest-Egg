extends "res://tools/scenarios/scenario_base.gd"
var checks := 0
var failures := 0
var main: Node
func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--out="): out_dir = arg.trim_prefix("--out=")
 DirAccess.make_dir_recursive_absolute(out_dir)
 _run.call_deferred()
func check(ok: bool, text: String) -> void:
 checks += 1
 if not ok: failures += 1
 print("MEAL_WORLD_CHECK %s %s" % [ok,text])
func _run() -> void:
 CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
 Transition.instant = true
 Story.auto_skip = false
 main = preload("res://game/main.gd").new()
 main.set("_run_store", RunSaveStore.new("/workspace/Nest-Egg/work/batch1026/meal-world-v6-slot.json"))
 add_child(main)
 await settle(5)
 main.call("_on_continue_requested")
 var deadline := Time.get_ticks_msec() + 120000
 var level: Level
 while Time.get_ticks_msec() < deadline:
  level = main.get("_screen") as Level
  if level != null and level.is_initialized() and not main.call("_route_pending") and not Story.is_cinematic_active(): break
  await get_tree().process_frame
 check(level != null and level.data.resource_path == "res://data/levels/ch1_stall.tres", "fresh Main returns to the real authored stall map")
 var grounded_deadline := Time.get_ticks_msec() + 5000
 while not level.player.is_on_floor() and Time.get_ticks_msec() < grounded_deadline:
  await get_tree().physics_frame
 check(level.player.is_on_floor(), "actual Main player reaches real floor contact before photo-only pause")
 print("MEAL_WORLD_GROUND on_floor=%s velocity=%s" % [level.player.is_on_floor(),level.player.velocity])
 var table := level.find_child("dawn_noodle_stall__noodle_bowls_table", true, false) as PropNode
 check(table != null and table.data.size.distance_to(Vector2(40, 25.5 * 40 / 30.4)) < .001, "actual map instance uses the same authored table dimensions")
 var reaction: PropReaction
 for child in table.get_children():
  if child is PropReaction: reaction = child
 check(reaction != null and reaction.is_swapped() and reaction._swap_node.visible, "actual cold map rebuilds the eaten left bowl, with one resting utensil pair")
 check(reaction != null and not table.get_child(0).visible and reaction._swap_node.data.size.is_equal_approx(table.data.size), "cold map hides the old full bowl without shifting its support")
 var facts := var_to_bytes([GameState.world_flags, Progression.snapshot(), StoryItems.snapshot(), Story.progress_snapshot()])
 var sprite := table.get_child(0) as Sprite2D
 var bottom := table.to_global(sprite.position + Vector2(0, sprite.texture.get_height() * sprite.scale.y)).y
 var floor_y := level.player.global_position.y
 check(absf(bottom - floor_y) < 2, "actual table canvas retains the player floor contact (%.4f px)" % absf(bottom - floor_y))
 check(not GameplayLock.is_locked() and not get_tree().paused and not level.player.interaction.active, "completed real map restores gameplay without a presentation lock")
 # Photo-only arrangement after the real gameplay/ownership checks above.
 level.player.set_physics_process(false)
 level.player.velocity = Vector2.ZERO
 level.player.global_position.x = table.global_position.x + table.data.size.x + 28
 level.player.aim_dir = Vector2.RIGHT
 level.player.facing = 1
 var camera := get_viewport().get_camera_2d() as LevelCamera
 if camera != null:
  camera.set_process(false)
  camera.set_physics_process(false)
  camera.global_position.x = table.global_position.x + table.data.size.x * .5
  camera.reset_smoothing()
  camera.force_update_scroll()
 await wait(1.0)
 await RenderingServer.frame_post_draw
 var viewport := get_viewport()
 var screen := viewport.get_canvas_transform()
 var rect: Rect2 = screen * Rect2(table.global_position, table.data.size)
 check(viewport.get_visible_rect().encloses(rect), "whole actual table canvas is inside the native capture frame")
 capture("actual-map-table")
 check(facts == var_to_bytes([GameState.world_flags, Progression.snapshot(), StoryItems.snapshot(), Story.progress_snapshot()]), "inspection cannot change credits, items, outcomes or story history")
 print("MEAL_WORLD_TOTAL checks=%d failures=%d" % [checks,failures])
 main.call("_quit", 1 if failures else 0)
