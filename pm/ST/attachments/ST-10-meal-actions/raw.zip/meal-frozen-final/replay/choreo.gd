extends Node
class MealOnly extends TestSuite:
 func run() -> void:
  var layers: Array = StageLibrary.definition(&"ch1_dawn_noodle_stall")["layers"]
  var bad: Dictionary = layers.filter(func(v: Dictionary) -> bool: return v.get("id") == "noodle_table")[0].duplicate(true)
  bad["source_width"] = 1370
  var sprite := StageLayers.create(bad, "historical width negative") as StageLayers._Sprite
  var width := sprite.texture.get_width() * sprite.scale.x
  check(absf(width - 68.0) > 10, "historical importer corruption fails physical table-width guard: %.4f instead of 68" % width)
  sprite.free()
  await preload("res://tests/helpers/meal_choreography_checks.gd").run(self)
var checks := 0
var failures := 0
func _ready() -> void:
 await MealOnly.new(self).run()
 print("MEAL_CHOREO_TOTAL checks=%d failures=%d" % [checks,failures])
 get_tree().quit(1 if failures else 0)
func _check(ok: bool, message: String) -> void:
 checks += 1
 if not ok: failures += 1
 print("MEAL_CHOREO_CHECK %s %s" % [ok,message])
func _frames(count: int) -> void:
 for i in count: await get_tree().process_frame
