extends "res://tools/scenarios/scenario_base.gd"
class MouthPoint extends StagePropBinding:
 var offset := Vector2.ZERO
 func _init(node: Node2D, point: Vector2, stage_offset: Vector2) -> void:
  super(node, point)
  offset = stage_offset
 func stage_point(parent: Node2D) -> Vector2:
  return super.stage_point(parent) + offset
var checks := 0
var failures := 0
func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--out="): out_dir = arg.trim_prefix("--out=")
 DirAccess.make_dir_recursive_absolute(out_dir)
 _run.call_deferred()
func check(ok: bool, text: String) -> void:
 checks += 1
 if not ok: failures += 1
 print("MEAL_PREVIEW_CHECK %s %s" % [ok, text])
func shot(label: String) -> void:
 await RenderingServer.frame_post_draw
 capture(label)
func _run() -> void:
 var facts := var_to_bytes([GameState.world_flags, StoryItems.snapshot(), Progression.snapshot(), Story.progress_snapshot()])
 var custom: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://work/st10-meal/layout.json"))
 StageLibrary._cache[&"ch1_dawn_noodle_stall"] = custom
 var p := CutscenePlayer.new()
 add_child(p)
 var steps: Array = Story._scenes["ch1_t_supper_stay_meal"]["steps"].slice(0, 3).duplicate(true)
 steps[0]["fade"] = .3
 steps[2]["pos"][0] = 322
 steps.append({"do": "wait", "time": 300.0})
 p.play(&"st10_meal_preview", {"steps": steps})
 while p.steps_run < 3: await get_tree().process_frame
 var actor: CutsceneActor = p._actors[&"rin"]
 await wait(.3)
 var stage := p._stage
 var table := stage.prop_node("noodle_table") as StageLayers._Sprite
 var bowl := stage.to_local(table.to_global(table.source_point(Vector2(85, 55))))
 var sticks := stage.prop_node("meal_chopsticks") as StageLayers._Sprite
 var tip_offset := Vector2(10, .275)
 var pickup := bowl - tip_offset
 sticks.position = pickup
 await shot("meal-layout")
 await p._do_reach({"id": "rin", "hand": "front", "space": "prop", "prop": "meal_chopsticks", "to": [310, 481], "time": .35, "grip": true})
 await p._do_prop_hold({"do": "prop_hold", "id": "meal_chopsticks", "actor": "rin", "hand": "front", "point": [310, 481], "follow_rotation": true})
 check(stage.prop_held("meal_chopsticks"), "actual closed palm touches the painted utensil grip before pickup")
 await shot("meal-pickup")
 stage.set_prop_visible("meal_noodles", true)
 await p._do_reach({"id": "rin", "hand": "front", "to": [pickup.x, pickup.y - 15], "time": .4})
 await shot("meal-lift")
 var head: Sprite2D
 for part: CanvasItem in actor.rig._parts:
  if part.name == &"head" and part is Sprite2D: head = part
 var binding := MouthPoint.new(head, Vector2(152, 145) + head.offset, -tip_offset.rotated(-2.8))
 await p._do_prop_move({"do": "prop_move", "id": "meal_noodles", "angle": 2.8, "time": .45, "wait": false})
 check(actor.set_hand_target({"hand": "front", "space": "prop", "prop": "preview_lips", "to": [0, 0], "time": .45, "angle": -2.8}, binding), "live lip target configures without changing stage or weapon ownership")
 await wait(.55)
 var error := 0.0
 for frame in 8:
  await RenderingServer.frame_post_draw
  var tip := stage.to_local(sticks.to_global(sticks.source_point(Vector2(1110, 503))))
  var mouth := stage.to_local(head.to_global(Vector2(152, 145) + head.offset))
  error = maxf(error, tip.distance_to(mouth))
 check(error < .08, "actual utensil tips follow visible lip source point (%.5f stage px)" % error)
 await shot("meal-mouth")
 stage.set_prop_visible("meal_noodles", false)
 await wait(.2)
 await p._do_prop_move({"do": "prop_move", "id": "meal_noodles", "angle": 0, "time": .4, "wait": false})
 await p._do_reach({"id": "rin", "hand": "front", "to": [pickup.x, pickup.y - 15], "time": .4})
 await p._do_reach({"id": "rin", "hand": "front", "to": [pickup.x, pickup.y], "time": .35})
 check(stage.release_prop("meal_chopsticks"), "same utensil releases back to the bowl support")
 await p._do_reach({"id": "rin", "hand": "front", "release": true, "time": .3})
 stage.set_prop_state("noodle_table", "eaten")
 await shot("meal-after")
 p.cancel()
 await settle(4)
 check(facts == var_to_bytes([GameState.world_flags, StoryItems.snapshot(), Progression.snapshot(), Story.progress_snapshot()]), "isolated prototype cannot award story results")
 print("MEAL_PREVIEW_TOTAL checks=%d failures=%d" % [checks, failures])
 get_tree().quit(1 if failures else 0)
