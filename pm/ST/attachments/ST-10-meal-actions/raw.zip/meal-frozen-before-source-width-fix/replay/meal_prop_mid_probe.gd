extends "res://work/meal_prop_probe.gd"
## Existing rule: a pending cinematic resumes from its beginning, not its visual cursor.
var _resumed_full := false
var _resumed_empty := false

func _shot(name: String, player: CutscenePlayer) -> void:
	await super._shot(name, player)
	if _mode == "read":
		if name == "meal-full":
			_resumed_full = true
			_check(not GameState.has_flag(&"ch1_supper_meal_done"), "cold mid-meal entry restarts full bowl without prematurely completing meal")
		elif name == "meal-empty":
			_resumed_empty = true

func _drive(done: Array) -> void:
	if _mode == "read":
		await super._drive(done)
		return
	var deadline := Time.get_ticks_msec() + 180000
	while Time.get_ticks_msec() < deadline:
		var current := String(Story._current_cinematic)
		var player: CutscenePlayer = Story._player
		if is_instance_valid(player) and player.choice_active():
			var desired := "stay" if current == "ch1_t_supper_choice_none" else "accept"
			var index := player._choice_options.find_custom(func(o: Dictionary) -> bool: return o.get("id") == desired)
			_check(index >= 0, "real Ali offers explicit " + desired)
			player.choose(maxi(0, index))
		elif is_instance_valid(player) and player.is_running() and player._dialogue.visible:
			if current == "ch1_t_supper_stay_meal":
				var state: String = player._stage.prop_state("noodle_table")
				if not _captured.has("meal-full"):
					_captured["meal-full"] = true
					_check(state == "default", "actual chosen pending meal begins full")
					await _shot("meal-full", player)
				if state == "eaten":
					_check(not GameState.has_flag(&"ch1_supper_meal_done"), "visible empty bowl has not completed pending meal")
					await _shot("meal-empty", player)
					await _frames(3)
					var saved: Dictionary = _main.get("_run_store").read()
					_check(saved.get("cinematic") == current and saved.get("story", {}).get("flags", {}).get("ch1_supper_meal_done") != true, "actual disk keeps pending meal despite its temporary empty-bowl visual")
					return
			player._dialogue.complete()
			player._advance_requested = true
		await _frames(1)
	_check(false, "actual pending meal reaches empty-bowl checkpoint within budget")

func _finish() -> void:
	if _mode == "read":
		_check(_resumed_full and _resumed_empty, "cold mid-meal replay naturally returns from full to eaten before address")
	if not _out.is_empty():
		var file := FileAccess.open(_out.path_join("mid-probe-source.json"), FileAccess.WRITE)
		file.store_string(JSON.stringify({"sha256": FileAccess.get_sha256("res://work/meal_prop_mid_probe.gd"), "base_sha256": FileAccess.get_sha256("res://work/meal_prop_probe.gd")}))
		file.close()
	await super._finish()
