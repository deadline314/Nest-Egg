extends Node
func _ready() -> void:
 var stage := StageLibrary.build(&"ch1_dawn_noodle_stall")
 add_child(stage)
 var table := stage.prop_node("noodle_table") as StageLayers._Sprite
 var bowl := stage.to_local(table.to_global(table.source_point(Vector2(85, 55))))
 for x in [305, 313]:
  var actor := CutsceneActor.new()
  stage.actors.add_child(actor)
  actor.setup(&"rin", "rin", "", 1.7, "")
  actor.position = Vector2(x, 300)
  actor.face(1)
  actor.set_pose(&"sit")
  actor._input.melee_grip = true  # Measurement only: existing closed texture, no production state repurposing.
  actor.set_process(false)
  for frame in 120: actor._process(1.0 / 60.0)
  var head: Sprite2D
  for part: CanvasItem in actor.rig._parts:
   if part.name == &"head" and part is Sprite2D: head = part
  var mouth := stage.to_local(head.to_global(Vector2(152, 145) + head.offset))
  var shoulder := stage.to_local(actor.rig.bone(&"arm_front_upper").global_position)
  var points := {"bowl": bowl + Vector2(-9, -2), "mouth": mouth + Vector2(-9, 0)}
  var results := {}
  for id: String in points:
   results[id] = {"target": [points[id].x, points[id].y], "reachable": actor.rig.place_hand(&"front", stage.to_global(points[id]), 0.0)}
  print("MEAL_MEASURE ", JSON.stringify({"actor_x": x, "shoulder": [shoulder.x, shoulder.y], "mouth": [mouth.x, mouth.y], "bowl": [bowl.x, bowl.y], "grip": actor.rig.hand_grip_offset(&"hand_front"), "targets": results}))
  actor.free()
 stage.free()
 get_tree().quit()
