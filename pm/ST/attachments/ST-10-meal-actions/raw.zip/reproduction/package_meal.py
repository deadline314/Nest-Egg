from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
B=Path('/workspace/Nest-Egg/work/batch1026'); ROOT=B/'kitchen-worktree'; N=Path('/workspace/Nest-Egg/work/batch1020b')
P=ROOT/'pm/ST/attachments/ST-10-meal-actions'
sha=lambda body:hashlib.sha256(body).hexdigest()
raw=(B/'meal-verified-final-changed.log').read_text()
m=re.findall(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)\s+\(wall time (\d+) s\)',raw)
assert m and (B/'meal-verified-final-changed.exit').read_text()=='0'
checks,new,known,seconds=map(int,m[-1]);assert checks>90000 and new==known==0 and 'Running 80 groups in 8 processes' in raw
entries={}
def add(path,name):
 p=Path(path);assert p.is_file(),p;assert name not in entries,name;entries[name]=p.read_bytes()
freeze=B/'meal-frozen-final'; source=json.loads((freeze/'source.json').read_text())
for name,record in source['files'].items():
 p=ROOT/name
 if record.get('deleted'):assert not p.exists(),name
 else:assert p.is_file() and sha(p.read_bytes())==record['sha256'],name
for folder in ['meal-frozen-source','meal-frozen-source-v2','meal-frozen-source-v3','meal-frozen-before-source-width-fix','meal-frozen-final','meal-before-source-width-fix']:
 for p in sorted((B/folder).rglob('*')):
  if p.is_file():add(p,folder+'/'+str(p.relative_to(B/folder)))
for p in sorted((ROOT/'work/st10-meal').iterdir()):
 if p.suffix in ['.gd','.tscn','.json','.uid']:add(p,'work/st10-meal/'+p.name)
# Include every failure log, intermediate result and the original unaltered filter.
for pattern in ['meal-*.log','meal-*.json','meal-*.gd','meal-*.txt','ci-86845791*.log','ci-86845791*.json']:
 for p in sorted(B.glob(pattern)):
  name='logs/'+p.name
  if name not in entries:add(p,name)
for folder in ['meal-final-shards','meal-verified-final-shards']:
 for p in sorted((B/folder).glob('shard_*.log')):add(p,'logs/'+folder+'/'+p.name)
finals=['st10-meal-main-v4','st10-meal-cancel-v3','st10-meal-skip-v3','st10-meal-write-v3','st10-meal-read-v3']
history=['st10-meal-preview-v1','st10-meal-preview-v2','st10-meal-main-v1','st10-meal-cancel-v1','st10-meal-skip-v1','st10-meal-write-v1','st10-meal-read-v1','st10-meal-main-v2','st10-meal-world-v1','st10-meal-world-v3','st10-meal-world-v4','st10-meal-world-v5','st10-meal-main-v3','st10-meal-cancel-v2','st10-meal-skip-v2','st10-meal-write-v2']
results=[]
for name in history+finals+['st10-meal-world-v6']:
 for suffix in ['.log','.exit']:add(N/(name+suffix),'native/'+name+suffix)
 result=N/name/'result.json'
 if result.exists():add(result,'native/'+name+'/result.json')
 if name in finals:
  r=json.loads(result.read_text());log=(N/(name+'.log')).read_text();assert not r['failures'] and (N/(name+'.exit')).read_text()=='0' and not re.search(r'^ERROR:|SCRIPT ERROR:|were leaked|instances were leaked|cannot reach',log,re.M)
  results.append({'name':name,**r})
 include_all=name in finals+['st10-meal-world-v6','st10-meal-preview-v1','st10-meal-preview-v2']
 for p in sorted((N/name).glob('*.png')):
  if include_all or name in ['st10-meal-world-v1','st10-meal-world-v3','st10-meal-world-v4','st10-meal-world-v5'] or name=='st10-meal-main-v3' or (name=='st10-meal-main-v1' and p.stem in ['meal-full','meal-empty','mechanical-mouth']):add(p,'native/'+name+'/'+p.name)
for name in ['after_meal_regression.py','write_meal_docs.py','run_final_meal.py','run_final_meal_clean.py','run_final_meal_verified.py','package_meal.py','meal-next-plan.md','meal-next-world-plan.md']:
 add(B/name,'reproduction/'+name)
add(Path('/workspace/Nest-Egg/work/batch1024/native-large.py'),'reproduction/native-large.py')
for name in ['assets_src/pipeline/grade_master.json','tools/assets/grade.py','tools/assets/depth_normals.py','tools/assets/texture_import.py','tools/assets/story_staging_art.py','tools/assets/test_story_staging_art.py','tools/select_tests.py','tools/test_filters.sh','tools/run_tests_changed.sh','tests/known_failures.txt']:
 add(ROOT/name,'dependencies/'+name)
for p in sorted((ROOT/'pm/ST/attachments/ST-10-meal-props/references').iterdir()):
 if p.is_file():add(p,'references/'+p.name)
for name in ['design/20-campaign-experience/MEAL_PROP_CONTACTS.md','design/11-free-assets/SCENE_PROPS.md']:
 add(ROOT/name,'design/'+Path(name).name)
add(ROOT/'assets_src/work/story_staging_art-receipt.json','assets/story_staging_art-receipt.json')
validation={'date':'2026-10-26 Asia/Taipei','base':source['base'],'engine':'4.7.2-stable ed1daf0bf','renderer':'native Forward+ HDR / Vulkan llvmpipe software','selector':{'groups':80,'shards':8,'checks':checks,'new_failures':new,'known_failures':known,'seconds':seconds,'filters_and_known_failures_unchanged':True},'native':results,'world':{'checks':9,'failures':0,'cold_accepted_map':True},'first_selector_before_duplicate_art_cleanup':{'groups':78,'checks':95617,'new_failures':0,'known_failures':0,'seconds':525},'unit':{'grip_and_existing_helpers':{'checks':802,'failures':0},'part_fixture_initial':{'checks':850,'failures':1,'reason':'Godot uniquified same-parent sibling names; ambiguity fixture corrected'},'part_fixture_corrected':{'checks':850,'failures':0},'world_added':{'checks':857,'failures':0},'import_width_original_negative':{'tests':1,'expected_failures':1},'import_width_fixed':{'tests':4,'failures':0},'independent_actual_mechanics':{'checks':12,'failures':0}},'visual_rejection':{'phase':'main-v3 and its cancel/skip/write variants','reason':'importer replaced authored source_width304 with actual1370 without rescaling contacts; table306.469px instead of68.004. Numeric hand metrics passed; native images rejected. Corrected importer and added actual table/bowl guards.'},'prior_kitchen_ci':json.loads((B/'ci-86845791-receipt.json').read_text()),'scope':'Actual Main/NPC with arranged canonical evening prerequisites and explicit stay/accept choices. Synthetic advancement waits for text completion; skip probe calls the existing Story skip API. World probe restores a separate accepted slot and arranges camera position. No human full-chapter playthrough or physical GPU/gamepad acceptance. ST-10 remains in progress for actual map disk insertion.'}
P.mkdir(parents=True,exist_ok=True);(P/'.gdignore').write_text('');entries['validation.json']=(json.dumps(validation,ensure_ascii=False,indent=2)+'\n').encode()
archive=P/'raw.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,body in sorted(entries.items()):
  info=zipfile.ZipInfo(name,date_time=(2026,10,26,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,body)
manifest={'archive':'raw.zip','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entries':[{'path':name,'bytes':len(body),'sha256':sha(body)} for name,body in sorted(entries.items())]}
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(entries)
 for record in manifest['entries']:
  body=z.read(record['path']);assert len(body)==record['bytes'] and sha(body)==record['sha256']
(P/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');(P/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
images=ROOT/'pm/ST/images'
for src,label in [('st10-meal-main-v4/mechanical-pickup.png','pickup'),('st10-meal-main-v4/mechanical-mouth.png','mouth'),('st10-meal-main-v4/meal-empty.png','after'),('st10-meal-read-v3/address.png','cold-address'),('st10-meal-world-v6/actual-map-table.png','cold-map'),('st10-meal-preview-v1/meal-mouth.png','rejected-face'),('st10-meal-main-v3/meal-full.png','rejected-width')]:
 shutil.copyfile(N/src,images/('ST-10-meal-actions-'+label+'.png'))
print(json.dumps({'checks':checks,'new_failures':new,'known_failures':known,'seconds':seconds,'native_checks':sum(r['checks'] for r in results)+9,'native_failures':sum(len(r['failures']) for r in results),'archive_entries':len(entries),'archive_bytes':archive.stat().st_size,'archive_sha256':manifest['sha256']},indent=2))
