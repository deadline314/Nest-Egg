import hashlib, json, os, re, shutil, subprocess
from pathlib import Path
B=Path('/workspace/Nest-Egg/work/batch1026')
ROOT=B/'kitchen-worktree'
N=Path('/workspace/Nest-Egg/work/batch1020b')
env=os.environ.copy()
env['NE_NATIVE_PROJECT']='../batch1026/kitchen-worktree'
results=[]
def native(name, mode, directory):
    command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',name,'res://work/st10-meal/main.tscn','--mode='+mode,'--save-dir='+str(directory)]
    with (B/(name+'-console.log')).open('w') as log:
        code=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    raw=(N/(name+'.log')).read_text()
    result=json.loads((N/name/'result.json').read_text())
    results.append({'name':name,'exit':code,'result':result})
    (B/'meal-clean-native-sequence.json').write_text(json.dumps(results,indent=2)+'\n')
    print(name,result,flush=True)
    assert code==0 and not result['failures'] and not re.search(r'^ERROR:|SCRIPT ERROR:|were leaked|instances were leaked|cannot reach',raw,re.M),name
native('st10-meal-main-v3','normal',B/'meal-main-v3-slot')
native('st10-meal-cancel-v2','cancel',B/'meal-cancel-v2-slot')
native('st10-meal-skip-v2','skip',B/'meal-skip-v2-slot')
native('st10-meal-write-v2','write',B/'meal-write-v2-slot')
native('st10-meal-read-v2','read',B/'meal-write-v2-slot')
shutil.copyfile(B/'meal-write-v2-slot/slot.json',B/'meal-world-v2-slot.json')
with (B/'meal-world-v2-console.log').open('w') as log:
    code=subprocess.run(['python','/workspace/Nest-Egg/work/batch1024/native-large.py','st10-meal-world-v2','res://work/st10-meal/world.tscn'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
raw=(N/'st10-meal-world-v2.log').read_text()
assert code==0 and 'MEAL_WORLD_TOTAL checks=7 failures=0' in raw and not re.search(r'^ERROR:|SCRIPT ERROR:|were leaked|instances were leaked',raw,re.M)
engine=str(N/'godot472/Godot_v4.7.2-stable_linux.x86_64')
with (B/'meal-clean-final-import.log').open('w') as log:
    subprocess.run([engine,'--headless','--path','.','--editor','--quit'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
assert not re.search(r'^ERROR:|SCRIPT ERROR:',(B/'meal-clean-final-import.log').read_text(),re.M)
env.update(GODOT=engine,SHARDS='8',LOG_DIR=str(B/'meal-clean-final-shards'))
with (B/'meal-clean-final-changed.log').open('w') as log:
    code=subprocess.run(['tools/run_tests_changed.sh'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
(B/'meal-clean-final-changed.exit').write_text(str(code))
print('FINAL_MEAL_SELECTOR_EXIT',code,flush=True)
raise SystemExit(code)
