from pathlib import Path
import json,re
B=Path('/workspace/Nest-Egg/work/batch1026');R=B/'kitchen-worktree';N=Path('/workspace/Nest-Egg/work/batch1020b')
t=(B/'meal-verified-final-changed.log').read_text();m=re.findall(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)\s+\(wall time (\d+) s\)',t)
assert m and (B/'meal-verified-final-changed.exit').read_text()=='0'
checks,new,known,seconds=map(int,m[-1]);assert new==known==0
names=['st10-meal-main-v4','st10-meal-cancel-v3','st10-meal-skip-v3','st10-meal-write-v3','st10-meal-read-v3']
results=[json.loads((N/name/'result.json').read_text()) for name in names]
assert all(not r['failures'] for r in results)
world=(N/'st10-meal-world-v6.log').read_text();assert 'MEAL_WORLD_TOTAL checks=9 failures=0' in world and (N/'st10-meal-world-v6.exit').read_text()=='0'
total=sum(r['checks'] for r in results)+9
palm=max(r['samples']['palm_error'] for r in results);hold=max(r['samples']['hold_error'] for r in results);mouth=max(r['samples']['mouth_error'] for r in results)
rows='\n'.join(f"| {name} | {r['checks']}／0 |" for name,r in zip(names,results))+'\n| st10-meal-world-v6 | 9／0 |'
p=R/'pm/ST/attachments/ST-10-meal-actions';p.mkdir(parents=True,exist_ok=True)
(p/'README.md').write_text(f'''# ST-10：真正持筷進食與餐後地圖

2026-10-26（Asia/Taipei）。凜用既有握持手圖取起同一雙筷子，從左碗取麵、從臉前送入口，實際筷尖碰到呼吸中的嘴唇後食物才消失，再把餐具放回左碗並收手。保留原對話、選擇、原餐後左碗空／右碗有食物與原結果擁有者；短動作是一個吃麵節拍，不宣稱一口吃完一整碗。

地圖也依真正的餐點完成旗標重建餐後狀態。舞台去掉烘入的左筷，因為有同一實體餐具；地圖餐後變體有一雙放回碗邊的筷子。桌碗不自發光，避免舊glow留下固定筷影；攤車與燈籠光仍沿原設定。表面、normal、圖集與前後狀態由同一來源管線製作；舊入口委派同一製作者，舊Qwen表格條目保留為來源歷史。

## 實際原生畫面

![取起餐具](../../images/ST-10-meal-actions-pickup.png)
![送入口：臉保持可見](../../images/ST-10-meal-actions-mouth.png)
![餐後左碗空、右碗仍有食物](../../images/ST-10-meal-actions-after.png)
![另程序續玩重建餐後地址段](../../images/ST-10-meal-actions-cold-address.png)
![實際冷續玩地圖餐桌；拍攝固定水平鏡頭](../../images/ST-10-meal-actions-cold-map.png)

本批是Godot4.7.2 ed1daf0bf、Forward+ HDR、Vulkan llvmpipe軟體。安排既有晚間結果，以真Main／真阿梨、明示stay／accept選項走正式段落。拍攝會展開文字，其餘推進等文字完成；動畫沒有插入診斷停頓。跳過呼叫既有Story skip API，不冒稱實體Escape或手把操作。冷地圖先檢查真正遊戲鎖與狀態，再暫停玩家物理、固定鏡頭水平位置拍攝，新增完整餐桌在框內的檢查；不是人類整章通關、自然實體輸入或硬體GPU驗收。

## 驗證

原選擇器80組、{checks:,}項、0新／0已知失敗、{seconds}秒。原斷言、filter與known failures未更動。原餐後狀態14項與原廚房機械回歸保留；新檢查包含閉手／旋轉、具名部件、真碗／筷尖、世界／舞台尺寸及餐後地圖。

| 實際Main案例 | checks／failures |
|---|---|
{rows}

合計{total}／0，最終六程序0引擎ERROR／退出洩漏。全權重接觸最大{palm:.8f}舞台px、持物{hold:.8f}px、嘴唇{mouth:.8f}px；低誤差不代替看圖。原生取樣數與每份完整結果在validation.json。獨立接觸／繼承幫手857／0，實際機械與壞寬度控制12／0。素材工具原4項、匯入政策含新反例共4項通過；真正舊入口重建後14個PNG成品SHA與主製作者相同，304px作者來源座標不再被覆寫，見meal-final-pipeline-proof。

前批返家關爐86845791的真正完整CI為97,687項／0新／0已知失敗、533秒，run40237141943／job121301009049原始job log與receipt一併保留。本批CI另以本批實際提交追蹤，前批結果不當成本批CI。

## 保留的退件與錯誤

第一個水平送入口原型雖筷尖到點，手臂遮臉，退件。最初使用近戰握圖僅作原型量測，正式版使用通用持物握圖，沒有偽造武器／近戰狀態。

![退件：數值到點但前臂遮臉](../../images/ST-10-meal-actions-rejected-face.png)

第一輪原78組95,617／0、525秒是清理固定筷圖之前的版本，不當最終通過。之後新貼圖從304變1370px，舊匯入工具覆寫source_width卻保留scale，桌子變306.469舞台px，手／餐具彼此的數值仍過；Main-v3圖實看退件。修正工具只補缺少的作者座標，新增舊工具1項預期失敗→修後4／0；正式桌寬68.004px，並額外核對餐具尖端真的在可見碗上。退件來源、log、PNG與新反例一起保留，不把早期數值過關稱作畫面通過。

![退件：來源座標覆寫造成大桌](../../images/ST-10-meal-actions-rejected-width.png)

另有850項／1失敗是測試把同父節點重名當歧義，Godot會自動改名；改成不同父節點的真重名部件後850／0，沒有改產品判定。第一次unittest模組入口相對匯入失敗，換成工具的script入口後4／0，錯誤log保留。world-v3的7項數值通過但照片把桌子裁到右緣，照片不算最終視覺證據；world-v4／v5在引擎取得真正落地前就暫停玩家，照片亦退件；world-v6等實際on_floor並加檢查，再安排拍攝站位與全桌取框，產品來源不變。

## 素材與研究

三份新生成RGBA原件、完整prompt、實際尺寸與SHA皆在assets_src/candidates/st10_meal_1026，原輸出保留。筷子1536×1024，桌面完整／餐後各1369×1149，向右／下補偶數畫布；工具未提供seed／model／job，記null。外區不是逐像素不變：下方桌椅alpha32 IoU0.9816728、右碗／蒸氣0.9869584，仍以原生支撐、尺寸及畫面核對。沒有用繪圖程式手補產品圖。原餐後地圖來源保留一雙休息筷子，右碗食物與蒸氣不移除。

研究沿用已實看的[五款橫向動作作品圖片與來源](../../../Nest-Egg/attachments/NE-278-references/sources.json)，並再次核對Spiritfarer座面／對話留白及Eastward人物層次。官方原圖及URL／SHA在raw.zip的references；靜態圖不當逐格吃麵動作、玩家偏好民調或本作驗收。

![Spiritfarer：座面與對話留白](../ST-10-meal-props/references/972660-0.jpg)
![Eastward：多人佈景與分層](../ST-10-meal-props/references/977880-2.jpg)

## 重跑與界線

source/base及各輪before／after、原選擇器完整八份log、所有退件、原生程序結果、不可變來源、重建receipt在raw.zip；manifest逐entry讀回bytes／SHA。診斷腳本放回work/st10-meal後，用reproduction/native-large.py指定獨立profile／slot跑main.tscn，mode normal/cancel/skip/write/read；write與read共用隔離slot。world_grounded.tscn使用另複本，請依本次replay腳本的slot路徑調整工作目錄，不使用玩家正式存檔。再執行原tools/run_tests_changed.sh，GODOT指定4.7.2；素材入口為story_staging_art.py，舊story_prop_states.py會委派相同製作者。

本批不代勾整票最後綜合條件，不取代其他角色接縫、人工完整章節或實體裝置驗收。ST-10維持進行中。
''',encoding='utf-8')
marker='# Commit-10（正式持筷進食與餐後地圖，進行中）'
p=R/'pm/ST/[ST-10]檢查並修正過場舞台的佈景比例與位置.md';body=p.read_text();assert marker not in body
p.write_text(body+f'''\n\n{marker}

## 內文

原本餐後只把左碗變空，凜沒有取食動作。現在握同一雙筷子從左碗取麵、由臉前送入口，筷尖真正碰到呼吸中的嘴唇後食物才消失，再放回餐具並收手。桌面與坐位按實際支撐重新核對，舞台和地圖共用物理尺寸；餐後地圖與另程序續玩也顯示左碗空、右碗有食物，各保留一雙餐具，不重發錢、物品或完成結果。

去掉表面／舊發光圖的固定左筷，避免取起後仍有另一雙或光影殘影。首個水平姿勢雖數值到點但遮臉，退件；新貼圖又被匯入工具覆寫座標而放成大桌，亦以原生圖退件。修後保留作者座標，新增實際桌寬與筷尖在可見碗上的檢查；來源、失敗與退件圖完整保留。

原80組{checks:,}項、0新／0已知失敗、{seconds}秒。真Main自然、持物中取消重入、跳過、保存、另程序續玩與餐後地圖共{total}／0，六程序0引擎ERROR／洩漏。閉手／旋轉／部件與繼承幫手857／0，獨立機械與壞尺寸控制12／0，兩種素材工具各4項通過，14個成品SHA重建一致。不是人類整章或實體輸入／GPU驗收；本票維持進行中。

![正式Main：餐具由臉前送入口](images/ST-10-meal-actions-mouth.png)
![餐後只清空凜的左碗](images/ST-10-meal-actions-after.png)
![另程序續玩重建餐後段落](images/ST-10-meal-actions-cold-address.png)

[原生圖、同類遊戲圖片、退件、原始輸出與重跑方法](attachments/ST-10-meal-actions/README.md)。
''',encoding='utf-8')
p=R/'pm/user_guide.md';body=p.read_text();guide_marker='2026-10-26（ST-10進食）';assert guide_marker not in body
p.write_text(body+f'''\n\n{guide_marker}：吃麵要驗可見碗、掌心、筷尖與嘴唇整條接觸，不能只驗手與抽象目標互相對上。來源圖片解析度不等於作者座標畫布，匯入政策只補缺值；否則換高解析圖會把桌子放大。[正式Main、取消／跳過、冷續玩、餐後地圖、兩輪視覺退件與相近遊戲原圖](ST/attachments/ST-10-meal-actions/README.md)。最終原80組{checks:,}項、原生{total}／0；整票及實體條件不代勾。前批關爐86845791完整CI真job97,687／0、533秒已附，不代稱本批CI。\n''',encoding='utf-8')
p=R/'design/20-campaign-experience/MEAL_PROP_CONTACTS.md';body=p.read_text();body=body.replace('實作前核對，尚未驗收。','已交付本批進食驗證；整票仍依原清單驗收。',1);body+=f'''\n\n## 本批驗證\n\n原80組{checks:,}／0新／0已知失敗、{seconds}秒；實際Main與冷地圖{total}／0、六程序無引擎ERROR／退出洩漏。完整結果、來源座標負控制與原生退件見[ST-10進食附件](../../pm/ST/attachments/ST-10-meal-actions/README.md)。\n''';p.write_text(body,encoding='utf-8')
print(json.dumps({'checks':checks,'seconds':seconds,'native':total,'native_palm_error':palm,'native_hold_error':hold,'native_mouth_error':mouth},indent=2))
