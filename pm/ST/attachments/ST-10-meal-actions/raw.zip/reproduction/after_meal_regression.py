from pathlib import Path
import os,re,shutil,subprocess,time
B=Path('/workspace/Nest-Egg/work/batch1026');N=Path('/workspace/Nest-Egg/work/batch1020b');ROOT=B/'kitchen-worktree'
end=time.monotonic()+1200
while not (B/'meal-verified-final-changed.exit').exists():
 assert time.monotonic()<end,'selector did not finish'
 time.sleep(.5)
assert (B/'meal-verified-final-changed.exit').read_text()=='0','selector failed'
shutil.copyfile(B/'meal-write-v3-slot/slot.json',B/'meal-world-v4-slot.json')
env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1026/kitchen-worktree'
with (B/'meal-world-v4-console.log').open('w') as log:
 code=subprocess.run(['python','/workspace/Nest-Egg/work/batch1024/native-large.py','st10-meal-world-v4','res://work/st10-meal/world_framed.tscn'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
s=(N/'st10-meal-world-v4.log').read_text()
assert code==0 and 'MEAL_WORLD_TOTAL checks=8 failures=0' in s and not re.search(r'^ERROR:|SCRIPT ERROR:|were leaked|instances were leaked',s,re.M),s[-3500:]
print('Framed native world complete: 8/0; inspect actual-map-table.png before packaging',flush=True)
