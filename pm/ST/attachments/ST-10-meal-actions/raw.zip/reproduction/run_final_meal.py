import hashlib, json, os, re, shutil, subprocess
from pathlib import Path
B=Path('/workspace/Nest-Egg/work/batch1026')
ROOT=B/'kitchen-worktree'
N=Path('/workspace/Nest-Egg/work/batch1020b')
env=os.environ.copy()
env['NE_NATIVE_PROJECT']='../batch1026/kitchen-worktree'
results=[]
def native(name, mode, directory):
    command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',name,'res://work/st10-meal/main.tscn','--mode='+mode,'--save-dir='+str(directory)]
    with (B/(name+'-console.log')).open('w') as log:
        code=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    raw=(N/(name+'.log')).read_text()
    result=json.loads((N/name/'result.json').read_text())
    results.append({'name':name,'exit':code,'result':result})
    (B/'meal-native-sequence.json').write_text(json.dumps(results,indent=2)+'\n')
    print(name,result,flush=True)
    assert code==0 and not result['failures'] and not re.search(r'^ERROR:|SCRIPT ERROR:|were leaked|instances were leaked|cannot reach',raw,re.M),name
assert (N/'st10-meal-main-v1.exit').read_text()=='0'
native('st10-meal-cancel-v1','cancel',B/'meal-cancel-v1-slot')
native('st10-meal-skip-v1','skip',B/'meal-skip-v1-slot')
native('st10-meal-write-v1','write',B/'meal-write-v1-slot')
native('st10-meal-read-v1','read',B/'meal-write-v1-slot')
engine=str(N/'godot472/Godot_v4.7.2-stable_linux.x86_64')
with (B/'meal-final-import.log').open('w') as log:
    subprocess.run([engine,'--headless','--path','.','--editor','--quit'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
assert not re.search(r'^ERROR:|SCRIPT ERROR:',(B/'meal-final-import.log').read_text(),re.M)
env.update(GODOT=engine,SHARDS='8',LOG_DIR=str(B/'meal-final-shards'))
with (B/'meal-final-changed.log').open('w') as log:
    code=subprocess.run(['tools/run_tests_changed.sh'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
(B/'meal-final-changed.exit').write_text(str(code))
print('FINAL_MEAL_SELECTOR_EXIT',code,flush=True)
raise SystemExit(code)
