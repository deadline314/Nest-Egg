from pathlib import Path
from copy import deepcopy
import json, subprocess
root=Path.cwd()
base=Path(__file__).resolve().parent

def started(path):
    return json.loads(subprocess.check_output(['git','show',f'HEAD:{path}'],cwd=root))

story_path='data/story/ch2_heron.json'
stage_path='data/cutscene/stages/ch2_pawnshop_counter.json'
old_story=started(story_path)
old_stage=started(stage_path)
story=json.loads((root/story_path).read_bytes())
stage=json.loads((root/stage_path).read_bytes())
changed={}
for sid, old in old_story['scenes'].items():
    active=story['scenes'][sid]
    if old == active:
        continue
    changed[sid]=[]
    for index,(before,after) in enumerate(zip(old['steps'],active['steps'],strict=True)):
        if before != after:
            assert before == {**after,'pos':[205,after['pos'][1]]}
            assert after['do']=='actor' and after['id']=='k' and after['pos'][0] == 229
            changed[sid].append(index)
            active['steps'][index]=before
assert set(changed)=={'ch2_t_s01_settle','ch2_t_s01_settled','ch2_t_s01_reaction','ch2_t_s01_reaction_left'}
assert all(len(indexes)==1 for indexes in changed.values()) and old_story==story
altered=[(before,after) for before,after in zip(old_stage['layers'],stage['layers'],strict=True) if before!=after]
assert len(altered)==1
before,after=altered[0]
assert before=={**after,'pos':[215,after['pos'][1]]} and after['id']=='towel' and after['pos'][0]==237
stage['layers'][stage['layers'].index(after)]=before
assert stage==old_stage
rec={'scenes':len(story['scenes']),'changed_actors':changed,'stage':'ch2_pawnshop_counter',
     'start_towel':[215,237],'old_k':[205,229],'unchanged_story_except_actor_positions':True}
(base/'compiled-diff.json').write_text(json.dumps(rec,indent=2)+'\n')
print(rec,flush=True)
