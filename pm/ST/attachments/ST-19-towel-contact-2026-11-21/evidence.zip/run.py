from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
project = base.parent/'ne218-baseline-20261117'
scope = base/sys.argv[1]
headless = 'headless' in sys.argv[2:]
scope.mkdir()
env = os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','TEMP','TMP','TMPDIR','XDG_CONFIG_HOME','XDG_DATA_HOME'):
    (scope/key).mkdir()
    env[key] = str(scope/key)
sources = ('data/story/ch1_kasa.json','data/story/ch2_heron.json','game/cutscene/cutscene_player.gd',
           'game/rig/character_rig.gd','art/characters/rin/character.json','data/cutscene/stages/ch2_pawnshop_counter.json')
sha = lambda file: sha256(file.read_bytes()).hexdigest()
manifest = {path:sha(project/path) for path in sources}
command = ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project)]
if headless:
    command.append('--headless')
else:
    command = [sys.executable,'-B',str(project/'tools/comfyui/gpu_lock.py'),'--']+command
    command += ['--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy','--resolution','1280x720']
command += ['--fixed-fps','60','--quit-after','39000',str(base/'inspect_cinematics.tscn'),'--',f'--out={scope}']
command += [arg for arg in sys.argv[2:] if arg.startswith(('--scene=','--counter-k=','--towel-start='))]
(scope/'command.json').write_text(json.dumps({'argv':command,'sources':manifest},indent=2)+'\n',encoding='utf-8')
with (scope/'engine.log').open('wb') as log:
    result = subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=250)
raw = (scope/'engine.log').read_text(encoding='utf-8',errors='replace')
assert result.returncode == 0 and not re.search(r'^(?:SCRIPT )?ERROR:|^FAIL ',raw,re.M), raw[-5000:]
report = json.loads((scope/'placements.json').read_bytes())
assert not report['failures'] and len(report['scenes']) >= 1
assert manifest == {path:sha(project/path) for path in sources}
print(len(report['scenes']),sum(len(row) for row in report['scenes'].values()),flush=True)




