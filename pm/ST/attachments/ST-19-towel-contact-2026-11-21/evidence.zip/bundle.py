from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json
import re

root=Path.cwd()
base=Path(__file__).resolve().parent
def read(path):
    return json.loads((base/path).read_bytes())

stock=read('native-stock/placements.json')
fixed=read('native-final/placements.json')
def push(report):
    return [frame for frame in report['counter_contact'] if frame['step']==4]
raw_before,raw_after=push(stock),push(fixed)
assert len(raw_before)==len(raw_after)==36 and not stock['failures'] and not fixed['failures']
before_distance=max(x['distance'] for x in raw_before)
after_distance=max(x['distance'] for x in raw_after)
assert before_distance > 70 and after_distance < 1.5 and raw_after[-1]['distance'] < 0.1
assert 267.8 < raw_after[-1]['x'] <= 268.0
log=lambda part:(base/part).read_text(encoding='utf-8-sig')
assert 'k/front cannot reach' in log('native-stock/engine.log')
assert 'cannot reach' not in log('native-final/engine.log')
assert log('focus-final-stock.log').count('FAIL: Old K keeps his palm on the towel') == 1
assert 'Ran 65 tests' in log('author-tests.log') and log('author-tests.log').rstrip().endswith('OK')
assert 'ST19_TOWEL_FLOW failures=0' in log('flow-realtime.log') and 'SCRIPT ERROR:' not in log('flow-realtime.log')
assert read('compiled-diff.json')['unchanged_story_except_actor_positions']
assert read('official-release/verification.json') == {'exit':0,'errors':[],'source_held':True}
official=log('official-release/raw.log')
counts=re.search(r'Running (\d+) groups', official)
check=re.search(r'checks:\s*(\d+), new failures: 0, known failures [^:]*: 0.*wall time (\d+) s',official)
assert counts and check
suites, checks, seconds = int(counts[1]), int(check[1]), int(check[2])
assert suites==34

ticket=next((root/'pm/ST').glob('[[]ST-19]*')).relative_to(root)
archive=Path('pm/ST/attachments/ST-19-towel-contact-2026-11-21/evidence.zip')
photos={'towel-push-before':'native-stock/towel_push_36.png',
        'towel-push-after':'native-final/towel_push_36.png',
        'towel-receive':'native-final/ch2_t_s01_settle_16.png'}
images={key:Path(f'pm/Nest-Egg/images/ST-19-{key}-20261121.png') for key in photos}
previous=(root/ticket).read_text(encoding='utf-8')
assert '# Commit-37（' in previous and '# Commit-38（' not in previous
assert not (root/archive.parent).exists() and all(not (root/file).exists() for file in images.values())
raw=[base/path for path in (
    'adopt.py','check-compiled.py','compiled-diff.json','bundle.py','author-tests.log','inspect_cinematics.gd',
    'inspect_cinematics.tscn','flow.gd','flow.tscn','flow-realtime.log','run.py','focus-final-stock.log',
    'official-release/command.json','official-release/raw.log','official-release/verification.json')]
for scope in ('native-stock','native-final','official-release/shards'):
    raw.extend(file for file in sorted((base/scope).iterdir()) if file.is_file())
(root/archive).parent.mkdir()
with ZipFile(root/archive,'x',compression=ZIP_DEFLATED) as bundle:
    for file in raw:
        bundle.write(file,file.relative_to(base).as_posix())
with ZipFile(root/archive) as bundle:
    assert bundle.testzip() is None
for key,path in images.items():
    (root/path).write_bytes((base/photos[key]).read_bytes())
section=f'''
---

# Commit-38（老 K 把毛巾推到凜手邊）

## 內文

第二章當舖的毛巾滑到後半程時，老 K 的前手搆不到原來的接觸點，提早掉回待機姿勢。把老 K 和毛巾起點沿原櫃臺靠近凜。毛巾仍停在原交接點，凜照原動作接過並擦乾頭髮。四個相鄰結算段落使用同一站位。

### 測試結果

- RX 9070 XT Forward+，修前修後各量 36 個推送影格。掌心離布面定位點的最大距離由 {before_distance:.2f} 降為 {after_distance:.2f} 邏輯像素，最後一格 {raw_after[-1]['distance']:.2f} 像素。兩個搆不到的診斷消失。
- 由正式當舖櫃臺選擇結算，實際領到 720 信用點一次；回訪維持原錢包和道具，毛巾沒有進物品欄。
- 重建 193 段故事資料，僅改四段站位及一份舞台的毛巾起點。65 項作者測試通過。新增接觸回歸在舊版重現失敗，修後受影響回歸 {suites} 套、{checks:,} 項通過，{seconds} 秒。

[原生畫面、接觸量測、劇本比較與回歸紀錄](attachments/ST-19-towel-contact-2026-11-21/evidence.zip)

![修前老 K 已放下手，毛巾尚在移動](../Nest-Egg/images/ST-19-towel-push-before-20261121.png)
![修後老 K 掌心沿著毛巾移動](../Nest-Egg/images/ST-19-towel-push-after-20261121.png)
![凜接過毛巾後的對話](../Nest-Egg/images/ST-19-towel-receive-20261121.png)
'''
(root/ticket).write_text(previous.rstrip()+'\n\n\n'+section.lstrip('\n'),encoding='utf-8')
paths=[*map(Path,read('runtime.json')), Path('design/13-story-v2/CH02_IMPLEMENTATION.md'),ticket,archive,*images.values()]
(base/'delivery.json').write_text(json.dumps([path.as_posix() for path in paths],ensure_ascii=False,indent=2)+'\n',
                                  encoding='utf-8')
print(len(raw),(root/archive).stat().st_size)
