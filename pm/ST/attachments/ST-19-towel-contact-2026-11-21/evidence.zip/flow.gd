extends "res://tools/ch2_flow_probe.gd"


func _run() -> void:
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip = false
	_carry_ch1_results()
	await _enter("pawnshop")
	var before := Progression.credits
	var inventory := var_to_bytes(StoryItems.snapshot())
	_check(not GameState.has_flag(&"ch2_morning_settled"), "settlement has not paid before the actual conversation")
	await _talk(&"ch2_old_k", ["settle"])
	_check(Progression.credits == before + 720 and GameState.has_flag(&"ch2_morning_settled"), "settlement pays the actual 720 credits")
	_check(var_to_bytes(StoryItems.snapshot()) == inventory, "towel never becomes a story item")
	await _talk(&"ch2_old_k")
	_check(Progression.credits == before + 720 and var_to_bytes(StoryItems.snapshot()) == inventory, "revisiting keeps the one payment and original items")
	Story.reset_active_presentation(&"route")
	_level.queue_free()
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	print("ST19_TOWEL_FLOW failures=",_failures)
	get_tree().quit(int(_failures > 0))
