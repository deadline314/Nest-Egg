from pathlib import Path
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
out = base / sys.argv[1]
out.mkdir()
env = os.environ.copy()
for name in ('APPDATA', 'LOCALAPPDATA', 'XDG_DATA_HOME', 'XDG_CONFIG_HOME'):
    env[name] = str(out / 'profile' / name)
env.update(PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
command = [sys.executable, '-B', str(root/'tools/comfyui/gpu_lock.py'), '--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--path', str(shared),
           '--rendering-method', 'forward_plus', '--rendering-driver', 'vulkan',
           '--audio-driver', 'Dummy', '--resolution', '1280x720', '--fixed-fps', '60',
           '--quit-after', '12000', 'res://tools/screenshot.tscn', '--',
           f'--out={out.as_posix()}', '--scenario=ch2_market_enemies']
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
    result = subprocess.run(command,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
raw = (out/'raw.log').read_text(encoding='utf-8',errors='replace')
print(raw[-6000:],flush=True)
assert result.returncode == 0 and 'ERROR:' not in raw, result.returncode
assert len(list(out.glob('NE-266*.png'))) == 5
