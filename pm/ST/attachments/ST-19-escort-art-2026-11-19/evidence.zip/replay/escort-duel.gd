extends Ch2MarketEnemiesScenario

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.trim_prefix("--out=")
	_begin.call_deferred()


func _begin() -> void:
	add_child(LightKit.create_environment())
	Story.auto_skip = true
	Enemy.activation_culling_enabled = false
	for side in [-1, 1]:
		await _duel(side)
	get_tree().quit(failures)


func _duel(side: int) -> void:
	GameState.start_new_run(GameState.difficulties[1])
	level = Level.new()
	level.configure(load(LEVEL) as LevelData)
	add_child(level)
	_migration = MapLayoutMigration.read(level.data)
	await settle(30)
	player = level.player
	level.hud.visible = false
	player.health.grant_invulnerability(30.0)
	player.set_physics_process(false)
	var escorts: Array[Enemy] = []
	for node in get_tree().get_nodes_in_group(&"enemies"):
		var enemy := node as Enemy
		if enemy.data.id == &"ch2_escort":
			escorts.append(enemy)
	if escorts.size() != 3 or _migration.has("error"):
		failures += 1
		await finish()
		return
	_place(8.0, 20)
	await _frames(int(TITLE_CARD_TIME * 60))
	var escort := escorts[0]
	var tile := level._layout.tile_size
	player.global_position.x = escort.global_position.x + side * 74.0
	player.global_position.y = escort.global_position.y
	_frame(escort.global_position, escort.global_position)
	var name := "left" if side < 0 else "right"
	for state in [&"windup", &"strike", &"recover"]:
		if await _wait_for([escort], state, 240) == null:
			await finish()
			return
		await _frames(12 if state == &"windup" else 5)
		_frame(escort.global_position, escort.global_position)
		await _frames(2)
		await RenderingServer.frame_post_draw
		var hand := escort.rig.bone(&"hand_front").global_position
		var direction: Vector2 = escort.call(&"_hand_dir")
		var grip := hand + direction * 1.5
		var tip := hand + direction * 16.0
		if escort.facing != side or not escort.fsm.is_in(state) or not is_equal_approx(grip.distance_to(tip), 14.5):
			failures += 1
			push_error("[escort duel] mismatched phase, facing or tip")
		print("ESCORT ", JSON.stringify({"side": side, "phase": str(escort.fsm.current), "feet": str(escort.global_position),
			"tile_size": tile, "wrist": str(hand), "grip": str(grip), "tip": str(tip), "dir": str(direction),
			"weapon_texture_loaded": escort.get("_baton_texture") is Texture2D}))
		capture("escort-%s-%s" % [name, state])
	var info := DamageInfo.create(6, Combat.Team.PLAYER, &"pistol", Vector2(-side * 100.0, 0.0))
	info.origin = player.global_position
	var result := escort.hurtbox.receive(info)
	if result != Hurtbox.Result.DAMAGED or escort.health.current != 0:
		failures += 1
		push_error("[escort duel] defeat animation did not receive its lethal control hit")
	for frame in [12, 20]:
		await _frames(frame)
		_frame(escort.global_position, escort.global_position)
		await _frames(2)
		await RenderingServer.frame_post_draw
		capture("escort-%s-fall-%d" % [name, frame])
	await finish()
