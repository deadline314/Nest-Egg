from pathlib import Path

from PIL import Image, ImageDraw

output = Path('art/weapons/ch2_escort_baton.png')
scale = 4
image = Image.new('RGBA', (72 * scale, 16 * scale))
draw = ImageDraw.Draw(image)


def polygon(points, fill):
    draw.polygon([(x * scale, y * scale) for x, y in points], fill=fill)


polygon([(0, 5), (3, 4), (49, 4), (52, 1), (67, 1), (71, 4), (71, 11),
         (67, 14), (52, 14), (49, 11), (3, 11), (0, 10)], '#1b1b1e')
polygon([(26, 5), (50, 5), (53, 3), (67, 3), (70, 5), (70, 10), (67, 12),
         (53, 12), (50, 10), (26, 10)], '#636773')
polygon([(27, 6), (50, 6), (53, 4), (66, 4), (68, 5), (51, 7), (27, 7)], '#a5a3a0')
polygon([(50, 9), (56, 8), (69, 7), (69, 10), (66, 11), (53, 11)], '#47494e')
polygon([(4, 5), (25, 5), (28, 6), (28, 9), (25, 10), (4, 10)], '#655146')
for x in range(6, 23, 4):
    polygon([(x, 6), (x + 2, 6), (x + 1, 9), (x - 1, 9)], '#332929')
polygon([(61, 4), (63, 4), (64, 10), (62, 11)], '#8b6650')
image.resize((72, 16), Image.Resampling.LANCZOS).save(output)
