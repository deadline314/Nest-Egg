extends "res://tools/prologue_play_probe.gd"
var _checks := 0
var _issues: Array[String] = []
var _starts: Array[StringName] = []
var _before := PackedByteArray()

func _check(ok: bool, what: String) -> void:
	_checks += 1
	if not ok: _issues.append(what)
	super._check(ok, what)

func _run() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
	Transition.instant = true
	Story.auto_skip = false
	_main = load("res://game/main.gd").new()
	var store := RunSaveStore.new(_save_dir.path_join("slot.json"))
	_main.set("_run_store", store)
	add_child(_main)
	await _frames(8)
	_main.call("_on_start_requested", GameState.difficulties[1])
	for i in 600:
		if _level() != null and _level().is_initialized(): break
		await _frames(1)
	_check(_level() != null, "real Main new game initializes its original prologue")
	if _level() == null: await _done(); return
	await _frames(90)
	await _finish_story()
	for i in 600:
		if not GameplayLock.is_locked() and not Story.is_cinematic_active(): break
		await _frames(1)
	await _frames(8)
	_main.call("_save_run")
	var station := _station(&"ch1_training_workbench")
	_before = FileAccess.get_file_as_bytes(store.path)
	_check(not _before.is_empty() and not GameState.has_flag(station.data.done_flag), "true initial primary predates reaching the bench")
	_check(DirAccess.make_dir_absolute(store.path + ".tmp") == OK, "real write obstruction is an owned empty directory")
	Story.scene_started.connect(func(id: StringName, _kind: StringName) -> void: _starts.append(id))
	var movement := &"move_right" if station.global_position.x > _player().global_position.x else &"move_left"
	Input.action_press(movement)
	for i in 600:
		if _prompt() != null or GameState.has_flag(station.data.done_flag): break
		Input.action_press(movement)
		await _frames(1)
	Input.action_release(movement)
	await _frames(4)
	_check(absf(_player().global_position.x-station.global_position.x) <= station.data.reach.x+8, "original movement physically reaches its actual station")
	_check(not GameState.has_flag(station.data.done_flag) and not station.is_done(), "refused training write cannot publish completion or mark the station done")
	_check(not _starts.has(station.data.done_scene), "refused write cannot start its follow-up explanation")
	_check(FileAccess.get_file_as_bytes(store.path) == _before, "refused write retains exact original primary bytes")
	_check(_prompt() != null and get_tree().paused, "refused real movement holds the world and offers retry")
	await _shot("training-refused")
	if _prompt() != null:
		_prompt().get("retry_button").pressed.emit()
		await _frames(4)
		_check(not GameState.has_flag(station.data.done_flag) and not _starts.has(station.data.done_scene), "second refusal does not publish or replay anything")
	_check(DirAccess.remove_absolute(store.path + ".tmp") == OK, "remove only this test's owned IO obstruction")
	if _prompt() != null:
		_prompt().get("retry_button").pressed.emit()
		await _frames(4)
		_check(GameState.has_flag(station.data.done_flag) and station.is_done(), "successful retry completes the exact original movement result")
		_check(_starts.count(station.data.done_scene) == 1, "retry starts its original explanation exactly once")
		var saved := RunSaveCodec.decode(FileAccess.get_file_as_string(store.path))
		_check(saved.has("data") and saved["data"]["story"]["flags"].get(String(station.data.done_flag),false), "notification follows the durable original training result")
	await _done()

func _prompt() -> Control:
	var owner: Variant = _main.get("_training_completion")
	return owner.get("_prompt") as Control if owner is Node else null

func _done() -> void:
	DirAccess.make_dir_recursive_absolute(_out)
	FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify({"checks":_checks,"failures":_issues},"  "))
	Story.reset_active_presentation(&"menu")
	_main.call("_quit", 0 if _issues.is_empty() else 1)
