from pathlib import Path
p=Path('data/scripts/level_data.gd');s=p.read_text();s=s.replace('@export var channel_done_flags: Dictionary[StringName, StringName] = {}','@export var channel_done_flags: Dictionary[StringName, StringName] = {}\n## 同一完成動作的其他旗標；和主旗標一起保存、一起發布。\n@export var channel_done_extra_flags: Dictionary[StringName, PackedStringArray] = {}');s=s.replace('@export var channel_cleared_flags: Dictionary[StringName, StringName] = {}','@export var channel_cleared_flags: Dictionary[StringName, StringName] = {}\n## 同一解除動作的其他旗標；和主旗標一起保存、一起發布。\n@export var channel_cleared_extra_flags: Dictionary[StringName, PackedStringArray] = {}');p.write_text(s)
p=Path('game/channel_completion.gd');s=p.read_text();s=s.replace('func request(level: Level, channel: StringName, active: bool) -> bool:', '''func _extra_mapping(level: Level, active: bool) -> Dictionary:
	return level.data.channel_done_extra_flags if active else level.data.channel_cleared_extra_flags

func _all_results_done(level: Level, channel: StringName, active: bool) -> bool:
	if not GameState.has_flag(_mapping(level, active)[channel]): return false
	var extra: PackedStringArray = _extra_mapping(level, active).get(channel, PackedStringArray())
	if extra.size() > MAX_PENDING: return false
	for flag: String in extra:
		if not GameState.has_flag(StringName(flag)): return false
	return true

func request(level: Level, channel: StringName, active: bool) -> bool:''');s=s.replace('not mapping.has(channel) or GameState.has_flag(mapping[channel])','not mapping.has(channel) or _all_results_done(level, channel, active)');s=s.replace('level.data.channel_done_flags, level.data.channel_cleared_flags, level.data.channel_scenes, level.data.durable_channel_results','level.data.channel_done_flags, level.data.channel_cleared_flags, level.data.channel_done_extra_flags,\n\t\tlevel.data.channel_cleared_extra_flags, level.data.channel_scenes, level.data.durable_channel_results');needle='\t\tflags[proof["flag"]] = true\n';assert needle in s;s=s.replace(needle,needle+'''\t\tvar extra: PackedStringArray = _extra_mapping(_level, proof["active"]).get(proof["channel"], PackedStringArray())
		if extra.size() > MAX_PENDING:
			_require_original("world result flags exceed supported bound")
			return
		for flag: String in extra:
			if flag.is_empty():
				_require_original("world result contains an empty extra flag")
				return
			flags[flag] = true
		if flags.size() > MAX_PENDING:
			_require_original("world result flag batch exceeds supported bound")
			return
''');p.write_text(s)
p=Path('game/level/level.gd');s=p.read_text();needle='## 機關頻道啟動時播放對應的場景（LevelData.channel_scenes）。';assert needle in s;s=s.replace(needle,'## Actor capability without a reverse dependency from enemies to Level.\nfunc has_durable_channel_owner() -> bool:\n\treturn data != null and data.durable_channel_results and channel_handler.is_valid()\n\n\n'+needle);old='''	if flags.has(channel) and not GameState.has_flag(flags[channel]):
		GameState.set_flag(flags[channel])
		Story.outcomes.refresh_derived()
''';new='''	if flags.has(channel):
		var extra: PackedStringArray = (data.channel_done_extra_flags if active else data.channel_cleared_extra_flags).get(channel, PackedStringArray())
		if extra.size() > 64:
			push_warning("[Level] channel/%s extra flags exceed supported bound" % channel)
			return
		var names := PackedStringArray([String(flags[channel])])
		names.append_array(extra)
		var changed := false
		for flag: String in names:
			if not flag.is_empty() and not GameState.has_flag(StringName(flag)):
				GameState.set_flag(StringName(flag))
				changed = true
		if changed: Story.outcomes.refresh_derived()
''';assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('game/enemies/yong_boss.gd');s=p.read_text();old='''func _on_box_completed() -> void:
	GameState.set_flag(StringName(str(_hook("isolated_flag"))), true)
	GameState.set_flag(StringName(str(_hook("revoked_flag"))), true)
	EventBus.toast_requested.emit(str(_hook("box_done_toast")))
	_enter_subdue("subdue", true)
''';new='''func _on_box_completed() -> void:
	var durable := _has_durable_world_owner()
	if not durable:
		# Standalone actor tools retain their original local result path.
		GameState.set_flag(StringName(str(_hook("isolated_flag"))), true)
		GameState.set_flag(StringName(str(_hook("revoked_flag"))), true)
	_enter_subdue("subdue", true)
	if durable:
		EventBus.mechanism_toggled.emit(StringName(str(_hook("isolation_channel"))), true)
	EventBus.toast_requested.emit(str(_hook("box_done_toast")))


func _has_durable_world_owner() -> bool:
	var ancestor := get_parent()
	while ancestor != null:
		if ancestor.has_method("has_durable_channel_owner"):
			return bool(ancestor.call("has_durable_channel_owner"))
		ancestor = ancestor.get_parent()
	return false
''';assert old in s;s=s.replace(old,new);old='\treturn StringName(str(_hook("done_channel"))) if is_subdued() and is_instance_valid(_pull) and _pull.done else &""';new='''	if is_subdued() and is_instance_valid(_pull) and _pull.done:
		return StringName(str(_hook("done_channel")))
	if is_instance_valid(_box) and _box.done:
		return StringName(str(_hook("isolation_channel")))
	return &""''';assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('data/bosses/yong.json');s=p.read_text().replace('"isolated_flag": "yong_link_isolated",','"isolated_flag": "yong_link_isolated",\n    "isolation_channel": "ch2_yong_isolation",');p.write_text(s)
p=Path('tools/level/build_ch2.py');s=p.read_text();old="'ledger_office': dict(durable=True, done={'ch2_yong_down': 'ch2_yong_subdued'}),";new="'ledger_office': dict(durable=True, done={'ch2_yong_down': 'ch2_yong_subdued', 'ch2_yong_isolation': 'yong_link_isolated'},\n                          done_extra={'ch2_yong_isolation': ['yong_link_revoked']}),";assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('tools/level/build_ch1.py');s=p.read_text();needle="    triggers = [scene for _, scene in sorted(area.triggers)]";assert needle in s;s=s.replace(needle,'''    for key, field in (('done_extra', 'channel_done_extra_flags'), ('cleared_extra', 'channel_cleared_extra_flags')):
        if story.get(key):
            entries = ', '.join('&' + json.dumps(channel) + ': PackedStringArray(' + ', '.join(json.dumps(flag) for flag in flags) + ')' for channel, flags in story[key].items())
            res.append(f'{field} = Dictionary[StringName, PackedStringArray](' + '{' + entries + '})')
'''+needle);p.write_text(s)
p=Path('data/levels/ch2_ledger_office.tres');s=p.read_text();old='channel_done_flags = Dictionary[StringName, StringName]({&"ch2_yong_down": &"ch2_yong_subdued"})';new='channel_done_flags = Dictionary[StringName, StringName]({&"ch2_yong_down": &"ch2_yong_subdued", &"ch2_yong_isolation": &"yong_link_isolated"})\nchannel_done_extra_flags = Dictionary[StringName, PackedStringArray]({&"ch2_yong_isolation": PackedStringArray("yong_link_revoked")})';assert old in s;s=s.replace(old,new);p.write_text(s)
