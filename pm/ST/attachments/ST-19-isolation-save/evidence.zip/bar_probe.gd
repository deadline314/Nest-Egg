extends "res://tests/probes/channel_completion.gd"
func _ready() -> void:
 super._ready()
 CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
func _run() -> void:
 _main=load("res://game/main.gd").new()
 _main.set("_run_store",RunSaveStore.new(_save_dir.path_join("slot.json")))
 add_child(_main)
 await _frames(8)
 _main.call("_on_continue_requested")
 await _frames(8)
 var boss: Node
 for node: Node in _level().channel_sources:
  if is_instance_valid(node) and node is PatternBoss and node.data.id==&"yong":boss=node
 _check(boss!=null and boss.get("stage")=="subdue","exact accepted box primary restores its original subdue route")
 if boss==null:await _done();return
 await _wait_control()
 await _walk_to(boss.global_position.x+180.0)
 await _frames(4)
 _check(boss.is_awake(),"real walking after cold continue wakes the original boss")
 _check(_level().hud.boss_bar._name==str(boss.call("_hook","subdue_name")),"cold subdue wake presents progress rather than the original life label")
 _check(not _player().is_dead() and GameState.has_flag(&"yong_link_isolated") and GameState.has_flag(&"yong_link_revoked") and not GameState.has_flag(&"ch2_yong_subdued"),"real cold movement retains the accepted box pair without a final boss result")
 await _done()
