from pathlib import Path
import json,re,zipfile,hashlib,shutil,subprocess
r=Path.cwd();w=r/'work/yong-box-save';d=r/'pm/ST/attachments/ST-19-isolation-save';d.mkdir(parents=True,exist_ok=True)
a=json.loads((w/'public-final/receipt.json').read_text());assert len(a['cases'])==10 and all(c['passed'] for c in a['cases'])
controls=[]
for folder,count in [('channel-final',17),('yong-final',7),('janus-final',7)]:
 b=json.loads((w/folder/'receipt.json').read_text());assert len(b['cases'])==count and all(c['passed'] for c in b['cases']);controls.extend(b['cases'])
c=(w/'affected-console.log').read_text();g=int(re.search(r'Running (\d+) groups',c)[1]);checks,new,known,seconds=map(int,re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)  \(wall time (\d+) s\)',c).groups());assert new==known==0
native=[json.loads((w/f/'receipt.json').read_text()) for f in ('native-final','native-cold')];assert all(x['exit']==0 and not x['diagnostics'] and x['result']['failures']==[] for x in native)
old=json.loads((w/'before/receipt.json').read_text());assert old['git_clean'] and old['result']['checks']==8 and len(old['result']['failures'])==2
walk=json.loads((w/'bar-before/receipt.json').read_text());assert walk['passed'] and walk['result']['checks']==4
n=sum(x['result']['checks'] for x in a['cases']);cross=sum(x['result']['checks'] for x in controls)
for dest,src in [('refused','native-final/result/isolation-refused.png'),('accepted','native-final/result/isolation-accepted.png'),('cold','native-cold/result/isolation-cold.png')]:shutil.copyfile(w/src,r/f'pm/ST/images/ST-19-isolation-{dest}.png')
extra=['data/scripts/level_data.gd','game/channel_completion.gd','game/level/level.gd','game/enemies/yong_boss.gd','data/bosses/yong.json','data/levels/ch2_ledger_office.tres','tools/level/build_ch1.py','tools/level/build_ch2.py','tools/level/check_channel_generation.py','.github/workflows/tests.yml','design/13-story-v2/CH02_IMPLEMENTATION.md']
source={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in extra}
with zipfile.ZipFile(d/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in w.rglob('*'):
  if not p.is_file() or any('profile' in part or part.startswith('data_') or part in ('__pycache__','.godot') for part in p.relative_to(w).parts) or p.name in ('.gitignore','.gdignore'):continue
  z.write(p,str(p.relative_to(w)))
 for name in extra:z.write(r/name,'source-final/'+name)
 for name in ['game/channel_completion.gd','game/enemies/yong_boss.gd','data/scripts/level_data.gd','data/levels/ch2_ledger_office.tres']:
  z.writestr('source-before/'+name,subprocess.check_output(['git','show','53e86de1:'+name]))
 z.write('/workspace/.nest-egg-env/ci-godot/dist/receipt.json','engine-receipt.json')
a.update(affected={'groups':g,'checks':checks,'failures':0,'seconds':seconds},existing_cases=len(controls),existing_checks=cross,native=native,cold_walk=walk,supplemental_source_sha256=source,archive_sha256=hashlib.sha256((d/'evidence.zip').read_bytes()).hexdigest())
(d/'receipt.json').write_text(json.dumps(a,indent=2,ensure_ascii=False)+'\n')
(d/'README.md').write_text(f'''# ST-19：原主隔離箱的成組結果

乾淨53e86de1負控制8項有2失敗：明示既有斷連選擇、血量與位置，再真正按住原箱子1.5秒完成；即使主檔不能寫，隔離與撤銷兩個旗標仍提前公開。結果旗標沒有被樣本直接設定，原整份主檔bytes未變。這不是自然完整頭目戰或第二章通關。

原阿勇必須原箱子done才能提供isolation通道；只發訊號或呼叫完成回呼不授權。原地圖把主旗標yong_link_isolated與其他旗標yong_link_revoked歸為同一動作，一次準備、一份整輪寫入、一次靜默安裝後才逐一通知。每個通知都讀回同一磁碟主檔，確認兩旗標、原箱子與原人物狀態；通知內切主選單被阻擋。

兩組其他旗標映射納入來源簽章。更換映射、超過64個結果或空旗標均要求原整輪，不安裝部分結果；拒絕／取消保持原主檔。上限由LevelData共用，擁有者能力查詢不讓敵人反向預載Level；獨立工具維持原本的本地結果路徑。

- 最後10程序{n}項全過：真按住、兩次拒寫與接受、退出、死亡、換原來源、假通道／假回呼、換契約、超量／空旗標、接受／取消原主檔逐bytes冷讀。
- 原第一章17、阿勇電池7、守門人插銷7，共31程序{cross}項全過。舊--boss與預設路徑仍通過，--action增加隔離箱場景。
- 原必要選擇器{g}組、{checks:,}項、0新增／已知失敗、{seconds}秒；6份完整退出日誌另檢DummyTexture0。
- 原生Forward+／軟體Vulkan互動及冷續玩共{sum(x['result']['checks'] for x in native)}項全過、0嚴格診斷，三張原圖逐張看過。拒絕圖是原保存提示，接受圖保留原回饋；目標仍是直接進區前的原序章目標，不作整章任務或素材驗收。
- bar-before是額外原主檔冷讀後實際行走喚醒檢查，4項全過，制伏進度名稱原本正確；沒有把它寫成已修復的失敗。
- 三章29個原區域建構輸出（不含天亮當舖共圖變體）核對擁有者與四組主／其他旗標宣告一致，產生器來源亦保留成組設定。

最初after的8項行為全過，但退出4物件／2資源外洩，因此整次仍失敗。原診斷保留，先獨立交付NE-282的程序終止播放修正0e146d39；after-audio同場景8項全過且0診斷，再進行上述最終驗證。沒有濾掉外洩或使用零退出碼冒充成功。

引擎為與CI相同來源／修補／選項、本機編譯器的4.7.2 custom build，雜湊見engine-receipt；不宣稱二進位相同。未修改選擇器或已知失敗，軟體Vulkan與明示前置樣本不代稱真人完整戰鬥、實體裝置或整章人工驗收。

[evidence.zip](evidence.zip)含全部失敗、原整份主檔、來源、映射故障樣本、實際通知／冷讀與原生原圖。[receipt.json](receipt.json)記錄雜湊及驗證邊界。
''')
p=r/'pm/ST/[ST-19]完成第二章故事與關卡.md';assert '# Commit-4' not in p.read_text()
with p.open('a') as f:f.write(f'''\n\n# Commit-4（主隔離箱的兩個結果一起保存）

## 內文

原主隔離箱完成後，即使保存失敗仍會公開「已隔離」與「已撤銷連結」。現在兩個結果一起保存，成功後才一起發布；每個通知當下兩個結果都已成立。拒絕可重試，退出保留原主檔，死亡、來源或契約已變更則回原整輪；不接受一半結果，也不把隔離箱當成後續拔電池完成。

原版8項有2項失敗。修後10程序{n}項、原第一章／阿勇電池／守門人31程序{cross}項，以及受影響{g}組{checks:,}項全過。原生軟體Vulkan互動與冷讀{sum(x['result']['checks'] for x in native)}項全過。樣本僅安排前置選擇、血量與位置，按住原箱子是真的，不代稱完整自然戰鬥或整章人工通關。

![隔離箱結果保存拒絕](images/ST-19-isolation-refused.png)
![接受原隔離箱的成組結果](images/ST-19-isolation-accepted.png)

[原始失敗、映射故障、完整主檔、原圖與全部回歸](attachments/ST-19-isolation-save/README.md)。最初退出音訊外洩由NE-282獨立交付後重驗。
''')
print(g,checks,n,cross)
