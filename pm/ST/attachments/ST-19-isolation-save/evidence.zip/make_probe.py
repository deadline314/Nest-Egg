from pathlib import Path
s=Path('tests/probes/nonlethal_completion.gd').read_text()
s=s.replace('const RESULT := &"ch2_yong_subdued"','const RESULT := &"yong_link_isolated"\nconst EXTRA := &"yong_link_revoked"\nconst CHANNEL := &"ch2_yong_isolation"')
s=s.replace('not GameState.has_flag(RESULT)','_no_results()').replace('GameState.has_flag(RESULT)','_all_results()')
s=s.replace('''		_check(_all_results() == (_mode == "accepted_read"), "cold original primary preserves only its actually accepted nonlethal result")
		_check((_yong() == null) == (_mode == "accepted_read"), "cold accepted completion retires the original boss without inventing an enemy death")''','''		var accepted := _mode == "accepted_read"
		_check([GameState.has_flag(RESULT), GameState.has_flag(EXTRA)] == [accepted, accepted], "cold original primary preserves both actually accepted box results together")
		var restored := _yong()
		_check(restored != null and restored.get("stage") == ("subdue" if accepted else "cut_box"), "cold box result restores its original living boss route")''')
s=s.replace('''		if _mode == "accepted_read":
			_check(not _level().hud.boss_bar.is_open(), "cold accepted completion cannot wake a retired boss bar")''','''		_check(not GameState.has_flag(&"ch2_yong_subdued"), "isolation never grants the later power-cell result")''')
s=s.replace('var cell: BossHoldPoint = _actor.call("power_cell")','var cell: BossHoldPoint = _actor.call("isolation_box")')
s=s.replace('declared final disarm and health opening exposes the original power cell','declared cut-route fixture exposes the original isolation box')
s=s.replace('if flag != RESULT or value != true: return','if flag not in [RESULT, EXTRA] or value != true: return')
s=s.replace('saved["data"]["story"]["flags"].get(String(RESULT), false) and cell.done and _actor.call("is_subdued")','saved["data"]["story"]["flags"].get(String(RESULT), false) and saved["data"]["story"]["flags"].get(String(EXTRA), false) and cell.done and _actor.get("stage") == "subdue"')
s=s.replace('''	GameState.flag_changed.connect''','''	var authored_extra: PackedStringArray = _level().data.channel_done_extra_flags[CHANNEL]
	if _mode == "overflow":
		var too_many := PackedStringArray()
		for i in LevelData.MAX_CHANNEL_RESULT_FLAGS + 1: too_many.append("fixture_isolation_extra_%d" % i)
		_level().data.channel_done_extra_flags[CHANNEL] = too_many
	elif _mode == "empty_flag":
		_level().data.channel_done_extra_flags[CHANNEL] = PackedStringArray([""])
	GameState.flag_changed.connect''')
s=s.replace('EventBus.mechanism_toggled.emit(&"ch2_yong_down", true)','EventBus.mechanism_toggled.emit(CHANNEL, true)').replace('_actor.call("_on_pull_completed")','_actor.call("_on_box_completed")')
s=s.replace('a forged subdued state without the original completed cell is refused','a forged route change without the original completed box is refused')
s=s.replace('for i in 120:\n\t\tif cell.done:', 'for i in 180:\n\t\tif cell.done:')
s=s.replace('''	await _frames(4)
	_check(cell.done''','''	for i in 120:
		if _prompt() != null: break
		await get_tree().process_frame
	_check(cell.done''',1)
s=s.replace('cell.done and _actor.call("is_subdued")','cell.done and _actor.get("stage") == "subdue"')
s=s.replace('_mode in ["death", "stale"]','_mode in ["death", "stale", "contract", "overflow", "empty_flag"]')
s=s.replace('''		else:
			_actor.data = _actor.data.duplicate(true)
			_prompt().get("retry_button").pressed.emit()
			await _frames(3)''','''		elif _mode in ["stale", "contract"]:
			if _mode == "stale": _actor.data = _actor.data.duplicate(true)
			else: _level().data.channel_done_extra_flags[CHANNEL] = PackedStringArray()
			_prompt().get("retry_button").pressed.emit()
			await _frames(3)''')
s=s.replace('''		DirAccess.remove_absolute(store.path + ".tmp")''','''		_level().data.channel_done_extra_flags[CHANNEL] = authored_extra
		DirAccess.remove_absolute(store.path + ".tmp")''',1)
s=s.replace('_observations == [true]','_observations == [true, true]')
a=s.index('func _prepare_opening() -> void:');b=s.index('func _yong()',a)
s=s[:a]+'''func _prepare_opening() -> void:
	# Explicit prior cut choice, health and position; the held box action is real.
	GameState.set_flag(&"yong_link_choice", "cut", false)
	_actor.set_physics_process(false)
	_actor.call("_set_health_silent", _actor.call("_choice_hp"))
	_actor.call("_start_cut", false)
	_actor.contact.active = false
	_player().global_position = (_actor.call("isolation_box") as BossHoldPoint).global_position
	_player().velocity = Vector2.ZERO
	_player().set_physics_process(false)

func _no_results() -> bool:
	return not GameState.has_flag(RESULT) and not GameState.has_flag(EXTRA)

func _all_results() -> bool:
	return GameState.has_flag(RESULT) and GameState.has_flag(EXTRA)

'''+s[b:]
s=s.replace('original cell','original isolation box').replace('power-cell','isolation-box').replace('power cell','isolation box').replace('nonlethal-','isolation-')
s=s.replace('Original final-action fixture, not a natural full boss fight. No result flags set.','Original held isolation-box fixture; only prior choice/position/health arranged, never its results.')
Path('tests/probes/isolation_completion.gd').write_text(s)
Path('tests/probes/isolation_completion.tscn').write_text('[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://tests/probes/isolation_completion.gd" id="1"]\n\n[node name="IsolationCompletionProbe" type="Node"]\nscript = ExtResource("1")\n')
p=Path('tools/run_nonlethal_completion.py');s=p.read_text();s=s.replace('parser.add_argument("--boss", choices=("yong", "janus"), default="yong")','parser.add_argument("--action", "--boss", dest="action", choices=("yong", "janus", "isolation"), default="yong")').replace('args.boss','args.action')
s=s.replace('scene = SCENE if args.action == "yong" else "res://tests/probes/janus_completion.tscn"','scene = {"yong": SCENE, "janus": "res://tests/probes/janus_completion.tscn",\n             "isolation": "res://tests/probes/isolation_completion.tscn"}[args.action]')
s=s.replace('"data/enemies/janus.tres", "data/bosses/janus.json"]','"data/enemies/janus.tres", "data/bosses/janus.json",\n             "tests/probes/isolation_completion.gd", "tests/probes/isolation_completion.tscn"]')
s=s.replace('receipt = {"boss": args.action,','receipt = {"action": args.action, "boss": "yong" if args.action == "isolation" else args.action,')
s=s.replace('''    with ThreadPoolExecutor(max_workers=3) as executor:
        for case in executor.map(run, [args.action, "cancel", "death", "stale", "forged"]):''','''    modes = [args.action, "cancel", "death", "stale", "forged"]
    if args.action == "isolation": modes.extend(["contract", "overflow", "empty_flag"])
    with ThreadPoolExecutor(max_workers=3) as executor:
        for case in executor.map(run, modes):''')
p.write_text(s)
p=Path('.github/workflows/tests.yml');s=p.read_text();needle='          python3 tools/run_nonlethal_completion.py --boss janus --godot "$GODOT" --output "${{ runner.temp }}/janus-completion"';assert needle in s;s=s.replace(needle,needle+'\n          python3 tools/run_nonlethal_completion.py --action isolation --godot "$GODOT" --output "${{ runner.temp }}/isolation-completion"');needle='            ${{ runner.temp }}/janus-completion/**/*.json';s=s.replace(needle,needle+'\n            ${{ runner.temp }}/isolation-completion/**/*.log\n            ${{ runner.temp }}/isolation-completion/**/*.json');p.write_text(s)
