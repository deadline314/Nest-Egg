extends "res://tests/probes/training_completion.gd"
## Declared cut-choice, position and health fixtures, not full combat.
func _ready() -> void:
 super._ready()
 CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))

func _run() -> void:
 _main = load("res://game/main.gd").new()
 var store := RunSaveStore.new(_save_dir.path_join("slot.json"))
 _main.set("_run_store",store)
 add_child(_main)
 await _frames(8)
 _main.call("_on_start_requested",GameState.difficulties[1])
 await _frames(90)
 await _finish_story()
 await _wait_control()
 _main.call("_on_area_requested","res://data/levels/ch2_ledger_office.tres")
 await _frames(12)
 await _finish_story()
 await _wait_control()
 var boss: Node
 for node in _level().channel_sources:
  if is_instance_valid(node) and node is PatternBoss and node.data.id == &"yong": boss=node
 _check(boss != null,"real Main owns the original second-chapter boss")
 if boss == null: await _done();return
 # Explicit cut-choice, health and position fixture; the original held box action follows.
 GameState.set_flag(&"yong_link_choice","cut",false)
 boss.set_physics_process(false)
 boss.call("_set_health_silent",boss.call("_choice_hp"))
 boss.call("_start_cut",false)
 boss.contact.active=false
 var cell: BossHoldPoint=boss.call("isolation_box")
 _player().global_position=cell.global_position
 _player().velocity=Vector2.ZERO
 _player().set_physics_process(false)
 _check(cell.enabled and not cell.done and not GameState.has_flag(&"yong_link_isolated") and not GameState.has_flag(&"yong_link_revoked"),"declared cut-route opening exposes the original uncompleted isolation box")
 _main.call("_save_run")
 _before=FileAccess.get_file_as_bytes(store.path)
 _check(not _before.is_empty() and DirAccess.make_dir_absolute(store.path+".tmp")==OK,"owned refusal begins after a complete original primary")
 Input.action_press(&"interact")
 for i in 180:
  if cell.done:break
  await _frames(1)
 Input.action_release(&"interact")
 await _frames(4)
 _check(cell.done and boss.get("stage")=="subdue","real held interaction completes the original isolation box without killing the boss")
 _check(not boss.is_dying(),"the nonlethal result never pretends to be an enemy death")
 _check(not GameState.has_flag(&"yong_link_isolated"),"refused original box action cannot publish isolation")
 _check(not GameState.has_flag(&"yong_link_revoked"),"refused original box action cannot publish revocation")
 _check(FileAccess.get_file_as_bytes(store.path)==_before,"refused nonlethal action retains exact original primary bytes")
 await _done()
func _wait_control() -> void:
 for i in 1800:
  if not GameplayLock.is_locked() and not Story.is_cinematic_active():return
  await _frames(1)
