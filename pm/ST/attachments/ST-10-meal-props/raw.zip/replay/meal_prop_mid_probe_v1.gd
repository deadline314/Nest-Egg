extends "res://work/meal_prop_probe.gd"
## Existing rule: a pending cinematic resumes from its beginning, not its visual cursor.
var _resumed_full := false
var _resumed_empty := false

func _shot(name: String, player: CutscenePlayer) -> void:
	await super._shot(name, player)
	if _mode == "read":
		if name == "meal-full":
			_resumed_full = true
			_check(not GameState.has_flag(&"ch1_supper_meal_done"), "cold mid-meal entry restarts full bowl without prematurely completing meal")
		elif name == "meal-empty":
			_resumed_empty = true
	if _mode == "write" and name == "meal-empty":
		await _frames(3)
		var saved: Dictionary = _main.get("_run_store").read()
		_check(saved.get("cinematic") == "ch1_t_supper_stay_meal" and saved.get("story", {}).get("flags", {}).get("ch1_supper_meal_done") != true, "actual disk keeps pending meal despite its temporary empty-bowl visual")
		_closing = true
		await _finish()

func _finish() -> void:
	if _mode == "read":
		_check(_resumed_full and _resumed_empty, "cold mid-meal replay naturally returns from full to eaten before address")
	if not _out.is_empty():
		var file := FileAccess.open(_out.path_join("mid-probe-source.json"), FileAccess.WRITE)
		file.store_string(JSON.stringify({"sha256": FileAccess.get_sha256("res://work/meal_prop_mid_probe.gd"), "base_sha256": FileAccess.get_sha256("res://work/meal_prop_probe.gd")}))
		file.close()
	await super._finish()
