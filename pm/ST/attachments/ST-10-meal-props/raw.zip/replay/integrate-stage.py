from pathlib import Path
import subprocess,json,hashlib
b=Path('/workspace/Nest-Egg/work/batch1021');w=b/'stage'
def run(*args,check=True):return subprocess.run(args,cwd=w,check=check)
def out(*args):return subprocess.check_output(args,cwd=w)
assert out('git','branch','--show-current').decode().strip()=='codex/stage-meal-state'
paths=[p.decode() for p in out('git','diff','HEAD','--name-only','-z').split(b'\0') if p]
saved={p:(w/p).read_bytes() for p in paths}
run('git','-c','user.name=Stanley Li','-c','user.email=stanley890314@gmail.com','stash','push','-u','-m','ST-10 own worktree before ST-9 integration')
oid=out('git','rev-parse','stash@{0}').decode().strip();(b/'stage-second-stash.oid').write_text(oid)
run('git','rebase','origin/main')
apply=run('git','stash','apply',oid,check=False)
unmerged=[p.decode() for p in out('git','diff','--name-only','--diff-filter=U','-z').split(b'\0') if p]
if unmerged:
 assert unmerged==['tests/suite/test_cutscene.gd'],unmerged
 p=w/unmerged[0];text=out('git','show','HEAD:'+unmerged[0]).decode();needle='func run() -> void:\n';assert needle in text
 text=text.replace(needle,needle+'\tpreload("res://tests/helpers/stage_prop_state_checks.gd").run(self)\n',1)
 assert 'story_batch_preflight_checks.gd' in text;p.write_text(text);run('git','add',unmerged[0])
assert not out('git','diff','--name-only','--diff-filter=U').strip()
exceptions={'tests/suite/test_cutscene.gd','tools/story/ch1_runtime_backend.py','data/story/ch1_kasa.json'}
proof={}
for name,d in saved.items():
 if name not in exceptions:assert (w/name).read_bytes()==d,name
 proof[name]={'sha256_before':hashlib.sha256(d).hexdigest(),'sha256_after':hashlib.sha256((w/name).read_bytes()).hexdigest()}
# Rebuild the actual compiler output with BOTH policies and prop-state steps.
with (b/'stage-story-regenerate.log').open('w') as f:subprocess.run(['python3','tools/story/build_ch1_story.py'],cwd=w,check=True,stdout=f,stderr=subprocess.STDOUT)
s=json.loads((w/'data/story/ch1_kasa.json').read_text())['scenes']
assert s['ch1_t_handoff_accept']['completion_policy']=='main_terminal_results_v1'
assert s['ch1_t_handoff_accept']['results'][0].get('destination')=='ch1_handoff_cabinet'
assert s['ch1_t_supper_stay_address']['steps'][0]['prop_states']=={'noodle_table':'eaten'}
assert any(t.get('do')=='prop' and t.get('state')=='eaten' for t in s['ch1_t_supper_stay_meal']['steps'])
for line in out('git','stash','list','--format=%gd %H').decode().splitlines():
 ref,sha=line.split()
 if sha==oid:run('git','stash','drop',ref);break
else:raise RuntimeError('Own stash missing; preserve all others')
(b/'meal-rebase-story-receipt.json').write_text(json.dumps({'base':out('git','rev-parse','HEAD').decode().strip(),'tracked_sources':proof,'both_compiler_behaviors_verified':True,'own_stash_dropped':oid},indent=2))
print('both ST-9 and ST-10 behaviors preserved and actual story regenerated')
