from pathlib import Path
import subprocess,os,hashlib,json,time
b=Path('/workspace/Nest-Egg/work/batch1021');w=b/'stage'
# Keep native rendering separate from the fixed-base regression run.
deadline=time.monotonic()+1200
while not (b/'changed.exit').exists():
 if time.monotonic()>deadline:raise RuntimeError('Required regression still running; no baseline mutation made')
 time.sleep(5)
if (b/'changed.exit').read_text().strip()!='0':raise RuntimeError('Required regression failed; preserve baseline and prioritize failures')
paths=[x.decode() for x in subprocess.check_output(['git','diff','--name-only','-z'],cwd=w).split(b'\0') if x and not x.decode().startswith(('tests/','design/','pm/','assets_src/','art/'))]
saved={p:(w/p).read_bytes() for p in paths}
archive=b/'meal-candidate-source';archive.mkdir(exist_ok=True)
for p,v in saved.items():
 d=archive/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(v)
receipt={}
try:
 for p in paths:(w/p).write_bytes(subprocess.check_output(['git','show','ddbb6248:'+p],cwd=w))
 env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1021/stage'
 with (b/'meal-baseline-v2-wrapper.log').open('w') as log:r=subprocess.run(['python3','/workspace/Nest-Egg/work/batch1020b/native.py','meal-prop-baseline-v2','res://work/meal_prop_probe.tscn','--mode=normal','--save-dir='+str(b/'meal-baseline-v2-slot')],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt['exit']=r.returncode
finally:
 for p,v in saved.items():(w/p).write_bytes(v)
 receipt['restored']={p:hashlib.sha256((w/p).read_bytes()).hexdigest()==hashlib.sha256(v).hexdigest() for p,v in saved.items()}
 (b/'meal-baseline-v2-restored.json').write_text(json.dumps(receipt,indent=2))
print(receipt)
