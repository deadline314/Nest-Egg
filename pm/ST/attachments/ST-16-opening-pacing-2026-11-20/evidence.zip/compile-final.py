from pathlib import Path
from subprocess import check_output
import json
import sys
base=Path(__file__).resolve().parent
root=Path.cwd()
baseline=(base/'baseline.txt').read_text().strip()
old=json.loads(check_output(['git','show',f'{baseline}:data/story/ch1_kasa.json']))
def encode(value):
    return json.dumps(value,ensure_ascii=False,indent=1)+'\n'
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'tools/story'))
import ch1_runtime_backend as backend
backend.legacy.STAGE_DIR=str(base/'stages')
backend.OUT=str(base/'final.json')

assert backend.main()==0
trial=json.loads((base/'final.json').read_bytes())
assert list(trial)==list(old)
assert [key for key in old if old[key]!=trial[key]]==['scenes']
assert list(old['scenes'])==list(trial['scenes'])
changed=[key for key in old['scenes'] if old['scenes'][key]!=trial['scenes'][key]]
assert changed==['ch1_p01_door','ch1_p02_talk']
scene=trial['scenes'][changed[0]]
previous=old['scenes'][changed[0]]
assert {k:v for k,v in scene.items() if k!='steps'}=={k:v for k,v in previous.items() if k!='steps'}
assert [step for step in scene['steps'] if step['do'] not in ('say','wait')]==[step for step in previous['steps'] if step['do'] not in ('say','wait')]
assert sum(step['do']=='say' for step in scene['steps'])==4
assert len(trial['scenes'][changed[1]]['lines'])==5 and trial['scenes'][changed[1]]['map_interaction']
(base/'compile-proof.json').write_text(encode({'chapter_scenes':len(old['scenes']),'quests':len(old['quests']),
    'changed_scenes':changed,'opening_lines':[6,4],'workbench_lines':[7,5],'preserves_stage_and_routes':True}),encoding='utf-8')
(root/'data/story/ch1_kasa.json').write_bytes((base/'final.json').read_bytes())


