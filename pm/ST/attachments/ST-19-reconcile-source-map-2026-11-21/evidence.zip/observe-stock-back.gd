extends "res://tools/ch1_flow_probe.gd"

const FLOOR := "res://data/levels/ch2_loading.tres"
const DOCS := [&"ch2_evidence_contract", &"ch2_evidence_receipt", &"ch2_evidence_collection"]
const CHOICES := [&"ch2_t_s10_principal", &"ch2_t_s10_interest", &"ch2_t_s10_batch"]
var app: Node
var store: RunSaveStore
var mode := ""
var language := "zh"
var text_scale := 1.0


func _run() -> void:
	var slot := ""
	for item: String in OS.get_cmdline_user_args():
		if item.begins_with("--mode="): mode = item.trim_prefix("--mode=")
		elif item.begins_with("--lang="): language = item.trim_prefix("--lang=")
		elif item.begins_with("--scale="): text_scale = float(item.trim_prefix("--scale="))
		elif item.begins_with("--slot="): slot = item.trim_prefix("--slot=")
	if not slot.is_absolute_path() or mode not in ["stock", "candidate"]:
		get_tree().quit(2)
		return
	store = RunSaveStore.new(slot)
	app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	app.set("_run_store", store)
	add_child(app)
	Story.auto_skip = false
	for _frame in STEP_LIMIT:
		if app.get("_screen") is MainMenu and not bool(app.call("_route_pending")):
			break
		await get_tree().process_frame
	var menu := app.get("_screen") as MainMenu
	if menu == null or store.read().get("level", "") != FLOOR:
		app.call("_quit", 2)
		return
	await _settle(8)
	menu._continue_button.pressed.emit()
	for _frame in STEP_LIMIT:
		var current := app.get("_screen") as Level
		if current != null and current.is_initialized() and current.data.resource_path == FLOOR and not bool(app.call("_route_pending")):
			_level = current
			break
		await get_tree().process_frame
	if not is_instance_valid(_level):
		app.call("_quit", 2)
		return
	Settings.set_ui_text_scale(text_scale)
	_check(Story.set_language(language) and Story.language == language, "the actual story language is active")
	_check(StoryItems.owns(DOCS[0]) and StoryItems.owns(DOCS[1]) and not StoryItems.owns(DOCS[2]),
		"real Continue starts with the first two original documents")
	if not await _interact(&"ch2_collection_book"):
		app.call("_quit", 2)
		return
	for _frame in STEP_LIMIT:
		if StoryItems.owns(DOCS[2]) and not Story.is_cinematic_active():
			break
		if is_instance_valid(Story._player) and Story._player._dialogue.visible:
			await _tap(&"ui_accept")
		await get_tree().process_frame
	_check(StoryItems.owns(DOCS[2]) and GameState.has_flag(&"ch2_evidence_collection"),
		"reading the real collection book grants its original record")
	var before := StoryItems.snapshot()
	var credits := Progression.credits
	if not await _interact(&"ch2_drying_desk"):
		app.call("_quit", 2)
		return
	var choice := await _choice_at(CHOICES[0])
	if choice == null:
		app.call("_quit", 2)
		return
	await _tap(&"ui_cancel")
	var advanced := await _choice_at(CHOICES[1])
	_check(advanced != null and advanced.choice_active(), "stock escape submits the current default and reaches step two")
	_check(StoryItems.snapshot() == before and Progression.credits == credits and not GameState.has_flag(&"ch2_market_reconciled"),
		"stock escape advances the puzzle without publishing a final result")
	if advanced != null:
		await RenderingServer.frame_post_draw
		_capture("escape-advanced")
	var file := FileAccess.open(_out_dir.path_join("reconcile.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"advanced": advanced != null, "failed": _failures}, "  "))
	file.close()
	app.call("_quit", int(_failures != 0))


func _interact(id: StringName) -> bool:
	for node in _level._entities.get_children():
		if not node is NpcActor or node.data.id != id:
			continue
		_level.player.global_position = node.global_position + Vector2(-26, 0)
		_level.player.velocity = Vector2.ZERO
		_level.camera.snap_to_target()
		for _frame in 55:
			if node.interaction_available() and _level.player.is_on_floor():
				await _tap(&"interact")
				return true
			await get_tree().physics_frame
	_check(false, "the original interaction could not be reached: " + str(id))
	return false


func _focus(button: Button, direction: Key) -> void:
	for _i in 6:
		if button.has_focus():
			break
		for pressed: bool in [true, false]:
			var event := InputEventKey.new()
			event.keycode = direction
			event.physical_keycode = direction
			event.pressed = pressed
			Input.parse_input_event(event)
			await get_tree().process_frame
	_check(button.has_focus(), "keyboard navigation reaches " + button.text)


func _tap(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await get_tree().process_frame
	event = InputEventAction.new()
	event.action = action
	Input.parse_input_event(event)
	await get_tree().process_frame


func _choice_at(id: StringName) -> CutscenePlayer:
	for _frame in STEP_LIMIT:
		var cutscene := Story._player
		if is_instance_valid(cutscene) and cutscene.scene_id == id and cutscene.choice_active():
			return cutscene
		if is_instance_valid(cutscene) and cutscene._dialogue.visible:
			await _tap(&"ui_accept")
		await get_tree().process_frame
	_check(false, "the original choice could not be reached: " + str(id))
	return null
