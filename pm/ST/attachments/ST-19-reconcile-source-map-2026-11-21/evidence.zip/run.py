from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
root = Path.cwd()
game = base.parent / "ne218-baseline-20261117"
label, mode, language = sys.argv[1:4]
folder = base / label
folder.mkdir()
size = sys.argv[4] if len(sys.argv) > 4 else "1280x720"
scale = sys.argv[5] if len(sys.argv) > 5 else "1.0"
seed = root / "work/ne97-campaign-route-20261119/native-ch2-loading-ground-v2/save/slot.json"
slot = folder / "slot.json"
copy2(seed, slot)
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TMPDIR", "TEMP", "TMP", "XDG_CONFIG_HOME", "XDG_DATA_HOME"):
    path = folder / key
    path.mkdir()
    env[key] = str(path)
sources = json.loads((base / "runtime.json").read_bytes())
metadata = {item: sha256((game / item).read_bytes()).hexdigest() for item in sources}
command = [sys.executable, "-B", str(game / "tools/comfyui/gpu_lock.py"), "--",
           "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(game), "--rendering-method", "forward_plus",
           "--rendering-driver", "vulkan", "--audio-driver", "Dummy", "--fixed-fps", "60", "--resolution", size,
           "--quit-after", "7000", str(base / "observe.tscn"), "--", "--out=" + str(folder), "--slot=" + str(slot),
           "--mode=" + mode, "--lang=" + language, "--scale=" + scale]
(folder / "command.json").write_text(json.dumps({"argv": command, "seed_sha256": sha256(seed.read_bytes()).hexdigest(),
                                                "source_sha256": metadata}, indent=2) + "\n", encoding="utf-8")
with (folder / "engine.log").open("wb") as log:
    completed = subprocess.run(command, cwd=game, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=225)
text = (folder / "engine.log").read_text(encoding="utf-8", errors="replace")
print(text[-4800:], flush=True)
assert completed.returncode == 0 and not re.search(r"^(SCRIPT ERROR|ERROR:|FAIL )|leaked at exit", text, re.M)
record = json.loads((folder / "reconcile.json").read_bytes())
assert record["failed"] == 0 and record["flag"]
assert all(sha256((game / path).read_bytes()).hexdigest() == value for path, value in metadata.items())
