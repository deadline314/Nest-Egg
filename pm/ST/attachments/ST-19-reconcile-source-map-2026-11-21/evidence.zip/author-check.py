from hashlib import sha256
from pathlib import Path
from shutil import copy2
import copy
import json
import sys

base = Path(__file__).resolve().parent
root = Path.cwd()
sys.path.insert(0, str(root / "tools/story"))
import build_ch2_story
import story_contracts

ids = ("ch2_t_s10_principal", "ch2_t_s10_interest", "ch2_t_s10_batch")
production = root / "data/story/ch2_heron.json"
baseline = json.loads(production.read_bytes())
output = base / "rebuilt-ch2.json"
build_ch2_story.write_chapter(build_ch2_story.spec(), output)
compiled = json.loads(output.read_bytes())
for ident in ids:
    result = compiled["scenes"][ident]
    before = baseline["scenes"][ident]
    contract = story_contracts.effect_projection(before)
    assert story_contracts.same_effects(result, contract)
    negative = copy.deepcopy(result)
    negative["steps"][-1]["options"][0]["target"] = "ch2_t_s10_revisit"
    assert not story_contracts.same_effects(negative, contract)
    assert result["steps"][-1].pop("cancel_choice_on_back") is True
assert compiled == baseline
seal = sha256((root / "data/story_contracts/migration-5a.json").read_bytes()).hexdigest()
assert seal == story_contracts.MIGRATION_SHA
copy2(output, production)
(base / "author-delta.json").write_text(json.dumps({"scenes": ids, "sealed_migration": seal}, indent=2) + "\n",
                                         encoding="utf-8")
print("Only the three specified choice surfaces acquired an explicit Back action; every original option and effect is byte-equivalent structurally.")
