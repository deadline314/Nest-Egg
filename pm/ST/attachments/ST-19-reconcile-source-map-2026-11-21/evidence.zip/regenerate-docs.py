from hashlib import sha256
from pathlib import Path
import json
import sys
base=Path(__file__).resolve().parent
root=Path.cwd()
sys.path.insert(0,str(root/"tools/story"))
import build_ch2_story
from chapter_compiler import write_documents
chapter=build_ch2_story.spec()
output=base/"regenerated-documents"
output.mkdir(exist_ok=True)
write_documents(chapter.source,"ch2_heron",output,200)
records={}
for item in sorted(output.glob("*.tres")):
    target=root/"data/story_items"/item.name
    raw=item.read_text(encoding="utf-8").encode("utf-8")
    assert raw == target.read_text(encoding="utf-8").encode("utf-8"), item.name
    records[item.stem]={"sha256":sha256(raw).hexdigest(),"source_actor":chapter.source.documents[item.stem].get("source_actor","")}
assert len(records)==8
assert {k:v["source_actor"] for k,v in records.items() if v["source_actor"]} == {
    "ch2_evidence_contract":"ch2_rent_window","ch2_evidence_receipt":"ch2_vig","ch2_evidence_collection":"ch2_collection_book"}
(base/"generated-documents.json").write_text(json.dumps(records,indent=2)+"\n",encoding="utf-8")
print("Rebuilt and compared all eight original Ch2 document resources with normalized line endings.")
