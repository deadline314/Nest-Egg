from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import json, sys

root=Path.cwd()
scope=Path(__file__).resolve().parent
sys.path.insert(0,str(root/"tools/story"))
import ch1_runtime_backend as backend
import story_i18n

out=scope/"compiled-final"
out.mkdir()
backend.OUT=str(out/"ch1_kasa.json")
backend.legacy.STAGE_DIR=str(out)
assert backend.main()==0
scene="ch1_t_ali_2_sit"
story_path=Path("data/story/ch1_kasa.json")
stage_path=Path("data/cutscene/stages/ch1_revival_lounge.json")
original_story=json.loads((root/story_path).read_bytes())
rebuilt_story=json.loads((out/story_path.name).read_bytes())
original_stage=json.loads((root/stage_path).read_bytes())
rebuilt_stage=json.loads((out/stage_path.name).read_bytes())
assert original_story["scenes"][scene]==rebuilt_story["scenes"][scene]
assert original_stage==rebuilt_stage
differing=[key for key in original_story if original_story.get(key)!=rebuilt_story.get(key)]
scene_diff=sorted(ident for ident in (original_story["scenes"].keys()|rebuilt_story["scenes"].keys())
                 if original_story["scenes"].get(ident)!=rebuilt_story["scenes"].get(ident))
config=(root/"tools/select_tests.py")
runtime=[str(stage_path.as_posix()),str(story_path.as_posix()),"data/cutscene/stage_proportions.json"]
author=["tools/story/build_ch1_story.py","tools/story/ch1_runtime_backend.py"]
import subprocess
def select(paths):
    return subprocess.check_output([sys.executable,str(config),"--files",*paths],text=True).strip()
assert select(runtime)==select(runtime+author)
summary={"scene_regenerated_equal":True,"stage_regenerated_equal":True,
         "unchanged_selector":select(runtime),"whole_story_changed_sections":differing,"whole_story_changed_scenes":scene_diff,
         "source_sha256":{item:sha256((root/item).read_bytes()).hexdigest() for item in runtime+author}}
(scope/"compiler.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(summary,ensure_ascii=False,indent=2))
