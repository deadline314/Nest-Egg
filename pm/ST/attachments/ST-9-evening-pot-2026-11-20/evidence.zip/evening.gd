extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const PROP := "ali_lounge_soup_pot"
const SIT := &"ch1_t_ali_2_sit"
const ORDERED := &"ch1_t_ali_2_ordered"
const POINT := Vector2(158, 28)
var _out := ""
var _rows: Array[Dictionary] = []


func _ready() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	var facts := [GameState.world_flags.duplicate(true), Progression.credits, StoryItems.snapshot()]
	if not await _observe(SIT, "normal") or not await _observe(ORDERED, "normal") 			or not await _observe(SIT, "skip") or not await _observe(SIT, "cancel"):
		printerr("A stage case failed")
		get_tree().quit(1)
		return
	if facts != [GameState.world_flags, Progression.credits, StoryItems.snapshot()]:
		printerr("Direct presentation changed story facts")
		get_tree().quit(1)
		return
	var out := FileAccess.open(_out.path_join("evening.json"), FileAccess.WRITE)
	out.store_string(JSON.stringify({"adapter":RenderingServer.get_video_adapter_name(),
		"renderer":RenderingServer.get_current_rendering_method(), "hdr_2d":get_viewport().use_hdr_2d,
		"facts_unchanged":true, "cases":_rows}, "  ") + "\n")
	out.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit()


func _observe(id: StringName, mode: String) -> bool:
	var scene: Dictionary = Story._scenes.get(id, {})
	var issues := CutsceneChecker.validate(str(id), scene, Story._speakers)
	issues.append_array(CutsceneChecker.staging_problems(str(id), scene))
	if not issues.is_empty():
		printerr(issues)
		return false
	var player := CutscenePlayer.new()
	add_child(player)
	player.play(id, scene)
	var rows: Array[Array] = []
	var first_line := false
	var moved := false
	var shot_handoff := false
	var shot_greeting := false
	var first_line_frames := 0
	for frame in 180:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		if player._stage == null:
			continue
		var pot := player._stage.prop_node(PROP) as StageLayers._Sprite
		var ali: CutsceneActor = player._actors.get(&"ali")
		if pot == null or not is_instance_valid(ali):
			continue
		first_line = player._dialogue.visible
		if first_line:
			first_line_frames += 1
		if id == ORDERED:
			if pot.visible or ali.hand_targets_active():
				printerr("Ordered route shows the close-up prop or reach")
				return false
			if first_line:
				break
			continue
		if not pot.visible:
			printerr("No-order route did not make the pot visible")
			return false
		var stage_point := player._stage.to_local(pot.global_position)
		var grip := player._stage.to_local(pot.to_global(pot.source_point(POINT)))
		var hand := player._stage.to_local(ali.hand_contact_global(&"front"))
		var distance := grip.distance_to(hand)
		rows.append([frame,stage_point.x,stage_point.y,grip.x,grip.y,hand.x,hand.y,distance,
			ali.hand_targets_active(),ali.hand_target_settled(&"front"),first_line])
		if stage_point.x > 264.1 and stage_point.x < 273.9:
			moved = true
			if not ali.hand_target_settled(&"front") or distance > 0.05:
				printerr("Pot moved before the open hand reached its handle: ", stage_point, " / ", distance)
				return false
			if mode != "normal":
				if mode == "skip":
					player.skip()
				else:
					player.cancel()
				break
			if stage_point.x <= 269.0 and not shot_handoff:
				shot_handoff = Capture.image(get_viewport()).save_png(_out.path_join("ali-pot-contact.png")) == OK
		if first_line_frames >= 20 and player._dialogue.is_complete() and stage_point.x <= 264.01 and not shot_greeting:
			shot_greeting = Capture.image(get_viewport()).save_png(_out.path_join("ali-evening-greeting.png")) == OK
		if shot_greeting and not ali.hand_targets_active():
			break
	if mode == "normal" and (not first_line or (id == SIT and not (moved and shot_handoff and shot_greeting))):
		printerr("Failed normal arrival: ", first_line, " ", moved, " ", shot_handoff, " ", shot_greeting)
		return false
	if mode != "normal" and not moved:
		return false
	if player.is_running():
		if mode != "cancel":
			player.skip()
	for frame in 120:
		if not player.is_running():
			break
		await get_tree().process_frame
	var settled := not player.is_running()
	player.queue_free()
	await get_tree().process_frame
	_rows.append({"scene":str(id),"mode":mode,"shown_first_line":first_line,"moved":moved,"settled":settled,
		"steps_sha256":JSON.stringify(scene["steps"]).sha256_text(),"frames":rows})
	return settled
