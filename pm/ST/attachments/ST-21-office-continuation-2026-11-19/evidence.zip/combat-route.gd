extends Node
## 序章真輸入探針（ST-16）：從真正的 Main 新遊戲入口開始，用移動、跳躍、射擊、近戰、格擋、衝刺與互動鍵玩完序章，
## 走出店門進當舖，沿途截圖並檢查每一項練習是否靠真的動作完成。瞄準用手把右搖桿的輸入（AimInput 的手把路徑）。
## 用法：godot --path . res://tools/prologue_play_probe.tscn -- --out=<絕對路徑資料夾>
##   [--save-dir=<絕對路徑>]：存檔寫到這個資料夾（不碰玩家的存檔），供 prologue_resume_probe 在另一個程序繼續。
##   [--stop-after=<旗標>]：練到這個旗標就像玩家一樣從 Main 正常退出（會存檔）。
##   [--gamepad]：先送一個真的手把按鍵事件，提示改顯示手把按鍵（截圖檔名加 -pad）。

const LIMIT := 1800

var _out := ""
var _main: Node
var _failures := 0
var _played: Array[StringName] = []
var _save_dir := ""
var _stop_after := &""
var _gamepad := false


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--save-dir="):
			_save_dir = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--stop-after="):
			_stop_after = StringName(arg.trim_prefix("--stop-after="))
		elif arg == "--gamepad":
			_gamepad = true
	if not _save_dir.is_empty() and (not _save_dir.is_absolute_path() or DirAccess.make_dir_recursive_absolute(_save_dir) != OK):
		push_error("[ProloguePlayProbe] --save-dir 要是可寫入的絕對路徑：%s" % _save_dir)
		get_tree().quit(2)
		return
	if not _out.is_empty():
		DirAccess.make_dir_recursive_absolute(_out)
	_run.call_deferred()


func _check(ok: bool, what: String) -> void:
	print("%s %s" % ["PASS" if ok else "FAIL", what])
	if not ok:
		_failures += 1


var _accept_radio := false
var _radio_ticks := 0
var _radio_captured := false

func _frames(n: int) -> void:
	for i in n:
		await get_tree().physics_frame
		if _accept_radio and Story._layer.is_radio_frozen():
			_radio_ticks += 1
			if _radio_ticks == 10 and not _radio_captured:
				await _capture_route_radio()
			if _radio_ticks > 15 and _radio_ticks % 12 == 0:
				_send_action(&"ui_accept")
		else:
			_radio_ticks = 0


func _send_action(action: StringName) -> void:
	var key := InputEventAction.new()
	key.action = action
	key.pressed = true
	Input.parse_input_event(key)
	var release := InputEventAction.new()
	release.action = action
	Input.parse_input_event(release)


func _shot(name: String) -> void:
	print("SHOT %s gamepad=%s" % [name, InputBindings.using_gamepad])
	if _out.is_empty() or DisplayServer.get_name() == "headless":
		return
	if _gamepad:
		name += "-pad"
	await _frames(4)
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	print("saved %s (%s)" % [name, error_string(image.save_png(_out.path_join(name + ".png")))])


func _level() -> Level:
	var screen: Variant = _main.get("_screen")
	return screen as Level if screen is Level else null


func _player() -> Player:
	var level := _level()
	return level.player if level != null else null


## 玩家讀完演出就按略過（等同 Esc）；選擇題選預設。
func _finish_story(shot := "") -> void:
	var shown := false
	for i in LIMIT:
		if not Story.is_cinematic_active():
			return
		if not shot.is_empty() and not shown:
			await _frames(60)
			await _shot(shot)
			shown = true
		Story.skip_cinematic()
		await _frames(6)


func _walk_to(x: float, tolerance := 6.0) -> void:
	for i in LIMIT:
		var player := _player()
		if player == null:
			return
		await _finish_story()
		var dx := x - player.global_position.x
		if absf(dx) <= tolerance:
			break
		var action := &"move_right" if dx > 0.0 else &"move_left"
		Input.action_press(action)
		await _frames(1)
		Input.action_release(action)
	Input.action_release(&"move_right")
	Input.action_release(&"move_left")
	await _frames(4)


func _press(action: StringName, hold := 2) -> void:
	Input.action_press(action)
	await _frames(hold)
	Input.action_release(action)
	await _frames(2)


func _aim(direction: Vector2) -> void:
	AimInput.using_gamepad = true
	for name in [&"aim_left", &"aim_right", &"aim_up", &"aim_down"]:
		Input.action_release(name)
	if direction.x > 0.0:
		Input.action_press(&"aim_right", direction.x)
	elif direction.x < 0.0:
		Input.action_press(&"aim_left", -direction.x)
	if direction.y < 0.0:
		Input.action_press(&"aim_up", -direction.y)
	elif direction.y > 0.0:
		Input.action_press(&"aim_down", direction.y)


func _station(id: StringName) -> TrainingStation:
	for node in _level().find_children("*", "TrainingStation", true, false):
		if (node as TrainingStation).data.id == id:
			return node
	return null


func _npc(id: StringName) -> NpcActor:
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if (node as NpcActor).data.id == id:
			return node
	return null


## 送一個真的手把按鍵事件（像玩家拿起手把按了一下），讓提示改顯示手把的按鍵。
func _touch_gamepad() -> void:
	var press := InputEventJoypadButton.new()
	press.device = 0
	press.button_index = JOY_BUTTON_GUIDE
	press.pressed = true
	Input.parse_input_event(press)
	var release := press.duplicate() as InputEventJoypadButton
	release.pressed = false
	Input.parse_input_event(release)
	await _frames(2)


## 練到 --stop-after 指定的旗標時，從 Main 正常退出（Main 退出前會存檔）。回傳 true 代表探針已結束。
func _stop_if(flag: StringName) -> bool:
	if _stop_after != flag or not GameState.has_flag(flag):
		return false
	print("PROLOGUE_STOPPED_AT %s level=%s deaths=%d" % [flag, _level().data.resource_path if _level() != null else "", GameState.deaths])
	print("PROLOGUE_PLAY_PROBE failures=%d" % _failures)
	_main.call("_quit", 1 if _failures > 0 else 0)
	return true


func _wait_flag(flag: StringName, frames := 600) -> bool:
	for i in frames:
		if GameState.has_flag(flag):
			return true
		await _frames(1)
	return GameState.has_flag(flag)


func _run() -> void:
	if "--from-save" in OS.get_cmdline_user_args():
		await _route_from_save()
		return
	Story.scene_started.connect(func(id: StringName, _mode: StringName) -> void: _played.append(id))
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	if not _save_dir.is_empty():
		_main.set("_run_store", RunSaveStore.new(_save_dir.path_join("slot.json")))
	add_child(_main)
	await _frames(30)
	# 軟體算圖時選單轉場很慢：轉場還沒結束時 Main 會忽略開始，所以每秒重按一次，最多等兩分鐘。
	var deadline := Time.get_ticks_msec() + 120000
	var started := false
	while Time.get_ticks_msec() < deadline and (_level() == null or _player() == null):
		if not started and not bool(_main.call("_route_pending")):
			_main.call("_on_start_requested", GameState.difficulties[1])
			started = _main.get("_active_run")
		await _frames(30)
	var level := _level()
	_check(level != null and level.data.resource_path == "res://data/levels/ch1_prologue.tres", "a new game from Main enters the prologue")
	if level == null:
		print("PROLOGUE_PLAY_PROBE failures=%d" % _failures)
		get_tree().quit(1)
		return
	await _frames(90)
	await _finish_story("ST-16-p01-door")
	var deaths := GameState.deaths
	# 暫停選單的略過：短按先確認（預設焦點「繼續練習」），這裡取消，回到原步、不改進度。
	var menu: PauseMenu = level._pause_menu
	for i in LIMIT:
		if not GameplayLock.is_locked() and not Story.is_cinematic_active():
			break
		await _frames(1)
	await _frames(30)
	# 演出會吃掉確認鍵，所以等操作交回玩家才拿起手把按一下（像玩家一樣），之後的提示都改顯示手把按鍵。
	if _gamepad:
		await _touch_gamepad()
	menu.open()
	_check(menu._root.visible, "the pause menu opens once the opening hands over control")
	menu._skip_button.button_down.emit()
	menu._skip_button.button_up.emit()
	menu._skip_button.pressed.emit()
	await _frames(40)  # 選單有淡入動畫
	await _shot("ST-16-skip-confirm")
	menu._cancel_skip()
	menu.close()
	_check(not GameState.has_flag(&"ch1_prologue_skipped"), "cancelling the prologue skip keeps the practice")
	# P01→P02：走到工作桌（真的移動才算），再跳上兩格高的搬貨台。
	var bench := _station(&"ch1_training_workbench")
	await _walk_to(bench.global_position.x)
	_check(await _wait_flag(&"ch1_prologue_bench_done", 60), "walking to the workbench completes the movement practice")
	if _stop_if(&"ch1_prologue_bench_done"):
		return
	await _finish_story("ST-16-p02-talk")
	var platform := _station(&"ch1_training_platform")
	# 像玩家一樣：沒跳上去就退回助跑再跳（最多四次）。
	for attempt in 4:
		await _walk_to(platform.global_position.x - 46.0, 4.0)
		await _frames(20)
		if attempt == 0:
			await _shot("ST-16-p02-jump-prompt")
		Input.action_press(&"move_right")
		Input.action_press(&"jump")
		# 像玩家一樣在空中收方向：到了搬貨台上方就放開右鍵，落在台上。
		for i in 70:
			if i == 16:
				Input.action_release(&"jump")
			if _player().global_position.x >= platform.global_position.x - 6.0:
				Input.action_release(&"move_right")
			if GameState.has_flag(&"ch1_prologue_jump_done"):
				break
			await _frames(1)
		Input.action_release(&"jump")
		Input.action_release(&"move_right")
		if GameState.has_flag(&"ch1_prologue_jump_done"):
			break
		var p := _player()
		print("jump attempt %d missed: player %s state %s, platform %s, locked %s, story %s" % [attempt, p.global_position, p.state, platform.global_position, GameplayLock.is_locked(), Story.is_cinematic_active()])
	_check(await _wait_flag(&"ch1_prologue_jump_done", 60), "a real jump onto the cargo platform completes the jump practice")
	if _stop_if(&"ch1_prologue_jump_done"):
		return
	await _finish_story()
	# P03：射擊線，用手把瞄準右方開槍打低靶。
	var range_mark := _station(&"ch1_training_range")
	await _walk_to(range_mark.global_position.x)
	await _finish_story("ST-16-p03-range")
	_check(_npc(&"ch1_old_k_backyard").is_present() and not _npc(&"ch1_old_k_prologue").is_present(), "Old K moves to the backyard line once the tool is down")
	var target := _station(&"ch1_training_target")
	await _walk_to(target.global_position.x - 120.0)
	_aim(Vector2.RIGHT)
	await _frames(10)
	await _shot("ST-16-p03-aim")
	for i in 6:
		await _press(&"shoot", 3)
		if GameState.has_flag(&"ch1_prologue_shot_done"):
			break
		await _frames(20)
	_check(await _wait_flag(&"ch1_prologue_shot_done", 120), "a real shot hits the low target")
	if _stop_if(&"ch1_prologue_shot_done"):
		return
	await _finish_story()
	# P04：橡膠靶近戰、訓練器格擋（先被打停一次，再舉盾擋下）、衝刺穿線。
	var area := _station(&"ch1_training_area")
	await _walk_to(area.global_position.x)
	await _finish_story("ST-16-p04-intro")
	var dummy := _station(&"ch1_training_dummy")
	await _walk_to(dummy.global_position.x - 22.0)
	_aim(Vector2.RIGHT)
	for i in 6:
		await _press(&"melee", 3)
		if GameState.has_flag(&"ch1_prologue_melee_done"):
			break
		await _frames(20)
	_check(await _wait_flag(&"ch1_prologue_melee_done", 120), "a real melee hit on the rubber dummy")
	if _stop_if(&"ch1_prologue_melee_done"):
		return
	await _finish_story()
	var trainer := _station(&"ch1_training_trainer")
	await _walk_to(trainer.global_position.x - 34.0)
	var health := _player().health.current
	for i in 300:
		if GameState.has_flag(&"ch1_prologue_fall_shown"):
			break
		if trainer._phase == &"warn" and i % 30 == 0:
			await _shot("ST-16-p04-trainer-warn")
		await _frames(1)
	_check(GameState.has_flag(&"ch1_prologue_fall_shown") and _player().health.current == health and GameState.deaths == deaths, "an unblocked strike stops the trainer without hurting or killing")
	await _finish_story("ST-16-p04-fall")
	_aim(Vector2.RIGHT)
	Input.action_press(&"block")
	_check(await _wait_flag(&"ch1_prologue_guard_done", 600), "holding block toward the trainer blocks its strike")
	if _stop_if(&"ch1_prologue_guard_done"):
		return
	Input.action_release(&"block")
	await _finish_story()
	var dash := _station(&"ch1_training_dash")
	await _walk_to(dash.global_position.x - 40.0)
	Input.action_press(&"move_right")
	await _frames(2)
	await _press(&"dash", 3)
	await _frames(20)
	Input.action_release(&"move_right")
	_check(await _wait_flag(&"ch1_prologue_dash_done", 120), "a real dash across the training line")
	if _stop_if(&"ch1_prologue_dash_done"):
		return
	await _finish_story()
	# P05→P06：回櫃台和老 K 說話兩次，從旁邊的門回店裡。
	var old_k := _npc(&"ch1_old_k_counter")
	_check(old_k.is_present() and not _npc(&"ch1_old_k_backyard").is_present(), "Old K is back at the counter after the dash")
	await _walk_to(old_k.global_position.x + 14.0)
	await _press(&"interact")
	await _finish_story("ST-16-p05-service")
	_check(GameState.has_flag(&"ch1_prologue_service_heard"), "Old K explains the recovery service")
	await _frames(70)
	await _press(&"interact")
	await _finish_story("ST-16-p06-call")
	_check(GameState.has_flag(&"ch1_prologue_exit"), "the wrap-up call hands over the exit")
	if _stop_if(&"ch1_prologue_exit"):
		return
	var exit: Portal = _level()._portals.get(&"prologue_exit")
	await _walk_to(exit.global_position.x)
	await _press(&"interact")
	deadline = Time.get_ticks_msec() + 120000
	while Time.get_ticks_msec() < deadline and not (_level() != null and _level().data.resource_path == "res://data/levels/ch1_pawnshop.tres" and _player() != null):
		await _frames(1)
	await _frames(150)
	await _shot("ST-16-pawnshop-arrival")
	_check(_level() != null and _level().data.resource_path == "res://data/levels/ch1_pawnshop.tres", "the prologue door leads into the pawnshop")
	_check(GameState.deaths == 0 and not GameState.has_flag(&"ch1_first_death_done"), "the prologue never counted a death or the first registration")
	var missing := PacingEstimate.PROLOGUE_PATH.filter(func(id: StringName) -> bool: return not _played.has(id))
	_check(missing.is_empty(), "the pacing path matches the scenes a real run plays (missing %s)" % [missing])
	if _failures == 0:
		if "--ch3-cold" in OS.get_cmdline_user_args():
			_check_chapter_three_entry()
		elif "--ch2-close" in OS.get_cmdline_user_args():
			await _chapter_two_close()
		elif "--ch2-yong" in OS.get_cmdline_user_args():
			await _chapter_two_yong()
		elif "--ch2-loading" in OS.get_cmdline_user_args():
			await _chapter_two_loading()
		elif "--ch2-market" in OS.get_cmdline_user_args():
			await _chapter_two_market()
		elif "--ch2-open" in OS.get_cmdline_user_args():
			await _chapter_two_open()
		elif "--vault-bridge" in OS.get_cmdline_user_args():
			await _chapter_one_vault_bridge()
		elif "--handoff" in OS.get_cmdline_user_args():
			await _chapter_one_handoff()
		elif "--upper-vault" in OS.get_cmdline_user_args():
			await _chapter_one_vault_exit()
		elif "--vault" in OS.get_cmdline_user_args():
			await _chapter_one_vault()
		elif "--raft" in OS.get_cmdline_user_args():
			await _chapter_one_raft()
		elif "--flood" in OS.get_cmdline_user_args():
			await _chapter_one_flood()
		elif "--warehouse" in OS.get_cmdline_user_args():
			await _chapter_one_warehouse()
		elif "--blockade" in OS.get_cmdline_user_args():
			await _chapter_one_blockade()
		elif "--street" in OS.get_cmdline_user_args():
			await _chapter_one_street()
		else:
			await _chapter_one_start()
	print("NE97_ROUTE %s deaths=%d failures=%d" % [_visits, GameState.deaths, _failures])
	print("PROLOGUE_PATH_PLAYED %s" % [_played])
	print("PROLOGUE_PLAY_PROBE failures=%d" % _failures)
	if not _save_dir.is_empty():
		_main.call("_quit", 1 if _failures > 0 else 0)
	else:
		get_tree().quit(1 if _failures > 0 else 0)


var _visits: Array[String] = []


func _chapter_one_start() -> void:
	print("NE97_JOYPADS ", Input.get_connected_joypads())
	_visits.append(_level().data.resource_path.get_file())
	await _walk_to(1378.0)
	for tick in 1200:
		if GameState.has_flag(&"ch1_dinner_done"):
			break
		await _frames(1)
	await _shot("ne97-dinner")
	if not _assert_route(GameState.has_flag(&"ch1_dinner_done"), "walked into the free dinner"):
		return
	if not await _route_portal(&"pawn_stairs"):
		return
	await _walk_to(210.0)
	await _route_jump(1, 30)
	await _walk_to(451.0)
	await _route_jump(1, 28)
	await _walk_to(54.0 * 16.0 - 14.0)
	await _press(&"interact")
	await _finish_story("ne97-rooftop-brief")
	if not _assert_route(GameState.has_flag(&"ch1_heard_brief"), "actually interacted with Egret on the rooftop"):
		return
	await _walk_to(508.0)
	await _route_jump(-1, 29)
	await _walk_to(277.0)
	await _route_jump(-1, 30)
	if not await _route_portal(&"roof_stairs"):
		return
	if not await _route_portal(&"pawn_front"):
		return
	await _walk_to(34.0 * 16.0 + 8.0)
	if not await _route_portal(&"street_booth"):
		return
	await _route_checkpoint()
	await _route_portal(&"booth_street")


func _assert_route(ok: bool, label: String) -> bool:
	var description := "no active player" if _player() == null else "%s at %s health=%d" % [_level().data.id, _player().global_position, _player().health.current]
	_check(ok, "NE97 %s [%s]" % [label, description])
	return ok


func _route_jump(direction: int, ticks: int) -> void:
	var move := &"move_right" if direction > 0 else &"move_left"
	Input.action_press(move)
	Input.action_press(&"jump")
	await _frames(ticks)
	Input.action_release(&"jump")
	Input.action_release(move)
	await _frames(12)


func _route_portal(id: StringName) -> bool:
	var current := _level()
	var portal: Portal = current._portals.get(id)
	if not _assert_route(portal != null, "found portal %s" % id):
		return false
	var destination := portal.data.target_level
	for tick in 1300:
		if _level() != current or _player() == null:
			break
		var dx := portal.global_position.x - _player().global_position.x
		if absf(dx) <= 6.0:
			break
		var movement := &"move_right" if dx > 0.0 else &"move_left"
		Input.action_press(movement)
		await _frames(1)
		Input.action_release(movement)
	if _level() == current and is_instance_valid(portal):
		await _press(&"interact")
	for tick in 2400:
		if _level() != null and _level().data.resource_path == destination and _player() != null:
			await _frames(30)
			await _finish_story()
			_visits.append(destination.get_file())
			await _shot("ne97-%s" % id)
			return _assert_route(true, "entered through %s" % id)
		await _frames(1)
	return _assert_route(false, "could not enter through %s" % id)


func _route_checkpoint() -> void:
	var booth := _level().find_children("*", "Checkpoint", true, false).front() as Checkpoint
	await _walk_to(booth.global_position.x)
	await _press(&"interact")
	for tick in 600:
		if Story._layer.is_radio_frozen():
			Story._layer.advance_radio()
		if GameState.has_flag(&"ch1_recording_heard"):
			break
		await _frames(1)
	_assert_route(GameState.has_flag(&"ch1_recording_heard"), "activated the authored checkpoint and finished its recording")


func _route_from_save() -> void:
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_main.set("_run_store", RunSaveStore.new(_save_dir.path_join("slot.json")))
	add_child(_main)
	for tick in 2400:
		var menu := _main.get("_screen") as MainMenu
		if menu != null and menu.is_inside_tree() and not _main.call("_route_pending") and menu._continue_button != null and menu._continue_button.has_focus():
			break
		await _frames(1)
	var menu := _main.get("_screen") as MainMenu
	if not _assert_route(menu != null and is_instance_valid(menu._continue_button) and menu.is_visible_in_tree(), "the real Continue button is available"):
		_main.call("_quit", 2)
		return
	await _frames(24)
	menu._continue_button.pressed.emit()
	for tick in 2400:
		if _player() != null:
			break
		await _frames(1)
	if _assert_route(_player() != null, "continued from the actual earlier main slot"):
		await _frames(30)
		if "--ch3-cold" in OS.get_cmdline_user_args():
			_check_chapter_three_entry()
		elif "--ch2-close" in OS.get_cmdline_user_args():
			await _chapter_two_close()
		elif "--ch2-yong" in OS.get_cmdline_user_args():
			await _chapter_two_yong()
		elif "--ch2-loading" in OS.get_cmdline_user_args():
			await _chapter_two_loading()
		elif "--ch2-market" in OS.get_cmdline_user_args():
			await _chapter_two_market()
		elif "--ch2-open" in OS.get_cmdline_user_args():
			await _chapter_two_open()
		elif "--vault-bridge" in OS.get_cmdline_user_args():
			await _chapter_one_vault_bridge()
		elif "--handoff" in OS.get_cmdline_user_args():
			await _chapter_one_handoff()
		elif "--upper-vault" in OS.get_cmdline_user_args():
			await _chapter_one_vault_exit()
		elif "--vault" in OS.get_cmdline_user_args():
			await _chapter_one_vault()
		elif "--raft" in OS.get_cmdline_user_args():
			await _chapter_one_raft()
		elif "--flood" in OS.get_cmdline_user_args():
			await _chapter_one_flood()
		elif "--warehouse" in OS.get_cmdline_user_args():
			await _chapter_one_warehouse()
		elif "--blockade" in OS.get_cmdline_user_args():
			await _chapter_one_blockade()
		elif "--street" in OS.get_cmdline_user_args():
			await _chapter_one_street()
		else:
			await _chapter_one_start()
	print("NE97_ROUTE %s deaths=%d failures=%d" % [_visits, GameState.deaths, _failures])
	_main.call("_quit", 1 if _failures > 0 else 0)


func _chapter_one_street() -> void:
	if not _assert_route(_level().data.id == &"ch1_street", "continued on the actual street"):
		return
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	_aim(Vector2.RIGHT)
	_accept_radio = true
	for step in [[42.75, 46.4], [46.6, 51.9], [51.9, 55.2], [55.2, 59.9]]:
		await _walk_to(step[0] * 16.0, 5.0)
		print("NE97_STREET_JUMP_FROM ", _player().global_position, " grounded=", _player().is_on_floor())
		await _fight_jump(step[1] * 16.0)
		print("NE97_STREET_STEP ", step, " at ", _player().global_position, " hp=", _player().health.current)
	if not _assert_route(_player().global_position.y < 610.0, "climbed the street terraces using jump and movement"):
		return
	await _shot("ne97-street-approach")
	if "--landmark-only" in OS.get_cmdline_user_args():
		_assert_route(_radio_captured and GameState.has_flag(&"ch1_dinner_done") and GameState.has_flag(&"ch1_heard_brief"),
			"started and cleared the frozen street call using Accept and reached the first encounter approach")
		return
	await _fight_jump(68.3 * 16.0, true)
	if not _assert_route(_player().global_position.y < 520.0, "reached the occupied terrace by jumping onto the final ledge"):
		return
	for step in [71.0, 84.0, 104.0, 120.0, 137.0]:
		if not await _fight_step(step*16.0, 1200):
			return
	await _shot("ne97-street-plaza")
	print("NE97_STREET_PREBLOCKADE ", _player().global_position)


func _fight_jump(target_x: float, sprint := false, double_jump := false) -> void:
	var player := _player()
	var direction := &"move_right" if target_x >= player.global_position.x else &"move_left"
	Input.action_press(direction)
	Input.action_press(&"jump")
	var passed := false
	for tick in 190:
		if _player() != player:
			break
		if double_jump and tick == 32:
			Input.action_release(&"jump")
		elif double_jump and tick == 36:
			Input.action_press(&"jump")
		if sprint and tick == 30 and not player.is_on_floor():
			Input.action_press(&"dash")
		elif sprint and tick == 31:
			Input.action_release(&"dash")
		if not passed and (absf(player.global_position.x - target_x) < 6.0 or (sprint and player.global_position.x > target_x)):
			passed = true
			Input.action_release(direction)
		if not GameplayLock.is_locked() and tick >= 17 and player.is_on_floor():
			break
		await _frames(1)
	Input.action_release(direction)
	Input.action_release(&"jump")
	await _frames(4)


func _fight_step(target_x: float, ticks: int) -> bool:
	var player := _player()
	for tick in ticks:
		if _player() != player or player.is_dead():
			break
		var delta_x := target_x - player.global_position.x
		if target_x >= 160.0*16.0 and player.global_position.x > 149.0*16.0 and player.global_position.x < 152.0*16.0 and player.global_position.y > 610.0 and player.is_on_floor():
			await _fight_jump(156.0 * 16.0, true)
			continue
		if absf(delta_x) < 8.0:
			break
		var nearest: Enemy
		var best := 250.0 * 250.0
		var from := player.aim_origin()
		for node in get_tree().get_nodes_in_group(&"enemies"):
			var enemy := node as Enemy
			if enemy == null or enemy.is_dying():
				continue
			var to := enemy.hurtbox.center()
			var distance := from.distance_squared_to(to)
			if distance >= best:
				continue
			var ray := PhysicsRayQueryParameters2D.create(from, to, Layers.WORLD)
			if not player.get_world_2d().direct_space_state.intersect_ray(ray).is_empty():
				continue
			nearest = enemy
			best = distance
		if player.loadout.is_dry() and not player.loadout.is_reloading() and tick % 20 == 0:
			_send_action(&"reload")
		if player.health.current <= 4 and tick % 45 == 0 and player.consumables.count(&"med_injector") > 0:
			_send_action(&"use_item")
		var movement := &"move_right" if delta_x > 0.0 else &"move_left"
		if nearest != null:
			if tick % 60 == 0:
				print("NE97_COMBAT ", nearest.data.id, " hp=", nearest.health.current, " player=", player.global_position,
					" med=", player.health.current, " mag=", player.loadout.mag_in(player.loadout.active_slot), " locked=", GameplayLock.is_locked(),
					" enemy=", nearest.hurtbox.center(), " aim=", player.aim_dir, " muzzle=", player.muzzle_position())
			var center := nearest.hurtbox.center()
			_aim((center - player.muzzle_position()).normalized())
			if best < 45.0 * 45.0:
				var near_ledge := from.x < 68.0*16.0 or (from.x > 150.0*16.0 and from.x < 158.0*16.0)
				movement = &"move_right" if near_ledge or center.x < from.x else &"move_left"
				if tick % 25 == 0 and movement == &"move_right":
					Input.action_press(&"dash")
				if tick % 24 == 0:
					Input.action_press(&"melee")
				Input.action_release(&"shoot")
				Input.action_press(movement)
			else:
				Input.action_press(&"shoot")
		else:
			Input.action_release(&"shoot")
		if nearest == null or best > 136.0*136.0:
			Input.action_press(movement)
		await _frames(1)
		Input.action_release(movement)
		Input.action_release(&"melee")
		Input.action_release(&"dash")
	Input.action_release(&"shoot")
	return _assert_route(_player() == player and not player.is_dead() and absf(player.global_position.x-target_x) < 10.0, "combat walking reaches X %.1f" % target_x)


func _capture_route_radio() -> void:
	var player := _player()
	var queue: Array = Story._layer.get("_radio_queue")
	if player == null or queue.is_empty() or queue.front()["id"] != &"ch1_g06_lamp":
		return
	_radio_captured = true
	var row := {"has_lock": Story._layer.is_radio_frozen(), "scene": str(queue.front()["id"]),
		"has_floor": player.is_on_floor(), "px": player.global_position.x, "py": player.global_position.y,
		"vy": player.velocity.y, "hp": player.health.current, "deaths": GameState.deaths,
		"renderer": RenderingServer.get_current_rendering_method(), "adapter": RenderingServer.get_video_adapter_name()}
	print("NE97_RADIO ", JSON.stringify(row))
	if not _out.is_empty() and DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		var frame := preload("res://tools/viewport_capture.gd").image(get_viewport())
		_check(frame.save_png(_out.path_join("ne97-street-radio.png")) == OK, "saved the real first street radio frame")


func _chapter_one_blockade() -> void:
	if not _assert_route(_level().data.id == &"ch1_street", "continued before the actual blockade"):
		return
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	_aim(Vector2.RIGHT)
	_accept_radio = true
	await _walk_to(121.5 * 16.0, 7.0)
	await _frames(45)
	_send_action(&"use_item")
	await _frames(10)
	print("NE97_MED_ITEM ", _player().global_position, " health=", _player().health.current)
	for step in [[135.0, 139.3], [139.9, 145.0], [145.2, 150.1], [149.9, 154.3]]:
		if not await _fight_step(step[0] * 16.0, 850):
			return
		await _frames(8)
		print("NE97_BLOCKADE_FROM ", _player().global_position, " grounded=", _player().is_on_floor())
		await _fight_jump(step[1] * 16.0)
		print("NE97_BLOCKADE_STEP ", step, " at ", _player().global_position, " hp=", _player().health.current)
	if not _assert_route(_player().global_position.y < 601.0, "reached the street blockade from the lower road"):
		return
	await _shot("ne97-blockade-approach")
	for step in [160.0, 167.0, 177.0, 182.0, 190.0, 198.0, 204.0]:
		if not await _fight_step(step*16.0, 1250):
			return
	_assert_route(GameState.has_flag(&"ch1_street_route_open"), "the original wave clearance saved the street route open flag")
	await _route_portal(&"street_warehouse")


func _chapter_one_warehouse() -> void:
	if not _assert_route(_level().data.id == &"ch1_warehouse", "continued naturally from street into warehouse"):
		return
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	_aim(Vector2.RIGHT)
	_accept_radio = true
	await _walk_to(152.0, 7.0)
	_send_action(&"use_item")
	await _frames(10)
	for step in [[12.9, 17.1], [17.6, 24.0]]:
		if not await _fight_step(step[0] * 16.0, 850):
			return
		await _frames(6)
		await _fight_jump(step[1] * 16.0)
		print("NE97_WH_FRONT_STEP ", step, " at ", _player().global_position, " hp=", _player().health.current)
	for step in [30.0, 38.0, 45.0]:
		if not await _fight_step(step * 16.0, 1200):
			return
	await _frames(6)
	await _fight_jump(50.3*16.0)
	if not _assert_route(_player().global_position.x >= 46.0*16.0, "reached the watchdog forecourt over the freight containers"):
		return
	var dog: PatternBoss
	for node in get_tree().get_nodes_in_group(&"enemies"):
		if node is PatternBoss and node.data.id == &"watchdog":
			dog = node
	if not _assert_route(dog != null and not dog.is_dying(), "found the original Watchdog"):
		return
	await _watchdog_live(dog)


func _watchdog_live(dog: PatternBoss) -> void:
	var original_player := _player()
	var script: Script = load("C:/Users/stanl/Github/Nest-Egg/work/ne97-campaign-route-20261119/watchdog-driver.gd")
	var driver: Node = script.new()
	add_child(driver)
	driver.use_current_fight(_level(), dog)
	var phase := -1
	var motion := &""
	var hits := 0
	for tick in 12000:
		if _player() != original_player or original_player.is_dead() or not is_instance_valid(dog) or dog.is_dying():
			break
		if dog.phase != phase:
			phase = dog.phase
			await _shot("ne97-watchdog-phase-%d" % phase)
		if dog.fsm.current != motion:
			motion = dog.fsm.current
			if hits < 5 or tick % 300 < 8:
				print("NE97_WATCHDOG state=", motion, " move=", dog.current_move(), " hp=", dog.health.current, " player=", original_player.health.current)
				hits += 1
		if not GameplayLock.is_locked():
			if original_player.loadout.is_dry() and not original_player.loadout.is_reloading() and tick % 20 == 0:
				_send_action(&"reload")
			if original_player.health.current <= 4 and tick % 30 == 0 and original_player.consumables.count(&"med_injector") > 0:
				_send_action(&"use_item")
			driver.drive_frame()
		await _frames(1)
	driver.release_driver()
	driver.queue_free()
	if not _assert_route(_player() == original_player and not original_player.is_dead() and (not is_instance_valid(dog) or dog.is_dying()), "defeated the authored Watchdog with ordinary inputs"):
		return
	await _frames(120)
	_assert_route(GameState.has_flag(&"watchdog_defeated"), "the actual Watchdog channel opened and saved the isolation wall")
	await _shot("ne97-watchdog-gate-open")


func _chapter_one_flood() -> void:
	if not _assert_route(_level().data.id == &"ch1_warehouse" and GameState.has_flag(&"watchdog_defeated"), "cold Continue retained the original watchdog gate completion"):
		return
	_aim(Vector2.RIGHT)
	_accept_radio = true
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	var warehouse := _level()
	await _walk_to(77.5*16.0)
	await _press(&"interact")
	for tick in 750:
		if GameState.checkpoint_applies(warehouse.data.resource_path) and not _player().is_on_phone():
			break
		await _frames(1)
	if not _assert_route(GameState.checkpoint_applies(warehouse.data.resource_path), "actual phone call saves a new warehouse checkpoint"):
		return
	await _shot("ne97-warehouse-phone")
	if not await _flood_switch(&"ch1_switch_a"):
		return
	await _frames(12)
	var owners: Array[String] = []
	for lock in GameplayLock.get("_locks").values():
		var owner: Node = lock["owner"].get_ref()
		owners.append(str(owner.name) if is_instance_valid(owner) else "missing")
	print("NE240_SWITCH_CONFLICT ", JSON.stringify({"x":_player().global_position.x, "npc_scene":str(Story._current_cinematic),
		"in_pump_range":_npc(&"ch1_pump_service").interaction_available(), "locks":owners, "player_state":_player().state}))
	if "--overlap-only" in OS.get_cmdline_user_args():
		await _shot("ne240-after-gate-key")
		if "--expect-separated" in OS.get_cmdline_user_args():
			if not _assert_route(owners.is_empty() and not Story.is_cinematic_active() and not GameState.has_flag(&"ch1_pump_case_reset"),
				"one gate press left movement free and pump maintenance pending"):
				return
			var pump := _npc(&"ch1_pump_service")
			await _walk_to(pump.global_position.x, 5.0)
			await _press(&"interact")
			await _frames(18)
			_assert_route(Story._current_cinematic == &"ch1_t_pump_check" and not GameState.has_flag(&"ch1_pump_case_reset"),
				"a separate press at the pump opened its real optional maintenance")
			await _shot("ne240-separate-pump-key")
		return
	if not await _flood_high_ledge():
		return
	if not await _flood_switch(&"ch1_switch_b"):
		return
	if not await _fight_step(116.0*16.0, 1550):
		return
	await _walk_to(123.5*16.0, 5.0)
	for tick in 2400:
		if _level() != warehouse and _player() != null:
			break
		if Story.is_cinematic_active():
			await _finish_story("ne97-first-registration")
		await _frames(2)
	if not _assert_route(GameState.has_flag(&"ch1_flood_gate_open") and GameState.deaths == 1 and _level() != warehouse and GameState.has_flag(&"ch1_first_death_done"),
		"actual flood plate fills, drowns once and the first-registration returns to the warehouse checkpoint"):
		return
	await _shot("ne97-warehouse-flood-return")


func _flood_switch(id: StringName) -> bool:
	for node in get_tree().get_nodes_in_group(WorldState.GROUP):
		if node is MechanismSwitch and node.data.id == id:
			await _walk_to(node.global_position.x, 5.0)
			await _press(&"interact")
			return _assert_route(node.active, "ordinary interaction opened %s" % id)
	return _assert_route(false, "could not find %s" % id)


func _flood_high_ledge() -> bool:
	for step in [[96.8, 99.5], [99.6, 102.5], [102.6, 107.1]]:
		if not await _fight_step(step[0]*16.0, 950):
			return false
		await _frames(8)
		await _fight_jump(step[1]*16.0)
		print("NE97_FLOOD_LEDGE ", step, " at ", _player().global_position, " hp=", _player().health.current)
	return _assert_route(_player().global_position.y < 698.0, "reached the raised switch platform by normal jumping")


func _chapter_one_raft() -> void:
	if not _assert_route(_level().data.id == &"ch1_warehouse" and GameState.has_flag(&"ch1_flood_gate_open") and GameState.deaths == 1,
		"cold Continue preserves the real flooded raft and first death"):
		return
	_aim(Vector2.RIGHT)
	_accept_radio = true
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: print("NE97_KILL ", id))
	if not await _flood_high_ledge():
		return
	if not await _fight_step(120.0*16.0, 1600):
		return
	await _frames(48)
	if not _assert_route(_player().is_on_floor() and absf(_player().global_position.y - 784.0) < 8.0,
		"stood on the real one-way raft over the flooded pit"):
		return
	await _shot("ne97-flooded-raft")
	if not await _fight_step(136.4*16.0, 1650):
		return
	for step in [[140.0,45], [145.3,41], [140.4,37], [145.3,33], [140.4,29], [145.3,25], [140.4,21], [146.0,17]]:
		_aim(Vector2(signf(step[0]*16.0 - _player().global_position.x), 0.0))
		await _fight_jump(step[0]*16.0)
		if not _assert_route(absf(_player().global_position.y - step[1]*16.0) < 8.0, "landed on the real warehouse stair platform at row %d" % step[1]):
			return
	await _route_portal(&"wh_vault")


func _chapter_one_vault() -> void:
	if not _assert_route(_level().data.id == &"ch1_vault" and not _player().has_air_jump(), "continued before the vault with the usual single jump"):
		return
	_aim(Vector2.RIGHT)
	_accept_radio = true
	var kills: Array[StringName] = []
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void:
		kills.append(id)
		print("NE97_KILL ", id))
	await _walk_to(7.5*16.0)
	await _press(&"interact")
	for tick in 750:
		if GameState.checkpoint_applies(_level().data.resource_path) and not _player().is_on_phone():
			break
		await _frames(1)
	if not _assert_route(GameState.checkpoint_applies(_level().data.resource_path), "saved at the real vault phone"):
		return
	for step in [[11.0,45], [16.0,41], [12.0,37], [17.0,33]]:
		_aim(Vector2(signf(step[0]*16.0 - _player().global_position.x), 0.0))
		await _fight_jump(step[0]*16.0)
		if not _assert_route(absf(_player().global_position.y - step[1]*16.0) < 8.0, "landed on real vault side platform row %d" % step[1]):
			return
	if not await _fight_step(24.0*16.0, 1150):
		return
	await _fight_jump(29.8*16.0)
	if not _assert_route(_player().global_position.y < 472.0, "reached the vault combat shelf"):
		return
	for tile in [32.0,38.0,41.0,47.0]:
		if not await _fight_step(tile*16.0, 1750):
			return
	await _chapter_one_vault_exit()


func _chapter_one_vault_exit() -> void:
	if not _assert_route(_level().data.id == &"ch1_vault" and StoryItems.holds(&"ch1_data_disk") and _player().has_air_jump(),
		"the actual vault disk pickup is held and grants the air jump"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	await _shot("ne97-vault-disk")
	await _walk_to(49.0*16.0, 5.0)
	await _frames(18)
	await _fight_jump(52.8*16.0)
	if not _assert_route(absf(_player().global_position.y - 400.0) < 8.0, "reached the vault double jump takeoff ledge"):
		return
	await _fight_jump(54.0*16.0, false, true)
	if not _assert_route(absf(_player().global_position.y - 288.0) < 8.0, "the real air jump climbs the 112-pixel vault step"):
		return
	await _shot("ne97-vault-air-jump-landing")
	await _fight_jump(61.5*16.0, false, true)
	if not _assert_route(absf(_player().global_position.y - 272.0) < 8.0, "cleared the central vault column"):
		return
	await _chapter_one_vault_bridge()


func _chapter_one_vault_bridge() -> void:
	_accept_radio = true
	_aim(Vector2.RIGHT)
	if _player().consumables.count(&"med_injector") > 0 and _player().health.current <= 4:
		_send_action(&"use_item")
		await _frames(10)
	await _fight_jump(68.1*16.0, true, true)
	if not _assert_route(absf(_player().global_position.y - 208.0) < 8.0, "landed on the vault upper walkway"):
		return
	for tile in [72.0,84.0,96.0,109.0]:
		if not await _fight_step(tile*16.0, 1450):
			return
	await _fight_jump(116.0*16.0)
	await _route_portal(&"wh_upper")


func _chapter_one_handoff() -> void:
	if not _assert_route(_level().data.id == &"ch1_handoff" and StoryItems.holds(&"ch1_data_disk"), "entered handoff with the genuine recovered disk"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	if not await _input_talk(&"ch1_handoff_cabinet", ["deliver"], func() -> bool: return StoryItems.was_transferred(&"ch1_data_disk")):
		return
	if not await _input_talk(&"ch1_handoff_cabinet", ["take"], func() -> bool: return StoryItems.holds(&"ch1_delivery_receipt")):
		return
	if not await _input_talk(&"ch1_handoff_cabinet", ["save"], func() -> bool: return GameState.has_flag(&"ch1_handoff_done")):
		return
	if not _assert_route(StoryItems.holds(&"ch1_market_summary") and not StoryItems.holds(&"ch1_data_disk"), "the real cabinet kept custody and issued the receipt and summary"):
		return
	await _shot("ne97-handoff-receipt")
	if not await _route_portal(&"handoff_lounge"):
		return
	if not await _input_talk(&"ch1_ali_lounge", ["order"], func() -> bool: return GameState.has_flag(&"ch1_met_ali")):
		return
	if not await _input_talk(&"ch1_ali_lounge", ["evening"], func() -> bool: return GameState.has_flag(&"ch1_lounge_evening_done")):
		return
	if not await _route_portal(&"lounge_exit"):
		return
	if not await _input_talk(&"ch1_ali_stall", ["stay", "accept"], func() -> bool: return GameState.has_flag(&"ch1_supper_done")):
		return
	await _shot("ne97-ch1-supper")
	if not await _route_portal(&"stall_home"):
		return
	for tick in 3400:
		if _level() != null and _level().data.id == &"ch2_pawnshop" and _player() != null:
			break
		if Story.is_cinematic_active():
			await _finish_story()
		await _frames(1)
	if not _assert_route(_level() != null and _level().data.id == &"ch2_pawnshop" and GameState.has_flag(&"ch1_complete"),
		"normal chapter ending transferred to the real chapter 2 pawnshop"):
		return
	await _shot("ne97-ch2-campaign-entry")


func _input_talk(id: StringName, choices: Array, completed: Callable, offset := -12.0) -> bool:
	var actor := _npc(id)
	if not _assert_route(actor != null and actor.is_present(), "found real conversation target %s" % id):
		return false
	await _walk_to(actor.global_position.x + offset, 5.0)
	for tick in 180:
		if actor.interaction_available() and not GameplayLock.is_locked():
			break
		await _frames(1)
	if not _assert_route(actor.interaction_available(), "the real interaction is ready after its cooldown"):
		return false
	await _press(&"interact")
	var pending := choices.duplicate()
	var saw_scene := false
	for tick in 4450:
		if completed.call() and pending.is_empty() and not Story.is_cinematic_active():
			break
		if Story.is_cinematic_active():
			if not saw_scene:
				saw_scene = true
				print("NE97_REAL_TALK ", id, " ", Story._current_cinematic)
			var cutscene: CutscenePlayer = Story._player
			if cutscene != null and cutscene.choice_active():
				var wanted: String = pending.front() if not pending.is_empty() else str(cutscene._choice_step.get("default", ""))
				var index := cutscene._choice_options.find_custom(func(option: Dictionary) -> bool: return str(option.get("id", "")) == wanted)
				if not _assert_route(index >= 0, "%s offers real choice %s" % [id,wanted]):
					return false
				if not pending.is_empty():
					pending.pop_front()
				cutscene.choose(index)
			elif tick % 8 == 0:
				_send_action(&"ui_accept")
		await _frames(1)
	return _assert_route(saw_scene and pending.is_empty() and completed.call(), "completed the real interaction at %s" % id)


func _chapter_two_open() -> void:
	if not _assert_route(_level().data.id == &"ch2_pawnshop" and GameState.has_flag(&"ch1_complete") and StoryItems.was_transferred(&"ch1_data_disk")
		and StoryItems.holds(&"ch1_delivery_receipt") and StoryItems.holds(&"ch1_market_summary") and GameState.deaths == 1,
		"cold Chapter 2 Continue retains actual Chapter 1 completion, custody, receipt, summary and puzzle death"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	await _finish_story("ne97-ch2-morning")
	var wallet := Progression.credits
	if not await _input_talk(&"ch2_old_k", ["settle"], func() -> bool: return GameState.has_flag(&"ch2_morning_settled")):
		return
	if not _assert_route(Progression.credits == wallet+720, "the formal morning settlement adds 720 credits once"):
		return
	if not await _input_talk(&"ch2_radio", ["antenna","power","antenna","speaker","middle","save"],
		func() -> bool: return GameState.has_flag(&"ch2_radio_repaired") and StoryItems.holds(&"ch2_radio_clip")):
		return
	await _shot("ne97-ch2-radio-repaired")
	if not await _route_portal(&"pawn_stairs"):
		return
	await _walk_to(210.0)
	await _route_jump(1, 30)
	await _walk_to(451.0)
	await _route_jump(1, 28)
	if not await _input_talk(&"ch2_egret", [], func() -> bool: return GameState.has_flag(&"ch2_brief_done") and StoryItems.holds(&"ch2_check_card")):
		return
	await _walk_to(508.0)
	await _route_jump(-1, 29)
	await _walk_to(277.0)
	await _route_jump(-1, 30)
	if not await _route_portal(&"roof_stairs") or not await _route_portal(&"pawn_front") or not await _route_portal(&"street_market"):
		return
	if not await _input_talk(&"ch2_patroller", [], func() -> bool: return GameState.has_flag(&"ch2_gate_checked")):
		return
	await _shot("ne97-ch2-market-arrival")


func _chapter_two_market() -> void:
	if not _assert_route(_level().data.id == &"ch2_market_gate" and GameState.has_flag(&"ch2_gate_checked"), "continued after the original market gate check"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	var kills: Array[StringName] = []
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void:
		kills.append(id)
		print("NE97_KILL ", id))
	for tile in [32.0,44.0,57.0,70.0,83.0,94.5]:
		if not await _fight_step(tile*16.0, 1750):
			return
	_assert_route(kills.has(&"ch2_escort") and kills.has(&"ch2_bill_thrower"),"ground route fights and defeats both unique chapter two enemy types")
	var booth := _level().find_children("*", "Checkpoint", true, false).front() as Checkpoint
	await _walk_to(booth.global_position.x)
	await _press(&"interact")
	for tick in 750:
		if GameState.checkpoint_applies(_level().data.resource_path) and not _player().is_on_phone():
			break
		await _frames(1)
	if not _assert_route(GameState.checkpoint_applies(_level().data.resource_path), "real entrance booth saves the market checkpoint"):
		return
	await _shot("ne97-market-b3-after-ground-fights")
	if not await _route_portal(&"gate_market"):
		return
	if not await _input_talk(&"ch2_vig", ["ask"], func() -> bool: return GameState.has_flag(&"ch2_market_contact_done") and StoryItems.holds(&"ch2_evidence_receipt")):
		return
	if not await _input_talk(&"ch2_rent_window", [], func() -> bool: return StoryItems.holds(&"ch2_evidence_contract")):
		return
	await _shot("ne97-ch2-market-contract")


func _chapter_two_loading() -> void:
	if not _assert_route(_level().data.id == &"ch2_market" and StoryItems.holds(&"ch2_evidence_receipt") and StoryItems.holds(&"ch2_evidence_contract"),
		"the real market stop kept receipt and contract"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	if not await _route_portal(&"market_stairs"):
		return
	if not await _input_talk(&"ch2_ali_home", ["wash","right","left"], func() -> bool: return GameState.has_flag(&"sq1_soup_practice_done")):
		return
	await _shot("ne97-ch2-ali-kitchen")
	if not await _route_portal(&"home_roof"):
		return
	if not _assert_route(_player().global_position.y < 390.0, "Ali's rear window exits onto the real market awning"):
		return
	if not await _route_portal(&"market_canopy"):
		return
	if not _assert_route(_player().global_position.y < 475.0, "the upper canopy drops onto the loading bypass over the ground fights"):
		return
	await _shot("ne97-ch2-loading-upper-bypass")
	if not await _input_talk(&"ch2_sc1_lever", [], func() -> bool: return GameState.has_flag(&"ch2_sc1_open")):
		return
	if not await _input_talk(&"ch2_collection_book", [], func() -> bool: return StoryItems.holds(&"ch2_evidence_collection")):
		return
	if not await _input_talk(&"ch2_drying_desk", ["total","principal","contract","collection","north"],
		func() -> bool: return GameState.has_flag(&"ch2_market_reconciled")):
		return
	await _shot("ne97-ch2-desk-correct")
	await _route_portal(&"loading_ledger")


func _chapter_two_yong() -> void:
	if not _assert_route(_level().data.id == &"ch2_ledger_front" and GameState.has_flag(&"ch2_market_reconciled"), "the actual three papers reconcile and unlock the ledger forecourt"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	var level := _level()
	var booth := level.find_children("*", "Checkpoint", true, false).front() as Checkpoint
	await _walk_to(booth.global_position.x)
	await _press(&"interact")
	for tick in 750:
		if GameState.checkpoint_applies(level.data.resource_path) and not _player().is_on_phone():
			break
		await _frames(1)
	if not _assert_route(GameState.checkpoint_applies(level.data.resource_path), "actual ledger forecourt booth saves the checkpoint"):
		return
	if not await _input_talk(&"ch2_ledger_door", [], func() -> bool: return GameState.has_flag(&"ch2_yong_intro_seen")):
		return
	if not await _route_portal(&"front_office"):
		return
	var yong: PatternBoss
	for node in get_tree().get_nodes_in_group(&"enemies"):
		if node is PatternBoss and node.data.id == &"yong":
			yong = node
	if not _assert_route(yong != null and yong.health.current == 100 and _player().health.max_health == 6, "real Yong starts with active 100 HP against the normal player health and pistol"):
		return
	await _yong_live(yong)


func _yong_live(yong: PatternBoss) -> void:
	var original_player := _player()
	var script: Script = load("C:/Users/stanl/Github/Nest-Egg/work/ne97-campaign-route-20261119/yong-driver.gd")
	var driver: Node = script.new()
	add_child(driver)
	driver.use_current_fight(_level(), yong)
	var stage := ""
	var disarmed := false
	for tick in 14500:
		if _player() != original_player or original_player.is_dead() or not is_instance_valid(yong) or yong.call(&"is_subdued"):
			break
		if str(yong.get("stage")) != stage:
			stage = str(yong.get("stage"))
			print("NE97_YONG stage=", stage, " hp=", yong.health.current, " player=", original_player.health.current)
			await _shot("ne97-yong-stage-%s" % stage)
		if not disarmed and yong.call(&"is_disarmed"):
			disarmed = true
			await _shot("ne97-yong-real-disarm")
		if Story.is_cinematic_active():
			var cutscene: CutscenePlayer = Story._player
			if cutscene != null and cutscene.choice_active():
				var id := "cut" if Story._current_cinematic == &"ch2_t_s12_choice" else str(cutscene._choice_step.get("default", ""))
				var index := cutscene._choice_options.find_custom(func(option: Dictionary) -> bool: return str(option.get("id", "")) == id)
				if index >= 0:
					print("NE97_YONG choice=", id)
					cutscene.choose(index)
			elif tick % 8 == 0:
				_send_action(&"ui_accept")
		elif not GameplayLock.is_locked():
			if original_player.loadout.is_dry() and not original_player.loadout.is_reloading() and tick % 15 == 0:
				_send_action(&"reload")
			if original_player.health.current <= 4 and tick % 30 == 0 and original_player.consumables.count(&"med_injector") > 0:
				_send_action(&"use_item")
			driver.drive_frame()
		await _frames(1)
	driver.release_driver()
	driver.queue_free()
	if not _assert_route(_player() == original_player and not original_player.is_dead() and is_instance_valid(yong) and yong.call(&"is_subdued"),
		"normal health run subdues the authored Yong with the original combat and hold interactions"):
		return
	await _frames(40)
	_assert_route(GameState.has_flag(&"ch2_yong_subdued") and GameState.has_flag(&"yong_link_revoked") and disarmed,
		"the original lock parts, isolation and power-cell owner publish the real cut-route result")
	await _shot("ne97-yong-subdued-and-saved")


func _chapter_two_close() -> void:
	if not _assert_route(_level().data.id == &"ch2_ledger_office" and GameState.has_flag(&"ch2_yong_subdued"), "the actual Yong subdued outcome is in the current whole-run save"):
		return
	_accept_radio = true
	_aim(Vector2.RIGHT)
	var wallet := Progression.credits
	if not await _input_talk(&"ch2_ledger_cabinet", [], func() -> bool: return StoryItems.holds(&"ch2_original_ledger") and GameState.has_flag(&"ch2_egret_transport_done")):
		return
	if not _assert_route(Progression.credits == wallet + 120 and StoryItems.holds(&"ch2_clinic_index") and StoryItems.holds(&"ch2_ali_page"),
		"the original ledger cabinet publishes its one-time 120 payout and the evidence"):
		return
	if not await _route_portal(&"office_family"):
		return
	var restored := func() -> bool: return GameState.has_flag(&"ch2_egret_returned") and int(GameState.get_flag(&"egret_restoration_count")) == 214
	if not await _input_talk(&"ch2_egret_booth", [], restored, 12.0):
		return
	await _shot("ne97-ch2-egret-214")
	if not await _route_portal(&"gate_lounge"):
		return
	wallet = Progression.credits
	if not await _input_talk(&"ch2_terminal", [], func() -> bool: return GameState.has_flag(&"ch2_audit_submitted")):
		return
	if not _assert_route(Progression.credits == wallet + 250, "the real terminal posts the once-only 250 audit award"):
		return
	if not await _input_talk(&"ch2_ali_lounge", ["correct"], func() -> bool: return str(GameState.get_flag(&"ali_ledger_action")) == "correct" and not StoryItems.holds(&"ch2_ali_page")):
		return
	await _shot("ne97-ch2-audit-submitted")
	if not await _route_portal(&"lounge_gate") or not await _route_portal(&"gate_street") or not await _route_portal(&"street_home") or not await _route_portal(&"pawn_stairs"):
		return
	await _walk_to(210.0)
	await _route_jump(1, 30)
	await _walk_to(451.0)
	await _route_jump(1, 28)
	if not await _input_talk(&"ch2_egret", ["go"], func() -> bool: return GameState.has_flag(&"ch2_heron_closed")):
		return
	for tick in 3000:
		if _level() != null and _level().data.id == &"ch3_pawnshop" and _player() != null:
			break
		if Story.is_cinematic_active():
			await _finish_story()
		await _frames(1)
	if not _assert_route(_level() != null and _level().data.id == &"ch3_pawnshop" and GameState.has_flag(&"ch2_heron_closed"), "Chapter 2 naturally ends and saves the original Chapter 3 pawnshop"):
		return
	await _frames(40)
	await _shot("ne97-ch3-campaign-entry")


func _check_chapter_three_entry() -> void:
	_assert_route(_level().data.id == &"ch3_pawnshop" and GameState.has_flag(&"ch1_complete") and GameState.has_flag(&"ch2_heron_closed"),
		"a cold Main really continued at the official Chapter 3 pawnshop after both closures")
	_assert_route(GameState.deaths == 1 and _player().health.current == 6 and int(GameState.get_flag(&"egret_restoration_count")) == 214,
		"chapter handoff preserves standard-health, one flood death and Egret's exact 214 count")
	_assert_route(GameState.has_flag(&"ch2_yong_subdued") and GameState.has_flag(&"yong_link_revoked") and GameState.has_flag(&"ch2_audit_submitted"),
		"the original boss, cut route and audit survive cold Continue together")
