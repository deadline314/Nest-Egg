extends "C:/Users/stanl/Github/Nest-Egg/work/ne97-campaign-route-20261119/combat-route.gd"

var _office_trace_seen: Dictionary = {}
var _office_last_step := ""
var _office_step_at := 0
var _office_probe_skipped := false


func _trace_office_source() -> void:
	var player: CutscenePlayer = Story._player
	if is_instance_valid(player) and String(player.scene_id).begins_with("ch3_t_c20"):
		var step: String = player.get("_current_where")
		if step != _office_last_step:
			_office_last_step = step
			_office_step_at = Engine.get_physics_frames()
			print("NE97_OFFICE_STEP ", step, " physics=", Engine.get_physics_frames(), " process=", Engine.get_process_frames())
		if step.begins_with("場景 ch3_t_c20_rest 第 29 步") and not _office_probe_skipped and Engine.get_physics_frames() - _office_step_at > 120:
			var actors: Dictionary = player.get("_actors")
			for id in [&"old_k", &"rin"]:
				var actor := actors.get(id) as CutsceneActor
				if actor != null:
					var motion := actor.rig.animator as NpcAnimator
					print("NE97_OFFICE_MOVE_GATE ", JSON.stringify({"actor": id, "pose": actor.pose, "y": actor.position.y,
						"ground": actor.ground_y, "ready": player.call(&"_standing_ready", actor), "can_process": actor.can_process(),
						"posture_active": motion.posture_active(), "stand_ready": motion.posture_ready(&"stand")}))
			_office_probe_skipped = true
			if "--office-step-skip" in OS.get_cmdline_user_args():
				Story.skip_cinematic()
	if Story._current_cinematic not in [&"ch3_t_c18_box", &"ch3_t_c19_watch"]:
		return
	var segment: StringName = Story._current_cinematic
	var request := Story.current_presentation_request()
	if _office_trace_seen.has(segment):
		return
	_office_trace_seen[segment] = true
	var context := Story.presentation_context_for_request(segment, request)
	var actor := _npc(&"ch3_petition_box")
	print("NE97_OFFICE_SOURCE ", JSON.stringify({"scene": segment, "context": context, "actor_key": actor.state_key(),
		"live_talking": actor.get("_talking"), "actor_index": actor.get("_presentation_index"), "entry": actor.data.talks[0].scene,
		"current_dispatch": Story.resolve_dispatch(actor.data.talks[0].scene), "entry_completed": Story._completed.has(&"ch3_t_c18_box"),
		"receipt_received": GameState.has_flag(&"ch3_petition_receipt_taken"), "admitted": Story.is_npc_presentation(actor.data, 0, segment)}))


func _route_from_save() -> void:
	if "--trace-office-source" in OS.get_cmdline_user_args():
		get_tree().process_frame.connect(_trace_office_source)
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_main.set("_run_store", RunSaveStore.new(_save_dir.path_join("slot.json")))
	add_child(_main)
	var menu: MainMenu
	for tick in 2400:
		menu = _main.get("_screen") as MainMenu
		if menu != null and menu.is_inside_tree() and not _main.call("_route_pending") and menu._continue_button != null and menu._continue_button.has_focus():
			break
		await _frames(1)
	if not _assert_route(menu != null and menu.is_visible_in_tree() and is_instance_valid(menu._continue_button), "the original Continue button is available"):
		_main.call("_quit", 2)
		return
	await _frames(24)
	menu._continue_button.pressed.emit()
	if "--ch3-ended" in OS.get_cmdline_user_args():
		await _chapter_three_cold_ending()
		_main.call("_quit", 1 if _failures > 0 else 0)
		return
	for tick in 2400:
		if _player() != null:
			break
		await _frames(1)
	if _assert_route(_player() != null, "continued the genuine campaign slot"):
		await _frames(30)
		if "--ch3-office-recovery" in OS.get_cmdline_user_args():
			await _chapter_three_office_recovery()
		elif "--ch3-office-first" in OS.get_cmdline_user_args():
			await _chapter_three_office_first()
		elif "--ch3-office-last" in OS.get_cmdline_user_args():
			await _chapter_three_office_last()
		elif "--ch3-ending" in OS.get_cmdline_user_args():
			await _chapter_three_ending()
		elif "--ch3-showroom" in OS.get_cmdline_user_args():
			await _chapter_three_showroom()
		elif "--ch3-aftercare" in OS.get_cmdline_user_args():
			await _chapter_three_aftercare()
		elif "--ch3-janus" in OS.get_cmdline_user_args():
			await _chapter_three_janus()
		elif "--ch3-clinic" in OS.get_cmdline_user_args():
			await _chapter_three_clinic()
		elif "--ch3-freight" in OS.get_cmdline_user_args():
			await _chapter_three_freight()
		elif "--ch3-pump" in OS.get_cmdline_user_args():
			await _chapter_three_pump()
		else:
			await _chapter_three_departure()
	print("NE97_CH3_ROUTE %s deaths=%d failures=%d" % [_visits, GameState.deaths, _failures])
	_main.call("_quit", 1 if _failures > 0 else 0)


func _chapter_three_departure() -> void:
	if not _assert_route(_level().data.id == &"ch3_pawnshop" and GameState.has_flag(&"ch2_heron_closed")
			and StoryItems.holds(&"ch2_clinic_index") and GameState.get_flag(&"yong_link_choice") == "cut"
			and _player().health.current == 6 and GameState.deaths == 1,
			"Chapter 3 opens with the real clinic index, cut record, six health and one prior flood death"):
		return
	if not await _input_talk(&"ch3_old_k", ["ask", "go"], func() -> bool: return GameState.has_flag(&"ch3_departure_done")):
		return
	await _shot("ne97-ch3-breakfast-departure")
	if not await _route_portal(&"pawn_front"):
		return
	if not await _input_talk(&"ch3_control_box", [], func() -> bool: return GameState.has_flag(&"ch3_interlock_seen")):
		return
	if not _assert_route(not GameState.has_flag(&"ch3_freight_ready"), "the actual control box explains the water safety interlock before enabling the lift"):
		return
	await _shot("ne97-ch3-lift-interlock")
	if not await _route_portal(&"plaza_pump"):
		return
	_assert_route(_level().data.id == &"ch3_pump" and not GameState.has_flag(&"ch3_pump_low"), "entered the original pump room before draining the tank")


func _chapter_three_pump() -> void:
	if not _assert_route(_level().data.id == &"ch3_pump" and not GameState.has_flag(&"ch3_pump_low"),
			"resumed inside the actual flooded pump room"):
		return
	var kills: Array[StringName] = []
	EventBus.enemy_killed.connect(func(id: StringName, _finisher: bool) -> void: kills.append(id))
	await _walk_to(7.1 * 16.0, 3.0)
	await _fight_jump(9.3 * 16.0)
	if not _assert_route(absf(_player().global_position.y - 528.0) < 0.25 and _player().is_on_floor(), "first jump reaches the short entrance ledge"):
		return
	await _fight_jump(13.6 * 16.0)
	if not _assert_route(absf(_player().global_position.y - 464.0) < 0.25 and _player().is_on_floor(), "second jump reaches the dry upper walk without entering combat"):
		return
	var health_before := _player().health.current
	if not await _input_talk(&"ch3_drain_wheel", ["back", "drain"], func() -> bool: return GameState.has_flag(&"ch3_pump_low")):
		return
	if not _assert_route(kills.is_empty() and _player().health.current == health_before, "the real dry bridge reaches the wheel without kills or damage"):
		return
	await _shot("ne97-ch3-drained-bridge")
	await _walk_to(62.0 * 16.0, 5.0)
	Input.action_press(&"move_down")
	await _press(&"jump")
	Input.action_release(&"move_down")
	for tick in 130:
		if _player().is_on_floor() and absf(_player().global_position.y - 576.0) < 0.25:
			break
		await _frames(1)
	if not _assert_route(_player().is_on_floor() and _player().global_position.y > 570.0, "down plus jump drops through the actual upper platform to the panel floor"):
		return
	if not await _fight_step(63.8 * 16.0, 540):
		return
	if not await _input_talk(&"ch3_branch_panel", ["main", "branch", "power"], func() -> bool: return GameState.has_flag(&"ch3_lift_powered")):
		return
	if not _assert_route(GameState.has_flag(&"ch3_wet_branch_isolated") and GameState.has_flag(&"ch3_lift_powered"),
			"the wet branch and lift power are both confirmed after the recoverable wrong choice"):
		return
	await _shot("ne97-ch3-pump-panel-complete")


func _chapter_three_freight() -> void:
	if not _assert_route(_level().data.id == &"ch3_pump" and GameState.has_flag(&"ch3_pump_low")
			and GameState.has_flag(&"ch3_wet_branch_isolated") and GameState.has_flag(&"ch3_lift_powered"),
			"the drained and powered pump room is restored from a cold continuation"):
		return
	EventBus.enemy_killed.connect(func(id: StringName, _finished: bool) -> void: print("NE97_CH3_KILL ", id))
	for position in [840.0, 650.0, 430.0, 200.0, 83.0]:
		if not await _fight_step(position, 660):
			return
	if not await _route_portal(&"pump_plaza"):
		return
	if not await _input_talk(&"ch3_control_box", [], func() -> bool: return GameState.has_flag(&"ch3_freight_ready")):
		return
	if not await _input_talk(&"ch3_outer_ladder", [], func() -> bool: return GameState.has_flag(&"ch3_outer_ladder_down")):
		return
	if not await _route_portal(&"plaza_ladder"):
		return
	if not _assert_route(_level().data.id == &"ch3_pump" and absf(_player().global_position.y - 464.0) < 0.25,
			"the outdoor ladder drops directly onto the original dry upper bridge"):
		return
	var return_ladder: Portal = _level()._portals.get(&"pump_ladder")
	await _walk_to(return_ladder.global_position.x - 66.0, 4.0)
	if not _assert_route(return_ladder.is_armed(), "walking off the arrival ladder re-arms the round trip"):
		return
	if not await _route_portal(&"pump_ladder"):
		return
	if not await _route_portal(&"plaza_lift"):
		return
	await _walk_to(15.5 * 16.0, 5.0)
	for tick in 720:
		if GameState.has_flag(&"ch3_mezzanine_reached"):
			break
		await _frames(1)
	_assert_route(_level().data.id == &"ch3_mezzanine" and GameState.has_flag(&"ch3_mezzanine_reached"),
			"the original lift carries the player up to the mezzanine")


func _chapter_three_clinic() -> void:
	if not _assert_route(_level().data.id == &"ch3_mezzanine" and GameState.has_flag(&"ch3_mezzanine_reached")
			and GameState.has_flag(&"ch3_outer_ladder_down"), "resumed at the real mezzanine after the outdoor ladder round trip"):
		return
	if not await _input_talk(&"ch3_notice_terminal", [], func() -> bool: return true):
		return
	await _walk_to(37.0 * 16.0, 4.0)
	await _fight_jump(39.5 * 16.0)
	if not _assert_route(_player().is_on_floor() and absf(_player().global_position.y - 528.0) < 0.25, "jumped to the first ledge into the care walkway"):
		return
	await _fight_jump(46.5 * 16.0)
	if not _assert_route(_player().is_on_floor() and absf(_player().global_position.y - 480.0) < 0.25, "reached the upper care walkway above both inspectors"):
		return
	await _shot("ne97-ch3-care-walkway")
	await _walk_to(57.0 * 16.0, 6.0)
	await _fight_jump(64.5 * 16.0, true)
	await _walk_to(70.0 * 16.0, 6.0)
	if not await _route_portal(&"mezz_clinic"):
		return
	if not await _input_talk(&"ch3_zhi", ["disease"], func() -> bool: return GameState.has_flag(&"ch3_clinic_access") and StoryItems.holds(&"ch3_review_slip")):
		return
	if not _assert_route(StoryItems.holds(&"ch2_clinic_index"), "the real public counter admits Rin while keeping the previous chapter's clinic index"):
		return
	if not await _input_talk(&"ch3_public_report", ["save"], func() -> bool: return StoryItems.holds(&"ch3_report_p17")):
		return
	if not await _input_talk(&"ch3_nursing_board", ["twentytwo", "eleven"], func() -> bool: return StoryItems.holds(&"ch3_roster_n17")):
		return
	if not await _input_talk(&"ch3_register_cabinet", ["ask", "save"], func() -> bool: return StoryItems.holds(&"ch3_register_t17")):
		return
	if not await _input_talk(&"ch3_deposit_drawer", ["play", "lend"], func() -> bool: return StoryItems.holds(&"ch3_ahan_tape")):
		return
	var credits := Progression.credits
	if not await _input_talk(&"ch3_reading_desk", ["ninetytwo", "hundred", "three", "eleven", "cured", "tracked"],
			func() -> bool: return GameState.has_flag(&"ch3_report_reconciled") and StoryItems.holds(&"ch3_mezz_pass")):
		return
	if not _assert_route(Progression.credits == credits + 180, "the answered objection pays exactly 180 credits and grants the real pass"):
		return
	await _shot("ne97-ch3-clinic-reconciled")
	await _route_portal(&"clinic_gate")


func _chapter_three_janus() -> void:
	if not _assert_route(_level().data.id == &"ch3_gate_hall" and StoryItems.holds(&"ch3_mezz_pass")
			and not GameState.has_flag(&"ch3_janus_disabled"), "the authentic clinic pass opens the original gate hall before the encounter"):
		return
	if not await _input_talk(&"ch3_scanner_gate", [], func() -> bool: return GameState.has_flag(&"ch3_janus_intro_seen")):
		return
	var boss: JanusBoss
	for enemy in get_tree().get_nodes_in_group(&"enemies"):
		if enemy is JanusBoss:
			boss = enemy
			break
	if not _assert_route(boss != null and boss.health.current == boss.health.max_health,
			"the original gatekeeper still has full work-frame stability after his introduction"):
		return
	var before_deaths := GameState.deaths
	var hit_parts := {}
	for part in boss.hurtbox.parts:
		var id: StringName = part.part_id
		part.hit_received.connect(func(_info: DamageInfo) -> void: hit_parts[id] = int(hit_parts.get(id, 0)) + 1)
	var moves := {}
	var player := _player()
	var minimum := player.health.current
	var previous := &""
	var jump_used := false
	var shield_reported := false
	_aim(Vector2.RIGHT)
	await _walk_to(boss.global_position.x - 131.0, 6.0)
	_accept_radio = true
	for tick in 12000:
		if not is_instance_valid(boss) or boss.halted or not is_instance_valid(player) or player.is_dead() or _player() != player:
			break
		minimum = mini(minimum, player.health.current)
		var state := boss.fsm.current
		var move := StringName(str(boss.get("_move_id")))
		var active := state == &"windup" or state == &"act"
		if move != &"" and state == &"windup" and previous != &"windup":
			moves[move] = int(moves.get(move, 0)) + 1
			jump_used = false
			print("NE97_JANUS_WINDUP ", tick, " ", move, " hp=", boss.health.current, " player_hp=", player.health.current,
				" shield_misses=", boss.shield_misses, " gap=", player.global_position.x - boss.global_position.x)
		previous = state
		var delta_x := boss.global_position.x - player.global_position.x
		var towards := signf(delta_x)
		var gap := absf(delta_x)
		var move_x := towards if gap > 141.0 else (-towards if gap < 119.0 else 0.0)
		if active and move == &"shield_bash" and gap < 133.0:
			move_x = -towards
		var front := towards == -float(boss.facing)
		var scan := active and String(move).begins_with("scan_") and front
		var high := scan and String(move).ends_with("high")
		if high:
			Input.action_press(&"move_down")
			move_x = 0.0
		else:
			Input.action_release(&"move_down")
		if scan and not high and not jump_used and player.is_on_floor() and (state == &"act" or float(boss.get("_telegraph_left")) < 0.16):
			_send_action(&"jump")
			jump_used = true
		if player.health.current <= 4 and tick % 45 == 0 and player.consumables.count(&"med_injector") > 0:
			_send_action(&"use_item")
		if player.loadout.is_dry() and not player.loadout.is_reloading() and tick % 20 == 0:
			_send_action(&"reload")
		if boss.shield_cracked and not shield_reported:
			shield_reported = true
			await _shot("ne97-ch3-janus-cracked-shield")
		var target := Vector2.INF
		for enemy in get_tree().get_nodes_in_group(&"enemies"):
			if enemy is not Enemy or enemy == boss or enemy.is_dying():
				continue
			if enemy.global_position.distance_to(player.global_position) < 132.0:
				target = enemy.hurtbox.center()
				break
		if not target.is_finite() and boss.shield_cracked:
			var part := &"shield_lock" if boss.is_part_open(&"shield_lock") else &"shield"
			target = boss.call(&"_part_point", part)
		if target.is_finite() and gap > 36.0:
			_aim((target - player.muzzle_position()).normalized())
			Input.action_press(&"shoot")
		else:
			_aim(Vector2(towards, 0.0))
			Input.action_release(&"shoot")
		if move_x != 0.0:
			Input.action_press(&"move_left" if move_x < 0 else &"move_right")
		await _frames(1)
		Input.action_release(&"move_left")
		Input.action_release(&"move_right")
	Input.action_release(&"shoot")
	Input.action_release(&"move_down")
	_accept_radio = false
	print("NE97_JANUS_RESULT ", JSON.stringify({"moves": moves, "hits": hit_parts, "shields_missed": boss.shield_misses,
		"stability": boss.health.current, "min_hp": minimum, "health": player.health.current, "retained_deaths": GameState.deaths}))
	if not _assert_route(boss.halted and not boss.pin_pulled and boss.shield_cracked and GameState.deaths == before_deaths,
			"ordinary gunfire disabled the real frame after three avoided shield charges, leaving its original pin attached"):
		return
	await _shot("ne97-ch3-janus-frame-stopped")
	var pin: Vector2 = boss.global_position + (boss.call(&"_pin_local") as Vector2)
	await _walk_to(pin.x - boss.facing * 14.0, 5.0)
	if not _assert_route(boss.pin_reachable(), "walked within reach of the original rear pin"):
		return
	await _press(&"interact")
	for tick in 300:
		if GameState.has_flag(&"ch3_janus_disabled"):
			break
		await _frames(1)
	_assert_route(GameState.has_flag(&"ch3_janus_disabled") and not GameState.has_flag(&"ch3_janus_aftercare_done"),
			"the pin input commits the shutdown before the aftercare encounter")


func _chapter_three_aftercare() -> void:
	if not _assert_route(_level().data.id == &"ch3_gate_hall" and GameState.has_flag(&"ch3_janus_disabled")
			and not GameState.has_flag(&"ch3_janus_aftercare_done") and GameState.get_flag(&"ch3_janus_device_stability") == 0,
			"the original pin result survives a cold start before aftercare"):
		return
	var credits := Progression.credits
	if not await _input_talk(&"ch3_gatekeeper", [], func() -> bool: return GameState.has_flag(&"ch3_janus_aftercare_done")):
		return
	var gatekeeper := _npc(&"ch3_gatekeeper")
	if not _assert_route(gatekeeper != null and gatekeeper._actor.pose == &"sit" and GameState.has_flag(&"ch3_care_passage_open")
			and Progression.credits == credits + 100, "aftercare seats the living gatekeeper, opens the shortcut and pays exactly 100 credits"):
		return
	await _shot("ne97-ch3-janus-seated")
	if not await _route_portal(&"gate_care"):
		return
	var care_return: Portal = _level()._portals.get(&"mezz_care")
	await _walk_to(care_return.global_position.x + 66.0, 5.0)
	if not await _route_portal(&"mezz_care"):
		return
	gatekeeper = _npc(&"ch3_gatekeeper")
	if not _assert_route(gatekeeper != null and gatekeeper._actor.pose == &"sit" and Progression.credits == credits + 100,
			"the care-passage round trip keeps the gatekeeper seated without paying again"):
		return
	if not await _route_portal(&"gate_lift"):
		return
	for tick in 720:
		if GameState.has_flag(&"ch3_sunlight_reached"):
			break
		await _frames(1)
	if not _assert_route(GameState.has_flag(&"ch3_sunlight_reached"), "the original lift and timed arrival reach the sunlight"):
		return
	if not await _input_talk(&"ch3_light_spot", [], func() -> bool: return true):
		return
	if not await _input_talk(&"ch3_telescope", [], func() -> bool: return true):
		return
	await _route_portal(&"edge_show")


func _chapter_three_showroom() -> void:
	if not _assert_route(_level().data.id == &"ch3_showroom" and GameState.has_flag(&"ch3_sunlight_reached"), "resumed inside the showroom after the actual sunlight route"):
		return
	var credits := Progression.credits
	if not await _input_talk(&"ch3_lin", ["post"], func() -> bool: return GameState.has_flag(&"ch3_clearwater_tour_started") and StoryItems.holds(&"ch3_tour_card")):
		return
	if not _assert_route(Progression.credits == credits and GameState.get_flag(&"room_choice") == "unset", "posting the objection starts the tour without collecting a deposit"):
		return
	for window in ["morning", "quiet", "late"]:
		var measured := StringName("room_%s_measured" % window)
		if not await _input_talk(StringName("ch3_window_%s" % window), [], func() -> bool: return GameState.has_flag(measured)):
			return
		await _shot("ne97-ch3-measured-%s" % window)
	if not await _input_talk(&"ch3_lin", ["propose", "quiet"], func() -> bool: return GameState.has_flag(&"sq3_room_proposal_done") and GameState.get_flag(&"room_choice") == "quiet"):
		return
	if not _assert_route(Progression.credits == credits + 20, "the first measured-room proposal pays exactly 20 credits"):
		return
	if not await _input_talk(&"ch3_lin", ["propose", "late"], func() -> bool: return GameState.get_flag(&"room_choice") == "late"):
		return
	if not _assert_route(Progression.credits == credits + 20, "changing the proposal updates the room without paying a second time"):
		return
	if not await _input_talk(&"ch3_lin", ["ask"], func() -> bool: return GameState.has_flag(&"ch3_lin_asked")):
		return
	if not await _input_talk(&"ch3_lin", ["finish"], func() -> bool: return GameState.has_flag(&"ch3_clearwater_tour_done")):
		return
	await _route_portal(&"show_hall")


func _chapter_three_office_first() -> void:
	var established := _level().data.id == &"ch3_office_hall" and GameState.has_flag(&"ch3_clearwater_tour_done")
	if not _assert_route(established and GameState.get_flag(&"room_choice") == "late", "reaching the original office preserves the showroom proposal"):
		return
	var credits := Progression.credits
	if not await _input_talk(&"ch3_petition_box", ["read", "listen", "leave"],
			func() -> bool: return GameState.has_flag(&"ch3_trade_half_heard") and GameState.has_flag(&"ch3_petition_receipt_taken")):
		return
	if not _assert_route(GameState.has_flag(&"sq7_ye_name_seen") and not GameState.has_flag(&"ch3_trade_listened")
			and not GameState.has_flag(&"ch3_trade_overheard") and Progression.credits == credits + 20,
			"the optional handwriting gives its one reward and leaving halfway records only the first half"):
		return
	await _shot("ne97-ch3-office-stepped-away")


func _chapter_three_office_last() -> void:
	var record_only := "--office-record-only" in OS.get_cmdline_user_args()
	var entry := &"ch3_t_c20_react" if record_only else &"ch3_t_c20_middle"
	if not _assert_route(_level().data.id == &"ch3_office_hall" and GameState.has_flag(&"ch3_trade_half_heard")
			and GameState.has_flag(&"ch3_trade_listened") == record_only and Story.resolve_dispatch(&"ch3_dispatch_bench") == entry,
			"a cold continuation resumes the original conversation at the waiting bench, halfway through"):
		return
	var middle_choice := "stay" if "--office-stay" in OS.get_cmdline_user_args() else "door"
	if not await _input_talk(&"ch3_waiting_bench", ["record"] if record_only else [middle_choice, "record"],
			func() -> bool: return GameState.has_flag(&"ch3_trade_overheard") and GameState.has_flag(&"ch3_l2_route_announced")):
		var player: CutscenePlayer = Story._player
		if is_instance_valid(player):
			print("NE97_OFFICE_HALTED ", player.scene_id, " step=", player.get("_current_where"), " process=", Engine.get_process_frames())
		return
	if not _assert_route(StoryItems.holds(&"ch3_trade_note") and StoryItems.holds(&"ch3_petition_receipt"), "the actual confirmation retains both the trade note and petition receipt"):
		return
	await _shot("ne97-ch3-office-recorded")
	for portal in [&"hall_edge", &"edge_lift", &"gate_care", &"mezz_lift", &"plaza_street"]:
		if not await _route_portal(portal):
			return
	_assert_route(_level().data.id == &"ch3_pawnshop" and GameState.has_flag(&"ch3_trade_overheard"), "the real home route returns to the evening pawnshop")


func _chapter_three_office_recovery() -> void:
	var actor := _npc(&"ch3_petition_box")
	if not _assert_route(_level().data.id == &"ch3_office_hall" and Story._current_cinematic == &"ch3_t_c19_watch"
			and actor != null and actor.get("_talking") and GameState.has_flag(&"ch3_petition_receipt_taken")
			and StoryItems.holds(&"ch3_intake_receipt") and not GameState.has_flag(&"ye_handwriting_seen"),
			"the original actor resumes the older blocked save after the receipt"):
		return
	var balance := Progression.credits
	var choices := ["read", "listen", "leave"]
	for tick in 4400:
		if choices.is_empty() and not Story.is_cinematic_active():
			break
		var cutscene: CutscenePlayer = Story._player
		if cutscene != null and cutscene.choice_active() and not choices.is_empty():
			var wanted: String = choices.front()
			var option := cutscene._choice_options.find_custom(func(current: Dictionary) -> bool: return str(current.get("id", "")) == wanted)
			if not _assert_route(option >= 0, "the recovered scene offers choice %s" % wanted):
				return
			choices.pop_front()
			cutscene.choose(option)
		elif tick % 8 == 0:
			_send_action(&"ui_accept")
		await _frames(1)
	if not _assert_route(choices.is_empty() and GameState.has_flag(&"ch3_trade_half_heard") and StoryItems.holds(&"ch3_intake_receipt")
			and GameState.has_flag(&"sq7_ye_name_seen") and Progression.credits == balance + 20,
			"the older save finishes the follow-up with the original receipt and exactly one name reward"):
		return
	await _shot("ne97-ch3-office-recovered")


func _chapter_three_ending() -> void:
	if not _assert_route(_level().data.id == &"ch3_pawnshop" and GameState.has_flag(&"ch3_trade_overheard")
			and not GameState.has_flag(&"ch3_shore_closed"), "cold continuation opens the evening pawnshop after the full return journey"):
		return
	if not await _input_talk(&"ch3_old_k_kitchen", ["note"], func() -> bool: return GameState.has_flag(&"ch3_home_supper_done")):
		return
	if not _assert_route(GameState.has_flag(&"ch3_umbrella_asked_twice"), "the kitchen conversation asks about the umbrella twice and puts the note away"):
		return
	if GameState.has_flag(&"m3_available"):
		if not await _input_talk(&"ch3_unsigned_record", [], func() -> bool: return GameState.has_flag(&"m3_seen")):
			return
	if not await _input_talk(&"ch3_shop_radio", ["tell", "agree"], func() -> bool: return GameState.has_flag(&"ch3_shore_closed")):
		return
	await _chapter_three_cold_ending()


func _chapter_three_cold_ending() -> void:
	for tick in 2400:
		if _main.get("_screen") is VictoryScreen and not _main.call("_route_pending"):
			break
		await _frames(1)
	var victory := _main.get("_screen") as VictoryScreen
	if not _assert_route(victory != null and victory.chapter == &"ch3_clearwater" and GameState.has_flag(&"ch3_shore_closed")
			and GameState.has_flag(&"ch3_told_egret_trade") and GameState.deaths == 1, "the genuine ending shows the third-chapter victory screen and preserves the single earlier flood death"):
		return
	var catalog := QuestCatalog.new()
	catalog.load_story_sources()
	var open_main := catalog.list_for("ch3_clearwater", "main", false, GameState.world_flags)
	_assert_route(catalog.issues.is_empty() and open_main.is_empty() and StoryItems.holds(&"ch3_trade_note")
			and GameState.get_flag(&"room_choice") == "late", "all Third Chapter main quests close and the trade note and proposal survive")
	await _shot("ne97-ch3-victory")
