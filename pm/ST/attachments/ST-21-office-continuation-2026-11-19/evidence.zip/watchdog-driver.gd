extends "res://tools/scenarios/watchdog_fight_scenario.gd"


func use_current_fight(active_level: Level, dog: PatternBoss) -> void:
	level = active_level
	player = level.player
	_dog = dog
	_use_pad = true
	AimInput.set_virtual_gamepad(player, true)
	player.health.damaged.connect(_on_player_damaged)
	_dog.health.damaged.connect(_on_dog_damaged)


func drive_frame() -> void:
	_elapsed += get_physics_process_delta_time()
	_drive()


func release_driver() -> void:
	_release_all()
	if is_instance_valid(player):
		AimInput.set_virtual_gamepad(player, false)
	print("NE97_WATCHDOG totals hit_count=", _hits_taken, ", damage=", _damage_taken, ", back_hits=", _back_hits)
