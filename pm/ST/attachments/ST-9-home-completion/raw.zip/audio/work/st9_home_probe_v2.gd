extends "res://tools/run_save_probe.gd"
## Arranged canonical prerequisites; real automatic home intro and Skip action.
## This diagnoses completion durability, not a whole chapter playthrough.
const HOME := &"ch1_c14_home"
const LAST := "res://data/levels/ch1_pawnshop_dawn.tres"
var _out := ""
var _record: Dictionary = {}
var _store: RunSaveStore
var _before := PackedByteArray()
var _primary := PackedByteArray()
var _injected := false

func _ready() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=")
	if not _out.is_empty():
		DirAccess.make_dir_recursive_absolute(_out)
	super._ready()

func _run() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
	Transition.instant = true
	Story.auto_skip = _mode not in ["refuse_read", "accept_read"]
	_main = MainScript.new()
	_main.process_mode = Node.PROCESS_MODE_PAUSABLE
	_store = RunSaveStore.new(_directory.path_join("slot.json"))
	_main.set("_run_store", _store)
	add_child(_main)
	await _frames(3)
	if _mode in ["refuse_read", "accept_read"]:
		if DirAccess.dir_exists_absolute(_store.path + ".tmp"):
			_check(DirAccess.remove_absolute(_store.path + ".tmp") == OK, "remove only the previous probe-owned obstruction")
		var saved := _store.read()
		var expected := _mode == "accept_read"
		_check(bool(saved.get("story", {}).get("flags", {}).get("ch1_home_done", false)) == expected, "cold reader sees only the actually committed home outcome")
		_main.call("_on_continue_requested")
		if expected:
			await _victory()
			_check(GameState.has_flag(&"ch1_home_done") and GameState.has_flag(&"ch1_complete") and Story.progress_snapshot().has(HOME), "fresh Main restores both accepted flags and actual completion")
			_check(_prompt() == null and not GameplayLock.is_locked() and not get_tree().paused, "accepted cold continue has no stale recovery pause")
		else:
			await _movie()
			_check(not GameState.has_flag(&"ch1_home_done") and not GameState.has_flag(&"ch1_complete") and not Story.progress_snapshot().has(HOME), "fresh Main resumes the uncompleted real home intro without granting results")
			_check(_main.get("_level_path") == LAST and Story.current_presentation_request() != 0, "uncommitted cold continue retains a real resumable home request")
		_check(Progression.credits == int(saved.get("progression", {}).get("credits", -1)), "cold continue preserves the actual saved wallet")
		_record = {"mode": _mode, "saved_home": saved.get("story", {}).get("flags", {}).get("ch1_home_done"), "live_home": GameState.has_flag(&"ch1_home_done"), "saved_complete": saved.get("chapter_complete")}
		await _shot("cold-continue")
		await _finish()
		return
	_check(_mode in ["refuse_write", "retry_write"], "known home completion mode")
	_main.call("_on_start_requested", GameState.difficulties[1])
	await _room()
	Story.reset_active_presentation(&"probe_setup")
	_check(Story._apply_scene_results(&"ch1_t_handoff_summary")["ok"] and Story._apply_scene_results(&"ch1_t_supper_leave_none")["ok"], "arrange canonical prerequisites with actual market-document ownership")
	Progression.add_credits(37)
	Story.auto_skip = false
	Story.scene_started.connect(_inject_home_fault)
	_main.call("_on_area_requested", LAST)
	await _movie()
	_check(_injected and _main.get("_level_path") == LAST, "real automatic terminal intro injects the owned fault after Main captures entry")
	await _shot("home-before-skip")
	Story.skip_cinematic()
	await _refusal()
	_check(_before == _facts(), "refused home ending retains flags wallet items and completed history")
	_check(_primary == FileAccess.get_file_as_bytes(_store.path), "actual home refusal keeps the exact original primary")
	_check(Story.current_presentation_request() != 0 and _main.get("_cinematic") == String(HOME), "refused home keeps its actual request and original presentation entry")
	var prompt := _prompt()
	_check(prompt != null and prompt.is_visible_in_tree() and prompt.get("presentation") == "event" and not prompt.cancel_button.visible, "automatic home refusal exposes event-specific retry-only recovery")
	_check(prompt != null and GameplayLock.is_locked() and get_tree().paused, "home recovery holds its own persistent pause")
	if prompt != null:
		var back := InputEventAction.new()
		back.action = &"ui_cancel"
		back.pressed = true
		prompt._unhandled_input(back)
		_check(_prompt() == prompt, "Back cannot strand the ended automatic home stage")
	_record = {"source": LAST, "primary_unchanged": _primary == FileAccess.get_file_as_bytes(_store.path), "after_refusal_home": GameState.has_flag(&"ch1_home_done"), "after_refusal_seen": Story.progress_snapshot().has(HOME)}
	await _shot("home-refused")
	if _mode == "retry_write":
		if prompt != null:
			prompt.retry_button.pressed.emit()
		await _refusal()
		_check(_before == _facts() and _prompt() != null, "same home request remains uncompleted and retryable after a second actual refusal")
		_check(DirAccess.remove_absolute(_store.path + ".tmp") == OK, "remove only the owned home obstruction before successful retry")
		prompt = _prompt()
		if prompt != null:
			prompt.retry_button.pressed.emit()
		await _victory()
		var saved := _store.read()
		_check(GameState.has_flag(&"ch1_home_done") and GameState.has_flag(&"ch1_complete") and Story.progress_snapshot().has(HOME), "same real home request installs both flags and completion after successful save")
		_check(saved.get("story", {}).get("flags", {}).get("ch1_home_done") == true and saved.get("chapter_complete") == true, "actual reader sees saved home and the subsequent accepted edition ending")
		_check(_prompt() == null and not GameplayLock.is_locked() and not get_tree().paused, "successful home retry leaves no recovery UI or pause")
		_record["after_retry_home"] = GameState.has_flag(&"ch1_home_done")
		await _shot("home-accepted")
	Story.scene_started.disconnect(_inject_home_fault)
	await _finish()

func _inject_home_fault(id: StringName, _mode_name: StringName) -> void:
	if id != HOME or _injected:
		return
	_injected = true
	_primary = FileAccess.get_file_as_bytes(_store.path)
	_before = _facts()
	_check(DirAccess.make_dir_absolute(_store.path + ".tmp") == OK, "actual owned temp directory blocks home completion before rotation")

func _facts() -> PackedByteArray:
	return var_to_bytes([GameState.world_flags, Progression.snapshot(), StoryItems.snapshot(), Story.progress_snapshot()])

func _gate() -> Node:
	for property: Dictionary in _main.get_property_list():
		if property["name"] == "_story_completion":
			return _main.get("_story_completion")
	return _main.get("_radio_completion")

func _prompt() -> Control:
	var gate := _gate()
	return gate.get("_prompt") if gate != null else null

func _room() -> Level:
	var deadline := Time.get_ticks_msec() + 120000
	while Time.get_ticks_msec() < deadline:
		var level := _main.get("_screen") as Level
		if level != null and level.is_initialized() and not _main.call("_route_pending") and not Story.is_cinematic_active() and Story._passive_requests.is_empty() and not GameplayLock.is_locked():
			return level
		await _frames(1)
	_check(false, "initial real Main room settles before time guard")
	return _main.get("_screen") as Level

func _movie() -> void:
	var deadline := Time.get_ticks_msec() + 120000
	while Time.get_ticks_msec() < deadline:
		if Story._current_cinematic == HOME and is_instance_valid(Story._player) and Story._player.is_running() and Story._player._actors.size() >= 2 and is_instance_valid(Story._player._dialogue) and Story._player._dialogue.is_visible_in_tree() and Story._player._dialogue.is_complete():
			return
		await _frames(1)
	_check(false, "real home movie reaches its actors and first dialogue before time guard")

func _refusal() -> void:
	var deadline := Time.get_ticks_msec() + 120000
	while Time.get_ticks_msec() < deadline:
		if _prompt() != null or GameState.has_flag(&"ch1_home_done"):
			await _frames(2)
			return
		await _frames(1)
	_check(false, "real home completion resolves or refuses before time guard")

func _victory() -> void:
	var deadline := Time.get_ticks_msec() + 120000
	while Time.get_ticks_msec() < deadline:
		var screen: Node = _main.get("_screen")
		if screen is VictoryScreen and not _main.call("_route_pending") and not screen._buttons.is_empty() and not screen._buttons[0].disabled:
			return
		await _frames(1)
	_check(false, "real home completion reaches the accepted edition ending before time guard")

func _shot(name: String) -> void:
	if _out.is_empty() or DisplayServer.get_name() == "headless":
		return
	var canvas := CanvasLayer.new()
	canvas.layer = 120
	add_child(canvas)
	var note := Label.new()
	note.text = "SOFTWARE FORWARD+ / ARRANGED PRE-HOME FACTS + IO FAULT / NOT A PLAYTHROUGH"
	note.position = Vector2(12, 12)
	note.add_theme_font_size_override("font_size", 12)
	canvas.add_child(note)
	var saved := _store.read()
	var flags: Dictionary = saved.get("story", {}).get("flags", {})
	var status := Label.new()
	status.text = "HOME live=[%s,%s] seen=%s / disk=[%s,%s]" % [GameState.has_flag(&"ch1_home_done"), GameState.has_flag(&"ch1_complete"), Story.progress_snapshot().has(HOME), flags.get("ch1_home_done", "missing"), flags.get("ch1_complete", "missing")]
	status.position = Vector2(12, 28)
	status.add_theme_font_size_override("font_size", 11)
	canvas.add_child(status)
	await _frames(2)
	await RenderingServer.frame_post_draw
	preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(_out.path_join(name + ".png"))
	canvas.queue_free()

func _finish() -> void:
	_record["mode"] = _mode
	_record["checks"] = _checks
	_record["failures"] = Array(_failures)
	_record["engine"] = Engine.get_version_info().string
	_record["probe_sha256"] = FileAccess.get_sha256("res://work/st9_home_probe_v2.gd")
	_record["source_sha256"] = {}
	for path: String in ["game/main.gd", "game/radio_completion.gd", "autoload/story.gd", "core/story_outcomes.gd", "data/story/ch1_kasa.json", "ui/radio_save_prompt.gd"]:
		_record["source_sha256"][path] = FileAccess.get_sha256("res://" + path)
	if not _out.is_empty():
		var file := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
		file.store_string(JSON.stringify(_record, "  ") + "\n")
		file.close()
	await super._finish()
