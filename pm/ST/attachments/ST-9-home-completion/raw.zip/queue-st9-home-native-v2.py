from pathlib import Path
import os,subprocess,json,time,hashlib
b=Path(__file__).parent;p=b/'audio'
while not (b/'st9-home-native-refuse.exit').exists():time.sleep(2)
assert (b/'st9-home-native-refuse.exit').read_text()=='1'
while not (b/'st9-home-affected.exit').exists():time.sleep(2)
assert (b/'st9-home-affected.exit').read_text()=='0'
inputs=json.loads((b/'st9-home-test-inputs.json').read_text());assert all(hashlib.sha256((p/k).read_bytes()).hexdigest()==v for k,v in inputs.items())
before=json.loads((b/'st9-home-source-before.json').read_text());rels=[*before,'tests/helpers/radio_prompt_checks.gd'];candidate={k:(p/k).read_bytes() for k in rels};results=[]
env=os.environ.copy();env['NE_NATIVE_PROJECT']='audio'
def run(suffix,mode,slot):
 name='st9-home-native-v2-'+suffix
 r=subprocess.run(['python',str(b/'native.py'),name,'res://work/st9_home_probe_v2.tscn','--mode='+mode,'--save-dir='+str(b/slot)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit':r.returncode});(b/'st9-home-native-v2-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 log=(b/(name+'.log')).read_text();assert not any(x in log for x in ['SCRIPT ERROR:','Parse Error:','Compile Error:','\nERROR:'])
 return r.returncode
try:
 for k,d in before.items():(p/k).write_bytes((b/d['snapshot']).read_bytes())
 (p/'tests/helpers/radio_prompt_checks.gd').write_bytes(subprocess.check_output(['git','show','cdd6fc7cf8d9cbdfa8e84e641b09f54fd196087e:tests/helpers/radio_prompt_checks.gd'],cwd=p))
 assert run('before','refuse_write','st9-home-v2-before-slot')!=0
finally:
 for k,data in candidate.items():(p/k).write_bytes(data)
assert all(hashlib.sha256((p/k).read_bytes()).hexdigest()==v for k,v in inputs.items())
for suffix,mode,slot in [('refuse','refuse_write','st9-home-v2-refuse-slot'),('refuse-cold','refuse_read','st9-home-v2-refuse-slot'),('retry','retry_write','st9-home-v2-retry-slot'),('retry-cold','accept_read','st9-home-v2-retry-slot')]:assert run(suffix,mode,slot)==0
assert all(hashlib.sha256((p/k).read_bytes()).hexdigest()==v for k,v in inputs.items())
(b/'st9-home-native-v2-candidate-restored.json').write_text(json.dumps(inputs,indent=2)+'\n')
