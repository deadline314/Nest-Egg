from pathlib import Path
import hashlib,json
b=Path(__file__).parent;p=b/'audio'
paths=['game/radio_completion.gd','game/main.gd','autoload/story.gd','ui/radio_save_prompt.gd','tools/story/ch1_runtime_backend.py','data/story/ch1_kasa.json']
records={}
for rel in paths:
 data=(p/rel).read_bytes();dest=b/('st9-home-before-'+rel.replace('/','__'));dest.write_bytes(data);records[rel]={'sha256':hashlib.sha256(data).hexdigest(),'snapshot':dest.name}
(b/'st9-home-source-before.json').write_text(json.dumps(records,indent=2)+'\n')
s=(p/'game/radio_completion.gd').read_text();s=s.replace('## Main-owned completion gate for important, flag-only radio scenes.', '## Main-owned durable flags for important radio and explicitly marked terminal scenes.');s=s.replace('const Prompt :=', 'const POLICY := "main_flags_v1"\nconst Prompt :=',1)
s=s.replace('var _pending_request := 0','var _pending_request := 0\nvar _pending_cinematic := false\nvar _notify_flags: Array[String] = []')
s=s.replace('Story.passive_completion_gate = complete','Story.passive_completion_gate = complete\n\tStory.cinematic_completion_gate = complete',1)
s=s.replace('\t_clear()\n\n\nfunc blocks_save()', '\tif Story.cinematic_completion_gate == complete:\n\t\tStory.cinematic_completion_gate = Callable()\n\t_clear()\n\n\nfunc blocks_save()',1)
a=s.index('func complete(');z=s.index('\n\nfunc _commit(',a)
s=s[:a]+'''func complete(id: StringName, request: int) -> Dictionary:
	var scene: Dictionary = Story._scenes.get(String(id), {})
	var cinematic := scene.get("completion_policy", "") == POLICY
	var radio := str(scene.get("mode", "")) == "radio" and bool(scene.get("freeze", false))
	if not main.get("_active_run") or not (radio or cinematic):
		return {} # Standalone presentation tools retain their existing behavior.
	var results: Variant = scene.get("results", [])
	if not cinematic and (not results is Array or not results.is_empty() or not StoryRules.transfer_ids(scene).is_empty() or not (Story._pending_transfers.get(id, []) as Array).is_empty()):
		return {} # Existing radio admission; marked scenes must never fall through.
	var level := main.get("_screen") as Level
	if level == null or not level.is_initialized() or main.call("_route_pending") or (not cinematic and Story.is_cinematic_active()):
		if cinematic:
			push_warning("[StoryFlagCompletion] marked scene has no current Main Level: " + String(id))
			return {"handled": true, "ready": false}
		return {}
	_pending_id = id
	_pending_request = request
	_pending_cinematic = cinematic
	if _lock == 0:
		_lock = GameplayLock.acquire(self, Input.MOUSE_MODE_VISIBLE)
	var result := _commit(id, scene, level)
	if not result.get("committed", false):
		push_warning("[StoryFlagCompletion] %s: %s" % [id, str(result.get("error", "completion preparation refused")).left(512)])
		_reload_original = result.get("reload_original", false)
		_show_prompt(false)
		return {"handled": true, "ready": false}
	if result.get("recovery", false):
		_recovery = true
		_show_prompt(true)
		return {"handled": true, "ready": false}
	_publishing = true
	if cinematic:
		# Retire the old entry before completion/flag listeners can route or save.
		main.call("_clear_cinematic")
		# Story first retires this real handle and settles its waiter. The deferred
		# notification is queued before Level's deferred completion/navigation.
		_notify_flags.assign(result["changed"])
	else:
		for flag: String in result["changed"]:
			GameState.flag_changed.emit(StringName(flag), GameState.get_flag(StringName(flag)))
	_clear()
	_finish_publish.call_deferred()
	return {"handled": true, "ready": true}
''' +s[z:]
s=s.replace('''	var source := Bundle._capture_source()
	if source.has("error"):
		return source
	var candidate := RunSnapshot.capture(main.get("_level_path"), level.run_snapshot(), "", main.get("_chapter_complete"))
	var baseline := candidate.duplicate(true)''','''	var problem := Story.outcomes.result_contract_problem(id, scene)
	if not problem.is_empty():
		return {"error": problem}
	var cinematic := scene.get("completion_policy", "") == POLICY
	if cinematic:
		if scene.get("mode", "") not in ["animated", "dialogue"] or not str(scene.get("then", "")).is_empty() or Story.offers_choice(scene) or not StoryRules.transfer_ids(scene).is_empty() or not (Story._pending_transfers.get(id, []) as Array).is_empty():
			return {"error": "main_flags_v1 requires a terminal, choice-free, flag-only scene"}
		if level.data.intro_scene != id or not level.data.complete_after_intro or level.data.resource_path != main.get("_level_path") or Story._current_cinematic != id or Story.current_presentation_request() != _pending_request:
			return {"error": "main_flags_v1 requires its real terminal intro request and current Level"}
		for item: StoryItemData in StoryItems.catalog():
			if item.trigger == StoryItemData.Trigger.SCENE_FINISHED and item.trigger_scene == id:
				return {"error": "flag completion cannot own an automatic item reward"}
	for op: Dictionary in StoryOutcomes.operations(scene):
		if op["kind"] != "flag" or not GameState.flag_defaults.has(String(op["id"])):
			return {"error": "flag completion cannot own non-flag or undeclared results"}
	# run_snapshot may merge Level's area; freeze the source after that capture.
	var candidate := RunSnapshot.capture(main.get("_level_path"), level.run_snapshot(), "", main.get("_chapter_complete"))
	var source := Bundle._capture_source()
	if source.has("error"):
		return source
	var unchanged := candidate.duplicate(true)
	var baseline := candidate.duplicate(true)
	if cinematic:
		var entry: Variant = main.get("_cinematic_entry")
		if not entry is Dictionary or entry.is_empty():
			return {"error": "terminal flag completion has no original presentation entry"}
		baseline = entry.duplicate(true)
		baseline["cinematic"] = String(id)
		baseline["cinematic_context"] = main.get("_cinematic_context").duplicate(true)''',1)
s=s.replace('\tvar facts := func(kind:', '\tfor op: Dictionary in StoryOutcomes.operations(scene):\n\t\tflags[String(op["id"])] = op.get("value", true)\n\tvar facts := func(kind:',1)
s=s.replace('[[normalized["story"]["items"], baseline["story"]["items"]], [normalized["progression"], baseline["progression"]]]','[[normalized["story"]["items"], unchanged["story"]["items"]], [normalized["progression"], unchanged["progression"]], [normalized["state"], unchanged["state"]]]')
s=s.replace('run/story/items or run/progression needs a whole-run repair','non-flag run owners need a whole-run repair')
s=s.replace('\t_prompt = Prompt.new()\n', '\t_prompt = Prompt.new()\n\t_prompt.presentation = "event" if _pending_cinematic else "radio"\n\t_prompt.allow_cancel = not _pending_cinematic\n',1)
s=s.replace('\t\tStory.reset_active_presentation(&"load")', '\t\tif _recovery and _pending_cinematic:\n\t\t\tmain.call("_clear_cinematic")\n\t\tStory.reset_active_presentation(&"load")',1)
s=s.replace('''	if _pending_request != 0:
		Story._on_passive_finished(_pending_id, _pending_request)''','''	if _pending_request != 0:
		if _pending_cinematic:
			Story._on_cinematic_finished(_pending_id, _pending_request)
		else:
			Story._on_passive_finished(_pending_id, _pending_request)''',1)
s=s.replace('func _clear() -> void:\n\t_pending_id', 'func _clear() -> void:\n\t_pending_cinematic = false\n\t_pending_id',1)
s=s.replace('func _finish_publish() -> void:\n\t_publishing = false', '''func _finish_publish() -> void:
	var flags := _notify_flags.duplicate()
	_notify_flags.clear()
	for flag: String in flags:
		GameState.flag_changed.emit(StringName(flag), GameState.get_flag(StringName(flag)))
	_publishing = false''',1)
(p/'game/story_flag_completion.gd').write_text(s)
(p/'game/radio_completion.gd').write_text('extends "res://game/story_flag_completion.gd"\n## Compatibility path for existing radio owner fixtures and saved tool setups.\n')
f=p/'game/main.gd';s=f.read_text().replace('_radio_completion','_story_completion').replace('res://game/radio_completion.gd','res://game/story_flag_completion.gd');f.write_text(s)
f=p/'autoload/story.gd';s=f.read_text().replace('var passive_completion_gate: Callable','var passive_completion_gate: Callable\nvar cinematic_completion_gate: Callable',1)
s=s.replace('func _on_cinematic_finished(id: StringName) -> void:\n\tif _current_cinematic != id:', 'func _on_cinematic_finished(id: StringName, expected_request := 0) -> void:\n\tif _current_cinematic != id or (expected_request != 0 and expected_request != _current_request):',1)
s=s.replace('''	_current_cinematic = &""
	var completed_request := _current_request''','''	var guarded: Dictionary = cinematic_completion_gate.call(id, _current_request) if cinematic_completion_gate.is_valid() else {}
	if guarded.get("handled", false) and not guarded.get("ready", false):
		return
	_current_cinematic = &""
	var completed_request := _current_request''',1)
a=s.index('func _on_cinematic_finished(');z=s.index('\n\n## 選項或交易失敗',a);part=s[a:z].replace('var applied := _apply_scene_results(id)','var applied := {"ok": true, "failure_scene": ""} if guarded.get("handled", false) else _apply_scene_results(id)');s=s[:a]+part+s[z:];f.write_text(s)
f=p/'tools/story/ch1_runtime_backend.py';s=f.read_text();old='''    if segment.next_scene:
        scene["then"] = segment.next_scene
    return scene''';new='''    if segment.next_scene:
        scene["then"] = segment.next_scene
    # Main owns durable completion of the automatic home boundary. This limited
    # flag policy does not advertise the future atomic item/money coordinator.
    if segment.binding == "home" and scene.get("mode") == "animated" and results and all(op["kind"] == "flag" for op in results) and not segment.options and not segment.next_scene:
        scene["completion_policy"] = "main_flags_v1"
    return scene''';assert old in s;s=s.replace(old,new,1);f.write_text(s)
