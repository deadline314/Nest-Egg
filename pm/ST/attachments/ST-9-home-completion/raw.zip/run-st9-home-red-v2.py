from pathlib import Path
import os,subprocess,json,hashlib
b=Path(__file__).parent;p=b/'audio';before=json.loads((b/'st9-home-source-before.json').read_text());rels=[*before,'tests/helpers/radio_prompt_checks.gd'];candidate={k:(p/k).read_bytes() for k in rels};proof={k:hashlib.sha256(v).hexdigest() for k,v in candidate.items()}
try:
 for k,d in before.items():(p/k).write_bytes((b/d['snapshot']).read_bytes())
 (p/'tests/helpers/radio_prompt_checks.gd').write_bytes(subprocess.check_output(['git','show','cdd6fc7cf8d9cbdfa8e84e641b09f54fd196087e:tests/helpers/radio_prompt_checks.gd'],cwd=p))
 env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',GODOT=str(b/'godot472/Godot_v4.7.2-stable_linux.x86_64'),SHARDS='1',LOG_DIR=str(b/'st9-home-red-v2'))
 with (b/'st9-home-red-v2.log').open('w') as log:r=subprocess.run(['tools/run_tests_parallel.sh','--only=RunSaveSuite'],cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT)
 (b/'st9-home-red-v2.exit').write_text(str(r.returncode));assert r.returncode!=0
 for f in (b/'st9-home-red-v2').glob('shard_*.log'):assert not any(x in f.read_text() for x in ['SCRIPT ERROR:','Parse Error:','Compile Error:'])
finally:
 for k,data in candidate.items():(p/k).write_bytes(data)
assert all(hashlib.sha256((p/k).read_bytes()).hexdigest()==v for k,v in proof.items())
(b/'st9-home-red-v2-candidate-restored.json').write_text(json.dumps(proof,indent=2)+'\n')
print((b/'st9-home-red-v2.log').read_text())
