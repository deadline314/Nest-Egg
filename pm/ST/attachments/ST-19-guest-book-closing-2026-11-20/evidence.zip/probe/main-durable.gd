extends "res://tools/ch2_flow_probe.gd"

const ENTRY := &"ch2_guest_entry"
const CLOSE := &"ch2_t_s21_close"
const LOUNGE := "res://data/levels/ch2_lounge_front.tres"
var _mode := "normal"
var _slot := ""
var _main: Node
var _send_escape := false
var _sent := false
var _stage_frames := 0
var _opening_credits := -1
var _begun: Array[String] = []
var _closing_entries: Array[Dictionary] = []


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--mode="):
			_mode = argument.trim_prefix("--mode=")
		elif argument.begins_with("--save-dir="):
			_slot = argument.trim_prefix("--save-dir=")
	process_mode = Node.PROCESS_MODE_ALWAYS
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Transition.instant = true
	Story.auto_skip = false
	Settings.set_skip_cutscenes(false)
	super._ready()


func _run() -> void:
	_shots = {"ch2_t_s21_close":"guest-book-closing", "ch2_t_s17_open:choice":"guest-list"}
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_slot.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(60)
	var reopened := _mode == "cold" or _mode == "cold-complete"
	_check(GameState.has_flag(&"ch2_egret_returned"), "the original save already contains Egret's actual return")
	if not reopened:
		_check(not GameState.has_flag(&"guest_book_completed") and _guest_flags() == [false,false,false], "the ordinary save has not started the guest book")
	var original_level := _main.get("_screen") as Level
	if original_level == null:
		_check(false, "Main did not load the input run slot")
		_finish_probe()
		return
	if original_level.data.resource_path != LOUNGE:
		_main.call("_on_area_requested", LOUNGE)
		await _settle(60)
	_level = _main.get("_screen") as Level
	if not _check_level():
		_finish_probe()
		return
	Story.scene_started.connect(func(id: StringName, _what: StringName) -> void:
		_begun.append(String(id))
		if id == CLOSE:
			_closing_entries.append(_results())
			if _mode == "setting" and not _sent:
				Settings.set_skip_cutscenes(true))
	if _mode == "cold-complete":
		var paid := Progression.credits
		_check(not Story.is_cinematic_active() and not get_tree().paused, "cold continue returns to Rin without restarting the closing")
		_check(GameState.has_flag(&"guest_book_completed") and _receipt() == "recorded", "cold read keeps the final paid receipt")
		_check(await _talk(ENTRY), "the ordinary completed-book revisit opens")
		_check(_begun == ["ch2_t_s17_revisit"] and Progression.credits == paid, "a cold completed revisit never pays twice")
		_finish_probe()
		return
	if _mode == "cold":
		var paid := Progression.credits
		_check(not Story.is_cinematic_active() and not get_tree().paused, "cold continue returns to Rin without restarting the closing")
		_check(GameState.has_flag(&"ch2_audit_submitted") and _guest_flags() == [true,true,true], "cold read keeps the three original guest decisions")
		_check(not GameState.has_flag(&"guest_book_completed") and _receipt() == "missing", "cold read preserves the unfinished closing")
		await _resume(paid)
		_finish_probe()
		return
	_check(GameState.has_flag(&"ch2_audit_submitted"), "the arranged save is after the audit and before the first guest")
	await _settle(26)
	_opening_credits = Progression.credits
	_check(await _talk(ENTRY,["watch","zheng","ask","fish","back"]), "the original first guest is completed")
	_check(_results()["delta"] == 20, "first guest pays twenty")
	_check(await _talk(ENTRY,["watch","chen","today","soup","back"]), "the original second guest is completed")
	_check(_results()["delta"] == 40, "second guest pays twenty")
	_send_escape = _mode in ["skip","warm","setting"]
	var settled := await _third_guest()
	_check(not _closing_entries.is_empty() and _closing_entries[0]["delta"] == 60 and _guest_flags() == [true,true,true],
			"all three guest receipts are present before the closing starts")
	if _send_escape:
		_check(_sent and not settled and not Story.is_cinematic_active() and not get_tree().paused, "leaving the closing releases the real NPC and returns gameplay")
		_check(_results()["delta"] == 60 and _receipt() == "missing" and not GameState.has_flag(&"guest_book_completed") and not Story.was_seen(CLOSE),
				"leaving keeps only the three guest payments")
		if _mode != "skip":
			await _resume(Progression.credits)
	else:
		_check(settled and _results()["delta"] == 100 and _receipt() == "recorded" and GameState.has_flag(&"guest_book_completed"),
				"finishing naturally grants exactly the existing forty-point receipt")
	await _settle(24)
	if _mode == "skip":
		_check(_main.get("_run_store").read().get("cinematic") == "", "the actual post-leave save has no active presentation")
	_finish_probe()


func _check_level() -> bool:
	var valid := _level != null and _level.data.resource_path == LOUNGE
	_check(valid, "entered the official lounge through Main")
	return valid


func _third_guest() -> bool:
	var npc := _object(ENTRY)
	if npc == null:
		_check(false, "the original guest book object must be present")
		return false
	_level.player.global_position = npc.global_position + Vector2(-28,0)
	await _settle(12)
	var done := [false,false]
	var talk := func() -> void:
		done[1] = await npc._talk()
		done[0] = true
	talk.call()
	await _drive(["watch","hong","listen","heard"],func() -> bool: return done[0])
	_check(done[0], "the real NPC request settles")
	return done[1]


func _resume(paid: int) -> void:
	_begun.clear()
	_check(await _talk(ENTRY), "checking the same guest book resumes its original ending")
	_check(_begun == [String(CLOSE)], "resume goes directly to the closing without repeating a guest")
	_check(GameState.has_flag(&"guest_book_completed") and Progression.credits == paid + 40 and _receipt() == "recorded",
			"resume completes the original forty-point receipt exactly once")
	_begun.clear()
	_check(await _talk(ENTRY), "the original completed-book revisit works")
	_check(_begun == ["ch2_t_s17_revisit"] and Progression.credits == paid + 40, "a revisit does not repeat any payment")


func _guest_flags() -> Array[bool]:
	return [GameState.has_flag(&"guest_ticket_answered"),GameState.has_flag(&"guest_band_answered"),GameState.has_flag(&"guest_letter_answered")]


func _receipt() -> String:
	return Progression.story_receipt_status(&"ch2.guest_book")["status"]


func _results() -> Dictionary:
	return {"delta":Progression.credits-_opening_credits,"credits":Progression.credits,"guests":_guest_flags(),
			"receipt":_receipt(),"done":GameState.has_flag(&"guest_book_completed")}


func _finish_probe() -> void:
	var result := {"mode":_mode,"failures":_failures,"escaped":_sent,"closing_entries":_closing_entries,
			"after":_results(),"skip_setting":Settings.get_skip_cutscenes()}
	var file := FileAccess.open(_out_dir.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(result,"  ")+"\n")
	file.close()
	get_tree().quit(0 if _failures == 0 else 1)


func _process(_delta: float) -> void:
	var player: CutscenePlayer = Story._player
	if not is_instance_valid(player) or player.scene_id != CLOSE or not is_instance_valid(player._stage):
		return
	_stage_frames += 1
	if _send_escape and not _sent and _stage_frames >= 40:
		_sent = true
		var expected_hint := UiKit.cinematic_skip_hint(Story.language,&"ui_cancel",true)
		_check(player._skip_hint.text == expected_hint, "the existing action hint says leave")
		_capture.call_deferred("before-leave")
		var press := InputEventKey.new()
		press.keycode = KEY_ESCAPE
		press.physical_keycode = KEY_ESCAPE
		press.pressed = true
		Input.parse_input_event(press)
		var release := press.duplicate() as InputEventKey
		release.pressed = false
		Input.parse_input_event(release)

