extends "res://tools/ch2_flow_probe.gd"

const ENTRY := &"ch2_guest_entry"
const CLOSE := &"ch2_t_s21_close"
var _skip_close := false
var _escaped := false
var _entered := false
var _stage_frames := 0
var _seen_at_close: Dictionary = {}


func _ready() -> void:
	_skip_close = "--skip-close" in OS.get_cmdline_user_args()
	process_mode = Node.PROCESS_MODE_ALWAYS
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	super._ready()


func _run() -> void:
	_shots = {"ch2_t_s21_close":"s21-close", "ch2_t_s17_open:choice":"original-guest-list"}
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip = false
	GameState.set_flag(&"ch2_audit_submitted")
	await _enter("lounge_front")
	var start := Progression.credits
	Story.scene_started.connect(func(id: StringName, _kind: StringName) -> void:
		if id == CLOSE:
			_entered = true
			_seen_at_close = _outcomes(start))
	_check(await _talk(ENTRY, ["watch","zheng","ask","fish","back"]), "actual concierge source awards the first guest")
	_check(Progression.credits == start + 20, "the first guest pays twenty")
	_check(await _talk(ENTRY, ["watch","chen","today","soup","back"]), "the original source continues with Chen")
	_check(Progression.credits == start + 40, "two guests pay forty")
	_check(await _talk(ENTRY, ["watch","hong","listen","heard"]), "the third guest starts the original closing scene")
	var final := _outcomes(start)
	_check(final["guests"] == [true,true,true] and _entered, "all guest choices complete before closing")
	_check(_seen_at_close.get("delta") == 60 and not _seen_at_close.get("completed", true), "the book does not pay before reaching its closing scene")
	_check(not get_tree().paused and not Story.is_cinematic_active(), "closing returns control to Rin")
	if _skip_close:
		_check(_escaped, "a single physical Escape event reached the closing presentation")
	else:
		_check(final["delta"] == 100 and final["completed"], "the ordinary closure pays the original total")
	var report := {"skip":_skip_close,"escaped":_escaped,"stage_frames":_stage_frames,
			"on_entry":_seen_at_close,"after_return":final,"failures":_failures,"adapter":RenderingServer.get_video_adapter_name()}
	var file := FileAccess.open(_out_dir.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"  ") + "\n")
	file.close()
	AudioRelease.begin_shutdown()
	if is_instance_valid(_level):
		_level.queue_free()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures == 0 else 1)


func _outcomes(start: int) -> Dictionary:
	return {"delta":Progression.credits - start,"completed":GameState.has_flag(&"guest_book_completed"),
			"guests":[GameState.has_flag(&"guest_ticket_answered"),GameState.has_flag(&"guest_band_answered"),GameState.has_flag(&"guest_letter_answered")],
			"receipt":Progression.story_receipt_status(&"ch2.guest_book")}


func _process(_delta: float) -> void:
	var cinematic: CutscenePlayer = Story._player
	if not is_instance_valid(cinematic) or cinematic.scene_id != CLOSE or not is_instance_valid(cinematic._stage):
		return
	_stage_frames += 1
	if _skip_close and not _escaped and _stage_frames >= 40:
		_escaped = true
		_capture.call_deferred("before-escape")
		var press := InputEventKey.new()
		press.keycode = KEY_ESCAPE
		press.physical_keycode = KEY_ESCAPE
		press.pressed = true
		Input.parse_input_event(press)
		var release := press.duplicate() as InputEventKey
		release.pressed = false
		Input.parse_input_event(release)
