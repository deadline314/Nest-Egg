from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import os
import re
import subprocess
import sys

base=Path(__file__).resolve().parent
game=base.parent/"ne218-baseline-20261117"
label, mode, language=sys.argv[1:4]
out=base/label
out.mkdir()
seed=Path(sys.argv[4]) if len(sys.argv)>4 else base.parent/"evidence-20261121-st19-reconcile-source-map/candidate-release-zh/slot.json"
sha=lambda p:sha256(p.read_bytes()).hexdigest()
assert seed.is_file()
input_digest=sha(seed)
slot=out/"slot.json"
copy2(seed,slot)
env=os.environ.copy()
for key in ("APPDATA","LOCALAPPDATA","TEMP","TMP","TMPDIR"):
    path=out/key
    path.mkdir()
    env[key]=str(path)
source=json.loads((base.parent/"evidence-20261121-st19-ledger-dispute/published-source.json").read_bytes())
paths=["data/story/ch2_heron.json","data/cutscene/stages/ch2_ledger_dispute.json",
       "data/levels/ch2_loading.tres","data/levels/ch2_ledger_front.tres","game/cutscene/cutscene_player.gd"]
exact={path:sha(game/path) for path in paths}
assert all(exact[path]==source[path] for path in paths)
command=[sys.executable,"-B",str(game/"tools/comfyui/gpu_lock.py"),"--","C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
         "--path",str(game),"--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy",
         "--fixed-fps","60","--resolution","1280x720","--quit-after","6500",str(base/"old-midpoint.tscn"),
         "--",f"--out={out}",f"--slot={slot}",f"--mode={mode}",f"--lang={language}"]
(out/"command.json").write_text(json.dumps({"argv":command,"source":exact,"seed_sha256":input_digest},indent=2)+"\n",encoding="utf-8")
with (out/"engine.log").open("wb") as log:
    p=subprocess.run(command,cwd=game,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=245)
raw=(out/"engine.log").read_text(encoding="utf-8",errors="replace")
print(raw[-9000:],flush=True)
assert p.returncode==0 and not re.search(r"^(?:SCRIPT )?ERROR:|^FAIL |cannot reach stage point|leaked at exit",raw,re.M)
assert all(sha(game/path)==digest for path,digest in exact.items()) and sha(seed)==input_digest
report=json.loads((out/"actual-route.json").read_bytes())
assert report["failures"]==0 and report["credits"]==1274 and report["hdr"] and "9070 XT" in report["adapter"]
assert report["real_hold"] and report["opening"] and report["language"]==language
disk=json.loads(json.loads(slot.read_bytes())["payload"])
assert disk["cinematic"] == "ch2_t_s11_xiaowei", disk["cinematic"]
assert disk["level"]=="res://data/levels/ch2_ledger_front.tres" and disk["story"]["flags"]["ch2_yong_intro_seen"]==(mode!="leave")
assert all(key in disk["story"]["items"]["held"] for key in ("ch2_evidence_contract","ch2_evidence_receipt","ch2_evidence_collection"))
assert not any(disk["story"]["flags"].get(f,False) for f in ("ch2_yong_subdued","ch2_original_ledger_taken","yong_link_isolated","yong_link_revoked"))