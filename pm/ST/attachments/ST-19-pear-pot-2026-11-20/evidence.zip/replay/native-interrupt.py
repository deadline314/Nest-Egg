from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import os
import subprocess
import sys

root=Path.cwd()
base=Path(__file__).resolve().parent
project=base.parent/'ne218-baseline-20261117'
prior=base.parent/'evidence-20261120-st19-guest-close'
source=json.loads((base/'source.json').read_bytes())
held=lambda:all(sha256((project/path).read_bytes()).hexdigest()==value for path,value in source.items())
assert held()
tier=sys.argv[1]
assert tier in ('high','low')
suffix=sys.argv[2] if len(sys.argv)>2 else ''
assert not suffix or suffix.isdecimal()
output=base/('interrupt-'+tier+suffix)
(output/'slot').mkdir(parents=True)
seed=prior/'durable-skip/slot/slot.json'
copyfile(seed,output/'slot/slot.json')
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_DATA_HOME'):
    env[key]=str(output/'profile'/key)
command=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
       'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(project),
       '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','WASAPI',
       '--resolution','960x540','--max-fps','60',str(base/'pear-interrupt.tscn'),'--','--out='+str(output),
       '--mode=cold','--save-dir='+str(output/'slot'),'--tier='+tier]
(output/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
with (output/'raw.log').open('wb') as log:
    result=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
raw=(output/'raw.log').read_text(encoding='utf-8',errors='replace')
receipt={'exit':result.returncode,'source_held':held(),'issues':[line for line in raw.splitlines() if 'ERROR:' in line or 'WARNING: [CutsceneReach]' in line]}
(output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(raw[-3400:],receipt,flush=True)
assert receipt=={'exit':0,'source_held':True,'issues':[]} and 'RX 9070 XT' in raw and 'Forward+' in raw

