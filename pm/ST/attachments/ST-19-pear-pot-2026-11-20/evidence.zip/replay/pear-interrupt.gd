extends "D:/NestEggVerification/evidence-20261120-st19-guest-close/main-durable.gd"

const PEAR := "ali_closing_pear"
const STOVE := "ali_closing_stove"
const GRIP := Vector2(14.5, 50.5)
const FLOOR := 265.5
const STOVE_SCALE := 36.0 * 3.9 / 287.0
const RIM_Y := FLOOR - (287.0 - 19.0) * STOVE_SCALE
const RIM_X := 135.0 + 90.0 * STOVE_SCALE
var _tier := LightQuality.Tier.HIGH
var _appearance := false
var _pickup := false
var _above := false
var _dropped := false
var _hidden := false
var _contact := 0.0
var _lowest_release := -INF
var _stove_bottom := INF
var _closed := false
var _interrupting := true


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument == "--tier=low":
			_tier = LightQuality.Tier.LOW
	super._ready()
	process_priority = 30
	Settings.set_light_quality(_tier)


func _resume(paid: int) -> void:
	var npc := _object(ENTRY)
	var done := [false,false]
	var talk := func() -> void:
		done[1] = await npc._talk()
		done[0] = true
	talk.call()
	await _drive([],func() -> bool: return done[0])
	await _settle(18)
	_check(_sent and _above and done[0] and not done[1], "one escape while the pear is actually held ends the owner request")
	_check(not Story.is_cinematic_active() and not get_tree().paused and not npc._talking and (not is_instance_valid(Story._player) or not is_instance_valid(Story._player._stage)),
			"the cooker stage and its held fruit are disposed before control returns")
	_check(Progression.credits == paid and _guest_flags() == [true,true,true] and _receipt() == "missing" and not GameState.has_flag(&"guest_book_completed"),
			"interrupting the real gesture keeps the three payments and leaves settlement pending")
	_check(_main.get("_run_store").read().get("cinematic") == "", "the same gesture leaves the saved playback checkpoint clear")


func _leave_during_hold() -> void:
	await _capture_rendered("held-before-leave")
	var press := InputEventKey.new()
	press.keycode = KEY_ESCAPE
	press.physical_keycode = KEY_ESCAPE
	press.pressed = true
	_sent = true
	Input.parse_input_event(press)
	var release := press.duplicate() as InputEventKey
	release.pressed = false
	Input.parse_input_event(release)


func _process(_delta: float) -> void:
	var player: CutscenePlayer = Story._player
	if _closed or not is_instance_valid(player) or player.scene_id != CLOSE or not is_instance_valid(player._stage):
		return
	var stage := player._stage
	var pear := stage.prop_node(PEAR) as StageLayers._Sprite
	var stove := stage.prop_node(STOVE) as StageLayers._Sprite
	if pear == null or stove == null:
		return
	if not _appearance:
		_stove_bottom = stage.to_local(stove.to_global(stove.source_point(Vector2(90.0, 287.0)))).y
		var pear_texture := pear.texture as CanvasTexture
		var stove_texture := stove.texture as CanvasTexture
		if pear_texture != null and stove_texture != null and stove.visible and not pear.visible:
			var use_normals := _tier == LightQuality.Tier.HIGH
			_appearance = (pear_texture.normal_texture != null) == use_normals and (stove_texture.normal_texture != null) == use_normals
	if pear.visible and stage.prop_held(PEAR):
		var actor := player._actors.get(&"ali") as CutsceneActor
		if actor == null:
			return
		var point := stage.to_local(pear.to_global(pear.source_point(GRIP)))
		var hand := stage.to_local(actor.hand_contact_global(&"front"))
		_contact = maxf(_contact, point.distance_to(hand))
		if not _pickup and point.x < 155.0:
			_pickup = true
			_capture_rendered.call_deferred("pickup")
		if not _above and point.x > RIM_X - 4.0 and absf(point.y - (RIM_Y - 17.0)) < 1.1:
			_above = true
			_leave_during_hold.call_deferred()
	elif _above and pear.visible:
		var pos := stage.to_local(pear.to_global(Vector2.ZERO))
		_lowest_release = maxf(_lowest_release, pos.y)
		if not _dropped and pos.y > RIM_Y - 3.5:
			_dropped = true
			_capture_rendered.call_deferred("drop")
	elif _dropped and not pear.visible:
		_hidden = true
		_closed = true
		_capture_rendered.call_deferred("inside-pot")
		var file := FileAccess.open(_out_dir.path_join("motion.json"), FileAccess.WRITE)
		file.store_string(JSON.stringify({"tier":_tier, "floor":_stove_bottom, "rim_y":RIM_Y,
				"peak_contact_error_px":_contact, "lowest_fruit_y":_lowest_release, "appearance":_appearance,
				"pickup":_pickup,"above":_above,"drop":_dropped,"hidden":_hidden}, "  ") + "\n")


func _capture_rendered(name: String) -> void:
	await RenderingServer.frame_post_draw
	_capture(name)



