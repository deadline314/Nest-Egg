from hashlib import sha256
from pathlib import Path
import json

base = Path(__file__).resolve().parent
shared = base.parent / "ne218-baseline-20261117"
root = Path.cwd()
sha = lambda path: sha256(path.read_bytes()).hexdigest()
manifest = json.loads((base / "source.json").read_bytes())
runtime = json.loads((base / "runtime.json").read_bytes())
assert all(sha(shared / path) == digest for path, digest in manifest.items())
assert all(sha(root / path) == manifest[path] for path in runtime)
author = "tools/story/ch2_stages.py"
stage = "data/cutscene/stages/ch2_ledger_xiaowei.json"
table = "data/cutscene/stage_proportions.json"
assert sha(root / table) == manifest[table]
chair = "yong_hideout__xiaowei_chair_umbrella"
bounds = [411, 223.0, 103, 4]
source_path = root / author
old = source_path.read_bytes()
anchor = b'_XIAOWEI_CHAIR_SCALE = _XIAOWEI_CHAIR["scale"]'
assert old.count(anchor) == 1
nl = b"\r\n" if b"\r\n" in old else b"\n"
source_path.write_bytes(old.replace(anchor,
    f'_XIAOWEI_CHAIR["support_rect"] = [411, _XIAOWEI_PLATFORM, 103, 4]'.encode() + nl + anchor))
stage_file = root / stage
stage_data = json.loads(stage_file.read_bytes())
layer, = (layer for layer in stage_data["layers"] if layer.get("path", "").endswith(chair + ".png"))
layer["support_rect"] = bounds
assert abs(layer["pos"][1] + 112 * layer["scale"] - bounds[1]) < 0.001
assert bounds[0] <= layer["pos"][0] and layer["pos"][0] + 128 * layer["scale"] < bounds[0] + bounds[2]
stage_file.write_text(json.dumps(stage_data, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
table_path = root / table
old = table_path.read_bytes()
anchor = b'    "ali_kitchen__soup_stove": {'
assert old.count(anchor) == 1 and chair.encode() not in old
nl = b"\r\n" if b"\r\n" in old else b"\n"
# The same painted seat row is used by the chair geometry and the seated actor.
definition = [f'    "{chair}": {{', '      "kind": "seat",', '      "body": [0.567, 1.0]', '    },']
table_path.write_bytes(old.replace(anchor,nl.join(line.encode() for line in definition)+nl+anchor))
for path in (author, stage, table):
    (shared / path).write_bytes((root / path).read_bytes())
    manifest[path] = sha(root / path)
runtime.append(table)
assert all(sha(shared / path) == digest for path, digest in manifest.items())
(base / "runtime.json").write_text(json.dumps(runtime, indent=2) + "\n", encoding="utf-8")
(base / "source.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print("Retained original stage audit failure, measured raised support, and registered the actual painted seat scale.")
