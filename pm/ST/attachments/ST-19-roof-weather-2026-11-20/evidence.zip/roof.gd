extends "res://tools/ch1_flow_probe.gd"

const ROOF := "res://data/levels/ch2_rooftop.tres"
const EGRET := &"ch2_egret"
var _main: Node
var _slot := ""
var _mode := "go"
var _sip_logged := false
var _cup_released := false
var _cup_sfx := 0
var _lowest_y := INF
var _min_cup := Vector2.INF
var _setdown_point := Vector2.INF
var _peak_sfx_db := -200.0
var _printed_arm := false
var _weather := {}


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_slot = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
	process_mode = Node.PROCESS_MODE_ALWAYS
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_shots = {"ch2_t_s03_tea":"briefing-roof-tea", "ch2_t_s22_tea":"tea-opening", "ch2_t_s22_tea:choice":"tea-choice", "ch2_t_s22_decided":"tea-decided"}
	_main = load("res://game/main.gd").new()
	_main.set("_run_store",RunSaveStore.new(_slot.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(48)
	_check(GameState.has_flag(&"ch2_egret_returned"), "uses a real restored-Egret save")
	GameState.set_flag(&"ch2_audit_submitted")
	if _mode == "known":
		GameState.set_flag(&"sq2_sunday_heard")
	var valid := StageLibrary.validate(&"ch2_rooftop_tea")
	_check(valid.is_empty(), "the real rooftop stage definition validates: " + str(valid))
	var audit := SceneAudit.audit_stages({"ch2_t_s22_greycoat": Story._scenes["ch2_t_s22_greycoat"]}, StageLibrary.definition)
	_check(audit.is_empty(), "stage proportion and support pass for the final actors: " + str(audit))
	_check(Sfx.source_of(&"ch2_roof_cup") == &"file", "the actual licensed cup audio is imported")
	Sfx.sound_played.connect(func(id: StringName) -> void:
		if id == &"ch2_roof_cup":
			_cup_sfx += 1
			var current: CutscenePlayer = Story._player
			if is_instance_valid(current) and current._stage != null:
				_cup_released = not current._stage.prop_held("rin_roof_cup")
				_setdown_point = _grip(current))
	_main.call("_on_area_requested", ROOF)
	await _settle(60)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.resource_path == ROOF, "loaded the actual rooftop in Main")
	var npc := _object(EGRET)
	_check(npc != null, "the original Egret actor is present")
	if npc == null:
		_done({})
		return
	if not GameState.has_flag(&"ch2_brief_done"):
		_check(await _talk(EGRET), "the original first rooftop briefing completes")
		_check(GameState.has_flag(&"ch2_brief_done"), "the real briefing unlocks the later roof talk")
	var scenes: Array[String] = []
	Story.scene_started.connect(func(id: StringName, _type: StringName) -> void: scenes.append(String(id)))
	_check(Story.resolve_dispatch(npc.data.talks[npc.current_talk_index()].scene) == &"ch2_t_s22_tea", "dispatches the actual S22 talk")
	_check(await _talk(EGRET,["wait" if _mode == "wait" else "go"]), "the original rooftop direction choice returns")
	await _settle(120)
	var expected := _mode != "wait"
	_check(GameState.has_flag(&"ch2_heron_closed") == expected and GameState.has_flag(&"harbor_walk_ready") == expected,
			"only confirming closes the chapter and opens the original walking link")
	_check(_cup_sfx == (1 if expected else 0), "the cue plays once only when finishing the tea")
	if expected:
		_check(_sip_logged and _lowest_y < 165.0, "the held cup reaches the intended sip position")
		_check(_cup_released and _setdown_point.distance_to(Vector2(292.56,204.18)) < 1.5,
				"the hand leaves the original cup on its tabletop contact: " + str(_setdown_point))
		_check(_peak_sfx_db > -75.0, "native mixer confirms a real signal on the SFX bus after setdown")
	if _mode == "known":
		_check(scenes.has("ch2_t_s22_sunday_known"), "the optional Sunday reply retains its original route")
	for signature: String in ["ch2_t_s03_tea/ch2_rooftop_tea", "ch2_t_s22_greycoat/ch2_rooftop_watcher",
			"ch2_t_s22_greycoat/ch2_rooftop_tea"]:
		_check(_weather.has(signature) and _weather[signature] == 1, "one visible, moving rooftop rain layer for " + signature)
	print("ROOF_WEATHER ",JSON.stringify(_weather))
	_capture("after-roof")
	print("ROOF_CASE ", JSON.stringify({"mode":_mode,"closed":GameState.has_flag(&"ch2_heron_closed"),
			"walk":GameState.has_flag(&"harbor_walk_ready"),"scenes":scenes, "sip":str(_min_cup),"setdown":str(_setdown_point),"cue":_cup_sfx,"peak_db":_peak_sfx_db}))
	_done({"mode":_mode,"closed":GameState.has_flag(&"ch2_heron_closed"),"walk":GameState.has_flag(&"harbor_walk_ready"),"scenes":scenes, "sip":str(_min_cup),"setdown":str(_setdown_point),"cue":_cup_sfx,"peak_db":_peak_sfx_db})


func _done(result: Dictionary) -> void:
	result["failures"] = _failures
	FileAccess.open(_out_dir.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify(result,"  "))
	get_tree().quit(0 if _failures == 0 else 1)


func _process(_delta: float) -> void:
	if _cup_sfx > 0:
		var bus := AudioServer.get_bus_index(&"SFX")
		_peak_sfx_db = maxf(_peak_sfx_db, AudioServer.get_bus_peak_volume_left_db(bus,0))
	var player: CutscenePlayer = Story._player
	if not is_instance_valid(player) or not is_instance_valid(player._stage):
		return
	var stage := player._stage
	var signature := "%s/%s" % [player.scene_id,stage.stage_id]
	if stage.stage_id in [&"ch2_rooftop_tea",&"ch2_rooftop_watcher"] and not _weather.has(signature):
		var matching := 0
		for layer in stage.front.get_children():
			if layer is StageLayers._Rain and layer.is_visible_in_tree() and layer.is_processing() and layer._drops.size() > 0 and layer._color.a > 0.0:
				matching += 1
		if matching > 0:
			_weather[signature] = matching
	if player.scene_id != &"ch2_t_s22_greycoat":
		return
	if not _printed_arm and player._current_where.contains("第 32 步"):
		var rin: CutsceneActor = player._actors.get(&"rin")
		if is_instance_valid(rin):
			_printed_arm = true
			var model := rin.rig
			var skeleton: Skeleton2D = model.get("_skeleton")
			var shoulder := model.bone(&"arm_front_upper")
			var shoulder_scene := player._stage.to_local(shoulder.global_position)
			var offset := model.hand_source_point(&"front", Vector2(96.5,37.5))
			var arm_length := model.rest(&"arm_front_lower").length() + model.rest(&"hand_front").length()
			var origin := skeleton.to_local(shoulder.global_position)
			print("ARM_PROBE ", JSON.stringify({"feet":str(rin.position),"shoulder":str(shoulder_scene),"offset":str(offset),
				"length":arm_length,"skel_scale":str(skeleton.global_scale), "stage_scale":str(player._stage.global_scale),"pose":rin.pose}))
			for sample: Array in [["cup",Vector2(292.56,204.18),PI/4], ["mouth",Vector2(269,154),-PI/4],
					["cup-nearest",Vector2(292.56,204.18),PI/2], ["mouth-out",Vector2(279,166),-PI/4]]:
				var target := skeleton.to_local(player._stage.to_global(sample[1]))
				var direction := skeleton.global_transform.affine_inverse().basis_xform(player._stage.global_transform.basis_xform(Vector2.from_angle(sample[2]))).angle()
				print("ARM_TARGET ",sample[0]," ",origin.distance_to(target-offset.rotated(direction)))
	if not player._stage.prop_held("rin_roof_cup"):
		return
	var point := _grip(player)
	if point.y < _lowest_y:
		_lowest_y = point.y
		_min_cup = point
	if not _sip_logged and point.y <= 154.08:
		_sip_logged = true
		_capture("cup-lifted")


func _grip(player: CutscenePlayer) -> Vector2:
	var prop := player._stage.prop_node("rin_roof_cup") as StageLayers._Sprite
	if not is_instance_valid(prop):
		return Vector2.INF
	return player._stage.to_local(prop.to_global(prop.source_point(Vector2(126,234))))

