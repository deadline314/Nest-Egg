extends "res://tests/smoke_test.gd"

func _frames(count: int) -> void:
	await super._frames(count)
	if count == 2:
		# Model a slow observer independently of how quickly the test host renders.
		var player := get_child(get_child_count() - 1) as CutscenePlayer
		if is_instance_valid(player):
			await player.finished
		await get_tree().process_frame
		await get_tree().process_frame


func _run() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	var use_candidate := "--candidate" in OS.get_cmdline_user_args()
	var suite: CutsceneSuite = preload("candidate.gd").new(self) if use_candidate else CutsceneSuite.new(self)
	await suite._test_overlay_and_layers()
	_check(_checks == 11, "all overlay and layer assertions were reached")
	await _finish()
