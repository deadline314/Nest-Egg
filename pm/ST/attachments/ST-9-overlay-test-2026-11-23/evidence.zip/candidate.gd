extends CutsceneSuite


func _test_overlay_and_layers() -> void:
	_finished_ids.clear()
	var overlay := {"overlay": true, "steps": [{"do": "fx", "kind": "noise", "time": 0.1}, {"do": "wait", "time": 0.1}]}
	check(CutsceneChecker.validate("overlay", overlay, _speakers()).is_empty(), "疊加演出不需要舞台也能通過檢查")
	var player := _play(&"test_overlay", overlay, 1.0)
	# play() builds the overlay immediately; a short scene can finish before another frame.
	var backdrop := player._root.get_child(0) as ColorRect
	check(backdrop.color.a == 0.0 and player._fade.color.a == 0.0, "疊加演出不蓋黑底，遊戲畫面看得到")
	player.speed = 40.0
	check(await _wait_finished(&"test_overlay"), "疊加演出播完")

	var counter := StageLayers.create({"kind": "counter", "pos": [0, 0], "from": 10, "to": 20, "time": 1.0}, "test counter")
	check(counter != null and counter.call("current") == 10, "計數器從起始值開始")
	counter.call("_process", 0.5)
	check(counter.call("current") == 15, "計數器隨時間往上數")
	counter.call("_process", 5.0)
	check(counter.call("current") == 20, "計數器停在終點")
	counter.free()

	var motes := StageLayers.create({"kind": "motes", "count": 12, "area": [10, 20, 100, 50]}, "test motes")
	check(motes != null and motes.get("_points").size() == 12, "塵粒圖層建立固定數量的粒子")
	motes.call("_process", 30.0)
	var inside := true
	for point: Vector2 in motes.get("_points"):
		inside = inside and point.x >= 0.0 and point.x <= 100.0 and point.y >= 0.0 and point.y <= 50.0
	check(inside, "塵粒漂移後仍在指定範圍內（循環使用，不配置新物件）")
	motes.free()
	var pulsing := StageLayers.create({"kind": "glow", "pos": [0, 0], "radius": 20, "color": "#ff3322", "pulse": 1.0, "pulse_depth": 0.8}, "test pulse")
	var bright: float = pulsing.self_modulate.r
	pulsing.call("_process", 0.25)
	check(pulsing.self_modulate.r < bright * 0.5, "脈動的柔光在週期的一半暗下來")
	pulsing.free()

	var sprite := StageLayers.create({"kind": "sprite", "path": "res://art/environment/props/window_rain.png", "pos": [0, 0], "scale": 0.5}, "test sprite")
	check(sprite != null and sprite.get_child_count() == 1, "道具貼圖附帶自發光層")
	sprite.free()
	var plain := StageLayers.create({"kind": "sprite", "path": "res://art/environment/props/trash_can.png", "pos": [0, 0]}, "test sprite")
	check(plain != null and plain.get_child_count() == 0, "沒有自發光層的道具不加多餘節點")
	plain.free()
