extends ScenarioBase

const LEVEL_PATH := "res://data/levels/ch3_showroom.tres"
const QUIET_WINDOW := &"ch3_window_quiet"
const DAY := &"showroom_day"
const QUIET := &"showroom_quiet"

var _tag := ""
var _records: Dictionary = {}
var _zones: Array[String] = []
var _sounds: Array[String] = []
var _record := AudioEffectRecord.new()
var _ambience_bus := -1
var _record_slot := -1


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\","/")
		elif argument.begins_with("--tag="):
			_tag = argument.trim_prefix("--tag=")
	if not out_dir.is_absolute_path() or _tag not in ["before", "after"] or AudioServer.get_driver_name().to_lower() == "dummy":
		push_error("showroom probe requires an absolute output path, a variant and actual audio driver")
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	_ambience_bus = AudioServer.get_bus_index(Ambience.BUS)
	_record_slot = AudioServer.get_bus_effect_count(_ambience_bus)
	AudioServer.add_bus_effect(_ambience_bus, _record)
	EventBus.zone_changed.connect(func(id: StringName) -> void: _zones.append(String(id)))
	Ambience.layer_started.connect(func(id: StringName) -> void: _sounds.append(String(id)))
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch3_clearwater_tour_started", true, false)
	level = Level.new()
	level.configure(load(LEVEL_PATH) as LevelData)
	add_child(level)
	player = level.player
	level.hud.visible = false
	_check(_ambience_bus >= 0 and Ambience.enabled, "room tone uses the enabled ambience settings bus")
	var window := _find_window()
	if window == null:
		push_error("the official showroom is missing its quiet-window interaction")
		get_tree().quit(2)
		return
	player.global_position = Vector2(512, window.global_position.y)
	player.velocity = Vector2.ZERO
	await settle(20)
	await _sample("morning", DAY)
	await _walk_to(736)
	await _sample("quiet", QUIET if _tag == "after" else DAY)
	var credits := Progression.credits
	_check(window.interaction_available(), "the quiet measurement is available from the original location")
	_check(await window._talk() and GameState.has_flag(&"room_quiet_measured"), "real window measurement saves its original result")
	_check(Progression.credits == credits and not GameState.has_flag(&"sq3_room_proposal_done"), "room sound does not affect proposal or wallet")
	await _walk_to(960)
	await _sample("late", DAY)
	await _walk_to(736)
	await _sample("quiet_return", QUIET if _tag == "after" else DAY)
	await _walk_to(512)
	await _sample("morning_return", DAY)
	var expected := ["showroom_day", "showroom_quiet", "showroom_day", "showroom_quiet", "showroom_day"] if _tag == "after" else ["showroom_day"]
	_check(_zones == expected, "walk emits the expected five or one zone changes without repeated events")
	var expected_sounds := ["amb_wind", "amb_ventilation", "amb_wind", "amb_ventilation", "amb_wind"] if _tag == "after" else ["amb_wind"]
	_check(_sounds == expected_sounds, "each transition launches only one authored ambient layer")
	var report := {"adapter": RenderingServer.get_video_adapter_name(), "audio_driver":AudioServer.get_driver_name(),
		"renderer": RenderingServer.get_current_rendering_method(), "failures":failures, "zones":_zones.duplicate(),
		"sounds":_sounds.duplicate(), "samples":_records}
	AudioServer.remove_bus_effect(_ambience_bus, _record_slot)
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	AssetPrefetch.clear()
	await settle(20)
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(report,"\t"))
	get_tree().quit(0 if failures == 0 else 1)


func _find_window() -> NpcActor:
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		var npc := node as NpcActor
		if npc != null and npc.data.id == QUIET_WINDOW:
			return npc
	return null


func _walk_to(x: float) -> void:
	var action := &"move_right" if x > player.global_position.x else &"move_left"
	var direction := 1.0 if action == &"move_right" else -1.0
	Input.action_press(action)
	for frame in range(250):
		if (x - player.global_position.x) * direction < 3.0:
			break
		await get_tree().physics_frame
	Input.action_release(action)
	await settle(5)
	_check(absf(player.global_position.x - x) < 10, "normal movement reaches showroom sample %s" % x)


func _sample(name: String, zone: StringName) -> void:
	await wait(2.25)
	_check(level._lighting.zone_id_at(player.global_position.x) == zone and Ambience.current_zone() == zone, "lighting and ambience agree at " + name)
	_check(Ambience.playing_layers() == 1, "only one ambient layer remains after the transition at " + name)
	var layers := Ambience.layers_for(zone)
	if layers.size() != 1:
		return
	var sound := StringName(str(layers[0].get("sound", "")))
	_check(sound == (&"amb_ventilation" if zone == QUIET else &"amb_wind"), "actual zone uses the intended recorded sound at " + name)
	var active := Ambience.layer_player(0).current_stream()
	var variants := Sfx.bank().variants(sound)
	_check(not variants.is_empty() and active != null and absf(active.get_length() - variants[0].get_length()) < 0.001, "actual playback uses the configured stream at " + name)
	_record.set_recording_active(true)
	await wait(1.2)
	_record.set_recording_active(false)
	await settle(2)
	var sample := _record.get_recording()
	_check(sample != null and sample.get_length() >= 0.8, "WASAPI provides PCM data for " + name)
	if sample == null:
		return
	_check(sample.save_to_wav(out_dir.path_join(name + ".wav")) == OK, "save ambience bus recording " + name)
	var color := level._lighting.current.ambient_color
	_records[name] = {"zone":String(zone),"sound":String(sound),"x":player.global_position.x,
		"ambient": [color.r,color.g,color.b], "volume_db": layers[0]["volume_db"],
		"recording_seconds":sample.get_length(), "active_stream_length":active.get_length()}
	await RenderingServer.frame_post_draw
	capture(name)


func _check(condition: bool, message: String) -> void:
	if not condition:
		failures += 1
		push_error(message)
