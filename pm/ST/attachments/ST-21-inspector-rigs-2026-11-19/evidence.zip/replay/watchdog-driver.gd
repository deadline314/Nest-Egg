extends "res://tools/scenarios/watchdog_fight_scenario.gd"


func use_current_fight(active_level: Level, dog: PatternBoss) -> void:
	level = active_level
	player = level.player
	_dog = dog
	_use_pad = true
	AimInput.set_virtual_gamepad(player, true)
	player.health.damaged.connect(_on_player_damaged)
	_dog.health.damaged.connect(_on_dog_damaged)


func drive_frame() -> void:
	_elapsed += get_physics_process_delta_time()
	if GameState.difficulty.id == &"hardcore" and not _dog.is_leashed():
		var incoming := _dog.hurtbox.center() - player.aim_origin()
		if absf(incoming.x) < 56.0 and absf(incoming.y) < 45.0 and player._dash_cooldown_left > 0.0:
			Input.action_release(&"shoot")
			Input.action_release(&"dash")
			Input.action_release(&"jump")
			_set_stick(incoming.normalized())
			Input.action_press(&"block")
			_set_action(&"move_left", incoming.x > 0.0)
			_set_action(&"move_right", incoming.x < 0.0)
			return
	Input.action_release(&"block")
	_drive()


func release_driver() -> void:
	_release_all()
	Input.action_release(&"block")
	if is_instance_valid(player):
		AimInput.set_virtual_gamepad(player, false)
	print("NE97_WATCHDOG totals hit_count=", _hits_taken, ", damage=", _damage_taken, ", back_hits=", _back_hits)
