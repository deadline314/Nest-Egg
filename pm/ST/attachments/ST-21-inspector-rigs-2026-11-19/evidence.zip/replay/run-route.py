from pathlib import Path
from shutil import copyfile
import json
import os
import subprocess
import sys

root = Path.cwd()
base = root / 'work/ne97-campaign-route-20261119'
out = base / sys.argv[1]
out.mkdir()
mode = sys.argv[3] if len(sys.argv)>3 else 'street'
fresh = mode == 'fresh'
profile = out / 'profile'
save = out / 'save'
save.mkdir()
if not fresh:
    prior = base/sys.argv[2]/'save' if len(sys.argv)>2 else base/'headless-second-save'
    for member in prior.glob('slot.json*'):
        copyfile(member, save/member.name)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
env = os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key] = str(profile/key)
scene = 'ch3-live-route.tscn' if mode.startswith('ch3-') and mode != 'ch3-cold' else 'combat-route.tscn'
entry = [] if fresh else ['--from-save']
cmd = [sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',engine,'--path',str(shared),
       '--rendering-method','forward_plus','--rendering-driver','vulkan','--audio-driver','Dummy',
       '--resolution','1280x720','--fixed-fps','60','--quit-after','18000',(base/scene).as_posix(),
       '--',*entry,'--'+mode,f'--out={out.as_posix()}',f'--save-dir={save.as_posix()}'] + sys.argv[4:]
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'raw.log').open('wb') as log:
    result = subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=220)
raw = (out/'raw.log').read_text(encoding='utf-8',errors='replace')
print(raw[-8500:],flush=True)
print('exit=',result.returncode,flush=True)
sys.exit(result.returncode)
