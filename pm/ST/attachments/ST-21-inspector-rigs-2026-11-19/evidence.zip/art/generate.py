from pathlib import Path
import subprocess
import sys

root = Path.cwd()
tool = root / 'tools/comfyui/creature_art.py'
pieces = (
    ('pump_inspector', 'body', 23021, (832, 640),
     'A compact obsolete industrial drainage patrol machine, an extremely low wide chassis, exact orthographic left flank with front facing right. A short squared-off wedge bumper on its right, two soot-dark rectangular intake vents and repainted muted rust orange armor with chipped dark graphite edges. One small amber slit set into the right facing bumper, no aura. The bottom is a continuous flat dark graphite undersill with two obvious mechanical mounting sockets for the missing track assembly. The housing is fully drawn, but NO wheels, NO tracks, NO legs and no loosely floating parts. Wide low silhouette, approximately twice as wide as it is tall. Low saturation, two flat shadow tones, clean dark outlines and opaque pigment. No ground, no lettering, no shadows outside the object, no perspective, no separate figures.'),
    ('pump_inspector', 'track', 23022, (832, 512),
     'One single compact continuous tank-tread assembly for a small heavy sewer maintenance machine, orthographic strict side view facing right. End outline is a shallow rounded trapezoid with flat bottom; one dark rubber belt wraps three rigid steel rollers at the same height, fully connected. One small recessed hub in the center of each roller. Smudged gray graphite and muted silver, low saturation, hard outline and two flat hard-edge shadows, no neon. Long shallow shape, approximately four times wider than tall. Show only the indivisible tread assembly, no large machine housing above, no second track, no ground, no text, no external shadows and no separate parts.'),
    ('insulation_inspector', 'carriage', 23023, (704, 768),
     'An old industrial rail-mounted electrical insulation inspection carriage, strict orthographic left-flank side elevation front right. Compact upright box profile about three quarters as wide as tall. At the very top two small dark round rollers clamp a rail that is outside the drawing, rollers touch a dull gray rectangular top bracket. Downward sequence of two dull pale celadon ceramic insulating ribs, enclosed in a slate gray enclosure, one subtle oxidized teal badge stripe, then a compact hard cable collar dead center on the bottom. End at collar, no loose line, no suspended probe, no emitter, no background rail, no ground and no detached items. Heavy black edge, low saturation, two hard-edge shadow tones and restrained worn surfaces. Tiny machine used to test electrical insulation, not a gun. No perspective, text, light bloom or floating parts.'),
    ('insulation_inspector', 'probe', 23024, (704, 576),
     'One single compact electrical tester probe head, orthographic exact side view with the tip facing right. A short light gray ceramic block with rounded outer corners, two muted dark teal fins enclosed within its silhouette, one small amber tip molded flush with the right face and a small cable socket at the center of the top. Wide low profile, the probe is less than twice as wide as tall. It is a contact tester, not a firearm. Low saturation, two flat shadow tones and heavy dark contour. No cable, beam, glow, gun barrel, perspective, detached shapes, ground or text.'),
    ('pump_inspector', 'body', 23025, (768, 640),
     'One compact industrial mobile drainage pump housing, precisely flat side elevation, front faces right. Boxy centered squared tank and closed motor cover stand high above the lower chassis, nearly as tall as the width of its central panel. Overall object width only about 1.8 times its height. A heavy battered dark orange central motor box above a continuous graphite horizontal bottom sill, two squared vent panels, side-mounted rusted flanges set flat against the box, a small short blunt right bumper with a single recessed amber sensor. Fully connected thick black silhouette with low-saturation orange and two hard-edge shadow tones. The dark sill has two exposed circular mounting sockets, the tread assembly is removed, no wheels, no legs, no track, no ground, no bloom, no lettering and no perspective.'),
)

for creature, part, seed, (width, height), prompt in pieces:
    print(creature, part, seed, flush=True)
    subprocess.run([sys.executable, '-B', str(tool), '--id', creature, '--part', part,
                    '--seed', str(seed), '--size', str(width), str(height), '--prompt', prompt], cwd=root, check=True)
