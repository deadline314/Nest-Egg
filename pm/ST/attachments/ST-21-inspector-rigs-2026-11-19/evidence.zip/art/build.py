from hashlib import sha256
import json
from pathlib import Path
import sys

from PIL import Image

root = Path.cwd()
scratch = Path(__file__).resolve().parent
source = root / 'art_src/creatures'
output = scratch / 'compiled'
sys.path.insert(0, str(root / 'tools/art'))
from make_creature_parts import clean

parts = {
    'pump_inspector': [('body', 23021, (106, 53), [53, 53], [0, -4.5], 1),
                       ('track', 23022, (98, 24), [49, 24], [0, 0], 0)],
    'insulation_inspector': [('carriage', 23023, (64, 104), [32, 104], [0, 0], 0),
                             ('probe', 23024, (40, 27), [20, 13], [0, 6], 1)],
}


def sway(part, prop, base=0.0, amp=0.0, freq=1.0, vfreq=0.0):
    return {'part': part, 'prop': prop, 'base': base, 'amp': amp, 'freq': freq, 'vfreq': vfreq}


states = {
    'pump_inspector': {
        'patrol': [sway('body', 'y', amp=0.16, freq=2.0, vfreq=4.0)],
        'windup': [sway('body', 'rot', base=0.04, amp=0.012, freq=11.0), sway('body', 'y', base=0.45)],
        'ram': [sway('body', 'x', base=0.45, amp=0.13, freq=17.0), sway('body', 'rot', base=0.065)],
        'recover': [sway('body', 'rot', base=-0.045), sway('body', 'y', base=0.55)],
        'dead': [sway('body', 'rot', base=-0.09), sway('body', 'y', base=0.9)],
    },
    'insulation_inspector': {
        'idle': [],
        'charge': [sway('carriage', 'x', amp=0.14, freq=14.0)],
        'recover': [sway('carriage', 'x', amp=0.1, freq=6.0)],
        'dead': [sway('carriage', 'rot', base=-0.09)],
    },
}

records = {}
for ident, config in parts.items():
    target = output / ident
    target.mkdir(parents=True, exist_ok=True)
    entries = []
    for part, seed, size, pivot, position, z in config:
        path = source / ident / f'{part}_s{seed}.png'
        with Image.open(path) as raw:
            assert raw.mode == 'RGBA' and raw.getchannel('A').getextrema() == (0, 255)
            cropped = clean(raw)
            cropped.resize(size, Image.Resampling.LANCZOS).save(target / f'{part}.png')
            records[f'{ident}/{part}'] = {'source': path.relative_to(root).as_posix(),
                'sha256': sha256(path.read_bytes()).hexdigest(), 'native': raw.size, 'crop': cropped.size,
                'texture': size, 'pivot': pivot, 'world_position': position, 'seed': seed}
        entries.append({'name': part, 'file': f'{part}.png', 'pivot': pivot, 'pos': position, 'z': z})
    rig = {'dir': f'res://art/creatures/{ident}/', 'texture_scale': 0.25, 'parts': entries,
           'gait': {'full_speed': 38 if ident == 'pump_inspector' else 70},
           'states': {name: {'channels': channels} for name, channels in states[ident].items()}}
    (output / f'{ident}.json').write_text(json.dumps(rig, indent=1) + '\n', encoding='utf-8')
(output / 'sources.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf-8')
print(json.dumps(records), flush=True)
