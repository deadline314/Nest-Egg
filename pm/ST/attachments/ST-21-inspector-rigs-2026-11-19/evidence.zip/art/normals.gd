extends SceneTree

const FOLDERS := ["pump_inspector", "insulation_inspector"]


func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size() != 1:
		quit(2)
		return
	var written := 0
	for folder in FOLDERS:
		var directory := args[0].path_join(folder)
		for file in DirAccess.get_files_at(directory):
			if not file.ends_with(".png") or file.ends_with("_n.png"):
				continue
			var image := Image.load_from_file(directory.path_join(file))
			if image == null or NormalMapMaker.make(image).save_png(directory.path_join(file.trim_suffix(".png") + "_n.png")) != OK:
				quit(1)
				return
			written += 1
	print("generated %d creature normals" % written)
	quit(0 if written == 4 else 1)
