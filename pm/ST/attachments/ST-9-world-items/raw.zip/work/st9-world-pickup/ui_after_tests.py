from pathlib import Path
import time,json,subprocess,hashlib
w=Path.cwd()/'work/st9-world-pickup';deadline=time.monotonic()+1800
while not (w/'changed-receipt.json').exists():
 assert time.monotonic()<deadline
 time.sleep(1)
assert json.loads((w/'changed-receipt.json').read_text())['exit_code']==0
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
(w/'ui-frozen-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['work/st9-world-pickup/ui_probe.gd','work/st9-world-pickup/ui_probe.tscn','work/st9-world-pickup/probe.gd','ui/radio_save_prompt.gd','game/world_item_completion.gd']},indent=2))
with (w/'ui-native-driver.log').open('w') as f:r=subprocess.run(['python',str(w/'ui_native.py')],stdout=f,stderr=subprocess.STDOUT,timeout=2200)
print('ui native',r.returncode,flush=True)
