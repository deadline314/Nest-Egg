from pathlib import Path
import os,subprocess,json
w=Path.cwd()/'work/st9-world-pickup';env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen';rows=[]
for label,args in [('en',['--language=en','--cancel-case']),('ja',['--language=ja','--postcommit-case']),('zh1080',['--1080','--rollback-case'])]:
 n='st9-1022-world-item-ui-'+label+'-v1';cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',n,'res://work/st9-world-pickup/ui_probe.tscn','--mode=write','--save-dir='+str(w/('ui-'+label+'-save')),*args]
 with (w/('ui-'+label+'-wrapper.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=700)
 rows.append({'label':label,'name':n,'command':cmd,'exit_code':r.returncode});(w/'ui-native-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);assert r.returncode==0
