from pathlib import Path
import subprocess,os,json,hashlib,time
root=Path.cwd();w=root/'work/st9-world-pickup';env=os.environ.copy();env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='6',LOG_DIR=str(w/'changed-shards'))
rows=json.loads((w/'native-receipt.json').read_text());assert len(rows)==5 and all(r['exit_code']==r['expected'] for r in rows)
for p,h in json.loads((w/'native-frozen-source.json').read_text()).items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
with (w/'uid.log').open('w') as f:r=subprocess.run([env['GODOT'],'--headless','--path',str(root),'--script','res://work/st9-world-pickup/make_uid.gd'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
assert r.returncode==0 and 'SCRIPT ERROR:' not in (w/'uid.log').read_text()
files=['game/main.gd','autoload/story_items.gd','game/pickups/pickup.gd','game/pickups/collectible_pickup.gd','ui/radio_save_prompt.gd','game/world_item_completion.gd','game/world_item_completion.gd.uid','work/st9-world-pickup/probe.gd','work/st9-world-pickup/phone_base.gd','tools/quest_resume_probe.gd']
(w/'verification-frozen-source.json').write_text(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files},indent=2))
cmd=['tools/run_tests_changed.sh','157c5de2'];start=time.monotonic()
with (w/'changed.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
(w/'changed-receipt.json').write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2));print(r.returncode,flush=True)
