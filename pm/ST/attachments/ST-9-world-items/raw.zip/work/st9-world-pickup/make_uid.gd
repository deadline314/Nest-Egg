extends SceneTree
func _initialize() -> void:
	var path := "res://game/world_item_completion.gd.uid"
	if not FileAccess.file_exists(path):
		var file := FileAccess.open(path,FileAccess.WRITE)
		file.store_line(ResourceUID.id_to_text(ResourceUID.create_id()))
	quit()
