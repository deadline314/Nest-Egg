from pathlib import Path
import os,subprocess,json,hashlib,shutil
root=Path.cwd();w=root/'work/st9-world-pickup';env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1022/kitchen';rows=[]
files=['game/main.gd','autoload/story_items.gd','game/pickups/pickup.gd','game/pickups/collectible_pickup.gd','ui/radio_save_prompt.gd'];final={p:(root/p).read_bytes() for p in files};mapping={'game/main.gd':'main-before.gd','autoload/story_items.gd':'story_items-before.gd','game/pickups/pickup.gd':'pickup-before.gd','game/pickups/collectible_pickup.gd':'collectible-before.gd'}
(w/'native-frozen-source.json').write_text(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files+['game/world_item_completion.gd','work/st9-world-pickup/probe.gd','work/st9-world-pickup/phone_base.gd','tools/quest_resume_probe.gd']},indent=2))
def run(label,args,mode='write',saved=None,expected=0):
 name='st9-1022-world-item-'+label+'-v1';saved=saved or w/(label+'-native-save');cmd=['python','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/st9-world-pickup/probe.tscn','--mode='+mode,'--save-dir='+str(saved),*args]
 with (w/(label+'-native-wrapper.log')).open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=700)
 rows.append({'label':label,'name':name,'command':cmd,'exit_code':r.returncode,'expected':expected});(w/'native-receipt.json').write_text(json.dumps(rows,indent=2));print(label,r.returncode,flush=True);assert r.returncode==expected
try:
 for p,n in mapping.items():(root/p).write_bytes((w/n).read_bytes())
 (root/'ui/radio_save_prompt.gd').write_bytes(subprocess.check_output(['git','show','157c5de2:ui/radio_save_prompt.gd']))
 run('before',[],expected=1)
finally:
 for p,b in final.items():(root/p).write_bytes(b)
run('accepted',['--cancel-case','--listener-case'])
saved=w/'accepted-native-save';shutil.copytree(saved,w/'accepted-native-frozen');(w/'native-cold-source.json').write_text(json.dumps({'writer_sha256':hashlib.sha256((saved/'slot.json').read_bytes()).hexdigest(),'frozen_sha256':hashlib.sha256((w/'accepted-native-frozen/slot.json').read_bytes()).hexdigest()},indent=2))
run('continue',[],mode='continue',saved=saved)
run('committed',['--postcommit-case'])
run('original',['--rollback-case'])
