extends "res://work/st9-world-pickup/probe.gd"
func _ready() -> void:
	var language:="zh"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--language="):language=arg.trim_prefix("--language=")
	_check(Story.set_language(language),"actual story language accepted: "+language)
	Settings.set_ui_text_scale(1.2)
	if OS.get_cmdline_user_args().has("--1080"):
		get_window().size=Vector2i(1920,1080)
	super._ready()

func _shot(label: String) -> void:
	await super._shot(label)
	if not rows.is_empty():
		rows[-1]["language"]=Story.language
		rows[-1]["text_scale"]=Settings.get_ui_text_scale()
		rows[-1]["window_size"]=[get_window().size.x,get_window().size.y]
	_save_report()
