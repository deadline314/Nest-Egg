from pathlib import Path
import subprocess,os,json,time,sys
root=Path.cwd();work=root/'work/st9-world-pickup';name=sys.argv[1];out=work/name;out.mkdir();env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',XDG_DATA_HOME=str(out/'profile'),XDG_CONFIG_HOME=str(out/'profile'),XDG_CACHE_HOME=str(out/'profile'))
cmd=['/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64','--headless','--path',str(root),'res://work/st9-world-pickup/probe.tscn','--','--mode=write','--save-dir='+str(out/'save'),'--out='+str(out)]+sys.argv[2:]
start=time.monotonic()
with (work/(name+'.log')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=200)
(work/(name+'-receipt.json')).write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2));print(name,r.returncode);assert 'SCRIPT ERROR:' not in (work/(name+'.log')).read_text(), 'script errors invalidate all counters'
