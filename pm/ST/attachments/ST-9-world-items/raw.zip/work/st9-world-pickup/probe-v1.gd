extends "res://work/st9-world-pickup/phone_base.gd"
const WAREHOUSE := "res://data/levels/ch1_warehouse.tres"
var before_disk := PackedByteArray()
var observed: Array = []

func _shot(label: String) -> void:
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		_check(preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(out.path_join(label + ".png")) == OK, "capture " + label)
	rows.append({"name":label,"owned":StoryItems.owns(&"ch1_data_disk"),"held":StoryItems.holds(&"ch1_data_disk"),"flag":GameState.has_flag(&"ledger_disk_obtained"),"paused":get_tree().paused})
	_save_report()

func _save_report() -> void:
	FileAccess.open(out.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify({"completed":_completed,"failures":_failures,"mode":_mode,"rows":rows,"notifications":observed,"scope":"actual Main and authored warehouse disc pickup; declared prerequisite route flags and player position, not route combat or whole chapter"},"\t"))

func _write() -> void:
	DirAccess.make_dir_recursive_absolute(out)
	await _until(func() -> bool:return not bool(_main.call("_route_pending")))
	_main.call("_on_start_requested",GameState.difficulties[1])
	_check(await _wait_level(PROLOGUE),"actual Main new run")
	await _skip_cinematics()
	for flag in [&"ch1_prologue_exit",&"ch1_dinner_done",&"ch1_heard_brief",&"ch1_street_route_open",&"watchdog_defeated",&"ch1_flood_gate_open"]:
		GameState.set_flag(flag)
	await _enter(WAREHOUSE)
	await _read_to_end()
	var pickup:CollectiblePickup
	for node in _level().find_children("*","",true,false):
		if node is CollectiblePickup and node.item.id==&"ch1_data_disk":pickup=node
	_check(pickup!=null,"actual authored disc pickup exists")
	if pickup==null:return
	_check(not StoryItems.owns(&"ch1_data_disk") and not GameState.has_flag(&"ledger_disk_obtained"),"target acquisition has not been injected")
	_main.call("_save_run")
	before_disk=FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json"))
	_check(not before_disk.is_empty(),"real baseline slot exists")
	StoryItems.acquired.connect(func(item:StoryItemData)->void:
		if item.id==&"ch1_data_disk":observed.append({"item":String(item.id),"disk_changed":FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json"))!=before_disk,"flag":GameState.has_flag(&"ledger_disk_obtained")}) )
	_check(DirAccess.make_dir_absolute(_save_dir.path_join("slot.json.tmp"))==OK,"real temp-file directory blocks save")
	_level().player.health.nonlethal_floor=1
	_level().player.global_position=pickup.global_position
	_level().player.velocity=Vector2.ZERO
	await get_tree().create_timer(0.65,true,false,true).timeout
	_check(not StoryItems.owns(&"ch1_data_disk") and not StoryItems.holds(&"ch1_data_disk"),"failed write keeps disc out of backpack")
	_check(not GameState.has_flag(&"ledger_disk_obtained"),"failed write keeps disc objective unfinished")
	_check(is_instance_valid(pickup) and not pickup.is_queued_for_deletion(),"failed write leaves actual pickup in world")
	_check(observed.is_empty(),"failed write announces no acquired item")
	_check(FileAccess.get_file_as_bytes(_save_dir.path_join("slot.json"))==before_disk,"failed write preserves original slot bytes")
	await _shot("write-refused")
	DirAccess.remove_absolute(_save_dir.path_join("slot.json.tmp"))
	_completed=true
	_save_report()
