from pathlib import Path
import subprocess,json,hashlib,zipfile,shutil
root=Path.cwd();w=root/'work/st9-world-pickup';out=root/'pm/ST/attachments/ST-9-world-items';out.mkdir(parents=True,exist_ok=True);base=Path('/workspace/Nest-Egg/work/batch1020b');sha=lambda b:hashlib.sha256(b).hexdigest();files={}
receipt=json.loads((w/'changed-receipt.json').read_text());assert receipt['exit_code']==0
for p,h in json.loads((w/'verification-frozen-source.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
for p,h in json.loads((w/'ui-frozen-source.json').read_text()).items():assert sha((root/p).read_bytes())==h,p
for p in ['tests','tools/run_tests_changed.sh','tools/run_tests_parallel.sh','tools/select_tests.py','tools/test_filters.sh']:
 assert not subprocess.check_output(['git','diff','--name-only','157c5de2','--',p]).strip(),p
rows=json.loads((w/'native-validation.json').read_text());assert all(r['completed'] and r['engine_errors']==0 and r['leaks']==0 and r['all_pngs_individually_viewed'] for r in rows);assert [r['failures'] for r in rows]==[5,0,0,0,0]
ui=json.loads((w/'ui-native-validation.json').read_text());assert len(ui)==3 and all(r['completed'] and r['failures']==0 and r['engine_errors']==0 and r['leaks']==0 and r['all_pngs_individually_viewed'] for r in ui)
cold=json.loads((w/'native-cold-source.json').read_text());assert cold['writer_sha256']==cold['frozen_sha256']==sha((w/'accepted-v2-native-frozen/slot.json').read_bytes())
for p in w.rglob('*'):
 if p.is_file() and p.name!='package-receipt.json' and not any('profile' in x or x=='__pycache__' for x in p.relative_to(w).parts):files['work/st9-world-pickup/'+str(p.relative_to(w))]=p.read_bytes()
for d in sorted(base.glob('st9-1022-world-item*')):
 if d.is_dir() and not d.name.endswith('-profile'):
  for p in d.rglob('*'):
   if p.is_file():files['native/'+d.name+'/'+str(p.relative_to(d))]=p.read_bytes()
 elif d.is_file():files['native/'+d.name]=d.read_bytes()
paths=['game/main.gd','autoload/story_items.gd','game/pickups/pickup.gd','game/pickups/collectible_pickup.gd','ui/radio_save_prompt.gd','game/world_item_completion.gd','game/world_item_completion.gd.uid','tools/quest_resume_probe.gd','tools/viewport_capture.gd','game/level/level.gd','core/run_save_store.gd','core/run_snapshot.gd','core/story_install_bundle.gd','data/story_items/ch1_data_disk.tres','data/levels/ch1_vault.tres','data/levels/ch1_vault_map.json','work/.gdignore','design/20-campaign-experience/WORLD_ITEM_COMPLETION.md']
for p in paths:files['source/final/'+p]=(root/p).read_bytes()
for p in paths[:5]:files['source/before/'+p]=subprocess.check_output(['git','show','157c5de2:'+p])
for p in (root/'pm/Nest-Egg/attachments/NE-278-references').iterdir():
 if p.is_file():files['references/'+p.name]=p.read_bytes()
text=(w/'changed.log').read_text();assert 'new failures: 0' in text and 'Detected script errors' not in text
validation={'base':'157c5de279d8db117afc34376fcaf27bbb4dbb53','affected_receipt':receipt,'affected_summary':[l for l in text.splitlines() if 'checks:' in l or 'Running 63' in l],'original_tests_harness_filters_known_failures_unchanged':True,'headless_before':{'checks':12,'failures':4,'script_errors':0},'native':rows,'ui_native':ui,'positive_native_checks':sum(r['checks'] for r in rows if r['case']!='before')+sum(r['checks'] for r in ui),'all_final_native_pngs_individually_viewed':sum(r['pngs'] for r in rows)+sum(r['pngs'] for r in ui),'cold':cold,'history':'wrong warehouse half and survival-field probe errors rejected; first product12/0 still SCRIPT ERROR rejected; wrong area_states path fixed to actual id; original tests unchanged; v1 native cold assertion during Transition rejected, v2 waits actual owners; v2 cold receipt compared v1 frozen path, corrected from recorded writer SHA and immutable v2 bytes, original bad receipt retained','research':'Hollow Knight and Ori actual prior screenshots re-viewed for typography and scene separation; no inference about save algorithms','environment':'Godot4.7.2 Forward+ HDR, llvmpipe software Vulkan, Xvfb720p and1080p; public synthetic actions','scope':'real Main, actual authored vault disc and source key, declared prerequisite flags/position and survival floor1, actual IO directory refusal, existing writer hooks for rollback failure/postcommit source race, public retry/cancel/reload and independent continue; not human full chapter, physical controller, all chapter pickups or general Story coordinator'}
(out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,b in sorted(files.items()):z.writestr(p,b)
with zipfile.ZipFile(out/'raw.zip') as z:
 assert z.testzip() is None
 for p,b in files.items():assert sha(z.read(p))==sha(b)
manifest={'archive_bytes':(out/'raw.zip').stat().st_size,'archive_sha256':sha((out/'raw.zip').read_bytes()),'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
images=[('st9-1022-world-item-before-v2','write-refused','before'),('st9-1022-world-item-accepted-v2','write-refused','refused'),('st9-1022-world-item-accepted-v2','write-accepted','accepted'),('st9-1022-world-item-continue-v2','cold-continued','continued'),('st9-1022-world-item-committed-v2','committed-reload','committed'),('st9-1022-world-item-original-v2','original-reload','original'),('st9-1022-world-item-ui-en-v1','write-refused','english'),('st9-1022-world-item-ui-ja-v1','committed-reload','japanese'),('st9-1022-world-item-ui-zh1080-v1','original-reload','1080')]
for name,source,label in images:shutil.copyfile(base/name/(source+'.png'),root/('pm/ST/images/ST-9-world-item-'+label+'.png'))
summary={'entries':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256'],'validation':validation};(w/'package-receipt.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
