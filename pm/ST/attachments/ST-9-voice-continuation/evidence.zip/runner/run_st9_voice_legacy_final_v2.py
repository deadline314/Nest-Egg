import hashlib,json,os,pathlib,re,subprocess
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=pathlib.Path('/workspace/Nest-Egg/work/batch1020b')
import time
deadline=time.monotonic()+2400
while True:
 text=(w/'st9-voice-native-final-v3.log').read_text() if (w/'st9-voice-native-final-v3.log').exists() else ''
 assert 'Traceback' not in text,'final voice validation failed'
 if 'ALL FINAL VOICE AND EXISTING DURABLE BOUNDARIES VERIFIED' in text:break
 assert time.monotonic()<deadline,'final voice validation deadline exceeded'
 time.sleep(1)
env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(w/'godot-audio-build/dist/godot'))
jobs=[(npc,False,'write') for npc in ['ch1_label_watch','ch1_label_guitar','ch1_label_raincoat','ch1_label_fare','ch1_egret']]
jobs += [('ch1_label_watch',True,'write'),('ch1_egret',False,'continue'),('ch1_label_watch',True,'continue')]
records=[]
for npc,dawn,mode in jobs:
 tag='st9-voice-legacy-final2-'+npc+('-dawn' if dawn else '')+'-'+mode+'-v1';slot=w/('st9-voice-legacy-final2-'+npc+('-dawn' if dawn else '')+'-v1-save')
 command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://work/st9-person-completion/probe.tscn','--mode='+mode,'--save-dir='+str(slot),'--npc='+npc]
 if dawn:command.append('--dawn')
 print('START',tag,flush=True)
 with (w/(tag+'-console.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 data=json.loads((n/tag/'result.json').read_text());log=(n/(tag+'.log')).read_text();engine_exit=int((n/(tag+'.exit')).read_text());clean=not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use|^FAIL ',log,re.M)
 record={'tag':tag,'checks':data['checks'],'failures':data['failures'],'completed':data['completed'],'exit':code,'engine_exit':engine_exit,'clean':clean};records.append(record)
 (w/'st9-voice-legacy-final2-v1.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 assert code==0 and engine_exit==0 and clean and data['completed'] and data['failures']==0,record
 if mode=='write':
  payload=(slot/'slot.json').read_bytes();sha=hashlib.sha256(payload).hexdigest();(slot/'expect.json').write_text(json.dumps({'sha256':sha})+'\n');(slot/'frozen-writer-slot.json').write_bytes(payload)
print('ALL LEGACY SOURCES VERIFIED',flush=True)
