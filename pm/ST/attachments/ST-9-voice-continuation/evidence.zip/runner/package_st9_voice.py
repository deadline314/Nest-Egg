import pathlib,json,hashlib,re,zipfile,shutil
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=pathlib.Path('/workspace/Nest-Egg/work/batch1020b');d=r/'pm/ST/attachments/ST-9-voice-continuation'
assert (w/'st9-voice-affected-v3.exit').read_text().strip()=='0'
assert (w/'st9-voice-after-final-v3.exit').read_text().strip()=='0'
assert (w/'st9-voice-handoff-regression-v3.exit').read_text().strip()=='0'
assert (w/'st9-voice-sunday-regression-v3.exit').read_text().strip()=='0'
frozen=json.loads((w/'st9-voice-final-source-v2.json').read_text())
def digest(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
for p,h in frozen.items():assert digest(r/p)==h,p
headless=json.loads((w/'st9-voice-ci-style-v2/receipt.json').read_text());assert len(headless['cases'])==17 and all(x['passed'] for x in headless['cases'])
native=json.loads((w/'st9-voice-native-final-v3.json').read_text());assert len(native)==17 and all(x['clean'] and not x['failures'] and x['exit']==x['engine_exit']==0 for x in native)
legacy=json.loads((w/'st9-voice-legacy-final2-v1.json').read_text());assert len(legacy)==8 and all(x['clean'] and not x['failures'] and x['exit']==x['engine_exit']==0 for x in legacy)
before=json.loads((w/'st9-voice-before-v1.json').read_text());after=json.loads((w/'st9-voice-after-final-v3-v1.json').read_text());assert len(before)==len(after)==5 and sum(x['checks'] for x in before)==sum(x['checks'] for x in after)==67 and sum(len(x['failures']) for x in before)==19 and all(not x['failures'] and x['clean'] for x in after)
text=(w/'st9-voice-affected-v3.log').read_text();match=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)\s+\(wall time (\d+) s\)',text);assert match and match[2]==match[3]=='0'
old_probe=w/'st9-voice-before-v1-source/work/st9-voice-boundary/probe.gd';assert digest(old_probe)==digest(r/'work/st9-voice-boundary/probe.gd')==digest(r/'tests/helpers/voice_completion_base.gd')
entries={}
def add(name,p):
 if p.is_file():entries[name]=p

def tree(prefix,p):
 for file in sorted(p.rglob('*')):
  if file.is_file() and not any(part.endswith('-profile') or part in ['.godot','__pycache__'] for part in file.relative_to(p).parts):add(prefix+'/'+str(file.relative_to(p)),file)
for p in frozen:add('source/final/'+p,r/p)
add('source/final/design/20-campaign-experience/STORY_CONTINUATIONS.md',r/'design/20-campaign-experience/STORY_CONTINUATIONS.md')
for name in ['st9-voice-before-v1-source','st9-voice-after-v1-source','st9-voice-repeat-before-v1-source','st9-voice-before-standalone-fix-v1-source','st9-voice-after-final-v3-v1-source']:tree('source/'+name,w/name)
tree('source/legacy-person',r/'work/st9-person-completion')
for p in w.glob('st9-voice-*.gd'):add('source/history/'+p.name,p)
for directory in sorted(n.glob('st9-voice-*')):
 if directory.is_dir() and not directory.name.endswith('-profile'):
  tree('native/'+directory.name,directory)
  for suffix in ['.log','.exit','-xvfb.log']:add('native/'+directory.name+suffix,n/(directory.name+suffix))
for directory in sorted(w.glob('st9-voice-*')):
 if directory.is_dir() and (directory.name.endswith('-slot') or directory.name.startswith(('st9-voice-ci-style-','st9-voice-handoff-regression-','st9-voice-sunday-regression-'))):tree('runs/'+directory.name,directory)
for p in w.glob('st9-voice-*'):
 if p.is_file() and p.suffix in ['.log','.exit','.json']:add('logs/'+p.name,p)
for name in ['st9-voice-policy-v1-shards','st9-voice-policy-v2-shards','st9-voice-affected-v1-shards','st9-voice-affected-v2-shards','st9-voice-standalone-fix-v1-shards','st9-voice-affected-v3-shards','st9-voice-perf-prefix-current-v1-shards','st9-voice-perf-prefix-baseline-v1-shards']:
 for p in (w/name).glob('*.log'):add('tests/'+name+'/'+p.name,p)
for p in w.glob('run_st9_voice*.py'):add('runner/'+p.name,p)
add('runner/package_st9_voice.py',pathlib.Path(__file__))
add('runner/verify_st9_voice_delivery.py',w/'verify_st9_voice_delivery.py')
archive=d/'evidence.zip';manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(entries.items()):manifest[name]={'bytes':p.stat().st_size,'sha256':digest(p)};z.write(p,name)
with zipfile.ZipFile(archive) as z:
 for name,expected in manifest.items():
  with z.open(name) as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected['sha256'],name
assert archive.stat().st_size<50*1024*1024
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shared={}
for key,name in [('handoff','st9-voice-handoff-regression-v3'),('sunday','st9-voice-sunday-regression-v3')]:
 data=json.loads((w/name/'receipt.json').read_text());assert all(x['passed'] for x in data['cases']);shared[key]={'processes':len(data['cases']),'checks':sum(x['result']['checks'] for x in data['cases']),'failures':0}
validation={'base':'2360ea4c067d4981fc9aa92b5b5a24c281746583','source_sha256':frozen,'engine_sha256':headless['engine_sha256'],'negative':{'cases':5,'checks':67,'before_failures':19,'after_failures':0,'identical_probe_sha256':digest(old_probe)},'performance_control':json.loads((w/'st9-voice-perf-control-v1.json').read_text()),'affected':{'workers':4,'groups':int(re.search(r'Running (\d+) groups',text)[1]),'checks':int(match[1]),'new_failures':0,'known_failures':0,'seconds':int(match[4])},'headless':{'stage':'before standalone replay-only skip routing fix; exact source receipt retained','source_sha256':headless['source_sha256'],'processes':17,'checks':sum(x['result']['checks'] for x in headless['cases']),'failures':0,'original_primaries':headless['original_pending_primaries']},'native':{'processes':17,'checks':sum(x['checks'] for x in native),'failures':0,'cases':native},'legacy':{'processes':8,'checks':sum(x['checks'] for x in legacy),'failures':0,'cases':legacy},'shared_regressions':shared,'archive':{'file':'evidence.zip','bytes':archive.stat().st_size,'entries':len(manifest),'sha256':digest(archive)},'boundaries':['Arranged preexisting heard recording, actual authored headset NPC and choices; not a human chapter playthrough.','Software Forward+ HDR2D; physical input, hardware performance and human style gates remain separate.','Only finite first-chapter flag continuations/choices/result-free reply; general atomic_v1 remains absent.']}
(d/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
images={'reading':n/'st9-voice-final-write-v3/reading/refused.png','retry':n/'st9-voice-final-write-v3/first-reading/refused.png','cold':n/'st9-voice-final-first_read-v3/cold/refused.png','later':n/'st9-voice-final-repeat-v3/accepted/refused.png','invalid':n/'st9-voice-final-invalid_skip-v3/accepted/refused.png'}
for name,p in images.items():shutil.copyfile(p,r/'pm/ST/images'/('ST-9-voice-'+name+'.png'))
print(json.dumps({key:value for key,value in validation.items() if key not in ['source_sha256','native','legacy','boundaries']},ensure_ascii=False))
