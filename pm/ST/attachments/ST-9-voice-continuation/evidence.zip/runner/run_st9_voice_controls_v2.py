import pathlib,json,re,subprocess,os,hashlib
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=pathlib.Path('/workspace/Nest-Egg/work/batch1020b');env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(w/'godot-audio-build/dist/godot'));modes=['skip_active','skip_early','skip_auto','return','unheard'];rows=[]
files=['autoload/story.gd','core/story_outcomes.gd','data/story/ch1_kasa.json','game/cutscene/cutscene_player.gd','game/story_result_completion.gd','game/story_result_sources.gd','tests/probes/voice_completion.gd','tests/helpers/voice_completion_base.gd'];source={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files};(w/'st9-voice-controls-v2-source.json').write_text(json.dumps(source,indent=2)+'\n')
for mode in modes:
 tag='st9-voice-control-'+mode+'-v2';command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://tests/probes/voice_completion.tscn','--mode='+mode,'--save-dir='+str(w/(tag+'-slot'))]
 print('START',tag,flush=True)
 with (w/(tag+'-console.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 data=json.loads((n/tag/'result.json').read_text());raw=(n/(tag+'.log')).read_text();row={'tag':tag,'mode':mode,'checks':data['checks'],'failures':data['failures'],'exit':code,'clean':not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use|^FAIL ',raw,re.M)};rows.append(row);(w/'st9-voice-controls-v2.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);assert code==0 and row['clean'] and not data['failures'],row
 for p,h in source.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
print('ALL SIX CONTROLS VERIFIED',flush=True)
