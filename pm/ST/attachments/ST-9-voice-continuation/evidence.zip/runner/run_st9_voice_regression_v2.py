import pathlib,json,time,subprocess,os,hashlib
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';deadline=time.monotonic()+1200
while not (w/'st9-voice-standalone-fix-v1.exit').exists():
 assert time.monotonic()<deadline,'focused regression deadline exceeded'
 time.sleep(1)
assert (w/'st9-voice-standalone-fix-v1.exit').read_text().strip()=='0'
while True:
 try:
  receipt=json.loads((w/'st9-voice-ci-style-v2/receipt.json').read_text())
  if receipt['cases']:assert receipt['cases'][-1]['passed'],'voice case failed; stop regression'
  if len(receipt['cases'])==17:break
 except (FileNotFoundError,ValueError):pass
 assert time.monotonic()<deadline,'voice helper deadline exceeded'
 time.sleep(1)
source=json.loads((w/'st9-voice-final-source-v2.json').read_text())
for p,h in source.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
env=os.environ.copy();env.update(GODOT=str(w/'godot-audio-build/dist/godot'),SHARDS='8',LOG_DIR=str(w/'st9-voice-affected-v2-shards'))
with (w/'st9-voice-affected-v2.log').open('w') as log:code=subprocess.run(['bash','tools/run_tests_changed.sh','2360ea4c067d4981fc9aa92b5b5a24c281746583'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
(w/'st9-voice-affected-v2.exit').write_text(str(code)+'\n');print('original changed selection exit',code,flush=True);assert code==0
for p,h in source.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
print('unchanged final source verified after regression',flush=True)
