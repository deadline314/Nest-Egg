from pathlib import Path
import json,subprocess,os,time,hashlib,re
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';b=w/'st9-voice-perf-baseline-v1';deadline=time.monotonic()+600
while not (w/'st9-voice-perf-prefix-current-v1.exit').exists():
 assert time.monotonic()<deadline
 time.sleep(1)
assert (w/'st9-voice-perf-prefix-current-v1.exit').read_text().strip()=='0'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=b,text=True).strip()=='2360ea4c067d4981fc9aa92b5b5a24c281746583'
print('Current five-suite prefix passed; preparing immutable baseline cache.',flush=True)
subprocess.run(['cp','-a','--reflink=auto',str(r/'.godot'),str(b/'.godot')],check=True)
engine=str(w/'godot-audio-build/dist/godot')
with (w/'st9-voice-perf-baseline-import-v1.log').open('w') as log:
 code=subprocess.run([engine,'--headless','--editor','--quit'],cwd=b,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
assert code==0
assert 'SCRIPT ERROR' not in (w/'st9-voice-perf-baseline-import-v1.log').read_text()
env=os.environ.copy();env.update(GODOT=engine,SHARDS='1',LOG_DIR=str(w/'st9-voice-perf-prefix-baseline-v1-shards'))
with (w/'st9-voice-perf-prefix-baseline-v1.log').open('w') as log:
 code=subprocess.run(['bash','tools/run_tests_parallel.sh','--only=ProgressionSuite,CutsceneSuite,SceneSanitySuite,EconomySuite,FxMeleePickupsSuite'],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=400).returncode
(w/'st9-voice-perf-prefix-baseline-v1.exit').write_text(str(code)+'\n');assert code==0
rows={}
for label in ['current','baseline']:
 text=(w/f'st9-voice-perf-prefix-{label}-v1-shards/shard_0.log').read_text();match=re.search(r'FX_PERF idle=([\d.]+) ms, 12 explosions=([\d.]+) ms per frame, particles=(\d+), nodes \+(-?\d+)',text);assert match
 rows[label]={'idle_ms':float(match[1]),'explosions_ms':float(match[2]),'particles':int(match[3]),'node_growth':int(match[4]),'exit':0,'summary':(w/f'st9-voice-perf-prefix-{label}-v1.log').read_text().splitlines()[-1]}
 rows[label]['measured_delta_ms']=round(rows[label]['explosions_ms']-rows[label]['idle_ms'],2)
rows['bounds']={'cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text().strip(),'unchanged_budget_ms':6,'unchanged_explosions':12,'failed_eight_worker_idle_ms':15.68,'failed_eight_worker_explosions_ms':29.79,'interpretation':'Both unchanged five-suite prefixes are recorded; a later success does not identify the earlier transient timing root cause. Final original selector is rerun with four workers matching the available CPU quota, no tests or thresholds removed.'}
(w/'st9-voice-perf-control-v1.json').write_text(json.dumps(rows,indent=2)+'\n');(w/'st9-voice-perf-control-v1.exit').write_text('0\n');print(json.dumps(rows),flush=True)
