import pathlib,subprocess,os,json,re,hashlib
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=pathlib.Path('/workspace/Nest-Egg/work/batch1020b');env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(w/'godot-audio-build/dist/godot'))
files=['game/story_result_sources.gd','core/story_outcomes.gd','work/st9-voice-boundary/probe.gd','work/st9-voice-boundary/probe.tscn','game/story_result_completion.gd','autoload/story.gd','game/main.gd','game/cutscene/cutscene_player.gd','data/story/ch1_kasa.json'];source=w/'st9-voice-after-final-v3-v1-source';source.mkdir(exist_ok=False)
for name in files:
 p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((r/name).read_bytes())
manifest={name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in files};(source/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');rows=[]
for mode in ['ask','first','second_choice','second','later']:
 tag='st9-voice-after-final-v3-'+mode+'-v1';slot=w/(tag+'-slot');cmd=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://work/st9-voice-boundary/probe.tscn','--mode='+mode,'--save-dir='+str(slot)]
 print('START',tag,flush=True)
 with (w/(tag+'-console.log')).open('w') as log:code=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 data=json.loads((n/tag/'result.json').read_text());raw=(n/(tag+'.log')).read_text();clean=not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use',raw,re.M);row={'mode':mode,'tag':tag,'checks':data['checks'],'failures':data['failures'],'exit':code,'clean':clean};rows.append(row);(w/'st9-voice-after-final-v3-v1.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert code==0 and not data['failures'] and clean,row
 for name,h in manifest.items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==h,name
print('ALL FIVE REPAIRED BOUNDARIES VERIFIED',flush=True)
