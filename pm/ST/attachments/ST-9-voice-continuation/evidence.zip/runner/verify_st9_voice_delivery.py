from pathlib import Path
import json,hashlib,zipfile,re,subprocess,csv,urllib.parse
w=Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';d=r/'pm/ST/attachments/ST-9-voice-continuation'
v=json.loads((d/'validation.json').read_text());manifest=json.loads((d/'manifest.json').read_text())
def digest(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
for name,expected in v['source_sha256'].items():assert digest(r/name)==expected,name
archive=d/v['archive']['file'];assert digest(archive)==v['archive']['sha256'] and archive.stat().st_size==v['archive']['bytes']
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==v['archive']['entries']==len(manifest)
 for name,expected in manifest.items():
  payload=z.read(name);assert len(payload)==expected['bytes'] and hashlib.sha256(payload).hexdigest()==expected['sha256'],name
assert v['negative']=={'cases':5,'checks':67,'before_failures':19,'after_failures':0,'identical_probe_sha256':'2fa87a2ded4fb0bb715f1b8f1696314408b5abb2bf33643220fa9ae4000d9d7a'}
assert v['affected']['groups']==67 and v['affected']['workers']==4 and v['affected']['new_failures']==v['affected']['known_failures']==0
assert v['native']['processes']==17 and v['legacy']['processes']==8 and v['native']['failures']==v['legacy']['failures']==0
native_primaries=json.loads((w/'st9-voice-native-original-primaries-v3.json').read_text());assert len(native_primaries)==3
for row in native_primaries.values():assert digest(w/'st9-voice-final-write-v3-slot'/row['source'])==row['sha256']
visual=json.loads((w/'st9-voice-visual-final.json').read_text());assert len(visual['images'])==5
for row in visual['images']:
 assert row['inspected'] is True and digest(r/row['file'])==row['sha256']
protected=['tests/known_failures.txt','tools/test_filters.sh','tools/select_tests.py','tools/run_tests_changed.sh','tools/run_tests_parallel.sh']
assert subprocess.check_output(['git','diff','HEAD','--',*protected],cwd=r,text=True)==''
ticket=r/'pm/ST/[ST-9]把第一章劇本接進遊戲.md';text=ticket.read_text();assert '> 狀態：進行中' in text and '# Commit-20' in text
assert len(re.findall(r'^- \[ \]',text,re.M))==2
for doc,content in [(d/'README.md',(d/'README.md').read_text()),(ticket,text.split('# Commit-20',1)[1])]:
 for target in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',content):
  target=target.strip('<>').split('#')[0]
  if not target or re.match(r'\w+://',target):continue
  resolved=(doc.parent/urllib.parse.unquote(target)).resolve()
  if not resolved.exists():
   rel=str(resolved.relative_to(r));subprocess.run(['git','cat-file','-e','HEAD:'+rel],cwd=r,check=True)
actual={'unfinished':0,'review':0}
for folder in ['Nest-Egg','Nest-Egg-BG','ST']:
 for p in (r/'pm'/folder).glob('[[]*.md'):
  status=re.search(r'^> 狀態：(.+)$',p.read_text(),re.M)
  if status and status[1].startswith(('待辦','進行中')):actual['unfinished']+=1
  elif status and status[1].startswith('審查中'):actual['review']+=1
for key,file in [('unfinished','unfinished-tickets-2026-10-26-latest.csv'),('review','review-tickets-2026-10-26-latest.csv')]:assert len(list(csv.DictReader((r/'pm'/file).open())))==actual[key]
subprocess.run(['git','diff','--check'],cwd=r,check=True)
receipt={'source_files':len(v['source_sha256']),'entries':len(manifest),'archive_sha256':v['archive']['sha256'],'affected':v['affected'],'native_checks':v['native']['checks'],'legacy_checks':v['legacy']['checks'],'images_inspected':5,'original_pending_primaries':native_primaries,**actual,'protected_test_sources_unchanged':True}
(w/'st9-voice-delivery-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
