import pathlib,json,time,subprocess,os,re,hashlib,shutil
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'st9-counters-worktree';n=pathlib.Path('/workspace/Nest-Egg/work/batch1020b');deadline=time.monotonic()+1800
while not (w/'st9-voice-affected-v3.exit').exists():
 assert time.monotonic()<deadline,'affected regression deadline exceeded'
 time.sleep(1)
assert (w/'st9-voice-affected-v3.exit').read_text().strip()=='0'
frozen=json.loads((w/'st9-voice-final-source-v2.json').read_text());env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/st9-counters-worktree',NE_NATIVE_GODOT=str(w/'godot-audio-build/dist/godot'))
modes=['write','completed_read','choice_read','first_read','second_read','repeat','skip_active','later_read','skip_early','skip_auto','return','unheard','cancel','cancel_read','invalid','invalid_skip','return_then_ask'];rows=[];primaries={}
for mode in modes:
 tag='st9-voice-final-'+mode+'-v3';source_mode={'completed_read':'write','later_read':'skip_active','cancel_read':'cancel'}.get(mode,mode);slot=w/('st9-voice-final-'+source_mode+'-v3-slot')
 original={'choice_read':'accepted-choice-primary.json','first_read':'first-reading-primary.json','second_read':'second-choice-primary.json'}.get(mode)
 if original:
  slot.mkdir(exist_ok=False);payload=(w/'st9-voice-final-write-v3-slot'/original).read_bytes();(slot/'slot.json').write_bytes(payload);primaries[mode]={'source':original,'sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload)};(w/'st9-voice-native-original-primaries-v3.json').write_text(json.dumps(primaries,indent=2)+'\n')
 command=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://tests/probes/voice_completion.tscn','--mode='+mode,'--save-dir='+str(slot)];print('START',tag,flush=True)
 with (w/(tag+'-console.log')).open('w') as log:code=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 data=json.loads((n/tag/'result.json').read_text());raw=(n/(tag+'.log')).read_text();row={'tag':tag,'mode':mode,'checks':data['checks'],'failures':data['failures'],'exit':code,'engine_exit':int((n/(tag+'.exit')).read_text()),'clean':not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use|^FAIL ',raw,re.M)};rows.append(row);(w/'st9-voice-native-final-v3.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);assert code==0 and row['engine_exit']==0 and row['clean'] and not data['failures'],row
 for p,h in frozen.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
print('ALL SEVENTEEN NATIVE VOICE CASES VERIFIED',flush=True)
# Same immutable five-boundary probe, plus the accepted previous handoff/Sunday probes.
negative=(w/'run_st9_voice_after_v1.py').read_text().replace('st9-voice-after-', 'st9-voice-after-final-v3-');(w/'run_st9_voice_after_final_v3.py').write_text(negative)
with (w/'st9-voice-after-final-v3.log').open('w') as log:code=subprocess.run(['python',str(w/'run_st9_voice_after_final_v3.py')],cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
(w/'st9-voice-after-final-v3.exit').write_text(str(code)+'\n');assert code==0
for helper,output in [('run_handoff_completion.py','st9-voice-handoff-regression-v3'),('run_sunday_choice.py','st9-voice-sunday-regression-v3')]:
 print('START',output,flush=True)
 with (w/(output+'.log')).open('w') as log:code=subprocess.run(['python',str(r/'tools'/helper),'--godot',env['NE_NATIVE_GODOT'],'--output',str(w/output)],cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
 (w/(output+'.exit')).write_text(str(code)+'\n');assert code==0,output;print('PASS',output,flush=True)
for p,h in frozen.items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
print('ALL FINAL VOICE AND EXISTING DURABLE BOUNDARIES VERIFIED',flush=True)
