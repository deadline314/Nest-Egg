from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
root=Path('work/ch2-evidence-save');console=(root/'required-runner.log').read_text()
m=re.search(r'checks: (\d+), new failures: 0, known failures .*: 0  \(wall time (\d+) s\)',console)
assert m
checks,seconds=map(int,m.groups())
for name in ['after','matrix','patroller','native']:
 r=json.loads((root/name/'receipt.json').read_text());assert all(c['passed'] for c in r['cases']),name
assert 'diagnostics=0' in (root/'dummy-exit.log').read_text()
folder=Path('pm/ST/attachments/ST-19-evidence-save');folder.mkdir(exist_ok=False)
source=root/'delivery-source';source.mkdir(exist_ok=False)
names=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
for name in names:
 p=Path(name)
 if p.is_file():
  target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
shutil.copyfile('/workspace/.nest-egg-env/ci-godot/dist/receipt.json',root/'engine-receipt.json')
images={
 'contract-accepted/contract-refused':'refused',
 'contract-accepted/contract-accepted':'contract',
 'collection-accepted/collection-accepted':'collection',
 'collection-accepted_read/collection-cold':'cold',
}
for source_name,name in images.items():shutil.copyfile(root/'native'/(source_name+'.png'),Path('pm/ST/images')/('ST-19-evidence-'+name+'.png'))
with zipfile.ZipFile(folder/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in {'.json','.log','.exit','.gd','.tscn','.py','.png','.txt','.sh'} and '__pycache__' not in p.parts:
   archive.write(p,str(p.relative_to(root)))
receipt={'base':'fd295016c2059e356e769ba0cec55e6a0348fdac','before':{'processes':2,'checks':26,'failures':12,'git_clean':True},'same_refusal_after':{'processes':2,'checks':26,'failures':0},'evidence':{'processes':14,'checks':236,'failures':0},'patroller':{'processes':8,'checks':83,'failures':0},'compiler':{'checks':15,'failures':0},'native_software':{'processes':4,'checks':88,'failures':0},'required':{'groups':9,'checks':checks,'new_failures':0,'known_failures':0,'seconds':seconds},'archive_sha256':hashlib.sha256((folder/'evidence.zip').read_bytes()).hexdigest()}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(folder/'README.md').write_text(f'''# ST-19：合約與代收簿一起保存物品及進度

乾淨fd295016主線，在真Main的原租攤視窗／原代收簿互動讀完時，以自己建立的.tmp目錄阻止原主檔寫入；兩程序26項有12失敗。物品、旗標、完成歷史、人物次數與通知都提前發生，完整原主檔bytes未變。樣本明示切入原公眾攤道／裝卸間並安排位置，沒有設定證據物品或結果旗標，真正呼叫原物件並送閱讀按鍵；不是完整自然路線或整章通關。

原作者只對`ch2_t_s08_contract`與`ch2_t_s08_collection`明示終端政策，有限契約保留各自原資源、區域、模式、未取得條件及原物品＋旗標兩項結果；巡帳員契約語意不變。後者仍為原疊加演出，前者仍為原對話。沒有啟用一般atomic_v1，亦不以任意載入JSON決定可發的物品。

- 同樣拒寫樣本26項修後0失敗。正式兩種來源各跑接受、原接受冷讀、取消、原取消冷讀、來源失效、換成另一已宣告物品、同資源同格位的假物件，共14程序236項全過、0嚴格診斷。
- 接受前兩次真實IO拒絕不發通知、不改全部旗標／持有／完成事實，也不結算原等待者；成功後每種通知各一次。每個通知都直接解碼原checksum主檔，物品、旗標、歷史與三處world次數一起存在，原NPC等待者尚未返回。
- 物品通知內的合法`mark_seen`確認由新快照保存，冷讀沒有NEW標記；比對真正`unseen`欄位與完整持有快照。通知內的另一物品生產被拒絕。每次通知的完整磁碟主檔都另存，不只看還原後的補正結果。
- 移除原登記來源後重試只能要求原整輪，回復後原物件、次數與未取得事實一致；異物品與假節點不能授權。取消原檔跨程序還原，沒有手造讀檔來源。
- 原巡帳員8程序83項、作者政策15項，以及原選擇器9組{checks:,}項全過，0新／已知失敗、{seconds}秒。只增有限資料契約，因此原選擇器選9組；沒有把未跑套件當通過。六份退出另驗DummyTexture0，選擇器／已知失敗未改。
- 原生Forward+／軟體Vulkan兩種接受與冷讀4程序88項全過，0嚴格診斷；四張交付圖已看。原圖全部保留。合約圖的主線橫幅仍是明示進區前的目標，代收簿圖的電線通訊是原區域提示，不作證據閱讀的圖像判據；結果以原主檔、通知與冷讀為準。

人物素材、租攤視窗員的完整新外觀與指定動作不在此項驗證；本票仍進行中。軟體Vulkan不是實體GPU、真人輸入或完整人工通關。引擎為同CI來源／修補／選項的本機4.7.2建置，編譯器不同，不聲稱二進位相同。

[evidence.zip](evidence.zip)含乾淨原始失敗、原主檔、全部通知原檔、來源快照、回歸及原生PNG。[receipt.json](receipt.json)記錄雜湊與範圍。
''')
p=Path('pm/ST/[ST-19]完成第二章故事與關卡.md')
with p.open('a') as stream:
 stream.write(f'''

# Commit-6（查帳證據與閱讀進度一起保存）

## 內文

在租攤視窗看完合約、或讀完裝卸間代收簿後，原本即使保存失敗仍會拿到副本並記為已讀。現在物品與閱讀進度一起保存，成功後才通知取得；拒絕可原地重試，取消保留原進度，來源失效回到原完整存檔。假物件或遭替換的獎勵不能取得證據。

原版兩程序26項有12失敗，相同拒寫樣本修後全過。正式14程序236項、巡帳員83項、作者資料15項、受影響9組{checks:,}項，以及原生軟體Vulkan88項全部通過。通知當下原存檔中的物品與人物進度已一致，閱讀確認及冷續玩也保留。樣本明示進區與位置，不代稱自然整章通關。

![證據結果保存拒絕](images/ST-19-evidence-refused.png)
![保存後取得合約副本](images/ST-19-evidence-contract.png)
![代收簿重試成功](images/ST-19-evidence-collection.png)

[原始失敗、完整主檔、來源及全部驗證](attachments/ST-19-evidence-save/README.md)。
''')
print(json.dumps(receipt,indent=2))
