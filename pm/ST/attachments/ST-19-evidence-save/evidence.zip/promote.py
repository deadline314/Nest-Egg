from pathlib import Path
p=Path('work/ch2-evidence-save/probe.gd')
s=p.read_text()
s=s.replace('var _flag_notices := 0','var _flag_notices := 0\nvar _events: Array[Dictionary] = []')
s=s.replace(' _definition=PRODUCERS.get(_producer,{})',''' if _mode.contains("--"):
  _producer=_mode.get_slice("--",0)
  _mode=_mode.get_slice("--",1)
 _definition=PRODUCERS.get(_producer,{})''')
s=s.replace(' _main.call("_on_start_requested",GameState.difficulties[1])',''' if _mode.ends_with("_read"):
  _main.call("_on_continue_requested")
  await _frames(12)
  var original:=_evidence_actor()
  var accepted:=_mode=="accepted_read"
  _check(original!=null and _level().data.resource_path==_definition.level,"cold original primary restores its original area and evidence object")
  _check(GameState.has_flag(_definition.item)==accepted and StoryItems.holds(_definition.item)==accepted and Story._completed.has(_definition.scene)==accepted,"cold flag, custody and completion match the accepted original result")
  _check(original!=null and original.talk_count==int(accepted),"cold original actor counter settles exactly once")
  _check(not StoryItems.is_new(_definition.item),"cold read preserves the ordinary item observer acknowledgement")
  _check(_prompt()==null and not get_tree().paused,"cold read leaves no stale presentation prompt")
  await _shot(_producer+"-cold")
  await _done()
  return
 _main.call("_on_start_requested",GameState.difficulties[1])''',1)
s=s.replace(' var count:=npc.talk_count',''' var original_scene: Dictionary=Story._scenes[String(_definition.scene)].duplicate(true)
 if _mode=="contract":
  Story._scenes[String(_definition.scene)]["results"][0]["id"]="ch1_grey_cloth"
 if _mode=="duplicate":
  var duplicate:=NpcActor.new()
  duplicate.configure(npc.data,npc.cell)
  duplicate.position=npc.position
  _level()._entities.add_child(duplicate)
  duplicate.remove_from_group(WorldState.GROUP)
  npc=duplicate
  _check(not _level().npc_sources.has(npc),"same-resource same-cell evidence duplicate is not an authored source")
 var count:=npc.talk_count''')
s=s.replace(' _check(not done[0] and npc.talk_count==count,"refused reading retains its original waiter and counter")',' _check(npc.talk_count==count and (_mode in ["contract","duplicate"] or not done[0]),"refused reading preserves its counter and genuine pending waiter")')
s=s.replace(' _check(_prompt()!=null and get_tree().paused,"real failed reading retains its retryable presentation")\n await _done()',''' if not _mode in ["contract","duplicate"]:
  _check(_prompt()!=null and get_tree().paused,"real failed reading retains its retryable presentation")
 await _shot(_producer+"-refused")
 if _mode in ["contract","duplicate"]:
  Story._scenes[String(_definition.scene)]=original_scene
  Story.reset_active_presentation(&"probe_invalid_source")
  await _frames(4)
  _check(not StoryItems.owns(&"ch1_grey_cloth") and _facts()==_original_facts,"altered or duplicate producer cannot grant a different declared item or any partial result")
  _check(FileAccess.get_file_as_bytes(_store.path)==_before,"invalid evidence producer retains exact original primary")
  DirAccess.remove_absolute(_store.path+".tmp")
  await _done()
  return
 if _mode=="cancel":
  Story.reset_active_presentation(&"probe_cancel")
  await _frames(4)
  _check(done[0] and not done[1] and npc.talk_count==count,"cancel returns the original waiter without settling the evidence")
  _check(_facts()==_original_facts and FileAccess.get_file_as_bytes(_store.path)==_before,"cancel preserves all original facts and exact primary")
  _check(_prompt()==null and not get_tree().paused,"cancel releases the evidence prompt and pause")
  DirAccess.remove_absolute(_store.path+".tmp")
  await _done()
  return
 if _mode=="stale":
  _level().npc_sources.erase(npc)
  _check(DirAccess.remove_absolute(_store.path+".tmp")==OK,"remove only owned IO obstruction before stale-source retry")
  if _prompt()!=null:_prompt().retry_button.pressed.emit()
  await _frames(4)
  _check(_prompt()!=null and _main.get("_result_completion").get("_reload_original"),"stale original source offers whole-original recovery")
  _check(_facts()==_original_facts and FileAccess.get_file_as_bytes(_store.path)==_before,"stale-source retry cannot accept partial evidence")
  if _prompt()!=null:_prompt().retry_button.pressed.emit()
  await _frames(12)
  var restored:=_evidence_actor()
  _check(restored!=null and restored.talk_count==count and not StoryItems.holds(_definition.item) and not GameState.has_flag(_definition.item),"whole-original recovery reconstructs the unaccepted original evidence")
  _check(_prompt()==null and not get_tree().paused,"original recovery clears its pending presentation")
  await _done()
  return
 if _prompt()!=null:_prompt().retry_button.pressed.emit()
 await _frames(4)
 _check(_facts()==_original_facts and not done[0] and _prompt()!=null,"second genuine writer refusal keeps the same original interaction pending")
 _check(DirAccess.remove_absolute(_store.path+".tmp")==OK,"remove only the owned obstruction for successful retry")
 if _prompt()!=null:_prompt().retry_button.pressed.emit()
 await _frames(8)
 _check(done[0] and done[1] and npc.talk_count==count+1,"successful retry settles the same original evidence interaction exactly once")
 _check(_item_notices==1 and _flag_notices==1 and StoryItems.holds(_definition.item) and GameState.has_flag(_definition.item) and Story._completed.has(_definition.scene),"one accepted result publishes exactly one item and flag notification")
 var saved:=_store.read()
 _check(not StoryItems.is_new(_definition.item) and not saved.get("story",{}).get("items",{}).get("new",[]).has(String(_definition.item)),"fresh save preserves ordinary observer acknowledgement without reinstalling an old proposal")
 _check(_prompt()==null and not get_tree().paused,"accepted evidence releases its prompt and pause")
 await _shot(_producer+"-accepted")
 await _done()''',1)
s=s.replace(' if item.id==_definition.item:_item_notices+=1',''' if item.id!=_definition.item:return
 _item_notices+=1
 _observe_coherent("item")
 _check(not StoryItems.acquire(&"ch1_grey_cloth",false),"reentrant unrelated item producer is refused during evidence publication")
 StoryItems.mark_seen(item.id)''')
s=s.replace(' if id==_definition.item and value==true:_flag_notices+=1',''' if id!=_definition.item or value!=true:return
 _flag_notices+=1
 _observe_coherent("flag")
func _observe_coherent(event: String) -> void:
 var npc:=_evidence_actor()
 _check(npc!=null and npc._talking and npc._durable_completed and npc.talk_count==1,"first result observers see durable original actor settlement before the waiter returns")
 _check(GameState.has_flag(_definition.item) and StoryItems.holds(_definition.item) and Story._completed.has(_definition.scene),"every result observer sees all installed live evidence facts")
 var raw:=FileAccess.get_file_as_string(_store.path)
 var decoded:=RunSaveCodec.decode(raw)
 _check(decoded.has("data"),"publication primary has its original valid checksum without reader repair")
 if not decoded.has("data") or npc==null:return
 var disk: Dictionary=decoded.data
 _check(disk.story.flags.get(String(_definition.item),false) and disk.story.items.held.has(String(_definition.item)) and disk.story.seen.has(String(_definition.scene)),"every observer sees item, flag and history in the complete original disk primary")
 var counts: Array=[]
 for world: Dictionary in [disk.runtime.world,disk.runtime.area.world,disk.state.area_states[String(_level().data.id)].world]:
  var count: Variant=world.get(npc.state_key(),{}).get("talks",-1)
  counts.append(count)
  _check(count==1,"every observer sees the same actor counter in all three raw primary worlds")
 var filename:=_producer+"-"+event+"-"+str(_events.size())+"-primary.json"
 var file:=FileAccess.open(_out.path_join(filename),FileAccess.WRITE)
 _check(file!=null,"raw publication primary can be preserved in the isolated evidence directory")
 if file!=null:
  file.store_string(raw)
  file.close()
 _events.append({"event":event,"talks":npc.talk_count,"world_counts":counts,"primary":filename})''')
s+='''
func _done() -> void:
 DirAccess.make_dir_recursive_absolute(_out)
 var file:=FileAccess.open(_out.path_join("result.json"),FileAccess.WRITE)
 if file!=null:
  file.store_string(JSON.stringify({"mode":_mode,"producer":_producer,"checks":_checks,"failures":_issues,"publications":_events},"  "))
  file.close()
 else:
  _check(false,"isolated result receipt is writable")
 Story.reset_active_presentation(&"menu")
 _main.call("_quit",0 if _issues.is_empty() else 1)
'''
s='\n'.join('\t'*(len(line)-len(line.lstrip(' ')))+line.lstrip(' ') for line in s.splitlines())+'\n'
Path('tests/probes/ch2_evidence_completion.gd').write_text(s)
Path('tests/probes/ch2_evidence_completion.tscn').write_text(Path('work/ch2-evidence-save/probe.tscn').read_text().replace('work/ch2-evidence-save/probe.gd','tests/probes/ch2_evidence_completion.gd'))
