"""Preview the first authored S11 desk beat using the existing office and paper materials."""
from pathlib import Path
from dataclasses import replace
import json
import sys

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/"tools/story"))
import build_ch2_story
from chapter_compiler import compile_chapter
from ch2_source import FORMAL_FRAMES, Frame
from ch2_stages import LEDGER, Cast
from guest_ticket_staging import PATH, PAPER_POINT, STATES, SOURCE_WIDTH
from market_pass_staging import RIN_HAND


DESK_TOP = 215.0
SCALE = 0.20
START = [201.0, 223.0]
PAPERS = (("s11_contract_copy", 220.0), ("s11_interest_receipt", 234.0), ("s11_collection_copy", 248.0))


def layers():
    return tuple(dict(kind="sprite",id=key,path=PATH,source_width=SOURCE_WIDTH,pos=[START[0]+x-PAPERS[0][1],START[1]],scale=SCALE,
                      filter="linear",visible=False,depth="back",
                      states={state["id"]: dict(path="res://"+state["path"]) for state in STATES}) for key, x in PAPERS)


def place_papers():
    steps = []
    for index,(key,x) in enumerate(PAPERS):
        if index:
            steps.append(dict(do="move",id="rin",to=[210.0+x-PAPERS[0][1],LEDGER.floor],
                              time=0.32,pose="walk",then="idle",wait=True))
        steps.extend((
            dict(do="reach",id="rin",hand="front",space="prop",prop=key,to=PAPER_POINT,contact=RIN_HAND,time=0.21,wait=True),
            dict(do="prop_visible",id=key,visible=True),
            dict(do="prop_hold",id=key,actor="rin",hand="front",point=PAPER_POINT,follow_rotation=False),
            dict(do="reach",id="rin",hand="front",to=[x+PAPER_POINT[0]*SCALE,DESK_TOP-18.0],
                 contact=RIN_HAND,time=0.29,wait=True),
        ))
        for state in STATES:
            target = [x+PAPER_POINT[0]*SCALE, DESK_TOP-(state["material_bottom_pixel_centre"]-PAPER_POINT[1])*SCALE]
            steps.extend((dict(do="prop",id=key,state=state["id"]),
                          dict(do="reach",id="rin",hand="front",to=target,contact=RIN_HAND,time=0.06,wait=True)))
        steps.extend((dict(do="prop_release",id=key),
                      dict(do="reach",id="rin",hand="front",release=True,time=0.22,wait=True)))
    steps.extend((dict(do="move",id="rin",to=[210.0,LEDGER.floor],time=0.54,pose="walk",then="idle",wait=True),
                  dict(do="face",id="rin",dir=1)))
    return tuple(steps)


def main():
    scene_id = "ch2_t_s11_intro"
    prior = compile_chapter(build_ch2_story.spec())
    office = replace(LEDGER,shot=(300.0,216.0,1.22),layers=LEDGER.layers+layers())
    cast = (Cast("egret",161.0,1), Cast("rin",210.0,1), Cast("yong",409.0,-1))
    FORMAL_FRAMES[scene_id] = Frame(office,cast,True,((1,place_papers()),))
    prepared = compile_chapter(build_ch2_story.spec())
    assert prior.keys() == prepared.keys()
    for category,value in prior.items():
        if category == "scenes":
            assert [k for k in value if value[k]!=prepared["scenes"][k]] == [scene_id]
            a,b = value[scene_id], prepared["scenes"][scene_id]
            presentation = {"steps","overlay","pose_policy"}
            assert {k:v for k,v in a.items() if k not in presentation} == {k:v for k,v in b.items() if k not in presentation}
            assert a["overlay"] is True and b["pose_policy"] == "supported" and "overlay" not in b
            assert [step for step in a["steps"] if step["do"]=="say"] == [step for step in b["steps"] if step["do"]=="say"]
        else:
            assert value == prepared[category]
    data = {"scene_id":scene_id, "scene":prepared["scenes"][scene_id], "stage":office.definition(), "stage_id":office.ident,
            "materials":list(PAPERS)}
    (OUT/"prototype.json").write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")


if __name__=="__main__":
    main()