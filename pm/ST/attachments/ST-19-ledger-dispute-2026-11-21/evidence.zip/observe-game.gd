extends "res://tools/ch1_flow_probe.gd"

const LOADING := "res://data/levels/ch2_loading.tres"
const FRONT := "res://data/levels/ch2_ledger_front.tres"
const OFFICE := "res://data/levels/ch2_ledger_office.tres"
const STAGE := &"ch2_ledger_dispute"
const INTRO := &"ch2_t_s11_intro"
const BEATS := [INTRO, &"ch2_t_s11_xiaowei", &"ch2_t_s11_boxes"]
const DOCS := [&"ch2_evidence_contract", &"ch2_evidence_receipt", &"ch2_evidence_collection"]
const PAPER_X := {"s11_contract_copy": 220.0, "s11_interest_receipt": 234.0, "s11_collection_copy": 248.0}
const REPLY := {"zh": "我沒有刪本金，這二十已經付了。",
	"en": "I didn't erase the principal. This twenty has already been paid.",
	"ja": "元本は消していない。この20はもう払ってある。"}

var _app: Node
var _store: RunSaveStore
var _mode := ""
var _lang := "zh"
var _checks := 0
var _items: Dictionary
var _credits := 0
var _paper := {}
var _scenes: Array[StringName] = []
var _opening := false
var _all_on_desk := false
var _actual_reply := ""
var _skip_sent := false
var _skipped_without_progress := false
var _saw_hand := false
var _level_path := ""


func _run() -> void:
	var slot := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--slot="):
			slot = arg.trim_prefix("--slot=")
		elif arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--lang="):
			_lang = arg.trim_prefix("--lang=")
	if not slot.is_absolute_path() or _mode not in ["normal", "skip", "leave", "resume"] or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	_store = RunSaveStore.new(slot)
	_app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_app.set("_run_store", _store)
	add_child(_app)
	Story.auto_skip = false
	var initial := FRONT if _mode == "resume" else LOADING
	var started := _store.read()
	_check(started.get("level", "") == initial, "actual persisted checkpoint starts in the correct area")
	for _frame in STEP_LIMIT:
		if _app.get("_screen") is MainMenu and not bool(_app.call("_route_pending")):
			break
		await get_tree().process_frame
	var menu := _app.get("_screen") as MainMenu
	if menu == null:
		_finish(false)
		return
	await _settle(6)
	_check(Story.set_language(_lang) and Story.language == _lang, "local language is active")
	menu._continue_button.pressed.emit()
	if not await _wait_for_area(initial):
		_finish(false)
		return
	_check(GameState.has_flag(&"ch2_market_reconciled") and not GameState.has_flag(&"ch2_yong_intro_seen"), "real S10 result is saved; S11 has not completed")
	_items = StoryItems.snapshot()
	_credits = Progression.credits
	_check(DOCS.all(func(id: StringName) -> bool: return StoryItems.owns(id)), "all original evidence is in the real inventory")
	if initial == LOADING:
		var exit := _level._portals.get(&"loading_ledger") as Portal
		if not is_instance_valid(exit) or not exit.is_open():
			_finish(false)
			return
		_level.player.global_position = exit.global_position - Vector2(0, 3)
		_level.player.velocity = Vector2.ZERO
		_level.camera.snap_to_target()
		for _frame in 75:
			if exit.interaction_available():
				await _tap(&"interact")
				break
			await get_tree().physics_frame
		if not await _wait_for_area(FRONT):
			_finish(false)
			return
	_check(_level.data.resource_path == FRONT and _store.read().get("level", "") == FRONT, "native loading portal enters and saves the authored front room")
	if not Story.is_cinematic_active() and not await _interact(&"ch2_ledger_door"):
		_finish(false)
		return
	for frame in STEP_LIMIT:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var cutscene := Story._player
		if not is_instance_valid(cutscene) or not cutscene.is_running():
			if GameState.has_flag(&"ch2_yong_intro_seen"):
				break
			continue
		var id := cutscene.scene_id
		if id in BEATS and not id in _scenes:
			_scenes.append(id)
			_check(not GameState.has_flag(&"ch2_yong_intro_seen"), "S11 remains uncompleted on arrival at " + str(id))
		if id == INTRO:
			if cutscene._stage != null and cutscene._stage.stage_id == STAGE:
				_record_papers(cutscene)
			if not _opening and cutscene._stage != null and cutscene._dialogue.visible and cutscene._dialogue.is_complete():
				_opening = true
				_capture("opening")
			if _saw_hand and _mode == "leave":
				_capture("quit-during-hold")
				_check(_safe_progress(false), "quitting mid-hold preserves the original document ownership and unplayed flags")
				_finish(true)
				return
			if _saw_hand and _mode == "skip" and not _skip_sent:
				_skip_sent = true
				_capture("skip-during-hold")
				await _tap(&"ui_cancel")
				for _frame in 180:
					if not Story.is_cinematic_active():
						break
					await get_tree().process_frame
				var blocked_office := _level._portals.get(&"front_office") as Portal
				_skipped_without_progress = not Story.is_cinematic_active() and _safe_progress(false) \
					and is_instance_valid(blocked_office) and not blocked_office.is_open()
				_check(_skipped_without_progress, "Escape releases the held prop, leaves the office locked and preserves progress as before")
				_scenes.clear()
				_opening = false
				_saw_hand = false
				_paper.clear()
				if not await _interact(&"ch2_ledger_door"):
					_finish(false)
					return
				continue
			if _paper.size() == PAPER_X.size() and cutscene._dialogue.visible and cutscene._dialogue.is_complete() and not _all_on_desk:
				_all_on_desk = true
				_actual_reply = cutscene._dialogue._text.text
				_check(_actual_reply == REPLY[_lang], "the full authored line appears in the chosen language")
				_capture("three-papers")
		if cutscene._dialogue.visible and (id != INTRO or _opening) and frame % 16 == 7:
			await _tap(&"ui_accept")
	_check(_scenes == BEATS, "original intro, Xiaowei, and boxes play in their original order")
	_check(_opening and _saw_hand, "real native actor and held evidence appeared in the new authored theatre")
	if _mode == "skip":
		_check(_skip_sent and _skipped_without_progress, "the cancelled presentation can be replayed by the same door")
	_check(_all_on_desk and _paper.size() == 3, "three actual paper layers settle on the desk before Rin's response")
	for name in PAPER_X:
		var row: Array = _paper.get(name, [1000.0,1000.0])
		_check(absf(row[0]-PAPER_X[name]) < 0.1 and absf(row[1]) < 0.08, name + " is at its physical desk contact")
	for _frame in 60:
		if _safe_progress(true):
			break
		await get_tree().process_frame
	_check(_safe_progress(true), "completion writes only the intended introduction result, safeguards cash, and keeps all evidence")
	var office := _level._portals.get(&"front_office") as Portal
	_check(is_instance_valid(office) and office.is_open() and office.data.target_level == OFFICE, "original authored office door unlocks")
	_finish(true)


func _record_papers(cutscene: CutscenePlayer) -> void:
	for name in PAPER_X:
		var prop := cutscene._stage.prop_node(name)
		if not is_instance_valid(prop) or not prop.is_visible_in_tree():
			continue
		if cutscene._stage.prop_held(name):
			if not _saw_hand:
				_saw_hand = true
				_capture("holding-a-copy")
			continue
		if cutscene._stage.prop_state(name) == "lay_8" and not _paper.has(name):
			_paper[name] = [prop.position.x, prop.position.y + 51.5 * 0.2 - 215.0]


func _safe_progress(finished: bool) -> bool:
	if StoryItems.snapshot() != _items or Progression.credits != _credits:
		return false
	var disk := _store.read()
	var flags: Dictionary = disk.get("story", {}).get("flags", {})
	if bool(flags.get("ch2_yong_intro_seen",false)) != finished or GameState.has_flag(&"ch2_yong_intro_seen") != finished:
		return false
	for key: StringName in [&"ch2_yong_subdued", &"ch2_original_ledger_taken", &"yong_link_isolated", &"yong_link_revoked"]:
		if GameState.has_flag(key) or bool(flags.get(str(key),false)):
			return false
	return disk.get("level","") == FRONT and (not finished or str(disk.get("cinematic","")) == "")


func _wait_for_area(path: String) -> bool:
	for _frame in STEP_LIMIT:
		var current := _app.get("_screen") as Level
		if current != null and current.is_initialized() and current.data.resource_path == path and not bool(_app.call("_route_pending")):
			_level = current
			_level_path = path
			return true
		await get_tree().process_frame
	_check(false, "could not enter " + path)
	return false


func _interact(id: StringName) -> bool:
	for node in _level._entities.get_children():
		if not node is NpcActor or node.data.id != id:
			continue
		_level.player.global_position = node.global_position + Vector2(-26, 0)
		_level.player.velocity = Vector2.ZERO
		_level.camera.snap_to_target()
		for _frame in 70:
			if node.interaction_available() and _level.player.is_on_floor():
				await _tap(&"interact")
				return true
			await get_tree().physics_frame
	_check(false, "could not activate the original ledger door")
	return false


func _tap(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await get_tree().physics_frame
	await get_tree().process_frame
	event = InputEventAction.new()
	event.action = action
	Input.parse_input_event(event)
	await get_tree().process_frame


func _check(ok: bool, what: String) -> void:
	_checks += 1
	super._check(ok, what)


func _finish(ok: bool) -> void:
	var file := FileAccess.open(_out_dir.path_join("actual-route.json"),FileAccess.WRITE)
	var report := {"mode":_mode,"language":Story.language,"checks":_checks,"failures":_failures + int(not ok),"paper":_paper,
		"scenes":_scenes,"opening":_opening,"real_hold":_saw_hand,"all_on_desk":_all_on_desk,"skip":_skip_sent,"skipped_without_progress":_skipped_without_progress,
		"level":_level_path,"reply":_actual_reply,"credits":Progression.credits, "adapter":RenderingServer.get_video_adapter_name(),"hdr":get_viewport().use_hdr_2d}
	file.store_string(JSON.stringify(report,"  ")+"\n")
	file.close()
	_app.call("_quit", int(not ok or _failures>0))