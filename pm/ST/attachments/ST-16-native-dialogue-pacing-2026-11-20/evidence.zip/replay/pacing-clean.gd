extends "res://tools/prologue_play_probe.gd"

const PROLOGUE := "res://data/levels/ch1_prologue.tres"
const PAWNSHOP := "res://data/levels/ch1_pawnshop.tres"
var _start := -1
var _last := -1
var _read_frames := 18
var _free := 0
var _transitions := 0
var _excluded := 0
var _story_frames := 0
var _line_advances := 0
var _phase_frames := {}
var _remaining := {}
var _results_saved := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg == "--careful":
			_read_frames = 66
	Story.auto_skip = false
	Settings.set_skip_cutscenes(false)
	super._ready()


func _physics_process(_delta: float) -> void:
	if _results_saved or not is_instance_valid(_main):
		return
	var current: Variant = _main.get("_screen")
	var level := current as Level if is_instance_valid(current) else null
	if _start < 0:
		if level == null or level.data.resource_path != PROLOGUE or not is_instance_valid(level.player):
			return
		_start = Engine.get_physics_frames()
	if level != null and level.data.resource_path == PAWNSHOP:
		_last = Engine.get_physics_frames()
		_results_saved = true
		_save_pacing()
		return
	if level != null and is_instance_valid(level._pause_menu) and level._pause_menu._root.visible:
		_excluded += 1
		return
	var scene := Story._current_cinematic
	if Story.is_cinematic_active() and scene != &"":
		_story_frames += 1
		_phase_frames[String(scene)] = int(_phase_frames.get(String(scene), 0)) + 1
	elif level == null or _main.get("_pending_screen") != null:
		_transitions += 1
	else:
		_free += 1


func _confirm_reading() -> void:
	var action := InputEventAction.new()
	action.action = &"ui_accept"
	action.pressed = true
	Input.parse_input_event(action)
	var release := action.duplicate() as InputEventAction
	release.pressed = false
	Input.parse_input_event(release)


func _finish_story(shot := "") -> void:
	var capture := false
	var previous := ""
	var ready_frames := 0
	for i in 7200:
		if not Story.is_cinematic_active() and not Story._layer.is_radio_frozen():
			return
		var playable := Story._player
		var kind := ""
		var ready := false
		if is_instance_valid(playable) and playable.is_running():
			if playable.choice_active():
				kind = String(Story._current_cinematic) + ":choice"
				ready = true
			elif is_instance_valid(playable._dialogue) and playable._dialogue.visible:
				kind = playable._current_where
				ready = playable._dialogue.is_complete()
		elif Story._layer.is_cinematic_active():
			kind = "%s:%d" % [Story._current_cinematic, Story._layer._cinematic_index]
			ready = Story._layer._text.visible_ratio >= 1.0
		elif Story._layer.is_radio_frozen():
			kind = "radio:" + String(Story._layer._radio_text.text)
			ready = Story._layer._radio_text.visible_ratio >= 1.0
		if kind != previous or not ready:
			ready_frames = 0
		elif ready:
			ready_frames += 1
		previous = kind
		if not shot.is_empty() and not capture and ready:
			capture = true
			await _shot(shot)
		if ready and ready_frames == _read_frames:
			_confirm_reading()
			_line_advances += 1
		await _frames(1)
	_check(false, "the reading on the original route must finish with normal confirmation")


func _save_pacing() -> void:
	var total := _last - _start - _excluded
	var summary := {"true_in_game_frames":total, "physics_fps":Engine.physics_ticks_per_second,
		"story_frames":_story_frames, "playable_frames":_free,"transition_frames":_transitions,
		"pause_menu_frames_excluded":_excluded,"ordinary_confirmations":_line_advances,
		"frames_after_typeset":_read_frames,"story_frames_by_scene":_phase_frames,
		"release_path":_played,"deaths":GameState.deaths}
	var output := FileAccess.open(_out.path_join("pacing.json"), FileAccess.WRITE)
	output.store_string(JSON.stringify(summary, "  ") + "\n")
	print("PROLOGUE_PACING ",JSON.stringify(summary))

