extends Node
var reads := 0
func fact(kind: StringName, id: StringName) -> Variant:
	reads+=1
	if kind==&"flag":
		if id==&"ready":return true
		if id==&"name":return &"choice"
		return null
	if kind==&"receipt":return id==&"ch2.guest.settled"
	if kind==&"account":return "chapter3_done"
	return false
func _ready() -> void:run.call_deferred()
func run() -> void:
	var cases: Array[Dictionary]=[]
	for row in [
		["not unknown",{"not":{"unknown":true}},false],
		["any success cannot hide unknown",{"any":[{}, {"unknown":true}]},false],
		["any fact true cannot hide unknown",{"any":[{"flag":"ready"}, {"unknown":true}]},false],
		["all fact false cannot hide unknown",{"all":[{"flag":"missing"}, {"unknown":true}]},false],
		["not empty operator",{"not":{"all":[]}},false],
		["not malformed scalar",{"not":{"flag":"ready","equals":[]}},false],
		["empty",{},true], ["implicit equals",{"flag":"ready"},true],
		["missing null equals false",{"flag":"missing","equals":false},true],
		["StringName equality",{"flag":"name","equals":&"choice"},true],
		["second chapter receipt",{"receipt":"ch2.guest.settled","status":"recorded"},true],
		["third chapter account",{"account":"chapter3","equals":"chapter3_done"},true],
		["not empty true",{"not":{}},false]]:
		reads=0
		var actual:=StoryRules.holds(row[1],fact)
		cases.append({"name":row[0],"expected":row[2],"actual":actual,"reads":reads,"passed":actual==row[2] and (reads==0 if row[0] in ["all fact false cannot hide unknown","any fact true cannot hide unknown"] else true)})
	var failures:=cases.filter(func(r:Dictionary)->bool:return not r["passed"]).size()
	print("ST3_PROOF "+JSON.stringify({"cases":cases,"failures":failures}))
	await AudioRelease.settle(get_tree());get_tree().quit(1 if failures else 0)
