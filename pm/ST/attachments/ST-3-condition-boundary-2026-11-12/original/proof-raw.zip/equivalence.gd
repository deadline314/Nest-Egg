extends Node
const Legacy=preload("res://work/st3-proof/baseline_story_rules.gd")
var mode := 0
var reads := 0
var conditions: Array[Dictionary]=[]
func fact(kind: StringName, id: StringName) -> Variant:
	reads+=1
	if mode==0:return Story.fact(kind,id)
	if kind==&"flag":return [false,true,0,2,0.0,-0.5,"","ask","unset"][mode-1]
	if kind==&"account":return ["none","open200","paid200","owed200","gifted200"][mode%5]
	return mode%2==0
func collect(value: Variant, path: String) -> void:
	if value is Dictionary:
		if value.has("when"):conditions.append({"path":path+".when","condition":value["when"]})
		for key: Variant in value:collect(value[key],path+"."+String(key))
	elif value is Array:
		for i in value.size():collect(value[i],"%s[%d]"%[path,i])
func _ready() -> void:run.call_deferred()
func run() -> void:
	var rows: Array[Dictionary]=[]
	var failures := 0
	var before:=JSON.stringify({"flags":GameState.world_flags,"items":StoryItems.snapshot(),"progress":Story.progress_snapshot(),"wallet":Progression.snapshot()})
	for name in DirAccess.get_files_at("res://data/story"):
		if name.ends_with(".json"):
			var path:="res://data/story/"+name
			collect(JSON.parse_string(FileAccess.get_file_as_string(path)),path)
	for condition in conditions:
		var raw: Variant=condition["condition"]
		var bytes:=JSON.stringify(raw)
		var problem:=StoryRules.condition_error(raw,condition["path"])
		if not problem.is_empty():failures+=1
		var results: Array[Dictionary]=[]
		for strategy in 10:
			mode=strategy;reads=0
			var old: bool=Legacy.holds(raw,fact)
			var old_reads:=reads;reads=0
			var current:=StoryRules.holds(raw,fact,condition["path"])
			var equal:=old==current and old_reads==reads and JSON.stringify(raw)==bytes
			if not equal:failures+=1
			results.append({"strategy":strategy,"old":old,"new":current,"old_reads":old_reads,"new_reads":reads,"equal":equal})
		rows.append({"path":condition["path"],"schema_error":problem,"results":results})
	var after:=JSON.stringify({"flags":GameState.world_flags,"items":StoryItems.snapshot(),"progress":Story.progress_snapshot(),"wallet":Progression.snapshot()})
	if before!=after:failures+=1
	var data:={"conditions":conditions.size(),"comparisons":conditions.size()*10,"failures":failures,"no_state_mutation":before==after,"rows":rows,"scope":"All published data/story when nodes, live facts plus9 scalar/receipt/account strategies. Exact old body except omitted class_name; no natural playthrough or full facts/ledger adapter claim."}
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			var file:=FileAccess.open(arg.trim_prefix("--out="),FileAccess.WRITE);file.store_string(JSON.stringify(data,"  "));file.close()
	print("ST3_EQ "+JSON.stringify({"conditions":conditions.size(),"comparisons":conditions.size()*10,"failures":failures,"no_state_mutation":before==after}))
	await AudioRelease.settle(get_tree());get_tree().quit(1 if failures else 0)
