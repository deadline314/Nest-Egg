import hashlib,json,os,pathlib,re,shutil,subprocess,time
WT=pathlib.Path(__file__).resolve().parents[2];HERE=pathlib.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
out=HERE/'runs'/str(time.time_ns());out.mkdir(parents=True)
names=['core/story_rules.gd','core/story_condition_tree.gd','autoload/story.gd','tests/suite/test_cutscene.gd']+[p.relative_to(WT).as_posix() for p in (WT/'data/story').glob('*.json')]
before={n:sha(WT/n) for n in names}
for n in ('core/story_rules.gd','work/st3-proof/probe.gd','work/st3-proof/probe.tscn'):
    p=out/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(WT/n,p)
cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(WT),'--headless','res://work/st3-proof/probe.tscn'];env=os.environ.copy();env['APPDATA']=str(out/'appdata');env['LOCALAPPDATA']=str(out/'localappdata')
(out/'command.json').write_text(json.dumps({'argv':cmd,'source_before':before,'base':'6fb171a314894540880e972b2cc1a8fb1f4bce2d'},indent=2)+'\n',encoding='utf8',newline='\n')
with (out/'engine.log').open('wb') as f:r=subprocess.run(cmd,cwd=WT,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30)
text=(out/'engine.log').read_text(encoding='utf8',errors='replace');after={n:sha(WT/n) for n in names};data=[json.loads(l.split(' ',1)[1]) for l in text.splitlines() if l.startswith('ST3_PROOF ')];(out/'receipt.json').write_text(json.dumps({'exit_code':r.returncode,'source_after':after,'source_unchanged':before==after,'script_errors':text.count('SCRIPT ERROR'),'results':data},indent=2)+'\n',encoding='utf8',newline='\n');print(out);print(text);raise SystemExit(r.returncode)
