extends ScenarioBase

const WINDOW_ID := &"ch3_window_morning"
const MEASURED := &"room_morning_measured"
const LEVEL_PATH := "res://data/levels/ch3_showroom.tres"
var _window: NpcActor
var _completed := false
var _success := false
var _records: Dictionary = {}
var _lines: Array[String] = []
var _mode := "full"


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\","/")
		elif argument.begins_with("--mode="):
			_mode = argument.trim_prefix("--mode=")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = false
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch3_clearwater_tour_started", true, false)
	await _open()
	if _window == null:
		get_tree().quit(2)
		return
	var position := player.global_position
	var credits := Progression.credits
	_check(_window.interaction_available(), "morning window is reachable in the official level")
	_start_measurement.call_deferred()
	var seated := false
	var stood := false
	var prior_line := ""
	var sit_ticks := 0
	var stand_ticks := 0
	var observed_running := false
	for frame in range(2400):
		var scene := Story._player
		if scene != null and scene.is_running() and Story._current_cinematic == &"ch3_t_c16_morning":
			observed_running = true
			var line: String = scene._dialogue._text.text
			var actor := scene._actors.get(&"rin") as CutsceneActor
			if not line.is_empty() and line != prior_line and scene._dialogue.is_complete():
				prior_line = line
				_lines.append(line)
				if _lines.size() == 1 and _mode == "full":
					await _sample("invitation", actor)
				elif _lines.size() == 3 and _mode == "full":
					await _sample("trial-prompt", actor)
				if _mode == "cancel":
					Story.reset_active_presentation(&"leave")
				elif _mode == "skip":
					scene.skip()
				else:
					scene._advance_requested = true
			if _mode == "full" and actor != null and actor.rig != null:
				if actor.pose == &"walk" and not _records.has("walk"):
					await _sample("walk", actor)
				if actor.pose == &"sit":
					sit_ticks += 1
					if not seated and sit_ticks >= 38:
						await _sample("seated", actor)
						seated = true
				if seated and not stood and actor.pose == &"idle":
					var animator := actor.rig.animator as NpcAnimator
					if is_equal_approx(actor.position.x, 508.0) and animator.posture_progress() >= 0.99:
						stand_ticks += 1
						if stand_ticks >= 12:
							await _sample("stood", actor)
							stood = true
		if _completed:
			break
		await settle(1)
	_check(observed_running and _completed, "the original NPC interaction plays the morning scene to its result")
	_check(GameState.has_flag(MEASURED) == (_mode != "cancel"), "measurement commits only on completion or explicit skip")
	_check(Progression.credits == credits and not GameState.has_flag(&"sq3_room_proposal_done"), "the proposal and wallet are independent")
	if _mode == "full":
		_check(seated and stood and _lines.size() == 3 and _success, "full scene keeps the three original lines and finishes the seated animation")
		_check(player.global_position.distance_to(position) < 0.4 and not player.interaction.active, "returns control and preserves the player position")
		await finish()
		await _open()
		_check(GameState.has_flag(MEASURED), "the first inspection remains completed after re-entry")
		Story.auto_skip = true
		_check(await _window._talk(), "the revisit retains its short original interaction")
		_check(Progression.credits == credits, "revisit does not add rewards")
		if not DisplayServer.get_name() == "headless":
			await RenderingServer.frame_post_draw
			capture("revisited")
	var measured := GameState.has_flag(MEASURED)
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	AssetPrefetch.clear()
	var deadline := Time.get_ticks_msec() + 10000
	var assets := AssetPrefetch.stats()
	while assets.inflight > 0 and Time.get_ticks_msec() < deadline:
		await settle(1)
		assets = AssetPrefetch.stats()
	_check(assets.inflight == 0, "headless neighbour requests drain at shutdown")
	await settle(30)
	var output := {"adapter": RenderingServer.get_video_adapter_name(), "failures": failures,
		"mode": _mode, "records": _records, "lines": _lines, "completed": _completed, "measured": measured}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(output, "\t"))
	get_tree().quit(0 if failures == 0 else 1)


func _start_measurement() -> void:
	_success = await _window._talk()
	_completed = true


func _open() -> void:
	level = Level.new()
	level.configure(load(LEVEL_PATH) as LevelData)
	add_child(level)
	player = level.player
	level._next_story_trigger = level._layout.story_triggers.size()
	level.hud.visible = false
	_window = null
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		var npc := node as NpcActor
		if npc != null and npc.data.id == WINDOW_ID:
			_window = npc
	if _window == null:
		push_error("the showroom is missing the morning window")
		return
	player.global_position = _window.global_position + Vector2(-23, 0)
	player.velocity = Vector2.ZERO
	level.camera.set_physics_process(false)
	level.camera.position_smoothing_enabled = false
	level.camera.global_position = _window.global_position + Vector2(10, -30)
	level.camera.reset_smoothing()
	level.camera.force_update_scroll()
	await settle(62)


func _sample(id: String, actor: CutsceneActor) -> void:
	if actor == null:
		_check(false, "Rin has an authored seat actor")
		return
	if not DisplayServer.get_name() == "headless":
		await RenderingServer.frame_post_draw
	var location := {}
	for name in [&"hip", &"head", &"foot_front", &"foot_back"]:
		var bone := actor.rig.bone(name)
		var p := bone.global_position
		location[String(name)] = [p.x,p.y]
	var origin := actor.global_position
	_records[id] = {"pose": String(actor.pose), "facing": actor.facing,
		"bones": location, "origin": [origin.x,origin.y], "stage": String(Story._current_cinematic)}
	if not DisplayServer.get_name() == "headless":
		capture(id)


func _check(condition: bool, label: String) -> void:
	if not condition:
		failures += 1
		push_error(label)
