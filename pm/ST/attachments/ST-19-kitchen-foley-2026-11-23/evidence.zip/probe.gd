extends "res://tools/ch2_flow_probe.gd"

const RINSE := &"ch2_sink_rinse"
const SET_DOWN := &"ch2_roof_cup"
const Capture := preload("res://tools/viewport_capture.gd")

var _cues: Array[StringName] = []
var _live: Dictionary[StringName, int] = {}
var _captured := false
var _checks := 0


func _run() -> void:
	if DisplayServer.get_name() != "headless":
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	Settings.use_storage("user://kitchen_sound_probe.cfg")
	Story.set_language("en")
	GameState.start_new_run(GameState.difficulties[1])
	Story.reset_progress()
	Story.auto_skip = false
	_carry_ch1_results()
	add_child(LightKit.create_environment())
	await _enter("ali_home")
	var credits := Progression.credits
	_check(not GameState.has_flag(&"sq1_soup_practice_done"), "soup practice begins incomplete")
	Sfx.sound_played.connect(_on_sound)
	await _talk(&"ch2_ali_home", ["wash", "right", "left"])
	await _settle(3)
	Sfx.sound_played.disconnect(_on_sound)
	_check(_cues == [RINSE, SET_DOWN, RINSE, SET_DOWN], "both decisions played rinse and ceramic contact once and in order (%s)" % [_cues])
	_check(_live.get(RINSE, 0) == 2 and _live.get(SET_DOWN, 0) == 2, "all four cues used an active voice playing its file resource (%s)" % [_live])
	_check(GameState.has_flag(&"sq1_soup_practice_done") and Progression.credits == credits + 40,
		"correct placement still completes the task and awards 40 credits once (delta %d)" % (Progression.credits - credits))
	await _talk(&"ch2_ali_home")
	_check(Progression.credits == credits + 40 and not get_tree().paused, "revisiting preserves the reward and releases gameplay")
	if DisplayServer.get_name() != "headless":
		_check(_captured, "native capture taken during the real dry-rack rinse")
	print("checks: %d, failures: %d" % [_checks, _failures])
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(_failures != 0))


func _check(ok: bool, what: String) -> void:
	_checks += 1
	super._check(ok, what)


func _on_sound(id: StringName) -> void:
	if id != RINSE and id != SET_DOWN:
		return
	var action: WorldPropAction = _level.player._visual.interaction_action
	var expected_phase := "scrub" if id == RINSE else "place"
	_cues.append(id)
	_check(action != null and action.phase == expected_phase, "%s matches original world action phase %s" % [id, expected_phase])
	_observe_voice.call_deferred(id)
	if id == RINSE and action != null and action._spec.get("scene") == "ch2_t_s07_soup" \
			and DisplayServer.get_name() != "headless":
		_capture_rinse.call_deferred()


func _observe_voice(id: StringName) -> void:
	for i in Sfx._players.size():
		if Sfx._voice_sound[i] == id and Sfx._players[i].playing and Sfx.source_of(id) == &"file":
			_live[id] = int(_live.get(id, 0)) + 1
			return


func _capture_rinse() -> void:
	for i in 8:
		await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var image := Capture.image(get_viewport())
	_captured = image.save_png(_out_dir.path_join("sink.png")) == OK
