from pathlib import Path
import zipfile,hashlib,json,shutil
root=Path('.'); dest=root/'pm/ST/attachments/ST-10-kitchen-candidates'; items=[]
for f in (root/'work/st10-contacts').rglob('*'):
 if f.is_file() and f.suffix not in ('.pyc',):items.append((f,str(f)))
for f in (root/'assets_src/candidates/st10_contacts_1022').rglob('*'):
 if f.is_file(): items.append((f,str(f)))
base=Path('/workspace/Nest-Egg/work/batch1020b')
for name in ['st10-1022-material-preview','st10-1022-material-preview-v2']:
 for f in (base/name).rglob('*'):
  if f.is_file(): items.append((f,'native/'+name+'/'+f.name))
 for suffix in ['.log','.exit','-xvfb.log']:
  f=base/(name+suffix)
  if f.exists():items.append((f,'native/'+f.name))
items.append((base/'native.py','native/native.py'))
for name in ['data/cutscene/stages/ch1_pawnshop_kitchen.json','data/story/ch1_kasa.json','game/cutscene/cutscene_actor.gd','game/cutscene/cutscene_player.gd','game/cutscene/stage_layers.gd','tools/viewport_capture.gd']:
 items.append((root/name,'frozen/'+name))
manifest=[]
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f,name in sorted(items,key=lambda x:x[1]):
  data=f.read_bytes(); z.writestr(name,data);manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(dest/'raw.zip') as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(manifest)
 for e in manifest:
  data=z.read(e['path']);assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
f=dest/'raw.zip'; m={'base':'a7c4f50a8f2dbb9b2ce5e966e4fc05fae9a98911','zip_bytes':f.stat().st_size,'zip_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'all_entries_read_back':True,'entries':manifest}
(dest/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print({k:v for k,v in m.items() if k!='entries'});print('entries',len(manifest))
