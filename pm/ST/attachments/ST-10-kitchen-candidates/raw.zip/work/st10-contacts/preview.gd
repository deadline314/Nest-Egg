extends Node

const Capture := preload("res://tools/viewport_capture.gd")
var out := ""
var checks := 0
var failures := 0
var records: Array = []

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	_run.call_deferred()

func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
	print("%s %s" % ["PASS" if ok else "FAIL", label])

func shot(name: String, player: CutscenePlayer) -> void:
	await RenderingServer.frame_post_draw
	var png := Capture.image(get_viewport())
	check(png.save_png(out.path_join(name + ".png")) == OK, "capture " + name)
	var actors := {}
	for id in player._actors:
		var actor: CutsceneActor = player._actors[id]
		actors[id] = {"position": [actor.position.x, actor.position.y], "scale": actor.scale.x,
			"facing": actor.facing, "ground_y": actor.ground_y, "pose": String(actor.pose)}
	records.append({"name": name, "size": [png.get_width(), png.get_height()], "actors": actors,
		"camera": [player.cam_pos.x, player.cam_pos.y, player.cam_zoom]})

func _run() -> void:
	check(not out.is_empty() and DisplayServer.get_name() != "headless", "native output supplied")
	DirAccess.make_dir_recursive_absolute(out)
	var scene: Dictionary = Story._scenes["ch1_c14_home"].duplicate(true)
	# Preserve the authored stage, camera, actors and actual walk. Stop before dialogue/results.
	scene["steps"] = scene["steps"].slice(0, 4)
	scene["steps"].append({"do": "wait", "time": 60.0})
	var player := CutscenePlayer.new()
	add_child(player)
	player.play(&"st10_material_preview", scene)
	var deadline := Time.get_ticks_msec() + 30000
	while player.steps_run < 4 and Time.get_ticks_msec() < deadline:
		await get_tree().process_frame
	check(player.steps_run >= 4, "authored walk reached the idle hold")
	await get_tree().create_timer(0.5).timeout
	await shot("kitchen-before", player)
	var background: Sprite2D
	for layer in player._stage.back.get_children():
		if layer is Sprite2D and layer.texture != null and layer.texture.get_width() > 1000:
			background = layer
	check(background != null, "actual kitchen background located")
	if background != null:
		var img := Image.load_from_file("res://work/st10-contacts/candidates/kitchen-empty-generated.png")
		check(img != null and img.get_size() == Vector2i(1672, 941), "actual generated canvas verified")
		background.texture = ImageTexture.create_from_image(img)
		background.scale = Vector2.ONE * (1280.0 / img.get_width())
		await get_tree().process_frame
		await shot("kitchen-empty-candidate", player)
		var kettle_img := Image.load_from_file("res://work/st10-contacts/candidates/kettle-generated.png")
		check(kettle_img != null and kettle_img.get_format() == Image.FORMAT_RGBA8, "kettle has real RGBA")
		var kettle := Sprite2D.new()
		kettle.texture = ImageTexture.create_from_image(kettle_img)
		kettle.centered = false
		kettle.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
		# Candidate placement only: actual alpha bbox is measured separately; never a hand attachment.
		kettle.scale = Vector2.ONE * (42.0 / 905.0)
		kettle.position = Vector2(85.0, 177.5) - Vector2(676.0, 1080.0) * kettle.scale
		player._stage.back.add_child(kettle)
		await get_tree().process_frame
		await shot("kitchen-kettle-candidate", player)
		check(player._actors[&"rin"].position.is_equal_approx(Vector2(330, 304)), "Rin authored position unchanged")
		check(player._actors[&"k"].position.is_equal_approx(Vector2(120, 304)), "Old K authored position unchanged")
		check(is_equal_approx(kettle.position.y + 1080.0 * kettle.scale.y, 177.5), "candidate kettle body bottom is the measured burner support")
		player.cam_pos = Vector2(85.0, 185.0)
		player.cam_zoom = 2.0
		await get_tree().process_frame
		await shot("kitchen-support-closeup-candidate", player)
	player.skip()
	while player.is_running():
		await get_tree().process_frame
	player.queue_free()
	await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	var file := FileAccess.open(out.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"checks": checks, "failures": failures, "records": records,
		"scope": "material candidate preview on authored opening and walk; no hand contact, flame, filling, results or full action acceptance"}, "\t"))
	print("ST10 candidate checks %d failures %d" % [checks, failures])
	get_tree().quit(1 if failures else 0)
