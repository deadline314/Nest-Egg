import os,subprocess,json,sys
from pathlib import Path
w=Path('/workspace/Nest-Egg/work/batch1026');b=w/'dummy-texture-worktree';env=os.environ.copy();env.update(GODOT=str(w/'godot-texture-build/dist/godot'),SHARDS='4',LOG_DIR=str(w/'st9-clinic-actions-affected-v1-shards'))
tasks=[('affected',['bash','tools/run_tests_changed.sh','origin/main']),('dummy-exit',['python3','tools/check_dummy_texture_exit.py',env['LOG_DIR']]),('clinic',['python3','tools/run_clinic_completion.py','--godot',env['GODOT'],'--output',str(w/'st9-clinic-actions-clinic-v1')])]
r=[]
for name,cmd in tasks:
 log=w/('st9-clinic-actions-'+name+'-v1.log')
 with log.open('w') as f:code=subprocess.run(cmd,cwd=b,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 (w/('st9-clinic-actions-'+name+'-v1.exit')).write_text(str(code)+'\n');r.append({'name':name,'exit':code,'log':str(log)});(w/'st9-clinic-actions-final-v1.json').write_text(json.dumps(r,indent=2)+'\n');print(name,code,flush=True)
 if code:sys.exit(code)
