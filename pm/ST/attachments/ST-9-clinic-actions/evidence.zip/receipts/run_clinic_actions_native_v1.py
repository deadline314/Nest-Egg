from pathlib import Path
import subprocess,os,json,hashlib,re,time,shutil
w=Path('/workspace/Nest-Egg/work/batch1026');b=w/'dummy-texture-worktree';n=w.parent/'batch1020b'
out=w/'st9-clinic-actions-native-final-v1';out.mkdir()
source=out/'source';source.mkdir()
for name in ['tests/probes/clinic_actions.gd','tests/probes/clinic_actions.tscn']:
 p=source/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(b/name,p)
env=os.environ.copy();env.update(NE_NATIVE_PROJECT='../batch1026/dummy-texture-worktree',NE_NATIVE_GODOT=str(w/'godot-texture-build/dist/godot'))
receipt={'cases':[],'source_sha256':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}}
started=time.monotonic()
for mode in ['normal_take','retry_take','write_take','read_take']:
 tag='st9-clinic-actions-'+mode.replace('_','-')+'-native-final-v1'
 slot=out/(mode+'-slot');slot.mkdir()
 if mode=='read_take':
  raw=(out/'write_take-slot/pending-primary.json').read_bytes();(slot/'slot.json').write_bytes(raw)
  receipt['pending_sha256']=hashlib.sha256(raw).hexdigest()
 cmd=['python','/workspace/Nest-Egg/work/batch1024/native-large.py',tag,'res://tests/probes/clinic_actions.tscn','--mode='+mode,'--save-dir='+str(slot)]
 with (out/(mode+'-wrapper.log')).open('w') as log:r=subprocess.run(cmd,cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(n/(tag+'.log')).read_text();bad=[x for x in text.splitlines() if re.search(r'^ERROR:|SCRIPT ERROR|Parse Error|^FAIL(?:\s|:)|handle_crash:|leaked at exit|resources still in use',x)]
 result=json.loads((n/tag/'result.json').read_text()) if (n/tag/'result.json').exists() else {}
 case={'mode':mode,'tag':tag,'exit':r.returncode,'diagnostics':bad,'result':result,'passed':r.returncode==0 and not bad and result.get('checks',0)>0 and result.get('failures')==[]}
 receipt['cases'].append(case);receipt['wall_seconds']=round(time.monotonic()-started,3);(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(mode,case['passed'],result.get('checks'),flush=True)
 if not case['passed']:raise SystemExit(1)
