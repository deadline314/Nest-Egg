extends "res://tests/probes/clinic_original.gd"
## Measure real current rig contacts before deciding prop placement or making art.
func _finish() -> void:
	var movie := _movie()
	_check(movie != null and Story._current_cinematic == TRAY,"contact plan uses the actual original first-clinic tray")
	var rows: Array = []
	if movie != null:
		var actor: CutsceneActor = movie._actors.get(&"rin")
		_check(actor != null and actor.rig != null,"current seated original rig exists")
		if actor != null and actor.rig != null:
			var stage: Node2D = movie._stage
			var original_lengths := _lengths(actor,stage)
			for plan: Dictionary in [
				{"label":"cup_pickup","hand":"back","to":[330.0,185.6],"angle":PI/6.0},
				{"label":"cup_aside","hand":"back","to":[343.0,185.6],"angle":PI/6.0},
				{"label":"cloth_corner","hand":"front","to":[326.0,186.0],"angle":PI/2.0},
				{"label":"jacket_pocket","hand":"front","to":[315.0,168.0],"angle":-PI/2.0},
			]:
				var step := {"do":"reach","id":"rin","hand":plan["hand"],"to":plan["to"],"angle":plan["angle"],"time":0.2,"grip":true}
				_check(actor.set_hand_target(step),"original hand contact plan admits "+plan["label"])
				for i in 20:
					await get_tree().physics_frame
				await get_tree().process_frame
				var p := stage.to_local(actor.hand_contact_global(StringName(plan["hand"])))
				var target := Vector2(plan["to"][0],plan["to"][1])
				var error := p.distance_to(target)
				var hand := &"hand_front" if plan["hand"] == "front" else &"hand_back"
				var offset := actor.rig.hand_grip_offset(hand)
				var lengths := _lengths(actor,stage)
				rows.append({"plan":plan,"actual":[p.x,p.y],"error":error,"grip_offset":[offset.x,offset.y],"baseline_lengths":original_lengths,"lengths":lengths})
				for key: String in original_lengths:
					_check(absf(lengths[key]-original_lengths[key]) <= 0.001,"planned real contact preserves original bone length: "+plan["label"]+"/"+key)
				_check(actor.hand_target_settled(StringName(plan["hand"])) and error <= 1.0,"unmodified real grip reaches planned contact within 1 stage pixel: "+plan["label"])
	DirAccess.make_dir_recursive_absolute(output)
	FileAccess.open(output.path_join("contacts.json"),FileAccess.WRITE).store_string(JSON.stringify(rows,"  "))
	await super._finish()

func _lengths(actor: CutsceneActor, stage: Node2D) -> Dictionary:
	var result := {}
	for side: String in ["front","back"]:
		var a := stage.to_local(actor.rig.bone(StringName("arm_"+side+"_upper")).global_position)
		var b := stage.to_local(actor.rig.bone(StringName("arm_"+side+"_lower")).global_position)
		var c := stage.to_local(actor.rig.bone(StringName("hand_"+side)).global_position)
		result[side+"_upper"] = a.distance_to(b)
		result[side+"_lower"] = b.distance_to(c)
	return result
