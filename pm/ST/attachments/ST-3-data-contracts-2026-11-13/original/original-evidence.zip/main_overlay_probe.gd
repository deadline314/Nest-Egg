extends "res://tools/run_save_probe.gd"
const Sources := preload("res://game/story_result_sources.gd")
const Catalog := preload("res://core/story_result_catalog.gd")
const ROOM := "res://data/levels/ch2_market_gate.tres"
class FaultStore extends RunSaveStore:
	var block := false
	var capture := false
	var prepared: Dictionary = {}
	func prepare_existing_write(raw: Variant) -> Dictionary:
		if capture: prepared = super.prepare_existing_write(raw)
		return {"error":"test_bad_cutscene injected exact existing-slot preparation refusal"} if block else super.prepare_existing_write(raw)
var intervention_done := false
var retried := false
var modes_seen: Array = []
var actor: NpcActor
var store: RunSaveStore
var counts_before := 0
var publications: Array = []
var refusal_observed := false
var origins_seen: Array = []

func _run() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Transition.instant = true
	Enemy.activation_culling_enabled = false
	Story.auto_skip = true
	Sources._catalog = Catalog.new("res://tests/fixtures/story_contracts_data_only/catalog.json")
	_main = MainScript.new()
	store = FaultStore.new(_directory.path_join("slot.json"))
	_main.set("_run_store",store)
	add_child(_main)
	await get_tree().process_frame
	if _mode == "cold": _main.call("_on_continue_requested")
	else: _main.call("_on_start_requested",GameState.difficulties[1])
	await _until(func() -> bool: return _main.get("_screen") is Level and (_main.get("_screen") as Level).is_initialized() and not _main.call("_route_pending"), "initial Main Level settles")
	_main.call("_on_area_requested",ROOM)
	await _until(func() -> bool: return _main.get("_level_path") == ROOM and _main.get("_screen") is Level and (_main.get("_screen") as Level).is_initialized() and not _main.call("_route_pending"), "real original market Level settles")
	var level := _main.get("_screen") as Level
	for node: Node in level._entities.get_children():
		if node is NpcActor and node.data.resource_path == "res://data/npcs/ch2_patroller.tres": actor = node; break
	_check(actor != null and actor.is_present(), "find actual original patroller spawn")
	if actor == null: await _done(); return
	if _mode == "cold":
		var saved: Dictionary = RunSaveCodec.decode(FileAccess.get_file_as_string(store.path))["data"]
		_check(GameState.has_flag(&"ch2_patrol_requested") and GameState.has_flag(&"ch2_patrol_copy_received") and StoryItems.holds(&"ch2_patrol_copy"),"new process resumes actual saved flag and manual original")
		_check(actor.talk_count == saved["runtime"]["world"][actor.state_key()]["talks"] and actor.talk_count == 1,"new process restores exact original NPC completion once")
		var before := var_to_bytes([StoryItems.snapshot(),GameState.world_flags,actor.talk_count])
		Story._on_cinematic_finished(&"ch2_t_patrol_copy",1)
		Story._on_passive_finished(&"ch2_t_patrol_copy",1)
		_check(var_to_bytes([StoryItems.snapshot(),GameState.world_flags,actor.talk_count]) == before,"stale previous-process callbacks cannot repeat an item/count/result")
		_check(Story._passive_contexts.is_empty(),"transient NPC contexts are never restored from disk")
		await _done();return
	level.player.global_position = actor.global_position + Vector2(-40,0)
	GameState.set_flag(&"test_contract_ack_mode",_mode == "ack")
	GameState.set_flag(&"test_contract_copy_mode",_mode != "ack" and not _mode.begins_with("other_"))
	if _mode.begins_with("other_"): GameState.set_flag(&"test_contract_bypass_mode",true)
	Story.auto_skip = false
	_main.call("_save_run",true)
	counts_before = actor.talk_count
	GameState.flag_changed.connect(_observe_flag)
	GameState.flag_changed.connect(_observe_bypass)
	StoryItems.acquired.connect(_observe_item)
	Story.scene_started.connect(_observe_start)
	(store as FaultStore).block = _mode in ["retry","catalog_reload"]
	(store as FaultStore).capture = _mode == "catalog_reload"
	actor._talk()
	var deadline := Time.get_ticks_msec() + 30000
	while Time.get_ticks_msec() < deadline:
		if not modes_seen.is_empty() and not actor.get("_talking") and _mode != "other_radio_chain": break
		var prompt: Control = (_main.get("_result_completion") as Node).get("_prompt")
		var flag_prompt: Control = (_main.get("_story_completion") as Node).get("_prompt")
		if prompt != null or flag_prompt != null:
			if _mode == "catalog_reload":
				var owner: Node = _main.get("_result_completion")
				var old_revision := Sources.revision()
				var old_generation := Story.presentation_generation()
				var old_contract := Sources.choice("ch2_t_patrol_copy_prompt",Story._player._choice_options[0],Story._scenes,Story._scene_sources)
				_check((store as FaultStore).prepared.has("data"),"pre-reload request owns a real prepared existing-slot ticket")
				_write_reloaded_catalog()
				Story.load_all()
				_check(Sources.revision() > old_revision and Story.presentation_generation() > old_generation,"real catalog change retires original request via existing load reset")
				var rejected: Dictionary = owner._prepare_and_commit(old_contract,&"ch2_t_patrol_copy",true)
				_check(rejected.has("error") and not GameState.has_flag(&"ch2_patrol_requested") and not StoryItems.holds(&"ch2_patrol_copy"),"delayed original prepared contract cannot commit against reloaded data")
				_check(Story._passive_contexts.is_empty() and not owner.blocks_save(),"reload clears original request state and transient source")
				await _done();return
			if _mode == "retry" and not retried:
				_check(not GameState.has_flag(&"ch2_patrol_requested") and not StoryItems.holds(&"ch2_patrol_copy") and actor.talk_count == counts_before and publications.is_empty(),"failed real Main preparation publishes nothing and keeps original NPC progress")
				_check(RunSaveCodec.decode(FileAccess.get_file_as_string(store.path))["data"]["story"]["flags"].get("ch2_patrol_requested",false) == false,"failure keeps durable primary before intent")
				(store as FaultStore).block = false;retried = true
				prompt.retry_requested.emit()
				await get_tree().process_frame
				continue
			if _mode in ["other_mainflags","other_radio_item","other_radio_chain","fake_origin"]: refusal_observed = true
			else: _check(false,"unexpected durable refusal: " + String(Story._current_cinematic))
			break
		var player: CutscenePlayer = Story._player if is_instance_valid(Story._player) else null
		if player != null and player.choice_active():
			if not intervention_done:
				intervention_done = true
				if _mode == "cancel":
					Story.reset_active_presentation(&"leave")
					break
				if _mode == "unrelated_reload":
					var revision := Sources.revision()
					var token := Story.current_presentation_request()
					Story.load_chapter("res://tests/fixtures/run_save_choice.json")
					_check(Sources.revision() == revision and Story.current_presentation_request() == token and player.choice_active(),"unrelated chapter load preserves exact original request and catalog revision")
				if _mode == "fake_origin":
					Story._presentation_context["source_id"] = "forged-not-an-original-actor"
				if _mode == "live_mutation":
					Story._scenes["ch2_t_patrol_copy_prompt"]["steps"].back()["options"][0]["set_flags"]["ch2_patrol_requested"] = false
			var wanted := "later" if _mode == "return" else "accept"
			var index := player._choice_options.find_custom(func(option:Dictionary)->bool: return option.get("id") == wanted)
			var accepted := index >= 0 and player.choose(index)
			_check(not accepted if _mode in ["fake_origin","live_mutation"] or (_mode in ["retry","catalog_reload"] and not retried) else accepted, "public actual menu respects producer and content: " + wanted)
		elif player != null and player.is_running() and player._dialogue.visible:
			player._dialogue.complete()
			player._advance_requested = true
		elif Story._layer.is_radio_frozen(): Story._layer.advance_radio()
		elif Story._layer.is_cinematic_active(): Story._layer.advance()
		await get_tree().process_frame
	if _mode.begins_with("other_"):
		if _mode == "other_radio_chain":
			_check(refusal_observed and modes_seen.has("ch2_t_patrol_unknown_material"),"unregistered material continuation reaches actual refusal")
			_check(not StoryItems.holds(&"ch2_patrol_copy") and GameState.has_flag(&"test_contract_bypass_seen"),"legitimate first flag commits while material continuation cannot fall back")
			_check(origins_seen.size() == 2 and origins_seen[0]["context"] == origins_seen[1]["context"] and not origins_seen[1]["context"].is_empty(),"passive then retains its original sanitized NPC source")
		elif _mode == "other_radio_flags":
			_check(not refusal_observed and GameState.has_flag(&"test_contract_bypass_seen"),"existing flag-only important radio is legitimately accepted")
			_check(publications.size() == 1 and publications[0].get("flag_owner_publishing",false),"actual original FlagCompletion owns the notification")
		else:
			_check(refusal_observed,"unsupported new NPC metadata reaches a real refusal")
			_check(not GameState.has_flag(&"test_contract_bypass_seen") and not StoryItems.holds(&"ch2_patrol_copy"),"metadata rename cannot grant flag/item through legacy")
			_check(actor.talk_count == counts_before,"refused metadata preserves NPC progress")
		Story.reset_active_presentation(&"leave")
		await _done()
		return
	if _mode in ["cancel","fake_origin","live_mutation"]:
		_check(not GameState.has_flag(&"ch2_patrol_requested") and not StoryItems.holds(&"ch2_patrol_copy") and not GameState.has_flag(&"ch2_patrol_copy_received"),"cancelled or invalid real request cannot grant results")
		_check(actor.talk_count == counts_before and publications.is_empty(),"rejected request preserves NPC count and never publishes")
		_check(Story._passive_contexts.is_empty(),"rejected/cancelled request leaves no passive context")
		Story.reset_active_presentation(&"leave")
		await _done();return
	_check(not actor.get("_talking"), "real NPC interaction retires within bound")
	_check(actor.talk_count == counts_before + 1,"real original NPC talk count advances exactly once")
	if _mode == "ack":
		_check(GameState.has_flag(&"ch2_patrol_note_seen"),"new data-only NPC flag completes")
		_check(not StoryItems.owns(&"ch2_patrol_copy"),"flag-only content cannot grant manual item")
	else:
		_check(GameState.has_flag(&"ch2_patrol_requested") == (_mode != "return"),"choice intent matches actual selected route")
		_check(StoryItems.holds(&"ch2_patrol_copy") == (_mode != "return"),"manual item follows real accept only")
		_check(GameState.has_flag(&"ch2_patrol_copy_received") == (_mode != "return"),"manual item result flag matches selected route")
	_check(publications.size() == (1 if _mode == "ack" else (0 if _mode == "return" else 3)), "each actual result notification is observed exactly once")
	var decoded := RunSaveCodec.decode(FileAccess.get_file_as_string(store.path))
	_check(decoded.has("data"),"actual committed primary decodes with original checksum")
	if decoded.has("data"):
		var flags: Dictionary = decoded["data"]["story"]["flags"]
		_check(flags.get("ch2_patrol_note_seen",false) == GameState.has_flag(&"ch2_patrol_note_seen") and flags.get("ch2_patrol_requested",false) == GameState.has_flag(&"ch2_patrol_requested"),"actual disk flags match live results")
	await _done()

func _observe_bypass(id: StringName, value: Variant) -> void:
	if id != &"test_contract_bypass_seen" or value != true: return
	var decoded := RunSaveCodec.decode(FileAccess.get_file_as_string(store.path))
	var publishing: bool = (_main.get("_story_completion") as Node).get("_publishing")
	publications.append({"event":String(id),"flag_owner_publishing":publishing,"primary_valid":decoded.has("data")})
	if _mode == "other_radio_flags":
		_check(decoded.has("data") and decoded["data"]["story"]["flags"].get("test_contract_bypass_seen") == true,"legitimate other-owner flag is on disk before notification")

func _observe_flag(id: StringName, value: Variant) -> void:
	if id not in [&"ch2_patrol_note_seen", &"ch2_patrol_requested", &"ch2_patrol_copy_received"] or value != true: return
	_observe(String(id), id != &"ch2_patrol_requested")

func _observe_item(item: StoryItemData) -> void:
	if item.id == &"ch2_patrol_copy": _observe("item:" + String(item.id),true)

func _observe(label: String, final: bool) -> void:
	var bytes := FileAccess.get_file_as_bytes(store.path)
	var decoded := RunSaveCodec.decode(bytes.get_string_from_utf8())
	_check(decoded.has("data"), "primary is already valid inside first result notification: " + label)
	var expected_count := counts_before + int(final)
	if decoded.has("data"):
		var saved: Dictionary = decoded["data"]
		_check(actor.talk_count == expected_count and saved["runtime"]["world"][actor.state_key()]["talks"] == expected_count,"live/disk NPC count published atomically: " + label)
		if label.begins_with("item:"):
			_check(saved["story"]["items"]["held"].has("ch2_patrol_copy"),"manual original is on disk before acquire notification")
		else:
			_check(saved["story"]["flags"].get(label) == true,"actual result flag is on disk before notification: " + label)
	FileAccess.open(_directory.path_join(label.replace(":","-") + "-notification-primary.json"),FileAccess.WRITE).store_buffer(bytes)
	publications.append({"event":label,"live_count":actor.talk_count,"expected_count":expected_count})

func _until(predicate: Callable, message: String) -> void:
	var deadline := Time.get_ticks_msec() + 30000
	while not predicate.call() and Time.get_ticks_msec() < deadline: await get_tree().process_frame
	_check(predicate.call(),message)

func _done() -> void:
	var f := FileAccess.open(_directory.path_join("result.json"),FileAccess.WRITE)
	f.store_string(JSON.stringify({"mode":_mode,"checks":_checks,"failures":Array(_failures),"scenes":modes_seen,"before_count":counts_before,"publications":publications,"origins":origins_seen,"after_count":actor.talk_count if is_instance_valid(actor) else -1},"  "));f.close()
	print("MAIN_DATA_ONLY ",_mode," ",_checks," checks / ",_failures.size()," failures")
	_main.call("_quit",0 if _failures.is_empty() else 1)

func _observe_start(id: StringName, _kind: StringName) -> void:
	modes_seen.append(String(id))
	var requests: Array = Story._passive_requests.get(id,[])
	var request: int = requests.back() if not requests.is_empty() else Story.current_presentation_request()
	origins_seen.append({"id":String(id),"request":request,"context":Story.presentation_context_for_request(id,request)})

func _write_reloaded_catalog() -> void:
	var folder := "user://test_bad_cutscene_catalog_reload"
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(folder))
	for chapter: String in ["ch1","ch2"]:
		var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/story_contracts_data_only/" + chapter + ".json"))
		if chapter == "ch2":
			for record: Dictionary in data["records"]:
				if record["id"] == "ch2_t_patrol_copy_prompt": record["rule"]["options"][0]["flags"]["ch2_patrol_requested"] = false
		var file := FileAccess.open(folder.path_join(chapter + ".json"),FileAccess.WRITE)
		file.store_string(JSON.stringify(data));file.close()
	var root := {"version":1,"chapters":[{"source":"res://data/story/ch1_kasa.json","path":"ch1.json"},{"source":"res://data/story/ch2_heron.json","path":"ch2.json"}]}
	var file := FileAccess.open(folder.path_join("catalog.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(root));file.close()
	Sources._catalog._path = folder.path_join("catalog.json")
