# ST3 catalog：三態 caller 分流提案 v1（owner 尚未接線）

## 固定事實

base5a。48 catalog NPC rows 已純讀100/0；schema negatives24/0，原全部紀錄保留。尚未修改 Story loader／owner 行為（completion 只移除舊死 const），不把這些當真 Main 保存驗收。

目前 `_writes` 把每個 choice 當寫入過寬，會修成只看實際 `results/set_flags/transfer_items`、必要保存政策；純顯示選單的 target 是演出接續，不直接當物品／交易提交。例 `ch1_t_handoff_confirm`、`ch1_t_ali_1`、`ch1_hub_brief`、`ch2_t_s01_settle`、`ch2_t_s18_ticket` 都無直接 intent/results，須保留原流程，目的段仍受其真 owner。

剔除純選單後仍有33條 ch2 既有直接 effects 不在本次有限表，例 `ch2_t_s01_settled`（真交易+flag）、`ch2_t_s02_saved`（flag/交易/原件）、`ch2_t_s03_rain`（flag+manual item）、`ch2_t_s12_choice`（enum intent）、`ch2_t_s18_name/done` 等。清單在 direct-writes-ch2_heron.json。ch1 剩餘1條 `ch1_c09_wake` 實由 Clinic adapter 接，不須新泛用處理。不能將33條借新 catalog 改稱原已原子耐久。

## 真 caller / origin

`NpcActor._present_talk:268–303` 入隊時附 framing_source=person/object、真state_key/source_id、talk_index，自己設 `_talking/_presentation_index`。`Story.current_presentation_context:804` 只是副本，`presentation_context:790` 只是型別清理，**本身不是授權**。`Story.is_npc_presentation:826` 由原 talk entry 經 then/options/dispatch 可達性檢查，可重用但仍須實體證據。

`StoryResultCompletion._npc_source:328–344` 已驗 current persistent Level、actor原resource、level.npc_sources、state_key、原layout spawn/cell、talk_index、真talk可達，然後 prepare_story_completion。未知contract不能直接呼叫這個方法來分流，因它先要求 Sources.npc_source(id)。最小拆出只辨識實體來源的 private helper，保留前述原證據（含目前request/actor活著）；**回傳僅判斷此請求是否真的來自NPC，不授結果權限**。正式 `_npc_source` 仍再比對catalog NPC/Level並調原prepare。

分流辨識不能依賴 reward-free prepare 成功才承認 NPC：自帶獎勵的真NPC也應屬NPC請求，不能因prepare拒絕而落到legacy。若context聲稱person/object但沒有真actor/spawn/talk/request，屬INVALID，不能當NOT_NPC。已知protected id即使context/policy被刪也先走本owner拒絕。

## 分流順序（不把 REFUSED 改成 NOT_OWNED）

1. 原 FlagSources／Clinic／dinner 等明確adapter保持原准入。其他 protected ID（有效catalog或封固初始ownership名單）無條件進catalog inspect；MATCH仍接原Main證據，REFUSED回handled=true/ready=false或原choice拒絕流程。
2. 未登記、無直接effects的純呈現／純選單，照原演出流程；不因有target誤判寫入。
3. 未登記且有直接effects：真NPC origin先看下述封固遷移相容索引。**精確匹配既有legacy內容者**明確留在原writer；不是先收到REFUSED再fallback。未匹配的新NPC effects進catalog，缺contract就是REFUSED。無效NPC context直接拒絕。
4. 非NPC且非protected／recognized policy，維持既有非本owner流程；這次不接全章scene coordinator。任何宣告本owner政策、卻無相符contract的請求仍拒絕，不能以metadata選擇新能力。

完整Main路由正控必分開觀察純選單、legacyNPC、舞台非NPC與catalogNPC，不能只跑schema。

## 若33條中真NPC effects仍無其他明確owner：封固相容索引

只覆蓋5a已存在內容，獨立檔存 `{source,scene_id,effect_projection}` 與原48 protected IDs；原byte SHA封在code，禁止增改／自scene推導擴張。runtime只讀、一次驗證；不是可新增的legacy role、不是新結果許可，**只保留本次遷移前已存在的原writer**。索引缺檔／SHA不符不能當空清單；本owner需分流的NPC副作用一律拒絕。若catalog與索引同時損壞而失去ownership資料，寧拒絕不明的effectful Main請求，也不據此放行。

projection保留有序effects、choice intent/target/default/when、branch條件與結構、結果順序、then/on_failure／custody要求；省略純顯示文字與既有舞台座標，沿原語系。新增效果、搬到不同branch、換原件／交易、改source或selection皆不匹配。需先以原33條逐項比對，再證明新ID、新投影及壞索引拒絕；不只檢ID存在。新NPC例只能走新正式contract，不能改索引授權。使用封固索引會增加一份一次性migration adapter；若真caller盤點能完全辨別原owner，可省掉對應列，不硬加全部章節內容。

## 最小預計改動

Catalog保留三態與原live matcher；Source Facade提供protected識別／獨立相容匹配，初始ownership由封固索引保障冷啟缺檔。Completion只做上述caller分流、拆出origin辨識與原catalog revision/request檢查；不改任何writer、custody或ledger。Loader只在真正catalog revision改變時沿原reset取消，無關load_chapter不全域取消。

本方案尚未接owner；請Root審分流與必要相容索引後實作。不新增通用legacy metadata或把舊33條移成新保存能力。
