# ST-3 NPC formal contract catalog — current review

The candidate is isolated in `D:/NestEggVerification/st3-data-contracts-20261112`. Its current base is published `f25d9b8a05c0e0fc83c58e69f20cd229c3922048`; earlier red/green evidence remains explicitly based on 5a. No primary source, PM, staging, commit or push was performed by this worker.

## Ownership and dispatch

`core/story_result_catalog.gd` owns independent expected content and bounded schema/route matching. Its MATCH is content evidence, not writer authorization. `game/story_result_sources.gd` retains its facade and the original Clinic/Flags/dinner adapters. `game/story_result_completion.gd` still authenticates Main's current live Level, actual original NPC/spawn/talk/request, original reward-free preparation and the original durable writer. The existing write/install/publish sequence remains authoritative.

The data catalog migrates 48 original NPC records; no shipped chapter JSON is changed. A SHA-sealed 5a migration projection supports exactly the 30 previous legacy NPC effects and their original bindings/entry graph, not arbitrary new owners. Known IDs stay protected when policy metadata disappears. Whole catalog failures are atomic. Live scenes are compared on every admission. Cache revision changes use existing presentation cancellation; unrelated `load_chapter` keeps its exact request. The new request-local passive context is sanitized transient data, stamped for source checks and removed on settlement/reset. It grants no result and is not serialized into save data.

Both author backends consume the same catalog through `tools/story/story_contracts.py`. The author adapters validate typed operations/intents, routes and generated effects. Synthetic fixtures add one NPC flag, one manual original and a real optional choice solely in data. They are overlays, not shipped story content or new save authorization.

## Evidence by actual epoch

- Original tables are independently exported in `actual-original-tables.json` and `tests/fixtures/story_result_contract_originals.json`; old expected literals are not derived from the new catalog. `schema-run-3` checks all 48 bindings/live contracts (100/0). `original-guards-1` retains 136 existing source assertions.
- `author-baseline` / `author-candidate-3`: all three complete generated chapter documents are byte-identical. SHA ch1 f6703f32…68e4c; ch2 eeb1345f…1355b6; ch3 aa4ed26e…43e0a8. Source generation is distinct from physical shipped JSON. Existing stage-weather tests still have 3 baseline failures; see below.
- True Main 5a positive overlays: `main-copy-1` 21/0, `main-return-1` 12/0, `main-ack-1` 9/0. The actual primary is decoded inside each result notification; the accepted manual item and original NPC count are already on disk before notification.
- `main-retry-2` 23/0: real Main preparation refused, no result/count publication, original primary preserved; actual retry signal succeeds once. `main-cancel-1` 6/0; `main-unrelated-reload-1` 22/0; `main-cold-1` 7/0 in a new engine process; stale old callbacks cannot repeat saved item/count. `main-live-mutation-1` 7/0 and `main-fake-origin-3` 7/0 refuse changed content/forged origin.
- `other-radio-item-red-1` is a true prior bypass (9/5, no SCRIPT ERROR): dropped passive context let legacy publish material/flag before durable primary. `other-radio-item-green-1` refuses (6/0). `other-radio-flags-green-2` (6/0) preserves the legitimate original flag owner and primary-before-notify. `other-mainflags-green-1` (6/0) rejects a fake terminal intro. `other-radio-chain-green-1` (6/0) preserves context into then and refuses new material. The published NPC-talk graph inventory has 77 roots / 438 reachable IDs and no existing passive then chain.
- `main-catalog-reload-1` (8/2) found the new facade's static `reload` name colliding with native Script.reload. Renaming only that entry to `reload_catalog` produced `main-catalog-reload-2` (8/0): real prepared ticket, changed catalog/reset, old contract refusal and cleared request state. No global cancellation was added to `load_chapter`.
- f25d preflight: `preflight-f25d-1` 279/0 (all permanent catalog/migration/IO/passive/lifetime checks plus original 136 source assertions), no SCRIPT ERROR or shutdown diagnosis. `catalog-io-2` 10/0 uses an actual engine-written JSON .res and PCK remap with absent raw JSON, plus oversized raw and decoded resource controls. It does not claim a complete release export.
- `official-f25d-v1`: original changed script, 61 groups / SHARDS=2, complete 10,210 input names/sizes/SHA and six genuine imported UID metadata. Import 10.138s, exit0/no ERROR. The test run is in progress; do not call it green before exit.json.

Every Main overlay runner restores all three physical mappings and removes the temporary item in a finally block; restore receipts remain per epoch. The parser-failed `main-fake-origin-2` was stopped only after its parse failure; its aborted exit/source drift is preserved. Other early bad fixtures/assertions remain intact.

## Honest remaining boundaries and fixture diagnostics

`review-v2/python-tests.log`: 29 Python story tests, 26 passing and 3 old StageWeather failures (hidden kitchen tap_water and phone rain classified as outdoor; the old build() scene dictionary compared with the formal complete chapter). `weather-original-closure-baseline.log` replays the three using git 5a's original closure source and obtains the same 3 failures. No original assertion/filter was changed. `author-candidate-3` proves our author output remains byte-identical.

The combined work-only lifecycle harness initially exits 25/0 with 6 ObjectDB / 2 resource diagnostics. Default split runs 10/0 and 15/0 are clean; changing quit to deferred alone still leaks. Keeping original order and explicitly releasing its local Checks suite before direct quit is clean (`lifecycle-release-direct-1`). This is a harness-local lifetime fix; no product shutdown/filter/threshold was changed and old diagnostics are retained.

No native GPU, performance, physical controller or human play-through claim is made. New three-example final-base Main replay is pending the official batch's natural exit, so overlays cannot change its frozen inputs. The catalog supports existing result/choice/intent capabilities; it does not introduce a generic coordinator or trust arbitrary metadata.

## Review and reproducibility

`official-f25d-v1/candidate.json` and `candidate-source.zip` are the exact candidate/source metadata used by the final batch; `source-before.json` is the complete fixed context. Original runner: `run_official_f25d.py` (its pre-run hash and exact command/env are recorded). Execution is `GODOT=C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe SHARDS=2 tools/run_tests_changed.sh f25d9b8a05c0e0fc83c58e69f20cd229c3922048` via Git Bash and five isolated user environment roots. No audio-driver adapter or filter changes.

Small controls: `python -X utf8 work/st3-contracts-v1/run_short.py <new-epoch> res://work/st3-contracts-v1/preflight_probe.tscn`; Main overlay: `python -X utf8 work/st3-contracts-v1/run_main.py <new-epoch> <ack|copy|return|retry|cancel|unrelated_reload|catalog_reload|fake_origin|live_mutation|other_radio_flags|other_radio_item|other_mainflags|other_radio_chain>`. Run sequentially only after the official batch exits. Cold takes a third argument naming an earlier owned work slot. Do not run these against primary.
