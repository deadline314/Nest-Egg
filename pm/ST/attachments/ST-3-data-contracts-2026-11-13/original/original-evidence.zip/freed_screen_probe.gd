extends Node
const MainScript := preload("res://game/main.gd")
class RetiredLevel extends Level:
	func _ready() -> void: pass
class RetiredPlayer extends Player:
	func _ready() -> void: pass
class RetiringGate extends Node:
	var target: Node
	var called := false
	func defer_story(_id: StringName,_request: int) -> bool:
		called = true
		target.queue_free()
		return false
	func blocks_save() -> bool: return false
const Sources := preload("res://game/story_result_sources.gd")
var main: Node
var checks := 0
var failures: Array = []
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok: failures.append(label);print("FAIL ",label)
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_run.call_deferred()
func _run() -> void:
	main = MainScript.new()
	main.set("_run_store",RunSaveStore.new("user://test_bad_cutscene_freed_screen.json"))
	add_child(main)
	await get_tree().process_frame
	var before := var_to_bytes([GameState.world_flags,Progression.snapshot(),StoryItems.snapshot(),Story.progress_snapshot()])
	var stale := RetiredLevel.new()
	stale.set_process(false);stale.set_physics_process(false)
	add_child(stale)
	main.set("_screen",stale)
	stale.queue_free()
	while is_instance_valid(stale): await get_tree().process_frame
	check(not is_instance_valid(main.get("_screen")),"actual queued screen was freed before callback")
	var owner: Node = main.get("_result_completion")
	for active: bool in [false,true]:
		main.set("_active_run",active)
		var completed: Dictionary = owner.call("complete",&"test_bad_cutscene_freed_screen",7)
		var chosen: Dictionary = owner.call("choose",{},Callable())
		check(completed.get("handled",false) and not completed.get("ready",true),"freed screen completion is refused before any fallback")
		check(chosen.get("handled",false) and not chosen.get("accepted",true),"freed screen choice is refused before any fallback")
	var leaving := RetiredLevel.new()
	leaving.set_process(false);leaving.set_physics_process(false)
	add_child(leaving)
	main.set("_screen",leaving)
	leaving.queue_free()
	var pending: Dictionary = owner.call("complete",&"test_bad_cutscene_freed_screen",7)
	check(pending.get("handled",false) and not pending.get("ready",true),"queued Level is refused before release")
	while is_instance_valid(leaving): await get_tree().process_frame
	# MATCH is established independently of the invalid host lifetime.
	var id := "ch2_t_s05_gate"
	check(Sources.inspect(id,Story._scenes,Story._scene_sources)["state"] == Sources.Catalog.MATCH,"actual original catalog content is MATCH before host controls")
	owner.set("_contract_revision",Sources.revision())
	owner.set("_id",StringName(id));owner.set("_request",7)
	owner.call("_prepare_and_commit",Story._scenes[id])
	var live := RetiredLevel.new()
	live.set_process(false);live.set_physics_process(false)
	live.data = load("res://data/levels/ch2_market_gate.tres")
	live.set("_initialization_complete",true)
	add_child(live)
	main.set("_screen",live);main.set("_level_path",live.data.resource_path)
	var entities := Node2D.new();live.add_child(entities);live.set("_entities",entities)
	var player := RetiredPlayer.new();player.set_process(false);player.set_physics_process(false)
	player.melee.free();player.melee = null
	add_child(player);live.player = player
	var context_before: Dictionary = Story._presentation_context.duplicate(true)
	Story._presentation_context = {"framing_source":"person","source_id":"test_bad_cutscene_freed_actor","talk_index":0}
	player.queue_free()
	while is_instance_valid(player): await get_tree().process_frame
	var bad_player: Variant = owner.call("_npc_origin",live,StringName(id),7)
	check(bad_player is Dictionary and bad_player.get("kind") == "invalid","released Player is refused before reading state")
	var living_player := RetiredPlayer.new();living_player.melee.free();living_player.melee = null;live.player = living_player
	entities.queue_free()
	while is_instance_valid(entities): await get_tree().process_frame
	var bad_entities: Variant = owner.call("_npc_origin",live,StringName(id),7)
	check(bad_entities is Dictionary and bad_entities.get("kind") == "invalid","released entity host is refused before reading children")
	Story._presentation_context = context_before
	# The real Main callback slot retires a MATCH host after the early gate.
	var after_gate := RetiredLevel.new()
	after_gate.set_process(false);after_gate.set_physics_process(false)
	after_gate.data = live.data;after_gate.set("_initialization_complete",true)
	add_child(after_gate);main.set("_screen",after_gate)
	var original_channel: Node = main.get("_channel_completion")
	var channel := RetiringGate.new();channel.target = after_gate
	main.add_child(channel);main.set("_channel_completion",channel)
	owner.call("_reset",&"test")
	var cinematic_before := Story._current_cinematic
	var request_before := Story._current_request
	Story._current_cinematic = StringName(id);Story._current_request = 7
	main.set("_active_run",true)
	var rejected: Dictionary = owner.call("complete",StringName(id),7)
	check(channel.called and after_gate.is_queued_for_deletion(),"real Main defer callback retires the MATCH host in the same turn")
	check(rejected.get("handled",false) and not rejected.get("ready",true),"post-gate queued host cannot reach a durable write")
	owner.call("_reset",&"test")
	Story._current_cinematic = cinematic_before;Story._current_request = request_before
	main.set("_channel_completion",original_channel);channel.queue_free()
	while is_instance_valid(after_gate): await get_tree().process_frame
	living_player.free();live.queue_free()
	while is_instance_valid(live): await get_tree().process_frame
	main.set("_active_run",false)
	check(var_to_bytes([GameState.world_flags,Progression.snapshot(),StoryItems.snapshot(),Story.progress_snapshot()]) == before,"retired screen callback cannot mutate game facts")
	print("FREED_SCREEN ",checks," checks / ",failures.size()," failures")
	var f := FileAccess.open("res://work/st3-contracts-v1/freed-screen-results.json",FileAccess.WRITE)
	f.store_string(JSON.stringify({"checks":checks,"failures":failures},"  "));f.close()
	main.call("_quit",0 if failures.is_empty() else 1)
