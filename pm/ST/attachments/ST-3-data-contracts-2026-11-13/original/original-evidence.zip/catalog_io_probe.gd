extends Node
const Catalog := preload("res://core/story_result_catalog.gd")
var checks := 0
var failures: Array = []
func check(ok: bool, message: String) -> void:
	checks += 1
	print("PASS " if ok else "FAIL ",message)
	if not ok: failures.append(message)
func _ready() -> void:
	var folder := "user://test_bad_cutscene_catalog_io"
	DirAccess.make_dir_recursive_absolute(folder)
	var catalog := Catalog.new()
	check(catalog._error.is_empty(),"canonical runtime catalog remains valid")
	var large_path := folder.path_join("oversized.json")
	var file := FileAccess.open(large_path,FileAccess.WRITE)
	file.store_string(" ".repeat(RunSaveCodec.MAX_BYTES + 1) + "{}")
	file.close()
	check(catalog._read(large_path).is_empty() and catalog._error.contains("exceeds 4 MiB"),"oversized raw JSON refuses before ResourceLoader parse")
	catalog._error = ""
	var value := JSON.new()
	value.data = {"version":1,"token":"actual binary JSON resource"}
	var binary := folder.path_join("payload.res")
	check(ResourceSaver.save(value,binary) == OK,"engine writes actual JSON binary resource")
	var huge := JSON.new()
	huge.data = {"chunks":Array(range(5000)).map(func(_i:int)->String: return "x".repeat(1000))}
	var huge_binary := folder.path_join("huge.res")
	check(ResourceSaver.save(huge,huge_binary) == OK,"engine writes oversized remapped JSON payload")
	var mount := "res://tests/fixtures/test_bad_cutscene_catalog_io_pack/"
	var logical := mount + "catalog.json"
	check(not FileAccess.file_exists(logical) and not ResourceLoader.exists(logical),"private pack logical path has no existing source")
	var remap := folder.path_join("catalog.json.remap")
	file = FileAccess.open(remap,FileAccess.WRITE)
	file.store_string('[remap]\npath="' + mount + 'payload.res"\n');file.close()
	var huge_remap := folder.path_join("huge.json.remap")
	file = FileAccess.open(huge_remap,FileAccess.WRITE)
	file.store_string('[remap]\npath="' + mount + 'huge.res"\n');file.close()
	var pack := PCKPacker.new()
	var pack_path := folder.path_join("remap.pck")
	check(pack.pck_start(pack_path) == OK and pack.add_file(mount + "payload.res",binary) == OK and pack.add_file(logical + ".remap",remap) == OK and pack.add_file(mount + "huge.res",huge_binary) == OK and pack.add_file(mount + "huge.json.remap",huge_remap) == OK and pack.flush() == OK,"engine produces actual remapped PCK")
	check(ProjectSettings.load_resource_pack(pack_path,false),"mount private pack without replacing runtime files")
	check(not FileAccess.file_exists(logical) and ResourceLoader.exists(logical),"actual PCK remap resolves with absent raw JSON source")
	var loaded := catalog._read(logical)
	check(catalog._error.is_empty() and loaded == value.data,"runtime loader preserves actual remapped JSON content")
	check(catalog._read(mount + "huge.json").is_empty() and catalog._error.contains("JSON data exceeds 4 MiB"),"remapped resource still obeys decoded JSON byte limit")
	print("CATALOG_IO ",checks," checks / ",failures.size()," failures")
	get_tree().quit(0 if failures.is_empty() else 1)
