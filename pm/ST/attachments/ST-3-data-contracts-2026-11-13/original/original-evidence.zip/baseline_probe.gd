extends Node
const Sources := preload("res://game/story_result_sources.gd")
const Supper := preload("res://game/story_result_supper.gd")
const Chapter2 := preload("res://game/story_result_ch2.gd")
func _ready() -> void:
	var out := {"sources":{"NPC_SOURCES":Sources.NPC_SOURCES,"BOUNDARIES":Sources.BOUNDARIES,"CHOICES":Sources.CHOICES},"supper":{"NPC_SOURCE":Supper.NPC_SOURCE,"BOUNDARIES":Supper.BOUNDARIES,"CHOICES":Supper.CHOICES},"ch2":{"NPC_SOURCES":Chapter2.NPC_SOURCES,"BOUNDARIES":Chapter2.BOUNDARIES}}
	var f := FileAccess.open("res://work/st3-contracts-v1/actual-original-tables.json", FileAccess.WRITE)
	if f == null: get_tree().quit(2); return
	f.store_string(JSON.stringify(out, "  ")); f.close()
	var failed := 0
	for id: String in ["ch2_t_patrol_note_ack", "ch2_t_patrol_copy", "ch2_t_patrol_copy_prompt"]:
		if Sources.npc_source(id).is_empty():
			failed += 1
			print("EXPECTED_RED new data-only NPC contract unavailable: ", id)
	print("BASELINE_DATA_EXTENSION 3 cases / ", failed, " unsupported")
	get_tree().quit(1 if failed > 0 else 0)
