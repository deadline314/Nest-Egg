extends Node
const Catalog := preload("res://core/story_result_catalog.gd")
const Sources := preload("res://game/story_result_sources.gd")
const Original := preload("res://tests/fixtures/story_result_contract_originals.json")
var checks := 0
var failures: Array = []
func check(ok: bool, name: String) -> void:
	checks += 1
	if not ok: failures.append(name); print("FAIL ", name)
func _ready() -> void:
	var c := Catalog.new()
	check(c._error.is_empty(), "entire canonical catalog loads: " + c._error)
	check(c._records.size() == 48, "all 48 original NPC records retained")
	for chapter: String in ["ch1", "ch2"]:
		var path := "res://data/story/%s" % ("ch1_kasa.json" if chapter == "ch1" else "ch2_heron.json")
		var scenes: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))["scenes"]
		var locations := {}
		for id: String in scenes: locations[id] = path
		var group: Dictionary = Original.data["sources" if chapter == "ch1" else "ch2"]
		for id: String in group["NPC_SOURCES"]:
			check(Sources.npc_source(id) == group["NPC_SOURCES"][id], "independent original binding " + id)
			check(c.inspect(id, scenes, locations)["state"] == Catalog.MATCH, "original live contract " + id)
		check(Sources.inspect("test_plain_presentation", {"test_plain_presentation":{"lines":[]}}, {"test_plain_presentation":path})["state"] == Catalog.NOT_OWNED, "pure unowned presentation")
	print("SCHEMA_STAGE1 ", checks, " checks / ", failures.size(), " failures")
	var f := FileAccess.open("res://work/st3-contracts-v1/schema-results.json", FileAccess.WRITE)
	f.store_string(JSON.stringify({"checks":checks,"failures":failures},"  ")); f.close()
	get_tree().quit(0 if failures.is_empty() else 1)
