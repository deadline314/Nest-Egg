from pathlib import Path
import os,subprocess,json,hashlib,time,zipfile
ROOT=Path(__file__).resolve().parents[2]
BASE="f25d9b8a05c0e0fc83c58e69f20cd229c3922048"
OUT=ROOT/"work/st3-contracts-v1/official-f25d-v1"
GODOT="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
BASH="C:/Program Files/Git/bin/bash.exe"
def git(*args):return subprocess.run(["git",*args],cwd=ROOT,check=True,capture_output=True).stdout
assert ROOT.resolve().as_posix()=="D:/NestEggVerification/st3-data-contracts-20261112"
assert git("rev-parse","HEAD").decode().strip()==BASE
OUT.mkdir(exist_ok=False)
def write(name,value):
 (OUT/name).write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
def paths():
 names=git("ls-files","-z").decode().split("\0")+git("ls-files","--others","--exclude-standard","-z").decode().split("\0")
 excluded={"pm","design","work","art_src","assets_src",".git",".godot"}
 return sorted({name for name in names if name and name.split("/")[0] not in excluded and "__pycache__" not in Path(name).parts and (ROOT/name).is_file()})
def snapshot():
 result={}
 for name in paths():
  file=ROOT/name;h=hashlib.sha256()
  with file.open("rb") as stream:
   for chunk in iter(lambda:stream.read(1024*1024),b""):h.update(chunk)
  result[name]={"bytes":file.stat().st_size,"sha256":h.hexdigest()}
 return result
def isolated(label):
 env=os.environ.copy();env.update(PYTHONIOENCODING="utf-8",PYTHONDONTWRITEBYTECODE="1")
 for key in ["APPDATA","LOCALAPPDATA","USERPROFILE","HOME","XDG_DATA_HOME"]:
  folder=OUT/label/key;folder.mkdir(parents=True,exist_ok=True);env[key]=str(folder)
 return env
write("runner.json",{"path":str(Path(__file__)),"sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"base":BASE,"godot":GODOT})
original=snapshot();write("before-import.json",original)
cmd=[GODOT,"--headless","--editor","--path",str(ROOT),"--import","--quit"]
write("import-command.json",cmd);started=time.monotonic()
with (OUT/"import.log").open("wb") as log:result=subprocess.run(cmd,cwd=ROOT,env=isolated("import-data"),stdout=log,stderr=subprocess.STDOUT)
text=(OUT/"import.log").read_text(encoding="utf-8",errors="replace")
write("import-exit.json",{"exit_code":result.returncode,"seconds":time.monotonic()-started,"script_errors":text.count("SCRIPT ERROR"),"errors":sum(line.startswith("ERROR:") for line in text.splitlines())})
assert result.returncode==0 and "SCRIPT ERROR" not in text and "ERROR:" not in text,"import failed"
before=snapshot();write("source-before.json",before)
assert all(before.get(p)==v for p,v in original.items()),"source drift during import"
uids={p:v for p,v in before.items() if p not in original};write("generated-import-metadata.json",uids)
assert all(p.endswith(".gd.uid") for p in uids),uids
tracked=[p for p in git("diff","--name-only","-z").decode().split("\0") if p]
candidate=set(tracked)
for name in before:
 if name not in original or name.startswith(("data/story_contracts/","tests/fixtures/story_contracts_data_only/","tests/helpers/story_contract")) or name in {"core/story_result_catalog.gd","core/story_result_catalog.gd.uid","tools/story/story_contracts.py","tools/story/test_story_contracts.py","tests/fixtures/story_result_contract_originals.json","tests/fixtures/story_result_legacy_originals.json"}:candidate.add(name)
write("candidate.json",{"base":BASE,"files":{p:before[p] for p in sorted(candidate)},"scope":"catalog candidate on published f25d; original source-before is complete actual context"})
with zipfile.ZipFile(OUT/"candidate-source.zip","w",zipfile.ZIP_DEFLATED) as archive:
 for name in sorted(candidate):archive.writestr(name,(ROOT/name).read_bytes())
env=isolated("test-data");env.update(GODOT=GODOT,SHARDS="2",LOG_DIR=(OUT/"logs").as_posix(),MSYS_NO_PATHCONV="1")
selection=["python","-X","utf8","tools/select_tests.py","--base",BASE]
write("selector-command.json",selection);selected=subprocess.run(selection,cwd=ROOT,env=env,capture_output=True)
(OUT/"selector.stdout").write_bytes(selected.stdout);(OUT/"selector.stderr").write_bytes(selected.stderr);assert selected.returncode==0
cmd=[BASH,"tools/run_tests_changed.sh",BASE];write("command.json",{"argv":cmd,"SHARDS":"2","GODOT":GODOT,"LOG_DIR":env["LOG_DIR"],"five_env":{k:env[k] for k in ["APPDATA","LOCALAPPDATA","USERPROFILE","HOME","XDG_DATA_HOME"]}})
print("IMPORT_DONE",len(before),"sources; generated",len(uids),"UID; ORIGINAL_SELECTOR",selected.stdout.decode().strip(),flush=True)
started=time.monotonic()
with (OUT/"full.log").open("wb") as log:result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
after=snapshot();write("source-after.json",after)
logs=list((OUT/"logs").glob("shard_*.log"));script_errors=sum(p.read_bytes().count(b"SCRIPT ERROR") for p in logs)
receipt={"exit_code":result.returncode,"seconds":time.monotonic()-started,"source_fixed":before==after,"source_count":len(before),"script_errors":script_errors,"shard_logs":[p.name for p in logs]}
write("exit.json",receipt);print(json.dumps(receipt),flush=True)
raise SystemExit(result.returncode or int(before!=after) or int(script_errors>0))
