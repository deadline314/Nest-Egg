from pathlib import Path
import os,subprocess,json,hashlib,time,zipfile
ROOT=Path(__file__).resolve().parents[2]
BASE="f25d9b8a05c0e0fc83c58e69f20cd229c3922048"
OUT=ROOT/"work/st3-contracts-v1/official-author-f25d-v2"
GODOT="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
BASH="C:/Program Files/Git/bin/bash.exe"
def git(*args):return subprocess.run(["git",*args],cwd=ROOT,check=True,capture_output=True).stdout
assert ROOT.resolve().as_posix()=="D:/NestEggVerification/st3-data-contracts-20261112"
assert git("rev-parse","HEAD").decode().strip()==BASE
OUT.mkdir(exist_ok=False)
def write(name,value):
 (OUT/name).write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
def paths():
 names=git("ls-files","-z").decode().split("\0")+git("ls-files","--others","--exclude-standard","-z").decode().split("\0")
 excluded={"pm","design","work","art_src","assets_src",".git",".godot"}
 return sorted({name for name in names if name and (name.split("/")[0] not in excluded or name.startswith("assets_src/audio/") and name.endswith(".json")) and "__pycache__" not in Path(name).parts and (ROOT/name).is_file()})
def snapshot():
 result={}
 for name in paths():
  file=ROOT/name;h=hashlib.sha256()
  with file.open("rb") as stream:
   for chunk in iter(lambda:stream.read(1024*1024),b""):h.update(chunk)
  result[name]={"bytes":file.stat().st_size,"sha256":h.hexdigest()}
 return result
def isolated(label):
 env=os.environ.copy();env.update(PYTHONIOENCODING="utf-8",PYTHONDONTWRITEBYTECODE="1")
 for key in ["APPDATA","LOCALAPPDATA","USERPROFILE","HOME","XDG_DATA_HOME"]:
  folder=OUT/label/key;folder.mkdir(parents=True,exist_ok=True);env[key]=str(folder)
 return env
write("runner.json",{"path":str(Path(__file__)),"sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"base":BASE,"godot":GODOT})
original=snapshot();write("before-import.json",original)
write("import-not-repeated.json",{"reason":"All shipping GDScript, data and six generated UID files unchanged from the completed f25d run; only author Python and data-fixture source changed","existing_godot_cache":(ROOT/".godot").is_dir()})
before=snapshot();write("source-before.json",before)
assert all(before.get(p)==v for p,v in original.items()),"source drift during import"
uids={p:v for p,v in before.items() if p not in original};write("generated-import-metadata.json",uids)
assert not uids,uids
old_candidate=json.loads((ROOT/"work/st3-contracts-delivery-v1/candidate.json").read_text())
candidate=set(old_candidate["files"])
changed={name for name in candidate if before[name]["sha256"] != old_candidate["files"][name]["sha256"]}
assert changed=={"tests/fixtures/story_contracts_data_only/source.py","tools/story/ch1_closure.py","tools/story/ch1_runtime_backend.py","tools/story/chapter_compiler.py","tools/story/story_contracts.py","tools/story/test_story_contracts.py"},changed
write("only-author-delta.json",{"old50_source_zip_sha256":"0577023236bdb6c48bb094c57bcc9453d7b7dcbb620518b5ee3459455e9f786e","changed":sorted(changed),"shipping_gd_data_unchanged":True})
write("candidate.json",{"base":BASE,"files":{p:before[p] for p in sorted(candidate)},"scope":"catalog candidate on published f25d; original source-before is complete actual context"})
with zipfile.ZipFile(OUT/"candidate-source.zip","w",zipfile.ZIP_DEFLATED) as archive:
 for name in sorted(candidate):archive.writestr(name,(ROOT/name).read_bytes())
env=isolated("test-data");env.update(GODOT=GODOT,SHARDS="2",LOG_DIR=(OUT/"logs").as_posix(),MSYS_NO_PATHCONV="1")
selection=["python","-X","utf8","tools/select_tests.py","--base",BASE]
write("selector-command.json",selection);selected=subprocess.run(selection,cwd=ROOT,env=env,capture_output=True)
(OUT/"selector.stdout").write_bytes(selected.stdout);(OUT/"selector.stderr").write_bytes(selected.stderr);assert selected.returncode==0
cmd=[BASH,"tools/run_tests_changed.sh",BASE];write("command.json",{"argv":cmd,"SHARDS":"2","GODOT":GODOT,"LOG_DIR":env["LOG_DIR"],"five_env":{k:env[k] for k in ["APPDATA","LOCALAPPDATA","USERPROFILE","HOME","XDG_DATA_HOME"]}})
print("AUTHOR_CANDIDATE_FIXED",len(before),"source-projection entries; ORIGINAL_SELECTOR",selected.stdout.decode().strip(),flush=True)
started=time.monotonic()
with (OUT/"full.log").open("wb") as log:result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
after=snapshot();write("source-after.json",after)
logs=list((OUT/"logs").glob("shard_*.log"));script_errors=sum(p.read_bytes().count(b"SCRIPT ERROR") for p in logs)
receipt={"exit_code":result.returncode,"seconds":time.monotonic()-started,"source_fixed":before==after,"source_count":len(before),"script_errors":script_errors,"shard_logs":[p.name for p in logs]}
write("exit.json",receipt);print(json.dumps(receipt),flush=True)
raise SystemExit(result.returncode or int(before!=after) or int(script_errors>0))
