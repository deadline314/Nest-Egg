from pathlib import Path
import sys,importlib.util,unittest,json,hashlib
ROOT=Path(__file__).resolve().parents[3]
LEAF=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/"tools/story"))
if "--patched" in sys.argv:
 sys.path.insert(0,str(LEAF))
import story_contracts as contracts
# Standalone source has a different __file__; redirect only filesystem inputs.
contracts.ROOT=ROOT;contracts.CATALOG=ROOT/"data/story_contracts/catalog.json";contracts.MIGRATION=ROOT/"data/story_contracts/migration-5a.json"
print(json.dumps({"source":contracts.__file__,"source_sha256":hashlib.sha256(Path(contracts.__file__).read_bytes()).hexdigest(),"instrumentation":"Only ROOT/CATALOG/MIGRATION filesystem paths; behavior functions unchanged"}),flush=True)
spec=importlib.util.spec_from_file_location("late_contract_tests",LEAF/"test_story_contracts.py");module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
if "--patched" in sys.argv:suite=unittest.defaultTestLoader.loadTestsFromModule(module)
else:suite=unittest.TestSuite(module.StoryContracts(name) for name in ["test_explicit_original_entry_and_resource_preserve_legacy","test_explicit_legacy_binding_without_original_entry_refuses","test_explicit_legacy_binding_wrong_resource_refuses"])
r=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if r.wasSuccessful() else 1)
