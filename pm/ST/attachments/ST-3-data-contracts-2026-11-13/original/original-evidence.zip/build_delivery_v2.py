from pathlib import Path
import hashlib,json,subprocess,zipfile,shutil
ROOT=Path(__file__).resolve().parents[2]
WORK=ROOT/"work/st3-contracts-v1"
OUT=ROOT/"work/st3-contracts-delivery-v2"
OUT.mkdir(exist_ok=False)
def digest(data):return hashlib.sha256(data).hexdigest()
def save(name,data):
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
official=json.loads((WORK/"official-author-f25d-v2/candidate.json").read_text())
files={}
for name,record in official["files"].items():
 data=(ROOT/name).read_bytes()
 if name not in ("tools/story/story_contracts.py","tools/story/test_story_contracts.py"):assert digest(data)==record["sha256"],name
 files[name]={"bytes":len(data),"sha256":digest(data)}
workflow=".github/workflows/tests.yml";data=(ROOT/workflow).read_bytes();files[workflow]={"bytes":len(data),"sha256":digest(data)}
with zipfile.ZipFile(OUT/"candidate-source.zip","w",zipfile.ZIP_DEFLATED) as archive:
 for name in sorted(files):archive.writestr(name,(ROOT/name).read_bytes())
save("candidate.json",{"base":official["base"],"files":files,"official_epoch":"official-author-f25d-v2","late_author_paths":["tools/story/story_contracts.py","tools/story/test_story_contracts.py"],"scope":"official exact GD/data/resources plus late two-Python-author patch, independently selected0 Godot groups and verified18+6; no claim all final50 tested in same61"})
tracked=subprocess.run(["git","diff","--name-only","-z"],cwd=ROOT,check=True,capture_output=True).stdout.decode().split("\0");tracked=[p for p in tracked if p]
assert all(p in files for p in tracked),tracked
patch=subprocess.run(["git","diff","--binary","--",*tracked],cwd=ROOT,check=True,capture_output=True).stdout
for name in files:
 if name not in tracked:
  result=subprocess.run(["git","diff","--no-index","--","NUL",name],cwd=ROOT,capture_output=True);assert result.returncode in [0,1];patch+=result.stdout
(OUT/"candidate.diff").write_bytes(patch)
# Preserve all existing red, parser-aborted, baseline and green epochs. No work
# originals are moved, edited or removed; this delivery is outside WORK.
with zipfile.ZipFile(OUT/"original-evidence.zip","w",zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for file in sorted(WORK.rglob("*")):
  if file.is_file() and "__pycache__" not in file.parts and file.suffix!=".pyc":archive.write(file,file.relative_to(WORK).as_posix())
index={}
for name in ["candidate-source.zip","original-evidence.zip"]:
 file=OUT/name
 with zipfile.ZipFile(file) as archive:
  assert archive.testzip() is None
  index[name]={"bytes":file.stat().st_size,"sha256":digest(file.read_bytes()),"members":{info.filename:{"bytes":info.file_size,"crc32":f"{info.CRC:08x}","sha256":digest(archive.read(info))} for info in archive.infolist()}}
save("archive-index.json",index)
(OUT/".gdignore").write_bytes(b"")
(OUT/".gitattributes").write_text("*.zip -text\n",encoding="utf-8",newline="\n")
(OUT/".gitignore").write_text("__pycache__/\n*.pyc\n",encoding="utf-8",newline="\n")
shutil.copyfile(WORK/"README-current.md",OUT/"README-details.md")
print(json.dumps({name:{k:v for k,v in row.items() if k!="members"} for name,row in index.items()},indent=2))
