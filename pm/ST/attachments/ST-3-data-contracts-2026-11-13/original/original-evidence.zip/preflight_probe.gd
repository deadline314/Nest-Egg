extends Node
class Checks extends TestSuite:
	func run() -> void: pass
var checks := 0
var failures: Array = []
func _check(ok: bool, label: String) -> void:
	checks += 1
	if not ok: failures.append(label);print("FAIL ",label)
func _ready() -> void:
	var suite := Checks.new(self)
	preload("res://tests/helpers/story_contract_catalog_checks.gd").run(suite)
	preload("res://tests/helpers/story_contract_io_checks.gd").run(suite)
	preload("res://tests/helpers/story_contract_migration_checks.gd").run(suite)
	preload("res://tests/helpers/story_contract_passive_context_checks.gd").run(suite)
	preload("res://tests/helpers/ali_source_checks.gd").run(suite)
	preload("res://tests/helpers/voice_source_checks.gd").run(suite)
	preload("res://tests/helpers/supper_source_checks.gd").run(suite)
	preload("res://tests/helpers/prologue_source_checks.gd").run(suite)
	preload("res://tests/helpers/clinic_source_checks.gd").run(suite)
	await preload("res://tests/helpers/story_contract_lifetime_checks.gd").run(suite)
	suite = null
	print("CONTRACT_PREFLIGHT ",checks," checks / ",failures.size()," failures")
	get_tree().quit(0 if failures.is_empty() else 1)
