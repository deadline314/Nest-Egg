extends Node
class Checks extends TestSuite:
	func run() -> void: pass
var checks := 0
var failures: Array = []
func _check(ok: bool, label: String) -> void:
	checks += 1
	if not ok: failures.append(label);print("FAIL ",label)
func _ready() -> void:
	var suite := Checks.new(self)
	if "--passive" in OS.get_cmdline_user_args(): preload("res://tests/helpers/story_contract_passive_context_checks.gd").run(suite)
	else: await preload("res://tests/helpers/story_contract_lifetime_checks.gd").run(suite)
	await get_tree().process_frame
	await get_tree().process_frame
	print("SPLIT ",checks," checks / ",failures.size()," failures")
	get_tree().quit(0 if failures.is_empty() else 1)
