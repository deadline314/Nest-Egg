from pathlib import Path
import os,sys,subprocess,json,hashlib,time,zipfile
root=Path(__file__).resolve().parents[2];label,mode=sys.argv[1:3];fixture=root/'tests/fixtures/story_contracts_data_only';mapping=json.loads((fixture/(mode+'-mapping.json' if mode.startswith('other_') else 'mapping.json')).read_text(encoding='utf-8'))
out=root/'work/st3-contracts-v1'/label;out.mkdir(exist_ok=False);backup={};installed={}
if mode=='cold':
 source=(root/sys.argv[3]).resolve();assert source.is_relative_to(root/'work/st3-contracts-v1') and source.is_file();(out/'slot.json').write_bytes(source.read_bytes())
try:
 for row in mapping['files']:
  target=(root/row['target']).resolve();assert target.is_relative_to(root) and root.as_posix().endswith('/st3-data-contracts-20261112')
  data=(fixture/row['fixture']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
  backup[row['target']]=target.read_bytes() if target.exists() else None;target.write_bytes(data);installed[row['target']]=hashlib.sha256(data).hexdigest()
 env=os.environ.copy()
 for key in ['APPDATA','LOCALAPPDATA','USERPROFILE','HOME','XDG_DATA_HOME']:
  p=out/key;p.mkdir();env[key]=str(p)
 paths=[p for folder in ['core','game','autoload','data','tests'] for p in (root/folder).rglob('*') if p.is_file() and p.suffix in ['.gd','.tres','.tscn','.json']]
 paths += list((root/'assets_src/audio').glob('*.json'))
 paths += [root/'work/st3-contracts-v1/run_main.py']
 paths += [root/'work/st3-contracts-v1/main_overlay_probe.gd',root/'work/st3-contracts-v1/main_overlay_probe.tscn']
 def hashes():return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 before=hashes();(out/'source-before.json').write_text(json.dumps(before,indent=2),encoding='utf-8',newline='\n')
 with zipfile.ZipFile(out/'active-overlay.zip','w',zipfile.ZIP_DEFLATED) as z:
  for row in mapping['files']:z.writestr(row['target'],(root/row['target']).read_bytes())
 cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--headless','--quit-after','7200','res://work/st3-contracts-v1/main_overlay_probe.tscn','--','--mode='+mode,'--save-dir='+str(out.resolve())]
 (out/'command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8',newline='\n');started=time.monotonic()
 with (out/'engine.log').open('wb') as log:result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 after=hashes();(out/'source-after.json').write_text(json.dumps(after,indent=2),encoding='utf-8',newline='\n')
 receipt={'exit_code':result.returncode,'seconds':time.monotonic()-started,'source_fixed':before==after,'script_errors':(out/'engine.log').read_bytes().count(b'SCRIPT ERROR')}
 (out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8',newline='\n');print(json.dumps(receipt),flush=True)
finally:
 for name,data in backup.items():
  target=root/name;assert hashlib.sha256(target.read_bytes()).hexdigest()==installed[name]
  if data is None:target.unlink()
  else:target.write_bytes(data)
 (out/'restore.json').write_text(json.dumps({'restored':list(backup),'new_files_removed':[p for p,b in backup.items() if b is None]},indent=2),encoding='utf-8',newline='\n')

raise SystemExit(receipt["exit_code"] or int(receipt["script_errors"] > 0) or int(not receipt["source_fixed"]))
