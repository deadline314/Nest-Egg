extends Node
class Checks extends TestSuite:
	func run() -> void: pass
var checks := 0
var failures: Array = []
func _check(ok: bool, name: String) -> void:
	checks += 1
	if not ok: failures.append(name); print("FAIL ", name)
func _ready() -> void:
	var s := Checks.new(self)
	preload("res://tests/helpers/ali_source_checks.gd").run(s)
	preload("res://tests/helpers/voice_source_checks.gd").run(s)
	preload("res://tests/helpers/supper_source_checks.gd").run(s)
	preload("res://tests/helpers/prologue_source_checks.gd").run(s)
	preload("res://tests/helpers/clinic_source_checks.gd").run(s)
	print("ORIGINAL_SOURCE_GUARDS ",checks," checks / ",failures.size()," failures")
	var f := FileAccess.open("res://work/st3-contracts-v1/legacy-results.json",FileAccess.WRITE)
	f.store_string(JSON.stringify({"checks":checks,"failures":failures},"  "));f.close()
	get_tree().quit(0 if failures.is_empty() else 1)
