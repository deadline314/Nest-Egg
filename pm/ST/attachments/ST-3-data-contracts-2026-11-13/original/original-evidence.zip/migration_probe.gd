extends Node
var checks := 0
var failures: Array = []
func check(ok: bool, name: String) -> void:
	checks += 1
	if not ok: failures.append(name); print("FAIL ",name)
func _ready() -> void:
	preload("res://tests/helpers/story_contract_migration_checks.gd").run(self)
	print("MIGRATION_GUARDS ",checks," checks / ",failures.size()," failures")
	var f := FileAccess.open("res://work/st3-contracts-v1/migration-results.json",FileAccess.WRITE)
	f.store_string(JSON.stringify({"checks":checks,"failures":failures},"  "));f.close()
	get_tree().quit(0 if failures.is_empty() else 1)
