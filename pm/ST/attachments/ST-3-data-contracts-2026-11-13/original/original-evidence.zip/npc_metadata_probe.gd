extends Node
var scenes := {}
func _ready() -> void:
	for path: String in ["res://data/story/ch1_kasa.json","res://data/story/ch2_heron.json"]:
		scenes.merge(JSON.parse_string(FileAccess.get_file_as_string(path))["scenes"])
	var targets := {}
	for row: Dictionary in JSON.parse_string(FileAccess.get_file_as_string("res://work/st3-contracts-v1/direct-writes-ch2_heron.json")):
		targets[row["id"]] = []
	for npc: NpcData in ResourceCatalog.load_dir("res://data/npcs",NpcData,"NpcMetadata"):
		for i in npc.talks.size():
			var pending: Array = [String(npc.talks[i].scene)]
			var seen := {}
			while not pending.is_empty() and seen.size() < 256:
				var id: String = pending.pop_back()
				if seen.has(id) or not scenes.has(id): continue
				seen[id] = true
				if targets.has(id): targets[id].append({"npc":npc.resource_path,"index":i,"entry":String(npc.talks[i].scene),"talk":_talk(npc.talks[i])})
				var scene: Dictionary = scenes[id]
				if not str(scene.get("then","")).is_empty(): pending.append(scene["then"])
				for route: Dictionary in scene.get("routes",[]): pending.append(str(route.get("target","")))
				for step: Dictionary in StoryRules.entries(scene.get("steps",[])):
					if step.get("do") == "choice":
						for option: Dictionary in step.get("options",[]): pending.append(str(option.get("target","")))
	var f := FileAccess.open("res://work/st3-contracts-v1/legacy-npc-metadata.json",FileAccess.WRITE)
	f.store_string(JSON.stringify(targets,"  "));f.close()
	print("METADATA_ONLY ",targets.size()," original effect scenes; no actual actor authorization claimed")
	get_tree().quit()

func _talk(talk: NpcTalk) -> Dictionary:
	return {"scene":String(talk.scene),"min_talks":talk.min_talks,"min_deaths":talk.min_deaths,"after_scene":String(talk.after_scene),"requires_flag":String(talk.requires_flag),"unless_flag":String(talk.unless_flag),"requires_item":String(talk.requires_item),"requires_held_item":String(talk.requires_held_item),"unless_held_item":String(talk.unless_held_item),"requires_transferred_item":String(talk.requires_transferred_item),"once":talk.once,"credits":talk.credits,"consumable":talk.consumable.resource_path if talk.consumable else "","story_item":talk.story_item.resource_path if talk.story_item else ""}
