import sys,types,subprocess,unittest
from pathlib import Path
sys.dont_write_bytecode=True
root=Path.cwd();sys.path.insert(0,str(root/'tools/story'))
name='ch1_closure';module=types.ModuleType(name);module.__file__=str(root/'tools/story/ch1_closure.py');sys.modules[name]=module
original=subprocess.run(['git','show','5a363c4e:tools/story/ch1_closure.py'],capture_output=True,check=True).stdout
exec(compile(original,module.__file__,'exec'),module.__dict__)
import test_stage_weather
suite=unittest.defaultTestLoader.loadTestsFromModule(test_stage_weather)
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
