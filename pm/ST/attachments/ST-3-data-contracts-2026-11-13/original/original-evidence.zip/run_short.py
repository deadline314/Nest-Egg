from pathlib import Path
import os,sys,json,subprocess,time,hashlib
root=Path(__file__).resolve().parents[2];label,scene=sys.argv[1:3]
out=root/'work/st3-contracts-v1'/label;out.mkdir(parents=True,exist_ok=False)
env=os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA','USERPROFILE','HOME','XDG_DATA_HOME']:
 p=out/key;p.mkdir();env[key]=str(p)
paths=['core/story_result_catalog.gd','game/story_result_sources.gd','game/story_result_ch2.gd','game/story_result_supper.gd','game/story_result_completion.gd','autoload/story.gd','tools/story/ch1_closure.py','tools/story/ch1_runtime_backend.py','tools/story/chapter_compiler.py']
paths += [p.relative_to(root).as_posix() for p in (root/'data/story_contracts').glob('*.json')]
paths += [scene.removeprefix('res://'),scene.removeprefix('res://').replace('.tscn','.gd')]
for folder in ['core','game','autoload','data','tests']:
 paths += [p.relative_to(root).as_posix() for p in (root/folder).rglob('*') if p.is_file() and p.suffix in ['.gd','.tres','.tscn','.json']]
paths=sorted(set(paths))
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before=hashes();(out/'source-before.json').write_text(json.dumps(before,indent=2),encoding='utf-8',newline='\n')
cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(root),'--headless','--quit-after','600',scene]
if '--verbose' in sys.argv[3:]:cmd.insert(1,'--verbose')
if '--passive' in sys.argv[3:]:cmd += ['--','--passive']
(out/'command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8',newline='\n');started=time.monotonic()
with (out/'engine.log').open('wb') as log: p=subprocess.run(cmd,env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=90)
after=hashes();(out/'source-after.json').write_text(json.dumps(after,indent=2),encoding='utf-8',newline='\n')
script_errors=(out/'engine.log').read_bytes().count(b'SCRIPT ERROR')
receipt={'exit_code':p.returncode,'script_errors':script_errors,'seconds':time.monotonic()-started,'source_fixed':before==after,'command':cmd}
(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8',newline='\n');print(json.dumps(receipt))
raise SystemExit((p.returncode or int(script_errors>0)) if before==after else 3)
