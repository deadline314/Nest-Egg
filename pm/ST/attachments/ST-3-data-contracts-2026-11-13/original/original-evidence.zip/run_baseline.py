from pathlib import Path
import os,subprocess,json,time,hashlib
root=Path(__file__).resolve().parents[2]
out=root/'work/st3-contracts-v1/baseline-run';out.mkdir(parents=True,exist_ok=False)
env=os.environ.copy()
for key in ['APPDATA','LOCALAPPDATA','USERPROFILE','HOME','XDG_DATA_HOME']:
 p=out/key;p.mkdir();env[key]=str(p)
exe='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
for label,args in [('import',['--headless','--editor','--import','--quit']),('baseline',['--headless','res://work/st3-contracts-v1/baseline_probe.tscn'])]:
 cmd=[exe,'--path',str(root),*args];(out/(label+'-command.json')).write_text(json.dumps(cmd,indent=2),encoding='utf-8',newline='\n')
 started=time.monotonic()
 with (out/(label+'.log')).open('wb') as log: result=subprocess.run(cmd,env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 receipt={'exit_code':result.returncode,'seconds':time.monotonic()-started,'command':cmd}
 (out/(label+'-exit.json')).write_text(json.dumps(receipt,indent=2),encoding='utf-8',newline='\n')
 print(label,json.dumps(receipt),flush=True)
 if label=='import' and result.returncode!=0: raise SystemExit(result.returncode)
