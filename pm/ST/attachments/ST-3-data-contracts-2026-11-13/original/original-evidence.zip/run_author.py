from pathlib import Path
import contextlib,hashlib,io,json,sys,time,traceback,zipfile
root=Path(__file__).resolve().parents[2];sys.dont_write_bytecode=True;sys.path.insert(0,str(root/'tools/story'))
out=root/'work/st3-contracts-v1'/sys.argv[1];out.mkdir(exist_ok=False)
paths=['tools/story/story_contracts.py','tools/story/ch1_closure.py','tools/story/ch1_runtime_backend.py','tools/story/chapter_compiler.py']
with zipfile.ZipFile(out/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.writestr(p,(root/p).read_bytes())
log=io.StringIO();results={};started=time.monotonic()
with contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
 import ch1_runtime_backend,build_ch2_story,build_ch3_story,chapter_compiler
 for chapter,build in [('ch1',ch1_runtime_backend.compile_document),('ch2',lambda:chapter_compiler.compile_chapter(build_ch2_story.spec())),('ch3',lambda:chapter_compiler.compile_chapter(build_ch3_story.spec()))]:
  try:
   data=build();b=(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode();(out/(chapter+'.json')).write_bytes(b)
   baseline=root/'work/st3-contracts-v1/author-baseline'/(chapter+'.json');same=baseline.read_bytes()==b
   results[chapter]={'unchanged':same,'sha256':hashlib.sha256(b).hexdigest()};print(chapter,results[chapter])
  except Exception:
   results[chapter]={'error':True};traceback.print_exc()
(out/'raw.log').write_bytes(log.getvalue().encode());receipt={'results':results,'seconds':time.monotonic()-started,'exit_code':int(any(r.get('error') or not r.get('unchanged') for r in results.values()))}
(out/'exit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8',newline='\n');print(json.dumps(receipt));raise SystemExit(receipt['exit_code'])
