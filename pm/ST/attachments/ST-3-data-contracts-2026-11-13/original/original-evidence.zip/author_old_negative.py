from pathlib import Path
import sys,hashlib,json,unittest,importlib.util
ROOT=Path(__file__).resolve().parents[2]
ZIP=ROOT/"work/st3-contracts-delivery-v1/candidate-source.zip"
sys.dont_write_bytecode=True
sys.path[:0]=[str(ZIP)+"/tools/story",str(ROOT/"tools/story")]
import story_contracts as contracts
contracts.ROOT=ROOT;contracts.CATALOG=ROOT/"data/story_contracts/catalog.json"
import chapter_compiler, ch1_runtime_backend
chapter_compiler.ROOT=ROOT;ch1_runtime_backend.ROOT=ROOT
assert str(ZIP) in contracts.__file__ and str(ZIP) in chapter_compiler.__file__ and str(ZIP) in ch1_runtime_backend.__file__
path=ROOT/"tools/story/test_story_contracts.py"
spec=importlib.util.spec_from_file_location("current_contract_tests",path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
names=["test_missing_new_npc_contract_is_a_compile_error","test_unknown_explicit_binding_rejected_even_for_pure_dialogue","test_legacy30_survive_text_but_not_effect_or_entry_changes","test_known_npc_entry_cannot_add_unregistered_effect_sibling"]
print(json.dumps({"old50_zip_sha256":hashlib.sha256(ZIP.read_bytes()).hexdigest(),"current_test_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"module_paths":[contracts.__file__,chapter_compiler.__file__,ch1_runtime_backend.__file__],"instrumentation":"Only filesystem ROOT/CATALOG paths redirected from zipimport pseudo-directory; no behavior functions replaced","tests":names}),flush=True)
suite=unittest.TestSuite(module.StoryContracts(name) for name in names)
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
