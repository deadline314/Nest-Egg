extends "res://tools/ch1_flow_probe.gd"

const LOADING := "res://data/levels/ch2_loading.tres"
const FRONT := "res://data/levels/ch2_ledger_front.tres"
const OFFICE := "res://data/levels/ch2_ledger_office.tres"
const STAGE := &"ch2_ledger_dispute"
const CHILD_STAGE := &"ch2_ledger_xiaowei"
const CONTROL_STAGE := &"ch2_ledger_controls"
const INTRO := &"ch2_t_s11_intro"
const BEATS := [INTRO, &"ch2_t_s11_xiaowei", &"ch2_t_s11_boxes"]
const DOCS := [&"ch2_evidence_contract", &"ch2_evidence_receipt", &"ch2_evidence_collection"]
const PAPER_X := {"s11_contract_copy": 220.0, "s11_interest_receipt": 234.0, "s11_collection_copy": 248.0}
const REPLY := {"zh": "我沒有刪本金，這二十已經付了。",
	"en": "I didn't erase the principal. This twenty has already been paid.",
	"ja": "元本は消していない。この20はもう払ってある。"}

var _app: Node
var _store: RunSaveStore
var _mode := ""
var _lang := "zh"
var _checks := 0
var _items: Dictionary
var _credits := 0
var _paper := {}
var _scenes: Array[StringName] = []
var _opening := false
var _all_on_desk := false
var _actual_reply := ""
var _skip_sent := false
var _started: Array[StringName] = []
var _child_lines := {}
var _control_lines := {}
var _saw_hand := false
var _level_path := ""


func _run() -> void:
	var slot := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--slot="):
			slot = arg.trim_prefix("--slot=")
		elif arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--lang="):
			_lang = arg.trim_prefix("--lang=")
	if not slot.is_absolute_path() or _mode not in ["normal", "skip", "skip-middle", "legacy", "skip-boxes"] or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	_store = RunSaveStore.new(slot)
	_app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_app.set("_run_store", _store)
	add_child(_app)
	Story.auto_skip = false
	Story.scene_started.connect(func(id: StringName, _kind: StringName) -> void:
		if id in BEATS:
			_started.append(id))
	var initial := FRONT if _mode == "legacy" else LOADING
	var started := _store.read()
	_check(started.get("level", "") == initial, "actual persisted checkpoint starts in the correct area")
	if _mode == "legacy":
		_check(started.get("cinematic","") == String(BEATS[1]), "the old save has the originally pending child scene")
	for _frame in STEP_LIMIT:
		if _app.get("_screen") is MainMenu and not bool(_app.call("_route_pending")):
			break
		await get_tree().process_frame
	var menu := _app.get("_screen") as MainMenu
	if menu == null:
		_finish(false)
		return
	await _settle(6)
	_check(Story.set_language(_lang) and Story.language == _lang, "local language is active")
	menu._continue_button.pressed.emit()
	if not await _wait_for_area(initial):
		_finish(false)
		return
	_check(GameState.has_flag(&"ch2_market_reconciled") and not GameState.has_flag(&"ch2_yong_intro_seen"), "real S10 result is saved; S11 has not completed")
	_items = StoryItems.snapshot()
	_credits = Progression.credits
	_check(DOCS.all(func(id: StringName) -> bool: return StoryItems.owns(id)), "all original evidence is in the real inventory")
	if initial == LOADING:
		var exit := _level._portals.get(&"loading_ledger") as Portal
		if not is_instance_valid(exit) or not exit.is_open():
			_finish(false)
			return
		_level.player.global_position = exit.global_position - Vector2(0, 3)
		_level.player.velocity = Vector2.ZERO
		_level.camera.snap_to_target()
		for _frame in 75:
			if exit.interaction_available():
				await _tap(&"interact")
				break
			await get_tree().physics_frame
		if not await _wait_for_area(FRONT):
			_finish(false)
			return
	_check(_level.data.resource_path == FRONT and _store.read().get("level", "") == FRONT, "native loading portal enters and saves the authored front room")
	if not Story.is_cinematic_active() and not await _interact(&"ch2_ledger_door"):
		_finish(false)
		return
	for frame in STEP_LIMIT:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var cutscene := Story._player
		if not is_instance_valid(cutscene) or not cutscene.is_running():
			if GameState.has_flag(&"ch2_yong_intro_seen"):
				break
			continue
		var id := cutscene.scene_id
		if id in BEATS and not id in _scenes:
			_scenes.append(id)
			_check(not GameState.has_flag(&"ch2_yong_intro_seen"), "S11 remains uncompleted on arrival at " + str(id))
		if id == BEATS[1]:
			_record_child(cutscene)
		if id == BEATS[1] and _mode in ["skip-middle","legacy"] and not _skip_sent and not Transition.is_active() \
				and cutscene._dialogue.visible and cutscene._dialogue.is_complete():
			_skip_sent = true
			_capture("skip-during-child-line")
			await _tap(&"ui_cancel")
			continue
		if id == BEATS[2]:
			_record_controls(cutscene)
			if _mode == "skip-boxes" and not _skip_sent and not _control_lines.is_empty() and not Transition.is_active():
				_skip_sent = true
				await _tap(&"ui_cancel")
				continue
		if id == INTRO:
			if cutscene._stage != null and cutscene._stage.stage_id == STAGE:
				_record_papers(cutscene)
			if not _opening and cutscene._stage != null and cutscene._dialogue.visible and cutscene._dialogue.is_complete():
				_opening = true
				_capture("opening")
			if _saw_hand and _mode == "skip" and not _skip_sent:
				_skip_sent = true
				_capture("skip-during-hold")
				await _tap(&"ui_cancel")
				continue
			if _paper.size() == PAPER_X.size() and cutscene._dialogue.visible and cutscene._dialogue.is_complete() and not _all_on_desk:
				_all_on_desk = true
				_actual_reply = cutscene._dialogue._text.text
				_check(_actual_reply == REPLY[_lang], "the full authored line appears in the chosen language")
				_capture("three-papers")
		if cutscene._dialogue.visible and (id != INTRO or _opening) and frame % 16 == 7:
			await _tap(&"ui_accept")
	if _mode != "legacy":
		_check(_opening and _saw_hand, "real native actor and held evidence appeared")
	match _mode:
		"skip":
			_check(_skip_sent and _scenes == [INTRO] and _started == [INTRO, BEATS[2]], "held first beat advances quietly to the original terminal")
			_check(not _all_on_desk and _paper.is_empty(), "Escape interrupted the actual hold before the first paper was laid")
		"legacy":
			_check(_skip_sent and _scenes == [BEATS[1]] and _started == [BEATS[1], BEATS[2]], "cold legacy save skips directly from the originally pending actor scene")
			_check(not _opening and not _saw_hand, "the old save advances without replaying the original desk sequence")
		"skip-boxes":
			_check(_skip_sent and _scenes == BEATS and _started == BEATS, "Escape during the boxes follows the same original final result")
		"skip-middle":
			_check(_skip_sent and _scenes == [INTRO, BEATS[1]] and _started == BEATS, "the child dialogue skips to the same quiet terminal")
		_:
			_check(_scenes == BEATS and _started == BEATS, "normal viewing keeps the original three beats")
			_check(_all_on_desk and _paper.size() == 3, "the original contact animation still completes")
	for _frame in 60:
		if _safe_progress(true):
			break
		await get_tree().process_frame
	_check(_safe_progress(true), "completion writes only the intended introduction result, safeguards cash, and keeps all evidence")
	var office := _level._portals.get(&"front_office") as Portal
	_check(is_instance_valid(office) and office.is_open() and office.data.target_level == OFFICE, "original authored office door unlocks")
	var sample_count := 5 if _mode in ["normal", "skip-boxes"] else 1
	var control_count := 3 if _mode == "normal" else (1 if _mode == "skip-boxes" else 0)
	_check(_control_lines.size() == control_count, "isolation controls have the expected number of visible final lines")
	_check(_child_lines.size() == sample_count, "child stage presented each expected original complete line")
	for row: Array in _child_lines.values():
		var feet: Array = row[2]
		_check(feet.size() == 2 and feet.all(func(foot: Array) -> bool:
			return foot.size() == 2 and foot[0] >= 456.0 and foot[0] <= 478.0 and absf(foot[1] - 219.4) < 0.5),
			"both actual painted soles touch the footrest")
		_check(absf(row[1] - 219.4) < 0.005 and is_equal_approx(row[0],483.0), "child stays above the adults on the raised support")
	await RenderingServer.frame_post_draw
	_capture("front-door-after-completion")
	_finish(true)


func _record_controls(cutscene: CutscenePlayer) -> void:
	var stage := cutscene._stage
	if stage == null or stage.stage_id != CONTROL_STAGE or not cutscene._dialogue.visible or not cutscene._dialogue.is_complete():
		return
	var text := cutscene._dialogue._text.text
	if _control_lines.has(text):
		return
	var child := cutscene._actors.get(&"xiaowei") as CutsceneActor
	var yong := cutscene._actors.get(&"yong") as CutsceneActor
	var egret := cutscene._actors.get(&"egret") as CutsceneActor
	var box := stage.prop_node("medic_side_box")
	if child == null or child.rig == null or not (child.rig.animator as NpcAnimator).posture_ready(&"sit"):
		return
	_check(is_instance_valid(box) and box.is_visible_in_tree(), "the original side box uses its actual prop node")
	_check(is_instance_valid(yong) and is_instance_valid(egret) and child.position.y < yong.position.y and child.position.y < egret.position.y,
		"the child remains above the adult path during the final beat")
	var transform := stage.get_global_transform_with_canvas()
	var points := {}
	var features := {"main_lamp": Vector2(451, 248), "main_handle": Vector2(451, 260.75),
		"terminal": Vector2(493, 255), "shield": Vector2(524, 222.25), "glass": Vector2(483, 162)}
	for sample: String in features:
		var at: Vector2 = transform * features[sample]
		points[sample] = [at.x, at.y]
	var size := get_viewport().get_visible_rect().size
	var feet := [_lowest(child.rig.contact_part(&"foot_front"), stage.actors), _lowest(child.rig.contact_part(&"foot_back"), stage.actors)]
	_control_lines[text] = {"points": points, "logical_view": [size.x, size.y], "feet": feet,
		"child": [child.position.x, child.position.y], "yong_facing": yong.facing}
	_capture("controls-line-%d" % _control_lines.size())


func _record_child(cutscene: CutscenePlayer) -> void:
	if cutscene._stage == null or cutscene._stage.stage_id != CHILD_STAGE or not cutscene._dialogue.visible or not cutscene._dialogue.is_complete():
		return
	var text := cutscene._dialogue._text.text
	if _child_lines.has(text):
		return
	var actor := cutscene._actors.get(&"xiaowei") as CutsceneActor
	if actor == null or actor.rig == null or not (actor.rig.animator as NpcAnimator).posture_ready(&"sit"):
		return
	var source := actor.get_parent() as Node2D
	var feet := [_lowest(actor.rig.contact_part(&"foot_front"),source),_lowest(actor.rig.contact_part(&"foot_back"),source)]
	_child_lines[text] = [actor.position.x,actor.position.y,feet]
	_capture("child-line-%d" % _child_lines.size())


func _lowest(part: Sprite2D, parent: Node2D) -> Array:
	if not is_instance_valid(part) or part.texture == null:
		return []
	var img := part.texture.get_image()
	var bottom := Vector2.ZERO
	var found := false
	for x in img.get_width():
		for y in range(img.get_height()-1,-1,-1):
			if img.get_pixel(x,y).a<0.5:
				continue
			var point := CharacterRig.part_source_point(part,Vector2(x+0.5,y+0.5))
			var p := parent.to_local(part.to_global(point))
			if not found or p.y>bottom.y:
				bottom = p
				found = true
			break
	return [bottom.x,bottom.y] if found else []


func _record_papers(cutscene: CutscenePlayer) -> void:
	for name in PAPER_X:
		var prop := cutscene._stage.prop_node(name)
		if not is_instance_valid(prop) or not prop.is_visible_in_tree():
			continue
		if cutscene._stage.prop_held(name):
			if not _saw_hand:
				_saw_hand = true
				_capture("holding-a-copy")
			continue
		if cutscene._stage.prop_state(name) == "lay_8" and not _paper.has(name):
			_paper[name] = [prop.position.x, prop.position.y + 51.5 * 0.2 - 215.0]


func _safe_progress(finished: bool) -> bool:
	if StoryItems.snapshot() != _items or Progression.credits != _credits:
		return false
	var disk := _store.read()
	var flags: Dictionary = disk.get("story", {}).get("flags", {})
	if bool(flags.get("ch2_yong_intro_seen",false)) != finished or GameState.has_flag(&"ch2_yong_intro_seen") != finished:
		return false
	for key: StringName in [&"ch2_yong_subdued", &"ch2_original_ledger_taken", &"yong_link_isolated", &"yong_link_revoked"]:
		if GameState.has_flag(key) or bool(flags.get(str(key),false)):
			return false
	return disk.get("level","") == FRONT and (not finished or str(disk.get("cinematic","")) == "")


func _wait_for_area(path: String) -> bool:
	for _frame in STEP_LIMIT:
		var current := _app.get("_screen") as Level
		if current != null and current.is_initialized() and current.data.resource_path == path and not bool(_app.call("_route_pending")):
			_level = current
			_level_path = path
			return true
		await get_tree().process_frame
	_check(false, "could not enter " + path)
	return false


func _interact(id: StringName) -> bool:
	for node in _level._entities.get_children():
		if not node is NpcActor or node.data.id != id:
			continue
		_level.player.global_position = node.global_position + Vector2(-26, 0)
		_level.player.velocity = Vector2.ZERO
		_level.camera.snap_to_target()
		for _frame in 70:
			if node.interaction_available() and _level.player.is_on_floor():
				await _tap(&"interact")
				return true
			await get_tree().physics_frame
	_check(false, "could not activate the original ledger door")
	return false


func _tap(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await get_tree().physics_frame
	await get_tree().process_frame
	event = InputEventAction.new()
	event.action = action
	Input.parse_input_event(event)
	await get_tree().process_frame


func _check(ok: bool, what: String) -> void:
	_checks += 1
	super._check(ok, what)


func _finish(ok: bool) -> void:
	var file := FileAccess.open(_out_dir.path_join("actual-route.json"),FileAccess.WRITE)
	var report := {"mode":_mode,"language":Story.language,"checks":_checks,"failures":_failures + int(not ok),"paper":_paper,
		"scenes":_scenes,"opening":_opening,"real_hold":_saw_hand,"all_on_desk":_all_on_desk,"skip":_skip_sent,"started":_started,
		"level":_level_path,"control_lines":_control_lines,"child_lines":_child_lines,"reply":_actual_reply,"credits":Progression.credits, "adapter":RenderingServer.get_video_adapter_name(),"hdr":get_viewport().use_hdr_2d}
	file.store_string(JSON.stringify(report,"  ")+"\n")
	file.close()
	_app.call("_quit", int(not ok or _failures>0))

