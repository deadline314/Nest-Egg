extends Node
## Observe the original fresh Main/new-game prologue; never alter presentation data or clocks.
const MAIN := preload("res://game/main.gd")
const CAPTURE := preload("res://tools/viewport_capture.gd")
const SCENE := &"ch1_p01_door"
const PROOF := "D:/NestEggVerification/proofs/st2-locale-native-20261112/"
var _main: Node
var _out := ""
var _language := ""
var _failures: Array[String] = []
var _records: Array[Dictionary] = []
var _images: Array[Image] = []
var _files := {}
var _expected_steps := ""
var _started := 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if OS.get_cmdline_user_args().has("--parse-only"):
		print("ST2_LOCALE_PARSE_OK real autoloads; observer and Main preloaded, Main not instantiated; no images")
		get_tree().quit(0)
		return
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="): _out = argument.trim_prefix("--out=").replace("\\", "/").simplify_path()
		if argument.begins_with("--language="): _language = argument.trim_prefix("--language=")
	if not _out.begins_with(PROOF) or _language not in ["ja", "en"]:
		push_error("[ST2LocaleObserver] isolated proof output and ja/en are required")
		get_tree().quit(2)
		return
	_run.call_deferred()

func _run() -> void:
	_started = Time.get_ticks_msec()
	_check(Story.set_language(_language), "real Story locale API accepts selected language")
	_check(not Story.auto_skip and not Transition.instant, "original presentation and transition clocks remain enabled")
	_expected_steps = JSON.stringify(Story._scenes[String(SCENE)]["steps"]).sha256_text()
	_main = MAIN.new()
	# The observer is ALWAYS, so restore Main's normal pausable root inheritance.
	_main.process_mode = Node.PROCESS_MODE_PAUSABLE
	_main.set("_run_store", RunSaveStore.new(_out.path_join("slot.json")))
	add_child(_main)
	while Transition.is_active() or _main.get("_pending_screen") != null or not _main.get("_screen") is MainMenu:
		if not _within_deadline(): break
		await get_tree().process_frame
	if _within_deadline():
		# Same start callback used by the actual menu; no route/flag/position arrangement.
		_main.call("_on_start_requested", GameState.difficulties[1])
	while _records.size() < 2 and _within_deadline():
		await get_tree().process_frame
		var player := Story._player as CutscenePlayer
		if not is_instance_valid(player) or player.scene_id != SCENE: continue
		var text := player._center_text
		var sub := player._center_sub
		var kind := "narration" if _records.is_empty() else "subtitle"
		var wanted := str(Story._scenes[String(SCENE)]["steps"][1]["lines"][0]) if kind == "narration" else str(Story._scenes[String(SCENE)]["steps"][2]["sub"])
		var label := text if kind == "narration" else sub
		if label.text != wanted or label.visible_ratio < 0.999 or label.modulate.a < 0.999: continue
		if kind == "subtitle" and text.modulate.a < 0.999: continue
		await RenderingServer.frame_post_draw
		_check(_main.get("_level_path") == "res://data/levels/ch1_prologue.tres" and _main.get("_screen") is Level, "original Main route owns actual formal prologue Level")
		_check(Story._current_cinematic == SCENE and player.scene_id == SCENE, "actual Story request and CutscenePlayer own the original scene")
		_check(player.speed == 1.0 and not player.skipping and not player.user_skipped, "original speed and no skip")
		_check(not (_main.get("_screen") as Level).can_process() and not (_main.get("_screen") as Level).player.can_process(), "real world retains its original pause during the cutscene")
		_check(JSON.stringify(player._steps).sha256_text() == _expected_steps, "all original localized steps remain unchanged")
		var image := get_viewport().get_texture().get_image()
		_images.append(image)
		_records.append({"page": _language + "-" + kind, "kind": kind, "scene": String(player.scene_id), "where": player._current_where,
			"milliseconds_since_start": Time.get_ticks_msec() - _started, "frame": Engine.get_process_frames(),
			"speed": player.speed, "skipping": player.skipping, "user_skipped": player.user_skipped, "steps_run": player.steps_run,
			"steps_sha256": JSON.stringify(player._steps).sha256_text(), "text": _label(text), "sub": _label(sub),
			"size": [image.get_width(), image.get_height()], "format": image.get_format(),
			"root_visible": player._root.is_visible_in_tree(), "world_process_mode": (_main.get("_screen") as Level).process_mode,
			"world_can_process": (_main.get("_screen") as Level).can_process(), "player_can_process": (_main.get("_screen") as Level).player.can_process(), "world_clock": GameState.run_time,
			"framing_safe_rect": _rect(Story.framing.safe_rect()), "viewport_visible_rect": _rect(get_viewport().get_visible_rect()),
			"final_transform": _transform(get_viewport().get_final_transform()), "canvas_transform": _transform(get_viewport().get_canvas_transform())})
	_check(_records.size() == 2, "both actual narration and subtitle frames were observed")
	_check(get_viewport().use_hdr_2d and RenderingServer.get_current_rendering_method() == "forward_plus", "actual Forward+ HDR 2D")
	_check(RenderingServer.get_video_adapter_name().to_lower().replace(" ", "").contains("9070xt"), "actual RX 9070 XT adapter")
	# Encode the two immutable readbacks only after both target frames were captured.
	for index in _records.size():
		var record: Dictionary = _records[index]
		var image := _images[index]
		var raw := image.get_data()
		record["linear_raw"] = record["page"] + "-linear.bin"
		record["encoded_png"] = record["page"] + ".png"
		_write(record["linear_raw"], raw)
		_write(record["encoded_png"], CAPTURE.encode(image, true).save_png_to_buffer())
		_check(image.get_data() == raw, "original float readback remains immutable")
	var report := {"language": _language, "scene": String(SCENE), "renderer": RenderingServer.get_current_rendering_method(),
		"adapter": RenderingServer.get_video_adapter_name(), "hdr_2d": get_viewport().use_hdr_2d, "godot": Engine.get_version_info()["string"],
		"resolution": [1280, 720], "expected_steps_sha256": _expected_steps, "captures": _records, "files": _files, "failures": _failures,
		"story_source": Story._scene_sources.get(String(SCENE), ""), "story_source_sha256": FileAccess.get_sha256("res://data/story/ch1_kasa.json"),
		"classification": "fresh real Main -> original new-game callback -> formal prologue intro; original typewriter/hold/layout; observer only; interrupted after two target frames; not a completed prologue or human/native-language review"}
	var file := FileAccess.open(_out.path_join("manifest.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(report, "\t"))
	file.close()
	print("ST2_LOCALE_CAPTURE ", JSON.stringify(report))
	# Cleanup follows the readbacks; no scene completion or progress is fabricated.
	Story.reset_active_presentation(&"probe_end")
	_main.queue_free()
	for index in 6: await get_tree().process_frame
	_images.clear()
	Sfx.stop_all()
	Music.stop(0.0)
	Ambience.stop_all(0.0)
	await get_tree().create_timer(0.3, true, false, true).timeout
	get_tree().quit(0 if _failures.is_empty() else 1)

func _within_deadline() -> bool:
	if Time.get_ticks_msec() - _started < 45000: return true
	if not _failures.has("original route/target deadline exceeded"): _failures.append("original route/target deadline exceeded")
	return false

func _label(label: Label) -> Dictionary:
	return {"text": label.text, "visible": label.is_visible_in_tree(), "visible_ratio": label.visible_ratio,
		"visible_characters": label.visible_characters, "total_characters": label.get_total_character_count(), "alpha": label.modulate.a,
		"global_rect": _rect(label.get_global_rect()), "local_rect": _rect(label.get_rect()), "transform_with_canvas": _transform(label.get_global_transform_with_canvas()),
		"font_size": label.get_theme_font_size(&"font_size"), "font_path": label.get_theme_font(&"font").resource_path,
		"line_count": label.get_line_count(), "visible_line_count": label.get_visible_line_count(), "clip_text": label.clip_text,
		"autowrap_mode": label.autowrap_mode, "horizontal_alignment": label.horizontal_alignment, "vertical_alignment": label.vertical_alignment}

func _rect(rect: Rect2) -> Array:
	return [rect.position.x, rect.position.y, rect.size.x, rect.size.y]

func _transform(value: Transform2D) -> Array:
	return [value.x.x, value.x.y, value.y.x, value.y.y, value.origin.x, value.origin.y]

func _write(name: String, bytes: PackedByteArray) -> void:
	var file := FileAccess.open(_out.path_join(name), FileAccess.WRITE)
	file.store_buffer(bytes)
	file.close()
	var hash := HashingContext.new()
	hash.start(HashingContext.HASH_SHA256)
	hash.update(bytes)
	_files[name] = {"bytes": bytes.size(), "sha256": hash.finish().hex_encode()}

func _check(value: bool, message: String) -> void:
	if not value:
		_failures.append(message)
		print("FAIL: ", message)
