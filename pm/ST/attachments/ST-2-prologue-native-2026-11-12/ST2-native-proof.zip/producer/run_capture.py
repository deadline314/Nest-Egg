"""CPU prepare by default. Native requires a later explicit Root START, never an automatic watcher."""
import argparse
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import re
import runpy
import shutil
import subprocess
import sys
import time

P = Path(__file__).resolve().parent
D = P.parents[1]
C = Path('C:/Users/stanl/Github/Nest-Egg')
PROOF = Path('D:/NestEggVerification/proofs/st2-locale-native-20261112')
GODOT = Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
C20 = C / 'work/st2-product-adoption-v1/c-native-context-v20.json'
QUEUE_HELPER = C / 'work/ne267-gait-reach-proposal-20261112/native-gh-v1/run_native.py'
SCENE = 'res://work/st2-locale-native/capture.tscn'
BAD = re.compile(r'SCRIPT ERROR|^ERROR:|^WARNING:|Parse Error|Compile Error|ObjectDB.*leak|were leaked|resources still in use|^FAIL:')


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def inputs():
    guard = json.loads(C20.read_text(encoding='utf-8'))
    assert guard['count'] == len(guard['files']) == 387
    c = {name: sha(C / name) for name in guard['files']}
    assert c == guard['files'], 'C387 protected source changed; Root must review'
    seven = json.loads(Path('D:/NestEggVerification/proofs/st2-localization-fix-20261112/final-manifest.json').read_text(encoding='utf-8'))['files']
    assert all(sha(D / item['path']) == item['after_sha256'] for item in seven), 'sealed seven changed'
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=D).decode('utf-8').split('\0')
    # Conservative runtime dependency superset, no archived PM/design or generated cache.
    prefixes = ('autoload/', 'core/', 'game/', 'ui/', 'data/', 'art/', 'audio/', 'shaders/', 'fonts/', 'scenes/')
    selected = {n for n in names if n.startswith(prefixes) and (D / n).is_file()}
    selected.update(item['path'] for item in seven)
    selected.update(['project.godot', 'tools/viewport_capture.gd', 'work/.gdignore'])
    selected.update(n for n in names if '/' not in n and n.endswith(('.tres', '.png', '.cfg')) and (D / n).is_file())
    owned = {str(path): sha(path) for path in sorted(P.iterdir()) if path.is_file() and path.suffix in ('.gd', '.py', '.tscn', '.uid')}
    engines = [GODOT, GODOT.with_name('Godot_v4.7.2-stable_win64.exe')]
    return dict(c_context_sha256=sha(C20), c=c, d={n: sha(D / n) for n in sorted(selected)}, own=owned,
                external_helpers={str(path): sha(path) for path in [QUEUE_HELPER, C / 'tools/comfyui/gpu_lock.py', C / 'tools/comfyui/comfy_guard.py', *engines]})


def run(out, label, command):
    profile = out / ('user-' + label)
    profile.mkdir()
    env = os.environ.copy()
    keys = ('APPDATA', 'LOCALAPPDATA', 'USERPROFILE', 'HOME', 'XDG_DATA_HOME')
    env.update({key: str(profile) for key in keys})
    env.update(PYTHONIOENCODING='utf-8', GIT_OPTIONAL_LOCKS='0')
    started = time.monotonic()
    timed_out = False
    with (out / (label + '.log')).open('xb') as log:
        proc = subprocess.Popen(command, cwd=D, env=env, stdout=log, stderr=subprocess.STDOUT)
        try:
            code = proc.wait(timeout=120)
        except subprocess.TimeoutExpired:
            timed_out = True
            # Only the recorded subprocess tree belongs to this invocation.
            result = subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
            (out / (label + '-owned-timeout-cleanup.log')).write_bytes(result.stdout + result.stderr)
            code = proc.wait(timeout=15)
    text = (out / (label + '.log')).read_text(encoding='utf-8')
    diagnostics = [line for line in text.splitlines() if BAD.search(line)]
    save(out / (label + '-process.json'), dict(pid=proc.pid, command=command, cwd=str(D),
         environment={key: env[key] for key in (*keys, 'PYTHONIOENCODING', 'GIT_OPTIONAL_LOCKS')},
         exit=code, timed_out=timed_out, seconds=time.monotonic() - started,
         diagnostics=diagnostics, log_sha256=sha(out / (label + '.log'))))
    assert code == 0 and not diagnostics and not timed_out, (label, code, diagnostics)
    return text


def prepare(attempt):
    out = PROOF / attempt
    assert not out.exists()
    out.mkdir()
    before = inputs()
    save(out / 'before.json', before)
    for path in before['own']:
        target = out / 'producer' / Path(path).name
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(path, target)
    text = run(out, 'parser', [str(GODOT), '--headless', '--path', str(D), SCENE, '--', '--parse-only'])
    assert 'ST2_LOCALE_PARSE_OK' in text
    run(out, 'reader-controls', [sys.executable, str(P / 'read_capture.py'), '--controls'])
    after = inputs()
    save(out / 'after.json', after)
    assert before == after
    save(out / 'cpu-ready.json', dict(status='CPU prepared; NO queue query, GPU lock, native launch or images; await Root START',
         source_guard='before.json', source_guard_sha256=sha(out / 'before.json'), c_count=387, d_count=len(before['d']),
         parser_process_sha256=sha(out / 'parser-process.json'), parser_log_sha256=sha(out / 'parser.log'),
         reader_process_sha256=sha(out / 'reader-controls-process.json'), reader_log_sha256=sha(out / 'reader-controls.log')))
    print(json.dumps({'cpu_ready': str(out / 'cpu-ready.json'), 'c_count': 387, 'd_count': len(before['d']), 'own_files': len(before['own'])}))


def native(ready_path, authorized):
    assert authorized, 'The CLI flag is not authorization; Root must explicitly say START in the conversation'
    ready_path = ready_path.resolve()
    assert ready_path.is_relative_to(PROOF) and ready_path.name == 'cpu-ready.json'
    ready = json.loads(ready_path.read_text(encoding='utf-8'))
    prepared = ready_path.parent
    assert sha(prepared / 'before.json') == ready['source_guard_sha256']
    assert sha(prepared / 'parser.log') == ready['parser_log_sha256'] and sha(prepared / 'reader-controls.log') == ready['reader_log_sha256']
    before = inputs()
    assert before == json.loads((prepared / 'before.json').read_text(encoding='utf-8'))
    out = PROOF / (prepared.name + '-native')
    assert not out.exists()
    out.mkdir()
    save(out / 'source-before.json', before)
    queues = runpy.run_path(str(QUEUE_HELPER))['queues']
    outside = queues()
    save(out / 'queue-outside-before.json', outside)
    if not outside['clear']:
        save(out / 'blocked.json', {'reason': 'outside queue busy/unknown; no lock/native'})
        save(out / 'source-after.json', inputs())
        return 2
    sys.path.insert(0, str(C / 'tools/comfyui'))
    import comfy_guard
    assert comfy_guard.LOCK_PATH.resolve() == (C / 'assets_src/work/comfy.lock').resolve()
    lock = comfy_guard.LOCK_PATH.open('a+b')
    acquired = False
    inside_after = None
    try:
        lock.seek(0)
        try: msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            save(out / 'blocked.json', {'reason': 'canonical lock busy; no waiting/native'})
            return 2
        acquired = True
        inside = queues()
        save(out / 'queue-inside-before.json', inside)
        if not inside['clear']:
            save(out / 'blocked.json', {'reason': 'inside queue changed busy/unknown; no native'})
            return 2
        assert inputs() == before
        for language in ('ja', 'en'):
            case = out / language
            case.mkdir()
            run(case, 'native', [str(GODOT), '--path', str(D), '--resolution', '1280x720',
                 '--rendering-driver', 'vulkan', '--rendering-method', 'forward_plus', SCENE, '--',
                 '--language=' + language, '--out=' + str(case)])
            run(case, 'metadata-reader', [sys.executable, str(P / 'read_capture.py'), '--manifest', str(case / 'manifest.json'), '--language', language])
            assert inputs() == before
    finally:
        try:
            if acquired:
                inside_after = queues()
                save(out / 'queue-inside-after.json', inside_after)
        finally:
            if acquired:
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            lock.close()
            try:
                save(out / 'queue-outside-after.json', queues())
            finally:
                after = inputs()
                save(out / 'source-after.json', after)
                assert before == after
    assert inside_after and inside_after['clear'], 'queue active/unknown by capture end; reject this preserved batch'
    save(out / 'completion.json', {'status': 'two real Main locale captures complete; raw/PNG float reader and visual review pending'})
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--attempt', default='prepare-v1')
    parser.add_argument('--ready', type=Path)
    parser.add_argument('--start-authorized', action='store_true')
    args = parser.parse_args()
    assert args.attempt.isascii() and re.fullmatch(r'prepare-v[0-9]+', args.attempt)
    if args.prepare:
        assert not args.start_authorized and args.ready is None
        prepare(args.attempt)
    else:
        raise SystemExit(native(args.ready, args.start_authorized))
