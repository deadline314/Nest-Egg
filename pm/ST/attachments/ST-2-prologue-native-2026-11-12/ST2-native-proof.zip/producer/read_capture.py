"""Read actual locale metadata; synthetic negative controls never generate images."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def expected(language):
    data = json.loads((ROOT / 'data/story/ch1_kasa.json').read_text(encoding='utf-8'))
    steps = data['scenes']['ch1_p01_door']['steps']
    return steps[1]['lines_' + language][0], steps[2]['sub_' + language]


def validate(data, language):
    assert data['language'] == language and data['scene'] == 'ch1_p01_door'
    assert data['renderer'] == 'forward_plus' and data['hdr_2d'] is True
    assert '9070xt' in data['adapter'].lower().replace(' ', '')
    assert data['failures'] == [] and data['story_source'] == 'res://data/story/ch1_kasa.json'
    assert len(data['captures']) == 2
    assert data['story_source_sha256'] == hashlib.sha256((ROOT / 'data/story/ch1_kasa.json').read_bytes()).hexdigest()
    for record, kind, text in zip(data['captures'], ('narration', 'subtitle'), expected(language)):
        assert record['scene'] == 'ch1_p01_door' and record['kind'] == kind
        assert record['speed'] == 1 and record['skipping'] is False and record['user_skipped'] is False
        assert record['steps_sha256'] == data['expected_steps_sha256']
        assert record['size'] == data['resolution'] == [1280, 720]
        assert record['root_visible'] is True
        assert record['world_can_process'] is False and record['player_can_process'] is False
        label = record['text' if kind == 'narration' else 'sub']
        assert label['text'] == text and label['visible'] is True
        assert label['visible_ratio'] >= .999 and label['alpha'] >= .999
        assert label['line_count'] > 0 and label['visible_line_count'] >= label['line_count']
        assert label['font_size'] > 0 and len(label['global_rect']) == 4
        assert len(label['transform_with_canvas']) == 6
    assert data['captures'][0]['frame'] < data['captures'][1]['frame']


def controls():
    source = hashlib.sha256((ROOT / 'data/story/ch1_kasa.json').read_bytes()).hexdigest()
    good = dict(language='ja', scene='ch1_p01_door', renderer='forward_plus', hdr_2d=True,
                adapter='AMD Radeon RX 9070 XT', failures=[], resolution=[1280, 720],
                story_source='res://data/story/ch1_kasa.json', story_source_sha256=source,
                expected_steps_sha256='synthetic metadata control', captures=[])
    for i, (kind, text) in enumerate(zip(('narration', 'subtitle'), expected('ja'))):
        label = dict(text=text, visible=True, visible_ratio=1, alpha=1, line_count=1,
                     visible_line_count=1, font_size=16, global_rect=[0, 0, 640, 360],
                     transform_with_canvas=[1, 0, 0, 1, 0, 0])
        good['captures'].append(dict(scene='ch1_p01_door', kind=kind, speed=1, skipping=False,
                                    user_skipped=False, steps_sha256=good['expected_steps_sha256'],
                                    size=[1280, 720], root_visible=True, world_can_process=False,
                                    player_can_process=False, text=label, sub=label, frame=i))
    validate(good, 'ja')
    mutations = [lambda d: d.update(renderer='gl_compatibility'), lambda d: d.update(hdr_2d=False),
                 lambda d: d['captures'][0]['text'].update(text='原中文未替換。'),
                 lambda d: d['captures'][0]['text'].update(visible_ratio=.8),
                 lambda d: d['captures'][1]['sub'].update(alpha=0),
                 lambda d: d['captures'][1]['sub'].update(visible_line_count=0),
                 lambda d: d['captures'][0].update(speed=2),
                 lambda d: d['captures'][0].update(steps_sha256='changed step'),
                 lambda d: d['captures'][0].update(world_can_process=True),
                 lambda d: d.update(story_source_sha256='changed source')]
    for mutate in mutations:
        bad = copy.deepcopy(good)
        mutate(bad)
        try:
            validate(bad, 'ja')
        except AssertionError:
            continue
        raise AssertionError('reader accepted a synthetic invalid control')
    return {'classification': 'CPU synthetic metadata controls only; no engine images or visual acceptance',
            'positive': 1, 'negative_rejected': len(mutations)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--controls', action='store_true')
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--language', choices=('ja', 'en'))
    args = parser.parse_args()
    if args.controls:
        print(json.dumps(controls(), ensure_ascii=False))
    else:
        data = json.loads(args.manifest.read_text(encoding='utf-8'))
        validate(data, args.language)
        for name, receipt in data['files'].items():
            raw = (args.manifest.parent / name).read_bytes()
            assert len(raw) == receipt['bytes'] and hashlib.sha256(raw).hexdigest() == receipt['sha256']
        print(json.dumps({'metadata_and_file_hashes_valid': True, 'language': args.language,
                          'visual_review_and_float_png_reader_still_required': True}))
