ST2 JA/EN native four-frame evidence.

One archive, no nested assets/history packages. Four original 1280x720 PNGs and four immutable RGB-half HDR readbacks; actual Main/new-game prologue route. Both engines naturally exited0 with no warnings/errors/leaks. Exact UI text, rects, line counts, font sizes, transforms, original step SHA and observed full-visible timing milestones are in ja/manifest.json and en/manifest.json. Original steps/durations/stage/font/lighting/speed remain unchanged; Main/world preserve normal pause. These are four target frames, not continuous ramp sampling or completion of the prologue. The Chinese Esc hint belongs to unchanged UI outside this scope. Root and child viewed all four full originals.

CPU readers (extract only readers/ to any folder, no Godot/network needed):
 python readers/verify_index.py ST2-native-proof.zip
 python readers/verify_capture_precision.py ST2-native-proof.zip
The second is the unchanged existing all-pixel float/sRGB/alpha verifier and requires installed numpy/Pillow. Its actual source SHA/command/exit and four-image result are included.

Root C387 v20 and conservative actual D runtime dependency superset8682 plus own4 producers/engine/canonical helpers were frozen before/after. Identical full guard bytes are stored once and both observed hashes remain in index.json. Source and commands retain exact original Windows paths for provenance; readers use archive-relative paths and remain usable after cleanup. No player save/profile directory, PM/history asset, cache, other project prompt or new framework is packaged. Original producer source and CPU parser/negative controls are retained.

外/內queue均真8188 response0/0、8189 genuine10061；canonical primary lock nonblocking、無排隊/重試/啟服務。Native結束後主鎖已釋。只作功能/畫面證據；另ST3兩個headless程序同時存在，不稱排他效能、母語審稿或人類遊玩。沒有更動七產品檔、PM、index或commit。
