from pathlib import Path
import subprocess,os,json,hashlib
b=Path(__file__).parent;p=b/'audio';product=p/'core/story_outcomes.gd';candidate=product.read_bytes();assert candidate==(b/'st9-story-outcomes-candidate.gd').read_bytes()
env=os.environ.copy();env.update(GODOT=str(b/'godot472/Godot_v4.7.2-stable_linux.x86_64'),LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',SHARDS='1')
def run(name,args):
 env['LOG_DIR']=str(b/name);(b/name).mkdir(exist_ok=False)
 with (b/(name+'.log')).open('w') as log:r=subprocess.run(args,cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT)
 (b/(name+'.exit')).write_text(str(r.returncode));print(name,r.returncode,flush=True);return r.returncode
try:
 product.write_bytes((b/'st9-story-outcomes-before.gd').read_bytes())
 assert run('st9-result-shape-red-v2',['bash','tools/run_tests_parallel.sh','--only=CutsceneSuite'])==1
 log=(b/'st9-result-shape-red-v2/shard_0.log').read_text();assert log.count('FAIL:')==42 and not any(x in log for x in ['SCRIPT ERROR:','Parse Error:','Compile Error:'])
finally:product.write_bytes(candidate)
assert product.read_bytes()==candidate
assert run('st9-result-shape-affected',['bash','tools/run_tests_changed.sh','d4d8647ee80cfa3db05e5eb448acf21ea665c6fa'])==0
(b/'st9-result-shape-verification.json').write_text(json.dumps({'base':'d4d8647ee80cfa3db05e5eb448acf21ea665c6fa','product_sha256':hashlib.sha256(candidate).hexdigest(),'test_sha256':hashlib.sha256((p/'tests/suite/test_cutscene.gd').read_bytes()).hexdigest(),'negative_failures':42,'candidate_restored':True},indent=2)+'\n')
