extends "res://tools/ch3_flow_probe.gd"

const MainRoute := preload("res://tools/probe_main_route.gd")
const HINT := &"ch3_b_c02_upper_route"
var _main: Node
var _native_route: MainRoute
var _hint_count := 0

func _enter(area: String, near := Vector2.INF) -> void:
	_level = await _native_route.enter(level_pattern % area, near)

func _run() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch3_clearwater"))
	Story.set_language("zh")
	TranslationServer.set_locale("zh")
	Settings.set_skip_cutscenes(false)
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_main.set("_run_store", RunSaveStore.new(_out_dir.path_join("save.json")))
	add_child(_main)
	_native_route = MainRoute.new(self, _main)
	_check(await _native_route.start_new_game(), "new game starts before backfilling chapter 2 results")
	_carry_ch2_results()
	await _enter("pawnshop")
	await _talk(&"ch3_old_k", ["go"])
	_check(GameState.has_flag(&"ch3_departure_done"), "the standard breakfast choice enables departure")
	await _enter("plaza")
	await _talk(&"ch3_control_box")
	await _talk(&"ch3_water_gauge")
	await _talk(&"ch3_control_box")
	_check(GameState.has_flag(&"ch3_interlock_seen"), "real plaza interactions reveal the interlock before arriving")
	Story.scene_started.connect(func(id: StringName, mode: StringName) -> void:
		if id == HINT and mode == Story.MODE_BUBBLES:
			_hint_count += 1)
	await _enter("pump")
	for i in 300:
		if not Transition.is_active() and not GameplayLock.is_locked() and _level.player.is_on_floor():
			break
		await get_tree().physics_frame
	var player := _level.player
	var before := player.global_position
	Input.action_press(&"jump")
	Input.action_press(&"move_right")
	for i in 70:
		await get_tree().physics_frame
		if player.global_position.x >= 146:
			break
	Input.action_release(&"move_right")
	for i in 60:
		await get_tree().physics_frame
	Input.action_release(&"jump")
	_check(_hint_count == 1 and not GameState.has_flag(&"ch3_pump_low") and not GameplayLock.is_locked(), "undrained pump shows exactly one hint with no gameplay lock")
	_check(before.x < 112 and player.is_on_floor() and absf(player.global_position.y - 528) < 2, "first jump lands on the actual ledge from the area spawn")
	await RenderingServer.frame_post_draw
	_capture("pump-entrance-after-plaza")
	print("ST21_PUMP_CONTEXT failures=%d start=%s landing=%s" % [_failures, before, player.global_position])
	_main.call("_quit", 0 if _failures == 0 else 1)
