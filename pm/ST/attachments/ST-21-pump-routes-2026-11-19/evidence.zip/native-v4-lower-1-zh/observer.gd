extends Node

const ROUTE_HINT := &"ch3_b_c02_upper_route"
const PUMP := "res://data/levels/ch3_pump.tres"
const CAPTURE := preload("res://tools/viewport_capture.gd")
var _out := ""
var _route := "upper"
var _difficulty := 1
var _language := "zh"
var _already_drained := false
var _hint_starts := 0
var _hint_mode := &""
var _combatants: Dictionary = {}
var _frames_on_route := 0
var _fails: Array[String] = []
var _traces: Array[Dictionary] = []

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--route="):
			_route = arg.trim_prefix("--route=")
		elif arg.begins_with("--language="):
			_language = arg.trim_prefix("--language=")
		elif arg == "--already-drained":
			_already_drained = true
		elif arg.begins_with("--difficulty="):
			_difficulty = arg.trim_prefix("--difficulty=").to_int()
	_run.call_deferred()

func _frames(count: int) -> void:
	for i in count:
		await get_tree().physics_frame

func _action(action: StringName, pressed: bool) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = pressed
	Input.parse_input_event(event)

func _trace(player: Player, label: String) -> void:
	_traces.append({"label": label, "x": player.global_position.x, "y": player.global_position.y,
		"grounded": player.is_on_floor(), "health": player.health.current})

func _jump_to(player: Player, x: float) -> void:
	_action(&"jump", true)
	_action(&"move_right", true)
	for i in 68:
		await _frames(1)
		if player.global_position.x >= x:
			break
	_action(&"move_right", false)
	await _frames(60)
	_action(&"jump", false)
	await _frames(2)

func _run() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch3_clearwater"))
	Story.set_language(_language)
	TranslationServer.set_locale(_language)
	Story.auto_skip = true
	var main := load("res://game/main.gd").new() as Node
	main.set("_run_store", RunSaveStore.new(_out.path_join("fixture.json")))
	add_child(main)
	for i in 300:
		if not main.call("_route_pending") and not Transition.is_active():
			break
		await _frames(1)
	main.call("_on_start_requested", GameState.difficulties[_difficulty])
	for i in 480:
		if main.get("_screen") is Level and not Transition.is_active() and not Story.is_cinematic_active():
			break
		await _frames(1)
	if not main.get("_active_run") or GameState.difficulty.resource_path != GameState.DIFFICULTY_PATHS[_difficulty]:
		_fails.append("selected difficulty must start before the pump is entered")
		_finish()
		return
	Story.scene_started.connect(_on_scene_started)
	if _already_drained:
		GameState.set_flag(&"ch3_pump_low")
	Story.auto_skip = false
	main.call("_on_area_requested", PUMP)
	var level: Level
	for i in 400:
		await _frames(1)
		level = main.get("_screen") as Level
		if is_instance_valid(level) and level.data.resource_path == PUMP and not GameplayLock.is_locked():
			break
	if not is_instance_valid(level) or level.data.resource_path != PUMP:
		_fails.append("pump load")
		_finish()
		return
	var player := level.player
	await _frames(60)
	_trace(player, "initial")
	var initial_health := player.health.current
	if _route == "upper":
		await _jump_to(player, 146.0)
		_trace(player, "first landing")
		await RenderingServer.frame_post_draw
		CAPTURE.image(get_viewport()).save_png(_out.path_join("pump-route-guide.png"))
		await _jump_to(player, 220.0)
		_trace(player, "upper bridge landing")
	_action(&"move_right", true)
	var highest_y := -INF
	var lowest_y := INF
	for i in 700:
		await _frames(1)
		_frames_on_route += 1
		for enemy in get_tree().get_nodes_in_group(&"enemies"):
			if enemy is Enemy and enemy.data != null:
				_combatants[str(enemy.data.id)] = true
		highest_y = maxf(highest_y, player.global_position.y)
		lowest_y = minf(lowest_y, player.global_position.y)
		if player.global_position.x > 1150.0 or player.is_dead():
			break
	_action(&"move_right", false)
	_trace(player, "far end")
	if _route == "upper" and (not is_equal_approx(highest_y, lowest_y) or highest_y >= 470 or player.health.current != initial_health or player.global_position.x <= 1150.0):
		_fails.append("upper route needs two jumps and a safe continuous crossing")
	if _route == "lower" and (player.global_position.x <= 1150.0 or player.health.current >= initial_health or not _combatants.has("insulation_inspector") or not _combatants.has("pump_inspector")):
		_fails.append("lower route reaches the far side through both patrols with damage")
	_traces.append({"label": "bridge bounds", "lowest_y": lowest_y, "highest_y": highest_y})
	if _already_drained:
		if _hint_starts != 0:
			_fails.append("cue replayed after draining")
	elif _hint_starts != 1 or _hint_mode != Story.MODE_BUBBLES:
		_fails.append("entrance cue is a single moving speech bubble")
	if GameState.difficulty.resource_path != GameState.DIFFICULTY_PATHS[_difficulty] or Progression.credits != 0:
		_fails.append("scoped route keeps difficulty and economy")
	await RenderingServer.frame_post_draw
	CAPTURE.image(get_viewport()).save_png(_out.path_join("pump-upper-bridge.png"))
	_finish()

func _on_scene_started(id: StringName, mode: StringName) -> void:
	if id == ROUTE_HINT:
		_hint_starts += 1
		_hint_mode = mode

func _finish() -> void:
	FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify({
		"traces": _traces, "failures": _fails, "adapter": RenderingServer.get_video_adapter_name(),
		"route": _route, "difficulty": GameState.difficulty.resource_path, "locale": _language, "cue_starts": _hint_starts, "cue_mode": _hint_mode, "combatants": _combatants.keys(), "route_seconds": _frames_on_route / 60.0,
	}, "\t"))
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _fails.is_empty() else 1)
