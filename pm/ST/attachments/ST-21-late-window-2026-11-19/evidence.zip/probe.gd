extends ScenarioBase

const LEVEL_PATH := "res://data/levels/ch3_showroom.tres"
const WINDOW_ID := &"ch3_window_late"
const SILL_ID := &"clearwater__sill_with_coin"
const REACTION_ID := &"showroom_late_shade"
const MEASURED := &"room_late_measured"

var _window: NpcActor
var _sill: PropNode
var _shade: PropReaction
var _tag := ""
var _samples: Dictionary = {}


func _ready() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			out_dir = argument.trim_prefix("--out=").replace("\\", "/")
		elif argument.begins_with("--tag="):
			_tag = argument.trim_prefix("--tag=")
	if not out_dir.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	Story.auto_skip = true
	GameState.start_new_run(GameState.difficulties[1])
	GameState.set_flag(&"ch3_clearwater_tour_started", true, false)
	await _open()
	if _window == null or _sill == null:
		get_tree().quit(2)
		return
	_check((_shade != null) == (_tag == "after"), "the authored window has the expected shade control")
	_check(_window.interaction_available(), "the measurement is available from the real spot")
	await _sample("starting")
	var previous := Progression.credits
	var completed: bool = await _window._talk()
	_check(completed and GameState.has_flag(MEASURED), "the normal room inspection saves its existing measurement flag")
	_check(Progression.credits == previous and not GameState.has_flag(&"sq3_room_proposal_done"), "measuring keeps the proposal and wallet intact")
	await settle(30)
	await _sample("measured")
	await finish()
	await _open()
	_check(GameState.has_flag(MEASURED), "a measured window is still recorded when revisited")
	await _sample("returned")
	var data := {"tag": _tag, "samples": _samples, "failures": failures, "adapter": RenderingServer.get_video_adapter_name()}
	FileAccess.open(out_dir.path_join("report.json"), FileAccess.WRITE).store_string(JSON.stringify(data, "\t"))
	AudioRelease.begin_shutdown()
	await finish()
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if failures == 0 else 1)


func _open() -> void:
	level = Level.new()
	level.configure(load(LEVEL_PATH) as LevelData)
	add_child(level)
	player = level.player
	level._next_story_trigger = level._layout.story_triggers.size()
	level.hud.visible = false
	_window = null
	_sill = null
	_shade = null
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		var npc := node as NpcActor
		if npc != null and npc.data.id == WINDOW_ID:
			_window = npc
	for node in get_tree().get_nodes_in_group(PropNode.GROUP):
		var prop := node as PropNode
		if prop != null and prop.data.id == SILL_ID:
			_sill = prop
			_shade = prop.get_node_or_null("Reaction_" + String(REACTION_ID)) as PropReaction
	if _window == null or _sill == null:
		push_error("the showroom is missing the authored window")
		return
	player.global_position = _window.global_position + Vector2(-23, 0)
	player.velocity = Vector2.ZERO
	level.camera.set_physics_process(false)
	level.camera.position_smoothing_enabled = false
	level.camera.global_position = _window.global_position + Vector2(10, -30)
	level.camera.reset_smoothing()
	level.camera.force_update_scroll()
	get_viewport().warp_mouse(Vector2(165, 140))
	await settle(62)


func _sample(id: String) -> void:
	await RenderingServer.frame_post_draw
	var origin := _sill.get_global_transform_with_canvas().origin
	var measured := GameState.has_flag(MEASURED)
	var shaded := _shade != null and _shade.is_swapped()
	if _tag == "after":
		_check(shaded == measured, "the shade follows the saved result")
	_samples[id] = {"measured": measured, "shaded": shaded, "origin": [origin.x, origin.y],
		"sill": [_sill.global_position.x, _sill.global_position.y, _sill.data.size.x, _sill.data.size.y]}
	capture(id)


func _check(condition: bool, label: String) -> void:
	if not condition:
		failures += 1
		push_error(label)
