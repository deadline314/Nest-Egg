from pathlib import Path
p=Path('tests/probes/patroller_completion.gd');s=p.read_text()
s=s.replace(' var before_count:=npc.talk_count',''' var original_scene: Dictionary=Story._scenes[String(TARGET)].duplicate(true)
 if _mode=="contract":
  Story._scenes[String(TARGET)]["results"][0]["value"]=false
 if _mode=="duplicate":
  var duplicate:=NpcActor.new()
  duplicate.configure(npc.data,npc.cell)
  duplicate.position=npc.position
  _level()._entities.add_child(duplicate)
  duplicate.remove_from_group(WorldState.GROUP)
  npc=duplicate
  _check(not _level().npc_sources.has(npc),"same-resource same-cell duplicate is not an original authored actor")
 var before_count:=npc.talk_count''')
s=s.replace(' done[1]=await npc._talk()',' done[1]=await Story.play(TARGET) if _mode=="direct" else await npc._talk()')
s=s.replace(' if _mode=="cancel":',''' if _mode in ["direct","duplicate","contract"]:
  Story._scenes[String(TARGET)]=original_scene
  Story.reset_active_presentation(&"probe_invalid_source")
  await _frames(4)
  _check(not GameState.has_flag(&"ch2_gate_checked") and not Story._completed.has(TARGET),"unowned or altered scene cannot publish gate progress")
  _check(FileAccess.get_file_as_bytes(store.path)==_before,"invalid producer leaves exact original primary intact")
  DirAccess.remove_absolute(store.path+".tmp")
  await _done()
  return
 if _mode=="cancel":''')
s=s.replace(' await _done()\nfunc _patroller()', ' await _shot("patroller-accepted")\n await _done()\nfunc _patroller()')
s=s.replace(' if _mode in ["direct","duplicate","contract"]:', ' await _shot("patroller-refused")\n if _mode in ["direct","duplicate","contract"]:')
s=s.replace('  await _done()\n  return\n _main.call','  await _shot("patroller-cold")\n  await _done()\n  return\n _main.call',1)
p.write_text(s)
p=Path('tools/run_patroller_completion.py');s=p.read_text().replace("('cancel_read','cancel')]","('cancel_read','cancel'),('direct','direct'),('duplicate','duplicate'),('contract','contract')]")
p.write_text(s)
