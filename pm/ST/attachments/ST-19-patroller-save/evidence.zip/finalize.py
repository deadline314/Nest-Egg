from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
root=Path('work/ch2-gate-save')
console=(root/'required-runner.log').read_text()
m=re.search(r'checks: (\d+), new failures: 0, known failures .*: 0  \(wall time (\d+) s\)',console)
assert m,'required suites are not complete and passing'
checks,seconds=map(int,m.groups())
for name in ['verified-guarded','handoff','supper-selected','native']:
 receipt=json.loads((root/name/'receipt.json').read_text())
 assert all(row['passed'] for row in receipt['cases']),name
assert 'diagnostics=0' in (root/'dummy-exit.log').read_text()
folder=Path('pm/ST/attachments/ST-19-patroller-save');folder.mkdir(exist_ok=False)
source=root/'delivery-source';source.mkdir(exist_ok=False)
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
files+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
files+=[ 'game/main.gd','autoload/story.gd','game/npc/npc_actor.gd','tools/runtime_probe.py']
for name in dict.fromkeys(files):
 p=Path(name)
 if p.is_file():
  target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
shutil.copyfile('/workspace/.nest-egg-env/ci-godot/dist/receipt.json',root/'engine-receipt.json')
for mode,name in [('accepted/patroller-refused','refused'),('accepted/patroller-accepted','accepted'),('accepted_read/patroller-cold','cold')]:
 shutil.copyfile(root/'native'/(mode+'.png'),Path('pm/ST/images')/('ST-19-patroller-'+name+'.png'))
with zipfile.ZipFile(folder/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in {'.json','.log','.exit','.gd','.tscn','.py','.png','.txt'} and '__pycache__' not in p.parts:
   archive.write(p,str(p.relative_to(root)))
receipt={'integration_base':'cb3cb8c7f7a76e33fc72afdd6e8eac11b5e9bfa1','baseline':'dba49a7b597476f2f0406712580c9bbb5f240b6c','before':{'checks':9,'failures':4},'patroller':{'processes':8,'checks':83,'failures':0},'first_chapter_selected':{'processes':8,'checks':271,'failures':0},'compiler':{'checks':15,'failures':0},'native_software':{'processes':2,'checks':25,'failures':0},'required':{'groups':68,'checks':checks,'new_failures':0,'known_failures':0,'seconds':seconds},'archive_sha256':hashlib.sha256((folder/'evidence.zip').read_bytes()).hexdigest()}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(folder/'README.md').write_text(f'''# ST-19：原巡帳員通行結果

乾淨 dba49a7b 的原市集入口巡帳員，在真正完成通行對話時遇到 .tmp 目錄造成的保存拒絕，9項有4失敗：放行旗標、已讀紀錄、原等待者／次數提前完成，也沒有重試提示。原主檔bytes未變。樣本明示安排先前簡報旗標、查核證和位置；沒有設定放行結果，用真NPC互動與閱讀按鍵完成原對話，不是自然整章通關。

新增第二章有限來源契約，作者只明示啟用這一個終端結果。保存成功後才靜默安裝旗標、紀錄與NPC次數，再發布通知；第一個通知直接解碼原checksum主檔，三處world次數均為1，原等待者當時仍在。原場景資料、區域、資源、格位、原互動和原節點身分一起約束授權；相同資源與格位的事後複製品不能通過。

- 真對話、兩次拒寫、成功重試、外部取消、接受／取消冷讀、直接呼叫、同格複製品、改結果及插入未登記選項，共8程序83項、0嚴格診斷。
- 第一章原交付櫃2程序107項；原宵夜付款與留宿選擇兩組，各含原pending主檔與接受主檔冷讀，共6程序164項；合計8程序271項，全部通過。宵夜只選這兩組，未宣稱重跑完整宵夜矩陣。
- 兩章作者政策及原第一章政策測試共15項通過；不自動升級其他結果、不接受分派入口或選擇冒充終端保存。
- 原必要選擇器68組、{checks:,}項、0新／已知失敗、{seconds}秒。選擇器與已知失敗清單未改；完整六份日誌另驗DummyTexture0。
- 原生Forward+／軟體Vulkan拒絕、接受與冷讀共25項通過，嚴格診斷0，三張原圖已看。非實體GPU、真人操控或整章長度／張力驗收。

before-observer-error、before-observer-type-error是早期觀察器簽章錯誤，不能當產品負控制。matrix首次因測試覆寫父類別同名方法而解析失敗，停止自有程序並修正；matrix-final中直接呼叫已安全返回，測試卻錯要求它持有原NPC等待者及提示，兩項失敗屬不適用的觀察假設。保留所有原始記錄，改成確認未授權呼叫不改旗標、紀錄、次數與原檔，最後verified全過。沒有以這些失敗宣稱產品已修好。新增選項保護另以只移除此保護的擁有者子類作反事實對照：它回到舊選項發結果路徑，18項7失敗並真的提早通知通行；正式保護11項全過且沒有結果通知。差7項是只有錯誤通知發生時才執行的觀察檢查，並非刪掉斷言。最初此診斷子類的局部型別推導錯誤與中止記錄也保留。

第一次必要回歸68組92,203項有1項近戰裝置時間軸失敗，不能當作通過；原始日誌完整保留在required-initial。已先獨立交付NE-237的時鐘比對修正cb3cb8c7，再基於最新main重新執行全部必要範圍與正式runner。editor import另外通過。引擎為同CI來源／修補／選項的本機4.7.2建置，編譯器不同，不宣稱二進位相同。證據包含原負控制、原主檔、所有中間失敗、回歸、來源與原生PNG。[evidence.zip](evidence.zip)、[receipt.json](receipt.json)。
''')
ticket=Path('pm/ST/[ST-19]完成第二章故事與關卡.md')
with ticket.open('a') as stream:
 stream.write(f'''

# Commit-5（巡帳員通行與對話進度一起保存）

## 內文

巡帳員完成查核時，原本即使保存失敗仍會放行並記為讀過。現在成功保存後才一起接受通行、對話紀錄與人物交談次數；拒絕可以原地重試，外部取消保留原進度。直接呼叫、假冒巡帳員或遭修改的結果都不能取得通行。

原版9項有4失敗；修後8程序83項、第一章交付櫃與付款／留宿選擇8程序271項、作者資料15項，以及受影響68組{checks:,}項全過。原生軟體Vulkan互動及冷讀25項全過。樣本安排先前簡報、查核證與位置，真正讀完原對話；不代稱自然整章通關或人工驗收。

![通行結果保存拒絕](images/ST-19-patroller-refused.png)
![重試後接受通行](images/ST-19-patroller-accepted.png)
![冷續玩還原原巡帳員與進度](images/ST-19-patroller-cold.png)

[原始失敗、完整主檔、來源與全部驗證](attachments/ST-19-patroller-save/README.md)。
''')
print(json.dumps(receipt,indent=2))
