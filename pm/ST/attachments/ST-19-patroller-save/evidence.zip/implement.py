from pathlib import Path
p=Path('tools/story/chapter_compiler.py');s=p.read_text();s=s.replace('from ch1_runtime_backend import CompileError, _bubble_ok, _results, _say_lines, _walk','from ch1_runtime_backend import CompileError, DURABLE_POLICIES, validate_completion_policies, _bubble_ok, _results, _say_lines, _walk');s=s.replace('    unpublished_quests: set[str] = field(default_factory=set)','    unpublished_quests: set[str] = field(default_factory=set)\n    completion_policies: dict[str, str] = field(default_factory=dict)');needle='    _check_lines(scenes)';assert needle in s;s=s.replace(needle,'''    for ident, policy in spec.completion_policies.items():
        if ident not in scenes:
            raise CompileError(f'{ident}: 保存政策的段落不存在')
        if not isinstance(policy, str) or policy not in DURABLE_POLICIES:
            raise CompileError(f'{ident}: 未知的保存政策 {policy!r}')
        scene = scenes[ident]
        if scene.get('mode') == 'dispatch':
            raise CompileError(f'{ident}: 分派入口不能宣告段落保存政策')
        if policy == 'main_terminal_results_v1' and any(step.get('do') in ('choice', 'branch') for step in _walk(scene.get('steps', []))):
            raise CompileError(f'{ident}: 終端保存政策不能包含選擇或分支')
        scene['completion_policy'] = policy
        validate_completion_policies({ident: scene})
'''+needle);p.write_text(s)
p=Path('tools/story/build_ch2_story.py');s=p.read_text();needle='        flag_defaults=source.flag_defaults,';assert needle in s;s=s.replace(needle,needle+'\n        completion_policies={"ch2_t_s05_gate": "main_terminal_results_v1"},');p.write_text(s)
Path('game/story_result_ch2.gd').write_text('''extends RefCounted
## Explicit second-chapter boundaries; other story payloads cannot enable them.
const SOURCE := "res://data/story/ch2_heron.json"
const NPC_SOURCES := {
	"ch2_t_s05_gate": {
		"npc": "res://data/npcs/ch2_patroller.tres",
		"levels": ["res://data/levels/ch2_market_gate.tres"],
	},
}
const BOUNDARIES := {
	"ch2_t_s05_gate": {
		"policy": "main_terminal_results_v1", "then": "", "mode": "dialogue",
		"when": {"all": [{"flag": "ch2_brief_done", "equals": true}, {"not": {"flag": "ch2_gate_checked", "equals": true}}]},
		"operations": [{"kind": "flag", "id": "ch2_gate_checked", "value": true}],
	},
}
''')
p=Path('game/story_result_sources.gd');s=p.read_text();s=s.replace('const Clinic := preload("res://game/story_result_clinic.gd")','const Clinic := preload("res://game/story_result_clinic.gd")\nconst Chapter2 := preload("res://game/story_result_ch2.gd")');s=s.replace('return BOUNDARIES.has(id) or Supper.BOUNDARIES.has(id) or Clinic.owns(id)','return not _boundary_rule(id).is_empty() or Clinic.owns(id)');s=s.replace('return BOUNDARIES.get(id, Supper.BOUNDARIES.get(id, {}))','return Chapter2.BOUNDARIES.get(id, BOUNDARIES.get(id, Supper.BOUNDARIES.get(id, {})))');needle='static func _loaded(id: String, scenes: Dictionary, sources: Dictionary) -> Dictionary:';s=s.replace(needle,'''static func npc_source(id: String) -> Dictionary:
	return Chapter2.NPC_SOURCES.get(id, NPC_SOURCES.get(id, {}))

static func authored_source(id: String) -> String:
	return Chapter2.SOURCE if Chapter2.NPC_SOURCES.has(id) else SOURCE

'''+needle);s=s.replace('_text_equals(sources.get(id), SOURCE)','_text_equals(sources.get(id), authored_source(id))');needle='static func _flags_match(raw: Variant, expected: Dictionary) -> bool:';s=s.replace(needle,'''static func _condition_matches(raw: Variant, expected: Variant, depth := 0) -> bool:
	if depth > 16: return false
	if expected is Dictionary:
		if not raw is Dictionary or raw.size() != expected.size(): return false
		for key: String in expected:
			if not raw.has(key) or not _condition_matches(raw[key], expected[key], depth + 1): return false
		return true
	if expected is Array:
		if not raw is Array or raw.size() != expected.size(): return false
		for i in expected.size():
			if not _condition_matches(raw[i], expected[i], depth + 1): return false
		return true
	return _value_equals(raw, expected)

'''+needle);needle='\tvar steps: Variant = scene.get("steps", [])\n';assert needle in s;s=s.replace(needle,'''\tif rule.has("mode") and not _text_equals(scene.get("mode"), rule["mode"]): return {}
	if rule.has("when") and not _condition_matches(scene.get("when", {}), rule["when"]): return {}
'''+needle,1);s=s.replace('not NPC_SOURCES.has(id)','npc_source(id).is_empty()').replace('NPC_SOURCES.get(id, {}) != NPC_SOURCES.get(target, {})','npc_source(id) != npc_source(target)');p.write_text(s)
p=Path('game/story_result_completion.gd');s=p.read_text();s=s.replace('Story._scene_sources.get(String(_id)) != "res://data/story/ch1_kasa.json"','Story._scene_sources.get(String(_id)) != Sources.authored_source(String(_id))');s=s.replace('elif NPC_SOURCES.has(String(_id)):', 'elif not Sources.npc_source(String(_id)).is_empty():');s=s.replace('var source: Dictionary = NPC_SOURCES.get(String(_id), {})','var source: Dictionary = Sources.npc_source(String(_id))');needle='\t\tif actor == null or actor.is_queued_for_deletion()';assert needle in s;s=s.replace(needle,'\t\tif actor == null or not level.npc_sources.has(actor) or actor.is_queued_for_deletion()',1);s=s.replace('return {"error": "terminal NPC result requires its actual current authored interaction"}','return {"error": "terminal NPC result requires its actual current authored interaction", "reload_original": true}');old='''	if not Sources.owns_choice(String(Story._current_cinematic)):
		return {"handled": true, "accepted": false} if choice_pending() else {}
''';new='''	if not Sources.owns_choice(String(Story._current_cinematic)):
		if choice_pending(): return {"handled": true, "accepted": false}
		var scene: Dictionary = Story._scenes.get(String(Story._current_cinematic), {})
		if scene.get("completion_policy", "") in COMPLETION_POLICIES:
			push_warning("[StoryResultCompletion] marked segment contains an unregistered choice")
			Story.reset_active_presentation(&"leave")
			EventBus.toast_requested.emit(Prompt.copy("這段對話暫時無法繼續，原進度保留。", "この会話は未対応です。元の進行状況は保持されています。", "This conversation is unavailable. Your previous progress is preserved."))
			return {"handled": true, "accepted": false}
		return {}
''';assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('game/level/level.gd');s=p.read_text().replace('var channel_sources: Array[Node] = []','var channel_sources: Array[Node] = []\n## Only original authored map actors may settle durable NPC results.\nvar npc_sources: Array[NpcActor] = []');needle='\t\t\tif node is Enemy or node is MechanismSwitch or node is FloodPit or node is EncounterZone:';assert needle in s;s=s.replace(needle,'\t\t\tif node is NpcActor: npc_sources.append(node)\n'+needle,1);p.write_text(s)
