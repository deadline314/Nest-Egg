extends "res://game/story_result_completion.gd"
## Counterfactual only: restore the previous legacy fallback for unknown choices.
func choose(option: Dictionary, retry: Callable) -> Dictionary:
 if not Sources.owns_choice(String(Story._current_cinematic)):
  return {"handled":true,"accepted":false} if choice_pending() else {}
 return super.choose(option,retry)
