from pathlib import Path
p=Path('work/ch2-gate-save/probe.gd').read_text().replace('var before_count:=npc.talk_count','var before_count:=npc.talk_count\n GameState.flag_changed.connect(_observe)')
p=p.replace('func _run() -> void:', '''var _store: RunSaveStore
var _publications := 0
func _run() -> void:''')
p=p.replace(' add_child(_main)\n await _frames(8)',' _store=store\n add_child(_main)\n await _frames(8)\n if _mode.ends_with("_read"):\n  _main.call("_on_continue_requested")\n  await _frames(12)\n  var original:=_npc()\n  var accepted:=_mode=="accepted_read"\n  _check(original!=null and _level().data.id==&"ch2_market_gate","cold primary restores the original chapter-two actor and area")\n  _check(GameState.has_flag(&"ch2_gate_checked")==accepted and Story._completed.has(TARGET)==accepted,"cold result and history agree with the accepted original primary")\n  _check(original!=null and original.talk_count==int(accepted),"cold original actor counter settles exactly once")\n  _check(_prompt()==null and not get_tree().paused,"cold read has no stale result prompt")\n  await _done()\n  return')
p=p.replace(' await _done()\nfunc _prompt()', ''' if _mode=="cancel":
  Story.reset_active_presentation(&"probe_cancel")
  await _frames(4)
  _check(done[0] and not done[1] and npc.talk_count==before_count,"reset returns the original waiter without accepting a check")
  _check(_prompt()==null and not get_tree().paused,"reset releases the original retry presentation")
  _check(FileAccess.get_file_as_bytes(store.path)==_before,"reset preserves exact original primary")
  DirAccess.remove_absolute(store.path+".tmp")
  await _done()
  return
 var prompt:=_prompt()
 if prompt!=null:prompt.retry_button.pressed.emit()
 await _frames(4)
 _check(_prompt()!=null and not done[0] and not GameState.has_flag(&"ch2_gate_checked"),"a second genuine writer refusal remains pending without a result")
 _check(DirAccess.remove_absolute(store.path+".tmp")==OK,"remove only the owned write obstruction")
 if _prompt()!=null:_prompt().retry_button.pressed.emit()
 await _frames(8)
 _check(done[0] and done[1] and npc.talk_count==before_count+1,"same original request settles once after successful retry")
 _check(_publications==1 and GameState.has_flag(&"ch2_gate_checked") and Story._completed.has(TARGET),"successful retry publishes one coherent gate result")
 _check(_prompt()==null and not get_tree().paused,"accepted check releases its prompt and pause")
 await _done()
func _npc() -> NpcActor:
 if _level()==null:return null
 for actor: NpcActor in _level().npc_sources:
  if is_instance_valid(actor) and actor.data.id==&"ch2_patroller":return actor
 return null
func _observe(id: StringName, value: Variant) -> void:
 if id!=&"ch2_gate_checked" or value!=true:return
 _publications+=1
 var npc:=_npc()
 _check(npc!=null and npc._talking and npc._durable_completed and npc.talk_count==1,"first result observer sees durable actor settlement before waiter returns")
 var decoded:=RunSaveCodec.decode(FileAccess.get_file_as_string(_store.path))
 _check(decoded.has("data"),"publication observes original valid checksum without read repair")
 if not decoded.has("data") or npc==null:return
 var disk: Dictionary=decoded.data
 _check(disk.story.flags.get("ch2_gate_checked",false) and disk.story.seen.has(String(TARGET)),"first result observer sees durable flag and history")
 for world: Dictionary in [disk.runtime.world,disk.runtime.area.world,disk.state.area_states[String(_level().data.id)].world]:
  _check(world.get(npc.state_key(),{}).get("talks",-1)==1,"first observer sees the same actor count in every raw primary world")
 _check(not Story.play(TARGET,false),"reentrant presentation cannot replace a publishing result")
func _prompt()''')
Path('tests/probes/patroller_completion.gd').write_text(p)
Path('tests/probes/patroller_completion.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://tests/probes/patroller_completion.gd" id="1"]\n[node name="PatrollerCompletionProbe" type="Node"]\nscript = ExtResource("1")\n')
