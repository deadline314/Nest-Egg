extends "res://work/st13-run-catalog-v1/control.gd"
func _run()->void:
	var condition:="old"
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--condition="):condition=arg.trim_prefix("--condition=")
	var factory=load("res://work/st13-hint-fix-v1/"+condition+".gd")
	for first_seconds in [2.2,.4]:
		var screen=factory.new()
		var plan:={"skippable":false,"steps":[{"kind":"status","text":"保留短暫說明與所有閱讀時間。","time":first_seconds},{"kind":"status","text":"你可以選擇重試或繼續閱讀。","time":1.0},{"kind":"card","time":1.2}]}
		screen.sequence=plan.duplicate(true);screen.setup({},true)
		get_tree().root.add_child(screen);screen.set_process(false)
		await _frames(2)
		screen._process(minf(first_seconds,1.2)-.01)
		_check(not screen._sequence_buttons.is_visible_in_tree(),"mandatory interval still hides the actions")
		screen._process(.02)
		await _frames(2)
		var hint:FocusHintBar=screen._hint_slot.get_child(0)
		var retry:Button=screen._sequence_buttons.get_child(0)
		_check(hint.is_visible_in_tree() and hint.text()==retry.tooltip_text and hint._label.size.x>1,"initial focused retry publishes its actual nonempty, laid-out explanation")
		_check(not screen.sequence_complete and screen._sequence_buttons.is_visible_in_tree(),"actions open while the original voluntary sequence remains unfinished")
		var menu:Button=screen._sequence_buttons.get_child(1);menu.grab_focus()
		for step in 3:screen._process(3.0)
		await _frames(2)
		_check(screen.sequence_complete and screen.sequence==plan,"all source text/times finish unchanged")
		_check(menu.has_focus() and hint.text()==menu.tooltip_text,"natural finish retains the selected menu focus and its explanation")
		screen.free();await _frames(2)
	var plain=factory.new();plain.setup({},true);get_tree().root.add_child(plain)
	await _frames(2)
	var plain_hint:FocusHintBar=plain._hint_slot.get_child(0)
	_check(plain._sequence_buttons.get_child(0).has_focus() and not plain_hint.text().is_empty(),"no-sequence mode keeps the original deferred initial focus")
	plain.free();factory=null
	await _frames(2)
	AudioRelease.begin_shutdown();await AudioRelease.settle(get_tree())
	var file:=FileAccess.open(_out,FileAccess.WRITE)
	file.store_string(JSON.stringify({"classification":"Anonymous source-copy CPU cause control, not adopted product or real Main/native acceptance","condition":condition,"checks":_checks,"failures":_failures},"\t"));file.close()
	print("ST13_HINT_SOURCE_COPY ",condition," checks=",_checks," failures=",_failures.size())
	get_tree().quit.call_deferred(0 if _failures.is_empty() else 1)
