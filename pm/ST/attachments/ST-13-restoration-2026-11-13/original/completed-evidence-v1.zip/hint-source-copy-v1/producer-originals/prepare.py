"""RAM source copies only; never edit the eight frozen product/test files."""
import hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent
ROOT=P.parents[1]
raw=(ROOT/'ui/death_screen.gd').read_bytes();text=raw.decode('utf8')
assert text.startswith('class_name DeathScreen\n')
old=text.removeprefix('class_name DeathScreen\n')
assert old.count('\tretry.grab_focus.call_deferred()')==1
fixed=old.replace('\tretry.grab_focus.call_deferred()\n','',1)
needle='\telse:\n\t\t_open_card(file)\n'
assert fixed.count(needle)==1
fixed=fixed.replace(needle,needle+'\t\tretry.grab_focus.call_deferred()\n',1)
for name,body in [('old.gd',old),('fixed.gd',fixed)]:
    target=P/name;assert not target.exists();target.write_text(body,encoding='utf8',newline='\n')
test=(ROOT/'tests/suite/test_death_flow.gd').read_text(encoding='utf8')
needle='\t\tscreen._process(.02)\n\t\tvar early:='
assert test.count(needle)==1
proposed=test.replace(needle,'\t\tscreen._process(.02)\n\t\tawait frames(2)\n\t\tvar hint := screen._hint_slot.get_child(0) as FocusHintBar\n\t\tvar retry := screen._sequence_buttons.get_child(0) as Button\n\t\tcheck(hint.is_visible_in_tree() and hint.text() == retry.tooltip_text and hint._label.size.x > 1, "opening actions publishes the focused retry explanation, not only its empty slot")\n\t\tvar early:=',1)
target=P/'test_death_flow-proposed.txt';assert not target.exists();target.write_text(proposed,encoding='utf8',newline='\n')
contract=dict(classification='Unadopted anonymous source copies: remove class_name only for two factories; fixed copy only moves the existing deferred grab into the no-sequence branch.',base_UI_sha256=hashlib.sha256(raw).hexdigest(),base_test_sha256=hashlib.sha256((ROOT/'tests/suite/test_death_flow.gd').read_bytes()).hexdigest(),old_copy_sha256=hashlib.sha256((P/'old.gd').read_bytes()).hexdigest(),fixed_copy_sha256=hashlib.sha256((P/'fixed.gd').read_bytes()).hexdigest(),permanent_test_proposal_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),product_sources_untouched=True)
(P/'contract.json').write_text(json.dumps(contract,indent=2)+'\n',encoding='utf8')
print('Prepared source-copy cause control and permanent test proposal; no product edits')
