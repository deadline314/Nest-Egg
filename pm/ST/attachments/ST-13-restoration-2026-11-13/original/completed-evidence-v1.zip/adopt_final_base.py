"""Authorized managed-tree-only restore/rebase/reapply; no commit, index or primary edit."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
P=Path(__file__).resolve().parent
OUT=P/'pre-final-rebase-v1';OUT.mkdir(exist_ok=False)
manifest=json.loads((P/'catalog-delivery-v1/stage-manifest.json').read_text(encoding='utf8'))['files']
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT).decode('utf8').strip()
assert set(git('diff','--name-only').splitlines())==set(manifest)
assert not git('diff','--cached','--name-only')
names=set(manifest)
added=json.loads((P/'catalog-official-v1/source-after.json').read_text(encoding='utf8'))['files'].keys()-json.loads((P/'catalog-official-v1/source-before.json').read_text(encoding='utf8'))['files'].keys()
assert len(added)==12
names.update(added)
for leaf in (ROOT/'work').glob('st13-*'):
    if leaf.is_dir():names.update(p.relative_to(ROOT).as_posix() for p in leaf.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
index={}
for n in sorted(names):
    source=ROOT/n;dest=OUT/'originals'/n;dest.parent.mkdir(parents=True,exist_ok=True);data=source.read_bytes();dest.write_bytes(data)
    index[n]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
assert all(index[n]['sha256']==v['sha256'] for n,v in manifest.items())
(OUT/'original.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--',*manifest],cwd=ROOT))
(OUT/'backup-index.json').write_text(json.dumps(dict(before_HEAD=git('rev-parse','HEAD'),eight_original_candidate_exact=True,added_owned_work12=sorted(added),files=index),indent=2)+'\n',encoding='utf8')
subprocess.run(['git','restore','--source=HEAD','--worktree','--',*manifest],cwd=ROOT,check=True)
assert not git('diff','--name-only')
fetch=subprocess.run(['git','fetch','origin','main'],cwd=ROOT,capture_output=True)
(OUT/'fetch.stdout').write_bytes(fetch.stdout);(OUT/'fetch.stderr').write_bytes(fetch.stderr);assert fetch.returncode==0
latest=git('rev-parse','origin/main')
assert subprocess.run(['git','merge-base','--is-ancestor','20f9dddf8c57a9f8727442f661f5f7cb6236f872',latest],cwd=ROOT).returncode==0
rebase=subprocess.run(['git','rebase','origin/main'],cwd=ROOT,capture_output=True)
(OUT/'rebase.stdout').write_bytes(rebase.stdout);(OUT/'rebase.stderr').write_bytes(rebase.stderr);assert rebase.returncode==0
assert git('rev-parse','HEAD')==latest and not git('diff','--name-only')
patch=OUT/'original.patch'
subprocess.run(['git','apply','--check',str(patch)],cwd=ROOT,check=True)
subprocess.run(['git','apply',str(patch)],cwd=ROOT,check=True)
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==v['sha256'] for n,v in manifest.items())
# Adopt only the proposed permanent assertion first, to obtain its genuine red.
proposal=ROOT/'work/st13-hint-fix-v1/test_death_flow-proposed.txt'
(ROOT/'tests/suite/test_death_flow.gd').write_bytes(proposal.read_bytes())
(OUT/'base-adoption.json').write_text(json.dumps(dict(new_actual_HEAD=latest,primary_C_untouched=True,index_untouched=True,eight_previous_sources_reapplied_exact=True,permanent_hint_assertion_adopted_before_UI_fix=True,old70_inventory_rejection_preserved=True),indent=2)+'\n',encoding='utf8')
print('Managed new base',latest,'old eight exact reapplied; only permanent hint assertion additionally adopted, UI fix not yet adopted')
