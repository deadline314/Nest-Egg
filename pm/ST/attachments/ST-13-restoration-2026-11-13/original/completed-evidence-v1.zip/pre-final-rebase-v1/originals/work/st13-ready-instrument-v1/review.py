"""Read-only section replay and exact restoration seal; no engine launch."""
import hashlib,json
from pathlib import Path
P=Path('D:/NestEggVerification/proofs/st13-restoration-clock-20261112')
CASE=P/'candidate-ready-instrument-v1'
CONTRACT=P/'candidate-ready-instrument-v1-source-contract'
def load(p):return json.loads(p.read_text(encoding='utf8'))
before=load(CASE/'before.json');after=load(CASE/'after.json');restored=load(CONTRACT/'restoration.json')
assert before['tracked_source_sha256']==after['tracked_source_sha256'] and before['own']==after['own']
assert before['base']=='5a363c4e29c186661eba364cc2bbee3cee374178' and restored['exact_candidate_restored']
assert restored['source_before']==restored['source_after']
rows=[]
for line in (CASE/'process.log').read_text(encoding='utf8').splitlines():
    if not line.startswith('ST13_LEVEL_READY '):continue
    record=json.loads(line.split('ST13_LEVEL_READY ',1)[1]);marks=record['marks']
    sections=[dict(section=b[0],microseconds=b[1]-a[1],msec=(b[1]-a[1])/1000) for a,b in zip(marks,marks[1:])]
    assert all(s['microseconds']>=0 for s in sections)
    total=marks[-1][1]-marks[0][1]
    assert sum(s['microseconds'] for s in sections)==total
    rows.append(dict(Level_id=record['Level_id'],resume=record['resume'],total_msec=total/1000,sections=sections))
assert len(rows)==2 and rows[0]['Level_id']!=rows[1]['Level_id']
proc=load(CASE/'process.json');assert proc['exit_code']==1 and not proc['diagnostics']
receipt=dict(classification='One natural Main process, first Level load plus same-Level retry; instrumentation only, no product optimization adopted',actual_base=before['base'],source_contract_metadata_erratum='source-contract.json.base is the saved three candidate SHA dictionary, not a Git commit; actual base is frozen before.json.base. Original contract is preserved.',rows=rows,candidate_exactly_restored=True,engine_diagnostics=0,complete_control_still_red=True,largest_repeat_section='Hud',inference_not_subsection_measurement='QuestGuidance._ready reparses/validates all canonical quest sources on each new HUD; QuestMapIndex already reuses chapter geometry. No individual QuestGuidance subsection timing is claimed.',files={})
for folder in [CASE,CONTRACT]:
    for path in folder.rglob('*'):
        if path.is_file() and 'user' not in path.relative_to(folder).parts:
            receipt['files'][path.relative_to(P).as_posix()]=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
target=P/'candidate-ready-instrument-v1-review.json';assert not target.exists();target.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print('Read-only instrumentation replay passed; exact candidate restoration verified; repeat HUD',next(s['msec'] for s in rows[1]['sections'] if s['section']=='Hud'),'ms')
