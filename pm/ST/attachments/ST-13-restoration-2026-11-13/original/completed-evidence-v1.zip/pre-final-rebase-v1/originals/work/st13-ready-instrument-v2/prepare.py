"""New epoch of the exact section observer, using the approved eight-source wrapper."""
from pathlib import Path
P=Path(__file__).resolve().parent
source=(P.parent/'st13-ready-instrument-v1/run.py').read_text(encoding='utf8')
assert "TAG='candidate-ready-instrument-v1'" in source
source=source.replace("TAG='candidate-ready-instrument-v1'","TAG='catalog-ready-instrument-v2'",1)
source=source.replace("ROOT/'work/st13-candidate-v1/run_main_v3.py'","ROOT/'work/st13-run-catalog-v1/run.py'",1)
source=source.replace('base=expected,classification=',"base='5a363c4e29c186661eba364cc2bbee3cee374178',classification=",1)
source=source.replace('code=module.main(TAG,2,False)',"code=module.main(__import__('argparse').Namespace(tag=TAG,mode='main',count=2,refuse=False))",1)
source=source.replace('"process_return":code','"process_return":code')
target=P/'run.py';assert not target.exists();target.write_text(source,encoding='utf8',newline='\n')
print('Prepared v2 only; no instrumentation or engine started')
