extends "res://work/st13-run-catalog-v1/control.gd"
func _run()->void:
	var rows=[]
	for count in [2,3]:
		GameState.start_new_run(GameState.difficulties[1])
		for n in count:GameState.register_death()
		var screen:=DeathScreen.new()
		screen.sequence=Story.death_sequence(&"ch1_kasa",count)
		screen.setup(DefeatCodex.unlock(&"grunt_shot"),true)
		get_tree().root.add_child(screen)
		var frame:=0
		var first:=-1
		var samples=[]
		while not screen.sequence_complete:
			await get_tree().process_frame
			frame+=1
			if screen._sequence_buttons.is_visible_in_tree() and first<0:first=frame
			if first>=0 and frame-first in [0,3,10,30]:
				var bar:=screen._hint_slot.get_child(0) as FocusHintBar
				var focus:=get_viewport().gui_get_focus_owner()
				samples.append({"frames_after_actions":frame-first,"bar_text":bar.text(),"bar_visible":bar.is_visible_in_tree(),"label_size":[bar._label.size.x,bar._label.size.y],"focus_text":focus.text if focus is Button else "","sequence_index":screen.sequence_index,"card_alpha":screen._sequence_card.modulate.a,"card_scale_y":screen._sequence_card.scale.y})
		rows.append({"count":count,"samples":samples})
		screen.free()
		await get_tree().process_frame
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	var file:=FileAccess.open(_out,FileAccess.WRITE)
	file.store_string(JSON.stringify({"classification":"Headless live UI readiness only, not native readability or natural Main control","rows":rows},"\t"));file.close()
	print("ST13_READINESS_ONLY ",JSON.stringify(rows))
	get_tree().quit.call_deferred(0)
