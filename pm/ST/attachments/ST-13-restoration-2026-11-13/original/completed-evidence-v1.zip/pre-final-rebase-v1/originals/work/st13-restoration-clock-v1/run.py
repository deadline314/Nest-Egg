"""Only this probe leaf/proof is written. Four natural-time processes, sequential."""
import argparse,hashlib,json,os,re,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent
ROOT=P.parents[1]
PROOF=Path('D:/NestEggVerification/proofs/st13-restoration-clock-20261112')
GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
BASE='81df4b8c9cfff960d81d3c8e54bba5ebb3e86b51'
ENV=['APPDATA','LOCALAPPDATA','USERPROFILE','XDG_DATA_HOME','XDG_CONFIG_HOME']
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode('utf8').strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    assert not path.exists();path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8',newline='\n')
def snapshot():
    assert git('rev-parse','HEAD')==BASE
    assert subprocess.run(['git','diff','--quiet'],cwd=ROOT).returncode==0
    assert subprocess.run(['git','diff','--cached','--quiet'],cwd=ROOT).returncode==0
    paths=git('ls-files','-z').split('\0')
    active=[n for n in paths if n and (n.split('/')[0] in ['autoload','core','game','ui','data','scenes','shaders','tools'] and Path(n).suffix in ['.gd','.uid','.tscn','.tres','.json','.gdshader'] or n=='project.godot')]
    return dict(base=BASE,tracked_source_sha256={n:sha(ROOT/n) for n in active},own={str(n):sha(n) for n in P.iterdir() if n.suffix in ['.gd','.tscn','.py']},git_status=git('status','--short'))
def process(folder,scene,count=None,extra=None,verbose_engine=False):
    folder.mkdir(parents=True,exist_ok=False)
    env=os.environ.copy();prior={k:env.get(k) for k in ENV}
    for key in ENV:
        target=folder/'user'/key;target.mkdir(parents=True);env[key]=str(target)
    save(folder/'environment.json',dict(original=prior,isolated={k:env[k] for k in ENV},five_names=ENV))
    command=[GODOT,'--headless','--path',str(ROOT),'--audio-driver','Dummy']
    if verbose_engine:command.append('--verbose')
    if count is None:command+=['--quit-after','120',str(P/scene)]
    else:command+=[str(P/scene),'--','--count='+str(count),'--out='+str(folder/'measurement.json')]
    command+=extra or []
    start=time.monotonic()
    with (folder/'process.log').open('xb') as log:
        result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
    text=(folder/'process.log').read_text(encoding='utf8',errors='replace')
    diagnostics=[line for line in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|Parse Error|ObjectDB.*leak|were leaked|resources still in use',line)]
    row=dict(command=command,exit_code=result.returncode,seconds=time.monotonic()-start,diagnostics=diagnostics,log_sha256=sha(folder/'process.log'))
    save(folder/'process.json',row)
    assert not diagnostics,(folder,diagnostics)
    if count is None:assert result.returncode==0 and 'ST13_PARSE_OK' in text
    else:assert result.returncode in [0,1,2] and (folder/'measurement.json').exists()
    print(folder.name,'exit',result.returncode,'diagnostics',len(diagnostics),flush=True)
    return row
def main(tag,parse_only,verbose_engine=False):
    out=PROOF/tag;out.mkdir(parents=True,exist_ok=False)
    before=snapshot();save(out/'before.json',before)
    process(out/'parser','parse.tscn')
    rows=[]
    if not parse_only:
        for count in [2,3]:
            for repeat in [1,2]:
                folder=out/('count%d-run%d'%(count,repeat));process(folder,'probe.tscn',count,verbose_engine=verbose_engine)
                data=json.loads((folder/'measurement.json').read_text());assert data['target_count']==count
                assert data['measurement']['selected_sequence']['min_deaths']==count
                rows.append(dict(count=count,repeat=repeat,zero_to_retry_msec=data['measurement']['zero_to_retry_msec'],ST13_le_3000msec=data['measurement']['ST13_le_3000msec']))
    after=snapshot();save(out/'after.json',after)
    # No tracked or existing own bytes may change. New .uid files are recorded separately.
    assert before['base']==after['base'] and before['tracked_source_sha256']==after['tracked_source_sha256']
    assert all(after['own'][n]==h for n,h in before['own'].items())
    save(out/'completion.json',dict(classification='Natural UI-availability lower bound; not Main persistence or actual retry/control proof',source_fixed=True,no_GPU=True,no_frame_or_time_scale_changes=True,verbose_engine=verbose_engine,parse_only=parse_only,measurements=rows,all_original_3000msec=[r['ST13_le_3000msec'] for r in rows]))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--tag',required=True);ap.add_argument('--parse-only',action='store_true');ap.add_argument('--verbose-engine',action='store_true');args=ap.parse_args();main(args.tag,args.parse_only,args.verbose_engine)
