# ST13 Level ready cost and minimal reuse proposal

The diagnostic used managed base `5a363c4e29c186661eba364cc2bbee3cee374178` plus the three frozen ST13 candidates. Only `Level._ready` received local timestamp-array instrumentation. It printed once at the end of each ready call. One real Main process loaded the booth and retried it once; public synthetic input and the original timed transition were retained. No renderer, FPS, time scale, persistence or algorithm was changed.

| Section | First load ms | Retry ms |
| --- | ---: | ---: |
| Entire Level ready | 3819.876 | 716.700 |
| Hud | 2444.874 | 672.115 |
| Player and CharacterRig | 752.475 | 7.068 |
| Props | 314.326 | 1.314 |
| Inventory add | 17.679 | 17.881 |
| LevelBuilder parse | 8.058 | 4.141 |
| Terrain build | 25.062 | 0.134 |
| BackWall setup | 1.560 | 0.601 |

The retry's repeated cost is HUD (93.8%), not terrain meshes or Inventory. Individual QuestGuidance subsections were not timed, so the following is a source-based explanation to test, not a measured attribution inside HUD.

`QuestGuidance._ready` constructs a new `QuestCatalog` and calls `load_story_sources` every time. That rereads three canonical story JSON files and revalidates 29 quests / 71 step locations across 27 areas, including 44 repeated area validations. Each `QuestCatalog.valid_location` calls `LevelBuilder.parse`; there is no catalog reuse. `QuestMapIndex.for_chapter` already reuses its index, so replacing that cache would miss the repeated definition work.

`QuestMapState.for_run` is the existing shared lifetime owner: it follows `GameState.area_states` identity, persists through death/area/chapter changes and resets for a new or restored run. Main already binds this state. PauseMenu passes `guidance.catalog` to its navigation UI; runtime UI methods only read it. Tests can construct and mutate independent fixture catalogs. RunSnapshot currently validates another temporary catalog for restoring navigation and then discards it before the new HUD validates again.

Proposed narrow change, pending runtime implementation:

1. Keep one private, validated source catalog on the existing run state. Return a fresh catalog with deep-copied quest dictionaries and copied issues for each UI consumer. UI mutations must never modify the owner's definition snapshot. Do not cache world flags, selected goals or completion results.
2. Guidance uses that copy only when no catalog was explicitly injected; keep fixture catalogs intact.
3. Navigation restore obtains the same run-state copy after installing area/story state. The following HUD can reuse the definitions already validated by restore.
4. On the existing Story reload boundary, explicitly invalidate the current run's definition snapshot. Language display still uses the original source records and the existing `display_text` fallback; no translated facts or new mission truth are introduced.
5. Keep the existing loader and all malformed-data checks. A source load with issues must not become a successful retained snapshot; a repaired source can be revalidated. No file IO occurs per frame.

Expected narrow files: `core/navigation/quest_map_state.gd`, `ui/quest_guidance.gd`, the navigation-restore lines in `core/run_snapshot.gd`, one invalidation call in `autoload/story.gd`, and the existing `tests/suite/test_quest_map.gd`. The existing three ST13 candidates stay separate and byte-identical until an authorized fix is tested.

Controls to add before implementation: cold versus repeated actual HUD/Level construction; mutation isolation of nested quests/steps and issues; death/chapter lifetime and new-run reset; real restore warming the same owner; injected fixture identity; Story reload/language invalidation; fresh task-status evaluation after flags change; malformed source retains path-specific issues and a repaired source recovers. Existing direct `QuestCatalog.read_source` validation stays unchanged. Then repeat the complete natural Main clock for counts 2/3 and actual write refusal/repair. A shorter UI wait cannot substitute for the full control endpoint.

Evidence stays under `D:/NestEggVerification/proofs/st13-restoration-clock-20261112/candidate-ready-instrument-v1` and `candidate-ready-instrument-v1-source-contract`. The independent section/restoration receipt is `candidate-ready-instrument-v1-review.json`. The original contract's `base` field accidentally contains the candidate SHA dictionary; the actual immutable Git base is retained in before/after and explicitly corrected in the separate review. No old artifact was rewritten.

The process exited 1 for the original complete-clock threshold, with zero engine/script/leak diagnostics. The candidate Level/UI/test SHA values were exactly restored after the process. No C product, PM, index or commit was modified.
