import argparse,hashlib,json,os,re,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent
ROOT=P.parents[1]
PROOF=Path('D:/NestEggVerification/proofs/st13-restoration-clock-20261112')
BASE='20f9dddf8c57a9f8727442f661f5f7cb6236f872'
OWNED=['ui/death_screen.gd','game/level/level.gd','tests/suite/test_death_flow.gd','ui/quest_guidance.gd','core/navigation/quest_map_state.gd','core/run_snapshot.gd','autoload/story.gd','tests/suite/test_quest_map.gd']
ENV=['APPDATA','LOCALAPPDATA','USERPROFILE','XDG_DATA_HOME','XDG_CONFIG_HOME']
GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
    assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8',newline='\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode('utf8').strip()
def snapshot():
    assert git('rev-parse','HEAD')==BASE
    changed=set(git('diff','--name-only').splitlines());assert changed<=set(OWNED),changed
    assert not git('diff','--cached','--name-only')
    names=git('ls-files','-z').split('\0')
    names=[n for n in names if n and (n=='project.godot' or n.split('/')[0] in ['autoload','core','game','ui','data','scenes','shaders','tools','tests'] and Path(n).suffix in ['.gd','.uid','.tscn','.tres','.json','.gdshader'])]
    own={str(p.relative_to(ROOT)):sha(p) for leaf in ['st13-candidate-v1','st13-run-catalog-v1'] for p in (ROOT/'work'/leaf).rglob('*') if p.suffix in ['.gd','.tscn','.py']}
    return dict(base=BASE,tracked_source_sha256={n:sha(ROOT/n) for n in names},own=own,changed=sorted(changed))
def main(args):
    out=PROOF/args.tag;out.mkdir(parents=True,exist_ok=False)
    before=snapshot();write(out/'before.json',before)
    for n in OWNED:
        target=out/'runtime-originals'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/n).read_bytes())
    for n in before['own']:
        target=out/'producer-originals'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/n).read_bytes())
    env=os.environ.copy();original={k:env.get(k) for k in ENV}
    for k in ENV:
        target=out/'user'/k;target.mkdir(parents=True);env[k]=str(target)
    write(out/'environment.json',dict(original=original,isolated={k:env[k] for k in ENV}))
    scene='res://work/st13-run-catalog-v1/control.tscn'
    extra=['--out='+str(out/'measurement.json')]
    if args.mode=='main':
        scene='res://work/st13-candidate-v1/main_probe_v3.tscn';extra+=['--count='+str(args.count)]
        if args.refuse:extra+=['--refuse-write']
    elif args.mode=='suites':
        scene='res://tests/smoke_test.tscn';extra=['--only=QuestMapSuite,DeathFlowSuite']
    elif args.mode=='hint-short':scene='res://work/st13-candidate-v1/short.tscn'
    cmd=[GODOT,'--headless','--path',str(ROOT),'--audio-driver','Dummy',scene,'--',*extra]
    start=time.monotonic()
    try:
        with (out/'process.log').open('xb') as log:result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300 if args.mode=='suites' else 95)
        code=result.returncode
    except subprocess.TimeoutExpired:code='timeout'
    text=(out/'process.log').read_text(encoding='utf8',errors='replace')
    diag=[l for l in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|Parse Error|ObjectDB.*leak|were leaked|resources still in use',l)]
    write(out/'process.json',dict(command=cmd,exit_code=code,seconds=time.monotonic()-start,diagnostics=diag,log_sha256=sha(out/'process.log'),mode=args.mode))
    after=snapshot();write(out/'after.json',after)
    assert before==after,'actual runtime/source footprint changed'
    print(args.tag,'exit',code,'diagnostics',len(diag),flush=True)
    if (out/'measurement.json').exists():
        x=json.loads((out/'measurement.json').read_text(encoding='utf8'))
        if args.mode in ['control','hint-short']:print(x,flush=True)
        else:print(dict(ui_msec=x.get('measurement',{}).get('zero_to_retry_msec'),control_msec=x.get('control',{}).get('zero_to_control_msec'),error=x.get('prerequisite_error'),refusal=bool(x.get('refusal'))),flush=True)
    assert not diag,diag
    return code if isinstance(code,int) else 2
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--tag',required=True);a.add_argument('--mode',choices=['control','main','suites','hint-short'],required=True);a.add_argument('--count',type=int,choices=[2,3],default=2);a.add_argument('--refuse',action='store_true');raise SystemExit(main(a.parse_args()))
