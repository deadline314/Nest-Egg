"""Read-only independent timing/exit reader. Never upgrades audio leaks to PASS."""
import argparse,hashlib,json,re
from pathlib import Path
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(root):
    index=json.loads((root/'canonical-default-v9-index.json').read_text())
    for name,h in index['files'].items():assert sha(root/name)==h,(name,'original bytes changed')
    source=root/'runtime-default-v9-originals'
    story=json.loads((source/'data/story/ch1_kasa.json').read_text(encoding='utf8'))
    delay=float(re.search(r'const DEATH_SCREEN_DELAY\s*:=\s*([0-9.]+)',(source/'game/level/level.gd').read_text(encoding='utf8'))[1])
    before=json.loads((root/'natural-audiorelease-v9/before-pair.json').read_text())
    after=json.loads((root/'natural-audiorelease-v9/after-all-four.json').read_text())
    assert before==after and before['base']=='81df4b8c9cfff960d81d3c8e54bba5ebb3e86b51'
    rows=[]
    for count in [2,3]:
        for repeat in [1,2]:
            folder=root/'natural-audiorelease-v9'/('count%d-run%d'%(count,repeat))
            record=json.loads((folder/'measurement.json').read_text());m=record['measurement']
            process=json.loads((folder/'process.json').read_text());env=json.loads((folder/'environment.json').read_text())
            log=(folder/'process.log').read_text(encoding='utf8',errors='replace')
            assert sha(folder/'process.log')==process['log_sha256']
            assert '--headless' in process['command'] and '--verbose' not in process['command']
            assert not any(arg in process['command'] for arg in ['--max-fps','--fixed-fps','--time-scale','--quit-after'])
            assert record['environment']==env['isolated'] and len(env['five_names'])==5
            assert record['fixture']['prior_deaths']==count-1 and record['fixture']['clinic_not_played_in_probe']
            assert record['fixture']['prior_recording_not_played_in_probe'] and record['fixture']['recording_heard_flag']
            assert record['entry_observation_at_exit']['deaths']==count
            assert 'prerequisite_error' not in record
            started=record['entry_settled']['started'];finished=record['entry_settled']['finished']
            for id in record['fixture']['expected_entry_radio_ids']:
                assert any(s['id']==id and s['mode']=='radio' for s in started)
                assert any(s['id']==id and s['usec']<m['hit_usec'] for s in finished)
            assert record['entry_settled']['clock']['tree_paused']==False
            assert m['hit_usec']<=m['health_zero_usec']<m['screen_entered_tree_usec']<m['retry_visible_enabled_focus_usec']
            observed=(m['retry_visible_enabled_focus_usec']-m['health_zero_usec'])/1000
            assert observed==m['zero_to_retry_msec']
            picked=max((s for s in story['death_sequences'] if s['min_deaths']<=count),key=lambda s:s['min_deaths'])
            assert m['selected_sequence']==picked and picked['min_deaths']==count
            nominal=sum(min(3,max(0,float(s.get('time',.6)))) for s in picked['steps'])
            assert abs(nominal-m['sequence_nominal_seconds'])<1e-12 and m['original_Level_delay_seconds']==delay
            assert m['retry_state']['visible_in_tree'] and not m['retry_state']['disabled'] and m['retry_state']['can_process'] and m['retry_state']['has_focus']
            assert m['retry_not_activated'] and not m['Main_save_owner_present']
            assert all(v==1 for v in m['raw_time_scales']) and len(m['raw_time_scales'])==len(m['raw_process_deltas'])>0
            assert all(v>0 for v in m['raw_process_deltas'])
            clocks=[record['startup_clock'],record['entry_settled']['clock'],m['end_clock']]
            assert all(c['max_fps']==0 and c['physics_ticks_per_second']==60 and c['time_scale']==1 and not c['story_auto_skip'] for c in clocks)
            threshold=observed<=3000
            assert m['ST13_le_3000msec']==threshold and process['exit_code']==(0 if threshold else 1)
            scripts=[line for line in log.splitlines() if 'SCRIPT ERROR' in line or 'Parse Error' in line]
            assert not scripts
            diagnostics=[line for line in log.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|Parse Error|ObjectDB.*leak|were leaked|resources still in use',line)]
            assert diagnostics==process['diagnostics'] and not diagnostics
            assert isinstance(m['sequence_complete_at_UI_available'],bool)
            shutdown=record['audio_shutdown']
            assert shutdown['after_measurement_only'] and shutdown['begin_usec']>=m['retry_visible_enabled_focus_usec']
            assert shutdown['end_usec']>shutdown['begin_usec'] and not shutdown['allows_playback_after']
            assert 'screen.sequence_complete and' not in (root/'producer-default-v9-originals/probe.gd').read_text()
            marker=log.index('ST13_NATURAL_CLOCK')
            assert all(log.index(line)>marker for line in diagnostics),'error before finalized observation'
            rows.append(dict(count=count,repeat=repeat,zero_to_UI_available_msec=observed,Level_delay_seconds=delay,sequence_seconds=nominal,original_le_3000msec=threshold,exit_code=process['exit_code'],raw_script_errors=scripts,raw_exit_diagnostics=diagnostics,strict_engine_clean=not diagnostics,mode='default, existing AudioRelease after endpoint',not_actual_retry_or_Main_persistence=True))
    return dict(classification='Published81df default natural-clock baseline; existing terminal audio helper used only after observation, no product fix',tracked_sources= len(before['tracked_source_sha256']),source_fixed=True,rows=rows,conclusion='Both count2 observations exceed3seconds before retry can be initiated. Count3 UI availability is not full restored player control. The four default observations have0engine diagnostics using the existing shutdown helper. Earlier audio leaks remain in original epochs; no audio-product fix or full Main/control proof is claimed.',default_failures_retained=index['retained_default_failures'],no_manual_skip_pause_FPS_or_time_scale_changes=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path('D:/NestEggVerification/proofs/st13-restoration-clock-20261112'));args=ap.parse_args();print(json.dumps(read(args.root),indent=2))
