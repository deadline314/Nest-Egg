"""Only original selector planning; never starts tests or an engine."""
import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
P=Path(__file__).resolve().parent/'catalog-selector-plan-v1'
P.mkdir(exist_ok=False)
cmd=['python','-X','utf8','tools/select_tests.py','--base','5a363c4e29c186661eba364cc2bbee3cee374178','--explain']
start=time.monotonic();r=subprocess.run(cmd,cwd=ROOT,capture_output=True)
(P/'stdout.txt').write_bytes(r.stdout);(P/'stderr.txt').write_bytes(r.stderr)
assert r.returncode==0,r.stderr
groups=[line.split(':',1)[0] for line in r.stdout.decode('utf8').splitlines() if ':' in line]
owned=json.loads((P.parent/'catalog-pre-adoption-v1.json').read_text())['three_ST13_candidates_before_catalog_fix']
assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in owned.items()),'Level instrumentation not restored'
record=dict(classification='Original selector plan only; no affected tests executed here',actual_base=cmd[-2],command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start,group_count=len(groups),groups=groups,original_selector_sha256=hashlib.sha256((ROOT/'tools/select_tests.py').read_bytes()).hexdigest(),tracked_changed=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT).decode().splitlines(),proposed_entry='GODOT=C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe tools/run_tests_changed.sh 5a363c4e29c186661eba364cc2bbee3cee374178',no_long_batch_started=True)
(P/'plan.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
print('Original selector:',len(groups),'groups; not started')
