import hashlib,json
from pathlib import Path
ROOT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
P=Path(__file__).resolve().parent
OUT=P/'native-v2-source-originals';OUT.mkdir(exist_ok=False)
before=json.loads((P/'native-layout-v2-count2/before.json').read_text(encoding='utf8'))
index={}
for n,h in before['own'].items():
    source=Path(n);data=source.read_bytes();assert hashlib.sha256(data).hexdigest()==h
    target=OUT/'producer'/source.name;target.parent.mkdir(exist_ok=True);target.write_bytes(data);index[target.relative_to(OUT).as_posix()]=h
for n,v in json.loads((P/'catalog-delivery-v1/stage-manifest.json').read_text(encoding='utf8'))['files'].items():
    source=Path(v['candidate_path']);data=source.read_bytes();assert hashlib.sha256(data).hexdigest()==v['sha256']
    target=OUT/'runtime-eight'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);index[target.relative_to(OUT).as_posix()]=v['sha256']
for n in ['work/st13-candidate-v1/main_probe_v3.gd','work/st13-run-catalog-v1/run.py']:
    source=P/'pre-final-rebase-v1/originals'/n;data=source.read_bytes()
    assert hashlib.sha256(data).hexdigest()==before['managed']['own'][n]
    target=OUT/'dependency'/Path(n).name;target.parent.mkdir(exist_ok=True);target.write_bytes(data);index[target.relative_to(OUT).as_posix()]=hashlib.sha256(data).hexdigest()
source=ROOT/'tools/viewport_capture.gd';assert hashlib.sha256(source.read_bytes()).hexdigest()==before['canonical_capture_sha256']
(OUT/'viewport_capture.gd').write_bytes(source.read_bytes());index['viewport_capture.gd']=before['canonical_capture_sha256']
(OUT/'index.json').write_text(json.dumps(dict(actual_base=before['managed']['base'],files=index,native_images_require_original_v2_readiness_limitation=True,precision_only_not_readable_layout_acceptance=True),indent=2)+'\n',encoding='utf8')
print('Exact native v2 producer/dependency/eight-source bytes preserved:',len(index),'files')
