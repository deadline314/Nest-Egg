"""Small immutable-source delivery. Raw remains in the persistent proof directory."""
import hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent
ROOT=P.parents[1]
PROOF=Path('D:/NestEggVerification/proofs/st13-restoration-clock-20261112')
OUT=PROOF/'candidate-delivery-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
    assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8',newline='\n')
assert not OUT.exists();OUT.mkdir()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
assert base=='5a363c4e29c186661eba364cc2bbee3cee374178'
owned=['game/level/level.gd','ui/death_screen.gd','tests/suite/test_death_flow.gd']
sources={}
for n in owned:
    target=OUT/'candidate'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/n).read_bytes());sources[n]=sha(target)
patch=subprocess.check_output(['git','diff','--binary','--',*owned],cwd=ROOT)
(OUT/'candidate.patch').write_bytes(patch)
cases=['candidate-main-v2-count2','candidate-main-v2-count3','candidate-main-v2-refusal-count2','candidate-main-v3-span-count2']
rows=[]
for name in cases:
    folder=PROOF/name
    x=json.loads((folder/'measurement.json').read_text(encoding='utf8'))
    process=json.loads((folder/'process.json').read_text(encoding='utf8'))
    before=json.loads((folder/'before.json').read_text(encoding='utf8'));after=json.loads((folder/'after.json').read_text(encoding='utf8'))
    assert before['tracked_source_sha256']==after['tracked_source_sha256'] and before['own']==after['own']
    assert not process['diagnostics']
    assert all(before['tracked_source_sha256'][n]==sources[n] for n in owned if n!='tests/suite/test_death_flow.gd')
    rows.append(dict(case=name,count=x['target_count'],exit_code=process['exit_code'],UI_msec=x['measurement']['zero_to_retry_msec'],control_msec=x['control']['zero_to_control_msec'],complete_control_le_3000=x['control']['ST13_le_3000msec'],refusal_safety=bool(x.get('refusal')),source_fixed=True,engine_diagnostics=0))
write(OUT/'summary.json',dict(classification='Partial candidate; UI/focus/refusal safety green, complete Main return-to-control RED. No ST13 completion.',base=base,owned_sources=sources,short_unit_red=dict(checks=14,failures=5),short_unit_green=dict(checks=17,failures=0),cases=rows,original_default_baseline='canonical-default-v9-index.json',no_GPU=True,no_changed_batch=True,no_primary_C_or_PM_or_index_edits=True,first_Main_driver_failure='candidate-main-v1-count2 preserved: standalone root-parent assertion was invalid under real Main; explicitly terminated only its own stuck process after assertion; no lethal timing and no strict cleanup claim',notes=['Main real original timed Transition is enabled explicitly because headless default instant=true. No speed/FPS/time_scale adjustments.', 'Synthetic public ui_accept and move_right; never physical keyboard/controller or human walkthrough.', 'Refusal blocked only owned .tmp after legal death autosaves settled. Original primary/backup retained; repair entered one new Level, deaths/fees not applied again.', 'Count2 and count3 UI timings do not replace complete control endpoint.', 'Main v3 observer subclasses only wrap original calls with wall timestamps; no product Main modification.']))
names=cases+['candidate-main-v1-count2','candidate-short-red-v1','candidate-short-green-v1']
index={}
for name in names:
    for path in sorted((PROOF/name).rglob('*')):
        if path.is_file() and 'user' not in path.relative_to(PROOF/name).parts:
            index[path.relative_to(PROOF).as_posix()]=dict(bytes=path.stat().st_size,sha256=sha(path))
for path in OUT.rglob('*'):
    if path.is_file():index[path.relative_to(PROOF).as_posix()]=dict(bytes=path.stat().st_size,sha256=sha(path))
write(OUT/'index.json',dict(raw_root=str(PROOF),files=index))
print('candidate bundle:',len(index),'files',sum(r['bytes'] for r in index.values()),'bytes; complete control remains RED')
