"""Exact eight-source delivery and original 70-group entry; no source edits."""
import hashlib,json,os,re,subprocess,time,sys
from pathlib import Path
ROOT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
PROOF=Path('D:/NestEggVerification/proofs/st13-restoration-clock-20261112')
OUT=PROOF/'catalog-official-v2'
DELIVERY=PROOF/'catalog-delivery-v2'
BASE='20f9dddf8c57a9f8727442f661f5f7cb6236f872'
OWNED=['ui/death_screen.gd','game/level/level.gd','tests/suite/test_death_flow.gd','ui/quest_guidance.gd','core/navigation/quest_map_state.gd','core/run_snapshot.gd','autoload/story.gd','tests/suite/test_quest_map.gd']
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while data:=f.read(1048576):h.update(data)
    return h.hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode('utf8').strip()
def write(p,d):
    assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8',newline='\n')
def snapshot():
    assert git('rev-parse','HEAD')==BASE
    assert set(git('diff','--name-only').splitlines())==set(OWNED)
    names=git('ls-files','-co','--exclude-standard','-z').split('\0')
    names=sorted(set(n for n in names if n and (ROOT/n).is_file()))
    return dict(base=BASE,count=len(names),files={n:dict(bytes=(ROOT/n).stat().st_size,sha256=sha(ROOT/n)) for n in names})
def main():
    assert (ROOT/'.godot').is_dir(),'No implicit import authorized in this runner'
    OUT.mkdir(parents=True,exist_ok=False)
    manifest=json.loads((DELIVERY/'stage-manifest.json').read_text(encoding='utf8'))['files']
    assert set(manifest)==set(OWNED) and all(sha(ROOT/n)==v['sha256'] for n,v in manifest.items())
    selected=subprocess.run([sys.executable,'-X','utf8','tools/select_tests.py','--base',BASE],cwd=ROOT,capture_output=True)
    (OUT/'selector.stdout').write_bytes(selected.stdout);(OUT/'selector.stderr').write_bytes(selected.stderr)
    assert selected.returncode==0
    groups=selected.stdout.decode('utf8').strip().split(',')
    write(OUT/'selector.json',dict(base=BASE,groups=groups,count=len(groups),exit_code=selected.returncode))
    before=snapshot();write(OUT/'source-before.json',before)
    env=os.environ.copy();prior={k:env.get(k) for k in ['APPDATA','LOCALAPPDATA','USERPROFILE','XDG_DATA_HOME','XDG_CONFIG_HOME']}
    for k in prior:
        p=OUT/'environment'/k;p.mkdir(parents=True);env[k]=p.as_posix()
    env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',SHARDS='2',LOG_DIR=(OUT/'logs').as_posix(),PYTHONIOENCODING='utf-8')
    write(OUT/'environment.json',dict(original=prior,isolated={k:env[k] for k in prior},GODOT=env['GODOT'],SHARDS=env['SHARDS'],LOG_DIR=env['LOG_DIR'],classification='Functional affected batch; other headless work exists, not isolated performance'))
    command=['C:/Program Files/Git/bin/bash.exe','--noprofile','--norc','tools/run_tests_changed.sh',BASE]
    write(OUT/'command.json',dict(command=command,cwd=str(ROOT),original_entry_sha256=sha(ROOT/'tools/run_tests_changed.sh'),original_parallel_sha256=sha(ROOT/'tools/run_tests_parallel.sh'),original_filter_sha256=sha(ROOT/'tools/test_filters.sh'),known_failures_sha256=sha(ROOT/'tests/known_failures.txt'),expected_groups=len(groups)))
    start=time.monotonic()
    print('START final original affected entry',len(groups),'groups/SHARDS2; frozen',before['count'],'files',flush=True)
    with (OUT/'entry.log').open('xb') as log:r=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    write(OUT/'process.json',dict(exit_code=r.returncode,seconds=time.monotonic()-start,entry_log_sha256=sha(OUT/'entry.log')))
    after=snapshot();write(OUT/'source-after.json',after)
    errors=[]
    for path in sorted((OUT/'logs').glob('shard_*.log')):
        text=path.read_text(encoding='utf8',errors='replace')
        errors.extend(dict(file=path.name,line=line) for line in text.splitlines() if re.search('SCRIPT ERROR|Parse Error',line))
    write(OUT/'source-gate.json',dict(count_before=before['count'],count_after=after['count'],all_files_exact=before==after,SCRIPT_or_Parse_errors=errors,original_entry_exit=r.returncode,overall_accepted=before==after and not errors and r.returncode==0))
    assert before==after and not errors and r.returncode==0
    print('DONE original affected entry; sources exact; exit0; no SCRIPT errors',flush=True)
if __name__=='__main__':main()
