import hashlib,importlib.util,json,os,re,subprocess
from pathlib import Path
ROOT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
P=Path(__file__).resolve().parent/'hint-source-copy-v1';P.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('scope',ROOT/'work/st13-run-catalog-v1/run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
before=s.snapshot();s.write(P/'before.json',before)
leaf=ROOT/'work/st13-hint-fix-v1'
originals=P/'producer-originals';originals.mkdir()
for src in leaf.iterdir():
    if src.is_file():(originals/src.name).write_bytes(src.read_bytes())
results=[]
for condition in ['old','fixed']:
    folder=P/condition;folder.mkdir();env=os.environ.copy()
    for k in s.ENV:
        target=folder/'user'/k;target.mkdir(parents=True);env[k]=str(target)
    command=[s.GODOT,'--headless','--path',str(ROOT),'--audio-driver','Dummy','--quit-after','12000','res://work/st13-hint-fix-v1/control.tscn','--','--condition='+condition,'--out='+str(folder/'checks.json')]
    with (folder/'process.log').open('xb') as log:r=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=40)
    text=(folder/'process.log').read_text(encoding='utf8');diag=[l for l in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|Parse Error|ObjectDB.*leak|were leaked|resources still in use',l)]
    s.write(folder/'process.json',dict(command=command,exit_code=r.returncode,diagnostics=diag))
    assert not diag and r.returncode==(1 if condition=='old' else 0),(condition,r.returncode,diag)
    result=json.loads((folder/'checks.json').read_text(encoding='utf8'));results.append(result)
after=s.snapshot();s.write(P/'after.json',after);assert before==after
s.write(P/'summary.json',dict(classification='RAM source-copy CPU cause control only; eight frozen actual product/test sources remain untouched; not adopted Main or native acceptance',source_fixed=True,results=results))
print(results)
