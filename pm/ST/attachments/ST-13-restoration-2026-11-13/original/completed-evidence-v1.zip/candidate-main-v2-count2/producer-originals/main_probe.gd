extends Node
## Real Main retry observer. Synthetic public input; real time and IO; no skip or time/FPS changes.
const AREA="res://data/levels/ch1_booth_alley.tres"
const CLINIC=&"ch1_c09_wake"
var _out:=""
var _count:=2
var _level:Level
var _started:=[]
var _finished:=[]
var _health_zero_usec:=-1
var _hit_usec:=-1
var _screen_usec:=-1
var _result:={}
var _entry_only:=false
var _main:Node
var _refuse:=false
var _source_level_id:=0
var _load_events:=[]

func _on_started(id:StringName,mode:StringName)->void:_started.append({"id":str(id),"mode":str(mode),"usec":Time.get_ticks_usec()})
func _on_finished(id:StringName)->void:_finished.append({"id":str(id),"usec":Time.get_ticks_usec()})
func _on_child_entered(child:Node)->void:
	if child is DeathScreen and _screen_usec<0:_screen_usec=Time.get_ticks_usec()
func _on_health_changed(current:int,_max:int)->void:
	if current==0 and _health_zero_usec<0:_health_zero_usec=Time.get_ticks_usec()
func _entry_finished(id:StringName)->bool:
	for row:Dictionary in _finished:
		if row.id==String(id):return true
	return false

func _ready()->void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):_out=arg.trim_prefix("--out=")
		elif arg.begins_with("--count="):_count=int(arg.trim_prefix("--count="))
		elif arg=="--entry-observe-only":_entry_only=true
		elif arg=="--refuse-write":_refuse=true
	call_deferred("_run")

func _clock()->Dictionary:
	return {"ticks_usec":Time.get_ticks_usec(),"time_scale":Engine.time_scale,"max_fps":Engine.max_fps,"physics_ticks_per_second":Engine.physics_ticks_per_second,"tree_paused":get_tree().paused,"story_auto_skip":Story.auto_skip,"display_server":DisplayServer.get_name(),"process_frames":Engine.get_process_frames(),"physics_frames":Engine.get_physics_frames(),"observed_fps":Engine.get_frames_per_second()}

func _run()->void:
	assert(_out.is_absolute_path() and _count in [2,3])
	Story.scene_started.connect(_on_started)
	Story.scene_finished.connect(_on_finished)
	var env:={}
	for name in ["APPDATA","LOCALAPPDATA","USERPROFILE","XDG_DATA_HOME","XDG_CONFIG_HOME"]:env[name]=OS.get_environment(name)
	_result={"classification":"Real Main/Level/Health natural-clock; explicit prior clinic/checkpoint fixture, public synthetic retry/move input, actual destination writer","target_count":_count,"environment":env,"godot":Engine.get_version_info(),"user_data_dir":OS.get_user_data_dir(),"startup_clock":_clock(),"native_rendering_or_screenshots":false}
	_main=load("res://game/main.gd").new()
	get_tree().root.add_child(_main)
	await get_tree().process_frame
	while Transition.is_active() or is_instance_valid(_main._pending_screen):await get_tree().process_frame
	_result.transition_fixture={"original_headless_instant":Transition.instant,"enabled_original_timed_transition":true}
	Transition.instant=false
	GameState.start_new_run(load("res://data/difficulty/standard.tres") as DifficultyData)
	for i in _count-1:GameState.register_death()
	GameState.set_flag(&"ch1_first_death_done",true)
	GameState.set_flag(&"ch1_recording_heard",true)
	# A previously registered ordinary-death checkpoint also heard its first-use
	# important recording. Otherwise set_checkpoint itself opens a frozen tutorial.
	Story.restore_progress([String(CLINIC),"ch1_t_booth_recording"],"explicit prior-clinic/registered-booth fixture")
	Progression.credits=1000
	var data:=load(AREA) as LevelData
	var checkpoints:=LevelBuilder.parse(data).checkpoints
	assert(not checkpoints.is_empty())
	GameState.current_level_path=AREA
	GameState.set_checkpoint(checkpoints[0],{}, {},Progression.snapshot())
	var expected:=Story.respawn_scene_ids(data.chapter)
	_result.fixture={"prior_deaths":_count-1,"clinic_completion_flag":true,"completed_story_records":[String(CLINIC),"ch1_t_booth_recording"],"recording_heard_flag":true,"prior_recording_not_played_in_probe":true,"clinic_not_played_in_probe":true,"registered_checkpoint_area":AREA,"registered_checkpoint_position":[checkpoints[0].x,checkpoints[0].y],"credits":1000,"difficulty":String(GameState.difficulty.id),"expected_entry_radio_ids":expected}
	_main._active_run=true
	_main._level_path=AREA
	_main._load_level()
	while not _main._screen is Level or Transition.is_active():await get_tree().process_frame
	_level=_main._screen as Level
	_source_level_id=_level.get_instance_id()
	_level.child_entered_tree.connect(_on_child_entered)
	var spawn_usec:=Time.get_ticks_usec()
	while true:
		await get_tree().process_frame
		var complete:=true
		for id in expected:
			if not _entry_finished(id):complete=false
		var quiet:=not Story.is_cinematic_active() and not DialogueLayer.radio_visible() and not GameplayLock.is_locked() and not get_tree().paused
		if complete and quiet and _level.is_initialized():break
		if _entry_only and Time.get_ticks_usec()-spawn_usec>8000000:
			_result.prerequisite_error="Entry-only diagnostic; no lethal hit attempted"
			_finish.call_deferred(2);return
		if Time.get_ticks_usec()-spawn_usec>45000000:
			_result.prerequisite_error="Entry radio did not naturally settle; no lethal measurement"
			_finish.call_deferred(2);return
	assert(_level.get_parent()==_main and _main.get_parent()==get_tree().root and _level.process_mode==Node.PROCESS_MODE_INHERIT and _main.process_mode==Node.PROCESS_MODE_INHERIT)
	assert(not _level.player.health.is_dead and Story.auto_skip==false)
	_result.entry_settled={"elapsed_msec":float(Time.get_ticks_usec()-spawn_usec)/1000.0,"started":_started.duplicate(true),"finished":_finished.duplicate(true),"clock":_clock(),"level_process_mode":_level.process_mode}
	_level.player.health.health_changed.connect(_on_health_changed)
	var lethal:=DamageInfo.create(9999,Combat.Team.ENEMY,&"grunt_shot")
	lethal.ignore_invulnerability=true
	_hit_usec=Time.get_ticks_usec()
	var accepted:=_level.player.health.take_damage(lethal)
	assert(accepted and _level.player.health.is_dead and _level.died and GameState.deaths==_count)
	var deltas:=[]
	var scales:=[]
	var phases:=[]
	var previous_step:=-999
	var screen:DeathScreen
	while true:
		await get_tree().process_frame
		deltas.append(get_process_delta_time())
		scales.append(Engine.time_scale)
		for child in _level.get_children():
			if child is DeathScreen:screen=child
		if is_instance_valid(screen):
			if previous_step!=screen.sequence_index:
				phases.append({"step":screen.sequence_index,"usec":Time.get_ticks_usec(),"left":screen._sequence_left,"complete":screen.sequence_complete})
				previous_step=screen.sequence_index
			var retry:Button=screen._sequence_buttons.get_child(0) as Button if is_instance_valid(screen._sequence_buttons) else null
			if is_instance_valid(retry) and retry.is_visible_in_tree() and not retry.disabled and retry.can_process() and retry.has_focus() and retry.get_global_rect().has_area():
				var end_usec:=Time.get_ticks_usec()
				var nominal:=0.0
				for step:Dictionary in screen.sequence.steps:nominal+=clampf(float(step.get("time",.6)),0,3)
				_result.measurement={"hit_usec":_hit_usec,"health_zero_usec":_health_zero_usec,"screen_entered_tree_usec":_screen_usec,"retry_visible_enabled_focus_usec":end_usec,"hit_to_retry_msec":float(end_usec-_hit_usec)/1000.0,"zero_to_retry_msec":float(end_usec-_health_zero_usec)/1000.0,"hit_to_screen_msec":float(_screen_usec-_hit_usec)/1000.0,"screen_to_retry_msec":float(end_usec-_screen_usec)/1000.0,"original_Level_delay_seconds":Level.DEATH_SCREEN_DELAY,"selected_sequence":screen.sequence,"sequence_nominal_seconds":nominal,"sequence_phases":phases,"sequence_complete_at_UI_available":screen.sequence_complete,"raw_process_deltas":deltas,"raw_time_scales":scales,"end_clock":_clock(),"retry_state":{"visible_in_tree":retry.is_visible_in_tree(),"disabled":retry.disabled,"can_process":retry.can_process(),"has_focus":retry.has_focus(),"rect":[retry.get_global_rect().position.x,retry.get_global_rect().position.y,retry.size.x,retry.size.y]},"Main_save_owner_present":false,"retry_not_activated":true,"ST13_le_3000msec":end_usec-_health_zero_usec<=3000000,"scope":"UI availability only; full return-to-control duration is at least this long; no actual retry/route/persistence proof"}
				_result.measurement.Main_save_owner_present=true
				_result.measurement.retry_not_activated=false
				_result.measurement.applied_Level_delay_seconds=Level.ORDINARY_DEATH_SCREEN_DELAY
				_result.measurement.scope="UI endpoint only; subsequent Main control endpoint separately measured"
				await _retry_to_control()
				return
		if Time.get_ticks_usec()-_hit_usec>20000000:
			_result.prerequisite_error="No naturally available retry after lethal hit within20seconds"
			_finish.call_deferred(2);return

func _finish(code:int)->void:
	_result.audio_shutdown={"begin_usec":Time.get_ticks_usec(),"after_measurement_only":_result.has("measurement")}
	AudioRelease.begin_shutdown()
	_result.entry_observation_at_exit={"started":_started.duplicate(true),"finished":_finished.duplicate(true),"current_cinematic":String(Story._current_cinematic),"passive_requests":Story._passive_requests.duplicate(true),"radio_active":Story._layer._radio_active,"radio_queue_count":Story._layer._radio_queue.size(),"radio_visible":DialogueLayer.radio_visible(),"tree_paused":get_tree().paused,"gameplay_locked":GameplayLock.is_locked(),"respawn_pending":GameState.respawn_pending,"deaths":GameState.deaths,"level_initialized":is_instance_valid(_level) and _level.is_initialized()}
	Story.reset_active_presentation(&"st13_probe_cleanup_after_observation")
	Story.scene_started.disconnect(_on_started)
	Story.scene_finished.disconnect(_on_finished)
	if is_instance_valid(_main):
		_main.queue_free()
		await _main.tree_exited
		_main=null
		_level=null
	# Only AFTER the endpoint is frozen: let existing retirement/preload owners
	# finish their real callbacks, rather than quitting two frames before the
	# TextureRelease three-frame request has naturally disconnected.
	var cleanup_start:=Time.get_ticks_usec()
	var cleanup_frames:=0
	while true:
		await get_tree().process_frame
		cleanup_frames+=1
		var prefetch:=AssetPrefetch.stats()
		if TextureRelease._pending<0 and int(prefetch.queued)==0 and int(prefetch.inflight)==0:
			_result.cleanup={"frames_after_world_retired":cleanup_frames,"msec":float(Time.get_ticks_usec()-cleanup_start)/1000.0,"TextureRelease_pending":TextureRelease._pending,"prefetch":prefetch,"after_measurement_only":true}
			break
		if Time.get_ticks_usec()-cleanup_start>10000000:
			_result.cleanup_error="Existing resource owners did not naturally retire in10seconds"
			code=2
			break
	var audio_start:=Time.get_ticks_usec()
	await AudioRelease.settle(get_tree())
	_result.audio_shutdown.settle_msec=float(Time.get_ticks_usec()-audio_start)/1000.0
	_result.audio_shutdown.end_usec=Time.get_ticks_usec()
	_result.audio_shutdown.allows_playback_after=AudioRelease.allows_playback()
	_result.end_after_cleanup=_clock()
	_result.expected_exit=code
	var file:=FileAccess.open(_out,FileAccess.WRITE)
	file.store_string(JSON.stringify(_result,"\t"));file.close()
	print("ST13_NATURAL_CLOCK exit=",code," measurement=",_result.has("measurement"))
	get_tree().quit.call_deferred(code)

func _send(action:StringName,pressed:bool)->void:
	var event:=InputEventAction.new()
	event.action=action;event.pressed=pressed
	Input.parse_input_event(event)

func _accept()->void:
	_send(&"ui_accept",true)
	await get_tree().process_frame
	_send(&"ui_accept",false)

func _retry_to_control()->void:
	var primary:=PackedByteArray()
	var backup:=PackedByteArray()
	var deaths_before:=GameState.deaths
	var credits_before:=Progression.credits
	var store:RunSaveStore=_main._run_store
	if _refuse:
		# First drain original death autosaves; block only the owned route writer.
		while _main._save_queued or _main._runtime_save_queued:await get_tree().process_frame
		primary=FileAccess.get_file_as_bytes(store.path)
		backup=FileAccess.get_file_as_bytes(store.path+".bak")
		assert(not primary.is_empty())
		assert(DirAccess.make_dir_absolute(store.path+".tmp")==OK)
	var accept_usec:=Time.get_ticks_usec()
	_result.retry_input={"usec":accept_usec,"action":"ui_accept","synthetic":true,"direct_handler_call":false}
	await _accept()
	if _refuse:
		var wait_start:=Time.get_ticks_usec()
		while not is_instance_valid(_main._destination_save_prompt):
			await get_tree().process_frame
			if Time.get_ticks_usec()-wait_start>5000000:
				_result.prerequisite_error="Real rejected writer did not display its original prompt"
				_finish.call_deferred(2);return
		var prompt:Control=_main._destination_save_prompt
		while not prompt.retry_button.has_focus():await get_tree().process_frame
		_result.refusal={"real_tmp_directory":true,"same_dead_Level":_main._screen==_level and _level.died,"source_Level_id":_source_level_id,"retry_only":not prompt.can_stay and not prompt.cancel_button.visible,"purpose":prompt.purpose,"primary_exact":FileAccess.get_file_as_bytes(store.path)==primary,"backup_exact":FileAccess.get_file_as_bytes(store.path+".bak")==backup,"deaths_exact":GameState.deaths==deaths_before,"credits_exact":Progression.credits==credits_before,"writer_issues":store.issues.duplicate(),"clock":_clock()}
		assert(_result.refusal.same_dead_Level and _result.refusal.retry_only and _result.refusal.primary_exact and _result.refusal.backup_exact and _result.refusal.deaths_exact and _result.refusal.credits_exact)
		assert(DirAccess.remove_absolute(store.path+".tmp")==OK)
		_result.refusal.repair_accept_usec=Time.get_ticks_usec()
		await _accept()
	var last_level_id:=_source_level_id
	var move_start:=Vector2.ZERO
	var move_pressed:=false
	var movement_usec:=-1
	var observed=[]
	while true:
		await get_tree().process_frame
		var level:Level=_main._screen as Level if _main._screen is Level else null
		if is_instance_valid(level) and level.get_instance_id()!=last_level_id:
			_load_events.append({"Level_id":level.get_instance_id(),"usec":Time.get_ticks_usec()})
			last_level_id=level.get_instance_id()
		observed.append({"usec":Time.get_ticks_usec(),"delta":get_process_delta_time(),"time_scale":Engine.time_scale,"transition":Transition.is_active(),"paused":get_tree().paused,"locked":GameplayLock.is_locked()})
		if is_instance_valid(level) and level.get_instance_id()!=_source_level_id and level.is_initialized() and not level.player.health.is_dead and not Transition.is_active() and not GameplayLock.is_locked() and not get_tree().paused:
			if not move_pressed:
				move_start=level.player.position
				_send(&"move_right",true);move_pressed=true
			elif level.player.position.x>move_start.x:
				movement_usec=Time.get_ticks_usec()
				_send(&"move_right",false)
				_result.control={"first_movement_usec":movement_usec,"zero_to_control_msec":float(movement_usec-_health_zero_usec)/1000.0,"retry_to_control_msec":float(movement_usec-accept_usec)/1000.0,"start":[move_start.x,move_start.y],"end":[level.player.position.x,level.player.position.y],"new_Level_id":level.get_instance_id(),"source_Level_id":_source_level_id,"new_Player_id":level.player.get_instance_id(),"load_events":_load_events,"public_action":"move_right","synthetic":true,"deaths_exact":GameState.deaths==deaths_before,"credits_exact":Progression.credits==credits_before,"saved_level":store.read().get("level"),"observed_frames":observed,"clock":_clock(),"ST13_le_3000msec":movement_usec-_health_zero_usec<=3000000}
				_level=level
				assert(_load_events.size()==1 and GameState.deaths==deaths_before and Progression.credits==credits_before)
				_finish.call_deferred(0 if _refuse or _result.control.ST13_le_3000msec else 1);return
		if Time.get_ticks_usec()-accept_usec>15000000:
			_send(&"move_right",false)
			_result.prerequisite_error="Main did not restore an actually movable new Player within15seconds"
			_result.control_observation=observed
			_finish.call_deferred(2);return
