import importlib.util,json,os,re,subprocess,time
from pathlib import Path
ROOT=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
P=Path(__file__).resolve().parent/'readiness-headless-v1';P.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('scope',ROOT/'work/st13-run-catalog-v1/run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.write(P/'before.json',s.snapshot())
env=os.environ.copy()
for k in s.ENV:
    t=P/'user'/k;t.mkdir(parents=True);env[k]=str(t)
command=[s.GODOT,'--headless','--path',str(ROOT),'--audio-driver','Dummy','--quit-after','12000','res://work/st13-readiness-v1/probe.tscn','--','--out='+str(P/'measurement.json')]
with (P/'process.log').open('xb') as log:r=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=40)
text=(P/'process.log').read_text(encoding='utf8');diag=[l for l in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|Parse Error|ObjectDB.*leak|were leaked|resources still in use',l)]
s.write(P/'process.json',dict(command=command,exit_code=r.returncode,diagnostics=diag));s.write(P/'after.json',s.snapshot())
assert not diag and r.returncode==0
print((P/'measurement.json').read_text(encoding='utf8'))
