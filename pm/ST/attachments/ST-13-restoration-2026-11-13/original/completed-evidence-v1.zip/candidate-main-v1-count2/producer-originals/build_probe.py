"""Create separate Main observer from the frozen standalone baseline, never overwrite it."""
from pathlib import Path
P=Path(__file__).resolve().parent
base=(P.parent/'st13-restoration-clock-v1/probe.gd').read_text(encoding='utf8')
base=base.replace('## Read-only natural-clock counterexample. No input, skip, pause or time/FPS writes.','## Real Main retry observer. Synthetic public input; real time and IO; no skip or time/FPS changes.')
base=base.replace('var _entry_only:=false','var _entry_only:=false\nvar _main:Node\nvar _refuse:=false\nvar _source_level_id:=0\nvar _load_events:=[]')
base=base.replace('elif arg=="--entry-observe-only":_entry_only=true','elif arg=="--entry-observe-only":_entry_only=true\n\t\telif arg=="--refuse-write":_refuse=true')
base=base.replace('"Standalone real Level/Health natural-clock diagnostic; fixture prior deaths/clinic, not a Main persistence or interactive retry walkthrough"','"Real Main/Level/Health natural-clock; explicit prior clinic/checkpoint fixture, public synthetic retry/move input, actual destination writer"')
needle='\tGameState.start_new_run('
base=base.replace(needle,'\t_main=load("res://game/main.gd").new()\n\tget_tree().root.add_child(_main)\n\tawait get_tree().process_frame\n\twhile Transition.is_active() or is_instance_valid(_main._pending_screen):await get_tree().process_frame\n\t_result.transition_fixture={"original_headless_instant":Transition.instant,"enabled_original_timed_transition":true}\n\tTransition.instant=false\n'+needle,1)
a=base.index('\t_level=Level.new()');b=base.index('\tvar spawn_usec',a)
base=base[:a]+'''\t_main._active_run=true
\t_main._level_path=AREA
\t_main._load_level()
\twhile not _main._screen is Level or Transition.is_active():await get_tree().process_frame
\t_level=_main._screen as Level
\t_source_level_id=_level.get_instance_id()
\t_level.child_entered_tree.connect(_on_child_entered)
'''+base[b:]
start=base.index('\t\t\t\t_finish.call_deferred(0 if bool(_result.measurement.ST13_le_3000msec) else 1);return')
end=start+len('\t\t\t\t_finish.call_deferred(0 if bool(_result.measurement.ST13_le_3000msec) else 1);return')
base=base[:start]+'''\t\t\t\t_result.measurement.Main_save_owner_present=true
\t\t\t\t_result.measurement.retry_not_activated=false
\t\t\t\t_result.measurement.applied_Level_delay_seconds=Level.ORDINARY_DEATH_SCREEN_DELAY
\t\t\t\t_result.measurement.scope="UI endpoint only; subsequent Main control endpoint separately measured"
\t\t\t\tawait _retry_to_control()
\t\t\t\treturn'''+base[end:]
cleanup='''\tif is_instance_valid(_level):
\t\t_level.queue_free()
\t\tawait _level.tree_exited
\t\t_level=null'''
assert cleanup in base
base=base.replace(cleanup,'''\tif is_instance_valid(_main):
\t\t_main.queue_free()
\t\tawait _main.tree_exited
\t\t_main=null
\t\t_level=null''')
base+='''
func _send(action:StringName,pressed:bool)->void:
\tvar event:=InputEventAction.new()
\tevent.action=action;event.pressed=pressed
\tInput.parse_input_event(event)

func _accept()->void:
\t_send(&"ui_accept",true)
\tawait get_tree().process_frame
\t_send(&"ui_accept",false)

func _retry_to_control()->void:
\tvar primary:=PackedByteArray()
\tvar backup:=PackedByteArray()
\tvar deaths_before:=GameState.deaths
\tvar credits_before:=Progression.credits
\tvar store:RunSaveStore=_main._run_store
\tif _refuse:
\t\t# First drain original death autosaves; block only the owned route writer.
\t\twhile _main._save_queued or _main._runtime_save_queued:await get_tree().process_frame
\t\tprimary=FileAccess.get_file_as_bytes(store.path)
\t\tbackup=FileAccess.get_file_as_bytes(store.path+".bak")
\t\tassert(not primary.is_empty())
\t\tassert(DirAccess.make_dir_absolute(store.path+".tmp")==OK)
\tvar accept_usec:=Time.get_ticks_usec()
\t_result.retry_input={"usec":accept_usec,"action":"ui_accept","synthetic":true,"direct_handler_call":false}
\tawait _accept()
\tif _refuse:
\t\tvar wait_start:=Time.get_ticks_usec()
\t\twhile not is_instance_valid(_main._destination_save_prompt):
\t\t\tawait get_tree().process_frame
\t\t\tif Time.get_ticks_usec()-wait_start>5000000:
\t\t\t\t_result.prerequisite_error="Real rejected writer did not display its original prompt"
\t\t\t\t_finish.call_deferred(2);return
\t\tvar prompt:Control=_main._destination_save_prompt
\t\twhile not prompt.retry_button.has_focus():await get_tree().process_frame
\t\t_result.refusal={"real_tmp_directory":true,"same_dead_Level":_main._screen==_level and _level.died,"source_Level_id":_source_level_id,"retry_only":not prompt.can_stay and not prompt.cancel_button.visible,"purpose":prompt.purpose,"primary_exact":FileAccess.get_file_as_bytes(store.path)==primary,"backup_exact":FileAccess.get_file_as_bytes(store.path+".bak")==backup,"deaths_exact":GameState.deaths==deaths_before,"credits_exact":Progression.credits==credits_before,"writer_issues":store.issues.duplicate(),"clock":_clock()}
\t\tassert(_result.refusal.same_dead_Level and _result.refusal.retry_only and _result.refusal.primary_exact and _result.refusal.backup_exact and _result.refusal.deaths_exact and _result.refusal.credits_exact)
\t\tassert(DirAccess.remove_absolute(store.path+".tmp")==OK)
\t\t_result.refusal.repair_accept_usec=Time.get_ticks_usec()
\t\tawait _accept()
\tvar last_level_id:=_source_level_id
\tvar move_start:=Vector2.ZERO
\tvar move_pressed:=false
\tvar movement_usec:=-1
\tvar observed=[]
\twhile true:
\t\tawait get_tree().process_frame
\t\tvar level:Level=_main._screen as Level if _main._screen is Level else null
\t\tif is_instance_valid(level) and level.get_instance_id()!=last_level_id:
\t\t\t_load_events.append({"Level_id":level.get_instance_id(),"usec":Time.get_ticks_usec()})
\t\t\tlast_level_id=level.get_instance_id()
\t\tobserved.append({"usec":Time.get_ticks_usec(),"delta":get_process_delta_time(),"time_scale":Engine.time_scale,"transition":Transition.is_active(),"paused":get_tree().paused,"locked":GameplayLock.is_locked()})
\t\tif is_instance_valid(level) and level.get_instance_id()!=_source_level_id and level.is_initialized() and not level.player.health.is_dead and not Transition.is_active() and not GameplayLock.is_locked() and not get_tree().paused:
\t\t\tif not move_pressed:
\t\t\t\tmove_start=level.player.position
\t\t\t\t_send(&"move_right",true);move_pressed=true
\t\t\telif level.player.position.x>move_start.x:
\t\t\t\tmovement_usec=Time.get_ticks_usec()
\t\t\t\t_send(&"move_right",false)
\t\t\t\t_result.control={"first_movement_usec":movement_usec,"zero_to_control_msec":float(movement_usec-_health_zero_usec)/1000.0,"retry_to_control_msec":float(movement_usec-accept_usec)/1000.0,"start":[move_start.x,move_start.y],"end":[level.player.position.x,level.player.position.y],"new_Level_id":level.get_instance_id(),"source_Level_id":_source_level_id,"new_Player_id":level.player.get_instance_id(),"load_events":_load_events,"public_action":"move_right","synthetic":true,"deaths_exact":GameState.deaths==deaths_before,"credits_exact":Progression.credits==credits_before,"saved_level":store.read().get("level"),"observed_frames":observed,"clock":_clock(),"ST13_le_3000msec":movement_usec-_health_zero_usec<=3000000}
\t\t\t\t_level=level
\t\t\t\tassert(_load_events.size()==1 and GameState.deaths==deaths_before and Progression.credits==credits_before)
\t\t\t\t_finish.call_deferred(0 if _refuse or _result.control.ST13_le_3000msec else 1);return
\t\tif Time.get_ticks_usec()-accept_usec>15000000:
\t\t\t_send(&"move_right",false)
\t\t\t_result.prerequisite_error="Main did not restore an actually movable new Player within15seconds"
\t\t\t_result.control_observation=observed
\t\t\t_finish.call_deferred(2);return
'''
target=P/'main_probe.gd'
assert not target.exists()
target.write_text(base,encoding='utf8',newline='\n')
(P/'main_probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://work/st13-candidate-v1/main_probe.gd" id="1"]\n\n[node name="ST13MainClock" type="Node"]\nscript = ExtResource("1")\n',encoding='utf8',newline='\n')
