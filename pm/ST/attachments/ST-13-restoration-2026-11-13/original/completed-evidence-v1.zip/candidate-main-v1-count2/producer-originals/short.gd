extends Node
const Suite=preload("res://tests/suite/test_death_flow.gd")
var _checks:=0
var _failures:=[]
var _out:=""
func _ready()->void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):_out=arg.trim_prefix("--out=")
	call_deferred("_run")
func _run()->void:
	var suite=Suite.new(self)
	await suite._test_restoration_brief_actions()
	suite._test_restoration_delay_policy()
	suite=null
	AudioRelease.begin_shutdown()
	await AudioRelease.settle(get_tree())
	var file:=FileAccess.open(_out,FileAccess.WRITE)
	file.store_string(JSON.stringify({"classification":"Synthetic UI timing/focus plus delay-policy regression; not natural Main timing","checks":_checks,"failures":_failures},"\t"));file.close()
	print("ST13_SHORT checks=",_checks," failures=",_failures.size())
	get_tree().quit.call_deferred(0 if _failures.is_empty() else 1)
func _check(ok:bool,message:String)->void:
	_checks+=1
	if not ok:
		_failures.append(message)
		print("FAIL: ",message)
func _frames(count:int)->void:
	for frame in count:await get_tree().process_frame
