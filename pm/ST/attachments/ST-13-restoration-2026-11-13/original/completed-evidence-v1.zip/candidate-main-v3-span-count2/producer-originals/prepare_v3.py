from pathlib import Path
P=Path(__file__).resolve().parent
text=(P/'main_probe.gd').read_text(encoding='utf8')
observer='''
class TimedMain extends "res://game/main.gd":
	var spans:=[]
	func _save_destination(runtime:Dictionary,destination_path:="",state_changes:Dictionary={},progression:Variant=null)->bool:
		var begin:=Time.get_ticks_usec()
		var result:=super._save_destination(runtime,destination_path,state_changes,progression)
		spans.append({"operation":"save_destination","begin_usec":begin,"end_usec":Time.get_ticks_usec(),"accepted":result})
		return result
	func _swap_screen(screen:Node)->void:
		var begin:=Time.get_ticks_usec()
		var kind:=screen.get_class()
		super._swap_screen(screen)
		spans.append({"operation":"swap_screen","begin_usec":begin,"end_usec":Time.get_ticks_usec(),"screen_class":kind})
	func _save_run(route_source:=false)->void:
		var begin:=Time.get_ticks_usec()
		super._save_run(route_source)
		spans.append({"operation":"save_run","begin_usec":begin,"end_usec":Time.get_ticks_usec()})
	func _load_level(kind:=Transition.Kind.IRIS,caption:="",hold:=0.0)->void:
		var begin:=Time.get_ticks_usec()
		super._load_level(kind,caption,hold)
		spans.append({"operation":"load_level_prepare","begin_usec":begin,"end_usec":Time.get_ticks_usec()})
'''
text=text.replace('extends Node\n','extends Node\n'+observer+'\n',1)
text=text.replace('_main=load("res://game/main.gd").new()','_main=TimedMain.new()')
text=text.replace('\t_result.audio_shutdown={','\t_result.Main_original_call_spans=_main.spans.duplicate(true)\n\t_result.audio_shutdown={',1)
target=P/'main_probe_v3.gd';assert not target.exists();target.write_text(text,encoding='utf8',newline='\n')
target=P/'main_probe_v3.tscn';assert not target.exists();target.write_text((P/'main_probe.tscn').read_text().replace('main_probe.gd','main_probe_v3.gd'),encoding='utf8',newline='\n')
target=P/'run_main_v3.py';assert not target.exists();target.write_text((P/'run_main.py').read_text().replace('st13-candidate-v1/main_probe.tscn','st13-candidate-v1/main_probe_v3.tscn'),encoding='utf8',newline='\n')
