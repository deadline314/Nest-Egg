import argparse,hashlib,json,os,re,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent
ROOT=P.parents[1]
PROOF=Path('D:/NestEggVerification/proofs/st13-restoration-clock-20261112')
BASE='5a363c4e29c186661eba364cc2bbee3cee374178'
ENV=['APPDATA','LOCALAPPDATA','USERPROFILE','XDG_DATA_HOME','XDG_CONFIG_HOME']
GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
    assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8',newline='\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).decode('utf8').strip()
def snapshot():
    assert git('rev-parse','HEAD')==BASE
    changed=set(git('diff','--name-only').splitlines())
    assert changed=={'ui/death_screen.gd','game/level/level.gd','tests/suite/test_death_flow.gd'},changed
    assert not git('diff','--cached','--name-only')
    names=git('ls-files','-z').split('\0')
    names=[n for n in names if n and (n=='project.godot' or n.split('/')[0] in ['autoload','core','game','ui','data','scenes','shaders','tools'] and Path(n).suffix in ['.gd','.uid','.tscn','.tres','.json','.gdshader'])]
    return dict(base=BASE,tracked_source_sha256={n:sha(ROOT/n) for n in names},own={str(p.relative_to(ROOT)):sha(p) for p in P.rglob('*') if p.suffix in ['.gd','.tscn','.py']},status=git('status','--short'))
def main(tag,count,refuse):
    out=PROOF/tag;out.mkdir(parents=True,exist_ok=False)
    before=snapshot();write(out/'before.json',before)
    for n in before['own']:
        p=out/'producer-originals'/Path(n).name;p.parent.mkdir(exist_ok=True);p.write_bytes((ROOT/n).read_bytes())
    for n in ['ui/death_screen.gd','game/level/level.gd','tests/suite/test_death_flow.gd','game/main.gd','autoload/transition.gd']:
        p=out/'runtime-originals'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/n).read_bytes())
    env=os.environ.copy();original={k:env.get(k) for k in ENV}
    for k in ENV:
        target=out/'user'/k;target.mkdir(parents=True);env[k]=str(target)
    write(out/'environment.json',dict(original=original,isolated={k:env[k] for k in ENV}))
    cmd=[GODOT,'--headless','--path',str(ROOT),'--audio-driver','Dummy','res://work/st13-candidate-v1/main_probe_v3.tscn','--','--count='+str(count),'--out='+str(out/'measurement.json')]
    if refuse:cmd.append('--refuse-write')
    start=time.monotonic()
    with (out/'process.log').open('xb') as log:
        result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=95)
    text=(out/'process.log').read_text(encoding='utf8',errors='replace')
    diag=[l for l in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|Parse Error|ObjectDB.*leak|were leaked|resources still in use',l)]
    write(out/'process.json',dict(command=cmd,exit_code=result.returncode,seconds=time.monotonic()-start,diagnostics=diag,log_sha256=sha(out/'process.log'),classification='Natural default headless with original timed transition explicitly enabled; no GPU or speed/FPS changes'))
    after=snapshot();write(out/'after.json',after)
    assert before['tracked_source_sha256']==after['tracked_source_sha256'] and before['own']==after['own']
    print(out,'exit',result.returncode,'diag',diag,flush=True)
    if (out/'measurement.json').exists():
        m=json.loads((out/'measurement.json').read_text());print(json.dumps({k:m.get(k) for k in ['prerequisite_error','control','refusal']},ensure_ascii=False)[:3500],flush=True)
    assert not diag and (out/'measurement.json').exists()
    return result.returncode
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--tag',required=True);a.add_argument('--count',type=int,required=True,choices=[2,3]);a.add_argument('--refuse',action='store_true');v=a.parse_args();raise SystemExit(main(v.tag,v.count,v.refuse))
