extends Node
## Read-only natural-clock counterexample. No input, skip, pause or time/FPS writes.
const AREA="res://data/levels/ch1_booth_alley.tres"
const CLINIC=&"ch1_c09_wake"
var _out:=""
var _count:=2
var _level:Level
var _started:=[]
var _finished:=[]
var _health_zero_usec:=-1
var _hit_usec:=-1
var _screen_usec:=-1
var _result:={}

func _ready()->void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):_out=arg.trim_prefix("--out=")
		elif arg.begins_with("--count="):_count=int(arg.trim_prefix("--count="))
	call_deferred("_run")

func _clock()->Dictionary:
	return {"ticks_usec":Time.get_ticks_usec(),"time_scale":Engine.time_scale,"max_fps":Engine.max_fps,"physics_ticks_per_second":Engine.physics_ticks_per_second,"tree_paused":get_tree().paused,"story_auto_skip":Story.auto_skip,"display_server":DisplayServer.get_name(),"process_frames":Engine.get_process_frames(),"physics_frames":Engine.get_physics_frames(),"observed_fps":Engine.get_frames_per_second()}

func _run()->void:
	assert(_out.is_absolute_path() and _count in [2,3])
	Story.scene_started.connect(func(id:StringName,mode:StringName)->void:_started.append({"id":str(id),"mode":str(mode),"usec":Time.get_ticks_usec()}))
	Story.scene_finished.connect(func(id:StringName)->void:_finished.append({"id":str(id),"usec":Time.get_ticks_usec()}))
	var env:={}
	for name in ["APPDATA","LOCALAPPDATA","USERPROFILE","XDG_DATA_HOME","XDG_CONFIG_HOME"]:env[name]=OS.get_environment(name)
	_result={"classification":"Standalone real Level/Health natural-clock diagnostic; fixture prior deaths/clinic, not a Main persistence or interactive retry walkthrough","target_count":_count,"environment":env,"godot":Engine.get_version_info(),"user_data_dir":OS.get_user_data_dir(),"startup_clock":_clock(),"native_rendering_or_screenshots":false}
	GameState.start_new_run(load("res://data/difficulty/standard.tres") as DifficultyData)
	for i in _count-1:GameState.register_death()
	GameState.set_flag(&"ch1_first_death_done",true)
	Story.restore_progress([String(CLINIC)],"explicit prior-clinic fixture")
	Progression.credits=1000
	var data:=load(AREA) as LevelData
	var checkpoints:=LevelBuilder.parse(data).checkpoints
	assert(not checkpoints.is_empty())
	GameState.current_level_path=AREA
	GameState.set_checkpoint(checkpoints[0],{}, {},Progression.snapshot())
	var expected:=Story.respawn_scene_ids(data.chapter)
	_result.fixture={"prior_deaths":_count-1,"clinic_completion_flag":true,"completed_story_record":String(CLINIC),"clinic_not_played_in_probe":true,"registered_checkpoint_area":AREA,"registered_checkpoint_position":[checkpoints[0].x,checkpoints[0].y],"credits":1000,"difficulty":String(GameState.difficulty.id),"expected_entry_radio_ids":expected}
	_level=Level.new()
	_level.configure(data)
	_level.child_entered_tree.connect(func(child:Node)->void:
		if child is DeathScreen and _screen_usec<0:_screen_usec=Time.get_ticks_usec())
	# Sibling of the ALWAYS observer; Level keeps its original inherited pausable mode.
	get_tree().root.add_child(_level)
	var spawn_usec:=Time.get_ticks_usec()
	while true:
		await get_tree().process_frame
		var complete:=true
		for id in expected:
			if not _finished.any(func(row:Dictionary)->bool:return row.id==String(id)):complete=false
		var quiet:=not Story.is_cinematic_active() and not DialogueLayer.radio_visible() and not GameplayLock.is_locked() and not get_tree().paused
		if complete and quiet and _level.is_initialized():break
		if Time.get_ticks_usec()-spawn_usec>45000000:
			_result.prerequisite_error="Entry radio did not naturally settle; no lethal measurement"
			await _finish(2);return
	assert(_level.get_parent()==get_tree().root and _level.process_mode==Node.PROCESS_MODE_INHERIT)
	assert(not _level.player.health.is_dead and Story.auto_skip==false)
	_result.entry_settled={"elapsed_msec":float(Time.get_ticks_usec()-spawn_usec)/1000.0,"started":_started.duplicate(true),"finished":_finished.duplicate(true),"clock":_clock(),"level_process_mode":_level.process_mode}
	_level.player.health.health_changed.connect(func(current:int,_max:int)->void:
		if current==0 and _health_zero_usec<0:_health_zero_usec=Time.get_ticks_usec())
	var lethal:=DamageInfo.create(9999,Combat.Team.ENEMY,&"grunt_shot")
	lethal.ignore_invulnerability=true
	_hit_usec=Time.get_ticks_usec()
	var accepted:=_level.player.health.take_damage(lethal)
	assert(accepted and _level.player.health.is_dead and _level.died and GameState.deaths==_count)
	var deltas:=[]
	var scales:=[]
	var phases:=[]
	var previous_step:=-999
	var screen:DeathScreen
	while true:
		await get_tree().process_frame
		deltas.append(get_process_delta_time())
		scales.append(Engine.time_scale)
		for child in _level.get_children():
			if child is DeathScreen:screen=child
		if is_instance_valid(screen):
			if previous_step!=screen.sequence_index:
				phases.append({"step":screen.sequence_index,"usec":Time.get_ticks_usec(),"left":screen._sequence_left,"complete":screen.sequence_complete})
				previous_step=screen.sequence_index
			var retry:Button=screen._sequence_buttons.get_child(0) as Button if is_instance_valid(screen._sequence_buttons) else null
			if screen.sequence_complete and is_instance_valid(retry) and retry.is_visible_in_tree() and not retry.disabled and retry.can_process() and retry.has_focus() and retry.get_global_rect().has_area():
				var end_usec:=Time.get_ticks_usec()
				var nominal:=0.0
				for step:Dictionary in screen.sequence.steps:nominal+=clampf(float(step.get("time",.6)),0,3)
				_result.measurement={"hit_usec":_hit_usec,"health_zero_usec":_health_zero_usec,"screen_entered_tree_usec":_screen_usec,"retry_visible_enabled_focus_usec":end_usec,"hit_to_retry_msec":float(end_usec-_hit_usec)/1000.0,"zero_to_retry_msec":float(end_usec-_health_zero_usec)/1000.0,"hit_to_screen_msec":float(_screen_usec-_hit_usec)/1000.0,"screen_to_retry_msec":float(end_usec-_screen_usec)/1000.0,"original_Level_delay_seconds":Level.DEATH_SCREEN_DELAY,"selected_sequence":screen.sequence,"sequence_nominal_seconds":nominal,"sequence_phases":phases,"raw_process_deltas":deltas,"raw_time_scales":scales,"end_clock":_clock(),"retry_state":{"visible_in_tree":retry.is_visible_in_tree(),"disabled":retry.disabled,"can_process":retry.can_process(),"has_focus":retry.has_focus(),"rect":[retry.get_global_rect().position.x,retry.get_global_rect().position.y,retry.size.x,retry.size.y]},"Main_save_owner_present":false,"retry_not_activated":true,"ST13_le_3000msec":end_usec-_health_zero_usec<=3000000,"scope":"UI availability only; full return-to-control duration is at least this long; no actual retry/route/persistence proof"}
				await _finish(0 if bool(_result.measurement.ST13_le_3000msec) else 1);return
		if Time.get_ticks_usec()-_hit_usec>20000000:
			_result.prerequisite_error="No naturally available retry after lethal hit within20seconds"
			await _finish(2);return

func _finish(code:int)->void:
	if is_instance_valid(_level):
		_level.queue_free()
		await _level.tree_exited
		_level=null
	await get_tree().process_frame
	await get_tree().process_frame
	_result.end_after_cleanup=_clock()
	_result.expected_exit=code
	var file:=FileAccess.open(_out,FileAccess.WRITE)
	file.store_string(JSON.stringify(_result,"\t"));file.close()
	print("ST13_NATURAL_CLOCK exit=",code," measurement=",_result.has("measurement"))
	get_tree().quit(code)
