extends Node
const Probe=preload("probe.gd")
func _ready()->void:
	var probe=Probe.new()
	assert(probe is Node)
	probe.free()
	print("ST13_PARSE_OK full autoload scene")
	get_tree().quit()
