extends "res://work/st13-candidate-v1/main_probe_v3.gd"
const Capture=preload("res://tools/viewport_capture.gd")
var _images:Array=[]
var _captures:Array=[]
func _run()->void:
	if OS.get_cmdline_user_args().has("--parse-only"):
		AudioRelease.begin_shutdown()
		await AudioRelease.settle(get_tree())
		print("ST13_NATIVE_PARSE_OK complete autoload")
		get_tree().quit.call_deferred(0)
		return
	await super._run()
func _screen()->DeathScreen:
	for child in _level.get_children():
		if child is DeathScreen:return child
	return null
func _fail(reason:String)->void:
	_result.native_error=reason
	_images.clear()
	_finish.call_deferred(2)
func _retry_to_control()->void:
	_result.classification="Forward+ native layout only: original Main/Health fixture, natural voluntary sequence, public synthetic focus navigation; no return-to-control timing acceptance"
	_result.measurement.erase("ST13_le_3000msec")
	_result.measurement.retry_not_activated=true
	_result.measurement.scope="Native layout observation only; headless clock evidence is separate"
	var screen:=_screen()
	if screen==null or screen.sequence_complete:
		_fail("No unfinished ordinary sequence at early actions");return
	if not await _grab(screen,"early-actions"):
		_fail("Unsupported readback or early layout prerequisite; original format metadata/raw retained");return
	_send(&"ui_down",true)
	await get_tree().process_frame
	_send(&"ui_down",false)
	var deadline:=Time.get_ticks_usec()+5000000
	var menu:=screen._sequence_buttons.get_child(1) as Button
	while not menu.has_focus() or str(screen.sequence.steps[screen.sequence_index].get("kind",""))!="card":
		await get_tree().process_frame
		if Time.get_ticks_usec()>deadline or screen.sequence_complete:
			_fail("Public menu focus/card observation did not precede voluntary finish");return
	if not await _grab(screen,"voluntary-card"):
		_fail("Card readback prerequisite rejected");return
	while not screen.sequence_complete:
		await get_tree().process_frame
		if Time.get_ticks_usec()>deadline:
			_fail("Original voluntary sequence failed to finish naturally");return
	if not menu.has_focus():
		_fail("Natural finish stole the publicly selected menu focus");return
	if not await _grab(screen,"natural-finish-menu"):
		_fail("Final layout readback prerequisite rejected");return
	# All original readbacks precede any PNG conversion; no clock claim uses encode time.
	for item:Dictionary in _images:
		var raw_image:Image=item.image
		var record:Dictionary=item.record
		var file:=FileAccess.open(_out.get_base_dir().path_join(record.linear_raw),FileAccess.WRITE)
		file.store_buffer(raw_image.get_data());file.close()
	for item:Dictionary in _images:
		var raw_image:Image=item.image
		var record:Dictionary=item.record
		var encoded:=Capture.encode(raw_image,bool(record.hdr_2d))
		if encoded.save_png(_out.get_base_dir().path_join(record.encoded_png))!=OK:
			_fail("Canonical PNG save failed: "+str(record.encoded_png));return
	_images.clear()
	_result.native={"classification":"Layout only; not natural timing or physical input acceptance","resolution":[1280,720],"captures":_captures,"renderer":RenderingServer.get_current_rendering_method(),"adapter":RenderingServer.get_video_adapter_name(),"all_raw_before_encode":true,"menu_focus_preserved":true}
	_finish.call_deferred(0)
func _grab(screen:DeathScreen,page:String)->bool:
	await RenderingServer.frame_post_draw
	var viewport:=get_viewport()
	var original:=viewport.get_texture().get_image()
	var focus:=viewport.gui_get_focus_owner()
	var record:={"page":page,"size":[original.get_width(),original.get_height()],"format":original.get_format(),"hdr_2d":viewport.use_hdr_2d,"raw_bytes":original.get_data().size(),"mipmaps":original.has_mipmaps(),"linear_raw":page+".raw","encoded_png":page+".png","sequence_index":screen.sequence_index,"sequence_complete":screen.sequence_complete,"sequence_left":screen._sequence_left,"focus_text":focus.text if focus is Button else "","actions_visible":screen._sequence_buttons.is_visible_in_tree(),"hint_visible":screen._hint_slot.is_visible_in_tree(),"clock":_clock()}
	var file:=FileAccess.open(_out.get_base_dir().path_join(page+"-format.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(record,"\t"));file.close()
	# Preserve observed bytes even if the reader's floating-format prerequisite fails.
	if original.get_format() not in [Image.FORMAT_RGBH,Image.FORMAT_RGBAH,Image.FORMAT_RGBF,Image.FORMAT_RGBAF] or original.get_size()!=Vector2i(1280,720):
		file=FileAccess.open(_out.get_base_dir().path_join(record.linear_raw),FileAccess.WRITE)
		file.store_buffer(original.get_data());file.close()
		return false
	_captures.append(record)
	_images.append({"image":original,"record":record})
	return record.actions_visible and record.hint_visible
