extends Node
const Suite=preload("res://tests/suite/test_quest_map.gd")
var _checks:=0
var _failures:=[]
var _out:=""
func _ready()->void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):_out=arg.trim_prefix("--out=")
	call_deferred("_run")
func _run()->void:
	var previous:=Story.auto_skip
	Story.auto_skip=true
	var suite=Suite.new(self)
	suite._test_run_catalog_reuse()
	await suite._test_guidance_catalog_injection()
	suite=null
	Story.auto_skip=previous
	AudioRelease.begin_shutdown()
	Story.reset_active_presentation(&"st13_catalog_control_cleanup")
	while TextureRelease._pending>=0 or AssetPrefetch.stats().inflight>0 or AssetPrefetch.stats().queued>0:await get_tree().process_frame
	await AudioRelease.settle(get_tree())
	var file:=FileAccess.open(_out,FileAccess.WRITE)
	file.store_string(JSON.stringify({"classification":"Controlled per-run catalog/injection regression, not natural Main timing","checks":_checks,"failures":_failures},"\t"));file.close()
	print("ST13_CATALOG_CONTROL checks=",_checks," failures=",_failures.size())
	get_tree().quit.call_deferred(0 if _failures.is_empty() else 1)
func _check(ok:bool,message:String)->void:
	_checks+=1
	if not ok:
		_failures.append(message);print("FAIL: ",message)
func _frames(count:int)->void:
	for frame in count:await get_tree().physics_frame
func _end_level(level:Level)->void:
	for action in [&"move_right",&"shoot",&"jump",&"aim_right",&"aim_left",&"block"]:Input.action_release(action)
	if is_instance_valid(level):
		get_tree().root.remove_child(level);level.free()
	get_tree().paused=false
	Engine.time_scale=1
	await _frames(2)
