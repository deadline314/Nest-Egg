extends "res://work/st13-candidate-v1/main_probe_v3.gd"
const Capture=preload("res://tools/viewport_capture.gd")
var _images:Array=[]
var _captures:Array=[]
func _run()->void:
	if OS.get_cmdline_user_args().has("--parse-only"):
		AudioRelease.begin_shutdown()
		await AudioRelease.settle(get_tree())
		print("ST13_NATIVE_PARSE_OK complete autoload")
		get_tree().quit.call_deferred(0)
		return
	await super._run()
func _screen()->DeathScreen:
	for child in _level.get_children():
		if child is DeathScreen:return child
	return null
func _fail(reason:String)->void:
	_result.native_error=reason
	_export_images()
	_result.native_failure_captures=_captures
	_images.clear()
	_finish.call_deferred(2)
func _retry_to_control()->void:
	_result.classification="Forward+ native layout only: original Main/Health fixture, natural voluntary sequence, public synthetic focus navigation; no return-to-control timing acceptance"
	_result.measurement.erase("ST13_le_3000msec")
	_result.measurement.retry_not_activated=true
	_result.measurement.scope="Native layout observation only; headless clock evidence is separate"
	var screen:=_screen()
	if screen==null or screen.sequence_complete:
		_fail("No unfinished ordinary sequence at early actions");return
	if not await _await_readable(screen,false):
		_fail("Early focus hint did not naturally publish readable text");return
	if not await _grab(screen,"early-actions"):
		_fail("Unsupported readback or early layout prerequisite; original format metadata/raw retained");return
	var direction:=InputEventKey.new()
	direction.keycode=KEY_RIGHT;direction.physical_keycode=KEY_RIGHT;direction.pressed=true
	Input.parse_input_event(direction)
	await get_tree().process_frame
	direction=InputEventKey.new()
	direction.keycode=KEY_RIGHT;direction.physical_keycode=KEY_RIGHT;direction.pressed=false
	Input.parse_input_event(direction)
	var deadline:=Time.get_ticks_usec()+5000000
	var menu:=screen._sequence_buttons.get_child(1) as Button
	while not menu.has_focus() or str(screen.sequence.steps[screen.sequence_index].get("kind",""))!="card":
		await get_tree().process_frame
		if Time.get_ticks_usec()>deadline or screen.sequence_complete:
			_fail("Public menu focus/card observation did not precede voluntary finish");return
	if not await _await_readable(screen,true):
		_fail("Original card reveal did not settle before voluntary finish");return
	if not await _grab(screen,"voluntary-card"):
		_fail("Card readback prerequisite rejected");return
	while not screen.sequence_complete:
		await get_tree().process_frame
		if Time.get_ticks_usec()>deadline:
			_fail("Original voluntary sequence failed to finish naturally");return
	if not menu.has_focus():
		_fail("Natural finish stole the publicly selected menu focus");return
	if not await _await_readable(screen,true):
		_fail("Final menu hint/card readiness failed");return
	if not await _grab(screen,"natural-finish-menu"):
		_fail("Final layout readback prerequisite rejected");return
	# All original readbacks precede any PNG conversion; no clock claim uses encode time.
	if not _export_images():
		_fail("Canonical PNG save failed");return
	_images.clear()
	_result.native={"classification":"Layout only; not natural timing or physical input acceptance","resolution":[1280,720],"captures":_captures,"renderer":RenderingServer.get_current_rendering_method(),"adapter":RenderingServer.get_video_adapter_name(),"all_raw_before_encode":true,"menu_focus_preserved":true}
	_finish.call_deferred(0)
func _export_images()->bool:
	for item:Dictionary in _images:
		var encoded:=Capture.encode(item.image,bool(item.record.hdr_2d))
		if encoded.save_png(_out.get_base_dir().path_join(item.record.encoded_png))!=OK:return false
	return true
func _alpha(item:CanvasItem)->float:
	var value:=1.0
	var cursor:Node=item
	while cursor!=null:
		if cursor is CanvasItem:value*=cursor.modulate.a*cursor.self_modulate.a
		cursor=cursor.get_parent()
	return value
func _readiness(screen:DeathScreen)->Dictionary:
	var hint:=screen._hint_slot.get_child(0) as FocusHintBar
	var focus:=get_viewport().gui_get_focus_owner()
	var hint_ready:=focus is Button and hint.is_visible_in_tree() and not hint.text().is_empty() and hint.text()==focus.tooltip_text and hint._label.size.x>1 and hint._label.size.y>0 and is_equal_approx(_alpha(hint),1.0)
	var card:=screen._sequence_card
	var labels=[]
	var card_ready:=card.is_visible_in_tree() and card.scale.is_equal_approx(Vector2.ONE) and is_equal_approx(_alpha(card),1.0)
	for label:Label in card.find_children("*","Label",true,false):
		if label.text.strip_edges().is_empty():continue
		var shown:=label.is_visible_in_tree() and label.size.x>1 and label.size.y>0
		labels.append({"text":label.text,"visible":shown,"size":[label.size.x,label.size.y]})
		card_ready=card_ready and shown
	return {"hint_ready":hint_ready,"hint_text":hint.text(),"hint_visible":hint.is_visible_in_tree(),"hint_label_size":[hint._label.size.x,hint._label.size.y],"hint_alpha":_alpha(hint),"card_ready":card_ready and not labels.is_empty(),"card_scale":[card.scale.x,card.scale.y],"card_alpha":_alpha(card),"card_labels":labels}
func _await_readable(screen:DeathScreen,card:bool)->bool:
	var stable:=0
	var deadline:=Time.get_ticks_usec()+4000000
	while Time.get_ticks_usec()<deadline:
		await RenderingServer.frame_post_draw
		var state:=_readiness(screen)
		stable=stable+1 if state.hint_ready and (not card or state.card_ready) else 0
		if stable>=3:return true
	return false
func _grab(screen:DeathScreen,page:String)->bool:
	await RenderingServer.frame_post_draw
	var viewport:=get_viewport()
	var original:=viewport.get_texture().get_image()
	var focus:=viewport.gui_get_focus_owner()
	var record:={"page":page,"size":[original.get_width(),original.get_height()],"format":original.get_format(),"hdr_2d":viewport.use_hdr_2d,"raw_bytes":original.get_data().size(),"mipmaps":original.has_mipmaps(),"linear_raw":page+".raw","encoded_png":page+".png","sequence_index":screen.sequence_index,"sequence_complete":screen.sequence_complete,"sequence_left":screen._sequence_left,"focus_text":focus.text if focus is Button else "","actions_visible":screen._sequence_buttons.is_visible_in_tree(),"hint_visible":screen._hint_slot.is_visible_in_tree(),"clock":_clock()}
	record.readiness=_readiness(screen)
	var file:=FileAccess.open(_out.get_base_dir().path_join(page+"-format.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(record,"\t"));file.close()
	file=FileAccess.open(_out.get_base_dir().path_join(record.linear_raw),FileAccess.WRITE)
	file.store_buffer(original.get_data());file.close()
	# Preserve observed bytes even if the reader's floating-format prerequisite fails.
	if original.get_format() not in [Image.FORMAT_RGBH,Image.FORMAT_RGBAH,Image.FORMAT_RGBF,Image.FORMAT_RGBAF] or original.get_size()!=Vector2i(1280,720):
		return false
	_captures.append(record)
	_images.append({"image":original,"record":record})
	return record.actions_visible and record.hint_visible and record.readiness.hint_ready and (page=="natural-finish-menu" or not screen.sequence_complete) and (page=="early-actions" or record.readiness.card_ready)
