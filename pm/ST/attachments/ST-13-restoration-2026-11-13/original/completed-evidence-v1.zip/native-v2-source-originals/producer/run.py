"""Root-authorized layout only; canonical nonblocking lock, no service lifecycle."""
import argparse,hashlib,importlib.util,json,msvcrt,os,re,runpy,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent
ROOT=P.parents[1]
C=Path('C:/Users/stanl/Github/Nest-Egg')
PROOF=Path('D:/NestEggVerification/proofs/st13-restoration-clock-20261112')
GUARD=C/'work/st3-facts-adoption-v1/c-native-context-v23.json'
QUEUE=C/'work/ne267-gait-reach-proposal-20261112/native-gh-v1/run_native.py'
queues=runpy.run_path(str(QUEUE))['queues']
spec=importlib.util.spec_from_file_location('st13scope',ROOT/'work/st13-run-catalog-v1/run.py')
scope=importlib.util.module_from_spec(spec);spec.loader.exec_module(scope)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
    assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8',newline='\n')
def snapshot():
    candidate=json.loads((PROOF/'catalog-delivery-v1/stage-manifest.json').read_text(encoding='utf8'))['files']
    assert all(sha(ROOT/n)==v['sha256'] for n,v in candidate.items())
    expected=json.loads(GUARD.read_text(encoding='utf8'))['files']
    assert len(expected)==393
    actual={n:sha(C/n) for n in expected};assert actual==expected
    assert sha(ROOT/'tools/viewport_capture.gd')==sha(C/'tools/viewport_capture.gd')
    return dict(managed=scope.snapshot(),primary_C=actual,primary_guard_sha256=sha(GUARD),own={str(p):sha(p) for p in P.iterdir() if p.suffix in ['.gd','.py','.tscn']},canonical_capture_sha256=sha(ROOT/'tools/viewport_capture.gd'),queue_helper_sha256=sha(QUEUE))
def process(out,count,parser):
    env=os.environ.copy()
    for k in scope.ENV:
        p=out/'user'/k;p.mkdir(parents=True);env[k]=str(p)
    write(out/'environment.json',{k:env[k] for k in scope.ENV})
    cmd=[scope.GODOT,'--path',str(ROOT),'--audio-driver','Dummy']
    if parser:cmd+=['--headless','--quit-after','1200']
    else:cmd+=['--resolution','1280x720','--rendering-driver','vulkan','--rendering-method','forward_plus','--quit-after','36000']
    cmd+=['res://work/st13-ui-native-v1/capture.tscn','--','--count='+str(count),'--out='+str(out/'measurement.json')]
    if parser:cmd+=['--parse-only']
    start=time.monotonic()
    try:
        with (out/'process.log').open('xb') as log:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
        code=r.returncode
    except subprocess.TimeoutExpired:code='timeout'
    text=(out/'process.log').read_text(encoding='utf8',errors='replace')
    diag=[l for l in text.splitlines() if re.search(r'SCRIPT ERROR|^ERROR:|Parse Error|ObjectDB.*leak|were leaked|resources still in use',l)]
    write(out/'process.json',dict(command=cmd,exit_code=code,seconds=time.monotonic()-start,diagnostics=diag,log_sha256=sha(out/'process.log'),scope='parser only' if parser else 'native layout only, never natural-clock or physical input acceptance'))
    assert code==0 and not diag,(code,diag)
    if parser:assert 'ST13_NATIVE_PARSE_OK' in text
    else:
        x=json.loads((out/'measurement.json').read_text(encoding='utf8'))
        assert x['native']['renderer']=='forward_plus' and len(x['native']['captures'])==3 and x['native']['menu_focus_preserved']
def main(a):
    out=PROOF/a.tag;out.mkdir(exist_ok=False)
    before=snapshot();write(out/'before.json',before)
    if a.parser:
        process(out,a.count,True)
        after=snapshot();write(out/'after.json',after);assert before==after
        print('PARSE_GREEN full autoload, exact sources',flush=True);return 0
    assert a.root_explicit_start,'Preparation is not authorization'
    outside=queues();write(out/'queue-before-lock.json',outside)
    if not outside['clear']:print('WAITING queue, no engine/lock',flush=True);return 2
    sys.path.insert(0,str(C/'tools/comfyui'));import comfy_guard
    assert comfy_guard.LOCK_PATH.resolve()==(C/'assets_src/work/comfy.lock').resolve()
    started=False;failure=None
    with comfy_guard.LOCK_PATH.open('a+b') as lock:
        lock.seek(0)
        try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:print('WAITING primary lock, no engine',flush=True);return 2
        try:
            inside=queues();write(out/'queue-inside-before.json',inside)
            if not inside['clear']:return 2
            assert snapshot()==before
            print('START ST13 layout count'+str(a.count),flush=True);started=True
            try:process(out,a.count,False)
            except Exception as exc:failure=repr(exc)
        finally:
            write(out/'queue-inside-after.json',queues())
            lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)
    write(out/'queue-after-unlock.json',queues())
    after=snapshot();write(out/'after.json',after);assert before==after
    if failure:
        write(out/'failure-receipt.json',dict(error=failure,rejected=True,source_fixed=True,lock_released=True))
        print('DONE rejected native, sources retained and lock released',flush=True);return 1
    assert started and json.loads((out/'queue-inside-after.json').read_text())['clear'] and json.loads((out/'queue-after-unlock.json').read_text())['clear']
    write(out/'completion.json',dict(native_layout_complete=True,source_fixed=True,lock_released=True,no_performance_or_natural_clock_claim=True))
    print('DONE ST13 layout, all own engine exited and lock released',flush=True);return 0
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--tag',required=True);a.add_argument('--count',type=int,choices=[2,3],default=2);a.add_argument('--parser',action='store_true');a.add_argument('--root-explicit-start',action='store_true');raise SystemExit(main(a.parse_args()))
