# ST13 final candidate — pending final affected batch

Actual managed base: `20f9dddf8c57a9f8727442f661f5f7cb6236f872`, including the published NE264 HUD changes. Eight owned files and their byte hashes are sealed in `catalog-delivery-v2/stage-manifest.json`; `candidate.patch` is the exact diff against that base. Primary C, PM, index and commits remain Root-owned.

The change opens existing death actions after the shorter of the first original step and1.2seconds, keeps all original steps and skip behavior, and preserves menu focus at natural finish. Ordinary entry is0.7seconds; authored story deaths retain1.1. Existing per-run navigation state privately retains validated quest definitions and supplies deep copies to each UI; Story reload invalidates them, failed loads keep their original issues and remain retryable, and real restore reuses the same owner. The final narrow focus fix defers initial focus only for the no-sequence case, letting sequence actions first focus after becoming visible.

| Final-source check | Result |
| --- | --- |
| Permanent visible/nonempty hint + original focus/delay regression |19checks/2fail old UI →19/0 fixed UI;0diagnostics |
| Original QuestMapSuite + DeathFlowSuite |486/0;1existing expected no-booth ERROR retained; unchanged original filter says0unexpected;0SCRIPT |
| Real Main count2, HP0 → new player public movement |2956.851ms |
| Real Main count3, same endpoint |2583.626ms |
| Actual temporary-directory write refusal, original prompt, repair and exactly one restore |Pass;2884.077ms observation; original primary/backup/deaths/fees retained |
| Final native layout |Count2/3 × early actions / readable voluntary card / natural finish,6original1280×720 images; Forward+/RX9070XT, RGBH14/HDR2D;0engine/script/leak diagnostics |
| Independent raw/PNG precision |6×921600pixels; canonical independent formula passes all; actual hint text/layout and card scale/alpha readiness retained |
| Final original affected selector |70groups, SHARDS2; running; no completion claim yet |

Main clocks use the real Level/Health damage, existing deferred Main route, actual destination writer and original timed GLITCH. Headless default instant mode is explicitly disabled. Inputs are synthetic public ui_accept/move_right, not physical keyboard/controller. Five environment paths are isolated. Cleanup waits occur after the endpoint. Other headless work was present, so this is functional timing evidence, not isolated performance. Native readbacks/PNG conversion are layout-only and do not stand in for the three-second clock.

The first original70 batch is retained separately:94397checks/0new/0known/1368seconds,0SCRIPT, but its complete inventory gate rejected27919→27931 because12authorized preparation files were added under owned work. All27919 original files stayed exact, with no removed or modified inputs. `catalog-official-v1/source-gate.json` remains false. It is not relabeled as the final-source batch. Final `catalog-official-v2` uses the new base/focus fix and freezes all28035 files; no managed files may change or be added during it.

Earlier evidence remains intact: default81df standalone UI count2 around4.50seconds; first shortened-UI candidates still failing complete Main clocks; before/after repeated Level ready716.700→45.048ms and HUD672.115→3.012ms; initial cold HUD costs also remain recorded. These measurements are not qualified performance comparisons.

Native v1's wrong down-direction helper failed with0engine diagnostics and lost its RAM-only early readback; its absence of raw/PNG is disclosed. Source bytes were recovered by inverse patch and match its original before-guard SHA, explicitly labeled post-execution reconstruction. Native v2 stored real raw/PNG, but card entered-state/slot-visible checks were insufficient: Root rejected blank reveal-start card and missing initial hint. Those six originals and their source copies remain unchanged. Final v3 waits actual hint text/layout and original card scale/alpha endpoints across three true post_draws. Root and the worker independently viewed all six v3 originals and found the requested content readable and menu focus retained.

Read-only readers:

- `verify-default-v9.py` + `canonical-default-v9-index.json`: original default standalone baseline.
- `verify_candidate.py`: pre-cache complete Main red cases, units and actual refusal.
- `verify_final_delivery.py --raw-root <folder> --require-official`: final eight-source units, full Main clocks, refusal and official gate. Before final batch completion omit the last flag; it explicitly reports pending.
- `verify_native_layout_v3.py --raw-root <folder>`: final readiness/source/queue checks and independent full-pixel raw/PNG verification using the canonical precision reader. `native-layout-v3-count{2,3}/native-raw.zip` each holds three original readbacks and PNGs.

Keep complete raw evidence in this persistent external proof root; do not move it into a temporary worktree or normalize JSON/log line endings. Git delivery can contain the eight-source snapshot, exact diff, readers/index, selected original six PNGs and small raw/source archives. Full tracked base assets are already identified by immutable Git; do not duplicate all28035 files into a new archive.

NE267 G40320 is separate and still overall rejected by queue-after1/0. Its original six exterior notches, scope0/material0 and actual RGBA prerequisite are preserved; no additional zoom matrix was run.
