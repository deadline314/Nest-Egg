"""Temporarily time original Level._ready sections; restore exact candidate bytes."""
import hashlib,importlib.util,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent
ROOT=P.parents[1]
PROOF=Path('D:/NestEggVerification/proofs/st13-restoration-clock-20261112')
TAG='catalog-ready-instrument-v2'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(path,value):
    assert not path.exists();path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
owned=['ui/death_screen.gd','game/level/level.gd','tests/suite/test_death_flow.gd']
original={n:(ROOT/n).read_bytes() for n in owned}
expected=json.loads((PROOF/'candidate-delivery-v1/summary.json').read_text(encoding='utf8'))['owned_sources']
assert {n:sha(b) for n,b in original.items()}==expected
out=PROOF/(TAG+'-source-contract');out.mkdir(parents=True,exist_ok=False)
for n,b in original.items():
    dest=out/'candidate-originals'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
raw=original['game/level/level.gd'];text=raw.decode('utf8')
start=text.index('func _ready() -> void:');end=text.index('\n\nfunc _process(',start)
body=text[start:end]
body=body.replace('func _ready() -> void:\n','func _ready() -> void:\n\tvar _st13_marks:Array=[]\n\t_st13_marks.append(["begin",Time.get_ticks_usec()])\n',1)
def after(needle,label):
    global body
    assert body.count(needle)==1,(needle,body.count(needle))
    body=body.replace(needle,needle+'\n\t_st13_marks.append(["'+label+'",Time.get_ticks_usec()])',1)
after('\t_layout = LevelBuilder.parse(data)','Layout.parse')
after('\tadd_child(_world)','identity_state_background_world')
after('\t_scenery_walls = back_wall.geometry','BackWall.setup')
after('\t_lower_scenery(scenery_start, WorldLayers.DECOR)','spawn_decor')
after('\t_world.add_child(wall_shadows)','WallShadows')
after('\t_lower_scenery(scenery_start, WorldLayers.PROPS)','spawn_props')
after('\tterrain.wall_geometry = back_wall.geometry','Terrain.create')
call='\tterrain.build(_layout, data.environment, data.load_regions())'
assert body.count(call)==1
body=body.replace(call,'\tvar _st13_regions := data.load_regions()\n\t_st13_marks.append(["Terrain.load_regions",Time.get_ticks_usec()])\n\tterrain.build(_layout, data.environment, _st13_regions)\n\t_st13_marks.append(["Terrain.build",Time.get_ticks_usec()])',1)
after('\tFx.bind_container(fx)','ghosts_and_containers')
after('\t_spawn_atmosphere()','spawn_atmosphere')
after('\tadd_child(_foreground)','Foreground')
after('\tadd_child(hud)','Hud')
after('\t_power_grid.zone_changed.connect(func(_zone: StringName, _powered: bool) -> void: _rebuild_lighting_events())','PowerGrid')
after('\t_spawn_static_entities()','static_entities')
after('\t_spawn_cinematic_entries()','cinematic_entries')
after('\t_spawn_player()','player_CharacterRig')
after('\tWorldState.restore(get_tree(), _resume.get("world", {}) if not _resume.is_empty() else (_area.get("world", {}) if _persistent else GameState.checkpoint_world))','WorldState.restore')
after('\tadd_child(_light_budget)','lighting')
after('\tcamera.snap_to_target()','camera')
after('\t_tokens = AttackTokens.new(data.attack_caps)','restore_run_entities_and_tokens_create')
after('\tStory.set_bubble_host(_bubbles)','tokens_and_bubbles')
after('\tadd_child(_pause_menu)','PauseMenu.configure_add')
after('\t_inventory.configure(player)','Inventory.configure')
after('\tadd_child(_inventory)','Inventory.add')
body+='\n\t_st13_marks.append(["tail",Time.get_ticks_usec()])\n\tprint("ST13_LEVEL_READY ",JSON.stringify({"Level_id":get_instance_id(),"area":data.resource_path,"resume":not _resume.is_empty(),"marks":_st13_marks}))\n'
instrumented=(text[:start]+body+text[end:]).encode('utf8')
target=ROOT/'game/level/level.gd'
write(out/'source-contract.json',dict(base='5a363c4e29c186661eba364cc2bbee3cee374178',classification='Instrumentation only: Level._ready local array of section timestamps, one final print, same algorithms/resource calls. Main original calls wrapped by existing TimedMain observer.',instrumented_sha256=sha(instrumented),producer_sha256=sha(Path(__file__).read_bytes()),candidate_sha256={n:sha(b) for n,b in original.items()},only_instrumentation_delta='game/level/level.gd::_ready',scene='res://work/st13-candidate-v1/main_probe_v3.tscn',no_GPU=True))
(out/'producer.py').write_bytes(Path(__file__).read_bytes())
(out/'instrumented-level.gd').write_bytes(instrumented)
spec=importlib.util.spec_from_file_location('st13_main_v3',ROOT/'work/st13-run-catalog-v1/run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
target.write_bytes(instrumented)
code=None
try:
    code=module.main(__import__('argparse').Namespace(tag=TAG,mode='main',count=2,refuse=False))
finally:
    observed={n:sha((ROOT/n).read_bytes()) for n in owned}
    assert observed['ui/death_screen.gd']==expected['ui/death_screen.gd'] and observed['tests/suite/test_death_flow.gd']==expected['tests/suite/test_death_flow.gd']
    assert observed['game/level/level.gd']==sha(instrumented),'instrumented Level unexpectedly changed; refuse blind restore'
    target.write_bytes(raw)
    restored={n:sha((ROOT/n).read_bytes()) for n in owned}
    write(out/'restoration.json',dict(source_before=expected,source_during=observed,source_after=restored,exact_candidate_restored=restored==expected,process_return=code))
    assert restored==expected
print('Instrumented run complete; exact three candidate source SHA restored; engine result',code)
