"""Read-only replay of original natural clocks, source seals and genuine IO refusal."""
import argparse,hashlib,json,math,re
from pathlib import Path
def load(p):return json.loads(p.read_text(encoding='utf8'))
def main(root):
    d=root/'candidate-delivery-v1';index=load(d/'index.json')
    for name,item in index['files'].items():
        p=root/name
        assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],name
    summary=load(d/'summary.json');assert len(summary['cases'])==4
    for row in summary['cases']:
        p=root/row['case'];x=load(p/'measurement.json');proc=load(p/'process.json');env=load(p/'environment.json')
        before=load(p/'before.json');after=load(p/'after.json')
        assert before['base']==summary['base']==after['base']
        assert before['tracked_source_sha256']==after['tracked_source_sha256'] and before['own']==after['own']
        assert not proc['diagnostics'] and '--headless' in proc['command'] and '--verbose' not in proc['command']
        assert not re.search(r'SCRIPT ERROR|^ERROR:|ObjectDB.*leak|were leaked|resources still in use',(p/'process.log').read_text(encoding='utf8'),re.M)
        assert set(env['isolated'])=={'APPDATA','LOCALAPPDATA','USERPROFILE','XDG_DATA_HOME','XDG_CONFIG_HOME'}
        assert len(set(env['isolated'].values()))==5 and x['environment']==env['isolated']
        assert all(Path(v).is_relative_to(p) for v in env['isolated'].values())
        assert x['transition_fixture']=={'original_headless_instant':True,'enabled_original_timed_transition':True}
        m=x['measurement'];c=x['control'];zero=m['health_zero_usec']
        assert abs(m['zero_to_retry_msec']-(m['retry_visible_enabled_focus_usec']-zero)/1000)<1e-7
        assert abs(c['zero_to_control_msec']-(c['first_movement_usec']-zero)/1000)<1e-7
        assert c['ST13_le_3000msec']==(c['first_movement_usec']-zero<=3000000)==False
        assert c['new_Level_id']!=c['source_Level_id'] and len(c['load_events'])==1
        assert c['end'][0]>c['start'][0] and c['deaths_exact'] and c['credits_exact']
        assert c['public_action']=='move_right' and c['synthetic'] and x['retry_input']['action']=='ui_accept' and not x['retry_input']['direct_handler_call']
        assert not m['sequence_complete_at_UI_available'] and m['applied_Level_delay_seconds']==.7
        assert all(v==1 for v in m['raw_time_scales'])
        assert all(v['time_scale']==1 and math.isfinite(v['delta']) for v in c['observed_frames'])
        assert c['clock']['max_fps']==0 and c['clock']['physics_ticks_per_second']==60 and not c['clock']['tree_paused']
        assert x['audio_shutdown']['begin_usec']>=c['first_movement_usec'] and not x['audio_shutdown']['allows_playback_after']
        if row['refusal_safety']:
            f=x['refusal'];assert f['real_tmp_directory'] and f['same_dead_Level'] and f['retry_only'] and f['purpose']=='respawn'
            assert all(f[k] for k in ['primary_exact','backup_exact','deaths_exact','credits_exact']) and f['writer_issues'] and proc['exit_code']==0
        else:assert proc['exit_code']==1
    red=load(root/'candidate-short-red-v1/checks.json');green=load(root/'candidate-short-green-v1/checks.json')
    assert red['checks']==14 and len(red['failures'])==5 and green['checks']==17 and not green['failures']
    print('READ_ONLY verified',len(index['files']),'raw/source files; UI/refusal safety green;3 unobstructed complete Main clocks RED;1 intentionally blocked IO case is not timing acceptance')
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--raw-root',type=Path,default=Path(__file__).resolve().parent);v=a.parse_args();main(v.raw_root)
