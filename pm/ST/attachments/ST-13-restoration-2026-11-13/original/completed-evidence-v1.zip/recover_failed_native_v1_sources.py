"""Recover exact failed producer bytes by inverse patch, verify against original guard."""
import hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
OUT=P/'native-v1-source-recovery';OUT.mkdir(exist_ok=False)
before=json.loads((P/'native-layout-v1-count2/before.json').read_text(encoding='utf8'))['own']
expected={Path(n).name:h for n,h in before.items()}
t=(P/'native-v2-source-originals/producer/capture.gd').read_text(encoding='utf8')
t=t.replace('\t_export_images()\n\t_result.native_failure_captures=_captures\n','',1)
a=t.index('\tvar direction:=InputEventKey.new()');b=t.index('\tvar deadline:=',a)
t=t[:a]+'\t_send(&"ui_down",true)\n\tawait get_tree().process_frame\n\t_send(&"ui_down",false)\n'+t[b:]
a=t.index('\tif not _export_images():');b=t.index('\t_images.clear()',a)
t=t[:a]+'''\tfor item:Dictionary in _images:
\t\tvar raw_image:Image=item.image
\t\tvar record:Dictionary=item.record
\t\tvar file:=FileAccess.open(_out.get_base_dir().path_join(record.linear_raw),FileAccess.WRITE)
\t\tfile.store_buffer(raw_image.get_data());file.close()
\tfor item:Dictionary in _images:
\t\tvar raw_image:Image=item.image
\t\tvar record:Dictionary=item.record
\t\tvar encoded:=Capture.encode(raw_image,bool(record.hdr_2d))
\t\tif encoded.save_png(_out.get_base_dir().path_join(record.encoded_png))!=OK:
\t\t\t_fail("Canonical PNG save failed: "+str(record.encoded_png));return
'''+t[b:]
a=t.index('func _export_images()->bool:');b=t.index('func _grab(',a);t=t[:a]+t[b:]
needle='\tfile=FileAccess.open(_out.get_base_dir().path_join(record.linear_raw),FileAccess.WRITE)\n\tfile.store_buffer(original.get_data());file.close()\n'
assert t.count(needle)==1;t=t.replace(needle,'',1)
needle='or original.get_size()!=Vector2i(1280,720):\n\t\treturn false'
assert t.count(needle)==1
t=t.replace(needle,'or original.get_size()!=Vector2i(1280,720):\n\t\tfile=FileAccess.open(_out.get_base_dir().path_join(record.linear_raw),FileAccess.WRITE)\n\t\tfile.store_buffer(original.get_data());file.close()\n\t\treturn false',1)
data=t.encode('utf8');(OUT/'capture.gd').write_bytes(data)
r=(P/'native-v2-source-originals/producer/run.py').read_text(encoding='utf8')
r=r.replace('started=False;failure=None','started=False',1)
r=r.replace('            try:process(out,a.count,False)\n            except Exception as exc:failure=repr(exc)','            process(out,a.count,False)',1)
a=r.index('    if failure:\n');b=r.index('    assert started',a);r=r[:a]+r[b:]
(OUT/'run.py').write_text(r,encoding='utf8',newline='\n')
(OUT/'capture.tscn').write_bytes((P/'native-v2-source-originals/producer/capture.tscn').read_bytes())
actual={n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in expected}
(OUT/'recovery.json').write_text(json.dumps(dict(classification='Reconstructed after execution from the preserved v2 source and the narrow inverse patch; exact bytes verified by original v1 before-guard SHA, not falsely described as an execution-time copy.',expected=expected,recovered=actual,all_exact=expected==actual),indent=2)+'\n',encoding='utf8')
assert actual==expected,(actual,expected)
print('All3 failed v1 producer files recovered exactly against original SHA')
