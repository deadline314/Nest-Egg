import hashlib,json,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((P/'completed-index-v1.json').read_text(encoding='utf8'))
assert sha(P/prior['archive'])==prior['sha256']
gate=json.loads((P/'catalog-official-v2/source-gate.json').read_text(encoding='utf8'));assert gate['overall_accepted']
files=[]
for p in sorted(P.rglob('*')):
    if not p.is_file():continue
    parts=p.relative_to(P).parts;name=p.relative_to(P).as_posix()
    if any(s in parts for s in ['user','environment','__pycache__']) or p.suffix.lower() in ['.raw','.zip']:continue
    if 'catalog-official-v2' in parts and any(s.startswith('data_') for s in parts):continue
    if name in prior['files']:
        assert sha(p)==prior['files'][name]['sha256'],('previous evidence changed',name)
        continue
    files.append(p)
out=P/'final-supplement-v1.zip';assert not out.exists()
index={}
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:
        name=p.relative_to(P).as_posix();data=p.read_bytes();z.writestr(name,data)
        index[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for name,item in index.items():
        data=z.read(name);assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
receipt=dict(archive=out.name,bytes=out.stat().st_size,sha256=sha(out),member_count=len(index),files=index,previous_completed_archive_preserved=True,final_official_gate=gate,raw_float_archives_remain_external=True)
target=P/'final-supplement-index-v1.json';assert not target.exists();target.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print('Final supplement verified',len(index),'members',round(out.stat().st_size/1024**2,2),'MiB; total two archives',round((out.stat().st_size+(P/prior['archive']).stat().st_size)/1024**2,2),'MiB')
