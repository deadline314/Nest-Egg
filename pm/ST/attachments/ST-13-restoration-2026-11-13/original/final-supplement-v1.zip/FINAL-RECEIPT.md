# ST13 — final eight-source candidate verified

Actual base `20f9dddf8c57a9f8727442f661f5f7cb6236f872`, including NE264 HUD integration. Eight exact owned source/test files are in `catalog-delivery-v2/stage-manifest.json` and `candidate.patch`. Nothing was adopted to primary C or committed by this worker.

- Final original affected entry:70groups, SHARDS2,94431checks,0new,0known, exit0;1343seconds reported by the original runner,1346.628seconds by the wrapper.
- Full inventory:28035files before/after, identical names/bytes/SHA;0SCRIPT/Parse. The true final source gate is `catalog-official-v2/source-gate.json`.
- Actual permanent hint regression:19/2 red →19/0 green,0diagnostics. Original QuestMap/DeathFlow:486/0, with1existing expected no-booth ERROR retained; unchanged original filter reports0unexpected.
- Real Main/Health/public input through actual save and original timed transition to a new controllable player: count2 **2956.851ms**, count3 **2583.626ms**. Keep the borderline count2 value; no fastest-run selection.
- Actual temporary-directory write refusal keeps the original dead level, retry-only prompt, primary/backup bytes, deaths and fees; repair/public retry restores once. Final observation2884.077ms.
- Six final Forward+ native originals: counts2/3 × early actions/readable voluntary card/natural finish. Actual RGBH14/HDR2D,1280×720, RX9070XT; all processes exit0/0diagnostics, C397/v24/final8/producer exact, primary lock released and both ports clear before/after.
- Root and worker viewed all six originals. The initial retry explanation is readable, the voluntary card is fully expanded, and natural finish preserves the menu selection and explanation. Independent raw/PNG precision verifies5529600pixels; maximum RGB error.0039213085 and alpha error0 under the original canonical contract.

These are synthetic public input and functional clocks, not physical keyboard/controller or isolated-performance evidence. Native PNG conversion does not count as a three-second clock. First-clinic/recording/prior-death/checkpoint setup is an explicit fixture, not a claimed clinic playthrough. All original text, step durations, skip, fee and save gates remain intact.

Preserve every previous result: default standalone count2~4.50seconds, pre-cache full Main red clocks, cold first-load HUD costs, native helper v1's failed direction/no-raw limitation, v2's blank reveal-start card/missing hint, and old70's inventory rejection. Old70 had94397/0checks but its gate remains false because12owned preparation files were added; all original27919inputs remained unchanged. Do not relabel those old outputs with final results.

Portable readonly verification:

```
python verify_final_delivery.py --raw-root <persistent-proof-root> --require-official
python verify_native_layout_final.py --raw-root <persistent-proof-root>
```

The final native reader validates the archived canonical precision reader's SHA before execution; it does not depend on a future live managed checkout. Complete original float archives remain external in `native-layout-v3-count{2,3}/native-raw.zip`; each archive is about16.6MB. Six selected original PNGs can be copied unchanged for PM images. `completed-evidence-v1.zip` holds1123completed evidence/source members in22.99MiB, individually SHA/CRC verified; final official results and late sealed readers are a separate small supplement. Original files are never deleted or normalized.
