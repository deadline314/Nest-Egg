extends Node


func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	var scene_id := &"ch1_p01_door"
	var scene: Dictionary = Story._scenes.get(scene_id, {})
	var original_narration: Array = scene.get("steps", [])[1].get("lines", [])
	var target := "\n".join(PackedStringArray(original_narration))
	var player := CutscenePlayer.new()
	add_child(player)
	player.play(scene_id, scene)
	var checks := {"language": Story.language, "adapter": RenderingServer.get_video_adapter_name(),
		"renderer": RenderingServer.get_current_rendering_method(), "text": target,
		"story_problems": Story.validate(), "lint": Story.lint(), "capture": false}
	for frame in 1500:
		await get_tree().process_frame
		var label := player._center_text
		if not is_instance_valid(label) or label.text != target or label.visible_ratio < 1.0 or label.modulate.a < 0.99:
			continue
		await RenderingServer.frame_post_draw
		var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
		checks["label_lines"] = label.get_line_count()
		checks["label_visible_lines"] = label.get_visible_line_count()
		checks["capture"] = image.save_png(out.path_join("prologue.png")) == OK
		break
	player.skip()
	for frame in 500:
		if not player.is_running():
			break
		await get_tree().process_frame
	checks["released"] = not player.is_running() and not GameplayLock.is_locked()
	FileAccess.open(out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify(checks, "\t"))
	get_tree().quit(0 if checks.capture and checks.released and checks.label_lines == checks.label_visible_lines and checks.story_problems.is_empty() and checks.lint.is_empty() else 1)
