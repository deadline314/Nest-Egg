extends Node


func _ready() -> void:
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	var report := {
		"language": Story.language, "validation": Story.validate(), "lint": Story.lint(),
		"scene_count":Story._scenes.size(), "languages":StoryLocale.LANGUAGES,
	}
	if "--candidate" in OS.get_cmdline_user_args():
		var bad: Array[String] = []
		for language: String in ["zh", "ja", "en"]:
			var cap := StoryLint.bubble_limit(false, language)
			var bark_cap := StoryLint.bubble_limit(true, language)
			var component := "牆邊。" if language == "zh" else "word "
			if not StoryLint.with_rule(StoryLint.readability(component.repeat(cap + 1), "overflow", "bubbles", false, language), "氣泡長度").size() == 1:
				bad.append("bubble overage is still found for " + language)
			if bark_cap >= cap:
				bad.append("the bark cap is shorter")
		var scene := {"steps":[{"do":"say", "speaker":"test", "text":"這條貨道今天積水。".repeat(10)}]}
		var speakers := {"test":{}}
		if CutsceneChecker.validate("test", scene, speakers).is_empty():
			bad.append("authored line length stays checked")
		scene.steps[0].text = "現在可以過去。"
		scene.steps[0].speaker = "missing"
		if CutsceneChecker.validate("test", scene, speakers).is_empty():
			bad.append("the authored checker rejects missing speakers")
		report["control_failures"] = bad
	FileAccess.open(out, FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	get_tree().quit.call_deferred(0)
