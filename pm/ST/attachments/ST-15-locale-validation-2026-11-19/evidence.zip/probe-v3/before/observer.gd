extends Node


func _ready() -> void:
	var out := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	var report := {
		"language": Story.language, "validation": Story.validate(), "lint": Story.lint(),
		"scene_count":Story._scenes.size(), "languages":StoryLocale.LANGUAGES,
	}
	FileAccess.open(out, FileAccess.WRITE).store_string(JSON.stringify(report, "\t"))
	get_tree().quit.call_deferred(0)
