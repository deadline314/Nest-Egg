from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

root=Path.cwd()
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
evidence=Path('D:/NestEggVerification/evidence-20261117')
prior=evidence/'ne267-source-delivery-20261118/s09-hawker-release/integration'
base=evidence/'st15-runtime-locale-20261119'
out=base/'integration'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
expected=read(prior/'publish/result.json')['commit']
previous=read(prior/'published-source.json')
assert subprocess.check_output(['git','branch','--show-current'],cwd=root).strip()==b'codex/ticket-work-20261119-st15-locale'
assert all(subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree).decode().strip()==expected for tree in (root,shared))
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root).strip()
assert all(sha(shared/name)==digest for name,digest in previous.items())
manifest=read(base/'manifest-v2.json')
paths={name:base/'sources-v2'/name for name in manifest}
assert all(sha(root/name)==sha(shared/name)==row['before'] and sha(paths[name])==row['after'] for name,row in manifest.items())
reports=read(base/'probe-v3/compare.json')
for locale,previous_count in [('zh',0),('ja',110),('en',1447)]:
    start=reports['before:'+locale]
    stop=reports['after:'+locale]
    assert start['diagnostics']==previous_count and not start['control_failures']
    assert stop['diagnostics']==stop['lint']==stop['validation']==stop['exit']==0 and stop['source_held'] and not stop['control_failures']
    vis=read(base/'native-prologue-v1'/locale/'result.json')
    assert vis['capture'] and vis['released'] and vis['label_lines']==vis['label_visible_lines'] and not vis['story_problems'] and not vis['lint']
    assert vis['language']==locale and '9070' in vis['adapter']
assert re.search(r'checks: 209, failures: 0', (base/'targeted-v2/raw.log').read_text(encoding='utf-8'))
assert sha(root/'data/story/ch2_heron.json')==previous['data/story/ch2_heron.json']
assert all(sha(base/'runtime'/name)==sha(root/name) for name in ('data/story/ch1_kasa.json','data/story/ch2_heron.json','data/story/ch3_clearwater.json'))
out.mkdir()
source=previous|{name:row['after'] for name,row in manifest.items()}
for tree in (root,shared):
    for path,value in paths.items():
        (tree/path).write_bytes(value.read_bytes())
assert all(sha(shared/name)==digest for name,digest in source.items())
(out/'paths.json').write_text(json.dumps(list(paths),indent=2)+'\n')
(out/'source.json').write_text(json.dumps(source,indent=2)+'\n')
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'

def run(label,args):
    destination=out/label
    destination.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(destination/'profile'/key)
    env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',GODOT=engine,SHARDS='8',LOG_DIR=str(destination/'shards'))
    (destination/'command.json').write_text(json.dumps(args,indent=2)+'\n')
    with (destination/'raw.log').open('wb') as log:
        proc=subprocess.run(args,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=2400)
    raw=(destination/'raw.log').read_bytes()
    result={'exit':proc.returncode,'errors':[line.decode(errors='replace') for line in raw.splitlines() if b'ERROR:' in line],
            'source_held':all(sha(shared/name)==digest for name,digest in source.items()) and all(sha(root/name)==source[name] for name in paths)}
    (destination/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(label,result,raw.decode(errors='replace')[-1300:],flush=True)
    assert result=={'exit':0,'errors':[],'source_held':True}
    return result

for language in ('zh','ja','en'):
    run('story-lint-'+language,[engine,'--headless','res://tools/story_lint.tscn','--','--story-language='+language])
selector=['C:/Program Files/Git/bin/bash.exe','-c',f'python3() {{ python "$@"; }}; export -f python3; tools/run_tests_changed.sh {expected}']
verify=run('official',selector)
(out/'verification.json').write_text(json.dumps(verify,indent=2)+'\n')
