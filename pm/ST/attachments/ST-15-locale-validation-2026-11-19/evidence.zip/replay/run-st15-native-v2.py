from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/st15-runtime-locale-20261119')
project=base/'runtime'
out=base/'native-prologue-v1'
out.mkdir()
manifest=json.loads((base/'manifest-v2.json').read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert all(sha(project/name)==row['after'] for name,row in manifest.items())
probe=out/'observer.gd'
probe.write_bytes((root/'work/st15-localized-prologue.gd').read_bytes())
scene=probe.with_suffix('.tscn')
scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{probe.as_posix()}" id="1"]\n[node name="LocalizedPrologue" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
for lang in ('zh','ja','en'):
    unit=out/lang
    unit.mkdir()
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[key]=str(unit/'profile'/key)
    args=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',engine,'--path',str(project),
          '--audio-driver','Dummy','--rendering-method','forward_plus','--rendering-driver','vulkan',
          '--resolution','1280x720','--fixed-fps','60','--quit-after','2400',str(scene),'--','--out='+str(unit),'--story-language='+lang]
    (unit/'command.json').write_text(json.dumps(args,indent=2)+'\n')
    with (unit/'raw.log').open('wb') as log:
        process=subprocess.run(args,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    raw=(unit/'raw.log').read_text(encoding='utf-8')
    assert process.returncode==0 and 'ERROR:' not in raw and 'WARNING:' not in raw,raw[-1600:]
    result=json.loads((unit/'result.json').read_text(encoding='utf-8'))
    assert result['language']==lang and result['capture'] and result['released'] and '9070' in result['adapter']
    print(lang,result['label_lines'],len(result['text']),flush=True)
PY = sys.executable
unit=base/'targeted-v2'
unit.mkdir()
env=os.environ.copy()
for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[key]=str(unit/'profile'/key)
args=[engine,'--headless','--path',str(project),'res://tests/smoke_test.tscn','--','--only=StoryLintSuite']
(unit/'command.json').write_text(json.dumps(args,indent=2)+'\n')
with (unit/'raw.log').open('wb') as log:
    process=subprocess.run(args,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
raw=(unit/'raw.log').read_text(encoding='utf-8')
print(raw[-1200:],flush=True)
assert process.returncode==0 and 'ERROR:' not in raw and 'failures: 0' in raw.lower(),raw[-2000:]
