from pathlib import Path
from collections import Counter
import hashlib
import json
import os
import re
import shutil
import subprocess

root=Path.cwd()
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
base=Path('D:/NestEggVerification/evidence-20261117/st15-runtime-locale-20261119')
project=base/'runtime'
if not project.exists():
    shutil.copytree(shared,project,ignore=shutil.ignore_patterns('.git','work','__pycache__','.agent-state'))
manifest=json.loads((base/'manifest-v2.json').read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert all(sha(project/name)==row['before'] for name,row in manifest.items())
out=base/'probe-v3'
out.mkdir()
candidate=(root/'work/st15-locale-probe-v2.gd').read_text(encoding='utf-8')
anchor = '\tif "--candidate" in OS.get_cmdline_user_args():\n'
common = '\tFileAccess.open(out, FileAccess.WRITE).store_string(JSON.stringify(report, "\\t"))\n'
assert candidate.count(anchor)==candidate.count(common)==1
baseline = candidate[:candidate.index(anchor)] + candidate[candidate.index(common):]
primary=['data/story/ch1_kasa.json','data/story/ch2_heron.json','data/story/ch3_clearwater.json']
stories={name:sha(project/name) for name in primary}
counts={}
for edition in ('before','after'):
    target=out/edition
    target.mkdir()
    observer=target/'observer.gd'
    observer.write_text(candidate if edition=='after' else baseline,encoding='utf-8')
    scene=observer.with_suffix('.tscn')
    scene.write_text(f'[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="{observer.as_posix()}" id="1"]\n[node name="StoryLocale" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')
    if edition=='after':
        for name,row in manifest.items():
            (project/name).write_bytes((base/'sources-v2'/name).read_bytes())
            assert sha(project/name)==row['after']
    for language in ('zh','ja','en'):
        unit=target/language
        unit.mkdir()
        env=os.environ.copy()
        for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
            env[key]=str(unit/'profile'/key)
        cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(project),'--quit-after','180',
             scene.as_posix(),'--','--out='+str(unit/'report.json'),'--story-language='+language]
        if edition=='after':
            cmd.append('--candidate')
        (unit/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
        with (unit/'raw.log').open('wb') as log:
            process=subprocess.run(cmd,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
        raw=(unit/'raw.log').read_text(encoding='utf8')
        diagnostics=re.findall(r'^.*(?:ERROR:|WARNING:).*$',raw,re.M)
        assert process.returncode==0 and all(re.match(r'(?:ERROR|WARNING): \[Story\]',line) for line in diagnostics), raw[-2000:]
        report=json.loads((unit/'report.json').read_text(encoding='utf-8'))
        errors=Counter(line.split(']')[0]+']' for line in diagnostics)
        result={'exit':process.returncode,'diagnostics':len(diagnostics),'kinds':dict(errors), 'locale':report['language'],
                'validation':len(report['validation']),'lint':len(report['lint']),'source_held':all(sha(project/name)==h for name,h in stories.items()),
                'control_failures':report.get('control_failures',[]),'scenes':report['scene_count']}
        (unit/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(edition,language,result,flush=True)
        assert result['locale']==language and result['source_held'] and not result['control_failures']
        counts[edition+':'+language] = result
(out/'compare.json').write_text(json.dumps(counts,indent=2)+'\n')

assert [counts['before:'+code]['diagnostics'] for code in ('zh','ja','en')] == [0,110,1447]
assert all(counts['after:'+code]['diagnostics']==counts['after:'+code]['lint']==counts['after:'+code]['validation']==0 for code in ('zh','ja','en'))
