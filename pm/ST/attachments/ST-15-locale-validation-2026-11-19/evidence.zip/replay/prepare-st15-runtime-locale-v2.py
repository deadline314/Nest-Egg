from pathlib import Path
import hashlib
import json
import shutil

root=Path.cwd()
base=Path('D:/NestEggVerification/evidence-20261117/st15-runtime-locale-20261119')
source=base/'sources-v2'
source.mkdir(parents=True)


def replace(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new)


story_name='autoload/story.gd'
story=(root/story_name).read_text(encoding='utf-8')
story=replace(story,'const MAX_BUBBLE_CHARS := 30\n','')
story=replace(story,'const MAX_BARK_CHARS := 16\n','')
story=replace(story,'func validate() -> PackedStringArray:\n\tvar problems := PackedStringArray()\n',
              'func validate() -> PackedStringArray:\n\tvar problems := PackedStringArray()\n\tvar authored_chapters: Dictionary[String, Dictionary] = {}\n')
story=replace(story,'CutsceneChecker.validate(scene_id, scene, _speakers)',
              'CutsceneChecker.validate(scene_id, _authored_scene(scene_id, scene, authored_chapters), _speakers)')
anchor='## 分派路線、選項接續（target）與條件（when）都要指向存在的場景、格式正確。'
story=replace(story,anchor,'''## 動畫的台詞長度和節奏預算以作者的原文估算。只在這次驗證中保留章節快取。
func _authored_scene(scene_id: String, scene: Dictionary, chapters: Dictionary[String, Dictionary]) -> Dictionary:
	if language == StoryLocale.SOURCE_LANGUAGE:
		return scene
	var path := _scene_sources.get(scene_id, "") as String
	if path.is_empty():
		return scene
	if not chapters.has(path):
		var source := load(path) as JSON if ResourceLoader.exists(path) else null
		var authored_scenes: Variant = source.data.get("scenes", {}) if source != null and source.data is Dictionary else {}
		chapters[path] = authored_scenes if authored_scenes is Dictionary else {}
	var original: Variant = chapters[path].get(scene_id)
	return original if original is Dictionary else scene


'''+anchor)
story=replace(story,'var cap := MAX_BARK_CHARS if bool(scene.get("bark", false)) else MAX_BUBBLE_CHARS',
              'var cap := StoryLint.bubble_limit(bool(scene.get("bark", false)), language)')
story=replace(story,'StoryLint.check_chapter(String(chapter_id), text_units(chapter_id), _speakers)',
              'StoryLint.check_chapter(String(chapter_id), text_units(chapter_id), _speakers, language)')

lint_name='core/story_lint.gd'
lint=(root/lint_name).read_text(encoding='utf-8')
lint=replace(lint,'static func check_unit(unit_id: String, lines: Array, speakers: Dictionary) -> Array[Dictionary]:',
             'static func check_unit(unit_id: String, lines: Array, speakers: Dictionary, language := StoryLocale.SOURCE_LANGUAGE) -> Array[Dictionary]:')
lint=replace(lint,'\t\t\tissues.append_array(readability(text, where, str(entry.get("mode", "text")), bool(entry.get("bark", false))))\n',
             '\t\t\tissues.append_array(readability(text, where, str(entry.get("mode", "text")), bool(entry.get("bark", false)), language))\n\t\tif TRANSLATION_BUBBLE_FACTOR.has(language):\n\t\t\tcontinue\n')
lint=replace(lint,'static func check_chapter(chapter_id: String, units: Array, speakers: Dictionary) -> Array[Dictionary]:',
             'static func check_chapter(chapter_id: String, units: Array, speakers: Dictionary, language := StoryLocale.SOURCE_LANGUAGE) -> Array[Dictionary]:')
lint=replace(lint,'\t\tissues.append_array(check_unit(unit_id, lines, speakers))\n',
             '\t\tissues.append_array(check_unit(unit_id, lines, speakers, language))\n\t\tif TRANSLATION_BUBBLE_FACTOR.has(language):\n\t\t\tcontinue\n')
lint=replace(lint,'const TRANSLATION_BUBBLE_FACTOR := {"ja": 1.5, "en": 3.0}\n',
             'const TRANSLATION_BUBBLE_FACTOR := {"ja": 1.5, "en": 3.0}\n\n\nstatic func bubble_limit(bark: bool, language: String) -> int:\n\treturn int((16 if bark else 30) * float(TRANSLATION_BUBBLE_FACTOR.get(language, 1.0)))\n')
lint=replace(lint,'var limit := int((16 if bark else 30) * float(TRANSLATION_BUBBLE_FACTOR[language]))','var limit := bubble_limit(bark, language)')
lint=replace(lint,'var cap := 16 if bark else 30','var cap := bubble_limit(bark, language)')

lint=replace(lint,'language := "zh") -> Array[Dictionary]:','language := StoryLocale.SOURCE_LANGUAGE) -> Array[Dictionary]:')
lint=replace(lint,'var formal := _is_formal(speakers, speaker_id)\n\t\tvar where', 'var where')
lint=replace(lint,'\t\tif TRANSLATION_BUBBLE_FACTOR.has(language):\n\t\t\tcontinue\n\t\tfor word',
             '\t\tif TRANSLATION_BUBBLE_FACTOR.has(language):\n\t\t\tcontinue\n\t\tvar formal := _is_formal(speakers, speaker_id)\n\t\tfor word')

test_name='tests/suite/test_story_lint.gd'
tests=(root/test_name).read_text(encoding='utf-8')
tests=replace(tests,'\t\tcheck(Story.set_language(language), "the prologue supports %s" % language)\n',
              '\t\tcheck(Story.set_language(language), "the prologue supports %s" % language)\n'
              '\t\tvar validation := Story.validate()\n'
              '\t\tcheck(validation.is_empty(), "loaded story validates in %s: %s" % [language, validation])\n'
              '\t\tvar issues := Story.lint()\n'
              '\t\tcheck(issues.is_empty(), "loaded story lints in %s: %s" % [language, issues])\n')
anchor='\tcheck(StoryLint.readability("字".repeat(30), "fixture", "bubbles").is_empty(), "30 character bubble passes")\n'
tests=replace(tests,anchor,'''	for language: String in ["ja", "en"]:
		var limit := 45 if language == "ja" else 90
		var bark_limit := 24 if language == "ja" else 48
		check(StoryLint.bubble_limit(false, language) == limit and StoryLint.bubble_limit(true, language) == bark_limit,
			"%s bubble and bark limits use the existing translation factor" % language)
		var lines := [{"speaker": "rin", "text": "瞄準線".repeat(limit), "mode": "dialogue"}]
		check(StoryLint.check_unit("fixture", lines, SPEAKERS, language).is_empty(),
			"%s prose avoids Chinese vocabulary and length rules" % language)
		lines[0].mode = "bubbles"
		lines[0].text = "a".repeat(limit)
		check(StoryLint.check_unit("fixture", lines, SPEAKERS, language).is_empty(), "%s bubble fits at its limit" % language)
		lines[0].text += "a"
		check(_has_rule(StoryLint.check_unit("fixture", lines, SPEAKERS, language), "氣泡長度", StoryLint.Level.WARNING),
			"%s still warns about oversized translated bubbles" % language)
'''+anchor)
files={story_name:story,lint_name:lint,test_name:tests}
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
manifest={}
for name,payload in files.items():
    dest=source/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(payload.encode())
    manifest[name]={'before':sha(root/name),'after':sha(dest)}
(base/'manifest-v2.json').write_text(json.dumps(manifest,indent=2)+'\n')
