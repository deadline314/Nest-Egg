extends "res://tools/ch1_flow_probe.gd"

const UPLOAD := &"ch2_t_s15_upload"
const REVISIT := &"ch2_t_s15_revisit"
const LEVEL_PATH := "res://data/levels/ch2_lounge_front.tres"
const ITEMS := [&"ch2_evidence_contract", &"ch2_evidence_receipt", &"ch2_evidence_collection", &"ch2_original_ledger", &"ch2_clinic_index", &"ch2_ali_page"]

var _mode := ""
var _main: Node
var _store: RunSaveStore
var _clicks := 0
var _contact_samples := 0
var _closest := INF
var _max_finished_error := 0.0
var _finish_samples := 0
var _captured := false
var _first_line := false
var _press_seen := false
var _start_wallet := 0
var _beginning_items: Dictionary


func _run() -> void:
	var slot := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--slot="):
			slot = arg.trim_prefix("--slot=")
	if _mode not in ["before", "normal", "exit", "cold", "air", "skip", "right"] or not slot.is_absolute_path():
		get_tree().quit(2)
		return
	_store = RunSaveStore.new(slot)
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	_main.set("_run_store", _store)
	add_child(_main)
	Story.auto_skip = false
	Story.scene_started.connect(func(id: StringName, _unused: StringName) -> void: _played.append(String(id)))
	Sfx.sound_played.connect(func(id: StringName) -> void:
		if id == &"switch" and Story._current_cinematic == UPLOAD:
			_clicks += 1)
	for i in 2400:
		if _main.get("_screen") is MainMenu and not bool(_main.call("_route_pending")):
			break
		await get_tree().physics_frame
	if not _require(_main.get("_screen") is MainMenu, "normal Main shows its Continue entry"):
		return
	var initial := _store.read()
	if not _require(initial.get("level", "") == LEVEL_PATH, "private prior slot resolves the real lounge frontage"):
		return
	_start_wallet = int(initial["progression"]["credits"])
	_main.call("_on_continue_requested")
	for i in 2400:
		var scene := _main.get("_screen") as Level
		if is_instance_valid(scene) and scene.data.resource_path == LEVEL_PATH and scene.is_initialized() and not bool(_main.call("_route_pending")):
			_level = scene
			break
		await get_tree().physics_frame
	if not _require(is_instance_valid(_level), "normal Continue enters the authored level"):
		return
	_beginning_items = StoryItems.snapshot()
	_check(ITEMS.all(func(id: StringName) -> bool: return StoryItems.holds(id)), "all three copies, original account, private page and clinical index are in the slot")
	_check(Progression.credits == _start_wallet and not GameState.has_flag(&"ch2_audit_submitted")
		and not _audit_paid(), "nothing paid before interacting with the real terminal")
	_check(Story.resolve_dispatch(&"ch2_dispatch_terminal") == UPLOAD, "original terminal eligibility resolves the authored upload")
	var terminal := _object(&"ch2_terminal")
	if not _require(is_instance_valid(terminal), "actual terminal owner is present"):
		return
	if _mode == "cold":
		_check(initial.get("cinematic", "") == String(UPLOAD), "cold start reads the real pending upload marker")
		print("COLD_STANCE_BOOT ", _level.player.is_on_floor(), " position=", _level.player.global_position, " velocity=", _level.player.velocity)
	else:
		_check(str(initial.get("cinematic", "")).is_empty(), "first start has no pending presentation")
		_level.player.global_position = terminal.global_position + Vector2(41 if _mode == "right" else -18, 0)
		_level.camera.snap_to_target()
		for i in 50:
			if terminal.interaction_available() and _level.player.is_on_floor():
				break
			await get_tree().physics_frame
		_check(terminal.interaction_available() and _level.player.is_on_floor(), "player stands at the original terminal floor and interaction range")
		if _mode == "air":
			Input.action_press(&"jump")
			for i in 8:
				await get_tree().physics_frame
				if not _level.player.is_on_floor():
					break
			Input.action_release(&"jump")
			_check(not _level.player.is_on_floor(), "original input begins from an actual jump")
		await _interact()
	for i in 600:
		if Story._current_cinematic == UPLOAD:
			break
		await get_tree().physics_frame
	if not _require(Story._current_cinematic == UPLOAD, "real terminal enters the original S15 upload"):
		return
	await _play_upload()
	if _mode != "exit":
		await _settle(18)
		_check(GameState.has_flag(&"ch2_audit_submitted") and _audit_paid()
			and Progression.credits == _start_wallet + 250, "the original upload awards 250 and the one canonical receipt")
		_check(_store.read().get("story", {}).get("flags", {}).get("ch2_audit_submitted", false), "the finished upload is on disk")
		var gamepad := InputBindings.using_gamepad
		_check(not gamepad, "the control stream remains on its original keyboard family")
		_check(await _talk(&"ch2_terminal"), "the same terminal accepts a normal short revisit")
		_check(_played.has(String(REVISIT)) and _played.count(String(UPLOAD)) == 1
			and Progression.credits == _start_wallet + 250, "revisit never submits or pays a second time")
	_check(_beginning_items == StoryItems.snapshot(), "the scan retains all three copies, the original account, and the index")
	if _mode in ["before", "air", "cold"]:
		_check(not _press_seen and _clicks == 0 and _first_line, "without a physical contact the original full dialogue still works")
	elif _mode == "skip":
		_check(_press_seen and _clicks == 0 and not _first_line, "Escape during reach still uses the original immediate skip policy")
	else:
		_check(_press_seen and _contact_samples > 0 and _closest < 0.25 and _clicks == 1,
			"the true palm reaches the registered terminal button and emits exactly one contact sound")
		_check(_finish_samples > 0 and _max_finished_error < 0.25, "the pressed contact is physically aligned at completion")
	var record := FileAccess.open(_out_dir.path_join("round.json"), FileAccess.WRITE)
	if record == null:
		_main.call("_quit", 2)
		return
	record.store_string(JSON.stringify({"mode":_mode,"failures":_failures,"clicks":_clicks,"pressed":_press_seen,"contact_samples":_contact_samples,
		"minimum_contact_error":null if is_inf(_closest) else _closest,"max_finished_contact_error":_max_finished_error,"first_line":_first_line,
		"credit_delta":Progression.credits - _start_wallet,"scene":String(Story._current_cinematic),"recorded_scenes":_played}, "  "))
	record.close()
	_main.call("_quit", 1 if _failures > 0 else 0)


func _play_upload() -> void:
	var skipped := false
	for i in STEP_LIMIT:
		if Story._current_cinematic != UPLOAD:
			return
		var action: WorldPropAction = _level.player._visual.interaction_action
		if action != null and action.phase == "press":
			_press_seen = true
			var goal := action._prop_point("button")
			var palm := _level.player._visual.rig.hand_contact_global(&"front")
			var distance := palm.distance_to(goal)
			_contact_samples += 1
			_closest = minf(_closest, distance)
			if _mode == "skip" and not skipped:
				skipped = true
				var escape := InputEventKey.new()
				escape.keycode = KEY_ESCAPE
				escape.physical_keycode = KEY_ESCAPE
				escape.device = 16
				escape.pressed = true
				Input.parse_input_event(escape)
				Input.flush_buffered_events()
			if not _captured and distance <= 0.24:
				_captured = true
				await RenderingServer.frame_post_draw
				_capture("terminal-palm")
		if action != null and action.phase == "release" and action.contacts_completed == 1 and action._phase_started:
			_max_finished_error = maxf(_max_finished_error, action._from_hand.distance_to(action._prop_point("button")))
			_finish_samples += 1
			if _mode == "exit":
				_check(not GameState.has_flag(&"ch2_audit_submitted") and not _audit_paid()
					and Progression.credits == _start_wallet and not Story._completed.has(UPLOAD),
					"contact alone writes no outcome before the original dialogue completes")
				return
		var cutscene := Story._player
		if is_instance_valid(cutscene) and cutscene._dialogue.visible:
			cutscene._dialogue.complete()
			if not _first_line:
				_first_line = true
				await RenderingServer.frame_post_draw
				_capture("terminal-first-line")
			cutscene._advance_requested = true
		await get_tree().process_frame
	_check(false, "S15 leaves the active presentation before its bound")


func _interact() -> void:
	for event: InputEvent in InputMap.action_get_events(&"interact"):
		if event is InputEventKey:
			var key := event.duplicate() as InputEventKey
			key.pressed = true
			Input.parse_input_event(key)
			Input.flush_buffered_events()
			await get_tree().physics_frame
			await get_tree().physics_frame
			var release := key.duplicate() as InputEventKey
			release.pressed = false
			Input.parse_input_event(release)
			Input.flush_buffered_events()
			return
	_check(false, "the original input map supplies a keyboard event")


func _require(ok: bool, description: String) -> bool:
	_check(ok, description)
	if not ok:
		_main.call("_quit", 1)
	return ok


func _audit_paid() -> bool:
	return Progression.story_receipt_status(&"ch2.audit_settled").get("status") == "recorded"
