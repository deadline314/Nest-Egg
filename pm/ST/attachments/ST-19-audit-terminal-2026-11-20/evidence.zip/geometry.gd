extends Node


func _ready() -> void:
	var rig := CharacterRig.new()
	add_child(rig)
	if not rig.setup("rin"):
		get_tree().quit(1)
		return
	var input := RigInput.new()
	input.facing = 1
	input.aim_dir = Vector2.RIGHT
	input.on_floor = true
	input.hand_grip_front = true
	var target := Vector2(10.2, -24.65)
	for crouch: bool in [false,true]:
		input.crouching = crouch
		for i in 100:
			rig.animate(1.0 / 60.0,input)
		for x: float in [-11.0, -8.0, -5.5, -4.0, -2.0, 0.0, 2.0, 4.0]:
			rig.global_position.x = x
			for angle: float in [0.0, -20.0, 20.0, -40.0, 40.0, 60.0]:
				var best := INF
				var worst := 0.0
				var hits := 0
				for frame in 48:
					rig.animate(1.0 / 60.0,input)
					var ok := rig.place_hand(&"front",target,deg_to_rad(angle))
					var error := rig.hand_contact_global(&"front").distance_to(target)
					best = minf(best,error)
					worst = maxf(worst,error)
					hits += int(ok and error < 0.25)
				print(crouch, " x=", x, " tilt=", angle, " min=", best, " max=", worst, " hits=", hits)
	get_tree().quit()