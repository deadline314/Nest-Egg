from pathlib import Path
from hashlib import sha256
from subprocess import run
from shutil import copyfile
import json
import os
import sys

base = Path(__file__).resolve().parent
shared = base.parent/'ne218-baseline-20261117'
root=Path.cwd()
python = Path(sys.executable)
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
def render(case, scene, args, fixed):
    out=base/case
    out.mkdir(exist_ok=False)
    env=os.environ.copy()
    for key in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        var = out/'profile'/key
        var.mkdir(parents=True)
        env[key]=str(var)
    command = [str(python),str(shared/'tools/comfyui/gpu_lock.py'),'--',engine,
               '--path',str(shared),'--resolution','1280x720','--position','10,90',
               '--rendering-method','forward_plus','--rendering-driver','vulkan']
    if fixed:
        command.extend(('--fixed-fps','60'))
    command.append(str(scene))
    command.extend(('--',*[a.replace('{out}',out.as_posix()) for a in args]))
    (out/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result=run(command,cwd=shared,env=env,stdout=log,stderr=log,timeout=650)
    (out/'exit.txt').write_text(str(result.returncode)+'\n',encoding='utf-8')
    raw=(out/'raw.log').read_text(encoding='utf-8')
    print(case,result.returncode,len(raw),flush=True)
    assert result.returncode==0 and 'ERROR:' not in raw and 'RX 9070 XT' in raw
    return raw







mode=sys.argv[1]
assert mode in ('before','normal','exit','cold','air','skip','right'), mode
seed=base/'unsubmitted-slot.json'
slot=base/f'{mode}-slot.json'
assert seed.is_file() and not slot.exists()
copyfile(base/'exit-slot.json' if mode=='cold' else seed, slot)
text=render(mode,base/'terminal.tscn',['--out={out}',f'--mode={mode}',f'--slot={slot.as_posix()}'],True)
assert 'FAIL ' not in text
summary = json.loads((base/mode/'round.json').read_bytes())
game = json.loads(json.loads(slot.read_bytes())['payload'])
original = json.loads(json.loads(seed.read_bytes())['payload'])
assert summary['failures']==0 and game['story']['items']['held'] == original['story']['items']['held']
applied = mode != 'exit'
assert bool(game['story']['flags']['ch2_audit_submitted']) == applied
assert game['progression']['credits']==original['progression']['credits']+(250 if applied else 0)
assert ('ch2.audit_settled' in game['progression']['story_transactions']['receipts'])==applied
assert game['cinematic']==('ch2_t_s15_upload' if not applied else '')
(base/mode/'disk-receipt.json').write_text(json.dumps({'applied':applied,'credit_delta':game['progression']['credits']-original['progression']['credits'],
    'cinematic':game['cinematic'],'slot_sha256':sha256(slot.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf-8')
print(summary)