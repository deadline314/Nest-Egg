from pathlib import Path
from hashlib import sha256
import json

base = Path(__file__).resolve().parent
source = base.parent/'evidence-20261120-st19-guest-close/durable-skip/slot/slot.json'
old = source.read_bytes()
envelope = json.loads(old)
game = json.loads(envelope['payload'])
assert game['level'] == 'res://data/levels/ch2_lounge_front.tres' and not game['cinematic']
assert game['runtime']['world']['npc:ch2_terminal@16,19']['talks'] == 0
assert not game['progression']['story_transactions']['receipts'].get('ch2.audit_settled')
flags = game['story']['flags']
assert flags['ch2_original_ledger_taken'] and flags['ch2_egret_returned']
flags.update(ch2_audit_submitted=False, ch2_market_reconciled=True, ch2_market_contact_done=True)
for name in ('guest_ticket_answered', 'guest_band_answered', 'guest_letter_answered', 'ch2_guest_book_entered', 'guest_book_completed'):
    flags[name] = False
receipts = game['progression']['story_transactions']['receipts']
for tag in ('zheng','chen','hong'):
    game['progression']['credits'] -= receipts.pop('ch2.guest_'+tag)['credits_delta']
for name in ('contract', 'receipt', 'collection'):
    key = 'ch2_evidence_'+name
    flags[key] = True
    for slot in ('owned','held','unseen'):
        if key not in game['story']['items'][slot]:
            game['story']['items'][slot].append(key)
game['story']['seen'] = [tag for tag in game['story']['seen'] if not tag.startswith(('ch2_t_s15_', 'ch2_t_s17_', 'ch2_t_s18_','ch2_t_s19_', 'ch2_t_s20_','ch2_t_s21_'))]
game['runtime']['position'] = [241.0, 320.0]
game['runtime']['world']['npc:ch2_guest_entry@44,19']['talks'] = 0
payload = json.dumps(game,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
envelope['checksum'] = sha256(payload.encode('utf-8')).hexdigest()
envelope['payload'] = payload
fixture = base/'unsubmitted-slot.json'
fixture.write_text(json.dumps(envelope,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
(base/'fixture-receipt.json').write_text(json.dumps({'source_sha256':sha256(old).hexdigest(),'arranged_fixture_sha256':sha256(fixture.read_bytes()).hexdigest(),
    'original_credits':game['progression']['credits'],'prepared_conditions': ['reconcile','copies','before submission','near the original terminal']},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('prepared private audit fixture', envelope['checksum'])
