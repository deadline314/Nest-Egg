ST3 CI regression: fixed b2abac978cf6a14feaf254bb608b3779299fa89f.

Original CI artifact preserves patroller contract ten assertions / zero failures, exit0, but shared runtime_probe rejected its one expected Catalog rejection diagnostic. Product refusal is correct; no runtime Catalog changes.

Five CI runners have 22 deliberate protected-content mutations. Fixed full diagnostic text (whole line after Python str.strip() leading/trailing whitespace normalization, not raw-byte identity) and one occurrence per case must be declared by the Python caller, never by the probe result. Default remains zero diagnostics. All raw diagnostic lines/count stay visible; missing, repeated, unrelated ERROR or any SCRIPT ERROR must refuse.

Original home/recording metadata controls use existing FlagSources and need no allowance. Other existing completion owners do not mutate Catalog content. Full five original runners comprise 98 child cases including story_marker audit.
