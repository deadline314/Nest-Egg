from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
BASE="b2abac978cf6a14feaf254bb608b3779299fa89f"
GODOT=Path("C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe")
NAMES=["run_patroller_completion.py","run_ch2_evidence_completion.py","run_ch2_reading_completion.py","run_story_marker_completion.py","run_voice_completion.py"]
def save(name,obj):(OUT/name).write_bytes((json.dumps(obj,indent=2)+"\n").encode())
def snapshot():
 names=subprocess.check_output(["git","ls-files","-z"],cwd=ROOT).decode().split("\0")
 suffixes={".gd",".gdshader",".tscn",".tres",".json",".py",".uid",".yml",".yaml",".godot"}
 return {n:{"bytes":(ROOT/n).stat().st_size,"sha256":hashlib.sha256((ROOT/n).read_bytes()).hexdigest()} for n in names if n and Path(n).suffix in suffixes and not n.startswith(("pm/",".claude/",".agents/"))}
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT).decode().strip()==BASE
before=snapshot();save("source-before.json",before)
changed=subprocess.check_output(["git","diff","--name-only"],cwd=ROOT).decode().splitlines()
save("candidate.json",{"base":BASE,"files":{n:before[n] for n in changed},"projection":"Tracked .gd/.gdshader/.tscn/.tres/.json/.py/.uid/.yml/.yaml/.godot, excluding PM and skill documentation. Not whole-repo raw-asset hashing."})
(OUT/"candidate.diff").write_bytes(subprocess.check_output(["git","diff","--binary"],cwd=ROOT))
env=os.environ.copy();env["PYTHONIOENCODING"]="utf-8"
for key in ("APPDATA","LOCALAPPDATA","USERPROFILE","TMP","TEMP"):
 path=OUT/"outer-environment"/key;path.mkdir(parents=True,exist_ok=True);env[key]=str(path)
commands=[("unit-windows",[sys.executable,"tools/test_runtime_probe.py"]),("unit-posix",["wsl.exe","-d","Ubuntu","--cd","/mnt/d/NestEggVerification/st3-ci-contracts-20261113","python3","tools/test_runtime_probe.py"]),("selector",[sys.executable,"tools/select_tests.py","--base",BASE,"--explain"]),("changed",["C:/Program Files/Git/bin/bash.exe","tools/run_tests_changed.sh",BASE])]
commands += [(name.removeprefix("run_").removesuffix(".py"),[sys.executable,"tools/"+name,"--godot",str(GODOT),"--output",str(OUT/name.removesuffix(".py"))]) for name in NAMES]
rows=[]
for label,command in commands:
 start=time.monotonic();save(label+"-command.json",{"argv":command,"cwd":str(ROOT),"environment":{k:env[k] for k in ("APPDATA","LOCALAPPDATA","USERPROFILE","TMP","TEMP","PYTHONIOENCODING")}})
 with (OUT/(label+"-stdout.log")).open("wb") as log:result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={"label":label,"exit":result.returncode,"seconds":round(time.monotonic()-start,3)};rows.append(row);save("progress.json",rows);print(json.dumps(row),flush=True)
 if result.returncode:break
 after_check=snapshot()
 if after_check != before:
  save("unexpected-source-drift.json",after_check);raise SystemExit("SOURCE DRIFT")
after=snapshot();save("source-after.json",after)
save("exit.json",{"all_commands_completed":len(rows)==len(commands),"commands":rows,"source_fixed":before==after,"source_count":len(before),"engine":"Original 4.7.2 console executable via original headless Dummy CI callers; no adapter/GPU","passed":len(rows)==len(commands) and all(r["exit"]==0 for r in rows) and before==after})
raise SystemExit(0 if len(rows)==len(commands) and all(r["exit"]==0 for r in rows) and before==after else 1)
