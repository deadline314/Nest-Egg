import os
import difflib, hashlib, json, subprocess, sys
from pathlib import Path
root=Path(os.environ.get('ST2_CANDIDATE_ROOT', 'D:/NestEggVerification/st2-localization-fix-20261112'))
proof=Path(__file__).resolve().parent
label=sys.argv[1]
tracked=subprocess.check_output(['git','diff','--name-only','-z','HEAD'],cwd=root).decode('utf-8').strip('\0').split('\0')
untracked=[p for p in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode('utf-8').split('\0') if p]
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=root)
for name in untracked:
    if name != 'tools/story/test_story_i18n.py':
        raise RuntimeError('Unowned untracked file: '+name)
    text=(root/name).read_text(encoding='utf-8')
    addition='diff --git a/{0} b/{0}\nnew file mode 100644\n'.format(name)
    addition+=''.join(difflib.unified_diff([],text.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+name))
    patch+=addition.encode('utf-8')
(proof/(label+'.patch')).write_bytes(patch)
manifest={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),
          'branch':subprocess.check_output(['git','branch','--show-current'],cwd=root).decode().strip(),
          'tree':str(root),'patch_sha256':hashlib.sha256(patch).hexdigest(),'files':[]}
for name in tracked+untracked:
    baseline=None if name in untracked else hashlib.sha256(subprocess.check_output(['git','show','HEAD:'+name],cwd=root)).hexdigest()
    manifest['files'].append({'path':name,'absolute_path':str(root/name),'before_sha256':baseline,'after_sha256':hashlib.sha256((root/name).read_bytes()).hexdigest()})
(proof/(label+'-manifest.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'patch':str(proof/(label+'.patch')),'bytes':len(patch),'sha256':manifest['patch_sha256'],'files':len(manifest['files'])}))
