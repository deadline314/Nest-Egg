import os
import copy, hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
root = Path(os.environ.get('ST2_CANDIDATE_ROOT', 'D:/NestEggVerification/st2-localization-fix-20261112'))
proof = Path(__file__).resolve().parent
sys.path.insert(0, str(root/'tools/story'))
import story_i18n

def original(path):
    return subprocess.check_output(['git','show','4a2f9ecfaf3d98db102e79b37420821f714549ca:'+path], cwd=root)

def json_original(path):
    return json.loads(original(path).decode('utf-8'))

path = 'data/story/ch1_kasa.json'
before = json_original(path)
after = json.loads((root/path).read_text(encoding='utf-8'))
clean = copy.deepcopy(after)
steps = clean['scenes']['ch1_p01_door']['steps']
new_fields = {'/scenes/ch1_p01_door/steps/1/lines_ja': steps[1].pop('lines_ja'),
              '/scenes/ch1_p01_door/steps/1/lines_en': steps[1].pop('lines_en'),
              '/scenes/ch1_p01_door/steps/2/sub_ja': steps[2].pop('sub_ja'),
              '/scenes/ch1_p01_door/steps/2/sub_en': steps[2].pop('sub_en')}
term_path = '/scenes/ch1_p01_door/steps/11/ja'
old_term = before['scenes']['ch1_p01_door']['steps'][11]['ja']
new_term = clean['scenes']['ch1_p01_door']['steps'][11]['ja']
assert new_term == old_term.replace('巢蛋当舗', '巣卵質店')
clean['scenes']['ch1_p01_door']['steps'][11]['ja'] = old_term
assert clean == before, 'Any source value or other existing metadata changed beyond the reviewed Japanese shop name'
table_path = 'tools/story/i18n/ch1_kasa.json'
old_table = json_original(table_path)
new_table = json.loads((root/table_path).read_text(encoding='utf-8'))
shoe = '先把鞋擦乾。巢蛋當舖收貨，不收你一路踩進來的水。'
assert {k for k,v in old_table.items() if new_table[k] != v} == {shoe}
assert new_table[shoe] == {**old_table[shoe], 'ja': old_table[shoe]['ja'].replace('巢蛋当舗', '巣卵質店')}
new_table_keys = sorted(set(new_table)-set(old_table))
assert len(new_table_keys) == 2
assert set(old_table)-set(new_table) == set()
old_module = importlib.util.module_from_spec(importlib.util.spec_from_loader('story_i18n_before',loader=None))
old_module.__file__ = str(root/'tools/story/story_i18n.py')
exec(compile(original('tools/story/story_i18n.py'), 'story_i18n_before.py', 'exec'), old_module.__dict__)
old_entries = [*old_module._speaker_names(before), *old_module.walk(before)]
new_entries = [*story_i18n._speaker_names(after), *story_i18n.walk(after)]
raw_missing = story_i18n.apply(copy.deepcopy(before), {})
after_missing = story_i18n.apply(copy.deepcopy(after), {})
assert len(new_entries) == len(old_entries) + 2
assert len(raw_missing) == 4 and len(after_missing) == 0
assert story_i18n.missing_strings(before, old_table) == new_table_keys or sorted(story_i18n.missing_strings(before, old_table)) == new_table_keys
assert story_i18n.missing_strings(after, new_table) == []
# Preserve all existing JA/EN authored overrides, not only translated table content.
overrides=[]
for p, owner, field, zh in old_entries:
    for lang in ('ja','en'):
        old_value=old_module._localized_key(field,lang)
        if owner.get(old_value) and owner.get(old_value) != old_table.get(zh,{}).get(lang):
            overrides.append({'path':p,'language':lang,'value':owner[old_value]})
for entry in overrides:
    node=after
    for token in entry['path'].split('/')[1:-1]:
        node=node[int(token)] if isinstance(node,list) else node[token]
    field=entry['path'].split('/')[-1]
    assert node[story_i18n._localized_key(field,entry['language'])] == entry['value']
old_test=original('tests/suite/test_story_lint.gd').decode('utf-8')
new_test=(root/'tests/suite/test_story_lint.gd').read_text(encoding='utf-8')
start=old_test.index('func _test_locale()')
end=old_test.index('\n\n\n#',start)
assert old_test[start:end] in new_test
paths=['core/story_locale.gd','tools/story/story_i18n.py','tools/story/i18n/ch1_kasa.json','data/story/ch1_kasa.json','tests/suite/test_story_lint.gd','tools/story/test_story_i18n.py','design/13-story-v2/DIALOGUE_READABILITY.md']
allowed=set(paths)
changed=subprocess.check_output(['git','diff','--name-only','-z','HEAD'],cwd=root).decode('utf-8').strip('\0').split('\0')
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode('utf-8').strip('\0').split('\0')
assert set(changed+untracked) <= allowed, changed+untracked
report={'base':'4a2f9ecfaf3d98db102e79b37420821f714549ca','new_metadata':new_fields,
        'reviewed_japanese_shop_name':{'path':term_path,'table_source_key':shoe,'before':old_term,'after':new_term},
        'all_other_existing_story_values_identical':True,'all_other_existing_table_entries_identical':True,
        'existing_locale_assertions_identical':True,'old_visible_occurrences':len(old_entries),
        'old_unique_chinese':len({entry[3] for entry in old_entries}),
        'new_visible_occurrences':len(new_entries),'new_unique_chinese':len({entry[3] for entry in new_entries}),
        'before_missing_after_schema_fix_no_table':raw_missing,'after_missing_no_table':after_missing,
        'new_table_keys':new_table_keys,'table_entries_before':len(old_table),'table_entries_after':len(new_table),
        'preserved_authored_overrides':overrides,
        'candidate_files':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths]}
(proof/'integrity.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
