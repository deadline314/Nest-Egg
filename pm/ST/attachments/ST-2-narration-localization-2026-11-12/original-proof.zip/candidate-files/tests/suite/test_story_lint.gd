class_name StoryLintSuite
extends TestSuite
## 劇本品質檢查（NE-49）：檢查器本身（好句通過、壞句被抓到、等級與門檻正確）、
## 所有章節劇本與道具文字通過檢查、整合進 Story.validate()。

const SPEAKERS := {
	"rin": {"name": "凜"},
	"mei": {"name": "芽"},
	"old_k": {"name": "老K"},
	"warden": {"name": "監管者", "formal": true},
	"system": {"name": "天穹廣播", "formal": true},
}


func run() -> void:
	_test_good_lines_pass()
	_test_readability()
	_test_player_text_catalog()
	_test_teaching_words()
	_test_contrast_patterns()
	_test_punctuation_limits()
	_test_written_connectives()
	_test_grand_words()
	_test_sentence_length()
	_test_abstract_nouns_and_voices()
	_test_all_scripts_pass()
	_test_items_pass()
	_test_story_validation_integration()
	_test_locale()
	_test_locale_narration()


## ST-2：三語欄位。選了日文就換成日文；缺日文退回英文，再缺退回中文，並記下位置；宣告三語的章節會列出缺譯。
func _test_locale() -> void:
	var data := {"chapter": {"id": "t", "title": "測試章", "title_ja": "テスト章", "title_en": "Test Chapter", "languages": ["zh", "ja", "en"]},
		"scenes": {"a": {"mode": "dialogue", "when": {"flag": "中文旗標"}, "lines": [
			{"speaker": "rin", "text": "我先去核對收據。", "ja": "先に領収書を確かめる。", "en": "I'll check the receipt first."},
			{"speaker": "rin", "text": "只有英文的一句。", "en": "Only English here."},
			{"speaker": "rin", "text": "沒有譯文的一句。"}]},
			"b": {"mode": "animated", "steps": [{"do": "choice", "text": "要怎麼做？", "ja": "どうする？", "en": "What now?", "options": [
				{"id": "x", "text": "先問她。", "ja": "まず聞く。", "en": "Ask her first.", "explanation": "不影響主線。", "explanation_en": "No effect on the main story."}]}]}}}
	check(StoryLocale.audit(data).size() == 4, "the audit lists every missing Japanese or English field: %s" % [StoryLocale.audit(data)])
	var ja: Dictionary = data.duplicate(true)
	var missing := StoryLocale.localize(ja, "ja")
	var lines: Array = ja["scenes"]["a"]["lines"]
	check(lines[0]["text"] == "先に領収書を確かめる。" and ja["chapter"]["title"] == "テスト章", "Japanese replaces the Chinese text")
	check(lines[1]["text"] == "Only English here." and lines[2]["text"] == "沒有譯文的一句。", "a missing Japanese line falls back to English, then to Chinese")
	var option: Dictionary = ja["scenes"]["b"]["steps"][0]["options"][0]
	check(option["text"] == "まず聞く。" and option["explanation"] == "No effect on the main story.", "options and their explanations are localized too")
	check(missing.size() == 3 and missing[0].contains("/scenes/a/lines/1/text"), "each fallback is reported with its location: %s" % [missing])
	check(ja["scenes"]["a"]["when"]["flag"] == "中文旗標", "conditions and flags are never translated")
	check(StoryLocale.localize(data.duplicate(true), "zh").is_empty() and StoryLocale.localize(data.duplicate(true), "xx").is_empty(), "Chinese and unknown languages leave the text alone")
	# 真劇本：切到英文再切回來，章節標題跟著換，進度不受影響。
	var title_zh := str(Story.chapter_info(&"ch1_kasa").get("title", ""))
	check(not Story.set_language("xx") and Story.language == "zh", "an unsupported language is refused")
	check(Story.set_language("en") and str(Story.chapter_info(&"ch1_kasa").get("title", "")) != title_zh, "switching to English reloads the chapter in English")
	check(str(Story._speakers.get("rin", {}).get("name", "")) == "Rin" and str(Story._speakers.get("lamp", {}).get("name", "")) == "Wick", "speaker nameplates switch language too")
	check(Story.set_language("zh") and str(Story.chapter_info(&"ch1_kasa").get("title", "")) == title_zh and str(Story._speakers["rin"]["name"]) == "凜", "switching back restores the Chinese text")


func _test_locale_narration() -> void:
	var data := {"scenes": {"opening": {"steps": [
		{"do": "narrate", "lines": ["雨沒有停過。", "只有英文的一句。", "沒有譯文的一句。", 17, {"id": "中文代碼"}],
			"lines_ja": ["雨は降り続いていた。", " ", {"bad": true}, 17, {"id": "中文代碼"}],
			"lines_en": ["The rain never stopped.", "Only English here.", "", 17, {"id": "中文代碼"}]},
		{"do": "title", "sub": "巢蛋當舖", "sub_ja": {"bad": true}, "sub_en": "Nest Egg Pawnshop"},
		{"do": "title", "sub": "保留中文副標", "sub_ja": 12, "sub_en": ["bad"]},
		{"do": "flags", "lines": ["中文代碼"]}],
		"when": {"text": "中文條件"}, "set_flags": ["中文旗標"]}}}
	var audit := StoryLocale.audit(data)
	check(audit.size() == 6 and audit.has("/scenes/opening/steps/0/lines/1（缺日文）") and audit.has("/scenes/opening/steps/1/sub（缺日文）"), "narration and subtitle audit validates types at their exact source paths: %s" % [audit])
	check(StoryLocale.report("res://data/story/fixture.json", audit, "缺譯").contains("res://data/story/fixture.json"), "missing narration reports retain their source file")
	var ja: Dictionary = data.duplicate(true)
	var missing := StoryLocale.localize(ja, "ja")
	var steps: Array = ja["scenes"]["opening"]["steps"]
	check(steps[0]["lines"].slice(0, 3) == ["雨は降り続いていた。", "Only English here.", "沒有譯文的一句。"], "narration localizes each string with Japanese, English, then Chinese fallback")
	check(steps[0]["lines"].slice(3) == [17, {"id": "中文代碼"}] and steps[3]["lines"] == ["中文代碼"], "mixed narration values and non-narration string arrays remain intact")
	check(steps[1]["sub"] == "Nest Egg Pawnshop" and steps[2]["sub"] == "保留中文副標", "subtitle rejects non-string translations and falls back safely")
	check(missing.size() == 4 and missing.has("/scenes/opening/steps/0/lines/1（ja，改用英文）") and missing.has("/scenes/opening/steps/0/lines/2（ja，保留中文）") and missing.has("/scenes/opening/steps/1/sub（ja，改用英文）"), "each narration/subtitle fallback records the precise path and chosen language: %s" % [missing])
	check(ja["scenes"]["opening"]["when"] == data["scenes"]["opening"]["when"] and ja["scenes"]["opening"]["set_flags"] == ["中文旗標"], "narration localization preserves conditions and flags")
	for bad: Variant in ["wrong container", [], ["wrong length"]]:
		var malformed := {"scenes": {"opening": {"steps": [{"do": "narrate", "lines": ["原文一。", "原文二。"], "lines_ja": bad, "lines_en": bad}]}}}
		var bad_missing := StoryLocale.localize(malformed, "ja")
		check(malformed["scenes"]["opening"]["steps"][0]["lines"] == ["原文一。", "原文二。"] and bad_missing.size() == 2 and bad_missing[1].begins_with("/scenes/opening/steps/0/lines/1"), "wrong narration container/length preserves both source strings and reports each index: %s" % [bad])
	# 真序章與語言切換：同時保留 seen-only、completed 與世界旗標。
	var seen_before := Story._seen.duplicate(true)
	var completed_before := Story._completed.duplicate(true)
	var flags_before := GameState.world_flags.duplicate(true)
	Story._completed.erase(&"ch1_p02_talk")
	Story._seen[&"ch1_p02_talk"] = true
	Story._seen[&"ch1_p01_door"] = true
	Story._completed[&"ch1_p01_door"] = true
	GameState.world_flags["test_locale_progress"] = 7
	var expected_seen := Story._seen.duplicate(true)
	var expected_completed := Story._completed.duplicate(true)
	var expected_flags := GameState.world_flags.duplicate(true)
	var narration := {"zh": "沉港市的下層港區，雨沒有停過，水位每晚都在漲。", "ja": "沈港市の下層の港湾区では、雨が降りやまず、水位は毎晩上がり続けている。", "en": "In Sinkport's lower docks, the rain never stops, and the water rises every night."}
	var subtitles := {"zh": "巢蛋當舖", "ja": "巣卵質店", "en": "Nest Egg Pawnshop"}
	for language: String in ["ja", "en", "zh"]:
		check(Story.set_language(language), "the prologue supports %s" % language)
		var opening: Array = Story._scenes["ch1_p01_door"]["steps"]
		check(opening[1]["lines"][0] == narration[language] and opening[2]["sub"] == subtitles[language], "real prologue narration and subtitle display %s" % language)
		if language == "ja":
			check(str(opening[11]["text"]).contains(subtitles["ja"]), "the Japanese prologue subtitle and Old K dialogue use the same pawnshop name")
		check(Story._seen == expected_seen and Story._completed == expected_completed and GameState.world_flags == expected_flags, "switching to %s preserves seen/completed/world_flags snapshots" % language)
	Story._seen.assign(seen_before)
	Story._completed.assign(completed_before)
	GameState.world_flags = flags_before


# ---------------------------------------------------------------------------
# 工具
# ---------------------------------------------------------------------------

func _say(speaker: String, text: String) -> Dictionary:
	return {"speaker": speaker, "text": text}


func _unit(lines: Array) -> Array[Dictionary]:
	return StoryLint.check_unit("測試", lines, SPEAKERS)


func _rules(issues: Array[Dictionary]) -> PackedStringArray:
	var rules := PackedStringArray()
	for issue in issues:
		rules.append(str(issue["rule"]))
	return rules


func _has_rule(issues: Array[Dictionary], rule: String, level: int) -> bool:
	for issue in StoryLint.with_rule(issues, rule):
		if int(issue["level"]) == level:
			return true
	return false


# ---------------------------------------------------------------------------
# 檢查器本身
# ---------------------------------------------------------------------------

func _test_good_lines_pass() -> void:
	# 風格指南「好」的寫法都必須通過。
	var good: Array = [
		_say("mei", "巷口有兩個人。你要是被打到我下個月的薪水就沒了。"),
		_say("rin", "貴的比較不會動。"),
		_say("old_k", "四萬三。"),
		_say("rin", "差多少。"),
		_say("old_k", "你自己不會算喔。"),
		_say("rin", "這次不用偷什麼。去接他而已。"),
		_say("warden", "七號小姐，您終於來取回它了。路上辛苦。"),
		_say("mei", "貨櫃那邊有東西在發熱。……我是說比你還熱。"),
		_say("system", "天穹集團提醒您，今日降雨持續。為您準備的傘，已放在每一個轉角。"),
	]
	check(_unit(good).is_empty(), "good lines from the style guide pass: %s" % [_rules(_unit(good))])
	check(_unit([]).is_empty(), "an empty unit passes")
	check(StoryLint.sentence_length("你好，世界") == 5 and StoryLint.split_sentences("一。二！三？四").size() == 4, "sentence splitting counts 。！？ and the tail")
	check(StoryLint.split_sentences("好……真的，可以嗎").size() == 1, "ellipsis and commas do not split a sentence")


func _test_teaching_words() -> void:
	for word in StoryLint.TEACHING_WORDS:
		var issues := _unit([_say("mei", "你看，這個%s不太對。" % word)])
		check(_has_rule(issues, "教學詞", StoryLint.Level.ERROR), "teaching word is an error: %s" % word)
	# 原本劇本裡的壞句子。
	check(_has_rule(_unit([_say("mei", "巷口有兩個天穹保全。紅色瞄準線一亮就閃，或者舉盾擋回去。")]), "教學詞", StoryLint.Level.ERROR), "the old tutorial line is caught")
	check(StoryLint.with_rule(_unit([_say("mei", "盾牌那隻看起來很貴欸。")]), "教學詞").is_empty(), "a normal line has no teaching word")


func _test_contrast_patterns() -> void:
	var bad := [
		"不是偷東西，是去接我弟弟回家。",
		"這不是治療，這是實驗。",
		"他不是壞人，而是被逼的。",
		"不是為了錢而是為了他。",
		"不是他，是我。",
	]
	for text in bad:
		check(_has_rule(_unit([_say("rin", text)]), "對比句型", StoryLint.Level.ERROR), "contrast pattern is an error: %s" % text)
	var fine := ["我不是去偷東西。", "他不是我弟。我們沒有血緣。", "這不是我的，我不要。", "不是每個人都有傘。"]
	for text in fine:
		check(StoryLint.with_rule(_unit([_say("rin", text)]), "對比句型").is_empty(), "a plain negation is fine: %s" % text)


func _test_punctuation_limits() -> void:
	# 破折號：一個場景最多 1 次，廣告與公文（formal 講者）除外。
	check(StoryLint.with_rule(_unit([_say("rin", "等等——")]), "破折號").is_empty(), "one dash is allowed")
	check(_has_rule(_unit([_say("rin", "等等——"), _say("mei", "什麼——")]), "破折號", StoryLint.Level.ERROR), "two dashes in a scene are an error")
	check(StoryLint.with_rule(_unit([_say("system", "請注意——"), _say("system", "請注意——"), _say("system", "請注意——")]), "破折號").is_empty(), "formal speakers are exempt from the dash limit")
	# 省略號：最多 2 次，半形三點也算。
	check(StoryLint.with_rule(_unit([_say("rin", "……"), _say("rin", "嗯……")]), "省略號").is_empty(), "two ellipses are allowed")
	check(_has_rule(_unit([_say("rin", "……"), _say("rin", "嗯……"), _say("mei", "喔……")]), "省略號", StoryLint.Level.ERROR), "three ellipses are an error")
	check(_has_rule(_unit([_say("rin", "……"), _say("rin", "嗯..."), _say("mei", "喔......")]), "省略號", StoryLint.Level.ERROR), "ASCII dots count as ellipses")
	check(StoryLint.with_rule(_unit([_say("rin", "………………")]), "省略號").is_empty(), "one long run of dots is a single ellipsis")
	# 驚嘆號：最多 1 個，全形半形都算。
	check(StoryLint.with_rule(_unit([_say("rin", "快跑！")]), "驚嘆號").is_empty(), "one exclamation mark is allowed")
	check(_has_rule(_unit([_say("rin", "快跑！"), _say("mei", "等等！")]), "驚嘆號", StoryLint.Level.ERROR), "two exclamation marks are an error")
	check(_has_rule(_unit([_say("rin", "快跑!"), _say("mei", "等等！")]), "驚嘆號", StoryLint.Level.ERROR), "half-width marks count too")


func _test_written_connectives() -> void:
	for word in StoryLint.WRITTEN_CONNECTIVES:
		var spoken := _unit([_say("rin", "%s他沒來。" % word)])
		check(_has_rule(spoken, "書面連接詞", StoryLint.Level.ERROR), "written connective is an error in speech: %s" % word)
		var formal := _unit([_say("warden", "%s請隨我來。" % word)])
		check(StoryLint.with_rule(formal, "書面連接詞").is_empty(), "the warden and broadcasts may use it: %s" % word)


func _test_grand_words() -> void:
	var two := [{"id": "a", "lines": [_say("rin", "命運。"), _say("mei", "靈魂。")]}]
	check(StoryLint.with_rule(StoryLint.check_chapter("c", two, SPEAKERS), "空泛大詞").is_empty(), "two grand words per chapter are allowed")
	var three := [{"id": "a", "lines": [_say("rin", "命運。")]}, {"id": "b", "lines": [_say("mei", "靈魂。"), _say("mei", "彷彿。")]}]
	var issues := StoryLint.check_chapter("c", three, SPEAKERS)
	check(_has_rule(issues, "空泛大詞", StoryLint.Level.ERROR), "a third grand word in the chapter is an error")
	check(StoryLint.with_rule(issues, "空泛大詞")[0]["message"].contains("a（命運）"), "the message names where each one is")
	for word in StoryLint.GRAND_WORDS:
		var many := [{"id": "x", "lines": [_say("rin", word), _say("rin", word), _say("rin", word)]}]
		check(_has_rule(StoryLint.check_chapter("c", many, SPEAKERS), "空泛大詞", StoryLint.Level.ERROR), "grand word is tracked: %s" % word)


func _test_sentence_length() -> void:
	var forty := "字".repeat(40)
	var forty_one := "字".repeat(41)
	var fifty_six := "字".repeat(56)
	var fifty_seven := "字".repeat(57)
	check(_unit([_say("mei", forty + "。")]).is_empty(), "a 40 character sentence passes")
	var warn := _unit([_say("mei", forty_one + "。")])
	check(_has_rule(warn, "單句長度", StoryLint.Level.WARNING) and not _has_rule(warn, "單句長度", StoryLint.Level.ERROR), "41 characters is a warning")
	var still_warn := _unit([_say("mei", fifty_six + "。")])
	check(not _has_rule(still_warn, "單句長度", StoryLint.Level.ERROR), "56 characters is still only a warning")
	check(_has_rule(_unit([_say("mei", fifty_seven + "。")]), "單句長度", StoryLint.Level.ERROR), "57 characters is an error")
	# 句子以。！？斷開，所以兩個 30 字的句子沒問題。
	check(_unit([_say("mei", "字".repeat(30) + "。" + "字".repeat(30) + "。")]).is_empty(), "two 30 character sentences pass")
	check(StoryLint.errors_of(warn).is_empty() and StoryLint.warnings_of(warn).size() == 1, "errors_of and warnings_of split by level")
	check(StoryLint.format(warn[0]).begins_with("[警告／單句長度]"), "the message says level, rule and place: %s" % StoryLint.format(warn[0]))


func _test_abstract_nouns_and_voices() -> void:
	var four := [{"id": "a", "lines": [_say("rin", "希望。"), _say("rin", "絕望。"), _say("rin", "代價。"), _say("rin", "未來。")]}]
	check(StoryLint.with_rule(StoryLint.check_chapter("c", four, SPEAKERS), "抽象名詞密度").is_empty(), "four abstract nouns are allowed")
	var five := [{"id": "a", "lines": [_say("rin", "我還抱著希望。別讓我失去希望。"), _say("rin", "他滿臉絕望。"), _say("rin", "我付得起代價。"), _say("rin", "他還有未來。")]}]
	var dense := StoryLint.check_chapter("c", five, SPEAKERS)
	check(_has_rule(dense, "抽象名詞密度", StoryLint.Level.WARNING) and StoryLint.errors_of(dense).is_empty(), "five abstract nouns are a warning, not an error")
	# 同一個講者連續 3 句都很長：警告；中間換人就不算。
	var long_text := "字".repeat(30) + "。"
	var streak := _unit([_say("mei", long_text), _say("mei", long_text), _say("mei", long_text)])
	check(_has_rule(streak, "講者長度", StoryLint.Level.WARNING), "three long lines in a row from one speaker is a warning")
	var broken := _unit([_say("mei", long_text), _say("mei", long_text), _say("rin", "嗯。"), _say("mei", long_text)])
	check(StoryLint.with_rule(broken, "講者長度").is_empty(), "another speaker in between resets the streak")
	var once := _unit([_say("mei", long_text), _say("mei", long_text), _say("mei", long_text), _say("mei", long_text)])
	check(StoryLint.with_rule(once, "講者長度").size() == 1, "a long streak is reported once")
	# 凜的句子應明顯短於芽：太長時提醒人工檢視；資料太少不檢查。
	var rin_long: Array = []
	var mei_short: Array = []
	for i in 4:
		rin_long.append(_say("rin", "這是一句比較長的話啊。"))
		mei_short.append(_say("mei", "短短的。"))
	var voices := StoryLint.check_chapter("c", [{"id": "a", "lines": rin_long + mei_short}], SPEAKERS)
	check(_has_rule(voices, "講者一致", StoryLint.Level.WARNING), "rin talking longer than mei is flagged for review")
	var fine: Array = []
	for i in 4:
		fine.append(_say("rin", "嗯。"))
		fine.append(_say("mei", "這是一句比較長的話啊，連珠炮。"))
		fine.append(_say("warden", "您好，請隨我來，路上辛苦了。"))
	check(StoryLint.with_rule(StoryLint.check_chapter("c", [{"id": "a", "lines": fine}], SPEAKERS), "講者一致").is_empty(), "a short-spoken rin passes")
	check(StoryLint.with_rule(StoryLint.check_chapter("c", [{"id": "a", "lines": [_say("rin", "很長很長很長的一句話啊。"), _say("mei", "短。")]}], SPEAKERS), "講者一致").is_empty(), "too little data is not judged")


# ---------------------------------------------------------------------------
# 實際劇本
# ---------------------------------------------------------------------------

func _test_all_scripts_pass() -> void:
	var issues := Story.lint()
	var errors := StoryLint.errors_of(issues)
	var lines := PackedStringArray()
	for issue in issues:
		lines.append(StoryLint.format(issue))
	check(errors.is_empty(), "every script scene passes the quality check: %s" % ["\n".join(lines)])
	check(issues.is_empty(), "the scripts also have no warnings: %s" % ["\n".join(lines)])
	check(Story.validate().is_empty(), "Story.validate() is clean: %s" % [Story.validate()])
	# 檢查範圍：每個章節的所有場景與章節卡都有被掃到。
	for chapter_id in Story.chapter_ids():
		var units := Story.text_units(chapter_id)
		var scene_units := 0
		var card := false
		for unit in units:
			if str(unit["id"]).ends_with("章節卡"):
				card = true
				check((unit["lines"] as Array).size() == 4, "the chapter card checks title, subtitle, end title and teaser: %s" % chapter_id)
			else:
				scene_units += 1
		check(card and scene_units >= 10, "%s: %d scenes and the chapter card are scanned" % [chapter_id, scene_units])
	var scanned := 0
	for chapter_id in Story.chapter_ids():
		scanned += Story.text_units(chapter_id).size()
	# 每個場景（加上它的死亡次數變化）與每張章節卡剛好各掃一次。
	var expected := Story.scene_ids().size() + Story.chapter_ids().size()
	for id: String in Story.scene_ids():
		expected += StoryReactions.variants_of(Story._scenes[id]).size()
	check(scanned == expected, "every scene, death variant and chapter card is scanned exactly once (%d of %d)" % [scanned, expected])
	# 章節卡的預告文字沒有破折號。
	for chapter_id in Story.chapter_ids():
		check(not str(Story.chapter_info(chapter_id).get("teaser", "")).contains("——"), "the teaser has no dash: %s" % chapter_id)


func _test_items_pass() -> void:
	var issues := StoryItems.lint()
	var lines := PackedStringArray()
	for issue in issues:
		lines.append(StoryLint.format(issue))
	check(issues.is_empty(), "every story item text passes the quality check: %s" % ["\n".join(lines)])
	for item in StoryItems.catalog():
		if item.is_collectible():
			check(item.body.length() <= StoryItemData.MAX_BODY_LENGTH, "item text fits the inventory (220 characters): %s %d" % [item.id, item.body.length()])
	# 壞的道具文字會被抓到。
	var units: Array[Dictionary] = [{"id": "道具 test_bad", "lines": [{"speaker": "", "text": "然而這是命運。命運，注定。"}]}]
	var bad := StoryLint.check_chapter("道具文字", units, {})
	check(_has_rule(bad, "書面連接詞", StoryLint.Level.ERROR) and _has_rule(bad, "空泛大詞", StoryLint.Level.ERROR), "bad item text is caught")


func _test_story_validation_integration() -> void:
	# 在章節裡塞一個壞場景：validate() 會指出是哪個場景、哪一句、什麼規則。
	Story._scenes["test_lint_scene"] = {"mode": "radio", "lines": [{"speaker": "rin", "text": "鎖定目標！"}, {"speaker": "mei", "text": "不是他，是我！"}]}
	Story._scene_chapter["test_lint_scene"] = &"chapter_01"
	var problems := Story.validate()
	var joined := "\n".join(problems)
	check(joined.contains("test_lint_scene 第 1 句") and joined.contains("教學詞"), "validate() points at the scene, line and rule: %s" % joined)
	check(joined.contains("對比句型") and joined.contains("驚嘆號"), "validate() reports every rule that was broken")
	Story._scenes.erase("test_lint_scene")
	Story._scene_chapter.erase("test_lint_scene")
	check(Story.validate().is_empty(), "validate() is clean again after removing the bad scene")
	# 動畫場景的 say 與 narrate 也在檢查範圍內。
	Story._scenes["test_lint_anim"] = {"mode": "animated", "steps": [
		{"do": "say", "speaker": "rin", "text": "快跑！"}, {"do": "say", "speaker": "mei", "text": "等等！"},
		{"do": "narrate", "lines": ["然而天亮了。"]},
	]}
	Story._scene_chapter["test_lint_anim"] = &"chapter_01"
	var anim_rules := _rules(StoryLint.errors_of(Story.lint()))
	check(anim_rules.has("驚嘆號"), "animated say steps are checked")
	Story._scenes.erase("test_lint_anim")
	Story._scene_chapter.erase("test_lint_anim")
	# 章節卡文字也會被檢查。
	var info: Dictionary = Story._chapters[&"chapter_01"]
	var original: Variant = info.get("teaser", "")
	info["teaser"] = "下一章——命運——"
	check(_has_rule(Story.lint(), "破折號", StoryLint.Level.ERROR), "chapter card text is checked")
	info["teaser"] = original
	check(StoryLint.errors_of(Story.lint()).is_empty(), "the chapter card is clean again")


func _test_readability() -> void:
	for bad in ["嗯。", "地點，碼頭倉庫。目標，資料盤。", "上面。我不問，你別問。", "一？你運氣好。吃什麼？餐，酒？"]:
		check(not StoryLint.readability(bad, "fixture").is_empty(), "fragmented prose fails: %s" % bad)
	check(_has_rule(StoryLint.readability("走吧。別問。", "fixture"), "短句並列", StoryLint.Level.WARNING), "two short sentences warn")
	check(_has_rule(StoryLint.readability("走吧。別問。快走。", "fixture"), "短句並列", StoryLint.Level.ERROR), "three short sentences error")
	check(_has_rule(StoryLint.readability("地點，碼頭倉庫。", "fixture"), "名詞斷句", StoryLint.Level.WARNING), "noun-led briefing warns")
	for good in ["好，我先去碼頭倉庫。", "一個灰衣人開貨車送你來，沒收錢就走了。", "記錄時間是 03:12，回收獎勵為 91,000 信用點。"]:
		check(StoryLint.readability(good, "fixture").is_empty(), "complete prose and numeric punctuation pass: %s" % good)
	check(StoryLint.readability("字".repeat(30), "fixture", "bubbles").is_empty(), "30 character bubble passes")
	check(_has_rule(StoryLint.readability("字".repeat(31), "fixture", "bubbles"), "氣泡長度", StoryLint.Level.WARNING), "31 character bubble warns")
	check(StoryLint.readability("字".repeat(16), "fixture", "bubbles", true).is_empty(), "16 character bark passes")
	check(_has_rule(StoryLint.readability("字".repeat(17), "fixture", "bubbles", true), "氣泡長度", StoryLint.Level.WARNING), "17 character bark warns")
	check(not _unit([_say("system", "地點，倉庫。目標，盤。")]).is_empty(), "formal speakers cannot bypass readability")
	check(StoryLint.readability("前往%s的區域地圖。%s%s", "fixture").is_empty(), "format substitutions are not independent one-letter speech")
	check(not StoryLint.readability("費用是%s。嗯。", "fixture").is_empty(), "format substitutions cannot exempt fragmented literal prose")


func _test_player_text_catalog() -> void:
	var entries := PlayerTextAudit.catalog()
	for fragment in ["data/story/ch1_kasa.json", "data/story/chapter_02.json", "data/levels/ch1_warehouse.tres", "data/story_items/doc_nest_log.tres", "data/weapons/pistol.tres", "ui/settings_screen.gd", "ui/inventory/pages/upgrades_page.gd", "game/props/flood_pit.gd", "ui/quest_map_screen.gd", "ui/quest_guidance.gd", "core/navigation/quest_map_index.gd"]:
		check(entries.any(func(entry: Dictionary) -> bool: return str(entry.id).contains(fragment)), "catalog covers %s" % fragment)
	check(PlayerTextAudit.lint(entries).is_empty(), "all current player text passes live readability scan")
	for field in ["ja", "en", "sub"]:
		check(entries.any(func(entry: Dictionary) -> bool: return str(entry.id).ends_with("/" + field)), "catalog includes existing translations and chapter subtitles: %s" % field)
	var labels: Array[Dictionary] = [{"id": "button", "text": "返回", "kind": "label"}]
	check(PlayerTextAudit.lint(labels).is_empty(), "explicit UI labels are not sentences")
	labels[0].kind = "text"
	check(not PlayerTextAudit.lint(labels).is_empty(), "the same short text is invalid as dialogue")
	var button := 'UiKit.button(str(option.get("text", "繼續。")), handler, "提示要完整。")'
	check(PlayerTextAudit._button_caption(button, button.find("繼續")), "nested default text is a button caption")
	check(not PlayerTextAudit._button_caption(button, button.find("提示")), "button tooltip is still prose")
	var quest_entries: Array[Dictionary] = []
	PlayerTextAudit._json({"quests": [{"title": "去。", "background": "上面。下面。", "reward": "獎勵十信用點。", "blocked_reason": "閘門尚未開啟。", "suggestion": "先去找老 K。", "steps": [{"title": "走。"}]}]}, "fixture", "", quest_entries)
	check(quest_entries.size() == 6, "future quest descriptions, rewards, blockers, suggestions and step titles are catalogued")
	check(quest_entries.filter(func(entry: Dictionary) -> bool: return entry.kind == "label").is_empty(), "quest action titles cannot bypass sentence readability as labels")
	check(not PlayerTextAudit.lint(quest_entries).is_empty(), "fragmented future quest objectives fail the same rules")
	var scene: Dictionary = Story._scenes["radio_start"]
	var before := JSON.stringify(scene)
	Story.text_units("chapter_01")
	check(JSON.stringify(scene) == before, "lint classification does not mutate dialogue source")
