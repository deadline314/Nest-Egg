import os
import json, os, subprocess, sys, time
from pathlib import Path
root = Path(os.environ.get('ST2_CANDIDATE_ROOT', 'D:/NestEggVerification/st2-localization-fix-20261112'))
proof = Path(__file__).resolve().parent
label = sys.argv[1]
cmd = sys.argv[2:]
user = proof / ('user-' + label)
user.mkdir(exist_ok=True)
env = os.environ.copy()
keys = ('APPDATA', 'LOCALAPPDATA', 'USERPROFILE', 'HOME', 'XDG_DATA_HOME')
for key in keys:
    env[key] = str(user)
env['PYTHONIOENCODING'] = 'utf-8'
start = time.time()
r = subprocess.run(cmd, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(proof / (label + '.stdout.log')).write_bytes(r.stdout)
(proof / (label + '.stderr.log')).write_bytes(r.stderr)
meta = {'command': cmd, 'cwd': str(root), 'environment': {k: env[k] for k in (*keys, 'PYTHONIOENCODING', *[k for k in ('GODOT', 'SHARDS', 'LOG_DIR') if k in env])}, 'exit': r.returncode, 'seconds': round(time.time()-start,3), 'stdout_bytes': len(r.stdout), 'stderr_bytes': len(r.stderr)}
(proof / (label + '.json')).write_text(json.dumps(meta, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(meta, ensure_ascii=False))
print(r.stdout.decode('utf-8', errors='replace')[-4000:])
print(r.stderr.decode('utf-8', errors='replace')[-4000:])
raise SystemExit(r.returncode)

