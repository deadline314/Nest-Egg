# ST-2 localization candidate proof

Base: `4a2f9ecfaf3d98db102e79b37420821f714549ca`; isolated branch: `codex/st2-localization-fix-20261112`.
Canonical source tree: `D:/NestEggVerification/st2-localization-fix-20261112`.
No commit, staging, push, PM changes, GPU runs, screenshots, native-language review, or human playtest performed.

`final.patch` and `candidate-files/` contain exactly seven candidate files; `final-manifest.json` records canonical absolute paths and SHA-256. Only source/tests/schema explanation are packaged, with no repository history, Godot imports, assets, or user saves.

## Change and invariants

`sub` joins the visible field schema; only `do=narrate` bare `lines` strings receive same-length `lines_ja/lines_en` arrays. Alternate container type, length, and each string slot are validated. Each place independently falls back ja -> en -> original Chinese. Mixed non-string values remain intact, translation metadata is skipped, and arbitrary code/flag/id string arrays do not become translatable.

The generated chapter has four new metadata fields. The only existing story value changed is Old K's Japanese shop name, from `巢蛋当舗` to `巣卵質店`, matching the new subtitle and the existing NAMES.md `巣卵` naming. Chinese, plot, actor/action/time, flags, quests/rewards/markers and every other existing JSON value are identical. Three authored overrides (JA2/EN1) and the unused old table entry remain. `integrity.json` gives paths/values; source inventory is 532 occurrences/475 unique -> 534/477, missing JA/EN slots 4 -> 0.

Original locale assertions remain verbatim. Added regressions exercise narrate + subtitle real data, independent fallback, bad type/length/container, exact source paths, mixed values, and direct seen/completed/world_flags snapshots including a seen-only scene.

## Tests and source boundaries

- Original StoryLintSuite baseline: 175 checks / 0 failures / exit 0.
- New runtime regression on old runtime/data: 194 checks / 9 failures / exit 1; green after schema/data fix: 194 / 0 / exit 0.
- Python unittest: original negative run 6 failures; an intermediate implementation run 1 failure is retained; corrected final run 4 tests, all pass / exit 0.
- Schema-only seven-file candidate -> original `tools/run_tests_changed.sh 4a2f9ecfaf3d98db102e79b37420821f714549ca`: 26 groups, 8834 checks, new 0, known 0, exit 0. `schema-only-manifest.json`, `schema-only-frozen-through-affected.json` and `schema-only.patch` retain that exact tested source.
- Schema-only -> terminology review changes exactly table/data/test (three files). `terminology-increment-range.json` and `terminology-increment.patch` prove this range, including the four unchanged file hashes. The incremental selector chooses nine groups; the original `tools/run_tests_parallel.sh` ran these groups: 4274 checks, new 0, known 0, exit 0. This nine-group selection is not the final seven-file candidate's full selection against base, which remains 26. `final-manifest.json` and `final-frozen-through-review.json` retain the final tested source.
- All native invocations use the original Godot 4.7.2 console executable and default `--headless`, no WASAPI adapter. Both affected rounds use two processes and five isolated user environment variables. Existing suite assertions/filters/known-failure thresholds are preserved. Per-command JSON stores the actual command, cwd, environment, exit and duration. All raw UTF-8 stdout/stderr/shard logs are retained. Every logged native run has 0 SCRIPT ERROR and 0 exit-leak markers; the original unsupported `xx` locale warning is retained.
- Original generator was rerun and all seven final candidate SHA-256 remain identical (`generator-idempotence.json`). Generator stage emissions only differed by existing platform newlines and were restored to exact base bytes after content equality checks. `git diff --check` and reverse patch check pass.

## Reproduce

Use the existing repo tools at the stated base, apply `final.patch`, and run `python tools/story/test_story_i18n.py`, `python tools/story/build_ch1_story.py`, and the original changed-test runner with isolated user directories and `SHARDS=2`. The existing selectors and runners are the source of truth. After cleanup/extraction, set `ST2_CANDIDATE_ROOT` to any complete checkout holding the candidate bytes to rerun the proof helpers; each helper locates its own proof directory. The seven owned file bytes are preserved inside the packet. Small proof-only Python helpers merely capture subprocess output, compare hashes/JSON, and package the seven files; they add no repository framework or dependency.

Initial `source-before-sha256.json` captures the five original checkout file byte hashes; manifests' before hashes are base Git blob bytes. Git path inventories use NUL separation and explicit UTF-8. `test-summary.json` indexes all original red/green logs, commands and raw error/leak checks.
