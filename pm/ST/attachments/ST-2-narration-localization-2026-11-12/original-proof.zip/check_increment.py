import os
import difflib, hashlib, json
from pathlib import Path
root=Path(os.environ.get('ST2_CANDIDATE_ROOT', 'D:/NestEggVerification/st2-localization-fix-20261112'))
proof=Path(__file__).resolve().parent
old=json.loads((proof/'schema-only-manifest.json').read_text(encoding='utf-8'))
new=json.loads((proof/'final-manifest.json').read_text(encoding='utf-8'))
a={v['path']:v['after_sha256'] for v in old['files']}
b={v['path']:v['after_sha256'] for v in new['files']}
changed=[k for k in a if a[k]!=b[k]]
assert set(changed)=={'tools/story/i18n/ch1_kasa.json','data/story/ch1_kasa.json','tests/suite/test_story_lint.gd'}
patch=''
for name in changed:
    after=(root/name).read_text(encoding='utf-8')
    before=after.replace('巣卵質店','巢蛋当舗')
    if name=='tests/suite/test_story_lint.gd':
        before=before.replace('\tStory._completed.erase(&"ch1_p02_talk")\n','')
        before=before.replace('\t\tif language == "ja":\n\t\t\tcheck(str(opening[11]["text"]).contains(subtitles["ja"]), "the Japanese prologue subtitle and Old K dialogue use the same pawnshop name")\n','')
    assert hashlib.sha256(before.encode('utf-8')).hexdigest()==a[name], name
    patch+='diff --git a/{0} b/{0}\n'.format(name)
    patch+=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
(proof/'terminology-increment.patch').write_text(patch,encoding='utf-8',newline='\n')
(proof/'terminology-increment-range.json').write_text(json.dumps({'from':'schema-only-manifest.json','to':'final-manifest.json','changed_files':changed,'unchanged_files':[k for k in a if a[k]==b[k]],'patch_sha256':hashlib.sha256(patch.encode('utf-8')).hexdigest()},indent=2)+'\n',encoding='utf-8')
print('Verified exactly 3 changed files and 4 unchanged files across the two source manifests; delta patch bytes:',len(patch.encode('utf-8')))
