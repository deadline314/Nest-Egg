from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys, time, zipfile

root = Path('C:/Users/stanl/Github/Nest-Egg')
tree = Path('D:/NestEggVerification/st2-localization-fix-20261112')
out = root / 'work/st2-joint-main-v1'
out.mkdir(exist_ok=False)
archive = Path('D:/NestEggVerification/proofs/st2-localization-fix-20261112/st2-localization-fix-proof.zip')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(archive) == '7740c520ece77a1bd8665605265c2931f15114b6d8db7160b0bc7c21592eeb06'
packet = out / 'original-packet'
with zipfile.ZipFile(archive) as z:
    for name in z.namelist():
        assert (packet / name).resolve().is_relative_to(packet.resolve())
    indexed = json.loads(z.read('portable-files-sha256.json'))
    assert len(indexed) == 97 and len(z.namelist()) == 98
    for row in indexed:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    z.extractall(packet)
manifest = json.loads((packet / 'final-manifest.json').read_bytes())
files = {row['path']: row for row in manifest['files']}
def git(*args):
    return subprocess.check_output(['git', *args], cwd=tree).decode('utf8').strip()
assert git('branch', '--show-current') == 'codex/st2-localization-fix-20261112'
for name, row in files.items():
    assert sha(tree / name) == row['after_sha256'] == sha(packet / 'candidate-files' / name)
env = os.environ.copy()
env.update(PYTHONIOENCODING='utf-8', ST2_CANDIDATE_ROOT=str(tree))
for helper in ('check_integrity.py', 'check_increment.py'):
    result = subprocess.run([sys.executable, '-X', 'utf8', str(packet / helper)], cwd=tree, env=env, capture_output=True)
    (out / (helper + '.stdout.log')).write_bytes(result.stdout)
    (out / (helper + '.stderr.log')).write_bytes(result.stderr)
    assert result.returncode == 0, (helper, result.stderr.decode('utf8', errors='replace'))
changed = set(filter(None, git('diff', '--name-only', '-z', 'HEAD').split('\0')))
untracked = set(filter(None, git('ls-files', '--others', '--exclude-standard', '-z').split('\0')))
assert changed | untracked == set(files) and untracked == {'tools/story/test_story_i18n.py'}
git('restore', '--source=HEAD', '--', *sorted(changed))
for name in untracked:
    (tree / name).unlink()
git('fetch', 'origin', 'main')
base = git('rev-parse', 'origin/main')
assert base == '612696e456b8d6321e4af16431c792a174c8b312'
git('rebase', base)
for name, row in files.items():
    target = tree / name
    assert (sha(target) if target.exists() else None) == row['before_sha256'], name
    shutil.copyfile(packet / 'candidate-files' / name, target)
    assert sha(target) == row['after_sha256'] == sha(root / name)
def snapshot():
    names = set(filter(None, git('ls-files', '-z').split('\0'))) | set(files)
    return {name: sha(tree / name) for name in sorted(names) if name == 'project.godot' or Path(name).suffix in {'.gd', '.tscn', '.tres', '.json', '.py', '.sh'}}
before = snapshot()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
for key in ('APPDATA', 'LOCALAPPDATA', 'USERPROFILE', 'HOME', 'XDG_DATA_HOME'):
    env[key] = str(out / 'userdata')
command = ['C:/Program Files/Git/bin/bash.exe', 'tools/run_tests_parallel.sh', '--only=StoryLintSuite,CutsceneSuite,MusicSuite,UiScreensSuite']
env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', SHARDS='2', LOG_DIR=str(out / 'logs'))
(out / 'command.json').write_text(json.dumps(dict(argv=command, cwd=str(tree), base=base, env={k: env[k] for k in ('GODOT', 'SHARDS', 'LOG_DIR', 'APPDATA', 'LOCALAPPDATA', 'USERPROFILE', 'HOME', 'XDG_DATA_HOME')}, scope='Original four-suite integration on latest published crossfade plus exact seven ST2 files; supplements, never replaces, original26 plus terminology9.'), indent=2) + '\n', encoding='utf8')
start = time.monotonic()
with (out / 'full.log').open('wb') as log:
    result = subprocess.run(command, cwd=tree, env=env, stdout=log, stderr=subprocess.STDOUT)
after = snapshot()
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
logs = list((out / 'logs').glob('shard_*.log'))
diagnostics = []
counts = []
for log in logs:
    text = log.read_text(encoding='utf8')
    diagnostics += [line for line in text.splitlines() if re.search(r'SCRIPT ERROR|Parse Error|Compile Error|ObjectDB.*leak|RID allocations.*leaked|resources still in use at exit', line)]
    counts += re.findall(r'^checks: (\d+), failures: (\d+)', text, re.M)
receipt = dict(exit_code=result.returncode, seconds=time.monotonic()-start, source_count=len(before), source_unchanged=before == after, diagnostics=diagnostics, shard_counts=counts, checks=sum(int(n) for n, _ in counts), failures=sum(int(n) for _, n in counts))
(out / 'exit.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt, indent=2), flush=True)
assert result.returncode == 0 and before == after and not diagnostics and len(counts) == 2 and receipt['failures'] == 0
