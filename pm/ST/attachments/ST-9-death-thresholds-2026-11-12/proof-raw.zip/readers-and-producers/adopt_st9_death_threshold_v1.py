from pathlib import Path
import copy, hashlib, json, shutil, subprocess

root=Path('C:/Users/stanl/Github/Nest-Egg')
tree=Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
out=root/'work/st9-death-threshold-v1/adoption'
out.mkdir(exist_ok=False)
base='2fa7bde15a08d0744d968c796ed9c5c4bf614015'
names=['tools/story/ch1_runtime_backend.py','data/story/ch1_kasa.json','data/story/ch2_heron.json','data/story/ch3_clearwater.json','tests/suite/test_death_flow.gd','design/13-story-v2/STORY_FEATURES.md']
sha=lambda data:hashlib.sha256(data).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=root).decode('utf8').strip()
assert git('rev-parse','HEAD')==git('rev-parse','origin/main')==base
assert not git('diff','--cached','--name-only')
assert set(filter(None,subprocess.check_output(['git','diff','--name-only','-z'],cwd=tree).decode('utf8').split('\0')))==set(names)
guard=json.loads((root/'work/st3-boundary-adoption-v1/c-native-context-v21.json').read_bytes())
assert len(guard['files'])==388 and all(sha((root/n).read_bytes())==wanted for n,wanted in guard['files'].items())
before={}
prepared={}
candidate={}
for name in names:
    before[name]=(root/name).read_bytes()
    old=subprocess.check_output(['git','show',base+':'+name],cwd=root)
    new=(tree/name).read_bytes()
    assert b'\r\n' not in new,name
    candidate[name]=sha(new)
    if name=='data/story/ch2_heron.json':
        physical=json.loads(before[name]); published=json.loads(old)
        assert physical['death_sequences']==published['death_sequences']
        expected=copy.deepcopy(physical)
        expected['death_sequences'][1]['min_deaths']=2
        expected['death_sequences'][2]['min_deaths']=3
        assert expected['death_sequences']==json.loads(new)['death_sequences']
        encoded=(json.dumps(expected,ensure_ascii=False,indent=1)+'\n').encode('utf8')
        assert (json.dumps(physical,ensure_ascii=False,indent=1)+'\n').encode('utf8')==before[name], 'physical story serialization differs; do not rewrite unrelated WIP'
        prepared[name]=encoded
    else:
        assert before[name]==old, name+': unrelated existing edits'
        prepared[name]=new
for name in names:
    for folder,data in [('before',before[name]),('canonical',(tree/name).read_bytes())]:
        dest=out/folder/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
for name,data in prepared.items():
    (root/name).write_bytes(data)
newfiles=dict(guard['files'])
for name in names:
    newfiles[name]=sha((root/name).read_bytes())
newguard=dict(guard,files=newfiles,scope='v22: exact previous C388 plus the tested ST9 death-threshold adoption; physical ch2 WIP preserved, canonical publication stages only its two threshold changes',previous='work/st3-boundary-adoption-v1/c-native-context-v21.json')
guardpath=root/'work/st9-death-threshold-v1/c-native-context-v22.json'
guardpath.write_text(json.dumps(newguard,indent=2)+'\n',encoding='utf8')
receipt=dict(base=base,files=candidate,physical_before={n:sha(b) for n,b in before.items()},physical_after={n:sha(b) for n,b in prepared.items()},staged_sources={'data/story/ch2_heron.json':str(out/'canonical/data/story/ch2_heron.json')},new_guard=str(guardpath),new_guard_count=len(newfiles),scope='Only the two threshold fields were changed in physical C ch2; unpublished source/scene/item WIP remains intact.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,indent=2))
