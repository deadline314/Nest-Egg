from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time

ROOT = Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
OUT = Path('C:/Users/stanl/Github/Nest-Egg/work/st9-death-threshold-v1') / sys.argv[1]
OUT.mkdir(parents=True, exist_ok=False)
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'

def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode('utf8').split('\0')
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths if p and (p == 'project.godot' or Path(p).suffix in {'.gd', '.tscn', '.tres', '.json', '.py', '.sh'})}

before = snapshot()
(OUT / 'sources-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf8')
env = os.environ.copy()
for key in ('APPDATA', 'LOCALAPPDATA', 'USERPROFILE', 'HOME', 'XDG_DATA_HOME'):
    env[key] = str(OUT / 'userdata')
argv = [ENGINE, '--headless', '--path', str(ROOT), 'res://tests/smoke_test.tscn', '--', '--only=DeathFlowSuite']
(OUT / 'command.json').write_text(json.dumps({'argv': argv, 'cwd': str(ROOT), 'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(), 'env': {key: env[key] for key in ('APPDATA', 'LOCALAPPDATA', 'USERPROFILE', 'HOME', 'XDG_DATA_HOME')}}, indent=2) + '\n', encoding='utf8')
start = time.monotonic()
with (OUT / 'engine.log').open('wb') as log:
    result = subprocess.run(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
after = snapshot()
(OUT / 'sources-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf8')
raw = (OUT / 'engine.log').read_text(encoding='utf8')
receipt = dict(exit_code=result.returncode, seconds=time.monotonic()-start, source_count=len(before), source_unchanged=before == after, results=re.findall(r'^checks: (\d+), failures: (\d+)', raw, re.M), failures=re.findall(r'^FAIL: (.*)', raw, re.M), diagnostics=[line for line in raw.splitlines() if re.search(r'SCRIPT ERROR|Parse Error|Compile Error|ObjectDB.*leak|RID allocations.*leaked|resources still in use at exit', line)], errors=[line for line in raw.splitlines() if line.startswith('ERROR:')])
(OUT / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt, ensure_ascii=False, indent=2), flush=True)
assert before == after and not receipt['diagnostics'] and len(receipt['results']) == 1
if sys.argv[1].startswith('red'):
    assert result.returncode == 1 and len(receipt['failures']) == 10, 'the original chapter data must fail all ten new boundary assertions'
else:
    assert result.returncode == 0 and not receipt['failures']
