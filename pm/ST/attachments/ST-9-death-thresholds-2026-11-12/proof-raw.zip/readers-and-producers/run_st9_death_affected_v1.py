from pathlib import Path
import hashlib, json, os, re, subprocess, time

root = Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
out = Path('C:/Users/stanl/Github/Nest-Egg/work/st9-death-threshold-v1/affected-01')
out.mkdir(exist_ok=False)
def snapshot():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode('utf8').split('\0')
    return {n: hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names if n and (n == 'project.godot' or Path(n).suffix in {'.gd', '.tscn', '.tres', '.json', '.py', '.sh'})}
before = snapshot()
(out/'source-before.json').write_text(json.dumps(before, indent=2)+'\n', encoding='utf8')
env = os.environ.copy()
env.update(GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', SHARDS='2', LOG_DIR=str(out/'logs'))
for key in ('APPDATA','LOCALAPPDATA','USERPROFILE','HOME','XDG_DATA_HOME'):
    env[key] = str(out/'userdata')
argv = ['C:/Program Files/Git/bin/bash.exe','tools/run_tests_changed.sh','2fa7bde15a08d0744d968c796ed9c5c4bf614015']
(out/'command.json').write_text(json.dumps(dict(argv=argv,cwd=str(root),env={k:env[k] for k in ('GODOT','SHARDS','LOG_DIR','APPDATA','LOCALAPPDATA','USERPROFILE','HOME','XDG_DATA_HOME')},scope='Original changed-range eleven groups on isolated published main plus the exact six-file ST9 change; functional checks, no exclusive performance claim.'),indent=2)+'\n',encoding='utf8')
start = time.monotonic()
with (out/'full.log').open('wb') as log:
    result = subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
after = snapshot()
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf8')
logs = sorted((out/'logs').glob('shard_*.log'))
raw = '\n'.join(p.read_text(encoding='utf8') for p in logs)
counts = re.findall(r'^checks: (\d+), failures: (\d+)',raw,re.M)
receipt = dict(exit_code=result.returncode,seconds=time.monotonic()-start,source_count=len(before),source_unchanged=before==after,counts=counts,checks=sum(int(n) for n,_ in counts),failures=re.findall(r'^FAIL: (.*)',raw,re.M),script_errors=[s for s in raw.splitlines() if re.search('SCRIPT ERROR|Parse Error|Compile Error',s)],shutdown_diagnostics=[s for s in raw.splitlines() if re.search(r'ObjectDB.*leak|RID allocations.*leaked|resources still in use at exit',s)])
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt,ensure_ascii=False,indent=2),flush=True)
assert result.returncode==0 and before==after and len(counts)==2 and not receipt['failures'] and not receipt['script_errors']
