from pathlib import Path
import copy, hashlib, json, subprocess, sys

root = Path('C:/Users/stanl/.codex/worktrees/ne286-boss-cache-verification/Nest-Egg')
out = Path('C:/Users/stanl/Github/Nest-Egg/work/st9-death-threshold-v1')
sys.dont_write_bytecode = True
sys.path.insert(0, str(root / 'tools/story'))
import ch1_runtime_backend, build_ch2_story, build_ch3_story, chapter_compiler, story_i18n

rows = []
for chapter, build in (
    ('ch1_kasa', ch1_runtime_backend.compile_document),
    ('ch2_heron', lambda: chapter_compiler.compile_chapter(build_ch2_story.spec())),
    ('ch3_clearwater', lambda: chapter_compiler.compile_chapter(build_ch3_story.spec())),
):
    path = root / f'data/story/{chapter}.json'
    original = subprocess.check_output(['git', 'show', f'HEAD:data/story/{chapter}.json'], cwd=root)
    old = json.loads(original)
    new = build()
    if chapter == 'ch1_kasa':
        new['chapter']['languages'] = ['zh', *story_i18n.LANGUAGES]
    missing = story_i18n.apply(new, story_i18n.load_table(story_i18n.table_path(chapter)))
    assert not missing, (chapter, missing)
    expected = copy.deepcopy(old)
    assert [entry['min_deaths'] for entry in expected['death_sequences']] == [1, 3, 5]
    expected['death_sequences'][1]['min_deaths'] = 2
    expected['death_sequences'][2]['min_deaths'] = 3
    assert new == expected, f'{chapter}: regeneration changed something outside the two thresholds'
    encoded = (json.dumps(new, ensure_ascii=False, indent=1) + '\n').encode('utf8')
    path.write_bytes(encoded)
    rows.append(dict(path=path.relative_to(root).as_posix(), before_sha256=hashlib.sha256(original).hexdigest(), after_sha256=hashlib.sha256(encoded).hexdigest(), unchanged_except=['/death_sequences/1/min_deaths', '/death_sequences/2/min_deaths']))
(out / 'regeneration.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf8')
print(json.dumps(rows, indent=2))
