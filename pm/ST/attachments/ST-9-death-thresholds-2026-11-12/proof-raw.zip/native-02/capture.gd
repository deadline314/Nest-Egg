extends Node

var out := ""
var files := {}
var captures: Array[Dictionary] = []
var observations: Array[Dictionary] = []

func _ready() -> void:
	if OS.get_cmdline_user_args().has("--parser-only"):
		print("ST9 native producer parsed with actual project autoloads")
		get_tree().quit()
		return
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out = arg.trim_prefix("--out=")
	assert(out.is_absolute_path() and DirAccess.make_dir_recursive_absolute(out) == OK)
	DisplayMode.ensure_scaling(get_window())
	_run.call_deferred()

func _run() -> void:
	Settings.use_storage("user://st9-death-native.cfg")
	Story.auto_skip = true
	add_child(LightKit.create_environment())
	for count in [2, 3]:
		GameState.start_new_run(GameState.difficulties[1])
		Story.reset_progress()
		# Fixture: the clinic has completed and earlier deaths were already counted.
		GameState.set_flag(&"ch1_first_death_done")
		for previous in count - 1:
			GameState.register_death()
		Progression.credits = 1000
		var level := Level.new()
		level.configure(load("res://data/levels/ch1_booth_alley.tres") as LevelData)
		add_child(level)
		for frame in 8:
			await get_tree().process_frame
		# Let the existing respawn radio/toast finish naturally before the next hit.
		await get_tree().create_timer(5.0).timeout
		var hit := DamageInfo.create(9999, Combat.Team.ENEMY, &"grunt_shot")
		hit.ignore_invulnerability = true
		level.player.health.take_damage(hit)
		var screens: Array = []
		var deadline := Time.get_ticks_msec() + 10000
		while screens.is_empty() and Time.get_ticks_msec() < deadline:
			await get_tree().process_frame
			screens = level.get_children().filter(func(node: Node) -> bool: return node is DeathScreen)
		assert(screens.size() == 1, "the real lethal hit must open exactly one death screen")
		var screen := screens[0] as DeathScreen
		assert(GameState.deaths == count and screen.sequence == Story.death_sequence(&"ch1_kasa", count))
		# The normal noise transition lasts 0.45s; capture the still-active line after it.
		await get_tree().create_timer(0.55).timeout
		await _capture("death-%d-line" % count, screen)
		var start := Time.get_ticks_msec()
		if count == 3:
			var accept := InputEventAction.new()
			accept.action = &"ui_accept"
			accept.pressed = true
			Input.parse_input_event(accept)
			await get_tree().process_frame
			accept = InputEventAction.new()
			accept.action = &"ui_accept"
			Input.parse_input_event(accept)
		while not screen.sequence_complete and Time.get_ticks_msec() < deadline:
			await get_tree().process_frame
		assert(screen.sequence_complete)
		assert(count != 3 or Time.get_ticks_msec() - start < 500, "public confirm must skip the third sequence promptly")
		observations.append({"deaths": count, "selected_threshold": screen.sequence.min_deaths, "skippable": screen.sequence.skippable, "wait_after_first_capture_ms": Time.get_ticks_msec() - start, "public_confirm_sent": count == 3})
		await _capture("death-%d-card" % count, screen)
		level.queue_free()
		for frame in 8:
			await get_tree().process_frame
	Sfx.stop_all()
	Music.stop(0.0)
	Ambience.stop_all(0.0)
	var report := {"resolution": captures[0].size, "window_size": [get_window().size.x, get_window().size.y], "renderer": RenderingServer.get_current_rendering_method(), "adapter": RenderingServer.get_video_adapter_name(), "hdr": get_viewport().use_hdr_2d, "captures": captures, "files": files, "observations": observations, "scope": "Actual published booth Level and lethal health hit; earlier deaths and completed-clinic flag are an explicit fixture. Native UI and synthetic public confirm, not a complete campaign, physical input, or full restoration timing test. PNG encoding blocks between observations."}
	assert(report.renderer == "forward_plus" and report.hdr)
	var file := FileAccess.open(out.path_join("manifest.json"), FileAccess.WRITE)
	assert(file != null)
	file.store_string(JSON.stringify(report, "\t"))
	file.close()
	await get_tree().create_timer(0.25).timeout
	get_tree().quit()

func _capture(page: String, screen: DeathScreen) -> void:
	await RenderingServer.frame_post_draw
	var raw := get_viewport().get_texture().get_image()
	assert(raw.get_format() in [Image.FORMAT_RGBH, Image.FORMAT_RGBAH, Image.FORMAT_RGBF, Image.FORMAT_RGBAF])
	var png := preload("res://tools/viewport_capture.gd").encode(raw, get_viewport().use_hdr_2d)
	_write(page + ".bin", raw.get_data())
	_write(page + ".png", png.save_png_to_buffer())
	captures.append({"page": page, "size": [raw.get_width(), raw.get_height()], "format": raw.get_format(), "linear_raw": page + ".bin", "encoded_png": page + ".png", "sequence_index": screen.sequence_index, "sequence_complete": screen.sequence_complete})

func _write(name: String, bytes: PackedByteArray) -> void:
	var file := FileAccess.open(out.path_join(name), FileAccess.WRITE)
	assert(file != null, "cannot create native evidence: " + name)
	file.store_buffer(bytes)
	file.close()
	files[name] = {"bytes": bytes.size(), "sha256": FileAccess.get_sha256(out.path_join(name))}
