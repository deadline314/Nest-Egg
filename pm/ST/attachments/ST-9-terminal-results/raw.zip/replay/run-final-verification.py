from pathlib import Path
import subprocess,os,json,hashlib
b=Path('/workspace/Nest-Egg/work/batch1021');old=Path('/workspace/Nest-Egg/work/batch1020b');w=b/'story'
# Retry only the corrected probe; preserve the earlier parse failure files.
s=(b/'meal-baseline.py').read_text().replace('meal-prop-baseline','meal-prop-baseline-v2').replace('meal-baseline-wrapper','meal-baseline-v2-wrapper').replace('meal-baseline-restored','meal-baseline-v2-restored').replace("b/'meal-baseline-slot'","b/'meal-baseline-v2-slot'")
(b/'meal-baseline-v2.py').write_text(s)
subprocess.run(['python3',str(b/'meal-baseline-v2.py')],check=True)
env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1021/story'
def native(name,tool,mode,slot):
 with (b/(name+'-wrapper.log')).open('w') as log:r=subprocess.run(['python3',str(old/'native.py'),name,tool,'--mode='+mode,'--save-dir='+str(b/slot)],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
 return r.returncode
p=w/'game/story_result_completion.gd';saved=p.read_bytes();text=saved.decode();patched='\tif is_instance_valid(_prompt):\n\t\t_prompt.set_recovery(_recovery)\n\t\tif _reload_original:\n\t\t\t_prompt.set_original_recovery()\n\t\treturn\n';assert patched in text
receipt={}
try:
 p.write_text(text.replace(patched,'\tif is_instance_valid(_prompt):\n\t\treturn\n',1))
 receipt['control']=native('terminal-recovery-control','res://work/terminal_recovery_probe.tscn','recovery','terminal-recovery-control-slot')
finally:
 p.write_bytes(saved);receipt['exact_restore']=p.read_bytes()==saved;receipt['sha256']=hashlib.sha256(saved).hexdigest();(b/'terminal-recovery-restored.json').write_text(json.dumps(receipt,indent=2))
receipt['after']=native('terminal-recovery-final','res://work/terminal_recovery_probe.tscn','recovery','terminal-recovery-final-slot')
receipt['ordinary_write']=native('terminal-ordinary-final','res://work/terminal_results_probe_v3.tscn','write','terminal-ordinary-final-slot')
receipt['ordinary_read']=native('terminal-ordinary-cold-final','res://work/terminal_results_probe_v3.tscn','read','terminal-ordinary-final-slot')
(b/'terminal-final-native-receipt.json').write_text(json.dumps(receipt,indent=2))
if any(receipt[k] != 0 for k in ['after','ordinary_write','ordinary_read']):raise RuntimeError('native final verification failed')
env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',GODOT=str(old/'godot472/Godot_v4.7.2-stable_linux.x86_64'),LOG_DIR=str(b/'changed-final'),SHARDS='6')
with (b/'changed-final.log').open('w') as log:r=subprocess.run(['bash','tools/run_tests_changed.sh','ddbb6248dc4b469e5286108ae421aa1effb0d5fe'],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
(b/'changed-final.exit').write_text(str(r.returncode));print(receipt,'changed final',r.returncode)
