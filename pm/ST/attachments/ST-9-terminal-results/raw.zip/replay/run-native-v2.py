from pathlib import Path
import subprocess,os,json,hashlib
b=Path('/workspace/Nest-Egg/work/batch1021');w=b/'story';prior=Path('/workspace/Nest-Egg/work/batch1020b')
paths=['autoload/progression.gd','autoload/story.gd','autoload/story_items.gd','core/story_outcomes.gd','data/story/ch1_kasa.json','game/main.gd','tools/story/ch1_runtime_backend.py']
saved={p:(w/p).read_bytes() for p in paths};receipt={}
env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1021/story'
def run(name,mode,slot):
 with (b/(name+'-wrapper.log')).open('w') as log:
  r=subprocess.run(['python3',str(prior/'native.py'),name,'res://work/terminal_results_probe.tscn','--mode='+mode,'--save-dir='+str(b/slot)],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
 receipt[name]=r.returncode
try:
 for p in paths:(w/p).write_bytes(subprocess.check_output(['git','show','ddbb6248:'+p],cwd=w))
 run('terminal-baseline-native-v2','negative','baseline-native-v2-slot')
finally:
 for p,v in saved.items():(w/p).write_bytes(v)
 receipt['restore']={p:hashlib.sha256((w/p).read_bytes()).hexdigest()==hashlib.sha256(v).hexdigest() for p,v in saved.items()}
 (b/'native-v2-restored.json').write_text(json.dumps(receipt,indent=2))
run('terminal-candidate-negative-v2','negative','candidate-negative-v2-slot')
run('terminal-candidate-native-v2','write','native-v2-slot')
run('terminal-candidate-cold-v2','read','native-v2-slot')
(b/'native-v2-receipt.json').write_text(json.dumps(receipt,indent=2))
print(receipt)
