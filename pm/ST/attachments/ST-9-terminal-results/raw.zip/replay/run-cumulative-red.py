from pathlib import Path
import subprocess,os,json,hashlib
b=Path('/workspace/Nest-Egg/work/batch1021');w=b/'story';p=w/'core/story_outcomes.gd';saved=p.read_bytes();text=saved.decode();old=subprocess.check_output(['git','show','ddbb6248:core/story_outcomes.gd'],cwd=w).decode();start='func preflight(';end='\n\n## 套用已預檢'
red=text[:text.index(start)]+old[old.index(start):old.index(end)]+text[text.index(end):]
(b/'cumulative-control.diff').write_text(subprocess.check_output(['git','diff','--','core/story_outcomes.gd'],cwd=w).decode())
try:
 p.write_text(red)
 env=os.environ.copy();env.update(LD_LIBRARY_PATH='/workspace/Nest-Egg/work/ne279/runtime/usr/lib/x86_64-linux-gnu',GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',LOG_DIR=str(b/'cumulative-red'),SHARDS='1')
 r=subprocess.run(['bash','tools/run_tests_parallel.sh','--only=CutsceneSuite'],cwd=w,env=env,stdout=(b/'cumulative-red.log').open('w'),stderr=subprocess.STDOUT)
 (b/'cumulative-red.exit').write_text(str(r.returncode))
finally:
 p.write_bytes(saved);(b/'cumulative-restored.json').write_text(json.dumps({'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'exact_restore':p.read_bytes()==saved}))
