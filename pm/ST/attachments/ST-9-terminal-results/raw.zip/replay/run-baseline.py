import subprocess,os,json,hashlib
from pathlib import Path
b=Path('/workspace/Nest-Egg/work/batch1021');w=b/'story'
paths=['autoload/progression.gd','autoload/story.gd','autoload/story_items.gd','core/story_outcomes.gd','data/story/ch1_kasa.json','game/main.gd','tools/story/ch1_runtime_backend.py']
saved={p:(w/p).read_bytes() for p in paths}
archive=b/'candidate-source';archive.mkdir(exist_ok=True)
for p,v in saved.items():
 d=archive/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(v)
report={}
try:
 for p in paths:(w/p).write_bytes(subprocess.check_output(['git','show','ddbb6248:'+p],cwd=w))
 env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1021/story'
 name='terminal-baseline-native'
 r=subprocess.run(['python3','/workspace/Nest-Egg/work/batch1020b/native.py',name,'res://work/terminal_results_probe.tscn','--mode=negative','--save-dir='+str(b/'baseline-slot')],env=env,stdout=(b/'baseline-wrapper.log').open('w'),stderr=subprocess.STDOUT)
 report['native_returncode']=r.returncode
finally:
 for p,v in saved.items():(w/p).write_bytes(v)
 report['restored']={p:hashlib.sha256((w/p).read_bytes()).hexdigest()==hashlib.sha256(v).hexdigest() for p,v in saved.items()}
 (b/'baseline-restore.json').write_text(json.dumps(report,indent=2))
print(report)
