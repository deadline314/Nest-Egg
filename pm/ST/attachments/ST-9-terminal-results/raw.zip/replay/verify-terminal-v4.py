from pathlib import Path
import subprocess,os,json,hashlib
b=Path('/workspace/Nest-Egg/work/batch1021');w=b/'story';old=Path('/workspace/Nest-Egg/work/batch1020b');env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1021/story'
def run(name,tool,mode,slot):
 with (b/(name+'-wrapper.log')).open('w') as log:r=subprocess.run(['python3',str(old/'native.py'),name,tool,'--mode='+mode,'--save-dir='+str(b/slot)],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
 return r.returncode
p=w/'game/story_result_completion.gd';saved=p.read_bytes();s=saved.decode();needle='\tif is_instance_valid(_prompt):\n\t\t_prompt.set_recovery(_recovery)\n\t\tif _reload_original:\n\t\t\t_prompt.set_original_recovery()\n\t\treturn\n';assert needle in s
r={}
try:
 p.write_text(s.replace(needle,'\tif is_instance_valid(_prompt):\n\t\treturn\n',1));r['control']=run('terminal-recovery-control-v4','res://work/terminal_recovery_probe_v4.tscn','recovery','recovery-control-v4-slot')
finally:
 p.write_bytes(saved);r['restored']=p.read_bytes()==saved;r['sha256']=hashlib.sha256(saved).hexdigest();(b/'terminal-v4-restored.json').write_text(json.dumps(r,indent=2))
r['recovery']=run('terminal-recovery-final-v4','res://work/terminal_recovery_probe_v4.tscn','recovery','recovery-final-v4-slot')
r['ordinary']=run('terminal-ordinary-final-v4','res://work/terminal_results_probe_v3.tscn','write','ordinary-final-v4-slot')
r['cold']=run('terminal-cold-final-v4','res://work/terminal_results_probe_v3.tscn','read','ordinary-final-v4-slot')
(b/'terminal-v4-receipt.json').write_text(json.dumps(r,indent=2));print(r)
