extends "res://work/terminal_results_probe_v3.gd"
## Trusted phase seam installs a real directory after primary rotation. Actual
## OS renames then fail; the original complete backup remains the only authority.
class RecoveryStore extends RunSaveStore:
	var obstruct_rotation := false
	func _durable_phase(phase: DurablePhase, absolute: String) -> void:
		if obstruct_rotation and phase == DurablePhase.PRIMARY_ROTATED:
			obstruct_rotation = false
			assert(DirAccess.make_dir_absolute(absolute) == OK)

func _run() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
	Transition.instant = true
	Story.auto_skip = true
	_main = MainScript.new()
	var recovery_store := RecoveryStore.new(_directory.path_join("slot.json"))
	_store = recovery_store
	_main.set("_run_store", _store)
	add_child(_main)
	await _frames(5)
	_main.call("_on_start_requested", GameState.difficulties[1])
	await _room("")
	Story.reset_active_presentation(&"probe_setup")
	_check(StoryItems.acquire(&"ch1_data_disk", false), "arrange held disk through actual custody owner")
	_main.call("_on_area_requested", "res://data/levels/ch1_handoff.tres")
	await _room("res://data/levels/ch1_handoff.tres")
	await _frames(5)
	Story.auto_skip = false
	_target = &"ch1_t_handoff_accept"
	Story.scene_started.connect(_inject)
	var npc := _cabinet()
	var done := [false, false]
	var talk := func() -> void:
		done[1] = await npc._talk()
		done[0] = true
	talk.call()
	await _drive("deliver", done)
	_check(_prompt() != null and _facts() == _facts_before, "initial ordinary refusal keeps actual result pending")
	_check(DirAccess.remove_absolute(_store.path + ".tmp") == OK, "remove only owned initial obstruction")
	recovery_store.obstruct_rotation = true
	_prompt().retry_button.pressed.emit()
	await _frames(3)
	_check(DirAccess.dir_exists_absolute(_store.path) and FileAccess.file_exists(_store.path + ".bak"), "actual failed renames retain original complete backup behind obstructed primary")
	if not DirAccess.dir_exists_absolute(_store.path):
		await _finish()
		return
	_check(_facts() == _facts_before and not done[0], "rollback failure publishes no result or successful waiter")
	var prompt := _prompt()
	_check(prompt != null and (prompt.get("_message") as Label).text.contains("原進度") and prompt.retry_button.text.contains("原進度"), "same existing prompt refreshes to original-backup recovery instead of retrying an unsafe write")
	await _shot("original-backup-recovery")
	_check(DirAccess.remove_absolute(_store.path) == OK, "remove only owned empty primary obstruction before reload")
	var previous_level_id := (_main.get("_screen") as Level).get_instance_id()
	prompt.retry_button.pressed.emit()
	await _room("res://data/levels/ch1_handoff.tres")
	await _frames(5)
	_check(StoryItems.holds(&"ch1_data_disk") and not StoryItems.was_transferred(&"ch1_data_disk") and not GameState.has_flag(&"ch1_disk_delivered"), "actual Main reload restores original held disk and uncompleted delivery")
	_check((_main.get("_screen") as Level).get_instance_id() != previous_level_id, "actual Main replaces the old Level during backup recovery")
	_check(_prompt() == null and _main.get("_result_completion").get("_lock") == 0, "original backup recovery releases its own persistent prompt and pause token")
	Story.scene_started.disconnect(_inject)
	await _finish()
