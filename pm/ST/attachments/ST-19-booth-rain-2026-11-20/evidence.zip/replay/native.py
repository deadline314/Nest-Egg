from pathlib import Path
from shutil import copyfile
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
prior = base.parent/'st19-cinematic-music-20261119'
shared = Path('D:/NestEggVerification/ne218-baseline-20261117')
guard = json.loads((base/'source.json').read_bytes())
for name in ('st19_booth_rain.gd','st19_booth_rain.tscn'):
    copyfile(base/name,shared/'work'/name)
assert all(hashlib.sha256((shared/name).read_bytes()).hexdigest()==digest for name,digest in guard.items())
tag, *modes = sys.argv[1:]
for mode in modes:
    out = base/tag/mode
    out.mkdir(parents=True)
    (out/'slot').mkdir()
    if mode.startswith('cold_'):
        original = base/tag/mode.removeprefix('cold_')/'slot/slot.json'
    else:
        route = 'cut_play' if mode=='normal' else 'keep_play'
        original = prior/f'candidate/{route}/slot/slot.json'
    copyfile(original,out/'slot/slot.json')
    env = os.environ.copy()
    for name in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
        env[name] = str(out/'profile'/name)
    cmd = [sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
           'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
           '--path',str(shared),'--audio-driver','WASAPI','--rendering-method','forward_plus',
           '--resolution','960x540','--position','32,32','--max-fps','60',
           'res://work/st19_booth_rain.tscn','--','--mode='+mode,'--save-dir='+str(out/'slot'),'--out='+str(out)]
    (out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
    with (out/'raw.log').open('wb') as log:
        result = subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    raw = (out/'raw.log').read_text(encoding='utf-8',errors='replace')
    receipt = {'mode':mode,'exit':result.returncode, 'source_held':all(hashlib.sha256((shared/name).read_bytes()).hexdigest()==digest for name,digest in guard.items()),
               'sound':[json.loads(s.removeprefix('AUDIO_STATE ')) for s in raw.splitlines() if s.startswith('AUDIO_STATE ')],
               'rain':[json.loads(s.removeprefix('RAIN_STATE ')) for s in raw.splitlines() if s.startswith('RAIN_STATE ')],
               'errors':[s for s in raw.splitlines() if 'ERROR:' in s or 'WARNING: [Cutscene' in s],
               'save_sha':hashlib.sha256((out/'slot/slot.json').read_bytes()).hexdigest()}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(receipt,flush=True)
    assert result.returncode==0 and not receipt['errors'] and receipt['source_held']
