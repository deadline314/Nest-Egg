from pathlib import Path

source = Path("design/20-campaign-experience/CH1_PRODUCTION_INTEGRATION.md")
old = source.read_text(encoding="utf-8")
target = "| F05–F07 | 甜湯／只坐，下班；明確去留；paid／owed／no-order 三種告別 | 接待與晚間完成分開，route意圖不開門。現金不足有欠條／留下／返回，完成結果才supper_done |"
assert old.count(target) == 1
source.write_text(old.replace(target,target.replace("接待與晚間完成分開","阿梨把杯收在吧台一旁，轉身往館外麵攤。接待與晚間完成分開")),encoding="utf-8",newline="\n")