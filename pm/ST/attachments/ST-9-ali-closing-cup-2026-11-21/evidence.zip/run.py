from hashlib import sha256
from pathlib import Path
import json
import math
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
label = sys.argv[1]
out = base / label
out.mkdir()
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    path = out / key
    path.mkdir()
    env[key] = str(path)
paths = ["data/story/ch1_kasa.json","data/cutscene/stages/ch1_revival_lounge.json","game/cutscene/cutscene_player.gd",
         "game/cutscene/stage_library.gd","autoload/story.gd","data/npcs/ch1_ali_lounge.tres","data/npcs/ch1_ali_stall.tres"]
sha = lambda path: sha256(path.read_bytes()).hexdigest()
source = {p:sha(game / p) for p in paths}
argv = [sys.executable,"-B",str(game/"tools/comfyui/gpu_lock.py"),"--",
        "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(game),
        "--rendering-method","forward_plus","--rendering-driver","vulkan","--audio-driver","Dummy",
        "--fixed-fps","60","--resolution","1280x720","--quit-after","3300",str(base/"observe.tscn"),"--",f"--out={out}"]
if len(sys.argv) > 2:
    argv.append("--draft=" + str(base/sys.argv[2]))
(out/"command.json").write_text(json.dumps({"argv":argv,"source":source},indent=2)+"\n",encoding="utf-8")
with (out/"engine.log").open("wb") as log:
    proc = subprocess.run(argv,cwd=game,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=230)
raw=(out/"engine.log").read_text(encoding="utf-8",errors="replace")
print(raw[-8000:],flush=True)
report = json.loads((out/"result.json").read_bytes())
assert all(sha(game/p)==digest for p,digest in source.items())
print(report["failures"], flush=True)
assert proc.returncode == 0 and not re.search(r"^SCRIPT ERROR:|^ERROR:",raw,re.M), (proc.returncode,report["failures"])
assert report["hdr"] and "9070 XT" in report["adapter"] and not report["failures"]
assert len(report["cases"]) == (1 if label.startswith("stock") else 3)
print(f"{label}: {[{k:v for k,v in row.items() if k!='rows'} for row in report['cases']]}", flush=True)
