from pathlib import Path
from shutil import copy2
import importlib.util
import json
import sys

root = Path.cwd()
base = Path(__file__).resolve().parent
author = root / "tools/story"
sys.dont_write_bytecode = True
sys.path.insert(0, str(author))
legacy = author / "build_ch1_story.py"
backend = author / "ch1_runtime_backend.py"


def replace(body, old, new):
    assert body.count(old) == 1, old
    return body.replace(old, new)


legacy_code = replace(legacy.read_text(encoding="utf-8"), "# 演員縮放：", '''# Mug cut from the existing clinic atlas; only the closing uses it.
LOUNGE_CUP = {
    "kind": "sprite", "id": "ali_lounge_closing_cup",
    "path": "res://art/environment/scene_props/revival_room_contacts/clinic_atlas.png",
    "pos": [289, 179], "region": [131, 776, 396, 328], "pivot": [198, 315],
    "scale": 0.024, "source_width": 1254, "filter": "linear", "visible": False,
    "modulate": "#d5b5a1", "depth": "front",
}
# 演員縮放：''')
legacy_code = replace(legacy_code, '(LOUNGE_BOWL, "cup")), start=2)', '(LOUNGE_BOWL, "cup"), (LOUNGE_CUP, "cup")), start=2)')
backend_code = replace(backend.read_text(encoding="utf-8"), '            elif ident == "ch1_t_supper_stay_meal":', '''            elif ident == "ch1_t_ali_evening_close":
                cup = legacy.LOUNGE_CUP
                grip = [162, 858]
                surface_grip = [round(x + (point - origin - pivot) * cup["scale"], 3)
                                for x, point, origin, pivot in zip(cup["pos"], grip, cup["region"], cup["pivot"])]
                rest = [surface_grip[0] - 14, surface_grip[1]]
                touch = {"do": "reach", "id": "ali", "hand": "front", "contact": [80.5, 24.5], "angle": 3.14}
                steps[0]["props"] = {cup["id"]: {"visible": True}}
                steps.extend([
                    dict(touch, space="prop", prop=cup["id"], to=grip, time=0.32),
                    {"do": "prop_hold", "id": cup["id"], "actor": "ali", "hand": "front", "point": grip},
                    dict(touch, to=[surface_grip[0], surface_grip[1] - 5], time=0.24),
                    dict(touch, to=[rest[0], rest[1] - 5], time=0.32),
                    dict(touch, to=rest, time=0.24),
                    {"do": "prop_release", "id": cup["id"]},
                    {"do": "reach", "id": "ali", "hand": "front", "release": True, "time": 0.24},
                    legacy.move("ali", 413, floor, 1.0),
                ])
            elif ident == "ch1_t_supper_stay_meal":''')

changed = {legacy: legacy_code, backend: backend_code}
selected = "ch1_t_ali_evening_close"
stage_name = "ch1_revival_lounge.json"
current_story = root / "data/story/ch1_kasa.json"
current_stage = root / "data/cutscene/stages" / stage_name


def module(path, code):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = result
    exec(compile(code, str(path), "exec"), result.__dict__)
    return result


mode = sys.argv[1]
assert mode in ("preview", "adopt")
out = base / sys.argv[2]
out.mkdir(exist_ok=False)
engine = module(legacy, legacy_code)
compiler = module(backend, backend_code)
compiler.OUT = str(out / "ch1_kasa.json")
engine.STAGE_DIR = str(out)
assert compiler.main() == 0
before = json.loads(current_story.read_bytes())
after = json.loads((out / "ch1_kasa.json").read_bytes())
previous = before["scenes"].pop(selected)
proposed = after["scenes"].pop(selected)
assert before == after, "another original scene changed"
left = previous.pop("steps")
right = proposed.pop("steps")
assert previous == proposed and [x for x in left if x.get("do") == "say"] == [x for x in right if x.get("do") == "say"]
assert right[-1] == left[-1] and right[1:len(left)-1] == left[1:-1]
# Dictionary field order may differ; interpreted data and all original cues must match.
approved = base / "draft-a"
for name in ("ch1_kasa.json", stage_name):
    assert json.loads((approved / name).read_bytes()) == json.loads((out / name).read_bytes())
original_stage = json.loads(current_stage.read_bytes())
proposed_stage = json.loads((out / stage_name).read_bytes())
new_sprite, = [x for x in proposed_stage["layers"] if x.get("id") == "ali_lounge_closing_cup"]
new_support, = [x for x in proposed_stage["furniture"] if x.get("id") == new_sprite["id"]]
proposed_stage["layers"].remove(new_sprite)
proposed_stage["furniture"].remove(new_support)
assert proposed_stage == original_stage and new_support.get("support") == "bar_counter"
print(f"{len(before['scenes'])+1} scenes verified, only authored closing and one stage prop changed")
if mode == "adopt":
    for path, body in changed.items():
        path.write_text(body, encoding="utf-8", newline="\n")
    copy2(out / "ch1_kasa.json", current_story)
    copy2(out / stage_name, current_stage)