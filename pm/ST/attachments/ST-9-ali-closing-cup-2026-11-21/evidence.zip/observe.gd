extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const SCENE := &"ch1_t_ali_evening_close"
const STAGE := &"ch1_revival_lounge"
const PROP := "ali_lounge_closing_cup"
const POINT := Vector2(162, 858)

var _out := ""
var _stage_override := ""
var _story_override := ""
var _results: Array[Dictionary] = []
var _failures: Array[String] = []


func _ready() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=")
		if argument.begins_with("--draft="):
			var draft := argument.trim_prefix("--draft=")
			_stage_override = draft.path_join("ch1_revival_lounge.json")
			_story_override = draft.path_join("ch1_kasa.json")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://closing-cup-fixture.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	var scene: Dictionary = Story._scenes.get(SCENE, {})
	if not _stage_override.is_empty():
		StageLibrary._cache[STAGE] = JSON.parse_string(FileAccess.get_file_as_string(_stage_override))
		var authored: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(_story_override))
		scene = authored["scenes"][String(SCENE)]
	var problems := CutsceneChecker.validate(String(SCENE), scene, Story._speakers)
	problems.append_array(CutsceneChecker.staging_problems(String(SCENE), scene))
	problems.append_array(StageLibrary.validate(STAGE))
	if not problems.is_empty():
		_failures.append_array(problems)
	var facts := [GameState.world_flags.duplicate(true), Progression.credits, StoryItems.snapshot()]
	if _failures.is_empty():
		if not scene["steps"][0].get("props", {}).has(PROP):
			await _observe(scene, "stock")
		else:
			await _observe(scene, "normal")
			await _observe(scene, "skip")
			await _observe(scene, "cancel")
	_check(facts == [GameState.world_flags, Progression.credits, StoryItems.snapshot()], "presentation preserves progress, wallet and held story items")
	var file := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"adapter":RenderingServer.get_video_adapter_name(),
		"hdr":get_viewport().use_hdr_2d,"cases":_results,"failures":_failures},"  "))
	file.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(not _failures.is_empty()))


func _observe(scene: Dictionary, mode: String) -> void:
	var film := CutscenePlayer.new()
	add_child(film)
	film.play(SCENE,scene)
	var rows: Array[Dictionary] = []
	var opening := false
	var carry := false
	var rest := false
	var leaving := false
	var stopped := false
	var cue_count := 0
	var pressed_cues: Dictionary = {}
	var initial := Vector2.INF
	var max_error := 0.0
	var first_contact := -1.0
	var high := INF
	var released := Vector2.INF
	for frame in 400:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		if not is_instance_valid(film) or not film.is_running():
			break
		if film._stage == null:
			continue
		var ali := film._actors.get(&"ali") as CutsceneActor
		if not is_instance_valid(ali):
			continue
		var mug := film._stage.prop_node(PROP) as StageLayers._Sprite
		if film._dialogue.is_complete() and film._dialogue.visible:
			var line_key: String = str(film._current_where)
			if not pressed_cues.has(line_key):
				pressed_cues[line_key] = true
				cue_count += 1
				if not opening:
					opening = _capture(mode,"invitation")
			film._advance_requested = true
		if mode == "stock":
			_check(mug == null and absf(ali.position.x-300)<0.05,"stock has no mug and Ali remains at the counter")
			continue
		if mug == null:
			_failures.append(mode+" no registered cup")
			break
		var origin := film._stage.to_local(mug.global_position)
		var hand := film._stage.to_local(ali.hand_contact_global(&"front"))
		var grip := film._stage.to_local(mug.to_global(mug.source_point(POINT)))
		var held := film._stage.prop_held(PROP)
		if not initial.is_finite():
			initial = origin
			_check(mug.visible,mode+" cup is initially visible and supported")
		if held:
			var error := grip.distance_to(hand)
			max_error = maxf(max_error,error)
			if first_contact < 0.0:
				first_contact = error
			high = minf(high,origin.y)
			if initial.y-origin.y >= 4.5:
				if mode == "skip":
					film.skip()
					stopped = true
					break
				if mode == "cancel":
					film.cancel()
					stopped = true
					break
				if not carry and absf(origin.x-initial.x) >= 6.0:
					carry = _capture(mode,"held")
		elif first_contact >= 0.0:
			if not released.is_finite():
				released = origin
			if not rest and absf(ali.position.x-300)<0.05:
				rest = _capture(mode,"set-down")
			if not leaving and ali.position.x >= 381.0:
				leaving = _capture(mode,"heading-out")
		rows.append({"frame":frame,"cup":_xy(origin),"grip":_xy(grip),"hand":_xy(hand),
			"ali":_xy(ali.position),"held":held,"visible":mug.visible,"cue_count":cue_count})
	if mode == "normal":
		_check(opening and carry and rest and leaving, "actual invitation, carry, set-down and exit frames captured")
		_check(initial.is_finite() and released.is_finite() and absf(released.x-initial.x+14)<0.15
			and absf(released.y-initial.y)<0.15, "cup released on the original bar top at a new point")
		_check(initial.y-high >= 4.7, "mug visibly lifts over the bar")
	elif mode == "stock":
		_check(opening,"stock authored original invitation captured")
	else:
		_check(stopped, mode+" triggered mid-hold")
	if mode != "stock":
		_check(first_contact >= 0.0 and max_error < 0.04,mode+" painted hand remains on the mug grip")
	_check(cue_count == 2,mode+" retains both original cues")
	for frame in 80:
		if not is_instance_valid(film) or not film.is_running():
			break
		await get_tree().process_frame
	_check(not is_instance_valid(film) or not film.is_running(), mode+" presentation released")
	if is_instance_valid(film):
		film.queue_free()
	await get_tree().process_frame
	_results.append({"mode":mode,"max_error":max_error,"first_contact":first_contact,"opening":opening,
			"initial":_xy(initial) if initial.is_finite() else [],"released":_xy(released) if released.is_finite() else [],
			"highest":high if is_finite(high) else null,"cue_count":cue_count,"rows":rows})


func _capture(mode: String, label: String) -> bool:
	return Capture.image(get_viewport()).save_png(_out.path_join("%s-%s.png" % [mode,label])) == OK


func _xy(value: Vector2) -> Array[float]:
	return [value.x,value.y]


func _check(ok: bool, message: String) -> void:
	if not ok and not message in _failures:
		_failures.append(message)