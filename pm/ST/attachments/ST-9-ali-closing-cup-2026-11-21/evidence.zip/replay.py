from pathlib import Path
from hashlib import sha256
import json
import os
import re
import shutil
import subprocess
import sys

base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
source_commit = (base / "baseline.txt").read_text().strip()
seed_base = base.parent / "evidence-20261120-st9-evening-soup/ali-completion"
seeds = {
    "ordered": (seed_base / "evening_ordered-slot/pending-primary.json", "c3fab5078036fc7ae09618ba6710c89c05ecdd22d0eb833970a3720231e13f51"),
    "sit": (seed_base / "evening_sit-slot/pending-primary.json", "6d50b6b221d35823c5365f4ecc3e7ada67fb1e70007d16d9223676775ca655cf"),
}
cases = {
    "real-ordered-zh": ("ordered", "normal", "zh"),
    "real-sit-en": ("sit", "normal", "en"),
    "real-ordered-skip-ja": ("ordered", "skip", "ja"),
    "real-stall-revisit-en": ("ordered", "revisit", "en"),
}
sha = lambda payload: sha256(payload).hexdigest()
decode = lambda path: json.loads(json.loads(path.read_bytes())["payload"])


def run(name):
    account, mode, language = cases[name]
    seed, fingerprint = seeds[account]
    if mode == "revisit":
        seed = base / "real-ordered-zh" / "slot.json"
        fingerprint = json.loads((seed.parent / "verified.json").read_bytes())["final_sha256"]
    payload = seed.read_bytes()
    assert sha(payload) == fingerprint
    out = base / name
    out.mkdir()
    original = out / "original.json"
    original.write_bytes(payload)
    slot = out / "slot.json"
    slot.write_bytes(payload)
    env = os.environ.copy()
    for key in ("APPDATA", "LOCALAPPDATA", "XDG_DATA_HOME", "XDG_CONFIG_HOME", "TEMP", "TMP", "TMPDIR"):
        (out / key).mkdir()
        env[key] = str(out / key)
    manifest = json.loads((base / "source.json").read_bytes())
    paths = [
        "data/story/ch1_kasa.json", "data/cutscene/stages/ch1_revival_lounge.json", "game/main.gd",
        "game/cutscene/cutscene_player.gd", "autoload/story.gd", "game/props/portal.gd",
        "data/npcs/ch1_ali_lounge.tres", "data/npcs/ch1_ali_stall.tres",
    ]
    source = {path: sha((game / path).read_bytes()) for path in paths}
    assert all(manifest[path] == digest for path, digest in source.items())
    argv = [sys.executable, "-B", str(game / "tools/comfyui/gpu_lock.py"), "--",
            "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(game),
            "--rendering-method", "forward_plus", "--rendering-driver", "vulkan", "--audio-driver", "Dummy",
            "--fixed-fps", "60", "--resolution", "1280x720", "--quit-after", "3800", str(base / "replay.tscn"), "--",
            f"--out={out}", f"--mode={mode}", f"--language={language}"]
    (out / "command.json").write_text(json.dumps({
        "argv": argv, "source": source, "expected_parent": source_commit, "original_path": str(seed),
        "original_sha256": fingerprint,
    }, indent=2) + "\n")
    with (out / "engine.log").open("wb") as log:
        process = subprocess.run(argv, cwd=game, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=235)
    raw = (out / "engine.log").read_text(encoding="utf-8", errors="replace")
    if process.returncode or re.search(r"^SCRIPT ERROR:|^ERROR:", raw, re.M):
        print(raw[-7500:], flush=True)
    report = json.loads((out / "result.json").read_bytes())
    assert process.returncode == 0 and not report["failures"] and not re.search(r"^SCRIPT ERROR:|^ERROR:", raw, re.M), report
    assert report["mode"] == mode and report["language"] == language and report["wallet"] == 234
    assert report["hdr"] and "9070 XT" in report["adapter"] and all(report["captures"].values())
    assert report["starts"] == (0 if mode == "revisit" else 1)
    before, final = decode(original), decode(slot)
    assert final["level"].endswith("ch1_stall.tres") and final["cinematic"] == ""
    assert before["progression"] == final["progression"]
    assert before["story"]["items"] == final["story"]["items"]
    changes = {key: value for key, value in final["story"]["flags"].items() if before["story"]["flags"].get(key) != value}
    assert changes == ({} if mode == "revisit" else {"ch1_lounge_evening_done": True}), changes
    assert all(key in final["story"]["flags"] for key in before["story"]["flags"])
    receipt = {"original_sha256": fingerprint, "final_sha256": sha(slot.read_bytes()),
               "flag_delta": changes, "checks": report["checks"], "source": source}
    (out / "verified.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(f"{name}: {report['checks']} validated, real committed transition, 234 credits.", flush=True)


for case in sys.argv[1:] or cases:
    run(case)