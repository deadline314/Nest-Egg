extends Node

const MainScript := preload("res://game/main.gd")
const Capture := preload("res://tools/viewport_capture.gd")
const ROOM := "res://data/levels/ch1_lounge.tres"
const STALL := "res://data/levels/ch1_stall.tres"
const CLOSING := &"ch1_t_ali_evening_close"
const MUG := "ali_lounge_closing_cup"

var _mode := ""
var _out := ""
var _language := ""
var _main: Node
var _store: RunSaveStore
var _checks := 0
var _faults: Array[String] = []
var _starts := 0
var _path := ""
var _marks: Dictionary = {}


func _ready() -> void:
	if "--syntax-only" in OS.get_cmdline_user_args():
		get_tree().quit()
		return
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
		elif arg.begins_with("--language="):
			_language = arg.trim_prefix("--language=")
	_run.call_deferred()


func _run() -> void:
	Settings.use_storage("user://lounge_replay.cfg")
	Settings.set_light_quality(LightQuality.Tier.HIGH)
	Story.set_language(_language)
	Story.auto_skip = false
	Transition.instant = true
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
	_store = RunSaveStore.new(_out.path_join("slot.json"))
	var initial := _primary()
	var revisiting := _mode == "revisit"
	_path = STALL if revisiting else ROOM
	_check(initial.get("level") == _path, "saved route belongs to the intended authored area")
	_check(initial.get("cinematic") == ("" if revisiting else String(CLOSING)), "exact saved source owns expected pending segment")
	_check(int(initial.get("progression", {}).get("credits", -1)) == 234, "opening primary retains original 234 credits")
	var held_before: Dictionary = initial.get("story", {}).get("items", {})
	var progress_before: Dictionary = initial.get("progression", {})
	Story.scene_started.connect(func(id: StringName, _kind: StringName) -> void:
		if id == CLOSING:
			_starts += 1)
	_main = MainScript.new()
	_main.set("_run_store", _store)
	add_child(_main)
	await _frames(8)
	_main.call("_on_continue_requested")
	_check(await _until(func() -> bool: return _level_at(_path)), "actual Main continues into its original world")
	var lounge_actor := _npc(&"ch1_ali_lounge")
	var stall_actor := _npc(&"ch1_ali_stall")
	if revisiting:
		_check(is_instance_valid(stall_actor) and stall_actor.is_present(), "cold stall has the original only Ali")
		_check(not is_instance_valid(lounge_actor) and _starts == 0, "completed original closing stays closed on cold revisit")
		_check(GameState.has_flag(&"ch1_lounge_evening_done") and not GameState.has_flag(&"ch1_supper_done"), "cold load neither repeats closing nor chooses supper")
		_check(_store.path.get_file() == "slot.json" and _primary().get("progression") == progress_before, "cold load keeps the actual account")
		if is_instance_valid(stall_actor):
			var player := (_main.get("_screen") as Level).player
			player.global_position = stall_actor.global_position + Vector2(-57.0,-2.0)
			player.velocity = Vector2.ZERO
			await _frames(56)
			var screen := get_viewport().get_canvas_transform() * (stall_actor.global_position + Vector2(0,-21))
			_check(get_viewport().get_visible_rect().grow(-35).has_point(screen), "original outdoor Ali is safely inside the screenshot")
		await _capture("revisit-stall")
		await _exit()
		return
	if not is_instance_valid(lounge_actor) or not _level_at(ROOM):
		await _exit()
		return
	var level := _main.get("_screen") as Level
	var portal := level._portals.get(&"lounge_exit") as Portal
	_check(is_instance_valid(portal) and not portal.is_open() and lounge_actor.is_present() and lounge_actor.talk_count == 1, "lounge Ali remains present and the normal exit stays locked before completion")
	_check(await _until(func() -> bool: return Story._current_cinematic == CLOSING and is_instance_valid(Story._player)), "Main opens the exact unfinished authored closing")
	var advanced: Dictionary = {}
	for frame in 520:
		await get_tree().process_frame
		await RenderingServer.frame_post_draw
		if Story._current_cinematic != CLOSING or not is_instance_valid(Story._player):
			break
		var film := Story._player as CutscenePlayer
		if not film.is_running() or not is_instance_valid(film._stage):
			continue
		var actor := film._actors.get(&"ali") as CutsceneActor
		if not is_instance_valid(actor):
			continue
		if film._dialogue.visible and film._dialogue.is_complete():
			var cue := film._current_where
			if not advanced.has(cue):
				advanced[cue] = true
				if advanced.size() == 1:
					_mark("invitation")
				_press(&"ui_accept")
		var mug := film._stage.prop_node(MUG) as StageLayers._Sprite
		if film._stage.prop_held(MUG) and is_instance_valid(mug):
			var stage_position := film._stage.to_local(mug.global_position)
			if stage_position.y < 175.0 and stage_position.x < 283.0:
				_mark("cup")
				if _mode == "skip":
					_press(&"ui_cancel")
		elif actor.position.x >= 381.0 and _mode == "normal":
			_mark("heading-out")
	_check(await _until(func() -> bool: return not Story.is_cinematic_active() and not GameplayLock.is_locked() and not get_tree().paused), "closing releases original cinematic, pause and input locks")
	_check(advanced.size() == 2 and _starts == 1 and _marks.get("cup", false), "both translated lines and physical cup play during the one resumed closing")
	_check(_mode == "skip" or _marks.get("heading-out", false), "unskipped Ali is visible heading away")
	_check(GameState.has_flag(&"ch1_lounge_evening_done") and not GameState.has_flag(&"ch1_supper_done")
		and portal.is_open() and not lounge_actor.is_present() and lounge_actor.talk_count == 2,
		"durable close advances to only the new lounge result and opens the real stall exit")
	var accepted := _primary()
	_check(accepted.get("cinematic") == "" and accepted.get("story", {}).get("flags", {}).get("ch1_lounge_evening_done", false)
		and accepted.get("progression") == progress_before and accepted.get("story", {}).get("items") == held_before,
		"checksum-valid accepted primary keeps wallet, order and held documents")
	FileAccess.open(_out.path_join("accepted-lounge.json"), FileAccess.WRITE).store_buffer(FileAccess.get_file_as_bytes(_store.path))
	if is_instance_valid(portal) and portal.is_open():
		var player := level.player
		player.global_position = portal.global_position + Vector2(-34.0,-2.0)
		player.velocity = Vector2.ZERO
		await _frames(8)
		var armed := portal.is_armed()
		player.global_position = portal.global_position + Vector2(0,-2.0)
		player.velocity = Vector2.ZERO
		_check(armed and await _until(func() -> bool: return _level_at(STALL)), "walk-trigger area enters the original outdoor noodle stall")
	else:
		_check(false, "closing did not provide a usable stall portal")
	stall_actor = _npc(&"ch1_ali_stall")
	_check(is_instance_valid(stall_actor) and stall_actor.is_present() and not is_instance_valid(_npc(&"ch1_ali_lounge")),
		"one ali remains after the normal area change")
	_check(_primary().get("level") == STALL and _primary().get("progression") == progress_before
		and _primary().get("story", {}).get("items") == held_before, "actual persisted stall keeps order, credits and documents")
	await _capture("outdoor-stall")
	await _exit()


func _npc(id: StringName) -> NpcActor:
	var level := _main.get("_screen") as Level
	if level == null:
		return null
	for node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if node is NpcActor and node.data.id == id and level.is_ancestor_of(node):
			return node
	return null


func _level_at(path: String) -> bool:
	var level := _main.get("_screen") as Level
	return level != null and _main.get("_level_path") == path and level.is_initialized() and not _main.call("_route_pending")


func _primary() -> Dictionary:
	return RunSaveCodec.decode(FileAccess.get_file_as_string(_store.path)).get("data", {})


func _mark(name: String) -> void:
	if _marks.has(name):
		return
	_marks[name] = Capture.image(get_viewport()).save_png(_out.path_join(name + ".png")) == OK


func _capture(name: String) -> void:
	await RenderingServer.frame_post_draw
	_mark(name)
	_check(_marks[name], "original game frame saved: " + name)


func _press(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	event = InputEventAction.new()
	event.action = action
	event.pressed = false
	Input.parse_input_event(event)


func _until(predicate: Callable) -> bool:
	for tick in 420:
		if predicate.call():
			return true
		await get_tree().process_frame
	return false


func _frames(count: int) -> void:
	for i in count:
		await get_tree().process_frame


func _check(result: bool, message: String) -> void:
	_checks += 1
	if not result:
		_faults.append(message)


func _exit() -> void:
	var report := FileAccess.open(_out.path_join("result.json"),FileAccess.WRITE)
	report.store_string(JSON.stringify({"adapter":RenderingServer.get_video_adapter_name(),
		"hdr":get_viewport().use_hdr_2d,"mode":_mode,"language":_language,"checks":_checks,"failures":_faults,
		"wallet":Progression.credits,"starts":_starts,"captures":_marks},"  "))
	report.close()
	_main.call("_quit", 0 if _faults.is_empty() else 1)