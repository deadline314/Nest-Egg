extends "res://tools/ch1_flow_probe.gd"

func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	super._ready()


func _capture(frame_name: String) -> void:
	if frame_name == "ST-9-victory" and _route == "stay":
		super._capture(frame_name)
