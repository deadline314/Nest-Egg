from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import sys

root=Path.cwd()
scope=Path(__file__).resolve().parent
sys.path.insert(0,str(root/"tools/story"))
import ch1_runtime_backend as backend

def sha(path):
    return sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_bytes())

actual = backend.OUT
stages = Path(backend.legacy.STAGE_DIR)
with TemporaryDirectory(prefix="derive-ch1-source-",dir=scope) as temporary:
    output=Path(temporary)
    backend.OUT=output/actual.name
    backend.legacy.STAGE_DIR=str(output/"stages")
    assert backend.main()==0
    generated=load(backend.OUT)
    current=load(actual)
    report={
        "chapter":current["chapter"]["id"],
        "scenes":len(current["scenes"]),
        "quests":len(current["quests"]),
        "languages":current["chapter"]["languages"],
        "derived_file_matches":sha(backend.OUT)==sha(actual),
        "document_sha":sha(actual),
        "stage_count":len(list((output/"stages").glob("*.json"))),
        "mismatched_stages":[],
        "scenario_differences":sorted(key for key in generated["scenes"] if generated["scenes"][key]!=current["scenes"].get(key)),
        "keys_different":sorted(set(generated["scenes"]) ^ set(current["scenes"])),
    }
    for stage in sorted((output/"stages").glob("*.json")):
        if not (stages/stage.name).exists() or load(stage)!=load(stages/stage.name):
            report["mismatched_stages"].append(stage.name)
(scope/"rebuild.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report,ensure_ascii=False,indent=2))
assert current == generated and not report["mismatched_stages"]
