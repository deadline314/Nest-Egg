from pathlib import Path
s=Path('work/ch2-evidence-save/probe.gd').read_text()
start=s.index('const PRODUCERS := {');end=s.index('var _producer',start)
s=s[:start]+'''const PRODUCERS := {
 "banyan": {"scene":&"ch2_t_s08_banyan","actor":&"ch2_banyan","level":"res://data/levels/ch2_market.tres","flag":&"ch2_banyan_heard"},
 "rumor": {"scene":&"ch2_t_s08_rumor","actor":&"ch2_hawker","level":"res://data/levels/ch2_market.tres","flag":&"ch2_rumor_heard"},
 "guard": {"scene":&"ch2_t_s09_guard","actor":&"ch2_guard","level":"res://data/levels/ch2_loading.tres","flag":&"ch2_guard_seen"},
 "bridge": {"scene":&"ch2_t_s09_lever","actor":&"ch2_sc1_lever","level":"res://data/levels/ch2_loading.tres","flag":&"ch2_sc1_open"},
}
'''+s[end:]
s=s.replace('var _producer := "contract"','var _producer := "banyan"')
s=s.replace('var _item_notices := 0\n','').replace(' StoryItems.acquired.connect(_observe_item)\n','').replace('_item_notices==0 and ','')
s=s.replace(' and not StoryItems.holds(_definition.item)','').replace(' _check(not StoryItems.holds(_definition.item),"refused reading cannot grant its evidence item")\n','')
a=s.index('func _observe_item(');b=s.index('func _observe_flag(',a);s=s[:a]+s[b:]
s=s.replace('_definition.item','_definition.flag').replace('_evidence_actor','_reading_actor').replace('_drive_evidence','_drive_reading').replace('evidence','reading')
Path('work/ch2-reading-save/probe.gd').write_text(s)
Path('work/ch2-reading-save/probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/ch2-reading-save/probe.gd" id="1"]\n[node name="ReadingCompletionProbe" type="Node"]\nscript = ExtResource("1")\n')
