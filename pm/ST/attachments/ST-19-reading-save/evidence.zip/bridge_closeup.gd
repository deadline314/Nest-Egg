extends "res://tests/probes/ch2_reading_completion.gd"
## Additional actual-primary cold reader, explicit leased camera; no world edits.
func _shot(name: String) -> void:
 await super._shot(name)
 if DisplayServer.get_name()=="headless" or _producer!="bridge":return
 var reaction: PropReaction
 for node: Node in _level().find_children("Reaction_bridge_ladder","Node",true,false):
  if node is PropReaction:reaction=node
 _check(reaction!=null and reaction._swap_node!=null,"close-up uses the actual original bridge reaction")
 if reaction==null or reaction._swap_node==null:return
 var prop: PropNode=reaction._swap_node
 var camera:=_level().camera
 var paused:=get_tree().paused
 get_tree().paused=true
 var acquired:=camera.acquire_presentation_focus(self,prop.to_global(prop.data.size*0.5))
 _check(acquired,"diagnostic camera leases the existing presentation scope without changing world progress")
 if acquired:
  var canvas:=CanvasLayer.new()
  canvas.layer=120
  add_child(canvas)
  var note:=Label.new()
  note.position=Vector2(8,8)
  note.add_theme_font_size_override("font_size",11)
  note.text="ACTUAL ACCEPTED PRIMARY / PAUSED WORLD / CAMERA FOCUS ONLY / SOFTWARE VULKAN"
  canvas.add_child(note)
  await _frames(90)
  await RenderingServer.frame_post_draw
  await super._shot("bridge-prop-cold")
  canvas.queue_free()
  camera.release_presentation_focus(self)
 get_tree().paused=paused
