set -e
source /workspace/.nest-egg-env/activate.sh
engine=/workspace/.nest-egg-env/ci-godot/dist/godot
root=/workspace/Nest-Egg/work/ch2-reading-save/native
mkdir -p "$root"
for producer in banyan rumor guard bridge; do
 for mode in accepted accepted_read; do
  XDG_DATA_HOME="$root/$producer-$mode-profile" python3 tools/comfyui/gpu_lock.py -- xvfb-run -a -s '-screen 0 1280x720x24' "$engine" --path . --rendering-method forward_plus --rendering-driver vulkan --audio-driver Dummy res://tests/probes/ch2_reading_completion.tscn -- --mode="$mode" --producer="$producer" --save-dir="$root/$producer-slot" --out="$root/$producer-$mode" > "$root/$producer-$mode.log" 2>&1
  echo "$producer $mode complete"
 done
done
