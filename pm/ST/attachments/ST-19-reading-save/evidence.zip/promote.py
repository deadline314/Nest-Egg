from pathlib import Path
s=Path('tests/probes/ch2_evidence_completion.gd').read_text()
proto=Path('work/ch2-reading-save/probe.gd').read_text()
block=proto[proto.index('const PRODUCERS := {'):proto.index('var _producer')]
a=s.index('const PRODUCERS := {');b=s.index('var _producer',a);s=s[:a]+block+s[b:]
s=s.replace('var _producer := "contract"','var _producer := "banyan"')
s=s.replace('var _item_notices := 0\n','').replace('\tStoryItems.acquired.connect(_observe_item)\n','')
s=s.replace(' and StoryItems.holds(_definition.item)==accepted','')
s=s.replace('\t\t_check(not StoryItems.is_new(_definition.item),"cold read preserves the ordinary item observer acknowledgement")\n','')
s=s.replace(' and not StoryItems.holds(_definition.item)','')
s=s.replace('\t_check(not StoryItems.holds(_definition.item),"refused reading cannot grant its evidence item")\n','')
s=s.replace('_item_notices==0 and ','').replace('_item_notices==1 and ','').replace(' and StoryItems.holds(_definition.item)','')
s=s.replace(' and disk.story.items.held.has(String(_definition.item))','')
s=s.replace('"ch1_grey_cloth"','"ch1_flood_gate_open"')
s=s.replace('not StoryItems.owns(&"ch1_flood_gate_open")','not GameState.has_flag(&"ch1_flood_gate_open")')
s=s.replace('\tvar saved:=_store.read()\n','').replace('\t_check(not StoryItems.is_new(_definition.item) and saved.get("story",{}).get("items",{}).has("unseen") and JSON.parse_string(JSON.stringify(saved.get("story",{}).get("items",{})))==JSON.parse_string(JSON.stringify(StoryItems.snapshot())),"fresh save preserves ordinary observer acknowledgement without reinstalling an old proposal")\n','')
a=s.index('func _observe_item(');b=s.index('func _observe_flag(',a);s=s[:a]+s[b:]
s=s.replace('_definition.item','_definition.flag').replace('evidence','reading')
s=s.replace('original authored object interactions','original authored interactions')
s=s.replace('one item and flag notification','one flag notification').replace('item, flag and history','flag and history').replace('a different declared item','a different declared flag')
s=s.replace('\t\tawait _shot(_producer+"-cold")','\t\t_check_bridge(accepted)\n\t\tawait _shot(_producer+"-cold")')
s=s.replace('\t_main.call("_save_run")','\t_check_bridge(false)\n\t_main.call("_save_run")',1)
s=s.replace('\tawait _shot(_producer+"-refused")','\t_check_bridge(false)\n\tawait _shot(_producer+"-refused")')
s=s.replace('\tawait _shot(_producer+"-accepted")','\t_check_bridge(true)\n\tawait _shot(_producer+"-accepted")')
s=s.replace('\t_observe_coherent("flag")','\t_observe_coherent("flag")\n\t_check_bridge(true,false)')
s+='''
func _check_bridge(accepted: bool, visual := true) -> void:
	if _producer!="bridge":return
	var level:=_level()
	_check(level!=null,"bridge outcome has the original live Main Level")
	if level==null:return
	var found:=0
	for portal: Portal in level._portals.values():
		if portal.data.requires_flag==&"ch2_sc1_open":
			found+=1
			_check(portal.is_open()==accepted,"original bridge shortcut eligibility agrees with the accepted result")
	_check(found>0,"actual authored bridge shortcut exists in the original area")
	if not visual:return
	var reaction: PropReaction
	for node: Node in level.find_children("Reaction_bridge_ladder","Node",true,false):
		if node is PropReaction:reaction=node
	_check(reaction!=null,"original folded/down bridge prop reaction exists")
	if reaction!=null:
		_check(reaction._swapped==accepted and reaction._swap_node!=null and reaction._swap_node.visible==accepted,"original bridge prop shows folded versus down according to the accepted result")
'''
# Keep the source consistent with project indentation.
s='\n'.join('\t'*(len(line)-len(line.lstrip(' ')))+line.lstrip(' ') for line in s.splitlines())+'\n'
Path('tests/probes/ch2_reading_completion.gd').write_text(s)
Path('tests/probes/ch2_reading_completion.tscn').write_text(Path('tests/probes/ch2_evidence_completion.tscn').read_text().replace('ch2_evidence_completion.gd','ch2_reading_completion.gd'))
