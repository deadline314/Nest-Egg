from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
root=Path('work/ch2-reading-save');console=(root/'required-runner.log').read_text()
m=re.search(r'checks: (\d+), new failures: 0, known failures .*: 0  \(wall time (\d+) s\)',console);assert m
checks,seconds=map(int,m.groups())
for name in ['after','matrix-final','evidence','patroller','native']:
 r=json.loads((root/name/'receipt.json').read_text());assert all(c['passed'] for c in r['cases']),name
assert 'diagnostics=0' in (root/'dummy-exit.log').read_text()
prop_result=json.loads((root/'native-prop/read/result.json').read_text())
assert prop_result['checks']==13 and not prop_result['failures'] and (root/'native-prop/read.exit').read_text().strip()=='0'
assert not re.search(r'^ERROR:|SCRIPT ERROR|Parse Error|^FAIL|leaked at exit|resources still in use',(root/'native-prop/read.log').read_text(),re.M)
folder=Path('pm/ST/attachments/ST-19-reading-save');folder.mkdir(exist_ok=False)
source=root/'delivery-source';source.mkdir(exist_ok=False)
for name in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines():
 p=Path(name)
 if p.is_file():
  target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
shutil.copyfile('/workspace/.nest-egg-env/ci-godot/dist/receipt.json',root/'engine-receipt.json')
images={
 'native/banyan-accepted/banyan-accepted.png':'banyan',
 'native/rumor-accepted/rumor-accepted.png':'rumor',
 'native/guard-accepted/guard-accepted.png':'guard',
 'native/bridge-accepted/bridge-refused.png':'refused',
 'native/bridge-accepted/bridge-accepted.png':'bridge',
 'native-prop/read/bridge-prop-cold.png':'bridge-cold',
}
for name,label in images.items():shutil.copyfile(root/name,Path('pm/ST/images')/('ST-19-reading-'+label+'.png'))
with zipfile.ZipFile(folder/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in {'.json','.log','.exit','.gd','.tscn','.py','.png','.txt','.sh'} and '__pycache__' not in p.parts:
   archive.write(p,str(p.relative_to(root)))
receipt={'base':'2aa735decf043ecb684a642f2658c66d3ce334a4','before':{'processes':4,'checks':48,'failures':20,'git_clean':True},'same_refusal_after':{'processes':4,'checks':48,'failures':0},'reading':{'processes':28,'checks':472,'failures':0},'prior_producers':{'processes':22,'checks':319,'failures':0},'compiler':{'checks':15,'failures':0},'native_software':{'processes':8,'checks':151,'failures':0},'native_prop_cold':{'processes':1,'checks':13,'failures':0},'required':{'groups':9,'checks':checks,'new_failures':0,'known_failures':0,'seconds':seconds},'archive_sha256':hashlib.sha256((folder/'evidence.zip').read_bytes()).hexdigest()}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(folder/'README.md').write_text(f'''# ST-19：人物閱讀與橋梯完成進度

乾淨2aa735de，在原榕伯、小販、守衛查看點與橋梯拉桿真正讀完時，以自己的.tmp目錄造成主檔拒寫；4程序48項有20失敗。旗標、已讀、回訪次數與通知提前生效，原完整主檔bytes保持。樣本明示切進原區域並安排位置，不設定結果旗標，呼叫原人物／物件並送閱讀鍵；不是自然整章流程。

四種來源各有有限契約：原NPC資源、原公眾攤道／裝卸間、原模式、未完成條件與原唯一旗標。作者只明示這四個終端政策，原台詞、翻譯、地圖、數值與通行條件不改。拒寫保留同一原等待者；成功後旗標、歷史與三處world次數先一起持久化，再通知並返回。另一個已宣告旗標或同格假節點也不能授權結果，來源失效只能回原整輪。

- 相同拒寫4程序48項修後全過。正式4來源×接受／接受冷讀／取消／取消冷讀／來源失效／換另一已宣告旗標／同資源同格假節點，共28程序472項全過、0嚴格診斷。每次通知另存原checksum主檔，檢查原等待者尚未返回且三處人物次數一致。
- 橋梯另檢查原通行口與原擺設反應：拒絕／取消不開，接受與冷讀可通行且擺設為放下。通知內檢查邏輯通行，稍後才檢查原畫面反應狀態，不假定同一格已完成繪製。沒有宣稱實際走過捷徑或新增拉桿人物動畫。
- 巡帳員8程序83項與兩份證據14程序236項，共22程序319項全過。作者政策15項通過。原選擇器9組{checks:,}項、0新／已知失敗、{seconds}秒，六份完整退出另驗DummyTexture0；選擇器與已知失敗清單未改。
- 原生Forward+／軟體Vulkan四種接受與冷讀8程序151項全過、0嚴格診斷。初次fixture移位未同步攝影機，有人物在畫面邊緣的原圖；保留native-unsettled，只於測試安排位置時使用原重生鏡頭snap路徑，再完整重跑28程序與8原生程序。沒有更改遊戲鏡頭、曝光、原人物圖或放寬門檻。
- 額外將真正接受的橋梯主檔逐bytes複製，另程序冷讀13項全過。專門近拍使用原攝影機租約並暫停世界，只改取景，不改進度／擺設；畫面明示儀器覆層，整面原橋梯可見。原檔SHA及相同byte複本記在native-prop/source.json。

六張交付原圖均看過。初次及修正後原圖、完整主檔與來源一併保存；上層主線目標與電線通訊是明示進區前／原區域的既有提示，不作本次已讀判據。物件或配角缺少的新外觀、動作與整章人工驗收不以這些圖代替，原驗收條件保持。

引擎是同CI來源／修補／選項的本機4.7.2建置，編譯器不同，不聲稱二進位相同。軟體Vulkan不代稱實體GPU、實體輸入或真人通關。[evidence.zip](evidence.zip)、[receipt.json](receipt.json)。
''')
p=Path('pm/ST/[ST-19]完成第二章故事與關卡.md')
with p.open('a') as stream:
 stream.write(f'''

# Commit-7（人物閱讀與橋梯進度先保存）

## 內文

讀完榕伯往事、小販傳聞、查看守衛或使用橋梯拉桿後，原本即使保存失敗仍會推進進度。現在成功保存後才完成閱讀與回訪進度；拒絕保留原互動可重試，取消保留原進度，來源失效回原完整存檔。橋梯在拒絕時維持關閉，接受及續玩後通行與放下外觀一致。

原版4程序48項有20失敗，相同拒寫樣本修後全過。正式28程序472項、原巡帳員與證據22程序319項、作者資料15項、受影響9組{checks:,}項全部通過。原生軟體Vulkan151項，以及原橋梯存檔近拍冷讀13項全過。樣本明示進區與位置，不代稱自然整章通關；近拍有標示取景用途。

![榕伯閱讀保存後](images/ST-19-reading-banyan.png)
![橋梯進度保存後](images/ST-19-reading-bridge.png)
![原橋梯主檔冷讀，僅租用鏡頭近拍](images/ST-19-reading-bridge-cold.png)

[原始失敗、初次取景、完整主檔及全部驗證](attachments/ST-19-reading-save/README.md)。
''')
print(json.dumps(receipt,indent=2))
