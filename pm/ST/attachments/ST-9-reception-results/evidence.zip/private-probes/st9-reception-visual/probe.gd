extends "res://tests/probes/reception_completion.gd"

func _capture(name: String) -> void:
	if name == "pending":
		var deadline := Time.get_ticks_msec() + 3000
		while Time.get_ticks_msec() < deadline:
			var player: CutscenePlayer = Story._player if is_instance_valid(Story._player) else null
			if is_instance_valid(player) and player._dialogue.visible:
				player._dialogue.complete()
				await _frames(2)
				break
			await _frames(1)
	await super._capture(name)
