#!/bin/bash
exec /workspace/Nest-Egg/work/batch1026/godot-audio-build/dist/godot --verbose "$@"
