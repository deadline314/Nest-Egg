from hashlib import sha256
from pathlib import Path
from shutil import copy2
import copy
import json
import sys

base = Path(__file__).resolve().parent
expected = ["ch2_evidence_contract", "ch2_evidence_receipt", "ch2_evidence_collection"]
ids = ("ch2_t_s10_principal", "ch2_t_s10_interest", "ch2_t_s10_batch")
root = Path.cwd()
sys.path.insert(0, str(root / "tools/story"))
import build_ch2_story
import story_contracts

output = base / "rebuilt-ch2.json"
production = root / "data/story/ch2_heron.json"
baseline = json.loads(production.read_bytes())
build_ch2_story.write_chapter(build_ch2_story.spec(), output)
compiled = json.loads(output.read_bytes())
effects_preserved = {}
for ident in ids:
    created = compiled["scenes"][ident]
    before = baseline["scenes"][ident]
    assert story_contracts.same_effects(created, story_contracts.effect_projection(before))
    changed_result = copy.deepcopy(created)
    changed_result["steps"][-1]["options"][0]["target"] = "ch2_t_s10_revisit"
    assert not story_contracts.same_effects(changed_result, story_contracts.effect_projection(before))
    assert created["steps"][-1].pop("reference_items") == expected
    effects_preserved[ident] = expected
assert compiled == baseline
seal = sha256((root / "data/story_contracts/migration-5a.json").read_bytes()).hexdigest()
assert seal == story_contracts.MIGRATION_SHA
(base / "author-delta.json").write_text(json.dumps({"scenes": effects_preserved, "sealed_migration": seal},
                                                 indent=2) + "\n", encoding="utf-8")
copy2(output, production)
print("Three choice reference lists added. All original dialogue, choices, effects, and routes match.")
