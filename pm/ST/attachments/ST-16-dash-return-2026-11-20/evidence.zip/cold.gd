extends "res://tools/prologue_resume_probe.gd"


func _continue() -> void:
	var record: Dictionary = (_main.get("_run_store") as RunSaveStore).read()
	_check(not record.is_empty(), "early quit left a readable save")
	var deadline := Time.get_ticks_msec() + LIMIT_MSEC
	while Time.get_ticks_msec() < deadline and bool(_main.call("_route_pending")):
		await _frames(10)
	_main.call("_on_continue_requested")
	_check(await _wait_level(PROLOGUE), "cold Continue returns to the original prologue")
	await _frames(120)
	_check(PRACTICE_FLAGS.all(func(flag: StringName) -> bool: return GameState.has_flag(flag)),
		"the real dash and all previous practice remain durable")
	_check(not GameState.has_flag(&"ch1_prologue_service_heard") and not GameState.has_flag(&"ch1_prologue_exit"),
		"the old K talk and exit still need real completion")
	_check(_prologue_scenes_played().is_empty() and not GameplayLock.is_locked(),
		"the optional dash conversation does not lock or replay on Continue")
	var counter: NpcActor
	for node: Node in get_tree().get_nodes_in_group(NpcActor.GROUP):
		if (node as NpcActor).data.id == &"ch1_old_k_counter":
			counter = node as NpcActor
			break
	_check(is_instance_valid(counter) and counter.is_present(), "Old K remains at the counter for the next actual step")
	_check(GameState.deaths == 0 and not GameState.has_flag(&"ch1_first_death_done"), "no death or registration was written")
	await _shot("ST-16-cold-dash-resume")
