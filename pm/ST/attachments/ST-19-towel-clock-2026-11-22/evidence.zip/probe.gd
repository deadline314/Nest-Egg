extends Node

const Capture := preload("res://tools/viewport_capture.gd")

var _out := ""
var _player: CutscenePlayer
var _binding: StagePropBinding
var _push := 0
var _rows: Array[Dictionary] = []
var _sample_limit := 8
var _case := 0
var _native := false
var _drawn_worst := 0.0


func _ready() -> void:
	process_mode = PROCESS_MODE_ALWAYS
	process_priority = 100
	_native = DisplayServer.get_name() != "headless"
	if _native:
		get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--cases="):
			_sample_limit = int(arg.trim_prefix("--cases="))
	if not _out.is_absolute_path():
		get_tree().quit(2)
		return
	_run.call_deferred()


func _run() -> void:
	var authored: Array = Story.audit_data()["scenes"]["ch2_t_s01_settle"]["steps"]
	_push = authored.find_custom(func(step: Dictionary) -> bool:
		return step.get("do") == "prop_move" and step.get("id") == "towel")
	for sample in _sample_limit:
		_case = sample
		_binding = null
		var steps := authored.slice(0, _push + 1)
		steps.append({"do": "wait", "time": 0.35})
		_player = CutscenePlayer.new()
		add_child(_player)
		_player.play(&"ch2_t_s01_settle", {"steps": steps})
		for unused in 1200:
			await get_tree().process_frame
			if not is_instance_valid(_player) or not _player.is_running():
				break
			_record("early", get_process_delta_time())
			if _native:
				await RenderingServer.frame_post_draw
				var draw := _record("draw", get_process_delta_time())
				if not draw.is_empty() and draw["distance"] > _drawn_worst:
					_drawn_worst = draw["distance"]
					Capture.image(get_viewport()).save_png(_out.path_join("worst.png"))
		if is_instance_valid(_player) and _player.is_running():
			_player.cancel()
		for settle in 4:
			await get_tree().process_frame
	var file := FileAccess.open(_out.path_join("contacts.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"frames": _rows, "native": _native, "adapter": RenderingServer.get_video_adapter_name()}, "  ") + "\n")
	file.close()
	var maxima := {}
	for row in _rows:
		var phase: String = row["phase"]
		maxima[phase] = maxf(float(maxima.get(phase, 0.0)), row["distance"])
	print("TOWEL_CLOCK ", _rows.size(), " ", maxima)
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _rows.size() > 20 else 1)


func _process(delta: float) -> void:
	_record("late", delta)


func _record(phase: String, delta: float) -> Dictionary:
	if not is_instance_valid(_player) or not _player.is_running() or _player.steps_run < _push or _player.steps_run > _push + 1:
		return {}
	var actor := _player._actors.get(&"k") as CutsceneActor
	var towel := _player._stage.prop_node("towel")
	if not is_instance_valid(actor) or not is_instance_valid(towel):
		return {}
	if _binding == null:
		_binding = StagePropBinding.new(towel, Vector2(80, 30))
	var parent := actor.get_parent() as Node2D
	var target := parent.to_global(_binding.stage_point(parent))
	var hand := actor.hand_contact_global(&"front")
	var shoulder := actor.rig.bone(&"arm_front_upper").global_position
	var sample := {"phase": phase, "case":_case, "frame":Engine.get_process_frames(), "physics":Engine.get_physics_frames(),
		"steps":_player.steps_run, "delta":delta, "distance":target.distance_to(hand), "towel_x":towel.position.x,
		"target":[target.x,target.y],"hand":[hand.x,hand.y],"shoulder":[shoulder.x,shoulder.y],
		"arm_reach":shoulder.distance_to(target),"actor_t":actor._t,"complete":actor.hand_target_complete(&"front")}
	_rows.append(sample)
	return sample
