extends "res://tests/smoke_test.gd"

func _run() -> void:
	var variant := "before"
	for arg in OS.get_cmdline_user_args():
		if arg == "--after":
			variant = "after"
	var script: Script = load("D:/NestEggVerification/evidence-20261122-st19-towel-clock/%s-suite.gd" % variant)
	var suite: TestSuite = script.new(self)
	await suite.run()
	await _finish()

