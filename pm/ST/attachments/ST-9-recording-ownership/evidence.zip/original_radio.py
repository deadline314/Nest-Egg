from pathlib import Path
import os,sys,subprocess,re,json
sys.path.insert(0,'tools')
from runtime_probe import stop_owned,write_json
root=Path('work/recording-owner-save/original-radio').resolve();root.mkdir(exist_ok=False)
engine='/workspace/.nest-egg-env/ci-godot/dist/godot';rows=[]
for scenario,slot,fault in [('retry','retry',True),('continue','retry',False),('cancel','cancel',False),('continue-cancel','cancel',False)]:
 profile=root/(scenario+'-profile');env=os.environ.copy();env.update(XDG_DATA_HOME=str(profile),APPDATA=str(profile),LOCALAPPDATA=str(profile))
 command=[engine,'--headless','--audio-driver','Dummy','--path',str(Path.cwd()),'res://tools/radio_durable_probe.tscn','--','--scenario='+scenario,'--save-dir='+str(root/(slot+'-slot')),'--out='+str(root/scenario)]+(['--filesystem-fault'] if fault else [])
 timed_out=False
 with (root/(scenario+'.log')).open('w') as log:
  process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  write_json(root/(scenario+'-process.json'),{'pid':process.pid,'command':command})
  try:code=process.wait(timeout=240)
  except subprocess.TimeoutExpired:
   timed_out=True;stop_owned(process)
   try:code=process.wait(timeout=10)
   except subprocess.TimeoutExpired:stop_owned(process,force=True);code=process.wait(timeout=10)
 (root/(scenario+'.exit')).write_text(str(code)+'\n')
 log=(root/(scenario+'.log')).read_text();diagnostics=re.findall(r'^ERROR:.*|SCRIPT ERROR.*|Parse Error.*|^FAIL.*|.*leaked at exit.*|.*resources still in use.*',log,re.M)
 checks=len(re.findall(r'^PASS ',log,re.M));passed=code==0 and not timed_out and not diagnostics and checks>0 and f'RADIO_DURABLE_PROBE scenario={scenario} failures=0' in log
 row={'mode':scenario,'exit':code,'timeout':timed_out,'diagnostics':diagnostics,'result':{'checks':checks,'failures':diagnostics},'passed':passed};rows.append(row);write_json(root/'receipt.json',{'cases':rows});print(scenario,passed,'checks',checks,flush=True)
 if not passed:raise SystemExit(1)
