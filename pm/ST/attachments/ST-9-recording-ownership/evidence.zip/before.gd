extends "res://tests/probes/channel_completion.gd"
const RECORDING := &"ch1_t_booth_recording"
const AREA := "res://data/levels/ch1_booth_alley.tres"
var _store: RunSaveStore
var _started := false
var _notices := 0
var _selected := false
func _run() -> void:
 _main=load("res://game/main.gd").new()
 _store=RunSaveStore.new(_save_dir.path_join("slot.json"))
 _main.set("_run_store",_store)
 add_child(_main)
 await _frames(8)
 _main.call("_on_start_requested",GameState.difficulties[1])
 await _frames(90)
 await _finish_story()
 await _wait_control()
 _main.call("_on_area_requested",AREA)
 await _frames(12)
 await _finish_story()
 await _wait_control()
 _check(not GameState.has_flag(&"ch1_recording_heard") and not Story._completed.has(RECORDING),"original recording is genuinely unheard before its actual original checkpoint event")
 var booth: Checkpoint
 for node: Node in _level()._entities.get_children():
  if node is Checkpoint:booth=node;break
 _check(booth!=null,"actual original alley owns its actual checkpoint booth")
 if booth==null:await _done();return
 _player().global_position=booth.global_position+Vector2(-23,0)
 _player().velocity=Vector2.ZERO
 _level().camera.snap_to_target()
 await _frames(8)
 var scene: Dictionary=Story._scenes[String(RECORDING)]
 match _mode:
  "missing":scene.erase("freeze")
  "foreign":scene["set_flags"]=["ch1_label_guitar_seen"]
  "choice":
   scene.erase("freeze")
   scene["mode"]="animated"
   scene["overlay"]=true
   scene["steps"]=[{"do":"choice","text":"Explicit unregistered recording choice fixture","default":"inject","options":[{"id":"inject","text":"Try an unrelated result","set_flags":{"ch1_label_guitar_seen":true}},{"id":"leave","text":"Leave"}]}]
 Story.scene_started.connect(func(id: StringName,_kind: StringName)->void:
  if id!=RECORDING:return
  _started=true
 )
 GameState.flag_changed.connect(func(flag: StringName,_value: Variant)->void:
  if flag in [&"ch1_recording_heard",&"ch1_label_guitar_seen"]:_notices+=1
 )
 var event:=InputEventAction.new()
 event.action=&"interact"
 event.pressed=true
 Input.parse_input_event(event)
 Input.flush_buffered_events()
 await _frames(1)
 event=event.duplicate()
 event.pressed=false
 Input.parse_input_event(event)
 Input.flush_buffered_events()
 for frame in 3600:
  if _started and _before.is_empty():
   # The real checkpoint event also marks navigation in a later subscriber.
   _main.call("_flush_save")
   _before=FileAccess.get_file_as_bytes(_store.path)
   FileAccess.open(_out.path_join("entry-primary.json"),FileAccess.WRITE).store_buffer(_before)
   if _mode!="foreign":_check(DirAccess.make_dir_absolute(_store.path+".tmp")==OK,"owned IO refusal follows the complete actually saved checkpoint event")
  if _prompt()!=null:break
  if is_instance_valid(Story._player) and Story._player.choice_active():
   _selected=true
   Story._player.choose(0)
  else:
   var confirm:=InputEventAction.new()
   confirm.action=&"ui_accept"
   confirm.pressed=true
   Input.parse_input_event(confirm)
   Input.flush_buffered_events()
   confirm=confirm.duplicate()
   confirm.pressed=false
   Input.parse_input_event(confirm)
   Input.flush_buffered_events()
  if _started and Story._current_cinematic==&"" and not Story._layer._radio_active:break
  await _frames(1)
 await _frames(4)
 _check(_started and booth.activated and GameState.has_checkpoint,"real interaction completes the original phone call and emits its actual checkpoint recording event")
 _check(not GameState.has_flag(&"ch1_recording_heard") and not GameState.has_flag(&"ch1_label_guitar_seen"),"damaged original recording cannot publish its own or another declared flag")
 _check(not Story._completed.has(RECORDING),"unaccepted original recording cannot become completed history")
 _check(_notices==0,"damaged original recording cannot notify a premature result")
 _check(_before.size()>0 and FileAccess.get_file_as_bytes(_store.path)==_before,"refused recording preserves the complete actually saved checkpoint entry primary")
 _check(_prompt()!=null and get_tree().paused,"original recording keeps its own recovery UI despite damaged freeze metadata")
 if _mode=="choice":_check(_selected,"actual checkpoint recording really presents and selects its injected choice")
 FileAccess.open(_out.path_join("observed-primary.json"),FileAccess.WRITE).store_buffer(FileAccess.get_file_as_bytes(_store.path))
 await _shot("recording-"+_mode+"-refused")
 await _done()
func _prompt() -> Control:
 var owner: Node=_main.get("_story_completion")
 return owner.get("_prompt") as Control if is_instance_valid(owner) else null
