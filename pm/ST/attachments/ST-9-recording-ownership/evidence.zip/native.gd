extends "res://tests/probes/recording_completion.gd"
## Observe the genuine reading UI before delegating to the unchanged fixture driver.
func _drive_recording() -> void:
 for frame in 3600:
  if not _issues.is_empty():return
  if _started or _prompt()!=null:break
  await _frames(1)
 if Story._layer._radio_active and Story._layer.is_radio_frozen():
  await _send(&"ui_accept")
  await _shot("recording-original-reading")
 await super._drive_recording()
