from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
root=Path('work/recording-owner-save')
def metric(name,count):
 data=json.loads((root/name/'receipt.json').read_text());rows=data['cases'];assert len(rows)==count and all(c['passed'] for c in rows),name
 return {'processes':count,'checks':sum(c['result']['checks'] for c in rows),'failures':0}
results={name:metric(name,count) for name,count in [('after-corrected',3),('matrix-input',16),('home',16),('original-radio',4),('contracts',1),('native-final',4)]}
before=json.loads((root/'before-corrected/receipt.json').read_text());assert before['git_clean'] and before['base']=='90bb38da43264e98fab2d857ceea5d8fd097e726'
negative={'processes':len(before['cases']),'checks':sum(c['result']['checks'] for c in before['cases']),'failures':sum(len(c['result']['failures']) for c in before['cases'])}
for name in ['matrix-input','home']:
 r=json.loads((root/name/'receipt.json').read_text())
 for filename,sha in r['source_sha256'].items():assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==sha,filename
m=re.search(r'checks: (\d+), new failures: 0, known failures .*: 0  \(wall time (\d+) s\)',(root/'required-runner.log').read_text());assert m
assert 'diagnostics=0' in (root/'dummy-exit.log').read_text()
assert not re.search(r'SCRIPT ERROR|Parse Error|Compile Error|^ERROR:',(root/'formal-import-v4.log').read_text(),re.M)
source=root/'delivery-source';source.mkdir(exist_ok=False)
for name in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines():
 p=Path(name)
 if p.is_file():
  target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
shutil.copyfile('/workspace/.nest-egg-env/ci-godot/dist/receipt.json',root/'engine-receipt.json')
folder=Path('pm/ST/attachments/ST-9-recording-ownership');folder.mkdir(exist_ok=False)
images={'native-final/intact-write/recording-original-reading.png':'reading','native-final/missing-write/recording-missing-refused.png':'refused','native-final/missing-read/recording-cold.png':'cold'}
for name,label in images.items():
 target=Path('pm/ST/images')/('ST-9-recording-owner-'+label+'.png');assert not target.exists();shutil.copyfile(root/name,target)
with zipfile.ZipFile(folder/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix in {'.json','.log','.exit','.gd','.tscn','.py','.png','.txt','.sh','.patch'} and '__pycache__' not in p.parts:archive.write(p,str(p.relative_to(root)))
receipt={'base':before['base'],'negative':negative,**results,'required':{'groups':7,'checks':int(m[1]),'seconds':int(m[2]),'new_failures':0,'known_failures':0},'archive_sha256':hashlib.sha256((folder/'evidence.zip').read_bytes()).hexdigest()}
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(folder/'README.md').write_text(f'''# ST-9：原電話亭錄音的有限來源

乾淨90bb38da，在原電話亭巷用真互動輸入啟動原Checkpoint通話，等原備份事件請求原錄音；不直接呼叫播放、不設已聽或完成旗標。明示刪freeze、換成另一個已宣告旗標、把錄音改成真選項；{negative['processes']}程序{negative['checks']}項有{negative['failures']}失敗。缺freeze／選項以自己的.tmp目錄控制真拒寫；換旗標使用可寫目的地，原版仍保存不屬於原錄音的結果。相同三案例修後{results['after-corrected']['checks']}項全過。

原錄音現在有獨立第一章劇本檔、原radio、布林freeze=true、原唯一旗標及空條件／接續／物品範圍。原旗標owner先依ID承接，缺欄位／另一政策不能轉給其他owner，真正選項門也先拒絕結果。terminal()明確區分返家intro與重要通訊，正常錄音不冒充電影。保留原檢查點及建檔播放入口，不新增地圖限制；未登記的重要通訊維持原語義，不宣稱全部radio皆已有限來源遷移。

正式8種安排各有另程序冷讀，16程序{results['matrix-input']['checks']}項全過：正常IO拒寫及原請求重試、缺freeze、非布林freeze、另一合法政策、另一合法旗標、真選項、錯劇本來源、插入條件。語義損壞測試明示還原載入字典／來源，再按真正原進度恢復；存有未讀呈現入口的情況由原reader續讀，其他情況必須再次按互動鍵撥原亭子。每個通知內檢查live及原checksum主檔的已聽／完成史、原checkpoint區域及原保存座標。接受後冷讀再真的撥一次，原備份仍能用，已聽錄音不重播、不重發結果。entry、completion-entry、refused、publication與最終主檔分別保留原bytes。

電話亭本來就更新checkpoint與導航備份標記，不等於錄音已聽。初次prototype在事件的後段導航訂閱者前取bytes，比到合法備份更新；保留before／after，修正觀察點後在乾淨原版重跑before-corrected，再跑after-corrected，27項修後全過。正式矩陣又遇到未凍結時合法舊狀態自動保存，matrix-v2保留時計／瞄準／時間戳差異。最後只在實際完成gate呼叫前讀主檔，原gate參數、回傳、候選、writer完全透傳；選項在實際choose前取相同觀察點。原gate在結束前還原，沒有用觀察器替代提交或篩掉失敗。

matrix初次的_entry與父類欄位撞名，editor與嚴格runner都有拒絕；只終止自己那個無法載入的程序。probe-first保存該版，修正命名後繼續完整驗證。matrix-final為修正完成邊界的完整版本；matrix-input另外修正原生輸入節奏並完整重跑16程序。native首次只等物理幀，真互動尚未開始，保留失敗與143退出（明示終止自己仍在等待的程序，不是引擎crash）。最後等booth.can_dial並讓按下跨過process／physics處理，再釋放；沒有改遊戲輸入、電話時序或放寬實際通話檢查。

原返家16程序{results['home']['checks']}項與原街道活子彈／敵人凍結的拒寫、重試、取消、冷讀4程序{results['original-radio']['checks']}項全過。街道retry使用真.tmp拒寫，cancel沿用原窄範圍rename故障，不是新的writer。共同audit現在45份宣告／45份契約，{results['contracts']['checks']}項全過。原選擇器7組{int(m[1]):,}項、0新／已知失敗、{int(m[2])}秒，六份完整退出另驗DummyTexture0；選擇器及已知失敗清單未改。

Forward+／軟體Vulkan正常拒寫／重試及缺freeze／原進度恢復各帶另程序冷讀、實際重撥，共4程序{results['native-final']['checks']}項全過，無嚴格診斷。三張交付原圖均看過：真原錄音閱讀、保留原進度提示、冷讀後再備份。閱讀畫面只送真ui_accept揭示原對白，不改文字或可見字數。傳統「已備份」吐司是原checkpoint事件，不能拿它當錄音已聽的判據；已聽判據是上述真旗標、完成史及主檔。

樣本明示進區及位置，不作自然整章通關。原場景提示、角色及道具素材未改，不代稱美術全動作驗收。本機4.7.2與CI同來源／修補／選項，編譯器不同，不宣稱二進位相同。軟體Vulkan與合成事件不代稱實體GPU、實體鍵鼠／手把或真人通關。[完整證據](evidence.zip)、[摘要](receipt.json)。
''')
p=Path('pm/ST/[ST-9]把第一章劇本接進遊戲.md')
with p.open('a') as stream:
 stream.write(f'''

# Commit-32（備份錄音保留原保存保護）

## 內文

電話亭的錄音標記損壞或結果被換掉時，原本可能在保存成功前就算聽過，或保存另一個已知結果。現在原錄音依自身來源保留保存保護；內容不符可恢復原進度，正常磁碟拒寫仍能重試。恢復後由原未讀錄音續讀或再次撥號，真正完成才保存已聽。另程序冷讀後仍能備份，錄音不重播、不重發結果。

原版3程序{negative['checks']}項有{negative['failures']}失敗，相同案例修後全過。正式16程序{results['matrix-input']['checks']}項，原返家{results['home']['checks']}項、原街道通訊{results['original-radio']['checks']}項、來源稽核{results['contracts']['checks']}項，以及受影響7組{int(m[1]):,}項全過。原生軟體Vulkan4程序{results['native-final']['checks']}項全過；實際撥號、閱讀及冷讀後重撥均走原互動。

![原電話亭錄音閱讀](images/ST-9-recording-owner-reading.png)
![內容無效時保留原進度](images/ST-9-recording-owner-refused.png)
![冷讀後可再備份且不重播錄音](images/ST-9-recording-owner-cold.png)

[原始失敗、觀察點與輸入修正、主檔及驗證](attachments/ST-9-recording-ownership/README.md)。位置與進區是明示安排，不代稱自然整章通關。
''')
print(json.dumps(receipt,indent=2))
