extends Node

const CAPTURE := preload("res://tools/viewport_capture.gd")
const MARKET := "res://data/levels/ch2_market.tres"
const SCENE := &"ch2_t_s08_screen"
const PORTRAIT := "res://art/portraits/ch2_shen.png"
var _out := ""
var _language := ""
var _checks := 0
var _failures: Array[String] = []
var _flag_changes: Dictionary = {}
var _motion: Dictionary = {}

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
		elif arg.begins_with("--language="):
			_language = arg.trim_prefix("--language=")
	_run.call_deferred()

func _frames(count: int) -> void:
	for i in count:
		await get_tree().physics_frame

func _check(value: bool, label: String) -> void:
	_checks += 1
	if not value:
		_failures.append(label)

func _press(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await _frames(2)
	event = InputEventAction.new()
	event.action = action
	Input.parse_input_event(event)

func _screenshot(filename: String) -> void:
	await RenderingServer.frame_post_draw
	_check(CAPTURE.image(get_viewport()).save_png(_out.path_join(filename)) == OK, filename)

func _run() -> void:
	_check(Story.set_language(_language), "locale is supported")
	TranslationServer.set_locale(_language)
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Story.auto_skip = true
	var main := load("res://game/main.gd").new() as Node
	main.set("_run_store", RunSaveStore.new(_out.path_join("fixture.json")))
	add_child(main)
	await _frames(25)
	main.call("_on_start_requested", GameState.difficulties[1])
	await _frames(130)
	main.call("_on_area_requested", MARKET)
	var level: Level
	for i in 360:
		await _frames(1)
		level = main.get("_screen") as Level
		if is_instance_valid(level) and level.data.resource_path == MARKET and not GameplayLock.is_locked():
			break
	_check(is_instance_valid(level) and level.data.resource_path == MARKET, "real market loads through Main")
	if not is_instance_valid(level):
		await _finish()
		return
	var notice: NpcActor
	for node in level._entities.get_children():
		if node is NpcActor and node.data.id == &"ch2_notice_screen":
			notice = node
	_check(notice != null and Story.resolve_dispatch(notice.data.talks[0].scene) == SCENE, "original notice dispatch")
	if notice == null:
		await _finish()
		return
	var player := level.player
	player.global_position = notice.global_position + Vector2(-28, 0)
	player.velocity = Vector2.ZERO
	await _frames(110)
	Story.auto_skip = false
	var data: Dictionary = Story._scenes[String(SCENE)]
	var lines := Story.resolved_lines(SCENE)
	_check(data.get("mode") == "radio" and data.get("dismissible") == true and lines.size() == 2,
		"actual notice is a two-line optional transmission")
	if lines.size() != 2:
		await _finish()
		return
	var flags := GameState.world_flags.duplicate(true)
	var count := notice.talk_count
	var layer := Story._layer
	_check(Story.framing.is_interaction_target(notice), "notice owns the original interact action")
	await _press(&"interact")
	for i in 390:
		await _frames(1)
		if layer._radio_root.visible and layer._radio_text.visible_ratio >= 1.0 and layer._radio_text.text == lines[0]["text"]:
			break
	_check(not Story.is_cinematic_active() and not get_tree().paused and not GameplayLock.is_locked() and Story.framing.amount == 0.0,
		"notice leaves the player and framing unlocked")
	_check(layer._radio_portrait.visible and layer._radio_portrait.texture != null and layer._radio_portrait.texture.resource_path == PORTRAIT,
		"announcement shows Shen's actual portrait")
	_check(layer._radio_name.text == lines[0]["name"] and layer._radio_text.text == lines[0]["text"] and layer._radio_text.visible_ratio >= 1.0,
		"all of the first localized line is visible")
	_check(layer._radio_continue.visible and layer._radio_continue.text == UiKit.cinematic_skip_hint(Story.language, &"pause"),
		"the visible dismissal hint matches the actual binding")
	await _screenshot("notice-reading.png")
	_check(not level.hud._controls_card.visible, "notice avoids competing pause instructions")
	var notice_motion := await _measure_movement(player)
	_check(notice_motion > 0.0 and layer._radio_root.visible, "player moves while the notice stays visible")
	await _screenshot("notice-while-moving.png")
	for i in 1000:
		await _frames(1)
		if layer._radio_root.visible and layer._radio_text.visible_ratio >= 1.0 and layer._radio_text.text == lines[1]["text"]:
			break
	_check(layer._radio_root.visible and layer._radio_text.visible_ratio >= 1.0 and layer._radio_text.text == lines[1]["text"],
		"the complete original weather information follows")
	await _screenshot("notice-weather.png")
	for i in 960:
		await _frames(1)
		if notice.talk_count == count + 1 and not layer._radio_root.visible:
			break
	_check(notice.talk_count == count + 1 and not layer._radio_root.visible, "the notice expires and completes once")
	player.global_position = notice.global_position + Vector2(-28, 0)
	player.velocity = Vector2.ZERO
	await _frames(42)
	var free_motion := await _measure_movement(player)
	_motion = {"notice": notice_motion, "normal": free_motion}
	_check(absf(notice_motion - free_motion) < 2.0 and free_motion > 24.0,
		"the same input moves the player equally with and without the notice")
	player.global_position = notice.global_position + Vector2(-28, 0)
	player.velocity = Vector2.ZERO
	await _frames(42)
	await _press(&"interact")
	await _frames(40)
	_check(layer._radio_root.visible and layer._radio_text.text == lines[0]["text"], "returned to notice and replayed it")
	var dodge := InputEventJoypadButton.new()
	dodge.button_index = JOY_BUTTON_B
	dodge.pressed = true
	Input.parse_input_event(dodge)
	await _frames(4)
	dodge = InputEventJoypadButton.new()
	dodge.button_index = JOY_BUTTON_B
	Input.parse_input_event(dodge)
	_check(layer._radio_root.visible and layer._radio_text.text == lines[0]["text"], "controller dodge does not dismiss the notice")
	var skip: InputEvent
	if _language == "en":
		var start := InputEventJoypadButton.new()
		start.button_index = JOY_BUTTON_START
		start.pressed = true
		skip = start
	else:
		var escape := InputEventKey.new()
		escape.physical_keycode = KEY_ESCAPE
		escape.pressed = true
		skip = escape
	_check(skip.is_action_pressed(&"pause"), "actual keyboard or controller input is bound to the shown shortcut")
	await _screenshot("notice-input-hint.png")
	Input.parse_input_event(skip)
	await _frames(5)
	if skip is InputEventKey:
		(skip as InputEventKey).pressed = false
	else:
		(skip as InputEventJoypadButton).pressed = false
	Input.parse_input_event(skip)
	await _frames(45)
	_check(notice.talk_count == count + 2 and not layer._radio_root.visible and not get_tree().paused and not GameplayLock.is_locked(),
		"dismissal closes just the notice without opening the pause menu")
	for flag: Variant in flags.keys() + GameState.world_flags.keys():
		var old: Variant = flags.get(flag)
		var current: Variant = GameState.world_flags.get(flag)
		if old != current:
			_flag_changes[flag] = [old, current]
	_check(not _flag_changes.keys().any(func(key: Variant) -> bool: return str(key).begins_with("ch2_")) and not notice.data.talks[0].has_reward(),
		"notice changes no Chapter 2 flags and remains reward-free")

	await _finish()

func _measure_movement(player: Player) -> float:
	var start := player.global_position.x
	var movement := InputEventAction.new()
	movement.action = &"move_right"
	movement.pressed = true
	Input.parse_input_event(movement)
	await _frames(21)
	movement = InputEventAction.new()
	movement.action = &"move_right"
	Input.parse_input_event(movement)
	return player.global_position.x - start

func _finish() -> void:
	FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE).store_string(JSON.stringify({
		"checks": _checks, "failures": _failures, "adapter": RenderingServer.get_video_adapter_name(),
		"language": _language, "changed_flags": _flag_changes, "motion": _motion,
	}, "\t"))
	await AudioRelease.settle(get_tree())
	get_tree().quit(0 if _failures.is_empty() else 1)
