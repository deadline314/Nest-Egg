extends "res://tools/prologue_play_probe.gd"

const PROLOGUE := "res://data/levels/ch1_prologue.tres"
const PAWNSHOP := "res://data/levels/ch1_pawnshop.tres"
var _start := -1
var _last := -1
var _read_frames := 18
var _free := 0
var _transitions := 0
var _excluded := 0
var _story_frames := 0
var _line_advances := 0
var _phase_frames := {}
var _remaining := {}
var _results_saved := false
var _dash_mode := ""
var _dash_from := INF
var _dash_movement := 0.0
var _dash_visible := {}
var _dash_readable_span := {}
var _dash_lines: PackedStringArray = []
var _dash_finished := false
var _workbench_shot := false


func _ready() -> void:
	get_window().set_flag(Window.FLAG_NO_FOCUS, true)
	process_mode = Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg == "--careful":
			_read_frames = 66
	Story.auto_skip = false
	Settings.set_skip_cutscenes(false)
	Story.scene_started.connect(func(id: StringName, kind: StringName) -> void:
		if id == &"ch1_p04_dash":
			_dash_mode = String(kind)
			for line in Story.resolved_lines(id):
				_dash_lines.append(String(line["text"])))
	Story.scene_finished.connect(func(id: StringName) -> void:
		if id == &"ch1_p04_dash":
			_dash_finished = true)
	super._ready()


func _physics_process(_delta: float) -> void:
	if _results_saved or not is_instance_valid(_main):
		return
	var current: Variant = _main.get("_screen")
	var level := current as Level if is_instance_valid(current) else null
	if level != null:
		_watch_dash_cue(level)
	if _start < 0:
		if level == null or level.data.resource_path != PROLOGUE or not is_instance_valid(level.player):
			return
		_start = Engine.get_physics_frames()
	if level != null and level.data.resource_path == PAWNSHOP:
		_last = Engine.get_physics_frames()
		_results_saved = true
		_save_pacing()
		return
	if level != null and is_instance_valid(level._pause_menu) and level._pause_menu._root.visible:
		_excluded += 1
		return
	var scene := Story._current_cinematic
	if Story.is_cinematic_active() and scene != &"":
		_story_frames += 1
		_phase_frames[String(scene)] = int(_phase_frames.get(String(scene), 0)) + 1
	elif level == null or _main.get("_pending_screen") != null:
		_transitions += 1
	else:
		_free += 1


func _confirm_reading() -> void:
	var action := InputEventAction.new()
	action.action = &"ui_accept"
	action.pressed = true
	Input.parse_input_event(action)
	var release := action.duplicate() as InputEventAction
	release.pressed = false
	Input.parse_input_event(release)


func _finish_story(shot := "") -> void:
	var capture := false
	var previous := ""
	var ready_frames := 0
	for i in 7200:
		if not Story.is_cinematic_active() and not Story._layer.is_radio_frozen():
			return
		var playable := Story._player
		var kind := ""
		var ready := false
		if is_instance_valid(playable) and playable.is_running():
			if playable.choice_active():
				kind = String(Story._current_cinematic) + ":choice"
				ready = true
			elif is_instance_valid(playable._dialogue) and playable._dialogue.visible:
				kind = playable._current_where
				ready = playable._dialogue.is_complete()
		elif Story._layer.is_cinematic_active():
			kind = "%s:%d" % [Story._current_cinematic, Story._layer._cinematic_index]
			ready = Story._layer._text.visible_ratio >= 1.0
		elif Story._layer.is_radio_frozen():
			kind = "radio:" + String(Story._layer._radio_text.text)
			ready = Story._layer._radio_text.visible_ratio >= 1.0
		if kind != previous or not ready:
			ready_frames = 0
		elif ready:
			ready_frames += 1
		previous = kind
		if ready and Story._current_cinematic == &"ch1_p02_talk" and not _workbench_shot and Story._layer._text.text.begins_with("四十八萬"):
			_workbench_shot = true
			_capture_snapshot.call_deferred("workbench-choice.png")
		if not shot.is_empty() and not capture and ready:
			capture = true
			await _shot(shot)
		if ready and ready_frames == _read_frames:
			_confirm_reading()
			_line_advances += 1
		await _frames(1)
	_check(false, "the reading on the original route must finish with normal confirmation")


func _save_pacing() -> void:
	var total := _last - _start - _excluded
	var summary := {"true_in_game_frames":total, "physics_fps":Engine.physics_ticks_per_second,
		"story_frames":_story_frames, "playable_frames":_free,"transition_frames":_transitions,
		"pause_menu_frames_excluded":_excluded,"ordinary_confirmations":_line_advances,
		"frames_after_typeset":_read_frames,"story_frames_by_scene":_phase_frames,
		"release_path":_played,"deaths":GameState.deaths, "dash_delivery":_dash_mode, "dash_move":_dash_movement, "dash_finished":_dash_finished, "dash_visible_frames":_dash_visible, "dash_text":_dash_lines,"dash_readable_span":_dash_readable_span}
	var output := FileAccess.open(_out.path_join("pacing.json"), FileAccess.WRITE)
	output.store_string(JSON.stringify(summary, "  ") + "\n")
	print("PROLOGUE_PACING ",JSON.stringify(summary))


func _watch_dash_cue(level: Level) -> void:
	if level.data.resource_path != PROLOGUE or _dash_mode.is_empty():
		return
	if _dash_from == INF:
		_dash_from = level.player.global_position.x
	if not GameplayLock.is_locked():
		_dash_movement = maxf(_dash_movement, absf(level.player.global_position.x - _dash_from))
	var host := level._bubbles
	host._layout_boxes()
	for bubble: Dictionary in host._active:
		if bubble["id"] != &"ch1_p04_dash" or bubble["leaving"]:
			continue
		var rect: Rect2 = bubble.get("rect", Rect2())
		if rect.has_area() and float(bubble["age"]) >= 0.12:
			_record_dash_text(String(bubble["text"]))
	var radio := Story._layer
	if is_instance_valid(radio._radio_text) and radio._radio_root.visible and radio._radio_text.visible_ratio >= 1.0 and String(radio._radio_text.text) in _dash_lines:
		_record_dash_text(radio._radio_text.text)


func _record_dash_text(line: String) -> void:
	var index := _dash_lines.find(line)
	if index < 0:
		return
	_dash_visible[line] = int(_dash_visible.get(line, 0)) + 1
	var active := _player()
	if active != null and not GameplayLock.is_locked():
		var x := active.global_position.x
		var span: Array = _dash_readable_span.get(line, [x, x])
		_dash_readable_span[line] = [minf(span[0], x), maxf(span[1], x)]
	if _dash_visible[line] == 24:
		_capture_snapshot.call_deferred("cue-line-%d.png" % index)


func _capture_snapshot(filename: String) -> void:
	await RenderingServer.frame_post_draw
	var image := preload("res://tools/viewport_capture.gd").image(get_viewport())
	image.save_png(_out.path_join(filename))


