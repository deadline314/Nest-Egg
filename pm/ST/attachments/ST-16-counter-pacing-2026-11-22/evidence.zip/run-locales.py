from pathlib import Path
from hashlib import sha256
import json,os,shutil,subprocess,sys

base=Path(__file__).resolve().parent
shared=base.with_name("ne218-baseline-20261117")
engine="C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
original=shared/"tests/fixtures/prologue_counter"
known={row["file"]:row["sha256"] for row in json.loads((original/"provenance.json").read_bytes())}
for lang in ("zh","ja","en"):
    for phase in ("fall","clean","call"):
        out=base/f"locale-{lang}-{phase}"
        for key in ("profile","save","screens"):
            (out/key).mkdir(parents=True,exist_ok=False)
        file=phase+".json"
        seed=original/file
        assert sha256(seed.read_bytes()).hexdigest()==known[file]
        shutil.copyfile(seed,out/"save/slot.json")
        profile=str(out/"profile")
        env=os.environ.copy()
        env.update(APPDATA=profile,LOCALAPPDATA=profile,XDG_DATA_HOME=profile,XDG_CONFIG_HOME=profile)
        command=[sys.executable,"-B",str(shared/"tools/comfyui/gpu_lock.py"),"--",engine,
                 "--path",str(shared),"--resolution","1280x720","--audio-driver","Dummy","--fixed-fps","60",
                 "--rendering-method","forward_plus","--rendering-driver","vulkan",str(base/"locale.tscn"),
                 "--",f"--story-language={lang}",f"--mode={phase}_normal",f"--save-dir={out/'save'}",f"--out={out/'screens'}"]
        with (out/"raw.log").open("wb") as log:
            run=subprocess.run(command,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
        (out/"exit.txt").write_text(str(run.returncode)+"\n")
        raw=(out/"raw.log").read_text(encoding="utf-8")
        assert run.returncode==0 and "Forward+" in raw and "RX 9070 XT" in raw and "ERROR:" not in raw and "FAIL " not in raw, raw[-3300:]
        text=json.loads((out/"screens/text.json").read_bytes())
        result=json.loads((out/"screens/result.json").read_bytes())
        assert text["language"]==lang and len(text["lines"])==(4 if phase=="call" else 5)
        assert result["failures"]==[] and result["deaths"]==0 and result["checks"]>=27
        print(lang,phase,"checks",result["checks"],"visual lines",[row["visual_lines"] for row in text["lines"]],flush=True)
