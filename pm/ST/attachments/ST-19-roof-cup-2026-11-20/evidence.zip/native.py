from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import os
import subprocess
import sys

root=Path.cwd()
base=Path(__file__).resolve().parent
shared=Path('D:/NestEggVerification/ne218-baseline-20261117')
previous=base.parent/'evidence-20261120-st19-roof-weather/published-source.json'
mode=sys.argv[1]
tag=sys.argv[2]
source=json.loads((previous if mode=='before' else base/'source.json').read_bytes())
def held():
    return all(sha256((shared/path).read_bytes()).hexdigest()==value for path,value in source.items())
assert held()
dest=base/tag
(dest/'slot').mkdir(parents=True)
if mode in ('cold','cold-skip'):
    copyfile(base/('native-final' if mode=='cold' else 'native-skip')/'slot/slot.json',dest/'slot/slot.json')
else:
    copyfile(root/'work/st19-booth-rain-20261120/after/normal/slot/slot.json',dest/'slot/slot.json')
env=os.environ.copy()
for name in ('APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME'):
    env[name]=str(dest/'profile'/name)
cmd=[sys.executable,'-B',str(root/'tools/comfyui/gpu_lock.py'),'--',
     'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(shared),'--rendering-method','forward_plus',
     '--rendering-driver','vulkan','--audio-driver','WASAPI','--resolution','1280x720','--max-fps','60',
     str(base/'briefing.tscn'),'--','--mode='+mode,'--save-dir='+str(dest/'slot'),'--out='+str(dest)]
(dest/'command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf-8')
with (dest/'raw.log').open('wb') as log:
    proc=subprocess.run(cmd,cwd=shared,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
raw=(dest/'raw.log').read_text(encoding='utf-8',errors='replace')
receipt={'exit':proc.returncode,'source_held':held(),
         'issues':[line for line in raw.splitlines() if 'ERROR:' in line or 'WARNING: [CutsceneReach]' in line]}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(raw[-4800:],receipt,flush=True)
assert proc.returncode==0 and receipt['source_held'] and not receipt['issues'] and 'RX 9070 XT' in raw


