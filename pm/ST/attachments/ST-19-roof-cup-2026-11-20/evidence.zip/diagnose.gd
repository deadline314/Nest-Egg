extends "res://tools/ch1_flow_probe.gd"

const ROOF := "res://data/levels/ch2_rooftop.tres"
const EGRET := &"ch2_egret"
const CARD := "public_aisle_pass"
const CARD_ITEM := &"ch2_check_card"
var _slot := ""
var _mode := "before"
var _main: Node
var _observations: Array[Dictionary] = []
var _states: Dictionary = {}
var _skipped := false
var _tea := {}
var _tea_error := 0.0
var _tea_drift_y := 0.0
var _tea_hold_frames := 0

func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_slot = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
	process_mode = Node.PROCESS_MODE_ALWAYS
	process_priority = 20
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()

func _run() -> void:
	_shots = {"ch2_t_s03_tea":"tea-before-briefing", "ch2_t_s03_brief":"briefing-open", "ch2_t_s03_rain":"briefing-ends"}
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", RunSaveStore.new(_slot.path_join("slot.json")))
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(50)
	var resumed := _mode == "cold" or _mode == "cold-skip"
	_check(GameState.has_flag(&"ch2_brief_done") == resumed and StoryItems.holds(CARD_ITEM) == resumed,
			"the original save has precisely its expected briefing and card state")
	_main.call("_on_area_requested", ROOF)
	await _settle(55)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.resource_path == ROOF and _object(EGRET) != null, "entered the actual rooftop and original Egret source")
	if _level == null or _object(EGRET) == null:
		_finish_report([])
		return
	var acquisitions := [0]
	StoryItems.acquired.connect(func(item: StoryItemData) -> void:
		if item.id == CARD_ITEM:
			acquisitions[0] += 1)
	var scenes: Array[String] = []
	Story.scene_started.connect(func(id: StringName, _what: StringName) -> void: scenes.append(String(id)))
	if resumed:
		_check(await _talk(EGRET, ["leave"]), "a cold reopen reaches the original rooftop topics")
		_check(StoryItems.holds(CARD_ITEM) and not scenes.has("ch2_t_s03_brief") and _states.is_empty() and acquisitions[0] == 0,
				"cold revisits retain the card without repeating its presentation")
		_finish_report(scenes)
		return
	if _mode == "skip-cup":
		_check(await _talk(EGRET), "one Escape interrupts the live cup movement")
		_check(_skipped and _tea.has("start") and not _tea.has("settled") and _states.is_empty(),
				"the actual cup was held before interruption, before any card appears")
		_check(not GameState.has_flag(&"ch2_brief_done") and not StoryItems.holds(CARD_ITEM)
				and not Story.is_cinematic_active() and acquisitions[0] == 0, "the interrupted cup does not publish the original card or leave a stage active")
		_tea.clear()
		_tea_error = 0.0
		_tea_drift_y = 0.0
		_tea_hold_frames = 0
		scenes.clear()
	if _mode == "skip-retry":
		_check(await _talk(EGRET), "one Escape returns from the original briefing")
		_check(_skipped and _states.has("egret-card") and not _states.has("rin-card"),
				"the interruption occurs while the first actor holds the card")
		_check(not GameState.has_flag(&"ch2_brief_done") and not StoryItems.holds(CARD_ITEM)
				and not Story.is_cinematic_active() and acquisitions[0] == 0, "the interruption never awards an unfinished card or strands the stage")
		scenes.clear()
	_check(await _talk(EGRET), "the original interaction completes")
	_check(GameState.has_flag(&"ch2_brief_done") and StoryItems.holds(CARD_ITEM) and acquisitions[0] == 1, "briefing and the one original inventory card arrive together")
	_check(scenes.has("ch2_t_s03_tea") and scenes.has("ch2_t_s03_brief") and scenes.has("ch2_t_s03_rain"), "the original three sections occurred")
	if _mode in ["normal","normal-final","skip-retry","skip-cup"]:
		_check(_states.has("egret-card") and _states.has("rin-card"), "both actual hands held the same card in the right order")
		_check(float(_states.get("egret-card", 10000.0)) < 0.25 and float(_states.get("rin-card", 10000.0)) < 0.25,
				"both palm contacts fit the actual card within the existing hold tolerance")
		_check(_states.has("card-hidden"), "Rin stows the physical card before the conversation returns")
	elif _mode == "before":
		_check(_states.is_empty(), "published original grants a card without presenting it on stage")
	var left := Vector2(292.56,204.18)
	var right := Vector2(300.4,204.18)
	_check(Vector2(_tea.get("initial",Vector2.INF)).distance_to(left) < 0.12, "the original cup starts on its tabletop contact")
	_check(Vector2(_tea.get("settled",Vector2.INF)).distance_to(right) < 0.12, "the cup slides toward the center, stays on the tabletop, and is released")
	_check(_tea_error < 0.25 and _tea_drift_y < 0.08 and _tea_hold_frames >= 12,
			"Egret's painted front hand carries the original cup horizontally throughout")
	_check(Vector2(_tea.get("brief",Vector2.INF)).distance_to(right) < 0.12 and
			Vector2(_tea.get("rain",Vector2.INF)).distance_to(right) < 0.12,
			"the briefing and rain shots both retain the new cup position")
	_finish_report(scenes)

func _finish_report(scenes: Array) -> void:
	var result := {"mode":_mode,"failures":_failures,"scenes":scenes,"states":_states,"observations":_observations,
			"brief_done":GameState.has_flag(&"ch2_brief_done"),"card":StoryItems.holds(CARD_ITEM),"escaped":_skipped,"cup":_tea,"cup_hand_max":_tea_error,"cup_y_drift_max":_tea_drift_y,"cup_hold_frames":_tea_hold_frames}
	var report := FileAccess.open(_out_dir.path_join("result.json"),FileAccess.WRITE)
	report.store_string(JSON.stringify(result,"  ") + "
")
	report.close()
	get_tree().quit(0 if _failures == 0 else 1)

func _process(_delta: float) -> void:
	var player: CutscenePlayer = Story._player
	if is_instance_valid(player) and is_instance_valid(player._stage) and player.scene_id in [&"ch2_t_s03_tea", &"ch2_t_s03_brief", &"ch2_t_s03_rain"]:
		_observe_cup(player)
	if not is_instance_valid(player) or player.scene_id != &"ch2_t_s03_brief" or not is_instance_valid(player._stage):
		return
	var egret: CutsceneActor = player._actors.get(&"egret")
	var rin: CutsceneActor = player._actors.get(&"rin")
	if not is_instance_valid(egret) or not is_instance_valid(rin):
		return
	if _observations.is_empty():
		for actor: CutsceneActor in [egret,rin]:
			var shoulder := actor.rig.bone(&"arm_front_upper")
			var arm_length := actor.rig.rest(&"arm_front_lower").length() + actor.rig.rest(&"hand_front").length()
			_observations.append({"actor":str(actor.actor_id),"root":str(actor.position),"shoulder":str(player._stage.to_local(shoulder.global_position)),"arm_length":arm_length})
	var sprite := player._stage.prop_node(CARD) as StageLayers._Sprite
	if not is_instance_valid(sprite):
		return
	if not sprite.visible:
		if _states.has("rin-card"):
			_states["card-hidden"] = true
		return
	if not player._stage.prop_held(CARD):
		return
	for hold: StagePropHold in player._stage._held:
		var owner := "egret-card" if hold.owns_actor(egret) else "rin-card" if hold.owns_actor(rin) else ""
		if hold.prop_id != CARD or owner.is_empty() or _states.has(owner):
			continue
		var actor := egret if owner=="egret-card" else rin
		var contact := Vector2(246.5,264.5) if actor==egret else Vector2(138.5,287.5)
		_states[owner] = player._stage.to_local(sprite.to_global(sprite.source_point(contact))).distance_to(
				player._stage.to_local(actor.hand_contact_global(&"front")))
		_save_frame.call_deferred(owner)
		if _mode == "skip-retry" and not _skipped:
			_skipped = true
			var down := InputEventKey.new()
			down.keycode = KEY_ESCAPE
			down.pressed = true
			Input.parse_input_event(down)
			var up := down.duplicate() as InputEventKey
			up.pressed = false
			Input.parse_input_event(up)

func _save_frame(name: String) -> void:
	await RenderingServer.frame_post_draw
	_capture(name)


func _observe_cup(player: CutscenePlayer) -> void:
	var stage := player._stage
	var sprite := stage.prop_node("rin_roof_cup") as StageLayers._Sprite
	var egret: CutsceneActor = player._actors.get(&"egret")
	if not is_instance_valid(sprite) or not is_instance_valid(egret):
		return
	var point := stage.to_local(sprite.to_global(sprite.source_point(Vector2(126,234))))
	if player.scene_id == &"ch2_t_s03_tea" and player._current_where.contains("第 6 步"):
		var rig := egret.rig
		var skeleton := rig.get("_skeleton") as Skeleton2D
		var local_inverse := skeleton.global_transform.affine_inverse()
		var shoulder := local_inverse * rig.bone(&"arm_front_upper").global_position
		var offset := rig.hand_source_point(&"front",Vector2(75.5,36.5))
		var limits := rig.rest(&"arm_front_lower").length()+rig.rest(&"hand_front").length()
		print("FIT ",egret.position," ",egret.pose," ",stage.to_local(rig.bone(&"arm_front_upper").global_position)," ",offset," ",limits)
		for x in range(313,336,2):
			for degrees in [180.0, 210.0, 240.0, 250.0, 270.0]:
				var direction := local_inverse.basis_xform(stage.global_transform.basis_xform(Vector2.from_angle(deg_to_rad(degrees)))).angle()
				var needed := 0.0
				for world in [Vector2(292.56,204.18),Vector2(300.4,204.18)]:
					world.x -= x-egret.position.x
					var target: Vector2 = local_inverse * stage.to_global(world)
					needed=maxf(needed,shoulder.distance_to(target-offset.rotated(direction)))
				print("FIT_X ",x," angle ",degrees," max ",snappedf(needed,0.01))
		get_tree().quit(0)
		return
	if player.scene_id == &"ch2_t_s03_brief":
		_tea["brief"] = point
		return
	if player.scene_id == &"ch2_t_s03_rain":
		_tea["rain"] = point
		return
	if not _tea.has("initial"):
		_tea["initial"] = point
		_save_frame.call_deferred("cup-on-table")
	if stage.prop_held("rin_roof_cup"):
		var palm := stage.to_local(egret.hand_contact_global(&"front"))
		_tea_error = maxf(_tea_error,palm.distance_to(point))
		_tea_drift_y = maxf(_tea_drift_y,absf(point.y-204.18))
		_tea_hold_frames += 1
		if not _tea.has("start"):
			_tea["start"] = point
			_save_frame.call_deferred("cup-in-hand")
			if _mode == "skip-cup" and not _skipped:
				_skipped = true
				_interrupt_cup.call_deferred()
		return
	if _tea.has("start") and not _tea.has("settled"):
		_tea["settled"] = point
		_save_frame.call_deferred("cup-moved")


func _interrupt_cup() -> void:
	var event := InputEventKey.new()
	event.keycode = KEY_ESCAPE
	event.pressed = true
	Input.parse_input_event(event)
	event = event.duplicate() as InputEventKey
	event.pressed = false
	Input.parse_input_event(event)


