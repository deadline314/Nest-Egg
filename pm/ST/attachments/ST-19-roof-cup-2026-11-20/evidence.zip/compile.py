from pathlib import Path
from subprocess import check_output
import json
import sys

base=Path(__file__).resolve().parent
root=Path.cwd()
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'tools/story'))
import build_ch2_story
from chapter_compiler import write_chapter
import roof_tea_staging as tea

out=base/'candidate.json'
chapter=build_ch2_story.spec()
assert not write_chapter(chapter,out)
original=json.loads(check_output(['git','show','HEAD:data/story/ch2_heron.json']))
data=json.loads(out.read_bytes())
assert list(original)==list(data) and list(original['scenes'])==list(data['scenes'])
assert [key for key in original if original[key]!=data[key]]==['scenes']
changed=[key for key in original['scenes'] if original['scenes'][key]!=data['scenes'][key]]
assert changed==['ch2_t_s03_tea','ch2_t_s03_brief','ch2_t_s03_rain']
for ident in changed:
    before,after=original['scenes'][ident],data['scenes'][ident]
    assert {k:v for k,v in before.items() if k!='steps'}=={k:v for k,v in after.items() if k!='steps'}
    steps=after['steps']
    if ident=='ch2_t_s03_tea':
        assert steps[:3]==before['steps'][:3]
        end=3+len(tea.slide_cup())
        assert steps[3:end]==tea.slide_cup()
        assert steps[end:]==before['steps'][3:]
    else:
        assert steps[0]==dict(before['steps'][0],props=tea.briefing_props())
        assert steps[1:]==before['steps'][1:]
for stage in build_ch2_story.ch2_stages.STAGES:
    formal=root/f'data/cutscene/stages/{stage.ident}.json'
    assert stage.definition()==json.loads(formal.read_bytes())
info={'scenes':len(data['scenes']), 'quests':len(data['quests']), 'changes':changed,
      'stages':len(build_ch2_story.ch2_stages.STAGES),'only_presentation_diff':True,
      'target_pos':tea.briefing_props()[tea.CUP]['pos']}
(base/'compile-proof.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
(root/'data/story/ch2_heron.json').write_bytes(out.read_bytes())
print(info)

