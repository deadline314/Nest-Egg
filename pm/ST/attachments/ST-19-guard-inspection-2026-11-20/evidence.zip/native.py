from pathlib import Path
from shutil import copy2
import json
import os
import re
import subprocess
import sys

project = Path.cwd()
base = Path(__file__).resolve().parent
seed = base.parent/"evidence-20261120-st19-guard-visual/final/cancel-slot/slot.json"
tag = sys.argv[1]
root = base/tag
root.mkdir()
setting = ("stock",) if tag == "stock" else ("left","right","cancel","air","cold")
if len(sys.argv)>2:
    setting=tuple(sys.argv[2:])
for case in setting:
    folder = root/case
    folder.mkdir()
    env = os.environ.copy()
    for key in ("APPDATA","LOCALAPPDATA","TEMP","TMP","TMPDIR","XDG_CONFIG_HOME","XDG_DATA_HOME"):
        path = folder/key
        path.mkdir()
        env[key] = str(path)
    save = folder/"slot.json"
    copy2(root/"left"/"slot.json" if case == "cold" else seed, save)
    command = [sys.executable,"-B",str(project/"tools/comfyui/gpu_lock.py"),"--",
        "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe","--path",str(project),"--fixed-fps","60",
        "--rendering-method","forward_plus","--rendering-driver","vulkan","--resolution","1280x720","--quit-after","5000",
        str(base/"observe.tscn"),"--","--out="+str(folder),"--mode="+case,"--slot="+str(save)]
    (folder/"command.json").write_text(json.dumps(command,indent=2)+"\n")
    with (folder/"engine.log").open("wb") as log:
        process = subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=170)
    evidence=(folder/"engine.log").read_text(encoding="utf-8",errors="replace")
    diagnostics=[line for line in evidence.splitlines() if re.search(r"^(?:SCRIPT )?ERROR:|Parse Error|^FAIL|leaked at exit",line)]
    assert process.returncode==0 and not diagnostics, (case,evidence[-5400:])
    result = json.loads((folder/"inspection.json").read_bytes())
    assert result["failed"] == 0
    print(case,{"visible":result["crouch"],"states":len(result["poses"]),"read":result["story_flag"]},flush=True)

