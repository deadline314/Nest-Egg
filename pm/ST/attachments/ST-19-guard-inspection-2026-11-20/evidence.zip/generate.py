from pathlib import Path
import importlib.util
import json
import sys

root = Path.cwd()
scope = Path(__file__).resolve().parent
sys.path.insert(0, str(root/"tools/story"))
import build_ch2_story as builder

def write(path):
    builder.write_chapter(builder.spec(), path)
    return json.loads(path.read_bytes())

reference = write(scope/"stock_ch2_heron.json")
old = json.loads((root/"data/story/ch2_heron.json").read_bytes())
assert reference == old, "checked-in chapter differs from its original author source"
module_spec = importlib.util.spec_from_file_location("candidate_ch2_source",scope/"candidate-source/tools/story/ch2_source.py")
module = importlib.util.module_from_spec(module_spec)
sys.modules[module_spec.name] = module
module_spec.loader.exec_module(module)
builder.ch2_source = module
import story_contracts
from shutil import copy2

contracts = scope/"candidate-source/data/story_contracts"
contracts.mkdir(parents=True,exist_ok=True)
for path in (root/"data/story_contracts").glob("*.json"):
    copy2(path,contracts/path.name)
rule_path = contracts/"ch2.json"
raw = rule_path.read_text(encoding="utf-8")
anchor = '"id": "ch2_t_s09_guard"'
left, marker, tail = raw.partition(anchor)
assert marker
before_mode, mode, rest = tail.partition('"mode": "dialogue"')
assert mode and '"operation' not in before_mode
rule_path.write_text(left+marker+before_mode+'"mode": "animated"'+rest,encoding="utf-8")
story_contracts.ROOT = scope/"candidate-source"
story_contracts.CATALOG = contracts/"catalog.json"
dest=scope/"candidate-source/data/story/ch2_heron.json"
dest.parent.mkdir(parents=True, exist_ok=True)
new = write(dest)
def scene(document):
    rows=document["scenes"]
    return rows["ch2_t_s09_guard"] if isinstance(rows,dict) else next(row for row in rows if row["id"]=="ch2_t_s09_guard")
baseline=scene(old)
candidate=scene(new)
assert baseline["results"]==candidate["results"] and baseline["completion_policy"]==candidate["completion_policy"]
assert len(baseline["lines"]) == len(candidate["steps"]) - 1
for line, step in zip(baseline["lines"], candidate["steps"][1:], strict=True):
    assert step["do"] == "say" and all(step.get(k) == v for k,v in line.items())
assert candidate["steps"][0]=={"do":"world_action","id":"loading_guard_inspect"}
baseline_fields=set(baseline)
candidate_fields=set(candidate)
changes={key:(baseline.get(key),candidate.get(key)) for key in sorted(baseline_fields | candidate_fields) if baseline.get(key)!=candidate.get(key)}
candidate.clear()
candidate.update(baseline)
assert new == old
(scope/"author-delta.json").write_text(json.dumps(changes,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

