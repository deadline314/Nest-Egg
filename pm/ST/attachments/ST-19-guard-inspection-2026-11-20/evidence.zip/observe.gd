extends "res://tools/ch1_flow_probe.gd"

const SCENE := &"ch2_t_s09_guard"
const REVISIT := &"ch2_t_s09_guard_revisit"
const FLOOR := "res://data/levels/ch2_loading.tres"
var mode := ""
var app: Node
var store: RunSaveStore
var guard: NpcActor
var profile := {}
var poses: Array[Dictionary] = []
var completed_before := false
var visual := false
var first_line := false
var canceled := false
var thumb := false


func _run() -> void:
	var slot_path := ""
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--mode="):
			mode = arg.trim_prefix("--mode=")
		if arg.begins_with("--slot="):
			slot_path = arg.trim_prefix("--slot=")
	if not slot_path.is_absolute_path() or mode not in ["stock","left","right","cancel","air","cold"]:
		get_tree().quit(2)
		return
	store = RunSaveStore.new(slot_path)
	app = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	app.set("_run_store",store)
	add_child(app)
	await _settle(5)
	Story.auto_skip = false
	Story.scene_started.connect(func(id: StringName,_kind: StringName) -> void: _played.append(String(id)))
	for frame in STEP_LIMIT:
		if app.get("_screen") is MainMenu and not bool(app.call("_route_pending")):
			break
		await get_tree().process_frame
	if not _require(app.get("_screen") is MainMenu and store.read().get("level","") == FLOOR, "isolated true Continue slot has the real loading room"):
		return
	await _settle(8)
	var menu := app.get("_screen") as MainMenu
	menu._continue_button.pressed.emit()
	for frame in STEP_LIMIT:
		var current := app.get("_screen") as Level
		if current != null and current.is_initialized() and current.data.resource_path == FLOOR and not bool(app.call("_route_pending")):
			_level = current
			break
		await get_tree().process_frame
	if not _require(is_instance_valid(_level), "real Main opens the actual loading bay"):
		return
	profile = {"wallet":Progression.credits,"items":StoryItems.snapshot()}
	guard = _object(&"ch2_guard")
	if not _require(guard != null and guard.data.kind == NpcData.Kind.OBJECT, "same inspect source exists"):
		return
	completed_before = GameState.has_flag(&"ch2_guard_seen")
	if mode == "cold":
		_check(completed_before and guard.talk_count == 1, "cold Continue loads exactly one successful inspection")
		_check(guard._actor != null and guard._actor.process_mode == Node.PROCESS_MODE_ALWAYS, "cold rest is ordinary world animation")
		await _finish_record()
		return
	_check(not completed_before and guard.talk_count == 0, "original inspection has not happened")
	var player := _level.player
	var side := 1 if mode == "right" else -1
	player.global_position = guard.global_position + Vector2(side * 26,0)
	player.velocity = Vector2.ZERO
	_level.camera.snap_to_target()
	for frame in 55:
		if guard.interaction_available() and player.is_on_floor():
			break
		await get_tree().physics_frame
	if not _require(guard.interaction_available() and player.is_on_floor(), "standing at the actual selection on safe ground"):
		return
	if mode == "air":
		Input.action_press(&"jump")
		for frame in 8:
			await get_tree().physics_frame
			if not player.is_on_floor():
				break
		Input.action_release(&"jump")
		_check(not player.is_on_floor(), "airborne starts from an original jump")
	await _bound_interact()
	for frame in STEP_LIMIT:
		if Story._current_cinematic == SCENE:
			break
		await get_tree().process_frame
	if not _require(Story._current_cinematic == SCENE, "real bound interact opens the original first inspection"):
		return
	await _read_inspection()
	if mode in ["left","right","cancel"]:
		_check(visual and poses.size() > 5, "normal interaction includes the authored pose")
	else:
		_check(not visual and first_line, "the original text can complete without staging")
	var accepted := mode != "cancel"
	_check(Story.resolve_dispatch(&"ch2_dispatch_guard") == (REVISIT if accepted else SCENE), "normal dispatcher selects the original revisit or unplayed first reading")
	_check(GameState.has_flag(&"ch2_guard_seen") == accepted and guard.talk_count == int(accepted), "only completed native reading settles flag and count")
	_check(Story._completed.has(SCENE) == accepted, "original seen completion follows its canonical save")
	_check((store.read().get("story",{}).get("flags",{}).get("ch2_guard_seen",false) == true) == accepted, "disk agrees after original completion or cancellation")
	_check(not get_tree().paused and player._visual.interaction_action == null, "the reading retires presentation movement and pause")
	if guard._actor != null:
		_check(guard._actor.process_mode == Node.PROCESS_MODE_ALWAYS, "guard retains its original processing mode after inspection")
	_check(Progression.credits == profile["wallet"] and StoryItems.snapshot() == profile["items"], "inspection does not add wallet, inventory or receipts")
	await _finish_record()


func _read_inspection() -> void:
	var player := _level.player
	for frame in STEP_LIMIT:
		if Story._current_cinematic != SCENE:
			await _settle(5)
			return
		var action := player._visual.interaction_action
		if action != null and action.phase == "inspect":
			visual = true
			var position := player.global_position - guard.global_position
			var chest := guard._actor.rig.bone(&"chest")
			poses.append({"frame":frame,"position":[position.x,position.y],"facing":player._visual._interaction_input.facing,
				"crouch":player._visual._interaction_input.crouching,"chest":chest.rotation,"guard_mode":guard._actor.process_mode})
			if poses.size() == 12 and not thumb:
				thumb = true
				await RenderingServer.frame_post_draw
				_capture("checking-breath")
			if mode == "cancel" and poses.size() >= 18:
				_check(not GameState.has_flag(&"ch2_guard_seen") and guard.talk_count == 0, "pose alone does not complete inspection")
				Story.reset_active_presentation(&"guard-inspection-cancel")
				canceled = true
		var cutscene := Story._player
		if is_instance_valid(cutscene) and cutscene._dialogue.visible:
			first_line = true
			await _bound_interact()
		elif Story._layer.is_cinematic_active():
			first_line = true
			await _bound_interact()
		else:
			await get_tree().process_frame
	_check(false, "inspection terminates within its real input bound")


func _bound_interact() -> void:
	for event: InputEvent in InputMap.action_get_events(&"interact"):
		if event is InputEventKey:
			var key := event.duplicate() as InputEventKey
			key.pressed = true
			Input.parse_input_event(key)
			Input.flush_buffered_events()
			await get_tree().physics_frame
			await get_tree().process_frame
			var release := key.duplicate() as InputEventKey
			release.pressed = false
			Input.parse_input_event(release)
			Input.flush_buffered_events()
			await get_tree().process_frame
			return
	_check(false, "expected actual keyboard interact binding")


func _finish_record() -> void:
	await RenderingServer.frame_post_draw
	_capture("restored")
	var file := FileAccess.open(_out_dir.path_join("inspection.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"mode":mode,"failed":_failures,"crouch":visual,"first_line":first_line,"cancelled":canceled,
		"poses":poses,"story_flag":GameState.has_flag(&"ch2_guard_seen"),"talk_count":guard.talk_count}, "  ") + "\n")
	file.close()
	app.call("_quit",1 if _failures > 0 else 0)


func _require(ok: bool, description: String) -> bool:
	_check(ok, description)
	if not ok:
		app.call("_quit", 1)
	return ok


