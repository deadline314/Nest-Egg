from pathlib import Path
import json
import re

base = Path(__file__).resolve().parent
cases = {"stock": "stock-v4/stock", "left": "final/left", "right": "final/right", "cancel": "final/cancel",
         "air": "final/air", "cold": "final/cold"}
summary = {}
saves = {}
read = lambda path: json.loads(path.read_bytes())
expected = {"stock": (False,True,1,0), "left": (True,True,1,39), "right": (True,True,1,39),
            "cancel": (True,False,0,18), "air": (False,True,1,0), "cold": (False,False,1,0)}
for name, relative in cases.items():
    folder = base/relative
    state = read(folder/"inspection.json")
    capture = state["poses"]
    assert (state["crouch"],state["first_line"],state["talk_count"],len(capture)) == expected[name],state
    assert state["story_flag"] == (name != "cancel") and state["cancelled"] == (name=="cancel")
    assert state["failed"] == 0
    log = (folder/"engine.log").read_text(encoding="utf-8")
    assert "Forward+ - Using Device #0: AMD - AMD Radeon RX 9070 XT" in log
    assert not re.search(r"^(?:SCRIPT )?ERROR:|^FAIL|Parse Error|leaked at exit",log,re.M)
    if name not in ("stock","cold"):
        assert "PASS normal dispatcher selects the original revisit or unplayed first reading" in log
    counts = len(re.findall(r"^PASS ",log,re.M))
    summary[name] = {"assertions": counts, "crouch_frames":len(capture), "shown_original_line":state["first_line"],
                     "flag":state["story_flag"],"talk":state["talk_count"]}
    if capture:
        settled = capture[1:]
        side = 1 if name == "right" else -1
        assert all(row["position"]==[side*46,0] and row["facing"]==-side and row["crouch"] and row["guard_mode"]==3
                   for row in settled)
        chest = [row["chest"] for row in settled]
        change = max(chest)-min(chest)
        assert change > 0.001
        summary[name].update(position=[side*46,0],body_facing=-side,chest_rotation_span=change)
    packet = read(folder/"slot.json")
    saves[name] = json.loads(packet["payload"])
    payload = saves[name]
    assert (payload["story"]["flags"].get("ch2_guard_seen",False) == True) == (name != "cancel")
    assert payload["story"]["seen"].count("ch2_t_s09_guard") == (0 if name=="cancel" else 1)
    assert payload["cinematic"] == "" and payload["cinematic_context"] == {}
    if name != "stock":
        stock = saves["stock"]
        assert all(payload["progression"][k]==stock["progression"][k] for k in ("credits","story_transactions","equipped"))
        assert payload["story"]["items"] == stock["story"]["items"]
assert saves["cold"].keys() == saves["left"].keys()
assert all(saves["cold"][key] == saves["left"][key] for key in saves["left"] if key != "saved_at")
delta = read(base/"author-delta.json")
assert set(delta) == {"lines","mode","overlay","steps"}
assert delta["mode"] == ["dialogue","animated"] and delta["steps"][1][0]["do"]=="world_action"
assert [{k:v for k,v in line.items() if k != "do"} for line in delta["steps"][1][1:]]==delta["lines"][0]
out = {"native":summary,"assertions":sum(case["assertions"] for case in summary.values()),
       "driver":"Forward+ Vulkan on RX 9070 XT at 1280×720 and fixed 60 FPS",
       "inputs":"seeded disposable actual Main Continue slots, positions controlled, keyboard input events simulated",
       "archive_invariants":"credits, equipped, story items and transaction receipts preserved; cold left save preserves every payload field except the updated timestamp"}
(base/"inspection-evidence.json").write_text(json.dumps(out,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps(out,ensure_ascii=False))
