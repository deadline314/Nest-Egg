from pathlib import Path
import subprocess

root = Path.cwd()
scope = Path(__file__).resolve().parent
target = scope/"candidate-source"

def replace(path, pairs):
    original = (root/path).read_bytes()
    assert original.replace(b"\r\n",b"\n")==subprocess.check_output(["git","show",f"37579e19:{path}"],cwd=root).replace(b"\r\n",b"\n"), path
    data = original.decode().replace("\r\n","\n")
    for before,after in pairs:
        assert data.count(before) == 1, (path,before)
        data = data.replace(before,after)
    result=target/path
    result.parent.mkdir(parents=True,exist_ok=True)
    result.write_bytes(data.encode())

replace("game/player/world_prop_action.gd", [
    ("## hand_angle（選填，度）：", "## inspect：從目前一側走到可安全蹲下的位置，查看原互動來源，不移動對方或碰道具。\n## hand_angle（選填，度）："),
    ('var _request := 0','var _request := 0\nvar _inspection_facing := 0'),
    ('return definition(id).get("kind") == "press"','return definition(id).get("kind") in ["press", "inspect"]'),
    ('["insert", "take_paper", "turn", "support", "place", "press"]:', '["insert", "take_paper", "turn", "support", "place", "press", "inspect"]:'),
    ('''	if spec["kind"] == "support":
		required = ["level", "source", "bone", "pose"]''','''	if spec["kind"] == "inspect":
		required = ["level", "source"]
	elif spec["kind"] == "support":
		required = ["level", "source", "bone", "pose"]'''),
    ('''	if typeof(spec.get("facing")) not in [TYPE_INT, TYPE_FLOAT] or not is_finite(float(spec["facing"])) or absf(float(spec["facing"])) != 1.0:
		return "world_action facing must be -1 or 1"''','''	if spec["kind"] != "inspect" and (typeof(spec.get("facing")) not in [TYPE_INT, TYPE_FLOAT] \\
			or not is_finite(float(spec["facing"])) or absf(float(spec["facing"])) != 1.0):
		return "world_action facing must be -1 or 1"'''.replace("\\\n","\\\n")),
    ('''	if spec["kind"] == "turn":
		if float(spec["radius"][0])''','''	if spec["kind"] == "inspect":
		if spec.get("crouch") != true or float(spec["station"][0]) <= 0.0 or float(spec["station"][0]) > MAX_APPROACH:
			return "world_action inspect requires crouch and a positive same-side station distance"
	if spec["kind"] == "turn":
		if float(spec["radius"][0])'''),
    ('''	if _spec["kind"] == "support":
		return _start_support(player, source)''','''	if _spec["kind"] == "support":
		return _start_support(player, source)
	if _spec["kind"] == "inspect":
		return _start_inspection(player, source)'''),
    ('''	input.facing = int(_spec["facing"])
	input.aim_dir = Vector2(input.facing, 0)''','''	input.facing = _inspection_facing if _inspection_facing != 0 else int(_spec["facing"])
	input.aim_dir = Vector2(input.facing, 0)
	if phase == "inspect":
		input.aim_dir = Vector2(input.facing, 0.25).normalized()'''),
    ('''	else:
		input.hand_grip_front = true


func after_frame''','''	elif _inspection_facing == 0:
		input.hand_grip_front = true


func after_frame'''),
    ('''	if phase not in ["approach", "feed"]:
		if not _phase_started:''','''	if _inspection_facing == 0 and phase not in ["approach", "feed"]:
		if not _phase_started:'''),
    ('''func _without_reaction() -> bool:
	return _spec.get("kind") in ["support", "place", "press"]''','''func _start_inspection(player: Player, source: NpcActor) -> bool:
	if not source.bone_global(&"chest").is_finite():
		return _fail("world action inspect needs its visible original actor")
	_start_position = player.global_position
	var side := -1 if _start_position.x < source.global_position.x else 1
	_station = source.global_position + Vector2(side * float(_spec["station"][0]), float(_spec["station"][1]))
	if not route_clear(player, _station):
		return _fail("world action inspection needs a supported route beside the actor", &"route")
	_player = weakref(player)
	_inspection_facing = -side
	player.velocity = Vector2.ZERO
	_sequence = [{"id":"approach"}, {"id":"inspect", "time":0.65}, {"id":"release", "time":0.28}]
	_enter_phase()
	_frame_camera(player, source.global_position.x)
	return true


func _without_reaction() -> bool:
	return _spec.get("kind") in ["support", "place", "press", "inspect"]'''),
])
replace("data/cutscene/world_prop_actions.json", [
    ('  "audit_terminal_submit": {','''  "loading_guard_inspect": {
    "scene": "ch2_t_s09_guard",
    "level": "res://data/levels/ch2_loading.tres",
    "source": "res://data/npcs/ch2_guard.tres",
    "kind": "inspect",
    "station": [46, 0],
    "crouch": true
  },
  "audit_terminal_submit": {''')
])
replace("tools/story/ch2_source.py", [
    ('''    source.add("ch2_t_s09_guard", "S09", (
        ("rin", "守衛還有呼吸，誰先來過？"),
        ("lamp", "我只看見門沒鎖，查不到人。"),
        ("lamp", "先看門內，別替影子取名字。")),
        when=negate(flag("ch2_guard_seen")), completion=(set_flag("ch2_guard_seen"),))''',
'''    source.add("ch2_t_s09_guard", "S09", steps=[dict(do="world_action", id="loading_guard_inspect"), *beats(
        ("rin", "守衛還有呼吸，誰先來過？"),
        ("lamp", "我只看見門沒鎖，查不到人。"),
        ("lamp", "先看門內，別替影子取名字。"))], mode="animated",
        when=negate(flag("ch2_guard_seen")), completion=(set_flag("ch2_guard_seen"),))''')
])



replace("game/cutscene/cutscene_player.gd", [
    ('''	elif event.is_action_pressed(&"ui_accept") or shoot_pressed or event.is_action_pressed(&"jump") \\
			or (event is InputEventMouseButton''','''	elif event.is_action_pressed(&"ui_accept") or shoot_pressed or event.is_action_pressed(&"jump") \\
			or (event.is_action_pressed(&"interact") and _overlay_mode and _dialogue.visible \\
				and Story.current_presentation_context().get("framing_source") == "object") \\
			or (event is InputEventMouseButton'''),
])

