extends Node
class OwnedReader extends Node:
 func read(_kind: StringName, _id: StringName) -> Variant:return false
var rows: Array[Dictionary] = []
var controls_failed := 0
var counterexamples := 0
func observe(name: String, actual: Variant, expected: Variant, details: Dictionary = {}, defect := true) -> void:
 var matches: bool = actual == expected
 rows.append({"name":name,"actual":actual,"design_expected":expected,"matches":matches,"details":details,"defect_probe":defect})
 if not matches:
  if defect:counterexamples += 1
  else:controls_failed += 1
func state() -> Dictionary:
 return {"flags":GameState.world_flags.duplicate(true),"defaults":GameState.flag_defaults.duplicate(true),"items":StoryItems.snapshot(),"wallet_ledger":Progression.snapshot(),"progress":Story.progress_snapshot(),"scenes":Story._scenes.duplicate(true),"sources":Story._scene_sources.duplicate(true),"chapters":Story._scene_chapter.duplicate(true),"runtime":Story.outcomes.runtime_facts.duplicate(true)}
func _ready() -> void:run.call_deferred()
func run() -> void:
 StoryItems.catalog()
 var before := state()
 var original_scenes := Story._scenes.duplicate(true)
 var original_sources := Story._scene_sources.duplicate(true)
 var original_chapters := Story._scene_chapter.duplicate(true)
 var original_runtime := Story.outcomes.runtime_facts.duplicate(true)
 var original_ledger: StoryTransactionLedger = Progression._story_transactions
 var definitions := {}
 for resource: StoryTransactionData in ResourceCatalog.load_dir("res://data/story_transactions", StoryTransactionData, "St3FactsAudit"):
  definitions[String(resource.id)] = resource.descriptor()
 var unknown_flag := {"not":{"flag":"test_st3_undeclared","equals":true}}
 var unknown_item := {"not":{"item":"test_st3_no_item"}}
 var unknown_receipt := {"not":{"receipt":"test.st3_no_receipt","status":"recorded"}}
 observe("unknown flag declared",GameState.flag_defaults.has("test_st3_undeclared") or Story.outcomes.runtime_facts.has("test_st3_undeclared") or Story.outcomes.derived_flags.has("test_st3_undeclared"),false,{},false)
 observe("unknown item registered",StoryItems.find(&"test_st3_no_item") != null,false,{},false)
 observe("unknown receipt registered",Story.outcomes.transactions.has("test.st3_no_receipt"),false,{},false)
 observe("not undeclared flag",StoryRules.holds(unknown_flag),false,{"fact":Story.fact(&"flag",&"test_st3_undeclared"),"strict":StoryConditionTree.evaluate(unknown_flag,{"flags":{}})})
 observe("true any hides undeclared flag",StoryRules.holds({"any":[{},unknown_flag]}),false)
 observe("not unregistered item",StoryRules.holds(unknown_item),false,{"strict":StoryConditionTree.evaluate(unknown_item,{"items":{}})})
 observe("not unregistered receipt",StoryRules.holds(unknown_receipt),false,{"status":Progression.story_receipt_status(&"test.st3_no_receipt")})
 var loaded := Story.load_chapter("res://work/st3-facts-audit/chapter.json")
 observe("actual chapter load",loaded,true,{},false)
 var validation := Array(Story.validate())
 for kind in ["flag","item","receipt","provider"]:
  var id: String = "test_st3_audit_"+kind
  var relevant: Array = validation.filter(func(problem: String) -> bool:return problem.contains(id) or (kind=="provider" and problem.contains("test_st3_bad_provider")))
  observe("loaded "+kind+" scene still available",Story.scene_available(StringName(id)),false,{"scene_still_registered":Story.has_scene(StringName(id)),"validation_issues":relevant})
 var live := {"flag":"ch1_true_death_record_known","equals":true}
 observe("legitimate default live provider",StoryRules.holds(live),true,{},false)
 var holder := OwnedReader.new()
 var stale := Callable(holder,"read")
 observe("valid candidate callback overrides live",StoryRules.holds(live,stale),false,{},false)
 holder.free()
 observe("stale callback silently falls back live",StoryRules.holds(live,stale),false,{"is_null":stale.is_null(),"is_valid":stale.is_valid()})
 var null_reader := func(_kind: StringName,_id: StringName)->Variant:return null
 observe("explicit fact null keeps false default",StoryRules.holds({"flag":"ch1_true_death_record_known","equals":false},null_reader),true,{},false)
 var bad_reader := func(_kind: StringName,_id: StringName)->Variant:return []
 observe("bad array fact under not",StoryRules.holds({"not":live},bad_reader),false,{"strict":StoryConditionTree.evaluate({"not":live},{"flags":{"ch1_true_death_record_known":[]}})})
 var nan_reader := func(_kind: StringName,_id: StringName)->Variant:return NAN
 observe("bad nan fact under not",StoryRules.holds({"not":live},nan_reader),false)
 var missing := StoryTransactionLedger.new()
 Progression._story_transactions = missing
 var receipt := {"receipt":"ch1.daily_dinner","status":"recorded"}
 var clean_proof := StoryConditionTree.verify_ledger({"ledger":missing.snapshot()},{"ledger_locked":false,"transaction_definitions":definitions})
 observe("clean valid empty ledger has missing receipt",StoryRules.holds({"not":receipt}),true,{"status":Progression.story_receipt_status(&"ch1.daily_dinner"),"strict":clean_proof},false)
 var broken := StoryTransactionLedger.new()
 broken.restore({"version":999,"receipts":{}},true,"test_st3_audit/locked")
 Progression._story_transactions = broken
 observe("locked receipt under not",StoryRules.holds({"not":receipt}),false,{"status":Progression.story_receipt_status(&"ch1.daily_dinner"),"locked":broken._locked,"original_raw":broken.snapshot()})
 observe("true any hides locked ledger",StoryRules.holds({"any":[{},receipt]}),false)
 var drift := StoryTransactionLedger.new()
 var drift_raw := {"version":1,"receipts":{"ch1.daily_dinner":{"definition_fingerprint":"0".repeat(64),"credits_delta":definitions["ch1.daily_dinner"]["credits_delta"]}}}
 drift.restore(drift_raw,true,"test_st3_audit/drift")
 Progression._story_transactions = drift
 observe("recorded receipt ignores descriptor drift",StoryRules.holds(receipt),false,{"status":Progression.story_receipt_status(&"ch1.daily_dinner"),"locked":drift._locked,"strict":StoryConditionTree.verify_ledger({"ledger":drift.snapshot()},{"ledger_locked":drift._locked,"transaction_definitions":definitions})})
 Progression._story_transactions = original_ledger
 Story._scenes = original_scenes
 Story._scene_sources = original_sources
 Story._scene_chapter = original_chapters
 Story.outcomes.runtime_facts = original_runtime
 var after := state()
 observe("all actual owner state restored",var_to_bytes(before)==var_to_bytes(after),true,{},false)
 var result := {"rows":rows,"confirmed_counterexamples":counterexamples,"controls_failed":controls_failed,"state_before":before,"state_after":after,"restored":var_to_bytes(before)==var_to_bytes(after),"validation_issues":validation,"scope":"Read-only audit leaf; public actual load_chapter/validate/scene_available and RAM-only ledger substitutions restored; no durable reward/commit/save or natural gameplay claim."}
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--out="):
   var file := FileAccess.open(arg.trim_prefix("--out="),FileAccess.WRITE)
   if file==null:push_error("audit output failed: "+arg);get_tree().quit(2);return
   file.store_string(JSON.stringify(result,"  "));file.close()
 print("ST3_FACTS_AUDIT "+JSON.stringify({"rows":rows.size(),"counterexamples":counterexamples,"controls_failed":controls_failed,"restored":result["restored"]}))
 await AudioRelease.settle(get_tree());get_tree().quit(1 if counterexamples or controls_failed else 0)
