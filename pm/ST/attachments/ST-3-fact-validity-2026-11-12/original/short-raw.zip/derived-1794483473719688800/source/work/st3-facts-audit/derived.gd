extends Node
var rows: Array[Dictionary] = []
var failures := 0
func check(name: String,actual: Variant,expected: Variant) -> void:
    rows.append({"name":name,"actual":actual,"expected":expected})
    if actual!=expected:failures+=1
func _ready() -> void:run.call_deferred()
func run() -> void:
    var flags := GameState.world_flags.duplicate(true)
    var original := Story.outcomes.derived_flags.duplicate(true)
    var items := StoryItems.snapshot()
    var wallet := Progression.snapshot()
    var seen := Story.progress_snapshot()
    var a := "test_bad_cutscene_derived_a"
    var b := "test_bad_cutscene_derived_b"
    GameState.world_flags[a]=false
    Story.outcomes.derived_flags={a:{"flag":"test_bad_cutscene_unknown_source","equals":true}}
    var predicate := {"not":{"flag":a,"equals":true}}
    check("unknown derived source under not",StoryRules.holds(predicate),false)
    Story.outcomes.derived_flags[a]={"not":{"unknown":true}}
    check("malformed derived source under not",StoryRules.holds(predicate),false)
    Story.outcomes.derived_flags={a:{"flag":b,"equals":true},b:{"flag":a,"equals":true}}
    check("derived source cycle under not",StoryRules.holds(predicate),false)
    var deep: Dictionary={}
    for i in 15:deep={"not":deep}
    Story.outcomes.derived_flags={a:deep}
    GameState.world_flags[a]=true
    check("expanded derived depth cannot reset root budget",StoryRules.holds({"flag":a,"equals":true}),false)
    Story.outcomes.derived_flags={a:{"not":{}}}
    check("valid false source does not replace stored scalar",StoryRules.holds({"flag":a,"equals":true}),true)
    check("stored scalar remains unchanged after read",GameState.world_flags[a],true)
    Story.outcomes.derived_flags={a:{"flag":"test_bad_cutscene_unknown_source","equals":true}}
    Story.outcomes.refresh_derived()
    check("invalid refresh must preserve prior scalar",GameState.world_flags[a],true)
    GameState.world_flags=flags
    Story.outcomes.derived_flags=original
    check("actual owner state restored",GameState.world_flags==flags and StoryItems.snapshot()==items and Progression.snapshot()==wallet and Story.progress_snapshot()==seen,true)
    var result := {"checks":rows.size(),"failures":failures,"rows":rows,"scope":"RAM-only registered derived formulas, original scalars and all measured owner state restored. No product/data changes."}
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--out="):
            var file := FileAccess.open(arg.trim_prefix("--out="),FileAccess.WRITE)
            if file==null:push_error("derived output failed: "+arg);get_tree().quit(2);return
            file.store_string(JSON.stringify(result,"  "));file.close()
    print("ST3_DERIVED "+JSON.stringify({"checks":rows.size(),"failures":failures}))
    await AudioRelease.settle(get_tree())
    get_tree().quit(1 if failures else 0)
