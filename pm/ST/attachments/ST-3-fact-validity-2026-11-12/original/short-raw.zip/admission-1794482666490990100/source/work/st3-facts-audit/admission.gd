extends Node
func _ready() -> void:run.call_deferred()
func state() -> Dictionary:
    return {"flags":GameState.world_flags.duplicate(true),"defaults":GameState.flag_defaults.duplicate(true),"items":StoryItems.snapshot(),"progress":Progression.snapshot(),"seen":Story.progress_snapshot(),"scenes":Story._scenes.duplicate(true),"sources":Story._scene_sources.duplicate(),"runtime":Story.outcomes.runtime_facts.duplicate(),"derived":Story.outcomes.derived_flags.duplicate(true),"transactions":Story.outcomes.transactions.duplicate(true)}
func run() -> void:
    var before := state()
    var declared := Story.outcomes._condition_producers.duplicate()
    Story.outcomes._condition_producers.clear()
    Story.outcomes._condition_reports["test_bad_cutscene/reset"] = true
    Story.load_all()
    var after := state()
    var restored: bool = var_to_bytes(before)==var_to_bytes(after)
    var producer_restored: bool = not declared.is_empty() and declared==Story.outcomes._condition_producers
    var reset: bool = Story.outcomes._condition_reports.is_empty() and not Story.outcomes._condition_catalog_loaded
    var result := {"checks":3,"failures":int(not restored)+int(not producer_restored)+int(not reset),"state_restored":restored,"actual_producers_restored":producer_restored,"reports_and_resource_cache_reset":reset,"source_count":declared.size(),"scope":"Actual public load_all restores authoritative producers after cache clear; no gameplay/presentation."}
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--out="):
            var file := FileAccess.open(arg.trim_prefix("--out="),FileAccess.WRITE)
            if file==null:push_error("admission output failed: "+arg);get_tree().quit(2);return
            file.store_string(JSON.stringify(result,"  "));file.close()
    print("ST3_ADMISSION "+JSON.stringify(result))
    await AudioRelease.settle(get_tree())
    get_tree().quit(1 if result["failures"] else 0)
