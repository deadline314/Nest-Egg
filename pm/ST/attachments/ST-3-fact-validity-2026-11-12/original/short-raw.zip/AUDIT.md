# ST-3 facts boundary: source audit and actual short counterexamples

Frozen epoch: f80d0d9f + the already sealed structural two sources; runtime bytes are the same as published86521278. No product change belongs to this audit. Accepted raw: `run-1794480844882894100`; exact five-env/default-headless argv and source before/after are retained. Engine intentionally exits1 because14 design expectations are violated; 23 observations include9 controls with0 failures. 6.6342622s,0 SCRIPT ERROR, no shutdown diagnostic; actual owner states restored byte-equivalent. This is not14 independent bugs or proof of bypassing durable rewards.

## Actual observations

- Default unknown flag resolves null; `not(flag==true)` returns true. True-first `any` also hides it. Strict pure evaluator rejects absent declared facts. Default unknown item likewise resolves false and `not` returns true.
- The **actual** public `load_chapter` returns true for the fixture JSON. `validate()` reports **no** when problem for unknown flag or item: it validates schema, not names. Those scenes remain registered/available. Unknown receipt and unknown runtime provider each produce a concrete validation issue, yet those scenes also remain registered/available. Story `_ready` reports validation errors but does not quarantine scenes; load_chapter itself never invokes validate.
- A non-null callback whose Node owner was freed has is_null=false/is_valid=false. `holds` silently selects live Story.fact instead; the valid original callback returns false whereas live registered always provider returns true. Null default Callable still legitimately selects live.
- A valid explicit callback returning null retains the original false-default comparison. Valid candidate callback false overrides live true. These controls pass and must remain supported.
- Callback Array and NaN flag facts under not return true; invalid actual values are collapsed into ordinary unequal values. A whole facts projection validator would reject them.
- A canonical, valid empty ledger verifies successfully and a missing known receipt is ordinary false: not(receipt) is correctly true. **This is not a corrupt ledger.**
- A malformed version999 ledger is locked and preserves its raw evidence; receipt status is `untrusted`. StoryOutcomes.receipt_recorded compresses untrusted to false, allowing not and true-first any. A structurally valid but fingerprint-drifted receipt returns recorded / true; canonical verify_ledger rejects the actual mismatch.

## Existing owners and boundaries

- `autoload/story.gd:241–281` registers data; `:184` reports validate issues without quarantining; `:368–377` projects facts; `:382–400` admits scene/route by bool holds.
- `core/story_outcomes.gd:59–106` prioritizes registered runtime provider then GameState values; unknown providers warn/false. `:122–132` compresses receipt status and derives account mask, with no validity result. Account argument is currently ignored; default project domain is ch1_lounge, while explicit generic callbacks remain a broader existing API.
- `autoload/game_state.gd:356–357` returns world value/default/null. Default registration and restore validate values; unknown names are not admitted by a runtime condition registry. `_prepare_install:157–179` preserves published legacy flags, so an adapter cannot blindly equate flag_defaults with every old external requires/producer contract.
- `autoload/story_items.gd:69–102` supplies canonical catalog/find and current holds. Acquiring/transferring/restoring and prepared installation already validate ownership/custody; unknown-name condition reads still collapse to not-held.
- `core/story_transaction_ledger.gd:77–105` preserves/locks malformed snapshots and reports untrusted, rather than empty/missing. `:113–145` prevents locked or mismatched actual transaction proposals. The condition projection loses that distinction.
- `autoload/progression.gd:119–135` prepared installation loads **all canonical resources** and calls public `StoryConditionTree.verify_ledger`; `core/story_result_plan.gd:68–96` verifies full ledger and strict projected admission before durable proposals. `game/story_result_completion.gd:403–421` verifies proposed ledger and uses candidate facts. These are genuine safeguards; this audit does not claim the entry-point counterexamples can bypass them.
- RunFlagCommit:26–35 / StoryFlagCompletion:148–151 / StoryResultCompletion:412–421 use proposed flags/items/ledger callbacks. They must not be replaced by live-only data. Generic raw Callable has no declaration metadata; it is not possible to infer whether null means missing-known or unknown from its returned value alone.
- ContinuityAudit flags read-without-writer is an existing static/test audit, not a runtime loader rejection. Full caller inventory is the earlier immutable read-only audit at D:/NestEggVerification/proofs/st3-current-audit-20261112/storyrules-callers.json (dbb epoch); caller source files remain byte-matched in accepted audit source set.

## Registry inventory, no false positive

`registry-inventory.json` scans actual556 loaded scenes (7 actual source JSONs, including development legacy) and registered derived trees. It finds901 flag-leaf occurrences,16 item,8 receipt,40 account; all default/runtime/derived flags, items and receipts have canonical declarations.150 defaults,4 runtime providers,7 derived names,49 item resources,24 transaction resources; account references only ch1_lounge. These are source/name checks, not all world states or natural gameplay.

There are23 entries in loaded chapter transaction maps. `ch1.revival_meal.later_pay` is a real24th canonical resource referenced by a derived flag, despite not being in a chapter transaction-operation map. It must **not** be rejected as an unknown receipt. Use actual canonical resource definitions, not a seven-ID whitelist or chapter operation map. No invalid formal name is claimed here.

## Smallest proposed next change (not implemented in this audit)

Keep the existing structural gate, legacy outer requires/custody, same_value and explicit fact-null compatibility. Separate truly null from invalid non-null Callable. Default Story-owned fact reads should carry valid/value/error until the whole tree is checked: declared flag/provider and canonical item/transaction admission; no implicit declaration from condition references; owner snapshot+lock+current descriptors for receipt/account via existing verify_ledger. Reuse that one proof per root evaluation, not per leaf; keep current legitimate empty/missing semantics. Candidate fact sources remain candidate sources.

A valid opaque Callable does not supply a declaration table. Preserve its legal generic API and explicit null while validating actual scalar types/finite values and propagating invalid through not/any/all; do not claim that raw custom callbacks have acquired fully proved registries. Actual canonical callers already own projections and registries; any stronger declaration integration must reuse those owners explicitly. Whole-branch invalid detection requires inspecting branches currently skipped by boolean short-circuit; no double evaluation or silent fallback to live. Keep error dedup bounded/reset with loaded Story owner, following existing report-once pattern, without introducing audio coupling or a new generic framework.

Ownership proposed to Root: StoryRules / StoryOutcomes, minimal Story load/reset registration hook, existing CutsceneSuite additions. No Tree chapter-policy change, no death data1/3/5, no thresholds, no primary C/PM/index edits. Long affected remains scheduled separately.

The first tool epoch had one diagnostic-script type-inference parse error and a bounded timeout. Its exact source/log/command is preserved; it is not accepted as a product counterexample. The corrected accepted epoch above ran actual public APIs and restores all substituted owner state before quit.
