# ST-3 fact-validity candidate v4

Base2fa7bde15a08d0744d968c796ed9c5c4bf614015. Only three candidate files in manifest/source; all original tests retained. No primary C/PM/index/commit changes. v3 and every earlier red/parser/invalid-local epoch remain untouched.

Final strict short wrappers:140 permanent assertions/0; original23 rows all met/owner state restored;5764 formal result comparisons/0; public load_all3/0; derived8/0 (previous5 red); exact default Callable alias8/0 (previous5 red). All six final engines exit0,0 SCRIPT ERROR, source before/after fixed. Intentional malformed-state ERROR messages remain, so this is not a0ERROR claim. Exact command/five isolated environments/default driver and raw sources/logs/results are at manifest.short paths under the parent audit directory.

The matrix covers524 formal source when nodes: one actual default owner plus10 valid callback strategies. Values match published865. Full-tree checking intentionally adds3742 callback reads over the valid matrix; each occurrence is read once. Old assertions of equal short-circuit read counts belong only to the previous structural epoch and are not claimed here.

Default flags derive names from defaults/runtime/derived/actually admitted producer bodies, items from catalog, receipts from all24 current canonical transaction resources. A skipped duplicate (including same path) cannot register new names; normal public load_all rebuilds119 actual producers and clears bounded diagnostics/cache. Missing legitimate context and valid missing receipts stay ordinary false. Current ledger snapshot, actual lock and current descriptors are checked once per root; no cached trusted/account substitute.

Derived provenance is checked within the same root schema/evaluation budgets and visiting set; malformed, unknown, cyclic and over-budget chains cannot be inverted through stored false. Reads preserve the original stored scalar even if a valid formula is false. Explicit refresh skips invalid results and retains original valid-update signals. Exact Story.fact aliases use the same owner boundary; valid opaque callbacks retain their own namespace authority and explicit null defaults, but nonscalar/nonfinite actual values are rejected. No new generic adapter/options or pureTree chapter whitelist change.

The original selector still chooses22 groups; selector.log is its actual stdout. No long regression has run for this v4; await Root scheduling after HUD's independent long batch. Previous45500/0 structural result is a different source epoch and is not reused as v4 acceptance.
