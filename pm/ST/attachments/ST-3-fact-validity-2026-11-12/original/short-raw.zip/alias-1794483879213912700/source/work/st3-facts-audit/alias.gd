extends Node
var rows: Array[Dictionary] = []
var failures := 0
func check(name: String,actual: bool,expected: bool) -> void:
    rows.append({"name":name,"actual":actual,"expected":expected})
    if actual!=expected:failures+=1
func _ready() -> void:run.call_deferred()
func run() -> void:
    var original := Progression._story_transactions
    var before := Progression.snapshot()
    for leaf: Dictionary in [{"flag":"test_bad_cutscene_alias_unknown","equals":true},{"item":"test_bad_cutscene_alias_unknown_item"},{"receipt":"test_bad_cutscene.alias_unknown_receipt","status":"recorded"}]:
        check("explicit Story.fact rejects unknown under not",StoryRules.holds({"not":leaf},Story.fact),false)
    check("explicit Story.fact true-any cannot hide unknown",StoryRules.holds({"any":[{}, {"flag":"test_bad_cutscene_alias_unknown","equals":true}]},Callable(Story,"fact")),false)
    var locked := StoryTransactionLedger.new()
    locked.restore({"version":999,"receipts":{}},true,"test_bad_cutscene/alias_locked")
    Progression._story_transactions = locked
    check("explicit Story.fact rejects untrusted receipt",StoryRules.holds({"not":{"receipt":"ch1.daily_dinner","status":"recorded"}},Story.fact),false)
    Progression._story_transactions = original
    check("explicit valid live facts remain true",StoryRules.holds({"flag":"ch1_true_death_record_known","equals":true},Story.fact),true)
    var missing := func(_kind: StringName,_id: StringName)->Variant:return null
    check("opaque explicit null default remains legal",StoryRules.holds({"flag":"private","equals":false},missing),true)
    check("actual ledger owner restored",Progression.snapshot()==before,true)
    var result := {"checks":rows.size(),"failures":failures,"rows":rows}
    for arg in OS.get_cmdline_user_args():
        if arg.begins_with("--out="):
            var file := FileAccess.open(arg.trim_prefix("--out="),FileAccess.WRITE)
            if file==null:push_error("alias output failed: "+arg);get_tree().quit(2);return
            file.store_string(JSON.stringify(result,"  "));file.close()
    print("ST3_ALIAS "+JSON.stringify({"checks":rows.size(),"failures":failures}))
    await AudioRelease.settle(get_tree())
    get_tree().quit(1 if failures else 0)
