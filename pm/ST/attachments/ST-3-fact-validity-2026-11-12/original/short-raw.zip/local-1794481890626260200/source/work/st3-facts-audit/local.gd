extends Node
var checks := 0
var failures := 0
func _check(ok: bool,message: String) -> void:
 checks += 1
 if not ok:failures += 1;print("FAIL: "+message)
func _ready() -> void:run.call_deferred()
func run() -> void:
 var suite := CutsceneSuite.new(self)
 suite._test_story_condition_boundary()
 suite._test_story_fact_boundary()
 print("ST3_FACTS_LOCAL "+JSON.stringify({"checks":checks,"failures":failures}))
 await AudioRelease.settle(get_tree());get_tree().quit(1 if failures else 0)
