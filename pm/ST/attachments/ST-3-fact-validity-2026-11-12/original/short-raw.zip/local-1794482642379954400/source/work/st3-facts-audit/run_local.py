import pathlib,json,hashlib,subprocess,os,time
R=pathlib.Path(__file__).resolve().parents[2];H=pathlib.Path(__file__).resolve().parent;O=H/('local-'+str(time.time_ns()));O.mkdir()
paths=['core/story_rules.gd','tests/suite/test_cutscene.gd','core/story_condition_tree.gd','core/story_transaction_ledger.gd','core/story_outcomes.gd','autoload/story.gd','autoload/story_items.gd','autoload/game_state.gd','autoload/progression.gd','core/story_result_plan.gd','core/run_flag_commit.gd','game/story_flag_completion.gd','game/story_result_completion.gd','work/st3-facts-audit/local.gd','work/st3-facts-audit/local.tscn','work/st3-facts-audit/chapter.json']
paths += sorted(p.as_posix() for folder in ['data/story','data/story_items','data/story_transactions'] for p in pathlib.Path(folder).glob('*') if p.is_file() and p.suffix in ['.json','.tres'])
paths.append('work/st3-facts-audit/run_local.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before={n:sha(R/n) for n in paths}
for n in paths:
 p=O/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/n).read_bytes())
keys=['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME'];env=os.environ.copy()
for key in keys:env[key]=str(O/'user'/key)
cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(R),'--headless','res://work/st3-facts-audit/local.tscn','--','--out='+str(O/'results.json')]
(O/'command.json').write_text(json.dumps({'argv':cmd,'env':{k:env[k] for k in keys},'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'source_before':before,'scope':'Actual HEAD plus working candidate per exact source_before; not a published-runtime equivalence claim. Sequential default headless; no import/other engine.'},indent=2)+'\n',encoding='utf8',newline='\n')
t=time.monotonic()
with (O/'engine.log').open('wb') as f:p=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
after={n:sha(R/n) for n in paths};text=(O/'engine.log').read_text(encoding='utf8',errors='replace');receipt={'exit':p.returncode,'seconds':time.monotonic()-t,'source_after':after,'source_fixed':before==after,'script_errors':text.count('SCRIPT ERROR'),'results_present':(O/'results.json').exists()}
receipt["completed"]='ST3_FACTS_LOCAL ' in text;(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n');print(str(O));print(json.dumps(receipt));print(text);raise SystemExit(p.returncode if before==after and receipt["script_errors"]==0 and receipt["completed"] else 2)
