import pathlib,hashlib,json,os,subprocess,time
R=pathlib.Path(__file__).resolve().parents[2]; O=R/'work/st3-facts-audit/official-v4'; O.mkdir(exist_ok=False)
BASE='2fa7bde15a08d0744d968c796ed9c5c4bf614015'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
names=[n for n in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0') if n and not n.startswith(('pm/','design/','assets/','assets_src/','.claude/','.agents/'))]
names=[n for n in names if (R/n).is_file()]
before={n:sha(R/n) for n in names}
assert (R/'.godot').is_dir(), 'Existing serial import cache required; do not launch implicit import'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE
candidate=json.loads((R/'work/st3-facts-audit/candidate-v4/manifest.json').read_text(encoding='utf8'))
for name,meta in candidate['files'].items():assert before[name]==meta['sha256'],name

(O/'source-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf8',newline='\n')
uid_before={p.relative_to(R).as_posix():sha(p) for p in R.rglob('*.gd.uid') if '.godot' not in p.parts and 'work' not in p.parts}
env=os.environ.copy(); env.update({'GODOT':'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','SHARDS':'2','LOG_DIR':str(O/'logs')})
for key in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME']:env[key]=str(O/'user'/key)
(O/'logs').mkdir()
cmd=['C:/Program Files/Git/bin/bash.exe','tools/run_tests_changed.sh',BASE]
command={'argv':cmd,'cwd':str(R),'base':BASE,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'env':{k:env[k] for k in ['GODOT','SHARDS','LOG_DIR','APPDATA','LOCALAPPDATA','XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME']},'exe_sha256':sha(pathlib.Path(env['GODOT'])),'runner_sha256':sha(pathlib.Path(__file__)),'source_count':len(before),'epoch':'Published2fa plus only facts-v4 three-source candidate; original death thresholds1/3/5, no ST9 candidate overlay; no concurrent import','source_scope':'All tracked files except pm/design/art assets/agent docs; resources and audio outside assets included. Generated GD UIDs recorded separately.'}
(O/'command.json').write_text(json.dumps(command,indent=2)+'\n',encoding='utf8',newline='\n')
start=time.monotonic()
with (O/'full.log').open('wb') as log: p=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
after={n:sha(R/n) for n in names};(O/'source-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf8',newline='\n')
uid_after={p.relative_to(R).as_posix():sha(p) for p in R.rglob('*.gd.uid') if '.godot' not in p.parts and 'work' not in p.parts}
(O/'uid-context.json').write_text(json.dumps({'before':uid_before,'after':uid_after},indent=2)+'\n',encoding='utf8',newline='\n')
logs=list((O/'logs').glob('shard_*.log'));texts=[p.read_text(encoding='utf8',errors='replace') for p in logs]
receipt={'exit':p.returncode,'seconds':time.monotonic()-start,'source_fixed':before==after,'source_count':len(before),'script_errors':sum(t.count('SCRIPT ERROR') for t in texts),'shards':len(logs),'child_exit_scope':'Original runner waits for children and verifies final check totals/errors. Wrapper records runner exit, not separate child exits.'}
(O/'exit.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n');print(json.dumps(receipt));print((O/'full.log').read_text(encoding='utf8',errors='replace'));raise SystemExit(p.returncode if before==after else 2)
