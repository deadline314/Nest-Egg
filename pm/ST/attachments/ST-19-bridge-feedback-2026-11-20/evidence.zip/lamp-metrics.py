from pathlib import Path
from statistics import median
from PIL import Image
import json
p=Path(__file__).resolve().parent
records={}
for stage in ('cancel_read','accepted_read'):
    im=Image.open(p/'final'/stage/'bridge-cold.png').convert('RGB')
    coords=[(x,y) for y in range(480,508) for x in range(361,390) if 8**2<=(x-375)**2+(y-494)**2<=11**2]
    pixels=[im.getpixel(point) for point in coords]
    records[stage]={'center':[375,494],'samples':len(pixels),
           'rgb_median':[median(rgb) for rgb in zip(*pixels)],
           'red_minus_green':median([rgb[0]-rgb[1] for rgb in pixels])}
assert records['cancel_read']['red_minus_green']>20
assert records['accepted_read']['red_minus_green']<-10
(p/'lamp-metrics.json').write_text(json.dumps(records,indent=2)+'\n')
print(records)

