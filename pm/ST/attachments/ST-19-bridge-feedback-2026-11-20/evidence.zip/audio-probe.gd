extends "res://tests/probes/ch2_reading_completion.gd"

var _requested_at := -1
var _voice_checked := false

func _count_bridge_cue(id: StringName) -> void:
	super._count_bridge_cue(id)
	if id == &"gate":
		_requested_at = Time.get_ticks_msec()
		_record_voice.call_deferred()

func _record_voice() -> void:
	var index := Sfx._voice_sound.find(&"gate")
	var voice: AudioStreamPlayer = Sfx._players[index] if index >= 0 else null
	var started := int(Sfx._last_play_msec.get(&"gate", -1000))
	var stream := voice.stream if is_instance_valid(voice) else null
	_voice_checked = started >= _requested_at and started - _requested_at < 50 and stream != null and voice.playing
	print("BRIDGE_AUDIO_CALL emitted=", _requested_at, " allocated=", started, " index=", index, " length=", stream.get_length() if stream != null else 0.0)

func _done() -> void:
	_check(_bridge_audio == 1 and _voice_checked, "accepted bridge change actually starts one populated audio voice")
	await super._done()

