extends "res://tools/ch1_flow_probe.gd"
## Actual Main and original NPC. Entering the kitchen directly and setting the visible-quest prerequisite are declared fixtures.

const KITCHEN := "res://data/levels/ch2_ali_home.tres"
const ALI := &"ch2_ali_home"
var _main: Node
var _slot := ""
var _mode := "taste"
var _store: FaultedRunStore
var _heals: Array[int] = []
var _retry_checked := false

class FaultedRunStore extends RunSaveStore:
	var fail_next_result := false
	var failed_writes := 0

	func _durable_write_temp(absolute: String, encoded: String) -> Error:
		if fail_next_result:
			fail_next_result = false
			failed_writes += 1
			return ERR_CANT_CREATE
		return super._durable_write_temp(absolute, encoded)


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_slot = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_shots = {
		"ch2_t_s07_bowls:choice":"soup-choice", "ch2_t_s07_wash:choice":"dry-rack-choice",
		"ch2_t_s07_soup":"tasting", "ch2_t_s07_revisit":"revisit",
		"ch2_t_s07_resume_wash:choice":"resume-choice", "ch2_t_s07_resume_soup":"resume-tasting",
	}
	_main = load("res://game/main.gd").new()
	_store = FaultedRunStore.new(_slot.path_join("slot.json"))
	_main.set("_run_store", _store)
	add_child(_main)
	await _settle(16)
	_main.call("_on_continue_requested")
	await _settle(48)
	if _mode == "taste":
		GameState.set_flag(&"ch2_market_contact_done")
		_main.call("_on_area_requested",KITCHEN)
		await _settle(60)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.resource_path == KITCHEN, "the real Main loaded the kitchen")
	if _level == null or _level.data.resource_path != KITCHEN:
		_done({})
		return
	var npc := _object(ALI)
	_check(npc != null, "the original Ali node is present")
	if npc == null:
		_done({})
		return
	var source_modes := []
	Story.scene_started.connect(func(id: StringName, _mode_tag: StringName) -> void:
		source_modes.append(String(id))
		if _mode == "retry" and id == &"ch2_t_s07_resume_soup":
			_store.fail_next_result = true
		var player := _level.player
		print("STANCE ", id, " ground=",player.is_on_floor()," velocity=",player.velocity,
			" active=",player.interaction.active," pos=",player.global_position,
			" phone=",player.is_on_phone()," carry=",player.carry.is_holding()))
	var before := _receipt(npc)
	var health := _level.player.health
	if _mode.begins_with("cold_"):
		_check(before["dispatch"] == "ch2_t_s07_revisit" and before["health"] == 6 and before["credits"] == 160,
				"actual cold Continue restores the credited and healed player")
	if _mode != "full":
		health.current -= 1 if _mode == "cap" else 2
		health.health_changed.emit(health.current, health.max_health)
		await _settle(35)
	before = _receipt(npc)
	health.healed.connect(func(amount: int) -> void:
		_heals.append(amount)
		if _mode in ["resume", "retry", "cap"]:
			var disk := _disk_receipt()
			_check(disk == [6, 160, true], "durable saved health, credits and receipt are visible before notification"))
	if _mode.begins_with("cold_"):
		_check(await _talk(ALI), "uses the original revisit after cold Continue")
	elif _mode == "taste":
		_check(await _talk(ALI, ["wash", "left"]), "first-visit dry-rack action completes")
	else:
		_check(before["dispatch"] == "ch2_t_s07_resume_wash", "address-only save offers the real washing choice")
		if _mode == "retry":
			_check_retry.call_deferred()
		_check(await _talk(ALI, ["left"]), "revisit dry-rack action completes")
	if _mode == "retry":
		_check(_retry_checked and _store.failed_writes == 1, "retried one real write failure")
	await _settle(48)
	var after := _receipt(npc)
	var revisiting := _mode.begins_with("cold_")
	var expected_gain := 0 if revisiting or _mode == "full" else (1 if _mode == "cap" else 2)
	_check(_heals == ([] if expected_gain == 0 else [expected_gain]), "normal health signal reports the exact gain once")
	_check(after["health"] == (4 if revisiting else 6) and after["credits"] == 160,
			"tasting heals up to maximum and pays exactly once; revisiting pays and heals nothing")
	_check(after["quest"] == "completed" and after["dispatch"] == "ch2_t_s07_revisit", "tasting closes the quest")
	_check(_disk_receipt() == [after["health"], 160, true], "ordinary autosave contains the final health and one receipt")
	_capture("health-after")
	print("ALI_SOUP ", JSON.stringify({"before": before, "after": after, "scenes": source_modes, "heals": _heals, "disk": _disk_receipt()}))
	_done({"before": before, "after": after, "scenes": source_modes, "heals": _heals, "disk": _disk_receipt()})


func _check_retry() -> void:
	for i in STEP_LIMIT:
		var owner := Story.result_completion
		var prompt: Control = owner.get("_prompt")
		if is_instance_valid(prompt):
			_check(_level.player.health.current == 4 and Progression.credits == 120 and _heals.is_empty(),
					"failed write publishes neither health nor credits")
			_check(_disk_receipt() == [4, 120, false] and not GameState.has_flag(&"sq1_soup_practice_done"),
					"failed write preserves the previous saved facts and active quest")
			_capture("retry-before")
			_retry_checked = true
			prompt.retry_button.pressed.emit()
			return
		await get_tree().process_frame


func _disk_receipt() -> Array:
	var decoded := RunSaveCodec.decode(FileAccess.get_file_as_string(_slot.path_join("slot.json")))
	if decoded.has("error"):
		return []
	var data: Dictionary = decoded["data"]
	return [int(data["runtime"]["health"]), int(data["progression"]["credits"]),
			data["progression"]["story_transactions"]["receipts"].has("ch2.sq1_soup")]


func _receipt(npc: NpcActor) -> Dictionary:
	var quest := {}
	var catalog := QuestCatalog.new()
	catalog.load_story_sources(["res://data/story/ch2_heron.json"])
	for record: Dictionary in catalog.quests:
		if record["id"] == "sq1_ali_soup":
			quest = record
	var flags := {}
	for name: String in ["knows_ali_address","ch2_market_contact_done","ch2_ali_home_visit","sq1_soup_practice_done"]:
		flags[name] = GameState.has_flag(StringName(name))
	return {"flags":flags,"dispatch":String(Story.resolve_dispatch(npc.data.talks[npc.current_talk_index()].scene)),
		"health":_level.player.health.current,"credits":Progression.credits,
		"quest":QuestCatalog.status(quest,flags) if not quest.is_empty() else ""}


func _done(record: Dictionary) -> void:
	record["failures"]=_failures
	FileAccess.open(_out_dir.path_join("result.json"),FileAccess.WRITE).store_string(JSON.stringify(record,"  "))
	get_tree().quit(0 if _failures==0 else 1)
