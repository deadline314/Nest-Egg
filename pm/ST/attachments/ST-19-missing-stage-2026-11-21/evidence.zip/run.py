from hashlib import sha256
from pathlib import Path
import json
import os
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
game = base.parent / "ne218-baseline-20261117"
label = sys.argv[1]
out = base / label
out.mkdir()
env = os.environ.copy()
for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "TMPDIR"):
    path = out / key
    path.mkdir()
    env[key] = str(path)
files = ["game/cutscene/cutscene_player.gd", "game/cutscene/stage_library.gd",
         "data/cutscene/stages/ch2_ledger_office.json", "autoload/story.gd"]
sha = lambda path: sha256(path.read_bytes()).hexdigest()
source = {p: sha(game / p) for p in files}
command = [sys.executable, "-B", str(game / "tools/comfyui/gpu_lock.py"), "--",
           "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe", "--path", str(game),
           "--rendering-method", "forward_plus", "--rendering-driver", "vulkan",
           "--audio-driver", "Dummy", "--fixed-fps", "60", "--resolution", "1280x720",
           "--quit-after", "1000", str(base / "observe.tscn"), "--", f"--out={out}"]
(out / "command.json").write_text(json.dumps({"argv": command, "source": source}, indent=2) + "\n", encoding="utf-8")
with (out / "engine.log").open("wb") as log:
    process = subprocess.run(command, cwd=game, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=100)
raw = (out / "engine.log").read_text(encoding="utf-8")
print(raw, flush=True)
assert all(sha(game / p) == digest for p, digest in source.items())
result = json.loads((out / "result.json").read_bytes())
assert "9070 XT" in result["adapter"] and result["hdr"]
assert (out / "missing-opening.png").exists() and (out / "missing-later.png").exists()
errors = re.findall(r"^SCRIPT ERROR: (.*)$", raw, re.M)
(out / "receipt.json").write_text(json.dumps(dict(exit=process.returncode, script_errors=errors), indent=2) + "\n", encoding="utf-8")
if label.startswith("stock"):
    assert len(errors) == 2
    assert all("'actors' on a base object of type 'Nil'" in error for error in errors)
    assert result["failures"] == ["missing-opening stage fallback / actor / fade", "missing-scene-step unexpected actor or stage"]
else:
    assert process.returncode == 0 and not errors and not result["failures"]
    assert raw.count("使用空白舞台") == raw.count("保留原本的舞台") == raw.count("沒有舞台可放置") == 1

