extends Node

const Capture := preload("res://tools/viewport_capture.gd")
const MISSING := "test_bad_cutscene_missing_stage_asset"
const SAY := {"do": "say", "text": "The dialogue is still available."}
var _out := ""
var _fails: Array[String] = []

func _ready() -> void:
	_run.call_deferred()


func _run() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	if not _out.is_absolute_path() or DisplayServer.get_name() == "headless":
		get_tree().quit(2)
		return
	await _check_variant("missing-opening", [{"do":"scene","id":MISSING,"fade":0.08}],
		{"do":"actor","id":"rin","kind":"rin","pos":[280,280],"scale":1.4}, "")
	await _check_variant("missing-later", [
		{"do":"scene","id":"ch2_ledger_office","fade":0.08},
		{"do":"actor","id":"rin","kind":"rin","pos":[270,296],"scale":1.9},
		{"do":"scene","id":MISSING}
	], {}, "ch2_ledger_office")
	await _check_variant("missing-scene-step", [],
		{"do":"actor","id":"rin","kind":"rin","pos":[280,280],"scale":1.4}, "none")
	var output := FileAccess.open(_out.path_join("result.json"), FileAccess.WRITE)
	output.store_string(JSON.stringify({"failures":_fails,"adapter":RenderingServer.get_video_adapter_name(),
		"hdr":get_viewport().use_hdr_2d}, "  "))
	output.close()
	await AudioRelease.settle(get_tree())
	get_tree().quit(int(not _fails.is_empty()))


func _check_variant(label: String, setup: Array, actor: Dictionary, expected_stage: String) -> void:
	var player := CutscenePlayer.new()
	add_child(player)
	var finished := [false]
	player.finished.connect(func(_name: StringName) -> void: finished[0] = true)
	var steps := setup.duplicate()
	if not actor.is_empty():
		steps.append(actor)
	steps.append(SAY)
	player.play(StringName("test_bad_cutscene_" + label), {"steps":steps})
	for frame in 220:
		await get_tree().process_frame
		if player._dialogue.visible and player._dialogue.is_complete():
			break
	if player._dialogue._text.text != SAY.text or not player._dialogue.is_complete():
		_fails.append(label + " dialogue text")
	if expected_stage == "none":
		if player._stage != null or player._actors.has(&"rin"):
			_fails.append(label + " unexpected actor or stage")
	elif player._stage == null or str(player._stage.stage_id) != expected_stage or not player._actors.has(&"rin") or player._fade.color.a > 0.001:
		_fails.append(label + " stage fallback / actor / fade")
	await RenderingServer.frame_post_draw
	if Capture.image(get_viewport()).save_png(_out.path_join(label + ".png")) != OK:
		_fails.append(label + " screenshot")
	player._advance_requested = true
	for frame in 65:
		await get_tree().process_frame
		if finished[0]:
			break
	if not finished[0] or GameplayLock.is_locked() or Story.framing.scope_count() != 0:
		_fails.append(label + " completion or gameplay lock")
	if is_instance_valid(player):
		player.queue_free()
	await get_tree().process_frame

