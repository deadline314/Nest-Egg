extends "res://tools/ch1_flow_probe.gd"

const ROOF := "res://data/levels/ch2_rooftop.tres"
const PAWN := "res://data/levels/ch2_pawnshop.tres"
const PRACTICE := &"ch2_roof_combo_practiced"
const CARD := &"ch2_check_card"
var _main: Node
var _store: RunSaveStore
var _slot := ""
var _mode := "zh"
var _station: TrainingStation
var _hits: Array[Dictionary] = []
var _outcomes := 0


func _ready() -> void:
	for arg: String in OS.get_cmdline_user_args():
		if arg.begins_with("--save-dir="):
			_slot = arg.trim_prefix("--save-dir=")
		elif arg.begins_with("--mode="):
			_mode = arg.trim_prefix("--mode=")
	process_mode = Node.PROCESS_MODE_ALWAYS
	process_priority = 20
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch2_heron"))
	Transition.instant = true
	Story.auto_skip = false
	super._ready()


func _run() -> void:
	_store = RunSaveStore.new(_slot.path_join("slot.json"))
	_main = load("res://game/main.gd").new()
	_main.set("_run_store", _store)
	add_child(_main)
	await _settle(16)
	if _mode in ["en", "ja"]:
		Story.set_language(_mode)
	_main.call("_on_continue_requested")
	await _settle(60)
	var start_done := _mode == "cold"
	_check(GameState.has_flag(PRACTICE) == start_done, "the independently loaded slot starts in the expected practice state")
	var needs_brief := _mode == "zh"
	_check(GameState.has_flag(&"ch2_brief_done") != needs_brief and StoryItems.holds(CARD) != needs_brief,
		"original briefing and card are loaded independently of practice")
	_level = _main.get("_screen") as Level
	if _level == null or _level.data.resource_path != ROOF:
		_main.call("_on_area_requested", ROOF)
		await _settle(60)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.resource_path == ROOF and _level._training_stations.size() == 1, "the real rooftop has one practice station")
	if _level == null or _level._training_stations.size() != 1:
		await _finish()
		return
	_station = _level._training_stations.front()
	_station.completed.connect(func(_s: TrainingStation) -> void: _outcomes += 1)
	_station._hurtbox.hit_received.connect(func(info: DamageInfo) -> void:
		_hits.append({"projectile": info.is_projectile, "stagger": info.stagger, "index": _level.player.melee.index}))
	if needs_brief:
		_check(not _station.is_active() and not _station.is_done() and not _station._hurtbox.enabled, "the target is inactive before the real briefing")
		await _near()
		_capture("before-brief")
		_check(await _talk(&"ch2_egret"), "the original briefing completes normally")
		await _settle(40)
		_check(GameState.has_flag(&"ch2_brief_done") and StoryItems.holds(CARD) and not GameState.has_flag(PRACTICE),
			"the original briefing grants the card independently of practice")
	if _mode == "skip":
		_check(_station.is_active(), "the available exercise can be left untouched")
		await _leave()
		_check(not GameState.has_flag(PRACTICE) and StoryItems.holds(CARD) and _outcomes == 0, "skipping practice preserves the route and its card")
		await _finish()
		return
	if start_done:
		await _near()
		_check(_station.is_done() and not _station._prompt.enabled and not _station._hurtbox.enabled,
			"the persisted completion keeps the checkmark and removes the invitation")
		await _attack()
		await _settle(35)
		_check(_outcomes == 0 and _hits.is_empty(), "a cold revisit cannot publish the result a second time")
		_capture("completed")
		await _finish()
		return
	_shots = {"ch2_t_s03_heavy": "egret-tip"}
	_check(await _talk(&"ch2_egret", ["heavy", "leave"]), "Egret offers the optional practice location at the original topic wheel")
	await _near()
	var joy := _mode == "ja"
	if joy:
		await _press(KEY_NONE, JOY_BUTTON_GUIDE)
	_check(_station.is_active() and _station._prompt.is_showing(), "the contextual target hint is visible close to the dummy")
	_check(_station._prompt.text == _station.data.prompt_text(Story.language) and Story.language == _mode
		and _station._prompt._segments.any(func(segment: Dictionary) -> bool: return segment.get("cap", false) and segment.get("text") == InputBindings.primary_label(&"melee")), "the hint uses the selected language and bound melee keycap")
	_check(_station._prompt._segments.all(func(segment: Dictionary) -> bool: return is_zero_approx(segment.get("y", 0.0))),
		"the localized practice copy fits on one line at the default text size")
	_capture("prompt")
	var progress := Progression.snapshot()
	var items := StoryItems.snapshot()
	var deaths := GameState.deaths
	var presentation_before := Story.is_cinematic_active()
	if not joy:
		await _press(KEY_J)
		await _settle(25)
		_check(_hits.any(func(hit: Dictionary) -> bool: return hit["projectile"]) and not GameState.has_flag(PRACTICE),
			"a real shot reaches the dummy without completing the exercise")
	await _attack(joy)
	await _settle(55)
	_check(_hits.any(func(hit: Dictionary) -> bool: return not hit["projectile"] and hit["index"] == 0 and hit["stagger"] == 2)
			and not GameState.has_flag(PRACTICE), "a real light hit reaches the dummy without completing the exercise")
	await _near()
	await _attack(joy)
	_check(await _phase(0, MeleeModule.Phase.RECOVERY), "first swing reaches its original recovery")
	await _attack(joy)
	_check(await _phase(1, MeleeModule.Phase.RECOVERY), "second swing uses the normal melee buffer")
	_check(not GameState.has_flag(PRACTICE), "two light hits do not complete practice")
	await _attack(joy)
	_check(await _phase(2, MeleeModule.Phase.WINDUP), "the third command enters the original heavy windup")
	for tick in 120:
		if GameState.has_flag(PRACTICE):
			break
		await get_tree().physics_frame
	var valid := _hits.any(func(hit: Dictionary) -> bool: return not hit["projectile"] and hit["stagger"] >= 3)
	_check(valid and _station.is_done() and GameState.has_flag(PRACTICE) and _outcomes == 1,
		"the third real swing lands its heavy follow-through and publishes once")
	_check(_store.read().get("story", {}).get("flags", {}).get(String(PRACTICE), false),
		"the primary slot already contains the practice flag when completion becomes visible")
	_check(not presentation_before and not Story.is_cinematic_active() and not GameplayLock.is_locked()
		and Progression.snapshot() == progress and StoryItems.snapshot() == items and GameState.deaths == deaths,
		"the optional completion changes no reward, inventory, death count or presentation lock")
	await _settle(25)
	_capture("completed")
	await _finish()


func _near() -> void:
	_level.player.global_position = _station.global_position + Vector2(-24, 0)
	_level.player.velocity = Vector2.ZERO
	_level.player.facing = 1
	AimInput.set_virtual_gamepad(_level.player, true)
	AimInput.restore_direction(Vector2.RIGHT)
	await _settle(62)


func _attack(joy := false) -> void:
	await _press(KEY_NONE if joy else KEY_F, JOY_BUTTON_Y if joy else -1)


func _press(key: int, button := -1) -> void:
	var event: InputEvent
	if button >= 0:
		var controller := InputEventJoypadButton.new()
		controller.device = 0
		controller.button_index = button
		event = controller
	else:
		var keyboard := InputEventKey.new()
		keyboard.physical_keycode = key
		event = keyboard
	event.set("pressed", true)
	Input.parse_input_event(event)
	await _settle(2)
	event = event.duplicate() as InputEvent
	event.set("pressed", false)
	Input.parse_input_event(event)
	await _settle(2)


func _phase(index: int, phase: MeleeModule.Phase) -> bool:
	for tick in 110:
		if _level.player.melee.index == index and _level.player.melee.phase == phase:
			return true
		await get_tree().physics_frame
	return false


func _leave() -> void:
	var stair: Portal = _level._portals.get(&"roof_stairs")
	_check(stair != null, "the original stair exit exists")
	if stair == null:
		return
	_level.player.global_position = stair.global_position
	await _settle(15)
	await _press(KEY_E)
	await _settle(75)
	_level = _main.get("_screen") as Level
	_check(_level != null and _level.data.resource_path == PAWN, "the actual stair exit works without finishing practice")


func _finish() -> void:
	var result := {"mode":_mode, "failures":_failures, "hits":_hits, "outcomes":_outcomes,
		"brief":GameState.has_flag(&"ch2_brief_done"), "practice":GameState.has_flag(PRACTICE), "card":StoryItems.holds(CARD)}
	var file := FileAccess.open(_out_dir.path_join("result.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify(result, "  ") + "\n")
	file.close()
	await _settle(60)
	_main.call("_quit", 0 if _failures == 0 else 1)
