import hashlib,json,os,pathlib,re,subprocess,sys

work=pathlib.Path('/workspace/Nest-Egg/work/batch1026')
repo=work/'kitchen-worktree'
base=pathlib.Path('/workspace/Nest-Egg/work/batch1020b')
frozen=json.loads((work/'handoff-final-source-v14/source.json').read_text())
def unchanged():
    for name,expected in frozen['files'].items():
        assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==expected,name

env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1026/kitchen-worktree'
env['NE_NATIVE_GODOT']=str(work/'godot-audio-build/dist/godot')
jobs=[('st10-handoff-main-audiofix-v1','preview','preview','handoff-main-audiofix-v1-save')]
jobs.extend(('st10-handoff-'+mode.replace('_','-')+'-audiofix-v1','lifecycle',mode,'handoff-'+mode+'-audiofix-v1-save') for mode in ['cancel_insert','cancel_receipt','skip_insert','skip_receipt','blocked'])
jobs.extend([('st10-handoff-writer-audiofix-v1','writer','write','handoff-writer-audiofix-v1-save'),('st10-handoff-cold-audiofix-v1','writer','read','handoff-writer-audiofix-v1-save'),('st10-handoff-save-reset-audiofix-v1','writer','reset_write','handoff-save-reset-audiofix-v1-save'),('st10-handoff-reset-cold-audiofix-v1','writer','reset_read','handoff-save-reset-audiofix-v1-save')])
jobs.extend(('st10-handoff-mid-'+part+'-audiofix-v1','mid','mid_'+part.replace('-','_'),'handoff-mid-'+part.split('-')[0]+'-audiofix-v1-save') for part in ['accept-write','accept-read','receipt-write','receipt-read'])
jobs.append(('st10-handoff-mid-original-read-audiofix-v1','mid','mid_accept_read','handoff-mid-original-audiofix-v1-save'))
# Reuse the exact primary bytes of the real earlier unfinished quit, without changing flags.
import shutil
original=work/'handoff-mid-primary-before-v2.json'
copy=work/'handoff-mid-original-audiofix-v1-save/slot.json'
copy.parent.mkdir(exist_ok=False)
shutil.copyfile(original,copy)
assert hashlib.sha256(copy.read_bytes()).hexdigest()==hashlib.sha256(original.read_bytes()).hexdigest()
(work/'handoff-audiofix-native-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
results=[]
for name,scene,mode,save in jobs:
    unchanged()
    print('START',name,flush=True)
    command=[sys.executable,'/workspace/Nest-Egg/work/batch1024/native-large.py',name,'res://work/st10-handoff/'+scene+'.tscn','--mode='+mode,'--save-dir='+str(work/save)]
    with (work/(name+'-console.log')).open('w') as output:
        code=subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT).returncode
    unchanged()
    log=(base/(name+'.log')).read_text(errors='replace')
    result={'name':name,'exit':code,'engine_exit':int((base/(name+'.exit')).read_text()),'clean':not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use',log,re.M)}
    path=base/name/'result.json'
    if path.exists():result.update(json.loads(path.read_text()))
    results.append(result)
    (work/'handoff-final-native-audiofix-v1.json').write_text(json.dumps(results,indent=2)+'\n')
    print('DONE',name,code,'checks',result.get('checks'),'failures',result.get('failures'),flush=True)
    assert code==0 and result['engine_exit']==0 and result['clean'],result
    assert not result.get('failures'),result
print('ALL NATIVE CHECKS COMPLETE; REVIEW IMAGES BEFORE AFFECTED RUN',flush=True)
unchanged()
