import hashlib,json,os,pathlib,re,subprocess,sys

work=pathlib.Path('/workspace/Nest-Egg/work/batch1026')
repo=work/'kitchen-worktree'
base=pathlib.Path('/workspace/Nest-Egg/work/batch1020b')
frozen=json.loads((work/'handoff-final-source-v12/source.json').read_text())
def unchanged():
    for name,expected in frozen['files'].items():
        assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==expected,name

env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1026/kitchen-worktree'
jobs=[('st10-handoff-main-v9','preview','preview','handoff-main-v9-save')]
jobs.extend(('st10-handoff-'+mode.replace('_','-')+'-vfinal3','lifecycle',mode,'handoff-'+mode+'-vfinal3-save') for mode in ['cancel_insert','cancel_receipt','skip_insert','skip_receipt','blocked'])
jobs.extend([('st10-handoff-writer-v4','writer','write','handoff-writer-v4-save'),('st10-handoff-cold-v4','writer','read','handoff-writer-v4-save'),('st10-handoff-save-reset-v3','writer','reset_write','handoff-save-reset-v3-save'),('st10-handoff-reset-cold-v2','writer','reset_read','handoff-save-reset-v3-save')])
jobs.append(('st10-handoff-mid-original-read-v4','mid','mid_accept_read','handoff-mid-original-v4-save'))
results=[]
for name,scene,mode,save in jobs:
    unchanged()
    print('START',name,flush=True)
    command=[sys.executable,'/workspace/Nest-Egg/work/batch1024/native-large.py',name,'res://work/st10-handoff/'+scene+'.tscn','--mode='+mode,'--save-dir='+str(work/save)]
    with (work/(name+'-console.log')).open('w') as output:
        code=subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT).returncode
    unchanged()
    log=(base/(name+'.log')).read_text(errors='replace')
    result={'name':name,'exit':code,'engine_exit':int((base/(name+'.exit')).read_text()),'clean':not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use',log,re.M)}
    path=base/name/'result.json'
    if path.exists():result.update(json.loads(path.read_text()))
    results.append(result)
    (work/'handoff-final-native-v8.json').write_text(json.dumps(results,indent=2)+'\n')
    print('DONE',name,code,'checks',result.get('checks'),'failures',result.get('failures'),flush=True)
    assert code==0 and result['engine_exit']==0 and result['clean'],result
    assert not result.get('failures'),result
print('ALL NATIVE CHECKS COMPLETE; REVIEW IMAGES BEFORE AFFECTED RUN',flush=True)
unchanged()
