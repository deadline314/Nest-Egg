import json,os,pathlib,re,subprocess,hashlib
w=pathlib.Path('/workspace/Nest-Egg/work/batch1026');r=w/'kitchen-worktree'
env=os.environ.copy();env.update(GODOT=str(w/'godot-audio-build/dist/godot'),SHARDS='3',LOG_DIR=str(w/'handoff-integrated-phase2-v1-shards'))
frozen=json.loads((w/'handoff-final-source-v14/source.json').read_text())
def verify():
 for name,h in frozen['files'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==h,name
def run(tag,command,extra=None):
 verify();print(tag,flush=True)
 with (w/(tag+'.log')).open('w') as out:code=subprocess.run(command,cwd=r,env={**env,**(extra or {})},stdout=out,stderr=subprocess.STDOUT).returncode
 (w/(tag+'.exit')).write_text(str(code)+'\n');verify();assert code==0,(tag,code)
run('handoff-integrated-unit-v1',[env['GODOT'],'--headless','--path',str(r),'res://work/st10-handoff/unit.tscn'])
run('handoff-integrated-phase2-v1',['bash','tools/run_tests_parallel.sh','--only=CutsceneSuite,EnvironmentSuite,NpcSuite,RunSaveSuite,StageCoverageWorldSuite,SceneSanitySuite,StoryLintSuite'])
run('handoff-integrated-native-v1',['python','/workspace/Nest-Egg/work/batch1024/native-large.py','st10-handoff-integrated-phase2-v1','res://work/st10-handoff/preview.tscn','--mode=preview','--save-dir='+str(w/'handoff-integrated-phase2-v1-save')],{'NE_NATIVE_PROJECT':'../batch1026/kitchen-worktree','NE_NATIVE_GODOT':env['GODOT']})
print('MERGED CHECKS COMPLETE',flush=True)
