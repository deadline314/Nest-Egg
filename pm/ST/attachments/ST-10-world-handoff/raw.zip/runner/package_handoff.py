import hashlib,json,pathlib,re,shutil,zipfile

W=pathlib.Path('/workspace/Nest-Egg/work/batch1026')
R=W/'kitchen-worktree'
N=pathlib.Path('/workspace/Nest-Egg/work/batch1020b')
D=R/'pm/ST/attachments/ST-10-world-handoff'
CASES=[row[0] for row in json.loads((W/'handoff-audiofix-native-jobs.json').read_text())]

def digest(data):return hashlib.sha256(data).hexdigest()
def put_file(entries,relative,path):
    if path.is_file():entries[relative]=path.read_bytes()
def tree(entries,prefix,path):
    for p in sorted(path.rglob('*')):
        if p.is_file():put_file(entries,prefix+'/'+str(p.relative_to(path)),p)
def archive(entries,prefix):
    groups=[];group={};size=0
    for name,data in sorted(entries.items()):
        if group and size+len(data)>32*1024*1024:
            groups.append(group);group={};size=0
        group[name]=data;size+=len(data)
    if group:groups.append(group)
    receipts=[]
    for i,group in enumerate(groups):
        name=prefix+('' if i==0 else '-'+str(i+1))+'.zip'
        p=D/name
        with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
            for key,value in group.items():z.writestr(key,value)
        with zipfile.ZipFile(p) as z:
            for key,value in group.items():
                actual=z.read(key);assert actual==value and digest(actual)==digest(value),key
        assert p.stat().st_size<50*1024*1024,p
        receipts.append({'file':name,'entries':len(group),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())})
    return receipts

def main():
    assert (W/'handoff-final-affected-audiofix-v1.exit').read_text().strip()=='0'
    changed=(W/'handoff-final-affected-audiofix-v1.log').read_text()
    m=re.search(r'checks: (\d+), new failures: (\d+), known failures .*?: (\d+)\s+\(wall time (\d+) s\)',changed)
    assert m and m[2]=='0' and m[3]=='0',changed[-2000:]
    shards=list((W/'handoff-final-affected-audiofix-v1-shards').glob('*.log'));assert len(shards)==8
    for shard in shards:
        text=shard.read_text(errors='replace')
        assert re.search(r'^checks: [0-9]+, failures: 0$',text,re.M),shard
        assert not re.search(r'handle_crash:|Program crashed|signal 11|double free|heap corruption|corrupted double-linked',text,re.I),shard
    frozen=json.loads((W/'handoff-final-source-v14/source.json').read_text())
    for name,expected in frozen['files'].items():assert digest((R/name).read_bytes())==expected,name
    D.mkdir(parents=True,exist_ok=True)
    (D/'.gdignore').write_text('')
    raw={};results=[]
    for name in CASES:
        result=json.loads((N/name/'result.json').read_text());log=(N/(name+'.log')).read_text()
        assert (N/(name+'.exit')).read_text().strip()=='0' and not result['failures'],(name,result)
        assert not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use',log,re.M),name
        results.append({'name':name,'source_snapshot':'v14',**result})
        tree(raw,'native/'+name,N/name)
        for suffix in ['.log','.exit']:put_file(raw,'native/'+name+suffix,N/(name+suffix))
    tree(raw,'source',W/'handoff-final-source-v14')
    for p in sorted((W/'handoff-final-affected-audiofix-v1-shards').glob('*.log')):put_file(raw,'affected/shards/'+p.name,p)
    for f in ['handoff-final-affected-audiofix-v1.log','handoff-final-affected-audiofix-v1.exit','handoff-unit-final-v5.log','handoff-generator-proof.json','handoff-assets-check-v1.log','handoff-art-build-v1.log','handoff-story-build-v1.log','handoff-import-final-v3.log','ci-9055c63a-job121322701400.log','ci-9055c63a-receipt.json','handoff-rejections.json','handoff-reset-probe-correction.json']:
        put_file(raw,'logs/'+f,W/f)
    for p in sorted(W.glob('handoff-*-vfinal-save')):tree(raw,'slots/'+p.name,p)
    for name in sorted({row[3] for row in json.loads((W/'handoff-audiofix-native-jobs.json').read_text())}):tree(raw,'slots/'+name,W/name)
    for p in sorted(W.glob('run_handoff_final_v*.py')):put_file(raw,'runner/'+p.name,p)
    put_file(raw,'runner/run_handoff_final_audiofix_v1.py',W/'run_handoff_final_audiofix_v1.py')
    put_file(raw,'engine/receipt.json',W/'ne280-engine-receipt.json')
    put_file(raw,'runner/run_st10_integrated_phase2_v1.py',W/'run_st10_integrated_phase2_v1.py')
    for name in ['handoff-integrated-unit-v1.log','handoff-integrated-unit-v1.exit','handoff-integrated-phase2-v1.log','handoff-integrated-phase2-v1.exit','handoff-integrated-native-v1.log','handoff-integrated-native-v1.exit','handoff-integrated-phase2-receipt.json','st10-local-source-rebase.json']:
        put_file(raw,'merged/'+name,W/name)
    for p in sorted((W/'handoff-integrated-phase2-v1-shards').glob('*.log')):put_file(raw,'merged/shards/'+p.name,p)
    put_file(raw,'runner/package_handoff.py',pathlib.Path(__file__))
    history={};references={}
    raw_hashes={digest(data):name for name,data in raw.items()}
    for p in sorted(W.iterdir()):
        if p.is_dir() and (p.name.startswith('handoff-final-source-v') or p.name.startswith('handoff-facing-before-source') or p.name.startswith('handoff-mid-before-source')) and p.name!='handoff-final-source-v14':
            for q in sorted(p.rglob('*')):
                if not q.is_file():continue
                key='source/'+p.name+'/'+str(q.relative_to(p));data=q.read_bytes();h=digest(data)
                if h in raw_hashes:references[key]={'sha256':h,'raw_entry':raw_hashes[h]}
                else:history[key]=data
        elif p.is_file() and p.name.startswith(('handoff-','st10-handoff-')) and p.suffix in ['.log','.json','.txt','.gd','.exit']:
            put_file(history,'logs/'+p.name,p)
    for p in sorted(N.glob('st10-handoff-*')):
        if p.name.endswith('-profile'):continue
        if p.name in CASES or any(p.name==c+s for c in CASES for s in ['.log','.exit']):continue
        if p.is_dir():
            tree(history,'native/'+p.name,p)
        elif p.is_file() and p.suffix in ['.log','.exit']:put_file(history,'native/'+p.name,p)
    for folder in sorted(W.glob('handoff-final-affected-v*-shards')):
        if folder.name=='handoff-final-affected-audiofix-v1-shards':continue
        for p in sorted(folder.glob('*.log')):put_file(history,'affected/'+folder.name+'/'+p.name,p)
    for p in sorted(W.glob('handoff-baseline-*.log')):put_file(raw,'baseline/'+p.name,p)
    for p in sorted(W.glob('handoff-baseline-*.exit')):put_file(raw,'baseline/'+p.name,p)
    for folder in sorted(W.glob('handoff-crash-*-v1-shards')):
        for p in sorted(folder.glob('*.log')):put_file(raw,'crash-controls/'+folder.name+'/'+p.name,p)
    for p in sorted(W.glob('handoff-crash-*')):
        if p.is_file():put_file(raw,'crash-controls/'+p.name,p)
    history['source/raw-references.json']=(json.dumps(references,indent=2)+'\n').encode()
    archives=archive(raw,'raw')+archive(history,'history')
    manifest={'raw':{k:{'bytes':len(v),'sha256':digest(v)} for k,v in sorted(raw.items())},'history':{k:{'bytes':len(v),'sha256':digest(v)} for k,v in sorted(history.items())},'historical_common_files':references}
    (D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    receipt={'base':frozen['base'],'source_snapshot':'v14','engine':json.loads((W/'ne280-engine-receipt.json').read_text()),'renderer':'software Vulkan llvmpipe / Forward+ / HDR2D','native':{'processes':len(results),'checks':sum(r['checks'] for r in results),'failures':0,'cases':results},'affected':{'groups':int(re.search(r'Running (\d+) groups',changed)[1]),'checks':int(m[1]),'new_failures':int(m[2]),'known_failures':int(m[3]),'wall_seconds':int(m[4])},'unit':{'checks':86,'failures':0,'expected_fixture_error_messages_retained':True},'merge_integration':json.loads((W/'handoff-integrated-phase2-receipt.json').read_text()),'reach':{'poses':360,'legacy_unreachable':2,'downward_unreachable':0,'worst_palm_error':.0000863167442730628},'mid_negative':{'checks':5,'failures':4,'original_primary_sha256':'19e068594b950ca1bc4e6863bd33cc95deba8d2c08c2a1c33122df6f5d4dadd3'},'generic_resume_negative':{'checks':6,'failures':1,'unwanted_physics_steps':7,'boundary':'queued restore begins'},'generic_resume_fixed':{'checks':6,'failures':0,'unwanted_physics_steps':0},'facing_negative':{'checks':15,'failures':1,'unexpected_gameplay_facing_observations':15},'facing_fixed':{'checks':15,'failures':0},'archives':archives,'boundaries':['Arranged canonical disk and direct real authored cabinet call; not a chapter playthrough.','No hardware GPU, human operator, or physical gamepad claim.','Existing terminal save UI remains retry-only; supported external presentation reset tested separately.','ST-9 general story-result delivery remains incomplete.']}
    (D/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    images={
      'insert':N/'st10-handoff-main-audiofix-v1/insert.png','take':N/'st10-handoff-main-audiofix-v1/take.png','stow':N/'st10-handoff-main-audiofix-v1/stow.png',
      'after':N/'st10-handoff-main-audiofix-v1/completed-ch1_t_handoff_receipt.png','retry':N/'st10-handoff-writer-audiofix-v1/ch1_t_handoff_receipt-refused.png',
      'reset':N/'st10-handoff-save-reset-audiofix-v1/receipt-save-reset.png','cold-paper':N/'st10-handoff-reset-cold-audiofix-v1/receipt-reset-cold.png',
      'mid-cold':N/'st10-handoff-mid-receipt-read-audiofix-v1/mid-resumed-ch1_t_handoff_receipt.png','mid-original':N/'st10-handoff-mid-original-read-audiofix-v1/mid-resumed-ch1_t_handoff_accept.png',
      'rejected-origin':N/'st10-handoff-main-v2/take.png','rejected-facing':N/'st10-handoff-facing-before-v1/completed-ch1_t_handoff_receipt.png'}
    for name,p in images.items():shutil.copyfile(p,R/'pm/ST/images'/('ST-10-world-handoff-'+name+'.png'))
    print(json.dumps({'native_checks':receipt['native']['checks'],'affected':receipt['affected'],'archives':archives}))

if __name__=='__main__':main()
