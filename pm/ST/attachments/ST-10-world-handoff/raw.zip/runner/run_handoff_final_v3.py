import hashlib,json,os,pathlib,re,subprocess,sys

work=pathlib.Path('/workspace/Nest-Egg/work/batch1026')
repo=work/'kitchen-worktree'
base=pathlib.Path('/workspace/Nest-Egg/work/batch1020b')
frozen=json.loads((work/'handoff-final-source-v4/source.json').read_text())
def unchanged():
    for name,expected in frozen['files'].items():
        assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==expected,name

env=os.environ.copy();env['NE_NATIVE_PROJECT']='../batch1026/kitchen-worktree'
jobs=[('st10-handoff-main-v6','preview','preview','handoff-preview-v6-save'),('st10-handoff-cancel-receipt-v2','lifecycle','cancel_receipt','handoff-cancel_receipt-v2-save'),('st10-handoff-skip-receipt-v3','lifecycle','skip_receipt','handoff-skip_receipt-v3-save'),('st10-handoff-writer-v2','writer','write','handoff-writer-v2-save'),('st10-handoff-cold-v2','writer','read','handoff-writer-v2-save'),('st10-handoff-save-cancel-v1','writer','cancel_write','handoff-save-cancel-v1-save'),('st10-handoff-cancel-cold-v1','writer','cancel_read','handoff-save-cancel-v1-save')]
results=[]
for name,scene,mode,save in jobs:
    unchanged()
    print('START',name,flush=True)
    command=[sys.executable,'/workspace/Nest-Egg/work/batch1024/native-large.py',name,'res://work/st10-handoff/'+scene+'.tscn','--mode='+mode,'--save-dir='+str(work/save)]
    with (work/(name+'-console.log')).open('w') as output:
        code=subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT).returncode
    unchanged()
    log=(base/(name+'.log')).read_text(errors='replace')
    result={'name':name,'exit':code,'engine_exit':int((base/(name+'.exit')).read_text()),'clean':not re.search(r'SCRIPT ERROR|^ERROR:|leaked|resources still in use',log,re.M)}
    path=base/name/'result.json'
    if path.exists():result.update(json.loads(path.read_text()))
    results.append(result)
    (work/'handoff-final-native-v3.json').write_text(json.dumps(results,indent=2)+'\n')
    print('DONE',name,code,'checks',result.get('checks'),'failures',result.get('failures'),flush=True)
    assert code==0 and result['engine_exit']==0 and result['clean'],result
    assert not result.get('failures'),result
print('ALL NATIVE CHECKS COMPLETE',flush=True)
unchanged()
env.update(GODOT='/workspace/Nest-Egg/work/batch1020b/godot472/Godot_v4.7.2-stable_linux.x86_64',SHARDS='8',LOG_DIR=str(work/'handoff-final-affected-v1-shards'))
with (work/'handoff-final-affected-v1.log').open('w') as output:
    code=subprocess.run(['bash','tools/run_tests_changed.sh'],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT).returncode
(work/'handoff-final-affected-v1.exit').write_text(str(code)+'\n')
unchanged()
print('AFFECTED EXIT',code,flush=True)
sys.exit(code)
