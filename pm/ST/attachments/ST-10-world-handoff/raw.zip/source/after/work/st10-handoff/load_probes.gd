extends Node

func _ready() -> void:
	var failed := false
	for path: String in ["res://work/st10-handoff/preview.gd", "res://work/st10-handoff/lifecycle.gd", "res://work/st10-handoff/writer.gd"]:
		var script := load(path) as GDScript
		var good := script != null and script.can_instantiate()
		print("PROBE_LOAD ", path, " ", good)
		failed = failed or not good
	get_tree().quit(1 if failed else 0)
