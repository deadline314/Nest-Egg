extends "res://tests/smoke_test.gd"
func _run() -> void:
	await preload("res://tests/helpers/resume_physics_scope_checks.gd").run(CutsceneSuite.new(self))
	await _finish()
