extends "res://work/st10-handoff/prior_terminal_results_probe.gd"

var _seen: Dictionary = {}
var _label: CanvasLayer
var _worst_palm := 0.0
var _worst_paper := 0.0
var _hand_frames := 0
var _paper_frames := 0
var _expected_facing := 1
var _facing_changes := 0

func _run() -> void:
	await _setup_main()
	for pair: Array in [["ch1_t_handoff_accept", "deliver"], ["ch1_t_handoff_receipt", "take"]]:
		_target = StringName(pair[0])
		var npc := _cabinet()
		var level := _main.get("_screen") as Level
		level.player.global_position = npc.global_position + Vector2(-16,0)
		var until := Time.get_ticks_msec() + 10000
		while (not level.player.is_on_floor() or absf(level.player.velocity.y) > 0.1) and Time.get_ticks_msec() < until:
			await get_tree().physics_frame
		await _frames(5)
		_check(level.player.is_on_floor(), "real player is grounded before interaction")
		_expected_facing = level.player.facing
		var done := [false, false]
		var talk := func() -> void:
			done[1] = await npc._talk()
			done[0] = true
		talk.call()
		await _drive_preview(pair[1], done)
		_check(done[0] and done[1], "actual cabinet request completes: " + String(_target))
		_check(Story.progress_snapshot().has(_target), "completion is published only by the original writer")
		await _capture("completed-" + String(_target))
	_check(StoryItems.was_transferred(&"ch1_data_disk") and StoryItems.holds(&"ch1_delivery_receipt"), "original disk transferred and receipt held")
	_check(_hand_frames > 0 and _worst_palm <= 0.25, "all observed reach frames keep the actual palm on the path: " + str(_worst_palm))
	_check(_paper_frames > 0 and _worst_paper <= 0.25, "all carried paper frames keep the same strip on the actual palm: " + str(_worst_paper))
	_check(_facing_changes == 0, "presentation preserves the gameplay-facing state paired with the original aim: " + str(_facing_changes))
	await _finish()

func _setup_main() -> void:
	CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
	Transition.instant = true
	Story.auto_skip = true
	_main = MainScript.new()
	_store = RunSaveStore.new(_directory.path_join("slot.json"))
	_main.set("_run_store", _store)
	add_child(_main)
	await _frames(5)
	_main.call("_on_start_requested", GameState.difficulties[1])
	await _room("")
	Story.reset_active_presentation(&"probe_setup")
	_check(StoryItems.acquire(&"ch1_data_disk", false), "arranged public disk custody; not a pickup playthrough")
	_main.call("_on_area_requested", "res://data/levels/ch1_handoff.tres")
	await _room("res://data/levels/ch1_handoff.tres")
	Story.reset_active_presentation(&"probe_setup")
	Story.auto_skip = false
	_label = CanvasLayer.new()
	_label.layer = 120
	add_child(_label)
	var note := Label.new()
	note.text = "SOFTWARE FORWARD+ / REAL MAIN + ARRANGED DISK / NOT A PLAYTHROUGH"
	note.position = Vector2(10, 10)
	note.add_theme_font_size_override("font_size", 12)
	_label.add_child(note)

func _drive_preview(choice: String, done: Array) -> void:
	var deadline := Time.get_ticks_msec() + 180000
	while Time.get_ticks_msec() < deadline and not done[0]:
		var movie := Story._player as CutscenePlayer
		if is_instance_valid(movie) and movie.choice_active():
			var index := movie._choice_options.find_custom(func(option: Dictionary) -> bool: return option.get("id") == choice)
			_check(index >= 0, "actual explicit cabinet choice exists: " + choice)
			if index < 0:
				return
			movie.choose(index)
		elif is_instance_valid(movie) and movie._dialogue.visible:
			movie._dialogue.complete()
			movie._advance_requested = true
		var level := _main.get("_screen") as Level
		var action := level.player._visual.interaction_action
		if action != null and not action.done and level.player.facing != _expected_facing:
			_facing_changes += 1
		if action != null and action._hand_started and action.phase != "release" and not action.done:
			_hand_frames += 1
			_worst_palm = maxf(_worst_palm, action.contact_error)
			if is_instance_valid(action._paper) and action._paper.visible:
				_paper_frames += 1
				_worst_paper = maxf(_worst_paper, action._paper.to_global(Vector2(0, action._paper.length)).distance_to(level.player._visual.rig.hand_contact_global(&"front")))
		if action != null and not action.done and action.phase not in ["approach", "release", "feed"] \
				and action._elapsed / action._duration > 0.65 and not _seen.has(action.phase):
			_seen[action.phase] = true
			await _capture(action.phase)
		if action != null and action.failed:
			_check(false, "action failed: " + action.error)
		await _frames(1)
	_check(done[0], "real interaction returns within bounded time")

func _capture(name: String) -> void:
	await RenderingServer.frame_post_draw
	var level := _main.get("_screen") as Level
	var action := level.player._visual.interaction_action
	var row := {"image":name, "player":[level.player.global_position.x,level.player.global_position.y],
		"gameplay_facing":level.player.facing, "rig_facing":level.player._visual.rig.facing, "aim":[level.player.aim_dir.x,level.player.aim_dir.y],
		"floor":level.player.is_on_floor(), "disk_held":StoryItems.holds(&"ch1_data_disk"),
		"disk_delivered":GameState.has_flag(&"ch1_disk_delivered"), "receipt_taken":GameState.has_flag(&"ch1_disk_receipt_taken")}
	if action != null:
		row.merge({"phase":action.phase,"elapsed":action._elapsed,"palm_error":action.contact_error,
			"contacts":action.contacts_completed,"paper_instance":action.paper_instance,"failed":action.failed,"error":action.error,
			"intake_error":action.intake_error if is_finite(action.intake_error) else null,
			"paper_grip_error":action.paper_grip_error if is_finite(action.paper_grip_error) else null})
	_records.append(row)
	print("HANDOFF_FRAME ",JSON.stringify(row))
	DirAccess.make_dir_recursive_absolute(_out)
	preload("res://tools/viewport_capture.gd").image(get_viewport()).save_png(_out.path_join(name+".png"))
