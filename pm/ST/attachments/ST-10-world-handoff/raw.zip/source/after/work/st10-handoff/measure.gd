extends "res://tools/scenarios/scenario_base.gd"
var main: Node
var rows: Array = []
func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--out="): out_dir = arg.trim_prefix("--out=")
 DirAccess.make_dir_recursive_absolute(out_dir)
 _run.call_deferred()
func room(path := "") -> Level:
 var end := Time.get_ticks_msec() + 120000
 while Time.get_ticks_msec() < end:
  var value := main.get("_screen") as Level
  if value != null and value.is_initialized() and not main.call("_route_pending") and (path.is_empty() or value.data.resource_path == path): return value
  await get_tree().process_frame
 return null
func _run() -> void:
 CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
 Transition.instant = true
 Story.auto_skip = true
 main = preload("res://game/main.gd").new()
 main.set("_run_store", RunSaveStore.new("/workspace/Nest-Egg/work/batch1026/handoff-measure-slot.json"))
 add_child(main)
 await settle(5)
 main.call("_on_start_requested", GameState.difficulties[1])
 await room()
 Story.reset_active_presentation(&"measurement_setup")
 assert(StoryItems.acquire(&"ch1_data_disk", false))
 main.call("_on_area_requested", "res://data/levels/ch1_handoff.tres")
 var level := await room("res://data/levels/ch1_handoff.tres")
 var p := level.player
 var end := Time.get_ticks_msec() + 5000
 while not p.is_on_floor() and Time.get_ticks_msec() < end: await get_tree().physics_frame
 assert(p.is_on_floor())
 p.velocity = Vector2.ZERO
 p.set_physics_process(false)
 var cabinet := level.find_child("clinic__report_cabinet", true, false) as PropNode
 assert(cabinet != null)
 p._visual.set_interacting(true)
 var rig := p._visual.rig
 var goals := {"intake":cabinet.global_position + cabinet.data.size * Vector2(.35,.30) - Vector2(3,0), "paper":cabinet.global_position + cabinet.data.size * Vector2(.9,.30) + Vector2(0,8)}
 for face: int in [1,-1]:
  for x: float in ([266,274,280,282,284] if face==1 else [308,312,315,318,322]):
   p.global_position.x=x
   p.facing=face
   p._visual._interaction_input.facing=face
   p._visual._interaction_input.aim_dir=Vector2(face,0)
   p._visual._interaction_input.hand_grip_front=true
   for name: String in ["intake","paper","pocket"]:
    p._visual._physics_process(1.0/60)
    var shoulder := rig.bone(&"arm_front_upper").global_position
    var goal: Vector2 = goals.get(name,p.global_position + Vector2(face*6,-30))
    var placed := rig.place_hand(&"front",goal,0 if face==1 else PI,1)
    var palm := rig.bone(&"hand_front").to_global(rig.hand_grip_offset(&"hand_front"))
    var row := {"x":x,"facing":face,"target":name,"goal":[goal.x,goal.y],"shoulder":[shoulder.x,shoulder.y],"reachable":placed,"actual_palm_error":palm.distance_to(goal)}
    rows.append(row)
    print("HANDOFF_MEASURE ",JSON.stringify(row))
 p._visual.set_interacting(false)
 var file:=FileAccess.open(out_dir.path_join("measurement.json"),FileAccess.WRITE)
 file.store_string(JSON.stringify({"cabinet_pos":[cabinet.global_position.x,cabinet.global_position.y],"cabinet_size":[cabinet.data.size.x,cabinet.data.size.y],"player_floor":p.global_position.y,"rows":rows},"  "))
 file.close()
 print("HANDOFF_MEASURE_TOTAL ",rows.size())
 main.call("_quit",0)
