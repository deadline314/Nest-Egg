extends "res://tests/smoke_test.gd"

func _run() -> void:
	var suite := CutsceneSuite.new(self)
	preload("res://tests/helpers/world_prop_action_checks.gd").run(suite)
	preload("res://tests/helpers/world_paper_reach_checks.gd").run(suite)
	await EnvironmentSuite.new(self)._test_prop_reaction()
	await _finish()
