extends RefCounted

static func run(suite: TestSuite) -> void:
	for pair: Array in [["handoff_insert", "ch1_t_handoff_accept"], ["handoff_take_paper", "ch1_t_handoff_receipt"]]:
		suite.check(WorldPropAction.problem(pair[0], pair[1], true).is_empty(), "authored world action accepts JSON numeric facing: " + pair[0])
		suite.check(not WorldPropAction.problem(pair[0], "another_scene", true).is_empty(), "a world action cannot be borrowed by another scene")
		suite.check(not WorldPropAction.problem(pair[0], pair[1], false).is_empty(), "a world action requires the actual map overlay")
	var spec := WorldPropAction.definition("handoff_insert")
	var original := spec.duplicate(true)
	for bad: Variant in [true, "1", 0, 0.5, INF, NAN]:
		spec["facing"] = bad
		suite.check(not WorldPropAction.problem("handoff_insert", "ch1_t_handoff_accept", true).is_empty(), "bad world action facing is rejected: " + str(bad))
	spec.assign(original)
	for bad: Variant in [null, [true, 2], [1, "2"], [INF, 0], [0, NAN], [0, 257]]:
		spec["station"] = bad
		suite.check(not WorldPropAction.problem("handoff_insert", "ch1_t_handoff_accept", true).is_empty(), "bad world action station is rejected: " + str(bad))
	spec.assign(original)
	for bad: Variant in [true, "5", -1, 0, 9, INF, NAN]:
		spec["width"] = bad
		suite.check(not WorldPropAction.problem("handoff_insert", "ch1_t_handoff_accept", true).is_empty(), "bad held item width is rejected: " + str(bad))
	spec.assign(original)
	suite.check(WorldPropAction.problem("handoff_insert", "ch1_t_handoff_accept", true).is_empty(), "invalid controls restore the original world action")
	for id: Variant in [null, true, 1, "../handoff_insert", "missing_world_action"]:
		suite.check(not WorldPropAction.problem(id, "ch1_t_handoff_accept", true).is_empty(), "world action names never resolve arbitrary paths")
	var camera := LevelCamera.new()
	var first := RefCounted.new()
	var second := RefCounted.new()
	var prior := camera.process_mode
	var zoom := camera.zoom
	suite.check(not camera.acquire_presentation_focus(first, Vector2.INF), "invalid camera focus does not acquire ownership")
	suite.check(camera.acquire_presentation_focus(first, Vector2(300, 290)) and camera.process_mode == Node.PROCESS_MODE_ALWAYS,
			"one presentation may frame the paused world")
	suite.check(not camera.acquire_presentation_focus(second, Vector2.ZERO), "a second presentation cannot steal camera focus")
	camera.release_presentation_focus(second)
	suite.check(camera._presentation_owner != null and camera._presentation_owner.get_ref() == first, "non-owner camera cleanup is harmless")
	camera.release_presentation_focus(first)
	suite.check(camera._presentation_owner == null and camera.process_mode == prior and camera.zoom == zoom,
			"own camera cleanup restores processing and preserves zoom")
	camera.free()
