extends "res://work/st10-handoff/preview.gd"

var _last_action: WorldPropAction
var _acted := false
var _paper_id := 0
var _escape_observed := false
var _wall: StaticBody2D
var _facts_boundary := PackedByteArray()

func _run() -> void:
	await _setup_main()
	if _mode.ends_with("receipt"):
		await _talk_scene("deliver", false)
		_check(GameState.has_flag(&"ch1_disk_delivered"), "receipt setup uses the actual accepted Main delivery")
	var receipt := _mode.ends_with("receipt")
	var player := (_main.get("_screen") as Level).player
	if _mode == "blocked":
		player.global_position = Vector2(260, 320)
		await _frames(5)
		_wall = StaticBody2D.new()
		_wall.collision_layer = Layers.WORLD
		_wall.collision_mask = 0
		_wall.position = Vector2(273, 290)
		var shape := RectangleShape2D.new()
		shape.size = Vector2(2, 60)
		var collision := CollisionShape2D.new()
		collision.shape = shape
		_wall.add_child(collision)
		(_main.get("_screen") as Level).add_child(_wall)
		await get_tree().physics_frame
	_target = &"ch1_t_handoff_receipt" if receipt else &"ch1_t_handoff_accept"
	Story.scene_started.connect(_remember_boundary)
	var result := await _talk_scene("take" if receipt else "deliver", true)
	Story.scene_started.disconnect(_remember_boundary)
	if _mode.begins_with("skip"):
		_check(_acted and _escape_observed and result, "real Escape skips the chosen physical segment and completes its saved result")
		_check(GameState.has_flag(&"ch1_disk_receipt_taken") if receipt else GameState.has_flag(&"ch1_disk_delivered"), "the explicit skipped choice reaches its original authoritative result")
	else:
		_check(not result, "cancelled or blocked physical segment returns without completion")
		_check(not _facts_boundary.is_empty() and _facts_boundary == var_to_bytes([StoryItems.snapshot(),GameState.world_flags,Progression.snapshot(),Story.progress_snapshot()]), "cancelled presentation preserves all item, flag, wallet and completion facts after the actual confirmation")
	if _mode.begins_with("cancel"):
		_check(_acted and _last_action != null and _last_action.done, "the actual in-flight physical action is retired")
		if receipt:
			var fixture := _reaction()
			_check(_paper_id != 0 and fixture._paper_visual.get_instance_id() == _paper_id and fixture.paper_ready(), "cancel returns the exact carried paper to its outlet")
	_check(player._visual.interaction_action == null and not player.interaction.active and not get_tree().paused, "presentation releases its player, input and pause owners")
	var camera := get_viewport().get_camera_2d() as LevelCamera
	_check(camera != null and camera._presentation_owner == null, "presentation releases only its camera focus")
	if _wall != null:
		_check(player.global_position.x < 267, "blocked action never moves the player through its actual collision")
		_wall.queue_free()
		await get_tree().physics_frame
		_check(WorldPropAction.route_clear(player, Vector2(284, 320)), "removing only the owned fixture restores the clear route")
	await _capture(_mode + "-after")
	await _finish()

func _remember_boundary(id: StringName, _kind: StringName) -> void:
	if id == _target:
		_facts_boundary = var_to_bytes([StoryItems.snapshot(),GameState.world_flags,Progression.snapshot(),Story.progress_snapshot()])

func _talk_scene(choice: String, intervene: bool) -> bool:
	var npc := _cabinet()
	var player := (_main.get("_screen") as Level).player
	if _mode != "blocked":
		player.global_position = npc.global_position + Vector2(-16,0)
		await _frames(5)
	var deadline := Time.get_ticks_msec() + 10000
	while (not player.is_on_floor() or absf(player.velocity.y) > 0.1) and Time.get_ticks_msec() < deadline:
		await get_tree().physics_frame
	_check(player.is_on_floor(), "real player has ground support")
	var done := [false,false]
	var talk := func() -> void:
		done[1] = await npc._talk()
		done[0] = true
	talk.call()
	if not intervene:
		await _drive_preview(choice, done)
		return done[0] and done[1]
	deadline = Time.get_ticks_msec() + 180000
	while not done[0] and Time.get_ticks_msec() < deadline:
		var movie := Story._player as CutscenePlayer
		if is_instance_valid(movie) and movie.choice_active():
			var index := movie._choice_options.find_custom(func(option:Dictionary)->bool:return option.get("id")==choice)
			_check(index>=0, "actual choice exists: "+choice)
			if index<0:break
			movie.choose(index)
		elif is_instance_valid(movie) and movie._dialogue.visible:
			movie._dialogue.complete()
			movie._advance_requested=true
		var action := player._visual.interaction_action
		if not _acted and action != null and not action.done and action.phase == ("pull" if choice == "take" else "insert") and action._elapsed > 0.1:
			_acted = true
			_last_action = action
			_paper_id = action.paper_instance
			await _capture(_mode + "-before")
			if _mode.begins_with("skip"):
				var event := InputEventKey.new()
				event.keycode = KEY_ESCAPE
				event.physical_keycode = KEY_ESCAPE
				event.pressed = true
				Input.parse_input_event(event)
				Input.flush_buffered_events()
				_escape_observed = movie.user_skipped
				event.pressed = false
				Input.parse_input_event(event)
			else:
				Story.reset_active_presentation(&"native_cancel")
		await _frames(1)
	_check(done[0], "actual NPC waiter returns within the time budget")
	return done[0] and done[1]

func _reaction() -> PropReaction:
	for node in get_tree().get_nodes_in_group(PropNode.GROUP):
		if node.data.id == &"handoff__commission_cabinet":
			for child in node.get_children():
				if child is PropReaction:return child
	return null
