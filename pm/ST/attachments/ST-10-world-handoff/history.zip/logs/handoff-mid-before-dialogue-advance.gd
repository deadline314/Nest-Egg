extends "res://work/st10-handoff/lifecycle.gd"

func _run() -> void:
	var receipt := _mode.contains("receipt")
	_target = &"ch1_t_handoff_receipt" if receipt else &"ch1_t_handoff_accept"
	if _mode.ends_with("_read"):
		CampaignEdition.override_current(CampaignEdition.current().describe("through-ch1_kasa"))
		Transition.instant = true
		Story.auto_skip = false
		_main = MainScript.new()
		_store = RunSaveStore.new(_directory.path_join("slot.json"))
		_main.set("_run_store",_store)
		add_child(_main)
		await _frames(5)
		var original := _store.read()
		_check(original.get("cinematic") == String(_target), "cold read uses the actual unfinished authored segment written on quit")
		_main.call("_on_continue_requested")
		await _room("res://data/levels/ch1_handoff.tres")
		var level := _main.get("_screen") as Level
		print("MID_COLD_INITIAL ", JSON.stringify({"floor_cache":level.player.is_on_floor(),"position":[level.player.global_position.x,level.player.global_position.y],"velocity":[level.player.velocity.x,level.player.velocity.y]}))
		var deadline := Time.get_ticks_msec()+180000
		while Time.get_ticks_msec()<deadline and not level._resumed_presentation_settled:
			var movie := Story._player as CutscenePlayer
			if is_instance_valid(movie) and movie._dialogue.visible:
				movie._dialogue.complete()
				movie._advance_requested=true
			await _frames(1)
		_check(level._resumed_presentation_settled and level._resumed_presentation_completed, "the same unfinished real cabinet interaction resumes to completion")
		_check(Story.progress_snapshot().has(_target), "cold continuation publishes exactly the chosen original completion")
		_check(StoryItems.holds(&"ch1_delivery_receipt") if receipt else StoryItems.was_transferred(&"ch1_data_disk"), "cold continuation reaches correct item custody")
		_check(_cabinet().talk_count == (2 if receipt else 1), "cold continuation settles the original NPC waiter once")
		await _capture("mid-resumed-"+String(_target))
		await _finish()
		return
	await _setup_main()
	if receipt:
		await _talk_scene("deliver",false)
	var npc := _cabinet()
	var player := (_main.get("_screen") as Level).player
	player.global_position=npc.global_position+Vector2(-16,0)
	await _frames(8)
	_check(player.is_on_floor(), "mid-write starts on real ground")
	var talk := func() -> void: await npc._talk()
	talk.call()
	var deadline := Time.get_ticks_msec()+180000
	while Time.get_ticks_msec()<deadline:
		var movie := Story._player as CutscenePlayer
		if is_instance_valid(movie) and movie.choice_active():
			var choice := "take" if receipt else "deliver"
			var index := movie._choice_options.find_custom(func(option:Dictionary)->bool:return option.get("id")==choice)
			_check(index>=0,"mid-write uses the actual explicit choice")
			if index<0:break
			movie.choose(index)
		var action := player._visual.interaction_action
		if action !=null and not action.done and action.phase == ("pull" if receipt else "contact") and action._elapsed>0.1:
			_check(not GameState.has_flag(&"ch1_disk_receipt_taken") if receipt else not GameState.has_flag(&"ch1_disk_delivered"),"quit during motion has not published its result")
			await _capture("mid-quit-"+String(_target))
			# Main's real quit saves its original whole entry and pending segment.
			await _finish()
			return
		await _frames(1)
	_check(false,"mid-write reaches the real unfinished motion")
	await _finish()
