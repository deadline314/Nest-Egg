# 第二章「鷺」作者關卡候選

ST-19 空間候選，2026-10-10；基準 `6eab4af4b51049296e66f2724aa9c32fd18bc02a`。以已通讀的 [SCRIPT_CH02.md](SCRIPT_CH02.md)／[CH02_SCRIPT_REVIEW.md](CH02_SCRIPT_REVIEW.md) 為來源。這份交付的是全章可重現地形與原生資源候選，不是正式第二章完成、正式任務、真人通關或 Windows 包。

作者來源：[build_ch2_levels.py](../../tools/story/build_ch2_levels.py)。產出：[manifest.json](../../assets_src/chapter2_candidate/manifest.json)、[真實候選地形圖](../../assets_src/chapter2_candidate/layout_atlas.html)。地形圖直接從 Grid 產生，是向量示意，不是遊戲像素截圖。

## 真實 schema 與正式入口界線

`LevelData`／`LevelBuilder` 支援任意 `res://` 的 `.tres` 和分段地圖 JSON；不必把地圖放入正式 `data/levels/`。`SceneAudit`、ResourceCatalog 等會掃正式目錄，故全部候選放 `assets_src/chapter2_candidate/levels/`，全部 id 為 `ch2_campaign_*`。候選沒有 intro、boss、outro、next_level 或自動完成，chapter 為 `ch2_campaign_candidate`，沒有冒用舊 `chapter_02`。

固定 16px 格，腳底格 `[x,y]` 對應 `[(x+0.5)*16,(y+1)*16]`。成人 H=56px 是佈景尺；引擎的玩家碰撞盒較小，不能用碰撞盒把住宅家具縮小。地圖高40格/640px，區域寬依用途調整；沒有靠同一第一章模板拉長道路。住宅／客人簿室淨高96px=1.71H；前室112px=2H。帳房是改造裝卸廳，成人戰區288px=5.14H是明列的雙層挑空例外，後方兒童隔間仍96px=1.71H，地面比成人戰場高192px。門32×72px=0.57H×1.29H。當舖梯子96px到住宅天花板；屋頂另一端是實體樓梯間上的 hidden 門。市場住處入口在公共外梯的上層落腳面，不画一条懸空短梯。

PortalData 只有單一 `requires_flag`；不能表達多條父女安全条件、交易結果或演出阶段。MechanismData 已有普通 switch／gate／lift／encounter；普通 switch 的 channel 不會自動產生故事 flag。SC1 使用真實 switch/gate 候選資源，channel=`ch2_candidate_sc1`；其故事結果 `ch2_sc1_open` 仍需正式結果服務接線。小薇房的牆、天花板與地板是真實 `#` 地形；獨立 actor／投射物層、救護搬送和父女兩路結果還需專用 backend，不能僅靠無敵值假稱兒童隔離驗收。

### 現有第一章出口，不代改別人的來源

| 正式現況 | 實際腳底格 | 銜接責任 |
|---|---|---|
| `ch1_vault` 的 `L`／wh_upper | `[120,8]` | ST-9 要把上層通道串到單一交盤事件；不能在二章重新交同一盤 |
| `ch1_lounge` 的 `G`／lounge_exit | `[52,19]` | 目前仍接宵夜舊路；候選未覆寫 |
| `ch1_stall` 的 `Z`／stall_home | `[44,19]` | 目前仍接 dawn 收尾，由 ST-9 處理付款／欠條／留下與返家 |
| `ch1_street` 的 `m`／street_market | `[186,19]` | 目前無目標的封路；新版查核證放行應由正式章節切換選取二章地圖 |

候選 `lounge.handoff_locker [26,33]` 是未交盤舊檔可回去補驗收的可達目的地契約，S00所有權仍是 ST-9，不生成第二份交盤戲。新一章結尾、二章入口與正式 router 均未改。若 story source／正式地圖選擇還未準備，`--production` 必須拒絕，不新增「先幫你設好旗標」的路由。

## 全章空間圖與阻塞層

```mermaid
flowchart LR
 P[當舖／結算與工作檯] <--> R[屋頂／簡報與章末]
 P <--> S[安全街口]
 S -->|查核證| E[市場入口／B3電話亭]
 S <--> L[復原館外／委託終端]
 L -->|同一查核證，不留後門| E
 E <--> M[茶攤／收據／合約]
 M <--> A[公共外梯／可選小廚房]
 M <--> F[裝卸下路／上層電線橋]
 F -->|SC1從內側開| M
 F <--> D[裝卸間乾燥作業室／代收簿與安全對帳桌]
 D -->|三份公眾證據對帳| T[北棟前室／安全檢查點]
 T <--> O[帳房／兩路制伏／原帳]
 O -->|鷺搬送完成，SC4| E
 L -->|主帳已上傳＋自選進入| G[客人簿室／非戰鬥視角]
 G -->|同一入口快照| L
 L -->|步行原路| S
 R -.->|章末指示，仍未開第三章| C[廣場貨梯／次日]
```

| 層 | 生產時點／通路 | 保留與拒絕 |
|---|---|---|
| 初始／缺交盤回退 | 當舖、屋頂、街口、館外交接櫃都可達 | 不憑空設已交盤；館外市場出口也讀 `ch2_brief_done`，測試已抓過這條後門 |
| S03查核證 | 街口與館外皆只放行公眾市場；證不消耗 | 不開夾層，不用阿梨地址當門檻 |
| S06–10調查 | 合約、收據、代收簿有不同實際來源；C在裝卸間乾燥作業室，可由上層繞戰入室取 | 入室門不讀對帳flag；私人D、付40、拜訪、榕伯故事都不是必要證據 |
| S10公眾對帳 | `ch2_market_reconciled` 開北棟前室門 | 沒有付費鑰匙，不靠私人帳或支線完成 |
| S12–13兩路結果 | 專用backend制伏→取帳→搬送開SC4 | 候選沒有阿勇替身與自動帳櫃獎勵；cut/keep都不是HP0即活著完成 |
| S15主帳上傳 | `ch2_audit_submitted` 公開客人簿選項；原步行路回屋頂 | 客人簿是可略事件，不能用可進门代表已切阿梨非戰鬥控制 |
| S22章末 | 真結果需S14返回＋S15上傳；歩行路已通版本 | 候選不寫完成、不跳舊level_03、不假畫快速傳送；屋頂可提前回訪但不提前結案 |

CPU狀態連通檢查確認：無任何 `knows_ali_address`／`sq*`／`guest_*` 作主線通路鑰匙。正式生產者、物品、任務公開與交易屬故事owner，manifest的 anchors 是地點契約，不是第二份 quests 真相。

## 各區形状、用途與節奏

| 候選尾名／尺寸 | 實際路線與安全段 | 體驗用途 |
|---|---|---|
| pawnshop／1312×640 | 室內櫃台→工作檯→靠牆樓梯 | 次晨低谷，修收音機可選；沒有第一章重新教七張告示牌 |
| rooftop／1600×640 | 樓梯間→茶桌接近→天線遠望 | S03／S04／S22共用地標，提前回訪不自動收束 |
| street／1952×640 | 當舖—公用候車段—館外路口—市場查核口 | 全段安全；廣場貨梯只有清楚閉路理由 |
| market_entry／2272×640 | 入口安全47格→96px防火隔板→兩場下路／雨棚上路→第二隔板→市場口 | 隔板两侧64px雨棚踏面可双向跳入，真WORLD碰撞擋自然巡邏与直射；B3與快速交通用途分開，鷺返回不更新凜檢查點；上層箱是待故事／物品owner鎖定SC1取用的20點節點 |
| market／2208×640 | 茶攤—代收—合約—公共外梯上層落腳—貨道 | 三條證據目的地可任意順序；外梯12個碰撞踏面每次升1格，正式階梯圖要畫5–7px子階，不把16px碰撞節點畫成一大級 |
| freight／2784×640 | 下層兩場→乾燥作業室門；上層已斷電電線橋迴圈→SC1 | 入口身份與裝卸機具分工不同；本圖沒有安全末段聲稱，飛行維修機可跟隨；搬箱為待backend情境動作；上層乾燥盒20點不鎖主線 |
| dry_room／1312×640 | 裝卸門→代收簿→檢查點→乾燥桌／紙箱架→北棟門 | 獨立無敵人Level隔開巡邏與飛行敵人；可先取C再對帳，未對帳時原門仍可返回找缺證據 |
| ali_home／1152×640 | 敲門→碗架工作段→湯鍋，兩門回同公共外梯 | 地址取得与洗碗獎分開；不探索床／衣櫃，主人可拒絕 |
| antechamber／1248×640 | 貨門→檢查點→同款隔離／鎖扣圖→入戰確認門 | 防火門隔開休息與戰場，不在重試點放攻擊者 |
| office／2048×640 | 左入口→低／中／高躲棍平台→主箱→側箱→帳櫃→家屬門 | 戰場右後有物理封閉的兒童隔間；兩側箱不同用途；沒有路跳進她的座位，也沒把她當敵人資源 |
| lounge／1888×640 | 舊檔交盤櫃→公眾委託終端→私人帳桌→客人簿門 | 四種功能有不同位置，不讓原盤又出現；館外低谷可自由回家 |
| guestbook／1568×640 | 門邊入口→窗桌鄭→中桌陳→門邊桌洪→收本 | 純非戰鬥、三客可分段保存；錯回應回筆記，不發死亡或商店薪資 |

安全區沒有硬塞每分鐘戰鬥數；開放遭遇只有入口兩場與裝卸两场，符合新版劇本而非舊每區固定鎖場模板。主路34–41分、全支線49–60分仍只是劇本估計；地圖步行距離、NPC閱讀、對帳与阿勇專用戰的實際耗時還沒有測量。

## S00–S22真實腳底位置

所有 `.tres` 路徑都是 `res://assets_src/chapter2_candidate/levels/ch2_campaign_<尾名>.tres`。以下不是正式QuestCatalog；故事編譯器應從 manifest 讀位置，不能手抄第二份任務資料。

| 場 | 地圖／錨點／腳底格 | 空間上的結果與回訪 |
|---|---|---|
| S00 | lounge／handoff_locker `[26,33]` | 只有單一跨章交盤來源或舊檔補驗收；不二發交易 |
| S01 | pawnshop／settlement `[25,29]` | 櫃台核800−80，重訪只讀原交易 |
| S02 | pawnshop／radio_bench `[48,29]` | 真收音機放工作檯上；調頻／聽清需正式情境動作 |
| S03 | rooftop／tea_brief `[37,31]` | 拿證後市場放行；提前回屋頂可再問 |
| S04 | 同tea_brief `[37,31]` | 自選週日追問，无主線門檻 |
| S05 | market_entry／entry_pass `[16,33]` | 入口看B3與公共攤道；可以選低／高路 |
| S06 | market／collection_contact `[35,33]` | 欠款社交在無戰鬥段，不誤射替玩家付40 |
| S07 | ali_home／knock `[15,29]`、wash_bowls `[35,29]`、taste_soup `[49,29]` | 公共外梯不用已知地址；主人回應才記知情 |
| S08 | market／receipt `[37,33]`、contract `[61,33]`；dry_room／collection_book `[20,29]` | 三物來源分清，C仍屬H12c裝卸區；榕伯 `[23,33]` 和演說 `[109,33]` 可略，廣播不遮幅 |
| S09 | freight／cut_wire `[70,21]`、breathing_guard `[91,33]`、sc1_lever `[42,21]`、wet_box `[113,33]` | 守衛還活、灰衣人未指名；橋開与搬箱backend分開 |
| S10 | dry_room／dry_table `[43,29]` | 安全桌與末段檢查點 `[26,29]` 同獨立空間；缺哪張紙指回哪個真位置；北棟門 `[70,29]` 只讀真對帳結果 |
| S11 | antechamber／isolation_diagram `[44,29]`；office／battle_start `[28,33]` | 先看設備与孩子，确认才戰；只標intro seen不制伏 |
| S12 | office／yong_arena `[59,33]`、main_isolation `[77,33]`、side_isolation `[94,33]` | 三個可達操作段，子女安全座位 `[109,21]` 是不可達保護空間，不作任務攻擊目標 |
| S13 | office／original_ledger `[105,33]`、transport `[113,33]` | 帳櫃與搬送分開結果；右門後SC4回入口 |
| S14 | market_entry／egret_return `[39,33]` | 電話亭旁暖休息帶，213→214只一次，角色事件非凜死亡 |
| S15 | lounge／audit_terminal `[47,33]` | 三證據掃描與診所索引，位置不同於交盤櫃 |
| S16 | lounge／private_ledger `[63,33]` | 阿梨自己的私人帳桌，不擋回屋頂 |
| S17 | lounge／guestbook_choice `[81,33]` | 可选進夜班，不自动切控制與知識 |
| S18 | guestbook／zheng_table `[29,29]` | 窗桌，問／聽／記，不複製客人身份為敵人 |
| S19 | guestbook／chen_table `[50,29]` | 中桌，端湯選忌諱，翻帽取得同意 |
| S20 | guestbook／hong_table `[72,29]` | 門桌，留返回和聽完空間 |
| S21 | guestbook／close_book `[86,29]` | 明確收本位置，回凜H10原入口快照 |
| S22 | rooftop／chapter_close `[44,31]` | 同一路返家與茶座，雙前置後提交；次章只顯示貨梯方向 |

## 敵人與資源核對

完整资源路径与SHA256见manifest的 `enemy_inventory`。第一章的資源ID交集和骨架身份交集分開驗；本候選僅兩個正式ID跨章重用，這兩種都使用同一 enforcer 美術身份，不能把槍／盾換裝算新敵。新增的兩種身份都有既有專用動畫／貼圖定義。

| 候選用途 | 正式資源／真實美術 | 採用理由与界線 |
|---|---|---|
| 入口近戰／遠程 | collector_brute／collector_gunner；`art/rigs/enforcer.json` | 市場封路收帳身份合理；兩場可繞，不貫穿所有地點 |
| 裝卸近身與支援 | slasher；`art/rigs/slasher.json`；repair_drone；`art/creatures/repair_drone.json` | 舊第二關有完整正式資源，匹配裝卸器械／維修支援；不重新命名或改skin假造押運者 |
| 阿勇本人 | 無正式專用EnemyData，尚未adopt | 舊reclaimer／custodian沒有父女讀取与帶電卸匣行為，不當替身；戰場有真幾何，主線結果沒有假實作 |
| 鷺守側門兩名押運手 | manifest只留 `[94,33]`／`[100,33]` 空間 | 尚未spawn，避免現有AI射入兒童房或越過鷺；需要獨立actor隔離再採正式收帳身份 |

四場共8隻，沒有增援或鎖場。现有資料 credit_value 的上限總和104，選高路可全部略過，故普通敵收入範圍0–104；不是劇本估計40–80的驗收，NE-231需校正選路收入。沒有把探索40與boss120／主線250混入普通敵掉落；候選沒有生成金錢pickup／帳冊／湯，避免獎勵在故事backend前失控。前後本候選功能告示牌=0、環境文字招牌字元=0；必要資訊在真角色／物件操作錨點与正式任務来源，不再砌七張教學牌。

裝卸兩組維修機與切割者初始相距160px，而不是僅勉強落在220px支援半徑內。維修機首次掃描前有1秒cooldown；切割者44px/s往左巡邏，保守加一個60Hz影格与5px懸浮仍約205px，第一次正常巡邏掃描可在半徑內。CPU核這條距離界線，玩家誘導／實際支援動畫與低幀率仍需原生測試。

獨立CPU審查抓到初版只有safe_zones metadata而連續地板會讓收帳人巡入B3；現已加第48／124欄真實#隔板（row28–33，高96px）及兩侧双向踏面。不是改note假稱活動邊界：既有Enemy巡邏碰WORLD牆折返，現有collector_shot不穿牆／無重力／無爆炸，正常槍手視線与射彈受同一牆擋。打手采用Slasher的210px/s躍起速度与專案900重力，連續理論最高24.5px，加首個60Hz影格3.5px仍低於64px踏面及96px墙；普通攻擊无法登上战区第一踏面再翻墙。證明只涵蓋正常巡邏／攻擊，原生低幀率、刻意連續擊飛、外力與異常spawn還须真物理測試，沒有據這條公式勾原生安全驗收。

同一審查也抓到裝卸間連續地板不能保證S10安全，尤其維修機會飛。現把代收簿、S10桌、乾燥架與末段檢查點移至真正獨立的裝卸間乾燥作業室Level；入室不要求對帳結果，對帳後才開往前室的門。`Main._swap_screen` 先remove_child舊Level、queue_free再add_child新Level，舊敵人離開SceneTree；`Level`為新區綁定projectiles時，`ProjectilePool.bind_container`先重設free/container，新子彈只掛新容器，舊tree_exit也核對容器身份。這是現有跨Level隔離的來源依據，仍須原生轉場驗證敵人／子彈沒有跟入，不冒稱已實際穿門測試。

道具只從現有 PropData 讀尺寸和真貼圖；每件真path都驗存在。radio_set底邊在arms_workbench頂面，支撐鏈為 `support=prop`；所有站地物給真底邊格、不任意放allow_overlap。客人簿用專用guest_book_table；帳房用yong_hideout保險櫃与高臺玩偶。沒採小薇床／公仔遮住人物，也不把玩偶當孩子actor。尚缺專用隔離箱，控制台只是標示操作區域的現有道具，正式箱體不能据此勾美術完成。

## 給主 Session 的真素材與接線隊列

| 缺口 | 世界尺寸、接觸／用途 | 交付需求 |
|---|---|---|
| 阿勇本人與專用棍／裝甲／匣 | 成人H56，建議碰撞24×56px；棍長48px、握持接觸；裝甲匣在胸前固定槽，斷電可取 | 專用透明立繪、分件與補底、蓄棍／落空／後補棍／棍鎖破損／拔匣／非致命固定／第二殼袖口与手顫，沿正式角色pipeline；不生成新ID套舊skin |
| 主隔離箱／維修側箱 | 主箱22×22px≈0.4H，牆裝中心高28px≈0.5H，機器白線→灰線；側箱22×18px，帶電護板／脫落蓋两狀態 | 少文字、圖形識別永久解除／暫停；安裝於實際帳房後牆，不裸浮於空氣；功能结果先backend |
| 小薇安全椅／腳踏／封閉隔間 | 兒童H待角色owner實測；家俱沿成人尺度，座面約15px、腳踏依她腿長；房96px淨高，地板352px | 認知與黃傘分支、腳底/椅座接觸，防止 projectile/actor穿界；與現有角色修復票分工，不另改骨架 |
| 公共後樓外梯／雨棚支架／橋梯 | 外梯192px爬升、12個16px碰撞踏面，用5–7px視覺子階；雨棚連梁與欄杆高28–35px；橋格16px模組 | 原始來源格與支撐線对齐，無額外碰撞超出LevelData；需要原生图核，而非當作地圖图解已批准 |
| 掃描委託終端／交盤櫃兩種用途 | 交盤櫃約50px高=0.9H、開口31px；掃描檯24px桌面或既有控制台 | 物品持有与一次回執一致，盤只有一片；不重用交盤圖暗示S15再交盘 |
| 碗架／湯鍋／端湯 | 碗約4px、杯3.4px；工作桌24px高、家具接觸線固定 | 實際道具与操作动画，已有kettle_stove只是區域參照，不冒稱洗碗動畫已會 |

既有老 K、凜、鷺、阿梨、燈及配角人物沿既有owner素材；缺電影／新情境動作交 ST-10／各章結果服务責任，不在這份候選复制现有NPC `.tres`，避免觸發第一章台詞。完整音效需求沿S00–S22劇本，這次沒有生成／改聲音，也沒有開始ComfyUI。

## 重現、檢查與交接

```powershell
python tools/story/build_ch2_levels.py
python tools/story/build_ch2_levels.py --check
python -m unittest discover -s tools/story -p test_ch2_levels.py -v
# 必須失敗（exit 2），不修改正式資料：
python tools/story/build_ch2_levels.py --production
```

CPU檢查涵蓋23場腳底、全部portals落點／反向target、分段寬高、符號／真资源路径、工作檯支撐、敵人兩種跨章上限、隔間不可達、支線不鎖主路、失去地板／過高牆／過寬坑的拒絕、候選逐byte重現及production拒絕。失敗測試確實抓过館外查核後門，再修来源与重產。物理路徑使用保守上4／橫6格與4格淨空；不代替正式SceneAudit或真人操控。

主 Session 分配共享GPU后可用獨立probe，不改runner或registry：

```powershell
# 原生解析、资源validate、SceneAudit全12張与link；count讀manifest，任何warn/error都失败
godot --headless --path . res://tools/story/ch2_layout_probe.tscn
# Forward+真像素预览：獨立profile，退出後還原原環境
$ch2PreviewProfile = 'C:/tmp/ch2-native-preview-profile'
$ch2OldAppData = $env:APPDATA
$ch2OldLocalData = $env:LOCALAPPDATA
$ch2OldProfile = $env:CH2_PROFILE
New-Item -ItemType Directory -Force -Path $ch2PreviewProfile | Out-Null
try {
    $env:APPDATA = $ch2PreviewProfile
    $env:LOCALAPPDATA = $ch2PreviewProfile
    $env:CH2_PROFILE = $ch2PreviewProfile
    godot --rendering-method forward_plus --path . res://tools/story/ch2_layout_probe.tscn -- --preview=dry_room --cell=43,29 --out=C:/tmp/ch2-dry-room.png
    godot --rendering-method forward_plus --path . res://tools/story/ch2_layout_probe.tscn -- --preview=office --cell=59,33 --out=C:/tmp/ch2-office.png
} finally {
    $env:APPDATA = $ch2OldAppData
    $env:LOCALAPPDATA = $ch2OldLocalData
    $env:CH2_PROFILE = $ch2OldProfile
}
```

probe預覽要求absolute CH2_PROFILE，且actual OS.user_data_dir確實在該root內；absolute輸出路徑、非headless Forward+亦必須通過，才執行新run。warmup前關閉GameState.story_autosave。普通headless audit不做新run，仍是唯讀資源檢查。probe使用已有ViewportCapture的HDR线性→sRGB；此代理只做CPU／Gdparse，未启引擎、未占GPU、未生成原生画面。正式受影响引擎套件、手把、音訊、劇情skip/death/resume矩陣、SC1取箱時機、帳房演員安全与章末包仍由主 Session驗收。新增候选无正式quests，票不能据此改完成。

獨立probe只預覽指定Level，未連接area_requested至Main，不是全區穿門runner。正式Main._save_destination目前以`res://data/levels/`白名單核目標，候選assets_src路徑會拒絕；所以全區候選不能直接當正式router採用。現有跨Level清理來源核對與真portal連通圖，不能替代安全profile下原生轉場／讀檔測試。production仍明確拒絕；正式接線由主Session与故事owner做。
