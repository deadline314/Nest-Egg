"""CPU contracts for the authored spatial candidate; no gameplay completion claim."""
import copy
import json
from pathlib import Path
import re
import subprocess
import sys
import unittest

import build_ch2_levels as ch2


def connected(areas, flags, start="pawnshop"):
    visited={start}
    pending=[start]
    while pending:
        for portal in areas[pending.pop()].portals:
            target=portal["to"]
            if target and target not in visited and (not portal["requires"] or portal["requires"] in flags):
                visited.add(target)
                pending.append(target)
    return visited


class Chapter2LevelsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.areas=ch2.authored_areas()
        cls.files,cls.manifest=ch2.generate()

    def test_all_twenty_three_scenes_have_real_foot_cells(self):
        self.assertEqual([],ch2.validate(self.areas))
        covered={s for a in self.areas.values() for anchor in a.anchors for s in anchor["scenes"]}
        self.assertEqual({f"S{i:02}" for i in range(23)},covered)
        for area in self.areas.values():
            reachable=ch2.reachable(area.grid,[5,area.ground-1])
            for anchor in area.anchors:
                self.assertIn(tuple(anchor["cell"]),reachable,anchor["id"])

    def test_gate_progression_keeps_home_optional_and_evidence_accessible(self):
        initial=connected(self.areas,set())
        self.assertIn("rooftop",initial)
        self.assertIn("lounge",initial)  # actual recovery destination for missing CH01 delivery
        self.assertNotIn("market_entry",initial)
        brief=connected(self.areas,{"ch2_brief_done"})
        self.assertTrue({"market","freight","dry_room","ali_home"}<=brief)
        self.assertNotIn("office",brief)
        reconciled=connected(self.areas,{"ch2_brief_done","ch2_market_reconciled"})
        self.assertIn("office",reconciled)
        self.assertNotIn("guestbook",reconciled)
        complete=connected(self.areas,{"ch2_brief_done","ch2_market_reconciled","ch2_audit_submitted"})
        self.assertEqual(set(self.areas),complete)
        flags={p["requires"] for a in self.areas.values() for p in a.portals}
        self.assertNotIn("knows_ali_address",flags)
        self.assertFalse(any(f.startswith("sq") or f.startswith("guest_") for f in flags))

    def test_each_portal_lands_on_clear_supported_reciprocal_foot_cell(self):
        for area in self.areas.values():
            for p in area.portals:
                self.assertGreaterEqual(p["height"],72)
                if p["to"]:
                    target=next(q for q in self.areas[p["to"]].portals if q["id"]==p["target"])
                    self.assertEqual(area.ident,target["to"])
                    self.assertIn(tuple(target["cell"]),ch2.walkable(self.areas[p["to"]].grid))

    def test_native_format_resources_all_exist_and_refer_to_candidate_only(self):
        generated=set(self.files)
        for rel,text in self.files.items():
            if rel.endswith(".tres"):
                for path in re.findall(r'(?:path|interior|layout_path) = "res://([^"]+)"',text):
                    if path.startswith("assets_src/chapter2_candidate/"):
                        self.assertIn(path.removeprefix("assets_src/chapter2_candidate/"),generated)
                    else:
                        self.assertTrue((ch2.ROOT/path).is_file(),path)
                for target in re.findall(r'target_level = "([^"]+)"',text):
                    self.assertTrue(target.startswith(ch2.RES),target)
                self.assertNotIn('intro_scene =',text)
                self.assertNotIn('complete_after_intro = true',text)

    def test_candidate_map_segments_match_level_height_without_reserved_collisions(self):
        for area in self.areas.values():
            raw=json.loads(self.files[f"levels/ch2_campaign_{area.ident}_map.json"])
            self.assertTrue(all(len(seg)==40 for seg in raw["segments"]))
            rows=["".join(seg[y] for seg in raw["segments"]) for y in range(40)]
            self.assertTrue(all(len(row)==area.width for row in rows))
            self.assertEqual(1,sum(row.count("P") for row in rows))
            allowed=set("#.PC=")|set(ch2.ENEMIES)|{p["char"] for p in area.portals}|set(area.mechanisms)
            self.assertEqual(set(),set("".join(rows))-allowed)
            self.assertFalse(any(c in "123456789&" for row in rows for c in row))

    def test_does_not_substitute_existing_boss_or_child_as_damage_target(self):
        office=self.areas["office"]
        child=office.protected[0]["actor_cell"]
        self.assertNotIn(tuple(child),ch2.reachable(office.grid,[5,33]))
        self.assertFalse(office.encounters)
        self.assertTrue(office.extras["boss_requirement"]["not_adopted"])
        self.assertIsNone(office.extras["boss_requirement"]["stand_in"])
        self.assertFalse(any(c=="B" for row in office.grid.rows() for c in row))
        self.assertEqual([],self.areas["guestbook"].encounters)

    def test_open_encounters_use_verified_distinct_art_and_two_max_shared_ids(self):
        inventory=self.manifest["enemy_inventory"]
        self.assertEqual(8,inventory["spawn_count"])
        self.assertLessEqual(len(inventory["ch1_shared_ids"]),2)
        self.assertLessEqual(len(inventory["ch1_shared_art_identities"]),2)
        self.assertEqual({"enforcer","slasher","repair_drone"}, {e["skin"] for e in inventory["resources"].values()})
        self.assertEqual(4,sum(len(a.encounters) for a in self.areas.values()))
        self.assertTrue(all(not e["lock"] and e["bypass"] for a in self.areas.values() for e in a.encounters))

    def test_entry_safe_bands_have_world_collision_and_bidirectional_player_access(self):
        entry=self.areas["market_entry"]
        physics=(ch2.ROOT/"project.godot").read_text(encoding="utf-8")
        gravity=float(re.search(r'2d/default_gravity=([0-9.]+)',physics)[1])
        behavior=(ch2.ROOT/"game/enemies/slasher.gd").read_text(encoding="utf-8")
        jump=float(re.search(r'const LEAP_VELOCITY := ([0-9.]+)',behavior)[1])
        self.assertGreater(64,jump**2/(2*gravity)+jump/60)  # first-frame allowance
        for x in (48,124):
            self.assertTrue(all(entry.grid.at(x,y)=="#" for y in range(28,34)))
            self.assertEqual("#",entry.grid.at(x,32))  # floor-to-floor hostile muzzle rays
        for start in ([39,33],[128,33]):
            seen=ch2.reachable(entry.grid,start)
            self.assertIn((39,33),seen)
            self.assertIn((128,33),seen)
            self.assertIn((70,33),seen)
        # Ground patrol cannot cross either WORLD wall. Native movement/swept
        # projectiles and artificial repeated knockback remain root's QA.
        at_floor={(x,33) for x in range(1,entry.width-1) if entry.grid.at(x,33)!="#"}
        seen={(62,33)}
        queue=[(62,33)]
        while queue:
            x,y=queue.pop()
            for nx in (x-1,x+1):
                p=(nx,y)
                if p in at_floor and p not in seen:
                    seen.add(p)
                    queue.append(p)
        self.assertNotIn((39,33),seen)
        self.assertNotIn((128,33),seen)

    def test_evidence_and_reconciliation_are_in_an_enemy_free_separate_level(self):
        room=self.areas["dry_room"]
        self.assertFalse(room.encounters)
        self.assertTrue(room.checkpoints)
        self.assertEqual({"S08","S10"},{s for a in room.anchors for s in a["scenes"]})
        freight=self.areas["freight"]
        door=next(p for p in freight.portals if p["to"]=="dry_room")
        self.assertEqual("",door["requires"])
        self.assertNotIn("antechamber",{p["to"] for p in freight.portals})
        exit_gate=next(p for p in room.portals if p["to"]=="antechamber")
        self.assertEqual("ch2_market_reconciled",exit_gate["requires"])
        self.assertFalse(any(a["id"] in {"dry_table","collection_book"} for a in freight.anchors))
        support=(ch2.ROOT/"data/enemies/repair_drone.tres").read_text(encoding="utf-8")
        radius=float(re.search(r'^ability_radius = ([0-9.]+)',support,re.M)[1])
        behavior=(ch2.ROOT/"game/enemies/repair_drone.gd").read_text(encoding="utf-8")
        cooldown=float(re.search(r'^var _cooldown := ([0-9.]+)',behavior,re.M)[1])
        slasher=(ch2.ROOT/"data/enemies/slasher.tres").read_text(encoding="utf-8")
        patrol_speed=float(re.search(r'^move_speed = ([0-9.]+)',slasher,re.M)[1])
        for encounter in freight.encounters:
            melee,drone=encounter["members"]
            dx,dy=(a-b for a,b in zip(melee["cell"],drone["cell"]))
            self.assertLess((dx*dx+dy*dy)**.5*ch2.TILE,radius)
            # Idle support has a one-second initial cooldown. Bound patrol away
            # from the hovering drone through one extra 60Hz frame and 5px sway.
            delayed_dx=abs(dx)*ch2.TILE+patrol_speed*(cooldown+1/60)
            self.assertLess((delayed_dx**2+(abs(dy)*ch2.TILE+5)**2)**.5,radius)

    def test_geometry_rejects_missing_floor_tall_wall_and_impossible_jump(self):
        grid=ch2.Grid(60,40)
        grid.fill(0,59,34,39,"#")
        self.assertIn((50,33),ch2.reachable(grid,[5,33]))
        grid.fill(20,34,34,39,".")
        self.assertNotIn((50,33),ch2.reachable(grid,[5,33]))
        grid.fill(20,34,34,39,"#")
        grid.fill(20,22,0,39,"#")
        self.assertNotIn((50,33),ch2.reachable(grid,[5,33]))
        broken=copy.deepcopy(self.areas)
        x,y=broken["lounge"].anchors[0]["cell"]
        broken["lounge"].grid.fill(x-4,x+4,y+1,39,".")
        self.assertTrue(any("handoff_locker: unreachable" in p for p in ch2.validate(broken)))

    def test_production_refuses_even_with_candidates_present_and_preserves_live_data(self):
        live=ch2.ROOT/"data/levels/level_02.tres"
        before=live.read_bytes()
        result=subprocess.run([sys.executable,str(ch2.ROOT/"tools/story/build_ch2_levels.py"),"--production"],capture_output=True,text=True)
        self.assertEqual(2,result.returncode)
        self.assertIn("Production is unavailable",result.stderr)
        self.assertEqual(before,live.read_bytes())

    def test_outputs_are_byte_reproducible_and_check_reads_without_mutation(self):
        other,_=ch2.generate()
        self.assertEqual(self.files,other)
        for rel,text in self.files.items():
            self.assertEqual(text.encode("utf-8"),(ch2.DEST/rel).read_bytes(),rel)
        self.assertEqual(0,ch2.main(["--check"]))


if __name__=="__main__":
    unittest.main()
