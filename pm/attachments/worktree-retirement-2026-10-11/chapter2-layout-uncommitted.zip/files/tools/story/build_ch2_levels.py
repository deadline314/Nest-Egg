#!/usr/bin/env python3
"""ST-19 authored CH02 spatial candidate. Never installs into the live catalog.

python tools/story/build_ch2_levels.py [--check]
The generated .tres are real LevelData/PortalData/MechanismData; narrative
anchors are a compiler input contract, not quests or completed story events.
"""
from __future__ import annotations

import argparse
from collections import deque
from dataclasses import dataclass, field
import hashlib
import html
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools/level"))
from level_kit import Grid  # noqa: E402

DEST = ROOT / "assets_src/chapter2_candidate"
RES = "res://assets_src/chapter2_candidate"
TILE, H, HEIGHT = 16, 56, 40
ENEMIES = {"g": "collector_gunner", "b": "collector_brute",
           "s": "slasher", "d": "repair_drone"}
BLOCKERS = (
    "ch1_delivery_receipt_and_once_only_settlement",
    "ch2_evidence_reconciliation_and_persistent_results",
    "yong_nonlethal_power_lock_and_cut_keep_phase_resume",
    "child_projectile_and_actor_isolation",
    "egret_actor_only_revival_213_to_214",
    "ali_guestbook_noncombat_actor_handoff_and_resume",
    "formal_story_quests_from_single_story_source",
    "chapter_complete_save_and_release_boundary",
    "native_scene_audit_and_full_gamepad_playthrough",
    "yong_original_art_animation_audio_and_combat_resource",
)


def quote(value):
    return json.dumps(value, ensure_ascii=False)


def resource_path(ident):
    return f"{RES}/levels/ch2_campaign_{ident}.tres"


@dataclass
class Area:
    ident: str
    name: str
    width: int
    ground: int
    purpose: str
    color: str
    material: str = "asphalt"
    ceiling: int = 0
    grid: Grid = field(init=False)
    portals: list = field(default_factory=list)
    anchors: list = field(default_factory=list)
    props: list = field(default_factory=list)
    encounters: list = field(default_factory=list)
    mechanisms: dict = field(default_factory=dict)
    checkpoints: list = field(default_factory=list)
    routes: list = field(default_factory=list)
    protected: list = field(default_factory=list)
    extras: dict = field(default_factory=dict)

    def __post_init__(self):
        self.grid = Grid(self.width, HEIGHT)
        self.grid.fill(0, 0, 0, HEIGHT - 1, "#")
        self.grid.fill(self.width - 1, self.width - 1, 0, HEIGHT - 1, "#")
        self.grid.fill(1, self.width - 2, self.ground, HEIGHT - 1, "#")
        if self.ceiling:
            self.grid.fill(1, self.width - 2, 0, self.ceiling - 1, "#")
        self.put(5, self.ground - 1, "P")

    def put(self, x, y, char):
        if self.grid.at(x, y) != ".":
            raise ValueError(f"{self.ident}[{x},{y}]: cannot place {char} over {self.grid.at(x,y)}")
        self.grid.put(x, y, char)

    def platform(self, x0, x1, row):
        self.grid.fill(x0, x1, row, row, "=")

    def prop(self, ident, x, row=None, **support):
        entry = {"id": ident, "x": x, "y": self.ground - 1 if row is None else row}
        entry.update(support)
        self.props.append(entry)

    def anchor(self, key, x, scenes, *, row=None, objective="", optional=False, **extra):
        self.anchors.append({"id": key, "cell": [x, self.ground - 1 if row is None else row],
                             "scenes": scenes, "objective": objective, "optional": optional, **extra})

    def checkpoint(self, x, row=None):
        cell = [x, self.ground - 1 if row is None else row]
        self.put(*cell, "C")
        self.checkpoints.append(cell)

    def encounter(self, ident, members, *, bypass, note):
        cells = []
        for x, char, row in members:
            self.put(x, row, char)
            cells.append({"enemy": ENEMIES[char], "cell": [x, row]})
        self.encounters.append({"id": ident, "members": cells, "bypass": bypass,
                                "lock": False, "note": note})

    def portal(self, char, ident, x, to, target, *, row=None, requires="", reason="", style="door", height=72):
        cell = [x, self.ground - 1 if row is None else row]
        self.put(*cell, char)
        self.portals.append({"char": char, "id": ident, "cell": cell, "to": to, "target": target,
                             "requires": requires, "reason": reason, "style": style,
                             "width": 32, "height": height})


def authored_areas():
    a = {s[0]: Area(*s) for s in (
        ("pawnshop", "當舖與工作檯", 82, 30, "次晨結算、修理與可选成長", "暖琥珀", "concrete", 24),
        ("rooftop", "當舖屋頂茶座", 100, 32, "簡報、私人界線與章末收束", "雨青與茶暖"),
        ("street", "當舖街口", 122, 34, "安全步行返家與下一章方向", "低飽和藍"),
        ("market_entry", "市場入口與市集電話亭", 142, 34, "放行範圍、兩場可繞開遭遇、鷺返回", "青雨棚"),
        ("market", "茶攤與代收攤道", 138, 34, "三證據樞紐、社交衝突与後樓入口", "暗綠與茶黃"),
        ("freight", "雨棚背面與裝卸間", 174, 34, "高低路、搬箱、兩場開放遭遇", "濕鐵藍", "old_metal"),
        ("ali_home", "後樓三樓小廚房", 72, 30, "主人同意後洗碗試湯、地址補救", "淺暖黃", "concrete", 24),
        ("antechamber", "北棟二樓前室", 78, 30, "安全重試點、裝甲鎖扣示範与入場確認", "灰青", "facility_floor", 23),
        ("office", "北棟帳房與家屬出口", 128, 34, "阿勇兩路戰的物理舞台与搬送路", "低彩鐵灰", "steel_plate", 16),
        ("lounge", "復原館外與委託終端", 118, 34, "補交盤介面、主帳上傳与私人帳可選交付", "青終端與暖桌"),
        ("guestbook", "復原館客人簿室", 98, 30, "三位成年客人的非戰鬥工作", "暗琥珀", "concrete", 24),
        ("dry_room", "裝卸間乾燥作業室", 82, 30, "安全取代收簿、乾燥紙箱與三證據對帳", "乾紙暖光", "concrete", 24),
    )}
    p, r, st, en, m, f, home, pre, office, lounge, guest, dry = a.values()
    p.anchor("settlement", 25, ["S01"], objective="核對昨晚的委託報酬。")
    p.anchor("radio_bench", 48, ["S02"], objective="修好收音機並聽清廣播。", optional=True)
    p.prop("pawnshop_front__counter_register", 29)
    p.prop("pawnshop_front__arms_workbench", 46)
    p.prop("radio_set", 47, support="prop", support_id="pawnshop_front__arms_workbench", support_x=46, dy=-31.5)
    p.portal("F", "pawn_front", 10, "street", "street_home")
    p.portal("T", "pawn_stairs", 72, "rooftop", "roof_stairs", style="ladder", height=96)
    r.portal("T", "roof_stairs", 10, "pawnshop", "pawn_stairs", style="hidden")
    r.prop("rooftop_hut", 7)
    r.prop("bench", 39)
    r.prop("antenna", 78)
    r.anchor("tea_brief", 37, ["S03", "S04"], objective="與鷺核對查帳目標並拿查核證。")
    r.anchor("chapter_close", 44, ["S22"], objective="確認明天去夾層診所核對原表。", requires_flags=["ch2_egret_returned", "ch2_audit_submitted"])
    r.routes.append({"id": "tea_approach", "from": [10,31], "to": [44,31], "use": "安全且可退回的接近預告；沒有自動完成。"})
    st.portal("F", "street_home", 12, "pawnshop", "pawn_front")
    st.portal("M", "street_market", 106, "market_entry", "market_street", requires="ch2_brief_done", reason="先回當舖屋頂，向鷺拿市場查核證。", style="road")
    st.portal("L", "street_lounge", 62, "lounge", "lounge_street", style="road")
    st.portal("N", "clinic_direction", 116, "", "", reason="明天從廣場貨梯去夾層診所；先完成今天的查帳。", style="road")
    st.checkpoint(25)
    st.prop("bus_stop", 30)
    st.prop("bench", 45)
    en.portal("S", "market_street", 10, "street", "street_market", style="road")
    en.portal("M", "entry_market", 128, "market", "market_entry", style="road")
    en.portal("L", "entry_lounge", 27, "lounge", "lounge_market", style="road")
    en.portal("Q", "entry_family", 112, "office", "office_family", requires="ch2_egret_transport_done", reason="家屬門還由帳房鎖住，先去北棟二樓處理阿勇。")
    en.checkpoint(32)
    en.prop("anchor_phone_booth__phone_booth", 36)
    en.prop("bench", 44)
    en.anchor("entry_pass", 16, ["S05"], objective="出示查核證，走公眾攤道。")
    en.anchor("egret_return", 39, ["S14"], objective="到市集電話亭等鷺。")
    # Real WORLD baffles protect B3 and the public departure apron. Enemy
    # patrol has no home radius; safety must not depend on metadata alone.
    for column in (48,124):
        en.grid.fill(column,column,28,33,"#")
    en.platform(42,46,30)
    en.platform(128,136,30)
    # Rooftop public bypass: climbs of 4 tiles, no lethal pit or required combat.
    for x0,x1,y in [(49,59,30), (61,71,26), (73,104,22), (106,116,26), (118,123,30)]:
        en.platform(x0,x1,y)
    en.encounter("entry_patrol", [(62,"b",33),(70,"g",33)], bypass="public_awning", note="先見打手、再見槍手；雨棚上路能繞過，沒有鎖場。")
    en.encounter("entry_loading_corner", [(94,"g",33),(104,"b",33)], bypass="public_awning", note="入口預告與下路掩護；不向電話亭安全段射擊。")
    en.routes.append({"id":"public_awning", "from":[49,29], "to":[123,29], "use":"公共雨棚外梯；可繞兩場，後段回入口上層箱。"})
    en.anchor("visible_cache", 84, [], row=21, optional=True, objective="從雨棚後路取回乾燥箱裡的零件。", reward="20 credit, owner transaction required")
    en.extras["safe_zones"] = [[2,47],[125,140]]
    en.extras["safe_zone_isolation"] = {"world_baffles":[[48,28,1,6],[124,28,1,6]],
                                        "height_px":96, "access":"bidirectional awning steps",
                                        "proof_scope":"normal patrol/attack; cumulative player knockback needs native QA",
                                        "native_ai_and_projectile_test":False}
    m.portal("E", "market_entry", 10, "market_entry", "entry_market", style="road")
    m.portal("D", "market_freight", 125, "freight", "freight_market", style="road")
    # A continuous 12-tread ascent to the third-floor public landing; each
    # collision tread rises 1 tile, decorative substeps still need native art review.
    for index in range(12):
        m.platform(76+index*4,79+index*4,33-index)
    m.platform(124,136,22)
    m.portal("U", "market_home", 125, "ali_home", "home_market", row=21, style="door")
    m.portal("R", "market_sc1", 132, "freight", "freight_sc1", row=21, requires="ch2_sc1_open", reason="從雨棚背面放下橋梯，就能走這條近路。", style="road")
    m.anchor("collection_contact", 35, ["S06"], objective="向代收處拿已付收據。")
    m.anchor("receipt", 37, ["S08"], objective="檢視已付收據上的批號與利息。")
    m.anchor("contract", 61, ["S08"], objective="到租攤視窗取本期合約副本。")
    m.anchor("tea_vendor", 23, ["S08"], objective="向榕伯問茶攤的往事。", optional=True)
    m.anchor("announcement", 109, ["S08"], optional=True, objective="收聽天穹週年演說。", modality="broadcast_no_letterbox")
    m.prop("neon_market__tea_urn", 20)
    m.prop("neon_market__debt_desk", 39)
    m.prop("neon_market__produce_stall", 68)
    home.portal("D", "home_market", 10, "market", "market_home")
    home.portal("X", "home_return", 63, "market", "market_home")
    home.anchor("knock", 15, ["S07"], optional=True, objective="敲門後向阿梨問清地址。")
    home.anchor("wash_bowls", 35, ["S07"], optional=True, objective="把洗好的碗放到乾燥架上。")
    home.anchor("taste_soup", 49, ["S07"], optional=True, objective="問阿梨今晚的湯要怎麼煮。")
    home.prop("pawnshop_kitchen__dining_table", 25)
    home.prop("pawnshop_kitchen__kettle_stove", 44)
    f.portal("M", "freight_market", 10, "market", "market_freight", style="road")
    f.portal("R", "freight_sc1", 34, "market", "market_sc1", row=21, requires="ch2_sc1_open", reason="先拉下旁邊的橋梯，打開回茶攤的近路。", style="road")
    f.portal("D", "freight_dry_room", 161, "dry_room", "dry_freight")
    for x0,x1,y in [(17,25,30),(27,35,26),(37,47,22),(49,112,22),(114,123,26),(125,133,30)]:
        f.platform(x0,x1,y)
    # portal at 34 needs actual upper landing beneath feet.
    f.platform(30,47,22)
    f.platform(48,48,22)
    f.anchor("cut_wire", 70, ["S09"], row=21, optional=True, objective="看看橋邊已被剪斷的電線。")
    f.anchor("breathing_guard", 91, ["S09"], optional=True, objective="確認牆邊守衛仍有呼吸。", preview_actor="missing_noncombat_guard")
    f.anchor("sc1_lever", 42, ["S09"], row=21, objective="從內側放下回代收處的橋梯。", result_flag="ch2_sc1_open", backend="story_result_flag_required")
    f.put(42,21,"a")
    f.put(48,21,"v")
    f.mechanisms = {
        "a": {"id":"sc1_switch", "kind":2, "cell":[42,21], "size":[1,1], "channel":"ch2_candidate_sc1", "hint":"{interact} 放下橋梯，打開上層貨道。"},
        "v": {"id":"sc1_gate", "kind":1, "cell":[48,21], "size":[1,4], "channel":"ch2_candidate_sc1", "hint":"先到橋梯內側，拉下旁邊的拉桿。"},
    }
    f.anchor("dry_box", 103, [], row=21, optional=True, objective="打開藏在乾燥梁上的小盒。", reward="20 credit, owner transaction required")
    f.anchor("wet_box", 113, ["S09"], optional=True, objective="把進水紙箱送到乾燥作業室。", backend="contextual_carry_required", delivery_area="dry_room", delivery_anchor="box_drying")
    f.encounter("freight_cutting_lane", [(61,"s",33),(71,"d",33)], bypass="wire_bridge", note="切割者護住機具；維修機距160px，預留首秒巡邏再掃描支援的距離。與入口收帳人分工不同。")
    f.encounter("freight_service_corner", [(105,"s",33),(115,"d",33)], bypass="wire_bridge", note="下層装卸短遭遇；維修機距160px，預留首秒巡邏距離；上層可繞到乾燥作業室。")
    f.routes.append({"id":"wire_bridge", "from":[17,29], "to":[133,29], "use":"公共外梯接已剪斷電線橋；必要C證據無戰鬥可及。"})
    f.prop("crates_stack", 50)
    f.prop("forklift", 87)
    dry.portal("F", "dry_freight", 10, "freight", "freight_dry_room")
    dry.portal("O", "dry_office", 70, "antechamber", "ante_dry_room", requires="ch2_market_reconciled", reason="先在乾燥桌核對三份證據與北棟批號。")
    dry.checkpoint(26)
    dry.anchor("collection_book", 20, ["S08"], objective="到裝卸間乾燥作業室取當日代收簿。")
    dry.anchor("dry_table", 43, ["S10"], objective="比較已付利息，確認北棟卸貨批號。")
    dry.anchor("box_drying", 54, [], optional=True, objective="把進水紙箱放到乾燥架上。", backend="contextual_carry_required")
    dry.prop("factory_office__desk_with_ledger", 39)
    dry.extras["safe_zone_isolation"] = {"kind":"separate_level", "enemy_spawns":0,
        "entry_requires":"", "next_gate":"ch2_market_reconciled",
        "source":"Main._swap_screen removes old Level; ProjectilePool.bind_container resets pool",
        "native_transition_projectile_test":False}
    pre.portal("D", "ante_dry_room", 10, "dry_room", "dry_office")
    pre.portal("O", "ante_office", 68, "office", "office_ante")
    pre.checkpoint(27)
    pre.anchor("isolation_diagram", 44, ["S11"], objective="看清主箱與維修側箱的用途，再確認進帳房。")
    pre.prop("control_console", 47)
    pre.prop("bench", 31)
    office.portal("D", "office_ante", 10, "antechamber", "ante_office")
    office.portal("F", "office_family", 114, "market_entry", "entry_family", requires="ch2_egret_transport_done", reason="先協助把鷺與她的裝備送出家屬門。")
    # Child balcony is physically closed to all playable routes, not an invincible NPC in an arena.
    office.grid.fill(90,126,22,23,"#")
    office.grid.fill(89,90,16,22,"#")
    office.protected.append({"id":"child_family_room", "rect_cells":[91,16,35,6],
                             "actor_cell":[109,21], "access":"adult_rescue_handoff_only",
                             "collision":"solid_floor_and_divider; projectile/actor isolation backend pending"})
    office.platform(30,46,30)
    office.platform(50,66,26)
    office.platform(70,85,30)
    office.anchor("battle_start", 28, ["S11"], objective="拿三張副本與阿勇核對原帳。")
    office.anchor("yong_arena", 59, ["S12"], objective="避開鐵棍，解除動力後制伏阿勇。", backend="nonlethal_boss_phase_required")
    office.anchor("main_isolation", 77, ["S12"], objective="確認永久解除父女連結，再操作主隔離箱。", backend="cut_choice_and_cancellable_operation_required")
    office.anchor("side_isolation", 94, ["S12"], objective="裝甲外蓋脫落後，停止側箱的讀取與動力。", backend="keep_second_phase_required")
    office.anchor("original_ledger", 105, ["S13"], objective="到帳櫃取原帳與診所報表索引。", requires_flags=["ch2_yong_subdued"])
    office.anchor("transport", 113, ["S13"], objective="撐開家屬門，送出鷺與她的裝備。")
    office.prop("control_console", 77)
    office.prop("server_rack", 96)
    office.prop("yong_hideout__vault_safe", 105)
    office.prop("yong_hideout__toy_corner", 104, row=21)
    office.extras["boss_requirement"] = {"id":"ayong", "world_body_px":[24,56], "arena_cells":[22,19,66,15],
                                        "spawn_cell":[59,33], "stand_in":None, "not_adopted":True,
                                        "side_guards":[[94,33],[100,33]], "side_guard_policy":"egret_only_after_child_isolation_backend"}
    office.extras["scale_exempt"] = {"adult_hall":"Converted loading hall: 288px/5.14H double-volume combat bay, not a domestic ceiling.",
                                    "child_room":"96px/1.71H clear height; 192px raised protected gallery."}
    lounge.portal("S", "lounge_street", 10, "street", "street_lounge", style="road")
    lounge.portal("M", "lounge_market", 107, "market_entry", "entry_lounge", requires="ch2_brief_done", reason="先回當舖屋頂向鷺拿查核證，今天只放行市場的公眾攤道。", style="road")
    lounge.portal("G", "lounge_guestbook", 84, "guestbook", "guest_return", requires="ch2_audit_submitted", reason="先到館外委託終端交回公開帳目，再決定看阿梨的夜班。")
    lounge.anchor("handoff_locker", 26, ["S00"], objective="把資料盤放入交接櫃，取驗收回執。", ownership="ST9 single scene, CH02 recovery only")
    lounge.anchor("audit_terminal", 47, ["S15"], objective="上傳公開查帳證據，儲存診所索引。")
    lounge.anchor("private_ledger", 63, ["S16"], optional=True, objective="把私人帳頁交阿梨自己決定。")
    lounge.anchor("guestbook_choice", 81, ["S17"], optional=True, objective="選擇看阿梨今晚的工作，或先回屋頂。")
    lounge.prop("revival_room__steel_locker", 26)
    lounge.prop("control_console", 47)
    lounge.prop("pawnshop_kitchen__dining_table", 64)
    guest.portal("D", "guest_return", 10, "lounge", "lounge_guestbook")
    guest.anchor("zheng_table", 29, ["S18"], optional=True, objective="問鄭先生要怎麼稱呼他，記下晚飯與放盤位置。")
    guest.anchor("chen_table", 50, ["S19"], optional=True, objective="問陳女士的食物忌諱，聽清她今晚的需要。")
    guest.anchor("hong_table", 72, ["S20"], optional=True, objective="聽洪先生說完，再記下他未先詢問的錯。")
    guest.anchor("close_book", 86, ["S21"], optional=True, objective="收好客人簿，回到凜的館外入口。")
    for x in [29,50,72]:
        guest.prop("guest_book_room__guest_book_table", x)
    guest.prop("guest_book_room__tea_cart", 86)
    guest.extras["control_contract"] = {"actor":"ali", "weapons":False, "death_count":False,
                                       "requires_backend":True, "return_snapshot":"lounge.guestbook_choice"}
    return a


def walkable(grid):
    """Conservative 4-tile body clearance, support on #/=, feet-cell coordinates."""
    return {(x,y-1) for x in range(1,grid.w-1) for y in range(4,grid.h)
            if grid.at(x,y) in "#=" and all(grid.at(x,y-k)!="#" for k in range(1,5))}


def reachable(grid, start, blocked=()):
    nodes = walkable(grid) - set(blocked)
    seen = {tuple(start)} if tuple(start) in nodes else set()
    queue = deque(seen)
    while queue:
        x,y = queue.popleft()
        for dx in range(-6,7):
            for dy in range(-4,17):
                dest = (x+dx,y+dy)
                if dest in seen or dest not in nodes or (dx==0 and dy==0):
                    continue
                # Ascending through # is impossible; = permits jumping through.
                top = min(y,y+dy) - (0 if abs(dx)<=1 and abs(dy)<=1 else 3)
                left,right = sorted((x,x+dx))
                if any(grid.at(xx,yy)=="#" for xx in range(left,right+1)
                       for yy in range(max(0,top-3), min(y,y+dy)+1)):
                    continue
                # Adjacent drops and platform drop-through are allowed; a jump
                # spans <=6 tiles and rises <=4, with 1 tile reserve vs engine 5/7.
                if dy>4 and abs(dx)>1:
                    continue
                seen.add(dest)
                queue.append(dest)
    return seen


def parse_prop(ident):
    paths = list((ROOT/"data/environment").glob(f"**/{ident}.tres"))
    if len(paths)!=1:
        raise ValueError(f"PropData {ident}: expected one resource, got {paths}")
    source = paths[0].read_text(encoding="utf-8")
    size = re.search(r"^size = Vector2\(([^,]+), ([^)]+)\)", source,re.M)
    texture = re.search(r'^texture = "res://([^"]+)"',source,re.M)
    if not size or not texture or not (ROOT/texture[1]).is_file():
        raise ValueError(f"{paths[0]}: missing size or real texture")
    return paths[0], tuple(map(float,size.groups()))


def validate(areas):
    problems=[]
    scenes=set()
    for area in areas.values():
        if not (ROOT/f"data/environment/materials/{area.material}.tres").is_file():
            problems.append(f"{area.ident}: missing material {area.material}")
        seen=reachable(area.grid,[5,area.ground-1])
        for record in area.anchors+area.portals:
            if tuple(record["cell"]) not in seen:
                problems.append(f"{area.ident}.{record['id']}: unreachable {record['cell']}")
            scenes.update(record.get("scenes",[]))
        for cell in area.checkpoints:
            if tuple(cell) not in seen:
                problems.append(f"{area.ident}: checkpoint unreachable {cell}")
        for encounter in area.encounters:
            for member in encounter["members"]:
                if tuple(member["cell"]) not in seen:
                    problems.append(f"{area.ident}/{encounter['id']}: enemy unreachable {member}")
        for portal in area.portals:
            if not portal["to"]:
                if not portal["reason"]:
                    problems.append(f"{area.ident}/{portal['id']}: locked door has no explanation")
                continue
            target=areas[portal["to"]]
            matches=[p for p in target.portals if p["id"]==portal["target"]]
            if len(matches)!=1 or matches[0]["to"]!=area.ident:
                problems.append(f"{area.ident}/{portal['id']}: target missing or not reciprocal")
            if portal["requires"] and not portal["reason"]:
                problems.append(f"{area.ident}/{portal['id']}: flag gate has no suggestion")
        for prop in area.props:
            path,size=parse_prop(prop["id"])
            x=prop["x"]*TILE
            if x<16 or x+size[0]>(area.width-1)*TILE:
                problems.append(f"{area.ident}: {path.name} outside")
            if prop.get("support","ground")=="prop":
                support=next((p for p in area.props if p["id"]==prop["support_id"] and p["x"]==prop["support_x"]),None)
                if support is None:
                    problems.append(f"{area.ident}: support missing for {prop}")
                else:
                    _,support_size=parse_prop(support["id"])
                    center=x+size[0]/2
                    if abs(prop["dy"]+support_size[1])>2 or not support["x"]*TILE<=center<=support["x"]*TILE+support_size[0]:
                        problems.append(f"{area.ident}: prop anchor does not contact workbench")
            else:
                floor=prop["y"]+1
                if any(area.grid.at(col,floor) not in "#=" for col in range(int(x/TILE),int((x+size[0]-.01)/TILE)+1)):
                    problems.append(f"{area.ident}: {prop['id']} lacks full support")
                if any(area.grid.at(col,row)=="#" for col in range(int(x/TILE),int((x+size[0]-.01)/TILE)+1)
                       for row in range(int((floor*TILE-size[1])/TILE),floor)):
                    problems.append(f"{area.ident}: {prop['id']} embedded")
    if scenes!={f"S{i:02}" for i in range(23)}:
        problems.append(f"scene coverage differs: {sorted(scenes)}")
    for char,ident in ENEMIES.items():
        if not (ROOT/f"data/enemies/{ident}.tres").is_file():
            problems.append(f"enemy resource missing: {char}/{ident}")
    return problems


def theme_text(area):
    dirs=sorted({"res://"+str(parse_prop(p["id"])[0].parent.relative_to(ROOT)).replace("\\","/")
                 for p in area.props if parse_prop(p["id"])[0].parent!=ROOT/"data/environment/props"})
    return f'''[gd_resource type="Resource" script_class="EnvironmentTheme" load_steps=5 format=3]

[ext_resource type="Script" path="res://data/scripts/environment_theme.gd" id="theme"]
[ext_resource type="Script" path="res://data/scripts/env_zone.gd" id="zone"]
[ext_resource type="Resource" path="res://data/environment/materials/{area.material}.tres" id="material"]

[sub_resource type="Resource" id="zone0"]
script = ExtResource("zone")
from_tile = 0
material = ExtResource("material")
hole_chance = 0.0
label = {quote(area.name)}
interior = "res://art/environment/materials/{'brick' if area.material=='concrete' else 'old_metal'}_body.png"
interior_scale = 4

[resource]
script = ExtResource("theme")
zones = Array[ExtResource("zone")]([SubResource("zone0")])
extra_prop_dirs = PackedStringArray({", ".join(quote(d) for d in dirs)})
'''


def level_text(area):
    exts=[("Script","res://data/scripts/level_data.gd","level"),
          ("Script","res://data/scripts/portal_data.gd","portal"),
          ("Resource",f"{RES}/themes/{area.ident}.tres","theme"),
          ("Script","res://data/scripts/lighting_zone.gd","lighting_zone"),
          ("Resource",f"res://data/lighting/{'pawnshop_warm' if area.ident in ('pawnshop','ali_home','guestbook','dry_room') else 'freight' if area.ident in ('freight','antechamber','office') else 'rooftop' if area.ident=='rooftop' else 'market'}.tres","lighting")]
    legend={}
    for char,ident in ENEMIES.items():
        if any(char in row for row in area.grid.rows()):
            exts.append(("Resource",f"res://data/enemies/{ident}.tres",ident))
            legend[char]=f'ExtResource("{ident}")'
    subs=['[sub_resource type="Resource" id="light0"]\nscript = ExtResource("lighting_zone")\nstart_tile = 0\nblend_tiles = 0\nprofile = ExtResource("lighting")\n']
    for i,p in enumerate(area.portals):
        sid=f"portal{i}"
        text=f'[sub_resource type="Resource" id="{sid}"]\nscript = ExtResource("portal")\nid = &{quote(p["id"])}\n'
        if p["to"]:
            text+=f'target_level = {quote(resource_path(p["to"]))}\ntarget_portal = &{quote(p["target"])}\n'
        names={"pawnshop":"當舖","rooftop":"屋頂","street":"街口","market_entry":"市場入口","market":"茶攤","freight":"裝卸間","ali_home":"小廚房","antechamber":"帳房前室","office":"帳房","lounge":"復原館外","guestbook":"客人簿室","dry_room":"乾燥作業室"}
        text+=f'prompt = {quote("{interact} "+ ("前往"+names[p["to"]] if p["to"] else "查看貨梯方向"))}\n'
        if p["requires"]:
            text+=f'requires_flag = &{quote(p["requires"])}\n'
        if p["reason"]:
            text+=f'locked_text = {quote(p["reason"])}\n'
        text+=f'width = {p["width"]}\nheight = {p["height"]}\nstyle = {quote(p["style"])}\n'
        subs.append(text)
        legend[p["char"]]=f'SubResource("{sid}")'
    if area.mechanisms:
        exts.append(("Script","res://data/scripts/mechanism_data.gd","mechanism"))
    for char,m in area.mechanisms.items():
        sid=m["id"]
        subs.append(f'''[sub_resource type="Resource" id="{sid}"]
script = ExtResource("mechanism")
id = &"{sid}"
kind = {m["kind"]}
display_name = {quote("橋梯拉桿" if m["kind"]==2 else "橋梯護門")}
channel = &"{m["channel"]}"
size_tiles = Vector2i({m["size"][0]}, {m["size"][1]})
hint = {quote(m["hint"])}
''')
        legend[char]=f'SubResource("{sid}")'
    lines=[f'[gd_resource type="Resource" script_class="LevelData" load_steps={len(exts)+len(subs)+1} format=3]',""]
    lines += [f'[ext_resource type="{typ}" path="{path}" id="{key}"]' for typ,path,key in exts]
    lines+=["","\n".join(subs),"[resource]",'script = ExtResource("level")',
            f'id = &"ch2_campaign_{area.ident}"',f'display_name = {quote(area.name+"（布局候選）")}',
            f'tile_size = {TILE}',f'height = {HEIGHT}',
            'legend = Dictionary[String, Resource]({'+", ".join(quote(c)+": "+v for c,v in sorted(legend.items()))+'})',
            'chapter = &"ch2_campaign_candidate"', 'persistent_world = true', 'show_chapter_card = false',
            'next_level = ""', 'death_credit_cap = 250', 'attack_caps = {"melee": 1, "ranged": 1}',
            f'rain = {"false" if area.ceiling else "true"}', 'environment = ExtResource("theme")',
            'lighting_zones = Array[ExtResource("lighting_zone")]([SubResource("light0")])',
            f'layout_path = "{RES}/levels/ch2_campaign_{area.ident}_map.json"',""]
    return "\n".join(lines)


def current_exit_contract():
    """Read actual baseline cells instead of copying design H labels as coordinates."""
    result=[]
    for name,char in [("vault","L"),("lounge","G"),("stall","Z"),("street","m")]:
        raw=json.loads((ROOT/f"data/levels/ch1_{name}_map.json").read_text(encoding="utf-8"))
        rows=["".join(seg[y] for seg in raw["segments"]) for y in range(len(raw["segments"][0]))]
        cells=[[x,y] for y,row in enumerate(rows) for x,c in enumerate(row) if c==char]
        result.append({"level":f"res://data/levels/ch1_{name}.tres", "char":char,"cells":cells})
    return result


def inventory(areas):
    identities={}
    for ident in ENEMIES.values():
        path=ROOT/f"data/enemies/{ident}.tres"
        source=path.read_text(encoding="utf-8")
        rig=re.search(r'^(rig_skin|creature_skin) = "([^"]+)"',source,re.M)
        skin=rig[2] if rig else "missing"
        art=ROOT/(f"art/rigs/{skin}.json" if rig and rig[1]=="rig_skin" else f"art/creatures/{skin}.json")
        if not art.is_file():
            raise ValueError(f"{path}: no real art identity {art}")
        identities[ident]={"resource":f"res://data/enemies/{ident}.tres", "skin":skin,
                           "art_definition":str(art.relative_to(ROOT)).replace("\\","/"),
                           "sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
    # The resource-ID intersection and art-skin intersection are distinct checks.
    ch1=set()
    for path in (ROOT/"data/levels").glob("ch1_*.tres"):
        ch1.update(re.findall(r'res://data/enemies/([^"/]+)\.tres',path.read_text(encoding="utf-8")))
    ch1_skins=set()
    for ident in ch1:
        source=(ROOT/f"data/enemies/{ident}.tres").read_text(encoding="utf-8")
        match=re.search(r'^(?:rig_skin|creature_skin) = "([^"]+)"',source,re.M)
        if match:
            ch1_skins.add(match[1])
    return {"resources":identities,"ch1_shared_ids":sorted(set(ENEMIES.values())&ch1),
            "ch1_shared_art_identities":sorted({r["skin"] for r in identities.values()}&ch1_skins),
            "spawn_count":sum(len(e["members"]) for a in areas.values() for e in a.encounters),
            "ayong_not_adopted":True,"side_guards_not_spawned":True}


def atlas_html(areas):
    """A vector schematic from the actual grid, clearly distinct from native pixels."""
    blocks=[]
    for key,area in areas.items():
        shapes=[]
        for y,row in enumerate(area.grid.rows()):
            x=0
            while x<len(row):
                char=row[x]
                end=x+1
                while end<len(row) and row[end]==char:
                    end+=1
                if char in "#=":
                    height=TILE if char=="#" else 4
                    shapes.append(f'<rect x="{x*TILE}" y="{y*TILE}" width="{(end-x)*TILE}" height="{height}" fill="{"#64717d" if char=="#" else "#91b7c3"}"/>')
                elif char!=".":
                    for xx in range(x,end):
                        color="#e8995e" if char in ch2_portal_chars(area) else "#72c6b8" if char in "PC" else "#db7272"
                        shapes.append(f'<text x="{xx*TILE+8}" y="{y*TILE+14}" text-anchor="middle" fill="{color}" font-size="16">{html.escape(char)}</text>')
                x=end
        for zone in area.protected:
            x,y,w,h=zone["rect_cells"]
            shapes.append(f'<rect x="{x*TILE}" y="{y*TILE}" width="{w*TILE}" height="{h*TILE}" fill="#86b694" fill-opacity="0.2" stroke="#86b694"/>')
        for anchor in area.anchors:
            x,y=anchor["cell"]
            shapes.append(f'<circle cx="{(x+.5)*TILE}" cy="{(y+1)*TILE}" r="4" fill="#ffdc7d"><title>{html.escape(anchor["id"]+": "+anchor["objective"])}</title></circle>')
        rows="".join(f'<tr><td>{html.escape(a["id"])}</td><td>{", ".join(a["scenes"])}</td><td>{a["cell"]}</td><td>{html.escape(a["objective"])}</td></tr>' for a in area.anchors)
        blocks.append(f'<section id="{key}"><h2>{area.name} · {area.width*TILE}×{HEIGHT*TILE}px</h2><p>{area.purpose}；色盤意圖：{area.color}。</p><div class="map"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {area.width*TILE} {HEIGHT*TILE}" style="width:{area.width*TILE}px;height:{HEIGHT*TILE}px">'+"".join(shapes)+f'</svg></div><table><tr><th>來源錨點</th><th>場號</th><th>腳底格</th><th>玩家目標</th></tr>{rows}</table></section>')
    return '<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><title>第二章真實候選地形圖</title><style>body{background:#172028;color:#dfe9ee;font:16px system-ui;margin:32px}section{margin:48px 0}h1,h2{font-weight:600}.map{overflow:auto;border:1px solid #53636e}svg{background:#1e2c35}table{border-collapse:collapse;margin-top:16px}td,th{text-align:left;padding:8px;border-bottom:1px solid #405360}th{color:#9ec9d4}p{max-width:1000px;line-height:1.6}</style><h1>第二章布局候選：來源幾何圖</h1><p>這是 Grid／LevelData 候選產生的向量示意，不是遊戲截圖。P 為起點、C 為檢查點、橙字為出入口、紅字為正式既有敵人或候選機關；黃色點是尚未接線的故事操作位置。阿勇與小薇沒有替身。每格16px、成人H56px；請用下方真實腳底格檢查接觸線。</p>'+"".join(blocks)+'</html>\n'


def ch2_portal_chars(area):
    return {p["char"] for p in area.portals}


def generate():
    areas=authored_areas()
    problems=validate(areas)
    if problems:
        raise ValueError("\n".join(problems))
    files={}
    for key,area in areas.items():
        rows=area.grid.rows()
        data={"segments":[[row[i:i+50] for row in rows] for i in range(0,area.width,50)],
              "props":area.props,"regions":[]}
        files[f"levels/ch2_campaign_{key}_map.json"]=json.dumps(data,ensure_ascii=False,indent=2)+"\n"
        files[f"levels/ch2_campaign_{key}.tres"]=level_text(area)
        files[f"themes/{key}.tres"]=theme_text(area)
    manifest={"schema":1,"status":"spatial_candidate_not_campaign_delivery", "generator":"tools/story/build_ch2_levels.py",
              "script_source":"design/13-story-v2/SCRIPT_CH02.md",
              "script_sha256":hashlib.sha256((ROOT/"design/13-story-v2/SCRIPT_CH02.md").read_bytes()).hexdigest(),
              "production_blockers":list(BLOCKERS),"current_ch1_exit_contract":current_exit_contract(),
              "enemy_inventory":inventory(areas),"transport":"walk_only; no teleport service claim",
              "preview_flags":sorted({p["requires"] for a in areas.values() for p in a.portals if p["requires"]}),
              "areas":{key:{"level":resource_path(key),"world_px":[a.width*TILE,HEIGHT*TILE],
                             "ground_feet_px":a.ground*TILE,"purpose":a.purpose,"color":a.color,
                             "portals":a.portals,"anchors":a.anchors,"checkpoints":a.checkpoints,
                             "encounters":a.encounters,"routes":a.routes,"mechanisms":a.mechanisms,
                             "protected":a.protected,**a.extras}
                       for key,a in areas.items()},
              "validation":{"cpu_geometry":True,"native_leveldata":False,"native_scene_audit":False,
                            "playthrough_duration":None,"physical_gamepad":False,"audio":False}}
    files["manifest.json"]=json.dumps(manifest,ensure_ascii=False,indent=2)+"\n"
    files["layout_atlas.html"]=atlas_html(areas)
    return files,manifest


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check",action="store_true",help="compare regenerated bytes; do not write")
    parser.add_argument("--production",action="store_true",help="reserved; fails until real narrative integration")
    args=parser.parse_args(argv)
    if args.production:
        parser.error("Production is unavailable. Missing verified runtime/art integration: "+", ".join(BLOCKERS))
    files,manifest=generate()
    drift=[]
    for rel,content in files.items():
        path=DEST/rel
        if args.check:
            if not path.is_file() or path.read_bytes()!=content.encode("utf-8"):
                drift.append(rel)
        else:
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_bytes(content.encode("utf-8"))
    if drift:
        print("Candidate differs: "+", ".join(drift),file=sys.stderr)
        return 1
    print(f"CH02: {len(manifest['areas'])} real LevelData candidates, 23 scene anchors, {len(files)} reproducible files; production blocked")
    return 0


if __name__=="__main__":
    raise SystemExit(main())
