extends Node
## Native LevelData audit / explicitly labelled candidate screenshot.
## Default: --headless res://tools/story/ch2_layout_probe.tscn
## Preview requires CH2_PROFILE plus isolated APPDATA/LOCALAPPDATA; see layout doc.

const CANDIDATE_ROOT := "res://assets_src/chapter2_candidate/levels"
var _preview := ""
var _cell := Vector2i(-1, -1)
var _out := ""


func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--preview="):
			_preview = arg.trim_prefix("--preview=")
		elif arg.begins_with("--cell="):
			var parts := arg.trim_prefix("--cell=").split(",")
			if parts.size() == 2:
				_cell = Vector2i(int(parts[0]), int(parts[1]))
		elif arg.begins_with("--out="):
			_out = arg.trim_prefix("--out=")
	_run.call_deferred()


func _run() -> void:
	if not _preview.is_empty() and not _preview_is_isolated():
		get_tree().quit(2)
		return
	var datas: Dictionary = {}
	var layouts: Dictionary = {}
	var problems := PackedStringArray()
	for path in SceneAudit.level_paths(CANDIDATE_ROOT):
		var data := load(path) as LevelData
		if data == null:
			problems.append("LevelData load failed: " + path)
			continue
		datas[path] = data
		var layout := LevelBuilder.parse(data)
		layouts[path] = layout
		problems.append_array(layout.warnings)
		problems.append_array(data.validate_lighting())
		if data.environment == null:
			problems.append("EnvironmentTheme missing: " + path)
		else:
			problems.append_array(data.environment.validate())
		for spawn: Dictionary in layout.spawns:
			var resource: Resource = spawn["resource"]
			if resource.has_method("validate"):
				problems.append_array(resource.call("validate"))
		for issue: Dictionary in SceneAudit.audit(data, layout):
			problems.append(SceneAudit.describe(issue))
	for issue: Dictionary in SceneAudit.audit_links(datas, layouts):
		problems.append(SceneAudit.describe(issue))
	var manifest: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://assets_src/chapter2_candidate/manifest.json"))
	if not manifest is Dictionary or not manifest.get("areas") is Dictionary:
		problems.append("Candidate manifest has no areas dictionary")
	elif datas.size() != manifest["areas"].size():
		problems.append("Candidate count differs from manifest: %d vs %d" % [datas.size(), manifest["areas"].size()])
	for problem in problems:
		printerr("[ch2_candidate] " + problem)
	print("[ch2_candidate] %d resources audited; %d issues; story/gamepad/release remain unverified" % [datas.size(), problems.size()])
	if not problems.is_empty() or _preview.is_empty():
		get_tree().quit(0 if problems.is_empty() else 1)
		return
	var selected := CANDIDATE_ROOT + "/ch2_campaign_" + _preview + ".tres"
	if not datas.has(selected) or _out.is_empty():
		printerr("[ch2_candidate] Preview requires a known candidate id and --out absolute PNG path")
		get_tree().quit(2)
		return
	GameState.story_autosave = false
	GameState.start_new_run(GameState.difficulties[0])
	Story.auto_skip = true
	add_child(LightKit.create_environment())
	var level := Level.new()
	level.configure(datas[selected] as LevelData)
	add_child(level)
	for frame in 20:
		await get_tree().process_frame
	if _cell.x >= 0 and _cell.y >= 0:
		level.player.global_position = level._layout.cell_to_feet(_cell.x, _cell.y)
		level.camera.snap_to_target()
		level._lighting.snap()
		level.camera.force_update_scroll()
		await get_tree().physics_frame
	var overlay := CanvasLayer.new()
	overlay.layer = 100
	add_child(overlay)
	var label := Label.new()
	label.text = "第二章布局候選：劇情與阿勇戰尚未接線"
	label.position = Vector2(12, 12)
	overlay.add_child(label)
	get_tree().paused = true
	await RenderingServer.frame_post_draw
	var screenshot := preload("res://tools/viewport_capture.gd").image(get_viewport())
	var error := screenshot.save_png(_out)
	print("[ch2_candidate] preview PNG error=%d: %s" % [error, _out])
	get_tree().quit(0 if error == OK else 1)


func _preview_is_isolated() -> bool:
	var profile := OS.get_environment("CH2_PROFILE").replace("\\", "/").simplify_path().trim_suffix("/")
	var actual := OS.get_user_data_dir().replace("\\", "/").simplify_path()
	if profile.is_empty() or not profile.is_absolute_path() or not actual.to_lower().begins_with(profile.to_lower() + "/"):
		printerr("[ch2_candidate] Preview requires absolute CH2_PROFILE containing actual OS.user_data_dir; use the isolated profile command in CH02_LEVEL_LAYOUT.md")
		return false
	if not _out.is_absolute_path():
		printerr("[ch2_candidate] Preview --out must be an absolute PNG path")
		return false
	if DisplayServer.get_name() == "headless" or RenderingServer.get_current_rendering_method() != "forward_plus":
		printerr("[ch2_candidate] Preview requires a non-headless Forward+ renderer")
		return false
	return true
