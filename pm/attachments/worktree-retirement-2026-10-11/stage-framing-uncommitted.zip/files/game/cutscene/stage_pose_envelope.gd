class_name StagePoseEnvelope
extends RefCounted
## ST-10：事件時建立的骨架空間保守界線，不取樣假定週期峰值，不改動畫器。
## 三角函數取整個角度區間極值；FK 對父角度區間旋轉 rest，蒙皮按凸組合與厚度限長求界。
## NpcLife.follow 的五組資料參數使用精確不變多邊形證書，其餘使用共同 Lyapunov 界線。
## 同演員曾用過的目標區間聯集保留過渡與餘勢；context cache 有上限，不跨播放器持有 Node。

const MAX_CONTEXTS := 64
const MAX_BONES := 128
const MAX_PARTS := 256
const FULL := Vector2(-PI, PI)
var supported := true
var reason := ""
var bounds := Rect2() # actor 本地空間，已含 rig.body_scale，不含 actor.position/scale/facing
var contexts := 0
var full_rotation_channels := PackedStringArray()
var _keys: Dictionary[String, bool] = {}
var _targets: Dictionary[StringName, Vector2] = {}
var _follow_targets: Dictionary[StringName, Vector2] = {}
var _hip_x := Vector2.ZERO
var _hip_y := Vector2.ZERO
var _ground := Vector2.ZERO
## update 每格先將 ground 歸零；plant 以零位移 FK 量最低 ankle，feet/gait 另保留分支聯集。
var _plant_ground := false
var _ground_extra := Vector2.ZERO
## raw _angles 與 post-pose IK 分開。gait/pin/feet 都是永久歷史，不因回NPC而縮回。
var _gait_ground := Vector2.ZERO
var _pin_ground := false
var _life_config: Dictionary = {}
## _apply_body 在 _angles 平滑之後才加run overlay；回NPC時仍有_run_w餘勢，不能只取聯集。
var _run_overlay: Dictionary[StringName, Vector2] = {}
## NE221：secondary spring加在raw平滑角與run overlay之後，不覆寫body目標。
var _secondary_springs: Dictionary[StringName, Vector2] = {}
var _secondary_limits: Dictionary[StringName, PackedFloat64Array] = {}
var _secondary_source := PackedByteArray()
## 節點拓撲在setup後固定；事件include先重驗類型／identity，不讓same-context跳過未知零件。
var _part_ids := PackedInt64Array()
var _human_feet_ik := false
var _feet_ik := false
var _feet_x: Dictionary[StringName, Vector2] = {}
var _knee_range: Dictionary[StringName, Vector2] = {}
var _angles: Dictionary[StringName, Vector2] = {}
var _positions: Dictionary[StringName, Rect2] = {}
var _first := true
var _rig: CharacterRig


func include(actor: CutsceneActor, velocity := Vector2.ZERO) -> bool:
	if not supported:
		return false
	if actor.rig == null:
		return _portrait(actor)
	if _rig != null and _rig != actor.rig:
		return _unsupported("不能把包絡轉用另一個 rig／動畫歷史")
	_rig = actor.rig
	if not _rig.animator is NpcAnimator or _rig.bone_order().size() > MAX_BONES \
			or _rig._parts.size() > MAX_PARTS or not is_finite(_rig.body_scale()) or _rig.body_scale() <= 0:
		return _unsupported("不受支援的動畫器／骨架容量／縮放")
	var body_scale := _rig.body_scale()
	# CharacterRig.facing 將 GDScript double 存進 Vector2(real_t=float32)。
	# 比較同一次量化的標準 scale；不以寬鬆 epsilon 接受另一個非標準 transform。
	var stored_scale := Vector2(body_scale, body_scale)
	if _rig.position != Vector2.ZERO or _rig.rotation != 0 or _rig.skew != 0 \
			or absf(_rig.scale.x) != stored_scale.x or _rig.scale.y != stored_scale.y \
			or _rig._skeleton.transform != Transform2D.IDENTITY:
		return _unsupported("非標準 rig／skeleton 原點或旋轉")
	# 新演員的 spring 初態是 follow: x=first target,v=0；glance: x=v=0。
	# 已播放才新建 cache 缺少歷史速度／target 範圍，不能假定回到初態。
	var animator := _rig.animator as NpcAnimator
	if contexts == 0:
		# animate(0)仍能初始化NpcLife.follow；_time==0本身不能證明fresh。
		if animator._time != 0.0 or animator._life != null or animator._hip_offset != Vector2.ZERO \
				or animator._ground_shift != 0.0 or animator._gait_w != 0.0 or animator._idle_pin_w != 0.0 \
				or animator._run_w != 0.0 or animator._feet_w != 0.0 \
				or animator._land_x != 0.0 or animator._land_v != 0.0:
			return _unsupported("新包絡不能接管已初始化／播放的動畫歷史")
		for name in _rig.bone_order():
			var initial := HumanoidAnimator.HAND_FOLLOWS_FOREARM if name in [&"hand_front", &"hand_back"] else 0.0
			if animator._angles.get(name, INF) != initial:
				return _unsupported("新包絡缺少已有角度歷史")
		for name in animator._spring_angle:
			if animator._spring_angle[name] != 0.0 or animator._spring_velocity.get(name, INF) != 0.0:
				return _unsupported("新包絡缺少已有secondary spring位置／速度歷史")
	if animator._life != null and not _life_config.is_empty() and animator._life._cfg != _life_config:
		return _unsupported("NpcLife 參數在同一歷史中改變，原 spring 證書不再適用")
	# 至多256個kind/id查核，僅事件include執行，不讀visual_bounds或每格配置。
	var changed_count := contexts > 0 and _part_ids.size() != _rig._parts.size()
	for i in _rig._parts.size():
		var part: Variant = _rig._parts[i]
		if not is_instance_valid(part):
			return _unsupported("零件來源已釋放，原包絡不能沿用")
		if not part is Sprite2D and not part is RigPartMesh:
			return _unsupported("未知零件類型 %s" % part.get_class())
		if contexts == 0:
			_part_ids.append(part.get_instance_id())
		elif not changed_count and _part_ids[i] != part.get_instance_id():
			return _unsupported("零件來源在動畫歷史中替換，原包絡不能沿用")
	if changed_count:
		return _unsupported("零件拓撲在動畫歷史中改變，原包絡不能沿用")
	# 固定secondary配置也在cache命中前查核，不讓熱改clamp誤用舊界線。
	if not _include_secondary_springs(animator):
		return false
	var input := actor._input
	# cache命中前也查核輸入/門檻；同context不能把後來NaN或負門檻當已證明資料。
	var threshold_value: Variant = _dictionary(animator._motion.get("move", {})).get("threshold", NAN)
	if typeof(threshold_value) not in [TYPE_INT, TYPE_FLOAT]:
		return _unsupported("human idle門檻非數值")
	if not is_finite(input.run_speed) or not is_finite(float(threshold_value)) or float(threshold_value) < 0:
		return _unsupported("human速度/idle門檻非有限或為負")
	# 本包絡的extra_sag=0來源是正式CutsceneActor不送jump/land/dash事件。
	if input.jumped or input.landed != 0.0 or input.dash_started:
		return _unsupported("過場輸入含未支援的一次性跳躍/落地/衝刺事件")
	var numbers := PackedFloat64Array([input.npc_loop_scale, velocity.x, input.run_speed]).to_byte_array().hex_encode()
	var key := "%s|%s|%s|%s|%d|%s|%s|%s|%s|%s" % [_rig.skin_id, actor.pose,
		input.npc_loop, numbers, actor.facing, _rig.weapon_def().get("file", ""),
		_rig.active_pose_parts(), input.talking, actor._listen_flag, input.two_handed]
	if _keys.has(key):
		return true # 舊 context 已在累積聯集中，不能把歷史界線縮回舊 cache。
	if contexts >= MAX_CONTEXTS or not velocity.is_finite() or not is_finite(input.npc_loop_scale):
		return _unsupported("context 容量／非有限動作參數")
	_keys[key] = true
	contexts += 1
	var m := _rig.animator._motion
	var target: Dictionary[StringName, Vector2] = {}
	for name in _rig.bone_order():
		target[name] = Vector2.ZERO
	var human := input.two_handed or actor.pose in [&"walk", &"run", &"crouch", &"aim_up", &"block", &"jump", &"dead"]
	if actor.pose == &"dead":
		return _unsupported("dead 的 corpse 接地需另建位移界線")
	if human:
		# walk/run 的零速度首格或停止格會回到 NPC；兩條實際分支都納入。
		if not input.two_handed and actor.pose in [&"walk", &"run"]:
			if not _npc_target(actor, m, target):
				return false
		var human_target: Dictionary[StringName, Vector2] = {}
		if not _human_target(actor, m, human_target):
			return false
		for name in human_target:
			target[name] = union_interval(target.get(name, Vector2.ZERO), human_target[name])
	else:
		if not _npc_target(actor, m, target):
			return false
	# 角度平滑從 0（手為 1.4）開始；每次演出事件包含歷史目標，不能漏過渡。
	for name in _rig.bone_order():
		var initial := HumanoidAnimator.HAND_FOLLOWS_FOREARM if name in [&"hand_front", &"hand_back"] else 0.0
		var range_value: Vector2 = target.get(name, Vector2.ZERO)
		_targets[name] = union_interval(_targets.get(name, Vector2(initial, initial)), range_value)
	# _targets保留全部raw/follow/smoothing歷史；secondary clamp另在FK相加。
	# plant 的輸入必須是 _apply_body 在 ground=0、尚未 leg IK 的 FK。
	# 不把已含ground的_positions回餵needed，避免自我循環／反覆膨脹。
	_build_fk(false, false)
	if not supported or not _derive_ground():
		return false
	_build_fk()
	if not supported:
		return false
	var result := Rect2()
	_first = true
	for part in _rig._parts:
		if part is Sprite2D:
			result = _merge(result, _sprite_bounds(part as Sprite2D))
		elif part is RigPartMesh:
			result = _merge(result, _mesh_bounds(part as RigPartMesh))
		else:
			return _unsupported("未知零件類型 %s" % part.get_class())
		if not supported:
			return false
	# 握持手變體不是 _parts 裡的新節點；保留 open/closed canvas 的聯集。
	for grip in _rig._hand_grips:
		var sprite: Sprite2D = grip["sprite"]
		var texture: Texture2D = grip["grip_texture"]
		var pivot: Vector2 = grip["grip_pivot"]
		result = _merge(result, _attachment_bounds(StringName(str(grip["bone"])),
			Rect2(-pivot, texture.get_size()), sprite.transform))
	if not _rig.weapon_def().is_empty():
		result = _merge(result, _weapon_bounds())
	if not supported or _first or not result.has_area() or not result.position.is_finite() or not result.end.is_finite():
		return _unsupported("沒有有限的演員輪廓")
	bounds = Transform2D(0.0, Vector2(absf(_rig.scale.x), _rig.scale.y), 0.0, Vector2.ZERO) * result
	return true


## 只在include事件檢查固定配置；_update_springs每個子步clamp提供連續界線。
## 同bone重複配置的最後一次update決定dictionary角度；聯集clamp而非加總各entry。
## 初態0必須包含，即使某個合法min/max不跨0；完整body目標不因此被替換。
func _include_secondary_springs(animator: NpcAnimator) -> bool:
	if animator._springs.size() > MAX_BONES or not RunSaveCodec.validate_tree(animator._springs, 4096).is_empty():
		return _unsupported("secondary spring配置非有限或超容量")
	var source := var_to_bytes(animator._springs)
	if contexts > 0 and source != _secondary_source:
		return _unsupported("secondary spring參數在同一歷史中改變")
	if contexts == 0:
		_secondary_source = source
		for spring in animator._springs:
			var name := StringName(str(spring.get("bone", "")))
			var low := float(spring.get("min", HumanoidAnimator.SPRING_MIN))
			var high := float(spring.get("max", HumanoidAnimator.SPRING_MAX))
			if not _rig.has_bone(name) or not animator._angles.has(name) or not is_finite(low) or not is_finite(high) or low > high:
				return _unsupported("secondary spring %s來源／clamp無效" % name)
			var previous: PackedFloat64Array = _secondary_limits.get(name, PackedFloat64Array([0.0, 0.0]))
			var limits := PackedFloat64Array([minf(previous[0], low), maxf(previous[1], high)])
			_secondary_limits[name] = limits
			# Vector2儲存float32；向外取相鄰值，不能以量化後較窄clamp拒真double端點。
			var interval := Vector2(limits[0], limits[1])
			if not interval.is_finite():
				return _unsupported("secondary spring clamp超出Vector2有限範圍")
			if interval.x > limits[0]:
				interval.x = _adjacent_float32(interval.x, false)
			if interval.y < limits[1]:
				interval.y = _adjacent_float32(interval.y, true)
			if not interval.is_finite():
				return _unsupported("secondary spring向外clamp超出Vector2有限範圍")
			_secondary_springs[name] = interval
	if animator._spring_angle.size() != _secondary_springs.size():
		return _unsupported("secondary spring角度來源與定義不符")
	for name: StringName in animator._spring_angle:
		if not _secondary_springs.has(name):
			return _unsupported("secondary spring角度缺少clamp來源")
		var value: float = animator._spring_angle[name]
		var limits: PackedFloat64Array = _secondary_limits[name]
		if not is_finite(value) or value < limits[0] or value > limits[1]:
			return _unsupported("secondary spring角度超出clamp來源")
	return true


## finite float32端點的一個IEEE相鄰值；0使用最小subnormal，不猜epsilon。
static func _adjacent_float32(value: float, upward: bool) -> float:
	if value == 0.0:
		var smallest := PackedByteArray([1, 0, 0, 0]).decode_float(0)
		return smallest if upward else -smallest
	var bytes := PackedFloat32Array([value]).to_byte_array()
	var bits := bytes.decode_u32(0)
	bits += 1 if (value > 0.0) == upward else -1
	bytes.encode_u32(0, bits)
	return bytes.decode_float(0)


func _portrait(actor: CutsceneActor) -> bool:
	if actor._portrait == null or actor._portrait.texture == null:
		return _unsupported("沒有頭像")
	# CutsceneActor 的唯一動畫：y=-32+sin(t TAU/3.2)*0.8，完整振幅解析界線。
	var rect := actor._portrait.transform * actor._portrait.get_rect()
	rect.position.y = -32.0 + (rect.position.y - actor._portrait.position.y) - 0.8
	rect.size.y += 1.6
	bounds = rect
	return true


func _npc_target(actor: CutsceneActor, m: Dictionary, target: Dictionary[StringName, Vector2]) -> bool:
	var data := RigLibrary.load_json(NpcAnimator.DATA_PATH)
	var posture := "stand"
	if actor.pose in [&"sit", &"lean"]:
		posture = str(actor.pose)
	elif actor.pose == &"squat":
		posture = "crouch"
	var poses := _dictionary(data.get("poses", {}))
	var base := _dictionary(poses.get(posture, poses.get("stand", {})))
	_add_bones(target, base.get("bones", {}))
	if posture == "stand":
		_add_bones(target, m["npc"]["stand"])
	for hand: StringName in [&"hand_front", &"hand_back"]:
		_add(target, hand, Vector2.ONE * HumanoidAnimator.HAND_FOLLOWS_FOREARM)
	var x := Vector2.ONE * float(base.get("hip_x", 0))
	var y := Vector2.ONE * float(base.get("hip_y", 0))
	var life: Dictionary = _dictionary(data.get("life", {})).duplicate(true)
	var overrides: Dictionary = m["npc"]["life"]
	for k in overrides:
		if overrides[k] is Dictionary and life.get(k) is Dictionary:
			(life[k] as Dictionary).merge(overrides[k], true)
		else:
			life[k] = overrides[k]
	if _life_config.is_empty():
		_life_config = life.duplicate(true)
	elif life != _life_config:
		return _unsupported("同一演員的生命感資料改變，不能丟棄原 spring 歷史")
	var amount := maxf(0, float(life.get("amount", 1)))
	var drift: Variant = life.get("drift", [])
	if drift is Array:
		for raw: Variant in drift:
			if raw is Dictionary:
				var track: Dictionary = raw
				_add(target, StringName(str(track.get("bone", ""))), symmetric(float(track.get("amp", 0.02)) * amount))
	var shift := _dictionary(life.get("shift", {}))
	var shift_x := absf(float(shift.get("hip_x", 0.8))) * amount
	# NpcLife._shift zeta=1, omega<=15, h<=1/60: x and x+v/omega are convex combinations
	# for a=omega*h<=0.25; zero initial state therefore stays within +/- target bound.
	x += symmetric(shift_x)
	_add(target, &"chest", symmetric(shift_x * float(shift.get("lean", 0.03))))
	if posture == "stand":
		var counter := asin(minf(0.5, shift_x / maxf(4, _rig.rest(&"leg_front_lower").length())))
		# NpcLife.free_leg: upper -= bend*0.5，lower += bend；不是四根骨頭都±knee。
		var knee := float(shift.get("knee", 0.1)) * minf(1.0, shift_x / maxf(0.1, float(shift.get("hip_x", 0.8))))
		for name: StringName in [&"leg_front_upper", &"leg_back_upper"]:
			_add(target, name, symmetric(counter) + pulse(-0.5 * knee))
		for name: StringName in [&"leg_front_lower", &"leg_back_lower"]:
			_add(target, name, symmetric(counter) + pulse(knee))
	var glance := _dictionary(life.get("glance", {}))
	var glance_gain := spring_gain(14, 0.7)
	if glance_gain < 0:
		return _unsupported("glance spring 無可證明的穩定界線")
	var glance_head := absf(float(glance.get("head", 0.2))) * amount * glance_gain
	_add(target, &"head", symmetric(glance_head))
	_add(target, &"neck", symmetric(glance_head * 0.25))
	_add(target, &"chest", symmetric(glance_head * 0.12))
	var breath := _dictionary(life.get("breath", {}))
	_add(target, &"chest", symmetric(float(m["idle"]["breath_amp"]) * (1 + absf(float(breath.get("sigh_amp", 1.8))) * amount)))
	y += symmetric(float(m["idle"]["hip_bob"])) + Vector2(-0.3, 0.0)
	var beat := _dictionary(life.get("beat", {}))
	_add(target, &"arm_front_upper", pulse(-float(beat.get("gesture", 0.35)) * amount))
	_add(target, &"arm_front_lower", pulse(-float(beat.get("gesture", 0.35)) * amount * 0.8))
	_add(target, &"head", pulse(-0.04 * amount) + pulse(float(beat.get("nod", 0.07)) * amount))
	_add(target, &"chest", pulse(-float(beat.get("inhale_amp", 0.05)) * amount) + pulse(float(beat.get("settle_amp", 0.03)) * amount))
	var loop := actor._input.npc_loop
	if loop != &"":
		var loops := _dictionary(data.get("loops", {}))
		if not loops.get(str(loop)) is Dictionary:
			return _unsupported("未知循環 %s" % loop)
		_add_bones(target, loops[str(loop)].get("bones", {}))
		_add_tracks(target, loops[str(loop)].get("tracks", []), actor._input.npc_loop_scale)
	# 完整淡入淡出權重 [0,1]，同 context 已含 talk/listen/wave 的生命感與餘勢。
	for overlay_name in ["talk", "listen", "wave"]:
		var overlay := _dictionary(_dictionary(data.get("overlays", {})).get(overlay_name, {}))
		var values: Dictionary[StringName, Vector2] = {}
		_add_bones(values, overlay.get("bones", {}))
		_add_tracks(values, overlay.get("tracks", []), float(m["npc"]["talk_amp"]) if overlay_name == "talk" else 1.0)
		# wave 只有當本次/歷史 context 確實揮手才加入，避免把普通待機當全揮手。
		if overlay_name == "wave" and actor.pose != &"wave":
			continue
		for name in values:
			_add(target, name, union_interval(Vector2.ZERO, values[name]))
	x += target.get(&"_hip_x", Vector2.ZERO)
	y += target.get(&"_hip_y", Vector2.ZERO)
	_hip_x = union_interval(_hip_x, x)
	_hip_y = union_interval(_hip_y, y)
	var feet := _dictionary(base.get("feet", {}))
	if not feet.is_empty():
		var reach := float(feet.get("reach", 0.98))
		var sag := float(feet.get("sag", 0))
		if not is_finite(reach) or not is_finite(sag) or reach < 0 or reach > 1 or sag < 0:
			return _unsupported("NPC feet 負 sag／超長 reach")
		_feet_ik = true
		var raw_xs: Variant = feet.get("x", [0.0, 0.0])
		var xs: Array = raw_xs if raw_xs is Array else [0.0, 0.0]
		var thigh := _rig.rest(&"leg_front_lower").length()
		var length := _rig.animator._leg_length
		var drop := sag * length
		if not is_finite(length) or length <= 0 or not is_finite(drop):
			return _unsupported("NPC feet 的腿長／sag 不是有限正值")
		for i in HumanoidAnimator.LEG_CHAINS.size():
			var upper: StringName = HumanoidAnimator.LEG_CHAINS[i][0]
			var value := float(xs[i]) * thigh if xs.size() > i else 0.0
			if not is_finite(value):
				return _unsupported("NPC feet x 不是有限值")
			_feet_x[upper] = union_interval(_feet_x.get(upper, Vector2.ONE * value), Vector2.ONE * value)
			drop = maxf(drop, length - sqrt(maxf(0, pow(length * reach, 2) - value * value)))
		# _post_pose: 每格從0以feet_w∈[0,1]混到非負drop；舊feet還會淡出。
		drop = minf(drop, HumanoidAnimator.GROUND_MAX_SHIFT)
		_ground_extra = union_interval(_ground_extra, Vector2(0, drop))
	# 無feet的old_k且grounding=false只保留0；不憑空套用±16。
	_plant_ground = _plant_ground or bool(m["grounding"])
	var follow := _dictionary(life.get("follow", {}))
	for name in target:
		if str(name).begins_with("_") or not follow.get(str(name)) is Dictionary:
			continue
		var config: Dictionary = follow[str(name)]
		var gain := spring_gain(float(config.get("w", 14)), float(config.get("z", 0.6)))
		if gain < 0:
			return _unsupported("follow %s 無可證明的穩定界線" % name)
		var range_value := union_interval(_follow_targets.get(name, target[name]), target[name])
		_follow_targets[name] = range_value
		target[name] = follow_interval(range_value, gain)
	return true


func _human_target(actor: CutsceneActor, m: Dictionary, target: Dictionary[StringName, Vector2]) -> bool:
	var idle: Dictionary = m["idle"]
	var move: Dictionary = m["move"]
	var chest := Vector2(float(idle["chest"]), float(idle["chest"])) + symmetric(absf(float(idle["breath_amp"])) + absf(float(idle["counter"])))
	var x := symmetric(float(idle["sway"]))
	var y := symmetric(float(idle["hip_bob"]))
	var moving := actor.pose in [&"walk", &"run"]
	if not is_finite(actor._input.run_speed) or not is_finite(float(move["threshold"])):
		return _unsupported("human速度/idle門檻非有限，不能判定pin資格")
	var legs: Array = idle["legs"]
	var leg_ik := bool(m["grounding"]) and ((moving and actor.pose != &"jump") or bool(idle["pin_feet"]))
	if moving:
		chest = union_interval(chest, symmetric(float(move["chest_lean"]) * 1.3))
		# grounded _body_pose 把_hip_y設0；hip_bounce只在非grounding自由腿分支。
		# 低速human idle仍可達，因此保留idle的sway/hip_bob，不假設Tween速度永恆固定。
		if not bool(m["grounding"]):
			y = union_interval(y, symmetric(float(move["hip_bounce"]) * float(move["swing"])))
	elif actor.pose == &"crouch":
		chest = Vector2.ONE * float(m["crouch"]["chest"])
		y = Vector2.ONE * float(m["crouch"]["hip_drop"])
		legs = m["crouch"]["legs"]
		leg_ik = false
	elif actor.pose == &"jump":
		# CutsceneActor 固定 vy=-120，不發 jumped 事件；air.apex_speed>120 時會混入 apex。
		# 不把每個 jump 都假定為完整 rise，也不捏造 takeoff/land 事件。
		var air: Dictionary = m["air"]
		var rise: Dictionary = air["rise"]
		var weight := 1.0 if float(air["apex_speed"]) <= 0 else clampf(120.0 / float(air["apex_speed"]), 0.0, 1.0)
		chest = Vector2.ONE * lerpf(float(air["apex"]["chest"]), float(rise["chest"]), weight)
		legs = []
		for i in 4:
			legs.append(lerpf(float(air["apex"]["legs"][i]), float(rise["legs"][i]), weight))
		leg_ik = false
	elif actor.pose == &"block":
		chest += Vector2.ONE * float(m["block"]["chest"])
		legs = m["block"]["legs"]
		leg_ik = false
	chest += symmetric(float(m["inertia"]["max"])) if float(m["inertia"]["gain"]) > 0 else Vector2.ZERO
	var aim := -PI / 4.0 if actor.pose == &"aim_up" else 0.0
	chest += Vector2.ONE * aim * float(m["look"]["chest"])
	target[&"chest"] = chest
	target[&"neck"] = Vector2.ONE * aim * float(m["look"]["neck"])
	target[&"head"] = Vector2.ONE * clampf(aim * float(m["look"]["head"]), float(m["look"]["head_min"]), float(m["look"]["head_max"]))
	# 真gait才可能提高_run_w；之後即使回NPC仍保留這組附加角度。
	# 不能把overlay加進human target後取NPC聯集；它是每格body角度上的Minkowski sum。
	if moving and bool(m["grounding"]):
		var torso: Dictionary = m["torso"]
		var hip_swing := absf(float(torso["hip_swing"]))
		var chest_wobble := hip_swing * absf(float(torso["chest_counter"])) + absf(float(torso["chest_wobble"]))
		_run_overlay[&"hip"] = symmetric(hip_swing)
		_run_overlay[&"chest"] = symmetric(chest_wobble)
		_run_overlay[&"head"] = symmetric((hip_swing + chest_wobble) * float(torso["head_hold"]))
	if legs.size() != 4:
		return _unsupported("human legs 不是四個角度")
	_human_feet_ik = _human_feet_ik or leg_ik
	for i in HumanoidAnimator.LEGS.size():
		var name: StringName = HumanoidAnimator.LEGS[i]
		# _reach_leg只改Bone2D，不回寫animator._angles。grounded gait保留先前raw腿角；
		# walk/run的低速human idle另會寫idle.legs。取聯集後保留在_targets，而非寫入FULL。
		target[name] = Vector2.ONE * float(legs[i])
		if moving and not bool(m["grounding"]):
			var swing := absf(float(move["swing"]))
			target[name] = symmetric(swing) if i % 2 == 0 else Vector2.ONE * float(move["knee_base"]) + union_interval(Vector2.ZERO, Vector2.ONE * float(move["knee_bend"]) * swing)
	for upper: StringName in [&"arm_front_upper", &"arm_back_upper"]:
		target[upper] = FULL if not _rig.weapon_def().is_empty() else Vector2(-0.2, 0.6)
	for lower: StringName in [&"arm_front_lower", &"arm_back_lower"]:
		target[lower] = FULL if not _rig.weapon_def().is_empty() else Vector2(-0.3, -0.3)
	for hand: StringName in [&"hand_front", &"hand_back"]:
		target[hand] = FULL if not _rig.weapon_def().is_empty() else Vector2.ONE * HumanoidAnimator.HAND_FOLLOWS_FOREARM
	_hip_x = union_interval(_hip_x, x)
	_hip_y = union_interval(_hip_y, y)
	# 無on_floor的jump不啟新plant/pin/gait；已存在NPC feet/餘勢的各支路仍永久保留。
	if bool(m["grounding"]) and actor.pose != &"jump":
		_plant_ground = true
		if moving and not _include_gait_ground(m):
			return false
		# 非two_handed的_is_npc_state門檻是speed<1；two_handed即使零速仍走human。
		# walk也可能有1<=speed<=threshold*run_speed的真idle/pin；不能只看欄位，
		# 更不能把正式Tween預測速度當每格速度的連續證書。
		var human_idle := actor.pose not in [&"crouch", &"block"] and (not moving \
			or actor._input.two_handed or float(move["threshold"]) * maxf(1, actor._input.run_speed) >= 1)
		_pin_ground = _pin_ground or (human_idle and bool(idle["pin_feet"]))
	return true


## _body_pose將speed_ratio clamp至[0,1.3]。這裡涵蓋全部速度，而非只依move預測值。
## amp_now是初態0與歷史amp的凸組合；NPC回程level/floor重設後仍有amp/lift/reach餘勢。
func _include_gait_ground(m: Dictionary) -> bool:
	var move: Dictionary = m["move"]
	var length := _rig.animator._leg_length
	for field: String in ["stride", "stride_exp", "stride_floor", "duty", "lift", "reach", "rise", "bounce", "bob_slow", "level"]:
		if not is_finite(float(move[field])):
			return _unsupported("gait %s非有限，不能推導drop" % field)
	if not is_finite(length) or length <= 0 or float(move["lift"]) < 0 \
			or (float(move["stride_exp"]) > 0 and (float(move["stride_floor"]) < 0 or float(move["stride_floor"]) > 1)):
		return _unsupported("gait腿長/lift/stride_floor超出來源界線")
	var stride := maxf(8, float(move["stride"]))
	var duty := clampf(maxf(HumanoidAnimator.WALK_DUTY, float(move["duty"])), 0.3, 0.8)
	var amplitude := minf(stride * duty * 0.5, length * 0.75)
	var reach := length * clampf(float(move["reach"]), 0.7, 1)
	var required := length - sqrt(maxf(0, reach * reach - amplitude * amplitude))
	var low := minf(0, minf(-float(move["rise"]), float(move["bounce"])))
	var high := maxf(HumanoidAnimator.GAIT_MIN_SAG, maxf(required, maxf(-float(move["rise"]), float(move["bounce"]))))
	if float(move["level"]) > 0:
		var slow := maxf(1, absf(float(move["bob_slow"])))
		# body_sag是[-rise*flight*slow,bounce*slow]端點間的凸值。
		# 若資料slow為負，以端點絕對值給安全界，不捏造正常資料的margin。
		var bob_low := -maxf(absf(float(move["rise"])), absf(float(move["bounce"]))) * slow
		var bob_high := -bob_low
		if float(move["bob_slow"]) >= 0 and float(move["rise"]) >= 0 and float(move["bounce"]) >= 0:
			bob_low = -float(move["rise"]) * slow
			bob_high = float(move["bounce"]) * slow
		low = minf(0, HumanoidAnimator.GAIT_MIN_SAG + bob_low)
		high = maxf(HumanoidAnimator.GAIT_MIN_SAG, required) + bob_high
	# offset.y=lift*sin(PI*t)>=0，故drop的offset項<=required；fade的floor fallback為1。
	# CutsceneActor從fresh setup播放且不送land事件，extra_sag=0；未知事件不能套這個來源契約。
	var limit := HumanoidAnimator.GROUND_MAX_SHIFT
	_gait_ground = union_interval(_gait_ground, Vector2(minf(low, limit), minf(high, limit)))
	return true


## HumanoidAnimator._plant_feet 用 max(front ankle.y,back ankle.y) 與 clamp 的單調性。
## 每格 ground先歸0；歷史角度／hip_offset均已聯集，故此輸入界線涵蓋任何過渡。
func _derive_ground() -> bool:
	_ground = union_interval(union_interval(Vector2.ZERO, _ground_extra), _gait_ground)
	if _pin_ground and not _include_pin_ground():
		return false
	if not _plant_ground:
		return true
	if not _positions.has(&"foot_front") or not _positions.has(&"foot_back"):
		return _unsupported("接地分支缺少兩個 ankle，不能推導零位移 FK")
	var front := _positions[&"foot_front"]
	var back := _positions[&"foot_back"]
	var floor_y := _rig.animator.ground_level()
	if not is_finite(floor_y) or not front.position.is_finite() or not front.end.is_finite() \
			or not back.position.is_finite() or not back.end.is_finite():
		return _unsupported("接地 ankle／floor 非有限")
	var lowest_min := maxf(front.position.y, back.position.y)
	var lowest_max := maxf(front.end.y, back.end.y)
	var limit := HumanoidAnimator.GROUND_MAX_SHIFT
	var needed := Vector2(clampf(floor_y - lowest_max, -limit, limit), clampf(floor_y - lowest_min, -limit, limit))
	_ground = union_interval(_ground, needed)
	return true


## _record_idle_feet在setup記下固定x。_pin_feet的offset.y=0，floor_sag=0，
## drop=max(0,L-sqrt((L*reach)^2-offset.x^2))；blend_shift沿既有ground與drop取凸值。
## upper.x只依raw hip transform，與ground的垂直位移/腿IK無關，可用零ground FK計算。
func _include_pin_ground() -> bool:
	var idle: Dictionary = _rig.animator._motion["idle"]
	var length := _rig.animator._leg_length
	var reach := float(idle["pin_reach"]) * length
	if not is_finite(length) or length <= 0 or not is_finite(reach) or reach < 0:
		return _unsupported("idle pin腿長/reach非有限或負值")
	var drop := 0.0
	for i in HumanoidAnimator.LEG_CHAINS.size():
		var upper: StringName = HumanoidAnimator.LEG_CHAINS[i][0]
		if not _positions.has(upper):
			return _unsupported("idle pin缺少upper骨頭")
		var fixed_x := float(_rig.animator._idle_foot_x[i])
		var hip: Rect2 = _positions[upper]
		if not is_finite(fixed_x) or not hip.position.is_finite() or not hip.end.is_finite():
			return _unsupported("idle pin固定腳/hip非有限")
		var offset := maxf(absf(fixed_x - hip.position.x), absf(fixed_x - hip.end.x))
		drop = maxf(drop, length - sqrt(maxf(0, reach * reach - offset * offset)))
	drop = minf(drop, HumanoidAnimator.GROUND_MAX_SHIFT)
	_ground = union_interval(_ground, Vector2(0, drop))
	return true


func _build_fk(apply_ground := true, apply_ik := true) -> void:
	_angles.clear()
	_positions.clear()
	full_rotation_channels.clear()
	_knee_range.clear()
	for name in _rig.bone_order():
		var local: Vector2 = _targets.get(name, Vector2.ZERO)
		# NE221 _apply_body：raw _angles + overlay + secondary spring。
		# 每次先重設全部body骨角再加一次spring，不因plant/pin重算而累加。
		local += _run_overlay.get(name, Vector2.ZERO)
		local += _secondary_springs.get(name, Vector2.ZERO)
		# 最終輪廓保留human IK的FULL腿/腳，以及全部過渡歷史；不以採樣或角錐縮輪廓。
		# apply_ik=false的零ground FK只用raw _angles，不受post-pose Bone2D旋轉污染。
		if apply_ik and _human_feet_ik and name in HumanoidAnimator.LEGS:
			local = FULL
		if apply_ik and (_feet_ik or _human_feet_ik) and name in [&"foot_front", &"foot_back"]:
			local = FULL
		if not local.is_finite():
			_unsupported("骨頭 %s 非有限目標" % name)
			return
		var parent := _rig.parent_of(name)
		var parent_angle: Vector2 = _angles.get(parent, Vector2.ZERO)
		var rest := _rig.rest(name)
		if not rest.is_finite() or _rig.bone(name).scale != Vector2.ONE or _rig.bone(name).skew != 0:
			_unsupported("骨頭 %s rest／scale 不受支援" % name)
			return
		var position := Rect2(rest, Vector2.ZERO) if parent == &"" else add_rect(_positions[parent], rotated_point(rest, parent_angle))
		if name == &"hip":
			var ground := _ground if apply_ground else Vector2.ZERO
			position = add_rect(position, Rect2(Vector2(_hip_x.x, _hip_y.x + ground.x), Vector2(_hip_x.y - _hip_x.x, _hip_y.y + ground.y - _hip_y.x - ground.x)))
		if apply_ik and _feet_ik and _feet_x.has(name):
			local = union_interval(local, _npc_leg_upper(name, position, parent_angle))
		elif _knee_range.has(name):
			local = union_interval(local, _knee_range[name])
		# lerp_angle 選最短路徑。跨度>=PI 無法以單一線性區間保證，明列全旋轉原因。
		if local.y - local.x >= PI:
			local = FULL
			full_rotation_channels.append(str(name))
		_angles[name] = parent_angle + local
		_positions[name] = position


## NpcAnimator._place_feet：目標相對髖為固定 x 和 ground_y-hip.y；不能把坐姿膝蓋當任意轉圈。
## 上腿方向=atan2(target)-acos(cos_alpha)，下腿相對彎角是 [0,acos(cos_knee)]。
## 超出可達距離時原 IK clamp 只減少彎曲；涵蓋 before/after 最短弧淡入淡出。
func _npc_leg_upper(upper: StringName, hip: Rect2, parent_angle: Vector2) -> Vector2:
	var chain: Array = HumanoidAnimator.LEG_CHAINS[0] if upper == &"leg_front_upper" else HumanoidAnimator.LEG_CHAINS[1]
	var lower: StringName = chain[1]
	var foot: StringName = chain[2]
	var lu := _rig.rest(lower).length()
	var ll := _rig.rest(foot).length()
	var xs: Vector2 = _feet_x[upper]
	var floor_y := _rig.animator.ground_level()
	var delta := Rect2(Vector2(xs.x, floor_y - hip.end.y), Vector2(xs.y - xs.x, hip.size.y))
	if lu <= 0 or ll <= 0 or delta.position.y <= 0 or not delta.end.is_finite():
		_knee_range[lower] = FULL
		return FULL # 目標穿過髖或壞鏈沒有單一 atan2 區間，明列此鏈不支援緊界線。
	var dx_min := 0.0 if xs.x <= 0 and xs.y >= 0 else minf(absf(xs.x), absf(xs.y))
	var dx_max := maxf(absf(xs.x), absf(xs.y))
	var d_min := clampf(Vector2(dx_min, delta.position.y).length(), 0.01, lu + ll - 0.01)
	var d_max := clampf(Vector2(dx_max, delta.end.y).length(), 0.01, lu + ll - 0.01)
	var c_min := minf(_cos_alpha(d_min, lu, ll), _cos_alpha(d_max, lu, ll))
	var critical := sqrt(maxf(0, lu * lu - ll * ll))
	if critical > d_min and critical < d_max:
		c_min = minf(c_min, _cos_alpha(critical, lu, ll))
	var alpha_max := acos(clampf(c_min, -1, 1))
	var base := atan_interval(delta)
	_knee_range[lower] = Vector2(0, acos(clampf((d_min * d_min - lu * lu - ll * ll) / (2 * lu * ll), -1, 1)))
	return Vector2(base.x - alpha_max - PI / 2 - parent_angle.y, base.y - PI / 2 - parent_angle.x)


static func _cos_alpha(distance: float, upper: float, lower: float) -> float:
	return (upper * upper + distance * distance - lower * lower) / (2 * upper * distance)


static func atan_interval(rect: Rect2) -> Vector2:
	var result := Vector2(INF, -INF)
	for point in [rect.position, Vector2(rect.end.x, rect.position.y), rect.end, Vector2(rect.position.x, rect.end.y)]:
		var angle: float = point.angle()
		result.x = minf(result.x, angle)
		result.y = maxf(result.y, angle)
	return result


func _sprite_bounds(sprite: Sprite2D) -> Rect2:
	if sprite.texture == null:
		return Rect2()
	var parent := sprite.get_parent() as Bone2D
	if parent == null:
		_unsupported("sprite 未直接掛在 bone")
		return Rect2()
	return _attachment_bounds(StringName(parent.name), sprite.get_rect(), sprite.transform)


func _attachment_bounds(bone: StringName, rect: Rect2, transform: Transform2D) -> Rect2:
	var result := rotated_point(transform * rect.position, _angles[bone])
	result = result.merge(rotated_point(transform * Vector2(rect.end.x, rect.position.y), _angles[bone]))
	result = result.merge(rotated_point(transform * rect.end, _angles[bone]))
	result = result.merge(rotated_point(transform * Vector2(rect.position.x, rect.end.y), _angles[bone]))
	return add_rect(_positions[bone], result)


func _mesh_bounds(mesh: RigPartMesh) -> Rect2:
	if RigPartMesh.volume_keep < 0 or RigPartMesh.volume_keep > 1:
		_unsupported("volume_keep 不在厚度凸界線[0,1]")
		return Rect2()
	var self_name := StringName(mesh._self_bone.name)
	var partner := StringName(mesh._partner.name)
	var result := Rect2()
	var first := true
	for point in mesh.rest_vertices():
		var v: Vector2 = mesh.transform * point
		var rigid := add_rect(_positions[self_name], rotated_point(v, _angles[self_name]))
		result = rigid if first else result.merge(rigid)
		first = false
	for v in mesh._zone_rest:
		var axis := Vector2(mesh._axis_x, v.y)
		var a := add_rect(_positions[self_name], rotated_point(axis, _angles[self_name]))
		var relative: Vector2 = axis - mesh._partner_rest if mesh._partner_is_child else axis + mesh._self_rest
		var b := add_rect(_positions[partner], rotated_point(relative, _angles[partner]))
		# moved_axis 凸組合；offset 經 volume_keep[0,1] 修正後長度<=原厚度，所有方向都在圓內。
		result = result.merge(a.merge(b).grow(absf(v.x - mesh._axis_x)))
	if mesh._root_partner != null:
		var root_name := StringName(mesh._root_partner.name)
		for v in mesh._root_points:
			var axis := Vector2(0, v.y)
			var a := add_rect(_positions[self_name], rotated_point(axis, _angles[self_name]))
			var b := add_rect(_positions[root_name], rotated_point(mesh._root_origin + axis, _angles[root_name]))
			result = result.merge(a.merge(b).grow(absf(v.x)))
	return result


func _weapon_bounds() -> Rect2:
	# No action/recoil inputs in CutsceneActor. Grip may be reach-clamped by shoulders;
	# anchor/hand convex union encloses either clamp result, then weapon canvas rotates about grip.
	var anchor := _rig.weapon_anchor()
	var bone: StringName = anchor[0]
	var origin := add_rect(_positions[bone], rotated_point(anchor[1], _angles[bone])).grow(absf(float(anchor[2])))
	for hand: StringName in [&"hand_front", &"hand_back"]:
		if _positions.has(hand):
			origin = origin.merge(_positions[hand].grow(_grip_radius(hand)))
	if _positions.has(&"arm_front_upper"):
		var length := _rig.rest(&"arm_front_lower").length() + _rig.rest(&"hand_front").length()
		origin = origin.merge(_positions[&"arm_front_upper"].grow(length + _grip_radius(&"hand_front")))
	var sprite := _rig._weapon_sprite
	var rect := sprite.get_rect()
	var radius := 0.0
	for p in [rect.position, Vector2(rect.end.x, rect.position.y), rect.end, Vector2(rect.position.x, rect.end.y)]:
		radius = maxf(radius, (sprite.transform * p).length())
	return origin.grow(radius)


func _grip_radius(hand: StringName) -> float:
	var radius := _rig.hand_grip_offset(hand).length()
	for grip in _rig._hand_grips:
		if grip["bone"] == hand:
			radius = maxf(radius, (grip["offset"] as Vector2).length())
	return radius


## 工具事件讀取副本；不用把 Node／animator／token 交給 Story 或存檔。
func diagnostics() -> Dictionary:
	return {"supported": supported, "reason": reason, "bounds": bounds, "contexts": contexts,
		"full_rotation_channels": full_rotation_channels.duplicate(), "angles": _angles.duplicate(),
		"targets": _targets.duplicate(), "hip_x": _hip_x, "hip_y": _hip_y, "ground_shift": _ground,
		"ground_extra": _ground_extra, "gait_ground": _gait_ground, "pin_ground": _pin_ground, "plant_ground": _plant_ground, "follow_raw_history": _follow_targets.duplicate(),
		"run_overlay": _run_overlay.duplicate(), "secondary_springs": _secondary_springs.duplicate()}


func _merge(total: Rect2, next: Rect2) -> Rect2:
	if _first:
		_first = false
		return next
	return total.merge(next)


func _unsupported(message: String) -> bool:
	supported = false
	reason = message
	return false


static func symmetric(value: float) -> Vector2:
	return Vector2(-absf(value), absf(value))


static func pulse(value: float) -> Vector2:
	return Vector2(minf(0, value), maxf(0, value))


static func union_interval(a: Vector2, b: Vector2) -> Vector2:
	return Vector2(minf(a.x, b.x), maxf(a.y, b.y))


static func add_rect(a: Rect2, b: Rect2) -> Rect2:
	return Rect2(a.position + b.position, a.size + b.size)


## 閉區間內包含端點及所有 sin/cos 極值；不是角度網格取樣。
static func rotated_point(point: Vector2, angles: Vector2) -> Rect2:
	var length := point.length()
	var from := angles.x + point.angle()
	var to := angles.y + point.angle()
	if to - from >= TAU:
		return Rect2(Vector2.ONE * -length, Vector2.ONE * length * 2)
	var a := Vector2.from_angle(from) * length
	var b := Vector2.from_angle(to) * length
	var out := Rect2(a, Vector2.ZERO).expand(b)
	for i in range(ceili(from / (PI / 2)), floori(to / (PI / 2)) + 1):
		out = out.expand(Vector2.from_angle(i * PI / 2) * length)
	return out


static func _add(target: Dictionary[StringName, Vector2], name: StringName, value: Vector2) -> void:
	target[name] = target.get(name, Vector2.ZERO) + value


static func _dictionary(value: Variant) -> Dictionary:
	return value if value is Dictionary else {}


static func _add_bones(target: Dictionary[StringName, Vector2], bones: Variant) -> void:
	if not bones is Dictionary:
		return
	for name in bones:
		_add(target, StringName(str(name)), Vector2.ONE * float(bones[name]))


static func _add_tracks(target: Dictionary[StringName, Vector2], tracks: Variant, amplitude: float) -> void:
	if not tracks is Array:
		return
	for raw: Variant in tracks:
		if not raw is Dictionary:
			continue
		var track: Dictionary = raw
		var value := Vector2.ONE * float(track.get("mean", 0)) + symmetric(float(track.get("amp", 0)) * amplitude)
		if bool(track.get("gated", false)) or bool(track.get("inv", false)):
			value = union_interval(value, Vector2.ZERO) # gate/source factor is always in[0,1]
		_add(target, StringName(str(track.get("bone", ""))), value)


## raw為永久聯集[l,h]。K(m,r)=(m,0)+rP；P含[-1,1]×{0}且convex。
## 新區間包含舊區間⇒|Δm|≤r_new-r_old；舊normalized state是舊P與初態segment的convex組合，
## 因此recenter同時保留位置與v/omega；NPC→human停用life時只凍結，不重設raw history。
static func follow_interval(raw: Vector2, gain: float) -> Vector2:
	var middle := (raw.x + raw.y) * 0.5
	return Vector2.ONE * middle + symmetric((raw.y - raw.x) * 0.5 * gain)


## Semi-implicit spring, a=w*h<=w/60; P solves continuous M'P+PM=-I.
## D(a)=(P-A'PA)/a is cubic. 32 interval boxes bound every a, not sampled stability.
## D>=dI => ||A||P<=sqrt(1-a*d/lambda_max(P)); forcing ||B||P<=a*b.
## invariant radius=2*lambda_max*b/d; converts to an x bound via (P^-1)xx.
## -1 means no certified finite gain. Unknown/high-rate data preserves author camera.
static func spring_gain(omega: float, zeta: float) -> float:
	# 精確128頂點有理不變多邊形，u∈[-1,1]、h∈[0,1/60]。
	# CPU證書逐facet/vertex/u±/z端點及整個a區間quadratic極值，gain向外取6位。
	# exact w/z比對；JSON float是double。Vector2量化後的其他參數不可借用此表。
	# 證書SHA（12/.6,14/.5,14/.7,16/.55,18/.5）：
	# 6071a425dddd535eec162739e8355dd9a53264ada28ef1593e40de951f70eed2
	# 3963c9d626b98e840949b616198a7d14d412eba1cbd9d4829fba347045a5d89f
	# 9e414f6abafa1ea882bb81a68bfa99d72426c062ed7b572e210b9039d29688b8
	# e655692d1fc181863967ac87ac4cd0cb044a007e6375d9d58b136c7e863a85ff
	# b425ab10c4fca7abc0cb9eb182985852ae9865abb74ce58b89c69363c4b17678
	if omega == 12.0 and zeta == 0.6:
		return 1.285220
	if omega == 14.0 and zeta == 0.5:
		return 1.528997
	if omega == 14.0 and zeta == 0.7:
		return 1.142133
	if omega == 16.0 and zeta == 0.55:
		return 1.407771
	if omega == 18.0 and zeta == 0.5:
		return 1.555079
	if not is_finite(omega) or not is_finite(zeta) or omega <= 0 or zeta <= 0:
		return -1.0
	var p := zeta + 1.0 / (2.0 * zeta)
	var r := 1.0 / (2.0 * zeta)
	var p_max := (p + r + sqrt((p - r) * (p - r) + 1.0)) * 0.5
	var det := p * r - 0.25
	var a_max := omega * NpcLife.MAX_STEP
	if not is_finite(a_max) or a_max > 1.0 or det <= 0:
		return -1.0
	var d := INF
	# Coefficients are the exact symbolic product of the source integrator's 2x2 matrix.
	var c11 := Vector3(2 * p - r, -1.0, -p)
	var c12 := Vector3(2 * zeta * p, p - 2 * zeta, -2 * zeta * p)
	var c22 := Vector3(2 * zeta - p, 2.0, -4 * zeta * zeta * p)
	for i in 32:
		var lo := a_max * i / 32.0
		var hi := a_max * (i + 1) / 32.0
		var d11 := _polynomial_range(1, c11, lo, hi)
		var d12 := _polynomial_range(0, c12, lo, hi)
		var d22 := _polynomial_range(1, c22, lo, hi)
		var off := maxf(absf(d12.x), absf(d12.y))
		# exact eigenvalue lower bound for interval symmetric matrix: smallest diagonals, largest |off|
		d = minf(d, (d11.x + d22.x - sqrt(pow(d11.x - d22.x, 2) + 4 * off * off)) * 0.5)
	if d <= 0 or not is_finite(d):
		return -1.0
	var b := sqrt(p * a_max * a_max + a_max + r)
	var gain := 2 * p_max * b / d * sqrt(r / det)
	return maxf(1.0, gain) if is_finite(gain) else -1.0


static func _polynomial_range(constant: float, coefficients: Vector3, lo: float, hi: float) -> Vector2:
	var result := Vector2.ONE * constant
	for power in 3:
		var a := coefficients[power] * pow(lo, power + 1)
		var b := coefficients[power] * pow(hi, power + 1)
		result += Vector2(minf(a, b), maxf(a, b))
	return result
