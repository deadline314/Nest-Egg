class_name CutscenePlayer
extends CanvasLayer
## 過場動畫播放器：依資料檔的步驟（scene、camera、actor、move、say、fx、title…）逐步演出。
## 演出時暫停遊戲，結束後還原暫停狀態與滑鼠模式。Esc 跳過整段；確認鍵／射擊／點擊推進台詞。
## 任何壞掉的步驟只記錄「場景 id 第 n 步」的錯誤並略過，不會卡住遊戲。
##
## 步驟一覽見 CutsceneChecker.STEP_FIELDS；資料格式說明在 design/10-presentation/DESIGN.md。

signal finished(scene_id: StringName)

const LAYER := UiLayers.CUTSCENE
const SCREEN := Vector2(640, 360)
const CENTER := Vector2(320, 180)
const NOISE_SHADER := "res://ui/transition/transition.gdshader"
const TITLE_FADE := 0.5
## 效果層（色調、閃光、雜訊、淡入淡出、黑邊、字幕、對話）的 z_index 起點，需高於任何角色零件。
const EFFECT_Z := 200

var scene_id: StringName = &""
## 播放速度倍率（測試用；1 = 正常）。
var speed := 1.0
## 本段跳過（Esc 或設定要求）。
var skipping := false
## 玩家主動按了略過（與 end 步驟或播完不同；接續的場景據此一併略過）。
var user_skipped := false
var steps_run := 0

var cam_pos: Vector2 = CENTER:
	set(value):
		cam_pos = value
		_apply_camera()
var cam_zoom: float = 1.0:
	set(value):
		cam_zoom = maxf(0.1, value)
		_apply_camera()

var _steps: Array = []
var _handlers: Dictionary[String, Callable] = {}
var _stage: StageLibrary.Stage
var _stage_holder: Node2D
var _actors: Dictionary[StringName, CutsceneActor] = {}
var _root: Control
var _dialogue: CutsceneDialogue
var _fade: ColorRect
var _tint: ColorRect
var _flash: ColorRect
var _noise: ColorRect
var _center_text: Label
var _center_sub: Label
var _skip_hint: Label
var _advance_requested := false
var _shake := 0.0
var _shake_time := 0.0
var _running := false
var _lock_token := 0
var _framing_token := 0
var _tweens: Array[Tween] = []
## 疊加模式：不蓋黑底、不放舞台，直接在遊戲畫面上演出（右臂雜訊、警報等短演出）。
var _overlay_mode := false
## 目前執行的步驟位置（錯誤訊息用）與下一步是否也是台詞（決定要不要收起對話框）。
var _current_where := ""
var _next_is_say := false
var _choice: VBoxContainer
var _choice_options: Array[Dictionary] = []
var _chosen := -1
var _pending_steps: Array = []
## 作者 cam_pos/cam_zoom 保持原 Tween 軌跡；只將有效鏡頭投影到事件快取的可行集合。
var effective_cam_pos := CENTER
var effective_cam_zoom := 1.0
var _framing_plan: StageFramingPlan
var _pose_envelopes: Dictionary[StringName, StagePoseEnvelope] = {}
var _actor_origins: Dictionary[StringName, Rect2] = {}
var _actor_facings: Dictionary[StringName, int] = {}
var _actor_motion: Dictionary[StringName, int] = {}
var _motion_serial := 0
var _framing_art := Rect2()
var _framing_supported := false
var _framing_reason := ""
var _framing_warnings: Dictionary[String, bool] = {}



func _init() -> void:
	layer = LAYER
	process_mode = Node.PROCESS_MODE_ALWAYS
	_handlers = {
		"scene": _do_scene, "letterbox": _do_letterbox, "camera": _do_camera, "actor": _do_actor,
		"pose": _do_pose, "move": _do_move, "face": _do_face, "remove": _do_remove, "say": _do_say,
		"narrate": _do_narrate, "title": _do_title, "fx": _do_fx, "sfx": _do_sfx, "wait": _do_wait,
		"fade": _do_fade, "transition": _do_transition, "end": _do_end,
		"choice": _do_choice, "branch": _do_branch,
	}


func is_running() -> bool:
	return _running


## 開始播放。scene 是場景資料（含 steps）。
func play(id: StringName, scene: Dictionary) -> void:
	if _running or not is_inside_tree():
		push_warning("[Cutscene] 播放器已在播放或不在場景樹中：%s" % id)
		return
	scene_id = id
	var raw: Variant = scene.get("steps", [])
	_steps = raw.duplicate(true) if typeof(raw) == TYPE_ARRAY else []
	_overlay_mode = bool(scene.get("overlay", false))
	_build_ui()
	if not _overlay_mode:
		_framing_token = Story.framing.acquire(self)
	Story.framing.safe_rect_changed.connect(_layout_safe_rect)
	InputBindings.bindings_changed.connect(_refresh_skip_hint)
	_layout_safe_rect(Story.framing.safe_rect())
	_lock_token = GameplayLock.acquire(self, Input.MOUSE_MODE_HIDDEN)
	Fx.reset_time()
	_running = true
	_run.call_deferred()


## 跳到結尾。
func skip() -> void:
	user_skipped = true
	skipping = true
	_advance_requested = true


func _run() -> void:
	if not _running or not is_inside_tree():
		return
	var index := 0
	while index < _steps.size():
		var raw: Variant = _steps[index]
		index += 1
		if skipping:
			Story.apply_default_choices({"steps": _steps.slice(index - 1)})
			break
		if typeof(raw) != TYPE_DICTIONARY:
			push_error("[Cutscene] 場景 %s 第 %d 步不是物件，已略過" % [scene_id, index])
			continue
		var step: Dictionary = raw
		var kind := str(step.get("do", ""))
		if kind == "end":
			break
		var handler: Callable = _handlers.get(kind, Callable())
		if not handler.is_valid():
			push_error("[Cutscene] 場景 %s 第 %d 步的動作「%s」不存在，已略過" % [scene_id, index, kind])
			continue
		_current_where = "場景 %s 第 %d 步（%s）" % [scene_id, index, kind]
		_next_is_say = index < _steps.size() and typeof(_steps[index]) == TYPE_DICTIONARY \
				and str((_steps[index] as Dictionary).get("do", "")) == "say"
		await handler.call(step)
		if not _running or not is_inside_tree():
			return
		if not _pending_steps.is_empty():
			for offset in _pending_steps.size():
				_steps.insert(index + offset, _pending_steps[offset])
			_pending_steps.clear()
		steps_run += 1
	await _finish()



func _finish() -> void:
	if not _running:
		return
	for tween in _tweens:
		if tween != null and tween.is_valid():
			tween.kill()
	_running = false
	_root.visible = false
	Transition.abort_owned(self)
	GameplayLock.release(_lock_token)
	_lock_token = 0
	Story.framing.release(_framing_token)
	_framing_token = 0
	finished.emit(scene_id)
	queue_free()


func _exit_tree() -> void:
	_running = false
	skipping = true
	Transition.abort_owned(self)
	Story.framing.release(_framing_token)
	GameplayLock.release(_lock_token)
	for tween in _tweens:
		if tween != null and tween.is_valid():
			tween.kill()


## 中止不等同跳過：不套用尚未做出的選項、旗標或完成事件。
func cancel() -> void:
	_running = false
	skipping = true
	_advance_requested = true
	Transition.abort_owned(self)
	for tween in _tweens:
		if tween != null and tween.is_valid():
			tween.kill()
	GameplayLock.release(_lock_token)
	_lock_token = 0
	Story.framing.release(_framing_token)
	_framing_token = 0
	if is_instance_valid(_root):
		_root.hide()
	queue_free()


# ---------------------------------------------------------------------------
# 輸入
# ---------------------------------------------------------------------------

func _input(event: InputEvent) -> void:
	if not _running:
		return
	if choice_active():
		if event.is_action_pressed(&"ui_cancel") or event.is_action_pressed(&"pause"):
			skip()
			get_viewport().set_input_as_handled()
		return  # focused buttons handle keyboard, controller and pointer confirmation
	if event.is_action_pressed(&"pause") or event.is_action_pressed(&"ui_cancel"):
		skip()
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed(&"ui_accept") or event.is_action_pressed(&"shoot") or event.is_action_pressed(&"jump") \
			or (event is InputEventMouseButton and event.is_pressed() and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT):
		if _dialogue.visible and not _dialogue.is_complete():
			_dialogue.complete()
		else:
			_advance_requested = true
		get_viewport().set_input_as_handled()
	else:
		get_viewport().set_input_as_handled()


# ---------------------------------------------------------------------------
# 介面
# ---------------------------------------------------------------------------

func _build_ui() -> void:
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.theme = UiKit.theme()
	_root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_root)
	var backdrop := ColorRect.new()
	backdrop.color = Color(0, 0, 0, 0.0 if _overlay_mode else 1.0)
	backdrop.set_anchors_preset(Control.PRESET_FULL_RECT)
	backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
	backdrop.z_index = WorldLayers.STAGE_BACK - 100  # 舞台背景各層在 STAGE_BACK，黑底要再低一點才不會蓋住它們
	_root.add_child(backdrop)
	_stage_holder = Node2D.new()
	_root.add_child(_stage_holder)
	# 疊在舞台上的效果層（由下到上）：色調、閃光、雜訊、黑邊、淡入淡出、對話。
	_tint = _overlay(Color(0, 0, 0, 0))
	_flash = _overlay(Color(1, 1, 1, 0))
	_noise = _make_noise_rect()
	_fade = _overlay(Color(0, 0, 0, 0.0 if _overlay_mode else 1.0))
	_center_text = UiKit.label("", UiKit.FS_DISPLAY, Palette.UI_TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	_center_text.set_anchors_preset(Control.PRESET_FULL_RECT)
	_center_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_center_text.offset_top = -12
	_center_text.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	_center_text.modulate.a = 0.0
	_root.add_child(_center_text)
	_center_sub = UiKit.label("", UiKit.FS_BODY, Palette.UI_MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	_center_sub.set_anchors_preset(Control.PRESET_FULL_RECT)
	_center_sub.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_center_sub.offset_top = 36
	_center_sub.modulate.a = 0.0
	_root.add_child(_center_sub)
	_dialogue = CutsceneDialogue.new()
	_root.add_child(_dialogue)
	_skip_hint = UiKit.label(InputBindings.format("{ui_cancel} 跳過"), UiKit.FS_BODY, Palette.UI_MUTED, HORIZONTAL_ALIGNMENT_RIGHT)
	_skip_hint.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_skip_hint.offset_left = -110
	_skip_hint.offset_right = -10
	_skip_hint.offset_top = 6
	_root.add_child(_skip_hint)
	# 角色骨架的零件有自己的 z_index，會畫在同層的淡入淡出、黑邊與對話之上；效果層一律拉高。
	var z := EFFECT_Z
	for child in _root.get_children():
		if child != _stage_holder and child != _root.get_child(0):
			(child as CanvasItem).z_index = z
			z += 1


func _overlay(color: Color) -> ColorRect:
	var rect := ColorRect.new()
	rect.color = color
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(rect)
	return rect


func _make_noise_rect() -> ColorRect:
	var rect := ColorRect.new()
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rect.visible = false
	var shader := load(NOISE_SHADER) as Shader
	if shader != null:
		var material := ShaderMaterial.new()
		material.shader = shader
		material.set_shader_parameter(&"kind", int(Transition.Kind.GLITCH))
		material.set_shader_parameter(&"accent", Palette.MAGENTA)
		material.set_shader_parameter(&"aspect", SCREEN.x / SCREEN.y)
		rect.material = material
	_root.add_child(rect)
	return rect


func _apply_camera() -> void:
	if _stage_holder == null:
		return
	effective_cam_pos = cam_pos
	effective_cam_zoom = cam_zoom
	var shake := _shake_offset()
	if _framing_plan != null and _framing_plan.follow_author(cam_pos, cam_zoom):
		_framing_plan.constrain_shake(shake)
		effective_cam_pos = _framing_plan.camera_position
		effective_cam_zoom = _framing_plan.zoom
		shake = Vector2.ZERO # 已納入同一可行中心區間
	_stage_holder.scale = Vector2.ONE * effective_cam_zoom
	_stage_holder.position = get_viewport().get_visible_rect().size * 0.5 - effective_cam_pos * effective_cam_zoom + shake
	if _stage != null:
		_stage.apply_parallax(effective_cam_pos)


func _shake_offset() -> Vector2:
	if _shake <= 0.01:
		return Vector2.ZERO
	return Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * _shake


func _process(delta: float) -> void:
	if not _running:
		return
	if _shake_time > 0.0:
		_shake_time -= delta
		if _shake_time <= 0.0:
			_shake = 0.0
		_apply_camera()


func _new_tween() -> Tween:
	var tween := create_tween()
	tween.set_speed_scale(speed)
	_tweens.append(tween)
	return tween


## 等待秒數；被跳過時立刻返回。
func _wait_time(seconds: float) -> void:
	var left := seconds
	while left > 0.0 and not skipping and _running:
		await get_tree().process_frame
		left -= get_process_delta_time() * speed


func _wait_tween(tween: Tween) -> void:
	while tween.is_valid() and tween.is_running() and not skipping and _running:
		await get_tree().process_frame


func _need_actor(step: Dictionary) -> CutsceneActor:
	var id := StringName(str(step.get("id", "")))
	var actor: CutsceneActor = _actors.get(id)
	if actor == null:
		push_error("[Cutscene] %s：找不到角色「%s」，已略過" % [_current_where, id])
	return actor


static func _vec(value: Variant, fallback: Vector2) -> Vector2:
	return StageLayers.vec2_of(value, fallback)


# ---------------------------------------------------------------------------
# 步驟
# ---------------------------------------------------------------------------

func _do_scene(step: Dictionary) -> void:
	var id := StringName(str(step.get("id", "")))
	if not StageLibrary.exists(id):
		push_error("[Cutscene] %s：場景「%s」不存在，保留原本的場景" % [_current_where, id])
		return
	if _stage != null:
		_stage.queue_free()
		_actors.clear()
	_pose_envelopes.clear()
	_actor_origins.clear()
	_actor_facings.clear()
	_actor_motion.clear()
	_framing_plan = null
	_stage = StageLibrary.build(id)
	_stage_holder.add_child(_stage)
	_cache_stage_art()
	cam_pos = _vec(step.get("pos"), _stage.default_camera_pos)
	cam_zoom = float(step.get("zoom", _stage.default_camera_zoom))
	_apply_camera()
	# 第一個場景從黑幕淡入（演出開始時畫面是黑的）。
	var fade_in := float(step.get("fade", 0.5 if _fade.color.a > 0.5 else 0.0))
	if fade_in > 0.0:
		await _do_fade({"to": 0.0, "time": fade_in})


func _do_letterbox(step: Dictionary) -> void:
	# 舊腳本命令保留等待語義；正式演出整段維持共用21:9，普通overlay FX不因這步取得畫幅。
	if bool(step.get("wait", false)):
		await _wait_time(float(step.get("time", 0.4)))


func _do_camera(step: Dictionary) -> void:
	var time := float(step.get("time", 0.0))
	var target_pos := _vec(step.get("pos"), cam_pos)
	var target_zoom := float(step.get("zoom", cam_zoom))
	if time <= 0.0:
		cam_pos = target_pos
		cam_zoom = target_zoom
		return
	var tween := _new_tween().set_parallel(true)
	var ease_type := Tween.EASE_IN_OUT
	tween.tween_property(self, "cam_pos", target_pos, time).set_trans(Tween.TRANS_SINE).set_ease(ease_type)
	tween.tween_property(self, "cam_zoom", target_zoom, time).set_trans(Tween.TRANS_SINE).set_ease(ease_type)
	if bool(step.get("wait", false)):
		await _wait_tween(tween)


func _do_actor(step: Dictionary) -> void:
	var id := StringName(str(step.get("id", "")))
	var actor := CutsceneActor.new()
	var ok := actor.setup(id, str(step.get("kind", "")), str(step.get("portrait", "")),
			float(step.get("scale", 1.0)), str(step.get("weapon", "")))
	if not ok:
		push_error("[Cutscene] %s：角色「%s」沒有可用的外觀或頭像，已略過" % [_current_where, id])
		actor.free()
		return
	actor.position = _vec(step.get("pos"), CENTER)
	actor.face(int(step.get("facing", 1)))
	actor.set_pose(StringName(str(step.get("pose", "idle"))))
	actor.set_loop(StringName(str(step.get("loop", ""))), float(step.get("loop_scale", 1.0)))
	actor.speaker_id = StringName(str(step.get("speaker", id)))
	actor.ground_y = float(step["ground"]) if step.has("ground") else (_stage.floor_y if _stage != null else NAN)
	var slot := _actor_slot(id, step)
	actor.layer_slot = slot
	actor.z_index = WorldLayers.stage_actor_z(slot)
	if _actors.has(id):
		_actors[id].queue_free()
	_actors[id] = actor
	_stage.actors.add_child(actor)
	_pose_envelopes.erase(id)
	_actor_origins.erase(id)
	_actor_facings.erase(id)
	_actor_motion.erase(id)
	if _actors.size() > WorldLayers.MAX_STAGE_ACTORS:
		_framing_plan = null
		_framing_warning("演員超過 framing cache 的 %d 組上限" % WorldLayers.MAX_STAGE_ACTORS)
		_apply_camera()
		return
	_pose_envelopes[id] = StagePoseEnvelope.new()
	_actor_facings[id] = actor.facing
	_cache_actor_framing(actor)


## 演員用的圖層組：每個演員佔自己的一組，兩個人重疊（走過、並肩）時零件不會互相穿插。
## step 的 layer 指定第幾組（數字大的在前面）；沒指定時重新登場的演員沿用原本的組，新演員接在最後（後登場的在前面）。
func _actor_slot(id: StringName, step: Dictionary) -> int:
	var slot := int(step.get("layer", -1))
	if slot < 0:
		var existing := _actors.get(id) as CutsceneActor
		slot = existing.layer_slot if existing != null else _actors.size()
	if slot >= WorldLayers.MAX_STAGE_ACTORS:
		push_warning("[Cutscene] %s：演員「%s」超過 %d 組圖層，與最後一組共用。" % [_current_where, id, WorldLayers.MAX_STAGE_ACTORS])
	return slot


func _do_pose(step: Dictionary) -> void:
	var actor := _need_actor(step)
	if actor != null:
		actor.set_pose(StringName(str(step.get("pose", "idle"))))
		if step.has("loop"):
			actor.set_loop(StringName(str(step.get("loop", ""))), float(step.get("loop_scale", 1.0)))
		_cache_actor_framing(actor)


## 說話中的演員（id 與講者相同）點頭比手勢，其他人安靜聆聽。傳空字串＝大家都不說話。
func _set_talkers(speaker_id: StringName) -> void:
	for id: StringName in _actors.keys():
		var actor := _actors[id] as CutsceneActor
		if is_instance_valid(actor):
			var talks := speaker_id != &"" and (actor.speaker_id == speaker_id or id == speaker_id)
			actor.set_talking(talks)
			actor.set_listening(speaker_id != &"" and not talks)
			_cache_actor_framing(actor, Vector2.ZERO, false)
	_rebuild_framing_plan()


func _do_face(step: Dictionary) -> void:
	var actor := _need_actor(step)
	if actor != null:
		actor.face(int(step.get("dir", 1)))
		_cache_actor_framing(actor)


func _do_remove(step: Dictionary) -> void:
	var actor := _need_actor(step)
	if actor != null:
		_actors.erase(actor.actor_id)
		_pose_envelopes.erase(actor.actor_id)
		_actor_origins.erase(actor.actor_id)
		_actor_facings.erase(actor.actor_id)
		_actor_motion.erase(actor.actor_id)
		actor.queue_free()
		_rebuild_framing_plan()


func _do_move(step: Dictionary) -> void:
	var actor := _need_actor(step)
	if actor == null:
		return
	var target := _vec(step.get("to"), actor.position)
	var time := maxf(0.01, float(step.get("time", 1.0)))
	if absf(target.x - actor.position.x) > 0.5:
		actor.face(1 if target.x > actor.position.x else -1)
	actor.set_pose(StringName(str(step.get("pose", "walk"))))
	if _actor_motion.has(actor.actor_id) and _pose_envelopes.has(actor.actor_id):
		# 原播放器允許兩個 Tween 同時寫同一 position；不同時長沒有單一路徑的完成時序。
		# 保留原演出，但不以最後一個 Tween 的終點假冒全部移動的保守界線。
		_pose_envelopes[actor.actor_id]._unsupported("同一演員重疊 move 的 Tween 路徑不受支援")
	_motion_serial += 1
	var motion_serial := _motion_serial
	_actor_motion[actor.actor_id] = motion_serial
	var velocity := (target - actor.position) / (time / maxf(speed, 0.0001) * maxf(absf(actor.scale.x), 0.0001) * (actor.rig.body_scale() if actor.rig != null else 1.0))
	_cache_actor_framing(actor, velocity, false)
	_actor_origins[actor.actor_id] = _actor_origins[actor.actor_id].expand(target)
	_rebuild_framing_plan()
	var tween := _new_tween()
	tween.tween_property(actor, "position", target, time)
	var then_pose := StringName(str(step.get("then", "idle")))
	tween.tween_callback(func() -> void:
		if is_instance_valid(actor) and _actors.get(actor.actor_id) == actor:
			actor.set_pose(then_pose)
			if _actor_motion.get(actor.actor_id, 0) == motion_serial:
				_actor_motion.erase(actor.actor_id)
			_cache_actor_framing(actor))
	if bool(step.get("wait", true)):
		await _wait_tween(tween)


func _do_say(step: Dictionary) -> void:
	var speaker := Story.speaker(str(step.get("speaker", "")))
	_set_talkers(StringName(str(step.get("speaker", ""))))
	_advance_requested = false
	_dialogue.show_line(speaker, str(step.get("text", "")), str(step.get("style", "normal")))
	var auto := float(step.get("auto", 0.0))
	var waited := 0.0
	while not skipping and _running:
		await get_tree().process_frame
		if _dialogue.is_complete():
			waited += get_process_delta_time() * speed
			if _advance_requested or (auto > 0.0 and waited >= auto):
				break
		else:
			_advance_requested = false
	_advance_requested = false
	if not _next_is_say:
		_dialogue.hide_box()
		_set_talkers(&"")


func _do_narrate(step: Dictionary) -> void:
	var lines: Array = step.get("lines", [])
	var hold := float(step.get("time", 2.2))
	var text := "\n".join(PackedStringArray(lines.map(func(l: Variant) -> String: return str(l))))
	_center_text.add_theme_font_size_override(&"font_size", UiKit.FS_BODY)
	_center_text.add_theme_color_override(&"font_color", StageLayers.color_of(step.get("color", "#9fd6e4")))
	_center_text.text = text
	_center_text.visible_ratio = 0.0
	_center_text.modulate.a = 1.0
	var type_time := maxf(0.4, float(text.length()) * 0.05)
	var tween := _new_tween()
	tween.tween_property(_center_text, "visible_ratio", 1.0, type_time)
	await _wait_tween(tween)
	await _wait_time(hold)
	var out := _new_tween()
	out.tween_property(_center_text, "modulate:a", 0.0, 0.4)
	await _wait_tween(out)


func _do_title(step: Dictionary) -> void:
	var hold := float(step.get("time", 2.5))
	var color := StageLayers.color_of(step.get("color", "#ff2e88"))
	_center_text.add_theme_font_size_override(&"font_size", UiKit.FS_TITLE if bool(step.get("small", false)) else UiKit.FS_DISPLAY)
	_center_text.add_theme_color_override(&"font_color", LightKit.glow(color, 1.4))
	_center_text.text = str(step.get("text", ""))
	_center_text.visible_ratio = 1.0
	_center_sub.text = str(step.get("sub", ""))
	var tween_in := _new_tween().set_parallel(true)
	tween_in.tween_property(_center_text, "modulate:a", 1.0, TITLE_FADE)
	tween_in.tween_property(_center_sub, "modulate:a", 1.0, TITLE_FADE)
	await _wait_tween(tween_in)
	await _wait_time(hold)
	var tween_out := _new_tween().set_parallel(true)
	tween_out.tween_property(_center_text, "modulate:a", 0.0, TITLE_FADE)
	tween_out.tween_property(_center_sub, "modulate:a", 0.0, TITLE_FADE)
	await _wait_tween(tween_out)


func _do_fx(step: Dictionary) -> void:
	var time := float(step.get("time", 0.5))
	var reduced := Settings.get_reduce_flashes()
	match str(step.get("kind", "")):
		"shake":
			_shake = float(step.get("strength", 4.0))
			_shake_time = time
		"flash":
			_pulse(_flash, StageLayers.color_of(step.get("color", "#ffffff")), 0.35 if reduced else 1.0, time)
		"lightning":
			_pulse(_flash, Color("cfe0ff"), 0.3 if reduced else 0.9, maxf(time, 0.25))
			Sfx.play(&"thunder", -6.0, 0.0)
		"noise":
			_pulse_noise(time, reduced)
		"tint":
			var color := StageLayers.color_of(step.get("color", "#ff0033"))
			var target := Color(color, float(step.get("alpha", 0.25)))
			var tween := _new_tween()
			tween.tween_property(_tint, "color", target, time)
		"rain":
			var on := bool(step.get("on", true))
			for group: Node2D in [_stage.back, _stage.front]:
				for layer in group.get_children():
					if str(layer.get_meta(&"kind", "")) == "rain":
						layer.visible = on
		"vignette":
			pass
	if bool(step.get("wait", false)):
		await _wait_time(time)


## 閃光：瞬間升到 amount 再淡出。
func _pulse(rect: ColorRect, color: Color, amount: float, time: float) -> void:
	rect.color = Color(color, amount)
	var tween := _new_tween()
	tween.tween_property(rect, "color:a", 0.0, time).set_ease(Tween.EASE_OUT)


func _pulse_noise(time: float, reduced: bool) -> void:
	if reduced or _noise.material == null:
		_pulse(_flash, Color.WHITE, 0.2, time)
		return
	var material := _noise.material as ShaderMaterial
	_noise.visible = true
	material.set_shader_parameter(&"seed", randf() * 10.0)
	var tween := _new_tween()
	tween.tween_method(func(v: float) -> void:
		material.set_shader_parameter(&"progress", v)
		material.set_shader_parameter(&"time_s", Time.get_ticks_msec() * 0.001), 0.6, 0.0, time)
	tween.tween_callback(_noise.hide)


func _do_sfx(step: Dictionary) -> void:
	Sfx.play(StringName(str(step.get("id", ""))), float(step.get("volume", -4.0)), float(step.get("jitter", 0.0)))


func _do_wait(step: Dictionary) -> void:
	await _wait_time(float(step.get("time", 0.5)))


func _do_fade(step: Dictionary) -> void:
	var color := StageLayers.color_of(step.get("color", "#000000"))
	var target := float(step.get("to", 0.0))
	var time := float(step.get("time", 0.6))
	_fade.color = Color(color, _fade.color.a)
	var tween := _new_tween()
	tween.tween_property(_fade, "color:a", target, time)
	if bool(step.get("wait", true)):
		await _wait_tween(tween)


func _do_transition(step: Dictionary) -> void:
	var kind: int = Transition.kind_from_name(str(step.get("kind", "fade")))
	if kind < 0:
		push_error("[Cutscene] %s：轉場「%s」不存在，已略過" % [_current_where, step.get("kind", "")])
		return
	var time := float(step.get("time", -1.0))
	if str(step.get("mode", "cover")) == "reveal":
		await Transition.reveal(kind, time)
	else:
		await Transition.cover(kind, time, Vector2(0.5, 0.5), "", self)


func _do_end(_step: Dictionary) -> void:
	skipping = true


func choice_active() -> bool:
	return is_instance_valid(_choice) and _choice.visible and _chosen < 0


func choose(index: int) -> bool:
	if not choice_active() or index < 0 or index >= _choice_options.size():
		return false
	_chosen = index
	Story.apply_choice(_choice_options[index])
	_choice.hide()
	return true


func _do_choice(step: Dictionary) -> void:
	_choice_options = StoryRules.options(step, GameState.has_flag, StoryItems.owns)
	if _choice_options.is_empty():
		push_warning("[Cutscene] %s 沒有可用選項，已略過" % _current_where)
		return
	_chosen = -1
	_choice = VBoxContainer.new()
	_choice.position = Vector2(96, 100)
	_choice.custom_minimum_size = Vector2(448, 0)
	_choice.theme = UiKit.theme()
	_choice.z_index = EFFECT_Z + 20
	_choice.add_theme_constant_override(&"separation", 8)
	_root.add_child(_choice)
	_choice.add_child(UiKit.label(str(step.get("text", "請選擇接下來的行動。")), UiKit.FS_BODY, Palette.CYAN))
	for i in _choice_options.size():
		var button := UiKit.button(str(_choice_options[i].get("text", "繼續。")), choose.bind(i))
		button.custom_minimum_size = Vector2(448, 32)
		_choice.add_child(button)
	_layout_safe_rect(Story.framing.safe_rect())
	(_choice.get_child(1) as Button).grab_focus()
	var mouse_mode := Input.mouse_mode
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	while _chosen < 0 and not skipping and _running:
		await get_tree().process_frame
	if not _running:
		return
	var option := _choice_options[_chosen] if _chosen >= 0 else StoryRules.default_option(step, _choice_options)
	if _chosen < 0:
		Story.apply_choice(option)
	if option.get("steps") is Array:
		_pending_steps = option.steps.duplicate(true)
	_choice.queue_free()
	Input.mouse_mode = mouse_mode


func _do_branch(step: Dictionary) -> void:
	var key := "steps" if StoryRules.eligible(step, GameState.has_flag, StoryItems.owns) else "else_steps"
	var raw: Variant = step.get(key, [])
	if raw is Array:
		_pending_steps = raw.duplicate(true)


func _layout_safe_rect(rect: Rect2) -> void:
	if not is_instance_valid(_root):
		return
	_dialogue.layout_safe_rect(rect)
	_rebuild_framing_plan()
	_skip_hint.set_anchors_preset(Control.PRESET_TOP_LEFT)
	_skip_hint.position = Vector2(maxf(8, rect.end.x - 120), rect.position.y + 6)
	_skip_hint.size = Vector2(110, 18)
	if is_instance_valid(_choice):
		var width := minf(448.0, maxf(0, rect.size.x - 48))
		_choice.position = Vector2((rect.size.x - width) * 0.5, rect.position.y + 24)
		_choice.custom_minimum_size.x = width
		_choice.size.x = width
		for control in _choice.get_children():
			(control as Control).custom_minimum_size.x = width


func _refresh_skip_hint() -> void:
	if is_instance_valid(_skip_hint):
		_skip_hint.text = InputBindings.format("{ui_cancel} 跳過")


## 舞台建構時只選一張正式背景，不把不連續圖層的 bounding union 當填滿。
func _cache_stage_art() -> void:
	_framing_art = Rect2()
	_framing_supported = false
	_framing_reason = "舞台沒有單一正式背景"
	if _overlay_mode or _stage == null:
		return
	var found := 0
	for node in _stage.back.get_children():
		if str(node.get_meta(&"kind", "")) != "sprite" or not node is Sprite2D:
			continue
		var sprite := node as Sprite2D
		if sprite.texture == null or not sprite.texture.resource_path.contains("/environment/scenes/"):
			continue
		found += 1
		if sprite.rotation != 0 or sprite.scale.x <= 0 or sprite.scale.y <= 0 \
				or sprite.skew != 0 or not sprite.visible or sprite.modulate.a != 1.0 or sprite.self_modulate.a != 1.0 \
				or float(sprite.get_meta(&"parallax", 1.0)) != 1.0:
			_framing_reason = "正式背景 rotation／scale／skew／透明度／parallax 不受單平面求解支援"
			return
		_framing_art = sprite.transform * sprite.get_rect()
	if found == 1 and StageFramingPlan._positive_rect(_framing_art):
		_framing_supported = true
		_framing_reason = ""
	elif found > 1:
		_framing_reason = "多張正式背景需分平面求解"


func _cache_actor_framing(actor: CutsceneActor, velocity := Vector2.ZERO, rebuild := true) -> void:
	var id := actor.actor_id
	if _actors.get(id) != actor:
		return
	var envelope: StagePoseEnvelope = _pose_envelopes.get(id)
	if envelope == null:
		return
	if _actor_facings.get(id, actor.facing) != actor.facing:
		_actor_facings[id] = 0 # 翻面前/後動畫格皆在聯集中，避免一格舊 facing 漏界線。
	envelope.include(actor, velocity)
	if not _actor_motion.has(id) or not _actor_origins.has(id):
		_actor_origins[id] = Rect2(actor.position, Vector2.ZERO)
	if actor._settling and is_finite(actor.ground_y):
		_actor_origins[id] = _actor_origins[id].expand(Vector2(actor.position.x, actor.ground_y))
	if rebuild:
		_rebuild_framing_plan()


func _rebuild_framing_plan() -> void:
	_framing_plan = null
	if _overlay_mode or _stage == null or _actors.is_empty():
		_apply_camera()
		return
	if not _framing_supported:
		_framing_warning(_framing_reason)
		_apply_camera()
		return
	var total := Rect2()
	var first := true
	for id in _actors:
		var actor: CutsceneActor = _actors[id]
		var envelope: StagePoseEnvelope = _pose_envelopes.get(id)
		if envelope == null or not envelope.supported:
			_framing_warning("演員 %s：%s" % [id, envelope.reason if envelope != null else "沒有 envelope"])
			_apply_camera()
			return
		if not actor.scale.is_finite() or actor.scale.x <= 0 or actor.scale.y <= 0 or actor.rotation != 0:
			_framing_warning("演員 %s rotation／scale 不受支援" % id)
			_apply_camera()
			return
		var bounds := envelope.bounds
		var mirrored := Rect2(Vector2(-bounds.end.x, bounds.position.y), bounds.size)
		if _actor_facings[id] == 0:
			bounds = bounds.merge(mirrored)
		elif actor.facing < 0 and actor.rig != null:
			bounds = mirrored
		bounds = Transform2D(0.0, actor.scale, 0.0, Vector2.ZERO) * bounds
		bounds = StagePoseEnvelope.add_rect(bounds, _actor_origins[id])
		total = bounds if first else total.merge(bounds)
		first = false
	var safe := Story.framing.safe_rect()
	# 真 panel 與肖像上緣；保留整段字幕預算，台詞切換不跳動鏡頭。
	var reserve := _dialogue._box_rect.merge(Rect2(_dialogue._box_rect.position + Vector2(6, -8), Vector2.ONE * CutsceneDialogue.PORTRAIT_SIZE))
	_framing_plan = StageFramingPlan.solve(total, _framing_art, get_viewport().get_visible_rect().size,
		safe, reserve, cam_pos, cam_zoom)
	if not _framing_plan.feasible:
		_framing_warning("%s；必要背景缺口 L/T/R/B=%s（舞台像素）" % [_framing_plan.reason, _framing_plan.art_gaps])
	_apply_camera()


func _framing_warning(message: String) -> void:
	var key := "%s:%s" % [_stage.stage_id if _stage != null else &"", message.get_slice("；", 0)]
	if not _framing_warnings.has(key) and _framing_warnings.size() < StagePoseEnvelope.MAX_CONTEXTS:
		_framing_warnings[key] = true
		push_warning("[StageFraming] %s：%s；保留作者鏡頭，不宣稱構圖通過" % [_current_where, message])


## 只供測試／量測工具事件讀取，不修改 Story、request handle 或任何存檔。
func framing_status() -> Dictionary:
	var actors: Dictionary = {}
	var supported := _framing_supported
	var reason := _framing_reason
	for id in _pose_envelopes:
		var envelope: StagePoseEnvelope = _pose_envelopes[id]
		actors[id] = envelope.diagnostics()
		actors[id]["origin_sweep"] = _actor_origins.get(id, Rect2())
		if not envelope.supported:
			supported = false
			reason = envelope.reason
	return {"supported": supported, "reason": reason,
		"plan_reason": _framing_plan.reason if _framing_plan != null else &"not_prepared", "actors": actors,
		"feasible": _framing_plan != null and _framing_plan.feasible,
		"actor_bounds": _framing_plan._actor_bounds if _framing_plan != null else Rect2(),
		"art_bounds": _framing_art, "required_art_gaps": _framing_plan.art_gaps if _framing_plan != null else Vector4.ZERO,
		"author_position": cam_pos, "author_zoom": cam_zoom,
		"effective_position": effective_cam_pos, "effective_zoom": effective_cam_zoom}
