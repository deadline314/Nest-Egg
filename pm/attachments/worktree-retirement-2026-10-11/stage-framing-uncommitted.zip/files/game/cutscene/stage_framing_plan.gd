class_name StageFramingPlan
extends RefCounted
## ST-10：單一舞台平面的純幾何規劃，不讀 Node／資源、不改演員或作者資料。
## solve 在 bounds／UI／分鏡事件更新時使用，結果由 caller 快取；每影格只套 camera_transform。
## actor/art 為舞台座標，safe/subtitle 為實際 viewport 座標；不支援旋轉、不同視差或透明藝術缺口。

const ROUNDING_EPSILON := 0.001
var valid_input := false
var feasible := false
var reason: StringName = &"invalid_input"
var camera_position := Vector2.ZERO
var zoom := 1.0
var actor_region := Rect2()
var required_art_bounds := Rect2()
## 缺口順序：left / top / right / bottom，世界像素；不能當成 RAM／來源圖片像素。
var art_gaps := Vector4.ZERO
var fit_zoom_max := 0.0
var cover_zoom_min := 0.0
var _viewport_center := Vector2.ZERO
var _q_min := 0.0
var _q_max := 0.0
var _actor_bounds := Rect2()
var _art_bounds := Rect2()
var _safe_rect := Rect2()


## subtitle_reserve=Rect2() 表示沒有字幕保留區。相交時整個 actor_region 位於其上方。
## 無解時 camera 是「最大 actor-fit zoom」的藝術延展候選，feasible 仍為 false，不能直接套用。
static func solve(actor_bounds: Rect2, art_bounds: Rect2, viewport_size: Vector2,
		safe_rect: Rect2, subtitle_reserve: Rect2, author_camera: Vector2,
		author_zoom: float, padding := 4.0) -> StageFramingPlan:
	var plan := StageFramingPlan.new()
	if not _positive_rect(actor_bounds):
		plan.reason = &"invalid_actor_bounds"
		return plan
	if not _positive_rect(art_bounds):
		plan.reason = &"invalid_art_bounds"
		return plan
	if not viewport_size.is_finite() or viewport_size.x <= 0 or viewport_size.y <= 0:
		plan.reason = &"invalid_viewport"
		return plan
	if not _positive_rect(safe_rect) or not Rect2(Vector2.ZERO, viewport_size).encloses(safe_rect):
		plan.reason = &"invalid_safe_rect"
		return plan
	if not _finite_rect(subtitle_reserve) or subtitle_reserve.size.x < 0 or subtitle_reserve.size.y < 0 \
			or (subtitle_reserve.size != Vector2.ZERO and not subtitle_reserve.has_area()):
		plan.reason = &"invalid_subtitle_rect"
		return plan
	if not is_finite(padding) or padding < 0:
		plan.reason = &"invalid_padding"
		return plan
	if not author_camera.is_finite() or not is_finite(author_zoom) or author_zoom <= 0:
		plan.reason = &"invalid_author_camera"
		return plan
	plan.valid_input = true
	plan._actor_bounds = actor_bounds
	plan._art_bounds = art_bounds
	plan._safe_rect = safe_rect
	plan._viewport_center = viewport_size * 0.5
	plan.camera_position = author_camera
	plan.zoom = author_zoom
	plan.actor_region = safe_rect.grow(-padding)
	if subtitle_reserve.has_area() and safe_rect.intersects(subtitle_reserve):
		plan.actor_region.size.y = minf(plan.actor_region.end.y, subtitle_reserve.position.y - padding) - plan.actor_region.position.y
	if not _finite_rect(plan.actor_region):
		return _overflow(plan)
	if not plan.actor_region.has_area():
		plan.reason = &"empty_actor_region"
		return plan
	plan.fit_zoom_max = minf(plan.actor_region.size.x / actor_bounds.size.x,
		plan.actor_region.size.y / actor_bounds.size.y)
	plan.cover_zoom_min = maxf(safe_rect.size.x / art_bounds.size.x, safe_rect.size.y / art_bounds.size.y)
	if not is_finite(plan.fit_zoom_max) or not is_finite(plan.cover_zoom_min) \
			or plan.fit_zoom_max <= 0 or plan.cover_zoom_min <= 0:
		return _overflow(plan)
	plan._q_min = 1.0 / plan.fit_zoom_max
	plan._q_max = 1.0 / plan.cover_zoom_min
	if not is_finite(plan._q_min) or not is_finite(plan._q_max):
		return _overflow(plan)
	var center := plan._viewport_center
	var target := plan.actor_region
	# 兩個 lower（actor/art）與兩個 upper，各軸四組不等式；沒有每影格陣列或候選網格。
	var intersection := true
	for axis in 2:
		var actor_low: float = actor_bounds.end[axis]
		var actor_high: float = actor_bounds.position[axis]
		var art_low: float = art_bounds.position[axis]
		var art_high: float = art_bounds.end[axis]
		var actor_low_slope: float = center[axis] - target.end[axis]
		var actor_high_slope: float = center[axis] - target.position[axis]
		var art_low_slope: float = center[axis] - safe_rect.position[axis]
		var art_high_slope: float = center[axis] - safe_rect.end[axis]
		intersection = _intersect_q(plan, actor_low, actor_low_slope, actor_high, actor_high_slope) and intersection
		intersection = _intersect_q(plan, actor_low, actor_low_slope, art_high, art_high_slope) and intersection
		intersection = _intersect_q(plan, art_low, art_low_slope, actor_high, actor_high_slope) and intersection
		intersection = _intersect_q(plan, art_low, art_low_slope, art_high, art_high_slope) and intersection
	intersection = intersection and plan._q_min <= plan._q_max and plan._q_max > 0
	var q := clampf(1.0 / author_zoom, plan._q_min, plan._q_max) if intersection else 1.0 / plan.fit_zoom_max
	if not is_finite(q) or q <= 0:
		return _overflow(plan)
	plan.zoom = 1.0 / q
	# 固定 q 後，中心取離作者最近的交集點；無解候選只使用 actor 區間，不假裝 art cover 已成立。
	for axis in 2:
		var low: float = actor_bounds.end[axis] + (center[axis] - target.end[axis]) * q
		var high: float = actor_bounds.position[axis] + (center[axis] - target.position[axis]) * q
		if intersection:
			low = maxf(low, art_bounds.position[axis] + (center[axis] - safe_rect.position[axis]) * q)
			high = minf(high, art_bounds.end[axis] + (center[axis] - safe_rect.end[axis]) * q)
		# 正好貼邊的單點區間可能有雙精度運算末位差；只合併微小數值差，不放寬幾何約束。
		if low > high:
			if low - high > ROUNDING_EPSILON:
				return _overflow(plan)
			low = (low + high) * 0.5
			high = low
		plan.camera_position[axis] = clampf(author_camera[axis], low, high)
	plan.feasible = intersection
	plan.reason = &"adjusted_camera" if intersection else &"art_coverage_conflict"
	if intersection:
		plan.follow_author(author_camera, author_zoom)
	var projected_actor := plan.project_rect(actor_bounds)
	var projected_art := plan.project_rect(art_bounds)
	if not _positive_rect(projected_actor) or not _positive_rect(projected_art):
		return _overflow(plan)
	if not _encloses(plan.actor_region, projected_actor) or (intersection and not _encloses(projected_art, safe_rect)):
		return _overflow(plan)
	return _record_art(plan, art_bounds, safe_rect)


## 只用已求出的 q 與中心區間；作者 Tween 每格可呼叫，不建立新物件／陣列或掃描角色。
## 無解時不套藝術延展候選，caller 保留作者鏡頭並顯示診斷。
func follow_author(author_camera: Vector2, author_zoom: float) -> bool:
	if not feasible or not author_camera.is_finite() or not is_finite(author_zoom) or author_zoom <= 0:
		return false
	var xf := Transform2D(Vector2(author_zoom, 0), Vector2(0, author_zoom), _viewport_center - author_camera * author_zoom)
	if _encloses(actor_region, xf * _actor_bounds) and _encloses(xf * _art_bounds, _safe_rect):
		camera_position = author_camera
		zoom = author_zoom
		reason = &"author_camera"
		return true
	var q := clampf(1.0 / author_zoom, _q_min, _q_max)
	zoom = 1.0 / q
	for axis in 2:
		var low: float = maxf(_actor_bounds.end[axis] + (_viewport_center[axis] - actor_region.end[axis]) * q,
			_art_bounds.position[axis] + (_viewport_center[axis] - _safe_rect.position[axis]) * q)
		var high: float = minf(_actor_bounds.position[axis] + (_viewport_center[axis] - actor_region.position[axis]) * q,
			_art_bounds.end[axis] + (_viewport_center[axis] - _safe_rect.end[axis]) * q)
		camera_position[axis] = clampf(author_camera[axis], low, maxf(low, high))
	reason = &"author_camera" if camera_position == author_camera and zoom == author_zoom else &"adjusted_camera"
	return true


## Shake 是 viewport 位移；換成作者中心後再次投影到同一可行集合，不能抖出背景／字幕界線。
func constrain_shake(offset: Vector2) -> Vector2:
	if not feasible or not offset.is_finite():
		return Vector2.ZERO
	var before := camera_position
	var q := 1.0 / zoom
	for axis in 2:
		var low: float = maxf(_actor_bounds.end[axis] + (_viewport_center[axis] - actor_region.end[axis]) * q,
			_art_bounds.position[axis] + (_viewport_center[axis] - _safe_rect.position[axis]) * q)
		var high: float = minf(_actor_bounds.position[axis] + (_viewport_center[axis] - actor_region.position[axis]) * q,
			_art_bounds.end[axis] + (_viewport_center[axis] - _safe_rect.end[axis]) * q)
		camera_position[axis] = clampf(before[axis] - offset[axis] * q, low, maxf(low, high))
	return (before - camera_position) * zoom


## 與 CutscenePlayer._apply_camera 相同：整舞台單一 zoom，原演員／家具相對比例不變。
func camera_transform() -> Transform2D:
	return Transform2D(Vector2(zoom, 0), Vector2(0, zoom), _viewport_center - camera_position * zoom)


func project_rect(stage_bounds: Rect2) -> Rect2:
	return camera_transform() * stage_bounds


static func _intersect_q(plan: StageFramingPlan, low: float, low_slope: float,
		high: float, high_slope: float) -> bool:
	var coefficient := low_slope - high_slope
	var rhs := high - low
	if coefficient == 0.0:
		return rhs >= 0.0
	var bound := rhs / coefficient
	if not is_finite(bound):
		return false
	if coefficient > 0:
		plan._q_max = minf(plan._q_max, bound)
	else:
		plan._q_min = maxf(plan._q_min, bound)
	return true


static func _record_art(plan: StageFramingPlan, art: Rect2, safe: Rect2) -> StageFramingPlan:
	var q := 1.0 / plan.zoom
	plan.required_art_bounds = Rect2(plan.camera_position + (safe.position - plan._viewport_center) * q, safe.size * q)
	if not _positive_rect(plan.required_art_bounds):
		return _overflow(plan)
	var required := plan.required_art_bounds
	plan.art_gaps = Vector4(maxf(0, art.position.x - required.position.x),
		maxf(0, art.position.y - required.position.y), maxf(0, required.end.x - art.end.x),
		maxf(0, required.end.y - art.end.y))
	if not plan.art_gaps.is_finite():
		return _overflow(plan)
	return plan


static func _overflow(plan: StageFramingPlan) -> StageFramingPlan:
	plan.valid_input = false
	plan.feasible = false
	plan.reason = &"numeric_overflow"
	plan.camera_position = Vector2.ZERO
	plan.zoom = 1.0
	plan.actor_region = Rect2()
	plan.required_art_bounds = Rect2()
	plan.art_gaps = Vector4.ZERO
	plan.fit_zoom_max = 0.0
	plan.cover_zoom_min = 0.0
	plan._q_min = 0.0
	plan._q_max = 0.0
	return plan


static func _finite_rect(rect: Rect2) -> bool:
	return rect.position.is_finite() and rect.size.is_finite() and rect.end.is_finite()


static func _positive_rect(rect: Rect2) -> bool:
	return _finite_rect(rect) and rect.size.x > 0 and rect.size.y > 0


static func _encloses(outer: Rect2, inner: Rect2) -> bool:
	# Transform2D / Vector2 使用 real_t，鏡頭套用後容許不足 0.001 像素的捨入差。
	return inner.position.x >= outer.position.x - ROUNDING_EPSILON \
		and inner.position.y >= outer.position.y - ROUNDING_EPSILON \
		and inner.end.x <= outer.end.x + ROUNDING_EPSILON \
		and inner.end.y <= outer.end.y + ROUNDING_EPSILON
