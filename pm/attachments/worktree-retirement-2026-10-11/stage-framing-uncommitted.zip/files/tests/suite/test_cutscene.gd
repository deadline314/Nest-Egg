class_name CutsceneSuite
extends TestSuite
## 過場動畫系統（NE-38）：資料檢查、所有步驟播放、跳過、損毀資料容錯、暫停還原、與 Story 整合。
## 故意損毀的演出 id 含 test_bad_cutscene，執行器會忽略它們的錯誤輸出。

const GOOD_SCENE := {
	"mode": "animated",
	"steps": [
		{"do": "scene", "id": "test_room", "fade": 0.1},
		{"do": "letterbox", "on": true, "time": 0.1, "wait": true},
		{"do": "camera", "pos": [300, 170], "zoom": 1.1, "time": 0.2, "wait": true},
		{"do": "actor", "id": "rin", "kind": "rin", "pos": [120, 290], "weapon": "rifle", "pose": "idle"},
		{"do": "actor", "id": "k", "portrait": "res://art/portraits/old_k.png", "pos": [260, 290], "facing": -1},
		{"do": "move", "id": "rin", "to": [200, 290], "time": 0.2, "pose": "walk", "wait": true},
		{"do": "face", "id": "rin", "dir": -1},
		{"do": "pose", "id": "rin", "pose": "crouch"},
		{"do": "say", "speaker": "rin", "text": "多少。", "auto": 0.05},
		{"do": "say", "speaker": "old_k", "text": "你鞋帶散了。", "style": "whisper", "auto": 0.05},
		{"do": "fx", "kind": "shake", "strength": 3, "time": 0.1},
		{"do": "fx", "kind": "flash", "time": 0.1},
		{"do": "fx", "kind": "noise", "time": 0.1},
		{"do": "fx", "kind": "tint", "color": "#ff0033", "alpha": 0.2, "time": 0.1},
		{"do": "sfx", "id": "ui_confirm"},
		{"do": "narrate", "lines": ["凌晨 3 點 12 分起暫停降雨"], "time": 0.1},
		{"do": "title", "text": "第一章　雨夜", "sub": "沉港市", "time": 0.1},
		{"do": "remove", "id": "k"},
		{"do": "wait", "time": 0.1},
		{"do": "fade", "to": 1.0, "time": 0.1},
	],
}

const FramingPlan := preload("res://game/cutscene/stage_framing_plan.gd")

var _finished_ids: Array[StringName] = []
## 演出結束時已執行的步驟數（播放器結束後就釋放了，所以在結束訊號裡記下來）。
var _steps_done: Dictionary[StringName, int] = {}


func run() -> void:
	_test_stage_framing_plan()
	_test_pose_envelope_math()
	_test_follow_history()
	await _test_fresh_npc_ground()
	await _test_raw_body_and_grounded_walking()
	await _test_ground_input_contexts()
	await _test_secondary_spring_additive()
	await _test_pose_envelope_actual()
	await _test_effective_camera_events()
	await _test_story_features()
	_test_checker()
	_test_stages()
	await _test_play_all_steps()
	await _test_skip()
	await _test_broken_data()
	await _test_pause_restored()
	await _test_story_integration()
	await _test_overlay_and_layers()
	await _test_stand_up_returns_to_the_floor()
	_test_walk_matches_stage_motion()
	await _test_lock_lifecycle()
	await _test_gameplay_input_lock()
	await _test_skip_covered_transition()
	await _test_framing_lifecycle()
	await _test_resumed_boss_cancel()
	await _test_saved_arena_initialization()
	_test_real_data()


## 純幾何回歸：直接驗投影後頭腳、藝術 cover 及可手算的中心／zoom，不碰真角色或故事資料。
func _test_stage_framing_plan() -> void:
	var viewport := Vector2(640, 360)
	var safe := Rect2(Vector2.ZERO, viewport)
	var subtitle := Rect2(0, 280, 640, 80)
	var art := safe
	var body := Rect2(100, 100, 100, 100)
	var author := Vector2(320, 180)
	var plan := FramingPlan.solve(body, art, viewport, safe, subtitle, author, 1.0, 0.0)
	check(plan.valid_input and plan.feasible and plan.camera_position == author and plan.zoom == 1.0, "可用的作者鏡頭原值完整保留")
	check(plan.art_gaps == Vector4.ZERO, "已覆蓋安全區的藝術沒有虛構延展缺口")
	plan = FramingPlan.solve(body, art, viewport, safe, Rect2(700, 0, 40, 360), author, 1.0, 0.0)
	check(plan.feasible and plan.actor_region == safe, "不與actual safe rect相交的字幕不裁掉角色區")
	plan = FramingPlan.solve(Rect2(300, 240, 40, 40), Rect2(-1000, -1000, 2000, 2000),
		viewport, safe, subtitle, Vector2(320, 0), 1.0, 0.0)
	check(plan.feasible and plan.zoom == 1.0 and plan.camera_position == Vector2(320, 180), "只需平移時保持作者zoom、選最近可行中心")
	# 基本 zoom 上下限重疊，但字幕迫使 actor 在 art 的下半部更靠上：q 必須≤3/4。
	body = Rect2(300, 250, 40, 50)
	plan = FramingPlan.solve(body, art, viewport, safe, subtitle, author, 1.0, 0.0)
	check(plan.feasible and is_equal_approx(plan.zoom, 4.0 / 3.0) and plan.camera_position.is_equal_approx(Vector2(320, 225)), "全部中心交集約束把作者 zoom 1 調到手算 4/3、中心 y225")
	_check_framing_projection(plan, body, art, safe, "中心限制")
	# 正好只有一個可行 zoom／中心，不得把閉區間交點當成無解。
	body = Rect2(0, 0, 640, 280)
	plan = FramingPlan.solve(body, art, viewport, safe, subtitle, Vector2(10, -10), 1.0, 0.0)
	check(plan.feasible and plan.camera_position == author and plan.zoom == 1.0, "零寬度可行區間保留其唯一鏡頭解")
	_check_framing_projection(plan, body, art, safe, "單點可行區間")
	# 演員在藝術邊界以外；雖然 fit_max≥cover_min，任何中心都不可能同時成立。
	body = Rect2(700, 100, 20, 50)
	plan = FramingPlan.solve(body, art, viewport, safe, Rect2(), author, 1.0, 0.0)
	check(plan.valid_input and not plan.feasible and plan.fit_zoom_max >= plan.cover_zoom_min, "不能只憑 zoom 範圍重疊宣稱中心有解")
	check(plan.reason == &"art_coverage_conflict" and is_equal_approx(plan.art_gaps.z, 80.0), "無解仍給美術可手算的右缺口80世界像素")
	check(plan.actor_region.grow(0.001).encloses(plan.project_rect(body)), "無解藝術候選仍完整保留演員頭腳")
	# 真實 ST-10 8Hz 廚房 actor 聯集，保留原尺寸；舊藝術不足，延展候選可解。
	body = Rect2(79.589, 65.353, 529.639, 256.711)
	var letterbox := CinematicFraming.rect_for(viewport)
	var portrait_reserve := Rect2(28, letterbox.end.y - 92, 584, 84)
	var old_art := Rect2(-64, -36, 768, 432)
	plan = FramingPlan.solve(body, old_art, viewport, letterbox, portrait_reserve, author, 1.0)
	check(not plan.feasible and plan.fit_zoom_max < plan.cover_zoom_min and plan.art_gaps.x > 0 and plan.art_gaps.w > 0, "實際廚房聯集需要左右與底部延展，不能縮單一角色通過")
	var extended_art := Rect2(-320, -180, 1280, 720)
	plan = FramingPlan.solve(body, extended_art, viewport, letterbox, portrait_reserve, author, 1.0)
	check(plan.feasible and plan.zoom < 1.0, "保留角色／家具相對比例，延展藝術後整個舞台可 zoom-out")
	_check_framing_projection(plan, body, extended_art, letterbox, "廚房延展候選")
	var offset := Vector2(10000, -5000)
	var shifted := FramingPlan.solve(Rect2(body.position + offset, body.size), Rect2(extended_art.position + offset, extended_art.size),
		viewport, letterbox, portrait_reserve, author + offset, 1.0)
	check(shifted.feasible and is_equal_approx(shifted.zoom, plan.zoom) and shifted.camera_position.is_equal_approx(plan.camera_position + offset), "平移舞台原點不改求解，不依賴固定地面或舞台中心")
	var wide := Vector2(840, 360)
	var wide_safe := CinematicFraming.rect_for(wide)
	plan = FramingPlan.solve(body, extended_art, wide, wide_safe, Rect2(28, 268, 784, 84), author, 1.0)
	check(plan.feasible and wide_safe.position.y == 0 and plan.actor_region.position.y == 4, "超寬輸入沿用實際全幅 safe rect，不再追加16:9黑邊")
	_check_framing_projection(plan, body, extended_art, wide_safe, "超寬延展候選")
	# 有效 UI 佔滿全畫面不等同壞資料；背景再大也不能產生全身空間。
	plan = FramingPlan.solve(body, extended_art, viewport, safe, safe, author, 1.0)
	check(plan.valid_input and not plan.feasible and plan.reason == &"empty_actor_region", "字幕沒有留下角色區時明確無解，不虛構背景缺口")
	for invalid: Rect2 in [Rect2(), Rect2(0, 0, -1, 10), Rect2(0, 0, 10, 0), Rect2(Vector2(NAN, 0), Vector2.ONE), Rect2(0, 0, INF, 1)]:
		check(not FramingPlan.solve(invalid, art, viewport, safe, Rect2(), author, 1.0).valid_input, "非法／零尺寸actor bounds安全拒絕")
		check(not FramingPlan.solve(Rect2(100, 100, 50, 50), invalid, viewport, safe, Rect2(), author, 1.0).valid_input, "非法／零尺寸art bounds安全拒絕")
	for bad_view: Vector2 in [Vector2.ZERO, Vector2(-1, 360), Vector2(640, INF)]:
		check(not FramingPlan.solve(body, art, bad_view, safe, Rect2(), author, 1.0).valid_input, "非法viewport不除以零或產生無限鏡頭")
	for bad_zoom: float in [0.0, -1.0, NAN, INF]:
		check(not FramingPlan.solve(body, art, viewport, safe, Rect2(), author, bad_zoom).valid_input, "非法作者zoom不形成可套用計畫")
	check(not FramingPlan.solve(body, art, viewport, Rect2(-1, 0, 640, 360), Rect2(), author, 1.0).valid_input, "actual safe rect不得越出viewport")
	check(not FramingPlan.solve(body, art, viewport, safe, Rect2(0, 200, 10, -1), author, 1.0).valid_input, "負字幕尺寸不是可選的空字幕")
	check(not FramingPlan.solve(body, art, viewport, safe, Rect2(), Vector2(INF, 0), 1.0).valid_input, "非法作者位置安全拒絕")
	check(not FramingPlan.solve(body, art, viewport, safe, Rect2(), author, 1.0, -1).valid_input, "負padding不能用擴大安全區繞過構圖")
	plan = FramingPlan.solve(body, art, viewport, safe, Rect2(), author, 1.0, 1.0e308)
	check(not plan.valid_input and not plan.feasible and plan.reason == &"numeric_overflow" \
		and plan.camera_position.is_finite() and plan.actor_region == Rect2() and plan.art_gaps.is_finite(), "有限輸入造成real_t溢位時回傳有限安全結果，不輸出可套用無限鏡頭")


func _check_framing_projection(plan: StageFramingPlan, body: Rect2, art: Rect2, safe: Rect2, description: String) -> void:
	check(plan.actor_region.grow(0.001).encloses(plan.project_rect(body)), description + "：頭與腳完整在字幕前安全區")
	check(plan.project_rect(art).grow(0.001).encloses(safe), description + "：藝術填滿actual safe rect")


func _test_pose_envelope_math() -> void:
	var arc := StagePoseEnvelope.rotated_point(Vector2(3, 4), Vector2(-PI / 2, PI / 2))
	check(is_equal_approx(arc.end.x, 5) and is_equal_approx(arc.position.y, -3) and is_equal_approx(arc.end.y, 5), "旋轉區間包含內部象限峰值，不只檢查姿勢端點")
	var circle := StagePoseEnvelope.rotated_point(Vector2(3, 4), Vector2(-TAU, TAU))
	check(circle == Rect2(-5, -5, 10, 10), "真正完整旋轉的半徑界線可手算，不加任意padding")
	for pair: Vector2 in [Vector2(16, 0.55), Vector2(12, 0.6), Vector2(14, 0.5), Vector2(18, 0.5), Vector2(14, 0.7)]:
		var gain := StagePoseEnvelope.spring_gain(pair.x, pair.y)
		check(is_finite(gain) and gain >= 1, "實際NPC follow/glance參數有可證明有限gain")
		var x := 0.0
		var v := 0.0
		var peak := 0.0
		# 不等子步、頻繁反向與停頓，不以這段有限執行冒充連續峰值證明。
		for i in 2400:
			var h := NpcLife.MAX_STEP * (0.1 + 0.9 * float((i * 37) % 101) / 100.0)
			var target := 1.0 if (i / 17) % 2 == 0 else -1.0
			v += (pair.x * pair.x * (target - x) - 2 * pair.y * pair.x * v) * h
			x += v * h
			peak = maxf(peak, absf(x))
		check(peak <= gain, "不等子步與反向輸入的真積分結果被解析spring界線包含")
	check(StagePoseEnvelope.spring_gain(0, 0.5) < 0 and StagePoseEnvelope.spring_gain(120, 0.5) < 0 \
		and StagePoseEnvelope.spring_gain(INF, 0.5) < 0, "不受支援的spring速率／非有限資料拒絕，不能產生假界線")
	var body := Rect2(100, 100, 100, 100)
	var art := Rect2(-1000, -1000, 2000, 2000)
	var safe := Rect2(0, 0, 640, 360)
	var plan := FramingPlan.solve(body, art, safe.size, safe, Rect2(0, 280, 640, 80), Vector2(320, 180), 1.0)
	var identity := plan.get_instance_id()
	for i in 120:
		var author := Vector2(50 + i * 9, -100 + i * 5)
		check(plan.follow_author(author, 0.2 + i * 0.03), "快取plan接受作者逐格Tween輸入")
		plan.constrain_shake(Vector2(500 * sin(i), -500 * cos(i)))
		_check_framing_projection(plan, body, art, safe, "快取Tween與震動")
	check(plan.get_instance_id() == identity, "逐格追蹤使用同一plan，不建立新求解器／角色bounds")


## exact double參數才可使用獨立整數證書；真NpcLife.follow保留非零速度及移動中點。
func _test_follow_history() -> void:
	var certified := [[12.0, 0.6, 1.285220], [14.0, 0.5, 1.528997], [14.0, 0.7, 1.142133],
		[16.0, 0.55, 1.407771], [18.0, 0.5, 1.555079]]
	for pair: Array in certified:
		var gain := StagePoseEnvelope.spring_gain(pair[0], pair[1])
		check(gain == pair[2], "exact w/z採用向外取整的有理不變多邊形gain")
		var unknown := StagePoseEnvelope.spring_gain(pair[0], pair[1] + 0.00001)
		check(unknown < 0 or unknown > gain, "其他w/z不能借用已知證書，仍走一般證明或拒絕")
		var life := NpcLife.new()
		life.setup("framing_history", {"follow": {"head": {"w": pair[0], "z": pair[1]}}}, {})
		var raw := Vector2(3, 3)
		check(life.follow(&"head", 3.0, 0.01) == 3.0 and life._spring_v[&"head"] == 0,
			"follow首target初始化位置，不能假設位置從0開始")
		# 刻意讓區間中點向兩側移動；每次擴張時保留actual x/v，不重建生命感層。
		for epoch in 4:
			var covered := true
			var moving_expansion := false
			for i in 240:
				var target: float = [-4.0, 7.0, -11.0, 15.0][epoch] + 0.7 * sin(i * 0.53)
				var next := StagePoseEnvelope.union_interval(raw, Vector2.ONE * target)
				moving_expansion = moving_expansion or (next != raw and absf(life._spring_v[&"head"]) > 0.01)
				raw = next
				var interval := StagePoseEnvelope.follow_interval(raw, gain)
				var dt := NpcLife.MAX_STEP * (0.2 + 1.8 * float((i * 37) % 101) / 100.0)
				var actual := life.follow(&"head", target, dt)
				covered = covered and actual >= interval.x - 0.00001 and actual <= interval.y + 0.00001
			check(covered and moving_expansion, "真follow在非零速度、中點移動、不等子步下仍被永久raw聯集包含")
		var current_only := StagePoseEnvelope.follow_interval(Vector2(20, 20), gain)
		check(life._spring_x[&"head"] < current_only.x, "只記新target、丟棄歷史會漏掉真餘勢；回歸不接受此做法")


## 以正式actor/rig、原scale驗新站姿與後續feet/human歷史；觀測不是連續證書替代品。
func _test_fresh_npc_ground() -> void:
	for entry: Array in [["rin", 3.8], ["old_k", 4.2]]:
		var actor := CutsceneActor.new()
		check(actor.setup(&"ground_history", entry[0], "", entry[1], ""), "正式廚房演員可建立接地fixture")
		actor.process_mode = Node.PROCESS_MODE_DISABLED
		runner.get_tree().root.add_child(actor)
		actor.ground_y = 298
		actor.position = Vector2(200, 298)
		var envelope := StagePoseEnvelope.new()
		check(envelope.include(actor), "新演員的初態可建立連續站姿包絡")
		var initial_ground := envelope._ground
		if entry[0] == "old_k":
			check(initial_ground == Vector2.ZERO and not envelope._plant_ground,
				"old_k grounding=false且無feet歷史，真ground只能是0")
		else:
			check(envelope._plant_ground and initial_ground.x > -1 and initial_ground.y < 3,
				"凜ground由零位移ankle FK反推，拒絕原無條件±16")
		check(not envelope.full_rotation_channels.has("head") and not envelope.full_rotation_channels.has("arm_front_lower"),
			"正式待機follow有有限角度，不再被鬆界誤分類為全旋轉")
		var stand_covered := true
		var ground_covered := true
		for i in 1200:
			actor.set_talking((i / 80) % 2 == 0)
			actor.set_listening((i / 80) % 2 != 0)
			actor._process(NpcLife.MAX_STEP * (0.2 + 1.8 * float((i * 37) % 101) / 100.0))
			var actual := actor.global_transform.affine_inverse() * actor.rig.visual_bounds()
			stand_covered = stand_covered and envelope.bounds.grow(0.001).encloses(actual)
			var shift := actor.rig.animator._ground_shift
			ground_covered = ground_covered and shift >= initial_ground.x - 0.00001 and shift <= initial_ground.y + 0.00001
		check(stand_covered and ground_covered, "正式%s待機、說話、聆聽、不等delta輪廓及ground在來源解析界線內" % entry[0])
		var replacement := StagePoseEnvelope.new()
		check(not replacement.include(actor) and replacement.reason.contains("歷史"),
			"中途新建包絡缺少已有spring速度，明確拒絕假初態")
		# 保留sit feet定義直到淡出，grounding=false也不能刪掉這段實際post_pose。
		actor.set_pose(&"sit")
		check(envelope.include(actor) and envelope._ground_extra.x == 0 and envelope._ground_extra.y > 0,
			"NPC sit使用真腿長/sag/reach推導非負drop，保留feet分支")
		var retained_drop := envelope._ground_extra
		var feet_covered := true
		for pose: StringName in [&"sit", &"idle"]:
			actor.set_pose(pose)
			check(envelope.include(actor) and envelope._ground_extra == retained_drop, "回站姿不清掉feet淡出歷史")
			for i in 90:
				actor._process(1.0 / 60)
				var actual := actor.global_transform.affine_inverse() * actor.rig.visual_bounds()
				feet_covered = feet_covered and envelope.bounds.grow(0.001).encloses(actual)
		check(feet_covered, "正式sit→idle包含feet淡入/淡出，並非只驗穩態")
		var life := (actor.rig.animator as NpcAnimator)._life
		var raw_before := envelope._follow_targets.duplicate()
		var velocities := life._spring_v.duplicate()
		actor.set_pose(&"walk")
		check(envelope.include(actor, Vector2(45, 0)), "human walk保留可達gait/IK保守分支")
		for i in 45:
			actor.position.x += 1.5
			actor._process(1.0 / 60)
		check(life._spring_v == velocities, "NPC→human實際分支凍結follow速度而非歸零")
		actor.set_pose(&"idle")
		check(envelope.include(actor) and envelope._follow_targets == raw_before,
			"回NPC重用永久raw歷史，中點與餘勢證明不因cached context丟失")
		if entry[0] == "rin":
			check(actor.rig.animator._run_w > 0 and not envelope._run_overlay.is_empty(),
				"actual gait結束仍有run overlay餘勢；NPC+overlay不能僅取聯集")
		else:
			check(envelope._run_overlay.is_empty(), "grounding=false無gait，不能憑空替old_k套run overlay")
		var resumed_covered := true
		var overlay_covered := true
		for i in 120:
			actor._process(1.0 / 60)
			var actual := actor.global_transform.affine_inverse() * actor.rig.visual_bounds()
			resumed_covered = resumed_covered and envelope.bounds.grow(0.001).encloses(actual)
			for bone: StringName in [&"hip", &"chest", &"head"]:
				var range_value: Vector2 = envelope._targets[bone] + envelope._run_overlay.get(bone, Vector2.ZERO)
				var angle := actor.rig.bone(bone).rotation
				overlay_covered = overlay_covered and angle >= range_value.x - 0.00001 and angle <= range_value.y + 0.00001
		check(resumed_covered and overlay_covered, "真human→NPC回程含殘留gait/feet/follow與附加overlay歷史")
		(life._cfg["follow"]["head"] as Dictionary)["w"] = 15.0
		check(not envelope.include(actor) and envelope.reason.contains("參數"),
			"即使context命中cache，運行中改spring參數也不能誤用舊證書")
		actor.queue_free()
		await frames(1)
	# 真animate(0)已初始化follow x但_time仍0；不能改pose後假裝v0/fresh。
	var zero_actor := CutsceneActor.new()
	check(zero_actor.setup(&"zero_history", "rin", "", 3.8, ""), "零delta fixture使用正式actor")
	zero_actor.process_mode = Node.PROCESS_MODE_DISABLED
	runner.get_tree().root.add_child(zero_actor)
	zero_actor._process(0.0)
	check(zero_actor.rig.animator._time == 0 and (zero_actor.rig.animator as NpcAnimator)._life != null,
		"actual零delta更新仍建立NpcLife，重現時間0不是新初態")
	zero_actor.set_pose(&"sit")
	var zero_envelope := StagePoseEnvelope.new()
	check(not zero_envelope.include(zero_actor) and zero_envelope.reason.contains("歷史"),
		"時間0但已有follow狀態時拒絕重新假定first target")
	zero_actor.queue_free()
	await frames(1)
	# NE-222新原生姿勢是Skeleton2D下的GPU蒙皮Polygon2D；cache hit前也必須拒絕。
	for mode in ["fresh", "append", "replace"]:
		var native_actor := CutsceneActor.new()
		check(native_actor.setup(&"native_mesh_guard", "rin", "", 3.8, ""), "未知蒙皮契約使用正式新actor")
		native_actor.process_mode = Node.PROCESS_MODE_DISABLED
		runner.get_tree().root.add_child(native_actor)
		var native_envelope := StagePoseEnvelope.new()
		if mode != "fresh":
			check(native_envelope.include(native_actor) and native_envelope.contexts == 1,
				"原拓撲context先真實建好，才能驗追加／替換不被cache hit繞過")
		var polygon := Polygon2D.new()
		polygon.polygon = PackedVector2Array([Vector2(0, 0), Vector2(10, 0), Vector2(0, 10)])
		native_actor.rig._skeleton.add_child(polygon)
		if mode == "replace":
			native_actor.rig._parts[0] = polygon
		else:
			native_actor.rig._parts.append(polygon)
		check(not native_envelope.include(native_actor) and native_envelope.reason.contains("Polygon2D"),
			"%s：未證明GPU蒙皮／bind_pose時拒絕，不用cache或原polygon假稱輪廓" % mode)
		native_actor.queue_free()
		await frames(1)


func _test_pose_envelope_actual() -> void:
	for entry: Dictionary in [{"kind": "rin", "loop": ""}, {"kind": "old_k", "loop": "stir"}, {"kind": "wataru", "loop": "pull_blanket"}, {"kind": "rin", "weapon": "rifle"}]:
		var actor := CutsceneActor.new()
		check(actor.setup(&"framing_test", entry["kind"], "", 2.0, entry.get("weapon", "")), "正式rig可建立解析envelope測試")
		actor.process_mode = Node.PROCESS_MODE_DISABLED
		runner.get_tree().root.add_child(actor)
		actor.ground_y = 298
		actor.position = Vector2(200, 298)
		actor.set_loop(StringName(entry.get("loop", "")))
		var envelope := StagePoseEnvelope.new()
		for pose: StringName in [&"idle", &"sit", &"idle", &"walk", &"crouch", &"jump", &"wave", &"listen"]:
			actor.set_pose(pose)
			actor.set_talking(pose == &"idle" or pose == &"sit")
			actor.set_listening(pose == &"listen")
			var ok := envelope.include(actor, Vector2(45, 0) if pose == &"walk" else Vector2.ZERO)
			check(ok and envelope.bounds.has_area(), "正式%s/%s取得保守pose/loop/weapon界線" % [entry["kind"], pose])
			var covered := true
			for frame in 120:
				if pose == &"walk":
					actor.position.x += 1.5
				actor._process(1.0 / 60)
				var actual := actor.global_transform.affine_inverse() * actor.rig.visual_bounds()
				covered = covered and envelope.bounds.grow(0.001).encloses(actual)
			check(covered, "正式%s/%s所有測試輪廓頭脚在解析界線內（有限回歸非峰值證明）" % [entry["kind"], pose])
		var contexts := envelope.contexts
		check(envelope.include(actor) and envelope.contexts == contexts, "相同pose/context重用累積界線，不掃描新mesh")
		actor.face(-1)
		check(envelope.include(actor) and envelope.contexts == contexts + 1, "facing是獨立cache鍵，保留翻面事件")
		actor._process(1.0 / 60)
		var flipped := actor.global_transform.affine_inverse() * actor.rig.visual_bounds()
		var reflected := Rect2(Vector2(-envelope.bounds.end.x, envelope.bounds.position.y), envelope.bounds.size)
		check(reflected.grow(0.001).encloses(flipped), "翻面後正式visual_bounds仍在鏡射解析界線內")
		actor.set_loop(StringName(entry.get("loop", "")), 1.25)
		check(envelope.include(actor) and envelope.contexts == contexts + 2, "loop_scale位元值參與cache鍵，不誤用舊幅度")
		var original_scale := actor.rig.scale
		actor.rig.scale *= Vector2(1.001, 1.0)
		var altered := StagePoseEnvelope.new()
		check(not altered.include(actor) and altered.reason.contains("非標準"), "同量化標準scale可用但實際非標準縮放仍拒絕")
		actor.rig.scale = original_scale
		if entry["kind"] == "old_k":
			# 容量驗證用新演員；新包絡不能假裝接管已播放演員的未知歷史。
			var capacity_actor := CutsceneActor.new()
			check(capacity_actor.setup(&"framing_capacity", "old_k", "", 2.0, ""), "容量fixture使用正式新rig")
			capacity_actor.process_mode = Node.PROCESS_MODE_DISABLED
			runner.get_tree().root.add_child(capacity_actor)
			var limited := StagePoseEnvelope.new()
			for i in StagePoseEnvelope.MAX_CONTEXTS:
				capacity_actor.set_loop(&"stir", 1.0 + i / 100.0)
				check(limited.include(capacity_actor), "有界context容量內可建立工作循環界線")
			capacity_actor.set_loop(&"stir", 4.0)
			check(not limited.include(capacity_actor) and limited.contexts == StagePoseEnvelope.MAX_CONTEXTS \
				and limited.reason.contains("容量"), "context上限拒絕新資料，不無限累積或默默用錯包絡")
			capacity_actor.queue_free()
		actor.set_pose(&"dead")
		check(not envelope.include(actor) and envelope.reason.contains("corpse"), "尚無corpse位移證明時明示unsupported，不聲稱頭脚已安全")
		actor.queue_free()
		await frames(1)


func _test_effective_camera_events() -> void:
	var player := CutscenePlayer.new()
	runner.get_tree().root.add_child(player)
	player._build_ui()
	player._layout_safe_rect(Story.framing.safe_rect())
	var stage := StageLibrary.Stage.new()
	player._stage = stage
	player._stage_holder.add_child(stage)
	# 幾何fixture明示大藝術，不把正式舊背景無解的條件改掉。
	player._framing_art = Rect2(-1000, -1000, 2000, 2000)
	player._framing_supported = true
	player._do_actor({"id": "rin", "kind": "rin", "scale": 2.0, "pos": [200, 298]})
	var status := player.framing_status()
	check(status["feasible"] and status["author_zoom"] == 1.0, "effective framing接入真播放器，作者鏡頭資料未被覆寫")
	if player._framing_plan == null:
		# 保留上面的功能失敗，清理並停止此案例，避免空值連鎖蓋掉真正原因。
		player.cancel()
		await frames(1)
		return
	var actor := player._actors[&"rin"]
	var scale_before := actor.scale
	var plan_identity := player._framing_plan.get_instance_id()
	player.cam_pos = Vector2(-500, -500)
	check(player.cam_pos == Vector2(-500, -500) and player.effective_cam_pos != player.cam_pos \
		and player._framing_plan.get_instance_id() == plan_identity, "作者camera setter只投影cache，不重建envelope或改Tween目標")
	await player._do_move({"id": "rin", "to": [400, 298], "time": 0.1, "wait": false})
	check(player._actor_origins[&"rin"].has_point(Vector2(399, 298)) \
		or player._actor_origins[&"rin"].end.x == 400, "移動尚未完成時界線已包括正式Tween終點")
	var movement_bounds := player._actor_origins[&"rin"]
	player._set_talkers(&"rin")
	check(player._actor_origins[&"rin"] == movement_bounds, "台詞事件不丟失未完成move的終點界線")
	await frames(16)
	check(not player._actor_motion.has(&"rin") and actor.position.is_equal_approx(Vector2(400, 298)), "正式move時間與終點保留，完成才釋放sweep")
	check(actor.scale == scale_before, "整舞台構圖不縮actor／家具比例")
	player._framing_art = Rect2(-64, -36, 768, 432)
	player._actor_origins[&"rin"] = Rect2(Vector2(3000, 298), Vector2.ZERO)
	player._rebuild_framing_plan()
	check(not player.framing_status()["feasible"] and player.effective_cam_pos == player.cam_pos \
		and player.effective_cam_zoom == player.cam_zoom, "正式藝術無解保留作者鏡頭，不能偷偷套黑底藝術候選")
	player._framing_art = Rect2(-1000, -1000, 2000, 2000)
	await player._do_move({"id": "rin", "to": [450, 298], "time": 5.0, "wait": false})
	await player._do_move({"id": "rin", "to": [500, 298], "time": 1.0, "wait": false})
	var unsupported := player.framing_status()
	check(not unsupported["supported"] and not unsupported["feasible"] \
		and str(unsupported["reason"]).contains("重疊 move") and player.effective_cam_pos == player.cam_pos, \
		"同actor重疊Tween無單一路徑證明時保留演出並明示unsupported")
	player.cancel()
	await frames(1)
	check(not is_instance_valid(player), "cancel釋放播放器與有界pose cache，不改Story完成語义")


func _test_saved_arena_initialization() -> void:
	Story.auto_skip = true
	var data := (load("res://data/levels/level_01.tres") as LevelData).duplicate() as LevelData
	data.intro_scene = &""
	data.boss_scene = &""
	data.show_chapter_card = false
	var original := await start_level(data)
	original._start_boss_fight()
	var deadline := Time.get_ticks_msec() + 4000
	while not original._boss_spawned and Time.get_ticks_msec() < deadline:
		await runner.get_tree().process_frame
	check(original._arena_triggered and original._boss_spawned and original.camera != null, "normal new arena initializes camera before boss lock and spawn")
	var runtime := original.run_snapshot()
	var boss_resource: String = original._layout.boss_spawn["resource"].resource_path
	await end_level(original)
	var restored := Level.new()
	restored.configure(data)
	restored.configure_resume(runtime)
	runner.get_tree().root.add_child(restored)
	await frames(4)
	check(restored._arena_triggered and restored._boss_spawned and restored.camera != null, "saved active arena restores lock only after camera ready")
	var bosses := 0
	for entry: Dictionary in restored._capture_enemies():
		if entry["resource"] == boss_resource:
			bosses += 1
	check(bosses == 1, "saved active arena restores exactly its existing boss without spawning another")
	await end_level(restored)


func _test_resumed_boss_cancel() -> void:
	var scene := &"st22_resumed_boss"
	Story._scenes[String(scene)] = {"mode": "cinematic", "lines": [{"speaker": "rin", "text": "電影真正完成後才開始頭目戰。"}]}
	for cancel in [true, false]:
		GameState.start_new_run(GameState.difficulties[1])
		Story.auto_skip = false
		var data := (load("res://data/levels/level_01.tres") as LevelData).duplicate() as LevelData
		data.intro_scene = &""
		data.boss_scene = scene
		data.show_chapter_card = false
		var level := Level.new()
		level.configure(data)
		level.configure_resume({"arena": true, "boss_pending": true, "cinematic": String(scene), "loadout": {}, "world": {}, "position": [-1, -1]})
		runner.get_tree().root.add_child(level)
		for frame in 4:
			await runner.get_tree().process_frame
		check(Story.is_cinematic_active() and not level._boss_spawned, "actual boss_pending resume waits for its movie")
		if cancel:
			Story.reset_active_presentation(&"route")
		else:
			Story.skip_cinematic()
		for frame in 4:
			await runner.get_tree().process_frame
		check(level._boss_spawned == not cancel, "resumed boss completion gate: cancel=%s spawned=%s settled=%s" % [cancel, level._boss_spawned, level._resumed_presentation_settled])
		await end_level(level)
	Story._scenes.erase(String(scene))
	Story.auto_skip = true


func _test_framing_lifecycle() -> void:
	var reduced := Settings.get_reduce_ui_motion()
	Settings.set_reduce_ui_motion(true)
	var first := Node.new()
	var second := Node.new()
	runner.add_child(first)
	runner.add_child(second)
	var first_token := Story.framing.acquire(first)
	Story.framing.acquire(second)
	check(Story.framing.scope_count() == 2 and is_equal_approx(Story.framing.amount, 1.0), "nested cinematic owners share one full framing scope")
	Story.framing.release(first_token)
	check(Story.framing.scope_count() == 1 and is_equal_approx(Story.framing.amount, 1.0), "out-of-order release keeps the remaining owner framed")
	second.queue_free()
	await frames(2)
	check(Story.framing.scope_count() == 0 and is_zero_approx(Story.framing.amount), "owner removal automatically restores framing")
	first.queue_free()
	var movie := _play(&"framing_choice", {"steps": [{"do": "choice", "text": "請選擇要走的方向。", "default": "stay", "options": [
		{"id": "stay", "text": "先留在這裡。", "set_flags": {"st22_cancel_default": true}}, {"id": "go", "text": "前往下一個房間。"}
	]}]}, 1.0)
	for i in 30:
		if movie.choice_active():
			break
		await frames(1)
	check(movie.choice_active() and Story.framing.scope_count() == 1, "real movie choice owns formal framing")
	var safe := Story.framing.safe_rect()
	check(safe.encloses(movie._choice.get_rect()), "choice buttons lie inside the actual cinematic safe rect")
	movie.cancel()
	await frames(2)
	check(not GameplayLock.is_locked() and Story.framing.scope_count() == 0, "cancelling a choice releases both input and framing")
	check(not _finished_ids.has(&"framing_choice"), "cancelled movie choice is not reported as completed")
	check(not GameState.has_flag(&"st22_cancel_default"), "cancellation does not apply a skipped choice default flag")
	var overlay := _play(&"framing_overlay", {"overlay": true, "steps": [{"do": "wait", "time": 10.0}]}, 1.0)
	await frames(2)
	check(Story.framing.scope_count() == 0 and is_zero_approx(Story.framing.amount), "ordinary overlay FX never acquires cinematic framing")
	overlay.cancel()
	await frames(2)
	Settings.set_reduce_ui_motion(reduced)


func _test_walk_matches_stage_motion() -> void:
	for skin in ["rin", "old_k"]:
		for actor_scale in [1.0, 3.8, 4.2]:
			for direction in [1, -1]:
				var actor := CutsceneActor.new()
				runner.add_child(actor)
				actor.set_process(false)
				check(actor.setup(&"walk_test", skin, "", actor_scale, ""), "walking actor builds")
				actor.position = Vector2(575, 304)
				actor.face(direction)
				actor.set_pose(&"walk")
				actor._process(1.0 / 60.0)
				check(actor._input.velocity.is_zero_approx(), "spawning a walking actor does not create a teleport stride")
				var expected: float = 94.230769 * direction / actor_scale / actor.rig.body_scale()
				for frame in 30:
					actor.position.x += 94.230769 * direction / 60.0
					actor._process(1.0 / 60.0)
				check(absf(actor._input.velocity.x - expected) < 0.002, "stage speed and direction reach the leg solver at actor scale")
				actor._process(1.0 / 60.0)
				check(actor._input.velocity.is_zero_approx(), "a stopped move stops stepping")
				actor.set_pose(&"run")
				actor.position.x += 150.0 * direction * actor_scale * actor.rig.body_scale() / 60.0
				actor._process(1.0 / 60.0)
				check(absf(actor._input.velocity.x - 150.0 * direction) < 0.002, "run uses actual translation too")
				actor.free()


## 坐在桌上、箱子上的演員站起來時，腳要落回舞台的地面線，不能留在座位的高度浮空（NE-214）。
func _test_stand_up_returns_to_the_floor() -> void:
	var actor := CutsceneActor.new()
	runner.add_child(actor)
	check(actor.setup(&"t", "rin", "", 1.0, ""), "an actor with a skeleton is built")
	actor.ground_y = 280.0
	actor.position = Vector2(100, 232.0)  # 坐在離地 48 像素的檢查台上
	actor.set_pose(&"sit")
	await frames(3)
	check(is_equal_approx(actor.position.y, 232.0), "sitting keeps the seat height")
	actor.set_pose(&"idle")
	for i in 90:
		await runner.get_tree().process_frame
	check(is_equal_approx(actor.position.y, 280.0), "standing up puts the feet back on the floor line (%.1f)" % actor.position.y)
	var free_actor := CutsceneActor.new()
	runner.add_child(free_actor)
	free_actor.setup(&"u", "rin", "", 1.0, "")
	free_actor.position = Vector2(50, 200.0)
	free_actor.set_pose(&"sit")
	free_actor.set_pose(&"idle")
	await frames(3)
	check(is_equal_approx(free_actor.position.y, 200.0), "an actor without a registered floor stays where the scene put it")
	actor.queue_free()
	free_actor.queue_free()
	await frames(2)


func _test_lock_lifecycle() -> void:
	var tree := runner.get_tree()
	var mouse_mode := Input.mouse_mode
	tree.paused = false
	var first := Node.new()
	var second := Node.new()
	runner.add_child(first)
	runner.add_child(second)
	var token := GameplayLock.acquire(first, Input.MOUSE_MODE_HIDDEN)
	var other := GameplayLock.acquire(second, Input.MOUSE_MODE_VISIBLE)
	GameplayLock.release(token)
	GameplayLock.release(token)
	check(tree.paused and GameplayLock.is_locked() and Input.mouse_mode == Input.MOUSE_MODE_VISIBLE, "重複釋放不影響其他演出與游標")
	second.queue_free()
	await frames(2)
	check(not tree.paused and not GameplayLock.is_locked() and Input.mouse_mode == mouse_mode, "owner 中途刪除自動回收最後一把鎖並還原游標")
	GameplayLock.release(other)
	first.queue_free()
	# 目的畫面解除舊選單的暫停，不能同時解除正在播放的演出。
	tree.paused = true
	var owner := Node.new()
	runner.add_child(owner)
	token = GameplayLock.acquire(owner)
	GameplayLock.set_base_paused(false)
	UiKit.set_cursor_visible(false)
	check(tree.paused, "換畫面更新基礎暫停仍保留演出鎖")
	GameplayLock.release(token)
	check(not tree.paused, "最後演出結束使用目的畫面的暫停狀態")
	# headless DisplayServer 的 mouse_mode 永遠回傳 VISIBLE；仍驗證保存的目的畫面需求。
	check(GameplayLock._base_mouse_mode == Input.MOUSE_MODE_HIDDEN and (DisplayServer.get_name() == "headless" or Input.mouse_mode == Input.MOUSE_MODE_HIDDEN), "轉場結束保留目的關卡的隱藏游標，不還原主選單游標")
	GameplayLock.set_base_mouse_mode(mouse_mode)
	owner.queue_free()
	# 真正的播放器中途刪除也能還原。
	var cinematic := _play(&"test_deleted", {"overlay": true, "steps": [{"do": "wait", "time": 30.0}]}, 1.0)
	await frames(2)
	cinematic.queue_free()
	await frames(2)
	check(not tree.paused and not GameplayLock.is_locked(), "播放器中途刪除不留下暫停或輸入鎖")
	# 阻擋式章節卡必須保留原本的手動暫停。
	tree.paused = true
	var card := ChapterCard.new()
	card.block = true
	runner.add_child(card)
	card._done()
	check(tree.paused and not GameplayLock.is_locked(), "章末卡結束保留原本手動暫停")
	tree.paused = false
	await frames(2)


## 用真正的玩家、音效訊號與輸入事件驗證，包含每影格輪詢及 ALWAYS 節點。
func _test_gameplay_input_lock() -> void:
	var level := await start_level(PropsSuite.level_data())
	var player := level.player
	await physics_frames(10)
	var sounds: Array[StringName] = []
	var on_sound := func(id: StringName) -> void: sounds.append(id)
	Sfx.sound_played.connect(on_sound)
	player._jump_buffer_left = 0.1
	player._dash_buffer_left = 0.1
	player._melee_buffer_left = 0.1
	var cinematic := _play(&"test_input_lock", {"overlay": true, "steps": [{"do": "wait", "time": 30.0}]}, 1.0)
	check(player._jump_buffer_left == 0.0 and player._dash_buffer_left == 0.0 and player._melee_buffer_left == 0.0, "過場開始清除玩家動作緩衝")
	var before := player.global_position
	var mag := player.loadout.mag_in(player.loadout.active_slot)
	var fire_sound := player.loadout.active_weapon().fire_sound
	var old_mode := player.process_mode
	player.process_mode = Node.PROCESS_MODE_ALWAYS
	var click := InputEventMouseButton.new()
	click.button_index = MOUSE_BUTTON_LEFT
	click.pressed = true
	Input.parse_input_event(click)
	Input.action_press(&"move_right")
	await physics_frames(12)
	check(player.global_position == before and player.loadout.mag_in(player.loadout.active_slot) == mag, "過場中的左鍵與移動輸入不能移動或消耗彈藥")
	check(not sounds.has(fire_sound), "過場點擊不會播放玩家開槍聲")
	var reload_event := InputEventAction.new()
	reload_event.action = &"reload"
	reload_event.pressed = true
	player._unhandled_input(reload_event)
	check(not player.loadout.is_reloading(), "過場事件輸入不能換彈")
	level._pause_menu.open()
	level._inventory.open()
	DevMenu.open()
	check(not level._pause_menu._root.visible and not level._inventory.is_open() and not DevMenu.is_open, "過場阻擋暫停、背包與開發選單")
	var done := [false]
	cinematic.finished.connect(func(_id: StringName) -> void: done[0] = true)
	cinematic.skip()
	for i in 60:
		if done[0]:
			break
		await runner.get_tree().process_frame
	check(done[0] and not runner.get_tree().paused and not GameplayLock.is_locked(), "過場結束當下恢復遊戲")
	await physics_frames(3)
	check(player.loadout.mag_in(player.loadout.active_slot) == mag and not sounds.has(fire_sound), "過場最後的點擊不會在恢復後補開槍")
	player.process_mode = old_mode
	Input.action_press(&"move_right")
	await physics_frames(8)
	Input.action_release(&"move_right")
	check(player.global_position.x > before.x, "過場後不按 Esc 就能正常移動")
	Input.action_press(&"shoot")
	await physics_frames(2)
	Input.action_release(&"shoot")
	check(player.loadout.mag_in(player.loadout.active_slot) < mag and sounds.has(fire_sound), "恢復後重新按射擊仍能正常開槍")
	Sfx.sound_played.disconnect(on_sound)
	await end_level(level)


func _test_skip_covered_transition() -> void:
	var instant := Transition.instant
	Transition.instant = false
	var cinematic := _play(&"test_skip_covered", {"overlay": true, "steps": [
		{"do": "transition", "kind": "fade", "mode": "cover", "time": 0.03},
		{"do": "wait", "time": 30.0},
		{"do": "transition", "kind": "fade", "mode": "reveal", "time": 0.03},
	]}, 1.0)
	for i in 120:
		if Transition.is_active() and Transition._rect.visible:
			break
		await runner.get_tree().process_frame
	var escape := InputEventKey.new()
	escape.keycode = KEY_ESCAPE
	escape.pressed = true
	Input.parse_input_event(escape)
	check(await _wait_finished(&"test_skip_covered", 120), "Esc 能跳過包含轉場的演出")
	check(not Transition.is_active() and not runner.get_tree().paused and not GameplayLock.is_locked(), "跳過演出會清掉它的轉場，不留下黑畫面或暫停")
	Transition.instant = instant


func _speakers() -> Dictionary:
	return {"rin": {}, "old_k": {}}


func _test_checker() -> void:
	check(CutsceneChecker.validate("good", GOOD_SCENE, _speakers()).is_empty(), "正常的演出資料通過檢查")
	var bad := {"steps": [
		{"do": "actor", "id": "x", "kind": "rin", "pos": [0, 0]},
		{"do": "scene", "id": "no_such_stage"},
		{"do": "move", "id": "ghost", "to": [1, 1]},
		{"do": "say", "speaker": "nobody", "text": "a"},
		{"do": "say", "speaker": "rin", "text": "b", "style": "weird"},
		{"do": "say", "speaker": "rin", "text": "c"},
		{"do": "say", "speaker": "rin", "text": "d"},
		{"do": "fx", "kind": "nope"},
		{"do": "sfx", "id": "no_such_sfx"},
		{"do": "transition", "kind": "spin"},
		{"do": "dance"},
		{"do": "wait"},
	]}
	var joined := "\n".join(CutsceneChecker.validate("bad", bad, _speakers()))
	for needle in ["之前沒有指定場景", "no_such_stage", "ghost", "nobody", "weird", "連續超過", "nope", "no_such_sfx", "spin", "dance", "time"]:
		check(joined.contains(needle), "檢查工具能指出問題：%s" % needle)
	var long_text := {"steps": [{"do": "scene", "id": "test_room"}, {"do": "say", "speaker": "rin", "text": "字".repeat(60)}]}
	check(not CutsceneChecker.validate("long", long_text, _speakers()).is_empty(), "台詞太長會被指出")
	var too_many: Array = [{"do": "scene", "id": "test_room"}]
	for i in 18:
		too_many.append({"do": "say", "speaker": "rin", "text": "好"})
		too_many.append({"do": "wait", "time": 0.1})
	check("\n".join(CutsceneChecker.validate("many", {"steps": too_many}, _speakers())).contains("上限 16"), "台詞總數超過 16 句會被指出")
	check(not CutsceneChecker.validate("empty", {"steps": []}, _speakers()).is_empty(), "沒有步驟會被指出")


func _test_stages() -> void:
	var ids := StageLibrary.ids()
	check(ids.size() >= 2, "舞台庫有場景（%d）" % ids.size())
	for id in ids:
		check(StageLibrary.validate(id).is_empty(), "舞台 %s 通過檢查" % id)
	var stage := StageLibrary.build(&"test_room")
	check(stage.back.get_child_count() > 0 and stage.front.get_child_count() > 0, "舞台分成後層與前層")
	stage.free()
	var broken := StageLayers.create({"kind": "gradient"}, "test_bad_cutscene 圖層")
	check(broken == null, "缺欄位的圖層回傳 null 而不是崩潰")
	check(StageLayers.create({"kind": "nonsense"}, "test_bad_cutscene 圖層") == null, "未知圖層種類回傳 null")
	# 窗光閃爍（life）只能用在小面積的層：整張背景開了它會變成一格一格忽明忽暗的方塊。
	var scene_art := "res://art/environment/scenes/pawnshop_front.webp"
	check(StageLibrary.life_covers_stage({"path": scene_art, "source_width": 1280, "scale": 0.5, "life": true}), "整張背景開 life 會被抓到")
	check(not StageLibrary.life_covers_stage({"path": scene_art, "source_width": 1280, "scale": 0.5}), "沒開 life 的背景沒有問題")
	check(not StageLibrary.life_covers_stage({"path": scene_art, "source_width": 1280, "scale": 0.1, "life": true}), "小面積的層可以開 life")
	for stage_id in ["ch1_pawnshop_front", "ch1_dawn_noodle_stall", "ch1_revival_room", "rainy_harbor", "elevator_rise"]:
		check(StageLibrary.validate(StringName(stage_id)).is_empty(), "舞台 %s 通過檢查：%s" % [stage_id, StageLibrary.validate(StringName(stage_id))])


func _play(id: StringName, scene: Dictionary, speed := 40.0) -> CutscenePlayer:
	var player := CutscenePlayer.new()
	player.speed = speed
	runner.add_child(player)
	player.finished.connect(func(done: StringName) -> void:
		_steps_done[done] = player.steps_run
		_finished_ids.append(done))
	player.play(id, scene)
	return player


func _wait_finished(id: StringName, max_frames := 900) -> bool:
	for i in max_frames:
		if _finished_ids.has(id):
			return true
		await runner.get_tree().process_frame
	return _finished_ids.has(id)


func _test_play_all_steps() -> void:
	_finished_ids.clear()
	var player := _play(&"test_all_steps", GOOD_SCENE)
	await frames(3)
	check(runner.get_tree().paused, "演出時遊戲暫停")
	check(await _wait_finished(&"test_all_steps"), "包含所有步驟的演出能播完")
	var done_count: int = _steps_done.get(&"test_all_steps", -1)
	check(done_count == GOOD_SCENE["steps"].size(), "每個步驟都執行了（%d / %d）" % [done_count, GOOD_SCENE["steps"].size()])
	await frames(2)
	check(not is_instance_valid(player), "演出結束後播放器釋放")
	check(not runner.get_tree().paused, "演出結束後還原成未暫停")


func _test_skip() -> void:
	_finished_ids.clear()
	var scene := {"steps": [{"do": "scene", "id": "test_room"}, {"do": "wait", "time": 30.0}, {"do": "wait", "time": 30.0}]}
	var player := _play(&"test_skip", scene, 1.0)
	await runner.get_tree().create_timer(0.3).timeout
	check(not _finished_ids.has(&"test_skip"), "長演出還在播放")
	player.skip()
	check(await _wait_finished(&"test_skip", 60), "跳過後立刻結束")
	check(not runner.get_tree().paused, "跳過後遊戲恢復")


func _test_broken_data() -> void:
	_finished_ids.clear()
	var scene := {"steps": [
		{"do": "move", "id": "ghost", "to": [1, 1]},
		{"do": "scene", "id": "no_such_stage"},
		{"do": "scene", "id": "test_room"},
		{"do": "actor", "id": "bad", "kind": "no_such_character", "pos": [10, 10]},
		{"do": "dance"},
		"not a dictionary",
		{"do": "fx", "kind": "tint"},
		{"do": "transition", "kind": "spin"},
		{"do": "wait", "time": 0.05},
	]}
	var player := _play(&"test_bad_cutscene", scene)
	check(await _wait_finished(&"test_bad_cutscene"), "資料損毀的演出略過壞步驟後仍然結束")
	check(int(_steps_done.get(&"test_bad_cutscene", 0)) >= 2, "好的步驟照常執行")


func _test_pause_restored() -> void:
	_finished_ids.clear()
	runner.get_tree().paused = true
	var player := _play(&"test_pause_kept", {"steps": [{"do": "scene", "id": "test_room"}, {"do": "wait", "time": 0.05}]})
	check(await _wait_finished(&"test_pause_kept"), "演出播完")
	check(runner.get_tree().paused, "演出前就暫停時，演出後仍然暫停")
	runner.get_tree().paused = false
	await frames(2)


func _test_story_integration() -> void:
	var previous_auto := Story.auto_skip
	Story.auto_skip = false
	Story._scenes["test_anim_scene"] = {"mode": "animated", "steps": [{"do": "scene", "id": "test_room", "fade": 0.05}, {"do": "wait", "time": 0.05}]}
	var modes: Array[StringName] = []
	var on_started := func(id: StringName, mode: StringName) -> void:
		if id == &"test_anim_scene":
			modes.append(mode)
	Story.scene_started.connect(on_started)
	var player_done := [false]
	Story.scene_finished.connect(func(id: StringName) -> void:
		if id == &"test_anim_scene":
			player_done[0] = true, CONNECT_ONE_SHOT)
	check(Story.play(&"test_anim_scene", false), "Story 可以播放動畫場景")
	check(Story.is_cinematic_active(), "動畫場景視為過場（暫停遊戲、排隊）")
	if Story._player != null:
		Story._player.speed = 40.0
	for i in 600:
		if player_done[0]:
			break
		await runner.get_tree().process_frame
	check(player_done[0], "動畫場景播完後發出結束訊號")
	check(modes.has(Story.MODE_ANIMATED), "開始訊號標示為動畫模式")
	check(not Story.is_cinematic_active(), "播完後不再是過場狀態")

	# 設定「略過過場動畫」時直接結束。
	Settings.set_skip_cutscenes(true)
	player_done[0] = false
	Story.scene_finished.connect(func(id: StringName) -> void:
		if id == &"test_anim_scene":
			player_done[0] = true, CONNECT_ONE_SHOT)
	Story.play(&"test_anim_scene", false)
	await frames(3)
	check(player_done[0], "開啟略過設定後動畫場景立刻結束")
	Settings.set_skip_cutscenes(false)
	Story.scene_started.disconnect(on_started)
	Story._scenes.erase("test_anim_scene")
	Story.auto_skip = previous_auto


func _test_real_data() -> void:
	check(Story.validate().is_empty(), "所有章節劇本（含動畫場景）通過檢查")


## 疊加演出（直接蓋在遊戲畫面上）、數字計數器、道具貼圖的自發光層。
func _test_overlay_and_layers() -> void:
	_finished_ids.clear()
	var overlay := {"overlay": true, "steps": [{"do": "fx", "kind": "noise", "time": 0.1}, {"do": "wait", "time": 0.1}]}
	check(CutsceneChecker.validate("overlay", overlay, _speakers()).is_empty(), "疊加演出不需要舞台也能通過檢查")
	var player := _play(&"test_overlay", overlay, 1.0)
	await frames(2)
	var backdrop := player._root.get_child(0) as ColorRect
	check(backdrop.color.a == 0.0 and player._fade.color.a == 0.0, "疊加演出不蓋黑底，遊戲畫面看得到")
	player.speed = 40.0
	check(await _wait_finished(&"test_overlay"), "疊加演出播完")

	var counter := StageLayers.create({"kind": "counter", "pos": [0, 0], "from": 10, "to": 20, "time": 1.0}, "test counter")
	check(counter != null and counter.call("current") == 10, "計數器從起始值開始")
	counter.call("_process", 0.5)
	check(counter.call("current") == 15, "計數器隨時間往上數")
	counter.call("_process", 5.0)
	check(counter.call("current") == 20, "計數器停在終點")
	counter.free()

	var motes := StageLayers.create({"kind": "motes", "count": 12, "area": [10, 20, 100, 50]}, "test motes")
	check(motes != null and motes.get("_points").size() == 12, "塵粒圖層建立固定數量的粒子")
	motes.call("_process", 30.0)
	var inside := true
	for point: Vector2 in motes.get("_points"):
		inside = inside and point.x >= 0.0 and point.x <= 100.0 and point.y >= 0.0 and point.y <= 50.0
	check(inside, "塵粒漂移後仍在指定範圍內（循環使用，不配置新物件）")
	motes.free()
	var pulsing := StageLayers.create({"kind": "glow", "pos": [0, 0], "radius": 20, "color": "#ff3322", "pulse": 1.0, "pulse_depth": 0.8}, "test pulse")
	var bright: float = pulsing.self_modulate.r
	pulsing.call("_process", 0.25)
	check(pulsing.self_modulate.r < bright * 0.5, "脈動的柔光在週期的一半暗下來")
	pulsing.free()

	var sprite := StageLayers.create({"kind": "sprite", "path": "res://art/environment/props/window_rain.png", "pos": [0, 0], "scale": 0.5}, "test sprite")
	check(sprite != null and sprite.get_child_count() == 1, "道具貼圖附帶自發光層")
	sprite.free()
	var plain := StageLayers.create({"kind": "sprite", "path": "res://art/environment/props/trash_can.png", "pos": [0, 0]}, "test sprite")
	check(plain != null and plain.get_child_count() == 0, "沒有自發光層的道具不加多餘節點")
	plain.free()


func _test_story_features() -> void:
	var previous_auto := Story.auto_skip
	var previous_flags := GameState.world_flags.duplicate(true)
	var previous_defaults := GameState.flag_defaults.duplicate(true)
	var previous_items := StoryItems.snapshot()
	var previous_seen := Story.progress_snapshot()
	var previous_sequences := Story._death_sequences.duplicate(true)
	check(Story.load_chapter("res://tests/fixtures/story_features.json"), "ST-3 fixture loads through the chapter API")
	for entry in [[false, false], [true, true], [0, false], [2, true], [0.0, false], [-0.5, true], ["", false], ["ask", true]]:
		GameState.set_flag(&"test_story_route", entry[0])
		check(GameState.has_flag(&"test_story_route") == entry[1], "native story truth handles scalar %s" % str(entry[0]))
		check(StoryRules.eligible({"requires_flag": "test_story_route"}, GameState.has_flag, StoryItems.owns) == entry[1], "branch prerequisites use the same scalar truth")
	GameState.set_flag(&"test_story_route", "")
	var scene: Dictionary = Story._scenes["test_story_choice"]
	check(CutsceneChecker.validate("test_story_choice", scene, Story._speakers).is_empty(), "choice and inline branches validate")
	Story.auto_skip = false
	var player := CutscenePlayer.new()
	runner.add_child(player)
	player.speed = 100.0
	player.play(&"test_story_choice", scene)
	for i in 90:
		if player.choice_active():
			break
		await frames(1)
	check(not Story.progress_snapshot().has(&"test_story_choice"), "unfinished scenes are excluded from serialized seen records")
	check(player.choice_active() and runner.get_tree().paused, "a choice waits for real input while gameplay is locked")
	check((player._choice.get_child(1) as Button).has_focus(), "the first choice starts with keyboard/controller focus")
	var accept := InputEventAction.new()
	accept.action = &"ui_accept"
	accept.pressed = true
	Input.parse_input_event(accept)
	Input.flush_buffered_events()
	await runner.get_tree().process_frame
	accept = InputEventAction.new()
	accept.action = &"ui_accept"
	accept.pressed = false
	Input.parse_input_event(accept)
	Input.flush_buffered_events()
	await runner.get_tree().process_frame
	check(GameState.has_flag(&"test_story_decision"), "native confirm input selects the focused ask option")
	check(GameState.has_flag(&"test_story_decision"), "selection records its flag")
	for i in 90:
		if not is_instance_valid(player):
			break
		await frames(1)
	check(not runner.get_tree().paused, "a chosen branch finishes and releases gameplay")
	player = CutscenePlayer.new()
	runner.add_child(player)
	player.speed = 100.0
	player.play(&"test_story_choice", scene)
	for i in 90:
		if player.choice_active():
			break
		await frames(1)
	check(player.choose(1), "the leave option can be selected")
	check(not GameState.has_flag(&"test_story_decision"), "the alternative choice writes false rather than another true flag")
	player.skip()
	for i in 90:
		if not is_instance_valid(player):
			break
		await frames(1)
	Story.auto_skip = true
	Story.apply_default_choices(scene)
	check(not GameState.has_flag(&"test_story_decision"), "skipping resolves an unanswered choice using the declared default")
	StoryItems.acquire(&"doc_crayon_drawing", false)
	check(StoryRules.eligible({"requires_item": "doc_crayon_drawing"}, GameState.has_flag, StoryItems.owns), "later story conditions inspect the existing inventory")
	check(not StoryRules.eligible({"requires_item": "missing_item"}, GameState.has_flag, StoryItems.owns), "missing story items cannot satisfy a condition")
	Story._seen[&"test_story_object"] = true
	Story._completed[&"test_story_object"] = true
	GameState.set_flag(&"test_story_visits", 2)
	GameState.set_flag(&"test_story_route", "ask")
	check(GameState.save_story_progress("user://test_story_progress.json"), "story flags, items and completed interactions save to disk")
	GameState.world_flags.clear()
	StoryItems._owned.clear()
	Story._seen.clear()
	check(GameState.load_story_progress("user://test_story_progress.json"), "saved story progress can be reopened")
	check(GameState.get_flag(&"test_story_visits") == 2 and Story.was_seen(&"test_story_object") and StoryItems.owns(&"doc_crayon_drawing"), "disk roundtrip retains numbers, seen objects and story items")
	check(GameState.get_flag(&"test_story_route") == "ask" and GameState.has_flag(&"test_story_route"), "string route survives disk restore and remains usable as a condition")
	var broken_file := FileAccess.open("user://test_story_progress.json", FileAccess.WRITE)
	broken_file.store_string("{ broken JSON")
	broken_file.close()
	check(not GameState.load_story_progress("user://test_story_progress.json"), "invalid JSON reports its file and line and restores safe defaults")
	GameState.restore_story_progress({"flags": {"test_story_visits": []}}, "test_bad_cutscene/save")
	check(GameState.get_flag(&"test_story_visits") == 0 and GameState.get_flag(&"test_story_decision") == false, "missing or corrupted flags restore declared defaults")
	check(GameState.get_flag(&"test_story_route") == "" and not GameState.has_flag(&"test_story_route"), "missing string route restores an empty, false default")
	var npc := NpcData.new()
	npc.id = &"test_object"
	npc.display_name = "測試物件"
	npc.kind = NpcData.Kind.OBJECT
	var talk := NpcTalk.new()
	talk.scene = &"test_story_object"
	talk.once = true
	talk.story_item = StoryItems.find(&"old_k_order")
	npc.talks = [talk]
	check(npc.validate().is_empty(), "an investigation can award an ordinary story item using existing NpcTalk data")
	check(npc.pick_talk(0, func(_id: StringName) -> bool: return false) == 0 and npc.pick_talk(0, func(_id: StringName) -> bool: return true) == -1, "a once-only investigation cannot be counted twice")
	talk.requires_item = &"doc_crayon_drawing"
	check(npc.pick_talk(0, func(_id: StringName) -> bool: return false, 0, GameState.has_flag, func(_id: StringName) -> bool: return false) == -1, "investigation item requirements block unavailable lines")
	check(not Story.validate_death_sequences("test", [{"steps": [{"kind": "unknown", "time": []}]}]).is_empty(), "startup validation catches malformed death sequence positions")
	var first := Story.death_sequence(&"ch1_kasa", 1)
	var second := Story.death_sequence(&"ch1_kasa", 2)
	var third := Story.death_sequence(&"ch1_kasa", 3)
	check(first.steps.size() == 4 and second.steps.size() == 2 and third.skippable, "first death is complete, second is shorter, third is skippable")
	var screen := DeathScreen.new()
	screen.sequence = first
	screen.setup({"title": "記憶卡", "text": "測試記憶。"}, true)
	runner.add_child(screen)
	check(screen.sequence_index == 0, "death sequence starts with the first line")
	for i in 240:
		if screen.sequence_complete:
			break
		await frames(1)
	check(screen.sequence_complete and screen.sequence_index == 3, "death sequence reaches the memory card in order")
	screen.queue_free()
	await frames(2)
	var table := ContinuityAudit.flag_table({"test": scene}, {}, {})
	check(table.has("test_story_route") and table.test_story_route.writes.size() == 2 and table.test_story_route.reads.size() == 1, "continuity audit reads both string-route writes and the branch condition")
	DirAccess.remove_absolute(ProjectSettings.globalize_path("user://test_story_progress.json"))
	Story._scenes.erase("test_story_choice")
	Story._scenes.erase("test_story_object")
	Story._scene_chapter.erase("test_story_choice")
	Story._scene_chapter.erase("test_story_object")
	Story._death_sequences = previous_sequences
	GameState.flag_defaults = previous_defaults
	GameState.world_flags = previous_flags
	StoryItems.restore(previous_items)
	Story.restore_progress(previous_seen)
	Story.auto_skip = previous_auto


## 正式actor的位置差/scale/delta進入真正動畫器；觀測只驗實作，連續界線來自來源公式。
func _test_raw_body_and_grounded_walking() -> void:
	for skin: String in ["rin", "old_k"]:
		var actor := CutsceneActor.new()
		check(actor.setup(&"raw_walking", skin, "", 3.8 if skin == "rin" else 4.2, ""), "正式walking fixture可建立")
		actor.process_mode = Node.PROCESS_MODE_DISABLED
		runner.get_tree().root.add_child(actor)
		actor.position = Vector2(200, 304)
		actor.ground_y = 304
		var envelope := StagePoseEnvelope.new()
		check(envelope.include(actor), "walking前保留新NPC原始body歷史")
		actor._process(1.0 / 60)
		actor.set_pose(&"walk")
		var grounded := bool(actor.rig.animator._motion.get("grounding", false))
		var observed_ground := true
		var observed_geometry := true
		var raw_matches := true
		var pin_was_active := false
		# 1~threshold*run_speed的human idle、普通walk、超run_speed與NPC停止都走真分支。
		for velocity: float in [0.0, 1.2, 10.0, 21.563105, 45.0, 220.0, -220.0, 0.0]:
			check(envelope.include(actor, Vector2(velocity, 0)), "每個walking來源context保留永久ground/body歷史")
			for i in 30:
				var dt := 1.0 / 60 * (0.4 + float((i * 13) % 17) / 10)
				actor.position.x += velocity * dt * absf(actor.scale.x) * actor.rig.body_scale()
				actor._process(dt)
				var animator := actor.rig.animator as NpcAnimator
				var actual := actor.global_transform.affine_inverse() * actor.rig.visual_bounds()
				observed_geometry = observed_geometry and envelope.bounds.grow(0.001).encloses(actual)
				observed_ground = observed_ground and animator._ground_shift >= envelope._ground.x - 0.00001 \
					and animator._ground_shift <= envelope._ground.y + 0.00001
				pin_was_active = pin_was_active or animator._idle_pin_w > 0.01
				for bone: StringName in HumanoidAnimator.LEGS:
					var value: Vector2 = envelope._targets[bone]
					raw_matches = raw_matches and animator._angles[bone] >= value.x - 0.00001 and animator._angles[bone] <= value.y + 0.00001
		check(observed_ground and observed_geometry and raw_matches, "真walking全部速度與停止的ground/raw角/完整postIK輪廓在解析界線內")
		if grounded:
			check(envelope._ground.x > -2 and envelope._ground.y < 10, "正常groundwalking由body/gait/pin公式推導，不套±16")
			check(pin_was_active and envelope._pin_ground, "真低速human-idle可啟pin，依來源保留固定腳drop歷史")
			for bone: StringName in HumanoidAnimator.LEGS:
				check(envelope._targets[bone].y - envelope._targets[bone].x < PI \
					and envelope.full_rotation_channels.has(str(bone)), "raw %s未被IK FULL污染、最終輪廓仍保留FULL" % bone)
		else:
			check(envelope._ground == Vector2.ZERO and not envelope._pin_ground and envelope._gait_ground == Vector2.ZERO,
				"grounding=false的自由腿不能啟gait/pin位移")
		var gait_history := envelope._gait_ground
		var pin_history := envelope._pin_ground
		# 座椅使用原正式feet；途中回walk/crouch/jump時保留feet淡出與之前pin/gait。
		var transition_geometry := true
		var transition_ground := true
		for pose: StringName in [&"sit", &"walk", &"crouch", &"jump", &"idle", &"aim_up", &"idle"]:
			actor.set_pose(pose)
			check(envelope.include(actor, Vector2(45, 0) if pose == &"walk" else Vector2.ZERO), "motion切換不丟raw/feet/gait/pin歷史")
			check(envelope._gait_ground == gait_history and (not pin_history or envelope._pin_ground), "gait/pin歷史在坐蹲跳回NPC時保持")
			for i in 40:
				if pose == &"walk":
					actor.position.x += 45.0 / 60 * absf(actor.scale.x) * actor.rig.body_scale()
				actor._process(1.0 / 60)
				var actual := actor.global_transform.affine_inverse() * actor.rig.visual_bounds()
				var shift := actor.rig.animator._ground_shift
				transition_geometry = transition_geometry and envelope.bounds.grow(0.001).encloses(actual)
				transition_ground = transition_ground and shift >= envelope._ground.x - 0.00001 and shift <= envelope._ground.y + 0.00001
		check(transition_geometry and transition_ground, "sit接觸/feet淡出與walk/crouch/jump/return真輪廓及ground均保留")
		actor.queue_free()
		await frames(1)
	var invalid_actor := CutsceneActor.new()
	check(invalid_actor.setup(&"unsupported_ground_input", "rin", "", 3.8, ""), "異常輸入驗證使用新正式actor")
	invalid_actor._input.landed = 1.0
	var event_envelope := StagePoseEnvelope.new()
	check(not event_envelope.include(invalid_actor) and event_envelope.reason.contains("一次性"),
		"未知land事件不能冒用CutsceneActor extra_sag=0契約")
	invalid_actor._input.landed = 0.0
	invalid_actor.set_pose(&"walk")
	var cached_speed_envelope := StagePoseEnvelope.new()
	check(cached_speed_envelope.include(invalid_actor), "正常速度先填入相同walking context快取")
	invalid_actor._input.run_speed = NAN
	var speed_envelope := StagePoseEnvelope.new()
	check(not speed_envelope.include(invalid_actor) and speed_envelope.reason.contains("非有限"),
		"非法速度資料不能誤判idle pin資格")
	check(not cached_speed_envelope.include(invalid_actor) and cached_speed_envelope.reason.contains("非有限"),
		"same-context命中cache前仍拒絕後來NaN速度")
	invalid_actor.free()
	for two_handed: bool in [false, true]:
		var negative_actor := CutsceneActor.new()
		check(negative_actor.setup(&"negative_idle_threshold", "rin", "", 3.8, ""), "負門檻驗證使用新正式actor")
		# 測試私有副本，不改正式motion或RigLibrary共享資料。
		negative_actor.rig.animator._motion = negative_actor.rig.animator._motion.duplicate(true)
		negative_actor.rig.animator._motion["move"]["threshold"] = -0.1
		negative_actor.set_pose(&"idle" if two_handed else &"aim_up")
		negative_actor._input.two_handed = two_handed
		var negative_envelope := StagePoseEnvelope.new()
		check(not negative_envelope.include(negative_actor) and negative_envelope.reason.contains("門檻"),
			"負門檻的零速%s不能套非gait來源界線" % ("two_handed" if two_handed else "aim_up"))
		negative_actor.free()


## 動態輸入必須構成context；取樣只檢查真分支，pin上限由來源公式證明。
func _test_ground_input_contexts() -> void:
	var speed_actor := CutsceneActor.new()
	check(speed_actor.setup(&"finite_speed_context", "rin", "", 3.8, ""), "finite速度context使用正式Rin")
	speed_actor.set_pose(&"walk")
	speed_actor._input.run_speed = 1.0
	var speed_envelope := StagePoseEnvelope.new()
	check(speed_envelope.include(speed_actor) and not speed_envelope._pin_ground,
		"非two_handed的speed1 walking沒有可達human idle pin")
	var speed_contexts := speed_envelope.contexts
	speed_actor._input.run_speed = 150.0
	check(speed_envelope.include(speed_actor) and speed_envelope.contexts == speed_contexts + 1 \
		and speed_envelope._pin_ground, "same-context finite速度1→150重新納入可達pin歷史")
	check(speed_envelope.include(speed_actor) and speed_envelope.contexts == speed_contexts + 1,
		"相同finite速度context仍命中有界cache")
	speed_actor.free()

	var idle_actor := CutsceneActor.new()
	check(idle_actor.setup(&"two_handed_context", "rin", "", 3.8, ""), "two_handed context使用正式Rin")
	idle_actor.process_mode = Node.PROCESS_MODE_DISABLED
	runner.get_tree().root.add_child(idle_actor)
	idle_actor.position = Vector2(200, 304)
	idle_actor.ground_y = 304
	var idle_envelope := StagePoseEnvelope.new()
	check(idle_envelope.include(idle_actor) and not idle_envelope._pin_ground,
		"初始idle NPC不啟human pin")
	var idle_contexts := idle_envelope.contexts
	var npc_bounds := idle_envelope.bounds
	idle_actor._input.two_handed = true
	check(idle_envelope.include(idle_actor) and idle_envelope.contexts == idle_contexts + 1 \
		and idle_envelope._pin_ground and idle_envelope._human_feet_ik,
		"idle NPC→two_handed的相同pose重新納入human pin與IK")
	check(idle_envelope.bounds.grow(0.001).encloses(npc_bounds), "two_handed新context仍保留NPC輪廓歷史")
	var idle_geometry := true
	var idle_ground := true
	for i in 40:
		idle_actor._process(1.0 / 60)
		var actual := idle_actor.global_transform.affine_inverse() * idle_actor.rig.visual_bounds()
		var shift := idle_actor.rig.animator._ground_shift
		idle_geometry = idle_geometry and idle_envelope.bounds.grow(0.001).encloses(actual)
		idle_ground = idle_ground and shift >= idle_envelope._ground.x - 0.00001 and shift <= idle_envelope._ground.y + 0.00001
	check(not (idle_actor.rig.animator as NpcAnimator)._use_npc and idle_actor.rig.animator._idle_pin_w > 0.99,
		"two_handed idle真動畫分支是human且pin已啟用")
	check(idle_geometry and idle_ground, "NPC→two_handed真輪廓與ground保留於永久包絡")
	idle_actor.queue_free()
	await frames(1)

	var pin_actor := CutsceneActor.new()
	check(pin_actor.setup(&"zero_speed_two_handed_pin", "rin", "", 3.8, ""), "合法pin reach反例使用正式Rin")
	# 僅複製這個actor的motion；合法正reach不改正式JSON/共享RigLibrary。
	pin_actor.rig.animator._motion = pin_actor.rig.animator._motion.duplicate(true)
	pin_actor.rig.animator._motion["idle"]["pin_reach"] = 0.1
	pin_actor.process_mode = Node.PROCESS_MODE_DISABLED
	runner.get_tree().root.add_child(pin_actor)
	pin_actor.position = Vector2(200, 304)
	pin_actor.ground_y = 304
	pin_actor.set_pose(&"walk")
	pin_actor._input.run_speed = 1.0
	var pin_envelope := StagePoseEnvelope.new()
	check(pin_envelope.include(pin_actor, Vector2.ZERO) and not pin_envelope._pin_ground,
		"私有reach的非two_handed低速context先不啟pin")
	var pin_contexts := pin_envelope.contexts
	pin_actor._input.two_handed = true
	check(pin_envelope.include(pin_actor, Vector2.ZERO) and pin_envelope.contexts == pin_contexts + 1 \
		and pin_envelope._pin_ground, "零速walk/two_handed/run_speed1也能human idle pin")
	check(is_equal_approx(pin_envelope._ground.y, HumanoidAnimator.GROUND_MAX_SHIFT),
		"合法reach=.1按固定腳與腿長解析推導ground16，不漏成正常gait9.355")
	var pin_geometry := true
	var pin_ground := true
	for i in 40:
		pin_actor._process(1.0 / 60)
		var actual := pin_actor.global_transform.affine_inverse() * pin_actor.rig.visual_bounds()
		var shift := pin_actor.rig.animator._ground_shift
		pin_geometry = pin_geometry and pin_envelope.bounds.grow(0.001).encloses(actual)
		pin_ground = pin_ground and shift >= pin_envelope._ground.x - 0.00001 and shift <= pin_envelope._ground.y + 0.00001
	check(not (pin_actor.rig.animator as NpcAnimator)._use_npc and pin_actor.rig.animator._idle_pin_w > 0.99 \
		and is_equal_approx(pin_actor.rig.animator._ground_shift, HumanoidAnimator.GROUND_MAX_SHIFT),
		"真零速two_handed walking分支啟pin並達正式ground16上限")
	check(pin_geometry and pin_ground, "reach=.1真postIK輪廓與ground仍由完整歷史包住")
	pin_actor.queue_free()
	await frames(1)


## NE221真_apply_body順序回歸；不改正式rig，用合法私有head spring讓三項同骨共存。
func _test_secondary_spring_additive() -> void:
	var actor := CutsceneActor.new()
	check(actor.setup(&"secondary_additive", "rin", "", 3.8, ""), "secondary additive使用正式Rin與原scale")
	actor.process_mode = Node.PROCESS_MODE_DISABLED
	runner.get_tree().root.add_child(actor)
	actor.position = Vector2(200, 304)
	actor.ground_y = 304
	var animator := actor.rig.animator as NpcAnimator
	# 原springs保持；只加這個actor私有來源，不改CharacterRig/JSON/RigLibrary。
	animator._springs = animator._springs.duplicate(true)
	animator._springs.append({"bone": "head", "rest": 0.04, "gain": 0.1, "stiffness": 120.0, "damping": 14.0, "min": -0.05, "max": 0.09})
	animator._spring_angle[&"head"] = 0.0
	animator._spring_velocity[&"head"] = 0.0
	actor.set_talking(true)
	var envelope := StagePoseEnvelope.new()
	check(envelope.include(actor), "同head的NpcLife/raw與secondary配置可建立界線")
	check(envelope._follow_targets.has(&"head") and envelope._targets[&"head"] != envelope._secondary_springs[&"head"],
		"secondary clamp不覆寫已證NpcLife/body head目標")
	check(envelope._secondary_springs[&"head"].is_equal_approx(Vector2(-0.05, 0.09)),
		"secondary保留定義clamp與初態而非擴成FULL")
	var outward := true
	for spring in animator._springs:
		var name := StringName(str(spring["bone"]))
		var interval: Vector2 = envelope._secondary_springs[name]
		var low := minf(0, float(spring.get("min", HumanoidAnimator.SPRING_MIN)))
		var high := maxf(0, float(spring.get("max", HumanoidAnimator.SPRING_MAX)))
		outward = outward and interval.x <= low and interval.y >= high
	check(outward, "正式coat/hair與私有head的float32界線向外包含真double clamp端點")
	var composed := true
	var contained := true
	var visual := true
	var repeat_stable := true
	var all_channels_active := false
	for pose: StringName in [&"idle", &"walk", &"idle"]:
		actor.set_pose(pose)
		check(envelope.include(actor, Vector2(45, 0) if pose == &"walk" else Vector2.ZERO),
			"NPC→human→NPC保留raw/follow/overlay與secondary全部歷史")
		# pre-IK FK也必須按三項SUM。正式head沒有腿/手IK，parent是neck。
		var parent := actor.rig.parent_of(&"head")
		var sum: Vector2 = envelope._targets[&"head"] + envelope._run_overlay.get(&"head", Vector2.ZERO) + envelope._secondary_springs[&"head"]
		check(not envelope.full_rotation_channels.has("head") \
			and envelope._angles[&"head"].is_equal_approx(envelope._angles[parent] + sum),
			"head FK是來源三項Minkowski SUM，沒有用FULL掩蓋")
		for i in 120:
			var dt := 1.0 / 60 * (0.4 + float((i * 7) % 11) / 10)
			if pose == &"walk":
				actor.position.x += 45.0 * dt * absf(actor.scale.x) * actor.rig.body_scale()
			actor._process(dt)
			var raw: float = animator._angles[&"head"]
			var overlay: float = animator._overlay.get(&"head", 0.0)
			var spring: float = animator._spring_angle[&"head"]
			var applied: float = actor.rig.bone(&"head").rotation
			composed = composed and is_equal_approx(applied, raw + overlay + spring)
			contained = contained and applied >= sum.x - 0.00001 and applied <= sum.y + 0.00001
			all_channels_active = all_channels_active or (absf(raw) > 0.001 and absf(overlay) > 0.001 and absf(spring) > 0.001)
			var actual := actor.global_transform.affine_inverse() * actor.rig.visual_bounds()
			visual = visual and envelope.bounds.grow(0.001).encloses(actual)
			animator._apply_body()
			var reapplied: float = actor.rig.bone(&"head").rotation
			animator._apply_body()
			repeat_stable = repeat_stable and is_equal_approx(reapplied, applied) \
				and is_equal_approx(actor.rig.bone(&"head").rotation, applied)
	check(composed and repeat_stable, "真_apply_body每次先重設raw+overlay再加spring，不在ground重算時累加")
	check(all_channels_active and contained and visual, "同骨三通道真非零且全轉場角度/visual輪廓由連續來源界線守住（回歸非峰值證明）")
	# 相同context也不能忽略後來的secondary配置變更。
	animator._springs[-1]["max"] = 0.12
	check(not envelope.include(actor) and envelope.reason.contains("參數"),
		"cache命中前拒絕secondary熱改，不能套舊clamp歷史")
	actor.queue_free()
	await frames(1)
	# 各case建立自己的fresh actor/envelope；已include的same-context guard不可被cache跳過。
	for corrupt: String in ["nonfinite", "outofclamp", "missing", "extra"]:
		var guarded := CutsceneActor.new()
		check(guarded.setup(&"secondary_guard", "rin", "", 3.8, ""), "secondary corruption使用正式Rin")
		guarded.process_mode = Node.PROCESS_MODE_DISABLED
		runner.get_tree().root.add_child(guarded)
		var state := guarded.rig.animator as NpcAnimator
		var guard_envelope := StagePoseEnvelope.new()
		check(guard_envelope.include(guarded), "secondary %s先建立可命中context" % corrupt)
		var name := StringName(str(state._springs[0]["bone"]))
		match corrupt:
			"nonfinite": state._spring_angle[name] = NAN
			"outofclamp": state._spring_angle[name] = 2.0 + float(state._springs[0].get("max", HumanoidAnimator.SPRING_MAX))
			"missing": state._spring_angle.erase(name)
			"extra": state._spring_angle[&"unknown_secondary"] = 0.0
		check(not guard_envelope.include(guarded) and guard_envelope.reason.contains("secondary spring"),
			"same-context拒絕secondary %s，不能由cached bounds隱藏損毀" % corrupt)
		guarded.queue_free()
		await frames(1)
