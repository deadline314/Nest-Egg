import json,pathlib,hashlib
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parent
# Standalone verifier has no candidate-generation imports or geometry library.
# All checks reduce to integer signs; certificate summaries are ignored.
def verify(path):
 raw=path.read_bytes();C=json.loads(raw);D=C['denominator'];V=C['vertices_int'];N=len(V)
 a=Fraction(C.get('a_upper',str(Fraction(C['w'])/60)));an,ad=a.numerator,a.denominator
 ze=[Fraction(s) for s in C.get('z_interval',[C['z'],C['z']])];checks=roots=0
 assert N>=3 and D>0
 for i in range(N):
  X,Y=V[i];XX,YY=V[(i+1)%N];XXX,YYY=V[(i+2)%N]
  assert (XX-X)*(YYY-YY)-(YY-Y)*(XXX-XX)>0,('convex',i)
  nx,ny=YY-Y,-(XX-X);d=nx*X+ny*Y
  assert nx*(-D)<=d and nx*D<=d,('initial',i)
  for vi,(x,y) in enumerate(V):
   base=nx*x+ny*y-d
   assert base<=0,('polygon vertex containment',i,vi)
   for z in ze:
    zn,zd=z.numerator,z.denominator;c=base*zd
    for u in (-1,1):
     t=-x*zd-2*zn*y+u*D*zd;b=nx*y*zd+ny*t;q=nx*t
     assert c<=0,('a=0',i,vi,u)
     assert c or b<=0,('a->0 tangent',i,vi,u)
     end=c*ad*ad+b*an*ad+q*an*an
     assert end<=0,('a=end',i,vi,u,z)
     # Concave vertex -b/(2q) is internal iff q<0, b>0, b*ad< -2q*an.
     if q<0 and b>0 and b*ad < -2*q*an:
      assert 4*q*c-b*b>=0,('internal maximum',i,vi,u,z)
      roots+=1
     checks+=1
 gain=Fraction(max(abs(v[0]) for v in V),D)
 # Round upward to one millionth for intended runtime table.
 scale=10**6;table=(gain.numerator*scale+gain.denominator-1)//gain.denominator
 return {'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'accepted':True,'vertices':N,'all_parameter_facet_vertex_u_cases':checks,'internal_extrema_checked':roots,'a_upper':str(a),'z_interval':[str(z) for z in ze],'gain_exact':str(gain),'gain_round_up_6dp':f'{table/scale:.6f}'}
if __name__=='__main__':
 import sys
 paths=[pathlib.Path(sys.argv[1])] if len(sys.argv)>1 else sorted(ROOT.glob('certificate-[0-9]*.json'))
 print(json.dumps([verify(p) for p in paths],indent=2))

