"""Independently check parameter coverage and outward runtime gains; stdlib only."""
import json
import pathlib
import struct
from fractions import Fraction as F

ROOT = pathlib.Path(__file__).resolve().parent
PAIRS = [("12", "0.6"), ("14", "0.5"), ("14", "0.7"), ("16", "0.55"), ("18", "0.5")]

def verify():
    result = []
    for ws, zs in PAIRS:
        path = ROOT / f"certificate-{ws}-{zs}.json"
        certificate = json.loads(path.read_text(encoding="utf-8"))
        assert certificate["w"] == ws and certificate["z"] == zs
        w, z = F(ws), F(zs)
        lower, upper = map(F, certificate["z_interval"])
        a_upper = F(certificate["a_upper"])
        # Check requested nominal intervals, not a certificate's stored summaries.
        assert lower <= z - F(1, 10**9) and upper >= z + F(1, 10**9)
        assert a_upper >= w / 60 + F(1, 10**9)
        actual_z = F.from_float(float(zs))
        actual_h = F.from_float(1.0 / 60.0)
        actual_a = F.from_float(float(ws) * (1.0 / 60.0))
        assert lower <= actual_z <= upper
        assert 0 < actual_a <= a_upper
        gain = F(max(abs(x) for x, _ in certificate["vertices_int"]), certificate["denominator"])
        million = 10**6
        numerator = (gain.numerator * million + gain.denominator - 1) // gain.denominator
        table = F(numerator, million)
        gain_binary64 = F.from_float(float(table))
        gain_binary32 = F.from_float(struct.unpack("f", struct.pack("f", float(table)))[0])
        assert gain_binary64 >= gain and gain_binary32 >= gain
        result.append({"w": ws, "z": zs, "accepted": True,
                       "double_z_exact": str(actual_z), "double_h_exact": str(actual_h),
                       "double_a_max_exact": str(actual_a), "a_margin": str(a_upper - actual_a),
                       "z_lower_margin": str(actual_z - lower), "z_upper_margin": str(upper - actual_z),
                       "gain_6dp": f"{float(table):.6f}",
                       "float64_gain_margin": str(gain_binary64 - gain),
                       "float32_gain_margin": str(gain_binary32 - gain)})
    return result

if __name__ == "__main__":
    print(json.dumps(verify(), indent=2))
