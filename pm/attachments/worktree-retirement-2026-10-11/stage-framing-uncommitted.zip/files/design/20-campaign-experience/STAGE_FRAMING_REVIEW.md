# ST-10 舞台構圖調查與最小修正提案

2026-10-10。這份文件保留早期離線調查及失敗圖證；文末的最新來源與原生結果優先於歷史提案。本輪基準為 `3bdb827eab7e9158a977a1318bd28e84b5b2d4e1`，工作分支已實作 Player、純幾何求解器及姿勢歷史包絡，尚未提交。兩張背景延展素材已交付來源流程，但正式舞台尚未採用；ST-10 尚未完成。故事、角色素材與骨架、音效、地圖及存檔契約不在本輪修改範圍。

## 已確認的問題與證據

根代理與本票均已目視正式入口圖：[ST-22 回家電影畫面](../../pm/Nest-Egg/images/ST-22-16x9-home-movie.png)。老 K 與凜的頭部超出上方可見區，腳仍在畫面中。這張圖沒有字幕，不足以驗收有字幕時的完整角色構圖。

`CutscenePlayer._apply_camera()` 只套用作者的 `cam_pos`／`cam_zoom`，沒有全身邊界限制。`tools/story/build_ch1_story.py` 的 `clamp_camera_y()` 只把腳底壓到畫面 y≤262；`CutsceneChecker.staging_problems()` 只檢查腳底 y≤266。移動鏡頭向下可救腳，卻會繼續切掉頭。因此舊 checker 通過不能代表完整構圖通過。

ST-22 現在使用實際 viewport 的 21:9 安全區。640×360 時上下黑邊各為 42.857143，安全區為 `[0, 42.857143, 640, 274.285714]`。`CutsceneDialogue.layout_safe_rect()` 的面板上緣是 233.142857；肖像框再高 8 像素，為 225.142857。舊的 262／266 腳底上限會讓腳落到字幕區。採預留 4 像素邊距的完整角色構圖時，可用高度約 174.285714；4 像素是本專案提案，須以原生圖調整，並非業界標準。

六張背景原始檔皆為 1536×864；舞台宣告 `source_width=1536`、scale=0.5、position=(-64,-36)，藝術背景世界範圍均為 `[-64,-36,768,432]`。`StageLayers.sprite_scale()` 已按 source_width 維持世界尺寸，沒有發現縮圖快取改變舞台幾何的證據。640 寬畫面要求鏡頭 zoom≥0.833333 才能僅靠這張背景填滿水平範圍；工具 EXPAND 的 840 寬 viewport 要求 zoom≥1.093750。背景底色／黑色遮罩不算藝術背景填充。

| 正式舞台 | 地面 y | generator 原始角色 scale | 現有正式 animated 使用 |
| --- | ---: | --- | --- |
| ch1_pawnshop_front | 348 | 凜 3.4、老 K 3.7 | ch1_c01_open |
| ch1_pawnshop_kitchen | 304 | 凜 3.8、老 K 4.2 | ch1_c14_home |
| ch1_rooftop | 262 | 凜 2.2、夜班工 2.3 | 目前沒有 |
| ch1_revival_room | 280 | 凜 2.5 | ch1_c09_wake |
| ch1_revival_lounge | 262 | 凜 2.4、阿梨 2.8 | 目前沒有 |
| ch1_dawn_noodle_stall | 300 | 凜 1.7、阿梨 1.9 | 目前沒有 |

故事來源後續若增加 animated 分鏡，工具會讀取正式 JSON 自動發現，不能沿用這張表假稱新稿已驗。

## 物理限制：先求可行，再決定修改

CPU 只做了一次角色 rest sprite 的保守包圍盒估算，沒有執行 NPC Animator、IK、彎曲 mesh 或新姿勢。估算凜高度 57.36、老 K 56.40 原始角色單位；廚房老 K 放大 4.2 後約 236.88 世界像素。若全身必須位於目前約 174.29 高的字幕前安全區，鏡頭 zoom 上限約 0.736，而背景填滿寬度的下限約 0.833。這是**待原生真實 bounds 核對的無解訊號**，不是正式量測或最終美術需求。

同時縮放整個舞台可保留人物／家具比例，但若必須 zoom-out 到背景範圍外，就需要擴展背景；單純拉低鏡頭、縮角色、改骨架材質或加純黑底均不能解決所有條件。不能先承諾現有素材可用一個 camera clamp 完成。

可行性計算輸入是：角色聯集 A、實際藝術背景矩形 B、角色可見目標矩形 S、藝術必須填滿的 safe rect F、viewport 中心 V。所有角色保持原本 unit_scale。

1. 全身 fit 給出 zoom 上限 `min(S.width/A.width, S.height/A.height)`。
2. 背景 cover 給出 zoom 下限 `max(F.width/B.width, F.height/B.height)`。
3. 對 x/y 各軸，角色中心區間為 `[A.end-(S.end-V)/z, A.begin-(S.begin-V)/z]`；背景中心區間為 `[B.begin-(F.begin-V)/z, B.end-(F.end-V)/z]`。
4. 令 q=1/z，中心上下界均為 a+bq。對所有下界／上界配對求交集，檢查有無正 q 與可用中心。不能只比 zoom 上下限，忽略演員站位與背景中心限制。
5. 有解時選擇最接近原分鏡的 zoom／中心；無解時輸出「角色 fit 鏡頭所需背景世界矩形」與四邊缺口，交主 session 的美術流程判斷延展。鏡頭提案不是素材修補。

此計算只適用相同舞台平面的矩形背景。多層視差、背景透明區、刻意俯仰／旋轉鏡頭不能以矩形求解假稱已填滿；這些條件需要單獨的有效藝術範圍或人工圖證。

## 歷史提案：最小 runtime 範圍

以下記錄早期提案；目前分支已實作對應 runtime 並進行原生驗證，不再代表尚未實作。

- 建議新增純資料求解器 `game/cutscene/stage_framing_plan.gd`：Rect2、鏡頭與約束輸入，輸出可行／缺口／建議有效鏡頭，不碰 Story／獎勵／存檔。具體路徑待核准，不在本輪先建立。
- `CutscenePlayer` 保留作者 camera tween 語義，另持有效鏡頭。新增／移除演員、切舞台、切姿勢、safe rect 改變時才更新保守舞台邊界。camera tween 的每影格套用只做已快取 Rect2／scalar 運算。
- `CharacterRig.visual_bounds()` 會收集 mesh 頂點及 sprite 角點，不能每影格對所有演員重掃。單次靜止 pose 也不足以保證整個說話／待機循環；需要一次有界的動畫週期量測或可重用的姿勢 envelope 快取，cache key 至少含角色來源、pose／loop、facing、weapon。若暫無保守 envelope，明確留驗收缺口，不假設靜止值涵蓋動畫峰值。
- move 開始時把起終點的 envelope 聯集納入鏡頭規劃，直到移動完成再縮回，避免移動途中追邊界造成鏡頭抖動。說話時肖像有無不改保留高度，鏡頭不逐句跳動。畫幅入場／viewport 改變重算約束，減少動態設定下不另加追蹤晃動。
- `CutsceneChecker` 日後檢查明確的 shot policy／舞台背景 contract，保留既有資料容錯；不能用腳底單一數字作新構圖驗收。完整頭腳構圖為本票預設；真正特寫若日後加入須資料明示，不能把現有切頭改名為特寫來過驗收。
- 若原生確認廚房無解，才提出六舞台中真正需要的背景延展。維持家具、接觸線與角色尺寸，延展畫布時同時調整 source_width／世界原點，使原圖內容仍落在同一世界座標；直接增加 source_width 再縮回同一整張尺寸會把家具縮小，不能使用。

無 Story mode／scene_started 契約、context、request handle、存檔、劇情、角色藝術／rig、HUD、AssetPrefetch、音效、地圖修改。

## 可重現原生探針

工具：[stage_framing_probe.gd](../../tools/stage_framing_probe.gd)、[入口 tscn](../../tools/stage_framing_probe.tscn)。只在根代理放行引擎後，序列執行兩次，沿用隔離 APPDATA 模式，設定 `ST10_PROFILE` 為隔離根目錄，`--out` 必須是絕對路徑。

```text
godot --path C:/tmp/Nest-Egg-stage-framing res://tools/stage_framing_probe.tscn -- --out=C:/tmp/st10-native-16x9 --debug-bounds
godot --path C:/tmp/Nest-Egg-stage-framing res://tools/stage_framing_probe.tscn -- --out=C:/tmp/st10-native-wide --wide --debug-bounds
```

工具拒絕 headless／非 Forward+ 圖證，正式 KEEP 為 1600×900 窗口；wide 只用工具 EXPAND，2100×900 窗口產生 840×360 viewport，不稱為正式顯示策略修改。兩種設定均使用 120% UI 文字。根代理已在 2026-10-10 明確放行單一引擎名額，實際結果如下。

量測流程：

1. 讀取正式 `ch1_kasa.json` 全部非 overlay animated 場景，交正式 `CutscenePlayer.play()` 原速播放原始分鏡；確認鍵為合成事件，直接進實際 `_input` 路徑。未走主線觸發／Story 結算，因此標記為「正式資料／正式播放器／合成確認」，不能稱真人遊玩。
2. 正式流程中的 say／camera／move／pose 不被工具改寫；各次取得變形後 `actor.rig.visual_bounds()`。此 bounds 已含 stage_holder camera transform，投影時只再套 canvas transform；反變換回舞台座標後計算新鏡頭可行性，避免 camera 乘兩次。
3. 報告 actual safeRect、dialogue 面板與肖像矩形／頂端、角色舞台／viewport／presentation 邊界、骨頭位置、完整身體出界量、腳底原點與地面差、真實 sprite 背景 cover、來源圖大小、props/H、可行鏡頭與缺口。`visual_bounds` 不含武器，武器另列。
4. 只讀 generator 的 SCALE literal 與正式 Stage.floor 建立六舞台合成 idle→sit→idle 矩陣，明標沒有正式座位 choreography；不能拿這組 synthetic sit 當坐椅／起身接觸已驗。generator 格式變更時工具明確失敗，不沿用手抄比例。
5. 8Hz 有界量測，最多 2,048 列、64 組 plain PNG；每個 stage／pose 組合在字幕出現時留圖。plain PNG 重新量測當次 rendered frame；可選標線 PNG 在下一個 rendered frame，角色可能繼續動畫，報告明標這個差異。PNG 原始 readback 尺寸與 presentation transform 同時記錄，不假設固定 2.5 倍。
6. 原始 PNG 供頭髮頂端、鞋底支撐、椅面、桌面、遮擋和家具比例目視。Sprite 矩形含透明 padding，bones 的腳點也不等於鞋底；prop/H 數值不能取代接觸線或背景內嵌家具驗收。

成功量測可 exit 0，但總報告 **accepted=false**，`geometry_accepted` 與人工家具／演出審查分列；圖片／資料／超時錯誤 exit 2。這是調查工具，不是把所有量測結果寫成 ASSERT 成功的測試。raw engine log 必須保留，退出碼不能代替 script-error 檢查。

## 後續驗證範圍與交付界線

先 refresh import／原生 probe 核對本輪工具，記錄新工具自然生成 UID，不順手納入外來 UID。若 runtime 授權後改了求解器與 Player，補純幾何有解／無解／中心交集、演員 head+feet、camera tween／move／sit→stand、portrait 有無、16:9／wide、viewport resize／減少動態的回歸，保留原 Story／NPC／save 契約測試。

受影響測試範圍由原 `tools/select_tests.py` 決定，不能預先固定數字、縮小 selector 或改 known failures。只在原生 Forward+ 圖、數值、家具比例／支撐面與原 selector 全綠後，才整理 PM 驗收。本輪只做 measure-only 原生調查，未改正式功能或執行受影響套件，未判定 ST-10 完成。

已依完整 scene-staging、visual-verification 技能與 `STAGING_REFERENCE.md` 調查；該參考文的建議比例／搜尋摘要不是本票已驗證的外部標準。本票以實際專案來源與後續 native 圖證為準。

## 原生 v1 結果：工具成功，構圖未通過

基準 `3c053d316fc4da97b00887c2cbbed60b19a12334`，Godot `4.7.2.stable.official.ed1daf0bf`，Vulkan Forward+／Intel Arc B580。私有 APPDATA 分為 `C:/tmp/st10-import-profile`、`C:/tmp/st10-profile-16x9`、`C:/tmp/st10-profile-wide`，沒有使用正式 user:// 存檔。

| 程序 | OS exit | raw Parse／Compile／SCRIPT／ERROR | 結果 |
| --- | ---: | ---: | --- |
| headless editor import v1 | 0 | 0 | 匯入完成，不能代替原生圖片驗收 |
| 原生 16:9 v1 | 0 | 0 | 492 列、16 plain＋16 bounds PNG；tool_completed=true，accepted=false，geometry_accepted=false |
| 原生 EXPAND v1 | 0 | 0 | 483 列、16 plain＋16 bounds PNG；tool_completed=true，accepted=false，geometry_accepted=false |

兩輪均自然退出，本票引擎名額已釋放。所有 raw 保留：`C:/tmp/st10-import/import-v1.log`、`C:/tmp/st10-native-16x9/engine-v1.log`、`C:/tmp/st10-native-wide/engine-v1.log`。各目錄有完整 `ST-10-report.json`；CPU 彙整在 `C:/tmp/st10-import/stage-union-v1.json`。不是只取成功摘要；raw 中沒有需要濾除的錯誤或警告。

原生工具 v1 SHA256 是 `e1c70359396b7325ad7481d506bdd4abe0ee974a9c0174afd864b482c8202688`；tscn SHA256 是 `0338b46c13f785e02096ea24e1e8c7d0a65ae8f857b9221b1989489426192031`。正式故事 SHA256 `6d020b5940b96a08a318687bbd6ab0329576bae8a5b54666d22d929f7b2197b4`；generator SHA256 `725828131d41904f9bd73b5a42bc500a7407496cdb3599cb849b5299c22e416c`。其餘來源 SHA 記錄於 `C:/tmp/st10-import/source-before-import.json`。

本票自然生成的唯一新工具 UID 為 `tools/stage_framing_probe.gd.uid`：`uid://d2s46sn6x1gw2`。未移除或納入外來 UID。完成兩輪後核對故事／generator／Player／Actor／Dialogue／Rig／StageLibrary／StageLayers／RigLibrary 的 SHA256 均與 CPU import 前相同。

代表圖：

- 正式廚房／16:9：`C:/tmp/st10-native-16x9/ST-10-16x9-003-ch1_pawnshop_kitchen.png`。本票及根代理均已目視切頭／字幕蓋鞋。此圖為凜已走到第一句對話位置，與 ST-22 舊圖的走入早期位置不同；不能把兩張當作完全同一時刻的單變數比較。
- 正式廚房／EXPAND：`C:/tmp/st10-native-wide/ST-10-wide-003-ch1_pawnshop_kitchen.png`。角色頭腳較完整，但左右約 36 viewport 像素顯示底色而非藝術背景，不能算超寬填滿通過。
- 正式前門／16:9：`C:/tmp/st10-native-16x9/ST-10-16x9-000-ch1_pawnshop_front.png`。背景底部範圍不足，字幕前全身 fit 上限也低於原藝術 cover 下限。
- 正式復原館／16:9：`C:/tmp/st10-native-16x9/ST-10-16x9-001-ch1_revival_room.png`（坐姿）、`ST-10-16x9-002-ch1_revival_room.png`（站姿）。全部已量測 snapshot 的幾何求解有解，原作者鏡頭仍切頭或壓入字幕，不表示現圖已通過。

正式廚房第一張原生 snapshot：老 K 世界身高 240.587、凜 223.257；老 K 上緣超出角色安全預算 40.322、凜 23.477 viewport 像素；鞋底分別侵入字幕預算 25.979／25.495。所需 zoom 上限 0.724417，原藝術 cover 下限 0.833333，無解。正式廚房全部 8Hz snapshot 的最低 fit 上限為 0.713692；EXPAND 為 1.064688，仍低於原藝術 cover 下限 1.093750。

### 所有已量測 snapshot 的聯集

下表為 **16:9＋EXPAND、正式播放＋明標合成矩陣的全部 975 列 snapshot**。actor envelope 是全演員、全 snapshot 的舞台 AABB 聯集；required art 是各 snapshot 保留作者意圖／actor fit 候選鏡頭所需安全區的世界矩形聯集。四邊缺口相對原藝術 `[-64,-36,768,432]`。這是 8Hz 觀測範圍，不是逐格、未見姿勢或未來新分鏡的峰值保證；也不能拿多個 snapshot 的聯集當成一個同時存在的真實姿勢。

| 舞台 | actor envelope `[x,y,w,h]` | required art 聯集 `[x,y,w,h]` | 最大缺口 L／T／R／B |
| --- | --- | --- | --- |
| 前門 | `[138.947,137.370,330.524,226.500]` | `[-71.171,132.506,782.342,345.823]` | `7.171／0／7.171／82.329` |
| 廚房 | `[79.589,65.353,529.639,256.711]` | `[-194.121,59.801,962.494,392.145]` | `130.121／0／64.373／55.946` |
| 屋頂 | `[193.853,132.650,249.801,138.364]` | `[-64,21.163,768,345.851]` | `0／0／0／0` |
| 復原館 | `[190.390,99.031,168.066,191.607]` | `[-64,39.137,768,346.598]` | `0／0／0／0` |
| 休息室 | `[191.517,109.209,258.337,163.233]` | `[-64,20.249,768,347.909]` | `0／0／0／0` |
| 麵攤 | `[199.821,196.366,234.027,111.116]` | `[-64,58.975,768,337.025]` | `0／0／0／0` |

四張目前沒有正式／或不缺背景的舞台不能因此算家具、坐椅或新劇情驗收通過。前門正式播放最大底缺 73.400，合成矩陣最大底缺 82.329；廚房正式播放最大缺口 L=130.121／R=64.373／B=50.416，合成矩陣為 L/R=58.310／B=55.946。完整分列及各 aspect 數字都在 CPU JSON，不將合成結果混稱正式片段。

根代理提出的 2560×1440 候選 canvas、scale=0.5、source_width=2560、origin=(-320,-180)，世界矩形為 `[-320,-180,1280,720]`，可包含這次 v1 的 8Hz snapshot required art 聯集；這不是後續連續姿勢包絡或正式採用的證明。原 1536×864 內容若原封不動置於新 canvas 的 (512,288)，世界起點仍為 (-64,-36)，原家具／地板像素與角色比例可保持。此結論只驗證幾何容納；未生成背景，也未驗證邊緣光影／接縫／新 camera、全動畫週期 envelope 或家具支撐。現證據只支持前門與廚房需要藝術延展，不支持順便重做其他四張背景。

### 家具資料與工具分類修正

合成麵攤 standing 凜 H≈100.11 世界像素；原始 sprite 矩形比例：攤車 H≈1.119H、桌子≈0.431H、吊燈≈0.564H。這些是貼圖矩形，可能含透明 padding；凳子是 poly，背景內嵌家具也不在 sprite 量測中。座面、腳底、椅子／桌面比例與遮擋仍為人工 pending。

v1 發現柔光 `_Glow` 同樣繼承 Sprite2D，原 props array 會額外列入 resource_path 空字串的 soft glow。它沒有被當藝術背景，也不影響 actor、可行鏡頭、required art 或上表聯集；但不能稱家具。工具 v2 已以 metadata `kind == sprite` 最小修正分類，gdparse exit 0，SHA256 `5318defb3f4d0be8a737a31717ca76252be99123d7a69f2e47551b8367351d9c`。**v2 尚未原生重跑**，v1 raw／圖片／JSON 保持原樣；正式產品不為 probe 改動。
