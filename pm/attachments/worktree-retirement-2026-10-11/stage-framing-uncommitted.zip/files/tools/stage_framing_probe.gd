extends Node
## ST-10：唯讀正式分鏡＋明標合成的六舞台量測。工具成功不等同構圖驗收。
## 尚須原生 Forward+ 執行；gdparse 只檢查語法。隔離 APPDATA，ST10_PROFILE 指向該根目錄。
const Capture := preload("res://tools/viewport_capture.gd")
const STORY_PATH := "res://data/story/ch1_kasa.json"
const GENERATOR_PATH := "res://tools/story/build_ch1_story.py"
const SOURCE_FILES := [
	"res://game/cutscene/cutscene_player.gd", "res://game/cutscene/stage_framing_plan.gd",
	"res://game/cutscene/stage_pose_envelope.gd", "res://game/cutscene/cutscene_dialogue.gd",
	"res://game/cutscene/stage_library.gd", "res://game/cutscene/stage_layers.gd",
	"res://game/cutscene/cutscene_actor.gd", "res://game/rig/rig_library.gd", "res://ui/ui_kit.gd",
	"res://game/rig/character_rig.gd", "res://game/rig/humanoid_animator.gd",
	"res://game/rig/npc_animator.gd", "res://game/rig/npc_life.gd", "res://game/rig/rig_part_mesh.gd",
	"res://art/rigs/npc_animations.json", "res://core/display_mode.gd", "res://ui/cinematic_framing.gd",
]
const SAMPLE_SECONDS := 0.125
const SCENE_TIMEOUT_MS := 180000
const MAX_ROWS := 2048
const MAX_SHOTS := 64
const MARGIN := 4.0
var baseline_sha := ""
var source_records: Dictionary[String, Dictionary] = {}
var envelope_records: Array[Dictionary] = []
var envelope_keys: Dictionary[String, int] = {}
var coverage_keys: Dictionary[String, bool] = {}
var omission_keys: Dictionary[String, bool] = {}
var coverage_omissions: Array[Dictionary] = []
var capture_waiting_keys: Dictionary[String, bool] = {}
var playback_serial := 0
var output := ""
var wide := false
var debug_bounds := false
var candidate_art := false
var candidate_overrides: Array[Dictionary] = []
var original_stage_cache: Dictionary[StringName, Dictionary] = {}
const CANDIDATE_ART := {
	"ch1_pawnshop_front": {"original": "res://art/environment/scenes/pawnshop_front.webp",
		"path": "res://art/environment/scenes/pawnshop_front_extended.webp",
		"pos": [-80, -68], "source_width": 1600, "source_height": 1216, "original_pixel_offset": [32, 64]},
	"ch1_pawnshop_kitchen": {"original": "res://art/environment/scenes/pawnshop_kitchen.webp",
		"path": "res://art/environment/scenes/pawnshop_kitchen_extended.webp",
		"pos": [-320, -180], "source_width": 2560, "source_height": 1440, "original_pixel_offset": [512, 288]},
}
var rows: Array[Dictionary] = []
var shots: Array[Dictionary] = []
var errors: PackedStringArray = []
var shot_keys: Dictionary[String, bool] = {}
var player: CutscenePlayer
var active_classification := ""
var completed_scenes: PackedStringArray = []
var finished_current := false
var overlay: CanvasLayer
var guides: Guides


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	baseline_sha = OS.get_environment("ST10_BASELINE").strip_edges().to_lower()
	var baseline_pattern := RegEx.new()
	baseline_pattern.compile("^[0-9a-f]{40}$")
	if baseline_pattern.search(baseline_sha) == null:
		_fail("ST10_BASELINE 必須由啟動 wrapper 提供實際 git HEAD 的完整40hex；不沿用舊常數")
		get_tree().quit(2)
		return
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			output = arg.trim_prefix("--out=")
		elif arg == "--wide":
			wide = true
		elif arg == "--debug-bounds":
			debug_bounds = true
		elif arg == "--candidate-art":
			candidate_art = true
	var isolated := OS.get_environment("ST10_PROFILE").replace("\\", "/").to_lower().trim_suffix("/")
	var actual := OS.get_user_data_dir().replace("\\", "/").to_lower()
	if isolated.is_empty() or not actual.begins_with(isolated + "/") or not output.is_absolute_path():
		_fail("需要隔離 APPDATA／ST10_PROFILE 與絕對 --out 路徑")
		get_tree().quit(2)
		return
	var err := DirAccess.make_dir_recursive_absolute(output)
	if err != OK:
		_fail("無法建立輸出目錄 %s：%s" % [output, error_string(err)])
		get_tree().quit(2)
		return
	if DisplayServer.get_name() == "headless" or RenderingServer.get_current_rendering_method() != "forward_plus":
		_fail("圖證必須使用原生 Forward+，不能以 headless／其他 renderer 代替")
		_write_report()
		get_tree().quit(2)
		return
	GameState.story_autosave = false
	Story.auto_skip = false
	Settings.set_skip_cutscenes(false)
	Settings.set_reduce_ui_motion(false)
	Settings.set_ui_text_scale(1.2)
	Engine.max_fps = 60
	DisplayMode.ensure_scaling(get_tree().root)
	get_tree().root.size = Vector2i(2100, 900) if wide else Vector2i(1600, 900)
	if wide:
		get_tree().root.content_scale_aspect = Window.CONTENT_SCALE_ASPECT_EXPAND
	overlay = CanvasLayer.new()
	overlay.layer = UiLayers.TRANSITION + 1
	add_child(overlay)
	guides = Guides.new()
	guides.hide()
	overlay.add_child(guides)
	for path: String in SOURCE_FILES:
		_record_source(path)
	_record_source(get_script().resource_path)
	_record_source(STORY_PATH)
	_record_source(GENERATOR_PATH)
	_record_source(str(UiKit.FONT_STYLES[UiKit.font_style()]["path"]))
	_run.call_deferred()


func _run() -> void:
	await get_tree().process_frame
	if candidate_art and not _prepare_candidate_art():
		_write_report()
		get_tree().quit(2)
		return
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(STORY_PATH))
	if not data is Dictionary or not data.get("scenes") is Dictionary:
		_fail("讀不到正式第一章 scenes：" + STORY_PATH)
	else:
		var scenes: Dictionary = data.scenes
		for id: String in scenes:
			var scene: Dictionary = scenes[id]
			if scene.get("mode") == "animated" and not bool(scene.get("overlay", false)):
				await _play(id, scene, "formal-data / production CutscenePlayer / synthetic confirm")
	# 唯讀 generator 的 SCALE，不另抄六舞台角色尺寸，也不執行或重產故事／舞台資料。
	var scales := _generator_scales()
	for stage_id: String in scales:
		var definition := StageLibrary.definition(StringName(stage_id))
		var floor_y := float(definition.get("floor", NAN))
		if not is_finite(floor_y):
			_fail("合成矩陣缺少正式地面線：" + stage_id)
			continue
		var steps: Array[Dictionary] = [{"do": "scene", "id": stage_id, "fade": 0.0}]
		var kinds: Dictionary = scales[stage_id]
		var index := 0
		for kind: String in kinds:
			steps.append({"do": "actor", "id": kind, "kind": kind, "scale": kinds[kind],
				"pos": [220 + index * 180, floor_y], "ground": floor_y, "pose": "idle", "speaker": kind})
			index += 1
		steps.append({"do": "say", "speaker": "rin", "text": "合成舞台量測：不是正式劇情或人工通關。"})
		for kind: String in kinds:
			steps.append({"do": "pose", "id": kind, "pose": "sit"})
		steps.append({"do": "say", "speaker": "rin", "text": "合成坐姿，只量鏡頭邊界；未宣稱座位接觸正確。"})
		for kind: String in kinds:
			steps.append({"do": "pose", "id": kind, "pose": "idle"})
		steps.append({"do": "say", "speaker": "rin", "text": "合成站姿恢復，保持原始角色與家具比例。"})
		await _play("st10_matrix_" + stage_id, {"steps": steps}, "synthetic / generator SCALE / stage floor / no seat choreography")
	_restore_candidate_cache()
	_write_report()
	get_tree().quit(0 if errors.is_empty() else 2)


func _record_character_sources(value: Variant, base_dir: String, depth := 0) -> void:
	# character.json 內相對 PNG／WebP、法線與握持圖；只串流 hash，絕不為 manifest 解碼 Image。
	if depth > 12:
		_fail("character art manifest 超出深度上限")
		return
	if value is Dictionary:
		for key: Variant in value:
			_record_character_sources(value[key], base_dir, depth + 1)
	elif value is Array:
		for item: Variant in value:
			_record_character_sources(item, base_dir, depth + 1)
	elif value is String and str(value).get_extension().to_lower() in ["png", "webp"]:
		var path := str(value) if str(value).begins_with("res://") else base_dir.path_join(str(value))
		_record_source(path)


func _prepare_candidate_art() -> bool:
	# 僅私有 probe 程序的 cache 替代；先完整驗兩份原定義，再一起裝入。磁碟 JSON／generator 不動。
	var replacements: Dictionary[StringName, Dictionary] = {}
	for raw_id: String in CANDIDATE_ART:
		var id := StringName(raw_id)
		var specification: Dictionary = CANDIDATE_ART[raw_id]
		var original := StageLibrary.definition(id)
		var copy := original.duplicate(true)
		var layers: Array = copy.get("layers", [])
		var matches := 0
		var changed := {}
		for raw: Variant in layers:
			if not raw is Dictionary:
				continue
			var layer: Dictionary = raw
			if str(layer.get("kind", "")) != "sprite" or str(layer.get("path", "")) != str(specification.original):
				continue
			matches += 1
			if StageLayers.vec2_of(layer.get("pos")) != Vector2(-64, -36) \
					or float(layer.get("scale", 0)) != 0.5 or float(layer.get("source_width", 0)) != 1536 \
					or float(layer.get("parallax", 1)) != 1 or str(layer.get("depth", "back")) != "back":
				_fail("候選 adapter 原 background metadata 已變；拒絕猜測：" + raw_id)
				return false
			changed = layer.duplicate(true)
			layer["path"] = specification.path
			layer["pos"] = specification.pos.duplicate()
			layer["source_width"] = specification.source_width
			layer["scale"] = 0.5
			changed = {"before": changed, "after": layer.duplicate(true)}
		if matches != 1:
			_fail("候選 adapter 需要精確一個正式 background sprite：" + raw_id)
			return false
		var path := str(specification.path)
		if not FileAccess.file_exists(path) or not ResourceLoader.exists(path):
			_fail("候選 background 未複製／匯入：" + path)
			return false
		var texture := RigLibrary.optional_texture(path)
		if texture == null:
			_fail("候選 background Texture2D 無法載入：" + path)
			return false
		var actual_scale := StageLayers.sprite_scale(changed.after, texture)
		var actual_rect := Rect2(StageLayers.vec2_of(specification.pos), texture.get_size() * actual_scale)
		var expected_size := Vector2(float(specification.source_width), float(specification.source_height)) * 0.5
		if not actual_rect.size.is_equal_approx(expected_size):
			_fail("候選 import 寬高比不符，不能保留原家具世界尺度：" + path)
			return false
		_record_source(StageLibrary.path_of(id))
		_record_source(str(specification.original))
		_record_source(path)
		_record_source(path + ".import")
		candidate_overrides.append({"stage": raw_id, "classification": "candidate art cache override",
			"original_stage_sha256": FileAccess.get_sha256(StageLibrary.path_of(id)),
			"candidate_image_sha256": FileAccess.get_sha256(path), "definition_override": changed,
			"loaded_texture_size": _vec(texture.get_size()), "loaded_sprite_scale": actual_scale,
			"expected_world_rect": _rect(Rect2(StageLayers.vec2_of(specification.pos), expected_size)),
			"original_pixel_offset": specification.original_pixel_offset,
			"original_region_preserved": "root source pixel comparison; probe observes placement/scale, not pixel identity",
			"native_adopted": false})
		original_stage_cache[id] = original
		replacements[id] = copy
	for id: StringName in replacements:
		StageLibrary._cache[id] = replacements[id]
	return true


func _restore_candidate_cache() -> void:
	for id: StringName in original_stage_cache:
		StageLibrary._cache[id] = original_stage_cache[id]
	original_stage_cache.clear()


func _exit_tree() -> void:
	_restore_candidate_cache()


func _generator_scales() -> Dictionary:
	var regex := RegEx.new()
	regex.compile("(?ms)^SCALE = (\\{.*?^\\})")
	var found := regex.search(FileAccess.get_file_as_string(GENERATOR_PATH))
	if found == null:
		_fail("generator SCALE 格式改變，需更新唯讀 adapter：" + GENERATOR_PATH)
		return {}
	# 此 literal 只含字串、數字與 dictionary；Python trailing comma 需移除。
	var raw := found.get_string(1).replace("'", "\"")
	var commas := RegEx.new()
	commas.compile(",\\s*([}])")
	raw = commas.sub(raw, "$1", true)
	var parsed: Variant = JSON.parse_string(raw)
	if not parsed is Dictionary or parsed.size() != 6:
		_fail("generator SCALE 不再是六舞台數字字典；拒絕沿用過期抄本")
		return {}
	for id: String in parsed:
		if not parsed[id] is Dictionary:
			_fail("generator SCALE 舞台欄位不是 dictionary：" + id)
			return {}
		for kind: String in parsed[id]:
			var value: Variant = parsed[id][kind]
			if not (value is float or value is int) or not is_finite(float(value)) or float(value) <= 0:
				_fail("generator SCALE 不是有限正數：%s / %s" % [id, kind])
				return {}
	return parsed


func _play(id: String, scene: Dictionary, classification: String) -> void:
	playback_serial += 1
	active_classification = classification + (" / candidate art cache override; NOT adopted" if candidate_art else "")
	finished_current = false
	player = CutscenePlayer.new()
	add_child(player)
	player.finished.connect(_mark_finished)
	# 正式原始 steps，不改鏡頭、比例、演出速度；不透過 Story 完成／獎勵／旗標管線。
	player.play(StringName(id), scene.duplicate(true))
	var deadline := Time.get_ticks_msec() + SCENE_TIMEOUT_MS
	var next_sample := 0
	var dialogue_key := ""
	var dialogue_since := 0
	while is_instance_valid(player) and player.is_running():
		await get_tree().process_frame
		if not is_instance_valid(player) or not player.is_running():
			break
		var now := Time.get_ticks_msec()
		if now > deadline:
			_fail("分鏡逾時：" + id)
			player.cancel()
			break
		if now >= next_sample:
			next_sample = now + int(SAMPLE_SECONDS * 1000)
			var row := _measure()
			if not row.is_empty():
				if rows.size() >= MAX_ROWS:
					_fail("量測列超過固定上限，停止而不截斷假報告")
					player.cancel()
					break
				rows.append(row)
				var key := "%s/%s/%s/%s" % [id, row.stage, row.step, row.pose_signature]
				if player._dialogue.visible:
					coverage_keys[key] = true
					if not shot_keys.has(key) and not omission_keys.has(key):
						if shots.size() >= MAX_SHOTS:
							_omit(key, row, "MAX_SHOTS=64；持續量測但未留此照片")
						else:
							capture_waiting_keys[key] = true
							if await _shot(row):
								shot_keys[key] = true
								capture_waiting_keys.erase(key)
		if not is_instance_valid(player) or not player.is_running():
			break
		if player._dialogue.visible:
			var key := str(player.steps_run) + "/" + player._dialogue._text.text
			if key != dialogue_key:
				dialogue_key = key
				dialogue_since = now
			# 實際 _input 路徑：一次顯示完整句，保留 1 秒閱讀／動效，再確認下一句。
			if now - dialogue_since >= 1000:
				_tap_confirm()
				dialogue_since = now - 500 if not player._dialogue.is_complete() else now
		elif player.choice_active() and now - dialogue_since >= 1000:
			# 新稿有 choice 時，正常 focused button 的確認輸入；變更只在隔離 profile。
			_tap_confirm()
			dialogue_since = now
	for key: String in capture_waiting_keys.keys():
		if key.begins_with(id + "/"):
			_omit(key, {"scene": id}, "結束前未取得同段全文完成的穩定frame")
			capture_waiting_keys.erase(key)
	if finished_current:
		completed_scenes.append(id)
	await get_tree().process_frame


func _mark_finished(id: StringName) -> void:
	finished_current = true
	print("[ST10] completed playback: " + str(id))


func _tap_confirm() -> void:
	for pressed: bool in [true, false]:
		var event := InputEventAction.new()
		event.action = &"ui_accept"
		event.pressed = pressed
		Input.parse_input_event(event)


func _measure() -> Dictionary:
	if not is_instance_valid(player) or not is_instance_valid(player._stage) or player._actors.is_empty():
		return {}
	var holder := player._stage_holder
	var xf := holder.get_global_transform()
	if is_zero_approx(xf.determinant()):
		_fail("舞台 transform 不可逆：" + str(player.scene_id))
		return {}
	var inverse := xf.affine_inverse()
	var canvas := holder.get_canvas_transform()
	var safe := Story.framing.safe_rect()
	var framing: Dictionary = player.call("framing_status") if player.has_method("framing_status") else {
		"supported": false, "feasible": false, "reason": "legacy Player without continuous framing API", "actors": {}}
	# 純工具讀取目前 plan，補公開 status 尚未列出的精確 q／中心限制；不修改 product API。
	if player.has_method("framing_status"):
		var plan: RefCounted = player.get("_framing_plan")
		if is_instance_valid(plan):
			var summary := {}
			for key: String in ["valid_input", "actor_region", "fit_zoom_max", "cover_zoom_min",
					"_q_min", "_q_max", "required_art_bounds", "camera_position", "zoom"]:
				summary[key] = plan.get(key)
			framing["cached_plan_geometry"] = summary
	var framing_row := _framing_row(framing)
	_record_source(StageLibrary.path_of(player._stage.stage_id))
	var source_layers: Array = StageLibrary.definition(player._stage.stage_id).get("layers", [])
	var panel := player._dialogue._panel.get_global_rect()
	var portrait := player._dialogue._frame.get_global_rect()
	# 預留完整肖像／字幕的固定預算，避免每句有無肖像使鏡頭跳動。
	var subtitle_top := minf(panel.position.y, portrait.position.y)
	var budget := Rect2(safe.position + Vector2(MARGIN, MARGIN),
		Vector2(safe.size.x - 2 * MARGIN, subtitle_top - safe.position.y - 2 * MARGIN))
	var actors: Array[Dictionary] = []
	var union := Rect2()
	var first := true
	var geometry_ok := true
	var signature := ""
	var standing_h := 0.0
	for id: StringName in player._actors:
		var actor: CutsceneActor = player._actors[id]
		var world := actor.rig.visual_bounds() if actor.rig != null else _sprite_world(actor._portrait)
		if not world.has_area():
			_fail("演員缺少可量測的視覺邊界：" + str(id))
			continue
		# visual_bounds 已包含 stage_holder 的 camera transform；只套 canvas，絕不再次乘 camera。
		var screen := canvas * world
		var local := inverse * world
		union = local if first else union.merge(local)
		first = false
		var clipped_top := maxf(0, budget.position.y - screen.position.y)
		var clipped_bottom := maxf(0, screen.end.y - budget.end.y)
		var fits := budget.encloses(screen)
		geometry_ok = geometry_ok and fits
		var loop := str(actor._input.npc_loop)
		var weapon_source := str(actor.rig.weapon_def().get("file", "")) if actor.rig != null else ""
		var source_signature := "%s:%s:%s:%s:%d:%s:%s:%s:%s" % [id, actor.pose, loop,
			PackedFloat64Array([actor._input.npc_loop_scale]).to_byte_array().hex_encode(), actor.facing,
			weapon_source, actor.rig.active_pose_parts() if actor.rig != null else &"", actor._input.talking, actor._listen_flag]
		var detail := {"id": str(id), "pose": str(actor.pose), "scale": _vec(actor.scale),
			"rig": actor.rig.skin_id if actor.rig != null else "portrait", "loop": loop,
			"loop_scale": actor._input.npc_loop_scale, "facing": actor.facing, "weapon_source": weapon_source,
			"active_pose_parts": str(actor.rig.active_pose_parts()) if actor.rig != null else "",
			"talking": actor._input.talking, "listening": actor._listen_flag, "source_signature": source_signature,
			"stage_body": _rect(local), "viewport_body": _rect(screen),
			"presentation_body": _rect(get_viewport().get_final_transform() * screen),
			"head_cut_px": clipped_top, "feet_overlap_px": clipped_bottom,
			"full_body_fits": fits, "origin_floor_delta": actor.position.y - actor.ground_y,
			"floor": actor.ground_y, "origin_stage": _vec(actor.position), "bounds_include_weapon": false}
		detail["floor_viewport_y"] = (canvas * xf * Vector2(actor.position.x, actor.ground_y)).y
		detail["visual_bottom_floor_delta"] = local.end.y - actor.ground_y
		detail["head_metric"] = "conservative complete body AABB top; not an opaque head pixel segmentation"
		if actor.rig != null:
			var bones := {}
			for name: StringName in [&"head", &"hip", &"foot_front", &"foot_back"]:
				if actor.rig.has_bone(name):
					bones[str(name)] = _vec(canvas * actor.rig.bone(name).global_position)
			detail["bone_viewport"] = bones
			var weapon := actor.rig._weapon_sprite
			if is_instance_valid(weapon) and weapon.is_visible_in_tree() and weapon.texture != null:
				detail["weapon_viewport"] = _rect(canvas * _sprite_world(weapon))
		if actor.rig != null:
			_record_source("res://art/characters/%s/character.json" % actor.rig.skin_id)
			_record_source("res://art/motion/%s.json" % actor.rig.skin_id)
			var skin: Dictionary = RigLibrary.character(actor.rig.skin_id)
			_record_character_sources(skin, RigLibrary.character_dir(actor.rig.skin_id))
			var rig_source := str(skin.get("rig", ""))
			if not rig_source.is_empty():
				_record_source(rig_source)
			if not weapon_source.is_empty():
				_record_source(weapon_source)
		var cached: Dictionary = (framing.get("actors", {}) as Dictionary).get(id, {})
		if not cached.is_empty() and cached.get("bounds") is Rect2 and cached.get("origin_sweep") is Rect2:
			var bound: Rect2 = cached["bounds"]
			var mirrored := Rect2(Vector2(-bound.end.x, bound.position.y), bound.size)
			var modes: Dictionary = player.get("_actor_facings")
			var mode := int(modes.get(id, actor.facing))
			if mode == 0:
				bound = bound.merge(mirrored)
			elif actor.facing < 0 and actor.rig != null:
				bound = mirrored
			var cached_stage := _sum_rect(Transform2D(0.0, actor.scale, 0.0, Vector2.ZERO) * bound, cached["origin_sweep"])
			detail["continuous_actor_stage_rect"] = _rect(cached_stage)
			detail["continuous_facing_mode"] = mode
			detail["observed_body_in_continuous_cache"] = cached_stage.grow(0.001).encloses(local)
			if detail.has("weapon_viewport"):
				detail["observed_weapon_in_continuous_cache"] = cached_stage.grow(0.001).encloses(inverse * _sprite_world(actor.rig._weapon_sprite))
		actors.append(detail)
		signature += source_signature + ";"
		if id == &"rin" and actor.pose == &"idle":
			standing_h = local.size.y
	var backgrounds: Array[Dictionary] = []
	var props: Array[Dictionary] = []
	var background := Rect2()
	for group: Node2D in [player._stage.back, player._stage.front]:
		for node: Node in group.get_children():
			# _Glow 同樣繼承 Sprite2D；柔光貼圖不是家具或可填滿畫面的背景藝術。
			if str(node.get_meta(&"kind", "")) != "sprite":
				continue
			var sprite := node as Sprite2D
			if sprite == null or sprite.texture == null:
				continue
			var world := _sprite_world(sprite)
			var local := inverse * world
			var screen := canvas * world
			var path := sprite.texture.resource_path
			_record_source(path)
			_record_source(path + ".import")
			var definition := {}
			for layer: Dictionary in source_layers:
				if str(layer.get("path", "")) == path:
					definition = layer
					break
			var entry := {"path": path, "stage_rect": _rect(local), "viewport_rect": _rect(screen),
				"texture_size": _vec(sprite.texture.get_size()), "parallax": sprite.get_meta(&"parallax", 1.0),
				"loaded_sprite_scale": _vec(sprite.scale), "loaded_sprite_origin": _vec(sprite.position),
				"centered": sprite.centered, "source_definition": definition, "source_sha256": source_records[path]["sha256"]}
			if path.contains("/environment/scenes/"):
				entry["covers_safe_rect"] = screen.encloses(safe)
				backgrounds.append(entry)
				if local.get_area() > background.get_area():
					background = local
			else:
				entry["height_over_rin_H"] = local.size.y / standing_h if standing_h > 0 else null
				entry["width_over_rin_H"] = local.size.x / standing_h if standing_h > 0 else null
				entry["metric_scope"] = "texture rectangle; alpha/contact/seat anchors require manual review"
				props.append(entry)
	var art_ok := false
	for entry: Dictionary in backgrounds:
		art_ok = art_ok or bool(entry.covers_safe_rect)
	return {"scene": str(player.scene_id), "stage": str(player._stage.stage_id), "step": player.steps_run,
		"classification": active_classification, "candidate_art_overridden_stage": candidate_art and CANDIDATE_ART.has(str(player._stage.stage_id)),
		"pose_signature": signature, "time_ms": Time.get_ticks_msec(),
		"viewport": _vec(get_viewport().get_visible_rect().size), "safe_rect": _rect(safe),
		"dialogue_visible": player._dialogue.visible, "panel_rect": _rect(panel), "portrait_rect": _rect(portrait),
		"dialogue_top": subtitle_top, "full_body_budget": _rect(budget), "actors": actors,
		"camera_author_pos": _vec(player.cam_pos), "camera_author_zoom": player.cam_zoom,
		"framing_status": framing_row,
		"camera_application": "continuous-cache effective camera" if bool(framing.get("feasible", false)) else "author camera fallback / no applicable plan",
		"dialogue_complete": player._dialogue.is_complete(),
		"text_scale_geometry": {"panel_actual_size": _vec(player._dialogue._panel.size),
			"panel_minimum": _vec(player._dialogue._panel.get_combined_minimum_size()),
			"text_rect": _rect(player._dialogue._text.get_global_rect()), "name_rect": _rect(player._dialogue._name.get_global_rect()),
			"body_font_px": player._dialogue._text.get_theme_font_size(&"font_size"), "font_style": UiKit.font_style(),
			"panel_inside_safe": safe.encloses(panel), "portrait_inside_safe": safe.encloses(portrait)},
		"holder_transform": str(xf), "canvas_transform": str(canvas), "presentation_transform": str(get_viewport().get_final_transform()),
		"backgrounds": backgrounds, "props": props, "rin_standing_H": standing_h,
		"geometry_accepted": geometry_ok and art_ok and not first, "background_art_covers": art_ok,
		"geometry_scope": "actual sampled body AABB/art cover only; not continuous proof or weapon/seat acceptance",
		"continuous_plan_feasible": bool(framing.get("feasible", false)),
		"feasibility": _feasibility(union, background, budget, safe), "manual_furniture_review_pending": true}


func _feasibility(actor: Rect2, art: Rect2, target: Rect2, cover: Rect2) -> Dictionary:
	if not actor.has_area() or not art.has_area() or not target.has_area():
		return {"solvable": false, "reason": "missing bounds"}
	var center := get_viewport().get_visible_rect().size * 0.5
	var fit_max := minf(target.size.x / actor.size.x, target.size.y / actor.size.y)
	var cover_min := maxf(cover.size.x / art.size.x, cover.size.y / art.size.y)
	# q = 1 / zoom；中心上下界皆為 a+b*q，四種兩兩不等式求精確可行區間。
	var q_min := 1.0 / fit_max
	var q_max := 1.0 / cover_min
	var lower := [actor.end, art.position]
	var upper := [actor.position, art.end]
	var lower_slope := [center - target.end, center - cover.position]
	var upper_slope := [center - target.position, center - cover.end]
	var possible := q_min <= q_max
	for axis in 2:
		for i in 2:
			for j in 2:
				var coefficient: float = lower_slope[i][axis] - upper_slope[j][axis]
				var rhs: float = upper[j][axis] - lower[i][axis]
				if is_zero_approx(coefficient):
					possible = possible and rhs >= 0
				elif coefficient > 0:
					q_max = minf(q_max, rhs / coefficient)
				else:
					q_min = maxf(q_min, rhs / coefficient)
	possible = possible and q_max >= q_min and q_max > 0
	# 無解時仍報 actor-fit 鏡頭需要的背景世界區域，不能用黑色底層假裝 cover。
	var q := clampf(1.0 / player.cam_zoom, q_min, q_max) if possible else 1.0 / fit_max
	var low: Vector2 = lower[0] + lower_slope[0] * q
	var high: Vector2 = upper[0] + upper_slope[0] * q
	if possible:
		low = low.max(lower[1] + lower_slope[1] * q)
		high = high.min(upper[1] + upper_slope[1] * q)
	var camera := player.cam_pos.clamp(low, high)
	var needed := Rect2(camera + (cover.position - center) * q, cover.size * q)
	return {"solvable": possible, "actor_fit_zoom_max": fit_max, "art_cover_zoom_min": cover_min,
		"candidate_zoom": 1.0 / q, "candidate_camera": _vec(camera), "required_art_world_rect": _rect(needed),
		"extension_world": {"left": maxf(0, art.position.x - needed.position.x),
			"top": maxf(0, art.position.y - needed.position.y), "right": maxf(0, needed.end.x - art.end.x),
			"bottom": maxf(0, needed.end.y - art.end.y)},
		"scope": "current sampled AABB, one parallax=1 rectangular art layer; not swept motion proof"}


func _shot(row: Dictionary) -> bool:
	if not player._dialogue.is_complete():
		_tap_confirm()
	# 保留正式 slide 動畫，等肖像完成滑入後再留完整台詞；不修改 UI source。
	await get_tree().create_timer(0.25, true, false, true).timeout
	# PNG 與數字在同一 frame_post_draw 重新取樣，不沿用等待前的移動位置。
	await RenderingServer.frame_post_draw
	var current := _measure()
	if current.is_empty() or not is_instance_valid(player) or not player._dialogue.visible:
		return false
	if not player._dialogue.is_complete() or current.step != row.step or current.pose_signature != row.pose_signature:
		return false # 留在 coverage waiting；不得把另一句／未完成字幕冒充這個 shot。
	var image := Capture.image(get_viewport())
	var file := "ST-10-%s-%03d-%s.png" % ["wide" if wide else "16x9", shots.size(), row.stage]
	if image.is_empty() or image.save_png(output.path_join(file)) != OK:
		_fail("無法寫入畫面：" + file)
		return false
	current["file"] = file
	current["readback_size"] = _vec(image.get_size())
	image = null # 每張落盤後釋放，不跨shot保留 Image。
	current["capture_dialogue_complete"] = true
	shots.append(current)
	if debug_bounds:
		guides.update_from(current)
		guides.show()
		await RenderingServer.frame_post_draw
		var debug_image := Capture.image(get_viewport())
		var debug_file := file.trim_suffix(".png") + "-bounds.png"
		if debug_image.is_empty() or debug_image.save_png(output.path_join(debug_file)) != OK:
			_fail("無法寫入標線畫面：" + debug_file)
		debug_image = null
		guides.hide()
		current["debug_file"] = debug_file
		current["debug_scope"] = "next rendered frame; animation may advance"
	return true


func _write_report() -> void:
	var geometry_ok := not rows.is_empty()
	for row: Dictionary in rows:
		geometry_ok = geometry_ok and bool(row.geometry_accepted)
	var report := {"tool_completed": errors.is_empty(), "accepted": false,
		"geometry_accepted": geometry_ok, "manual_review_pending": true, "errors": errors,
		"engine": Engine.get_version_info(), "renderer": RenderingServer.get_current_rendering_method(),
		"aspect": "tool EXPAND" if wide else "formal KEEP", "ui_text_scale": 1.2,
		"story_source_sha256": FileAccess.get_sha256(STORY_PATH), "generator_sha256": FileAccess.get_sha256(GENERATOR_PATH),
		"baseline_sha": baseline_sha, "baseline_origin": "launch wrapper ST10_BASELINE; full git HEAD, not a source constant",
		"probe_sha256": FileAccess.get_sha256(get_script().resource_path), "source_manifest": source_records,
		"envelope_diagnostics": envelope_records,
		"framing_status_encoding": "top-level cached continuous status each row; per-actor angles/targets deduplicated by playback/stage/id/context with envelope_ref",
		"photo_coverage": {"observed_dialogue_signature_count": coverage_keys.size(), "captured_signature_count": shot_keys.size(),
			"omitted_signature_count": omission_keys.size(), "omissions": coverage_omissions,
			"complete": omission_keys.is_empty() and coverage_keys.size() == shot_keys.size(), "max_shots": MAX_SHOTS},
		"art_adoption_verified": false, "native_adopted": false,
		"candidate_art": candidate_art, "candidate_overrides": candidate_overrides,
		"photo_limit_scope": "64 primary contexts; optional debug adds at most 64 next-frame PNGs",
		"art_source_scope": "actual runtime source paths/hashes/bounds; not PM or manual adoption acceptance",
		"sampling_scope": "8Hz rows can miss immediate/intermediate steps; raw warnings retained; photo coverage counts observed dialogue signatures only",
		"sampling_seconds": SAMPLE_SECONDS, "completed_scenes": completed_scenes, "rows": rows, "shots": shots,
		"limits": "8Hz sampled geometry, no manual artwork/seat acceptance, no story flags/rewards or player walkthrough"}
	var file := FileAccess.open(output.path_join("ST-10-report.json"), FileAccess.WRITE)
	if file == null:
		_fail("無法寫入報告：" + error_string(FileAccess.get_open_error()))
		return
	file.store_string(JSON.stringify(report, "\t"))
	print("[ST10] tool_completed=%s accepted=false geometry_accepted=%s rows=%d shots=%d" % [errors.is_empty(), geometry_ok, rows.size(), shots.size()])


func _fail(message: String) -> void:
	errors.append(message)
	push_error("[ST10 probe] " + message)


func _sprite_world(sprite: Sprite2D) -> Rect2:
	return sprite.get_global_transform() * sprite.get_rect() if is_instance_valid(sprite) and sprite.texture != null else Rect2()


func _vec(v: Vector2) -> Array:
	return [v.x, v.y]


func _rect(r: Rect2) -> Array:
	return [r.position.x, r.position.y, r.size.x, r.size.y]


func _record_source(path: String) -> void:
	if source_records.has(path):
		return
	var available := FileAccess.file_exists(path)
	source_records[path] = {"path": path, "available": available,
		"sha256": FileAccess.get_sha256(path) if available else ""}


func _sum_rect(a: Rect2, b: Rect2) -> Rect2:
	return Rect2(a.position + b.position, a.size + b.size)


func _json_value(value: Variant, depth := 0) -> Variant:
	if depth > 8:
		_fail("framing status 超出純資料深度上限")
		return null
	if value is Rect2:
		return _rect(value)
	if value is Vector2:
		return _vec(value)
	if value is Vector4:
		return [value.x, value.y, value.z, value.w]
	if value is Dictionary:
		var data := {}
		for key: Variant in value:
			data[str(key)] = _json_value(value[key], depth + 1)
		return data
	if value is Array or value is PackedStringArray:
		var data := []
		for item: Variant in value:
			data.append(_json_value(item, depth + 1))
		return data
	return value


func _framing_row(status: Dictionary) -> Dictionary:
	var result := status.duplicate()
	var actors := {}
	var raw: Dictionary = status.get("actors", {})
	for id: Variant in raw:
		var data: Dictionary = raw[id]
		var key := "%s/%s/%s/%s/%s/%s" % [playback_serial, player._stage.stage_id,
			id, data.get("contexts", 0), data.get("supported", false), data.get("reason", "")]
		if not envelope_keys.has(key):
			if envelope_records.size() >= MAX_ROWS:
				_fail("continuous envelope 診斷超過固定上限；不截斷假報完整")
				return {"supported": false, "reason": "diagnostic capacity exceeded"}
			envelope_keys[key] = envelope_records.size()
			var record: Dictionary = _json_value(data)
			record["ref"] = envelope_records.size()
			record["stage"] = str(player._stage.stage_id)
			record["scene"] = str(player.scene_id)
			record["actor"] = str(id)
			_record_source("res://art/weapons/weapons.json")
			envelope_records.append(record)
		actors[str(id)] = {"envelope_ref": envelope_keys[key], "bounds": _json_value(data.get("bounds", Rect2())),
			"origin_sweep": _json_value(data.get("origin_sweep", Rect2())), "contexts": data.get("contexts", 0),
			"supported": data.get("supported", false), "reason": data.get("reason", "")}
	result["actors"] = actors
	return _json_value(result)


func _omit(key: String, row: Dictionary, why: String) -> void:
	if omission_keys.has(key):
		return
	omission_keys[key] = true
	coverage_omissions.append({"key": key, "scene": row.get("scene", ""), "stage": row.get("stage", ""),
		"step": row.get("step", -1), "source_signature": row.get("pose_signature", ""), "reason": why})


class Guides:
	extends Node2D
	var rectangles: Array[Rect2] = []
	var safe := Rect2()
	var budget := Rect2()
	var floor_lines: Array[float] = []

	func update_from(row: Dictionary) -> void:
		rectangles.clear()
		floor_lines.clear()
		safe = StageLayers.rect_of(row.safe_rect)
		budget = StageLayers.rect_of(row.full_body_budget)
		for actor: Dictionary in row.actors:
			rectangles.append(StageLayers.rect_of(actor.viewport_body))
			floor_lines.append(float(actor.floor_viewport_y))
		queue_redraw()

	func _draw() -> void:
		draw_rect(safe, Color.CYAN, false, 1)
		draw_rect(budget, Color.YELLOW, false, 1)
		for r in rectangles:
			draw_rect(r, Color.MAGENTA, false, 1)
		for y in floor_lines:
			draw_line(Vector2(safe.position.x, y), Vector2(safe.end.x, y), Color.GREEN, 1)
