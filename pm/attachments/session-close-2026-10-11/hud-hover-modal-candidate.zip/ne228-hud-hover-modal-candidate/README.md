# NE228 背景 HUD tooltip／modal 邊界最小候選

2026-10-11；CPU-only，候選已凍結，依使用者移交 Session 的要求停下。沒有改 repo、Git、PM、Source／Snapshot／Story／Port／GameplayLock／token，也沒有啟動引擎或生成 UID。**Godot semantic import、測試 helper、原 changed runner、native 都 NOT RUN。** NE228 不新開票、不改狀態。

## 精確範圍

- modified `ui/hud.gd`：actual private preimage SHA `50fcc79ea9eba42813ea33901c74a9141c504603c863c787a19dd92ec6310872` → candidate `e546e9f269293a479ef5101d9068ab1e2900d4829e9e298a2b62998f63770d34`。
- NEW `tests/helpers/hud_background_mouse_checks.gd`：preimage ABSENT → `a1e585efa4ed83cf98c2f8831dd31373d3cfcab949309f34d5c9eedd8d230699`。

原 HUD 所有來源行完整保留、順序不變，只有新增。CombatHudSuite 原檔不改；下一 Session 由 Root 串接 helper，避免与 controller 同檔競爭。精確 bytes、protected sources 在 patch-index.json；CPU 靜態 scope／保留檢查 14 / 0，兩 GD 的 gdparse grammar clean。這不等於 Godot 型別／生命週期／UI 行為通過。29 個 helper assertion call sites（含 idle precondition 失敗分支）不是已執行 checks。

## 官方 4.7.2 研究與方案

使用 [4.7.2-stable Control source](https://raw.githubusercontent.com/godotengine/godot/4.7.2-stable/scene/gui/control.cpp)、[4.7.2-stable Viewport source](https://raw.githubusercontent.com/godotengine/godot/4.7.2-stable/scene/main/viewport.cpp)、[該 tag Control class XML](https://raw.githubusercontent.com/godotengine/godot/4.7.2-stable/doc/classes/Control.xml)。原始下載 bytes 留 official/，SHA 在 freeze manifest；未依 latest 文件猜行為。本文行號指本包下載複本。

Control.cpp:2581–2639 的 recursive disabled 會讓繼承子項 effective filter 變 IGNORE，並更新 viewport hover hierarchy；Viewport.cpp:2594–2685 的更新只發退出通知、移除 hover，沒有取消舊 tooltip。Viewport.cpp:1553–1563 的取消才同時断 tooltip timer 與 queue-free popup。Viewport::cancel_tooltip 雖是 C++ method，沒有 ClassDB 綁定；候選完全不呼叫這個不存在的 GDScript API。

實際 private Hud 沒有 ALWAYS 設定，UiKit root 也沒有；繼承 pausable 的 HUD 在首次暫停後不會跑 `_process`。候選用 HUD 自身 PAUSED／UNPAUSED notification 同步切換 root recursive DISABLED／INHERITED，ready 與既有 process 亦同步，處理加入已暫停樹與未來處理模式。原 Hud 處理模式不改，HUD／計時／radio／Pause 的可見規則不改。

取消舊 tooltip 使用官方 visibility hook（Control.cpp:4644–4649 → Viewport.cpp:2550–2567）：只對實際 hovered 且在 HUD root 下的 Control 同步 hide→恢復其 original visible。沒有 await，沒有 render frame 隱藏 HUD；完整 HUD root 不 hide，也沒有全域 popup close。這個局部 visibility pulse 會發該 Control／子項的 visibility 通知與 mouse-exit，因此是明列副作用，native 須驗沒有 layout／動作提示閃動或改旗標。

若 hover 已移走但舊 popup 還在，暫停 edge 只掃 HUD subtree 的 `PopupPanel` 且 theme type 為 `TooltipPanel`，重設其 HUD owner visibility，並只 queue-free 該 HUD-owned tooltip。跳過其他 Window 子樹，不操作 Radio／Pause 的 tooltip 或輸入。這是依引擎 tooltip 建立方式（Viewport.cpp:1661–1687，popup 掛到 tooltip owner）的有界 fallback；不讀私有 viewport 欄位、不安裝 owner。若未來 tooltip 完全移到 HUD 外，這個 owner 範圍須重新審核。

同步快路徑只比較 pause bool；掃子樹／visibility pulse 只在 pause edge，沒有每影格建立字串、節點或陣列。原 child mouse_filter 與 tooltip_text 不重寫。直接掛在 Hud、但不在 root 下的其他 CanvasLayer 元件不納入此最小候選。

## 有意義測試候選與下一次驗證

Helper 在真 Level/Hud 下建立一個 HUD 子控制項，以 synthetic pointer 真走 viewport hover 並等待引擎實際 tooltip；不是手造 popup。獨立 DialogueLayer 的實際 reading lease 加上 Level 真 PauseMenu，核首次 pause（Hud 已不可 process）仍即時禁用、舊 popup 退休、六個保留項（文字/filter/可見/幾何/UI processing/讀訊進度）、Pause focus/按鈕與確認輸入、關閉 Pause 保留 reading、cancel 後 normal restore。另一分支由 child recursive disabled 真移除 hover 而保留 engine popup，驗 fallback，再驗 fresh hover 可重建 tooltip。這是 UI fixture，沒有 Main/Source/cold/durable、實體滑鼠或整章證明。所有收尾只 cancel/close fixture-own UI，不全域 clear leases。

下一 Session：Root 先 exact preimage 保護下採用兩檔；semantic import 必須全 raw 無腳本／解析／編譯錯誤。串接 `await preload("res://tests/helpers/hud_background_mouse_checks.gd").run(self)` 至正在協作的 CombatHudSuite，再跑原 changed runner（不改 selector／known failures）；保留自然 EOF。未使用引擎，現在沒有 UID 候選，可由 Root 的隔離 import 產生並精確收據。

Native 必須重做 combat4 相同 geometry、原真射擊→取盤／跨 threshold→讀訊／Pause／返回閱讀路線：先在未鎖時停滑鼠讓任務 tooltip 真顯示，保持滑鼠不動再觸發通訊；另在 delay 尚未到時觸發，驗 pending timer 沒有晚冒 tooltip。保存同位置前後 PNG，確認講者與 Pause 目標不被背景 tooltip 遮住、HUD 不閃隱，讀訊 confirm 與 Pause button／focus正常，時鐘／同一真子彈／敵人凍結證據仍成立。再關閉最後 owner，真 hover 要能重新顯示提示。fallback 的 stale popup、keyboard focus、實體手把及其他 modal／尺度結果都仍待驗。

## 原圖與交付界線

真 defect 基準不是新候選結果：[combat4 返回閱讀圖](C:/tmp/ne246-combat-native-4/native/normal-actual-manual-reading-pause-return.png)、[combat4 actual Pause 圖](C:/tmp/ne246-combat-native-4/native/normal-actual-pause-above-manual.png)。兩圖保持原 bytes；本包 observations 未生成任何新 PNG。這兩圖的 tooltip 遮擋屬 NE228，與 NE223／NE229 關聯；未宣稱修好。NE246 原生 528/0 + combat4 97/0 只屬原來源；不能轉嫁到新 Hud 候選。

使用者要求收尾並停下：此包只供下一 Session 精確審查／採用。`pm/user_guide.md` 與任何票都沒有由本 agent 修改，交接給 Root 處理。
