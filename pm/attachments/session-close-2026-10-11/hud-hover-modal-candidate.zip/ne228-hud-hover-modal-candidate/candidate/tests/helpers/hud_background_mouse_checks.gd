extends RefCounted
## UI fixture only: real Hud/DialogueLayer/PauseMenu, synthetic pointer/confirm input.
## No Main/Source/durable proof, hardware mouse or full chapter claim.

static func run(s: TestSuite) -> void:
	if s.runner.get_tree().paused or GameplayLock.is_locked() or Story.is_cinematic_active() or Story.atomic_producer_busy() or not Story._passive_requests.is_empty():
		s.check(false, "HUD background mouse fixture requires idle unpaused owners")
		return
	var level: Level = await s.start_level(PropsSuite.level_data())
	var hud: Hud = level.hud
	var root: Control = hud._hud_root
	var viewport: Viewport = hud.get_viewport()
	var previous_mouse: Vector2 = viewport.get_mouse_position()
	var pause: PauseMenu = level._pause_menu
	var root_rect: Rect2 = root.get_rect()
	var probe := PanelContainer.new()
	probe.position = Vector2(20, 80)
	probe.size = Vector2(120, 24)
	probe.mouse_filter = Control.MOUSE_FILTER_STOP
	probe.tooltip_text = "這是只屬於背景 HUD 的說明。"
	root.add_child(probe)
	var initial_text: String = probe.tooltip_text
	var initial_rect: Rect2 = probe.get_rect()
	s.check(root.mouse_behavior_recursive == Control.MOUSE_BEHAVIOR_INHERITED, "normal HUD inherits mouse behavior")
	s.check(probe.get_mouse_filter_with_override() == Control.MOUSE_FILTER_STOP, "normal HUD child accepts its original mouse filter")
	_move(viewport, probe.get_global_transform_with_canvas() * (probe.size * 0.5))
	await s.frames(2)
	s.check(viewport.gui_get_hovered_control() == probe, "synthetic pointer genuinely hovers the HUD fixture control")
	await _tooltip_wait(hud.get_tree())
	var old_tooltip: PopupPanel = _owned_tooltip(probe)
	s.check(is_instance_valid(old_tooltip) and old_tooltip.visible, "real engine tooltip exists before reading pause")
	var radio := DialogueLayer.new()
	s.runner.add_child(radio)
	var lines: Array[Dictionary] = [
		{"name": "凜", "color": Palette.CYAN, "text": "請先讀完這一句，再繼續前進。", "portrait": ""},
		{"name": "凜", "color": Palette.CYAN, "text": "第二句仍然需要玩家確認。", "portrait": ""}]
	radio.enqueue_radio(&"hud_background_mouse_fixture", lines)
	s.check(hud.get_tree().paused and not hud.can_process(), "actual reading lease pauses the inherited HUD")
	s.check(root.mouse_behavior_recursive == Control.MOUSE_BEHAVIOR_DISABLED, "pause notification disables HUD mouse immediately without waiting for HUD process")
	s.check(probe.visible and root.is_visible_in_tree() and hud.visible, "reading keeps HUD and hovered child visible")
	s.check(probe.get_rect() == initial_rect and root.get_rect() == root_rect, "reading keeps HUD geometry unchanged")
	s.check(probe.tooltip_text == initial_text and probe.mouse_filter == Control.MOUSE_FILTER_STOP, "pause preserves tooltip text and configured child filter")
	s.check(probe.get_mouse_filter_with_override() == Control.MOUSE_FILTER_IGNORE and hud.cyber_gauge.get_mouse_filter_with_override() == Control.MOUSE_FILTER_IGNORE, "recursive override disables nested HUD controls")
	await s.frames(2)
	s.check(not is_instance_valid(old_tooltip) and _owned_tooltip(probe) == null, "old HUD tooltip is actually retired after its owned hover reset")
	s.check(radio.can_process() and radio._radio_root.visible, "reading UI remains visible and processing outside HUD subtree")
	await RadioReadingChecks.tap(radio)
	s.check(radio._radio_text.visible_ratio == 1.0 and radio._radio_queue.size() == 2, "real reading confirmation still reveals its current line")
	pause.open()
	await s.frames(2)
	s.check(pause._root.visible and pause._resume_button.can_process() and pause._resume_button.get_mouse_filter_with_override() != Control.MOUSE_FILTER_IGNORE, "Pause controls remain interactive outside HUD subtree")
	s.check(pause._resume_button.has_focus(), "Pause keeps actual resume-button focus")
	await RadioReadingChecks.tap(radio)
	s.check(radio._radio_queue.size() == 2, "confirmation behind actual Pause cannot consume unread radio")
	pause.close()
	await s.frames(2)
	s.check(hud.get_tree().paused and probe.get_mouse_filter_with_override() == Control.MOUSE_FILTER_IGNORE, "closing Pause retains reading lease and HUD suppression")
	await _tooltip_wait(hud.get_tree())
	s.check(_owned_tooltip(probe) == null, "stationary pointer cannot revive a pending HUD tooltip during reading")
	radio.cancel_radio()
	await s.frames(2)
	s.check(not hud.get_tree().paused and not GameplayLock.is_locked(), "fixture reading cancel releases only its actual UI lease")
	s.check(root.mouse_behavior_recursive == Control.MOUSE_BEHAVIOR_INHERITED and probe.get_mouse_filter_with_override() == Control.MOUSE_FILTER_STOP, "reading exit restores normal HUD interaction")
	s.check(probe.tooltip_text == initial_text and probe.get_rect() == initial_rect and root.get_rect() == root_rect, "reading exit preserves original text and geometry")
	_move(viewport, probe.get_global_transform_with_canvas() * (probe.size * 0.5))
	await _tooltip_wait(hud.get_tree())
	var renewed: PopupPanel = _owned_tooltip(probe)
	s.check(is_instance_valid(renewed) and renewed.visible, "normal hover creates a fresh HUD tooltip after restoration")
	# Engine-level fixture reproduces stale popup after hover hierarchy removal.
	probe.mouse_behavior_recursive = Control.MOUSE_BEHAVIOR_DISABLED
	s.check(viewport.gui_get_hovered_control() != probe, "fixture removes current hover before the next Pause edge")
	s.check(is_instance_valid(renewed) and renewed.visible, "recursive disabling alone leaves the existing engine tooltip visible")
	pause.open()
	s.check(root.mouse_behavior_recursive == Control.MOUSE_BEHAVIOR_DISABLED and probe.get_mouse_filter_with_override() == Control.MOUSE_FILTER_IGNORE, "standalone Pause also suppresses background HUD")
	await s.frames(2)
	s.check(not is_instance_valid(renewed) and _owned_tooltip(probe) == null and probe.visible, "HUD-owned stale-popup fallback retires tooltip without hiding its owner across a frame")
	probe.mouse_behavior_recursive = Control.MOUSE_BEHAVIOR_INHERITED
	pause.close()
	s.check(root.mouse_behavior_recursive == Control.MOUSE_BEHAVIOR_INHERITED and hud.cyber_gauge.get_mouse_filter_with_override() == Control.MOUSE_FILTER_PASS, "standalone Pause close restores existing HUD child filters")
	_move(viewport, probe.get_global_transform_with_canvas() * (probe.size * 0.5))
	await _tooltip_wait(hud.get_tree())
	var after_fallback: PopupPanel = _owned_tooltip(probe)
	s.check(is_instance_valid(after_fallback) and after_fallback.visible, "fresh hover still shows a tooltip after stale-popup cleanup")
	# All cleanup calls act only on fixture-owned UI, including failure cases.
	pause.close()
	radio.cancel_radio()
	radio.queue_free()
	probe.queue_free()
	_move(viewport, previous_mouse)
	await s.frames(2)
	await s.end_level(level)


static func _move(viewport: Viewport, position: Vector2) -> void:
	var motion := InputEventMouseMotion.new()
	motion.position = position
	motion.global_position = position
	viewport.push_input(motion, true)


static func _tooltip_wait(tree: SceneTree) -> void:
	var delay: float = float(ProjectSettings.get_setting("gui/timers/tooltip_delay_sec", 0.5))
	await tree.create_timer(clampf(delay + 0.1, 0.1, 3.0)).timeout


static func _owned_tooltip(owner: Control) -> PopupPanel:
	for child: Node in owner.get_children():
		if child is PopupPanel and (child as PopupPanel).theme_type_variation == &"TooltipPanel":
			return child as PopupPanel
	return null
