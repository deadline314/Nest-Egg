class_name PrologueLoan
extends RefCounted
## Retains the SAME Loadout and all connected signals. No extra inventory owner.
var _player: WeakRef
var _formal: Dictionary = {}
var _default: WeaponData
var _mode: StringName = &"unbound"
var _closed := false


func bind(player: Player) -> bool:
	if _player != null or not is_instance_valid(player) or player.loadout == null:
		return false
	_player = weakref(player)
	_default = player.tuning.default_weapon
	_formal = player.checkpoint_snapshot().duplicate(true)
	return true


func project() -> Dictionary:
	var value := _formal.duplicate(true)
	var player: Variant = _player.get_ref() if _player != null else null
	if is_instance_valid(player):
		value["consumables"] = player.consumables.snapshot()
	return value


func apply_world(world: Dictionary, flow: PrologueFlowData) -> void:
	var player: Variant = _player.get_ref() if _player != null else null
	if _closed or not is_instance_valid(player):
		return
	var key := PrologueProgressPlan.PREFIX
	var mode: StringName = &"empty"
	if world.get(key + "exited", false) or world.get(key + "tools_returned", false):
		mode = &"formal"
	elif world.get(key + "knife_taken", false):
		mode = &"knife"
	elif world.get(key + "tools_taken", false) and not world.get(key + "gun_returned", false):
		mode = &"pistol"
	if mode == _mode:
		return
	_mode = mode  # install latch BEFORE Loadout.changed observers
	match mode:
		&"formal":
			player.loadout.restore(project(), _default)
		&"pistol":
			player.loadout.reset(flow.pistol)
		&"knife":
			player.loadout.reset(flow.knife)
		_:
			player.loadout.reset(null)


func is_borrowing(weapon: WeaponData) -> bool:
	var player: Variant = _player.get_ref() if _player != null else null
	if (
		_closed
		or not is_instance_valid(player)
		or not _mode in [&"pistol", &"knife"]
		or weapon == null
	):
		return false
	var snapshot: Dictionary = player.loadout.snapshot()
	var paths: Array = snapshot.get("weapons", [])
	var slot: int = player.loadout.active_slot
	var actual: WeaponData = player.loadout.active_weapon()
	return (
		slot >= 0
		and slot < paths.size()
		and paths[slot] == weapon.resource_path
		and actual != null
		and actual.id == weapon.id
	)


func close() -> void:
	if _closed:
		return
	_closed = true
	var player: Variant = _player.get_ref() if _player != null else null
	if (
		is_instance_valid(player)
		and player.is_inside_tree()
		and not player.is_queued_for_deletion()
	):
		player.loadout.restore(project(), _default)
	_player = null
