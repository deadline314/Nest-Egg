class_name PrologueStation
extends Node2D
## A genuine map-bound physical target/control, never an abstract producer flag.
var data: PrologueStationData
var cell: Vector2i
var session: PrologueSession
var reach: Area2D
var hitbox: Hurtbox
var actor: CutsceneActor
var prompt: WorldPrompt
var light: PointLight2D
var door: StaticBody2D
var indicator := false
var pulse_time := -1.0
var pulse_kind: StringName = &""
var _pulse_sent := false
var _contacts := 0
var _health: HealthComponent
var _last_health := 1000000


func _ready() -> void:
	z_index = WorldLayers.ENTITY_BEHIND if data.kind != PrologueStationData.Kind.OLD_K else 0
	reach = Area2D.new()
	reach.collision_layer = 0
	reach.collision_mask = Layers.PLAYER
	reach.monitorable = false
	var shape := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = Vector2(data.interaction_radius * 2.0, 56)
	shape.shape = box
	shape.position.y = -28
	reach.add_child(shape)
	add_child(reach)
	prompt = WorldPrompt.new()
	prompt.text = data.prompt
	prompt.offset = Vector2(0, -64)
	prompt.reach_check = _can_interact
	add_child(prompt)
	if data.kind in [PrologueStationData.Kind.LOW_TARGET, PrologueStationData.Kind.RUBBER_TARGET]:
		_health = HealthComponent.new()
		_health.setup(1000000, 0.0)
		add_child(_health)
		hitbox = Hurtbox.new()
		hitbox.setup(Combat.Team.ENEMY, _health, data.hit_size, Vector2(0, -data.hit_size.y * 0.5))
		add_child(hitbox)
		hitbox.hit_received.connect(_on_hit)
	if data.kind == PrologueStationData.Kind.OLD_K:
		actor = CutsceneActor.new()
		add_child(actor)
		actor.setup(&"old_k", "old_k", "", 1.0, "")
		actor.face(-1)
		actor.set_loop(&"wipe_hands")
		actor.process_mode = Node.PROCESS_MODE_PAUSABLE
		Story.framing.register_target(self)
	if data.kind == PrologueStationData.Kind.LATCH:
		door = StaticBody2D.new()
		door.collision_layer = Layers.WORLD
		var shape := CollisionShape2D.new()
		var box := RectangleShape2D.new()
		box.size = Vector2(8, 74)
		shape.shape = box
		shape.position.y = -37
		door.add_child(shape)
		add_child(door)
	if data.kind == PrologueStationData.Kind.LIGHT:
		light = LightKit.create_point_light(Color(1, .78, .48), 100, .55, false)
		light.position.y = -48
		add_child(light)
	queue_redraw()


func _can_interact() -> bool:
	return is_instance_valid(session) and session.available(self) and actual_overlap()


func actual_overlap() -> bool:
	return (
		is_instance_valid(session)
		and is_instance_valid(session.player)
		and reach.get_overlapping_bodies().has(session.player)
	)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed(&"interact") and _can_interact():
		get_viewport().set_input_as_handled()
		session.interact(self)


func preview_available() -> bool:
	return (
		data.kind == PrologueStationData.Kind.OLD_K
		and is_instance_valid(session)
		and session.available(self)
	)


func interaction_available() -> bool:
	return preview_available() and actual_overlap()


func preview_scene() -> StringName:
	return session.person_scene() if is_instance_valid(session) else &""


func framing_position() -> Vector2:
	return global_position


func framing_priority() -> int:
	return 0


func _exit_tree() -> void:
	if data != null and data.kind == PrologueStationData.Kind.OLD_K:
		Story.framing.unregister_target(self)


func _on_hit(info: DamageInfo) -> void:
	if (
		info == null
		or info.get_attacker() != session.player
		or info.team != Combat.Team.PLAYER
		or _health == null
		or _health.current >= _last_health
	):
		return
	_last_health = _health.current  # real Hurtbox.receive already applied this contact to Health.
	_contacts += 1
	session.actual_target_hit(self, info)
	_health.setup(1000000, 0.0)  # Reusable training target, never a kill/loot producer.
	_last_health = _health.current


func arm(kind: StringName) -> void:
	pulse_kind = kind
	pulse_time = 0.0
	_pulse_sent = false
	indicator = false
	queue_redraw()


func stop() -> void:
	pulse_time = -1.0
	indicator = false
	queue_redraw()


func _physics_process(delta: float) -> void:
	if pulse_time < 0.0:
		return
	if (
		not session.live()
		or GameplayLock.is_locked()
		or get_tree().paused
		or session.player.is_dead()
	):
		stop()
		return
	pulse_time += delta
	var was := indicator
	indicator = pulse_time >= 0.7
	if was != indicator:
		queue_redraw()
	if pulse_time >= 1.1 and not _pulse_sent and actual_overlap():
		_pulse_sent = true
		session.actual_trainer_contact(self)
	if pulse_time >= 1.8:
		stop()


func apply_world(world: Dictionary) -> void:
	var prefix := PrologueProgressPlan.PREFIX
	if door != null:
		door.set_deferred(
			&"collision_layer",
			(
				0
				if (
					world.get(prefix + "p01_information", false)
					and not world.get(prefix + "p06_latch_closed", false)
				)
				else Layers.WORLD
			)
		)
	if light != null:
		light.enabled = not world.get(prefix + "p06_light_off", false)
	queue_redraw()


func _draw() -> void:
	if data == null or data.kind == PrologueStationData.Kind.OLD_K:
		return
	var dark := Color(.20, .22, .25)
	var metal := Color(.53, .55, .57)
	match data.kind:
		PrologueStationData.Kind.LOW_TARGET, PrologueStationData.Kind.RUBBER_TARGET:
			draw_line(Vector2(0, 0), Vector2(0, -data.hit_size.y), metal, 4)
			draw_rect(
				Rect2(-data.hit_size.x * .5, -data.hit_size.y, data.hit_size.x, data.hit_size.y),
				Color(.55, .39, .24)
			)
			draw_circle(Vector2(0, -data.hit_size.y * .5), 6, dark)
		PrologueStationData.Kind.GUARD, PrologueStationData.Kind.DASH:
			draw_rect(Rect2(-24, -6, 48, 6), dark)
			draw_line(Vector2(-12, -6), Vector2(-12, -44), metal, 4)
			var angle := -0.4 if pulse_time < 0.7 else 0.25
			draw_line(
				Vector2(-12, -32), Vector2(-12, -32) + Vector2(30, 0).rotated(angle), metal, 5
			)
			draw_circle(
				Vector2(-12, -47), 3, Color(.35, .8, .35) if indicator else Color(.6, .35, .15)
			)
			if data.kind == PrologueStationData.Kind.DASH:
				draw_line(
					Vector2(-data.lane_width * .5, 0),
					Vector2(data.lane_width * .5, 0),
					Color(.7, .6, .3),
					3
				)
		PrologueStationData.Kind.LATCH:
			draw_rect(Rect2(-4, -74, 8, 74), Color(.37, .25, .17))
			draw_line(Vector2(-7, -32), Vector2(7, -32), metal, 3)
		PrologueStationData.Kind.LIGHT:
			draw_line(Vector2.ZERO, Vector2(0, -50), metal, 3)
			draw_rect(Rect2(-9, -54, 18, 7), Color(.72, .65, .4))
		_:
			draw_rect(Rect2(-18, -26, 36, 22), dark)
			draw_rect(Rect2(-22, -30, 44, 4), metal)
			draw_line(Vector2(-16, -26), Vector2(-16, 0), metal, 3)
			draw_line(Vector2(16, -26), Vector2(16, 0), metal, 3)
