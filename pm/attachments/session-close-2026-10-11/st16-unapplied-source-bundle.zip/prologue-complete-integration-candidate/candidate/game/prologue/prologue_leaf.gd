class_name PrologueLeaf
extends Node
## One bool per WorldState key; no signals during restore/install.
var event: String
var completed := false


func _ready() -> void:
	add_to_group(WorldState.GROUP)


func state_key() -> String:
	return PrologueProgressPlan.PREFIX + event


func capture_state() -> bool:
	return completed


func restore_state(value: Variant) -> void:
	completed = typeof(value) == TYPE_BOOL and value
