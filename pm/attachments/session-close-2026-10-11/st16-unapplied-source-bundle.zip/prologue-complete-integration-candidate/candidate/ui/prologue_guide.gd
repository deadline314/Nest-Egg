class_name PrologueGuide
extends CanvasLayer
## Non-story confirmation. No wallet, rewards, flags, or scene completion.
var session: PrologueSession
var _goal: Label
var _notice: Label
var _skip: Button
var _retry: Button
var _dialog: PanelContainer
var _cancel: Button
var _confirm: Button
var _lock := 0
var _skip_choice := false
var _confirmed := false
var _confirmed_skip := false
var _optional_buttons: Array[Button] = []
var _paused_observed := false
var _hold: Timer
const GOALS := {
	"p01_information": "聽完門前的招呼",
	"move": "走到工作桌",
	"p02_information": "和老 K 談住宅目錄",
	"jump": "跳上搬貨台",
	"tools_taken": "取下試貨槍",
	"p03_information": "聽試貨說明",
	"shoot": "用試貨槍命中低靶",
	"p03_feedback": "核對試射結果",
	"gun_returned": "把試貨槍放回架上",
	"p04_information": "聽訓練器說明",
	"knife_taken": "取下試貨刀",
	"melee": "用刀命中軟靶",
	"guard": "開機後，面向桿子按 {block}",
	"dash": "開機後，按 {dash} 穿過燈線",
	"tools_returned": "把刀放回工具架",
	"p05_information": "和老 K 談復原規則",
	"p06_tape_returned": "把膠帶放回工作盒",
	"p06_latch_closed": "扣緊門扣",
	"p06_light_off": "關掉工作燈",
	"p06_contact": "聽鷺的聯絡",
	"confirm_exit": "吃完飯後，上屋頂找鷺"
}


func _ready() -> void:
	layer = UiLayers.HUD + 1
	process_mode = Node.PROCESS_MODE_ALWAYS
	var box := VBoxContainer.new()
	box.position = Vector2(12, 82)
	add_child(box)
	_goal = UiKit.label("", 11)
	box.add_child(_goal)
	_notice = UiKit.label("", 10)
	_notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_notice.custom_minimum_size.x = 230
	box.add_child(_notice)
	_skip = UiKit.button("略過序章…", confirm_exit.bind(true))
	box.add_child(_skip)
	_hold = Timer.new()
	_hold.one_shot = true
	_hold.wait_time = 0.6
	_hold.ignore_time_scale = true
	add_child(_hold)
	_hold.timeout.connect(confirm_exit.bind(true))
	_skip.button_down.connect(_hold.start)
	_skip.button_up.connect(_hold.stop)
	_retry = UiKit.button("重試保存", session.retry_pending)
	box.add_child(_retry)
	for pair: Array in [
		["跳躍射擊", &"jump_shot_practised"],
		["走動射擊", &"walk_shot_practised"],
		["砍後退開", &"melee_retreat_practised"],
		["格擋後砍靶", &"guard_melee_practised"],
		["衝刺後砍靶", &"dash_melee_practised"]
	]:
		var button := UiKit.button(pair[0], session.begin_optional.bind(pair[1]))
		_optional_buttons.append(button)
		box.add_child(button)
	_dialog = PanelContainer.new()
	_dialog.position = Vector2(130, 110)
	_dialog.custom_minimum_size = Vector2(370, 130)
	_dialog.theme = UiKit.theme()
	add_child(_dialog)
	var content := VBoxContainer.new()
	_dialog.add_child(content)
	content.add_child(UiKit.label("確認繼續到第一章？", 14))
	content.add_child(UiKit.label("略過只記出口，未練習項目保持未完成。", 11))
	_cancel = UiKit.button("返回", _close)
	_confirm = UiKit.button("確認繼續", _accept)
	content.add_child(_cancel)
	content.add_child(_confirm)
	_dialog.hide()
	session.progress_changed.connect(_refresh)
	InputBindings.bindings_changed.connect(_refresh)
	_refresh()


func _refresh() -> void:
	if not is_instance_valid(session):
		return
	_goal.text = InputBindings.format(str(GOALS.get(session.next_event(), "試完器材，回店吃飯")))
	for i in _optional_buttons.size():
		_optional_buttons[i].visible = (
			not session._presenting
			and (
				session._loan.is_borrowing(session.flow.pistol)
				if i < 2
				else session._loan.is_borrowing(session.flow.knife)
			)
		)
	_retry.visible = session._pending != null
	_skip.disabled = session._presenting or session._pending != null or not session.live()


func set_notice(text: String) -> void:
	_notice.text = text


func confirm_exit(skip: bool) -> void:
	if _lock != 0 or not session.live() or session._presenting or session._pending != null:
		return
	_skip_choice = skip
	_confirmed = false
	_lock = GameplayLock.acquire(self, Input.MOUSE_MODE_VISIBLE)
	_dialog.show()
	_cancel.grab_focus()


func _accept() -> void:
	# Only the real visible focused/clicked confirmation callback issues this latch.
	if _lock == 0 or not _dialog.visible or not session.live():
		return
	_confirmed = true
	_confirmed_skip = _skip_choice
	_close()
	session.confirm_exit(_confirmed_skip)
	_confirmed = false


func actual_confirmation(skip: bool) -> bool:
	return _confirmed and _confirmed_skip == skip and not _dialog.visible and _lock == 0


func _close() -> void:
	_dialog.hide()
	if _lock != 0:
		GameplayLock.release(_lock)
		_lock = 0
	_skip.grab_focus()


func _unhandled_input(event: InputEvent) -> void:
	if _dialog.visible and event.is_action_pressed(&"ui_cancel"):
		get_viewport().set_input_as_handled()
		_close()


func _exit_tree() -> void:
	if _lock != 0:
		GameplayLock.release(_lock)
	_lock = 0


func _process(_delta: float) -> void:
	# One small ALWAYS observer: actual PauseMenu uses tree.paused without GameplayLock.started.
	# No UI inventory, allocations, retained dead host, or per-frame font measurements.
	if not is_instance_valid(session):
		return
	var paused := get_tree().paused
	if paused and not _paused_observed:
		session.stop_machines()
	_paused_observed = paused
