class_name PrologueFlowData
extends Resource
## One source for real lessons, tool loans, map bindings and destinations.
@export var id: StringName = &"st16_prologue"
@export var story_path := "res://data/story/st16_prologue.json"
@export var first_scene: StringName = &"st16_p01_open"
@export var pistol: WeaponData
@export var knife: WeaponData
@export var destination := "res://data/levels/ch1_pawnshop.tres"
@export var station_dir := "res://data/prologue/stations/"
@export var section_scenes: Dictionary[StringName, PackedStringArray] = {}
@export var recovery_action: StringName = &"rin.training_recover"
@export var recovery_duration := 1.6


func validate() -> PackedStringArray:
	var result := PackedStringArray()
	if (
		id != &"st16_prologue"
		or story_path != "res://data/story/st16_prologue.json"
		or destination != PrologueProgressPlan.FIRST_CHAPTER
		or station_dir != "res://data/prologue/stations/"
	):
		result.append("ST16 flow source/destination does not match the published contract")
	if (
		pistol == null
		or pistol.resource_path != "res://data/weapons/pistol.tres"
		or pistol.is_melee()
	):
		result.append("ST16 missing canonical borrowed pistol")
	if (
		knife == null
		or knife.resource_path != "res://data/weapons/melee/melee_dagger.tres"
		or not knife.is_melee()
	):
		result.append("ST16 missing canonical borrowed knife")
	if (
		not is_finite(recovery_duration)
		or recovery_duration != 1.6
		or recovery_action != &"rin.training_recover"
	):
		result.append("ST16 recovery action contract changed")
	return result
