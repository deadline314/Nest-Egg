class_name PrologueStationData
extends Resource
## Formal map resource. IDs/geometry are checked by the Level-owned session.
enum Kind {
	TABLE,
	TOOLS,
	LOW_TARGET,
	GUN_RETURN,
	KNIFE,
	RUBBER_TARGET,
	GUARD,
	DASH,
	TOOLS_RETURN,
	SERVICE,
	TAPE,
	LATCH,
	LIGHT,
	EXIT,
	CATALOG,
	NOTEBOOK,
	OLD_K
}
@export var id: StringName
@export var kind: Kind
@export var prompt := ""
@export var scene: StringName
@export var interaction_radius := 40.0
@export var hit_size := Vector2(22, 28)
@export var lane_width := 96.0
@export var rig_id := ""
