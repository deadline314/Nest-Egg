#!/usr/bin/env python3
# ST16 only, deterministic stdlib generator. --root supports isolated CPU outputs.
from pathlib import Path
import argparse, hashlib, json, re
S=[('table',0,'a',32,19,'工作桌',''),('tools',1,'b',44,16,'取下試貨槍',''),('low_target',2,'c',57,19,'低靶',''),('gun_return',3,'d',52,19,'放回試貨槍',''),('knife',4,'e',66,19,'取下試貨刀',''),('rubber_target',5,'f',72,19,'軟靶',''),('guard',6,'g',77,19,'啟動慢速訓練器',''),('dash',7,'h',88,19,'啟動燈線訓練',''),('tools_return',8,'i',96,19,'歸還試貨刀',''),('service',9,'j',36,19,'閱讀復原服務單','st16_service'),('tape',10,'k',31,19,'收回膠帶',''),('latch',11,'l',14,19,'扣緊門扣',''),('light',12,'m',34,19,'關掉工作燈',''),('exit',13,'n',100,19,'繼續到第一章',''),('catalog',14,'o',26,19,'閱讀住宅目錄','st16_catalog'),('notebook',15,'p',28,19,'閱讀凜的手記','st16_notebook'),('old_k',16,'q',30,19,'和老 K 說話','')]
REQ=['p01_information','move','p02_information','jump','tools_taken','p03_information','shoot','p03_feedback','gun_returned','p04_information','knife_taken','melee','guard','dash','tools_returned','p05_information','p06_tape_returned','p06_latch_closed','p06_light_off','p06_contact']
GOALS=['聽完門前的招呼','走到工作桌','和老 K 談住宅目錄','跳上搬貨台','取下試貨槍','聽試貨說明','用試貨槍命中低靶','核對試射結果','把試貨槍放回架上','聽訓練器說明','取下試貨刀','用刀命中軟靶','面向桿子格擋','衝刺穿過燈線','把刀放回工具架','和老 K 談復原規則','把膠帶放回工作盒','扣緊門扣','關掉工作燈','聽鷺的聯絡']
SPEAKERS={'公共錄音':'st16_recording','老 K':'old_k','凜':'rin','鷺':'egret','晴岸住宅目錄':'st16_document','凜的手記':'st16_document'}
def put(root,path,text):
 p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8')
def words(text):
 who,sep,body=text.partition('：')
 if not sep:who='st16_document';body=text
 speaker=SPEAKERS.get(who,who);result=[]
 while len(body)>29:
  end=max((i+1 for i,ch in enumerate(body[:29]) if ch in '，。、；！？'),default=29)
  result.append({'speaker':speaker,'text':body[:end]});body=body[end:]
 if body:result.append({'speaker':speaker,'text':body})
 return result

def build(root):
 p=root/'design/13-story-v2/PROLOGUE_SCRIPT.md';text=p.read_text(encoding='utf-8');sections={}
 for m in re.finditer(r'^## (P0[1-6])｜[^\n]*\n(.*?)(?=^## |\Z)',text,re.M|re.S):sections[m[1]]=[s.removeprefix('> ').strip() for s in m[2].splitlines() if s.startswith('> ')]
 assert [len(sections[k]) for k in sections]==[6,9,6,9,14,6]
 scenes={};seq={}
 def group(key,mode,texts,duration=None):
  lines=[line for t in texts for line in words(t)];maxlines=2 if mode=='radio' else (6 if mode=='cinematic' else 8);seq[key]=[]
  for i in range(0,len(lines),maxlines):
   sid=key if i==0 else key+'_'+str(i//maxlines+1);scenes[sid]={'mode':mode,'lines':lines[i:i+maxlines]};seq[key].append(sid)
   if duration:scenes[sid]['duration']=duration
 group('st16_p01_open','cinematic',sections['P01'][:2],8.0);group('st16_p01_after','radio',sections['P01'][2:]);seq['st16_p01_open']+=seq['st16_p01_after']
 group('st16_p02_info','dialogue',sections['P02'][:7]);group('st16_catalog','dialogue',[sections['P02'][7]]);group('st16_notebook','dialogue',[sections['P02'][8]])
 group('st16_p03_info','radio',sections['P03'][:3]);group('st16_p03_feedback','radio',sections['P03'][3:]);group('st16_p04_info','radio',sections['P04'][:4]);group('st16_p04_recovery','dialogue',sections['P04'][4:7]);group('st16_p04_wrap','dialogue',sections['P04'][7:])
 group('st16_service','dialogue',sections['P05'][:4]);group('st16_p05_info_fall','dialogue',sections['P05'][4:12]);group('st16_p05_info_clear','dialogue',sections['P05'][4:10]+sections['P05'][12:])
 for key in ['st16_p05_info_fall','st16_p05_info_clear']:seq[key]=seq['st16_p04_wrap']+seq[key]
 group('st16_p06_contact','radio',sections['P06'])
 sha=hashlib.sha256(p.read_bytes()).hexdigest();cells={s[0]:[s[3],s[4]] for s in S}
 q={'id':'st16_try_tools','kind':'main','title':'試完器材，回店吃飯','background':'替老 K 核對剛收來的器材，再收工具、關工作燈。','reward':'工具只是借用，沒有金錢或正式武器獎勵。','visible_condition':{},'active_condition':{},'blocked_reason':'先完成目前這項操作。','suggestion':'可返回重試，或確認略過序章。','complete_condition':{'flag':'st16.training.exited','equals':True},'steps':[]}
 targets=['latch','table','old_k','tools','tools','low_target','low_target','low_target','gun_return','knife','knife','rubber_target','guard','dash','tools_return','old_k','tape','latch','light','light']
 for event,title,station in zip(REQ,GOALS,targets):q['steps'].append({'title':title,'complete_condition':{'flag':'st16.training.'+event,'equals':True},'target_kind':'map','binding':'st16_'+station,'location':{'level':'res://data/levels/st16_pawnshop_training.tres','cell':cells[station]}})
 q['steps'].append({'title':'確認繼續到第一章','complete_condition':q['complete_condition'],'target_kind':'map','binding':'st16_exit','location':{'level':'res://data/levels/st16_pawnshop_training.tres','cell':cells['exit']}})
 j={'chapter':{'id':'st16_prologue','title':'序章　雨裡的燈','subtitle':'沉港市・巢蛋當舖'},'speakers':{'st16_recording':{'name':'公共錄音','color':'#9ad7ff','portrait':'res://art/portraits/system.png'},'st16_document':{'name':'紙本','color':'#ded5b0','portrait':'res://art/portraits/system.png'}},'scenes':scenes,'quests':[q],'authored_source':{'path':'design/13-story-v2/PROLOGUE_SCRIPT.md','sha256':sha}}
 put(root,'data/story/st16_prologue.json',json.dumps(j,ensure_ascii=False,indent=2)+'\n')
 for sid,kind,glyph,x,y,prompt,scene in S:
  put(root,f'data/prologue/stations/{sid}.tres',f'[gd_resource type="Resource" script_class="PrologueStationData" load_steps=2 format=3]\n[ext_resource type="Script" path="res://data/scripts/prologue_station_data.gd" id="1"]\n[resource]\nscript = ExtResource("1")\nid = &"{sid}"\nkind = {kind}\nprompt = "{{interact}} {prompt}"\nscene = &"{scene}"\n')
 flow='[gd_resource type="Resource" script_class="PrologueFlowData" load_steps=4 format=3]\n[ext_resource type="Script" path="res://data/scripts/prologue_flow_data.gd" id="1"]\n[ext_resource type="Resource" path="res://data/weapons/pistol.tres" id="2"]\n[ext_resource type="Resource" path="res://data/weapons/melee/melee_dagger.tres" id="3"]\n[resource]\nscript = ExtResource("1")\npistol = ExtResource("2")\nknife = ExtResource("3")\nsection_scenes = Dictionary[StringName, PackedStringArray]({\n'+',\n'.join('&"'+key+'": PackedStringArray('+', '.join(json.dumps(v) for v in values)+')' for key,values in seq.items())+'\n})\n'
 put(root,'data/prologue/st16_flow.tres',flow)
 w,h=112,24;rows=[list('.'*w) for _ in range(h)]
 for y in range(h):rows[y][0]=rows[y][-1]='#'
 for y in range(20,h):rows[y]=list('#'*w)
 for y in range(10):
  for x in range(14,w):rows[y][x]='#'
 for x in range(42,47):rows[17][x]='='
 for x,y in [(40,19),(41,18),(47,18),(48,19)]:rows[y][x]='#'
 rows[19][10]='P'
 for sid,kind,glyph,x,y,prompt,scene in S:assert rows[y][x]=='.';rows[y][x]=glyph
 put(root,'data/levels/st16_pawnshop_training.json',json.dumps({'segments':[[''.join(row) for row in rows]],'props':[]},ensure_ascii=False,indent=2)+'\n')
 resources=['[ext_resource type="Script" path="res://data/scripts/level_data.gd" id="level"]','[ext_resource type="Resource" path="res://data/prologue/st16_flow.tres" id="flow"]','[ext_resource type="Resource" path="res://data/environment/themes/ch1_pawnshop.tres" id="env"]','[ext_resource type="Script" path="res://data/scripts/lighting_zone.gd" id="zone"]','[ext_resource type="Resource" path="res://data/lighting/rooftop.tres" id="rain"]','[ext_resource type="Resource" path="res://data/lighting/pawnshop_warm.tres" id="warm"]']+[f'[ext_resource type="Resource" path="res://data/prologue/stations/{sid}.tres" id="{sid}"]' for sid,*_ in S]
 level=f'[gd_resource type="Resource" script_class="LevelData" load_steps={len(resources)+3} format=3]\n'+'\n'.join(resources)+'\n'
 level+='[sub_resource type="Resource" id="outside"]\nscript = ExtResource("zone")\nstart_tile = 0\nblend_tiles = 2\nprofile = ExtResource("rain")\n[sub_resource type="Resource" id="inside"]\nscript = ExtResource("zone")\nstart_tile = 14\nblend_tiles = 4\nprofile = ExtResource("warm")\n[resource]\nscript = ExtResource("level")\nid = &"st16_pawnshop_training"\ndisplay_name = "巢蛋當舖・試貨"\nheight = 24\nchapter = &"st16_prologue"\npersistent_world = true\nshow_chapter_card = false\nannounce_area = false\nrain = true\nprologue_flow = ExtResource("flow")\nenvironment = ExtResource("env")\nlighting_zones = Array[LightingZone]([SubResource("outside"), SubResource("inside")])\nlayout_path = "res://data/levels/st16_pawnshop_training.json"\nlegend = Dictionary[String, Resource]({\n'+',\n'.join(f'"{glyph}": ExtResource("{sid}")' for sid,kind,glyph,x,y,prompt,scene in S)+'\n})\n'
 put(root,'data/levels/st16_pawnshop_training.tres',level)
 put(root,'data/prologue/source_bindings.json',json.dumps({'source_sha256':sha,'bindings':{sid:{'path':f'res://data/prologue/stations/{sid}.tres','cell':[x,y],'kind':kind,'glyph':glyph} for sid,kind,glyph,x,y,prompt,scene in S},'section_scenes':seq},ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2]);build(p.parse_args().root.resolve())
