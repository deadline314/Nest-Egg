class_name StoryRuntimeFacts
extends RefCounted
## 唯讀條件事實與 runtime provenance；不寫 GameState/Progression/StoryItems。
## Main 真 read/apply/new-run/retry 工廠持有此物件；作者資料不得建立 receipt。
const KEYS := ["ch1_true_death_record_known", "ch1_zero_true_deaths", "ch1_booth_registered", "ch1_booth_restoration_done", "ch1_first_clinic_active", "st16.training.p01_information", "st16.training.move", "st16.training.p02_information", "st16.training.jump", "st16.training.tools_taken", "st16.training.p03_information", "st16.training.shoot", "st16.training.p03_feedback", "st16.training.gun_returned", "st16.training.p04_information", "st16.training.knife_taken", "st16.training.melee", "st16.training.guard", "st16.training.dash", "st16.training.tools_returned", "st16.training.p05_information", "st16.training.p06_tape_returned", "st16.training.p06_latch_closed", "st16.training.p06_light_off", "st16.training.p06_contact", "st16.training.catalog_read", "st16.training.notebook_read", "st16.training.service_document_read", "st16.training.training_fall_shown", "st16.training.jump_shot_practised", "st16.training.walk_shot_practised", "st16.training.melee_retreat_practised", "st16.training.guard_melee_practised", "st16.training.dash_melee_practised", "st16.training.exited", "st16.training.skipped"]
static var _provider: Callable
var _main: WeakRef
var _death_record_known := false
var _count_known := false
var _booth_restored := false
var _retry: RetryReceipt

class RetryReceipt extends RefCounted:
	var main: WeakRef
	var old_level: WeakRef
	var new_level: WeakRef
	var checkpoint_path: String
	var deaths: int
	var ordinary := false
	var used := false

func configure(main: Node) -> void:
	_main = weakref(main)

static func bind_provider(provider: Callable) -> void:
	_provider = provider

static func unknown() -> Dictionary:
	var result := {}
	for key: String in KEYS:
		result[key] = false
	return result

static func persistable_flags(raw: Dictionary) -> Dictionary:
	var result := raw.duplicate(true)
	for key: String in KEYS:
		result.erase(key)
	return result

static func current() -> Dictionary:
	if not _provider.is_valid():
		return unknown()
	var raw: Variant = _provider.call()
	if not raw is Dictionary or raw.size() != KEYS.size():
		return unknown()
	for key: String in KEYS:
		if not raw.get(key) is bool:
			return unknown()
	return raw.duplicate(true)

## Main calls after its actual GameState.new_run reset; no persisted flag grants known.
func begin_new_run() -> void:
	_count_known = GameState.deaths == 0
	_death_record_known = _count_known
	_booth_restored = false
	_retry = null

## raw is the successfully decoded file BEFORE RunSnapshot fills missing defaults.
## canonical is the exact successful validator result Main will apply.
## A missing old death count remains unknown even when normalization supplies zero.
func adopt_read(raw: Dictionary, canonical: Dictionary) -> void:
	_death_record_known = false
	_count_known = false
	_booth_restored = false
	_retry = null
	var state: Variant = raw.get("state")
	var actual: Variant = canonical.get("state")
	if raw.get("version") != RunSaveCodec.VERSION or raw.get("release") != "demo-0.1" \
			or not state is Dictionary or not actual is Dictionary:
		return
	var count: Variant = state.get("deaths")
	_count_known = StoryTransactionData.integer_in(count, 0, 1000000) and actual.get("deaths") == int(count)
	_death_record_known = _count_known and int(count) == 0
	# Booth completion has no canonical persisted event record in the current source.
	# Do not infer it from checkpoint registration, count, first_death_done or a flag.

## Before an actual retry swap, Main supplies both real Levels. This only records
## the event provenance; the fact becomes true after new player/checkpoint restore.
func begin_retry(old_level: Level, new_level: Level) -> void:
	_retry = null
	var main: Variant = _main.get_ref() if _main != null else null
	if not is_instance_valid(main) or main._screen != old_level or not is_instance_valid(old_level) \
			or not old_level.is_inside_tree() or not old_level.died or not is_instance_valid(old_level.player) \
			or not old_level.player.is_dead() or not is_instance_valid(new_level) or new_level.is_inside_tree() \
			or not GameState.has_checkpoint or GameState.checkpoint_level_path.is_empty() \
			or not is_instance_valid(new_level.data) or new_level.data.resource_path != GameState.checkpoint_level_path:
		return
	var receipt := RetryReceipt.new()
	receipt.main = weakref(main)
	receipt.old_level = weakref(old_level)
	receipt.new_level = weakref(new_level)
	receipt.checkpoint_path = GameState.checkpoint_level_path
	receipt.deaths = GameState.deaths
	receipt.ordinary = old_level._death_entry.is_empty()
	_retry = receipt

## Main invokes after _swap_screen add_child / ready, before first publication.
func complete_retry(level: Level) -> bool:
	var receipt := _retry
	_retry = null
	if receipt == null or receipt.used:
		return false
	receipt.used = true
	var main: Variant = receipt.main.get_ref()
	if not is_instance_valid(main) or main._screen != level or receipt.new_level.get_ref() != level \
			or not is_instance_valid(level) or not level.is_inside_tree() or level.is_queued_for_deletion() \
			or level.died or not is_instance_valid(level.player) or level.player.is_dead() \
			or not level._from_checkpoint or level.data.resource_path != receipt.checkpoint_path \
			or not GameState.has_checkpoint or GameState.checkpoint_level_path != receipt.checkpoint_path \
			or GameState.deaths != receipt.deaths or not receipt.ordinary:
		return false
	_booth_restored = true
	_death_record_known = _count_known
	return true

func observe_clinic_entry(level: Level, witness: StoryRunSource.EntryWitness) -> void:
	if witness == null or witness.used or witness.kind != &"clinic" or witness.level.get_ref() != level \
			or not is_instance_valid(level) or witness.layout != level._layout or witness.resource != level.data \
			or not level.died or not is_instance_valid(level.player) or not level.player.is_dead() \
			or GameState.deaths != 1 or level._death_entry.get("scene") != "ch1_c09_wake":
		return
	_death_record_known = _count_known

func snapshot() -> Dictionary:
	var result := unknown()
	var main: Variant = _main.get_ref() if _main != null else null
	if not is_instance_valid(main) or not main._active_run or not is_instance_valid(main._screen) or not main._screen is Level:
		return result
	var level := main._screen as Level
	if not level.is_inside_tree() or level.is_queued_for_deletion() or not is_instance_valid(level.data) \
			or level.data.resource_path != main._level_path:
		return result
	result["ch1_true_death_record_known"] = _death_record_known
	result["ch1_zero_true_deaths"] = _death_record_known and GameState.deaths == 0
	result["ch1_booth_registered"] = GameState.has_checkpoint and not GameState.checkpoint_level_path.is_empty() \
		and ResourceLoader.exists(GameState.checkpoint_level_path)
	result["ch1_booth_restoration_done"] = _death_record_known and _booth_restored
	# A live dead body + actual death entry are necessary, but a pending/active
	# Main-issued clinic witness is also required. Memory replay context is not proof.
	if not level.died or not is_instance_valid(level.player) or not level.player.is_dead() \
			or GameState.deaths != 1 or level.data.chapter != &"ch1_kasa" \
			or level._death_entry.get("scene") != "ch1_c09_wake":
		return result
	var pending: Variant = main._story_entry
	if pending is StoryRunSource.EntryWitness and pending.kind == &"clinic" and not pending.used \
			and pending.level.get_ref() == level and pending.layout == level._layout and pending.resource == level.data:
		result["ch1_first_clinic_active"] = true
		return result
	for source: RefCounted in main._story_port._sources.values():
		if source is StoryRunSource.Source and source.level.get_ref() == level \
				and Story.is_atomic_request(source.request) and source.context == Story.request_presentation_context(source.request) \
				and main._story_sources.is_actual_clinic(source):
			result["ch1_first_clinic_active"] = true
			break
	return result
