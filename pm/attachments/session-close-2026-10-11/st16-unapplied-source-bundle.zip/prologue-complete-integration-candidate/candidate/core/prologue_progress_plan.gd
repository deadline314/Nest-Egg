class_name PrologueProgressPlan
extends RefCounted
## Pure, bounded proposal only. Actual Level-owned producers authenticate events.
## No Story/GameState/Input/Health/wallet/equipment/save access or side effects.
const LEVEL := "res://data/levels/st16_pawnshop_training.tres"
const FIRST_CHAPTER := "res://data/levels/ch1_pawnshop.tres"
const PREFIX := "st16.training."
const REQUIRED := [
	"p01_information",
	"move",
	"p02_information",
	"jump",
	"tools_taken",
	"p03_information",
	"shoot",
	"p03_feedback",
	"gun_returned",
	"p04_information",
	"knife_taken",
	"melee",
	"guard",
	"dash",
	"tools_returned",
	"p05_information",
	"p06_tape_returned",
	"p06_latch_closed",
	"p06_light_off",
	"p06_contact"
]
const OPTIONAL := [
	"catalog_read",
	"notebook_read",
	"service_document_read",
	"training_fall_shown",
	"jump_shot_practised",
	"walk_shot_practised",
	"melee_retreat_practised",
	"guard_melee_practised",
	"dash_melee_practised"
]
const PREREQUISITES := {
	"p01_information": [],
	"move": ["p01_information"],
	"p02_information": ["move"],
	"jump": ["p02_information"],
	"tools_taken": ["jump"],
	"p03_information": ["tools_taken"],
	"shoot": ["p03_information"],
	"p03_feedback": ["shoot"],
	"gun_returned": ["p03_feedback"],
	"p04_information": ["gun_returned"],
	"knife_taken": ["p04_information"],
	"melee": ["knife_taken"],
	"guard": ["melee"],
	"dash": ["guard"],
	"tools_returned": ["dash"],
	"p05_information": ["tools_returned"],
	"p06_tape_returned": ["p05_information"],
	"p06_latch_closed": ["p05_information"],
	"p06_light_off": ["p05_information"],
	"p06_contact": ["p06_tape_returned", "p06_latch_closed", "p06_light_off"]
}
const TERMINAL := ["exited", "skipped"]


static func _error(message: String) -> Dictionary:
	return {"error": "PrologueProgressPlan: " + message}


## Each saved WorldState leaf is one bool, compatible with RunSnapshot._world.
## Caller must validate raw types before general RunSnapshot bool normalization.
static func prepare_world(raw: Dictionary) -> Dictionary:
	var world := {}
	for key: Variant in raw:
		if typeof(key) not in [TYPE_STRING, TYPE_STRING_NAME]:
			return _error("world key must be text")
		if String(key).begins_with(PREFIX):
			var name := String(key).trim_prefix(PREFIX)
			if not name in REQUIRED and not name in OPTIONAL and not name in TERMINAL:
				return _error("unknown lesson leaf: " + name)
			if not raw[key] is bool:
				return _error("lesson leaf must be bool: " + name)
	for name: String in REQUIRED + OPTIONAL + TERMINAL:
		world[PREFIX + name] = raw.get(PREFIX + name, false)
	for name: String in REQUIRED:
		if world[PREFIX + name]:
			for prior: String in PREREQUISITES[name]:
				if not world[PREFIX + prior]:
					return _error("lesson predecessor missing: " + prior + " -> " + name)
	if world[PREFIX + "skipped"] and not world[PREFIX + "exited"]:
		return _error("skip requires the same committed exit")
	if world[PREFIX + "exited"] and not world[PREFIX + "skipped"]:
		for name: String in REQUIRED:
			if not world[PREFIX + name]:
				return _error("normal exit missing actual lesson: " + name)
	return {"world": world}


## Event vocabulary is not authority: Main must verify the real Level/session
## lease and actual producer. This function only plans the proposed bool patch.
static func propose_observed(raw: Dictionary, event: StringName) -> Dictionary:
	var prepared := prepare_world(raw)
	if prepared.has("error"):
		return prepared
	var name := String(event)
	if not name in REQUIRED and not name in OPTIONAL:
		return _error("event is not a supported observed fact")
	var world: Dictionary = prepared["world"]
	if world[PREFIX + "exited"]:
		return _error("closed lesson owner")
	if name in REQUIRED:
		for prior: String in PREREQUISITES[name]:
			if not world[PREFIX + prior]:
				return _error("event before actual predecessor: " + name)
	if world[PREFIX + name]:
		return {"changed": false, "world": world, "patch": {}}
	world[PREFIX + name] = true
	return {"changed": true, "world": world, "patch": {PREFIX + name: true}}


## trusted_skip_confirmed comes only from this actual Level's confirmation UI;
## root's port still authenticates owner + confirmation and performs durable write.
## Returned candidate never installs any leaf, owner or destination by itself.
static func propose_exit(raw: Dictionary, trusted_skip_confirmed: bool) -> Dictionary:
	var prepared := prepare_world(raw)
	if prepared.has("error"):
		return prepared
	var world: Dictionary = prepared["world"]
	if world[PREFIX + "exited"]:
		return _error("exit already committed")
	if not trusted_skip_confirmed:
		for name: String in REQUIRED:
			if not world[PREFIX + name]:
				return _error("normal exit requires actual event: " + name)
	world[PREFIX + "exited"] = true
	world[PREFIX + "skipped"] = trusted_skip_confirmed
	return {
		"world": world,
		"patch": {PREFIX + "exited": true, PREFIX + "skipped": trusted_skip_confirmed},
		"level": FIRST_CHAPTER,
		"chapter_complete": false,
		"required_target_binding": "dinner",
		"requires_actual_source_and_durable_commit": true
	}


static func next_required(raw: Dictionary) -> Dictionary:
	var prepared := prepare_world(raw)
	if prepared.has("error"):
		return prepared
	var world: Dictionary = prepared["world"]
	if world[PREFIX + "exited"]:
		return {"event": "", "exited": true}
	for name: String in REQUIRED:
		if not world[PREFIX + name]:
			return {"event": name, "exited": false}
	return {"event": "confirm_exit", "exited": false}
