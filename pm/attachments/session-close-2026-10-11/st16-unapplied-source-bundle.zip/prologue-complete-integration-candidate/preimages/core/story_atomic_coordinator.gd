class_name StoryAtomicCoordinator
extends RefCounted
## Trusted Main supplies the port. Author JSON never supplies callbacks or owner tokens.
## No service mutation, writer, ledger, wallet, or world implementation lives here.

const POLICY := "atomic_v1"
const MAX_OPTIONS := 8
const MAX_ROUTES := 64
const MAX_CHAIN := 64
const NATIVE_STEPS := ["scene", "letterbox", "camera", "actor", "pose", "move", "face", "remove", "say", "narrate", "title", "fx", "sfx", "wait", "fade", "transition", "end"]

class Capture extends RefCounted:
	var valid := false
	var status := "unbound_port"
	var message := "正式故事保存入口尚未接妥。"
	var projection: Dictionary = {}
	var registry: Dictionary = {}
	var runtime_facts: Dictionary = {}
	## Main-owned lease: persistent Level identity, generation, full snapshot/source proof.
	var lease: RefCounted
	var exclusive_scene_producers := false

class PreparedCommit extends RefCounted:
	var valid := false
	var status := "unprepared"
	var message := "故事結果尚未完成準備。"
	## Opaque typed owner/world/save preparation held by the real Main implementation.
	var owner_preparation: RefCounted
	var record: Dictionary = {}

class CommitOutcome extends RefCounted:
	var committed := false
	var installed := false
	var status := "unbound_port"
	var message := "正式故事保存入口尚未接妥。"

class CommitPort extends RefCounted:
	func is_busy() -> bool:
		return false

	## Root publishes only capabilities backed by real integrated phase evidence.
	## Class presence, producer_requests JSON, and TracePort are not capability proof.
	func readiness() -> Dictionary:
		return {"capabilities": [], "phase_evidence": []}

	## Acquire producer/lifecycle scope BEFORE Level.run_snapshot(), then capture all owners.
	## Return a lease even on rejection if a scope was acquired; release must be idempotent.
	func capture(_request: int, _scene_id: StringName, _operation: StringName) -> Capture:
		return Capture.new()

	## All fallible work BEFORE writing: canonical producer+choice proof, four owners,
	## Level world authority/rebind, Main cinematic metadata, continuation, save encoding.
	## The decision plan has NO completion event/history and only loaded reversible flags.
	func prepare(_capture: Capture, _plan: Dictionary, _continuation: StringName,
			_operation: StringName, _option_id: StringName) -> PreparedCommit:
		return PreparedCommit.new()

	## Durable-first; committed implies all prevalidated assignments installed synchronously.
	## No callbacks/await/late validator. Never return committed=false after commit point.
	func commit_and_install(_prepared: PreparedCommit) -> CommitOutcome:
		return CommitOutcome.new()

	## Only after all owners/world/Main installed. Producer scope remains held throughout.
	func publish(_prepared: PreparedCommit) -> void:
		pass

	## Re-capture/save dirty changes from synchronous listeners BEFORE releasing scope.
	## Actual buffered Main lifecycle actions must run only after this lease is released.
	func release(_capture: Capture) -> void:
		pass

var port: CommitPort
var _busy := false
var _active_capture: Capture
var _active_prepared: PreparedCommit


func is_busy() -> bool:
	return _busy


static func is_formal(scene: Dictionary) -> bool:
	return scene.get("results_policy", "") == POLICY


static func validate_scene(scene: Dictionary) -> Dictionary:
	if not is_formal(scene):
		return _fail("wrong_policy", "不是正式結果段。")
	if scene.get("completion_policy", "once") not in ["once", "repeatable_presentation", "reversible_intent"]:
		return _fail("unknown_completion_policy", "未登記的正式完成政策。")
	var errors := RunSaveCodec.validate_tree(scene, 32768)
	if not errors.is_empty():
		return _fail("invalid_scene", errors[0])
	if str(scene.get("mode", "")) == "dispatch":
		var routes: Variant = scene.get("routes")
		if not routes is Array or routes.is_empty() or routes.size() > MAX_ROUTES:
			return _fail("invalid_dispatch", "入口條件清單無效。")
		for route: Variant in routes:
			if not route is Dictionary or route.size() != 2 or not route.has("condition") or not route.get("target") is String or not StoryTransactionData.valid_id(route["target"]):
				return _fail("invalid_dispatch", "入口的條件或目標無效。")
			if not StoryConditionTree.validate(route["condition"])["valid"]:
				return _fail("invalid_dispatch", "入口條件不符合正式合約。")
		return {"valid": true}
	if str(scene.get("mode", "")) not in ["cinematic", "dialogue", "animated", "radio", "bubbles"]:
		return _fail("unsupported_mode", "正式結果演出模式未登記。")
	if not scene.get("results") is Array or scene["results"].size() > StoryResultPlan.MAX_RESULTS:
		return _fail("invalid_results", "正式結果清單無效。")
	if not scene.get("options", []) is Array or scene.get("options", []).size() > MAX_OPTIONS:
		return _fail("invalid_options", "選項清單無效。")
	var legacy_flags: Variant = scene.get("set_flags", [])
	if not (legacy_flags is Array or legacy_flags is Dictionary) or not legacy_flags.is_empty():
		return _fail("legacy_result_collision", "正式段不能同時使用舊完成旗標。")
	if not StoryConditionTree.validate(scene.get("condition", {}))["valid"]:
		return _fail("invalid_condition", "開始條件無效。")
	var steps: Variant = scene.get("steps", [])
	if not steps is Array or steps.size() > 1024:
		return _fail("invalid_steps", "演出步驟無效。")
	for step: Variant in steps:
		if not step is Dictionary or str(step.get("do", "")) not in NATIVE_STEPS:
			return _fail("legacy_choice_collision", "正式選擇只能由結果入口處理。")
	var ids: Dictionary = {}
	for option: Variant in scene.get("options", []):
		if not option is Dictionary or not option.get("id") is String or not StoryTransactionData.valid_id(option["id"]) or ids.has(option["id"]):
			return _fail("invalid_options", "選項識別碼無效或重複。")
		ids[option["id"]] = true
		if not option.get("text") is String or option["text"].is_empty() or option["text"].length() > 512:
			return _fail("invalid_options", "選項文字無效。")
		if not option.get("target", "") is String or (not option.get("target", "").is_empty() and not StoryTransactionData.valid_id(option["target"])):
			return _fail("invalid_options", "選項目標無效。")
		if not StoryConditionTree.validate(option.get("condition", {}))["valid"]:
			return _fail("invalid_options", "選項條件無效。")
		if not option.get("intent", []) is Array or option.get("intent", []).size() > 16:
			return _fail("invalid_intent", "選擇意圖必須是有界旗標清單。")
		for op: Variant in option.get("intent", []):
			if not op is Dictionary or op.size() != 3 or op.get("kind") != "flag" or not op.get("id") is String or not StoryTransactionData.valid_id(op["id"]) or not op.has("value"):
				return _fail("invalid_intent", "選擇不能直接付款、領物或移交道具。")
	if not scene.get("options", []).is_empty() and not scene["results"].is_empty():
		return _fail("mixed_decision_results", "選擇意圖與不可逆完成結果必須分段。")
	if str(scene.get("mode", "")) in ["radio", "bubbles"] and not scene.get("options", []).is_empty():
		return _fail("passive_decision", "必須確認的選擇不可由廣播或氣泡自動回答。")
	if scene.get("completion_policy", "once") == "repeatable_presentation" and (not scene["results"].is_empty() or not scene.get("options", []).is_empty()):
		return _fail("repeatable_results", "可重訪演出不能帶完成獎勵。")
	if scene.get("completion_policy", "once") == "reversible_intent":
		if not scene.get("options", []).is_empty() or scene["results"].is_empty():
			return _fail("invalid_intent_policy", "意圖返回段只能有可逆旗標。")
		for op: Variant in scene["results"]:
			if not op is Dictionary or op.size() != 3 or op.get("kind") != "flag" or not op.get("id") is String or not op.has("value"):
				return _fail("invalid_intent_policy", "可逆政策不能重發款項或道具。")
	return {"valid": true}


static func _fail(status: String, message: String) -> Dictionary:
	return {"valid": false, "status": status, "message": message.left(512)}


func _open(request: int, id: StringName, operation: StringName) -> Capture:
	if _busy or port == null:
		return null
	_busy = true
	_active_capture = port.capture(request, id, operation)
	if _active_capture == null:
		_active_capture = Capture.new()
	return _active_capture


func close() -> void:
	if not _busy:
		return
	var capture := _active_capture
	_active_prepared = null
	_active_capture = null
	# Keep busy through release: listeners/lifecycle flush must not re-enter Story.
	if port != null:
		port.release(capture)
	_busy = false


static func _facts(capture: Capture) -> Dictionary:
	var items: Dictionary = {}
	for id: Variant in capture.registry.get("item_definitions", {}):
		items[String(id)] = false
	for id: Variant in capture.projection.get("items", {}).get("held", []):
		items[String(id)] = true
	var flags: Dictionary = capture.registry.get("flag_defaults", {}).duplicate(true)
	flags.merge(capture.projection.get("flags", {}), true)
	return {"flags": flags, "items": items, "ledger": capture.projection.get("ledger", {})}


static func _condition(raw: Variant, capture: Capture) -> Dictionary:
	return StoryConditionTree.evaluate(raw, _facts(capture), {
		"ledger_locked": capture.registry.get("ledger_locked", true),
		"transaction_definitions": capture.registry.get("transaction_definitions", {}), "facts": capture.runtime_facts})


func admit(id: StringName, scene: Dictionary, request: int) -> Dictionary:
	var checked := validate_scene(scene)
	if not checked["valid"]:
		return checked
	var capture := _open(request, id, &"admit")
	if capture == null:
		return _fail("busy_or_unbound", "故事保存入口忙碌或尚未接妥。")
	var result := _capture_check(capture)
	if result["valid"]:
		result = _registered_scene(id, scene, capture)
	if result["valid"]:
		result = _condition(scene.get("condition", {}), capture)
		if result["valid"] and not result["value"]:
			result = _fail("condition_unmet", "目前尚未符合這段故事的條件。")
	close()
	return result


static func _capture_check(capture: Capture) -> Dictionary:
	if not capture.valid:
		return _fail(capture.status, capture.message)
	if capture.lease == null or not capture.exclusive_scene_producers:
		return _fail("producer_boundary_unbound", "世界、保存或舊獎勵入口尚未完成互斥接線。")
	for tree: Dictionary in [capture.projection, capture.registry]:
		var errors := RunSaveCodec.validate_tree(tree, 32768)
		if not errors.is_empty():
			return _fail("invalid_capture", errors[0])
	for key: String in ["flags", "items", "ledger", "area_states"]:
		if not capture.projection.get(key) is Dictionary:
			return _fail("invalid_capture", "缺少完整服務投影：" + key)
	if not capture.projection.get("completed") is Array or not capture.projection["items"].get("held") is Array:
		return _fail("invalid_capture", "完成史或持有狀態無效。")
	for key: String in ["flag_defaults", "transaction_definitions", "scenes", "producers", "item_definitions"]:
		if not capture.registry.get(key) is Dictionary:
			return _fail("invalid_capture", "缺少可信來源登記：" + key)
	if capture.registry.get("replay", true) != false:
		return _fail("replay_forbidden", "記憶回播不能產生正式結果。")
	var ledger := StoryConditionTree.verify_ledger(_facts(capture), {
		"ledger_locked": capture.registry.get("ledger_locked", true),
		"transaction_definitions": capture.registry["transaction_definitions"], "facts": capture.runtime_facts})
	if not ledger["valid"]:
		return _fail("invalid_ledger", ledger["error"])
	return {"valid": true}


static func _registered_scene(id: StringName, scene: Dictionary, capture: Capture) -> Dictionary:
	if str(capture.registry.get("scene_id", "")) != String(id):
		return _fail("invalid_registry", "正式來源識別碼與目前段落不符。")
	var registered: Variant = capture.registry["scenes"].get(String(id))
	if not registered is Dictionary or registered.get("condition") != scene.get("condition", {}) or registered.get("results") != scene.get("results", []):
		return _fail("unregistered_results", "載入段落與可信結果登記不一致。")
	if scene.get("completion_policy", "once") in ["repeatable_presentation", "reversible_intent"] and registered.get("once", true) != false:
		return _fail("invalid_repeatable_contract", "重訪段未登記為無獎勵演出。")
	return {"valid": true}


func dispatch(id: StringName, scene: Dictionary) -> Dictionary:
	var checked := validate_scene(scene)
	if not checked["valid"]:
		return checked
	var capture := _open(0, id, &"dispatch")
	if capture == null:
		return _fail("busy_or_unbound", "入口暫時無法讀取正式狀態。")
	var result := _capture_check(capture)
	if result["valid"]:
		result = _registered_scene(id, scene, capture)
	var target := ""
	if result["valid"]:
		for route: Dictionary in scene.get("routes", []):
			var matched := _condition(route["condition"], capture)
			if not matched["valid"]:
				result = _fail("invalid_dispatch", matched["error"])
				break
			if matched["value"]:
				if not target.is_empty():
					result = _fail("ambiguous_dispatch", "入口條件重疊，保留進度並拒絕任選一段。")
					break
				target = route["target"]
		if result["valid"]:
			result = {"valid": true, "target": target} if not target.is_empty() else _fail("no_matching_route", "目前沒有可用的對話分拍。")
	close()
	return result


func available_options(id: StringName, scene: Dictionary, request: int) -> Dictionary:
	var checked := validate_scene(scene)
	if not checked["valid"]:
		return checked
	var capture := _open(request, id, &"options")
	if capture == null:
		return _fail("busy_or_unbound", "選擇入口暫時忙碌。")
	var result := _capture_check(capture)
	if result["valid"]:
		result = _registered_scene(id, scene, capture)
	var options: Array[Dictionary] = []
	if result["valid"]:
		for option: Dictionary in scene.get("options", []):
			var matched := _condition(option.get("condition", {}), capture)
			if not matched["valid"]:
				result = _fail("invalid_options", matched["error"])
				break
			if matched["value"]:
				options.append(option.duplicate(true))
		if result["valid"]:
			result = {"valid": true, "options": options}
	close()
	return result


## On success keep scope held. Story publishes scene/request while busy, then closes.
## On rejection close now; no true completion, no publish, no continuation queue.
func complete(id: StringName, scene: Dictionary, request: int,
		option_id: StringName = &"", skipped := false) -> Dictionary:
	var checked := validate_scene(scene)
	if not checked["valid"]:
		return checked
	var decision: bool = not scene.get("options", []).is_empty()
	if skipped and (decision or scene.get("skip_policy", "cancel") != "presentation_only"):
		return _fail("cancelled_skip", "略過未確認的選擇不會完成、付款或領物。")
	var option: Dictionary = {}
	if decision:
		for entry: Dictionary in scene["options"]:
			if entry["id"] == String(option_id):
				option = entry
		if option.is_empty():
			return _fail("unanswered_choice", "尚未確認任何選項。")
	elif option_id != &"":
		return _fail("unexpected_choice", "此段沒有該選項。")
	var capture := _open(request, id, &"decision" if decision else &"completion")
	if capture == null:
		return _fail("busy_or_unbound", "故事保存入口忙碌或尚未接妥。")
	var result := _capture_check(capture)
	if result["valid"]:
		result = _registered_scene(id, scene, capture)
	if result["valid"]:
		var admission := _condition(scene.get("condition", {}), capture)
		if not admission["valid"] or not admission["value"]:
			result = _fail("condition_unmet", "演出期間條件已改變，尚未完成。")
	var plan: Dictionary = {}
	if result["valid"] and decision:
		var selectable := _condition(option.get("condition", {}), capture)
		if not selectable["valid"] or not selectable["value"]:
			result = _fail("choice_unavailable", "此選項目前已不適用。")
		else:
			plan = _decision_plan(option, capture)
	elif result["valid"]:
		if scene.get("completion_policy", "once") == "reversible_intent":
			plan = _decision_plan({"intent": scene["results"]}, capture)
		elif scene.get("completion_policy", "once") == "repeatable_presentation":
			# Root prepare still authenticates the loaded empty-result contract and full state.
			plan = {"valid": true, "next": capture.projection.duplicate(true), "events": []}
		else:
			plan = StoryResultPlan.plan(scene["results"], capture.projection, capture.registry, capture.runtime_facts)
	if result["valid"] and not plan.get("valid", false):
		result = _fail(str(plan.get("status", "invalid_plan")), str(plan.get("error", "結果準備失敗。")))
	var next := StringName(str(option.get("target", "") if decision else scene.get("then", "")))
	if result["valid"]:
		_active_prepared = port.prepare(capture, plan, next, &"decision" if decision else &"completion", option_id)
		if _active_prepared == null or not _active_prepared.valid:
			result = _fail(_active_prepared.status if _active_prepared != null else "invalid_preparation", _active_prepared.message if _active_prepared != null else "完整安裝尚未準備完成。")
	if result["valid"]:
		var outcome := port.commit_and_install(_active_prepared)
		if outcome == null or not outcome.committed:
			result = _fail(outcome.status if outcome != null else "invalid_outcome", outcome.message if outcome != null else "尚未保存任何故事結果。")
		elif not outcome.installed:
			# A broken trusted port is fatal, not a retryable payment failure.
			push_error("[StoryAtomicCoordinator] durable commit without complete install; retain scope and recover from committed slot")
			return _fail("committed_install_contract_broken", "故事已保存但安裝契約失效，必須讀取完整保存結果。")
		else:
			return {"valid": true, "decision": decision, "next": next, "events": plan["events"].duplicate(true)}
	close()
	return result


static func _decision_plan(option: Dictionary, capture: Capture) -> Dictionary:
	var next: Dictionary = capture.projection.duplicate(true)
	var flags: Dictionary = capture.registry.get("flag_defaults", {}).duplicate(true)
	flags.merge(next.get("flags", {}), true)
	var used: Dictionary = {}
	for op: Dictionary in option.get("intent", []):
		var id: String = op["id"]
		if StoryRuntimeFacts.KEYS.has(id) or used.has(id) or not flags.has(id) or typeof(flags[id]) != typeof(op["value"]):
			return {"valid": false, "status": "invalid_intent", "error": "意圖旗標未宣告、重複或型別不符。"}
		used[id] = true
		flags[id] = op["value"]
	next["flags"] = flags
	return {"valid": true, "next": next, "events": [], "intent": option.get("intent", []).duplicate(true)}


func publish_owner_events() -> void:
	if _busy and _active_prepared != null:
		port.publish(_active_prepared)


## Root constructs this from Story's loaded scenes + actual owner catalogs.
## producers is authenticated by Main/Level (live Node/resource/binding/source identity),
## NOT by this structural builder. No inferred producer or automatic capability is added.
static func build_registry(scene_id: StringName, scenes: Dictionary, flag_defaults: Dictionary,
		items: Array[StoryItemData], transactions: Array[StoryTransactionData],
		producers: Dictionary, ledger_locked: bool, replay := false) -> Dictionary:
	if scenes.size() > StoryResultPlan.MAX_ENTRIES or items.size() > 256 or transactions.size() > 128:
		return _fail("registry_limit", "正式來源登記超過上限。")
	var loaded: Dictionary = {}
	for id: Variant in scenes:
		if not id is String or not StoryTransactionData.valid_id(id) or not scenes[id] is Dictionary:
			return _fail("invalid_registry", "場景來源格式無效。")
		var scene: Dictionary = scenes[id]
		loaded[id] = {"once": scene.get("completion_policy", "once") not in ["repeatable_presentation", "reversible_intent"],
			"condition": scene.get("condition", {}), "results": scene.get("results", [])}
	if not loaded.has(String(scene_id)):
		return _fail("unknown_scene", "段落未載入正式故事服務。")
	var item_definitions: Dictionary = {}
	for item: StoryItemData in items:
		if item == null or item_definitions.has(String(item.id)):
			return _fail("invalid_registry", "道具來源遺失或重複。")
		item_definitions[String(item.id)] = {"trigger": item.trigger}
	var transaction_definitions: Dictionary = {}
	for transaction: StoryTransactionData in transactions:
		if transaction == null or transaction_definitions.has(String(transaction.id)):
			return _fail("invalid_registry", "帳務來源遺失或重複。")
		transaction_definitions[String(transaction.id)] = transaction.descriptor()
	var registry := {"scene_id": String(scene_id), "replay": replay, "scenes": loaded,
		"flag_defaults": flag_defaults, "item_definitions": item_definitions,
		"transaction_definitions": transaction_definitions, "producers": producers,
		"ledger_locked": ledger_locked}
	var errors := RunSaveCodec.validate_tree(registry, 32768)
	if not errors.is_empty():
		return _fail("invalid_registry", errors[0])
	return {"valid": true, "registry": registry.duplicate(true)}


## Main prepare calls this with its own freshly loaded scene, never request-supplied data.
## The bytes belong in the lease's stale check alongside owner/world/request generations.
static func producer_contract(scene: Dictionary, operation: StringName, option_id: StringName) -> Dictionary:
	var checked := validate_scene(scene)
	if not checked["valid"]:
		return checked
	var contract := {"operation": String(operation), "condition": scene.get("condition", {}),
		"results": scene.get("results", []), "intent": [], "target": scene.get("then", ""),
		"option_id": String(option_id), "loaded_source": var_to_bytes(scene)}
	if operation == &"decision":
		for option: Dictionary in scene.get("options", []):
			if option["id"] == String(option_id):
				contract["intent"] = option.get("intent", [])
				contract["target"] = option.get("target", "")
				contract["option_condition"] = option.get("condition", {})
				return {"valid": true, "contract": contract.duplicate(true)}
		return _fail("unanswered_choice", "目前載入的故事沒有此選項。")
	if operation != &"completion" or option_id != &"":
		return _fail("invalid_operation", "未登記的結果來源操作。")
	return {"valid": true, "contract": contract.duplicate(true)}


## Actual optional topic condition; Main supplies read-only trusted facts.
func interaction_condition(id: StringName, condition: Dictionary) -> bool:
	if not StoryConditionTree.validate(condition)["valid"]:
		return false
	var capture := _open(0, id, &"topics")
	if capture == null:
		return false
	var checked := _capture_check(capture)
	var result := false
	if checked["valid"]:
		var evaluated := _condition(condition, capture)
		result = evaluated["valid"] and evaluated["value"]
	close()
	return result
