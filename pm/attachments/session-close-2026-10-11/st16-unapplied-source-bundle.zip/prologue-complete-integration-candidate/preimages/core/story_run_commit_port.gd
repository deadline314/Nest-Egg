class_name StoryRunCommitPort
extends StoryAtomicCoordinator.CommitPort
const BindingGeometry := preload("res://core/story_binding_geometry.gd")
## Main owns this port. Loaded author data can describe results, never this writer.

enum Phase { IDLE, PREPARING, INSTALLING, PUBLISHING, RECOVERY }
var owner: WeakRef
var phase := Phase.IDLE
var dirty := false
var serial := 0
var _pending: Array[Dictionary] = []
var _sources: Dictionary[int, RefCounted] = {}

class Lease extends RefCounted:
	var serial: int
	var request: int
	var scene_id: StringName
	var operation: StringName
	var level: Level
	var main_source: PackedByteArray
	var scene_source: PackedByteArray
	var world_binding_signature: PackedByteArray
	var source: RefCounted
	var snapshot: Dictionary
	var released := false

class Installation extends RefCounted:
	var lease: Lease
	var bundle: StoryInstallBundle
	var world: StoryLevelWorldInstall.Prepared
	var stage_props: ClinicStageCustody.Prepared
	var write: RunSaveStore.PreparedExistingWrite
	var projection: Dictionary
	var record: Dictionary
	var events: Array
	var previous_credits: int
	var context: Dictionary
	var entry: Dictionary
	var installed := false
	var published := false


func configure(main: Node) -> void:
	owner = weakref(main)


func is_busy() -> bool:
	return phase != Phase.IDLE


func defer_lifecycle(method: StringName, arguments: Array = []) -> bool:
	if not is_busy():
		return false
	var action := {"method": method, "arguments": arguments}
	if not _pending.has(action):
		if _pending.size() >= 16:
			push_error("[StoryRunCommit] lifecycle queue full: %s; original progress retained" % method)
		else:
			_pending.append(action)
	return true


func register_source(request: int, id: StringName, context: Dictionary) -> void:
	var main: Node = owner.get_ref()
	if main == null or not Story.is_atomic_request(request):
		return
	# Continuations retain their original live source lease. They cannot choose a
	# different NPC or spawn simply by changing the continuation's author binding.
	if _sources.has(request):
		return
	var source: RefCounted = main._story_capture_source(request, id, context)
	if source != null:
		_sources[request] = source


func forget_source(request: int, _completed := false) -> void:
	_sources.erase(request)


func _main_source(main: Node) -> PackedByteArray:
	return var_to_bytes([main.get_instance_id(), main._screen.get_instance_id() if is_instance_valid(main._screen) else 0,
		main._level_path, main._active_run, main._destination_pending, main._quitting,
		main._chapter_complete, main._cinematic, main._cinematic_request,
		main._cinematic_context, main._cinematic_entry, Story._presentation_generation])


func capture(request: int, id: StringName, operation: StringName) -> StoryAtomicCoordinator.Capture:
	var capture := StoryAtomicCoordinator.Capture.new()
	var main: Node = owner.get_ref()
	if main == null or is_busy():
		return capture
	phase = Phase.PREPARING
	serial += 1
	dirty = false
	var lease := Lease.new()
	lease.serial = serial
	lease.request = request
	lease.scene_id = id
	lease.operation = operation
	capture.lease = lease
	if not main._active_run or main._destination_pending or main._quitting or main._publishing_restore \
			or main._restore_publish_pending or not is_instance_valid(main._screen) or not main._screen is Level \
			or (is_instance_valid(main._pending_screen) and not main._pending_screen.is_inside_tree()):
		capture.message = "目前正在換區或還原進度，故事尚未結算。"
		return capture
	var level := main._screen as Level
	if not level.is_inside_tree() or level.is_queued_for_deletion() or level.data.resource_path != main._level_path \
			or not level._persistent or not level.data.persistent_world:
		capture.status = "unsupported_restore_boundary"
		capture.message = "故事需要目前完整持久區域，進度仍保留。"
		return capture
	if not main._cinematic.is_empty() and not Story.is_atomic_scene(StringName(main._cinematic)):
		capture.status = "legacy_presentation_busy"
		capture.message = "請先結束目前的演出。"
		return capture
	lease.level = level
	lease.source = _sources.get(request)
	if operation in [&"completion", &"decision"]:
		if request <= 0 or not Story.is_atomic_request(request) or Story.request_scene(request) != id \
				or lease.source == null or not main._story_source_valid(lease.source, request, id):
			capture.status = "unbound_live_source"
			capture.message = "原互動來源已離開，這段尚未完成。"
			return capture
	# Acquire the scope before this capture: Level.run_snapshot can run existing
	# stateful producers. No observer sees or saves its intermediate projection.
	var runtime := level.run_snapshot()
	if runtime.is_empty():
		capture.message = "目前角色狀態無法保存，這段尚未完成。"
		return capture
	var base := RunSnapshot.prepare(RunSnapshot.capture(main._level_path, runtime, main._cinematic,
		main._chapter_complete, main._cinematic_context))
	if base.has("error"):
		capture.message = base["error"]
		return capture
	var encoded_base := RunSaveCodec.decode(RunSaveCodec.encode(base["data"]))
	if encoded_base.has("error"):
		capture.message = encoded_base["error"]
		return capture
	# Freeze the actual save representation, including JSON's numeric precision,
	# before applying results. Integer/float representation alone is not a change.
	lease.snapshot = encoded_base["data"]
	lease.main_source = _main_source(main)
	lease.scene_source = var_to_bytes(Story._scenes.get(String(id), {}))
	var progression := Progression.snapshot()
	capture.projection = {"flags": StoryRuntimeFacts.persistable_flags(GameState.world_flags), "items": StoryItems.snapshot(),
		"credits": progression["credits"], "ledger": progression["story_transactions"],
		"area_states": GameState.area_states.duplicate(true), "completed": Story.progress_snapshot()}
	var transactions: Array[StoryTransactionData] = []
	for resource: StoryTransactionData in ResourceCatalog.load_dir("res://data/story_transactions", StoryTransactionData, "StoryRunCommit"):
		transactions.append(resource)
	var registered := StoryAtomicCoordinator.build_registry(id, Story._scenes,
		StoryRuntimeFacts.persistable_flags(GameState.flag_defaults), StoryItems.catalog(), transactions,
		main._story_authenticated_producers(id, lease.source), Progression._story_transactions._locked)
	if not registered.get("valid", false):
		capture.status = registered.get("status", "invalid_registry")
		capture.message = registered.get("message", "故事來源尚未核對。")
		return capture
	capture.registry = registered["registry"]
	capture.runtime_facts = StoryRuntimeFacts.current()
	capture.valid = true
	capture.exclusive_scene_producers = true
	return capture


func _failure(message: String) -> StoryAtomicCoordinator.PreparedCommit:
	var rejected := StoryAtomicCoordinator.PreparedCommit.new()
	rejected.status = "invalid_preparation"
	rejected.message = message.left(512)
	return rejected


func prepare(capture: StoryAtomicCoordinator.Capture, plan: Dictionary, continuation: StringName,
		operation: StringName, option_id: StringName) -> StoryAtomicCoordinator.PreparedCommit:
	var main: Node = owner.get_ref()
	var lease := capture.lease as Lease
	if main == null or lease == null or phase != Phase.PREPARING or lease.serial != serial \
			or lease.released or _main_source(main) != lease.main_source:
		return _failure("故事或區域來源已變，尚未保存任何新結果。")
	if not main._story_source_valid(lease.source, lease.request, lease.scene_id):
		return _failure("真正的互動來源已失效，尚未結算。")
	var scene: Dictionary = Story._scenes.get(String(lease.scene_id), {})
	if var_to_bytes(scene) != lease.scene_source:
		return _failure("載入故事來源已改變，請重新互動。")
	var contract := StoryAtomicCoordinator.producer_contract(scene, operation, option_id)
	if not contract.get("valid", false) or contract["contract"]["target"] != String(continuation):
		return _failure("選項或續段與真正載入的故事不符。")
	# Independently reconstruct the proposal from the loaded contract. A planner
	# projection is not authorization to spend, acquire, or replace history.
	var canonical: Dictionary
	if operation == &"decision" or scene.get("completion_policy", "once") == "reversible_intent":
		var intent: Array = contract["contract"]["intent"] if operation == &"decision" else scene["results"]
		canonical = StoryAtomicCoordinator._decision_plan({"intent": intent}, capture)
	elif scene.get("completion_policy", "once") == "repeatable_presentation":
		canonical = {"valid": true, "next": capture.projection.duplicate(true), "events": []}
	else:
		canonical = StoryResultPlan.plan(scene["results"], capture.projection, capture.registry, capture.runtime_facts)
	if not canonical.get("valid", false) or not plan.get("valid", false) \
			or canonical["next"] != plan.get("next") or canonical["events"] != plan.get("events"):
		return _failure("故事結果與獨立核對不符，保留原進度。")
	var next: Dictionary = canonical["next"]
	var candidate := lease.snapshot.duplicate(true)
	candidate["story"]["flags"] = next["flags"].duplicate(true)
	candidate["story"]["items"] = next["items"].duplicate(true)
	candidate["story"]["seen"] = next["completed"].duplicate(true)
	candidate["progression"]["credits"] = next["credits"]
	candidate["progression"]["story_transactions"] = next["ledger"].duplicate(true)
	candidate["state"]["area_states"] = next["area_states"].duplicate(true)
	var area: Dictionary = next["area_states"].get(String(lease.level.data.id), {})
	if area.is_empty():
		return _failure("目前區域缺少完整世界記錄。")
	candidate["runtime"]["area"] = area.duplicate(true)
	candidate["runtime"]["world"] = area["world"].duplicate(true)
	var retained := Story.clinic_retains_terminal(lease.request, lease.scene_id, continuation)
	candidate["cinematic"] = String(lease.scene_id if retained else continuation)
	candidate["cinematic_context"] = Story.request_presentation_context(lease.request) if retained or continuation != &"" else {}
	# Physical preparation BEFORE any writer preparation; never infer custody
	# from the pure planner registry or canonical flags.
	var stage_props: ClinicStageCustody.Prepared
	for event: Dictionary in canonical["events"]:
		if event.get("kind") == "item_acquire" and event.get("id") == String(ClinicStageCustody.ITEM):
			var witness: ClinicStageCustody.TakeWitness = main._story_sources.stage_take_witness(lease.source)
			if witness == null or stage_props != null:
				return _failure("沒有唯一、真正由凜持有的診間灰布。")
			var physical: Dictionary = witness.props.prepare_transfer(witness.source, next)
			if physical.has("error"):
				return _failure(physical["error"])
			stage_props = physical["data"]
	var durable: Dictionary = main._run_store.prepare_existing_write(candidate)
	if durable.has("error"):
		return _failure(durable["error"])
	var write: RunSaveStore.PreparedExistingWrite = durable["data"]
	var normalized := write.snapshot()
	var differences := _preparation_differences(candidate, normalized)
	if not differences.is_empty():
		push_warning("[StoryRunCommit] preparation changed: %s" % "; ".join(differences))
		return _failure("完整存檔驗證改變結果（%s），保留原進度並重新核對。" % (differences[0] if not differences.is_empty() else "run"))
	var components := StoryInstallBundle.prepare_story(next)
	if components.has("error"):
		return _failure(components["error"])
	var nodes := StoryLevelWorldInstall.prepare(lease.level, next, main._story_is_actual_clinic(lease.source))
	if nodes.has("error"):
		return _failure(nodes["error"])
	var installation := Installation.new()
	installation.lease = lease
	installation.bundle = components["data"]
	installation.world = nodes["data"]
	installation.stage_props = stage_props
	installation.write = write
	installation.projection = next.duplicate(true)
	installation.record = normalized
	installation.events = canonical["events"].duplicate(true)
	installation.previous_credits = int(capture.projection["credits"])
	installation.context = normalized["cinematic_context"].duplicate(true)
	installation.entry = normalized.duplicate(true) if not String(normalized["cinematic"]).is_empty() else {}
	var prepared := StoryAtomicCoordinator.PreparedCommit.new()
	prepared.valid = true
	prepared.owner_preparation = installation
	prepared.record = normalized.duplicate(true)
	return prepared


## Bounded diagnostics only on refusal; never prints a complete saved record.
static func _preparation_differences(before: Variant, after: Variant, path := "run", result := PackedStringArray()) -> PackedStringArray:
	if result.size() >= 12:
		return result
	if before is Dictionary and after is Dictionary:
		for key: Variant in before:
			if not after.has(key):
				result.append("%s/%s removed" % [path, key])
			else:
				result = _preparation_differences(before[key], after[key], "%s/%s" % [path, key], result)
			if result.size() >= 12:
				return result
		for key: Variant in after:
			if not before.has(key):
				result.append("%s/%s added" % [path, key])
				if result.size() >= 12:
					return result
	elif before is Array and after is Array and before.size() == after.size():
		for i in before.size():
			result = _preparation_differences(before[i], after[i], "%s/%d" % [path, i], result)
			if result.size() >= 12:
				return result
	elif before != after:
		# Compare numbers in the existing JSON format, without accepting any
		# difference that would actually be written to the slot (including money).
		if typeof(before) in [TYPE_INT, TYPE_FLOAT] and typeof(after) in [TYPE_INT, TYPE_FLOAT] \
				and JSON.parse_string(JSON.stringify([before])) == JSON.parse_string(JSON.stringify([after])):
			return result
		result.append("%s changed" % path)
	return result


func commit_and_install(prepared: StoryAtomicCoordinator.PreparedCommit) -> StoryAtomicCoordinator.CommitOutcome:
	var outcome := StoryAtomicCoordinator.CommitOutcome.new()
	var installation := prepared.owner_preparation as Installation
	var main: Node = owner.get_ref()
	if main == null or installation == null or phase != Phase.PREPARING or installation.installed:
		return outcome
	var lease := installation.lease
	if lease.serial != serial or lease.released or _main_source(main) != lease.main_source \
			or not _lease_source_valid(main, lease):
		outcome.message = "故事來源已變，尚未保存任何結果。"
		return outcome
	for checked: Dictionary in [installation.bundle.preflight(),
		StoryLevelWorldInstall.preflight(installation.world, installation.projection),
		main._run_store.preflight_existing_write(installation.write)]:
		if checked.has("error"):
			outcome.message = checked["error"]
			return outcome
	if installation.stage_props != null:
		var physical := ClinicStageCustody.preflight(installation.stage_props, installation.projection)
		if physical.has("error"):
			outcome.message = physical["error"]
			return outcome
	var written: RunSaveStore.DurableWriteOutcome = main._run_store.commit_existing_write(installation.write)
	outcome.committed = written.committed
	if not written.committed:
		outcome.message = "故事保存失敗，原結果完整保留，請稍後重試。"
		return outcome
	# No await, author callback or publication until every owner/world/Main field
	# is installed. The production writer phase hook is its no-op implementation.
	phase = Phase.INSTALLING
	var installed := installation.bundle.install_silent()
	if installed.has("error"):
		if installation.stage_props != null:
			installation.stage_props.props._host.quarantine_authority_silent()
		phase = Phase.RECOVERY
		outcome.status = "committed_install_contract_broken"
		outcome.message = "已保存結果需要完整恢復；不再付款或覆蓋舊入口。"
		return outcome
	StoryLevelWorldInstall.install_authority_silent(installation.world)
	main._cinematic = installation.record["cinematic"]
	main._cinematic_context = installation.context
	main._cinematic_request = lease.request if not main._cinematic.is_empty() else 0
	main._cinematic_entry = installation.entry
	if installation.stage_props != null:
		ClinicStageCustody.install_authority_silent(installation.stage_props)
	installation.installed = true
	phase = Phase.PUBLISHING
	outcome.installed = true
	outcome.status = "committed"
	return outcome


func publish(prepared: StoryAtomicCoordinator.PreparedCommit) -> void:
	var installation := prepared.owner_preparation as Installation
	if installation == null or not installation.installed or installation.published or phase != Phase.PUBLISHING:
		return
	installation.published = true
	if installation.stage_props != null:
		ClinicStageCustody.publish_retirement(installation.stage_props)
	StoryLevelWorldInstall.publish_retirement(installation.world)
	# Visibility callbacks above already see all four owners and every retired
	# pickup authority latch. Data listeners below retain the same exclusive scope.
	if Progression.credits != installation.previous_credits:
		Progression.credits_changed.emit(Progression.credits, Progression.credits - installation.previous_credits)
	for event: Dictionary in installation.events:
		match event.get("kind", ""):
			"transaction_committed":
				Progression.story_transaction_committed.emit(StringName(event["id"]))
			"item_acquire":
				var item := StoryItems.find(StringName(event["id"]))
				StoryItems.acquired.emit(item)
				EventBus.toast_requested.emit(StoryItems.acquire_message(item))
			"item_transfer":
				StoryItems.transferred.emit(StoryItems.find(StringName(event["id"])))
	if is_instance_valid(installation.lease.level) and installation.lease.level.is_inside_tree():
		installation.lease.level.refresh_story_population()
	GameState.request_story_save()



func _lease_source_valid(main: Node, lease: Lease) -> bool:
	if lease.operation == &"world_pickup":
		if lease.source == null or lease.source.get("node") == null or lease.source.get("player") == null:
			return false
		var pickup := lease.source.get("node").get_ref() as CollectiblePickup
		var player := lease.source.get("player").get_ref() as Player
		return _world_source_valid(main, lease, pickup, player) \
			and var_to_bytes(Story._scenes.duplicate(true)) == lease.scene_source \
			and _world_binding_unchanged(main, lease)
	return var_to_bytes(Story._scenes.get(String(lease.scene_id), {})) == lease.scene_source \
		and main._story_source_valid(lease.source, lease.request, lease.scene_id)

const WORLD_PICKUP_PREFIX := "world.pickup."
const WORLD_PICKUP_BINDING := "world_pickup"
const DISK_ITEM_ID := &"ch1_data_disk"
const DISK_FLAG_ID := "ledger_disk_obtained"
const DISK_ITEM_PATH := "res://data/story_items/ch1_data_disk.tres"
const DISK_LEVEL_PATH := "res://data/levels/ch1_vault.tres"
const DISK_BINDING_PATH := "res://data/story/ch1_binding_contract.json"
const DISK_BINDING_ID := "disk_pickup"
const DISK_AREA_ID := "ch1_vault"
const DISK_CELL := Vector2i(40, 16)


## Main calls this only from its trusted CollectiblePickup factory callback.
## A world pickup is an independent command, never a Story request or completion.
## Main/source adapter requirements are documented in the candidate README.
func commit_world_pickup(pickup: CollectiblePickup, live_player: Player) -> bool:
	var main: Node = owner.get_ref()
	if main == null or phase != Phase.IDLE or not _world_boundary(main, main._screen, pickup, live_player):
		return false
	phase = Phase.PREPARING
	serial += 1
	dirty = false
	var capture := StoryAtomicCoordinator.Capture.new()
	var lease := Lease.new()
	lease.serial = serial
	lease.operation = &"world_pickup"
	lease.level = main._screen as Level
	lease.scene_id = &""
	capture.lease = lease

	lease.source = main._story_capture_world_pickup(pickup, live_player)
	if lease.source == null or not _world_source_valid(main, lease, pickup, live_player):
		return _reject_world_pickup(capture, pickup, "實際拾取來源或持久區域已變更。")
	var source: RefCounted = lease.source
	if not source.get("resource") is StoryItemData:
		return _reject_world_pickup(capture, pickup, "拾取不是已登記的劇情道具資源。")
	var item := source.get("resource") as StoryItemData
	if item.id == &"" or item.resource_path.is_empty() or item.trigger != StoryItemData.Trigger.MANUAL \
			or not is_same(StoryItems.find(item.id), item):
		return _reject_world_pickup(capture, pickup, "道具定義不是目前目錄中的 MANUAL 原件。")
	lease.scene_id = StringName(WORLD_PICKUP_PREFIX + String(item.id))
	lease.scene_source = var_to_bytes(Story._scenes.duplicate(true))
	lease.world_binding_signature = PackedByteArray()
	if item.id == DISK_ITEM_ID:
		var contract: Dictionary = main._story_world_pickup_contract(source)
		if not _valid_disk_binding(contract, source, item):
			return _reject_world_pickup(capture, pickup, "資料盤必須符合真實 vault 槽位與已載入 disk_pickup binding。")
		lease.world_binding_signature = var_to_bytes(contract)
	lease.main_source = _main_source(main)

	# Keep the command scope before the snapshot: producers and save callbacks
	# cannot observe or persist a half-applied pickup.
	var runtime := lease.level.run_snapshot()
	if runtime.is_empty() or not _world_source_valid(main, lease, pickup, live_player):
		return _reject_world_pickup(capture, pickup, "拾取或關卡在保存快照時已離開。")
	var base := RunSnapshot.prepare(RunSnapshot.capture(main._level_path, runtime, main._cinematic,
		main._chapter_complete, main._cinematic_context))
	if base.has("error"):
		return _reject_world_pickup(capture, pickup, base["error"])
	var encoded_base := RunSaveCodec.decode(RunSaveCodec.encode(base["data"]))
	if encoded_base.has("error"):
		return _reject_world_pickup(capture, pickup, encoded_base["error"])
	lease.snapshot = encoded_base["data"]
	var progression := Progression.snapshot()
	capture.projection = {"flags": StoryRuntimeFacts.persistable_flags(GameState.world_flags), "items": StoryItems.snapshot(),
		"credits": progression["credits"], "ledger": progression["story_transactions"],
		"area_states": GameState.area_states.duplicate(true), "completed": Story.progress_snapshot()}
	var registry := _world_pickup_registry(main, source, item, lease.scene_id)
	if registry.has("error"):
		return _reject_world_pickup(capture, pickup, registry["error"])
	capture.registry = registry["context"]
	capture.valid = true
	var operations: Array[Dictionary] = registry["operations"]
	var proposal := StoryResultPlan.plan_world_pickup(operations, capture.projection, capture.registry)
	if not proposal.get("valid", false):
		return _reject_world_pickup(capture, pickup, proposal.get("error", "資料盤結果未通過來源核對。"))
	var canonical := StoryResultPlan.plan_world_pickup(operations, capture.projection, capture.registry)
	if not canonical.get("valid", false) or canonical["next"] != proposal["next"] \
			or canonical["events"] != proposal["events"] \
			or canonical["next"]["completed"] != capture.projection["completed"]:
		return _reject_world_pickup(capture, pickup, "拾取命令重算不一致或意外改動 Story 完成紀錄。")
	if not _world_source_valid(main, lease, pickup, live_player) \
			or _main_source(main) != lease.main_source \
			or var_to_bytes(Story._scenes.duplicate(true)) != lease.scene_source \
			or not _world_binding_unchanged(main, lease):
		return _reject_world_pickup(capture, pickup, "拾取來源、載入 binding 或目前場景已改變。")
	var prepared := _prepare_world_pickup(capture, proposal, main)
	if not prepared.valid:
		return _reject_world_pickup(capture, pickup, prepared.message)
	var outcome := commit_and_install(prepared)
	if outcome == null or not outcome.committed:
		return _reject_world_pickup(capture, pickup, outcome.message if outcome != null else "拾取尚未保存，請重試。")
	if not outcome.installed:
		# Durable commit has crossed the point of no return; never report rejection or
		# allow a second acquisition. Keep the phase locked for recovery from the run.
		push_error("[StoryRunCommit] world pickup durable commit requires full restore before interaction can resume")
		return true
	# Force a fresh post-listener recapture: acquired observers may synchronously
	# mark_seen or change other persistent facts without emitting another save signal.
	dirty = true
	publish(prepared)
	release(capture)
	return true


func _reject_world_pickup(capture: StoryAtomicCoordinator.Capture, pickup: CollectiblePickup, message: String) -> bool:
	push_warning("[StoryRunCommit] world pickup refused: %s" % message.left(384))
	if is_instance_valid(pickup):
		pickup.release_story_request(true)
	release(capture)
	return false


func _world_boundary(main: Node, screen: Variant, pickup: Variant, live_player: Variant) -> bool:
	if main == null or not main._active_run or main._destination_pending or main._quitting \
			or main._publishing_restore or main._restore_publish_pending or main._chapter_complete \
			or is_instance_valid(main._pending_screen) or not is_instance_valid(screen) or not screen is Level:
		return false
	var level := screen as Level
	if not level.is_inside_tree() or level.is_queued_for_deletion() or level._finished or level.died \
			or not is_instance_valid(level.data) or not level._persistent or not level.data.persistent_world \
			or level.data.resource_path.is_empty() or level.data.resource_path != main._level_path \
			or main._screen != level or not is_instance_valid(level.player) or level.player != live_player \
			or not live_player.is_inside_tree() or live_player.is_queued_for_deletion() or live_player.is_dead() \
			or live_player.state in [Player.State.DEAD, Player.State.MOUNTED] \
			or not is_instance_valid(pickup) or not pickup.is_inside_tree() or pickup.is_queued_for_deletion():
		return false
	# No active or queued Story presentation may share this world command.
	return main._cinematic.is_empty() and main._cinematic_request == 0 \
		and Story._current_cinematic == &"" and Story._current_request == 0 \
		and Story._atomic_request_scenes.is_empty() and Story._passive_requests.is_empty()


func _world_source_valid(main: Node, lease: Lease, pickup: CollectiblePickup, live_player: Player) -> bool:
	if lease == null or lease.level == null or lease.source == null or lease.level != main._screen \
			or lease.source.get("kind") != "world_pickup" or lease.source.get("request") != 0 \
			or not str(lease.source.get("source_path")).is_empty() \
			or not str(lease.source.get("binding")).is_empty():
		return false
	return _world_boundary(main, lease.level, pickup, live_player) \
		and main._story_world_pickup_valid(lease.source, pickup, live_player)



func _world_binding_unchanged(main: Node, lease: Lease) -> bool:
	if lease.source.get("resource").id != DISK_ITEM_ID:
		return lease.world_binding_signature.is_empty()
	var contract: Variant = main._story_world_pickup_contract(lease.source)
	return contract is Dictionary and not lease.world_binding_signature.is_empty() \
		and var_to_bytes(contract) == lease.world_binding_signature


func _valid_disk_binding(raw: Variant, source: RefCounted, item: StoryItemData) -> bool:
	if not raw is Dictionary or raw.get("contract_source") != DISK_BINDING_PATH \
			or raw.get("binding") != DISK_BINDING_ID or not raw.get("definition") is Dictionary:
		return false
	var definition: Dictionary = raw["definition"]
	var location: Variant = definition.get("location")
	if definition.get("authored_kind") != "pickup" or not location is Dictionary \
			or location.get("level") != DISK_LEVEL_PATH or not BindingGeometry.cell_matches(location.get("cell"), DISK_CELL):
		return false
	if definition.has("resource") and definition["resource"] != item.resource_path:
		return false
	if definition.has("entity_cells") and (not definition["entity_cells"] is Array \
			or not BindingGeometry.cells_contain(definition["entity_cells"], DISK_CELL)):
		return false
	var level: Variant = source.get("level").get_ref()
	var node: Variant = source.get("node").get_ref()
	if not is_instance_valid(level) or not is_instance_valid(node) or item.id != DISK_ITEM_ID \
			or item.resource_path != DISK_ITEM_PATH or level.data.resource_path != DISK_LEVEL_PATH \
			or String(level.data.id) != DISK_AREA_ID or source.get("area_id") != DISK_AREA_ID \
			or source.get("cell") != DISK_CELL or source.get("slot") != "ch1_data_disk@40,16" \
			or node.item != item or node.position != level._layout.cell_to_feet(DISK_CELL.x, DISK_CELL.y):
		return false
	# A contract row without a corresponding actually loaded Story binding is not
	# enough to publish the external flag.
	var loaded_binding := false
	for scene: Variant in Story._scenes.values():
		if scene is Dictionary and StoryAtomicCoordinator.is_formal(scene) \
				and scene.get("binding") == DISK_BINDING_ID:
			loaded_binding = true
			break
	return loaded_binding


func _world_pickup_registry(main: Node, source: RefCounted, item: StoryItemData, command_id: StringName) -> Dictionary:
	if not StoryTransactionData.valid_id(String(command_id)) or not String(command_id).begins_with(WORLD_PICKUP_PREFIX) \
			or Story._scenes.has(String(command_id)):
		return {"error": "拾取命令識別碼無效或與實際 Story scene 衝突。"}
	var scenes: Dictionary = {}
	if Story._scenes.size() > StoryResultPlan.MAX_ENTRIES:
		return {"error": "Story 目錄超過安全上限。"}
	for raw_id: Variant in Story._scenes:
		var scene: Variant = Story._scenes[raw_id]
		if not raw_id is String or not StoryTransactionData.valid_id(raw_id) or not scene is Dictionary:
			return {"error": "已載入 Story 場景目錄損毀。"}
		scenes[raw_id] = {"once": scene.get("completion_policy", "once") not in ["repeatable_presentation", "reversible_intent"],
			"condition": scene.get("condition", {}), "results": scene.get("results", [])}
	var item_definitions: Dictionary = {}
	for canonical: StoryItemData in StoryItems.catalog():
		if not is_instance_valid(canonical) or canonical.id == &"" or item_definitions.has(String(canonical.id)):
			return {"error": "StoryItems 道具目錄遺失或重複。"}
		item_definitions[String(canonical.id)] = {"trigger": canonical.trigger}
	var transaction_resources: Array[Resource] = ResourceCatalog.load_dir("res://data/story_transactions", StoryTransactionData, "StoryWorldPickup")
	var transaction_definitions: Dictionary = {}
	for raw_transaction: Resource in transaction_resources:
		var transaction := raw_transaction as StoryTransactionData
		if not is_instance_valid(transaction) or transaction.id == &"" or transaction_definitions.has(String(transaction.id)):
			return {"error": "canonical transaction 目錄遺失或重複。"}
		transaction_definitions[String(transaction.id)] = transaction.descriptor()
	if not item_definitions.has(String(item.id)) or item_definitions[String(item.id)]["trigger"] != StoryItemData.Trigger.MANUAL:
		return {"error": "此世界道具不是 canonical MANUAL 定義。"}
	var binding_id := String(DISK_BINDING_ID) if item.id == DISK_ITEM_ID else WORLD_PICKUP_BINDING
	var operations: Array[Dictionary] = [{"kind": "item_acquire", "id": String(item.id), "source_binding": binding_id}]
	var producers: Dictionary = {"item_acquire:" + String(item.id): [{
		"scene_id": String(command_id), "source": item.resource_path, "capability": "consumed_pickup",
		"binding": binding_id, "area_id": String(source.get("area_id")), "slot": String(source.get("slot"))
	}]}
	if item.id == DISK_ITEM_ID:
		var contract: Dictionary = main._story_world_pickup_contract(source)
		if not _valid_disk_binding(contract, source, item) \
				or not GameState.flag_defaults.has(DISK_FLAG_ID) \
				or typeof(GameState.flag_defaults[DISK_FLAG_ID]) != TYPE_BOOL \
				or GameState.flag_defaults[DISK_FLAG_ID] != false \
				or bool(GameState.world_flags.get(DISK_FLAG_ID, false)):
			return {"error": "資料盤 flag 未有實際 producer/default/binding，拒絕部分領取。"}
		operations.append({"kind": "flag", "id": DISK_FLAG_ID, "value": true})
		producers["flag:" + DISK_FLAG_ID] = [{"scene_id": String(command_id),
			"source": contract["contract_source"], "capability": "world_pickup_flag"}]
	var context := {"scene_id": String(command_id), "replay": false, "scenes": scenes,
		"flag_defaults": StoryRuntimeFacts.persistable_flags(GameState.flag_defaults), "item_definitions": item_definitions,
		"transaction_definitions": transaction_definitions, "producers": producers,
		"ledger_locked": Progression._story_transactions._locked}
	if not RunSaveCodec.validate_tree(context, 32768).is_empty():
		return {"error": "拾取 registry 格式無效。"}
	return {"context": context, "operations": operations}


func _prepare_world_pickup(capture: StoryAtomicCoordinator.Capture, proposal: Dictionary, main: Node) -> StoryAtomicCoordinator.PreparedCommit:
	var rejected := StoryAtomicCoordinator.PreparedCommit.new()
	rejected.status = "invalid_world_pickup"
	rejected.message = "完整拾取安裝尚未準備完成。"
	var lease := capture.lease as Lease
	if main == null or lease == null or phase != Phase.PREPARING or lease.serial != serial \
			or lease.released or not proposal.get("valid", false) \
			or not _lease_source_valid(main, lease):
		rejected.message = "拾取來源已失效，沒有修改道具或消耗槽。"
		return rejected
	var canonical := StoryResultPlan.plan_world_pickup(
		_world_operations_for(lease), capture.projection, capture.registry)
	if not canonical.get("valid", false) or canonical["next"] != proposal.get("next") \
			or canonical["events"] != proposal.get("events") \
			or canonical["next"]["completed"] != capture.projection["completed"]:
		rejected.message = "拾取結果無法由原始快照獨立重算。"
		return rejected
	var next: Dictionary = canonical["next"]
	var candidate := lease.snapshot.duplicate(true)
	candidate["story"]["flags"] = next["flags"].duplicate(true)
	candidate["story"]["items"] = next["items"].duplicate(true)
	candidate["story"]["seen"] = next["completed"].duplicate(true)
	candidate["progression"]["credits"] = next["credits"]
	candidate["progression"]["story_transactions"] = next["ledger"].duplicate(true)
	candidate["state"]["area_states"] = next["area_states"].duplicate(true)
	var area: Dictionary = next["area_states"].get(String(lease.level.data.id), {})
	if area.is_empty():
		rejected.message = "實際區域 world/consumed 記錄不存在。"
		return rejected
	candidate["runtime"]["area"] = area.duplicate(true)
	candidate["runtime"]["world"] = area["world"].duplicate(true)
	# Pickup has no cinematic, route, or completion. Preserve actual idle metadata.
	candidate["cinematic"] = main._cinematic
	candidate["cinematic_context"] = main._cinematic_context.duplicate(true)
	var durable: Dictionary = main._run_store.prepare_existing_write(candidate)
	if durable.has("error"):
		rejected.message = durable["error"]
		return rejected
	var write := durable["data"] as RunSaveStore.PreparedExistingWrite
	var normalized := write.snapshot()
	var differences := _preparation_differences(candidate, normalized)
	if not differences.is_empty():
		rejected.message = "存檔正規化改變拾取結果（%s），保留原資料。" % differences[0]
		return rejected
	var components := StoryInstallBundle.prepare_story(next)
	if components.has("error"):
		rejected.message = components["error"]
		return rejected
	var world := StoryLevelWorldInstall.prepare(lease.level, next, false)
	if world.has("error"):
		rejected.message = world["error"]
		return rejected
	var installation := Installation.new()
	installation.lease = lease
	installation.bundle = components["data"]
	installation.world = world["data"]
	installation.write = write
	installation.projection = next.duplicate(true)
	installation.record = normalized
	installation.events = canonical["events"].duplicate(true)
	installation.previous_credits = int(capture.projection["credits"])
	installation.context = normalized["cinematic_context"].duplicate(true)
	installation.entry = main._cinematic_entry.duplicate(true)
	var prepared := StoryAtomicCoordinator.PreparedCommit.new()
	prepared.valid = true
	prepared.status = "prepared_world_pickup"
	prepared.owner_preparation = installation
	prepared.record = normalized.duplicate(true)
	return prepared


func _world_operations_for(lease: Lease) -> Array[Dictionary]:
	var source: RefCounted = lease.source
	var item: StoryItemData = source.get("resource") as StoryItemData
	var binding_id := String(DISK_BINDING_ID) if item.id == DISK_ITEM_ID else WORLD_PICKUP_BINDING
	var operations: Array[Dictionary] = [{"kind": "item_acquire", "id": String(item.id), "source_binding": binding_id}]
	if item.id == DISK_ITEM_ID:
		operations.append({"kind": "flag", "id": DISK_FLAG_ID, "value": true})
	return operations


func release(capture: StoryAtomicCoordinator.Capture) -> void:
	var lease := capture.lease as Lease if capture != null else null
	if lease == null or lease.released or lease.serial != serial:
		return
	if phase == Phase.RECOVERY:
		return # Never save an old entry over a durable but uninstalled result.
	var main: Node = owner.get_ref()
	if dirty and main != null and phase == Phase.PUBLISHING:
		# Synchronous publication listeners may mark an item seen, update state, or
		# route/free the Level. Recapture only the same live screen; never dereference
		# a stale lease or overwrite a newer destination with the prepared entry.
		var level: Variant = lease.level
		if is_instance_valid(level) and level is Level and is_instance_valid(main._screen) \
				and main._screen == level and main._active_run and not main._destination_pending \
				and level.is_inside_tree() and not level.is_queued_for_deletion() \
				and is_instance_valid(level.data) and level.data.resource_path == main._level_path:
			var runtime: Dictionary = level.run_snapshot()
			if not runtime.is_empty():
				var record := RunSnapshot.capture(main._level_path, runtime, main._cinematic,
					main._chapter_complete, main._cinematic_context)
				if not main._run_store.write(record):
					push_warning("[StoryRunCommit] listener changes not yet saved; committed batch remains intact")
				else:
					main._cinematic_entry = record.duplicate(true) if not main._cinematic.is_empty() else {}
			else:
				push_warning("[StoryRunCommit] Level recapture unavailable after publication; committed batch remains intact")
		else:
			push_warning("[StoryRunCommit] publication screen changed before listener recapture; newer route was left untouched")
	lease.released = true
	dirty = false
	phase = Phase.IDLE
	if main != null:
		for action: Dictionary in _pending:
			main.call_deferred(&"_run_story_lifecycle", action["method"], action["arguments"])
	_pending.clear()
