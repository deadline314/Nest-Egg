class_name QuestCatalog
extends RefCounted
## 唯讀任務檢視；故事條件由 StoryConditionTree 解讀，絕不推進或另存故事狀態。

var quests: Array[Dictionary] = []
var issues := PackedStringArray()
var condition_facts: Dictionary = {}
var condition_context: Dictionary = {}
var _transaction_definitions: Dictionary = {}
var _transaction_definitions_valid := false
var _transaction_definitions_loaded := false
var _reported_condition_errors: Dictionary = {}


func load_story_sources(paths: Array[String] = Story.CHAPTER_PATHS) -> void:
	quests.clear()
	issues.clear()
	_reported_condition_errors.clear()
	_load_transaction_definitions()
	for path in paths:
		var json := JSON.new()
		if json.parse(FileAccess.get_file_as_string(path)) != OK or not json.data is Dictionary:
			_issues_add("%s: 無法讀取故事資料。" % path)
			continue
		read_source(json.data, path)
	refresh_runtime_facts()


func _load_transaction_definitions() -> void:
	_transaction_definitions.clear()
	_transaction_definitions_loaded = true
	_transaction_definitions_valid = true
	for resource: StoryTransactionData in ResourceCatalog.load_dir("res://data/story_transactions", StoryTransactionData, "QuestCatalog"):
		var description := resource.descriptor()
		var id := String(resource.id)
		if description.has("error") or _transaction_definitions.has(id):
			_transaction_definitions_valid = false
			_issues_add("res://data/story_transactions/%s: canonical descriptor 無效或重複。" % id)
			continue
		_transaction_definitions[id] = description


func refresh_runtime_facts(flags: Dictionary = GameState.world_flags) -> void:
	if not _transaction_definitions_loaded:
		_load_transaction_definitions()
	var held: Dictionary = {}
	for item: StoryItemData in StoryItems.catalog():
		held[String(item.id)] = StoryItems.holds(item.id)
	var progression: Dictionary = Progression.snapshot()
	var ledger: Variant = progression.get("story_transactions")
	if not ledger is Dictionary:
		_issues_add("Progression.snapshot/story_transactions: canonical ledger 缺漏，收據與帳戶條件拒絕判定。")
		ledger = {}
	var registered_flags := _declared_flags(flags)
	condition_facts = {"flags": registered_flags, "items": held, "ledger": (ledger as Dictionary).duplicate(true)}
	condition_context = {"ledger_locked": _ledger_locked(),
		"transaction_definitions": _transaction_definitions.duplicate(true), "facts": StoryRuntimeFacts.current()}


func read_source(source: Dictionary, path: String) -> void:
	var raw: Variant = source.get("quests", [])
	if not raw is Array:
		_issues_add("%s.quests: 必須是陣列。" % path)
		return
	for i in raw.size():
		var at := "%s.quests[%d]" % [path, i]
		if not raw[i] is Dictionary:
			_issues_add("%s: 必須是物件。" % at)
			continue
		var quest: Dictionary = raw[i].duplicate(true)
		var valid := true
		for key in ["id", "title", "background", "reward"]:
			if not quest.get(key) is String or str(quest.get(key, "")).is_empty():
				_issues_add("%s.%s: 必須是非空文字。" % [at, key])
				valid = false
		if not quest.has("complete_condition") and (not quest.get("complete_flag") is String or str(quest.get("complete_flag", "")).is_empty()):
			_issues_add("%s.complete_condition: 缺少條件（舊資料可用 complete_flag）。" % at)
			valid = false
		if quest.get("title") is String and quest["title"].length() > 16:
			_issues_add("%s.title: 標題超過一行的 16 字預算。" % at)
			valid = false
		if not quest.get("kind", "main") in ["main", "side"]:
			_issues_add("%s.kind: 必須是 main 或 side。" % at)
			valid = false
		for key in ["visible_condition", "active_condition", "complete_condition"]:
			if quest.has(key):
				var checked := StoryConditionTree.validate(quest[key])
				if not checked["valid"]:
					_issues_add("%s.%s: %s" % [at, key, checked["error"]])
					valid = false
		if quest.has("visible_condition") and quest.get("visible_flags", []) != []:
			_issues_add("%s.visible_flags: 與 visible_condition 重複，請只保留一種來源。" % at)
			valid = false
		if quest.has("active_condition") and quest.get("requires_flags", []) != []:
			_issues_add("%s.requires_flags: 與 active_condition 重複，請只保留一種來源。" % at)
			valid = false
		if not _validate_compat_flag(quest, "complete_condition", "complete_flag", at):
			valid = false
		for key in ["requires_flags", "visible_flags"]:
			if not quest.get(key, []) is Array or not (quest.get(key, []) as Array).all(func(f: Variant) -> bool: return f is String and not f.is_empty()):
				_issues_add("%s.%s: 必須是旗標名稱陣列。" % [at, key])
				valid = false
		var has_active_gate: bool = quest.has("active_condition") and quest["active_condition"] != {}
		if quest.get("requires_flags", []) is Array and not quest.get("requires_flags", []).is_empty():
			has_active_gate = true
		if has_active_gate:
			for key in ["blocked_reason", "suggestion"]:
				if not quest.get(key) is String or str(quest.get(key, "")).is_empty():
					_issues_add("%s.%s: 缺少阻塞說明。" % [at, key])
					valid = false
		var steps: Variant = quest.get("steps")
		if not steps is Array or steps.is_empty():
			_issues_add("%s.steps: 必須有至少一個步驟。" % at)
			valid = false
		else:
			for j in steps.size():
				var step: Variant = steps[j]
				var step_at := "%s.steps[%d]" % [at, j]
				if not step is Dictionary:
					_issues_add("%s: 必須是物件。" % step_at)
					valid = false
					continue
				if not step.get("title") is String or str(step.get("title", "")).is_empty():
					_issues_add("%s.title: 缺少目標文字。" % step_at)
					valid = false
				elif step["title"].length() > 28:
					_issues_add("%s.title: 目標超過一行的 28 字預算。" % step_at)
					valid = false
				if not step.has("complete_condition") and (not step.get("complete_flag") is String or str(step.get("complete_flag", "")).is_empty()):
					_issues_add("%s.complete_condition: 缺少條件（舊資料可用 complete_flag）。" % step_at)
					valid = false
				if step.has("complete_condition"):
					var checked := StoryConditionTree.validate(step["complete_condition"])
					if not checked["valid"]:
						_issues_add("%s.complete_condition: %s" % [step_at, checked["error"]])
						valid = false
				if not _validate_compat_flag(step, "complete_condition", "complete_flag", step_at):
					valid = false
				var target := _validate_target(step, step_at)
				if not target["valid"]:
					_issues_add(target["error"])
					valid = false
		if quests.any(func(q: Dictionary) -> bool: return q.get("id") == quest.get("id")):
			_issues_add("%s.id: 任務編號重複。" % at)
			valid = false
		if valid:
			var chapter_data: Variant = source.get("chapter", {})
			quest["chapter"] = str(chapter_data.get("id", source.get("for_chapter", ""))) if chapter_data is Dictionary else str(source.get("for_chapter", ""))
			quest["kind"] = quest.get("kind", "main")
			quest["source"] = at
			quests.append(quest)


func _validate_compat_flag(owner: Dictionary, condition_key: String, flag_key: String, at: String) -> bool:
	if not owner.has(condition_key):
		return true
	var condition: Variant = owner[condition_key]
	if not condition is Dictionary:
		_issues_add("%s.%s: 相容旗標只允許與單一真旗標條件一致。" % [at, flag_key])
		return false
	var simple: bool = condition.size() == 2 and condition.get("flag") is String and condition.get("equals") is bool and condition["equals"]
	if owner.has(flag_key):
		if not simple or owner[flag_key] != condition.get("flag"):
			_issues_add("%s.%s: 相容旗標只允許與 `{\"flag\":...,\"equals\":true}` 一致的單一真旗標。" % [at, flag_key])
			return false
	elif simple:
		owner[flag_key] = condition["flag"]
	return true


func _valid_binding(value: Variant) -> bool:
	if not value is String or value.is_empty() or value.length() > StoryConditionTree.MAX_ID_LENGTH:
		return false
	for i in value.length():
		var code: int = value.unicode_at(i)
		var letter := code >= 97 and code <= 122
		if (i == 0 and not letter) or (not letter and not (code >= 48 and code <= 57) and code not in [95, 46]):
			return false
	return true


func _validate_target(step: Dictionary, at: String) -> Dictionary:
	if step.has("complete_condition") and not step.has("target_kind"):
		return {"valid": false, "error": "%s.target_kind: 新任務步驟必須明確標記 map、stage_interaction 或 chapter_handoff。" % at}
	var kind: Variant = step.get("target_kind", "map")
	if not kind is String or kind not in ["map", "stage_interaction", "chapter_handoff"]:
		return {"valid": false, "error": "%s.target_kind: 必須是 map、stage_interaction 或 chapter_handoff。" % at}
	if kind == "map":
		return {"valid": true} if valid_location(step.get("location")) else {"valid": false, "error": "%s.location: map 目標必須指向真實關卡與整數腳底格。" % at}
	if not step.has("location") or step["location"] != null:
		return {"valid": false, "error": "%s.location: 非地圖目標必須明確為 null，不得虛構地圖格。" % at}
	if not _valid_binding(step.get("binding")):
		return {"valid": false, "error": "%s.binding: 非地圖目標需要作者來源提供的正式 binding id。" % at}
	return {"valid": true}


static func valid_location(raw: Variant) -> bool:
	if not raw is Dictionary or not raw.get("level") is String or not raw.get("cell") is Array:
		return false
	var cell: Array = raw["cell"]
	if cell.size() != 2 or not cell.all(func(n: Variant) -> bool: return (n is int or n is float) and is_finite(float(n)) and float(n) == floorf(float(n))):
		return false
	if not ResourceLoader.exists(raw["level"]):
		return false
	var data := load(raw["level"]) as LevelData
	if data == null:
		return false
	var layout := LevelBuilder.parse(data)
	return cell[0] >= 0 and cell[1] >= 0 and cell[0] < layout.width and cell[1] < layout.height and layout.cell(int(cell[0]), int(cell[1])) != "#"


func find(id: String) -> Dictionary:
	for quest in quests:
		if quest["id"] == id:
			return quest
	return {}


## 舊章節旗標保留原本 Godot scalar truth semantics；新 AST 只透過 StoryConditionTree。
static func flag_set(flags: Dictionary, name: String) -> bool:
	return true if flags.get(name, false) else false


static func all_flags(names: Array, flags: Dictionary) -> bool:
	return names.all(func(flag: Variant) -> bool: return flag_set(flags, str(flag)))


func _condition_result(condition: Variant, where: String) -> Dictionary:
	var result := StoryConditionTree.evaluate(condition, condition_facts, condition_context)
	if not result["valid"]:
		var message := "%s: %s" % [where, result["error"]]
		if not _reported_condition_errors.has(message):
			_reported_condition_errors[message] = true
			_issues_add(message)
	return result


func _complete_result(owner: Dictionary, condition_key: String, flag_key: String, flags: Dictionary, at: String) -> Dictionary:
	if owner.has(condition_key):
		_use_flags(flags)
		return _condition_result(owner[condition_key], at + "." + condition_key)
	var name: Variant = owner.get(flag_key, "")
	if not name is String or name.is_empty():
		return {"valid": false, "value": false, "error": "%s.%s: 缺少 legacy completion flag。" % [at, flag_key]}
	return {"valid": true, "value": flag_set(flags, name), "error": ""}


## Strict AST facts use only the trusted declared registry; legacy readers keep
## the caller's complete flags and their existing scalar truth semantics.
func _declared_flags(flags: Dictionary) -> Dictionary:
	var result: Dictionary = GameState.flag_defaults.duplicate(true)
	for name: Variant in GameState.flag_defaults:
		if flags.has(name):
			result[name] = flags[name]
	return result


func _ledger_locked() -> bool:
	return not _transaction_definitions_valid or not is_instance_valid(Progression._story_transactions) \
		or Progression._story_transactions._locked


func _use_flags(flags: Dictionary) -> void:
	if not condition_facts.has("items") or not condition_facts.has("ledger"):
		refresh_runtime_facts(flags)
		return
	var registered_flags := _declared_flags(flags)
	condition_facts["flags"] = registered_flags
	# A cached valid-looking ledger snapshot cannot bypass the live lock.
	condition_context["ledger_locked"] = _ledger_locked()
	condition_context["facts"] = StoryRuntimeFacts.current()


func is_step_complete(step: Dictionary, flags: Dictionary, at := "quest.steps") -> bool:
	_use_flags(flags)
	var result := _complete_result(step, "complete_condition", "complete_flag", flags, at)
	return result["value"] if result["valid"] else false


func status(quest: Dictionary, flags: Dictionary) -> String:
	_use_flags(flags)
	var complete := _complete_result(quest, "complete_condition", "complete_flag", flags, str(quest.get("source", quest.get("id", "quest"))))
	if not complete["valid"]:
		return "invalid"
	if complete["value"]:
		return "completed"
	var steps: Variant = quest.get("steps", [])
	if steps is Array:
		for i in steps.size():
			var step: Variant = steps[i]
			if step is Dictionary:
				var result := _complete_result(step, "complete_condition", "complete_flag", flags, "%s.steps[%d]" % [quest.get("source", quest.get("id", "quest")), i])
				if not result["valid"]:
					return "invalid"
	var active: Dictionary
	if quest.has("active_condition"):
		active = _condition_result(quest["active_condition"], str(quest.get("source", quest.get("id", "quest"))) + ".active_condition")
	else:
		active = {"valid": true, "value": all_flags(quest.get("requires_flags", []), flags)}
	if not active["valid"]:
		return "invalid"
	return "active" if active["value"] else "blocked"


func _visible(quest: Dictionary, flags: Dictionary) -> bool:
	_use_flags(flags)
	if quest.has("visible_condition"):
		var result := _condition_result(quest["visible_condition"], str(quest.get("source", quest.get("id", "quest"))) + ".visible_condition")
		return result["valid"] and result["value"]
	return all_flags(quest.get("visible_flags", []), flags)


func is_visible(quest: Dictionary, flags: Dictionary) -> bool:
	return _visible(quest, flags)


func list_for(chapter: String, kind: String, completed: bool, flags: Dictionary) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for quest in quests:
		if quest["chapter"] != chapter or (kind != "all" and quest["kind"] != kind):
			continue
		if not _visible(quest, flags):
			continue
		var task_status := status(quest, flags)
		if task_status == "invalid":
			continue
		if (task_status == "completed") == completed:
			result.append(quest)
	result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return a["kind"] == "main" and b["kind"] != "main")
	return result


func current_step(quest: Dictionary, flags: Dictionary) -> Dictionary:
	for i in quest.get("steps", []).size():
		var step: Dictionary = quest["steps"][i]
		if not is_step_complete(step, flags, "%s.steps[%d]" % [quest.get("source", quest.get("id", "quest")), i]):
			return step
	return {}


## 交付檢查：定義與生產者由 Story compiler 提供；沒有資料時回報缺口，不把模擬當成功。
func validate_flags(known: Array, reachable: Array) -> PackedStringArray:
	var problems := PackedStringArray()
	for quest in quests:
		var names: Array = []
		_collect_condition_names(quest.get("complete_condition"), "flag", names)
		_collect_condition_names(quest.get("visible_condition"), "flag", names)
		_collect_condition_names(quest.get("active_condition"), "flag", names)
		if not quest.has("complete_condition"):
			names.append(quest["complete_flag"])
		for legacy in quest.get("requires_flags", []) + quest.get("visible_flags", []):
			names.append(legacy)
		for step: Dictionary in quest["steps"]:
			_collect_condition_names(step.get("complete_condition"), "flag", names)
			if not step.has("complete_condition"):
				names.append(step["complete_flag"])
		for name in names:
			if not known.has(name) or not reachable.has(name):
				problems.append("%s: 旗標 %s 未定義或不可達。" % [quest["source"], name])
	return problems


func _collect_condition_names(raw: Variant, key: String, output: Array) -> void:
	if not raw is Dictionary:
		return
	if raw.has(key):
		output.append(raw[key])
	for op in ["all", "any"]:
		for child in raw.get(op, []):
			_collect_condition_names(child, key, output)
	if raw.has("not"):
		_collect_condition_names(raw["not"], key, output)


func _issues_add(message: String) -> void:
	if not issues.has(message):
		issues.append(message)
		push_warning("[QuestMap] %s" % message)
