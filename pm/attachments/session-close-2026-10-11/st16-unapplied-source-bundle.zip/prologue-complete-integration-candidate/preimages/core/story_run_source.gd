class_name StoryRunSource
extends RefCounted
const BindingGeometry := preload("res://core/story_binding_geometry.gd")
## Runtime producer authentication. Author bindings describe a contract, not authority.
## No wallet, custody, writer, completion, world install or capability publication.

const MAX_SCENES := 256
const MAX_SPAWNS := 4096
const CABINET_DESTINATION := "dock_commission_cabinet"
const CLINIC_ROOT := &"ch1_c09_wake"
const CLINIC_STAGE := &"ch1_revival_room"
const DOCUMENT_BINDINGS := {
	"ch1_delivery_receipt": "cabinet", "ch1_market_summary": "cabinet",
	"ch1_lounge_bill": "ali_lounge", "ch1_lounge_tab": "ali_stall",
}

class EntryWitness extends RefCounted:
	var level: WeakRef
	var layout: LevelLayout
	var resource: Resource
	var kind: StringName
	var source_id: String
	var origin: StringName
	var trigger_index := -1
	var stage: WeakRef
	var used := false
	var clinic_restore: ClinicVisitResume.Receipt

class Source extends RefCounted:
	var request: int
	var context: Dictionary
	var kind: String
	var main: WeakRef
	var level: WeakRef
	var player: WeakRef
	var entities: WeakRef
	var layout: LevelLayout
	var level_data: LevelData
	var level_path: String
	var area_id: String
	var node: WeakRef
	var resource: Resource
	var resource_signature: PackedByteArray
	var cell: Vector2i
	var position: Vector2
	var slot: String
	var origin: StringName
	var binding: String
	var binding_definition: Dictionary
	var source_path: String
	var graph_signature: PackedByteArray
	var graph: Dictionary
	var npc_lease: RefCounted
	var npc_metadata: Dictionary
	var witness: EntryWitness
	var stage: WeakRef
	var continuation_host: WeakRef  # Runtime Stage lease; never serialized.
	var continuation_required := false  # Revocation cannot downgrade to movie-only proof.
	var was_dead := false

class RestoreEntryReceipt extends RefCounted:
	var layout: LevelLayout
	var layout_signature: PackedByteArray
	var main: WeakRef
	var level: WeakRef
	var resource: LevelData
	var saved_scene: StringName
	var context: Dictionary
	var snapshot_signature: PackedByteArray
	var used := false

var _restore_entry: RestoreEntryReceipt
var clinic_visits := ClinicVisitResume.new()


## Only Main's actual successful read/apply branch installs this runtime receipt.
## No caller-supplied context alone, request JSON or persistent flag creates it.
func register_resume_entry(main: Node, level: Level, validated: Dictionary) -> bool:
	_restore_entry = null
	if validated.get("runtime") is Dictionary and validated["runtime"].get("dead") == true \
			and validated["runtime"].get("death_entry") is Dictionary \
			and validated["runtime"]["death_entry"].get("scene") == String(CLINIC_ROOT) \
			and is_instance_valid(level) and is_instance_valid(level.data) and level.data.chapter == &"ch1_kasa":
		return clinic_visits.register_actual_restore(main, level, validated, self)
	clinic_visits.clear()
	if not _live(main) or not is_instance_valid(level) or level.is_inside_tree() \
			or not main._active_run or not main._restore_publish_pending \
			or not main._story_restore_snapshot is Dictionary or main._story_restore_snapshot != validated \
			or not is_instance_valid(level.data) or not level.data.persistent_world \
			or validated.get("level") != level.data.resource_path or not validated.get("runtime") is Dictionary:
		return false
	var scene: Variant = validated.get("cinematic")
	var context: Variant = validated.get("cinematic_context")
	if not scene is String or scene.is_empty() or not Story.is_atomic_scene(StringName(scene)) \
			or not context is Dictionary or Story.presentation_context(context) != context \
			or context.get("framing_source") != "entry" or validated["runtime"].get("dead", false):
		return false
	var receipt := RestoreEntryReceipt.new()
	receipt.main = weakref(main)
	receipt.level = weakref(level)
	receipt.resource = level.data
	receipt.saved_scene = StringName(scene)
	receipt.context = context.duplicate(true)
	receipt.snapshot_signature = var_to_bytes(validated)
	_restore_entry = receipt
	return true


## Actual Level._ready has parsed the layout before Main publishes restoration.
func bind_resume_layout(main: Node, level: Level) -> bool:
	if clinic_visits._receipt != null:
		return clinic_visits.bind_actual_layout(main, level)
	var receipt := _restore_entry
	if receipt == null or receipt.used or receipt.main.get_ref() != main or receipt.level.get_ref() != level \
			or not main._restore_publish_pending or _level(main) != level or receipt.resource != level.data:
		return false
	receipt.layout = level._layout
	receipt.layout_signature = var_to_bytes([level.data.layout_path, level.data.intro_scene, level._layout.story_triggers])
	return true


func clear_resume_entry() -> void:
	_restore_entry = null
	clinic_visits.clear()


## Runtime restoration is a distinct producer from crossing a new trigger.
## It never pretends saved trigger index equals the new Level's next-trigger cursor.
func begin_resume_entry(main: Node, level: Level, saved_scene: StringName, context: Dictionary) -> EntryWitness:
	if clinic_visits._receipt != null:
		return clinic_visits.begin(main, level, saved_scene, context)
	var receipt := _restore_entry
	_restore_entry = null  # one attempted use, including any refused reconstruction
	if receipt == null or receipt.used or receipt.main.get_ref() != main or receipt.level.get_ref() != level \
			or _level(main) != level or receipt.resource != level.data or receipt.layout != level._layout \
			or receipt.layout_signature != var_to_bytes([level.data.layout_path, level.data.intro_scene, level._layout.story_triggers]) \
			or level.died or level.player.is_dead() \
			or saved_scene != receipt.saved_scene or context != receipt.context \
			or level._resume.get("cinematic") != String(saved_scene) \
			or Story.presentation_context(level._resume.get("cinematic_context", {})) != context:
		return _refuse("resume/not the actual validated restore Level or saved entry")
	receipt.used = true
	var witness := EntryWitness.new()
	witness.level = weakref(level)
	witness.layout = level._layout
	witness.resource = level.data
	witness.source_id = str(context.get("source_id", ""))
	if witness.source_id == "level:intro":
		witness.kind = &"intro"
		witness.origin = level.data.intro_scene
	elif witness.source_id.begins_with("level:trigger:"):
		var text := witness.source_id.trim_prefix("level:trigger:")
		if not text.is_valid_int():
			return _refuse("resume/trigger index is not canonical")
		var index := text.to_int()
		if index < 0 or text != str(index) or index >= level._layout.story_triggers.size():
			return _refuse("resume/trigger not present in actual loaded layout")
		witness.kind = &"trigger"
		witness.trigger_index = index
		witness.origin = StringName(str(level._layout.story_triggers[index].get("scene", "")))
	else:
		return _refuse("resume/unsupported restore entry producer")
	var graph := graph_from(witness.origin)
	if not graph.get("valid", false) or not graph["scenes"].has(String(saved_scene)):
		return _refuse("resume/saved segment outside actual intro or trigger loaded graph")
	return witness


var last_error := ""


func _refuse(reason: String) -> Variant:
	last_error = reason.left(512)
	return null


static func _live(node: Variant) -> bool:
	return is_instance_valid(node) and node is Node and node.is_inside_tree() and not node.is_queued_for_deletion()


static func _level(main: Node) -> Level:
	if not _live(main) or not main._active_run or main._destination_pending or main._quitting or not _live(main._screen) or not main._screen is Level:
		return null
	var level := main._screen as Level
	if not is_instance_valid(level.data) or level.data.resource_path != main._level_path or not level._persistent or not level.data.persistent_world \
			or level._layout == null or not level._layout.is_valid() or level._layout.spawns.size() > MAX_SPAWNS \
			or not _live(level._entities) or not _live(level.player) or level.player.get_parent() != level._entities \
			or not _area_bound(level):
		return null
	return level


static func _area_bound(level: Level) -> bool:
	# Never call area_state() here: authentication must not create owner state.
	var area: Variant = GameState.area_states.get(String(level.data.id))
	return area is Dictionary and is_same(level._area, area) and area.get("consumed") is Dictionary


## Standalone world command, not a Story request/scene receipt. Main first checks
## this is its current Level and owns the exclusive durable-command scope.
func capture_pickup(level: Level, node: CollectiblePickup, player: Player) -> Source:
	last_error = ""
	if not _live(level) or not is_instance_valid(level.data) or not level._persistent or not level.data.persistent_world \
			or level._layout == null or not level._layout.is_valid() or level._layout.spawns.size() > MAX_SPAWNS \
			or level.player != player or not _live(player) or player.get_parent() != level._entities or not _area_bound(level) \
			or not _live(node) or not _live(level._entities):
		return _refuse("world-pickup/actual persistent Level boundary mismatch")
	var slot := ""
	for spawn: Dictionary in level._layout.spawns:
		if is_same(spawn.get("resource"), node.item) and spawn.get("position") == node.position:
			var candidate: String = level._spawn_key(spawn)
			if is_same(level._tracked.get(candidate), node):
				if not slot.is_empty():
					return _refuse("world-pickup/ambiguous actual tracked layout slot")
				slot = candidate
	if slot.is_empty():
		return _refuse("world-pickup/not the actual tracked layout Node")
	var source := Source.new()
	source.kind = "world_pickup"
	source.level = weakref(level)
	source.player = weakref(player)
	source.entities = weakref(level._entities)
	source.layout = level._layout
	source.level_data = level.data
	source.level_path = level.data.resource_path
	source.area_id = String(level.data.id)
	source.context = {"source_id": slot, "item_id": String(node.item.id) if is_instance_valid(node.item) else ""}
	if not _capture_pickup(source, level):
		return null
	# No scene/source-file/binding authority is synthesized here. Main's trusted
	# factory mapping alone can declare the disk's external contract and flag.
	source.origin = &""
	return source


func validate_world_pickup(raw: RefCounted) -> bool:
	if not raw is Source or raw.kind != "world_pickup" or raw.request != 0 or not raw.source_path.is_empty() or not raw.binding.is_empty():
		return false
	var source := raw as Source
	if source.level == null or source.node == null or source.player == null or source.entities == null:
		return false
	var level: Variant = source.level.get_ref()
	var pickup: Variant = source.node.get_ref()
	return _live(level) and level is Level and level._persistent and is_instance_valid(level.data) and level.data.persistent_world \
		and level.data == source.level_data and level.data.resource_path == source.level_path and String(level.data.id) == source.area_id \
		and level._layout == source.layout and level._layout.is_valid() and level._layout.spawns.size() <= MAX_SPAWNS \
		and _area_bound(level) and level._entities == source.entities.get_ref() and _live(level._entities) \
		and level.player == source.player.get_ref() and _live(level.player) and level.player.get_parent() == level._entities \
		and not level.died and not level.player.is_dead() and level.player.state != Player.State.MOUNTED \
		and _live(pickup) and pickup is CollectiblePickup and pickup.get_parent() == level._entities \
		and is_same(level._tracked.get(source.slot), pickup) and pickup.item == source.resource and pickup.position == source.position \
		and _item_signature(pickup.item) == source.resource_signature and pickup.item.trigger == StoryItemData.Trigger.MANUAL \
		and pickup._story_formal and pickup._story_request_pending and not pickup._story_retired \
		and not level._area["consumed"].has(source.slot) and not StoryItems.owns(pickup.item.id) and _slot_still_same(level, source)


## Root invokes ONLY at the actual Level producer call site, never from author JSON.
## source_id is plain context; this object is the unforgeable runtime call-site proof.
func begin_entry(level: Level, kind: StringName, trigger_index := -1, stage: Node = null) -> EntryWitness:
	if not _live(level) or level._layout == null or not _live(level.player):
		return _refuse("entry/actual Level or player missing")
	var witness := EntryWitness.new()
	witness.level = weakref(level)
	witness.layout = level._layout
	witness.resource = level.data
	witness.kind = kind
	match kind:
		&"intro":
			if level.died or level.player.is_dead() or level._from_checkpoint or level.data.intro_scene == &"":
				return _refuse("entry/intro is not eligible")
			witness.origin = level.data.intro_scene
			witness.source_id = "level:intro"
		&"trigger":
			if level.died or level.player.is_dead() or trigger_index < 0 or trigger_index >= level._layout.story_triggers.size() or trigger_index != level._next_story_trigger:
				return _refuse("entry/not the actual next layout trigger")
			var trigger: Dictionary = level._layout.story_triggers[trigger_index]
			if not is_finite(float(trigger.get("x", NAN))) or not level.player.global_position.is_finite() or level.player.global_position.x < trigger["x"]:
				return _refuse("entry/trigger threshold not reached")
			witness.origin = StringName(trigger["scene"])
			witness.trigger_index = trigger_index
			witness.source_id = "level:trigger:%d" % trigger_index
		&"clinic":
			if not _clinic_level(level) or not _declares_stage(CLINIC_ROOT, CLINIC_STAGE):
				return _refuse("entry/not actual first-death revival stage")
			# Initial death playback uses CLINIC_ROOT. A separately root-owned interactive
			# stage may start the real dispatch root after the movie, with this Stage node.
			witness.origin = CLINIC_ROOT if stage == null else &"ch1_dispatch_first_clinic"
			witness.source_id = "level:first_clinic"
			if stage != null:
				if not _stage_valid(stage, level, CLINIC_STAGE):
					return _refuse("entry/interactive clinic Stage is not live under actual Level")
				witness.stage = weakref(stage)
		_:
			return _refuse("entry/unknown producer kind")
	return witness


func capture(main: Node, request: int, id: StringName, context: Dictionary, entry: EntryWitness = null) -> Source:
	last_error = ""
	var level := _level(main)
	if level == null or request <= 0 or not Story.is_atomic_request(request) or Story.request_scene(request) != id \
			or Story.request_presentation_context(request) != context or Story.presentation_context(context) != context:
		return _refuse("source/request or actual persistent Level boundary mismatch")
	var source := Source.new()
	source.main = weakref(main)
	source.level = weakref(level)
	source.player = weakref(level.player)
	source.entities = weakref(level._entities)
	source.layout = level._layout
	source.level_data = level.data
	source.level_path = main._level_path
	source.area_id = String(level.data.id)
	source.was_dead = level.died
	source.request = request
	source.context = context.duplicate(true)
	source.kind = str(context.get("framing_source", ""))
	match source.kind:
		"person", "object":
			if not _capture_npc(source, level, id):
				return null
		"pickup":
			if not _capture_pickup(source, level):
				return null
		"entry":
			if not _capture_entry(source, level, entry):
				return null
		_:
			return _refuse("source/missing supported live producer context")
	var graph := graph_for_source(source)
	if not graph.get("valid", false) or not graph["scenes"].has(String(id)):
		return _refuse("source/actual requested segment outside loaded origin graph")
	source.graph = graph["scenes"]
	source.graph_signature = graph["signature"]
	source.source_path = graph["path"]
	source.binding = graph["binding"]
	var binding := _loaded_binding(source.source_path, source.binding)
	if binding.is_empty() or not _binding_matches(source, level, binding):
		return _refuse("source/loaded binding differs from actual producer geometry")
	source.binding_definition = binding.duplicate(true)
	if source.npc_lease != null and not bool(source.npc_metadata.get("main", false)) and not _topic_contract(source):
		return _refuse("source/selected NPC topic is not the loaded optional_interactions contract")
	return source


func _capture_npc(source: Source, level: Level, _id: StringName) -> bool:
	if level.died or level.player.is_dead() or level.player.state == Player.State.MOUNTED:
		_refuse("source/NPC interaction cannot begin on dead or mounted player")
		return false
	var key := str(source.context.get("source_id", ""))
	var found: NpcActor
	for child in level._entities.get_children():
		if child is NpcActor and child.state_key() == key:
			if found != null:
				_refuse("source/ambiguous NPC state key")
				return false
			found = child
	if not _live(found) or found.data == null or (source.kind == "person") != (found.data.kind == NpcData.Kind.PERSON):
		_refuse("source/exact actual NPC kind/state key absent")
		return false
	var lease: RefCounted = found.interaction_lease()
	var metadata: Dictionary = found.selected_topic_metadata()
	var index: int = source.context.get("talk_index", -1)
	if lease == null or metadata.is_empty() or index < 0 or index >= found.data.talks.size() or metadata.get("talk_index") != index \
			or not is_instance_valid(found.data.talks[index]) \
			or metadata.get("source_id") != key or lease.npc.get_ref() != found or lease.player.get_ref() != level.player \
			or lease.parent.get_ref() != level._entities or lease.resource != found.data or lease.talk != found.data.talks[index] \
			or not found._player_in_range or found._prompt_player != level.player or not _overlap(found, level.player) \
			or not _near(found.global_position, level.player.global_position, NpcActor.INTERACT_RANGE):
		_refuse("source/actual NPC selected topic, lease or initial overlap invalid")
		return false
	var origin := StringName(str(metadata.get("origin_scene", "")))
	var selected := StringName(str(metadata.get("scene", "")))
	if origin != found.data.talks[index].scene or source.context.get("talk_origin") != String(origin) or source.context.get("topic_scene") != String(selected):
		_refuse("source/NPC selected scene/original NpcTalk context mismatch")
		return false
	var spawn := _unique_spawn(level, found.data, found.cell)
	if spawn.is_empty() or found.position != spawn["position"]:
		_refuse("source/NPC not the unique current layout resource/cell")
		return false
	source.node = weakref(found)
	source.resource = found.data
	source.cell = found.cell
	source.position = found.position
	source.origin = selected
	source.npc_lease = lease
	source.npc_metadata = metadata.duplicate(true)
	source.resource_signature = _npc_signature(found, index)
	return true


func _capture_pickup(source: Source, level: Level) -> bool:
	if level.died or level.player.is_dead() or level.player.state == Player.State.MOUNTED:
		_refuse("source/pickup cannot begin on dead or mounted player")
		return false
	var key := str(source.context.get("source_id", ""))
	var node: Variant = level._tracked.get(key)
	if not _live(node) or not node is CollectiblePickup or node.get_parent() != level._entities \
			or not node._story_formal or not node._story_request_pending or node._story_retired \
			or not is_instance_valid(node.item) or node.item.trigger != StoryItemData.Trigger.MANUAL \
			or source.context.get("item_id") != String(node.item.id) or not _overlap(node, level.player) \
			or level._area.get("consumed", {}).has(key) or StoryItems.owns(node.item.id):
		_refuse("source/actual tracked MANUAL pending pickup absent, consumed or no initial overlap")
		return false
	var spawn := _unique_slot(level, key)
	if spawn.is_empty() or not is_same(spawn["resource"], node.item) or node.position != spawn["position"]:
		_refuse("source/pickup resource/slot/position differs from actual layout")
		return false
	source.node = weakref(node)
	source.resource = node.item
	source.cell = spawn["cell"]
	source.position = node.position
	source.slot = key
	# Root may use a separate, loaded pickup command scene. Its source must still
	# declare disk_pickup. An ordinary radio does not fabricate an item result.
	source.origin = Story.request_scene(source.request) if source.request > 0 else &""
	source.resource_signature = _item_signature(node.item)
	return true


func _capture_entry(source: Source, level: Level, entry: EntryWitness) -> bool:
	if entry == null:
		return _capture_cinematic_entry(source, level)
	if entry.level == null or entry.used or entry.level.get_ref() != level or entry.layout != level._layout or entry.resource != level.data \
			or source.context.get("source_id") != entry.source_id:
		_refuse("source/entry needs a one-use witness from actual Level producer call site")
		return false
	if entry.clinic_restore != null and not clinic_visits.authenticates(entry):
		_refuse("source/clinic restore receipt is not the actual read/apply Level")
		return false
	entry.used = true  # A rejected attempt cannot recycle proof into another request.
	if entry.kind == &"clinic" and not _clinic_level(level):
		_refuse("source/first clinic death boundary changed")
		return false
	if entry.kind != &"clinic" and (level.died or level.player.is_dead()):
		_refuse("source/live map entry became a death")
		return false
	source.witness = entry
	source.origin = entry.origin
	source.resource = level.data
	source.resource_signature = _level_signature(level, entry)
	source.stage = entry.stage
	return true


func _capture_cinematic_entry(source: Source, level: Level) -> bool:
	if level.died or level.player.is_dead() or level.player.state == Player.State.MOUNTED:
		_refuse("source/cinematic entry is not live-player eligible")
		return false
	var found: CinematicEntrance
	for child in level._entities.get_children():
		if child is CinematicEntrance and child.data != null and String(child.data.id) == source.context.get("source_id"):
			if found != null:
				_refuse("source/ambiguous actual cinematic entry id")
				return false
			found = child
	if not _live(found) or not found._playing or found._player != level.player \
			or not _near(found.global_position, level.player.global_position, NpcActor.INTERACT_RANGE) \
			or absf(found.global_position.y - level.player.global_position.y) > CinematicFraming.VERTICAL_RANGE:
		_refuse("source/cinematic entry was not actually activated in range")
		return false
	var count := 0
	for data: CinematicEntryData in level.data.cinematic_entries:
		if data != null and data.id == found.data.id:
			count += 1
			if not is_same(data, found.data):
				return false
	if count != 1 or found.position != level._layout.cell_to_feet(found.data.cell.x, found.data.cell.y):
		_refuse("source/cinematic entry resource/placement differs from actual LevelData")
		return false
	source.node = weakref(found)
	source.resource = found.data
	source.cell = found.data.cell
	source.position = found.position
	source.origin = found.data.scene
	source.resource_signature = _cinematic_signature(found.data)
	return true


func valid(raw: RefCounted, request: int, id: StringName) -> bool:
	if not raw is Source:
		return false
	var source := raw as Source
	if source.main == null or source.level == null or source.player == null or source.entities == null or request <= 0:
		return false  # A standalone world source can never become a scene receipt.
	var main: Variant = source.main.get_ref()
	var level: Variant = source.level.get_ref()
	if not _live(main) or not _live(level) or _level(main) != level or request != source.request or request <= 0 \
			or not Story.is_atomic_request(request) or Story.request_scene(request) != id or Story.request_presentation_context(request) != source.context \
			or level.data != source.level_data or level._layout != source.layout or level.player != source.player.get_ref() \
			or level._entities != source.entities.get_ref() or main._level_path != source.level_path or String(level.data.id) != source.area_id \
			or level.died != source.was_dead:
		return false
	var graph := graph_for_source(source)
	if not graph.get("valid", false) or graph["signature"] != source.graph_signature or not graph["scenes"].has(String(id)) \
			or _loaded_binding(source.source_path, source.binding) != source.binding_definition:
		return false
	if source.continuation_required and not _live_stage(source):
		return false
	if source.kind in ["person", "object"]:
		var npc: Variant = source.node.get_ref()
		var index: int = source.context.get("talk_index", -1)
		return _live(npc) and npc is NpcActor and npc.get_parent() == level._entities and npc.data == source.resource \
			and npc.position == source.position and npc.cell == source.cell and npc.state_key() == source.context["source_id"] \
			and npc.interaction_lease() == source.npc_lease and npc.selected_topic_metadata() == source.npc_metadata \
			and _npc_signature(npc, index) == source.resource_signature and not level.died and not level.player.is_dead() \
			and not _unique_spawn(level, source.resource, source.cell).is_empty() and _binding_matches(source, level, source.binding_definition) \
			and (source.npc_metadata.get("main", false) or (_topic_contract(source) and _condition_live(source.npc_metadata["condition"])))
	if source.kind == "pickup":
		var pickup: Variant = source.node.get_ref()
		return _live(pickup) and pickup is CollectiblePickup and pickup.get_parent() == level._entities \
			and is_same(level._tracked.get(source.slot), pickup) and pickup.item == source.resource and pickup.position == source.position \
			and _item_signature(pickup.item) == source.resource_signature and pickup._story_formal and pickup._story_request_pending \
			and not pickup._story_retired and not level._area.get("consumed", {}).has(source.slot) and not StoryItems.owns(pickup.item.id) \
			and not level.died and not level.player.is_dead() and _slot_still_same(level, source) \
			and _binding_matches(source, level, source.binding_definition)
	if source.kind == "entry":
		if source.node != null:
			var entrance: Variant = source.node.get_ref()
			return _live(entrance) and entrance is CinematicEntrance and entrance.get_parent() == level._entities \
				and entrance.data == source.resource and entrance.data.scene == source.origin and entrance._playing \
				and entrance.position == source.position and _cinematic_signature(entrance.data) == source.resource_signature \
				and level.data.cinematic_entries.has(entrance.data) and not level.died and not level.player.is_dead() \
				and _binding_matches(source, level, source.binding_definition)
		return source.witness != null and source.witness.level.get_ref() == level \
			and _level_signature(level, source.witness) == source.resource_signature \
			and (is_actual_clinic(source) if source.witness.kind == &"clinic" else not level.died and not level.player.is_dead()) \
			and _binding_matches(source, level, source.binding_definition)
	return false


func authenticated_producers(id: StringName, raw: RefCounted) -> Dictionary:
	var result := {}
	if not raw is Source or not valid(raw, raw.request, id):
		return result  # readonly admit/dispatch/topics get no award authority
	var source := raw as Source
	var scene: Variant = Story._scenes.get(String(id))
	if not scene is Dictionary or scene.get("binding") != source.binding or not scene.get("results") is Array or scene["results"].size() > 64:
		return result
	for operation: Variant in scene["results"]:
		if not operation is Dictionary or not operation.get("id") is String or not operation.get("kind") is String:
			return {}
		var entry := {"scene_id": String(id), "source": source.source_path, "capability": "scene_completion"}
		var kind: String = operation["kind"]
		var item_id: String = operation["id"]
		if kind == "item_transfer":
			if source.kind != "object" or source.binding != "cabinet" or item_id != "ch1_data_disk" or operation.get("destination") != CABINET_DESTINATION:
				continue
			entry["capability"] = "item_transfer"
			entry["destination"] = CABINET_DESTINATION
		elif kind == "item_acquire":
			var resource := StoryItems.find(StringName(item_id))
			if resource == null or resource.trigger != StoryItemData.Trigger.MANUAL:
				continue
			if operation.has("source_binding"):
				if source.kind == "pickup" and source.binding == "disk_pickup" and item_id == String((source.resource as StoryItemData).id) and operation["source_binding"] == source.binding:
					entry.merge({"capability": "consumed_pickup", "binding": source.binding, "area_id": source.area_id, "slot": source.slot}, true)
				elif source.binding == "first_clinic" and item_id == "ch1_grey_cloth" and operation["source_binding"] == "first_clinic":
					var held := stage_take_witness(source)
					if held == null:
						continue  # Stage visibility/flag alone never grants cloth.
					entry.merge({"capability": "stage_manual_item", "binding": "first_clinic", "stage_id": String(CLINIC_STAGE)}, true)
				else:
					continue
			elif source.kind in ["person", "object"] and DOCUMENT_BINDINGS.get(item_id) == source.binding:
				entry["capability"] = "scene_manual_item"
			else:
				continue
		elif kind not in ["flag", "transaction"]:
			continue
		var key := kind + ":" + item_id
		if result.has(key):
			return {}  # No ambiguous repeated registry candidates.
		result[key] = [entry]
	return result


static func _clinic_level(level: Level) -> bool:
	return _live(level) and level.died and _live(level.player) and level.player.is_dead() and GameState.deaths == 1 \
		and str(level._death_entry.get("scene", "")) == String(CLINIC_ROOT) and level.data.chapter == &"ch1_kasa"


func is_actual_clinic(raw: RefCounted) -> bool:
	if not raw is Source or raw.kind != "entry" or raw.binding != "first_clinic" or raw.witness == null or raw.witness.kind != &"clinic":
		return false
	if raw.level == null or raw.player == null or raw.witness == null:
		return false
	var level: Variant = raw.level.get_ref()
	return _live(level) and _clinic_level(level) and raw.player.get_ref() == level.player and _declares_stage(CLINIC_ROOT, CLINIC_STAGE) \
		and (raw.witness.clinic_restore == null or (raw.witness.clinic_restore.issuer != null \
			and raw.witness.clinic_restore.issuer.get_ref() is ClinicVisitResume \
			and raw.witness.clinic_restore.issuer.get_ref().authenticates(raw.witness)))


static func _stage_valid(stage: Variant, level: Level, id: StringName) -> bool:
	# Actual hierarchy: Stage -> _stage_holder -> CutscenePlayer UI -> Story.
	# Level ancestry is deliberately not used; no authored stage declaration or
	# similarly named arbitrary Node can substitute for this live ownership chain.
	var player: Variant = Story._player
	return _clinic_level(level) and _live(player) and player is CutscenePlayer and Story.is_ancestor_of(player) \
		and player.is_running() and not player._overlay_mode and _live(player._stage_holder) \
		and player.is_ancestor_of(player._stage_holder) and is_same(player._stage, stage) \
		and _live(stage) and stage is StageLibrary.Stage and stage.stage_id == id and stage.get_parent() == player._stage_holder


static func _live_stage(source: Source) -> bool:
	var level: Variant = source.level.get_ref()
	var host: Variant = source.continuation_host.get_ref() if source.continuation_host != null else null
	if source.continuation_required or host != null:
		return _live(host) and host is StageContinuationHost and Story._clinic_stage_host == host \
			and host.authenticates(source, level, Story._current_cinematic)
	var player: Variant = Story._player
	if not _live(player) or not player is CutscenePlayer or Story._current_request != source.request \
			or player.scene_id != Story.request_scene(source.request) or Story._current_cinematic != player.scene_id \
			or not source.graph.has(String(player.scene_id)) or not _stage_valid(player._stage, level, CLINIC_STAGE):
		return false
	# Refresh solely from the current actual native presentation, never cached null
	# or a weak old stage whose animated request has ended. Root's retained-stage
	# bridge across dialogue/choice must add its own exact same-request proof first.
	source.stage = weakref(player._stage)
	return true


static func _declares_stage(id: StringName, stage: StringName) -> bool:
	var scene: Variant = Story._scenes.get(String(id))
	if not scene is Dictionary or scene.get("binding") != "first_clinic" or not scene.get("steps") is Array or scene["steps"].size() > 1024:
		return false
	for step: Variant in scene["steps"]:
		if step is Dictionary and step.get("do") == "scene" and step.get("id") == String(stage):
			return StageLibrary.exists(stage)
	return false


static func _overlap(area: Area2D, player: Player) -> bool:
	for body in area.get_overlapping_bodies():
		if Pickup.resolve_player(body) == player:
			return true
	return false


static func _near(first: Vector2, second: Vector2, horizontal: float) -> bool:
	return first.is_finite() and second.is_finite() and absf(first.x - second.x) <= horizontal


static func _unique_spawn(level: Level, resource: Resource, cell: Vector2i) -> Dictionary:
	var found := {}
	for spawn: Dictionary in level._layout.spawns:
		if spawn.get("cell") == cell:
			if not found.is_empty() or not is_same(spawn.get("resource"), resource):
				return {}
			found = spawn
	return found


static func _unique_slot(level: Level, slot: String) -> Dictionary:
	var found := {}
	for spawn: Dictionary in level._layout.spawns:
		if level._spawn_key(spawn) == slot:
			if not found.is_empty():
				return {}
			found = spawn
	return found


static func _slot_still_same(level: Level, source: Source) -> bool:
	var spawn := _unique_slot(level, source.slot)
	return not spawn.is_empty() and is_same(spawn["resource"], source.resource) and spawn["cell"] == source.cell and spawn["position"] == source.position


static func _npc_signature(npc: NpcActor, index: int) -> PackedByteArray:
	if npc.data == null or index < 0 or index >= npc.data.talks.size() or npc.data.talks[index] == null:
		return PackedByteArray()
	var talk := npc.data.talks[index]
	return var_to_bytes([npc.data.resource_path, npc.data.id, npc.data.kind, npc.cell, talk.scene, talk.once,
		talk.min_talks, talk.min_deaths, talk.after_scene, talk.requires_flag, talk.unless_flag, talk.requires_item,
		talk.credits, talk.consumable.resource_path if talk.consumable != null else "", talk.story_item.resource_path if talk.story_item != null else ""])


static func _item_signature(item: StoryItemData) -> PackedByteArray:
	return var_to_bytes([item.resource_path, item.id, item.trigger, item.trigger_scene, item.play_scene, item.category])


static func _cinematic_signature(entry: CinematicEntryData) -> PackedByteArray:
	return var_to_bytes([entry.resource_path, entry.id, entry.scene, entry.cell, entry.once])


static func _level_signature(level: Level, witness: EntryWitness) -> PackedByteArray:
	return var_to_bytes([level.data.resource_path, level.data.id, level.data.chapter, level.data.intro_scene,
		level.data.story_triggers, level.data.cinematic_entries.map(func(entry: CinematicEntryData) -> Array: return [entry.id, entry.scene, entry.cell, entry.once]),
		level._layout.story_triggers, witness.kind, witness.source_id, witness.origin, witness.trigger_index, level._death_entry if witness.kind == &"clinic" else {}])


func _loaded_binding(path: String, binding: String) -> Dictionary:
	var document: JSON = load(path) as JSON if ResourceLoader.exists(path) else null
	if document == null or not document.data is Dictionary or not document.data.get("bindings") is Dictionary:
		return {}
	var raw: Variant = document.data["bindings"].get(binding)
	return raw if raw is Dictionary and RunSaveCodec.validate_tree(raw, 512).is_empty() and raw.get("binding") == binding else {}


func _binding_matches(source: Source, level: Level, binding: Dictionary) -> bool:
	if source.witness != null and source.witness.kind == &"clinic":
		return source.binding == "first_clinic" and binding.get("target_kind") == "stage_interaction" and binding.get("location") == null and is_actual_clinic(source)
	var location: Variant = binding.get("location")
	if not location is Dictionary or location.get("level") != source.level_path:
		return false
	if source.kind in ["person", "object"]:
		return binding.get("resource") == source.resource.resource_path and binding.get("entity_id") == String((source.resource as NpcData).id) \
			and BindingGeometry.cell_matches(binding.get("entity_cell"), source.cell) \
			and binding.get("dispatcher") == source.npc_metadata.get("origin_scene")
	if source.kind == "pickup":
		return source.binding == "disk_pickup" and binding.get("resource") == source.resource.resource_path \
			and BindingGeometry.cells_contain(binding.get("entity_cells"), source.cell)
	if source.kind == "entry" and source.node != null:
		return binding.get("entry_scene") == String(source.origin)
	if source.witness != null and source.witness.kind == &"intro":
		return binding.get("entry_scene") == String(source.witness.origin) and level.data.intro_scene == source.witness.origin
	if source.witness != null and source.witness.kind == &"trigger":
		var index := source.witness.trigger_index
		return index >= 0 and index < level._layout.story_triggers.size() and binding.get("trigger_scene") == String(source.witness.origin) \
			and binding.get("trigger_cell") is Array and binding["trigger_cell"].size() == 2 \
			and level._layout.story_triggers[index]["scene"] == source.witness.origin \
			and level._layout.story_triggers[index]["x"] == binding["trigger_cell"][0] * level._layout.tile_size
	return false


func _topic_contract(source: Source) -> bool:
	var origin := StringName(str(source.npc_metadata.get("origin_scene", "")))
	for topic in Story.npc_optional_topics(origin):
		if topic["scene"] == source.npc_metadata.get("scene") and topic["title"] == source.npc_metadata.get("title") and topic["condition"] == source.npc_metadata.get("condition"):
			return _condition_live(topic["condition"])
	return false


## No recursive CommitPort capture: completion may already hold PREPARING scope.
## This is the same current owner projection/descriptor schema, never a new ledger.
static func _condition_live(condition: Dictionary) -> bool:
	var flags := GameState.flag_defaults.duplicate(true)
	flags.merge(GameState.world_flags, true)
	var items := {}
	for item: StoryItemData in StoryItems.catalog():
		items[String(item.id)] = StoryItems.holds(item.id)
	var definitions := {}
	for resource: StoryTransactionData in ResourceCatalog.load_dir("res://data/story_transactions", StoryTransactionData, "StoryRunSource"):
		definitions[String(resource.id)] = resource.descriptor()
	var state := Progression.snapshot()
	var checked := StoryConditionTree.evaluate(condition, {"flags": flags, "items": items, "ledger": state["story_transactions"]},
		{"ledger_locked": Progression._story_transactions._locked, "transaction_definitions": definitions, "facts": StoryRuntimeFacts.current()})
	return checked["valid"] and checked["value"]


## Bounded loaded graph: dispatch/routes, options, then, and explicit failure target.
## All reachable nodes retain the same source file and physical binding.
func graph_from(origin: StringName) -> Dictionary:
	var path := Story.scene_source(origin)
	var first: Variant = Story._scenes.get(String(origin))
	if path.is_empty() or not first is Dictionary or not first.get("binding") is String or first["binding"].is_empty():
		return {"valid": false}
	var binding: String = first["binding"]
	var visited := {}
	var queue: Array[StringName] = [origin]
	while not queue.is_empty():
		var id: StringName = queue.pop_back()
		if visited.has(String(id)):
			continue
		var scene: Variant = Story._scenes.get(String(id))
		if visited.size() >= MAX_SCENES or not scene is Dictionary or Story.scene_source(id) != path \
				or (scene.get("binding") != binding) or not RunSaveCodec.validate_tree(scene, 8192).is_empty():
			return {"valid": false}
		# Legacy optional leaves remain outside this formal authority graph.
		visited[String(id)] = scene
		var targets: Array[String] = []
		if scene.has("then"):
			if not scene["then"] is String:
				return {"valid": false}
			targets.append(scene["then"])
		for field in ["routes", "options"]:
			var list: Variant = scene.get(field, [])
			if not list is Array or list.size() > 64:
				return {"valid": false}
			for entry: Variant in list:
				if not entry is Dictionary or not entry.get("target") is String:
					return {"valid": false}
				targets.append(entry["target"])
		var failures: Variant = scene.get("on_failure", {})
		if not failures is Dictionary or failures.size() > 8:
			return {"valid": false}
		for target: Variant in failures.values():
			if not target is String:
				return {"valid": false}
			targets.append(target)
		for target in targets:
			if not target.is_empty():
				if not StoryTransactionData.valid_id(target) or queue.size() >= MAX_SCENES:
					return {"valid": false}
				queue.append(StringName(target))
	if not RunSaveCodec.validate_tree(visited, 32768).is_empty():
		return {"valid": false}
	return {"valid": true, "binding": binding, "path": path, "scenes": visited, "signature": var_to_bytes([path, binding, visited])}


func graph_for_source(source: Source) -> Dictionary:
	if source.witness == null or source.witness.kind != &"clinic" or source.origin != CLINIC_ROOT:
		return graph_from(source.origin)
	var roots: Array[StringName] = [CLINIC_ROOT, &"ch1_dispatch_first_clinic"]
	var topics := Story.npc_optional_topics(CLINIC_ROOT)
	var declared: Variant = Story._npc_topic_catalog.get(Story.scene_source(CLINIC_ROOT), {}).get("first_clinic")
	if not declared is Array or declared.size() > 16 or declared.size() != topics.size():
		return {"valid": false}
	for topic in topics:
		roots.append(StringName(topic["scene"]))
	var path := Story.scene_source(CLINIC_ROOT)
	var scenes := {}
	for root in roots:
		var graph := graph_from(root)
		if not graph.get("valid", false) or graph["path"] != path or graph["binding"] != "first_clinic":
			return {"valid": false}
		scenes.merge(graph["scenes"], true)
		if scenes.size() > MAX_SCENES:
			return {"valid": false}
	if not RunSaveCodec.validate_tree(scenes, 32768).is_empty():
		return {"valid": false}
	return {"valid": true, "binding": "first_clinic", "path": path, "scenes": scenes,
		"signature": var_to_bytes([path, "first_clinic", roots, topics, scenes])}


## Independent runtime proof; pure planner registry is not physical authority.
func stage_take_witness(raw: RefCounted) -> ClinicStageCustody.TakeWitness:
	if not raw is Source or not is_actual_clinic(raw) or not _live_stage(raw):
		return null
	var host: Variant = raw.continuation_host.get_ref() if raw.continuation_host != null else null
	if not host is StageContinuationHost or not _live(host.custody):
		return null
	return host.custody.take_witness(raw)
