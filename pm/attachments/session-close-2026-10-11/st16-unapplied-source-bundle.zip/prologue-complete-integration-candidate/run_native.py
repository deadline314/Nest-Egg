#!/usr/bin/env python3
# Prepared launcher only. This file has NOT executed Godot during candidate production.
from pathlib import Path
import argparse, ctypes, ctypes.wintypes as w, hashlib, json, os, re, subprocess, sys, time
GODOT=Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64.exe')
EXPECTED_EXE='ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424'
SNAPSHOT='fc26a0714833b3354417ce124d2727d4f61e5450253f060f016706228b2b96f8'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class Memory(ctypes.Structure):
 _fields_=[('cb',w.DWORD),('PageFaultCount',w.DWORD),('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t),('PrivateUsage',ctypes.c_size_t)]
def memory(pid):
 k=ctypes.WinDLL('kernel32',use_last_error=True);ps=ctypes.WinDLL('psapi',use_last_error=True)
 k.OpenProcess.restype=w.HANDLE;k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.CloseHandle.argtypes=[w.HANDLE]
 ps.GetProcessMemoryInfo.argtypes=[w.HANDLE,ctypes.POINTER(Memory),w.DWORD];ps.GetProcessMemoryInfo.restype=w.BOOL
 handle=k.OpenProcess(0x0400|0x0010,False,pid)
 if not handle:return None
 try:
  data=Memory();data.cb=ctypes.sizeof(data)
  if not ps.GetProcessMemoryInfo(handle,ctypes.byref(data),data.cb):return None
  return {'working_set_bytes':data.WorkingSetSize,'private_bytes':data.PrivateUsage,'peak_working_set_bytes':data.PeakWorkingSetSize}
 finally:k.CloseHandle(handle)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--baseline',required=True);ap.add_argument('--mode',choices=['normal','normal-write-retry','whole-skip'],default='normal');ap.add_argument('--execute',action='store_true');args=ap.parse_args()
 if not re.fullmatch('[0-9a-fA-F]{40}',args.baseline):raise SystemExit('exact 40hex baseline required')
 root=args.root.resolve();out=args.out
 if not out.is_absolute() or out.exists():raise SystemExit('fresh absolute out required; never overwrite evidence or copy an old slot')
 source=json.loads((Path(__file__).parent/'native-source-manifest.json').read_text(encoding='utf-8'))
 for path,expected in source['sources'].items():
  p=root/path
  if not p.is_file() or sha(p)!=expected:raise SystemExit('source mismatch: '+path)
 if sha(root/'core/run_snapshot.gd')!=SNAPSHOT:raise SystemExit('protected RunSnapshot changed')
 if not GODOT.is_file() or sha(GODOT)!=EXPECTED_EXE:raise SystemExit('exact direct renderer executable required; never tiny console loader PID')
 command=[str(GODOT),'--path',str(root),'--rendering-method','forward_plus','res://tools/prologue_entry_probe.tscn','--','--out='+str(out),'--mode='+args.mode]
 pre={'classification':'prepared, not executed','root':str(root),'out':str(out),'baseline':args.baseline,'command':command,'source_sha256':source['sources'],'engine_sha256':EXPECTED_EXE,'run_snapshot_sha256':SNAPSHOT,'capabilities':[]}
 if not args.execute:print(json.dumps(pre,ensure_ascii=False,indent=2));return 0
 # Root owns the GPU slot and authorizes --execute. Profile is new for each process.
 out.mkdir(parents=True);profile=out/'private-profile';profile.mkdir();env=os.environ.copy();env['APPDATA']=str(profile);env['LOCALAPPDATA']=str(profile/'Local');env['ST16_BASELINE']=args.baseline;env['ST16_SOURCE_MANIFEST']=str(out/'sources.json')
 (out/'sources.json').write_text(json.dumps(source,indent=2),encoding='utf-8');(out/'launch.json').write_text(json.dumps(pre,ensure_ascii=False,indent=2),encoding='utf-8')
 samples=[];timeout=False;start=time.monotonic()
 with (out/'engine.raw.log').open('wb') as raw:
  process=subprocess.Popen(command,cwd=root,env=env,stdout=raw,stderr=subprocess.STDOUT)
  # Direct GUI/native EXE is this actual owned PID. No process-name enumeration.
  while process.poll() is None:
   sample=memory(process.pid)
   if sample:samples.append({'elapsed_seconds':time.monotonic()-start,'pid':process.pid,**sample})
   if time.monotonic()-start>1200:timeout=True;process.terminate();break
   time.sleep(.25)
  try:exit_code=process.wait(timeout=15)
  except subprocess.TimeoutExpired:process.kill();exit_code=process.wait()
 raw=(out/'engine.raw.log').read_bytes();text=raw.decode('utf-8',errors='replace')
 errors=[line for line in text.splitlines() if re.search(r'SCRIPT ERROR|Parse Error|Compile Error|^ERROR:|uninitialized RID',line,re.I)]
 drift=[path for path,expected in source['sources'].items() if not (root/path).is_file() or sha(root/path)!=expected]
 reportfile=out/'ST16-report.json';report=json.loads(reportfile.read_text(encoding='utf-8')) if reportfile.is_file() else {}
 accepted=exit_code==0 and not timeout and not errors and not drift and bool(report) and not report.get('failures',['missing'])
 result={'actual_exe_pid':process.pid,'natural_exit':not timeout,'exit_code':exit_code,'timeout':timeout,'elapsed_seconds':time.monotonic()-start,'raw_sha256':sha(out/'engine.raw.log'),'errors':errors,'source_drift':drift,'memory_samples':samples,'max_working_set_bytes':max((s['working_set_bytes'] for s in samples),default=None),'max_private_bytes':max((s['private_bytes'] for s in samples),default=None),'functional_accepted':accepted,'visual_accepted':False,'hardware_controller_accepted':False,'capabilities':[]}
 (out/'launcher-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in result.items() if k!='memory_samples'},ensure_ascii=False,indent=2));return 0 if accepted else 1
if __name__=='__main__':sys.exit(main())
