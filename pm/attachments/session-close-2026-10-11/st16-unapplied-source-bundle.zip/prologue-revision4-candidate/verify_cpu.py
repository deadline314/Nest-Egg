from pathlib import Path
import hashlib,json,difflib,subprocess,py_compile
A=Path('C:/tmp/prologue-revision3-candidate');B=Path(__file__).resolve().parent;rel='tools/prologue_entry_probe.gd'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=(B/'preimages'/rel).read_text('utf-8');new=(B/'candidate'/rel).read_text('utf-8');checks=[]
def ck(v,label):
 checks.append({'passed':bool(v),'check':label})
 if not v:raise AssertionError(label)
ck(new.split('func _loan_death_retry',1)[0]==old.split('func _loan_death_retry',1)[0],'all original normal/skip/writer retry flow and modes remain byte-equivalent')
ck(new.split('func _revealed_death_screen',1)[1]==old.split('func _revealed_death_screen',1)[1],'all original reveal/input/capture/finish predicates remain byte-equivalent')
ck('var saved: Dictionary = _main._run_store.read()' in new,'dynamic Main read has explicit Dictionary result')
ck('_session._loan.close()' not in new,'tool cannot actively retire the loan')
for token in ['await _tap(&"pause")','"回主選單"','await _button(menu_button)','_main._screen is MainMenu','not Transition.is_active() and leaving_level.get_ref() == null','_session.tree_exiting.connect(','_level.tree_exiting.connect(','CONNECT_ONE_SHOT','_observe_session_exit','player.checkpoint_snapshot()','session._loan._closed','session._loan._player == null','session._proofs.is_empty()','leaving_session.get_ref() == null','leaving_player.get_ref() == null','var menu_saved: Dictionary = _main._run_store.read()','menu_saved["runtime"]["world"] == world']:
 ck(token in new,'actual production retirement observation: '+token)
for relpath,expected in json.loads((A/'freeze-manifest.json').read_text('utf-8'))['artifacts'].items():
 ck(sha(A/relpath)==expected,'parent frozen artifact unchanged: '+relpath)
obs=new.split('func _observe_session_exit',1)[1].split('func _revealed_death_screen',1)[0]
for forbidden in ['_loan.close(', 'queue_free(', '.free(', 'take_damage(', '_show_main_menu(', 'install_world(', 'GameState.checkpoint_loadout =','health.current =','Story.set_flag(']:
 ck(forbidden not in obs,'observer does not mutate authority/lifecycle: '+forbidden)
r=subprocess.run(['C:/tmp/ne230-python/bin/gdparse.exe',str(B/'candidate'/rel)],capture_output=True,text=True,encoding='utf-8',errors='replace')
(B/'gdparse-final.json').write_text(json.dumps({'exit':r.returncode,'raw':r.stdout+r.stderr,'classification':'grammar only, not Godot semantic/native'},indent=2),'utf-8');ck(r.returncode==0,'GD grammar clean')
py_compile.compile(str(B/'run_native.py'),doraise=True)
(B/'cpu-results.json').write_text(json.dumps({'classification':'CPU source/grammar observations only, no runtime assertions executed','checks':len(checks),'failures':0,'details':checks,'engine_run':False,'capabilities':[]},indent=2),'utf-8')
patch=B/'patches/tools__prologue_entry_probe.gd.diff';patch.parent.mkdir(exist_ok=True);patch.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)),'utf-8')
(B/'patch-index.json').write_text(json.dumps([{'path':rel,'pre_sha256':sha(B/'preimages'/rel),'post_sha256':sha(B/'candidate'/rel),'patch':'patches/'+patch.name}],indent=2),'utf-8')
sources=json.loads((A/'native-source-manifest.json').read_text('utf-8'));sources['sources'][rel]=sha(B/'candidate'/rel);sources['classification']='revision4 prepared probe; no native execution';(B/'native-source-manifest.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),'utf-8')
(B/'provenance.json').write_text(json.dumps({'revision3_freeze_sha256':sha(A/'freeze-manifest.json'),'product_sources_changed':False,'tool_post_sha256':sha(B/'candidate'/rel),'protected_snapshot_sha256':'78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c','native_source_count':len(sources['sources']),'external_documentation':['https://docs.godotengine.org/en/stable/classes/class_node.html#class-node-signal-tree-exiting'],'capabilities':[]},indent=2),'utf-8')
print(json.dumps({'checks':len(checks),'grammar_clean':r.returncode==0,'probe_post_sha256':sha(B/'candidate'/rel)}))
