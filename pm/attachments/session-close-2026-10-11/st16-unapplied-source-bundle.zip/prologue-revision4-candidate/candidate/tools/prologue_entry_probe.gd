extends Node
## Synthetic input, actual Main/new-game/Level/Player/actions/RunSaveStore.
## No teleport, flag seeding, auto_skip, scene_finished emission, fake receipt or capabilities.
const Capture = preload("res://tools/viewport_capture.gd")
const SNAPSHOT_SHA := "78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c"
var _main: Node
var _level: Level
var _session: PrologueSession
var _out := ""
var _mode := "normal"
var _checks := 0
var _failures: Array[String] = []
var _rows: Array[Dictionary] = []
var _shots := 0
var _saved_slot := ""
var _last_accept := 0
var _start := 0
var _baseline := ""
var _source_hashes: Dictionary = {}
var _death_retry_finished := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_run.call_deferred()


func check(value: bool, message: String) -> void:
	_checks += 1
	if not value:
		_failures.append(message)
		push_error("[ST16Probe] %s" % message)


func _safe_output() -> bool:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=")
		elif argument.begins_with("--mode="):
			_mode = argument.trim_prefix("--mode=")
	_baseline = OS.get_environment("ST16_BASELINE")
	if (
		not _out.is_absolute_path()
		or _baseline.length() != 40
		or not _baseline.is_valid_hex_number(false)
		or _mode not in ["normal", "normal-write-retry", "whole-skip", "loan-death-pistol", "loan-death-knife"]
	):
		return false
	if (
		DirAccess.make_dir_recursive_absolute(_out) != OK
		or FileAccess.file_exists(_out.path_join("ST16-report.json"))
	):
		return false
	var manifest_path := OS.get_environment("ST16_SOURCE_MANIFEST")
	var manifest: Variant = JSON.parse_string(FileAccess.get_file_as_string(manifest_path))
	if not manifest is Dictionary or not manifest.get("sources") is Dictionary:
		return false
	for path: String in manifest["sources"]:
		var actual := FileAccess.get_sha256("res://" + path)
		_source_hashes[path] = actual
		if actual != manifest["sources"][path]:
			return false
	return FileAccess.get_sha256("res://core/run_snapshot.gd") == SNAPSHOT_SHA


func _run() -> void:
	_start = Time.get_ticks_msec()
	if not _safe_output():
		check(
			false, "fresh absolute output, legal baseline, exact protected source manifest required"
		)
		_finish()
		return
	_main = load("res://game/main.gd").new()
	_main._run_store.path = "user://st16-native-slot.json"
	get_tree().root.add_child(_main)
	if not await _wait(
		func() -> bool: return _main._screen is MainMenu and not Transition.is_active(), 20
	):
		_finish()
		return
	var menu: MainMenu = _main._screen
	check(
		not menu.overwrite_required,
		"fresh private profile reaches genuine new-game menu without an old slot"
	)
	await _button(menu._start_button)
	await _button(menu._confirm_button)
	if not await _wait(
		func() -> bool:
			return (
				_main._screen is Level
				and is_instance_valid((_main._screen as Level).prologue)
				and (_main._screen as Level).is_initialized()
				and not Transition.is_active()
			),
		30
	):
		_finish()
		return
	_level = _main._screen
	_session = _level.prologue
	AimInput.set_virtual_gamepad(_level.player, true)
	_saved_slot = _main._run_store.path
	check(
		(
			_main._level_path == PrologueProgressPlan.LEVEL
			and _level.data.resource_path == PrologueProgressPlan.LEVEL
		),
		"real start/difficulty route enters formal P01 map"
	)
	check(
		(
			GameState.deaths == 0
			and Progression.credits == 0
			and not GameState.world_flags.get("ch1_dinner_done", false)
		),
		"prologue entry has not paid history money or consumed first true death/dinner"
	)
	preload("res://tests/helpers/prologue_integration_checks.gd").actual_level(self, _main, _level)
	preload("res://tests/helpers/prologue_integration_checks.gd").projectile_provenance(
		self, _level
	)
	await _shot("new-run")
	if _mode == "whole-skip":
		if not await _event("p01_information", 90):
			_finish()
			return
		await _tap(&"pause")
		var skip := _find_button(_level._pause_menu, "略過序章…")
		if skip == null:
			check(false, "actual PauseMenu has prologue skip")
			_finish()
			return
		await _button(skip)
		await _button(_session._panel._confirm)
	else:
		if not await _normal():
			_finish()
			return
	if _death_retry_finished:
		_finish()
		return
	if not await _wait(
		func() -> bool:
			return (
				_main._screen is Level
				and (
					(_main._screen as Level).data.resource_path
					== PrologueProgressPlan.FIRST_CHAPTER
				)
				and not Transition.is_active()
			),
		35
	):
		_finish()
		return
	var chapter: Level = _main._screen
	var area: Dictionary = GameState.area_states.get("st16_pawnshop_training", {})
	check(
		area.get("world", {}).get(PrologueProgressPlan.PREFIX + "exited", false),
		"durable committed exit retains the old area world after real Level swap"
	)
	if _mode == "whole-skip":
		check(
			(
				area["world"].get(PrologueProgressPlan.PREFIX + "skipped", false)
				and not area["world"].get(PrologueProgressPlan.PREFIX + "shoot", false)
			),
			"skip did not fake actual training success"
		)
	else:
		for event: String in PrologueProgressPlan.REQUIRED:
			check(
				area["world"].get(PrologueProgressPlan.PREFIX + event, false),
				"real normal route saved required operation: %s" % event
			)
	var read: Dictionary = _main._run_store.read()
	check(
		(
			not read.is_empty()
			and read.get("level") == PrologueProgressPlan.FIRST_CHAPTER
			and not read.get("chapter_complete", true)
		),
		"actual durable slot is first-chapter entry, never chapter completion"
	)
	check(
		GameState.deaths == 0 and not GameState.world_flags.get("ch1_dinner_done", false),
		"first chapter remains uncompleted and first real death unconsumed"
	)
	await _shot("first-chapter-entry")
	# Continue with actual physical movement into genuine authored dinner trigger; no producer seeding.
	_level = chapter
	AimInput.set_virtual_gamepad(chapter.player, true)
	if await _walk_x(82.5 * 16.0, 30):
		check(
			await _wait(
				func() -> bool: return GameState.world_flags.get("ch1_dinner_done", false), 100
			),
			"actual first-chapter dinner remains independently playable through its true trigger"
		)
	await _shot("actual-dinner-route")
	_finish()


func _normal() -> bool:
	if not await _event("p01_information", 90):
		return false
	if not await _walk_station(&"table", 15) or not await _event("move", 5):
		return false
	await _interact(&"old_k")
	if not await _event("p02_information", 90):
		return false
	if not await _walk_x(632, 12):
		return false
	Input.action_press(&"move_right")
	Input.action_press(&"jump")
	if not await _wait(
		func() -> bool:
			return (
				_level.player.global_position.x
				>= _session._stations[&"tools"].global_position.x - 4
			),
		4
	):
		return false
	_release(&"move_right")
	_release(&"jump")
	if not await _event("jump", 5):
		return false
	await _interact(&"tools")
	if not await _event("tools_taken", 5) or not await _event("p03_information", 90):
		return false
	var formal := _session.formal_loadout()
	check(
		(
			_level.run_snapshot()["loadout"] == formal
			and _level.player.loadout == _session.player.loadout
		),
		"borrowed actual same Loadout preserves ordinary save projection"
	)
	await _shot("borrowed-pistol")
	if not await _walk_x(_session._stations[&"low_target"].global_position.x - 38, 12):
		return false
	_aim(_session._stations[&"low_target"].hitbox.center())
	Input.action_press(&"shoot")
	if not await _event("shoot", 7):
		return false
	_release(&"shoot")
	if not await _event("p03_feedback", 90):
		return false
	if _mode == "loan-death-pistol":
		return await _loan_death_retry(&"pistol")
	await _interact(&"gun_return")
	if not await _event("gun_returned", 5) or not await _event("p04_information", 90):
		return false
	await _interact(&"knife")
	if not await _event("knife_taken", 5):
		return false
	if _mode == "loan-death-knife":
		return await _loan_death_retry(&"knife")
	if not await _walk_x(_session._stations[&"rubber_target"].global_position.x - 18, 12):
		return false
	_aim(_session._stations[&"rubber_target"].hitbox.center())
	await _tap(&"melee")
	if not await _event("melee", 8):
		return false
	if not await _walk_station(&"guard", 10):
		return false
	var before_training_health: int = _level.player.health.current
	var before_training_deaths: int = GameState.deaths
	_aim(_level.player.aim_origin() + Vector2(-80, 0))
	_release(&"block")
	await _interact(&"guard")
	if not await _event("training_fall_shown", 90):
		return false
	check(
		(
			_level.player.health.current == before_training_health
			and GameState.deaths == before_training_deaths
			and not _session.world().get(PrologueProgressPlan.PREFIX + "guard", false)
		),
		"actual unguarded trainer contact completes harmless recovery without health, death or fake guard credit"
	)
	await _shot("actual-harmless-recovery")
	_aim(_level.player.aim_origin() + Vector2(80, 0))
	await _interact(&"guard")
	Input.action_press(&"block")
	if not await _event("guard", 5):
		return false
	_release(&"block")
	await _shot("actual-front-guard")
	if not await _walk_x(_session._stations[&"dash"].global_position.x - 24, 12):
		return false
	await _tap(&"interact")
	if not await _wait(func() -> bool: return _session._stations[&"dash"].indicator, 3):
		return false
	Input.action_press(&"move_right")
	await _tap(&"dash")
	if not await _event("dash", 4):
		return false
	_release(&"move_right")
	await _interact(&"tools_return")
	if not await _event("tools_returned", 6):
		return false
	await _interact(&"old_k")
	if not await _event("p05_information", 100):
		return false
	for pair: Array in [
		[&"tape", "p06_tape_returned"], [&"latch", "p06_latch_closed"], [&"light", "p06_light_off"]
	]:
		await _interact(pair[0])
		if not await _event(pair[1], 7):
			return false
	if not await _event("p06_contact", 100):
		return false
	await _shot("p06-cleanup-contact")
	await _interact(&"exit")
	if _mode == "normal-write-retry":
		var old_bytes := FileAccess.get_file_as_bytes(_saved_slot)
		_main._run_store.path = _out.path_join("missing-directory/slot.json")
		await _button(_session._panel._confirm)
		check(
			(
				_main._screen == _level
				and _session._pending != null
				and not _session.world().get(PrologueProgressPlan.PREFIX + "exited", false)
				and FileAccess.get_file_as_bytes(_saved_slot) == old_bytes
			),
			"real exit writer refusal keeps original Level, authorities, tools and old complete slot"
		)
		await _shot("exit-write-refusal")
		_main._run_store.path = _saved_slot
		await _button(_session._panel._retry)
	else:
		await _button(_session._panel._confirm)
	return true


## Deliberate genuine lethal test, NOT a harmless lesson failure or a seeded death.
func _loan_death_retry(kind: StringName) -> bool:
	if not await _wait(func() -> bool: return _session._idle_story(), 30):
		return false
	for action: StringName in [&"move_left", &"move_right", &"shoot", &"melee", &"block", &"jump", &"dash"]:
		_release(action)
	var old_level := _level
	var old_level_id := old_level.get_instance_id()
	var formal := _session.formal_loadout()
	var borrowed := _level.player.checkpoint_snapshot()
	var world := _session.world()
	var before_deaths := GameState.deaths
	check(borrowed != formal, "negative control: actual borrowed loadout differs from retained formal " + String(kind))
	if borrowed == formal:
		return false
	var damage := DamageInfo.create(_level.player.health.current, Combat.Team.ENEMY, &"st16_regression_lethal")
	damage.ignore_invulnerability = true
	check(_level.player.hurtbox.receive(damage) == Hurtbox.Result.DAMAGED,
		"real Hurtbox/Health damage reaches genuine Player death while borrowing " + String(kind))
	check(old_level.died and old_level.player.is_dead() and GameState.deaths == before_deaths + 1,
		"genuine prologue death is registered exactly once, separate from harmless training failure")
	check(GameState.checkpoint_loadout == formal and GameState.checkpoint_loadout != borrowed,
		"actual death world policy retains formal projection and refuses borrowed checkpoint")
	var saved: Dictionary = _main._run_store.read()
	check(not saved.is_empty() and saved["runtime"]["dead"]
		and saved["state"]["checkpoint_loadout"] == saved["runtime"]["loadout"],
		"genuine critical save keeps consistent formal runtime/checkpoint after death")
	if saved.is_empty():
		return false
	if not await _wait(func() -> bool: return _revealed_death_screen(old_level) != null, 30):
		return false
	var screen := _revealed_death_screen(old_level)
	await _shot("borrowed-" + String(kind) + "-death")
	var retry := _find_button(screen, "從檢查點重來")
	if retry == null:
		retry = _find_button(screen, "重新開始關卡")
	await _button(retry)
	if not await _wait(func() -> bool:
		return (is_instance_valid(_main._screen) and _main._screen is Level and _main._screen.get_instance_id() != old_level_id
			and (_main._screen as Level).is_initialized() and not Transition.is_active()), 45):
		return false
	_level = _main._screen
	_session = _level.prologue
	check(is_instance_valid(_session) and _session.live(), "actual Main retry rebuilt the Level-owned loan service")
	if not is_instance_valid(_session):
		return false
	var canonical_formal: Dictionary = saved["runtime"]["loadout"]
	check(_session.formal_loadout() == canonical_formal and _level.run_snapshot()["loadout"] == canonical_formal,
		"new real Player/PrologueLoan binds formal checkpoint, not old borrowed weapon")
	check(_session.world() == world and GameState.deaths == before_deaths + 1,
		"true retry preserves observed lesson world without manufacturing training or second death")
	check(_session._loan.is_borrowing(_session.flow.pistol if kind == &"pistol" else _session.flow.knife),
		"actual saved lesson reapplies loan only as temporary presentation after real retry")
	if not await _wait(func() -> bool: return _session._idle_story() and not Transition.is_active(), 30):
		return false
	# No active cleanup call. Production PauseMenu -> Main save/gates -> Level exit owns retirement.
	var retirement := {"session_exit_observed": false, "level_exit_observed": false}
	var leaving_session: WeakRef = weakref(_session)
	var leaving_player: WeakRef = weakref(_level.player)
	var leaving_level: WeakRef = weakref(_level)
	_session.tree_exiting.connect(
		_observe_session_exit.bind(retirement, leaving_session, leaving_player, canonical_formal.duplicate(true)),
		CONNECT_ONE_SHOT)
	_level.tree_exiting.connect(_observe_level_exit.bind(retirement), CONNECT_ONE_SHOT)
	await _tap(&"pause")
	var menu_button := _find_button(_level._pause_menu, "回主選單")
	await _button(menu_button)
	if not await _wait(func() -> bool:
		return (is_instance_valid(_main._screen) and _main._screen is MainMenu
			and not Transition.is_active() and leaving_level.get_ref() == null), 45):
		return false
	check(retirement.get("session_exit_observed", false) and retirement.get("level_exit_observed", false),
		"genuine PauseMenu/Main lifecycle removed the actual Level and observation service")
	check(retirement.get("actual_loadout") == canonical_formal,
		"actual loan retirement restores exact formal equipment after death retry")
	check(retirement.get("disposed", false) and retirement.get("loan_closed", false)
		and retirement.get("loan_player_released", false) and retirement.get("proofs_empty", false)
		and retirement.get("pending_released", false) and leaving_session.get_ref() == null
		and leaving_player.get_ref() == null,
		"production Level exit retired the loan and all observation leases without holding removed nodes")
	check(retirement.get("checkpoint_loadout") == canonical_formal
		and GameState.checkpoint_loadout == canonical_formal,
		"genuine menu lifecycle never wrote temporary loan into formal checkpoint")
	var menu_saved: Dictionary = _main._run_store.read()
	check(not menu_saved.is_empty() and not menu_saved["runtime"]["dead"]
		and menu_saved["runtime"]["loadout"] == canonical_formal
		and menu_saved["state"]["checkpoint_loadout"] == canonical_formal,
		"normal Main menu save path durably retained live formal runtime and checkpoint projection")
	check(not menu_saved.is_empty() and menu_saved["runtime"]["world"] == world,
		"menu save preserved only genuinely observed lesson world")
	_rows.append({"event": "actual-death-retry-menu-retirement", "kind": String(kind),
		"retirement": retirement, "saved_loadout": menu_saved.get("runtime", {}).get("loadout", {}),
		"elapsed_msec": Time.get_ticks_msec() - _start})
	_death_retry_finished = true
	await _shot("borrowed-" + String(kind) + "-retry-menu")
	return true


## Godot emits tree_exiting AFTER _exit_tree; this observer never triggers cleanup or mutation.
func _observe_session_exit(record: Dictionary, session_ref: WeakRef, player_ref: WeakRef, formal: Dictionary) -> void:
	var session: Variant = session_ref.get_ref()
	var player: Variant = player_ref.get_ref()
	record["session_exit_observed"] = true
	record["disposed"] = is_instance_valid(session) and session._disposed
	record["loan_closed"] = is_instance_valid(session) and session._loan._closed
	record["loan_player_released"] = is_instance_valid(session) and session._loan._player == null
	record["proofs_empty"] = is_instance_valid(session) and session._proofs.is_empty()
	record["pending_released"] = is_instance_valid(session) and session._pending == null and session._expected_station == null
	record["actual_player_inside_tree"] = is_instance_valid(player) and player.is_inside_tree()
	record["actual_loadout"] = player.checkpoint_snapshot() if is_instance_valid(player) else {}
	record["checkpoint_loadout"] = GameState.checkpoint_loadout.duplicate(true)
	record["expected_formal"] = formal


func _observe_level_exit(record: Dictionary) -> void:
	record["level_exit_observed"] = true


func _revealed_death_screen(level: Level) -> DeathScreen:
	if not is_instance_valid(level):
		return null
	for child: Node in level.get_children():
		if child is DeathScreen and child.sequence_complete and _revealed_death_nodes(child):
			return child
	return null


func _revealed_death_nodes(node: Node) -> bool:
	if node is CanvasItem and node.material is ShaderMaterial:
		var shader: Shader = (node.material as ShaderMaterial).shader
		if shader != null and shader.resource_path == DeathScreen.NOISE_SHADER:
			return false
	if node is UiPanel and (node.modulate.a < 0.999 or not node.scale.is_equal_approx(Vector2.ONE)):
		return false
	for child: Node in node.get_children():
		if not _revealed_death_nodes(child):
			return false
	return true


func _interact(id: StringName) -> void:
	if not await _walk_station(id, 30):
		return
	await _tap(&"interact")


func _walk_station(id: StringName, seconds: float) -> bool:
	return await _walk_x(_session._stations[id].global_position.x, seconds)


func _walk_x(x: float, seconds: float) -> bool:
	var deadline := Time.get_ticks_msec() + int(seconds * 1000)
	while (
		Time.get_ticks_msec() < deadline and is_instance_valid(_level) and _level.is_inside_tree()
	):
		var offset := x - _level.player.global_position.x
		if absf(offset) <= 3:
			_release(&"move_left")
			_release(&"move_right")
			for i in 4:
				await _tick()
			return true
		if not GameplayLock.is_locked() and not get_tree().paused:
			Input.action_press(&"move_right" if offset > 0 else &"move_left")
			_release(&"move_left" if offset > 0 else &"move_right")
		await _tick()
	_release(&"move_left")
	_release(&"move_right")
	check(false, "physical movement timeout at x %.2f" % x)
	return false


func _event(event: String, seconds: float) -> bool:
	var found := await _wait(
		func() -> bool:
			return (
				is_instance_valid(_session)
				and _session.world().get(PrologueProgressPlan.PREFIX + event, false)
			),
		seconds
	)
	_rows.append(
		{
			"event": event,
			"observed": found,
			"world": _session.world() if is_instance_valid(_session) else {},
			"elapsed_msec": Time.get_ticks_msec() - _start
		}
	)
	return found


func _wait(predicate: Callable, seconds: float) -> bool:
	var end := Time.get_ticks_msec() + int(seconds * 1000)
	while Time.get_ticks_msec() < end:
		if predicate.call():
			return true
		await _tick()
	check(false, "actual predicate timeout after %.1f seconds" % seconds)
	return false


func _tick() -> void:
	# Drive genuine dialogue UI input, never call finish/cancel or Story methods.
	if (Story.is_cinematic_active() or DialogueLayer.radio_visible()) and Time.get_ticks_msec() - _last_accept > 650:
		_last_accept = Time.get_ticks_msec()
		var e := InputEventAction.new()
		e.action = &"ui_accept"
		e.pressed = true
		Input.parse_input_event(e)
	await get_tree().process_frame
	var release := InputEventAction.new()
	release.action = &"ui_accept"
	release.pressed = false
	Input.parse_input_event(release)


func _tap(action: StringName) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = true
	Input.parse_input_event(event)
	await get_tree().physics_frame
	event = InputEventAction.new()
	event.action = action
	event.pressed = false
	Input.parse_input_event(event)
	await get_tree().process_frame


func _release(action: StringName) -> void:
	Input.action_release(action)


func _button(button: Button) -> void:
	if not is_instance_valid(button) or not button.is_visible_in_tree() or button.disabled:
		check(false, "actual visible enabled button required")
		return
	button.grab_focus()
	await _tap(&"ui_accept")


func _find_button(owner: Node, title: String) -> Button:
	for child: Node in owner.get_children():
		if child is Button and child.text == title:
			return child
		var found := _find_button(child, title)
		if found != null:
			return found
	return null


func _aim(target: Vector2) -> void:
	var direction := (target - _level.player.aim_origin()).normalized()
	for action: StringName in [&"aim_left", &"aim_right", &"aim_up", &"aim_down"]:
		_release(action)
	Input.action_press(&"aim_right" if direction.x >= 0 else &"aim_left", absf(direction.x))
	Input.action_press(&"aim_down" if direction.y >= 0 else &"aim_up", absf(direction.y))


func _shot(label: String) -> void:
	if _shots >= 10:
		return
	await RenderingServer.frame_post_draw
	var image: Image = Capture.image(get_viewport())
	var file := _out.path_join("ST16-%02d-%s.png" % [_shots, label])
	check(image != null and image.save_png(file) == OK, "actual native PNG %s" % label)
	image = null
	_shots += 1


func _finish() -> void:
	for action: StringName in [
		&"move_left",
		&"move_right",
		&"jump",
		&"dash",
		&"shoot",
		&"melee",
		&"block",
		&"aim_left",
		&"aim_right",
		&"aim_up",
		&"aim_down"
	]:
		_release(action)
	if is_instance_valid(_level) and is_instance_valid(_level.player):
		AimInput.set_virtual_gamepad(_level.player, false)
	var source_unchanged := true
	for path: String in _source_hashes:
		if FileAccess.get_sha256("res://" + path) != _source_hashes[path]:
			source_unchanged = false
	check(
		source_unchanged and FileAccess.get_sha256("res://core/run_snapshot.gd") == SNAPSHOT_SHA,
		"protected source unchanged throughout actual native run"
	)
	var report := {
		"baseline": _baseline,
		"source_sha256": _source_hashes,
		"mode": _mode,
		"classification":
		"synthetic inputs; genuine Main/newrun/formal Level/Player/durable writer; no hardware/full chapter claim",
		"checks": _checks,
		"failures": _failures,
		"rows": _rows,
		"shots": _shots,
		"elapsed_msec": Time.get_ticks_msec() - _start,
		"renderer": RenderingServer.get_current_rendering_method(),
		"os_ram": "launcher only; Performance static is not OS memory",
		"capabilities": []
	}
	if _out.is_absolute_path():
		var file := FileAccess.open(_out.path_join("ST16-report.json"), FileAccess.WRITE)
		if file != null:
			file.store_string(JSON.stringify(report, "  "))
			file.close()
	print("ST16_END checks=%d failures=%d" % [_checks, _failures.size()])
	var exit_code := 0 if _failures.is_empty() else 1
	if is_instance_valid(_main):
		if not _saved_slot.is_empty():
			_main._run_store.path = _saved_slot
		_main._quit(exit_code)  # Real production save -> cancel -> Transition.abort -> screen cleanup.
	else:
		get_tree().quit(exit_code)
