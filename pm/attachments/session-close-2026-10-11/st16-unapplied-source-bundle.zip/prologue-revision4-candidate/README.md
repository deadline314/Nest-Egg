# ST16 revision4：真 Main 退場觀測

工具候選，未採用、未啟引擎，repo／產品來源／PM／Git 均未修改。revision3 freeze `345c2a0aee54610b77346d8c269b868564f8737740dfdf9903fa98cc556b4e30` 的 27 個 artifacts 逐一核對保持原 bytes。兩個已接受產品修復不更動。

唯一 patch 是 `tools/prologue_entry_probe.gd`，精確 preimage `9c4ab3d8389fa1135cd28754b8f5e91d15273fdc849e9eb9d23f6a940c599f8d`。採用 revision3 後，再套本包唯一窄 diff；不替換任何 Main／Level／Loan／RunSnapshot／Story 來源。

## 修正

- `_main: Node` 的動態 store.read 結果明列 `var saved: Dictionary`，避免 Variant 推型警告。
- 移除主動 `_session._loan.close()`。真正死亡、critical save、可見 DeathScreen 按鈕、Main retry、新實際 Player 借装重新綁定等原檢查保持；其後送真 pause，對可見「回主選單」Button 送實際 ui_accept。由 PauseMenu→Level menu_requested→Main正常保存與radio gate→Transition→remove_child 觸發真 Session／Level 退出。
- observer 僅透過 WeakRef 讀取 Session、Player 與既有 loan，不執行 close/free/install/write，也不保存 Node 到報表。CONNECT_ONE_SHOT 的 Session.tree_exiting 記錄正式裝備是否已恢復、disposed／loan_closed／player WeakRef／proofs／pending，Level.tree_exiting 記錄真退場。
- [Godot Node 文件](https://docs.godotengine.org/en/stable/classes/class_node.html#class-node-signal-tree-exiting) 定義 tree_exiting 在該節點 `_exit_tree()` 後發送，因此是對產品 cleanup 的觀測點。若真 Player 已先退出導致 restoration 未发生，actual snapshot/assert 必須失敗，不改工具時序來假裝通過。
- 等實際 MainMenu、Transition inactive、舊 Level WeakRef null 後，才檢查觀測值與 Session／Player 已釋放、checkpoint 保持正式投影、真 store.read 的 runtime／checkpoint loadout 與原 canonical formal 相等、實際 lesson world 未變。截圖改為真主選單；不再把直接 close 稱為 Level 生命周期。

## 原保留與待驗

原 normal／normal-write-retry／whole-skip、所有既有输入／revealed DeathScreen／捕捉／退出 predicates 與 assertion 保留。新增兩個 loan-death 模式原真死亡主鏈不變，只改其最後退場驗證。此是一次真正 menu 保存／退場候選，**不是獨立 cold Continue、再次進遊戲、quit失敗恢復、P06出口或完整章節驗收**；這些仍待 Root 原生。Root 的 BG31 新遊戲 RID 尚待診斷，工具不能略過 ERROR 或宣稱通過。

CPU 58 項来源／保留檢查通過；1個 GD grammar clean，沒有 Godot semantic 或原生行為结果。未設定 PYTHONPATH 的一次 gdtoolkit 環境失敗保留 `gdparse-environment-attempt.json`；正確工具路徑下 final grammar clean。capabilities 仍空。

`native-source-manifest.json` 99個 source SHA 僅 probe post 更新；protected Snapshot 保持 `78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c`。launcher 與 revision3 同 bytes，沒有執行。Root 採用後若來源另改，需另立精確 manifest，不跳 SHA、ERROR／RID 檢查或原 selector。
