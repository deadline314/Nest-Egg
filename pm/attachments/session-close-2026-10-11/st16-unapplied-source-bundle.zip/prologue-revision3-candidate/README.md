# ST16 revision3：存檔版本鎖與死亡借裝隔離

這是 CPU 暫存候選；未改 repo、未執行 Godot、未更新票務。原 56f8／07c9 凍結包保持不動。此次只修兩個已審查邊界，保護 RunSnapshot 原位元組 `78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c`，不新增任何 capability。

## 根因與窄修

1. 原 `PrologueRunPort.prepare_snapshot` 先檢查教程資料，再呼叫 `RunSnapshot.prepare`。當 payload 是未來版本且 lesson 錯誤，回傳的是普通 lesson error，丟掉 `unknown_version`；實際 RunSaveStore.read 可因此讀取舊備份。新版本先呼叫既有 RunSnapshot，錯誤 Dictionary 原樣返回；成功後仍檢查 **原 raw** 三副本、嚴格 bool、未知 leaf、退出位置，最後返回同一 prepared。未以 tolerant world 結果取代原資料檢查，也沒有自行製作 raw tree 診斷。
2. 原 Level 死亡把 `player.checkpoint_snapshot()` 寫進 `GameState.checkpoint_loadout`；Main retry 再把它放進新 Player runtime。新 PrologueLoan.bind 因此把借槍／刀記成正式裝備。新 `_checkpoint_loadout_snapshot` 僅在精確正式序章 Resource、真子 Session、同 Level／Player／Flow、ready 且未 dispose 時取既有 loan 正式投影；不用 alive-only `live()`，因真正死亡時它必為 false。一般 Level 完全保留舊 snapshot fallback。死亡、電話 checkpoint、portal、章末 carry、run_snapshot 共用此投影，沒有新增裝備 owner。

## 採用順序

先完成原 NE246＋ST16 latest 的合成順序，再採本包 `patch-index.json` 五個 GD patch（四個 existing、一個新 helper），以及新 launcher。Main／Story／Source／Port authority／RunSnapshot／Player／Visual／rig／動作資料均無此次替換。Level patch 精確基於 07c9 合成 post，其他 preimage 見 index。若 Root 已修改任一 preimage，先做窄合成並另立來源 manifest，不覆蓋其後續改動。

## 有意義回歸候選

`tests/helpers/prologue_revision3_checks.gd` 由原 RunSave helper 的同一 run 接入，全部原 assertion 保留：

- 真 outer envelope v1，payload version2 或 release demo-0.2，加錯誤 lesson 整數；真合法 .bak。實際 Store.read 必須 empty／unknown_version／無 last_validated_raw；write 未授新輪必 false；主檔與備份完整內容不變。
- 真有限小型深度超預算 raw 加錯 lesson，必保留 RunSnapshot 原 error。四個 owner proof 與 GameState state 不變；不呼叫 apply、補 flags 或更動 wallet/custody。
- `loan-death-pistol`：真新遊戲走到借槍，真射擊使借槍 ammo 與正式 snapshot 不同，完成原 P03 回饋後才測死亡。
- `loan-death-knife`：真新遊戲走到借刀，使用不同正式武器集合做負控制。兩模式都透過真正 Hurtbox lethal Damage、Player/Level 死亡、critical save、已 reveal 的 DeathScreen 真按鈕、Main retry，核新 Level 真 PrologueLoan 正式投影與 temporary loan 分離。最後對真 loan retirement 核裝備還原；這不是 P06 完整通關驗收。
- 沒有 fake completion/source/flags/seen/caps、直接 emits 死亡訊號、灌 health/deaths；真正故意致死會增加一次死亡，與原正常路線的無傷訓練失誤測試分開。

五個 GD grammar clean。CPU 來源／保留原檢查有 52 項通過，**不是 52 項原生行為測試**。第一次 probe grammar 多行 lambda 缺括號的 raw 保留 `gdparse-attempt1.json`，已修在工具候選；沒有 engine raw 可聲稱。

## Root 原生指令與限制

`run_native.py` 不帶 --execute 只列命令；99 個 source SHA／Snapshot guard／fresh profile／實際 direct exe PID 的記憶體監測與完整 raw／RID 判定沿原 launcher。Root 取得 engine 名額後才 execute，例如：

```powershell
python C:/tmp/prologue-revision3-candidate/run_native.py --root <adopted-tree> --out C:/tmp/st16-r3-death-knife --baseline <actual-40hex-HEAD> --mode loan-death-knife --execute
```

原 normal／normal-write-retry／whole-skip 模式保留。兩個新增模式不聲稱 whole chapter、冷接續或手把通過。原 selector 仍須如實執行，不能修改 registry／filter／known failures。Root 若在採用後增加來源，需立新準確 manifest；不關來源 SHA guard。

## 冷接續、選單、死亡驗收矩陣

本包已準備兩個真死亡重試模式；尚未執行。下一階段冷接續應用借槍與借刀各自正常真流程，在 Story／Transition settled 時實際暫停→選單→退出；保留實際 slot bytes＋來源 SHA，再第二獨立 process 從真 Main Continue 讀同 bytes。核 Level 初始化前的 loadout 是正式、Session.activate 才依真世界重套借裝、正式 projection 不變、P06 committed 出口還原正式裝備。不得 seed lesson、copy unrelated slot 或靠本 process 計數冒充 cold。選單與 quit 保存都須核無借装進 checkpoint/正式 loadout；cold 模式、完整 P06 再玩、借裝耗材規則及第一真死亡診間回歸仍待 Root 原生排程，不擴造新權威。

美術／家具／P01 路人與排水／恢復姿勢與完整章節的原限制照舊，未因此採用或完成 ST16。
