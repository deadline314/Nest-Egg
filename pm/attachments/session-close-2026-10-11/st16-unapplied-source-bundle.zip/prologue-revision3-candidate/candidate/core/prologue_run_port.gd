class_name PrologueRunPort
extends RefCounted
## One actual Main/Level, existing fixed RunSaveStore. No second owner or wallet.
var _owner: WeakRef
var _busy := false
var _pending: Array[Dictionary] = []
var dirty := false


func configure(main: Node) -> void:
	_owner = weakref(main)


func is_busy() -> bool:
	return _busy


func defer_lifecycle(method: StringName, arguments: Array = []) -> bool:
	if not _busy:
		return false
	var action := {"method": method, "arguments": arguments}
	if not _pending.has(action):
		if _pending.size() < 16:
			_pending.append(action)
		else:
			push_error("[PrologueRun] lifecycle queue full; durable record retained")
	return true


static func prepare_snapshot(raw: Dictionary) -> Dictionary:
	# Preserve codec budgets and unsupported-version locks before reading lesson data.
	var prepared := RunSnapshot.prepare(raw)
	if prepared.has("error"):
		return prepared
	# Inspect ORIGINAL raw leaves, never the tolerant normalized world copies.
	if raw.get("level") == PrologueProgressPlan.LEVEL:
		if not raw.get("runtime") is Dictionary or not raw.get("state") is Dictionary:
			return {"error": "序章完整保存缺少世界資料。"}
		for key in ["area", "world"]:
			if not raw["runtime"].get(key, {}) is Dictionary:
				return {"error": "序章世界資料型別無效。"}
		if not raw["state"].get("area_states", {}) is Dictionary:
			return {"error": "序章區域資料型別無效。"}
		var saved_area: Variant = raw["state"].get("area_states", {}).get(
			"st16_pawnshop_training", {}
		)
		if not saved_area is Dictionary:
			return {"error": "序章區域資料型別無效。"}
		var lessons: Array[Dictionary] = []
		for world: Variant in [
			raw.get("runtime", {}).get("world", {}),
			raw.get("runtime", {}).get("area", {}).get("world", {}),
			raw.get("state", {}).get("area_states", {}).get("st16_pawnshop_training", {}).get(
				"world", {}
			)
		]:
			if not world is Dictionary:
				return {"error": "序章保存的訓練狀態格式不符；原檔保留。"}
			var checked := PrologueProgressPlan.prepare_world(world)
			if checked.has("error"):
				return checked
			lessons.append(checked["world"])
		if lessons[0] != lessons[1] or lessons[0] != lessons[2]:
			return {"error": "序章訓練紀錄不一致；不套用半份進度。"}
	var states: Variant = (
		raw.get("state", {}).get("area_states", {}) if raw.get("state") is Dictionary else {}
	)
	if states is Dictionary and states.has("st16_pawnshop_training"):
		var area: Variant = states["st16_pawnshop_training"]
		if not area is Dictionary or not area.get("world", {}) is Dictionary:
			return {"error": "序章保存的區域資料無效。"}
		var checked := PrologueProgressPlan.prepare_world(area.get("world", {}))
		if checked.has("error"):
			return checked
		if (
			raw.get("level") == PrologueProgressPlan.LEVEL
			and checked["world"][PrologueProgressPlan.PREFIX + "exited"]
		):
			return {"error": "序章已退出，但保存位置仍在序章；原檔保留。"}
	return prepared


func _actual(
	main: Node, level: Level, session: PrologueSession, proof: PrologueSession.Evidence
) -> bool:
	return (
		is_instance_valid(main)
		and main._active_run
		and not main._quitting
		and not main._destination_pending
		and not main._publishing_restore
		and not main._restore_publish_pending
		and main._screen == level
		and main._level_path == PrologueProgressPlan.LEVEL
		and is_instance_valid(level)
		and level.is_inside_tree()
		and not level.is_queued_for_deletion()
		and level.data.resource_path == PrologueProgressPlan.LEVEL
		and level._persistent
		and level.data.prologue_flow == session.flow
		and level.prologue == session
		and session.valid(proof)
		and session.flow.destination == PrologueProgressPlan.FIRST_CHAPTER
	)


func _source(main: Node, level: Level, session: PrologueSession) -> Dictionary:
	var owners := StoryInstallBundle._capture_source()
	if owners.has("error"):
		return owners
	return {
		"data":
		var_to_bytes(
			[
				owners["data"],
				main._level_path,
				main._active_run,
				main._quitting,
				main._destination_pending,
				main._screen.get_instance_id(),
				level._layout.get_instance_id(),
				session.world(),
				session.formal_loadout()
			]
		)
	}


func commit(
	level: Level,
	session: PrologueSession,
	proof: PrologueSession.Evidence,
	exiting: bool,
	skip: bool
) -> Dictionary:
	var main: Node = _owner.get_ref() if _owner != null else null
	if _busy or (is_instance_valid(main) and main._story_port.is_busy()) or Transition.is_active():
		return {"status": "busy"}
	if (
		not _actual(main, level, session, proof)
		or (proof.kind == &"skip") != skip
		or exiting != (proof.kind in [&"exit", &"skip"])
	):
		return {"status": "invalid_source"}
	if proof.kind == &"interaction" and not proof.overlap_at_issue:
		return {"status": "invalid_overlap"}
	if (
		proof.kind == &"presentation"
		and (proof.request <= 0 or Story.scene_source(proof.scene) != session.flow.story_path)
	):
		return {"status": "invalid_presentation"}
	if not session._idle_story():
		return {"status": "busy"}
	_busy = true
	var result := _prepare_commit(main, level, session, proof, exiting, skip)
	_busy = false
	for action: Dictionary in _pending:
		main.call_deferred(&"_run_story_lifecycle", action["method"], action["arguments"])
	_pending.clear()
	if dirty:
		dirty = false
		main.call_deferred(&"_queue_save")
	return result


func _prepare_commit(
	main: Node,
	level: Level,
	session: PrologueSession,
	proof: PrologueSession.Evidence,
	exiting: bool,
	skip: bool
) -> Dictionary:
	var proposal := (
		PrologueProgressPlan.propose_exit(session.world(), skip)
		if exiting
		else PrologueProgressPlan.propose_observed(session.world(), proof.event)
	)
	if proposal.has("error"):
		return {"status": "invalid_plan", "diagnostic": proposal["error"]}
	var runtime := level.run_snapshot()
	var raw := RunSnapshot.capture(main._level_path, runtime)
	var canonical := prepare_snapshot(raw)
	if canonical.has("error"):
		return {"status": "invalid_base", "diagnostic": canonical["error"]}
	var decoded := RunSaveCodec.decode(RunSaveCodec.encode(canonical["data"]))
	if decoded.has("error"):
		return {"status": "invalid_base"}
	var candidate: Dictionary = decoded["data"]
	var world: Dictionary = candidate["runtime"]["world"]
	world.merge(proposal["patch"], true)
	candidate["runtime"]["area"]["world"] = world.duplicate(true)
	candidate["state"]["area_states"][String(level.data.id)] = (
		candidate["runtime"]["area"].duplicate(true)
	)
	if exiting:
		candidate["level"] = session.flow.destination
		candidate["cinematic"] = ""
		candidate["cinematic_context"] = {}
		candidate["chapter_complete"] = false
		candidate["state"]["current_level_path"] = session.flow.destination
		candidate["state"]["pending_portal"] = ""
		var destination := load(session.flow.destination) as LevelData
		if destination == null:
			return {"status": "invalid_destination"}
		var area: Dictionary = (
			candidate["state"]["area_states"]
			. get(String(destination.id), {"world": {}, "consumed": {}, "damage": {}})
			. duplicate(true)
		)
		var destination_runtime: Dictionary = candidate["runtime"].duplicate(true)
		destination_runtime.merge(
			{
				"position": [-1, -1],
				"velocity": [0, 0],
				"loadout": session.formal_loadout(),
				"world": area["world"].duplicate(true),
				"area": area,
				"dead": false,
				"death_entry": {},
				"arena": false,
				"boss_pending": false,
				"ending": false,
				"can_continue": true,
				"loose": [],
				"enemies": [],
				"encounters": {}
			},
			true
		)
		candidate["runtime"] = destination_runtime
	var source := _source(main, level, session)
	if source.has("error"):
		return {"status": "invalid_owner", "diagnostic": source["error"]}
	var preparation: Dictionary = main._run_store.prepare_existing_write(candidate)
	if preparation.has("error"):
		push_warning("[PrologueRun] %s" % preparation["error"])
		return {"status": "writer_rejected"}
	var prepared: RunSaveStore.PreparedExistingWrite = preparation["data"]
	var actual := prepared.snapshot()
	var differences := StoryRunCommitPort._preparation_differences(candidate, actual)
	if (
		not differences.is_empty()
		or not _actual(main, level, session, proof)
		or source != _source(main, level, session)
	):
		return {"status": "stale_or_changed_preparation", "diagnostic": differences}
	var outcome: RunSaveStore.DurableWriteOutcome = main._run_store.commit_existing_write(prepared)
	if not outcome.committed:
		push_warning("[PrologueRun] write rejected at %s; old Level retained" % outcome.stage)
		return {"status": "writer_rejected"}
	# Durable commit is the first authoritative mutation. No signal during installation.
	var installed: Dictionary = actual["state"]["area_states"][String(level.data.id)].duplicate(
		true
	)
	GameState.area_states[String(level.data.id)] = installed
	level._area = installed
	session.install_world(installed["world"])
	if exiting:
		GameState.current_level_path = session.flow.destination
		GameState.pending_portal = &""
		main._destination_pending = true
	# All authorities and new-area alias are settled before visuals/listeners.
	session.publish_world()
	if exiting:
		main.call_deferred(
			&"_prologue_leave_committed",
			weakref(level),
			session.flow.destination,
			actual["runtime"].duplicate(true)
		)
	return {"status": "committed", "checksum": outcome.checksum}
