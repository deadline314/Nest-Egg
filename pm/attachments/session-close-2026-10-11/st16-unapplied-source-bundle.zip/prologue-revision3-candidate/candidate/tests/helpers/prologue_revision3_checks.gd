extends RefCounted
## Runtime regression candidate: actual codec/store, no owner installation or seeded authority.


static func run(suite: TestSuite, snapshot: Dictionary) -> void:
	var owners := StoryInstallBundle._capture_source()
	suite.check(not owners.has("error"), "owner unchanged regression begins with a real valid four-owner proof")
	if owners.has("error"):
		return
	var state := RunSnapshot.capture(PrologueProgressPlan.LEVEL, snapshot["runtime"].duplicate(true))
	var valid := RunSaveCodec.decode(RunSaveCodec.encode(snapshot))
	suite.check(valid.has("data"), "revision3 backup is an actual codec-readable complete run")
	if not valid.has("data"):
		return
	for future_key: String in ["version", "release"]:
		var future: Dictionary = valid["data"].duplicate(true)
		future[future_key] = RunSaveCodec.VERSION + 1 if future_key == "version" else "demo-0.2"
		future["runtime"]["world"][PrologueProgressPlan.PREFIX + "p01_information"] = 1
		var original_error := RunSnapshot.prepare(future)
		var port_error := PrologueRunPort.prepare_snapshot(future)
		suite.check(
			original_error.get("unknown_version", false) and port_error == original_error,
			"future run with malformed lesson preserves exact unsupported-version refusal: " + future_key
		)
		var path := "user://st16-revision3/%s-%d.json" % [future_key, Time.get_ticks_usec()]
		var absolute := ProjectSettings.globalize_path(path)
		var fresh := not FileAccess.file_exists(path) and not FileAccess.file_exists(path + ".bak")
		suite.check(fresh and DirAccess.make_dir_recursive_absolute(absolute.get_base_dir()) == OK,
			"future-version test owns a fresh isolated slot")
		if not fresh:
			continue
		# Envelope remains supported v1; ONLY its payload is newer, exercising our validator.
		var primary := RunSaveCodec.encode(future)
		var backup := RunSaveCodec.encode(valid["data"])
		var wrote := _write(path, primary) and _write(path + ".bak", backup)
		suite.check(wrote, "future primary and valid older backup actually reach the disk")
		if wrote:
			var store := RunSaveStore.new(path)
			store.validator = PrologueRunPort.prepare_snapshot
			var read := store.read()
			suite.check(read.is_empty() and store.unknown_version and store.last_validated_raw.is_empty(),
				"actual store locks future primary instead of downgrading to valid backup")
			suite.check(not store.write(valid["data"]), "actual writer cannot overwrite unknown primary without new-run authorization")
			suite.check(FileAccess.get_file_as_string(path) == primary
				and FileAccess.get_file_as_string(path + ".bak") == backup,
				"failed future read/write preserves both actual disk byte strings")
		for suffix: String in ["", ".bak"]:
			if FileAccess.file_exists(path + suffix):
				suite.check(DirAccess.remove_absolute(absolute + suffix) == OK, "isolated future test file cleanup")
	var deep := snapshot.duplicate(true)
	deep["runtime"]["world"][PrologueProgressPlan.PREFIX + "p01_information"] = 1
	var branch: Dictionary = deep
	for index in RunSaveCodec.MAX_DEPTH + 1:
		branch["depth"] = {}
		branch = branch["depth"]
	var bounded_error := RunSnapshot.prepare(deep)
	suite.check(bounded_error.has("error") and PrologueRunPort.prepare_snapshot(deep) == bounded_error,
		"raw tree budget failure precedes malformed lesson diagnostics with exact error")
	var original_state: Dictionary = state["state"]
	var current_state: Dictionary = RunSnapshot.capture(PrologueProgressPlan.LEVEL, snapshot["runtime"])["state"]
	suite.check(StoryInstallBundle._capture_source() == owners and current_state == original_state,
		"future lock/budget/real store refusals never install story, progression, custody or GameState owners")


static func _write(path: String, text: String) -> bool:
	if text.is_empty():
		return false
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(text)
	file.flush()
	var error := file.get_error()
	file.close()
	return error == OK
