from pathlib import Path
import difflib, hashlib, json, os, re, py_compile, subprocess
B=Path(__file__).resolve().parent;C=B/'candidate';P=B/'preimages'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def ck(v,label):
 checks.append({'passed':bool(v),'check':label})
 if not v:raise AssertionError(label)
port=(C/'core/prologue_run_port.gd').read_text('utf-8');oldport=(P/'core/prologue_run_port.gd').read_text('utf-8')
body=port.split('static func prepare_snapshot(raw: Dictionary) -> Dictionary:',1)[1].split('func _actual(',1)[0]
ck(body.index('RunSnapshot.prepare(raw)')<body.index('if raw.get("level")'), 'supported snapshot/tree/version preparation strictly before lesson access')
ck('if prepared.has("error"):\n\t\treturn prepared' in body,'unmodified error dictionary returned before lesson diagnostics')
ck(body.rstrip().endswith('return prepared'), 'successful strict raw check returns previously prepared data')
ck(body.count('RunSnapshot.prepare(')==1,'one original preparer invocation, no re-normalization')
strictold=oldport.split('\tif raw.get("level")',1)[1].split('\treturn RunSnapshot.prepare(raw)',1)[0]
strictnew=body.split('\tif raw.get("level")',1)[1].split('\treturn prepared',1)[0]
ck(strictold==strictnew,'all original raw strict bool/consistency/terminal checks byte-equivalent')
level=(C/'game/level/level.gd').read_text('utf-8');oldlevel=(P/'game/level/level.gd').read_text('utf-8')
for condition in ['data.resource_path == PrologueProgressPlan.LEVEL','prologue.get_parent() == self','prologue.level == self','prologue.player == player','prologue.flow == data.prologue_flow','prologue._ready_ok','not prologue._disposed']:
 ck(condition in level,'formal projection ownership: '+condition)
ck('prologue.live()' not in level.split('func _checkpoint_loadout_snapshot()',1)[1].split('func _apply_death_to_world',1)[0],'dead owner policy does not require alive-only lease')
ck('return player.checkpoint_snapshot() if is_instance_valid(player) else GameState.checkpoint_loadout' in level,'ordinary Level exact previous loadout fallback retained')
for method,nextmethod in [('_apply_death_to_world','_request_menu'),('_on_portal_used','_save_area_state'),('_run_ending','_close_menus'),('run_snapshot','_capture_run_area')]:
 section=level.split('func '+method+'(',1)[1].split('func '+nextmethod+'(',1)[0]
 ck('_checkpoint_loadout_snapshot()' in section,'formal projection at '+method)
ck(level.count('player.checkpoint_snapshot()')==1,'only generic fallback can serialize live temporary equipment')
ck(not (C/'core/run_snapshot.gd').exists(),'no replacement of protected Snapshot')
ck(sha(B/'observed-source/core/run_snapshot.gd')=='78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c','protected latest Snapshot bytes match')
helper=(C/'tests/helpers/prologue_integration_checks.gd').read_text('utf-8');oldhelper=(P/'tests/helpers/prologue_integration_checks.gd').read_text('utf-8')
ck(helper.replace('\tpreload("res://tests/helpers/prologue_revision3_checks.gd").run(suite, snapshot)\n','')==oldhelper,'all existing helper assertions remain intact')
r=(C/'tests/helpers/prologue_revision3_checks.gd').read_text('utf-8')
for item in ['RunSaveCodec.encode(future)','store.read()','store.unknown_version','store.last_validated_raw.is_empty()','not store.write(valid["data"])','path + ".bak"','StoryInstallBundle._capture_source() == owners','current_state == original_state','RunSaveCodec.MAX_DEPTH + 1','original_error.get("unknown_version", false)']:
 ck(item in r,'actual runtime regression candidate: '+item)
probe=(C/'tools/prologue_entry_probe.gd').read_text('utf-8')
for item in ['loan-death-pistol','loan-death-knife','player.hurtbox.receive(damage)','old_level.died and old_level.player.is_dead()','GameState.checkpoint_loadout != borrowed','_revealed_death_screen(old_level)','await _button(retry)','_main._screen.get_instance_id() != old_level_id','_session.formal_loadout() == canonical_formal','_session._loan.is_borrowing','DeathScreen.NOISE_SHADER']:
 ck(item in probe,'actual native regression prepared: '+item)
for unsupported in ['Story.scene_finished.emit','GameState.deaths =','health.current =','Story.set_flag(','Story.auto_skip =']:
 ck(not re.search(re.escape(unsupported)+r'(?![=])',probe),'no fabricated authority/completion: '+unsupported)
for mode in ['normal','normal-write-retry','whole-skip']:
 ck(mode in probe,'original mode retained '+mode)
parsed=[]
for f in sorted(C.rglob('*.gd')):
 result=subprocess.run(['C:/tmp/ne230-python/bin/gdparse.exe',str(f)],capture_output=True,text=True,encoding='utf-8',errors='replace');parsed.append({'path':f.relative_to(C).as_posix(),'exit':result.returncode,'raw':result.stdout+result.stderr})
(B/'gdparse-final.json').write_text(json.dumps(parsed,indent=2),'utf-8');ck(all(row['exit']==0 for row in parsed),'all candidate GD grammar clean')
py_compile.compile(str(B/'run_native.py'),doraise=True)
for rel in ['game/level/level.gd','core/prologue_run_port.gd','tests/helpers/prologue_integration_checks.gd','tools/prologue_entry_probe.gd']:
 diff=''.join(difflib.unified_diff((P/rel).read_text('utf-8').splitlines(True),(C/rel).read_text('utf-8').splitlines(True),fromfile='a/'+rel,tofile='b/'+rel));dst=B/'patches'/(rel.replace('/','__')+'.diff');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(diff,'utf-8')
rel='tests/helpers/prologue_revision3_checks.gd';(B/'patches'/'tests__helpers__prologue_revision3_checks.gd.diff').write_text(''.join(difflib.unified_diff([], (C/rel).read_text('utf-8').splitlines(True),fromfile='/dev/null',tofile='b/'+rel)),'utf-8')
report={'classification':'CPU source/grammar checks only; runtime regression code prepared, not executed','checks':len(checks),'failures':0,'details':checks,'gdgrammar':len(parsed),'engine_run':False,'native_accepted':False,'capabilities':[]}
(B/'cpu-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8');print(json.dumps({k:v for k,v in report.items()if k!='details'}))
