# NE246 × ST16 composition5：兩個實際不匹配來源的窄合成

原 full56f／composition07c／revision3／revision4 都不變。原 staged preflight 真正拒絕兩個不匹配，報表與 current-vs-old diff 在 C:/tmp/prologue-staged-adoption-candidate/mismatches。這包不是改寫舊 baseline，是 Root 新授權的一次獨立合成；僅替代 full45 內的兩個 patch。

- PauseMenu 實際 preimage 57d1a2f4... 保留全部 GameplayLock menu lease、_opened、suspended focus、READING permits guard、permission death cleanup、settings/navigation source。只加 existing ST16 callback、真 Skip Button 與 close 後才開確認；新 skip 自身再次要求 allowed／opened／root visible+enabled／permits_pause_menu／非電影，不能從被 reading 隱藏的 UI 穿透。
- RunSaveSuite 實際 preimage466413ef... 保留 formal_radio_settlement_checks／formal_radio_checkpoint_checks 及全部已有 assertions/predicates，只插原 ST16 helper run；revision3 tests 由該 helper 原接點進入。

原 full patch 與其舊 pre/post 全部列在 patch-index；本包 pre/post/diff 必須供 Root 先審，不能把兩個 full 舊 preimage mismatch 隱去。Main／Level／Story／Source／RunSnapshot／27 r3／12 r4 無變。13 CPU來源／grammar檢查通過，2 GD clean；未執行 Godot。原 selector、真新遊戲／借裝death／menu／cold／quit／P06／構圖仍待原生，caps 空。
