# ST16 完整串接候選（89b16 最新來源窄合成）

這是可審查的具體程式與正式資源候選，尚未採用或原生驗收。所有內容只寫入本 Ctmp 包；沒有執行 Godot、修改工作樹、Git、PM、RunSnapshot 或啟用 capabilities。本包以 Root latest-source-manifest 的 89b16e63d39ca18a7385d930a744f09c28846d61／unpublished SHA 為精確 preimage，保留 NE247 殘影死亡清理／低 FX 與 NE245 初始化／Encounter 身份守門。舊完整凍結另存 C:/tmp/prologue-complete-integration-candidate，不再修改。本包也是窄 diff，不可整份覆蓋更晚 NE246 changes。

## 實作範圍

- 正式 `st16_pawnshop_training.tres/json`，112×24 格，17 個資源／legend／cell 一一對應的實體站點；新 stdlib generator 可重建。
- P01–P06 原稿全部 50 句保留，只拆同 speaker 字幕，沒有自創付款、先完成第一章或授予作者 flag。P02/P05 真老 K 互動；P03 真射擊後才說結果；P04 失誤真復原後才播放失誤台詞；P06 真歸還膠帶／門扣／關燈後播放聯絡。
- 移動來自實際 Player move_and_slide 後位移；跳躍需真起跳及搬貨台落地；射擊／近戰需真 Hurtbox→Health 降低、實際 Player attacker、借裝來源和近戰 ACTIVE；格擋用真方向 guard；衝刺需真 DASH 位移穿過提示線。證據只由真 Level-owned Session 私有工廠建立，具體 layout/Node/resource 身份再次核對。
- 同一 Loadout 借槍／刀，保留既有 signals 與原裝備投影。普通 autosave 及 P06 目的地保存均投影原裝備；不是新增 wallet/custody owner。
- 訓練失誤以受限 recovery 動作／STAGGERED 演出，不進 Health 傷害／死亡／費用流程。新 action 尚須角色 owner 審查與真腳部／外套／手臂原生畫面驗收。
- 20 必要、9 選擇、2 終端 bool WorldState leaves。順序／原始 bool 型別／三個世界副本一致性在 unchanged RunSnapshot 外層驗證。資訊台詞完成不是技能完成；跳過只記 skipped+exited，六操作不灌 true。
- Main FIRST_LEVEL 真指向序章；P06 真新按鈕確認（取消可返回）→固定現有 RunSaveStore prepare_existing_write/commit_existing_write→成功才安装 world／rebind Level._area→發布視覺→真第一章地圖。寫入失敗保留原 Level／舊存檔／借裝，顯式 retry 可重試；沒有使用已知總回 true 的 _save_destination。
- synchronous prepared/install/publish 範圍具 Main lifecycle/save buffer 與 Story producer guard；不改 atomic request／source／capability／clinic 契約。借装及程序退出以真 Level/Player weak owner 清理。
- 暫停選單真「略過序章…」入口、保守返回焦點、手把 ui_accept／取消及既有 bindings 字串。暫停停止真訓練器，不消耗等待中的失誤演出。

## CPU 檢查

`cpu-results.json`：373 項 deterministic generator／原稿字串完整性／真資源 cell、最新 upstream delta 逐行保留與純資料檢查通過。這些不是 Godot 行為測試。

`gdparse-final.json`：24 檔，23 grammar clean；最新 Player 既有 `if set != _melee_set` 被舊 gdtoolkit 誤認 SET keyword，同一未修改 baseline 也失敗。沒有因此改原語法。Python launcher／generator py_compile clean。Godot 語意、typed Resource 載入、實際流程與畫面仍未執行。原先未設 PYTHONPATH 的 ModuleNotFoundError 是工具環境失敗，後續正確環境重新檢查，沒有聲稱引擎通過。

保護歷史 RunSnapshot：`78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c`，包內沒有 RunSnapshot replacement。`baseline-manifest.json` 確切記錄 Root unpublished 來源；不要把任何 Git HEAD 當成含其全部來源。採用前逐檔 SHA 核對。

## 採用與原生順序

1. 按 `patch-index.json` 審查／套窄 hunk。新 classes→正式生成資料→Main/Level/Story hook→Player/Projectile provenance→測試／工具。原稿複本 `candidate/design/...` 僅 generator CPU input，不採用、不改作者稿。
2. 使用新的私有 APPDATA headless editor import；完整 raw 需無 SCRIPT/Parse/Compile/ERROR，不只 exit 0。新 UID 只收本票自有工具／新 classes，外來 UID 不帶入。
3. 原有 `Npc/Cutscene/RunSave/Ch1Map/Player/Melee/Projectile/Quest` 等測試全部保留，沒有 registry／selector／known_failures 修改。實際 changed selector 如選 ALL 就照跑，不能藏路徑縮 coverage。
4. Root 採用與最新來源 manifest 對齊後，使用 direct actual executable 的 `run_native.py`，每次 fresh out/profile；只 `--execute` 才啟引擎。

```powershell
# 預設只驗 SHA 並印命令，不啟動引擎；Root 排程後加 --execute。
python C:/tmp/prologue-integration-current-candidate/run_native.py --root <adopted-worktree> --out C:/tmp/st16-native-normal --baseline <exact40hex> --mode normal
python C:/tmp/prologue-integration-current-candidate/run_native.py --root <adopted-worktree> --out C:/tmp/st16-native-retry --baseline <exact40hex> --mode normal-write-retry
python C:/tmp/prologue-integration-current-candidate/run_native.py --root <adopted-worktree> --out C:/tmp/st16-native-skip --baseline <exact40hex> --mode whole-skip
```

真 probe：實際 Main menu→difficulty→新遊戲→真正 20 項路線，Input.action_press/release／node-scoped simulated aiming，沒有 teleport、scene_finished、fake receipt、灌 flag／cap。先不格擋慢速桿子，確認真復原台詞且 health/deaths/guard 記錄不變，再真格擋。已借装單步原世界 snapshot 等於 formal projection。真子彈池射手回收負控，fake hit signal 不授訓練完成。

`normal-write-retry` 以當前固定 store 的隔離無效子目錄讓真 prepare/write 拒絕；舊 bytes／Level／exited 不變，再恢復 path 點真 retry。`whole-skip` 走真暫停與確認，不謊稱練過。出門後從真第一章 spawn 物理走入原 dinner trigger，要求真 durable dinner_done；**不是全第一章通關**。最多 10 PNG，真正 viewport_capture 色彩規則。launcher 只讀 owned direct native PID WS/Private；保存完整 raw／EXIT／RID／source 漂移，exit0 且 ERROR 才 fail。畫面永遠留待 Root 逐張目視，不把計數當視覺 pass。

## 必須保留的風險與後續驗收

- 原稿 P01 所述撐傘路人／排水孔動態與完整當舖 furniture/art 仍缺正式素材實作。本候選用既有主題與明確站點幾何，不以黑幕或 primitive 冒稱場景美術完成；需 scene-staging owner 另審。
- `rin.training_recover` 只是窄資料候選，非既有姿勢 clone，不修改原動作。ground 接觸／rig 材質／外套手臂／pose bounds／mesh shadow 皆待 native 原生與 owner 同意。
- 貨台高度48、連續地面／舊門關閉／燈光、玩家碰撞與射擊目標，只有 CPU 資料檢查；實際 Camera/HUD/文本120%/21:9/家具比例 pending。
- 保存菜單／冷 Continue 到每種借裝和台詞中段、寫入失敗然後 menu/quit、死亡首診、binding重綁／真手把，尚需 Root 原生 cases。probe 的合成輸入不等硬體驗收。
- 作者手記27400是原稿歷史敘事。本候選沒有從讀紙條發款；Root 需核真正 CH1 historic ledger/base 與敘事一致性，不能靠序章偷偷補錢。
- all four owner/source fingerprints／typed dictionary／deferred lifecycle 需 Root native observer 回歸。没有新增 readiness、capabilities 或 PM 完成宣稱。

## 最新窄合成備註

`merge-audit.json` 記 exact hunks：Player 將真 DASH 判定插在最新 `_fall_speed_before_move` 前，死亡只在原 `_on_died` 首行取消訓練，原 `clear_dash_silhouettes()` 不動；Level 新 configure hook 插在實際 configure 入口，不動 `_initialization_complete`／Encounter restore 回退。所有原作者 pose JSON values 逐項等同最新，只加尚未視驗的 recovery action。

Quest 不改 provider：沿用既有 StoryConditionTree 對 StoryRuntimeFacts.KEYS 的純 runtime 解讀與 Main 現有 fresh facts callback。序章 Quest 只在真 p01 world 或已提交 exit 存在時顯示，舊 save 未玩序章不憑空出現未完成教學；完成後可看既有記錄。新增負控證明同名永久 flag 不能代替 runtime provider。Root 真四 owner／進程／Custody／Ledger／Source／clinic 都保留。

老 K rig_id 由唯一正式 station Resource 明列，缺合法 rig 時該真 station 不能授進度，Level 延後返回選單；沒有用缺圖／假人完成 P02。

49 個 patches = 14 existing narrow diffs + 35 new files。`native-source-manifest.json` 78 個來源（含實際角色、Source/store、hurtbox、Quest runtime predicate、viewport capture）；只含文字／檔案 SHA，沒有一次解碼圖像。launcher SHA 用 1MiB chunk，不為驗180MB engine 一次讀入全檔。

原生 probe 是合成按鍵／真正 Level/actions 的驗收候選，不宣稱 source SHA／grammar 已證明 Godot 語意、家具／Recovery姿態、硬體手把、完整第一章。Root 須先保存 import raw，再跑真三 modes 與 actual selector。NE246 構圖／手動閱讀 phase 的後續窄合成須另包 review。
