from pathlib import Path
import difflib,hashlib,importlib.util,json,py_compile,re,shutil,subprocess
B=Path(__file__).resolve().parent;C=B/'candidate';P=B/'preimages';OLD=Path('C:/tmp/prologue-complete-integration-candidate')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def ck(value,message):
 checks.append({'check':message,'passed':bool(value)})
 if not value:raise AssertionError(message)
for rel in ['game/main.gd','game/level/level.gd','game/player/player.gd','game/player/player_visual.gd']:
 a=(OLD/'preimages'/rel).read_text('utf-8').splitlines();z=(P/rel).read_text('utf-8').splitlines();current=(C/rel).read_text('utf-8')
 for tag,_,__,j1,j2 in difflib.SequenceMatcher(None,a,z,autojunk=False).get_opcodes():
  if tag!='equal':
   for line in z[j1:j2]:ck(not line.strip() or line in current,'upstream delta retained '+rel+' '+line[:70])
a=json.loads((P/'art/rigs/action_poses.json').read_text('utf-8'));z=json.loads((C/'art/rigs/action_poses.json').read_text('utf-8'))
ck(all(z['actions'][key]==value for key,value in a['actions'].items()),'all latest pose values retained');ck(set(z['actions'])-set(a['actions'])=={'rin.training_recover'},'one proposed recovery only')
ck(not(C/'core/run_snapshot.gd').exists(),'Snapshot not replaced');ck(sha(P/'core/run_snapshot.gd')=='78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c','protected latest Snapshot exact')
for rel in ['tests/suite/test_run_save.gd','tests/suite/test_ch1_map.gd']:
 it=iter((C/rel).read_text('utf-8').splitlines());ck(all(any(line==other for other in it)for line in (P/rel).read_text('utf-8').splitlines()),'all old assertions retained '+rel)
spec=importlib.util.spec_from_file_location('st16gen',C/'tools/level/build_st16_prologue.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
for n in [1,2]:
 dst=B/('cpu-generated-'+str(n));file=dst/'design/13-story-v2/PROLOGUE_SCRIPT.md';file.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(C/'design/13-story-v2/PROLOGUE_SCRIPT.md',file);g.build(dst)
for f in (B/'cpu-generated-1').rglob('*'):
 if f.is_file() and not str(f.relative_to(B/'cpu-generated-1')).startswith('design'):
  rel=f.relative_to(B/'cpu-generated-1');ck(sha(f)==sha(B/'cpu-generated-2'/rel)==sha(C/rel),'deterministic '+str(rel))
j=json.loads((C/'data/story/st16_prologue.json').read_text('utf-8'));flat=[line for scene in j['scenes'].values()for line in scene['lines']]
for i,quote in enumerate(re.findall(r'^> (.+)$',(C/'design/13-story-v2/PROLOGUE_SCRIPT.md').read_text('utf-8'),re.M)):
 target=g.words(quote.strip());ck(any(flat[k:k+len(target)]==target for k in range(len(flat))),'preserved source quotation '+str(i+1))
for key,scene in j['scenes'].items():
 ck(not any(f in scene for f in ['set_flags','results','give_items','options']),'no false reward '+key);ck(all(len(l['text'])<=29 for l in scene['lines']),'subtitle bound '+key)
rows=json.loads((C/'data/levels/st16_pawnshop_training.json').read_text('utf-8'))['segments'][0];bindings=json.loads((C/'data/prologue/source_bindings.json').read_text('utf-8'))
ck(len(bindings['bindings'])==17 and len(rows)==24 and all(len(row)==112 for row in rows),'17 formal stations in bounded map')
for name,item in bindings['bindings'].items():
 x,y=item['cell'];ck(rows[y][x]==item['glyph'] and sum(row.count(item['glyph'])for row in rows)==1,'unique real cell '+name)
ck('rig_id = "old_k"' in (C/'data/prologue/stations/old_k.tres').read_text('utf-8'),'NPC rig is exact resource data')
parse=[]
for f in sorted(C.rglob('*.gd')):
 r=subprocess.run(['C:/tmp/ne230-python/bin/gdparse.exe',str(f)],capture_output=True,text=True,encoding='utf-8',errors='replace');parse.append({'path':str(f.relative_to(C)).replace(chr(92),'/'),'exit':r.returncode,'raw':r.stdout+r.stderr})
r=subprocess.run(['C:/tmp/ne230-python/bin/gdparse.exe',str(P/'game/player/player.gd')],capture_output=True,text=True,encoding='utf-8',errors='replace');baseline={'exit':r.returncode,'raw':r.stdout+r.stderr}
ck(all(p['exit']==0 or p['path']=='game/player/player.gd' for p in parse),'all grammar except baseline SET keyword');ck(r.returncode!=0 and "Token('SET', 'set')" in baseline['raw'],'actual current baseline identical parser limitation')
(B/'gdparse-final.json').write_text(json.dumps({'candidate':parse,'actual_latest_player':baseline},ensure_ascii=False,indent=2),'utf-8')
for f in [B/'run_native.py',C/'tools/level/build_st16_prologue.py']:py_compile.compile(str(f),doraise=True)
(B/'cpu-results.json').write_text(json.dumps({'classification':'CPU generation/source/grammar only, no semantic/native behavior pass','count':len(checks),'checks':checks,'failures':0,'engine_run':False,'capabilities':[]},ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'checks':len(checks),'grammar':len(parse),'grammar_clean':sum(p['exit']==0 for p in parse)}))
