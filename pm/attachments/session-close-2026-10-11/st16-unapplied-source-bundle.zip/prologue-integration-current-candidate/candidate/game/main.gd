extends Node
## 遊戲進入點與畫面路由：主選單 → 關卡 → 過關畫面。
## 同一時間只存在一個畫面；切換時舊畫面完整釋放，避免記憶體累積。

## 新遊戲的第一個區域（第一章「傘」從當舖開始）；舊的雨夜關卡在 data/levels/level_01.tres 保留給既有測試與開發用。
const FIRST_LEVEL := "res://data/levels/st16_pawnshop_training.tres"
const CHAPTER_ONE_ENTRY := "res://data/levels/ch1_pawnshop.tres"
const RETRY_CAPTION := "NEST 回溯紀錄 #%d"
const RETRY_HOLD := 0.22

var _screen: Node
## 目前這一關的資料路徑（重試會重載同一關；通關後依 LevelData.next_level 接續）。
var _level_path := FIRST_LEVEL
var _run_store := RunSaveStore.new()
var _active_run := false
var _save_queued := false
var _continue_data: Dictionary = {}
var _resume_runtime: Dictionary = {}
var _cinematic := ""
var _cinematic_entry: Dictionary = {}
var _cinematic_context: Dictionary = {}
var _cinematic_request := 0
var _chapter_complete := false
var _navigation: QuestMapState
var _runtime_save_queued := false
var _pending_screen: Node
var _quitting := false
var _destination_pending := false
var _restore_publish_pending := false
var _publishing_restore := false
var _story_port := StoryRunCommitPort.new()
var _story_sources := StoryRunSource.new()
var _story_entry: StoryRunSource.EntryWitness
var _story_restore_snapshot: Dictionary = {}
var _story_pending_death_save: WeakRef
var _story_facts := StoryRuntimeFacts.new()
var _prologue_port := PrologueRunPort.new()



func _ready() -> void:
	get_tree().auto_accept_quit = false
	_run_store.validator = PrologueRunPort.prepare_snapshot
	_prologue_port.configure(self)
	Story.bind_runtime_write_guard(self, _prologue_busy)
	_story_port.configure(self)
	_story_facts.configure(self)
	StoryRuntimeFacts.bind_provider(_story_runtime_facts)
	Story.bind_atomic_port(_story_port)
	Story.request_started.connect(_on_story_request_started)
	Story.request_settled.connect(_story_port.forget_source)
	Story.result_rejected.connect(_on_story_result_rejected)
	GameState.run_save_requested.connect(_queue_save)
	Progression.credits_changed.connect(func(_value: int, _delta: int) -> void: _queue_save())
	Progression.upgrades_changed.connect(_queue_save)
	Progression.abilities_changed.connect(_queue_save)
	Progression.pawned_changed.connect(_queue_save)
	EventBus.mechanism_toggled.connect(func(_id: StringName, _active: bool) -> void: _queue_save())
	EventBus.player_health_changed.connect(func(_value: int, _max: int) -> void: _queue_runtime_save())
	EventBus.player_loadout_changed.connect(func(_loadout: Loadout) -> void: _queue_runtime_save())
	EventBus.player_consumables_changed.connect(func(_bag: ConsumableBag) -> void: _queue_save())
	EventBus.enemy_killed.connect(func(_id: StringName, _finisher: bool) -> void: _queue_save())
	Story.scene_started.connect(_on_scene_started)
	Story.scene_finished.connect(_on_scene_finished)
	Story.presentation_cancelled.connect(_on_presentation_cancelled)
	add_child(LightKit.create_environment())
	_show_main_menu()


## 換畫面：用轉場蓋住 → 釋放舊畫面並加入新畫面 → 揭開。
func _switch_to(screen: Node, kind := Transition.Kind.FADE, center := Vector2(0.5, 0.5),
		caption := "", hold := 0.0) -> void:
	_pending_screen = screen
	await Transition.play(kind, _swap_screen.bind(screen), -1.0, center, caption, hold)


func _swap_screen(screen: Node) -> void:
	_pending_screen = null
	_destination_pending = false
	if is_instance_valid(_screen):
		remove_child(_screen)
		_screen.queue_free()
	GameplayLock.set_base_paused(false)
	Fx.reset_time()
	_screen = screen
	add_child(screen)
	if screen is Level and not screen.is_initialized():
		_restore_publish_pending = false
		return  # Failed initialization emits menu_requested; never publish or save its partial scene.
	if screen is Level:
		var bound: bool = _story_sources.bind_resume_layout(self, screen as Level)
		preload("res://tools/clinic_restore_diagnostics.gd").report("layout.bound", self, screen as Level, {}, bound)
		_story_facts.complete_retry(screen as Level)
	# Level._ready 已裝齊玩家、世界及續玩資料，通知才可離開 Main。
	if _restore_publish_pending:
		_restore_publish_pending = false
		_publishing_restore = true
		RunSnapshot.publish_restored()
		_publishing_restore = false
	if _story_pending_death_save != null:
		var death_source := _story_pending_death_save
		_story_pending_death_save = null
		_story_on_critical_level_save(death_source)
	_queue_save()


func _show_main_menu() -> void:
	if _prologue_port.defer_lifecycle(&"_show_main_menu", []):
		return
	if _story_port.defer_lifecycle(&"_show_main_menu", []):
		return
	if _route_pending():
		return
	_save_run()
	_active_run = false
	_story_restore_snapshot = {}
	_story_sources.clear_resume_entry()
	Story.reset_active_presentation(&"menu")
	_continue_data = _run_store.read()
	# 在主選單的時候，背景先把新遊戲第一個區域與開場過場的貼圖載進來。
	AssetPrefetch.warm_level(FIRST_LEVEL)
	var first := load(FIRST_LEVEL) as LevelData if ResourceLoader.exists(FIRST_LEVEL) else null
	if first != null:
		AssetPrefetch.request(AssetPrefetch.scene_texture_paths(first.intro_scene))
	var menu := MainMenu.new()
	menu.continue_available = not _continue_data.is_empty()
	menu.overwrite_required = _run_store.exists()
	if _run_store.unknown_version:
		menu.save_notice = "存檔版本較新，請更新遊戲或明確覆寫。"
	elif not _run_store.issues.is_empty():
		menu.save_notice = "已從備份恢復進度，可以繼續遊戲。" if not _continue_data.is_empty() else "存檔讀取失敗，原檔已保留；可開始新遊戲。"
	elif _continue_data.is_empty() and FileAccess.file_exists(GameState.STORY_SAVE_PATH):
		menu.save_notice = "舊版只保存故事，無法繼續整輪；可開始新遊戲，原故事檔會保留。"
	for issue in _run_store.issues:
		push_warning("[RunSave] %s" % issue)
	menu.continue_requested.connect(_on_continue_requested, CONNECT_DEFERRED)
	menu.start_requested.connect(_on_start_requested, CONNECT_DEFERRED)
	menu.quit_requested.connect(_quit, CONNECT_DEFERRED)
	_switch_to(menu, Transition.Kind.SCAN)


func _on_start_requested(difficulty: DifficultyData) -> void:
	if _prologue_port.defer_lifecycle(&"_on_start_requested", [difficulty]):
		return
	if _story_port.defer_lifecycle(&"_on_start_requested", [difficulty]):
		return
	if _route_pending():
		return
	_active_run = false
	_story_restore_snapshot = {}
	_story_sources.clear_resume_entry()
	GameState.story_autosave = false
	GameState.start_new_run(difficulty)
	_story_facts.begin_new_run()
	_clear_cinematic()
	_resume_runtime = {}
	_chapter_complete = false
	_level_path = FIRST_LEVEL
	_active_run = true
	_bind_navigation()
	# 選單已明確確認覆寫；新輪先落起點，載入失敗不復活舊輪。
	if not _run_store.write(RunSnapshot.capture(_level_path, {"loadout": {}, "world": {}, "position": [-1, -1], "health": difficulty.player_max_health}), true):
		EventBus.toast_requested.emit("新遊戲尚未保存，原檔已保留；會再嘗試保存。")
	_load_level(Transition.Kind.SCAN)


func _on_continue_requested() -> void:
	if _prologue_port.defer_lifecycle(&"_on_continue_requested", []):
		return
	if _story_port.defer_lifecycle(&"_on_continue_requested", []):
		return
	if _route_pending():
		return
	var data := _run_store.read()
	if data.is_empty():
		_show_main_menu()
		return
	_active_run = false
	_restore_publish_pending = true
	RunSnapshot.apply(data, false)
	_story_facts.adopt_read(_run_store.last_validated_raw, data)
	_story_restore_snapshot = data.duplicate(true)
	_level_path = data["level"]
	_resume_runtime = data["runtime"]
	_resume_runtime["cinematic"] = data["cinematic"]
	_resume_runtime["cinematic_context"] = data.get("cinematic_context", {}).duplicate(true)
	_chapter_complete = data["chapter_complete"]
	_cinematic_context = data.get("cinematic_context", {}).duplicate(true)
	_cinematic_request = 0
	_cinematic = data["cinematic"]
	_cinematic_entry = data.duplicate(true) if _cinematic != "" else {}
	_active_run = true
	_bind_navigation()
	if _chapter_complete:
		_show_victory((load(_level_path) as LevelData).chapter)
	else:
		_load_level(Transition.Kind.SCAN)


func _load_level(kind := Transition.Kind.IRIS, caption := "", hold := 0.0) -> void:
	var data: LevelData = load(_level_path) as LevelData if ResourceLoader.exists(_level_path) else null
	if data == null:
		push_error("[Main] 無法載入關卡：%s" % _level_path)
		_restore_publish_pending = false
		_story_restore_snapshot = {}
		_story_sources.clear_resume_entry()
		_show_main_menu()
		return
	var level := Level.new()
	level.configure(data)
	if data.prologue_flow != null:
		level.configure_prologue(_prologue_port.commit)
	level.configure_story_producers(_story_begin_entry, _story_collect_pickup)
	level.configure_story_resume_producer(_story_begin_resume_entry)
	level.configure_clinic_visit_resume_producer(_story_resume_clinic_visit)
	if not _resume_runtime.is_empty():
		level.configure_resume(_resume_runtime)
		if _restore_publish_pending and not _story_restore_snapshot.is_empty():
			preload("res://tools/clinic_restore_diagnostics.gd").report("register.before", self, level, _story_restore_snapshot)
			var registered: bool = _story_sources.register_resume_entry(self, level, _story_restore_snapshot)
			preload("res://tools/clinic_restore_diagnostics.gd").report("register.after", self, level, _story_restore_snapshot, registered)
		_story_restore_snapshot = {}
		_resume_runtime = {}
	if not _restore_publish_pending and is_instance_valid(_screen) and _screen is Level:
		_story_facts.begin_retry(_screen as Level, level)
	level.critical_save_requested.connect(_story_on_critical_level_save.bind(weakref(level)))
	level.retry_requested.connect(_on_retry_requested.bind(level), CONNECT_DEFERRED)
	level.menu_requested.connect(_show_main_menu, CONNECT_DEFERRED)
	level.completed.connect(_on_level_completed.bind(data, weakref(level)), CONNECT_DEFERRED)
	level.area_requested.connect(_on_area_requested, CONNECT_DEFERRED)
	_switch_to(level, kind, Vector2(0.5, 0.5), caption, hold)


## 死亡後重來用雜訊溶解並標示回溯編號；暫停選單的「從檢查點重來」用光圈。
func _on_retry_requested(level: Level) -> void:
	if _prologue_port.defer_lifecycle(&"_on_retry_requested", [level]):
		return
	if _story_port.defer_lifecycle(&"_on_retry_requested", [level]):
		return
	if _route_pending():
		return
	if not is_instance_valid(level) or level != _screen:
		return
	Story.reset_active_presentation(&"retry")
	# 檢查點在別的區域（區域組）：回到那個區域；舊式關卡的檢查點一定在同一關。
	var checkpoint_level := GameState.checkpoint_level_path
	if GameState.has_checkpoint and not checkpoint_level.is_empty() and RunSaveCodec.resource(checkpoint_level, "level", "res://data/levels/") != null:
		_level_path = checkpoint_level
	var runtime := level.run_snapshot()
	GameState.pending_portal = &""
	GameState.carried_health = -1
	runtime["loadout"] = GameState.checkpoint_loadout.duplicate(true)
	if not level.data.persistent_world:
		Progression.restore(GameState.checkpoint_progress if GameState.checkpoint_applies(_level_path) else GameState.level_start_progress)
	runtime["dead"] = false
	runtime["ending"] = false
	runtime["health"] = GameState.difficulty.player_max_health
	runtime["position"] = [-1, -1]
	runtime["velocity"] = [0, 0]
	runtime["crouching"] = false
	_clear_cinematic()
	if not _save_destination(runtime):
		return
	if is_instance_valid(level) and level.died:
		_load_level(Transition.Kind.GLITCH, RETRY_CAPTION % GameState.deaths, RETRY_HOLD)
	else:
		_load_level(Transition.Kind.IRIS)


## 穿過出入口：載入目標區域（玩家出現在 GameState.pending_portal 指定的出入口）。
func _on_area_requested(level_path: String) -> void:
	if _prologue_port.defer_lifecycle(&"_on_area_requested", [level_path]):
		return
	if _story_port.defer_lifecycle(&"_on_area_requested", [level_path]):
		return
	if _route_pending() or _restore_publish_pending:
		return
	# 撤回未完成演出的暫定效果，再保存新區入口；入口Portal由實際路由保留。
	var source: Level = _screen as Level if is_instance_valid(_screen) else null
	if source == null:
		return
	var portal := GameState.pending_portal
	Story.reset_active_presentation(&"route")
	GameState.pending_portal = portal
	# A settled rejection has no active Story to emit route cancellation.
	# Only discard runtime resume metadata; prior durable A owners remain installed.
	if not _story_clear_level_entry(source):
		return
	_save_run()
	_level_path = level_path
	# 保存目標入口而不是舊區位置；切換中關閉也能進新區。
	var runtime := (_screen as Level).run_snapshot() if _screen is Level else {}
	runtime["position"] = [-1, -1]
	if not _save_destination(runtime):
		return
	_load_level(Transition.Kind.FADE)


## 過關：有下一關就接續（帶著成長與裝備），否則進入結算畫面。下一關讀不到時退回結算，不會卡住。
func _on_level_completed(data: LevelData, source_ref: WeakRef = null) -> void:
	if _prologue_port.defer_lifecycle(&"_on_level_completed", [data, source_ref]):
		return
	if _story_port.defer_lifecycle(&"_on_level_completed", [data, source_ref]):
		return
	if _route_pending():
		return
	var source := _screen as Level
	if source_ref != null and source_ref.get_ref() != source:
		push_warning("[Main] 拒絕舊畫面的關卡完成：received=%s current=%s" % [data.resource_path if data != null else "<null>", source.data.resource_path if source != null and source.data != null else _level_path])
		return
	if source == null or data == null or source.data != data:
		var received := data.resource_path if data != null else "<null>"
		var current := source.data.resource_path if source != null and source.data != null else _level_path
		push_warning("[Main] 拒絕無效或過時關卡完成：received=%s current=%s（畫面=%s）" % [received, current, _screen.get_class() if is_instance_valid(_screen) else "<null>"])
		return
	_save_run()
	if RunSaveCodec.resource(data.next_level, "level", "res://data/levels/") != null:
		_level_path = data.next_level
		GameState.enter_level()
		var runtime := (_screen as Level).run_snapshot()
		runtime["ending"] = false
		runtime["position"] = [-1, -1]
		runtime["health"] = GameState.difficulty.player_max_health
		if not _save_destination(runtime):
			return
		_load_level(Transition.Kind.ELEVATOR)
	else:
		_chapter_complete = true
		_save_run()
		if not data.next_level.is_empty():
			push_error("[Main] 找不到下一關：%s，直接進入結算。" % data.next_level)
		_show_victory(data.chapter)


func _show_victory(chapter: StringName) -> void:
	var screen := VictoryScreen.new()
	screen.chapter = chapter
	screen.replay_requested.connect(_on_start_requested.bind(GameState.difficulty), CONNECT_DEFERRED)
	screen.menu_requested.connect(_show_main_menu, CONNECT_DEFERRED)
	_switch_to(screen, Transition.Kind.BLINDS)


func _route_pending() -> bool:
	return _quitting or _publishing_restore or _story_port.is_busy() or _prologue_port.is_busy() or (is_instance_valid(_pending_screen) and not _pending_screen.is_inside_tree())


func _bind_navigation() -> void:
	if _navigation != null and _navigation.changed.is_connected(_queue_runtime_save):
		_navigation.changed.disconnect(_queue_runtime_save)
	_navigation = QuestMapState.for_run()
	_navigation.changed.connect(_queue_runtime_save)


func _queue_runtime_save() -> void:
	if _prologue_port.is_busy():
		_prologue_port.dirty = true
		return
	if _story_port.is_busy():
		_story_port.dirty = true
		return
	if not _active_run or _runtime_save_queued or _restore_publish_pending or _publishing_restore:
		return
	_runtime_save_queued = true
	get_tree().create_timer(1.0, true, false, true).timeout.connect(func() -> void:
		_runtime_save_queued = false
		_queue_save())


func _queue_save() -> void:
	if _prologue_port.is_busy():
		_prologue_port.dirty = true
		return
	if _story_port.is_busy():
		_story_port.dirty = true
		return
	if not _active_run or _save_queued or _restore_publish_pending or _publishing_restore:
		return
	_save_queued = true
	_flush_save.call_deferred()


func _flush_save() -> void:
	_save_queued = false
	_save_run()


func _save_run() -> void:
	if _prologue_port.is_busy():
		_prologue_port.dirty = true
		return
	if _story_port.is_busy():
		_story_port.dirty = true
		return
	if not _active_run or _destination_pending or _restore_publish_pending or _publishing_restore or not is_instance_valid(_screen) or not _screen is Level:
		return
	var level := _screen as Level
	if not level.is_inside_tree() or level.is_queued_for_deletion():
		return
	if level.data.resource_path != _level_path:
		return  # 轉場期間已保存新區入口，不拿舊畫面的座標覆蓋。
	var runtime := level.run_snapshot()
	if runtime.is_empty():
		return
	var snapshot := RunSnapshot.capture(_level_path, runtime, _cinematic, _chapter_complete, _cinematic_context)
	if _cinematic != "" and not Story.is_atomic_scene(StringName(_cinematic)) and not _cinematic_entry.is_empty():
		# 尚未結束的選項／物品／款項皆暫定；完整入口快照避免A殘留再選B。
		snapshot = _cinematic_entry.duplicate(true)
		snapshot["cinematic"] = _cinematic
		snapshot["cinematic_context"] = _cinematic_context.duplicate(true)
	var saved := _run_store.write(snapshot)
	if not saved:
		EventBus.toast_requested.emit("存檔未成功，原進度仍保留。")


func _save_destination(runtime: Dictionary) -> bool:
	var destination := RunSaveCodec.resource(_level_path, "level", "res://data/levels/") as LevelData
	if destination == null:
		push_warning("[RunSave] run/level 目的地無效：%s，原存檔保留並返回選單" % _level_path)
		_show_main_menu()
		return false
	_destination_pending = true  # 同一區重試亦不能被舊畫面的 queued/close 保存蓋回。
	var area := {"consumed": {}, "damage": {}, "world": {}}
	if destination.persistent_world:
		area = GameState.area_state(destination.id).duplicate(true)
	elif GameState.checkpoint_applies(_level_path):
		area["world"] = GameState.checkpoint_world.duplicate(true)
	runtime["world"] = area["world"].duplicate(true)
	runtime["area"] = area
	runtime["loose"] = []
	runtime["enemies"] = []
	runtime["encounters"] = {}
	runtime["arena"] = false
	runtime["boss_pending"] = false
	runtime["velocity"] = [0, 0]
	runtime["facing"] = 1
	runtime["aim_dir"] = [1, 0]
	runtime["crouching"] = false
	runtime["guard"] = 100
	runtime["dead"] = false
	runtime["death_entry"] = {}
	runtime["death_cause"] = "unknown"
	runtime["ending"] = false
	if not _run_store.write(RunSnapshot.capture(_level_path, runtime)):
		EventBus.toast_requested.emit("區域進度尚未保存，原存檔仍保留。")
	return true


func _on_scene_started(id: StringName, mode: StringName) -> void:
	if is_instance_valid(_screen) and _screen is Level and is_instance_valid((_screen as Level).prologue) \
			and Story.scene_source(id) == (_screen as Level).prologue.flow.story_path:
		return  # Pure lesson presentation; only committed WorldState is the Continue cursor.
	# Formal passive presentations have their own request context; the modal
	# presentation context may belong to an unrelated scene.
	if Story.is_atomic_scene(id):
		return
	if not _active_run or not is_instance_valid(_screen) or not _screen is Level or mode not in [Story.MODE_CINEMATIC, Story.MODE_ANIMATED]:
		return
	_cinematic_context = Story.current_presentation_context()
	_cinematic_request = Story.current_presentation_request()
	_cinematic_entry = RunSnapshot.capture(_level_path, (_screen as Level).run_snapshot(), "", false, _cinematic_context)
	_cinematic = String(id)
	_queue_save()


func _on_scene_finished(id: StringName) -> void:
	var request := Story.finished_presentation_request()
	if Story.is_atomic_scene(id):
		# The durable owner port already installed the exact continuation metadata.
		_queue_save()
		return
	if is_instance_valid(_screen) and _screen is Level:
		(_screen as Level).refresh_story_population()
	if _cinematic == String(id) and (request == 0 or request == _cinematic_request):
		_clear_cinematic()
	_queue_save()


## Clear only an obsolete entry belonging to the SAME current live Level.
## Valid Continue construction/publication and newer destination receipts are protected.
## No owner rollback: committed preceding segments and actual death costs stay installed.
func _story_clear_level_entry(level: Level) -> bool:
	if _restore_publish_pending or _publishing_restore or _destination_pending or _story_port.is_busy() or not _active_run \
			or not is_instance_valid(level) or not is_instance_valid(_screen) or level != _screen \
			or not level.is_inside_tree() or level.is_queued_for_deletion() \
			or not is_instance_valid(level.data) or level.data.resource_path != _level_path:
		return false
	_clear_cinematic()
	_story_entry = null
	_story_restore_snapshot = {}
	_story_sources.clear_resume_entry()
	return true


## Level emits once AFTER actual register_death/world cost, BEFORE its critical save.
## Use a WeakRef: a queued lifecycle cannot keep a departed Level or clear its successor.
func _story_on_critical_level_save(source_ref: WeakRef) -> void:
	var raw: Variant = source_ref.get_ref() if source_ref != null else null
	if not is_instance_valid(raw) or not raw is Level:
		return
	var level := raw as Level
	if not is_instance_valid(_screen) or level != _screen or not level.is_inside_tree() \
			or level.is_queued_for_deletion() or not level.died \
			or not is_instance_valid(level.player) or not level.player.is_dead():
		return
	if _restore_publish_pending or _publishing_restore:
		# A synchronous restore observer may die. Finish installing the valid
		# new snapshot first; recheck its exact live Level once publication ends.
		_story_pending_death_save = source_ref
		return
	if _prologue_port.defer_lifecycle(&"_story_on_critical_level_save", [source_ref]):
		return
	if _story_port.defer_lifecycle(&"_story_on_critical_level_save", [source_ref]):
		return
	if not _story_clear_level_entry(level):
		return
	_save_run()


func _clear_cinematic() -> void:
	_cinematic = ""
	_cinematic_entry = {}
	_cinematic_context = {}
	_cinematic_request = 0


## 純取消不套完成旗標。死亡通知在Level結算前抵達，只撤回暫定資料，保留live玩家死亡演出。
func _on_presentation_cancelled(id: StringName, _context: Dictionary, reason: StringName, request: int) -> void:
	if Story.is_atomic_scene(id):
		# Formal steps cannot mutate data owners. Committed earlier batches remain;
		# never re-install an old entry over their receipts, custody or world state.
		if request == _cinematic_request:
			# This exact registered segment has not completed. Preserve its saved
			# continuation on result rejection; presentation/source still settle in Story.
			var source := _story_port._sources.get(request) as StoryRunSource.Source
			if reason == &"result_rejected" and _cinematic == String(id) \
					and _cinematic_context == _context and not Story.was_completed(id) \
					and _context.get("framing_source") == "entry" \
					and str(_context.get("source_id", "")).begins_with("level:trigger:") \
					and source != null and source.graph.has(String(id)) \
					and _story_source_valid(source, request, Story.request_scene(request)):
				_queue_save()
				return
			_clear_cinematic()
			_queue_save()
		return
	if _cinematic != String(id) or (_cinematic_request != 0 and request != _cinematic_request):
		return
	var level: Level = _screen as Level if is_instance_valid(_screen) else null
	var rolled_back := false
	if _active_run and not _destination_pending and level != null and level.data.resource_path == _level_path \
			and reason in [&"death", &"route", &"retry", &"leave"] and not _cinematic_entry.is_empty():
		var entry := _cinematic_entry.duplicate(true)
		_publishing_restore = true
		RunSnapshot.rollback_presentation(entry, false)
		_clear_cinematic()
		if level.is_inside_tree() and not level.is_queued_for_deletion():
			level.rollback_presentation_world(entry.get("runtime", {}))
		rolled_back = true
	_clear_cinematic()
	if rolled_back:
		_bind_navigation()
		RunSnapshot.publish_restored()
		_publishing_restore = false
		_queue_save()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_quit()


func _quit(exit_code := 0) -> void:
	if _prologue_port.defer_lifecycle(&"_quit", [exit_code]):
		return
	if _story_port.defer_lifecycle(&"_quit", [exit_code]):
		return
	if _publishing_restore:
		_quit.call_deferred(exit_code)
		return
	if _quitting:
		return
	_quitting = true
	_save_run()
	_active_run = false
	Story.reset_active_presentation(&"quit")
	Transition.abort()
	# 切換途中尚未加入樹的目標畫面也必須釋放。
	if is_instance_valid(_pending_screen) and not _pending_screen.is_inside_tree():
		_pending_screen.free()
	_pending_screen = null
	if is_instance_valid(_screen):
		_screen.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	get_tree().quit(exit_code)


func _on_story_request_started(request: int, id: StringName, context: Dictionary) -> void:
	_story_port.register_source(request, id, context)
	var source: RefCounted = _story_port._sources.get(request)
	if source is StoryRunSource.Source and _story_sources.is_actual_clinic(source) and not Story._clinic_host_live(request):
		if not Story.arm_clinic_continuation(source):
			Story.cancel_atomic_request(&"actual_clinic_host_failed")
			return
	if Story.is_atomic_request(request) and _active_run and is_instance_valid(_screen) and _screen is Level:
		_cinematic_context = context.duplicate(true)
		_cinematic_request = request
		_cinematic_entry = RunSnapshot.capture(_level_path, (_screen as Level).run_snapshot(), "", false, context)
		_cinematic = String(id)
		_queue_save()


## Runtime factories are installed before Level._ready; authored data never
## supplies a callback, result array, or serialized witness.
func _story_begin_entry(level: Level, kind: StringName, index := -1) -> Dictionary:
	_story_entry = null
	if not is_instance_valid(level) or level != _screen or not _active_run or _destination_pending or _quitting or _publishing_restore or _story_port.is_busy():
		return {}
	var witness := _story_sources.begin_entry(level, kind, index)
	if witness == null:
		return {}
	_story_entry = witness
	_story_facts.observe_clinic_entry(level, witness)
	return {"framing_source": "entry", "source_id": witness.source_id}


func _story_collect_pickup(pickup: CollectiblePickup, live_player: Player) -> bool:
	return _story_port.commit_world_pickup(pickup, live_player)


func _story_capture_world_pickup(pickup: CollectiblePickup, live_player: Player) -> RefCounted:
	if not is_instance_valid(_screen) or not _screen is Level:
		return null
	return _story_sources.capture_pickup(_screen as Level, pickup, live_player)


func _story_world_pickup_valid(source: RefCounted, pickup: CollectiblePickup, live_player: Player) -> bool:
	if not source is StoryRunSource.Source or not is_instance_valid(_screen) or not _screen is Level:
		return false
	var proof := source as StoryRunSource.Source
	return proof.kind == "world_pickup" and proof.request == 0 and proof.source_path.is_empty() and proof.binding.is_empty() \
		and proof.level.get_ref() == _screen and proof.player.get_ref() == live_player and proof.node.get_ref() == pickup \
		and (_screen as Level).data.resource_path == _level_path and _story_sources.validate_world_pickup(proof)


func _story_world_pickup_contract(source: RefCounted) -> Dictionary:
	if not source is StoryRunSource.Source or not is_instance_valid(source.resource) or not source.resource is StoryItemData \
			or (source.resource as StoryItemData).id != &"ch1_data_disk":
		return {}
	const PATH := "res://data/story/ch1_binding_contract.json"
	var document: JSON = load(PATH) as JSON if ResourceLoader.exists(PATH) else null
	if document == null or not document.data is Dictionary or document.data.get("schema") != "ch1_binding_contract_v1":
		return {}
	var resolved: Variant = document.data.get("resolved_bindings")
	if not resolved is Dictionary or resolved.get("schema") != "ch1_real_bindings_v1" or not resolved.get("bindings") is Dictionary:
		return {}
	var definition: Variant = resolved["bindings"].get("disk_pickup")
	if not definition is Dictionary or not RunSaveCodec.validate_tree(definition, 512).is_empty():
		return {}
	return {"contract_source": PATH, "binding": "disk_pickup", "definition": definition.duplicate(true)}


func _story_begin_resume_entry(level: Level, scene: StringName, context: Dictionary) -> bool:
	_story_entry = null
	if not is_instance_valid(level) or level != _screen or not _active_run or _destination_pending \
			or _quitting or _publishing_restore or _restore_publish_pending or _story_port.is_busy():
		return false
	_story_entry = _story_sources.begin_resume_entry(self, level, scene, context)
	return _story_entry != null


func _story_capture_source(request: int, id: StringName, context: Dictionary) -> RefCounted:
	var entry := _story_entry
	_story_entry = null
	return _story_sources.capture(self, request, id, context, entry)


func _story_source_valid(source: RefCounted, request: int, id: StringName) -> bool:
	return _story_sources.valid(source, request, id)


func _story_authenticated_producers(id: StringName, source: RefCounted) -> Dictionary:
	return _story_sources.authenticated_producers(id, source)


func _story_is_actual_clinic(source: RefCounted) -> bool:
	return _story_sources.is_actual_clinic(source)


func _on_story_result_rejected(_id: StringName, _request: int, _status: StringName, message: String) -> void:
	if _active_run:
		if Story._clinic_host_live(_request) and _request == Story._current_request \
				and _id == Story._current_cinematic and is_instance_valid(Story._atomic_decision_root):
			return  # The real clinic recovery panel owns plain error presentation.
		EventBus.toast_requested.emit(message)


func _run_story_lifecycle(method: StringName, arguments: Array) -> void:
	# Runtime-only bounded queue; authored JSON never chooses a lifecycle method.
	if method not in [&"_show_main_menu", &"_on_start_requested", &"_on_continue_requested",
		&"_on_retry_requested", &"_on_area_requested", &"_on_level_completed", &"_quit",
		&"_story_on_critical_level_save"]:
		push_error("[Main] rejected unknown story lifecycle: %s" % method)
		return
	callv(method, arguments)


## Main owns ch1_true_death_record_known provenance; author JSON never binds facts.
func _story_runtime_facts() -> Dictionary:
	var facts := _story_facts.snapshot()
	var area: Variant = GameState.area_states.get("st16_pawnshop_training")
	if _active_run and area is Dictionary and area.get("world") is Dictionary:
		var checked := PrologueProgressPlan.prepare_world(area["world"])
		if not checked.has("error"):
			facts.merge(checked["world"], true)
	return facts


## Runtime-only Level callback; never loaded from authors or serialized data.
func _story_resume_clinic_visit(level: Level) -> int:
	preload("res://tools/clinic_restore_diagnostics.gd").report("resume.before", self, level)
	_story_entry = null
	if level != _screen or not _active_run or _destination_pending or _quitting \
			or _publishing_restore or _restore_publish_pending or _story_port.is_busy():
		return 0
	var intent := _story_sources.clinic_visits.intent()
	if intent.is_empty():
		return 0
	var witness := _story_sources.begin_resume_entry(self, level, StringName(intent["scene"]), intent["context"])
	if witness == null or witness.clinic_restore == null:
		return 0
	_story_entry = witness
	_story_facts.observe_clinic_entry(level, witness)
	var request := Story.resume_clinic_visit(witness, StringName(intent["scene"]))
	preload("res://tools/clinic_restore_diagnostics.gd").report("resume.after", self, level, {}, request)
	if request == 0 and _story_entry == witness:
		_story_entry = null
	return request

## Called only by the fixed PrologueRunPort after its actual durable commit.
func _prologue_leave_committed(owner: WeakRef, destination: String, runtime: Dictionary) -> void:
	var level: Variant = owner.get_ref()
	if not _active_run or not is_instance_valid(level) or _screen != level or not level is Level 			or not _destination_pending or destination != CHAPTER_ONE_ENTRY 			or not is_instance_valid(level.prologue) or not level.prologue.world().get(PrologueProgressPlan.PREFIX + "exited", false):
		return
	# New path is latched before Transition; ordinary save can no longer overwrite it with old Level.
	_clear_cinematic()
	_story_restore_snapshot = {}
	_story_sources.clear_resume_entry()
	_level_path = destination
	_resume_runtime = runtime.duplicate(true)
	_bind_navigation()
	_load_level(Transition.Kind.IRIS, "吃完飯後，上屋頂找鷺。")

func _prologue_busy() -> bool:
	return _prologue_port.is_busy()
