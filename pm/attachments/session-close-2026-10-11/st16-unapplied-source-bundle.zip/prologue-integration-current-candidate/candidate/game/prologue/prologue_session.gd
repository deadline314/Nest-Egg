class_name PrologueSession
extends Node2D
## The actual Level owns observations. No event/flag supplied by author JSON is proof.
signal progress_changed
const Plan = preload("res://core/prologue_progress_plan.gd")
const INFO := {
	"p01_information": &"st16_p01_open",
	"p03_information": &"st16_p03_info",
	"p03_feedback": &"st16_p03_feedback",
	"p04_information": &"st16_p04_info"
}
const REQUIRED_STATIONS := [
	"table",
	"tools",
	"low_target",
	"gun_return",
	"knife",
	"rubber_target",
	"guard",
	"dash",
	"tools_return",
	"service",
	"tape",
	"latch",
	"light",
	"exit",
	"catalog",
	"notebook",
	"old_k"
]
var level: Level
var player: Player
var flow: PrologueFlowData
var _commit: Callable
var _leaves: Dictionary[String, PrologueLeaf] = {}
var _stations: Dictionary[StringName, PrologueStation] = {}
var _loan := PrologueLoan.new()
var _ready_ok := false
var _disposed := false
var _presenting := false
var _serial := 0
var _proofs: Dictionary[int, Evidence] = {}
var _pending: Evidence
var _retry_left := 0.0
var _jump_departed := false
var _jump_frame := -100000
var _dash_started := false
var _dash_origin := Vector2.ZERO
var _move_origin := Vector2.ZERO
var _expected_scene: StringName
var _expected_station: PrologueStation
var _expected_context: Dictionary = {}
var _expected_request := 0
var _request_done := false
var _request_completed := false
var _panel: PrologueGuide
var _recovering_station: WeakRef
var _challenge: StringName = &""
var _challenge_guard_frame := -100000
var _challenge_dash_frame := -100000
var _challenge_hit_frame := -100000
var _challenge_hit_origin := Vector2.ZERO


class Evidence:
	extends RefCounted
	var issuer: WeakRef
	var level_ref: WeakRef
	var player_ref: WeakRef
	var station_ref: WeakRef
	var resource: PrologueStationData
	var layout: LevelLayout
	var serial: int
	var event: StringName
	var kind: StringName
	var frame: int
	var request := 0
	var scene: StringName
	var context: Dictionary = {}
	var overlap_at_issue := false
	var from := Vector2.ZERO
	var to := Vector2.ZERO
	var used := false


func configure(owner: Level, data: PrologueFlowData, callback: Callable) -> void:
	level = owner
	flow = data
	_commit = callback


func _ready() -> void:
	if (
		not is_instance_valid(level)
		or get_parent() != level
		or not is_instance_valid(flow)
		or not flow.validate().is_empty()
		or not _commit.is_valid()
	):
		push_error("[Prologue] invalid Level-owned flow/commit factory")
		return
	player = level.player
	if (
		not is_instance_valid(player)
		or player.get_parent() != level._entities
		or not _loan.bind(player)
	):
		return
	_move_origin = player.global_position
	for event: String in Plan.REQUIRED + Plan.OPTIONAL + Plan.TERMINAL:
		var leaf := PrologueLeaf.new()
		leaf.event = event
		_leaves[event] = leaf
		add_child(leaf)
	if level._layout.spawns.size() > 32:
		return
	for spawn: Dictionary in level._layout.spawns:
		var data := spawn["resource"] as PrologueStationData
		if (
			data == null
			or not data.resource_path.begins_with(flow.station_dir)
			or _stations.has(data.id)
		):
			push_error("[Prologue] unsupported or repeated training station at %s" % spawn["cell"])
			return
		var station := PrologueStation.new()
		station.data = data
		station.cell = spawn["cell"]
		station.session = self
		station.position = spawn["position"]
		_stations[data.id] = station
		add_child(station)
		if not station.ready_for_training:
			level.menu_requested.emit.call_deferred()
			return
	if _stations.size() != REQUIRED_STATIONS.size():
		return
	for id: String in REQUIRED_STATIONS:
		if not _stations.has(StringName(id)):
			return
	player.motion_observed.connect(_on_motion)
	player.training_recovery_finished.connect(_on_recovery_finished)
	GameplayLock.started.connect(stop_machines)
	Story.request_started.connect(_on_request_started)
	Story.request_settled.connect(_on_request_settled)
	_panel = PrologueGuide.new()
	_panel.session = self
	add_child(_panel)
	_ready_ok = true


func activate() -> void:
	if not _ready_ok:
		return
	var prepared := Plan.prepare_world(world())
	if prepared.has("error"):
		push_error(prepared["error"])
		_ready_ok = false
		return
	_loan.apply_world(prepared["world"], flow)
	for station: PrologueStation in _stations.values():
		station.apply_world(prepared["world"])
	progress_changed.emit()


func live() -> bool:
	return (
		_ready_ok
		and not _disposed
		and is_inside_tree()
		and not is_queued_for_deletion()
		and is_instance_valid(level)
		and level.prologue == self
		and level.is_inside_tree()
		and not level.is_queued_for_deletion()
		and is_instance_valid(player)
		and level.player == player
		and player.get_parent() == level._entities
		and not level.died
		and not player.is_dead()
		and level.data.prologue_flow == flow
	)


func world() -> Dictionary:
	var value := {}
	for event: String in _leaves:
		value[Plan.PREFIX + event] = _leaves[event].completed
	return value


func formal_loadout() -> Dictionary:
	return _loan.project()


func install_world(value: Dictionary) -> void:
	# Called ONLY after fixed writer succeeds, with publication excluded by port.
	for event: String in _leaves:
		_leaves[event].restore_state(value.get(Plan.PREFIX + event, false))


func publish_world() -> void:
	_loan.apply_world(world(), flow)
	for station: PrologueStation in _stations.values():
		station.apply_world(world())
	progress_changed.emit()


func next_event() -> String:
	return str(Plan.next_required(world()).get("event", ""))


func _is_owned(station: PrologueStation) -> bool:
	if (
		not live()
		or not is_instance_valid(station)
		or not is_instance_valid(station.data)
		or not station.ready_for_training
		or station.get_parent() != self
		or station.session != self
		or _stations.get(station.data.id) != station
		or station.is_queued_for_deletion()
	):
		return false
	for spawn: Dictionary in level._layout.spawns:
		if (
			spawn["resource"] == station.data
			and spawn["cell"] == station.cell
			and spawn["position"] == station.position
		):
			return true
	return false


func available(station: PrologueStation) -> bool:
	if (
		not _is_owned(station)
		or get_tree().paused
		or GameplayLock.is_locked()
		or _presenting
		or player.state != Player.State.NORMAL
	):
		return false
	if _pending != null:
		return _pending.station_ref.get_ref() == station
	var event := next_event()
	match station.data.kind:
		PrologueStationData.Kind.TOOLS:
			return event == "tools_taken"
		PrologueStationData.Kind.GUN_RETURN:
			return event == "gun_returned"
		PrologueStationData.Kind.KNIFE:
			return event == "knife_taken"
		PrologueStationData.Kind.GUARD:
			return (
				(event == "guard" or _challenge == &"guard_melee_practised")
				and station.pulse_time < 0
			)
		PrologueStationData.Kind.DASH:
			return (
				(event == "dash" or _challenge == &"dash_melee_practised")
				and station.pulse_time < 0
			)
		PrologueStationData.Kind.TOOLS_RETURN:
			return event == "tools_returned"
		PrologueStationData.Kind.SERVICE, PrologueStationData.Kind.CATALOG, PrologueStationData.Kind.NOTEBOOK:
			return true
		PrologueStationData.Kind.OLD_K:
			return event in ["p02_information", "p05_information"]
		PrologueStationData.Kind.TAPE:
			return (
				event in ["p06_tape_returned", "p06_latch_closed", "p06_light_off"]
				and not _leaves["p06_tape_returned"].completed
			)
		PrologueStationData.Kind.LATCH:
			return (
				_leaves["p05_information"].completed and not _leaves["p06_latch_closed"].completed
			)
		PrologueStationData.Kind.LIGHT:
			return _leaves["p05_information"].completed and not _leaves["p06_light_off"].completed
		PrologueStationData.Kind.EXIT:
			return event == "confirm_exit"
	return false


func person_scene() -> StringName:
	if next_event() == "p02_information":
		return &"st16_p02_info"
	return (
		&"st16_p05_info_fall"
		if _leaves.get("training_fall_shown") != null and _leaves["training_fall_shown"].completed
		else &"st16_p05_info_clear"
	)


func _issue(event: StringName, kind: StringName, station: PrologueStation) -> Evidence:
	if not _is_owned(station) or _proofs.size() >= 2:
		return null
	_serial += 1
	var proof := Evidence.new()
	proof.issuer = weakref(self)
	proof.level_ref = weakref(level)
	proof.player_ref = weakref(player)
	proof.station_ref = weakref(station)
	proof.resource = station.data
	proof.layout = level._layout
	proof.serial = _serial
	proof.event = event
	proof.kind = kind
	proof.frame = Engine.get_physics_frames()
	proof.overlap_at_issue = station.actual_overlap()
	_proofs[proof.serial] = proof
	return proof


func valid(proof: Evidence) -> bool:
	return (
		live()
		and proof != null
		and not proof.used
		and _proofs.get(proof.serial) == proof
		and proof.issuer.get_ref() == self
		and proof.level_ref.get_ref() == level
		and proof.player_ref.get_ref() == player
		and proof.layout == level._layout
		and is_instance_valid(proof.station_ref.get_ref())
		and _is_owned(proof.station_ref.get_ref())
		and proof.station_ref.get_ref().data == proof.resource
	)


func consume(proof: Evidence) -> void:
	if proof != null:
		proof.used = true
		_proofs.erase(proof.serial)
		if _pending == proof:
			_pending = null


func _submit(proof: Evidence, exit := false, skip := false) -> void:
	if not valid(proof):
		return
	var result: Dictionary = _commit.call(level, self, proof, exit, skip)
	if result.get("status") == "committed":
		consume(proof)
	elif result.get("status") == "busy":
		_pending = proof
		_retry_left = 0.3
	else:
		_pending = proof
		_retry_left = -1.0  # writer/contract failure requires explicit real retry
		_panel.set_notice("進度尚未保存。請按重試，或返回選單。")
	progress_changed.emit()


func retry_pending() -> void:
	if _pending == null or not valid(_pending):
		return
	var proof := _pending
	_submit(proof, proof.kind in [&"exit", &"skip"], proof.kind == &"skip")


func interact(station: PrologueStation) -> void:
	if not available(station) or not station.actual_overlap():
		return
	if _pending != null:
		retry_pending()
		return
	match station.data.kind:
		PrologueStationData.Kind.GUARD:
			station.arm(&"guard")
		PrologueStationData.Kind.DASH:
			station.arm(&"dash")
		PrologueStationData.Kind.OLD_K:
			_present(person_scene(), StringName(next_event()), station, &"person")
		PrologueStationData.Kind.SERVICE:
			_present(&"st16_service", &"service_document_read", station, &"object")
		PrologueStationData.Kind.CATALOG:
			_present(&"st16_catalog", &"catalog_read", station, &"object")
		PrologueStationData.Kind.NOTEBOOK:
			_present(&"st16_notebook", &"notebook_read", station, &"object")
		PrologueStationData.Kind.EXIT:
			_panel.confirm_exit(false)
		_:
			var mapping := {
				"tools": &"tools_taken",
				"gun_return": &"gun_returned",
				"knife": &"knife_taken",
				"tools_return": &"tools_returned",
				"tape": &"p06_tape_returned",
				"latch": &"p06_latch_closed",
				"light": &"p06_light_off"
			}
			if mapping.has(String(station.data.id)):
				_submit(_issue(mapping[String(station.data.id)], &"interaction", station))


func confirm_exit(skip: bool) -> void:
	if not live() or _presenting or _pending != null or not _panel.actual_confirmation(skip):
		return
	var station: PrologueStation = _stations[&"exit"]
	if not skip and (next_event() != "confirm_exit" or not station.actual_overlap()):
		return
	_submit(_issue(&"exited", &"skip" if skip else &"exit", station), true, skip)


func _on_motion(
	before: Vector2, after: Vector2, was_floor: bool, now_floor: bool, jumping: bool, dashing: bool
) -> void:
	if not live() or _presenting or _pending != null:
		return
	var event := next_event()
	if jumping and was_floor and after.y < before.y:
		_jump_departed = true
		_jump_frame = Engine.get_physics_frames()
	if (
		_challenge == &"melee_retreat_practised"
		and Engine.get_physics_frames() - _challenge_hit_frame <= 120
		and after.distance_to(_challenge_hit_origin) >= 16.0
		and (
			after.distance_to(_stations[&"rubber_target"].global_position)
			> _challenge_hit_origin.distance_to(_stations[&"rubber_target"].global_position)
		)
	):
		_submit(_issue(_challenge, &"melee_then_retreat", _stations[&"rubber_target"]))
		_challenge = &""
		return
	if (
		event == "move"
		and player.state == Player.State.NORMAL
		and was_floor
		and now_floor
		and after.distance_to(_move_origin) > 20.0
		and _stations[&"table"].actual_overlap()
	):
		var proof := _issue(&"move", &"motion", _stations[&"table"])
		proof.from = _move_origin
		proof.to = after
		_submit(proof)
	elif event == "jump":
		if jumping and was_floor and after.y < before.y:
			_jump_departed = true
		if (
			_jump_departed
			and not was_floor
			and now_floor
			and _stations[&"tools"].actual_overlap()
			and absf(after.y - _stations[&"tools"].global_position.y) < 2.0
		):
			_submit(_issue(&"jump", &"landing", _stations[&"tools"]))
			_jump_departed = false
	elif event == "dash" or _challenge == &"dash_melee_practised":
		var station: PrologueStation = _stations[&"dash"]
		if not station.indicator or station.pulse_time < .7 or station.pulse_time > 1.8:
			return
		if not dashing:
			_dash_started = false
			return
		var line := station.global_position.x
		if not _dash_started:
			_dash_started = true
			_dash_origin = before
		var crossed := (
			(before.x < line and after.x >= line) or (before.x > line and after.x <= line)
		)
		if (
			crossed
			and was_floor
			and absf(after.y - station.global_position.y) <= 3.0
			and _dash_origin.distance_to(after) >= 16.0
		):
			var proof := _issue(&"dash", &"dash_segment", station)
			proof.from = _dash_origin
			proof.to = after
			_challenge_dash_frame = Engine.get_physics_frames()
			if event == "dash":
				_submit(proof)
			else:
				consume(proof)
			station.stop()


func actual_target_hit(station: PrologueStation, info: DamageInfo) -> void:
	if (
		not _is_owned(station)
		or info == null
		or info.get_attacker() != player
		or info.team != Combat.Team.PLAYER
		or _pending != null
	):
		return
	var event := next_event()
	var shot := (
		station == _stations[&"low_target"]
		and info.is_projectile
		and _loan.is_borrowing(flow.pistol)
		and info.source_id == flow.pistol.projectile.source_id
	)
	var cut := (
		station == _stations[&"rubber_target"]
		and not info.is_projectile
		and _loan.is_borrowing(flow.knife)
		and player._melee_phase == Player.MeleePhase.ACTIVE
	)
	if event == "shoot" and shot:
		_submit(_issue(&"shoot", &"projectile_contact", station))
	elif event == "melee" and cut:
		_submit(_issue(&"melee", &"melee_contact", station))
	elif (
		shot
		and _challenge == &"jump_shot_practised"
		and not player.is_on_floor()
		and _jump_departed
		and Engine.get_physics_frames() - _jump_frame <= 120
	):
		_submit(_issue(_challenge, &"air_projectile_contact", station))
		_challenge = &""
	elif (
		shot
		and _challenge == &"walk_shot_practised"
		and player.is_on_floor()
		and absf(player.velocity.x) >= 20.0
	):
		_submit(_issue(_challenge, &"moving_projectile_contact", station))
		_challenge = &""
	elif cut and _challenge == &"melee_retreat_practised":
		_challenge_hit_frame = Engine.get_physics_frames()
		_challenge_hit_origin = player.global_position
	elif (
		cut
		and (
			(
				_challenge == &"guard_melee_practised"
				and Engine.get_physics_frames() - _challenge_guard_frame <= 120
			)
			or (
				_challenge == &"dash_melee_practised"
				and Engine.get_physics_frames() - _challenge_dash_frame <= 120
			)
		)
	):
		_submit(_issue(_challenge, &"defended_melee_contact", station))
		_challenge = &""


func begin_optional(event: StringName) -> void:
	if not live() or _presenting or _pending != null or GameplayLock.is_locked():
		return
	if (
		event in [&"jump_shot_practised", &"walk_shot_practised"]
		and not _loan.is_borrowing(flow.pistol)
	):
		return
	if (
		event in [&"melee_retreat_practised", &"guard_melee_practised", &"dash_melee_practised"]
		and not _loan.is_borrowing(flow.knife)
	):
		return
	if not String(event) in Plan.OPTIONAL:
		return
	_challenge = event
	_challenge_guard_frame = -100000
	_challenge_dash_frame = -100000
	_challenge_hit_frame = -100000
	_panel.set_notice("自願組合練習；做完再歸還工具。")


func actual_trainer_contact(station: PrologueStation) -> void:
	if (
		not _is_owned(station)
		or not station.actual_overlap()
		or not station._pulse_sent
		or station.pulse_time < 1.1
		or _pending != null
	):
		return
	if (
		station == _stations[&"guard"]
		and (next_event() == "guard" or _challenge == &"guard_melee_practised")
	):
		var info := DamageInfo.create(1, Combat.Team.ENEMY, &"st16_guard_pulse")
		info.attacker = weakref(station)
		info.origin = station.global_position + Vector2(24, -Player.BODY_SIZE.y * .5)
		# Training is never Health damage, even while the player is invulnerable.
		# Use the genuine directional shield function; DASH/omni immunity cannot pass.
		if player.state == Player.State.NORMAL and player._guard(info) != Hurtbox.Guard.NONE:
			_challenge_guard_frame = Engine.get_physics_frames()
			if next_event() == "guard":
				_submit(_issue(&"guard", &"front_guard", station))
		else:
			_start_safe_recovery(station)
		station.stop()
	elif (
		station == _stations[&"dash"]
		and (next_event() == "dash" or _challenge == &"dash_melee_practised")
		and player.state != Player.State.DASH
	):
		_start_safe_recovery(station)
		station.stop()


func _start_safe_recovery(station: PrologueStation) -> void:
	_recovering_station = weakref(station)
	if not player.begin_training_recovery(self, flow.recovery_action, flow.recovery_duration):
		_recovering_station = null
	EventBus.toast_requested.emit("機器停了，可以重新開始。")


func _on_recovery_finished(owner: Node) -> void:
	if owner != self or _recovering_station == null or not live():
		return
	var station := _recovering_station.get_ref() as PrologueStation
	_recovering_station = null
	if _is_owned(station):
		_present(&"st16_p04_recovery", &"training_fall_shown", station, &"object")


func _idle_story() -> bool:
	return (
		not Transition.is_active()
		and not Story.is_cinematic_active()
		and Story._cinematic_queue.is_empty()
		and Story._passive_requests.is_empty()
		and not Story.atomic_request_pending()
		and not Story._atomic.is_busy()
		and not get_tree().paused
	)


func _physics_process(delta: float) -> void:
	if not live():
		return
	if _pending != null:
		if _retry_left > 0:
			_retry_left -= delta
			if _retry_left <= 0:
				retry_pending()
		return
	if _presenting or not _idle_story() or player.state != Player.State.NORMAL:
		return
	var event := next_event()
	if INFO.has(event):
		_present(
			INFO[event],
			StringName(event),
			_stations[&"latch"] if event == "p01_information" else _stations[&"old_k"],
			&"entrance"
		)
	elif event == "p06_contact":
		_present(&"st16_p06_contact", &"p06_contact", _stations[&"light"], &"object")


func _present(
	scene: StringName, event: StringName, station: PrologueStation, source: String
) -> void:
	if _presenting or not _is_owned(station) or not _idle_story():
		return
	var parts: PackedStringArray = flow.section_scenes.get(
		scene, PackedStringArray([String(scene)])
	)
	if parts.is_empty() or parts.size() > 8:
		return
	for part: String in parts:
		if Story.scene_source(StringName(part)) != flow.story_path:
			return
	_presenting = true
	if source == "person":
		Story.framing.interaction_started(station)
	stop_machines()
	for owned: PrologueStation in _stations.values():
		owned.prompt.enabled = false
	var complete := true
	for part: String in parts:
		_expected_scene = StringName(part)
		_expected_station = station
		_expected_context = {
			"framing_source": source,
			"source_id": "st16:%s@%d,%d" % [station.data.id, station.cell.x, station.cell.y]
		}
		_expected_request = 0
		_request_done = false
		_request_completed = false
		var outcome: Dictionary = await Story.play_and_wait_outcome(
			_expected_scene, false, _expected_context
		)
		if not live():
			return
		if (
			not outcome.get("completed", false)
			or not _request_done
			or not _request_completed
			or _expected_request <= 0
		):
			complete = false
			break
	_presenting = false
	for owned: PrologueStation in _stations.values():
		owned.prompt.enabled = true
	if complete:
		var proof := _issue(event, &"presentation", station)
		if proof != null:
			proof.request = _expected_request
			proof.scene = _expected_scene
			proof.context = _expected_context.duplicate(true)
			_submit(proof)
	_expected_scene = &""
	_expected_station = null
	_expected_context = {}
	_expected_request = 0


func _on_request_started(request: int, scene: StringName, context: Dictionary) -> void:
	if (
		_presenting
		and _expected_request == 0
		and scene == _expected_scene
		and context == _expected_context
	):
		_expected_request = request


func _on_request_settled(request: int, completed: bool) -> void:
	if _presenting and request == _expected_request:
		_request_done = true
		_request_completed = completed


func stop_machines() -> void:
	for station: PrologueStation in _stations.values():
		station.stop()


func _exit_tree() -> void:
	_disposed = true
	stop_machines()
	if is_instance_valid(player):
		player.cancel_training_recovery(self)
	_loan.close()
	_proofs.clear()
	_pending = null
	_expected_station = null
	_recovering_station = null
