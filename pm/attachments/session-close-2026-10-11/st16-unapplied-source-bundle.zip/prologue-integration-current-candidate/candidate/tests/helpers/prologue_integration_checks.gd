extends RefCounted


## Actual formal resources + pure strict save boundary; no fabricated producer completion.
static func run(suite: TestSuite) -> void:
	var original_flags := GameState.world_flags.duplicate(true)
	var original_progress := Progression.snapshot()
	var original_story := Story.progress_snapshot()
	var data := load(PrologueProgressPlan.LEVEL) as LevelData
	suite.check(
		data != null and data.prologue_flow != null and data.persistent_world,
		"formal prologue loads persistent Level/flow"
	)
	if data == null or data.prologue_flow == null:
		return
	var catalog := QuestCatalog.new()
	var source: Dictionary = JSON.parse_string(
		FileAccess.get_file_as_string(data.prologue_flow.story_path)
	)
	catalog.read_source(source, data.prologue_flow.story_path)
	suite.check(
		catalog.quests.size() == 1 and catalog.issues.is_empty(),
		"formal prologue quest validates actual runtime-fact AST and map destinations"
	)
	var predicate := {"flag": PrologueProgressPlan.PREFIX + "move", "equals": true}
	var forged_saved_flag := {"flags": {PrologueProgressPlan.PREFIX + "move": true}}
	var missing_provider := StoryConditionTree.evaluate(predicate, forged_saved_flag, {})
	suite.check(
		missing_provider.get("valid", false) and not missing_provider.get("value", true),
		"persisted same-name flag cannot impersonate Level-owned lesson fact"
	)
	var layout := LevelBuilder.parse(data)
	suite.check(
		(
			layout.is_valid()
			and layout.spawns.size() == 17
			and layout.spike_rects.is_empty()
			and layout.laser_rects.is_empty()
		),
		"actual training map has bounded true stations and no lethal terrain"
	)
	var owned: Dictionary = {}
	for spawn: Dictionary in layout.spawns:
		var station := spawn["resource"] as PrologueStationData
		suite.check(
			(
				station != null
				and not owned.has(station.id)
				and station.resource_path == "res://data/prologue/stations/%s.tres" % station.id
			),
			"map station identity has exact unique source"
		)
		if station != null:
			owned[station.id] = spawn
	suite.check(
		(
			owned.has(&"tools")
			and owned[&"tools"]["cell"] == Vector2i(44, 16)
			and owned[&"tools"]["position"].y == 272
		),
		"cargo landing target has actual 48-pixel platform elevation"
	)
	for root: StringName in data.prologue_flow.section_scenes:
		var parts: PackedStringArray = data.prologue_flow.section_scenes[root]
		suite.check(
			not parts.is_empty() and parts.size() <= 8, "each actual authored section is bounded"
		)
		for id: String in parts:
			suite.check(
				(
					Story.has_scene(StringName(id))
					and Story.scene_source(StringName(id)) == data.prologue_flow.story_path
				),
				"true loaded scene has the section source, not a fake namespace match"
			)
			var scene: Dictionary = Story._scenes.get(id, {})
			suite.check(
				(
					not scene.has("results")
					and not scene.has("set_flags")
					and not scene.has("give_items")
					and not scene.has("options")
				),
				"lesson presentation cannot award or stand in for an actual operation"
			)
	var empty := PrologueProgressPlan.prepare_world({})
	suite.check(
		empty.has("world") and not empty["world"][PrologueProgressPlan.PREFIX + "move"],
		"fresh actual world does not manufacture movement"
	)
	suite.check(
		PrologueProgressPlan.propose_observed({}, &"jump").has("error"),
		"later input without real prerequisite is rejected"
	)
	var whole_skip := PrologueProgressPlan.propose_exit({}, true)
	suite.check(
		(
			whole_skip.has("world")
			and whole_skip["world"][PrologueProgressPlan.PREFIX + "skipped"]
			and not whole_skip["world"][PrologueProgressPlan.PREFIX + "shoot"]
		),
		"whole skip records exit, never fake six skills"
	)
	var cursor: Dictionary = empty["world"]
	for event: String in PrologueProgressPlan.REQUIRED:
		var proposed := PrologueProgressPlan.propose_observed(cursor, StringName(event))
		suite.check(
			not proposed.has("error"), "ordered true operation plan can advance: %s" % event
		)
		cursor = proposed.get("world", cursor)
	suite.check(
		(
			PrologueProgressPlan.propose_exit(cursor, false).get("level")
			== "res://data/levels/ch1_pawnshop.tres"
		),
		"normal committed exit proposes true first chapter and no reward"
	)
	var snapshot := RunSnapshot.capture(
		PrologueProgressPlan.LEVEL,
		{
			"position": [168, 320],
			"world": {},
			"area": {"world": {}, "consumed": {}, "damage": {}},
			"health": 4,
			"loadout": {}
		}
	)
	var invalid := snapshot.duplicate(true)
	invalid["runtime"]["world"][PrologueProgressPlan.PREFIX + "p01_information"] = 1
	suite.check(
		PrologueRunPort.prepare_snapshot(invalid).has("error"),
		"raw JSON integer cannot normalize into an authorized lesson bool"
	)
	invalid = snapshot.duplicate(true)
	invalid["runtime"]["world"][PrologueProgressPlan.PREFIX + "unknown"] = true
	suite.check(
		PrologueRunPort.prepare_snapshot(invalid).has("error"),
		"unknown training leaf rejected while generic old saves remain compatible"
	)
	invalid = snapshot.duplicate(true)
	invalid["runtime"]["world"][PrologueProgressPlan.PREFIX + "p01_information"] = true
	suite.check(
		PrologueRunPort.prepare_snapshot(invalid).has("error"),
		"valid bool in only one owner copy still rejects half-installed lesson progress"
	)
	var detached: Node = load("res://game/main.gd").new()
	var false_level := Level.new()
	var false_session := PrologueSession.new()
	var fake := PrologueSession.Evidence.new()
	var port := PrologueRunPort.new()
	port.configure(detached)
	suite.check(
		(
			port.commit(false_level, false_session, fake, false, false).get("status")
			== "invalid_source"
		),
		"same-name detached objects cannot authorize real operation or writer"
	)
	false_session.free()
	false_level.free()
	detached.free()
	suite.check(
		(
			GameState.world_flags == original_flags
			and Progression.snapshot() == original_progress
			and Story.progress_snapshot() == original_story
		),
		"all pure proposals/refusals leave real owners unchanged"
	)


static func actual_level(suite: Node, main: Node, level: Level) -> void:
	var session := level.prologue
	suite.check(
		session.live() and session.level == level and session.player == level.player,
		"actual Main has a live Level-owned observation service"
	)
	var fake := PrologueSession.Evidence.new()
	fake.issuer = weakref(session)
	fake.level_ref = weakref(level)
	fake.player_ref = weakref(level.player)
	fake.station_ref = weakref(session._stations[&"tools"])
	fake.resource = session._stations[&"tools"].data
	fake.layout = level._layout
	fake.event = &"tools_taken"
	fake.kind = &"interaction"
	fake.serial = 999
	fake.overlap_at_issue = true
	var before := session.world()
	suite.check(
		(
			(
				main._prologue_port.commit(level, session, fake, false, false).get("status")
				== "invalid_source"
			)
			and session.world() == before
		),
		"actual owner refuses forged bool-overlap evidence not issued by real callback"
	)
	var loan := session.formal_loadout()
	suite.check(
		loan == level.run_snapshot()["loadout"],
		"actual save captures formal projection while same live Loadout is borrowed"
	)

	var before_flags := GameState.world_flags.duplicate(true)
	var before_deaths := GameState.deaths
	var before_health := level.player.health.current
	var temporary := PrologueStation.new()
	temporary.data = session._stations[&"guard"].data
	temporary.session = session
	temporary.cell = session._stations[&"guard"].cell
	# A copied name/resource/cell alone is not the actual loaded map station node.
	suite.check(
		not session._is_owned(temporary),
		"copied station with correct resource/cell is still not actual authority"
	)
	temporary.free()
	suite.check(
		(
			GameState.deaths == before_deaths
			and GameState.world_flags == before_flags
			and level.player.health.current == before_health
		),
		"source refusals preserve real health and first death"
	)

	var target: PrologueStation = session._stations[&"low_target"]
	var contact := DamageInfo.create(
		1, Combat.Team.PLAYER, session.flow.pistol.projectile.source_id
	)
	contact.attacker = weakref(level.player)
	contact.is_projectile = true
	var before_contacts := target._contacts
	target.hitbox.hit_received.emit(contact)
	suite.check(
		target._contacts == before_contacts and session.world() == before,
		"a fake hit signal without actual target Health damage cannot produce an observed contact"
	)


static func projectile_provenance(suite: Node, level: Level) -> void:
	var spec: ProjectileSpec = level.prologue.flow.pistol.projectile
	var shot: Projectile = ProjectilePool.spawn(
		spec, Vector2(-200, -200), Vector2.RIGHT, Combat.Team.PLAYER, 1.0, level.player
	)
	suite.check(
		shot._shooter != null and shot._shooter.get_ref() == level.player,
		"genuine pooled shot remembers only its current real shooter"
	)
	shot.deactivate()
	suite.check(
		shot._shooter == null and not shot.active, "pool retirement releases real shooter lease"
	)
	var anonymous: Projectile = ProjectilePool.spawn(
		spec, Vector2(-200, -200), Vector2.RIGHT, Combat.Team.PLAYER
	)
	suite.check(
		anonymous._shooter == null,
		"legacy pooled spawn cannot inherit a previously released player attribution"
	)
	anonymous.deactivate()
