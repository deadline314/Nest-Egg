# ST16 × NE246 窄合成候選

CPU only，沒有採用、引擎執行、Git、PM 或 capabilities。這是 **NE246 post** 與 **ST16 89b16 latest** 的四檔窄合成，不是另一份 runtime authority。Root 已凍結兩包都未改。

## 精確採用順序

1. Root 按 NE246 原 7 個窄 patch 採用，其 freeze SHA `02a7a659152c2e0db4d378053a95662abf344281649907a4a7c845b325e51848`。Main／Level／Story 的 post SHA 見此 `composition-audit.json`、preimages 與 `patch-index.json`。
2. 從 `C:/tmp/prologue-integration-current-candidate` 採 49-file index 的其餘 45 個 patch；**排除 Main、Level、Story、tools/prologue_entry_probe.gd**。該包 freeze SHA `56f8c5209929714b76c1314a3afd5b9f04d8822d5bad2b429faf0706b090246f`。
3. 套本包四個 exact narrow patches；前三份 preimage 是 NE246 post，工具 preimage 是 ST16 latest candidate。沒有修改 Source／Port／Scene授權／RunSnapshot／NE246 DialogueLayer／flags／wallet／custody。新資源／模板與 generator 都沿用 ST16 包。
4. 新 UID 由 editor import 自然生成；Root 收自己的 UID、保留外來 UID。先完整 raw editor import、實際原 selector，再各 fresh profile 原生模式。不得因 Main/Player/rig pose paths 挑 ALL 就縮 selector。

## 合成內容與根據

- Main 原有 initial radio checkpoint 和 final settlement RETRY/RECOVERY／退出守門完整保留。prologue busy 只增加在 _save_run 最前，防 prepared/install/publish 期間任何普通保存／checkpoint覆蓋候選。既有 _story_retry_radio_checkpoint 可被同一 actual Main prologue port 的有界 lifecycle queue 延後，原 white-list preserved。
- Level 原初始化、Encounter identity、clinic/source/live lease、真正入隊／冷接續全保留，僅 training hooks。Player/Visual/最新動作源来自 ST16 latest包，该包已逐行核NE247/NE245原變動，不替換。
- Story 原新 manual-reading／initial/final checkpoint 流程完整保留，僅 ST16 chapter source 与 actual Main synchronous runtime write guard。正式原子 Port/source 永远不通過作者或 lesson JSON 編造 readiness。
- **真實 probe 兼容必须修改**：NE246 radio现在手動确認，舊 _tick 只在 is_cinematic_active 发送 InputEventAction，P01 radio会卡。以只讀 DialogueLayer.radio_visible 查询发 genuine ui_accept，仍由 UI 等字／輸入 release／初次寫入／结算。没有 call_finish、auto_skip、fake receipt／seen／flag。query包含fade不会完成Story，单個按键由真實UI自行接收。
- 仍保留三模式 normal / normal-write-retry / whole-skip，實際Main菜单／Player action／真實弱射手／训练失误非死亡／可靠寫入拒绝／實際按鈕确認／第一章真 dinner入口。保護 Snapshot `78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c` 原 bytes，没有 replacement。

## CPU 結果与原生限制

213 個 source composition 檢查、4個 gdparse clean。逐行证明 NE246 相對89base新增／變動程式碼仍保留，以及初次保存／最后结算／真radio query。此檢查不是 Godot語意、Source行為或畫面测试；不能取代真實 native。

`native-source-manifest.json` 98個 exact sources，合並 NE246 27file post / ST16最新49files；`run_native.py` strict validate后可印準備命令，**Root授權 --execute 才啟動**。Root如果任一額外來源改變，先立新準確manifest，不跳SHA guard。

```powershell
python C:/tmp/prologue-ne246-composition-candidate/run_native.py --root <adopted-root> --out C:/tmp/st16-ne246-normal --baseline 89b16e63d39ca18a7385d930a744f09c28846d61 --mode normal
```

Root採用后--baseline應使用實際HEAD並同時保留unpublished組合SHA。fresh APPDATA/LOCALAPPDATA/out，direct actual native exe owned PID memory，所有 raw/ERROR/RID/timeout/漂移保留；exit0与计数不得自動認畫面通過。

完整风险见 ST16最新README：P01路人/排水孔的完整视觉还缺正式实现，几何训练器美术/家具和回復姿势接觸尚未native、借装冷Continue/menu/死亡、120%文字/多比例/真手把/真正完整第一章仍pending。沒有因此把ST16票標完成，Root負責票务。该包不改變NE246原phase事实／階段可用性。
