# ST16 Root-only staged adoption driver

這包只證明來源補丁能精準組合；未採入 Root 工作樹、未執行引擎。匯入／原始 selector／真新遊戲／loan death／cold Continue／menu／quit／P06 耐久出口／地圖構圖仍待原生驗收；capabilities=[]。原三模式及兩個 loan death 模式的 predicates 保留，CPU 型別盤點不是 Godot semantic pass。

## 來源與拒絕

凍結 baseline HEAD 6402090a2dcfdf6145cf3719b231cf8bf3a5faa8。所有 package manifest 的確切 SHA 已鎖在 driver。Protected RunSnapshot 必須仍為 78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c，沒有 Snapshot 補丁。

預設原 full45 仍拒絕 PauseMenu／RunSaveSuite 兩個真 content mismatch（exit3）；mismatches 與 evidence/original 保留。Root 先審 composition5 的兩個 narrow diff，才選 --use-composition5。composition5 檢查時 14 個 existing preimages 精準相符、36 個新增來源真正 ABSENT，共 50 個唯一來源／56 次補丁操作。source-stage-inventory.json 記每個 source 的 initial raw/LF SHA、逐階段 pre/current/post raw/LF SHA 和最終 SHA；evidence/composition5/plan.json 是完整可重算計畫。

順序為 full45（composition5 只替代其中兩檔）→原 full 新 probe ABSENT seed→composition4→revision3 五檔→revision4 probe。seed 只建立 Ctmp shadow 中的 composition4 中間 preimage，不把不存在的 actual probe 假稱既有檔。Root apply 是精準 verified hunks 產出的 final bytes；不 fuzzy/offset 套用、不重新定義 preimage。

原 native99 的五個 drift 仍列 OLD_NATIVE_MANIFEST_REJECTED_OUTSIDE_ADOPTION_SCOPE；即使 source_check_ok=true，舊 native manifest 也不可用。這五檔、其他工具、selector/registry、foreign UID 都不寫／不 rollback。Root 已知審查的原因不轉成偽造原 manifest 通過；採用後由 Root 的完整 7873＋runtime inventory 另建新執行 manifest。

BG31 core/asset_prefetch.gd 僅以 outside_patch_source_hash 觀測，這次觀測 SHA 899a16248df56a7da81ed857bb96840c2463b94bb9f2e698fe53212f78643528；不採用／不寫入／不 rollback。若 Root 先採 BG31 改變 Main，driver 必須拒絕 Main 舊 preimage；不能藉更新 baseline 讓它通過。outside source 或 HEAD 改變也會改 plan SHA，需重新 check/review token。

## Root 執行（本包未執行 apply）

先停止該工作樹的解析與引擎程序。每次 --out 必須是新的 C:/tmp 絕對目錄，不能在實際工作樹內。

```powershell
$py='C:/Users/stanl/AppData/Local/Programs/Python/Python312/python.exe'
$driver='C:/tmp/prologue-staged-adoption-candidate/staged_adoption.py'
$wt='C:/Users/stanl/.codex/worktrees/chapter-one-runtime/Nest-Egg'
# default check-only，原 mismatch 應拒絕，保留原結果
& $py $driver --root $wt --out C:/tmp/st16-root-original-check
# Root 讀過 composition5 兩 diff 後，仍只 check
& $py $driver --root $wt --out C:/tmp/st16-root-composition5-check --use-composition5
# Root 明確決定採用時才執行；填入上一份已審查 plan.sha256 的精確值
& $py $driver --root $wt --out C:/tmp/st16-root-composition5-apply --use-composition5 --apply --reviewed-plan-sha '<reviewed plan SHA>'
```

apply 開關和 reviewed-plan-sha 同時必要；所有 source/Snapshot 必須再次相符。套入範圍只限 50 source paths 與同目錄 transaction 暫存檔；備份只存 Ctmp。發生錯誤只回復仍等於自己 postimage 的已寫來源；有並行變更時拒絕覆蓋。這是停機後的 exact source adoption，不是跨 50 檔的作業系統原子交易。driver 不製造 UID，只列新增 GD 自然匯入後 Root 可留的 UID companion allowlist。

## CPU 證據

cpu-results.json 23/0：真 root check-only 拒絕／成功、exact hunk、ABSENT、stale-before-write 拒絕、scope 不寫保護檔。verify_cpu.py 可在 Ctmp 重驗 package hashes／計畫和拒絕邊界，26/0，不接引擎。dynamic-local-audit.json 枚舉最終 probe 的 39 個 := locals；3 次 Main Node 動態 read 均顯式 Dictionary。TYPE_AUDIT.md 記實際 typed callee 來源。沒有新增確定推型 blocker；原 Player gdtoolkit SET 限界仍照實保留。
