#!/usr/bin/env python3
"""CPU-only Ctmp verification. Does not read/write actual repo or launch engine/Git."""
from pathlib import Path
import importlib.util, json, hashlib
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('st16_driver', HERE/'staged_adoption.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
checks=[]
def check(name,condition):
 checks.append({'check':name,'passed':bool(condition)})
def refused(name,fn):
 try:fn()
 except d.Refusal:check(name,True)
 else:check(name,False)
pk=d.packages(True);ops=d.build_ops(pk,True)
check('five frozen packages and every artifact SHA unchanged', len(pk)==5)
check('56 operations 50 exact source paths',len(ops)==56 and len({o['path']for o in ops})==50)
refused('parent path refused',lambda:d.relative('../sample.gd'))
refused('absolute path refused',lambda:d.relative('/sample.gd'))
refused('backslash alias refused',lambda:d.relative('ui\\sample.gd'))
p=b'--- a/sample.gd\n+++ b/sample.gd\n@@ -1 +1 @@\n-before\n+after\n'
check('exact hunk replay',d.patch_text(b'before\n',p,'sample.gd')==b'after\n')
refused('stale hunk has no fuzzy replacement',lambda:d.patch_text(b'changed\n',p,'sample.gd'))
refused('wrong source header refused',lambda:d.patch_text(b'before\n',p,'other.gd'))
check('ABSENT new source hunk',d.patch_text(None,b'--- /dev/null\n+++ b/new.gd\n@@ -0,0 +1 @@\n+new\n','new.gd')==b'new\n')
for label in ['original','composition5']:
 pth=HERE/'evidence'/label/'plan.json';payload=pth.read_bytes();plan=json.loads(payload)
 check(label+' plan SHA matches retained bytes',d.sha(payload)==(pth.parent/'plan.sha256').read_text('utf-8').strip())
 check(label+' protected Snapshot exact',plan['protected_snapshot_sha256']==d.SNAPSHOT and plan['protected_snapshot_exact'])
 check(label+' native99 retains five drifts without authority',len(plan['old_native99_rejection'])==5 and all(not r['adoption_write']for r in plan['old_native99_rejection'])and not plan['old_native_manifest_usable'])
 check(label+' engine/native/caps pending',not plan['engine_run']and not plan['native_accepted']and plan['capabilities']==[])
 check(label+' BG31 outside patch recorded',plan['outside_patch_source_hash'][0]['path']=='core/asset_prefetch.gd'and all(o['path']!='core/asset_prefetch.gd'for o in ops))
 if label=='original':check('original two actual mismatches still reject',not plan['source_check_ok']and {r['path']for r in plan['source_mismatches']}==d.REPLACEMENTS)
 else:
  check('composition5 current exact sources match',plan['source_check_ok']and not plan['source_mismatches'])
  check('36 explicit ABSENT source preimages',sum(r['required_initial']=='ABSENT'for r in plan['initial_sources'])==36)
  check('all 56 shadow hunk operations verified',len(plan['stages'])==56 and all(r['status']=='EXACT_PATCH_VERIFIED'for r in plan['stages']))
  check('protected Snapshot and registry outside patch',all(o['path']not in ['core/run_snapshot.gd','tests/smoke_test.gd','tests/known_failures.txt','tools/select_tests.py']for o in ops))
# Only a Ctmp plain-text fixture, never an actual owner/Level/source.
f=HERE/'cpu-refusal-fixture';f.mkdir(exist_ok=True);(f/'sample.gd').write_bytes(b'changed\n')
refused('apply stale source refused before any write',lambda:d.apply(f,{'sample.gd':b'before\n'},{'sample.gd':b'after\n'},f/'unused-backup'))
check('stale refusal preserves Ctmp fixture bytes', (f/'sample.gd').read_bytes()==b'changed\n')
result={'classification':'CPU frozen artifact/exact patch/refusal checks only; no repo/engine/runtime','checks':len(checks),'failures':sum(not c['passed']for c in checks),'details':checks,'capabilities':[]}
(HERE/'reproducible-cpu-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps({'checks':result['checks'],'failures':result['failures']}))
raise SystemExit(1 if result['failures']else 0)
