# 五個模式的動態 local 審查

固定 r4 probe `8dc8d939f5a191bd2f05aff8d530c859461dc6ee88f0d88174970130fc778b38`；沒有修改它的任何 predicate。三個正常模式與兩個 loan-death 模式共用的所有 `:=` 宣告列於 dynamic-local-audit.json。

- 先前確定問題 `var saved := _main._run_store.read()` 已是明列 Dictionary；menu_saved 及普通 saved 讀取也明列 Dictionary。`_main: Node` 的 dynamic call 沒有再交給 `:=` 推型。
- borrowed/formal/world 來自明列 Dictionary 回傳型別的 Player／Session。find button／revealed death screen／await wait 各有 Button／DeathScreen／bool 回傳型別。
- DamageInfo.create 真來源回傳 DamageInfo；GameState.deaths 真來源整數；Level.player 明列 Player，world position/facing 為引擎與 Player 明列型別。
- observer 的 Node weakref 結果刻意明列 Variant，僅在 is_instance_valid 之後讀取，沒把動態回傳自動推導為 local。Dictionary／shader／WeakRef 已顯式。

目前沒找到第二個確定的 Variant-local 警告，不等於五模式 Godot semantic 已通過。Root 必須先真正 editor import（看整份 raw，exit0 不足），再原生跑全部路徑；若 compiler 仍有窄型別警告，要保留原 raw，只修型別，不改 predicate／來源／動作斷言。
