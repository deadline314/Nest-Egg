#!/usr/bin/env python3
"""Root-only exact staged patch driver. Default CHECK ONLY. Never launches engine/Git.
Scope remains pending original selector, native normal/loan death/cold/menu/quit/P06/art.
Old native99 rejection is diagnostic; this driver cannot make it runtime-ready.
"""
from pathlib import Path, PurePosixPath
import argparse, difflib, hashlib, json, os, re, stat, sys, time
HERE=Path(__file__).resolve().parent
PACKAGES={
 'full':(Path('C:/tmp/prologue-integration-current-candidate'),'56f8c5209929714b76c1314a3afd5b9f04d8822d5bad2b429faf0706b090246f'),
 'composition':(Path('C:/tmp/prologue-ne246-composition-candidate'),'07c90bcbbcc9d124720329dfc731bf86f3fc1beb10a01670e60e48d5234280d2'),
 'revision3':(Path('C:/tmp/prologue-revision3-candidate'),'345c2a0aee54610b77346d8c269b868564f8737740dfdf9903fa98cc556b4e30'),
 'revision4':(Path('C:/tmp/prologue-revision4-candidate'),'ba8e832bcfc068c80c96474c4ac9296c60d70538d4328bf2813165d9f5b50cdd'),
 'composition5':(Path('C:/tmp/prologue-ne246-composition5-candidate'),'59c74363453526b8bfc34023e7e11901ddc7ea5dcb52eade09d78328403ae0d7')}
SNAPSHOT='78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c'
BASE_HEAD='6402090a2dcfdf6145cf3719b231cf8bf3a5faa8'
EXCLUDED={'game/main.gd','game/level/level.gd','autoload/story.gd','tools/prologue_entry_probe.gd'}
REPLACEMENTS={'ui/pause_menu.gd','tests/suite/test_run_save.gd'}
class Refusal(Exception):pass
def sha(data):return hashlib.sha256(data).hexdigest()
def lf(data):return data.replace(b'\r\n',b'\n')
def load_json(p):return json.loads(p.read_text(encoding='utf-8'))
def relative(value):
 p=PurePosixPath(value)
 if p.is_absolute() or '..' in p.parts or '\\' in value or ':' in value:raise Refusal('unsafe relative scope '+value)
 return p.as_posix()
def checked_path(root,rel):
 rel=relative(rel);p=root/rel
 if not p.resolve().is_relative_to(root.resolve()):raise Refusal('path escapes root: '+rel)
 for q in [p,*p.parents]:
  if q==root.parent:break
  if q.exists() and (q.is_symlink() or getattr(q.lstat(),'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',1024)):
   raise Refusal('reparse/symlink scope is forbidden: '+str(q))
 return p

def patch_text(before,patch,rel):
 # Exact hunks only. No fuzz/offset matching. Input and output represented in LF.
 old=lf(before or b'').decode('utf-8').splitlines(keepends=True)
 lines=lf(patch).decode('utf-8').splitlines(keepends=True)
 if len(lines)<2 or lines[0].rstrip('\n') not in ['--- a/'+rel,'--- /dev/null'] or lines[1].rstrip('\n')!='+++ b/'+rel:
  raise Refusal('bad patch headers '+rel)
 out=[];cursor=0;i=2
 while i<len(lines):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n?',lines[i])
  if not m:raise Refusal('non-hunk patch line '+rel+' '+str(i+1))
  start=int(m[1]);count=int(m[2]) if m[2] is not None else 1;newcount=int(m[4]) if m[4] is not None else 1
  begin=0 if start==0 else start-1
  if begin<cursor or begin>len(old):raise Refusal('invalid/overlapping hunk '+rel)
  out.extend(old[cursor:begin]);cursor=begin;i+=1;consumed=0;created=0
  while i<len(lines) and not lines[i].startswith('@@ '):
   line=lines[i];i+=1
   if line.startswith('\\ No newline'):raise Refusal('non-newline patch needs explicit supported parser '+rel)
   if not line or line[0] not in ' +-':raise Refusal('invalid patch payload '+rel)
   kind=line[0];text=line[1:]
   if kind in ' -':
    if cursor>=len(old) or old[cursor]!=text:raise Refusal('exact hunk context mismatch '+rel)
    cursor+=1;consumed+=1
   if kind in ' +':out.append(text);created+=1
  if consumed!=count or created!=newcount:raise Refusal('hunk range/count mismatch '+rel)
 out.extend(old[cursor:]);return ''.join(out).encode('utf-8')

def packages(use5):
 result={}
 for label,(base,expected) in PACKAGES.items():
  if label=='composition5' and not use5:continue
  actual=sha((base/'freeze-manifest.json').read_bytes())
  if actual!=expected:raise Refusal('frozen package changed '+label)
  manifest=load_json(base/'freeze-manifest.json')
  for rel,wanted in manifest['artifacts'].items():
   p=checked_path(base,rel)
   if not p.is_file() or sha(p.read_bytes())!=wanted:raise Refusal('frozen artifact changed '+label+'/'+rel)
  result[label]=base
 return result

def operation(base,label,row):
 rel=relative(row['path']);pre=row.get('preimage_sha256',row.get('pre_sha256'));post=row.get('candidate_sha256',row.get('post_sha256'))
 target=checked_path(base,'candidate/'+rel);data=target.read_bytes()
 if sha(data)!=post:raise Refusal('candidate hash mismatch '+label+'/'+rel)
 pp=checked_path(base,row['patch']);patch=pp.read_bytes()
 if row.get('patch_sha256') and sha(patch)!=row['patch_sha256']:raise Refusal('patch hash mismatch '+label+'/'+rel)
 frozen_pre=None
 if pre is not None:
  frozen_pre=checked_path(base,'preimages/'+rel).read_bytes()
  if sha(frozen_pre)!=pre:raise Refusal('preimage artifact mismatch '+label+'/'+rel)
 if patch_text(frozen_pre,patch,rel)!=lf(data):raise Refusal('patch does not produce frozen candidate LF '+label+'/'+rel)
 return {'stage':label,'path':rel,'pre_sha256':pre,'pre_lf_sha256':sha(lf(frozen_pre)) if pre else None,
         'post_sha256':post,'post_lf_sha256':sha(lf(data)),'patch_sha256':sha(patch),'patch_bytes':patch,'post_bytes':data}

def build_ops(pk,use5):
 full=load_json(pk['full']/'patch-index.json');ops=[]
 for row in full:
  if row['path'] in EXCLUDED:continue
  if use5 and row['path'] in REPLACEMENTS:
   replacement=next(r for r in load_json(pk['composition5']/'patch-index.json')if r['path']==row['path'])
   ops.append(operation(pk['composition5'],'01-full45-with-composition5',replacement))
  else:ops.append(operation(pk['full'],'01-full45',row))
 # ABSENT actual file is an original new-file addition. Only shadow intermediate is seeded.
 seed=next(r for r in full if r['path']=='tools/prologue_entry_probe.gd')
 ops.append(operation(pk['full'],'01b-new-probe-seed-from-frozen-full',seed))
 for label,stage in [('composition','02-composition4'),('revision3','03-revision3'),('revision4','04-revision4')]:
  for row in load_json(pk[label]/'patch-index.json'):ops.append(operation(pk[label],stage,row))
 return ops

def read_head(root):
 # Read metadata only; no Git executable or mutation.
 dot=root/'.git'
 if dot.is_file():
  value=dot.read_text('utf-8').strip();g=Path(value.removeprefix('gitdir: '));g=g if g.is_absolute() else root/g
 else:g=dot
 head=(g/'HEAD').read_text('utf-8').strip()
 if not head.startswith('ref: '):return head
 ref=head[5:];common=(g/(g/'commondir').read_text('utf-8').strip()).resolve() if (g/'commondir').is_file() else g
 loose=common/ref
 if loose.is_file():return loose.read_text('utf-8').strip()
 for line in (common/'packed-refs').read_text('utf-8').splitlines() if (common/'packed-refs').is_file() else []:
  if line.endswith(' '+ref):return line.split()[0]
 return 'UNKNOWN'

def read_scope(root,ops):
 first={}
 for op in ops:first.setdefault(op['path'],op)
 initial={};rows=[];mismatches=[]
 for rel,op in sorted(first.items()):
  p=checked_path(root,rel)
  if p.exists() and not p.is_file():raise Refusal('non-file at source scope '+rel)
  data=p.read_bytes() if p.is_file() else None;initial[rel]=data
  row={'path':rel,'required_initial':'ABSENT' if op['pre_sha256'] is None else op['pre_sha256'],
       'current_sha256':sha(data) if data is not None else None,'current_lf_sha256':sha(lf(data)) if data is not None else None,
       'exact_initial_match':(sha(data) if data is not None else None)==op['pre_sha256']}
  rows.append(row)
  if not row['exact_initial_match']:mismatches.append(row)
 return initial,rows,mismatches

def simulate(initial,ops,out):
 memory=dict(initial);steps=[];blocked=set()
 for number,op in enumerate(ops):
  rel=op['path'];before=memory.get(rel);actual=sha(before) if before is not None else None
  row={k:v for k,v in op.items() if not k.endswith('_bytes')};row.update({'operation':number+1,'current_sha256':actual,'current_lf_sha256':sha(lf(before)) if before is not None else None})
  if actual!=op['pre_sha256'] or rel in blocked:
   row['status']='REFUSED_PREIMAGE';blocked.add(rel);steps.append(row);continue
  produced=patch_text(before,op['patch_bytes'],rel)
  if sha(produced)!=op['post_lf_sha256']:raise Refusal('stage LF post verification failed '+rel)
  # Preserve the exact frozen post bytes after proving hunk output, including CRLF policy.
  memory[rel]=op['post_bytes'];row['status']='EXACT_PATCH_VERIFIED';steps.append(row)
  shadow=out/'shadow'/(str(number+1).zfill(2)+'-'+op['stage'])/rel;shadow.parent.mkdir(parents=True,exist_ok=True);shadow.write_bytes(memory[rel])
 return memory,steps

def compare_old_native(root,pk,owned):
 old=load_json(pk['revision4']/'native-source-manifest.json')['sources'];rows=[]
 for rel,expected in sorted(old.items()):
  if rel in owned:continue
  p=checked_path(root,rel);actual=sha(p.read_bytes()) if p.is_file() else None
  if actual!=expected:rows.append({'path':rel,'old_native99_sha256':expected,'actual_current_sha256':actual,
   'status':'OLD_NATIVE_MANIFEST_REJECTED_OUTSIDE_ADOPTION_SCOPE','adoption_write':False})
 return rows

def readonly_extras(root):
 rel='core/asset_prefetch.gd';p=checked_path(root,rel)
 return [{'path':rel,'source_sha256':sha(p.read_bytes()) if p.is_file() else None,'role':'BG31 outside patch; not adopted/written/rolled back; native pending'}]

def apply(root,initial,final,out):
 # Root must stop parser/runtime jobs. Every source is rechecked immediately before mutation.
 for rel,before in initial.items():
  p=checked_path(root,rel);now=p.read_bytes() if p.is_file() else None
  if now!=before:raise Refusal('source changed after preflight '+rel)
 if sha(checked_path(root,'core/run_snapshot.gd').read_bytes())!=SNAPSHOT:raise Refusal('protected Snapshot changed during preflight')
 token=sha(json.dumps({r:sha(d) for r,d in sorted(final.items())},sort_keys=True).encode())[:12]
 temps={};written=[]
 try:
  for rel,data in sorted(final.items()):
   p=checked_path(root,rel);p.parent.mkdir(parents=True,exist_ok=True)
   if initial[rel] is not None:
    backup=out/'backups'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(initial[rel])
   temp=p.with_name('.'+p.name+'.st16-'+token+'.tmp')
   if temp.exists():raise Refusal('transaction temp already exists '+str(temp))
   with temp.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
   temps[rel]=temp
  for rel,data in sorted(final.items()):
   p=checked_path(root,rel);now=p.read_bytes() if p.is_file() else None
   if now!=initial[rel]:raise Refusal('concurrent source change before replace '+rel)
   os.replace(temps[rel],p);written.append(rel)
  for rel,data in final.items():
   if checked_path(root,rel).read_bytes()!=data:raise Refusal('post-write source verification failed '+rel)
  return {'status':'EXACT_SCOPE_APPLIED','sources_written':written,'runtime_ready':False,'capabilities':[]}
 except Exception as error:
  failures=[]
  for rel in reversed(written):
   p=checked_path(root,rel)
   if not p.is_file() or p.read_bytes()!=final[rel]:failures.append('refused to overwrite changed source '+rel);continue
   if initial[rel] is None:p.unlink()
   else:p.write_bytes(initial[rel])
  raise Refusal('apply failed: '+str(error)+'; rollback conflicts='+str(failures))
 finally:
  for temp in temps.values():
   if temp.exists():temp.unlink()

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
 ap.add_argument('--use-composition5',action='store_true',help='Root reviewed the TWO new narrow patches; never hides original mismatches')
 ap.add_argument('--apply',action='store_true',help='ROOT ONLY, after review and parser/runtime stopped; default is check-only')
 ap.add_argument('--reviewed-plan-sha',help='required with apply: exact plan SHA from a prior check-only run')
 args=ap.parse_args();root=args.root.resolve();out=args.out
 if not out.is_absolute() or out.exists() or out.resolve().is_relative_to(root):raise Refusal('fresh absolute Ctmp output outside actual root required')
 if not re.match(r'^[A-Za-z]:[/\\]tmp[/\\]',str(out)):raise Refusal('all shadow/evidence must be Ctmp')
 out.mkdir(parents=True);pk=packages(args.use_composition5);ops=build_ops(pk,args.use_composition5)
 initial,rows,mismatches=read_scope(root,ops)
 snap=sha(checked_path(root,'core/run_snapshot.gd').read_bytes());protected_match=snap==SNAPSHOT
 for rel,data in initial.items():
  if data is not None:
   p=out/'shadow/initial'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 final,steps=simulate(initial,ops,out)
 native_drifts=compare_old_native(root,pk,set(initial))
 # Full original45 remains separately rejected even when Root selected composition5.
 original45=build_ops(packages(False),False);_,oldrows,oldmismatches=read_scope(root,original45)
 finals=[{'path':rel,'initial_state':'ABSENT' if initial[rel] is None else sha(initial[rel]),'final_sha256':sha(data) if data is not None else None,'final_lf_sha256':sha(lf(data)) if data is not None else None}for rel,data in sorted(final.items())]
 core={'scope':'ROOT ONLY; source adoption is NOT readiness; pending import/original selector/native normal/loan death/cold/menu/quit/P06/art',
  'frozen_base_head':BASE_HEAD,'actual_head_metadata':read_head(root),'root':str(root),'selected_composition5':args.use_composition5,
  'package_manifest_sha256':{k:PACKAGES[k][1]for k in pk},'protected_snapshot_sha256':snap,'protected_snapshot_exact':protected_match,
  'initial_sources':rows,'stages':steps,'final_sources':finals,'source_mismatches':mismatches,
  'original45_mismatches_retained':oldmismatches,'old_native99_rejection':native_drifts,'old_native_manifest_usable':not native_drifts,
  'outside_patch_source_hash':readonly_extras(root),
  'new_uid_metadata_allowlist':[rel+'.uid'for rel,data in initial.items()if data is None and rel.endswith('.gd')],
  'uid_policy':'driver does not fabricate/copy UID; Root may retain ONLY own import-generated allowlist companions; existing/foreign metadata untouched',
  'source_check_ok':not mismatches and protected_match,'engine_run':False,'native_accepted':False,'capabilities':[]}
 plan_bytes=json.dumps(core,ensure_ascii=False,sort_keys=True,indent=2).encode('utf-8');plan_sha=sha(plan_bytes)
 (out/'plan.json').write_bytes(plan_bytes);(out/'plan.sha256').write_text(plan_sha+'\n','utf-8')
 if args.apply:
  if not core['source_check_ok']:raise Refusal('source preimages/Snapshot refuse apply; report preserved')
  if args.reviewed_plan_sha!=plan_sha:raise Refusal('Root apply needs the exact prior reviewed plan SHA')
  result=apply(root,initial,final,out);(out/'apply-result.json').write_text(json.dumps(result,indent=2),'utf-8')
 print(json.dumps({'mode':'APPLY' if args.apply else 'CHECK_ONLY','source_check_ok':core['source_check_ok'],'source_mismatch_count':len(mismatches),
  'old_native99_rejected':bool(native_drifts),'operations':len(ops),'unique_sources':len(final),'plan_sha256':plan_sha,'out':str(out)},indent=2))
 return 0 if core['source_check_ok'] else 3
if __name__=='__main__':
 try:sys.exit(main())
 except Refusal as e:print('REFUSED: '+str(e),file=sys.stderr);sys.exit(3)
