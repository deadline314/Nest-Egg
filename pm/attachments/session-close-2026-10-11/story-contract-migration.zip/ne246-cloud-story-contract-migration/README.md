# 第一章正式契約遷移：未完成 WIP 凍結交接

本包僅供 Root 審查與未完成工作紀錄。**不得整包當作已驗證修復採用，不代表正式第一章或序章可完整通關。**使用者要求收尾停止開發後，本包停止擴充；未改 repository、PM、Git、測試選擇器或 known failures，未啟動 Godot。

原始 Cloud ALL 自然退出：基準 `a5f2a1ba9eb64233b56108c3e930c68bffa52158`，86,162 checks／126 NEW FAILURES／0 known／exit 1，另有 3 SCRIPT errors。126 項明細和原始 raw/report 由 Root 保存；本包沒有取得所有逐项根因，不能宣稱會修復全部 126 項。

## 已形成的候選

- `autoload/story.gd`：正式 result 的「真布林 true 旗標投影」先檢查 TYPE_BOOL，避免合法字串 result（`ch1_supper_choice="unset"`）和 bool 比較造成 SCRIPT error。保留正式結果必須經真 Main/Port durable commit 的授權守門。
- 三個舊 animated scene 的完整歷史資料抽到獨立 `tests/fixtures/ch1_legacy_cinematics.json`；來源是 `2dab08d7a433d49af5ae8419ddcc794a16c83994:data/story/ch1_kasa.json`，並保存原 pawnshop intro 資源來源 SHA。不回填已移除的產品 opening。
- ChapterCutscenes 舊 opening／三段 pose-policy 斷言、Pacing 舊 budget 斷言保留在明確 legacy fixture；新增 live helper 驗證真已發布的三段 animated 資料、實際 actor pose／steps／估時計算，以及實際 dinner／home／death／portal 入口。
- Continuity 保留 legacy 完成旗標契約於不同 fixture ID；正式 c09 新增「legacy 不得直接授權」及純結果投影負控制。原正式付款／收盤／死亡正授權仍屬 Main/Port receipt 原生證據，沒有在 suite 假造 Source。
- Ch1Map 只完成部分結構遷移：保留歷史 opening／budget checks，正式 flags 從現有純 result 投影讀取，預載測試改引用真已載入的 home/kitchen。沒有降低原時間／遭遇門檻。

## 明確尚未完成，禁止把 WIP 當作整組可通過

1. Continuity `_test_once_scenes` 仍套舊一次性 dinner 契約，正式 dinner 已是 repeatable presentation；`_test_death_matrix` 仍由 bare Level 呼叫正式 c09，沒有真 Main receipt。尚未建立隔離、完整 owner/catalog 恢復的 legacy 機制案例。
2. Ch1Map `_test_story_flags` 仍直接播放正式 dinner／brief／Ali 並期望舊直接授旗標；其中舊 Ali scene 已移除。這些尚未合法遷移。
3. Ch1Map `_test_scenes_play_through` 的舊 waiter 不檢查 `play_and_wait` 回傳成功；formal admission 拒絕仍可能被誤標完成。尚未改成獨立真 CutscenePlayer 呈現驗證，不能將既有斷言當作完成證據。
4. Ch1Map `_test_walkthrough` 原來手設門旗標測試幾何路由，bare Level 正式末段不具 Main 授權；不能用它宣稱真第一章通關。未建立獨立 legacy terminal 機制 fixture。
5. Pacing 的原 `Story.scene_lines` 回呼尚未對 formal dispatch graph 提供完整對話數估計；原時間／遭遇斷言保留，尚未原生驗證其數值。
6. `live_seconds` 是 CPU 已寫的實際資料/呈現契約檢查候選，未經 Godot semantic import 或任何 suite；不代表舞台構圖、美術、完整劇情與 producer capability 全通過。P06 正式 intro 仍由 ST16 未完成候選所有。
7. 新 legacy 完成案例已有 owner/catalog 還原斷言，但沒有原生執行證据，不能替代正式死亡／重試／Continue 邊界驗證。

## 來源與檢查

`source-manifest.json` 列 7 個來源 exact byte preimage、LF preimage、postimage SHA 和各自窄 diff；新增兩檔前提均 ABSENT。`preimage/` 保存修改前原始 bytes；`candidate/` 是候選，不是產品採用狀態。`cpu-final-report.json` 保存來源零漂移、fixture 邊界及受保護 Snapshot/Source/Port 觀測 SHA。六個候選 GDScript 的 gdparse exit 0、空 raw 僅代表 grammar，不代表 Godot 型別／行為／原生通過。

先前可獨立審查的產品布林 guard、mixed-result regression 與 CombatHud 實際 catalog conservation 窄包仍凍結在 `C:/tmp/ne246-cloud-story-fixture-review/`，manifest SHA `a33ae04426a833a810bb592de01a23f6bd659dee7c121e0cac66c8e8768fe68d`。本 WIP 未再修改或合併該包，也未碰 custody 另有的 HUD tooltip 工作。

若未來重啟，Root 必須先審上述未完成項、確認 actual preimages，完成真正 legacy/live 分域與全 owner/catalog 還原，再 semantic import → 相關局部 suites → 原 selector／原 ALL；保留現在所有 red，不加 known failure，不移除斷言、不以舊 opening 或假 flags/capabilities 掩蓋正式缺口。此次交接後停止開發。
