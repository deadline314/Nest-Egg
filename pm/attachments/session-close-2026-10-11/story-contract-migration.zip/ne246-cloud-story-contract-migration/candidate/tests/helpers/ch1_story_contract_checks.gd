extends RefCounted
## Published CH1 presentation/data contract only, never Main/source capability.
const LEGACY: JSON = preload("res://tests/fixtures/ch1_legacy_cinematics.json")
const FORMAL_PATH := "res://data/story/ch1_kasa.json"
const LIVE: Array[String] = ["ch1_t_supper_stay_address", "ch1_c09_wake", "ch1_c14_home"]

static func legacy_scene(id: StringName) -> Dictionary:
	return (LEGACY.data["scenes"][String(id)] as Dictionary).duplicate(true)

static func catalog_bytes() -> PackedByteArray:
	return var_to_bytes([Story._scenes, Story._scene_sources, Story._npc_topic_catalog,
		Story._scene_chapter, Story._chapters, Story._speakers, Story._respawn_scenes,
		Story._death_scenes, Story._death_sequences, Story._death_notes, GameState.flag_defaults])

static func owner_bytes() -> PackedByteArray:
	return var_to_bytes([GameState._install_source(), Story._install_source(), Progression.snapshot(), StoryItems.snapshot()])

static func live_seconds(s: TestSuite) -> float:
	var before := owner_bytes()
	var catalog := catalog_bytes()
	var source: JSON = load(FORMAL_PATH) as JSON
	s.check(source != null and source.data is Dictionary, "formal CH1 published source is an actual imported JSON resource")
	if source == null or not source.data is Dictionary:
		return 0.0  # Failed check above; this is not accepted as valid duration.
	var authored: Dictionary = source.data["scenes"]
	var animated: Array[String] = []
	for id: String in authored:
		if authored[id].get("mode") == "animated":
			animated.append(id)
	animated.sort()
	var required: Array[String] = LIVE.duplicate()
	required.sort()
	s.check(animated == required, "published formal source has the exact three current animated scenes, without a fabricated P06 opening")
	var total := 0.0
	for id: String in LIVE:
		var scene: Dictionary = Story._scenes.get(id, {})
		s.check(not scene.is_empty() and Story.scene_source(StringName(id)) == FORMAL_PATH and authored.has(id) and scene == authored[id], "%s loaded scene and source path match the actual published JSON" % id)
		if scene.is_empty():
			continue
		s.check(StoryAtomicCoordinator.is_formal(scene) and scene.get("mode") == "animated", "%s is the real formal animated contract" % id)
		var steps: Variant = scene.get("steps")
		s.check(steps is Array and not steps.is_empty() and steps.size() <= 64, "%s has real bounded nonempty authored steps" % id)
		if not steps is Array or steps.is_empty():
			continue
		s.check(CutsceneChecker.validate(id, scene, Story._speakers).is_empty(), "%s actual steps, actors, speakers and stage resources validate" % id)
		s.check(CutsceneChecker.staging_problems(id, scene).is_empty(), "%s actual feet anchors are above the dialogue reserve; full visual proof is separate" % id)
		var says := 0
		var actors := 0
		for raw: Variant in steps:
			if not raw is Dictionary:
				continue
			var step: Dictionary = raw
			if step.get("do") == "say":
				says += 1
			if step.get("do") == "actor":
				actors += 1
			for key: String in ["pose", "then"]:
				if step.get("do") not in ["actor", "pose", "move"] or not step.has(key):
					continue
				var pose: String = str(step[key])
				s.check(CutsceneActor.POSES.has(pose), "%s uses an actual supported CutsceneActor %s pose" % [id, pose])
				if CutsceneChecker.SUPPORTED_POSES.has(pose):
					s.check(not str(step.get("pose_reason", "")).strip_edges().is_empty() and not str(step.get("pose_support", "")).strip_edges().is_empty(), "%s restricted live pose has an authored reason and physical support even without legacy policy metadata" % id)
		s.check(says > 0 and (actors > 0 or scene.get("overlay") == true), "%s contains real dialogue and actors or an explicitly authored overlay" % id)
		var duration: float = CutsceneChecker.estimate_seconds(scene)
		s.check(is_finite(duration) and duration > 0.0, "%s actual estimated duration is finite and positive; missing budgets do not default to zero" % id)
		var changed: Dictionary = scene.duplicate(true)
		changed["steps"].append({"do": "wait", "time": 0.37})
		s.check(is_equal_approx(CutsceneChecker.estimate_seconds(changed) - duration, 0.37), "%s real estimator observes an additional authored wait" % id)
		total += duration
	_main_hooks(s)
	s.check(owner_bytes() == before and catalog_bytes() == catalog, "live presentation checks leave every owner and full catalog unchanged")
	return total

static func _main_hooks(s: TestSuite) -> void:
	var pawn := load("res://data/levels/ch1_pawnshop.tres") as LevelData
	var dawn := load("res://data/levels/ch1_pawnshop_dawn.tres") as LevelData
	var stall := load("res://data/levels/ch1_stall.tres") as LevelData
	s.check(pawn != null and dawn != null and stall != null, "formal chapter boundary uses actual LevelData resources")
	if pawn == null or dawn == null or stall == null:
		return
	s.check(pawn.chapter == &"ch1_kasa" and pawn.intro_scene == &"" and not Story.has_scene(&"ch1_c01_open"), "published pawnshop deliberately leaves upstream intro to ST16/P06; this does not prove an integrated prologue")
	var layout: LevelLayout = LevelBuilder.parse(pawn)
	var actual_dinner := false
	for trigger: Dictionary in layout.story_triggers:
		actual_dinner = actual_dinner or trigger.get("scene") == &"ch1_b_dinner"
	s.check(layout.is_valid() and pawn.story_triggers.has("ch1_b_dinner") and actual_dinner, "actual pawnshop layout contains the real formal dinner trigger")
	var dinner: Dictionary = Story._scenes.get("ch1_b_dinner", {})
	var food: Dictionary = Story._scenes.get("ch1_b_dinner_food", {})
	s.check(dinner.get("binding") == "dinner" and dinner.get("then") == "ch1_b_dinner_food" and StoryAtomicCoordinator.is_formal(food) and Story._scene_set_flags(&"ch1_b_dinner_food").has("ch1_dinner_done"), "real dinner chain completes only through its formal food segment")
	s.check(dawn.intro_scene == &"ch1_c14_home" and dawn.complete_after_intro and dawn.next_level.is_empty(), "actual dawn entry owns formal home and the terminal chapter hook")
	var home_gate := false
	for resource: Resource in stall.legend.values():
		if resource is PortalData and (resource as PortalData).id == &"stall_home":
			var gate := resource as PortalData
			home_gate = gate.target_level == dawn.resource_path and gate.requires_flag == &"ch1_supper_done" and gate.cinematic_preview_scene == &"ch1_c14_home"
	s.check(home_gate, "actual stall-home portal requires supper completion and points to the actual formal home entry")
	var deaths: Variant = Story._death_scenes.get(&"ch1_kasa", [])
	var clinic := false
	if deaths is Array:
		for entry: Variant in deaths:
			if entry is Dictionary and entry.get("scene") == "ch1_c09_wake":
				clinic = entry.get("unless_flag") == "ch1_first_death_done" and entry.get("free") == true and entry.get("register_checkpoint") == true
	s.check(clinic and Story._scene_set_flags(&"ch1_c09_wake") == ["ch1_first_death_done"], "real first-death declaration and exact formal result agree; actual Main receipt tests own positive granting")
