extends Node
## 劇情服務：載入章節劇本（data/story/*.json）、播放過場／通訊對話、記錄本輪已看過的場景。
##   過場（cinematic）：暫停遊戲，一次一段，依序排隊。
##   通訊（radio）：凍結世界，確認逐句閱讀。
##   對話（dialogue）：場景人物，玩家主動觸發，暫停遊戲逐句推進（見 NpcActor）。
## 場景可以帶 variants，依累計死亡次數改用不同的台詞（見 StoryReactions）；劇本品質檢查見 StoryLint。
## 台詞全部在資料檔，修改不需改程式；死亡重來時已看過的場景不會重播。
## 多章節：CHAPTER_PATHS 列出的劇本會合併成同一份講者與場景表（場景 id 全域唯一，慣例以 c2_ 等前綴區分章節），
## 關卡以 LevelData.chapter 指定自己屬於哪一章（章節標題、結尾卡、預告取自該章）。

signal scene_started(scene_id: StringName, mode: StringName)
signal scene_finished(scene_id: StringName)
## 完成或取消的等待接點；取消不觸發 scene_finished，因而不寫完成旗標或發放獎勵。
signal request_settled(request: int, completed: bool)
signal presentation_cancelled(scene_id: StringName, context: Dictionary, reason: StringName, request: int)
signal result_rejected(scene_id: StringName, request: int, status: StringName, message: String)
signal request_started(request: int, scene_id: StringName, context: Dictionary)
signal decision_committed(scene_id: StringName, request: int, option_id: StringName)

const AtomicCoordinator = preload("res://core/story_atomic_coordinator.gd")
const LiteralContinuation = preload("res://core/story_literal_continuation.gd")

const CHAPTER_PATHS: Array[String] = [
	"res://data/story/chapter_01.json",
	"res://data/story/chapter_02.json",
	# 新故事（傘）：第一章的章節資訊；台詞與過場由 ST-9 接上。
	"res://data/story/ch1_kasa.json",
	# 動畫過場（只有 scenes，用 for_chapter 指明屬於哪一章）。
	"res://data/story/cutscenes_ch1.json",
	"res://data/story/cutscenes_ch2.json",
]
const DEFAULT_CHAPTER := &"chapter_01"
const MODE_CINEMATIC := &"cinematic"
const MODE_RADIO := &"radio"
## 動畫過場（資料檔以 steps 描述，見 CutscenePlayer）：與過場一樣暫停遊戲並排隊。
const MODE_ANIMATED := &"animated"
## 場景人物對話（玩家主動觸發）：與過場一樣暫停遊戲、逐句推進，但句數上限較高，且不算「看過就不再播」。
const MODE_DIALOGUE := &"dialogue"
## 地圖上的對話氣泡（見 MapBubbles）：不暫停、不鎖操作，講者頭上冒出短句。沒有氣泡宿主（不在關卡裡）或講者不在地圖上時改用通訊。
const MODE_BUBBLES := &"bubbles"
## 對話長度守則（見 design/04-story/STORY.md）：過場每段至多 6 句，通訊每段 1～2 句。
const MAX_CINEMATIC_LINES := 6
const MAX_RADIO_LINES := 2
const MAX_DIALOGUE_LINES := 8
## 氣泡守則（見 skill chapter-design）：一段 ≤ 4 句、每句 ≤ 30 字；戰鬥中的 bark ≤ 2 句、每句 ≤ 16 字。
const MAX_BUBBLE_LINES := 4
const MAX_BUBBLE_CHARS := 30
const MAX_BARK_LINES := 2
const MAX_BARK_CHARS := 16

## 測試用：過場立即結束（仍會發出開始／結束訊號）。
var auto_skip := false

## 章節 id -> 章節資訊（標題、副標、結尾卡、預告）。
var _chapters: Dictionary[StringName, Dictionary] = {}
var _speakers: Dictionary = {}
var _scenes: Dictionary = {}
var _scene_sources: Dictionary[String, String] = {}
var _npc_topic_catalog: Dictionary[String, Dictionary] = {}
## 場景 id -> 所屬章節 id（劇本品質檢查依章節加總）。
var _scene_chapter: Dictionary[String, StringName] = {}
## 死亡畫面的小字（各章節合併）與各章節的重生通訊（章節 id -> 清單），見 StoryReactions。
var _death_notes: Array = []
## 地圖氣泡的宿主（Level 登記，離開關卡時清除）。
var _bubble_host: MapBubbles
var _respawn_scenes: Dictionary = {}
var _death_scenes: Dictionary = {}
var _death_sequences: Dictionary = {}
var _seen: Dictionary[StringName, bool] = {}
var _completed: Dictionary[StringName, bool] = {}
var _cinematic_queue: Array[Dictionary] = []
var _current_cinematic: StringName = &""
var _presentation_context: Dictionary = {}
var _framing_token := 0
var _presentation_generation := 0
var _request_serial := 0
var _current_request := 0
var _finished_request := 0
var _waiters: Dictionary[int, bool] = {}
var _request_results: Dictionary[int, bool] = {}
var _request_failure_scenes: Dictionary[int, StringName] = {}
var _passive_requests: Dictionary[StringName, Array] = {}
var _resetting_presentation := false
var framing: CinematicFraming
var _layer: DialogueLayer
var _player: CutscenePlayer
var _atomic := AtomicCoordinator.new()
var _atomic_request_scenes: Dictionary[int, StringName] = {}
var _atomic_request_contexts: Dictionary[int, Dictionary] = {}
var _atomic_chains: Dictionary[int, Array] = {}
var _atomic_pending_resets: Array[Dictionary] = []
var _atomic_pending_finishes: Array[Dictionary] = []
var _atomic_decision_layer: CanvasLayer
var _atomic_decision_root: PanelContainer
var _atomic_choice_lock := 0
var _atomic_skipped := false
var _atomic_publishing := false

class FormalInputGate extends Node:
	var service: Node
	func _input(event: InputEvent) -> void:
		if not is_instance_valid(service) or not service.is_atomic_request(service.current_presentation_request()):
			return
		if event.is_action_pressed("pause") or event.is_action_pressed("ui_cancel"):
			get_viewport().set_input_as_handled()
			service.cancel_atomic_request(&"user_cancel")

class PreparedInstall extends RefCounted:
	var seen: Dictionary[StringName, bool] = {}
	var completed: Dictionary[StringName, bool] = {}


func _install_source() -> Dictionary:
	var catalog := _owner_catalog_fingerprint(_scenes, 32768)
	if catalog.has("error"):
		return {"owner_error": "scene catalog: " + str(catalog["error"])}
	var topics := _owner_catalog_fingerprint(_npc_topic_catalog, 8192)
	if topics.has("error"):
		return {"owner_error": "topic catalog: " + str(topics["error"])}
	var waiters: Array = []
	var results: Array = []
	for request: int in _waiters:
		waiters.append([request, _waiters[request]])
	for request: int in _request_results:
		results.append([request, _request_results[request]])
	return {"seen": _seen, "completed": _completed, "generation": _presentation_generation,
		"request_serial": _request_serial, "current_request": _current_request, "finished_request": _finished_request,
		"cinematic": String(_current_cinematic), "context": _presentation_context, "queue": _cinematic_queue,
		"waiters": waiters, "results": results, "request_failure_scenes": _request_owner_rows(_request_failure_scenes), "passive": _passive_requests, "resetting": _resetting_presentation,
		"scene_fingerprint": catalog["data"], "atomic_requests": _request_owner_rows(_atomic_request_scenes),
		"atomic_chains": _request_owner_rows(_atomic_chains), "atomic_contexts": _request_owner_rows(_atomic_request_contexts), "scene_sources": _scene_sources, "topic_fingerprint": topics["data"]}


## Runtime request IDs are integers, so represent them as rows for the pure-data
## owner proof. Keep the exact request/context content; durable saves are unchanged.
func _request_owner_rows(values: Dictionary) -> Array:
	var rows: Array = []
	var requests := values.keys()
	requests.sort()
	for request: Variant in requests:
		rows.append([request, values[request]])
	return rows


## Stream exact current contents; no stale cached hash and no nested owner AST.
## Validate each source entry at its ORIGINAL boundary/depth before hashing it.
## Objects/callbacks cannot be serialized out of sight into an accepted owner proof.
func _owner_catalog_fingerprint(values: Dictionary, entry_node_limit: int) -> Dictionary:
	if values.size() > RunSaveCodec.MAX_CONTAINER:
		return {"error": "catalog entry count exceeds the codec bound"}
	var keys := values.keys()
	for key: Variant in keys:
		if typeof(key) not in [TYPE_STRING, TYPE_STRING_NAME] or String(key).length() > RunSaveCodec.MAX_TEXT:
			return {"error": "catalog has an invalid source key"}
	keys.sort()
	var context := HashingContext.new()
	context.start(HashingContext.HASH_SHA256)
	context.update(var_to_bytes([values.size(), entry_node_limit]))
	var byte_count := 0
	for key: Variant in keys:
		var errors := RunSaveCodec.validate_tree(values[key], entry_node_limit)
		if not errors.is_empty():
			return {"error": (String(key) + ": " + errors[0]).left(512)}
		var encoded := var_to_bytes([key, values[key]])
		byte_count += encoded.size()
		if byte_count > RunSaveCodec.MAX_BYTES:
			return {"error": "catalog encoded contents exceed the codec byte bound"}
		context.update(encoded)
	return {"data": context.finish().hex_encode()}


func _catalog_install_fingerprint() -> String:
	# The catalog is already validated as authored content. A bounded runtime
	# owner proof needs its identity, rather than another nested copy of its ASTs.
	var context := HashingContext.new()
	context.start(HashingContext.HASH_SHA256)
	context.update(var_to_bytes(_scenes))
	return context.finish().hex_encode()


## Full restores require the caller to cancel presentation while the old run is intact.
## Story batches only replace progress, retaining current pending/queued reservations.
func prepare_install(raw: Variant, whole_run: bool) -> Dictionary:
	var errors := RunSaveCodec.validate_tree(raw)
	if not errors.is_empty():
		return {"error": errors[0]}
	if not raw is Array or raw.size() > _scenes.size():
		return {"error": "install/story/completed must be a bounded scene list"}
	if whole_run and (_current_cinematic != &"" or _current_request != 0 or _finished_request != 0 or not _cinematic_queue.is_empty() or not _passive_requests.is_empty() or not _waiters.is_empty() or _resetting_presentation):
		return {"error": "install/story/presentation must settle before whole-run preparation"}
	var prepared := PreparedInstall.new()
	if not whole_run:
		prepared.seen = _seen.duplicate()
	for value: Variant in raw:
		if typeof(value) not in [TYPE_STRING, TYPE_STRING_NAME] or not has_scene(StringName(value)) or prepared.completed.has(StringName(value)):
			return {"error": "install/story/completed unknown or repeated scene"}
		prepared.completed[StringName(value)] = true
		prepared.seen[StringName(value)] = true
	if not whole_run:
		for id: StringName in _completed:
			if not prepared.completed.has(id):
				return {"error": "install/story/batch cannot remove completed scenes"}
	return {"data": prepared}


## Never clears requests, callbacks, framing or queues, and emits nothing.
func _install_prepared(prepared: PreparedInstall) -> void:
	_seen = prepared.seen
	_completed = prepared.completed


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	framing = CinematicFraming.new()
	add_child(framing)
	_layer = DialogueLayer.new()
	add_child(_layer)
	_layer.cinematic_finished.connect(_on_cinematic_finished)
	_layer.radio_finished.connect(_on_passive_finished)
	_layer.radio_settlement_requested.connect(_on_radio_settlement_requested)
	_layer.radio_settlement_cancel_requested.connect(_on_radio_settlement_cancel_requested)
	_layer.radio_checkpoint_requested.connect(_on_radio_checkpoint_requested)
	_layer.radio_checkpoint_cancel_requested.connect(_on_radio_checkpoint_cancel_requested)
	scene_finished.connect(_apply_scene_flags)
	scene_finished.connect(_record_legacy_completion)
	var formal_input_gate := FormalInputGate.new()
	formal_input_gate.service = self
	formal_input_gate.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(formal_input_gate)
	EventBus.player_died.connect(func(_cause: StringName) -> void: reset_active_presentation(&"death"))
	load_all()
	if FileAccess.file_exists(GameState.STORY_SAVE_PATH):
		GameState.load_story_progress()
	for problem in validate():
		push_error("[Story] %s" % problem)
	for issue in lint_warnings():
		push_warning("[Story] %s" % StoryLint.format(issue))


## 載入 CHAPTER_PATHS 的所有章節（先清空）。單一章節壞掉只記錄錯誤，不影響其他章節。
func load_all() -> void:
	if _atomic.is_busy() or not _atomic_request_scenes.is_empty():
		push_warning("[Story] cannot replace loaded source while a formal request is active")
		return
	_chapters.clear()
	_speakers.clear()
	_scenes.clear()
	_scene_sources.clear()
	_npc_topic_catalog.clear()
	_scene_chapter.clear()
	_death_notes.clear()
	_respawn_scenes.clear()
	_death_scenes.clear()
	_death_sequences.clear()
	GameState.flag_defaults.clear()
	for path in CHAPTER_PATHS:
		load_chapter(path)


## 讀取一份章節劇本並合併進講者與場景表。講者 id 相同時後讀的覆蓋前者；場景 id 重複時略過後者並記錄錯誤。
func load_chapter(path: String) -> bool:
	if _atomic.is_busy() or not _atomic_request_scenes.is_empty():
		push_warning("[Story] cannot replace loaded source while a formal request is active")
		return false
	var json: JSON = load(path) as JSON if ResourceLoader.exists(path) else null
	if json == null or typeof(json.data) != TYPE_DICTIONARY:
		push_error("[Story] 無法讀取劇本：%s" % path)
		return false
	var data: Dictionary = json.data
	if data.has("flag_defaults"):
		GameState.register_flag_defaults(data["flag_defaults"], path)
	var info: Dictionary = data.get("chapter", {})
	# 沒有 chapter 區塊的檔案只提供場景，並以 for_chapter 指定所屬章節（不覆蓋章節資訊）。
	var chapter_id := StringName(str(info.get("id", data.get("for_chapter", path.get_file().get_basename()))))
	if data.has("chapter") or not data.has("for_chapter"):
		_chapters[chapter_id] = info
	var speakers: Variant = data.get("speakers", {})
	if typeof(speakers) == TYPE_DICTIONARY:
		_speakers.merge(speakers, true)
	var scenes: Variant = data.get("scenes", {})
	if typeof(scenes) == TYPE_DICTIONARY:
		for scene_id: String in scenes.keys():
			if _scenes.has(scene_id):
				push_error("[Story] 場景 id「%s」重複（%s），已略過後者" % [scene_id, path])
				continue
			_scenes[scene_id] = scenes[scene_id]
			_scene_sources[scene_id] = path
			_scene_chapter[scene_id] = chapter_id
	var topics: Variant = data.get("optional_interactions", {})
	if topics is Dictionary and topics.size() <= 64 and RunSaveCodec.validate_tree(topics, 8192).is_empty():
		_npc_topic_catalog[path] = topics.duplicate(true)
	elif data.has("optional_interactions"):
		push_error("[Story] %s optional_interactions 格式無效，拒絕額外話題。" % path)
	var notes: Variant = data.get("death_notes", [])
	if typeof(notes) == TYPE_ARRAY:
		_death_notes.append_array(notes)
	elif data.has("death_notes"):
		push_error("[Story] %s 的 death_notes 必須是陣列" % path)
	if data.has("respawn_scenes"):
		_respawn_scenes[chapter_id] = data["respawn_scenes"]
	if data.has("death_scenes"):
		_death_scenes[chapter_id] = data["death_scenes"]
	if data.has("death_sequences"):
		_death_sequences[chapter_id] = data["death_sequences"]
	return true


## 章節資訊。chapter 留空代表預設章節（第一章）。找不到時回傳空字典。
func chapter_info(chapter: StringName = DEFAULT_CHAPTER) -> Dictionary:
	if not _chapters.has(chapter):
		push_warning("[Story] 找不到章節：%s" % chapter)
		return {}
	return _chapters[chapter]


func chapter_ids() -> Array[StringName]:
	var ids: Array[StringName] = []
	for id in _chapters:
		ids.append(id)
	return ids


## 場景結束時設定它的 set_flags（旗標名稱清單，存進 GameState 的本輪旗標；出入口的 requires_flag 與之後的劇情分支都看它）。
func _apply_scene_flags(id: StringName) -> void:
	if is_atomic_scene(id):
		return  # Already installed by the durable batch; do not run legacy producers.
	var scene: Variant = _scenes.get(String(id), null)
	if typeof(scene) != TYPE_DICTIONARY:
		return
	var flags: Variant = (scene as Dictionary).get("set_flags", [])
	if typeof(flags) != TYPE_ARRAY:
		return
	for flag: Variant in flags:
		GameState.set_flag(StringName(str(flag)))


## 檢查劇本是否符合守則，回傳問題清單（空代表沒問題）：講者存在且有頭像、過場／通訊的句數、每句有文字。
func validate() -> PackedStringArray:
	var problems := PackedStringArray()
	for speaker_id: String in _speakers.keys():
		var portrait := str((_speakers[speaker_id] as Dictionary).get("portrait", ""))
		if portrait.is_empty() or not ResourceLoader.exists(portrait):
			problems.append("講者 %s 的頭像不存在：%s" % [speaker_id, portrait])
	for scene_id: String in _scenes.keys():
		var scene: Dictionary = _scenes[scene_id]
		var mode := str(scene.get("mode", "radio"))
		if AtomicCoordinator.is_formal(scene):
			var atomic_checked := _atomic_validate_targets(StringName(scene_id))
			if not atomic_checked.get("valid", false):
				problems.append("場景 %s 的正式合約無效：%s" % [scene_id, atomic_checked.get("message", "")])
				continue
			if mode == "dispatch":
				continue  # A control node is not a fabricated empty conversation.
		if scene.has("set_flags") and (typeof(scene["set_flags"]) != TYPE_ARRAY or (scene["set_flags"] as Array).any(func(f: Variant) -> bool: return str(f).is_empty())):
			problems.append("場景 %s 的 set_flags 必須是非空的旗標名稱清單" % scene_id)
		if mode == String(MODE_ANIMATED):
			problems.append_array(CutsceneChecker.validate(scene_id, scene, _speakers))
			continue
		var lines: Array = scene.get("lines", [])
		var limit := _line_limit(mode, scene)
		problems.append_array(StoryReactions.validate_variants(scene_id, scene, limit, _speakers))
		if lines.is_empty():
			problems.append("場景 %s 沒有任何台詞" % scene_id)
		elif lines.size() > limit:
			problems.append("場景 %s（%s）有 %d 句，上限 %d 句" % [scene_id, mode, lines.size(), limit])
		for entry: Variant in lines:
			if typeof(entry) != TYPE_DICTIONARY:
				problems.append("場景 %s 有一句不是物件" % scene_id)
				continue
			if not _speakers.has(str(entry.get("speaker", ""))):
				problems.append("場景 %s 的講者「%s」未定義" % [scene_id, entry.get("speaker", "")])
			if str(entry.get("text", "")).is_empty():
				problems.append("場景 %s 有一句沒有文字" % scene_id)
			if mode == String(MODE_BUBBLES):
				var cap := MAX_BARK_CHARS if bool(scene.get("bark", false)) else MAX_BUBBLE_CHARS
				if str(entry.get("text", "")).length() > cap:
					problems.append("場景 %s（氣泡%s）的句子超過 %d 字：%s" % [scene_id, "，戰鬥短句" if bool(scene.get("bark", false)) else "", cap, entry.get("text", "")])
	for scene_id: String in _scenes.keys():
		problems.append_array(_validate_chain(scene_id, _scenes[scene_id]))
	for chapter_id: StringName in _respawn_scenes:
		problems.append_array(StoryReactions.validate_respawns(String(chapter_id), _respawn_scenes[chapter_id], has_scene))
	for chapter_id: StringName in _death_scenes:
		problems.append_array(StoryReactions.validate_death_scenes(String(chapter_id), _death_scenes[chapter_id], has_scene, _scene_set_flags))
	for chapter_id: Variant in _death_sequences:
		problems.append_array(validate_death_sequences(str(chapter_id), _death_sequences[chapter_id]))
	if not _death_notes.is_empty():
		problems.append_array(StoryReactions.validate_notes("（全部）", _death_notes))
	for issue in StoryLint.errors_of(lint()):
		problems.append(StoryLint.format(issue))
	return problems


## 接續場景（then）：只能接在過場／動畫過場之後，目標必須存在，且不能形成迴圈。
func _validate_chain(scene_id: String, scene: Variant) -> PackedStringArray:
	var problems := PackedStringArray()
	if scene is Dictionary and AtomicCoordinator.is_formal(scene):
		var atomic_seen: Dictionary = {}
		var atomic_cursor := scene_id
		while not atomic_cursor.is_empty():
			if atomic_seen.has(atomic_cursor) or atomic_seen.size() >= AtomicCoordinator.MAX_CHAIN:
				problems.append("場景 %s 的正式 then 形成循環或超過上限（%s）" % [scene_id, atomic_cursor])
				break
			atomic_seen[atomic_cursor] = true
			var checked := _atomic_validate_targets(StringName(atomic_cursor))
			if not checked.get("valid", false):
				problems.append("場景 %s 的正式續段無效：%s" % [scene_id, checked.get("message", "")])
				break
			atomic_cursor = str((_scenes[atomic_cursor] as Dictionary).get("then", ""))
		return problems
	if typeof(scene) != TYPE_DICTIONARY or not (scene as Dictionary).has("then"):
		return problems
	var mode := str((scene as Dictionary).get("mode", "radio"))
	if mode != String(MODE_CINEMATIC) and mode != String(MODE_ANIMATED):
		problems.append("場景 %s（%s）不能設定 then，只有過場與動畫過場可以接續" % [scene_id, mode])
	var seen: Dictionary = {scene_id: true}
	var next := str((scene as Dictionary)["then"])
	while next != "":
		if not _scenes.has(next):
			problems.append("場景 %s 的接續場景「%s」不存在" % [scene_id, next])
			break
		if seen.has(next):
			problems.append("場景 %s 的接續形成迴圈（%s）" % [scene_id, next])
			break
		var next_mode := str((_scenes[next] as Dictionary).get("mode", "radio"))
		if next_mode != String(MODE_CINEMATIC) and next_mode != String(MODE_ANIMATED):
			problems.append("場景 %s 的接續場景「%s」是 %s，只能接過場或動畫過場" % [scene_id, next, next_mode])
		seen[next] = true
		next = str((_scenes[next] as Dictionary).get("then", ""))
	return problems


## 劇本品質檢查（文本風格指南的自動檢查，見 StoryLint）：掃描所有場景台詞與章節卡文字，回傳錯誤與警告。
func lint() -> Array[Dictionary]:
	var issues: Array[Dictionary] = []
	for chapter_id in _chapters:
		issues.append_array(StoryLint.check_chapter(String(chapter_id), text_units(chapter_id), _speakers))
	return issues


func lint_warnings() -> Array[Dictionary]:
	return StoryLint.warnings_of(lint())


## 某一章所有要檢查的文本單元：每個場景的台詞，加上章節卡文字。動畫場景取其中的 say 與 narrate 步驟。
func text_units(chapter_id: StringName) -> Array[Dictionary]:
	var units: Array[Dictionary] = []
	for scene_id: String in _scenes.keys():
		if _scene_chapter.get(scene_id, &"") != chapter_id:
			continue
		var text_lines := _scene_text_lines(_scenes[scene_id])
		for line: Dictionary in text_lines:
			line["mode"] = str(_scenes[scene_id].get("mode", "text"))
			line["bark"] = bool(_scenes[scene_id].get("bark", false))
		units.append({"id": scene_id, "lines": text_lines})
		for variant in StoryReactions.variants_of(_scenes[scene_id]):
			units.append({"id": "%s（死亡 %d 次起）" % [scene_id, StoryReactions.threshold(variant)], "lines": variant["lines"]})
	var card: Array = []
	var info: Dictionary = _chapters.get(chapter_id, {})
	for key in ["title", "subtitle", "end_title", "teaser"]:
		if info.has(key):
			card.append({"speaker": "", "text": str(info[key]), "kind": "label"})
	units.append({"id": "%s 章節卡" % chapter_id, "lines": card})
	return units


func _scene_text_lines(scene: Variant) -> Array:
	if typeof(scene) != TYPE_DICTIONARY:
		return []
	var result: Array = []
	if str((scene as Dictionary).get("mode", "radio")) == String(MODE_ANIMATED):
		var steps: Variant = (scene as Dictionary).get("steps", [])
		if typeof(steps) != TYPE_ARRAY:
			return result
		for step: Variant in StoryRules.entries(steps):
			if typeof(step) != TYPE_DICTIONARY:
				continue
			match str(step.get("do", "")):
				"choice":
					for option: Variant in step.get("options", []):
						if option is Dictionary:
							result.append({"speaker": "rin", "text": str(option.get("text", ""))})
				"say":
					result.append({"speaker": str(step.get("speaker", "")), "text": str(step.get("text", ""))})
				"narrate":
					var narration: Variant = step.get("lines", [])
					if typeof(narration) == TYPE_ARRAY:
						for text: Variant in narration:
							result.append({"speaker": "system", "text": str(text)})
		return result
	var lines: Variant = (scene as Dictionary).get("lines", [])
	if typeof(lines) == TYPE_ARRAY:
		for line: Variant in lines:
			result.append(line.duplicate() if line is Dictionary else line)
	return result


func _line_limit(mode: String, scene: Dictionary = {}) -> int:
	match mode:
		String(MODE_BUBBLES):
			return MAX_BARK_LINES if bool(scene.get("bark", false)) else MAX_BUBBLE_LINES
		String(MODE_CINEMATIC):
			return MAX_CINEMATIC_LINES
		String(MODE_DIALOGUE):
			return MAX_DIALOGUE_LINES
	return MAX_RADIO_LINES


func has_scene(id: StringName) -> bool:
	return _scenes.has(String(id))


func scene_ids() -> Array:
	return _scenes.keys()


## 劇情資料的唯讀檢視（連續性檢查用，見 ContinuityAudit）：場景表、各章節的重生場景表與死亡場景表。不要修改回傳的內容。
func audit_data() -> Dictionary:
	return {"scenes": _scenes, "respawn": _respawn_scenes, "death": _death_scenes}


func scene_lines(id: StringName) -> Array:
	return (_scenes.get(String(id), {}) as Dictionary).get("lines", [])


## 場景現在要念的台詞：累計死亡達到某個變化的門檻就改用那一組，否則用正常台詞。deaths < 0 代表用本輪的累計死亡。
func lines_for(id: StringName, deaths := -1) -> Array:
	var scene: Variant = _scenes.get(String(id), null)
	if typeof(scene) != TYPE_DICTIONARY:
		return []
	var variant := StoryReactions.variant_lines(scene, GameState.deaths if deaths < 0 else deaths)
	if not variant.is_empty():
		return variant
	var base: Variant = (scene as Dictionary).get("lines", [])
	return base if typeof(base) == TYPE_ARRAY else []


## lines_for 的結果換成顯示資料（名字、顏色、頭像，{death_time} 已填入）。
func resolved_lines(id: StringName, deaths := -1) -> Array[Dictionary]:
	return _resolve_lines(lines_for(id, deaths))


## 死亡畫面的小字：累計死亡達到次數後才有，沒有回傳空字串。
func death_note(deaths := -1) -> String:
	return StoryReactions.pick_note(_death_notes, GameState.deaths if deaths < 0 else deaths)


## 某章節在累計死亡 deaths 次時，重生後要播的通訊。
func respawn_scene_ids(chapter: StringName, deaths := -1) -> Array[StringName]:
	var ids: Array[StringName] = []
	var entries: Variant = _respawn_scenes.get(chapter, [])
	if typeof(entries) != TYPE_ARRAY:
		return ids
	for entry in StoryReactions.eligible_respawns(entries, GameState.deaths if deaths < 0 else deaths):
		ids.append(StringName(str(entry["scene"])))
	return ids


## 這個章節在這次死亡（死因 cause）後、重生前要播的特殊過場（例如第一次死亡的診間）；沒有符合的回傳空字典。
## 條件、旗標與演出選項的寫法見 StoryReactions。
func death_scene_entry(chapter: StringName, cause: StringName, deaths := -1) -> Dictionary:
	return StoryReactions.pick_death_scene(_death_scenes.get(chapter, []), GameState.deaths if deaths < 0 else deaths, cause, GameState.has_flag)


## 場景結束時會寫入的旗標清單（資料檢查用）。
func _scene_set_flags(id: StringName) -> Array:
	var scene: Variant = _scenes.get(String(id), {})
	if scene is Dictionary and AtomicCoordinator.is_formal(scene):
		var flags: Array = []
		for result: Variant in scene.get("results", []):
			if result is Dictionary and result.get("kind") == "flag" and typeof(result.get("value")) == TYPE_BOOL and result.get("value") == true:
				flags.append(result.get("id"))
		return flags
	var flags: Variant = (scene as Dictionary).get("set_flags", []) if typeof(scene) == TYPE_DICTIONARY else []
	var result: Array = []
	if typeof(flags) == TYPE_ARRAY:
		for flag: Variant in flags:
			result.append(str(flag))
	return result


## 死亡重生後播出該章節的反應通訊（repeat 的每次重生都播，其餘一輪只播一次）。回傳開始播的場景數。
func play_respawn_reactions(chapter: StringName, deaths := -1) -> int:
	var started := 0
	var entries: Variant = _respawn_scenes.get(chapter, [])
	if typeof(entries) != TYPE_ARRAY:
		return started
	for entry in StoryReactions.eligible_respawns(entries, GameState.deaths if deaths < 0 else deaths):
		if play(StringName(str(entry["scene"])), not bool(entry.get("repeat", false))):
			started += 1
	return started


func speaker(id: String) -> Dictionary:
	return _speakers.get(id, {"name": id, "color": "#ffffff", "portrait": ""})


func speaker_ids() -> Array:
	return _speakers.keys()


func was_seen(id: StringName) -> bool:
	return _seen.has(id)


## A pending reservation is not durable/legacy completion.
func was_completed(id: StringName) -> bool:
	return _completed.has(id)


## 新的一輪遊戲開始時清除觀看紀錄。
func reset_progress() -> void:
	reset_active_presentation(&"new_run")
	_seen.clear()
	_completed.clear()
	_cinematic_queue.clear()


func is_cinematic_active() -> bool:
	return _current_cinematic != &""


## 可保存的入隊來源，不包含畫幅位置、Node、token 或 Tween。
static func presentation_context(raw: Dictionary) -> Dictionary:
	var source := str(raw.get("framing_source", ""))
	if source == "pickup":
		var item: Variant = raw.get("item_id")
		var key: Variant = raw.get("source_id")
		if not item is String or not StoryTransactionData.valid_id(item) or not key is String or key.length() > 128 or not key.begins_with(item + "@"):
			return {}
		var cell: PackedStringArray = key.substr(item.length() + 1).split(",", false)
		if cell.size() != 2 or not cell[0].is_valid_int() or not cell[1].is_valid_int() or abs(int(cell[0])) > 1000000 or abs(int(cell[1])) > 1000000:
			return {}
		return {"framing_source": "pickup", "source_id": key, "item_id": item}
	if source not in ["person", "object", "entry"]:
		return {}
	var result := {"framing_source": source, "source_id": str(raw.get("source_id", ""))}
	var index: Variant = raw.get("talk_index")
	if source in ["person", "object"] and raw.has("talk_index") and not (typeof(index) in [TYPE_INT, TYPE_FLOAT] and is_finite(float(index)) and float(index) == floorf(float(index)) and index >= 0 and index < 256):
		return {}
	if source in ["person", "object"] and typeof(index) in [TYPE_INT, TYPE_FLOAT] and is_finite(float(index)) and float(index) == floorf(float(index)) and index >= 0 and index < 256:
		result["talk_index"] = int(index)
	for field in ["topic_scene", "talk_origin"]:
		if raw.has(field):
			if source not in ["person", "object"] or not raw[field] is String or not StoryTransactionData.valid_id(raw[field]):
				return {}
			result[field] = raw[field]
	return result


func has_atomic_binding(binding: StringName) -> bool:
	for raw: Variant in _scenes.values():
		if raw is Dictionary and AtomicCoordinator.is_formal(raw) and raw.get("binding", "") == String(binding):
			return true
	return false


func current_presentation_context() -> Dictionary:
	return _presentation_context.duplicate(true)


## runtime 關聯用，不能存檔；讀檔重新入隊會得到新handle。
func current_presentation_request() -> int:
	return _current_request


func finished_presentation_request() -> int:
	return _finished_request


## 續玩NPC後續segment只接受原talk的then鏈，不將任意同來源scene當成獎勵入口。
## Formal restore follows only the bounded graph of the actual loaded origin.
## This is reachability, not authority; Main still requires the live NPC lease.
## Pure retry selection. Reachability is not authority; Level must reacquire
## its real threshold witness and Main must capture/validate a new request source.
func pending_literal_continuation(origin: StringName) -> Dictionary:
	return LiteralContinuation.resolve(StoryRunSource.new().graph_from(origin), _completed, origin)


func is_resumable_scene(origin: StringName, segment: StringName) -> bool:
	if not is_atomic_scene(origin):
		return is_chained_scene(origin, segment)
	var graph := StoryRunSource.new().graph_from(origin)
	return graph.get("valid", false) and graph["scenes"].has(String(segment))


func is_chained_scene(origin: StringName, segment: StringName) -> bool:
	var visited: Dictionary[StringName, bool] = {}
	for i in 64:
		if origin == segment:
			return has_scene(origin)
		if not has_scene(origin) or visited.has(origin):
			return false
		visited[origin] = true
		origin = StringName(str((_scenes[String(origin)] as Dictionary).get("then", "")))
	return false


func scene_mode(id: StringName) -> StringName:
	return StringName(str((_scenes.get(String(id), {}) as Dictionary).get("mode", "radio")))


## 對外 scene_started 的 dialogue→cinematic 別名是存檔契約；資格判斷必須讀實際資料模式。
func uses_cinematic_framing(id: StringName, context: Dictionary = {}) -> bool:
	var mode := scene_mode(id)
	if mode == MODE_DIALOGUE:
		return str(context.get("framing_source", "")) == "person"
	if mode == MODE_CINEMATIC:
		return true
	return mode == MODE_ANIMATED and not bool((_scenes.get(String(id), {}) as Dictionary).get("overlay", false))


## 換區、死亡、新局或讀檔時中止演出。不當作看完，不套用跳過預設選項或完成旗標。
func reset_active_presentation(reason: StringName = &"leave") -> void:
	if _atomic.is_busy():
		if _atomic_pending_resets.size() < 16:
			_atomic_pending_resets.append({"reason": reason, "generation": _presentation_generation})
		else:
			push_error("[Story] atomic pending reset limit reached; Main must retain lifecycle request")
		return
	_release_clinic_stage(reason)
	_atomic_clear_decision()
	if _resetting_presentation:
		return
	_resetting_presentation = true
	_presentation_generation += 1
	var interrupted := _current_cinematic
	var interrupted_request := _current_request
	if interrupted != &"":
		_emit_presentation_cancelled(interrupted, current_presentation_context(), reason, interrupted_request)
	_current_cinematic = &""
	_current_request = 0
	_presentation_context = {}
	if is_instance_valid(_player):
		_player.cancel()
		_player = null
	if is_instance_valid(_layer):
		_layer.cancel_cinematic()
	if is_instance_valid(framing):
		framing.reset()
	_framing_token = 0
	var pending := _cinematic_queue
	_cinematic_queue = []
	if interrupted != &"":
		if not _completed.has(interrupted):
			_seen.erase(interrupted)
		_complete_request(interrupted_request, false)
	for queued in pending:
		if is_atomic_request(queued.request):
			_emit_presentation_cancelled(queued.id, queued.context, reason, queued.request)
		if not _completed.has(queued.id):
			_seen.erase(queued.id)
		_complete_request(queued.request, false)
	for id: StringName in _passive_requests:
		if not _completed.has(id):
			_seen.erase(id)
		var requests: Array = _passive_requests[id]
		for request in requests:
			if is_atomic_request(request):
				_emit_presentation_cancelled(id, request_presentation_context(request), reason, request)
			_complete_request(request, false)
	_passive_requests.clear()
	if is_instance_valid(_layer):
		_layer.cancel_radio()
	_resetting_presentation = false


## 播放場景。once = true 時同一輪只播一次。回傳是否有開始（或排入佇列）。
## 登記或清除氣泡宿主（Level 進入關卡時登記自己的 MapBubbles；宿主離開場景樹時自動清除）。
func set_bubble_host(host: MapBubbles) -> void:
	if is_instance_valid(_bubble_host) and _bubble_host.scene_finished.is_connected(_on_bubbles_finished):
		_bubble_host.scene_finished.disconnect(_on_bubbles_finished)
	_bubble_host = host
	if host != null:
		host.scene_finished.connect(_on_bubbles_finished)
		host.tree_exiting.connect(func() -> void:
			if _bubble_host == host:
				_bubble_host = null
				reset_active_presentation(), CONNECT_ONE_SHOT)


func _on_bubbles_finished(id: StringName) -> void:
	var requests: Array = _passive_requests.get(id, [])
	if not requests.is_empty() and is_atomic_request(int(requests[0])):
		if not is_instance_valid(_bubble_host) or not _bubble_host.is_inside_tree() or _bubble_host.is_queued_for_deletion() or not _bubble_host.can_show_all(resolved_lines(id)):
			_atomic_reject_passive(id, int(requests[0]), {"status": "presentation_source_lost", "message": "講者已離開，這段尚未完成。"})
			return
	_on_passive_finished(id)


func _on_passive_finished(id: StringName, expected_request := 0) -> void:
	var requests: Array = _passive_requests.get(id, [])
	if requests.is_empty():
		return  # 已取消或舊宿主的延遲回呼，不再寫完成旗標。
	if expected_request != 0 and int(requests[0]) != expected_request:
		return  # auto-skip 舊請求的延遲回呼不能完成取消後新入隊的同名場景。
	if is_atomic_request(int(requests[0])):
		if is_instance_valid(_layer) and _layer.has_radio_request(id, int(requests[0])):
			if not _radio_settlement_matches(id, int(requests[0])) or _layer._radio_settlement != DialogueLayer.RadioSettlement.WAITING:
				return  # unread/retired UI cannot bypass actual formal settlement
		if _atomic.is_busy():
			_atomic_defer_finish(id, int(requests[0]), true)
			return
		_atomic_finish_passive(id, int(requests[0]))
		return
	var request := int(requests.pop_front())
	if requests.is_empty():
		_passive_requests.erase(id)
	_finished_request = request
	scene_finished.emit(id)
	_finished_request = 0
	_complete_request(request, true)


func play(id: StringName, once := true, context: Dictionary = {}) -> bool:
	return _enqueue_request(id, once, context) != 0


## ID/line alone is presentation data, never a formal producer lease.
## A future formal radio restore must use Main's actual read/install receipt.
func resume_radio_request(id: StringName, line: int) -> bool:
	if is_atomic_scene(id) or scene_mode(id) not in [MODE_RADIO, MODE_BUBBLES] \
			or line < 0 or line >= resolved_lines(id).size():
		return false
	return _enqueue_request(id, true, {}, false, line) != 0


func _enqueue_request(id: StringName, once: bool, context: Dictionary, waiting := false, resumed_line := -1) -> int:
	if atomic_producer_busy() or _resetting_presentation:
		return 0  # Synchronous publication or cancellation cannot start another producer.
	# One durable cinematic slot cannot represent independent formal owners.
	# Busy returns before dispatch/admit and before any source lease or metadata.
	# Same-request continuation does not use _enqueue_request; legacy radio stays parallel.
	if atomic_request_pending() and (is_atomic_scene(id) or scene_mode(id) in [MODE_CINEMATIC, MODE_ANIMATED, MODE_DIALOGUE]):
		return 0
	if is_atomic_scene(id) and (is_cinematic_active() or not _cinematic_queue.is_empty()):
		return 0
	var visited: Dictionary = {}
	while has_scene(id) and str((_scenes[String(id)] as Dictionary).get("mode", "")) == "dispatch":
		if visited.has(id) or visited.size() >= AtomicCoordinator.MAX_CHAIN:
			result_rejected.emit(id, 0, &"dispatch_cycle", "入口鏈無效，尚未完成任何故事結果。")
			return 0
		visited[id] = true
		var route := _atomic.dispatch(id, _scenes[String(id)])
		_atomic_drain_resets()
		if not route.get("valid", false):
			result_rejected.emit(id, 0, StringName(str(route.get("status", "invalid_dispatch"))), str(route.get("message", "入口尚未接妥。")))
			return 0
		id = StringName(str(route["target"]))
	if id == &"" or not has_scene(id):
		if id != &"":
			push_warning("[Story] 找不到劇情場景：%s" % id)
		return 0
	if once and _seen.has(id):
		return 0
	if is_atomic_scene(id):
		var links := _atomic_validate_targets(id)
		if not links.get("valid", false):
			result_rejected.emit(id, 0, StringName(links["status"]), links["message"])
			return 0
		var admitted := _atomic.admit(id, _scenes[String(id)], _request_serial + 1)
		_atomic_drain_resets()
		if not admitted.get("valid", false):
			result_rejected.emit(id, 0, StringName(str(admitted.get("status", "rejected"))), str(admitted.get("message", "開始條件尚未符合。")))
			return 0
	_request_serial += 1
	var request := _request_serial
	if is_atomic_scene(id):
		_atomic_request_scenes[request] = id
		_atomic_request_contexts[request] = presentation_context(context)
		_atomic_chains[request] = []
	if waiting:
		_waiters[request] = true
	_seen[id] = true
	var scene: Dictionary = _scenes[String(id)]
	var mode := StringName(str(scene.get("mode", "radio")))
	if mode == MODE_CINEMATIC or mode == MODE_ANIMATED or mode == MODE_DIALOGUE:
		if is_cinematic_active():
			_cinematic_queue.append({"id": id, "context": presentation_context(context), "request": request})
		else:
			_start_cinematic(id, context, request)
	else:
		if is_atomic_scene(id):
			_atomic_start_passive(id, context, request)
			return request
		if not _passive_requests.has(id):
			_passive_requests[id] = []
		_passive_requests[id].append(request)
		request_started.emit(request, id, presentation_context(context))
		if not (_passive_requests.get(id, []) as Array).has(request):
			return request
		if resumed_line >= 0 or mode != MODE_BUBBLES or not _play_bubbles(id, request):
			scene_started.emit(id, MODE_RADIO)
			if not (_passive_requests.get(id, []) as Array).has(request):
				return request  # A synchronous observer cancelled the actual owner.
			if auto_skip:
				_on_passive_finished.call_deferred(id, request)
			else:
				_layer.enqueue_radio(id, resolved_lines(id), maxi(0, resumed_line))
	return request


## 氣泡場景：有宿主、講者全都在地圖上才用氣泡；測試的 auto_skip 立即結束。回傳 false 代表改用通訊。
func _play_bubbles(id: StringName, request: int) -> bool:
	var lines := resolved_lines(id)
	if auto_skip:
		scene_started.emit(id, MODE_BUBBLES)
		_on_passive_finished.call_deferred(id, request)
		return true
	if not is_instance_valid(_bubble_host) or not _bubble_host.can_show_all(lines):
		return false
	scene_started.emit(id, MODE_BUBBLES)
	_bubble_host.show_lines(id, lines)
	return true


## 播放並等待該場景結束，包含接在後面的 then 場景（場景不存在，或 once 為 true 且已看過時立即返回）。
func play_and_wait(id: StringName, once := true, context: Dictionary = {}) -> bool:
	var outcome := await play_and_wait_outcome(id, once, context)
	return outcome["completed"]


## Runtime-only retry outcome for the exact handle, never a saved authorization.
## Failure segment comes only from this handle's actual cancellation signal.
func play_and_wait_outcome(id: StringName, once := true, context: Dictionary = {}) -> Dictionary:
	var request := _enqueue_request(id, once, context, true)
	if request == 0:
		return {"completed": false, "retry_scene": id}
	while not _request_results.has(request):
		await request_settled
	var completed: bool = _request_results[request]
	var retry_scene: StringName = _request_failure_scenes.get(request, id)
	_request_results.erase(request)
	_request_failure_scenes.erase(request)
	_waiters.erase(request)
	return {"completed": completed, "retry_scene": retry_scene}


func _emit_presentation_cancelled(id: StringName, context: Dictionary, reason: StringName, request: int) -> void:
	if _waiters.has(request):
		_request_failure_scenes[request] = id
	presentation_cancelled.emit(id, context, reason, request)


func _complete_request(request: int, completed: bool) -> void:
	if request == 0:
		return
	if _clinic_host_live(request):
		_release_clinic_stage(&"settled")
	_atomic_request_scenes.erase(request)
	_atomic_request_contexts.erase(request)
	_atomic_chains.erase(request)
	if _waiters.has(request):
		_request_results[request] = completed
	request_settled.emit(request, completed)


## 跳過目前的過場（與按 Esc 相同）。
func skip_cinematic() -> void:
	if is_atomic_request(_current_request):
		var scene: Dictionary = _scenes.get(String(_current_cinematic), {})
		if not scene.get("options", []).is_empty() or scene.get("skip_policy", "cancel") != "presentation_only":
			cancel_atomic_request(&"user_skip")
			return
		_atomic_skipped = true
	if not is_cinematic_active():
		return
	if is_instance_valid(_player) and _player.is_running():
		_player.skip()
	else:
		_layer.finish_cinematic()


func _start_cinematic(id: StringName, context: Dictionary = {}, request := 0) -> void:
	if is_atomic_scene(id):
		var admitted := _atomic.admit(id, _scenes.get(String(id), {}), request)
		_atomic_drain_resets()
		if not admitted.get("valid", false):
			_atomic_reject_queued(id, request, admitted)
			return
		var chain: Array = _atomic_chains.get(request, [])
		if chain.has(id) or chain.size() >= AtomicCoordinator.MAX_CHAIN:
			_atomic_reject_queued(id, request, {"status": "continuation_cycle", "message": "續段鏈無效，已完成前段保持原狀。"})
			return
		chain.append(id)
		_atomic_chains[request] = chain
		_atomic_request_scenes[request] = id
	_atomic_skipped = false
	_presentation_generation += 1
	_current_cinematic = id
	_current_request = request
	_presentation_context = presentation_context(context)
	var scene: Dictionary = _scenes.get(String(id), {})
	var animated := str(scene.get("mode", "")) == String(MODE_ANIMATED)
	if request != 0:
		request_started.emit(request, id, request_presentation_context(request))
		if _current_cinematic != id or _current_request != request:
			return
	if is_atomic_scene(id) and scene.get("binding") == "first_clinic" and not _clinic_host_live(request):
		_atomic_reject_active(id, {"status": "clinic_host_unbound", "message": "診間舞台來源尚未接妥，尚未保存任何結果。"})
		return
	if id == ClinicStageCustody.TAKE and _clinic_host_live(request):
		_clinic_take_pending = request
		var physically_held := await _clinic_physical_take(request, id)
		if _clinic_take_pending == request:
			_clinic_take_pending = 0
		if not physically_held:
			if request == _current_request and id == _current_cinematic:
				_clinic_show_retry(id, &"", "灰布的實際持有未能確認，尚未取得物品。", false)
			return
	if _clinic_host_live(request) and animated and id != StageContinuationHost.ROOT and not CutscenePlayer.clinic_overlay_definition_valid(scene):
		_atomic_reject_active(id, {"status": "invalid_clinic_overlay", "message": "診間疊加演出尚未接妥，尚未保存這段結果。"})
		return
	scene_started.emit(id, MODE_ANIMATED if animated else MODE_CINEMATIC)
	if (auto_skip or Settings.get_skip_cutscenes()) and _clinic_host_live(request) and id == StageContinuationHost.ROOT:
		_player = CutscenePlayer.new()
		add_child(_player)
		_player.retain_clinic_stage(_clinic_stage_host)
		_player.finished.connect(_on_cinematic_finished)
		_player.play(id, scene)
		_player.skip()
		_atomic_skipped = true
		return  # Skip speech, not the actual authored clinic structure.
	if auto_skip or Settings.get_skip_cutscenes():
		if is_atomic_scene(id):
			# Accessibility skip suppresses presentation, never selects a payment default.
			# Decisions still present their explicit confirmation UI.
			_finish_auto_skip.call_deferred(id, _presentation_generation)
		else:
			apply_default_choices(scene)
			_finish_auto_skip.call_deferred(id, _presentation_generation)
		return
	if not animated and uses_cinematic_framing(id, _presentation_context):
		_framing_token = framing.acquire(self)
	elif not uses_cinematic_framing(id, _presentation_context):
		framing.clear_preview()
	if animated:
		_player = CutscenePlayer.new()
		add_child(_player)
		if _clinic_host_live(request) and id == StageContinuationHost.ROOT:
			_player.retain_clinic_stage(_clinic_stage_host)
		elif _clinic_host_live(request) and not _player.prepare_clinic_overlay(_clinic_stage_host, id, scene):
			_atomic_reject_active(id, {"status": "invalid_clinic_overlay", "message": "診間疊加演出尚未接妥，尚未保存這段結果。"})
			return
		_player.finished.connect(_on_cinematic_finished)
		_player.play(id, scene)
		return
	_layer.start_cinematic(id, resolved_lines(id))


func _finish_auto_skip(id: StringName, generation: int) -> void:
	if generation == _presentation_generation:
		_on_cinematic_finished(id)


func _on_cinematic_finished(id: StringName) -> void:
	if _current_cinematic != id:
		return
	if is_atomic_scene(id):
		if _atomic.is_busy():
			_atomic_defer_finish(id, _current_request, false)
			return
		if not (_scenes[String(id)] as Dictionary).get("options", []).is_empty():
			_atomic_show_decision(id)
		else:
			_atomic_finish(id)
		return
	_current_cinematic = &""
	var completed_request := _current_request
	_current_request = 0
	framing.release(_framing_token)
	_framing_token = 0
	var chained := _queue_chained_scene(id, completed_request)
	_presentation_context = {}
	_finished_request = completed_request
	scene_finished.emit(id)
	_finished_request = 0
	if not chained:
		_complete_request(completed_request, true)
	if not _cinematic_queue.is_empty():
		var queued: Dictionary = _cinematic_queue.pop_front()
		_start_cinematic(queued.id, queued.context, queued.request)


## 場景設定了 then 時，結束後立刻接著播（排在佇列最前面）；玩家按 Esc 略過時整串都略過，已看過的場景不重播。
func _queue_chained_scene(id: StringName, request: int) -> bool:
	var next := StringName(str((_scenes.get(String(id), {}) as Dictionary).get("then", "")))
	if next == &"" or not has_scene(next) or _seen.has(next):
		return false
	if is_instance_valid(_player) and _player.user_skipped:
		return false
	_seen[next] = true
	_cinematic_queue.push_front({"id": next, "context": _presentation_context.duplicate(true), "request": request})
	return true


## 把台詞的講者 id 換成顯示資料（名字、顏色、頭像），填入 {death_time}，帶上顯示前的沉默秒數 delay。
func _resolve_lines(raw: Variant) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	if typeof(raw) != TYPE_ARRAY:
		return result
	for entry: Variant in raw:
		if typeof(entry) != TYPE_DICTIONARY:
			continue
		var info := speaker(str(entry.get("speaker", "")))
		var resolved := {
			"speaker": str(entry.get("speaker", "")),
			"name": str(info.get("name", "")),
			"color": Color(str(info.get("color", "#ffffff"))),
			"portrait": str(info.get("portrait", "")),
			"text": StoryReactions.fill_placeholders(str(entry.get("text", "")), _death_clock()),
		}
		var delay := StoryReactions.line_delay(entry)
		if delay > 0.0:
			resolved["delay"] = delay
		result.append(resolved)
	return result


## {death_time} 要填的世界時間：剛剛死亡的時間；還沒死過就用現在的。
func _death_clock() -> String:
	return GameState.last_death_clock if not GameState.last_death_clock.is_empty() else GameState.world_clock_text()


func progress_snapshot() -> Array:
	return _completed.keys()


func restore_progress(raw: Variant, where := "story/seen", cancel_presentation := true) -> void:
	if cancel_presentation:
		reset_active_presentation(&"load")
	_seen.clear()
	_completed.clear()
	if not raw is Array:
		push_warning("[Story] %s 不是清單，退回空觀看紀錄" % where)
		return
	for entry: Variant in raw:
		var id := StringName(str(entry))
		if has_scene(id):
			_seen[id] = true
			_completed[id] = true
		else:
			push_warning("[Story] %s/%s 場景不存在，已略過" % [where, id])


func apply_choice(option: Dictionary) -> void:
	if is_atomic_request(_current_request):
		push_warning("[Story] formal choices accept only a loaded option ID through choose_atomic")
		return
	var flags: Variant = option.get("set_flags", {})
	for flag: Variant in StoryRules.flag_names(flags):
		GameState.set_flag(StringName(str(flag)), flags[flag] if flags is Dictionary else true)


## Skip uses explicit defaults, so gates cannot depend on an unanswered question.
func apply_default_choices(scene: Dictionary) -> void:
	if AtomicCoordinator.is_formal(scene):
		return
	_resolve_skipped_steps(scene.get("steps", []))


func _resolve_skipped_steps(raw: Variant) -> void:
	if not raw is Array:
		return
	for step: Variant in raw:
		if not step is Dictionary:
			continue
		if step.get("do") == "choice":
			var option := StoryRules.default_option(step, StoryRules.options(step, GameState.has_flag, StoryItems.owns))
			apply_choice(option)
			_resolve_skipped_steps(option.get("steps", []))
		elif step.get("do") == "branch":
			_resolve_skipped_steps(step.get("steps", []) if StoryRules.eligible(step, GameState.has_flag, StoryItems.owns) else step.get("else_steps", []))


func death_sequence(chapter: StringName, count := -1) -> Dictionary:
	var result := {}
	var threshold := -1
	var raw: Variant = _death_sequences.get(chapter, [])
	if not raw is Array:
		return result
	var actual := GameState.deaths if count < 0 else count
	for entry: Variant in raw:
		if not entry is Dictionary:
			continue
		var minimum_raw: Variant = entry.get("min_deaths", 1)
		if not (minimum_raw is int or minimum_raw is float):
			continue
		var minimum := int(minimum_raw)
		if minimum <= actual and minimum >= threshold:
			result = entry
			threshold = minimum
	return result


func validate_death_sequences(chapter: String, raw: Variant) -> PackedStringArray:
	var problems := PackedStringArray()
	if not raw is Array:
		return PackedStringArray(["章節 %s 的 death_sequences 必須是清單" % chapter])
	for i in raw.size():
		var entry: Variant = raw[i]
		var where := "章節 %s/death_sequences/%d" % [chapter, i]
		if not entry is Dictionary or not entry.get("steps") is Array:
			problems.append("%s 必須是有 steps 清單的物件" % where)
			continue
		var steps: Array = entry.steps
		if steps.is_empty() or steps.size() > 8:
			problems.append("%s/steps 必須有 1 到 8 步" % where)
		for j in steps.size():
			var step: Variant = steps[j]
			if not step is Dictionary:
				problems.append("%s/steps/%d 不是物件" % [where, j])
				continue
			var kind := str(step.get("kind", "line"))
			if not kind in ["line", "status", "card"]:
				problems.append("%s/steps/%d 未知種類 %s" % [where, j, kind])
			if kind != "card" and str(step.get("text", "")).strip_edges().is_empty():
				problems.append("%s/steps/%d 缺少文字" % [where, j])
			if kind == "line" and not _speakers.has(str(step.get("speaker", ""))):
				problems.append("%s/steps/%d 講者未定義" % [where, j])
			var seconds: Variant = step.get("time", 0.6)
			if not (seconds is int or seconds is float) or float(seconds) < 0.0 or float(seconds) > 3.0:
				problems.append("%s/steps/%d/time 必須在 0 到 3 秒" % [where, j])
	return problems


## Root Main binds a trusted typed port only after real world/lifecycle producer guards.
func bind_atomic_port(port: AtomicCoordinator.CommitPort) -> bool:
	if _atomic.is_busy() or not _atomic_request_scenes.is_empty():
		return false
	_atomic.port = port
	return true


func is_atomic_scene(id: StringName) -> bool:
	return AtomicCoordinator.is_formal(_scenes.get(String(id), {}))


func is_atomic_request(request: int) -> bool:
	return _atomic_request_scenes.has(request)


func atomic_producer_busy() -> bool:
	return _atomic.is_busy() or (_atomic.port != null and _atomic.port.is_busy())


func _record_legacy_completion(id: StringName) -> void:
	if is_atomic_scene(id):
		return
	_completed[id] = true
	GameState.request_story_save()


func cancel_atomic_request(reason: StringName = &"user_cancel") -> void:
	if is_atomic_request(_current_request):
		reset_active_presentation(reason)


func choose_atomic(option_id: StringName, expected_request: int, expected_generation: int) -> void:
	if _atomic.is_busy() or expected_request != _current_request or expected_generation != _presentation_generation or not is_atomic_request(expected_request):
		return
	_atomic_finish(_current_cinematic, option_id)


func _atomic_clear_decision() -> void:
	if get_viewport().size_changed.is_connected(_atomic_layout_decision):
		get_viewport().size_changed.disconnect(_atomic_layout_decision)
	if is_instance_valid(framing) and framing.safe_rect_changed.is_connected(_atomic_layout_decision):
		framing.safe_rect_changed.disconnect(_atomic_layout_decision)
	if is_instance_valid(_atomic_decision_layer):
		_atomic_decision_layer.queue_free()
	_atomic_decision_layer = null
	_atomic_decision_root = null
	GameplayLock.release(_atomic_choice_lock)
	_atomic_choice_lock = 0


func _atomic_show_decision(id: StringName) -> void:
	if is_instance_valid(_atomic_decision_layer):
		return  # Repeated player/layer finish is not a second confirmation.
	var choices := _atomic.available_options(id, _scenes[String(id)], _current_request)
	_atomic_drain_resets()
	if _current_cinematic != id:
		return
	if not choices.get("valid", false) or choices.get("options", []).is_empty():
		_atomic_reject_active(id, choices if not choices.get("valid", false) else {"status": "no_available_option", "message": "目前沒有可用選項，進度保持原狀。"})
		return
	_atomic_choice_lock = GameplayLock.acquire(self, Input.MOUSE_MODE_VISIBLE)
	_atomic_decision_layer = CanvasLayer.new()
	_atomic_decision_layer.layer = UiLayers.DIALOGUE
	_atomic_decision_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_atomic_decision_layer)
	_atomic_decision_root = PanelContainer.new()
	_atomic_decision_root.theme = UiKit.theme()
	_atomic_decision_layer.add_child(_atomic_decision_root)
	var column := VBoxContainer.new()
	_atomic_decision_root.add_child(column)
	var first: Button
	for option: Dictionary in choices["options"]:
		var button := Button.new()
		button.text = option["text"]
		button.tooltip_text = str(option.get("explanation", ""))
		button.pressed.connect(choose_atomic.bind(StringName(option["id"]), _current_request, _presentation_generation))
		column.add_child(button)
		if first == null:
			first = button
	var cancel := Button.new()
	cancel.text = "返回，不完成這次選擇"
	cancel.pressed.connect(cancel_atomic_request.bind(&"user_cancel"))
	column.add_child(cancel)
	_atomic_layout_decision()
	_atomic_decision_root.get_viewport().size_changed.connect(_atomic_layout_decision)
	framing.safe_rect_changed.connect(_atomic_layout_decision)
	if first != null:
		first.grab_focus()


func _atomic_layout_decision(_rect: Rect2 = Rect2()) -> void:
	if not is_instance_valid(_atomic_decision_root):
		return
	var safe: Rect2 = framing.safe_rect()
	if _atomic_decision_root.get_meta(&"clinic_visit_panel", false):
		_clinic_layout_panel(safe)
		return
	var width := minf(560.0, maxf(1.0, safe.size.x - 24.0))
	_atomic_decision_root.size = Vector2(width, 0.0)
	_atomic_decision_root.position = Vector2(safe.get_center().x - width * 0.5, safe.position.y + 12.0)


func _atomic_finish(id: StringName, option_id: StringName = &"") -> void:
	if _clinic_take_pending == _current_request and _clinic_take_pending != 0:
		return  # Skip/advance cannot race an unfinished physical take.
	if id != _current_cinematic or _atomic.is_busy():
		return
	var request := _current_request
	var generation := _presentation_generation
	var context := current_presentation_context()
	var scene: Dictionary = _scenes[String(id)]
	if scene.get("binding") == "first_clinic" and not _clinic_host_live(request):
		_atomic_reject_active(id, {"status": "clinic_host_unbound", "message": "診間舞台已離開，尚未保存這段結果。"})
		return
	var prospective := StringName(str(scene.get("then", "")))
	for option: Dictionary in scene.get("options", []):
		if str(option.get("id", "")) == String(option_id):
			prospective = StringName(str(option.get("target", "")))
	if _clinic_host_live(request) and not _clinic_stage_host.captured:
		_clinic_stage_failed(id)
		return
	var links := _atomic_validate_targets(id)
	if not links.get("valid", false) or (prospective != &"" and (_atomic_chains.get(request, []) as Array).has(prospective)):
		_atomic_reject_active(id, {"status": "invalid_continuation", "message": "續段尚未接妥，尚未保存任何新結果。"})
		return
	var result := _atomic.complete(id, _scenes[String(id)], request, option_id, _atomic_skipped)
	if not result.get("valid", false):
		if result.get("status") == "committed_install_contract_broken":
			return  # Trusted port fault: never retry a possibly durable payment.
		if _clinic_host_live(request):
			_clinic_show_retry(id, option_id, str(result.get("message", "尚未保存，請再試一次。")))
			result_rejected.emit(id, request, StringName(str(result.get("status", "rejected"))), str(result.get("message", "尚未保存。")))
			return
		_atomic_reject_active(id, result)
		return
	# All owner/world/Main assignments are installed; everything below is PUBLISHING.
	_atomic_publishing = true
	_atomic.publish_owner_events()
	_atomic_clear_decision()
	_current_cinematic = &""
	_current_request = 0
	_presentation_context = {}
	framing.release(_framing_token)
	_framing_token = 0
	var next: StringName = result["next"]
	var clinic_retained := next == &"" and _clinic_host_live(request) and _clinic_stage_host.captured
	if clinic_retained:
		_current_cinematic = id
		_current_request = request
		_presentation_context = context
	if result["decision"]:
		if not _completed.has(id):
			_seen.erase(id)
		decision_committed.emit(id, request, option_id)
	else:
		_finished_request = request
		scene_finished.emit(id)
		_finished_request = 0
	if next == &"" and not clinic_retained:
		_complete_request(request, not result["decision"])
	_atomic_publishing = false
	_atomic.close()
	_atomic_drain_resets()
	if next != &"":
		if generation == _presentation_generation and is_atomic_request(request):
			if has_scene(next) and is_atomic_scene(next):
				_seen[next] = true
				_cinematic_queue.push_front({"id": next, "context": context, "request": request})
			else:
				_atomic_reject_queued(next, request, {"status": "unbound_continuation", "message": "已保存前段；下一段尚未接妥，請重新互動。"})
		else:
			_complete_request(request, false)
	if clinic_retained and generation == _presentation_generation and _current_request == request and _clinic_host_live(request):
		_clinic_show_menu()
	_atomic_start_queued()


func _atomic_reject_active(id: StringName, result: Dictionary) -> void:
	var request := _current_request
	var context := current_presentation_context()
	var fallback := &""
	# Only the author's explicit insufficient-payment presentation may continue.
	# It cannot manufacture owed/gift receipts or apply a default selection.
	if result.get("status") == "insufficient_credits":
		var targets: Dictionary = (_scenes.get(String(id), {}) as Dictionary).get("on_failure", {})
		var target := StringName(str(targets.get("insufficient_credits", "")))
		if has_scene(target) and is_atomic_scene(target) and not (_atomic_chains.get(request, []) as Array).has(target):
			fallback = target
	# Reject only this request; unrelated queued legacy dialogue retains its reservation.
	_emit_presentation_cancelled(id, current_presentation_context(), &"result_rejected", request)
	_presentation_generation += 1
	_current_cinematic = &""
	_current_request = 0
	_presentation_context = {}
	if is_instance_valid(_player):
		_player.cancel()
		_player = null
	_layer.cancel_cinematic()
	framing.release(_framing_token)
	_framing_token = 0
	_atomic_clear_decision()
	if not _completed.has(id):
		_seen.erase(id)
	if fallback == &"":
		_complete_request(request, false)
	else:
		_cinematic_queue.push_front({"id": fallback, "request": request, "context": context})
	result_rejected.emit(id, request, StringName(str(result.get("status", "rejected"))), str(result.get("message", "尚未完成任何結果，請稍後再試。")))
	_atomic_start_queued()


func _atomic_reject_queued(id: StringName, request: int, result: Dictionary) -> void:
	if not _completed.has(id):
		_seen.erase(id)
	# Preserve the exact rejected continuation while its source/context maps exist.
	# Settling first loses the segment and leaves waiters with their original root.
	_emit_presentation_cancelled(id, request_presentation_context(request), &"result_rejected", request)
	_complete_request(request, false)
	result_rejected.emit(id, request, StringName(str(result.get("status", "rejected"))), str(result.get("message", "開始條件尚未符合。")))
	_atomic_start_queued()


func _atomic_start_queued() -> void:
	if not _atomic.is_busy() and not is_cinematic_active() and not _cinematic_queue.is_empty():
		var queued: Dictionary = _cinematic_queue.pop_front()
		var mode := scene_mode(queued.id)
		if is_atomic_scene(queued.id) and mode in [MODE_RADIO, MODE_BUBBLES]:
			_atomic_start_passive(queued.id, queued.context, queued.request)
		else:
			_start_cinematic(queued.id, queued.context, queued.request)


func _atomic_drain_resets() -> void:
	if _atomic.is_busy():
		return
	if _atomic_pending_resets.is_empty():
		_atomic_drain_finishes()
		return
	var pending := _atomic_pending_resets
	_atomic_pending_resets = []
	for action: Dictionary in pending:
		if action["generation"] == _presentation_generation:
			reset_active_presentation(action["reason"])
			_atomic_drain_finishes()
			return
	_atomic_drain_finishes()


func _atomic_validate_targets(id: StringName) -> Dictionary:
	var scene: Dictionary = _scenes.get(String(id), {})
	var checked := AtomicCoordinator.validate_scene(scene)
	if not checked["valid"]:
		return checked
	var targets: Array = [scene.get("then", "")]
	for route: Dictionary in scene.get("routes", []):
		targets.append(route["target"])
	for option: Variant in scene.get("options", []):
		if not option is Dictionary:
			return {"valid": false, "status": "invalid_options", "message": "選項資料無效。"}
		targets.append(option.get("target", ""))
	var failure: Variant = scene.get("on_failure", {})
	if not failure is Dictionary or (not failure.is_empty() and (failure.size() != 1 or not failure.has("insufficient_credits"))):
		return {"valid": false, "status": "invalid_failure_route", "message": "未登記的失敗續段。"}
	if not failure.is_empty():
		targets.append(failure["insufficient_credits"])
	for target: Variant in targets:
		if not target is String or (not target.is_empty() and (not has_scene(StringName(target)) or not is_atomic_scene(StringName(target)))):
			return {"valid": false, "status": "unbound_continuation", "message": "正式續段不存在或尚未綁定。"}
	return {"valid": true}


## Root validates passive/manual source identity against its loaded binding registry.
func request_presentation_context(request: int) -> Dictionary:
	if _atomic_request_contexts.has(request):
		return _atomic_request_contexts[request].duplicate(true)
	return current_presentation_context() if request == _current_request else {}


func _atomic_start_passive(id: StringName, context: Dictionary, request: int) -> void:
	var scene: Dictionary = _scenes.get(String(id), {})
	var links := _atomic_validate_targets(id)
	var admitted := _atomic.admit(id, scene, request) if links.get("valid", false) else links
	_atomic_drain_resets()
	var chain: Array = _atomic_chains.get(request, [])
	if not admitted.get("valid", false) or chain.has(id) or chain.size() >= AtomicCoordinator.MAX_CHAIN:
		_atomic_reject_passive(id, request, admitted if not admitted.get("valid", false) else {"status": "continuation_cycle", "message": "續段鏈無效，前段保存結果保持原狀。"})
		return
	chain.append(id)
	_atomic_chains[request] = chain
	_atomic_request_scenes[request] = id
	_atomic_request_contexts[request] = presentation_context(context)
	if not _passive_requests.has(id):
		_passive_requests[id] = []
	_passive_requests[id].append(request)
	request_started.emit(request, id, request_presentation_context(request))
	if _atomic_request_scenes.get(request, &"") != id:
		return
	if scene_mode(id) != MODE_BUBBLES or not _play_bubbles(id, request):
		scene_started.emit(id, MODE_RADIO)
		if _atomic_request_scenes.get(request, &"") != id \
				or not (_passive_requests.get(id, []) as Array).has(request):
			return  # Synchronous cancellation cannot create an orphan reading lease.
		_layer.enqueue_radio(id, resolved_lines(id), 0, request, scene_mode(id) == MODE_RADIO)


## Main's queued save and owned UI retry share this presentation-only boundary.
## No saved readiness flag or cursor exists; a cold read replays the current segment.
func radio_checkpoint_pending(id: StringName, request: int) -> bool:
	return request > 0 and is_atomic_request(request) and request_scene(request) == id \
		and scene_mode(id) == MODE_RADIO and not resolved_lines(id).is_empty() \
		and (not _checkpoint_layer_live() or _layer.queued_radio_checkpoint(id, request) != DialogueLayer.RadioCheckpoint.READY)


## Readonly UI identity only. Never grants Source/receipt or retries a writer.
func radio_settlement_pending(id: StringName, request: int) -> bool:
	return _radio_settlement_matches(id, request)


func _checkpoint_layer_live() -> bool:
	return is_instance_valid(_layer) and _layer.is_inside_tree() and not _layer.is_queued_for_deletion()


func try_radio_checkpoint(id: StringName, request: int, generation: int) -> bool:
	if generation != _presentation_generation or not radio_checkpoint_pending(id, request):
		return false
	if not _checkpoint_layer_live() or _layer.queued_radio_checkpoint(id, request) == -1:
		var context := request_presentation_context(request)
		_atomic_remove_passive(id, request)
		if not _completed.has(id):
			_seen.erase(id)
		_emit_presentation_cancelled(id, context, &"presentation_source_lost", request)
		_complete_request(request, false)
		return false
	if _layer.queued_radio_checkpoint(id, request) != DialogueLayer.RadioCheckpoint.WAITING:
		return false  # autosave cannot silently retry or re-write a RECOVERY outcome
	if _atomic.is_busy() or (_atomic.port != null and _atomic.port.is_busy()):
		if _atomic.port is StoryRunCommitPort:
			_atomic.port.defer_lifecycle(&"_story_retry_radio_checkpoint", [id, request, generation])
		return false  # same line/reading lease remains WAITING; actual release dispatches
	var outcome := AtomicCoordinator.CommitOutcome.new()
	if _atomic.port != null and _atomic.port.has_method("checkpoint_presentation"):
		var returned: Variant = _atomic.port.call("checkpoint_presentation", request, id)
		if returned is AtomicCoordinator.CommitOutcome:
			outcome = returned
	# A callback that reset/replaced UI cannot receive the old result.
	if generation != _presentation_generation or request_scene(request) != id or not _checkpoint_layer_live():
		return false
	var success := outcome.committed and outcome.installed
	var recovery := outcome.committed and not outcome.installed
	_layer.settle_radio_checkpoint(id, request, success, recovery)
	if not success:
		result_rejected.emit(id, request, StringName(outcome.status), outcome.message)
	return success


func _on_radio_checkpoint_requested(id: StringName, request: int) -> void:
	if _checkpoint_layer_live() and _layer.has_radio_request(id, request):
		try_radio_checkpoint(id, request, _presentation_generation)


func _on_radio_checkpoint_cancel_requested(id: StringName, request: int) -> void:
	if _atomic.is_busy() or (_atomic.port != null and _atomic.port.is_busy()) \
			or not _checkpoint_layer_live() or not _layer.has_radio_request(id, request) \
			or _layer.queued_radio_checkpoint(id, request) != DialogueLayer.RadioCheckpoint.RETRY \
			or request_scene(request) != id or not is_atomic_request(request):
		return
	var context := request_presentation_context(request)
	_atomic_remove_passive(id, request)
	if not _completed.has(id):
		_seen.erase(id)
	_emit_presentation_cancelled(id, context, &"radio_reading_cancel", request)
	_complete_request(request, false)
	if _checkpoint_layer_live():
		_layer.cancel_radio_checkpoint(id, request)  # sources retired before visibility callbacks


func _radio_settlement_matches(id: StringName, request: int) -> bool:
	var requests: Array = _passive_requests.get(id, [])
	return is_instance_valid(_layer) and _layer.is_inside_tree() and not _layer.is_queued_for_deletion() \
		and _layer.pending_radio_settlement(id, request) \
		and not requests.is_empty() and int(requests[0]) == request \
		and request_scene(request) == id and is_atomic_request(request)


func _on_radio_settlement_requested(id: StringName, request: int) -> void:
	if _radio_settlement_matches(id, request) and _layer._radio_settlement == DialogueLayer.RadioSettlement.WAITING:
		_on_passive_finished(id, request)  # unchanged coordinator/source/real filesystem boundary


func _on_radio_settlement_cancel_requested(id: StringName, request: int) -> void:
	if _atomic.is_busy() or not _radio_settlement_matches(id, request) \
			or _layer._radio_settlement != DialogueLayer.RadioSettlement.RETRY:
		return
	var context := request_presentation_context(request)
	_atomic_remove_passive(id, request)
	if not _completed.has(id):
		_seen.erase(id)
	_emit_presentation_cancelled(id, context, &"radio_reading_cancel", request)
	_complete_request(request, false)
	_layer.cancel_pending_radio(id, request)  # exact source/request has already been retired


func _atomic_radio_failure(id: StringName, request: int, result: Dictionary) -> void:
	if _radio_settlement_matches(id, request):
		var recovery: bool = result.get("status") == "committed_install_contract_broken"
		_layer.settle_radio(id, request, false, recovery)
		# Keep the exact live Source, seen reservation, waiter, cinematic metadata and
		# queue. Retry invokes fresh real Source/conditions/owner/writer preflight.
		result_rejected.emit(id, request, StringName(str(result.get("status", "rejected"))), str(result.get("message", "尚未完成任何結果。")))
	elif result.get("status") != "committed_install_contract_broken":
		_atomic_reject_passive(id, request, result)


func _atomic_remove_passive(id: StringName, request: int) -> void:
	var requests: Array = _passive_requests.get(id, [])
	requests.erase(request)
	if requests.is_empty():
		_passive_requests.erase(id)


func _atomic_reject_passive(id: StringName, request: int, result: Dictionary) -> void:
	var context := request_presentation_context(request)
	_atomic_remove_passive(id, request)
	if not _completed.has(id):
		_seen.erase(id)
	_emit_presentation_cancelled(id, context, &"result_rejected", request)
	_complete_request(request, false)
	result_rejected.emit(id, request, StringName(str(result.get("status", "rejected"))), str(result.get("message", "尚未完成任何結果。")))


func _atomic_finish_passive(id: StringName, request: int) -> void:
	if _atomic.is_busy() or not is_atomic_request(request):
		return
	if scene_mode(id) == MODE_RADIO and not resolved_lines(id).is_empty():
		if not is_instance_valid(_layer) or not _layer.is_inside_tree() or _layer.is_queued_for_deletion() \
				or not _layer.has_radio_request(id, request):
			_atomic_reject_passive(id, request, {"status": "presentation_source_lost", "message": "通訊畫面已離開，這段尚未完成。"})
			return
		if not _radio_settlement_matches(id, request) or _layer._radio_settlement != DialogueLayer.RadioSettlement.WAITING:
			return  # actual nonempty formal radio requires its retained final confirmation
	var generation := _presentation_generation
	var context := request_presentation_context(request)
	var scene: Dictionary = _scenes[String(id)]
	var next := StringName(str(scene.get("then", "")))
	if next != &"" and (_atomic_chains.get(request, []) as Array).has(next):
		_atomic_radio_failure(id, request, {"status": "continuation_cycle", "message": "續段鏈無效，尚未保存新結果。"})
		return
	var links := _atomic_validate_targets(id)
	var result := _atomic.complete(id, scene, request) if links.get("valid", false) else links
	if not result.get("valid", false):
		_atomic_radio_failure(id, request, result)
		return
	_atomic_publishing = true
	_atomic.publish_owner_events()
	if is_instance_valid(_layer):
		_layer.settle_radio(id, request, true)
	_atomic_remove_passive(id, request)
	_finished_request = request
	scene_finished.emit(id)
	_finished_request = 0
	if next == &"":
		_complete_request(request, true)
	_atomic_publishing = false
	_atomic.close()
	_atomic_drain_resets()
	if next != &"":
		if generation == _presentation_generation and is_atomic_request(request):
			_seen[next] = true
			_cinematic_queue.push_front({"id": next, "request": request, "context": context})
		else:
			_complete_request(request, false)
	_atomic_start_queued()


func _atomic_defer_finish(id: StringName, request: int, passive: bool) -> void:
	var event := {"id": id, "request": request, "passive": passive, "generation": _presentation_generation}
	if _atomic_pending_finishes.has(event):
		return
	if _atomic_pending_finishes.size() >= 64:
		push_error("[Story] atomic pending presentation limit reached")
		return
	_atomic_pending_finishes.append(event)


func _atomic_drain_finishes() -> void:
	if _atomic.is_busy() or _atomic_pending_finishes.is_empty():
		return
	var pending := _atomic_pending_finishes
	_atomic_pending_finishes = []
	for event: Dictionary in pending:
		if event["generation"] != _presentation_generation or _atomic_request_scenes.get(event["request"], &"") != event["id"]:
			continue
		if event["passive"]:
			var requests: Array = _passive_requests.get(event["id"], [])
			if not requests.is_empty() and int(requests[0]) == event["request"]:
				_atomic_finish_passive(event["id"], event["request"])
		elif _current_request == event["request"] and _current_cinematic == event["id"]:
			_on_cinematic_finished(event["id"])


func scene_source(id: StringName) -> String:
	return _scene_sources.get(String(id), "")


func request_scene(request: int) -> StringName:
	return _atomic_request_scenes.get(request, &"")


func active_request_for_scene(id: StringName) -> int:
	if _current_cinematic == id:
		return _current_request
	var requests: Array = _passive_requests.get(id, [])
	return int(requests[0]) if requests.size() == 1 else 0


func production_readiness() -> Dictionary:
	if _atomic.port == null:
		return {"capabilities": [], "phase_evidence": []}
	var status := _atomic.port.readiness()
	if not RunSaveCodec.validate_tree(status, 1024).is_empty() or not status.get("capabilities") is Array or not status.get("phase_evidence") is Array:
		return {"capabilities": [], "phase_evidence": []}
	if not status["capabilities"].is_empty() and status["phase_evidence"].is_empty():
		return {"capabilities": [], "phase_evidence": []}
	return status.duplicate(true)


## topic catalog is loaded from the same source document as the main root.
func npc_optional_topics(origin: StringName) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var source := scene_source(origin)
	var definition: Variant = _scenes.get(String(origin))
	if source.is_empty() or not definition is Dictionary:
		return result
	var binding := str(definition.get("binding", ""))
	var raw: Variant = _npc_topic_catalog.get(source, {}).get(binding, [])
	if not raw is Array or raw.size() > 16:
		return result
	for topic: Variant in raw:
		if not topic is Dictionary or topic.size() != 3 or not topic.get("scene") is String or not topic.get("title") is String or topic["title"].is_empty() or topic["title"].length() > 128:
			return []
		if not topic.has("condition") or not StoryConditionTree.validate(topic["condition"])["valid"] or not has_scene(StringName(topic["scene"])) or scene_source(StringName(topic["scene"])) != source:
			return []
		for previous: Dictionary in result:
			if previous["scene"] == topic["scene"]:
				return []
		result.append(topic.duplicate(true))
	return result


## Fresh Main CommitPort read capture only; cannot authorize a reward.
func npc_topic_available(origin: StringName, topic: Dictionary) -> bool:
	if not npc_optional_topics(origin).has(topic):
		return false
	return _atomic.interaction_condition(StringName(topic["scene"]), topic["condition"])


## Runtime-only clinic ownership. Never part of progress_snapshot/install JSON.
var _clinic_stage_host: StageContinuationHost
var _clinic_menu := false
var _clinic_restore_menu := false
var _clinic_take_pending := 0
var _clinic_retry_id := &""
var _clinic_retry_option := &""


## Main calls from request_started after actual death-witness source capture.
## For Continue, current scene may be an uncompleted clinic topic: this factory
## materializes the author's c09 structure WITHOUT applying c09 results again.
func arm_clinic_continuation(source: StoryRunSource.Source) -> bool:
	if is_instance_valid(_clinic_stage_host) or source == null \
			or not StoryRunSource.new().valid(source, source.request, _current_cinematic):
		return false
	var host := StageContinuationHost.new()
	add_child(host)
	_clinic_stage_host = host
	if not host.prepare(self, source):
		_clinic_stage_host = null
		host.release(&"preparation_failed", false)
		return false
	host.invalidated.connect(_clinic_host_invalidated)
	if _clinic_restore_menu or _current_cinematic != StageContinuationHost.ROOT:
		var player := CutscenePlayer.new()
		add_child(player)
		if not player.materialize_clinic_for_resume(host):
			player.cancel()
			_release_clinic_stage(&"resume_materialization_failed")
			return false
	return true


func _clinic_host_live(request: int) -> bool:
	return is_instance_valid(_clinic_stage_host) and _clinic_stage_host.request == request \
		and not _clinic_stage_host.retired


## Main PREPARING hook. An empty author's `then` retains this visit, not a fake
## authored edge. Main owns durable continuation metadata and restored witness.
func clinic_retains_terminal(request: int, id: StringName, continuation: StringName) -> bool:
	if continuation != &"" or request != _current_request or id != _current_cinematic \
			or not _clinic_host_live(request) or not _clinic_stage_host.captured:
		return false
	var source := _clinic_stage_host._source
	return StoryRunSource.new().valid(source, request, id) \
		and _clinic_stage_host.authenticates(source, source.level.get_ref(), id)


## Pure save intent, NOT stage/death authority. Continue cannot pass this data
## to arm(): Root must rehydrate a validated death boundary and fresh Source.
func clinic_resume_descriptor(request: int) -> Dictionary:
	if request != _current_request or not _clinic_host_live(request) or not _clinic_stage_host.captured:
		return {}
	var source := _clinic_stage_host._source
	if not StoryRunSource.new().valid(source, request, _current_cinematic):
		return {}
	return {"kind": "first_clinic_visit", "origin": String(StageContinuationHost.ROOT),
		"stage_id": String(StageContinuationHost.STAGE), "binding": "first_clinic",
		"source_path": source.source_path, "level_path": source.level_path,
		"area_id": source.area_id, "segment": String(_current_cinematic), "menu": _clinic_menu}


func _release_clinic_stage(reason: StringName) -> void:
	_clinic_menu = false
	_clinic_restore_menu = false
	_clinic_take_pending = 0
	_clinic_retry_id = &""
	_clinic_retry_option = &""
	var host := _clinic_stage_host
	_clinic_stage_host = null
	if is_instance_valid(host):
		host.release(reason, false)


func _clinic_host_invalidated(request: int, reason: StringName) -> void:
	if is_instance_valid(_clinic_stage_host) and _clinic_stage_host.request == request:
		# Host revoked before this callback. Normal reset handles busy producer scope.
		reset_active_presentation(reason)


## Not an authored decision: selects an existing interaction or ends the visit.
## Each click re-reads loaded metadata and canonical owner facts through Main.
func _clinic_show_menu() -> void:
	if not _clinic_host_live(_current_request) or not _clinic_stage_host.captured:
		return
	var request := _current_request
	var generation := _presentation_generation
	_clinic_menu = true
	_atomic_clear_decision()
	var rows: Array[Dictionary] = []
	var dispatcher: Variant = _scenes.get("ch1_dispatch_first_clinic")
	if dispatcher is Dictionary and dispatcher.get("binding") == "first_clinic" \
			and dispatcher.get("mode") == "dispatch" and dispatcher.get("routes") is Array \
			and dispatcher["routes"].size() <= 64:
		var targets: Array[StringName] = []
		for route: Variant in dispatcher["routes"]:
			if not route is Dictionary or not route.get("target") is String or not route.get("condition") is Dictionary:
				_clinic_show_retry(_current_cinematic, &"", "診間入口資料無效，進度保持原狀。", false)
				return
			var target := StringName(route["target"])
			if target != StageContinuationHost.ROOT and _atomic.interaction_condition(target, route["condition"]):
				targets.append(target)
		if targets.size() > 1:
			_clinic_show_retry(_current_cinematic, &"", "診間入口條件重疊，進度保持原狀。", false)
			return
		if targets.size() == 1 and not was_completed(targets[0]) and not (_atomic_chains.get(_current_request, []) as Array).has(targets[0]):
			rows.append({"scene": targets[0], "title": "查看托盤上的物品", "main": true})
	else:
		_clinic_show_retry(_current_cinematic, &"", "診間入口尚未接妥，進度保持原狀。", false)
		return
	for topic in npc_optional_topics(StageContinuationHost.ROOT):
		if not was_completed(StringName(topic["scene"])) and not (_atomic_chains.get(_current_request, []) as Array).has(StringName(topic["scene"])) \
				and npc_topic_available(StageContinuationHost.ROOT, topic):
			rows.append({"scene": StringName(topic["scene"]), "title": topic["title"], "main": false})
	if request != _current_request or generation != _presentation_generation or not _clinic_host_live(request):
		return
	var column := _clinic_panel("診間")
	for row in rows:
		var button := Button.new()
		button.text = row["title"]
		button.pressed.connect(_clinic_choose_topic.bind(row["scene"], row["main"], _current_request, _presentation_generation))
		column.add_child(button)
	var leave := Button.new()
	leave.text = "離開診間，繼續旅程"
	leave.pressed.connect(_clinic_leave.bind(_current_request, _presentation_generation))
	column.add_child(leave)
	leave.grab_focus()


func _clinic_choose_topic(target: StringName, main: bool, request: int, generation: int) -> void:
	if not _clinic_menu or request != _current_request or generation != _presentation_generation \
			or _atomic.is_busy() or not _clinic_host_live(request):
		return
	var source := _clinic_stage_host._source
	if not StoryRunSource.new().valid(source, request, _current_cinematic) \
			or not _clinic_stage_host.authenticates(source, source.level.get_ref(), _current_cinematic) \
			or not source.graph.has(String(target)) or was_completed(target) or (_atomic_chains.get(request, []) as Array).has(target):
		return
	var allowed := false
	if main:
		var dispatcher: Variant = _scenes.get("ch1_dispatch_first_clinic")
		var count := 0
		if not dispatcher is Dictionary or not dispatcher.get("routes") is Array or dispatcher["routes"].size() > 64:
			return
		for route: Dictionary in dispatcher["routes"]:
			if _atomic.interaction_condition(StringName(route["target"]), route["condition"]):
				count += 1
				allowed = StringName(route["target"]) == target
		allowed = allowed and count == 1
	else:
		for topic in npc_optional_topics(StageContinuationHost.ROOT):
			if StringName(topic["scene"]) == target:
				allowed = npc_topic_available(StageContinuationHost.ROOT, topic)
	if not allowed or request != _current_request or generation != _presentation_generation:
		return
	_clinic_menu = false
	_atomic_clear_decision()
	var context := current_presentation_context()
	_current_cinematic = &""
	_start_cinematic(target, context, request)


func _clinic_leave(request: int, generation: int) -> void:
	if not _clinic_menu or request != _current_request or generation != _presentation_generation \
			or _atomic.is_busy() or not _clinic_host_live(request):
		return
	# This is presentation settlement only. Main owns actual checkpoint/respawn.
	_clinic_menu = false
	_atomic_clear_decision()
	_current_cinematic = &""
	_current_request = 0
	_presentation_context = {}
	_complete_request(request, true)
	_atomic_start_queued()


func _clinic_panel(title: String) -> VBoxContainer:
	_atomic_decision_layer = CanvasLayer.new()
	_atomic_decision_layer.layer = UiLayers.DIALOGUE
	_atomic_decision_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_atomic_decision_layer)
	_atomic_decision_root = PanelContainer.new()
	_atomic_decision_root.theme = UiKit.theme()
	_atomic_decision_root.set_meta(&"clinic_visit_panel", true)
	_atomic_decision_layer.add_child(_atomic_decision_root)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.follow_focus = true
	_atomic_decision_root.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(column)
	column.minimum_size_changed.connect(_clinic_queue_panel_layout)
	var label := Label.new()
	label.text = title
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(label)
	_atomic_layout_decision()
	get_viewport().size_changed.connect(_atomic_layout_decision)
	framing.safe_rect_changed.connect(_atomic_layout_decision)
	return column


## Coordinator's failure path is noncommitted and closed. Retry runs complete()
## from fresh facts/source/write preparation; never reuses a prepared writer.
func _clinic_show_retry(id: StringName, option: StringName, message: String, retry_result := true) -> void:
	_atomic_clear_decision()
	_clinic_menu = false
	_clinic_retry_id = id if retry_result else &""
	_clinic_retry_option = option
	# Diagnostic details are for the log; recovery UI never exposes filesystem paths.
	push_warning("[StoryClinic] %s request=%d: %s" % [id, _current_request, message.left(512)])
	var column := _clinic_panel("尚未保存這段結果；請再試一次或取消。" if retry_result else "這次互動未能完成；請取消後重新進入。")
	if retry_result:
		var retry := Button.new()
		retry.text = "再試一次"
		retry.pressed.connect(_clinic_retry.bind(_current_request, _presentation_generation))
		column.add_child(retry)
		retry.grab_focus()
	var cancel := Button.new()
	cancel.text = "取消，保留進度"
	cancel.pressed.connect(cancel_atomic_request.bind(&"clinic_cancel"))
	column.add_child(cancel)


func _clinic_retry(request: int, generation: int) -> void:
	if request != _current_request or generation != _presentation_generation or _atomic.is_busy() \
			or not _clinic_host_live(request) or _clinic_retry_id != _current_cinematic:
		return
	_atomic_clear_decision()
	if not _clinic_stage_host.captured:
		if is_instance_valid(_player) and _player.is_running():
			_player._finish()
		return
	_atomic_finish(_clinic_retry_id, _clinic_retry_option)


func _clinic_stage_failed(id: StringName) -> void:
	if id == _current_cinematic and _clinic_host_live(_current_request):
		_clinic_show_retry(id, &"", "診間舞台未能建立，尚未保存這段結果。")


func atomic_request_pending() -> bool:
	return not _atomic_request_scenes.is_empty()


## Root's real restore callback passes an issued one-attempt runtime witness.
## Completed saved terminal builds only c09 structure and opens the visit menu.
## Uncompleted saved topic goes through normal admit/presentation/result path.
func resume_clinic_visit(witness: StoryRunSource.EntryWitness, scene: StringName) -> int:
	var receipt := witness.clinic_restore if witness != null else null
	if receipt == null or receipt.issuer == null or not receipt.issuer.get_ref() is ClinicVisitResume \
			or not receipt.issuer.get_ref().permits(witness, scene) or _atomic.is_busy() \
			or is_cinematic_active() or _current_request != 0 or not _cinematic_queue.is_empty():
		return 0
	var request := _request_serial + 1
	_request_serial = request
	_atomic_request_scenes[request] = scene
	_atomic_request_contexts[request] = receipt.context.duplicate(true)
	_atomic_chains[request] = []
	_waiters[request] = true
	if not was_completed(scene):
		_start_cinematic(scene, receipt.context, request)
		if _current_request != request:
			_clinic_forget_failed_resume(request)
			return 0
		return request
	# This is a presentation owner, not admit/complete of a completed scene.
	_presentation_generation += 1
	_current_cinematic = scene
	_current_request = request
	_presentation_context = receipt.context.duplicate(true)
	_clinic_restore_menu = true
	request_started.emit(request, scene, request_presentation_context(request))
	if request != _current_request or not _clinic_host_live(request) or not _clinic_stage_host.captured:
		if request == _current_request:
			cancel_atomic_request(&"clinic_restore_unbound")
		_clinic_forget_failed_resume(request)
		return 0
	_clinic_show_menu()
	return request


func _clinic_forget_failed_resume(request: int) -> void:
	_request_results.erase(request)
	_request_failure_scenes.erase(request)
	_waiters.erase(request)


func wait_clinic_visit(request: int) -> bool:
	if request <= 0 or not _waiters.has(request):
		return false
	while not _request_results.has(request):
		await request_settled
	var completed: bool = _request_results[request]
	_clinic_forget_failed_resume(request)
	return completed


func _clinic_physical_take(request: int, id: StringName) -> bool:
	var host := _clinic_stage_host
	if not _clinic_host_live(request) or not is_instance_valid(host.custody):
		return false
	var props := host.custody
	if not props.begin_take(host._source):
		return false
	var generation := _presentation_generation
	var started := Time.get_ticks_msec()
	while is_instance_valid(props) and props.state != ClinicStageCustody.State.HELD and props.state != ClinicStageCustody.State.INVALID:
		if request != _current_request or id != _current_cinematic or generation != _presentation_generation \
				or not is_instance_valid(host) or not host.motion_lease_live() or Time.get_ticks_msec() - started > 8000:
			return false
		await get_tree().process_frame
	return request == _current_request and id == _current_cinematic and generation == _presentation_generation \
		and is_instance_valid(props) and props.take_witness(host._source) != null


## Event-only presentation reflow. No request, owner, source or durable changes.
var _clinic_panel_layout_queued := false

func _clinic_queue_panel_layout() -> void:
	if _clinic_panel_layout_queued:
		return
	_clinic_panel_layout_queued = true
	_clinic_flush_panel_layout.call_deferred()

func _clinic_flush_panel_layout() -> void:
	_clinic_panel_layout_queued = false
	_atomic_layout_decision()

func _clinic_layout_panel(safe: Rect2) -> void:
	var scroll: ScrollContainer = _atomic_decision_root.get_child(0) as ScrollContainer
	if scroll == null or scroll.get_child_count() != 1:
		return
	var column: VBoxContainer = scroll.get_child(0) as VBoxContainer
	if column == null:
		return
	var style: StyleBox = _atomic_decision_root.get_theme_stylebox(&"panel")
	var padding: Vector2 = style.get_minimum_size()
	var width := minf(240.0, maxf(1.0, safe.size.x - 24.0))
	# Fixed column width prevents a zero-width wrapping label from leaving a huge
	# stale minimum height. Scroll follows real keyboard/controller focus.
	column.custom_minimum_size.x = maxf(1.0, width - padding.x - 16.0)
	var height := minf(maxf(1.0, safe.size.y - 24.0), column.get_combined_minimum_size().y + padding.y)
	_atomic_decision_root.size = Vector2(width, height)
	_atomic_decision_root.position = Vector2(safe.position.x + 12.0,
		maxf(safe.position.y + 12.0, safe.end.y - _atomic_decision_root.size.y - 12.0))
