from pathlib import Path
import hashlib, json

BASE = Path(__file__).parent
ROOT = Path('C:/Users/stanl/.codex/worktrees/chapter-one-runtime/Nest-Egg')
def sha(data): return hashlib.sha256(data).hexdigest()
def lf(data): return data.decode('utf8').replace('\r\n', '\n').encode()
manifest = json.loads((BASE / 'source-manifest.json').read_text(encoding='utf8'))
checks = []
def check(value, label):
    checks.append({'label': label, 'passed': bool(value)})
for row in manifest['patches']:
    path = row['path']
    current = ROOT / path
    candidate = (BASE / 'candidate' / path).read_bytes()
    check(sha(candidate) == row['postimage_lf_sha256'], path + ' frozen candidate SHA')
    if row['preimage_sha256'] == 'ABSENT':
        check(not current.exists(), path + ' actual source remains absent')
    else:
        check(sha(current.read_bytes()) == row['preimage_sha256'], path + ' actual preimage unchanged')
        check(sha(lf(current.read_bytes())) == row['preimage_lf_sha256'], path + ' LF preimage unchanged')
        check((BASE / 'preimage' / path).read_bytes() == current.read_bytes(), path + ' archived exact preimage')
fixture = json.loads((BASE / 'candidate/tests/fixtures/ch1_legacy_cinematics.json').read_text(encoding='utf8'))
check(set(fixture['scenes']) == {'ch1_c01_open', 'ch1_c09_wake', 'ch1_c14_home'}, 'explicit three-scene legacy fixture scope')
check(fixture['provenance']['commit'] == manifest['legacy_commit'], 'legacy commit provenance')
check(fixture['provenance']['source_sha256'] == manifest['legacy_catalog_sha256'], 'legacy source provenance SHA')
formal = json.loads((ROOT / 'data/story/ch1_kasa.json').read_text(encoding='utf8'))
animated = sorted(key for key, value in formal['scenes'].items() if value.get('mode') == 'animated')
check(animated == sorted(['ch1_t_supper_stay_address', 'ch1_c09_wake', 'ch1_c14_home']), 'actual published three animated scenes')
check('ch1_c01_open' not in formal['scenes'], 'actual formal source has no fabricated opening')
check(all('budget' not in formal['scenes'][key] and 'pose_policy' not in formal['scenes'][key] for key in animated), 'actual formal source lacks obsolete budget/pose-policy schema')
protected = {}
for path in ['core/run_snapshot.gd', 'core/story_run_source.gd', 'core/story_condition_tree.gd', 'core/story_run_commit_port.gd', 'tests/smoke_test.gd', 'tests/known_failures.txt', 'tools/select_tests.py']:
    file = ROOT / path
    protected[path] = sha(file.read_bytes()) if file.exists() else 'ABSENT'
check(protected['core/run_snapshot.gd'] == '78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c', 'protected RunSnapshot exact bytes')
check(protected['core/story_run_source.gd'] == 'cf1e279f486d0e9497150d9ff3639f651960db70b5ce4f4e307a21f9037b80e4', 'protected Source exact bytes')
check(protected['core/story_run_commit_port.gd'] == 'a10fa32095196f7f3e719587386482cac12b59b48525bb5e3e917e16e1365148', 'protected Port exact bytes')
check((BASE / 'gdparse-final.exit').read_text().strip() == '0' and (BASE / 'gdparse-final.log').stat().st_size == 0, 'six candidate GDScripts grammar only; not Godot semantic execution')
result = {'status': 'INCOMPLETE_WIP_FROZEN_NOT_READY_TO_APPLY', 'checks': checks, 'passed': sum(x['passed'] for x in checks), 'failed': sum(not x['passed'] for x in checks), 'protected_source_observations': protected, 'engine_run': False, 'original_cloud_all': {'baseline': manifest['baseline_head'], 'checks': 86162, 'new_failures': 126, 'known_failures': 0, 'exit_code': 1, 'script_errors': 3, 'provenance': 'Parent supplied natural EOF result; full per-failure raw report remains parent-owned; no attribution of all 126 failures to this candidate'}}
(BASE / 'cpu-final-report.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
if result['failed']:
    raise SystemExit(json.dumps([x for x in checks if not x['passed']], ensure_ascii=False))
artifacts = []
for path in sorted(BASE.rglob('*')):
    if path.is_file() and path.name not in {'freeze-manifest.json', 'freeze-manifest.sha256'}:
        artifacts.append({'path': path.relative_to(BASE).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())})
freeze = {'status': result['status'], 'scope': 'CPU-only incomplete contract migration handoff. Never apply entire WIP as verified completion.', 'baseline': manifest['baseline_head'], 'patches': manifest['patches'], 'artifacts': artifacts, 'engine_run': False, 'capabilities': [], 'repository_mutation': False}
encoded = (json.dumps(freeze, ensure_ascii=False, indent=2) + '\n').encode()
(BASE / 'freeze-manifest.json').write_bytes(encoded)
(BASE / 'freeze-manifest.sha256').write_text(sha(encoded) + '\n', encoding='ascii')
print(json.dumps({'passed': result['passed'], 'failed': result['failed'], 'artifact_count': len(artifacts), 'freeze_manifest_sha256': sha(encoded), 'status': freeze['status']}, ensure_ascii=False))
