from pathlib import Path
import subprocess,json,hashlib,difflib,re
ROOT=Path('C:/Users/stanl/.codex/worktrees/chapter-one-runtime/Nest-Egg')
OUT=Path(__file__).parent
OLD='2dab08d7a433d49af5ae8419ddcc794a16c83994'
def sha(b):return hashlib.sha256(b).hexdigest()
def src(p):return (ROOT/p).read_bytes().decode('utf8').replace('\r\n','\n')
rows=[]
def put(p,new):
 old=src(p) if (ROOT/p).exists() else ''
 assert old!=new,p
 dest=OUT/'candidate'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(new.encode())
 diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+p if old else '/dev/null',tofile='b/'+p))
 dp=p.replace('/','__')+'.diff';(OUT/dp).write_bytes(diff.encode())
 rows.append({'path':p,'preimage_sha256':sha((ROOT/p).read_bytes()) if old else 'ABSENT','preimage_lf_sha256':sha(old.encode()) if old else 'ABSENT','postimage_lf_sha256':sha(new.encode()),'diff':dp})
 if old:
  before=OUT/'preimage'/p;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes((ROOT/p).read_bytes())

raw=subprocess.run(['git','show',OLD+':data/story/ch1_kasa.json'],cwd=ROOT,stdout=subprocess.PIPE,check=True).stdout
old=json.loads(raw)
old_level=subprocess.run(['git','show',OLD+':data/levels/ch1_pawnshop.tres'],cwd=ROOT,stdout=subprocess.PIPE,check=True).stdout
old_intro=re.search(r'^intro_scene = &"([^"]+)"',old_level.decode('utf8'),re.M)
assert old_intro and old_intro.group(1)=='ch1_c01_open'
assert all(k in old['scenes'] for k in ['ch1_c01_open','ch1_c09_wake','ch1_c14_home'])
fixture={'provenance':{'commit':OLD,'path':'data/story/ch1_kasa.json','source_sha256':sha(raw),'level_path':'data/levels/ch1_pawnshop.tres','level_sha256':sha(old_level),'classification':'legacy compatibility only; never loaded by Story.CHAPTER_PATHS'},'scenes':{k:old['scenes'][k] for k in ['ch1_c01_open','ch1_c09_wake','ch1_c14_home']},'level_hooks':{'pawnshop':{'intro_scene':old_intro.group(1)}},'speakers':old['speakers']}
put('tests/fixtures/ch1_legacy_cinematics.json',json.dumps(fixture,ensure_ascii=False,indent=2)+'\n')

helper='''extends RefCounted
## Published CH1 presentation/data contract only, never Main/source capability.
const LEGACY: JSON = preload("res://tests/fixtures/ch1_legacy_cinematics.json")
const FORMAL_PATH := "res://data/story/ch1_kasa.json"
const LIVE: Array[String] = ["ch1_t_supper_stay_address", "ch1_c09_wake", "ch1_c14_home"]

static func legacy_scene(id: StringName) -> Dictionary:
	return (LEGACY.data["scenes"][String(id)] as Dictionary).duplicate(true)

static func catalog_bytes() -> PackedByteArray:
	return var_to_bytes([Story._scenes, Story._scene_sources, Story._npc_topic_catalog,
		Story._scene_chapter, Story._chapters, Story._speakers, Story._respawn_scenes,
		Story._death_scenes, Story._death_sequences, Story._death_notes, GameState.flag_defaults])

static func owner_bytes() -> PackedByteArray:
	return var_to_bytes([GameState._install_source(), Story._install_source(), Progression.snapshot(), StoryItems.snapshot()])

static func live_seconds(s: TestSuite) -> float:
	var before := owner_bytes()
	var catalog := catalog_bytes()
	var source: JSON = load(FORMAL_PATH) as JSON
	s.check(source != null and source.data is Dictionary, "formal CH1 published source is an actual imported JSON resource")
	if source == null or not source.data is Dictionary:
		return 0.0  # Failed check above; this is not accepted as valid duration.
	var authored: Dictionary = source.data["scenes"]
	var animated: Array[String] = []
	for id: String in authored:
		if authored[id].get("mode") == "animated":
			animated.append(id)
	animated.sort()
	var required: Array[String] = LIVE.duplicate()
	required.sort()
	s.check(animated == required, "published formal source has the exact three current animated scenes, without a fabricated P06 opening")
	var total := 0.0
	for id: String in LIVE:
		var scene: Dictionary = Story._scenes.get(id, {})
		s.check(not scene.is_empty() and Story.scene_source(StringName(id)) == FORMAL_PATH and authored.has(id) and scene == authored[id], "%s loaded scene and source path match the actual published JSON" % id)
		if scene.is_empty():
			continue
		s.check(StoryAtomicCoordinator.is_formal(scene) and scene.get("mode") == "animated", "%s is the real formal animated contract" % id)
		var steps: Variant = scene.get("steps")
		s.check(steps is Array and not steps.is_empty() and steps.size() <= 64, "%s has real bounded nonempty authored steps" % id)
		if not steps is Array or steps.is_empty():
			continue
		s.check(CutsceneChecker.validate(id, scene, Story._speakers).is_empty(), "%s actual steps, actors, speakers and stage resources validate" % id)
		s.check(CutsceneChecker.staging_problems(id, scene).is_empty(), "%s actual feet anchors are above the dialogue reserve; full visual proof is separate" % id)
		var says := 0
		var actors := 0
		for raw: Variant in steps:
			if not raw is Dictionary:
				continue
			var step: Dictionary = raw
			if step.get("do") == "say":
				says += 1
			if step.get("do") == "actor":
				actors += 1
			for key: String in ["pose", "then"]:
				if step.get("do") not in ["actor", "pose", "move"] or not step.has(key):
					continue
				var pose: String = str(step[key])
				s.check(CutsceneActor.POSES.has(pose), "%s uses an actual supported CutsceneActor %s pose" % [id, pose])
				if CutsceneChecker.SUPPORTED_POSES.has(pose):
					s.check(not str(step.get("pose_reason", "")).strip_edges().is_empty() and not str(step.get("pose_support", "")).strip_edges().is_empty(), "%s restricted live pose has an authored reason and physical support even without legacy policy metadata" % id)
		s.check(says > 0 and (actors > 0 or scene.get("overlay") == true), "%s contains real dialogue and actors or an explicitly authored overlay" % id)
		var duration: float = CutsceneChecker.estimate_seconds(scene)
		s.check(is_finite(duration) and duration > 0.0, "%s actual estimated duration is finite and positive; missing budgets do not default to zero" % id)
		var changed: Dictionary = scene.duplicate(true)
		changed["steps"].append({"do": "wait", "time": 0.37})
		s.check(is_equal_approx(CutsceneChecker.estimate_seconds(changed) - duration, 0.37), "%s real estimator observes an additional authored wait" % id)
		total += duration
	_main_hooks(s)
	s.check(owner_bytes() == before and catalog_bytes() == catalog, "live presentation checks leave every owner and full catalog unchanged")
	return total

static func _main_hooks(s: TestSuite) -> void:
	var pawn := load("res://data/levels/ch1_pawnshop.tres") as LevelData
	var dawn := load("res://data/levels/ch1_pawnshop_dawn.tres") as LevelData
	var stall := load("res://data/levels/ch1_stall.tres") as LevelData
	s.check(pawn != null and dawn != null and stall != null, "formal chapter boundary uses actual LevelData resources")
	if pawn == null or dawn == null or stall == null:
		return
	s.check(pawn.chapter == &"ch1_kasa" and pawn.intro_scene == &"" and not Story.has_scene(&"ch1_c01_open"), "published pawnshop deliberately leaves upstream intro to ST16/P06; this does not prove an integrated prologue")
	var layout: LevelLayout = LevelBuilder.parse(pawn)
	var actual_dinner := false
	for trigger: Dictionary in layout.story_triggers:
		actual_dinner = actual_dinner or trigger.get("scene") == &"ch1_b_dinner"
	s.check(layout.is_valid() and pawn.story_triggers.has("ch1_b_dinner") and actual_dinner, "actual pawnshop layout contains the real formal dinner trigger")
	var dinner: Dictionary = Story._scenes.get("ch1_b_dinner", {})
	var food: Dictionary = Story._scenes.get("ch1_b_dinner_food", {})
	s.check(dinner.get("binding") == "dinner" and dinner.get("then") == "ch1_b_dinner_food" and StoryAtomicCoordinator.is_formal(food) and Story._scene_set_flags(&"ch1_b_dinner_food").has("ch1_dinner_done"), "real dinner chain completes only through its formal food segment")
	s.check(dawn.intro_scene == &"ch1_c14_home" and dawn.complete_after_intro and dawn.next_level.is_empty(), "actual dawn entry owns formal home and the terminal chapter hook")
	var home_gate := false
	for resource: Resource in stall.legend.values():
		if resource is PortalData and (resource as PortalData).id == &"stall_home":
			var gate := resource as PortalData
			home_gate = gate.target_level == dawn.resource_path and gate.requires_flag == &"ch1_supper_done" and gate.cinematic_preview_scene == &"ch1_c14_home"
	s.check(home_gate, "actual stall-home portal requires supper completion and points to the actual formal home entry")
	var deaths: Variant = Story._death_scenes.get(&"ch1_kasa", [])
	var clinic := false
	if deaths is Array:
		for entry: Variant in deaths:
			if entry is Dictionary and entry.get("scene") == "ch1_c09_wake":
				clinic = entry.get("unless_flag") == "ch1_first_death_done" and entry.get("free") == true and entry.get("register_checkpoint") == true
	s.check(clinic and Story._scene_set_flags(&"ch1_c09_wake") == ["ch1_first_death_done"], "real first-death declaration and exact formal result agree; actual Main receipt tests own positive granting")
'''
put('tests/helpers/ch1_story_contract_checks.gd',helper)

p='autoload/story.gd';t=src(p)
needle='result.get("kind") == "flag" and result.get("value") == true:'
assert needle in t
put(p,t.replace(needle,'result.get("kind") == "flag" and typeof(result.get("value")) == TYPE_BOOL and result.get("value") == true:',1))

p='tests/suite/test_chapter_cutscenes.gd';t=src(p)
t=t.replace('const MAX_SAYS := 16','const MAX_SAYS := 16\nconst Contract = preload("res://tests/helpers/ch1_story_contract_checks.gd")',1)
t=t.replace('\t_test_ch1_pose_baseline()','\t_test_ch1_pose_baseline()\n\tContract.live_seconds(self)',1)
a=t.index('func _test_ch1_pose_baseline()');b=t.index('\n\nfunc _test_script_consistency()',a)
block=t[a:b].replace('_scene(', 'Contract.legacy_scene(')
block=block.replace('func _test_ch1_pose_baseline() -> void:\n','func _test_ch1_pose_baseline() -> void:\n\t# The superseded opening remains a real archived legacy contract, not product data.\n\tvar before := Contract.owner_bytes()\n\tvar catalog := Contract.catalog_bytes()\n',1)
block+='\n\tcheck(Contract.owner_bytes() == before and Contract.catalog_bytes() == catalog, "legacy pose checks do not install fixture scenes or change any owner")'
t=t[:a]+block+t[b:];put(p,t)

p='tests/suite/test_pacing.gd';t=src(p)
t=t.replace('const MAX_AREA_MINUTES := 8.0','const MAX_AREA_MINUTES := 8.0\nconst Contract = preload("res://tests/helpers/ch1_story_contract_checks.gd")',1)
t=t.replace('\t_test_algorithm()\n','\t_test_algorithm()\n\t_test_legacy_budgets()\n',1)
old_budget='''	var cutscene_seconds := 0.0
	for id in CUTSCENES:
		cutscene_seconds += float((Story.audit_data()["scenes"][id] as Dictionary).get("budget", 0.0))
	check(cutscene_seconds > 0.0, "the three cutscenes declare their budgets (%.0f s)" % cutscene_seconds)'''
assert old_budget in t
t=t.replace(old_budget,'''\t# Live formal scenes use the actual existing step estimator, not invented budgets.
\tvar cutscene_seconds: float = Contract.live_seconds(self)''',1)
t+='''

func _test_legacy_budgets() -> void:
	var before := Contract.owner_bytes()
	var catalog := Contract.catalog_bytes()
	var cutscene_seconds := 0.0
	for id in CUTSCENES:
		var scene: Dictionary = Contract.legacy_scene(StringName(id))
		check(scene.has("budget") and float(scene["budget"]) > 0.0, "%s legacy authored budget is present and positive" % id)
		cutscene_seconds += float(scene["budget"])
	check(cutscene_seconds > 0.0, "the three cutscenes declare their budgets (%.0f s)" % cutscene_seconds)
	check(Contract.owner_bytes() == before and Contract.catalog_bytes() == catalog, "legacy budget checks preserve every owner and the full product catalog")
''';put(p,t)

p='tests/suite/test_continuity.gd';t=(Path('C:/tmp/ne246-cloud-story-fixture-review/candidate')/p).read_text(encoding='utf8')
t=t.replace('const SEEN_FLAG := &"ch1_first_death_done"','const SEEN_FLAG := &"ch1_first_death_done"\nconst Contract = preload("res://tests/helpers/ch1_story_contract_checks.gd")',1)
original='''	Story._apply_scene_flags(&"ch1_c09_wake")
	check(GameState.has_flag(SEEN_FLAG), "finishing the scene writes its flag")'''
assert original in t
t=t.replace(original,'''\tvar formal_before := Contract.owner_bytes()
\tvar catalog_before := Contract.catalog_bytes()
\tStory._apply_scene_flags(&"ch1_c09_wake")
\tcheck(not GameState.has_flag(SEEN_FLAG) and Contract.owner_bytes() == formal_before, "legacy completion cannot grant the published formal clinic result or mutate any owner")
\tcheck(Story._scene_set_flags(&"ch1_c09_wake") == [String(SEEN_FLAG)], "published clinic result projects its exact first-death flag without granting it")
\tcheck(Contract.catalog_bytes() == catalog_before, "formal clinic read-only checks preserve the actual loaded catalog")
\t_test_legacy_completion_flag()''',1)
t+='''

func _test_legacy_completion_flag() -> void:
	# Distinct fixture ID: never disguise published formal c09 as legacy.
	const ID := "test_legacy_ch1_c09_wake"
	check(not Story._scenes.has(ID), "legacy completion fixture never replaces a published scene")
	if Story._scenes.has(ID):
		return
	var before := Contract.owner_bytes()
	var catalog := Contract.catalog_bytes()
	var flags: Dictionary = GameState.world_flags.duplicate(true)
	var autosave: bool = GameState.story_autosave
	GameState.story_autosave = false
	Story._scenes[ID] = Contract.legacy_scene(&"ch1_c09_wake")
	Story._apply_scene_flags(StringName(ID))
	check(GameState.has_flag(SEEN_FLAG), "finishing the scene writes its flag")
	Story._scenes.erase(ID)
	GameState.world_flags = flags
	GameState.story_autosave = autosave
	check(Contract.owner_bytes() == before and Contract.catalog_bytes() == catalog, "legacy completion fixture restores all owners and the full actual catalog")
''';put(p,t)

p='tests/suite/test_ch1_map.gd';t=src(p)
t=t.replace('const TILE := 16.0','const TILE := 16.0\nconst Contract = preload("res://tests/helpers/ch1_story_contract_checks.gd")',1)
t=t.replace('\t_test_narrative()','\t_test_narrative()\n\tContract.live_seconds(self)',1)
# Atomic flags are projected from actual formal result declarations, never granted here.
t=t.replace('for flag: Variant in (scene as Dictionary).get("set_flags", []):','for flag: Variant in Story._scene_set_flags(StringName(id)):',1)
needle='\tcheck(_datas["pawnshop"].intro_scene == &"ch1_c01_open", "the opening cutscene starts the chapter")'
assert needle in t
t=t.replace(needle,'''\t# Retain the prior resource contract explicitly as historical compatibility.
\tcheck(Contract.LEGACY.data["level_hooks"]["pawnshop"]["intro_scene"] == "ch1_c01_open", "the opening cutscene starts the chapter")
\tcheck(_datas["pawnshop"].intro_scene == &"" and not Story.has_scene(&"ch1_c01_open"), "actual pawnshop defers upstream prologue ownership to ST16/P06; no obsolete opening is installed")''',1)
needle='\t\tvar scene: Dictionary = Story._scenes.get(id, {})\n\t\tcheck(not scene.is_empty() and float(scene.get("budget", 0.0)) == float(CUTSCENE_BUDGETS[id])'
assert needle in t
t=t.replace(needle,'\t\tvar scene: Dictionary = Contract.legacy_scene(StringName(id))\n\t\tcheck(not scene.is_empty() and float(scene.get("budget", 0.0)) == float(CUTSCENE_BUDGETS[id])',1)
# This tests the live service's scene-path collection, so choose a real loaded scene/stage.
t=t.replace('AssetPrefetch.scene_texture_paths(&"ch1_c01_open")','AssetPrefetch.scene_texture_paths(&"ch1_c14_home")',1)
t=t.replace('stage_paths.has("res://art/environment/scenes/pawnshop_front.webp")','stage_paths.has("res://art/environment/scenes/pawnshop_kitchen.webp")',1)
put(p,t)

(OUT/'source-manifest.json').write_text(json.dumps({'scope':'CPU-only exact candidates; protected products unchanged; native not run','baseline_head':'a5f2a1ba9eb64233b56108c3e930c68bffa52158','legacy_commit':OLD,'legacy_catalog_sha256':sha(raw),'patches':rows},indent=2)+'\n',encoding='utf8')
print(json.dumps(rows,indent=2))
