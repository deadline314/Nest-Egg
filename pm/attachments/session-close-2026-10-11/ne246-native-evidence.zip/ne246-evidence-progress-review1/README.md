# NE246 原生進度與畫面缺陷候選

2026-10-11；本包只做 CPU 讀取、原證據位元組複製與文字候選。沒有啟動引擎、修改 repo／Git／PM、重寫產品資料或快照。NE246 維持「進行中」，原驗收條件不勾完。

## 可核原生證據

| 批次 | 最終檢查／失敗 | PID | 自然離開／退出碼 | 全 raw 錯誤／來源漂移 |
|---|---:|---:|---|---|
| normal-9 | 75 / 0 | 31756 | 是 / 0 | 0 / 0 |
| initial-retry-4 | 89 / 0 | 10228 | 是 / 0 | 0 / 0 |
| initial-cancel-1 | 54 / 0 | 31724 | 是 / 0 | 0 / 0 |
| final-retry-1 | 90 / 0 | 15108 | 是 / 0 | 0 / 0 |
| final-cancel-1 | 85 / 0 | 29972 | 是 / 0 | 0 / 0 |
| record-current-1 | 72 / 0 | 28364 | 是 / 0 | 0 / 0 |
| cold-current-1 | 63 / 0 | 29708 | 是 / 0 | 0 / 0 |
| combat-4 | 97 / 0 | 32956 | 是 / 0 | 0 / 0 |

七種正式閱讀模式合計 528 / 0；combat4 另計 97 / 0，不取代七模式。每批的 result、完整 native.log、原生 summary／receipt 已逐位元組複製；七批 source-manifest 原路徑與 SHA 留在 evidence-manifest.json，combat4 全來源 manifest 另有實際複本。本次獨立掃完整 raw 的 SCRIPT ERROR、Parse Error、Compile Error、ERROR: 與 probe FAIL，八批均無命中；沒有套 expected-negative 排除。自然 EOF、來源漂移依原 launcher result／關閉 summary 記錄核對，CPU review 沒有重新執行原生。

combat4 真 Input 射擊使彈匣 12→11。同一子彈 ID 801682496152 在未暫停兩個 physics frame 移動且 life .65→.633333；六次讀訊／暫停快照保留該 ID、位置 (835.8143, 231.0675)、速度、life .45、規格與 can_process=false。三個世界凍結列（閱讀、實際 Pause、返回閱讀）皆有 7 個敵人、1 顆現存活動子彈，before/after time 同為 3.80650633333332；Main、Level、Player 均不能處理。HUD 是 00:03.81。這是本次實例的有界證據，不是整章、全武器／全敵人或實體手把完成證據。

Root 已看兩張 actual PNG；本次 CPU 也獨立看圖，確認讀訊／Pause 畫面及下述 tooltip 問題。原 result.visual_accepted=false 原樣保留，沒有改寫成完整 UI 通過。

## 來源與界線

combat4 HEAD 是 a5f2a1ba9eb64233b56108c3e930c68bffa52158；完整來源列數 7884。它是原 7881 加獨立 combat probe GD／scene／UID 三檔；這三檔沒有包含在已推送的 148 路徑 WIP checkpoint。不可將 combat4 全來源實驗冒充雲端 feature 全來源測試。

八批 manifest 的 RunSnapshot 均為 78eaaed37e0f473a5ce0c864ce579ae5604ebc9bfe2806bfa998e421f00e469c；Source 均為 cf1e279f486d0e9497150d9ff3639f651960db70b5ce4f4e307a21f9037b80e4。本包沒有改寫兩者，也沒有安裝 owner、造 runtime proof 或替換產品資料。

Root 報告原 a5f2 雲端 ALL 有三個腳本錯誤：ChapterCutscenes steps、Story bool(String)、Pacing ch1_c01。當前包尚未取得該批完整 raw；此為明列來源的 Root 報告，不能寫成独立核實的完整回歸通過。與本次原生結果分開保留，NE246／整章尚未完成。

## 舊 red 與修正來源

所有原批次 raw/result/source manifest 保留原位置與 SHA，詳 evidence-manifest.json.prior_runs；没有覆寫／轉綠。

- normal1–4 的工具型別／匯入失敗，normal5 的 checkpoint owner 邊界、normal6 的 runtime proof／canonical projection 邊界，都不計入 528。
- normal7 雖 60 / 0，fixture root Always 使實例 Main/Level 繼承 Always，時鐘有前進。只保留其 Source／閱讀／checkpoint 鏈證據，不接受 worldFreeze。後續工具明設 actual Main PAUSABLE；沒有改產品 Main/Level。
- initial-retry2/3 雖各 89 / 0 且自然 exit0，EOF 都有「56 resources still in use at exit」，passed=false。callback cycle 的工具 disarm 修正後，initial-retry4 才有乾淨 EOF。
- combat1 有真飛行子彈檢查失敗；combat2 有 native viewport 內瞄準點檢查失敗；combat3 有同一子彈／截圖 settled 檢查失敗。combat4 的 native pointer warp 後仍由真 Input 產生射擊，不直接 spawn 子彈或修改 aim_dir；前批不能算通過。

## 畫面缺陷與候選文字

[兩项設計紀錄候選](design-defect-record-candidate.md) 分開畫面觀察與尚未證實的正式流程根因。[NE246 進度 Commit 候選](Commit-progress-candidate.md) 只寫玩家結果與目前驗收，不改票狀態／勾選。候選沒有新開票號、沒有把 NE246 的凍結證據當完整 UI 好了。

證據圖片：[返回閱讀](images/normal-actual-manual-reading-pause-return.png)、[實際 Pause](images/normal-actual-pause-above-manual.png)。
