extends Node
## Arranged real Main/NPC integration; semantic loaded-Button adapter, not human play.
## Two distinct processes and one isolated genuine slot. No author/owner writes.
const MainScript := preload("res://game/main.gd")
const Capture := preload("res://tools/viewport_capture.gd")
const A := &"ch1_t_ali_order"
const B := &"ch1_t_ali_name"
const ORDER := "ch1.revival_meal.order"
var _main: Node
var _out := ""
var _phase := ""
var _slot := ""
var _fault := ""
var _checks := 0
var _failures := 0
var _armed := false
var _rejections := 0
var _a_finishes := 0
var _b_finishes := 0
var _a_starts := 0
var _b_starts := 0
var _wallet_before_a := -1
var _owners_after_a: Dictionary = {}
var _pending_bytes := PackedByteArray()
var _pending_record: Dictionary = {}
var _events: Array[Dictionary] = []
var _old_auto_skip := false
var _old_skip_setting := false
var _next_advance := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--out="):
			_out = argument.trim_prefix("--out=").replace("\\", "/")
		elif argument.begins_with("--phase="):
			_phase = argument.trim_prefix("--phase=")
	if not _out.is_absolute_path() or _phase not in ["record-rejection", "cold-complete"] \
			or DisplayServer.get_name() == "headless" or RenderingServer.get_current_rendering_method() != "forward_plus":
		push_error("[OnceAliProbe] requires native Forward+, absolute isolated --out and a declared phase")
		get_tree().quit(2)
		return
	DirAccess.make_dir_recursive_absolute(_out)
	_slot = _out.path_join("slot.json")
	_fault = _out.path_join("writer-fault-directory")
	_run.call_deferred()


func _check(value: bool, label: String) -> void:
	_checks += 1
	if not value:
		_failures += 1
	print("ONCE_ALI_CHECK:", "PASS" if value else "FAIL", ":", label)


func _frames(count: int) -> void:
	for i in count:
		await get_tree().process_frame


func _action(action: StringName, pressed: bool) -> void:
	var event := InputEventAction.new()
	event.action = action
	event.pressed = pressed
	Input.parse_input_event(event)


func _advance() -> void:
	if Time.get_ticks_msec() < _next_advance or is_instance_valid(Story._atomic_decision_root):
		return
	if Story._current_cinematic == &"":
		return
	_next_advance = Time.get_ticks_msec() + 220
	_action(&"ui_accept", true)
	_action(&"ui_accept", false)


func _wait(predicate: Callable, milliseconds := 45000, option_scene: StringName = &"", option_id := "") -> bool:
	var deadline := Time.get_ticks_msec() + milliseconds
	while Time.get_ticks_msec() < deadline and _failures == 0:
		if predicate.call():
			return true
		if is_instance_valid(Story._atomic_decision_root) and option_scene != &"":
			if Story._current_cinematic != option_scene:
				_check(false, "unexpected loaded decision refuses guessed choice: " + String(Story._current_cinematic))
				return false
			await _capture("decision-" + String(option_scene) + ".png")
			_check(_press_option(option_scene, option_id), "explicit authored option through its actual loaded Button: " + option_id)
		else:
			_advance()
		await get_tree().process_frame
	return predicate.call()


func _idle() -> bool:
	return is_instance_valid(_main._screen) and not _main._route_pending() and not Transition.is_active() \
		and not Story.is_cinematic_active() and not Story.atomic_request_pending() and not GameplayLock.is_locked()


func _read_slot() -> Dictionary:
	var reader := RunSaveStore.new(_slot)
	reader.validator = RunSnapshot.prepare
	return reader.read()


func _owners() -> Dictionary:
	return {"flags": StoryRuntimeFacts.persistable_flags(GameState.world_flags), "progression": Progression.snapshot(),
		"items": StoryItems.snapshot(), "completed": Story.progress_snapshot()}


func _run() -> void:
	# Isolate real Input events from physical devices; retain normal physics/Areas.
	for action: StringName in InputMap.get_actions():
		InputMap.action_erase_events(action)
		Input.action_release(action)
	GameState.story_autosave = false
	_old_auto_skip = Story.auto_skip
	_old_skip_setting = Settings.get_skip_cutscenes()
	Story.auto_skip = false
	Settings.set_skip_cutscenes(false)
	_main = MainScript.new()
	_main._run_store = RunSaveStore.new(_slot)
	add_child(_main)
	Story.request_started.connect(_started)
	Story.result_rejected.connect(_rejected)
	Story.scene_finished.connect(_finished)
	_check(await _wait(func() -> bool: return _main._screen is MainMenu and _idle()), "actual Main menu installed")
	var a: Dictionary = Story._scenes.get(String(A), {})
	var b: Dictionary = Story._scenes.get(String(B), {})
	_check(Story.is_atomic_scene(A) and Story.is_atomic_scene(B) and a.get("then") == String(B) \
		and a.get("completion_policy", "once") == "once" and b.get("completion_policy", "once") == "once" \
		and a.get("binding") == "ali_lounge" and b.get("binding") == "ali_lounge", "loaded Ali A→B are both once; repeatable dinner policy is never substituted")
	if _failures == 0:
		if _phase == "record-rejection":
			await _record()
		else:
			await _cold()
	await _finish_probe()


func _route(path: String) -> Level:
	if not await _wait(_idle):
		_check(false, "actual previous route/presentation settles")
		return null
	_main._on_area_requested(path)
	var ready := await _wait(func() -> bool: return _main._screen is Level and _main._screen.data.resource_path == path and _idle())
	_check(ready, "arranged actual Main destination installed: " + path)
	if not ready:
		return null
	return _main._screen as Level


func _npc(level: Level, id: StringName, cell: Vector2i) -> NpcActor:
	var found: NpcActor
	for node in level._entities.get_children():
		if node is NpcActor and node.data.id == id and node.cell == cell:
			if found != null:
				_check(false, "authored NPC must be unique")
				return null
			found = node
	_check(found != null, "actual loaded NPC resource and cell exist: " + String(id))
	return found


func _interact(npc: NpcActor, player_cell: Vector2i) -> bool:
	if not is_instance_valid(npc) or not await _wait(_idle):
		return false
	var level := _main._screen as Level
	level.player.global_position = level._layout.cell_to_feet(player_cell.x, player_cell.y)
	level.player.velocity = Vector2.ZERO
	var overlap := await _wait(func() -> bool: return npc.get_overlapping_bodies().has(level.player) \
		and npc._player_in_range and npc._prompt_player == level.player \
		and npc.interaction_available() and Story.framing.is_interaction_target(npc), 15000)
	_check(overlap, "true Player/Area overlap, prompt and framing target admit interaction")
	if not overlap:
		return false
	_action(&"interact", true)
	await get_tree().physics_frame
	await get_tree().physics_frame
	_action(&"interact", false)
	await _frames(2)
	# Optional topic menus still use the actual loaded main-topic Button.
	if is_instance_valid(npc._topic_chooser):
		var matches: Array[Dictionary] = []
		for topic in npc.available_topics():
			if topic.get("main", false):
				matches.append(topic)
		_check(matches.size() == 1 and _press_text(npc._topic_chooser, str(matches[0]["title"])), "actual NPC topic chooser selects its loaded main interaction")
		await _frames(3)
	return _failures == 0


func _record() -> void:
	_check(not _main._run_store.exists() and not FileAccess.file_exists(_out.path_join("record-rejection.json")), "first phase requires a fresh isolated directory; existing genuine records preserved")
	if _failures > 0:
		return
	_main._on_start_requested(GameState.difficulties[1])
	_check(await _wait(func() -> bool: return _main._screen is Level and _idle()), "actual Main starts a new run")
	if _failures > 0:
		return
	var vault := await _route("res://data/levels/ch1_vault.tres")
	if vault == null:
		return
	var pickup: CollectiblePickup
	for node: Variant in vault._tracked.values():
		if is_instance_valid(node) and node is CollectiblePickup and node.item.id == &"ch1_data_disk":
			pickup = node
	_check(is_instance_valid(pickup) and pickup._story_formal, "actual tracked vault disk has its trusted runtime-only pickup factory")
	if _failures > 0:
		return
	vault.player.global_position = pickup.global_position
	vault.player.velocity = Vector2.ZERO
	_check(await _wait(func() -> bool: return StoryItems.holds(&"ch1_data_disk"), 20000), "real Player overlap acquires disk through genuine durable writer")
	var disk_record := _read_slot()
	_check(disk_record.get("story", {}).get("items", {}).get("held", []).has("ch1_data_disk") \
		and disk_record.get("state", {}).get("area_states", {}).get("ch1_vault", {}).get("consumed", {}).has("ch1_data_disk@40,16"), "independent actual slot proves disk custody and consumed world slot")
	if _failures > 0:
		return
	var handoff := await _route("res://data/levels/ch1_handoff.tres")
	if handoff == null:
		return
	var cabinet := _npc(handoff, &"ch1_handoff_cabinet", Vector2i(18, 19))
	for row: Dictionary in [
		{"scene": &"ch1_t_handoff_confirm", "option": "deliver", "flag": &"ch1_disk_delivered"},
		{"scene": &"ch1_t_handoff_receipt_prompt", "option": "take", "flag": &"ch1_disk_receipt_taken"},
		{"scene": &"ch1_t_handoff_summary_prompt", "option": "save", "flag": &"ch1_handoff_done"},
	]:
		if not await _interact(cabinet, Vector2i(17, 19)):
			return
		var flag: StringName = row["flag"]
		_check(await _wait(func() -> bool: return GameState.has_flag(flag), 45000, row["scene"], row["option"]), "genuine cabinet authored result: " + String(flag))
		if _failures > 0:
			return
	var lounge := await _route("res://data/levels/ch1_lounge.tres")
	if lounge == null:
		return
	var ali := _npc(lounge, &"ch1_ali_lounge", Vector2i(30, 19))
	if not await _interact(ali, Vector2i(29, 19)):
		return
	_check(await _wait(func() -> bool: return _rejections == 1, 60000, &"ch1_t_ali_1", "order"), "A genuinely commits and B reaches exactly one real writer rejection")
	if _failures > 0:
		return
	_check(_a_finishes == 1 and _b_finishes == 0 and _a_starts == 1 and _b_starts == 1, "once A completed exactly once; rejected B has no completion")
	_check(_owners() == _owners_after_a, "B writer rejection does not roll back A or change wallet/items/flags/completion")
	# The synchronous rejection observer proved byte preservation BEFORE an
	# ordinary queued Main save is allowed to replace the presentation marker.
	_check_a(_read_slot(), false)
	# Exercise ordinary Main lifecycle saving. NPC result rejection clears its
	# cinematic marker; the authored dispatcher is the legal new interaction route.
	_main._show_main_menu()
	_check(await _wait(func() -> bool: return _main._screen is MainMenu and _idle()), "actual Main returns to menu and saves the rejected NPC state normally")
	var saved := _read_slot()
	_check_a(saved, false)
	_check(saved.get("cinematic") == "" and saved.get("cinematic_context") == {}, "normal rejected-NPC save has no fabricated entry resume marker")
	_write_json("pending-a-to-b.json", _pending_record)
	var raw_evidence := FileAccess.open(_out.path_join("pending-a-to-b-slot.json"), FileAccess.WRITE)
	_check(raw_evidence != null, "original genuine A→B slot bytes have an evidence-only artifact")
	if raw_evidence != null:
		raw_evidence.store_buffer(_pending_bytes)
		raw_evidence.close()
	_write_json("record-rejection.json", {"pid": OS.get_process_id(), "wallet_before_a": _wallet_before_a,
		"owners_after_a": _owners_after_a, "saved_slot_sha256": FileAccess.get_sha256(_slot),
		"pending_slot_sha256": FileAccess.get_sha256(_out.path_join("pending-a-to-b-slot.json")),
		"a_finishes": _a_finishes, "b_finishes": _b_finishes, "rejections": _rejections})
	await _capture("rejected-return-menu.png")


func _cold() -> void:
	var evidence: Variant = JSON.parse_string(FileAccess.get_file_as_string(_out.path_join("record-rejection.json")))
	_check(evidence is Dictionary and _main._run_store.exists(), "cold phase requires genuine first-process artifacts and existing save")
	if not evidence is Dictionary or _failures > 0:
		return
	_check(evidence.get("pid") != OS.get_process_id(), "cold Continue runs in a distinct native process")
	_check(FileAccess.get_sha256(_slot) == evidence.get("saved_slot_sha256"), "cold process reads the exact prior genuine slot bytes")
	_wallet_before_a = evidence["wallet_before_a"]
	var expected := _prepare_evidence_owners(evidence.get("owners_after_a"))
	_check(expected.has("data"), "cold expected owners restore only validated JSON scalar types: " + str(expected.get("error", "")))
	if not expected.has("data"):
		return
	_owners_after_a = expected["data"]
	_check_evidence_negative_controls(evidence["owners_after_a"])
	if _failures > 0:
		return
	_check_a(_read_slot(), false)
	if _failures > 0:
		return
	_main._on_continue_requested()
	_check(await _wait(func() -> bool: return _main._screen is Level and _idle()), "actual Main Continue read/apply/Level/publication completes")
	_check(_main._screen is Level and _main._screen.data.resource_path == "res://data/levels/ch1_lounge.tres", "Continue restores the true saved lounge")
	_check(Progression.snapshot() == _owners_after_a["progression"] and StoryItems.snapshot() == _owners_after_a["items"] \
		and Story.was_completed(A) and not Story.was_completed(B), "cold restore preserves A receipt/custody/wallet and leaves B unfinished")
	if _failures > 0:
		return
	var ali := _npc(_main._screen as Level, &"ch1_ali_lounge", Vector2i(30, 19))
	if not await _interact(ali, Vector2i(29, 19)):
		return
	_check(await _wait(func() -> bool: return Story.was_completed(B), 45000), "same real Ali interaction author-dispatches B and durably completes it")
	_check(_a_starts == 0 and _a_finishes == 0 and _b_starts == 1 and _b_finishes == 1 and _rejections == 0, "cold process never replays once A; genuinely completes B exactly once")
	_check(Progression.snapshot() == _owners_after_a["progression"] and StoryItems.snapshot() == _owners_after_a["items"], "B completion leaves original zero-charge order receipt, bill and wallet unchanged")
	_main._save_run()
	_check_a(_read_slot(), true)
	await _capture("cold-b-complete.png")
	# Re-interact through the same real dispatcher to prove it does not replay A/B.
	if await _interact(ali, Vector2i(29, 19)):
		_check(await _wait(_idle), "post-completion actual NPC interaction settles")
		_check(_a_starts == 0 and _b_starts == 1 and _b_finishes == 1, "subsequent actual NPC interaction cannot complete A or B a second time")
		_check(Progression.snapshot() == _owners_after_a["progression"], "subsequent dialogue neither adds order debt nor charges a fee")
	_main._show_main_menu()
	_check(await _wait(func() -> bool: return _main._screen is MainMenu and _idle()), "completed cold run returns through actual Main menu lifecycle")
	_check_a(_read_slot(), true)


## Probe P2: JSON numbers become float and custody ids become String. Recreate
## the expected snapshot types from its own validated evidence, never live state.
## No restore/install, Source, receipt, flag, completion or slot mutation occurs.
func _prepare_evidence_owners(raw: Variant) -> Dictionary:
	var errors := RunSaveCodec.validate_tree(raw)
	if not errors.is_empty():
		return {"error": errors[0]}
	if not raw is Dictionary or raw.size() != 4 or not raw.has_all(["flags", "progression", "items", "completed"]):
		return {"error": "probe/evidence/owners requires the exact recorded owner fields"}
	var money := Progression.prepare_install(raw["progression"])
	if money.has("error"):
		return money
	var items := StoryItems.prepare_snapshot(raw["items"], "probe/evidence/items")
	if items.has("error"):
		return items
	# Require the recorded current-format snapshot, never a legacy/default repair.
	if not raw["items"] is Dictionary or raw["items"].size() != 5 or not raw["items"].has_all(["custody_version", "owned", "unseen", "held", "transferred"]):
		return {"error": "probe/evidence/items must retain all five custody fields"}
	var result: Dictionary = raw.duplicate(true)
	# All numeric fields in Progression.snapshot are integer-valued. The strict
	# owner validator above rejects fractions/NaN/types before any conversion.
	result["progression"] = _integer_evidence_tree(raw["progression"])
	result["items"] = items["data"]
	# Preserve every value, array order and field; only JSON-lost types may change.
	if JSON.parse_string(JSON.stringify(result)) != JSON.parse_string(JSON.stringify(raw)):
		return {"error": "probe/evidence retyping changed recorded content"}
	return {"data": result}


func _integer_evidence_tree(value: Variant) -> Variant:
	if value is Dictionary:
		var result: Dictionary = {}
		for key: Variant in value:
			result[key] = _integer_evidence_tree(value[key])
		return result
	if value is Array:
		var result: Array = []
		for item: Variant in value:
			result.append(_integer_evidence_tree(item))
		return result
	return int(value) if typeof(value) in [TYPE_INT, TYPE_FLOAT] else value


func _check_evidence_negative_controls(raw: Dictionary) -> void:
	var owners_before := var_to_bytes(_owners())
	var serialized_before := var_to_bytes(raw)
	var changed: Dictionary = raw.duplicate(true)
	changed["progression"]["credits"] += 1
	var prepared := _prepare_evidence_owners(changed)
	_check(prepared.has("data") and prepared["data"]["progression"] != _owners_after_a["progression"], "evidence retyping cannot hide a changed wallet")
	changed = raw.duplicate(true)
	changed["progression"]["story_transactions"]["receipts"].erase(ORDER)
	prepared = _prepare_evidence_owners(changed)
	_check(prepared.has("data") and prepared["data"]["progression"] != _owners_after_a["progression"], "evidence retyping cannot hide a lost order receipt")
	changed = raw.duplicate(true)
	changed["items"]["held"].erase("ch1_lounge_bill")
	changed["items"]["transferred"].append("ch1_lounge_bill")
	prepared = _prepare_evidence_owners(changed)
	_check(prepared.has("data") and prepared["data"]["items"] != _owners_after_a["items"], "evidence retyping cannot hide changed bill custody")
	for fault: String in ["fraction", "wrong_type", "missing_custody", "duplicate_custody", "receipt_delta", "receipt_fingerprint"]:
		changed = raw.duplicate(true)
		match fault:
			"fraction": changed["progression"]["credits"] = 0.5
			"wrong_type": changed["progression"]["credits"] = "0"
			"missing_custody": changed["items"].erase("held")
			"duplicate_custody": changed["items"]["owned"].append("ch1_lounge_bill")
			"receipt_delta": changed["progression"]["story_transactions"]["receipts"][ORDER]["credits_delta"] = 1
			"receipt_fingerprint": changed["progression"]["story_transactions"]["receipts"][ORDER]["definition_fingerprint"] = "0".repeat(64)
		_check(_prepare_evidence_owners(changed).has("error"), "evidence refuses corrupt comparison data: " + fault)
	_check(var_to_bytes(_owners()) == owners_before and var_to_bytes(raw) == serialized_before, "comparison negative controls leave all real owners and original evidence untouched")


func _started(request: int, id: StringName, context: Dictionary) -> void:
	var source := _main._story_port._sources.get(request) as StoryRunSource.Source
	_events.append({"event": "request_started", "pid": OS.get_process_id(), "scene": String(id), "request": request,
		"context": context.duplicate(true), "source_present": source != null,
		"source_valid": source != null and _main._story_source_valid(source, request, id),
		"source_kind": source.kind if source != null else "", "source_origin": String(source.origin) if source != null else "",
		"source_binding": source.binding if source != null else "", "source_file": source.source_path if source != null else "",
		"source_node_id": source.node.get_ref().get_instance_id() if source != null and source.node != null and is_instance_valid(source.node.get_ref()) else 0,
		"npc_lease_id": source.npc_lease.get_instance_id() if source != null and source.npc_lease != null else 0,
		"actual_player_id": _main._screen.player.get_instance_id() if _main._screen is Level else 0,
		"actual_player_position": str(_main._screen.player.global_position) if _main._screen is Level else ""})
	if id == A:
		_a_starts += 1
		_wallet_before_a = Progression.credits
		_capture.call_deferred("a-current-pose.png")
	if id != A and id != B:
		return
	_check(source != null and source.kind == "person" and source.binding == "ali_lounge" \
		and source.context == context and source.cell == Vector2i(30, 19) \
		and source.origin == &"ch1_dispatch_ali_lounge" and source.npc_lease != null \
		and source.node.get_ref() == _npc(_main._screen as Level, &"ch1_ali_lounge", Vector2i(30, 19)) \
		and _main._story_source_valid(source, request, id), "A/B use the actual Ali NPC producer lease and unchanged loaded binding")
	if id == B:
		_b_starts += 1
		_capture.call_deferred("b-current-pose.png")
		if _phase != "record-rejection" or _armed or _rejections != 0 or _failures > 0:
			return
		_pending_record = _read_slot()
		_check_a(_pending_record, false)
		_check(StoryRunSource._condition_live({"account": "ch1_lounge", "equals": "open200"}), "actual canonical ledger derives one open200 order, without a wallet debit or invented debt flag")
		_check(_a_finishes == 1 and _pending_record.get("cinematic") == String(B) \
			and _pending_record.get("cinematic_context") == context, "A durable batch genuinely records unfinished B with original NPC context")
		_owners_after_a = _owners()
		_pending_bytes = FileAccess.get_file_as_bytes(_slot)
		_check(DirAccess.make_dir_recursive_absolute(_fault) == OK and DirAccess.dir_exists_absolute(_fault), "fault uses a real directory under the isolated output")
		if _failures == 0:
			_armed = true
			_main._run_store.path = _fault


func _rejected(id: StringName, request: int, status: StringName, message: String) -> void:
	_events.append({"event": "result_rejected", "scene": String(id), "request": request, "status": String(status),
		"message": message, "source_error": _main._story_sources.last_error})
	if id != B or not _armed:
		_check(false, "unexpected real story rejection; no fake source/receipt recovery")
		return
	# Synchronous restoration: ordinary queued save/menu can use the real slot.
	_main._run_store.path = _slot
	_armed = false
	_rejections += 1
	_check(status in [&"invalid_preparation", &"write_rejected"] and message.contains("durable/source is a directory"), "B rejects for the injected actual writer-directory fault")
	_check(_owners() == _owners_after_a and Story.was_completed(A) and not Story.was_completed(B), "rejection observer retains exactly A's durable owners")
	_check(FileAccess.get_file_as_bytes(_slot) == _pending_bytes, "rejection observer confirms original genuine slot bytes remain intact")


func _finished(id: StringName) -> void:
	if id == A:
		_a_finishes += 1
	elif id == B:
		_b_finishes += 1


func _check_a(saved: Dictionary, b_complete: bool) -> void:
	var story: Dictionary = saved.get("story", {})
	var flags: Dictionary = story.get("flags", {})
	var progression: Dictionary = saved.get("progression", {})
	var receipts: Dictionary = progression.get("story_transactions", {}).get("receipts", {})
	_check(not saved.is_empty() and story.get("seen", []).count(String(A)) == 1 \
		and story.get("seen", []).count(String(B)) == int(b_complete), "independent genuine record contains once A and exact B completion count")
	_check(flags.get("ch1_ali_reception_selected") == true and flags.get("ch1_met_ali", false) == b_complete \
		and story.get("items", {}).get("held", []).has("ch1_lounge_bill"), "genuine record preserves A reception/order bill and correct B met flag")
	_check(receipts.has(ORDER) and receipts.get(ORDER, {}).get("credits_delta") == 0 \
		and progression.get("credits") == _wallet_before_a, "200 open order is a zero-wallet-delta receipt, not a 200 debit")
	for id in ["ch1.revival_meal.paid", "ch1.revival_meal.tab", "ch1.revival_meal.gift", "ch1.revival_meal.later_pay"]:
		_check(not receipts.has(id), "order/name proof cannot invent settlement/fees: " + id)


func _press_option(scene: StringName, id: String) -> bool:
	var found: Array[Dictionary] = []
	for option: Dictionary in (Story._scenes.get(String(scene), {}) as Dictionary).get("options", []):
		if option.get("id") == id:
			found.append(option)
	return found.size() == 1 and _press_text(Story._atomic_decision_root, str(found[0]["text"]))


func _press_text(root: Node, text: String) -> bool:
	var buttons: Array[Button] = []
	_collect(root, text, buttons)
	if buttons.size() != 1:
		return false
	buttons[0].pressed.emit()
	return true


func _collect(node: Node, text: String, buttons: Array[Button]) -> void:
	if not is_instance_valid(node):
		return
	if node is Button and node.text == text and not node.disabled and node.is_visible_in_tree():
		buttons.append(node)
	for child in node.get_children():
		_collect(child, text, buttons)


func _capture(name: String) -> void:
	await RenderingServer.frame_post_draw
	_check(Capture.image(get_viewport()).save_png(_out.path_join(_phase + "-" + name)) == OK, "native viewport artifact: " + name)


func _write_json(name: String, value: Dictionary) -> void:
	var file := FileAccess.open(_out.path_join(name), FileAccess.WRITE)
	_check(file != null, "probe evidence file opens: " + name)
	if file != null:
		file.store_string(JSON.stringify(value, "\t"))
		file.close()


func _finish_probe() -> void:
	if is_instance_valid(_main):
		_main._run_store.path = _slot
	Story.auto_skip = _old_auto_skip
	Settings.set_skip_cutscenes(_old_skip_setting)
	_write_json(_phase + "-summary.json", {"phase": _phase, "pid": OS.get_process_id(), "checks": _checks,
		"failures": _failures, "a_starts": _a_starts, "b_starts": _b_starts, "a_finishes": _a_finishes,
		"b_finishes": _b_finishes, "rejections": _rejections, "events": _events,
		"capabilities": Story.production_readiness(), "slot_sha256": FileAccess.get_sha256(_slot),
		"scope": "arranged real Main/physical disk overlap/actual NPC Input/loaded Button adapter; no full chapter, human input or readiness grant"})
	print("ONCE_ALI_SUMMARY:", JSON.stringify({"phase": _phase, "checks": _checks, "failures": _failures}))
	if is_instance_valid(_main):
		_main._quit(0 if _failures == 0 else 1)
	else:
		get_tree().quit(1)
