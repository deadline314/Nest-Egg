extends "res://tools/ne246_formal_reading_native_probe.gd"
## Independent normal-only native combat radio probe; base routes/assertions retained.
const BASE_PROBE_SHA := "e8b36951a7e7d0ec42229cf5996062d3a00d98be73e60e2d4e3af1011d24a38e"
## Synthetic semantic input, genuine current Player weapon/projectile; no spawn/loadout edits.
var _combat_projectile_id: int = 0
var _combat_spec_path: String = ""
var _combat_observations: Array[Dictionary] = []
var _combat_hold_count: int = 0

func _ready() -> void:
	if FileAccess.get_sha256("res://tools/ne246_formal_reading_native_probe.gd") != BASE_PROBE_SHA:
		push_error("[NE246Combat] base native probe bytes changed; review a new manifest before running")
		get_tree().quit(2)
		return
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--mode=") and argument != "--mode=normal":
			push_error("[NE246Combat] this independent tool accepts normal mode only")
			get_tree().quit(2)
			return
	super._ready()

func _manual_record() -> void:
	_check(not _main._run_store.exists() and not FileAccess.file_exists(_out.path_join("record-fault.json")), "record requires fresh isolated out; prior evidence is never overwritten")
	if _failures > 0:
		return
	_main._on_start_requested(GameState.difficulties[1])
	_check(await _wait(func() -> bool: return _main._screen is Level and _idle()), "actual Main starts new run")
	if _failures > 0:
		return
	var previous := _main._screen as Level
	previous.tree_exited.connect(_retired.bind(previous), CONNECT_ONE_SHOT)
	_main._on_area_requested(VAULT)
	# A real configured destination exists, but is not the current live Main Level.
	var destination: Variant = _main._pending_screen
	_check(destination is Level and _main._story_begin_entry(destination, &"trigger", 0).is_empty(), "actual pending wrong Level cannot obtain Main entry authority")
	_check(await _wait(func() -> bool: return _main._screen is Level and _main._screen.data.resource_path == VAULT and _idle()), "arranged Main installs actual loaded vault")
	if _failures > 0:
		return
	var level := _main._screen as Level
	level.tree_exited.connect(_retired.bind(level), CONNECT_ONE_SHOT)
	_check(level._layout.story_triggers.size() == 1 and level._layout.story_triggers[0]["scene"] == A \
		and level._layout.story_triggers[0]["x"] == 768.0 and level._layout.cell(48, 16) == "&", "actual layout declares original unique trigger index0/x768/(48,16)")
	var disk: CollectiblePickup
	for node: Variant in level._tracked.values():
		if is_instance_valid(node) and node is CollectiblePickup and node.item.id == &"ch1_data_disk":
			_check(disk == null, "physical disk pickup is unique")
			disk = node
	_check(is_instance_valid(disk) and disk._story_formal and disk.position == level._layout.cell_to_feet(40, 16), "actual disk uses formal pickup at (40,16), distinct from radio threshold")
	if _failures > 0:
		return
	# Arranged placement only: custody still requires real Player/Area overlap.
	level.player.global_position = disk.global_position
	level.player.velocity = Vector2.ZERO
	_check(await _wait(func() -> bool: return StoryItems.holds(&"ch1_data_disk"), 20000), "true Player overlap durably acquires actual disk")
	_check(await _wait(func() -> bool: return Story.was_seen(&"ch1_k_vault"), 15000), "original vault entry bark settles before owner baseline")
	var saved := _read_slot()
	_check(saved.get("story", {}).get("items", {}).get("held", []).has(&"ch1_data_disk") \
		and saved.get("story", {}).get("flags", {}).get("ledger_disk_obtained") == true \
		and saved.get("state", {}).get("area_states", {}).get("ch1_vault", {}).get("consumed", {}).has("ch1_data_disk@40,16"), "independent real slot proves disk custody/flag/consumed world slot")
	_check(level.player.global_position.x < 768 and _main._story_begin_entry(level, &"trigger", 0).is_empty(), "actual Player below x768 cannot obtain trigger witness")
	for index: int in [-1, 1]:
		_check(_main._story_begin_entry(level, &"trigger", index).is_empty(), "wrong actual trigger index cannot obtain authority: " + str(index))
	_owners_after_disk = _owners()
	await _capture("disk-before-cross.png")
	if _failures > 0:
		return
	_check(_bubble_observed and _bubble_nonmodal and Story.was_seen(&"ch1_k_vault"), "ordinary authored bubbles still finish automatically before important radio")
	if _phase in ["initial-retry", "initial-cancel"]:
		_checkpoint_fault = Driver.arm_initial_fault(_main, _suite, _out)
		_check(not _checkpoint_fault.is_empty(), "driver arms only actual registered Main source after independent disk save")
	var before_x := level.player.global_position.x
	_action(&"move_right", true)
	await _shoot_before_true_crossing(level)
	if _failures > 0:
		_action(&"move_right", false)
		return
	_check(await _manual_wait(func() -> bool: return _a_starts == 1, 10000), "actual Input-driven Player crosses x768 and Level begins original A")
	_action(&"move_right", false)
	_check(is_instance_valid(level.player) and not level.player.is_dead() and level.player.global_position.x >= 768 		and level.player.global_position.x > before_x, "crossing used real live movement; no state or trigger cursor assignment")
	if _failures > 0:
		return
	if _phase in ["initial-retry", "initial-cancel"]:
		await Driver.inspect_initial(_main, _suite, _checkpoint_fault, _phase == "initial-cancel")
		if _phase == "initial-cancel":
			_check(_owners() == _owners_after_disk and not Story.was_completed(A) and not Story.was_completed(B)
				and not _main._story_port._sources.has(_last_request) and level._next_story_trigger == 0,
				"initial cancel retires true Source with every disk owner unchanged and unconsumed trigger")
			return
		if _failures > 0:
			return
	_check(await _manual_wait(func() -> bool: return not Story.radio_checkpoint_pending(A, _main._cinematic_request)), "normal actual initial checkpoint is truly durable before read progression")
	var first_slot := _read_slot()
	_check(first_slot.get("cinematic") == String(A) and first_slot.get("cinematic_context") == {"framing_source": "entry", "source_id": "level:trigger:0"}, "independent slot saves actual first radio segment and original Source context")
	await _held_reading_and_pause()
	if _failures > 0 or _phase == "record-current":
		return
	if _phase in ["final-retry", "final-cancel"]:
		_check(await _manual_chain(B), "true manual A commits same-source durable then B before terminal fault")
		if _failures > 0:
			return
		Driver.inspect_final(_main, _suite, _out, _phase == "final-cancel")
		if _phase == "final-cancel":
			_check(_owners() == _owners_after_disk and not Story.was_completed(A) and not Story.was_completed(B)
				and not _main._story_port._sources.has(_last_request) and level._next_story_trigger == 0,
				"terminal cancel retires same-source then chain without owner award or trigger consumption")
			return
		if _failures > 0:
			return
	else:
		_check(await _manual_chain(), "actual fresh semantic confirmations complete full authored A→B chain")
	_check(_a_starts == 1 and _a_finishes == 1 and _b_starts == 1 and _b_finishes == 1 and _cancels == 0,
		"normal successful manual chain publishes both segments once and only settles terminal")
	_check(_owners() == _owners_after_disk and not Story.was_completed(A) and not Story.was_completed(B), "repeatable radio/cancel/refusal changes no wallet/custody/flags/once completion")
	_check(await _manual_wait(func() -> bool: return level._next_story_trigger == 1 and not level._story_trigger_pending), "only successful whole chain consumes live threshold cursor")
	_check(_read_slot().get("cinematic") == "", "actual durable terminal clears current segment")
	await _capture("manual-chain-settled.png")


func _shoot_before_true_crossing(level: Level) -> void:
	_check(await _manual_wait(func() -> bool: return level.player.global_position.x >= 736.0, 10000),
		"combat probe reaches pre-threshold firing position with actual move input")
	if _failures > 0:
		return
	var player: Player = level.player
	var weapon: WeaponData = player.loadout.active_weapon()
	_check(_a_starts == 0 and player.global_position.x < 768.0 and not get_tree().paused
		and player.can_process() and not player.is_dead() and weapon != null and not weapon.is_melee()
		and weapon.resource_path == "res://data/weapons/pistol.tres" and weapon.projectile != null
		and player.loadout.mag_in(player.loadout.active_slot) > 0,
		"current actual formal pistol has real ammunition before unchanged trigger x768")
	if _failures > 0:
		return
	_combat_spec_path = weapon.projectile.resource_path
	_check(_current_player_shot(level).is_empty(), "pre-shot pool has no earlier same-weapon Player projectile to misidentify")
	if _failures > 0:
		return
	var before_mag: int = player.loadout.mag_in(player.loadout.active_slot)
	# Aim through a real input event; do not assign aim_dir, device globals or a virtual source.
	# Original vault floor row16 is open to the right below the row14 platform.
	var target_world: Vector2 = player.aim_origin() + Vector2(32.0, 0.0)
	var point: Vector2 = player.get_canvas_transform() * target_world
	# Plain readonly values before the original guard: no Camera/Player/input mutation.
	var canvas: Transform2D = player.get_canvas_transform()
	var visible_rect: Rect2 = get_viewport().get_visible_rect()
	var origin: Vector2 = player.aim_origin()
	var camera: Camera2D = level.camera
	var camera_values: Dictionary = {"valid": is_instance_valid(camera)}
	if is_instance_valid(camera):
		camera_values.merge({"id": camera.get_instance_id(), "current": camera.is_current(),
			"position": [camera.position.x, camera.position.y],
			"global_position": [camera.global_position.x, camera.global_position.y],
			"offset": [camera.offset.x, camera.offset.y], "zoom": [camera.zoom.x, camera.zoom.y],
			"rotation": camera.rotation, "global_rotation": camera.global_rotation,
			"screen_center": [camera.get_screen_center_position().x, camera.get_screen_center_position().y],
			"smoothing_enabled": camera.position_smoothing_enabled, "smoothing_speed": camera.position_smoothing_speed,
			"process_callback": int(camera.process_callback)}, true)
	var aim_observation: Dictionary = {"stage": "pre_shoot_mouse_target",
		"point": [point.x, point.y], "target_world": [target_world.x, target_world.y],
		"visible_rect": {"position": [visible_rect.position.x, visible_rect.position.y],
			"size": [visible_rect.size.x, visible_rect.size.y]},
		"canvas_transform": {"x": [canvas.x.x, canvas.x.y], "y": [canvas.y.x, canvas.y.y],
			"origin": [canvas.origin.x, canvas.origin.y]},
		"player_global": [player.global_position.x, player.global_position.y],
		"aim_origin": [origin.x, origin.y], "actual_aim_dir": [player.aim_dir.x, player.aim_dir.y],
		"camera": camera_values, "physics_frame": Engine.get_physics_frames(),
		"process_frame": Engine.get_process_frames(), "paused": get_tree().paused, "a_starts": _a_starts,
		"has_point": visible_rect.has_point(point)}
	_combat_observations.append(aim_observation)
	print("NE246_COMBAT_AIM:", JSON.stringify(aim_observation))
	_check(get_viewport().get_visible_rect().has_point(point), "actual mouse aim target lies inside native viewport")
	if _failures > 0:
		return
	var mouse: InputEventMouseMotion = InputEventMouseMotion.new()
	mouse.position = point
	mouse.global_position = point
	mouse.relative = point - get_viewport().get_mouse_position()
	if mouse.relative.length_squared() < 16.0:
		mouse.relative = Vector2(4.0, 0.0)
	Input.parse_input_event(mouse)
	# Root Window on native Windows reads DisplayServer mouse position, not event-only mouse cache.
	# Official Viewport API maps this genuine pointer input from logical viewport coordinates.
	get_viewport().warp_mouse(point)
	var native_mouse: Vector2 = get_viewport().get_mouse_position()
	var native_world: Vector2 = player.get_global_mouse_position()
	var mouse_observation: Dictionary = {"stage": "native_pointer_after_warp",
		"viewport_mouse": [native_mouse.x, native_mouse.y], "world_mouse": [native_world.x, native_world.y],
		"requested_viewport": [point.x, point.y], "requested_world": [target_world.x, target_world.y],
		"aim_origin": [player.aim_origin().x, player.aim_origin().y],
		"player_global": [player.global_position.x, player.global_position.y],
		"physics_frame": Engine.get_physics_frames(), "process_frame": Engine.get_process_frames(),
		"paused": get_tree().paused}
	_combat_observations.append(mouse_observation)
	print("NE246_COMBAT_NATIVE_MOUSE:", JSON.stringify(mouse_observation))
	_action(&"shoot", true)
	var appeared: bool = await _manual_wait(func() -> bool: return not _current_player_shot(level).is_empty(), 1500)
	_action(&"shoot", false)  # exactly one normal semantic press; no extra fire after reading releases
	_check(appeared, "semantic shoot produces a genuine current-weapon Player projectile in actual Level pool")
	if not appeared:
		return
	var first: Dictionary = _current_player_shot(level)
	_check(not first.is_empty() and _a_starts == 0 and player.global_position.x < 768.0
		and not get_tree().paused and player.loadout.mag_in(player.loadout.active_slot) < before_mag
		and ProjectilePool.active_count() > 0 and (first["velocity"] as Vector2).length_squared() > 0.0,
		"actual ammo consumption and flying projectile precede original physical threshold")
	if _failures > 0:
		return
	_check(player.aim_dir.x > 0.0 and (first["velocity"] as Vector2).x > 0.0,
		"first actual shot really travels rightward from genuine native mouse input")
	if _failures > 0:
		return
	_combat_projectile_id = int(first["id"])
	_combat_observations.append({"stage": "first_actual_shot", "row": first.duplicate(true),
		"weapon": weapon.resource_path, "mag_before": before_mag, "mag_after": player.loadout.mag_in(player.loadout.active_slot),
		"player_x": player.global_position.x, "aim_dir": player.aim_dir, "mouse_target_world": target_world,
		"physics_frame": Engine.get_physics_frames(), "pool_active": ProjectilePool.active_count()})
	var flying: bool = await _manual_wait(func() -> bool:
		var row: Dictionary = _current_player_shot(level)
		return (not row.is_empty() and row["id"] == _combat_projectile_id
			and row["position"] != first["position"] and float(row["life"]) < float(first["life"])
			and float(row["life"]) > 0.0 and row["can_process"] and not get_tree().paused
			and _a_starts == 0 and level.player.global_position.x < 768.0), 1500)
	_check(flying, "same actual bullet moves and spends positive lifetime before real radio freeze")
	_combat_observations.append({"stage": "verified_live_flight", "passed": flying,
		"row": _current_player_shot(level), "player_x": player.global_position.x,
		"physics_frame": Engine.get_physics_frames(), "pool_active": ProjectilePool.active_count()})
	print("NE246_COMBAT_FLIGHT:", JSON.stringify(_combat_observations))


func _current_player_shot(level: Level) -> Dictionary:
	var container: Node2D = ProjectilePool.container()
	if not is_instance_valid(container) or not level.is_ancestor_of(container):
		return {}
	# The pool is bounded by its real MAX_SIZE. Observe; never create or alter slots.
	for child: Node in container.get_children():
		if not child is Projectile:
			continue
		var projectile: Projectile = child as Projectile
		if projectile.active and projectile.team == Combat.Team.PLAYER and projectile.spec != null \
			and projectile.spec.resource_path == _combat_spec_path \
			and (_combat_projectile_id == 0 or projectile.get_instance_id() == _combat_projectile_id):
			return {"id": projectile.get_instance_id(), "position": projectile.global_position,
				"velocity": projectile.velocity, "life": projectile._life, "can_process": projectile.can_process(),
				"team": int(projectile.team), "spec": projectile.spec.resource_path}
	return {}


func _paused_world_snapshot(level: Level) -> Dictionary:
	var proof: Dictionary = super._paused_world_snapshot(level)
	var shot: Dictionary = _current_player_shot(level)
	_check(_combat_projectile_id != 0 and not shot.is_empty() and shot["id"] == _combat_projectile_id
		and float(shot["life"]) > 0.0 and not shot["can_process"] and not proof["active_projectiles"].is_empty(),
		"combat reading snapshot includes the very same genuine previously flying Player bullet")
	var present: bool = false
	for row: Dictionary in proof["active_projectiles"]:
		if int(row["id"]) == _combat_projectile_id:
			present = row["position"] == shot["position"] and row["life"] == shot["life"] and row["velocity"] == shot["velocity"]
	_check(present, "base exact position/life snapshot really includes the identified live combat projectile")
	_combat_hold_count += 1
	_combat_observations.append({"stage": "paused_snapshot", "snapshot": _combat_hold_count,
		"row": shot, "physics_frame": Engine.get_physics_frames(), "pool_active": ProjectilePool.active_count()})
	return proof


func _finish_probe() -> void:
	_action(&"shoot", false)
	if _failures == 0:
		_check(_combat_hold_count == 6, "reading, actual Pause and returned reading each have before/after ballistic snapshots")
	if not _out.is_empty():
		_write_json("combat-reading-observations.json", {"scope": "normal-only genuine Input fire before original physical trigger; not full chapter/hardware play",
			"capabilities_granted": [], "projectile_id": _combat_projectile_id, "observations": _combat_observations,
			"checks": _checks, "failures": _failures, "base_probe_sha256": FileAccess.get_sha256("res://tools/ne246_formal_reading_native_probe.gd"),
			"combat_probe_sha256": FileAccess.get_sha256("res://tools/ne246_combat_reading_native_probe.gd"),
			"renderer": RenderingServer.get_current_rendering_method(), "pid": OS.get_process_id()})
	await super._finish_probe()
