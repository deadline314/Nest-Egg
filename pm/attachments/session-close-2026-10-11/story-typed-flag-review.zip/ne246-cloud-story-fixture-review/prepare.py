from pathlib import Path
import hashlib,json,difflib,collections

ROOT=Path('C:/Users/stanl/.codex/worktrees/chapter-one-runtime/Nest-Egg')
OUT=Path(__file__).parent
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return (ROOT/p).read_bytes().decode('utf-8').replace('\r\n','\n')
rows=[]
def candidate(path,old,new):
    assert old!=new
    dest=OUT/'candidate'/path; dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(new.encode())
    diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
    (OUT/(path.replace('/','__')+'.diff')).write_bytes(diff.encode())
    rows.append({'path':path,'preimage_sha256':sha((ROOT/path).read_bytes()),'preimage_lf_sha256':sha(old.encode()),'postimage_lf_sha256':sha(new.encode()),'diff':path.replace('/','__')+'.diff'})

p='autoload/story.gd';old=read(p)
needle='result.get("kind") == "flag" and result.get("value") == true:'
assert old.count(needle)==1
candidate(p,old,old.replace(needle,'result.get("kind") == "flag" and typeof(result.get("value")) == TYPE_BOOL and result.get("value") == true:'))

p='tests/suite/test_continuity.gd';old=read(p)
new=old.replace('\t_test_detects_orphans()\n','\t_test_detects_orphans()\n\t_test_formal_flag_projection()\n',1)
addition='''
## Read the actual Story projection; mixed formal values are not boolean flags.
## This installs no owner, runs no producer and grants no capability.
func _test_formal_flag_projection() -> void:
	const ID := "test_formal_flag_projection"
	check(not Story._scenes.has(ID), "formal flag projection fixture does not replace a loaded scene")
	if Story._scenes.has(ID):
		return
	var catalog_before := var_to_bytes([Story._scenes, Story._scene_sources, Story._npc_topic_catalog])
	var owners_before := var_to_bytes([GameState.story_progress_snapshot(), Story.progress_snapshot(), StoryItems.snapshot(), Progression.snapshot()])
	var mixed: Array = [
		{"kind": "flag", "id": "test_projection_true", "value": true},
		{"kind": "flag", "id": "test_projection_false", "value": false},
		{"kind": "flag", "id": "test_projection_string", "value": "unset"},
		{"kind": "flag", "id": "test_projection_string_true", "value": "true"},
		{"kind": "flag", "id": "test_projection_integer", "value": 1},
		{"kind": "flag", "id": "test_projection_float", "value": 1.0},
		{"kind": "flag", "id": "test_projection_missing"},
		{"kind": "flag", "id": "test_projection_array", "value": []},
		{"kind": "flag", "id": "test_projection_dictionary", "value": {}},
		{"kind": "transaction", "id": "test_projection_other_kind", "value": true},
	]
	Story._scenes[ID] = {"results_policy": "atomic_v1", "results": mixed}
	check(Story._scene_set_flags(StringName(ID)) == ["test_projection_true"], "actual formal projection includes only strict boolean true; strings/numbers/containers do not coerce")
	Story._scenes.erase(ID)
	check(var_to_bytes([Story._scenes, Story._scene_sources, Story._npc_topic_catalog]) == catalog_before, "formal projection regression restores the complete actual scene/source/topic catalog")
	check(var_to_bytes([GameState.story_progress_snapshot(), Story.progress_snapshot(), StoryItems.snapshot(), Progression.snapshot()]) == owners_before, "read-only formal projection leaves every owner unchanged")


'''
anchor='func _any(list: PackedStringArray, needle: String) -> bool:'
assert old.count(anchor)==1
new=new.replace(anchor,addition+anchor,1);candidate(p,old,new)

p='tests/suite/test_combat_hud.gd';old=read(p)
needle='func _test_radio_panel() -> void:\n'
assert old.count(needle)==1
new=old.replace(needle,needle+'''\t# Whole loaded catalog before/after the actual radio fixture, not a hash constant.
\tvar catalog_before := _loaded_story_catalog_bytes()
''',1)
new+='''
\tcheck(_loaded_story_catalog_bytes() == catalog_before, "actual CombatHud radio fixture preserves all loaded scenes, source paths, topics and chapter metadata")


func _loaded_story_catalog_bytes() -> PackedByteArray:
\treturn var_to_bytes([Story._scenes, Story._scene_sources, Story._npc_topic_catalog,
\t\tStory._scene_chapter, Story._chapters, Story._speakers, Story._respawn_scenes,
\t\tStory._death_scenes, Story._death_sequences, Story._death_notes, GameState.flag_defaults])
'''
candidate(p,old,new)

paths=['data/story/chapter_01.json','data/story/chapter_02.json','data/story/ch1_kasa.json','data/story/cutscenes_ch1.json','data/story/cutscenes_ch2.json']
catalog={};sources={};duplicates=[]
for p in paths:
    d=json.loads((ROOT/p).read_text(encoding='utf8'))
    for k,v in d.get('scenes',{}).items():
        if k in catalog: duplicates.append([k,p]);continue
        catalog[k]=v;sources[k]=p
formal=json.loads((ROOT/'data/story/ch1_kasa.json').read_text(encoding='utf8'))
report={'scope':'CPU deterministic CHAPTER_PATHS first-wins projection; not native loaded-state verification','catalog_count':len(catalog),'duplicate_scene_ids':duplicates,'legacy_open_exists': 'ch1_c01_open' in catalog,'formal_animated':[{ 'id':k,'source':sources[k],'pose_policy':v.get('pose_policy'),'budget':v.get('budget'),'steps':len(v.get('steps',[]))} for k,v in formal['scenes'].items() if v.get('mode')=='animated'],'actual_string_flag_results':[{ 'scene':k,'result':r} for k,v in catalog.items() for r in v.get('results',[]) if isinstance(r,dict) and r.get('kind')=='flag' and isinstance(r.get('value'),str)],'original_affected_assertions_retained':{}}
for row in rows:
    if row['path'].startswith('tests/'):
        before=read(row['path']);after=(OUT/'candidate'/row['path']).read_text(encoding='utf8')
        # Every old line remains an ordered subsequence; original checks are not rewritten.
        iterator=iter(after.splitlines());ok=all(any(line==oldline for line in iterator) for oldline in before.splitlines())
        assert ok,row['path'];report['original_affected_assertions_retained'][row['path']]=ok
(OUT/'cpu-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
evidence=['autoload/story.gd','tests/suite/test_combat_hud.gd','tests/suite/test_continuity.gd','tests/suite/test_chapter_cutscenes.gd','tests/suite/test_pacing.gd','tests/suite/test_cutscene.gd','tests/helpers/formal_radio_checkpoint_checks.gd','tests/helpers/formal_radio_settlement_checks.gd','tests/helpers/story_atomic_producer_checks.gd','tools/story/build_ch1_story.py','tools/story/test_ch1_production_backend.py','data/levels/ch1_pawnshop.tres',*paths,'core/run_snapshot.gd','core/story_run_source.gd','core/story_condition_tree.gd']
(OUT/'source-manifest.json').write_text(json.dumps({'baseline_head':'a5f2a1ba9eb64233b56108c3e930c68bffa52158','scope':'CPU-only; no registry/filter/known_failures/authority/author/source changes','patches':rows,'readonly_sources':[{'path':p,'sha256':sha((ROOT/p).read_bytes())} for p in evidence]},indent=2)+'\n',encoding='utf8')
print(json.dumps({'candidate_sources':len(rows),'catalog':report},ensure_ascii=False))
