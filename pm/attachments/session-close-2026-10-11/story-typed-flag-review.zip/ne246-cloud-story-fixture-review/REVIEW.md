# Cloud WIP148 Story 錯誤：CPU 唯讀診斷與窄候選

範圍：Root 私有工作樹 `C:/Users/stanl/.codex/worktrees/chapter-one-runtime/Nest-Egg`，基準 HEAD `a5f2a1ba9eb64233b56108c3e930c68bffa52158`。本包只寫 Ctmp；未啟動 Godot、未修改 repository / Git / PM。CPU grammar 不等於 Godot 語義或原生驗收。所有舊 raw / 紅測試均須保留。

## 已證明的原因

1. `tests/suite/test_chapter_cutscenes.gd:55` 與 `tests/suite/test_pacing.gd:76` 直接索引 `ch1_c01_open`。它在目前正式 JSON 本來不存在。`tools/story/build_ch1_story.py:548–551` 明確由 `_retained_document` 排除：P06 上游入口擁有序章，不重播舊試槍 intro。`tools/story/test_ch1_production_backend.py:32` 明確 `assertNotIn('ch1_c01_open', DOC['scenes'])`。這是來源／測試契約不一致，不能把舊演出塞回 catalog 來補測試。
2. `autoload/story.gd:570` 對 formal `flag` result 不分型別就和 `true` 比較。目前真 `ch1_t_supper_return` 寫入字串 `ch1_supper_choice='unset'`；GDScript 的 String / bool 比較會發 SCRIPT ERROR。候選只接受 TYPE_BOOL 後才比較 true，維持此 projection 回報「將設為真」旗標的原意。字串結果仍由原正式 planner 處理，沒有更改 author/result/condition/source/install/durable 規則。

`cpu-report.json` 以 `Story.CHAPTER_PATHS` 的實際五份 JSON、first-wins 順序建立 **CPU 預期** catalog：172 scenes、無重複 id、無 `ch1_c01_open`。這不是 runtime snapshot 或原生 pass。

## CombatHud 污染假說的核對

- `CombatHudSuite._test_radio_panel:85–99` 只新增並刪除自己的 `test_radio_panel` key；沒有 `_scenes.clear()` / whole-registry replacement / `load_chapter`。
- `formal_radio_settlement_checks:21/113`、`formal_radio_checkpoint_checks:42/168`、`story_atomic_producer_checks:99/221` 保存 `Story._scenes.duplicate(true)`，結尾回復。未發現這三處持有 whole-dictionary alias 後清空正式表的路徑。
- `CutsceneSuite._test_story_features:554` 合併自己兩個 `test_story_*` scenes，665–668 刪除對應 scene / chapter keys，無刪除 opening。它 **另有**尚未移除的測試 `_scene_sources` entries（load_chapter 會登記，teardown 沒有移除）；這不能造成已不存在的 `ch1_c01_open` 失蹤，本輪不為此擴大產品範圍。
- 候選在 **actual CombatHud radio fixture** 起點／終點新增動態全 catalog bytes 比較，包含 scenes、scene_sources、topic catalog、scene_chapter、chapters、speakers、respawn/death sequences/notes、flag defaults。使用實際前後內容，不比對硬編 SHA。原播放、滑入、閱讀、關閉的全部 assertions 原文保留。Root 尚須執行此新增回歸；不能宣稱污染假說已經由 runtime 排除。

## 可独立採用的三個窄 diff

1. `autoload__story.gd.diff`：單行 TYPE_BOOL guard；不得套到不同 preimage。
2. `tests__suite__test_continuity.gd.diff`：在原 `_test_real_data()` 前新增 actual projection 回歸，包含 true/false/string 'unset'/string 'true'/int 1/float 1.0/missing/array/dictionary/other result kind；唯一 strict true 可投影。fixture 不 replace loaded scene，結尾驗 complete catalog 與四 owner 不變，沒有 result completion / flag mutation / fake capability。
3. `tests__suite__test_combat_hud.gd.diff`：actual radio fixture 全 catalog 前後一致性。

`candidate/` 是窄 diff 的 postimage 供檢視，Root 應按 exact preimage + diff 採用；不以整檔覆蓋新的產品變更。manifest 同時列 actual bytes preimage、LF preimage、LF postimage。ConditionTree / RunSnapshot / StoryRunSource 只讀，未變更；registry/filter/known_failures 不動。

## 仍阻擋 whole ALL 綠燈的舊驗收契約

本包不刪或放寬原 assertions，故不宣稱三個錯誤已全部修完：

- ChapterCutscenes 的舊 opening、三場 `pose_policy='supported'`、舊 opening Rin counter 姿態與 pose_reason / pose_support negatives，目前都依賴已 superseded 來源。正式三場 animated 為 `ch1_t_supper_stay_address`（overlay）、`ch1_c09_wake`、`ch1_c14_home`，其 JSON 均無 pose_policy。直接換 ID 會令 restricted-pose negatives 失去意義：`CutsceneChecker:70` 只在 supported policy 時執行這些語意檢查。不能把沒有 policy 當同一驗收已通過。
- Pacing 原固定三 `budget` 的資料假設已失效：三個正式 animated scenes 均無 budget。不能默認 0、硬塞舊60秒、降低門檻或以讀字時間冒稱 author budget。應在 Root 決定新的正式估計契約後，對 author source / compiled metadata / calculator 做有來源的獨立遷移，並保留原時間／遭遇門檻目的。三個直接索引問題不是 UI Fixture 造成。
- `ContinuitySuite._test_real_data:95–96` 對正式 c09 直接 `_apply_scene_flags`，接著期望 first_death_done=true。產品 `Story._apply_scene_flags:320–321` 刻意跳過 atomic scene，由 durable commit 發放；此舊 assertion 會在 String SCRIPT 修完後仍 fail。不得讓舊 method 對正式場景直接授旗標，也不能偽造已完成診間。需用真的正式第一死 producer / durable port 回歸取代該 legacy expectation，或另明確保留 legacy fixture 的舊行為驗收。

## Root 驗收順序

先 exact 採單行產品與两個新增回歸、semantic import 查完整 raw，再單 CombatHud / Continuity 驗真正 method 行為。ChapterCutscenes / Pacing 舊 contract 的 red 必須保留並獨立处理；不要把這包當原 selector 全通。正式 compile/auth/readiness 保持原狀，本包不新增 capabilities。
