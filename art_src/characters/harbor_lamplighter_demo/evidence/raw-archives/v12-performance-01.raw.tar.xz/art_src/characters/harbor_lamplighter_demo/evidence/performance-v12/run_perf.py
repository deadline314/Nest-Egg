"""Run the unchanged original rig probe; externally sample process RAM only."""
from pathlib import Path
import hashlib,json,subprocess,sys,time,os
import psutil
import urllib.request
ROOT=Path('D:/NestEggVerification/role-20261117')
SOURCE=Path('C:/Users/stanl/Github/Nest-Egg')
OUT=Path(__file__).resolve().parent
PY=Path('D:/ComfyUI/.venv-rocm/Scripts/python.exe')
GODOT=Path('C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe')
FREEZE=SOURCE/'art_src/characters/harbor_lamplighter_demo/evidence/production-v12-freeze-123.json'
def hashes():
 values=json.loads(FREEZE.read_text(encoding='utf8'))['files']
 result={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in values}
 assert result==values, 'Frozen123 source mismatch'
 return result
def service_snapshot(label):
 values={}
 for endpoint in ['queue','system_stats']:
  with urllib.request.urlopen('http://127.0.0.1:8188/'+endpoint,timeout=5) as response:values[endpoint]=json.load(response)
 (OUT/('service-'+label+'.json')).write_text(json.dumps(values,indent=2)+'\n',encoding='utf8')
 assert not values['queue']['queue_running'] and not values['queue']['queue_pending'],'ComfyUI queue not idle'
 return values
before=hashes(); records=[]
user_data=OUT/'user-data';user_data.mkdir(exist_ok=True)
child_env=os.environ.copy()
child_env.update({name:str(user_data) for name in ['APPDATA','LOCALAPPDATA','XDG_DATA_HOME']})
service_snapshot('before')
preflight={'logical_cpus':psutil.cpu_count(), 'per_cpu_percent_one_second':psutil.cpu_percent(interval=1,percpu=True), 'process_names':[{'pid':p.pid,'name':p.info['name'],'status':p.info['status']} for p in psutil.process_iter(['name','status'])], 'probe_sha256':hashlib.sha256((ROOT/'tools/rig_perf_probe.gd').read_bytes()).hexdigest(), 'godot_sha256':hashlib.sha256(GODOT.read_bytes()).hexdigest(), 'python_version':sys.version,'isolated_user_data':str(user_data)}
(OUT/'preflight.json').write_text(json.dumps(preflight,indent=2)+'\n',encoding='utf8')
others=[{'pid':p.pid,'name':p.info['name'],'cmdline':p.info['cmdline']} for p in psutil.process_iter(['name','cmdline']) if 'godot' in (p.info['name'] or '').lower()]
assert not others, f'Another Godot process is running: {others}'
for number in range(1,6):
 for skin in ['rin','harbor_lamplighter_demo']:
  name=f'{number:02d}-{skin}';log=OUT/(name+'.log')
  if log.exists():raise SystemExit(f'Refusing to overwrite {log}')
  cmd=[str(PY),'tools/comfyui/gpu_lock.py','--',str(GODOT),'--path',str(ROOT),'--rendering-driver','vulkan','--rendering-method','forward_plus','res://tools/rig_perf_probe.tscn','--','--skin='+skin,'--count=10','--frames=600']
  samples=[];batch=0;start=time.perf_counter()
  with log.open('wb') as stream:
   process=subprocess.Popen(cmd,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,env=child_env)
   while process.poll() is None:
    batch+=1
    sample_elapsed=time.perf_counter()-start
    try:
     for child in psutil.Process(process.pid).children(recursive=True):
      try:
       if 'godot' not in child.name().lower():continue
       info=child.memory_info()
       samples.append({'batch':batch,'elapsed_s':sample_elapsed,'pid':child.pid,'name':child.name(),'rss_bytes':info.rss,'peak_working_set_bytes':getattr(info,'peak_wset',None),'private_bytes':getattr(info,'private',None)})
      except (psutil.NoSuchProcess,psutil.AccessDenied):pass
    except psutil.NoSuchProcess:pass
    time.sleep(.02)
   status=process.wait()
  pids={sample['pid']:{'pid':sample['pid'],'name':sample['name']} for sample in samples}
  family_rss={}
  peak_by_pid={}
  for sample in samples:
   family_rss[sample['batch']]=family_rss.get(sample['batch'],0)+sample['rss_bytes']
   peak_by_pid[sample['pid']]=max(peak_by_pid.get(sample['pid'],0),sample['peak_working_set_bytes'] or sample['rss_bytes'])
  ram={'scope':'Entire Godot console/actual-engine process family, never per-mode. Max sampled simultaneous RSS and conservative sum of each PID lifetime peak are both retained.','godot_processes':list(pids.values()),'max_observed_family_rss_bytes':max(family_rss.values(),default=0),'sum_individual_peak_working_set_bytes_conservative_upper_bound':sum(peak_by_pid.values()),'actual_engine_child_observed':any('_console' not in x['name'].lower() for x in pids.values())}
  row={'ram_family':ram,'run':number,'skin':skin,'command':cmd,'exit':status,'process_wall_seconds_including_lock_wait':time.perf_counter()-start,'log':log.name,'ram_samples':samples}
  records.append(row)
  (OUT/'runs.json').write_text(json.dumps({'scope':'Unmodified original rig_perf_probe; script animate CPU cost only, not rendered frame or GPU time. RAM is externally sampled for each complete probe process, not separate rigid/mesh phases; the original rigid queue_free is deferred until after the synchronous pair. Same source, engine, count, frames and weapon/action setup. Native Forward+ initialization is recorded in raw logs.','other_godot_processes_before':others,'runs':records},indent=2)+'\n',encoding='utf8')
  print(name,'exit',status,flush=True)
  if status:raise SystemExit(status)
service_snapshot('after')
after=hashes()
(OUT/'source-guard.json').write_text(json.dumps({'checked_files':len(before),'before':before,'after':after,'unchanged':before==after},indent=2)+'\n',encoding='utf8')
