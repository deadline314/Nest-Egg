"""Restore source-backed shirt pixels polluted by refinement's transparent RGB sampling."""
from pathlib import Path
import hashlib
import json
import cv2
import numpy as np
from PIL import Image

WORK = Path(__file__).resolve().parent
source = WORK / 'base_rgba.png'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '4cbdd4ff46e1ee28cabbfce08655e4052ff1cf7ef77dd72314eab6d20f855e59'
original = np.array(Image.open(source))
input_path = WORK / '07_refined/torso.png'
part = np.array(Image.open(input_path))
assert part.shape == original.shape == (1216, 832, 4)
hsv = cv2.cvtColor(part[:, :, :3], cv2.COLOR_RGB2HSV)
y, x = np.mgrid[:1216, :832]
reviewed = (x >= 306) & (x < 337) & (y >= 385) & (y < 490)
polluted = reviewed & (part[:, :, 3] > 127) & (hsv[:, :, 0] >= 130) & (hsv[:, :, 0] <= 175) & (hsv[:, :, 1] > 45)
assert 0 < int(polluted.sum()) <= 60
fixed = part.copy()
restore = polluted & (original[:, :, 3] >= 250)
fixed[restore] = original[restore]
# The remaining refinement-added rim pixels are outside the original shirt silhouette.
remove = polluted & ~restore
assert np.all(original[:, :, 3][remove] < 40)
fixed[:, :, 3][remove] = 0
assert np.array_equal(fixed[~polluted], part[~polluted])
out = WORK / 'overrides/refined/torso.png'
out.parent.mkdir(parents=True, exist_ok=True)
Image.fromarray(fixed).save(out)
receipt = {'reason': 'Transparent magenta RGB sampled into shirt by close_fill; source-backed repair only.',
           'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
           'input_sha256': hashlib.sha256(input_path.read_bytes()).hexdigest(),
           'output_sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
           'restored_source_pixels': int(restore.sum()), 'removed_outside_source_pixels': int(remove.sum()),
           'outside_mask_unchanged': True, 'coordinates': np.argwhere(polluted).tolist()}
(WORK / 'evidence/torso-source-repair.json').write_text(json.dumps(receipt, indent=2), encoding='utf8')
print(json.dumps(receipt | {'coordinates': 'recorded in evidence receipt'}))
