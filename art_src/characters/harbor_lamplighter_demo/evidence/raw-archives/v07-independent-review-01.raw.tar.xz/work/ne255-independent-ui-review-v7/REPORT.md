# NE-255：v7 wave / shoulder_front 獨立只讀審查

審查範圍為 `harbor_lamplighter_demo` **凍結 v7**，不是目前 v8 的角色驗收。只新增本目錄的報告、重算腳本及結果；未修改角色、骨架、動畫、checker、門檻或原始失敗封包。

## 結論與最小正確處理

代表幀 26 的主空隙是下巴外輪廓與抬起的袖內輪廓交會後留下的空氣口袋，來源資料支持此分類；沒有證據顯示它是肩根材質斷接或肘部 mesh 折疊。原始 342 筆每筆都含同一小片區域的主孔，完整角色重播後每筆也都仍有孔。可寫成「342 筆均包含同區域的主姿勢空隙」，但**不能寫成所有孔像素均已逐一完成來源反投影、342 筆自動通過或角色 all 0**。

v7 另有真實外觀缺陷：原生近拍能看見抬臂袖子靠近臉／肘位置的藍色矩形凸塊。它與要分類的主空氣口袋分開處理。最小正確方向是撤掉無需求的矩形 arm underlap，保留自然輪廓，再用新版本真實來源完整重驗；不應為消除這 342 個數字而向下巴空氣填袖料。fresh_character 已提供 v8 撤除矩形後的近拍作對照，但本報告不將 v7 的結果移作 v8 通過證明。

## 原始數據與完整類別範圍

原始封包：`art_src/characters/harbor_lamplighter_demo/evidence/npc-target-v7/`。

| 原始項目 | 結果 |
|---|---:|
| 全 NPC 封包 | 342 / 14400 失敗 |
| 失敗狀態／關節 | 全部 wave / shoulder_front |
| 1×，正／反面 | 各 72 筆 |
| 3.4×，正／反面 | 各 99 筆 |
| 有 8 鄰接封閉孔的樣本 | 268 |
| 僅邊緣 notch 的樣本 | 74 |
| 原始孔像素 occurrences（跨幀累加，非唯一像素） | 1103 |
| 主區孔 occurrences | 1073 |
| 其餘較上方副區 occurrences | 30 |

反面以 `x = 127 - x` 鏡回正面後，342 / 342 均包含以下主區孔，沒有只靠副孔才失敗的樣本：1× cell `x=67..68,y=59..60`；3.4× cell `x=75..79,y=48..51`。3.4× 全部孔的外包範圍為 `x=75..81,y=45..51`，故上方副孔不得只憑主區代表像素一概判定為自然。

原始、frozen pair 及 frozen whole 三組的全部 480 個 shoulder cell，在既有 56×56 關節 band 內皆是 `components=1,center_alpha=255`。這證明測到的肩根中心持續覆蓋，且沒有分裂的輪廓；它本身不等同於全角色外觀通過。

## 代表幀 26：主口袋的來源與完整角色

可直接檢視：

- [原始隔離 pair PNG，3.4× frame 26](../../art_src/characters/harbor_lamplighter_demo/evidence/npc-target-v7/wave_3.4_026.png)。正面 shoulder cell 起點 `(128,0)`，反面起點 `(896,0)`。
- [同幀真 triangles / UV / to_cell](../../art_src/characters/harbor_lamplighter_demo/evidence/trace-shoulder-v7/frames.json)。此幀兩面 3.4× shoulder crop 的 RGBA 與原始 target 完全一致。
- [凍結 whole PNG，同幀](../../art_src/characters/harbor_lamplighter_demo/evidence/replay-v7-whole-full/wave_3.4_026.png)。whole 正面 cell 起點 `(0,0)`，反面 `(128,0)`。
- [v7 原生完整全彩近拍](../../pm/Nest-Egg/images/NE-255-fresh-character/diagnostic/wave-frame26-mesh-normal-on.png)。可見完整衣領／上背／肩根連續，空隙位於下巴與抬臂內緣；亦可見另一項矩形袖凸塊缺陷。
- [凍結原圖](../../art_src/characters/harbor_lamplighter_demo/evidence/shoulder-v7-source-snapshot/base_rgba.png)、[SAM arm mask](../../art_src/characters/harbor_lamplighter_demo/evidence/shoulder-v7-source-snapshot/sam/points_arm.png)、[torso 分件](../../art_src/characters/harbor_lamplighter_demo/evidence/shoulder-v7-source-snapshot/07_refined/torso.png)、[arm_upper 分件](../../art_src/characters/harbor_lamplighter_demo/evidence/shoulder-v7-source-snapshot/07_refined/arm_upper.png)。

正面 cell 的四個孔為 `(76,48),(77,48),(78,48),(76,49)`，原始 alpha 分別為 `0,0,0,21`；反面對應為 `(51,48),(50,48),(49,48),(51,49)`。pair 和 whole 的這四點 RGBA 相同，額外零件沒有把它們填掉。

| cell 像素 | torso 原圖座標 | arm_upper 原圖座標 |
|---|---|---|
| 76,48 | 449.47455,180.88557 | 422.56502,379.01240 |
| 77,48 | 455.50113,181.14948 | 419.99983,384.47217 |
| 78,48 | 461.52771,181.41340 | 417.43464,389.93194 |
| 76,49 | 449.21064,186.91215 | 417.10526,376.44721 |

torso 的四個最近來源像素，原圖／P／07 torso alpha 均為 0，位置確在原畫下巴外的透明空間。arm_upper 的四個最近來源像素在原圖 alpha 為 `254,255,255,255`，但 SAM arm 全黑、07 arm alpha 全 0，而 07 torso 均為 254：這些原圖像素屬於袖內側以外的 torso 料，不能因原圖不透明就認定裁掉了應屬袖子的材質。

獨立用實際三角形重算的 torso UV 為 `(141.30..153.05,49.39..55.26)`，均落 triangle `[1,2,5]`；arm_upper UV 為 `(94.20..99.51,137.35..150.50)`，均落 triangle `[1,5,4]`。兩個三角形的 `vertices - UV` 都是固定平移，沒有在這些點發生關節帶的非剛性折疊。這是排除該代表幀「mesh 折出孔」的證據，並非宣稱整個角色的 mesh 全通過。

## 副區代表幀 32：完整頭部的遮擋

[原始 pair frame 32](../../art_src/characters/harbor_lamplighter_demo/evidence/npc-target-v7/wave_3.4_032.png)、[同幀凍結 whole](../../art_src/characters/harbor_lamplighter_demo/evidence/replay-v7-frame32-whole/wave_3.4_032.png)、[15 件真幾何資料](../../art_src/characters/harbor_lamplighter_demo/evidence/replay-v7-frame32-whole/frames.json)。正面 whole cell 起點 `(0,0)`。

| cell 點 | pair alpha | whole alpha | head UV | 凍結 head runtime 相鄰 alpha |
|---|---:|---:|---|---|
| 80,45 | 2 | 232 | 128.981,146.789 | `[[251,206],[252,228]]` |
| 80,46 | 5 | 254 | 128.392,152.642 | `[[254,254],[254,254]]` |
| 80,47 | 111 | 128 | 127.803,158.495 | `[[162,63],[41,5]]` |

前兩點在完整頭部材質內。第三點是抗鋸齒輪廓混合，使原始 alpha 111 在 whole 成為 128，剛達既有門檻；不得說三點都是完全不透明的頭部覆蓋。幾何與來源重算明細在 `verification.json`。

所有 1103 原始孔 occurrences 中，whole 有 15 點達到 128。扣除下一節的 1 點 replay 不一致，額外材質實際使 14 點越過門檻：3.4× frame 32 兩面各 3 點，33 兩面各 2 點，34 兩面各 1 點，48 兩面各 1 點。每個原始失敗樣本的主口袋仍有部分留在 whole。因此這些覆蓋不能證明所有 pair 孔都是接縫，也不能以 whole 代替隔離 pair 驗收。

另檢視 3.4× whole 的 frame 18／22／26／32／65／98，涵蓋首次、最大孔、主區代表及副區極值；它們上背、衣領、肩根輪廓連續。這是代表幀的全彩檢視，並未宣稱人工逐格逐像素檢視所有畫面。

## 封包不一致與禁止外推的限制

- `shoulder-v7-source-snapshot/hashes.json` 的 **63 份凍結檔案全部驗 hash 相符**。重播 wrapper 只把這批原始 RGBA／rig／motion 放進程序快取，不換正式角色檔。
- target → 最新 frozen pair 共 480 cell：395 alpha byte 全等、479 個 `>=128` mask 全等；總共 309 個 alpha byte 不同，但僅 **1 個 threshold bit 不同**。frame 26 的 3.4× 正反面 crop 都完全相等，可安全使用這幀的來源追蹤。
- 唯一 bit 差是 **3.4×、反面、frame 98、cell (51,49)**：原 target 為孔，pair 重播已達門檻。原 target 該格仍保留 7 孔／5 enclosed，較早 trace 為 6／4；兩者仍失敗。不得消去這一點，也不把 replay 當原 target 的 byte-identical 替代品。
- 小包 frame 26 replay pair 的 alpha 完全相等，但有 262 個 RGB 色版值與 trace 不同；使用 raw ImageTexture 的色彩路徑差異尚未證實根因。因此 **replay 僅用於 alpha／幾何／遮擋核對**，不聲稱與原生匯入路徑的全彩逐位元一致。
- frozen pair 的既有 checker 仍報 **342/480**；whole 診斷報 **376/480**（頭部等額外輪廓會把外部空間圍成更多封閉小區）。原 target **342/14400**、pair 342/480、whole 376/480 是三種不同範圍，必須分列。
- 268「enclosed」是 8 鄰接 alpha 拓撲分類，不能獨自判斷人體上應該有料或空氣。原 checker 及其所有數值判定原樣保留。
- 本報告只對 frame 26／32 指定像素做來源反投影；342 的完整家族證據為原始孔位置、鏡像、每格拓撲及 whole 遮擋核對。**未對全部 1103 個 occurrences 逐一取出該幀真幾何再反投影。**
- v8 已改來源／runtime arm 貼圖；本報告沒有證明 v7→v8 主區的位元或實際幾何完全相同。v8 的最終結論以其真來源、原生完整矩陣與每項未通過條件為準。

原封包完整性：

```text
frames.json          e801360f89631f21e95245fc2d3c79c2752aaab2f7246cd95e6bb12d3dbb75ff
report.json          bc1d3480d0b38b9451937f2e5deeb920034be02bfb3feb059bc17b6967691232
wave_3.4_026.png     f32027d877b846ec9793d733ef85db445c23c8c23d82722a75b19a3e4b47af0e
```

## 獨立重算方式

從 repo 執行 `python -B work/ne255-independent-ui-review-v7/verify.py`。腳本只讀原始證據與凍結來源，輸出本目錄 `verification.json`，不呼叫 checker 的寫檔入口，不更動其門檻。此次執行 exit 0，核對得到上述數字。

反投影使用像素中心 `(x+0.5,y+0.5)`，把記錄的 mesh `vertices` 經 `to_cell` 轉為 cell 三角形，再解 barycentric weights 插值實際 UV；非 mesh 零件使用同一 `to_cell` 的反矩陣減 `rect_origin`。以凍結 spec 及純函式 `cut_layers.part_transform`，將 runtime UV 轉回原圖座標。最近來源像素與 runtime 四鄰 alpha 分開記錄，避免把最近點 alpha 冒充實際濾波後的渲染 alpha。snapshot 的 ImageTexture `resource_path` 空白，故材質名稱從凍結 `character.json` 的 parts 對應取得，不猜測目前角色配置。

未執行／風險：此為只讀視覺診斷，未跑產品範圍測試、效能或實體手把驗收；沒有角色通過／結案判定。未解決的 v8 戰鬥、頸部、死亡、踝部問題仍由其完整矩陣保留並處理。
