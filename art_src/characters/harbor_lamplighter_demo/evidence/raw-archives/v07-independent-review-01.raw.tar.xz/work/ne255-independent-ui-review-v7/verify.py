"""Read frozen NE-255 evidence; write results only beside this review script.

Run from any directory with: python -B work/ne255-independent-ui-review-v7/verify.py
No checker, acceptance threshold, source asset, or original report is modified.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from PIL import Image
from scipy import ndimage

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
EVIDENCE = ROOT / "art_src/characters/harbor_lamplighter_demo/evidence"
SNAPSHOT = EVIDENCE / "shoulder-v7-source-snapshot"
sys.path.insert(0, str(ROOT / "tools/comfyui"))
from cut_layers import part_transform


def read_json(path):
    return json.loads(path.read_text(encoding="utf8"))


def rgba(path):
    return np.asarray(Image.open(path).convert("RGBA"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def crop(image, cell):
    x, y, width, height = cell["rect"]
    assert (width, height) == (128, 128)
    return image[y:y + height, x:x + width, 3]


def holes(alpha):
    # Exactly the original checker band and alpha threshold, without exemptions.
    band = alpha[36:92, 36:92] >= 128
    yy, xx = np.where(ndimage.binary_fill_holes(band) & ~band)
    return yy + 36, xx + 36


def map_pixel(cell, pixel, spec, character):
    k = spec["tex_px_per_wp"] / spec["illustration_px_per_wp"]
    joints = {name: np.asarray(value) * k for name, value in spec["joints"].items()}
    names = {part["name"]: part["texture"] for part in character["parts"]}
    result = []
    for part in cell["geometry_sample"]:
        transform = np.asarray(part["to_cell"])
        uv = None
        triangle_indices = None
        root_rigid = None
        if "vertices" in part:
            vertices = np.asarray(part["vertices"])
            texture_uv = np.asarray(part["uv"])
            screen = np.c_[vertices, np.ones(len(vertices))] @ transform.T
            for triangle in part["triangles"]:
                matrix = np.vstack([screen[triangle].T, np.ones(3)])
                try:
                    weights = np.linalg.solve(matrix, [pixel[0] + .5, pixel[1] + .5, 1])
                except np.linalg.LinAlgError:
                    continue
                if weights.min() >= -1e-6:
                    uv = weights @ texture_uv[triangle]
                    triangle_indices = triangle
                    offsets = vertices[triangle] - texture_uv[triangle]
                    root_rigid = bool(np.max(np.abs(offsets - offsets[0])) < 1e-5)
                    break
        else:
            uv = np.linalg.solve(transform[:, :2], np.asarray(pixel) + .5 - transform[:, 2])
            uv -= part["rect_origin"]
        if uv is None:
            continue
        # Snapshot ImageTexture resource_path is empty; frozen character data maps names.
        name = names[part["part"]]
        source = Image.open(SNAPSHOT / "07_refined" / f"{name}.png")
        affine, *_ = part_transform(source, spec["parts"][name], joints, k)
        source_xy = (affine @ [*uv, 1]) / k
        sx, sy = np.round(source_xy).astype(int)
        valid = 0 <= sx < source.width and 0 <= sy < source.height
        base = Image.open(SNAPSHOT / "base_rgba.png")
        torso = Image.open(SNAPSHOT / "07_refined/torso.png")
        sam = Image.open(SNAPSHOT / "sam/points_arm.png").convert("RGB")
        source_alpha = source.getpixel((sx, sy))[3] if valid else None
        entry = {
            "part": part["part"], "texture_name": name,
            "uv": uv.tolist(), "source_xy": source_xy.tolist(),
            "source_nearest": [int(sx), int(sy)], "source_nearest_alpha": source_alpha,
            "triangle": triangle_indices, "triangle_is_rigid_translation_in_uv": root_rigid,
        }
        if valid:
            entry.update(base_alpha=base.getpixel((sx, sy))[3],
                         torso_source_alpha=torso.getpixel((sx, sy))[3],
                         sam_arm_rgb=list(sam.getpixel((sx, sy))))
        runtime = rgba(SNAPSHOT / "runtime-parts" / f"{name}.png")
        rx, ry = np.floor(uv - .5).astype(int)
        if 0 <= rx < runtime.shape[1] - 1 and 0 <= ry < runtime.shape[0] - 1:
            entry["runtime_alpha_four_neighbors"] = runtime[ry:ry + 2, rx:rx + 2, 3].tolist()
        result.append(entry)
    return result


def main():
    manifest = read_json(SNAPSHOT / "hashes.json")
    mismatches = [name for name, expected in manifest.items()
                  if digest(SNAPSHOT / name) != expected]
    assert not mismatches, mismatches
    directories = {"target": EVIDENCE / "npc-target-v7",
                   "pair": EVIDENCE / "replay-v7-pair-full",
                   "whole": EVIDENCE / "replay-v7-whole-full"}
    groups = {name: read_json(directory / "frames.json")
              for name, directory in directories.items()}
    stats = Counter()
    mask_mismatches = []
    covered_pixels = []
    topology = {name: Counter() for name in directories}
    for group in groups["target"]:
        if group["pose"] != "wave":
            continue
        other_groups = {name: next(g for g in groups[name] if g["zoom"] == group["zoom"])
                        for name in ("pair", "whole")}
        for sample in group["samples"]:
            images = {name: rgba(directory / sample["file"])
                      for name, directory in directories.items()}
            for cell in group["cells"]:
                if cell["joint"] != "shoulder_front":
                    continue
                alphas = {}
                for name in directories:
                    selected = cell if name == "target" else next(
                        c for c in other_groups[name]["cells"] if c["facing"] == cell["facing"])
                    alphas[name] = crop(images[name], selected)
                    band = alphas[name][36:92, 36:92]
                    count = ndimage.label(band >= 128, np.ones((3, 3)))[1]
                    topology[name][f"components={count},center={int(band[28, 28])}"] += 1
                target, pair, whole = [alphas[name] for name in ("target", "pair", "whole")]
                stats["cells"] += 1
                stats["pair_alpha_exact_cells"] += int(np.array_equal(target, pair))
                bit_diff = (target >= 128) != (pair >= 128)
                stats["pair_mask_exact_cells"] += int(not bit_diff.any())
                stats["pair_alpha_different_pixels"] += int((target != pair).sum())
                stats["pair_mask_different_pixels"] += int(bit_diff.sum())
                if bit_diff.any():
                    yy, xx = np.where(bit_diff)
                    mask_mismatches.append({"zoom": group["zoom"], "facing": cell["facing"],
                                            "frame": sample["frame"], "pixels": list(map(list, zip(xx.tolist(), yy.tolist())))})
                yy, xx = holes(target)
                if not len(xx):
                    continue
                stats["original_failed_samples"] += 1
                stats["original_hole_pixel_occurrences"] += len(xx)
                facing_x = xx if cell["facing"] == 1 else 127 - xx
                if group["zoom"] == 3.4:
                    primary = (facing_x >= 75) & (facing_x <= 79) & (yy >= 48) & (yy <= 51)
                else:
                    primary = (facing_x >= 67) & (facing_x <= 68) & (yy >= 59) & (yy <= 60)
                stats["samples_with_primary_region_hole"] += int(primary.any())
                stats["primary_hole_pixel_occurrences"] += int(primary.sum())
                stats["other_hole_pixel_occurrences"] += int((~primary).sum())
                filled_whole = whole[yy, xx] >= 128
                filled_pair = pair[yy, xx] >= 128
                stats["original_holes_filled_in_whole"] += int(filled_whole.sum())
                stats["original_holes_already_filled_in_replay_pair"] += int(filled_pair.sum())
                stats["original_failed_samples_with_hole_remaining_in_whole"] += int((~filled_whole).any())
                for index in np.flatnonzero(filled_whole):
                    covered_pixels.append({"zoom": group["zoom"], "facing": cell["facing"],
                        "frame": sample["frame"], "pixel": [int(xx[index]), int(yy[index])],
                        "pair_alpha": int(pair[yy[index], xx[index]]),
                        "whole_alpha": int(whole[yy[index], xx[index]]),
                        "already_filled_in_pair": bool(filled_pair[index])})
    assert stats["cells"] == 480
    assert stats["original_failed_samples"] == stats["samples_with_primary_region_hole"] == 342
    assert stats["pair_mask_exact_cells"] == 479
    assert stats["original_failed_samples_with_hole_remaining_in_whole"] == 342
    spec = read_json(SNAPSHOT / "spec.json")
    character = read_json(SNAPSHOT / "character.json")
    mappings = []
    for dirname, frame, pixels in [
        ("trace-shoulder-v7", 26, [(76, 48), (77, 48), (78, 48), (76, 49)]),
        ("replay-v7-frame32-whole", 32, [(80, 45), (80, 46), (80, 47), (76, 48), (77, 48), (78, 48), (76, 49)]),
    ]:
        group = next(g for g in read_json(EVIDENCE / dirname / "frames.json") if g["zoom"] == 3.4)
        cell = next(c for c in group["cells"] if c["facing"] == 1)
        assert cell["geometry_frame"] == frame
        for pixel in pixels:
            mappings.append({"directory": dirname, "frame": frame, "cell_pixel": list(pixel),
                             "parts": map_pixel(cell, pixel, spec, character)})
    target_report = read_json(directories["target"] / "report.json")
    result = {
        "scope": "Frozen v7 diagnostic review; no current-character acceptance",
        "frozen_hashes_verified": len(manifest), "frozen_hash_mismatches": mismatches,
        "original_raw_report": {key: target_report[key] for key in ("samples", "failed_samples", "summary")},
        "original_target_sha256": {name: digest(directories["target"] / name)
                                   for name in ("frames.json", "report.json", "wave_3.4_026.png")},
        "stats": dict(stats), "topology": {name: dict(value) for name, value in topology.items()},
        "replay_mask_mismatches": mask_mismatches, "original_holes_covered_in_whole": covered_pixels,
        "representative_source_mappings": mappings,
    }
    (OUT / "verification.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf8")
    print(json.dumps({"snapshot_hashes": len(manifest), **dict(stats)}, indent=2))


if __name__ == "__main__":
    main()
