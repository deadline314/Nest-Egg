#!/usr/bin/env bash
set -uo pipefail
cd D:/NestEggVerification/role-20261117
function python3() { D:/ComfyUI/.venv-rocm/Scripts/python.exe "$@"; }
export -f python3
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
export GODOT='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
export SHARDS=2
export LOG_DIR='D:/NestEggVerification/evidence-20261117/ne255/official-3713/shards'
export TEMP='D:/NestEggVerification/evidence-20261117/ne255/official-3713/tmp'
export TMP="$TEMP" TMPDIR="$TEMP"
mkdir -p "$LOG_DIR" "$TEMP"
python3 D:/NestEggVerification/evidence-20261117/ne255/official-3713/source-guard.py before
before=$?
if [ "$before" -ne 0 ]; then exit "$before"; fi
python3 --version
"$GODOT" --version
 tools/run_tests_changed.sh 3713db51062b14ed33ab61488559109fc41e2bfd 2>&1 | tee D:/NestEggVerification/evidence-20261117/ne255/official-3713/runner.log
status=${PIPESTATUS[0]}
printf '%s\n' "$status" > D:/NestEggVerification/evidence-20261117/ne255/official-3713/runner.exit
python3 D:/NestEggVerification/evidence-20261117/ne255/official-3713/source-guard.py after
guard=$?
if [ "$guard" -ne 0 ]; then exit "$guard"; fi
exit "$status"
