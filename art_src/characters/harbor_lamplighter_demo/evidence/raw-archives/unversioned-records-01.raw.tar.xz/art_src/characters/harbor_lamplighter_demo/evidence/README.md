# NE-255 new-reader character evidence

The 123 production paths in `production-v12-freeze-123.json` are the frozen v12 authoring/runtime/preview source. Original design, transparent source, source parts, spec, recipe and rebuild helpers remain ordinary files outside these archives. This is an isolated adult noncombat NPC demonstration, not new story content.

Read `REVIEW-v12.md` for the actual verdict and limitations. The original final joint checker records **358 failures / 120960 samples in each pair-only and as-worn matrix**; automatic acceptance remains false. Manual source/geometry/native-image review is recorded separately. A successful archive verifier or game test does not turn those failures into zero.

## Verify the complete raw history

Use ordinary Python 3.11+ with its standard library, from this directory:

```powershell
python verify_raw_archives.py
```

Or pass `--index <absolute-path-to-raw-archives/index.json>`. Verification streams every tar member without extracting it or touching source files. It checks archive and member-manifest SHA256, archive size below 50,000,000 bytes, every original member SHA256/size, unique safe member names and complete counts. The included small positive/negative controls demonstrate rejection of an incorrect inner member hash even when the archive and sidecar hashes are correct.

`raw-archives/index.json` lists each independently readable `.raw.tar.xz` volume and its sidecar. Volumes group explicit vN labels from the original paths, with unversioned records and frozen authoring separated; this grouping does not invent dates for unlabelled diagnostics. The sidecars preserve repository-relative original paths, SHA256, byte sizes and original modification times. Tar member times are normalized for reproducibility. All original files remain locally retained; the delivery avoids staging the same thousands of images and reports again as loose files.

The history includes original failures, rejected variants, final matrix frames/reports/geometry, source snapshots, native captures, generation logs, official test logs and independent review. Early normal-on/off diagnostic controls did not freeze all their original spec/parts: those images remain diagnostic evidence, not a replayable final character source claim. The frozen v12 snapshot and normal authoring source are kept distinct.

Representative original native PNGs live in `pm/Nest-Egg/images/NE-255-fresh-character/`; marker/locator composites are explicitly diagnostic and do not replace their raw 128px crops. The official source guard compares every tracked runtime/art/authoring/data/test/tool/CI source plus the exact 123 frozen paths before and after the original test runner. Test times under shared load are not isolated performance acceptance.
