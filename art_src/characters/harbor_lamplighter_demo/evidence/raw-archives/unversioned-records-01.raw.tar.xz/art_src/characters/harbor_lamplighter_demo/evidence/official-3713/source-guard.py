from pathlib import Path
import hashlib,json,subprocess,sys
TARGET=Path('D:/NestEggVerification/role-20261117')
LOG=Path('D:/NestEggVerification/evidence-20261117/ne255/official-3713')
ROOT=Path('C:/Users/stanl/Github/Nest-Egg')
mode=sys.argv[1]
frozen=json.loads((ROOT/'art_src/characters/harbor_lamplighter_demo/evidence/production-v12-freeze-123.json').read_text(encoding='utf8'))['files']
prefixes=['autoload','core','game','ui','data','art','art_src','assets_src','tests','tools','project.godot','.github','.gitattributes']
raw=subprocess.check_output(['git','-C',str(TARGET),'ls-files','-z','--',*prefixes])
paths=sorted(set(raw.decode('utf8').strip('\0').split('\0'))|set(frozen))
result={}
for relative in paths:
 with (TARGET/relative).open('rb') as stream:result[relative]=hashlib.file_digest(stream,'sha256').hexdigest()
for p,h in frozen.items():assert result[p]==h,p
(LOG/f'source-{mode}.json').write_text(json.dumps({'scope':'All tracked Godot runtime/art/authoring/data/test/tool/CI source plus exact 123 frozen new appearance paths; historical pm archives excluded from hashing only, remain fully checked out.','files':result},indent=2)+'\n',encoding='utf8')
if mode=='after':
 before=json.loads((LOG/'source-before.json').read_text(encoding='utf8'))['files'];changes={p:{'before':before.get(p),'after':result.get(p)} for p in set(before)|set(result) if before.get(p)!=result.get(p)}
 (LOG/'source-guard-result.json').write_text(json.dumps({'changed_source':changes,'checked_files':len(result),'frozen_123_match':True},indent=2)+'\n',encoding='utf8');print('SOURCE_GUARD',len(result),'files;',len(changes),'changed',flush=True)
 if changes:raise SystemExit(1)
else:print('SOURCE_BEFORE',len(result),'files; frozen123 matched',flush=True)
